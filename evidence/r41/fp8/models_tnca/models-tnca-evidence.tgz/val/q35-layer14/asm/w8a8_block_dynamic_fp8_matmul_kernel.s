    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.addi       s4, s2, #0
    s.ld.d       s2, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // C: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // Bs: device_ptr64 at arg_base+24
    s.ld.sw      s7, [s1, #32]                   // M: i32 at arg_base+32
    s.ld.sw      s8, [s1, #40]                   // N: i32 at arg_base+40
    s.ld.sw      s9, [s1, #48]                   // K: i32 at arg_base+48
    s.ld.sw      s10, [s1, #56]                  // stride_am: i32 at arg_base+56
    s.ld.sw      s11, [s1, #64]                  // stride_bn: i32 at arg_base+64
    s.ld.sw      s12, [s1, #72]                  // stride_cm: i32 at arg_base+72
    s.ld.sw      s13, [s1, #80]                  // stride_bs_n: i32 at arg_base+80
rows_1:
    s.movz       s1, #127
    s.movz       s14, #128
    s.rdspecial  s15, pid.x
    s.add        s16, s7, s1
    s.movz       s17, #0
    s.movz       s18, #0
    s.cmp.lt     s19, s16, s17
    s.rdspecial  s17, pid.y
    s.sub        s20, s18, s19
    s.movz       s18, #0
    s.movz       s19, #0
    s.cmp.lt     s21, s14, s18
    // rows [r0, r0 + 16) of a 128-row program (row_split)
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s18, s16, s20
    s.sub        s16, s19, s21
    v.splat      v1, s4
    s.sub        s19, s18, s20
    v.add        v2, v0, v1
    s.add        s18, s8, s1
    s.movz       s21, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s18, s21
    s.movz       s21, #0
    s.sub        s24, s22, s23
    s.movz       s22, #0
    s.cmp.lt     s23, s14, s21
    s.lshri      s21, s19, #7
    s.xor        s25, s20, s16
    s.muli       s20, s21, #128
    s.xor        s26, s21, s25
    s.sub        s21, s26, s25
    s.xor        s25, s14, s16
    s.sub        s26, s22, s23
    s.sub        s22, s25, s16
    s.xor        s16, s18, s24
    s.xor        s18, s14, s26
    s.sub        s22, s16, s24
    s.sub        s16, s19, s20
    s.lshri      s16, s22, #7
    s.xor        s19, s24, s26
    s.movz       s20, #8
    s.xor        s23, s16, s19
    s.movz       s24, #0
    s.sub        s25, s23, s19
    s.movz       s19, #0
    s.mul        s23, s15, s25
    s.mul        s15, s25, s20
    s.muli       s25, s16, #128
    s.sub        s16, s18, s26
    s.movz       s16, #0
    s.add        s18, s23, s17
    s.cmp.lt     s17, s15, s16
    s.movz       s16, #0
    s.cmp.lt     s23, s18, s24
    s.sub        s24, s19, s17
    s.sub        s17, s16, s23
    s.sub        s16, s22, s25
    s.xor        s16, s15, s24
    s.xor        s19, s18, s17
    s.sub        s22, s16, s24
    s.movz       s16, #0
    s.movz       s23, #1
    s.sub        s25, s19, s17
    s.movz       s19, #0
    s.addi       s26, s16, #0
    s.cmp.eq     s16, s22, s23
    s.addi       s23, s19, #0
    s.mov        s26, s25
    br.nz        s16, sdiv_done_3
    s.movz       s16, #0
    s.mov        s26, s16
    s.movz       s16, #31
    s.addi       s19, s16, #0
sdiv_4:
    s.lshr       s16, s25, s19
    s.andi       s27, s16, #1
    s.shli       s16, s23, #1
    s.or         s28, s16, s27
    s.movz       s16, #0
    s.cmp.geu    s27, s28, s22
    s.sub        s29, s16, s27
    s.and        s16, s22, s29
    s.sub        s27, s28, s16
    s.mov        s23, s27
    s.movz       s16, #1
    s.shl        s27, s16, s19
    s.and        s16, s27, s29
    s.or         s27, s26, s16
    s.mov        s26, s27
    s.subi       s16, s19, #1
    s.mov        s19, s16
    s.movz       s16, #0
    s.cmp.ge     s27, s19, s16
    br.nz        s27, sdiv_4
sdiv_done_3:
    s.xor        s16, s17, s24
    s.movz       s17, #0
    s.xor        s19, s26, s16
    s.movz       s22, #0
    s.cmp.lt     s23, s15, s17
    s.sub        s17, s19, s16
    s.movz       s16, #0
    s.cmp.lt     s19, s18, s22
    s.sub        s22, s16, s23
    s.movz       s16, #0
    s.mul        s23, s17, s20
    s.sub        s17, s16, s19
    s.xor        s16, s15, s22
    s.xor        s15, s18, s17
    s.sub        s18, s16, s22
    s.movz       s16, #0
    s.sub        s19, s21, s23
    s.sub        s21, s15, s17
    s.movz       s15, #0
    s.addi       s22, s16, #0
    s.min.s      s16, s19, s20
    s.movz       s19, #1
    s.addi       s20, s15, #0
    s.cmp.eq     s15, s18, s19
    s.mov        s22, s21
    br.nz        s15, sdiv_done_5
    s.movz       s15, #0
    s.mov        s22, s15
    s.movz       s15, #31
    s.addi       s19, s15, #0
sdiv_6:
    s.lshr       s15, s21, s19
    s.andi       s24, s15, #1
    s.shli       s15, s20, #1
    s.or         s25, s15, s24
    s.movz       s15, #0
    s.cmp.geu    s24, s25, s18
    s.sub        s26, s15, s24
    s.and        s15, s18, s26
    s.sub        s24, s25, s15
    s.mov        s20, s24
    s.movz       s15, #1
    s.shl        s24, s15, s19
    s.and        s15, s24, s26
    s.or         s24, s22, s15
    s.mov        s22, s24
    s.subi       s15, s19, #1
    s.mov        s19, s15
    s.movz       s15, #0
    s.cmp.ge     s24, s19, s15
    br.nz        s24, sdiv_6
sdiv_done_5:
    s.xor        s15, s20, s17
    s.movz       s18, #0
    s.sub        s19, s15, s17
    s.movz       s15, #0
    s.movz       s17, #0
    s.cmp.lt     s20, s16, s18
    s.movz       s18, #0
    s.cmp.lt     s21, s19, s15
    s.sub        s15, s17, s20
    s.sub        s17, s18, s21
    s.xor        s18, s16, s15
    s.xor        s20, s19, s17
    s.sub        s21, s18, s15
    s.movz       s15, #0
    s.movz       s18, #1
    s.sub        s22, s20, s17
    s.movz       s20, #0
    s.addi       s24, s15, #0
    s.cmp.eq     s15, s21, s18
    s.addi       s18, s20, #0
    s.mov        s24, s22
    br.nz        s15, sdiv_done_7
    s.movz       s15, #0
    s.mov        s24, s15
    s.movz       s15, #31
    s.addi       s20, s15, #0
sdiv_8:
    s.lshr       s15, s22, s20
    s.andi       s25, s15, #1
    s.shli       s15, s18, #1
    s.or         s26, s15, s25
    s.movz       s15, #0
    s.cmp.geu    s25, s26, s21
    s.sub        s27, s15, s25
    s.and        s15, s21, s27
    s.sub        s25, s26, s15
    s.mov        s18, s25
    s.movz       s15, #1
    s.shl        s25, s15, s20
    s.and        s15, s25, s27
    s.or         s25, s24, s15
    s.mov        s24, s25
    s.subi       s15, s20, #1
    s.mov        s20, s15
    s.movz       s15, #0
    s.cmp.ge     s25, s20, s15
    br.nz        s25, sdiv_8
sdiv_done_7:
    s.movz       s15, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.cmp.lt     s22, s16, s15
    s.cmp.lt     s15, s19, s20
    s.sub        s20, s21, s22
    s.movz       s21, #0
    s.xor        s22, s16, s20
    s.sub        s16, s21, s15
    s.xor        s15, s18, s17
    s.xor        s18, s19, s16
    s.sub        s19, s22, s20
    s.movz       s21, #0
    s.sub        s22, s15, s17
    s.sub        s15, s18, s16
    s.movz       s17, #0
    s.addi       s18, s21, #0
    s.add        s21, s23, s22
    s.movz       s22, #1
    s.addi       s23, s17, #0
    s.cmp.eq     s17, s19, s22
    s.mov        s18, s15
    br.nz        s17, sdiv_done_9
    s.movz       s17, #0
    s.mov        s18, s17
    s.movz       s17, #31
    s.addi       s22, s17, #0
sdiv_10:
    s.lshr       s17, s15, s22
    s.andi       s24, s17, #1
    s.shli       s17, s23, #1
    s.or         s25, s17, s24
    s.movz       s17, #0
    s.cmp.geu    s24, s25, s19
    s.sub        s26, s17, s24
    s.and        s17, s19, s26
    s.sub        s24, s25, s17
    s.mov        s23, s24
    s.movz       s17, #1
    s.shl        s24, s17, s22
    s.and        s17, s24, s26
    s.or         s24, s18, s17
    s.mov        s18, s24
    s.subi       s17, s22, #1
    s.mov        s22, s17
    s.movz       s17, #0
    s.cmp.ge     s24, s22, s17
    br.nz        s24, sdiv_10
sdiv_done_9:
    s.mul        s15, s21, s14
    s.xor        s17, s16, s20
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s16, s18, s17
    v.movi       v1, #16
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #32
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #48
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #64
    v.iota       v9                              // arange(0, VLEN)
    s.sub        s18, s16, s17
    v.movi       v10, #80
    v.iota       v11                             // arange(0, VLEN)
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #96
    v.add        v14, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.add        v1, v3, v4
    v.splat      v3, s15
    v.add        v4, v5, v6
    v.movi       v5, #112
    v.add        v6, v7, v8
    v.add        v7, v9, v10
    v.add        v8, v3, v2
    v.splat      v2, s7
    v.add        v3, v12, v13
    v.add        v9, v0, v5
    v.splat      v0, s15
    v.splat      v0, s15
    v.splat      v0, s15
    v.splat      v0, s15
    v.movi       v0, #0
    v.splat      v5, s15
    v.splat      v5, s15
    v.cmp.lt     p1, v8, v0
    v.splat      v5, s15
    v.cmp.lt     p2, v2, v0
    v.splat      v5, s15
    v.sub        v5, v0, v8
    s.add        s16, s4, s15
    v.sub        v10, v0, v2
    v.splat      v12, s7
    v.splat      v12, s7
    v.splat      v12, s7
    v.splat      v12, s7
    v.splat      v12, s7
    v.splat      v12, s7
    v.splat      v12, s7
    v.splat      v12, s7
    v.movi       v12, #1
    @p1 v.sel        v13, v5, v8
    @p2 v.sel        v5, v10, v2
    v.movi       v2, #0
    v.movi       v8, #0
    s.movz       s15, #31
idiv_11:
    v.splat      v10, s15
    v.shl        v15, v8, v12
    v.lshr       v16, v13, v10
    v.cmp.lt     p2, v8, v0
    v.and        v17, v16, v12
    v.shl        v16, v12, v10
    v.or         v10, v15, v17
    s.subi       s17, s15, #1
    v.cmp.geu    p3, v10, v5
    p.or         p4, p2, p3
    v.sub        v15, v10, v5
    @p4 v.sel        v17, v16, v0
    @p4 v.sel        v16, v15, v10
    v.or         v10, v2, v17
    v.mov        v8, v16
    v.mov        v2, v10
    s.mov        s15, s17
    s.movz       s17, #0
    s.cmp.ge     s19, s15, s17
    br.nz        s19, idiv_11
    s.mul        s15, s18, s14
    v.sub        v2, v0, v8
    @p1 v.sel        v0, v2, v8
    v.splat      v2, s15
    v.splat      v5, s8
    v.add        v8, v2, v11
    v.splat      v2, s15
    v.splat      v10, s15
    v.splat      v11, s15
    v.splat      v12, s15
    v.splat      v13, s15
    v.splat      v15, s15
    v.splat      v16, s15
    v.movi       v17, #0
    v.add        v18, v2, v14
    v.add        v2, v10, v1
    v.cmp.lt     p1, v8, v17
    v.add        v1, v11, v4
    v.cmp.lt     p2, v5, v17
    v.add        v4, v12, v6
    v.sub        v6, v17, v8
    v.add        v10, v13, v7
    v.add        v7, v15, v3
    v.sub        v3, v17, v5
    v.add        v11, v16, v9
    v.splat      v9, s8
    v.splat      v12, s8
    v.splat      v13, s8
    v.splat      v14, s8
    v.splat      v15, s8
    v.splat      v16, s8
    v.splat      v19, s8
    v.movi       v20, #1
    @p1 v.sel        v21, v6, v8
    @p2 v.sel        v6, v3, v5
    v.movi       v3, #0
    v.movi       v5, #0
    s.movz       s17, #31
idiv_12:
    v.splat      v8, s17
    v.shl        v22, v5, v20
    v.lshr       v23, v21, v8
    v.cmp.lt     p2, v5, v17
    v.and        v24, v23, v20
    v.shl        v23, v20, v8
    v.or         v8, v22, v24
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v8, v6
    p.or         p4, p2, p3
    v.sub        v22, v8, v6
    @p4 v.sel        v24, v23, v17
    @p4 v.sel        v23, v22, v8
    v.or         v8, v3, v24
    v.mov        v5, v23
    v.mov        v3, v8
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_12
    v.movi       v3, #0
    v.sub        v6, v17, v5
    v.sub        v8, v3, v18
    v.sub        v17, v3, v9
    v.cmp.lt     p2, v18, v3
    @p1 v.sel        v20, v6, v5
    v.cmp.lt     p1, v9, v3
    v.movi       v5, #1
    @p2 v.sel        v6, v8, v18
    @p1 v.sel        v8, v17, v9
    v.movi       v9, #0
    v.movi       v17, #0
    s.movz       s17, #31
idiv_13:
    v.splat      v18, s17
    v.shl        v21, v17, v5
    v.lshr       v22, v6, v18
    v.cmp.lt     p1, v17, v3
    v.and        v23, v22, v5
    v.shl        v22, v5, v18
    v.or         v18, v21, v23
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v18, v8
    p.or         p4, p1, p3
    v.sub        v21, v18, v8
    @p4 v.sel        v23, v22, v3
    @p4 v.sel        v22, v21, v18
    v.or         v18, v9, v23
    v.mov        v17, v22
    v.mov        v9, v18
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_13
    v.movi       v5, #0
    v.sub        v6, v3, v17
    v.sub        v3, v5, v2
    v.sub        v8, v5, v12
    v.cmp.lt     p1, v2, v5
    @p2 v.sel        v9, v6, v17
    v.cmp.lt     p2, v12, v5
    v.movi       v6, #1
    @p1 v.sel        v17, v3, v2
    @p2 v.sel        v2, v8, v12
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s17, #31
idiv_14:
    v.splat      v12, s17
    v.shl        v18, v8, v6
    v.lshr       v21, v17, v12
    v.cmp.lt     p2, v8, v5
    v.and        v22, v21, v6
    v.shl        v21, v6, v12
    v.or         v12, v18, v22
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v18, v12, v2
    @p4 v.sel        v22, v21, v5
    @p4 v.sel        v21, v18, v12
    v.or         v12, v3, v22
    v.mov        v8, v21
    v.mov        v3, v12
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_14
    v.movi       v2, #0
    v.sub        v3, v5, v8
    v.sub        v5, v2, v1
    v.sub        v6, v2, v13
    v.cmp.lt     p2, v1, v2
    @p1 v.sel        v12, v3, v8
    v.cmp.lt     p1, v13, v2
    v.movi       v3, #1
    @p2 v.sel        v8, v5, v1
    @p1 v.sel        v1, v6, v13
    v.movi       v5, #0
    v.movi       v6, #0
    s.movz       s17, #31
idiv_15:
    v.splat      v13, s17
    v.shl        v17, v6, v3
    v.lshr       v18, v8, v13
    v.cmp.lt     p1, v6, v2
    v.and        v21, v18, v3
    v.shl        v18, v3, v13
    v.or         v13, v17, v21
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v13, v1
    p.or         p4, p1, p3
    v.sub        v17, v13, v1
    @p4 v.sel        v21, v18, v2
    @p4 v.sel        v18, v17, v13
    v.or         v13, v5, v21
    v.mov        v6, v18
    v.mov        v5, v13
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_15
    v.movi       v1, #0
    v.sub        v3, v2, v6
    v.sub        v2, v1, v4
    v.sub        v5, v1, v14
    v.cmp.lt     p1, v4, v1
    @p2 v.sel        v8, v3, v6
    v.cmp.lt     p2, v14, v1
    v.movi       v3, #1
    @p1 v.sel        v6, v2, v4
    @p2 v.sel        v2, v5, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s17, #31
idiv_16:
    v.splat      v13, s17
    v.shl        v14, v5, v3
    v.lshr       v17, v6, v13
    v.cmp.lt     p2, v5, v1
    v.and        v18, v17, v3
    v.shl        v17, v3, v13
    v.or         v13, v14, v18
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v13, v2
    p.or         p4, p2, p3
    v.sub        v14, v13, v2
    @p4 v.sel        v18, v17, v1
    @p4 v.sel        v17, v14, v13
    v.or         v13, v4, v18
    v.mov        v5, v17
    v.mov        v4, v13
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_16
    v.movi       v2, #0
    v.sub        v3, v1, v5
    v.sub        v1, v2, v10
    v.sub        v4, v2, v15
    v.cmp.lt     p2, v10, v2
    @p1 v.sel        v6, v3, v5
    v.cmp.lt     p1, v15, v2
    v.movi       v3, #1
    @p2 v.sel        v5, v1, v10
    @p1 v.sel        v1, v4, v15
    v.movi       v4, #0
    v.movi       v10, #0
    s.movz       s17, #31
idiv_17:
    v.splat      v13, s17
    v.shl        v14, v10, v3
    v.lshr       v15, v5, v13
    v.cmp.lt     p1, v10, v2
    v.and        v17, v15, v3
    v.shl        v15, v3, v13
    v.or         v13, v14, v17
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v13, v1
    p.or         p4, p1, p3
    v.sub        v14, v13, v1
    @p4 v.sel        v17, v15, v2
    @p4 v.sel        v15, v14, v13
    v.or         v13, v4, v17
    v.mov        v10, v15
    v.mov        v4, v13
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_17
    v.movi       v1, #0
    v.sub        v3, v2, v10
    v.sub        v2, v1, v7
    v.sub        v4, v1, v16
    v.cmp.lt     p1, v7, v1
    @p2 v.sel        v5, v3, v10
    v.cmp.lt     p2, v16, v1
    v.movi       v3, #1
    @p1 v.sel        v10, v2, v7
    @p2 v.sel        v2, v4, v16
    v.movi       v4, #0
    v.movi       v7, #0
    s.movz       s17, #31
idiv_18:
    v.splat      v13, s17
    v.shl        v14, v7, v3
    v.lshr       v15, v10, v13
    v.cmp.lt     p2, v7, v1
    v.and        v16, v15, v3
    v.shl        v15, v3, v13
    v.or         v13, v14, v16
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v13, v2
    p.or         p4, p2, p3
    v.sub        v14, v13, v2
    @p4 v.sel        v16, v15, v1
    @p4 v.sel        v15, v14, v13
    v.or         v13, v4, v16
    v.mov        v7, v15
    v.mov        v4, v13
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_18
    v.movi       v2, #0
    v.sub        v3, v1, v7
    v.sub        v1, v2, v11
    v.sub        v4, v2, v19
    v.cmp.lt     p2, v11, v2
    @p1 v.sel        v10, v3, v7
    v.cmp.lt     p1, v19, v2
    v.movi       v3, #1
    @p2 v.sel        v7, v1, v11
    @p1 v.sel        v1, v4, v19
    v.movi       v4, #0
    v.movi       v11, #0
    s.movz       s17, #31
idiv_19:
    v.splat      v13, s17
    v.shl        v14, v11, v3
    v.lshr       v15, v7, v13
    v.cmp.lt     p1, v11, v2
    v.and        v16, v15, v3
    v.shl        v15, v3, v13
    v.or         v13, v14, v16
    s.subi       s18, s17, #1
    v.cmp.geu    p3, v13, v1
    p.or         p4, p1, p3
    v.sub        v14, v13, v1
    @p4 v.sel        v16, v15, v2
    @p4 v.sel        v15, v14, v13
    v.or         v13, v4, v16
    v.mov        v11, v15
    v.mov        v4, v13
    s.mov        s17, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s17, s18
    br.nz        s19, idiv_19
    v.sub        v1, v2, v11
    v.movi       v2, #0
    @p2 v.sel        v3, v1, v11
    v.sub        v1, v2, v20
    v.cmp.lt     p1, v20, v2
    @p1 v.sel        v4, v1, v20
    v.movi       v1, #128
    s.movz       s17, #16
    v.movi       v7, #7
    v.sub        v11, v2, v1
    v.cmp.lt     p2, v1, v2
    s.movz       s18, #32
    v.lshr       v13, v4, v7
    s.movz       s19, #48
    v.sub        v4, v2, v13
    s.movz       s20, #64
    @p1 v.sel        v2, v4, v13
    s.movz       s21, #80
    v.movi       v4, #128
    s.movz       s22, #96
    v.movi       v7, #0
    s.movz       s23, #112
    v.cmp.lt     p1, v9, v7
    v.movi       v13, #1
    v.sub        v13, v7, v9
    v.movi       v14, #7
    @p1 v.sel        v15, v13, v9
    v.sub        v13, v7, v4
    v.lshr       v16, v15, v14
    @p2 v.sel        v14, v11, v1
    v.movi       v1, #0
    v.sub        v11, v7, v16
    v.cmp.lt     p2, v12, v1
    v.movi       v14, #128
    @p1 v.sel        v15, v11, v16
    v.cmp.lt     p1, v4, v7
    v.movi       v7, #1
    v.sub        v7, v1, v12
    v.movi       v11, #7
    @p2 v.sel        v16, v7, v12
    v.sub        v7, v1, v14
    v.lshr       v17, v16, v11
    @p1 v.sel        v11, v13, v4
    v.movi       v4, #0
    v.sub        v11, v1, v17
    v.cmp.lt     p1, v8, v4
    v.movi       v13, #128
    @p2 v.sel        v16, v11, v17
    v.cmp.lt     p2, v14, v1
    v.movi       v1, #1
    v.sub        v1, v4, v8
    v.movi       v11, #7
    @p1 v.sel        v17, v1, v8
    v.sub        v1, v4, v13
    v.lshr       v18, v17, v11
    @p2 v.sel        v11, v7, v14
    v.movi       v7, #0
    v.sub        v11, v4, v18
    v.cmp.lt     p2, v6, v7
    v.movi       v14, #128
    @p1 v.sel        v17, v11, v18
    v.cmp.lt     p1, v13, v4
    v.movi       v4, #1
    v.sub        v4, v7, v6
    v.movi       v11, #7
    @p2 v.sel        v18, v4, v6
    v.sub        v4, v7, v14
    v.lshr       v19, v18, v11
    @p1 v.sel        v11, v1, v13
    v.movi       v1, #0
    v.sub        v11, v7, v19
    v.cmp.lt     p1, v5, v1
    v.movi       v13, #128
    @p2 v.sel        v18, v11, v19
    v.cmp.lt     p2, v14, v7
    v.movi       v7, #1
    v.sub        v7, v1, v5
    v.movi       v11, #7
    @p1 v.sel        v19, v7, v5
    v.sub        v7, v1, v13
    v.lshr       v21, v19, v11
    @p2 v.sel        v11, v4, v14
    v.movi       v4, #0
    v.sub        v11, v1, v21
    v.cmp.lt     p2, v10, v4
    v.movi       v14, #128
    @p1 v.sel        v19, v11, v21
    v.cmp.lt     p1, v13, v1
    v.movi       v1, #1
    v.sub        v1, v4, v10
    v.movi       v11, #7
    @p2 v.sel        v21, v1, v10
    v.sub        v1, v4, v14
    v.lshr       v22, v21, v11
    @p1 v.sel        v11, v7, v13
    v.movi       v7, #0
    v.sub        v11, v4, v22
    v.cmp.lt     p1, v3, v7
    v.movi       v13, #128
    @p2 v.sel        v21, v11, v22
    v.cmp.lt     p2, v14, v4
    v.movi       v4, #1
    v.sub        v4, v7, v3
    v.movi       v11, #7
    @p1 v.sel        v22, v4, v3
    v.sub        v4, v7, v13
    v.lshr       v23, v22, v11
    @p2 v.sel        v11, v1, v14
    v.sub        v1, v7, v23
    v.splat      v11, s13
    @p1 v.sel        v14, v1, v23
    v.splat      v1, s13
    v.splat      v22, s13
    v.splat      v23, s13
    v.splat      v24, s13
    v.cmp.lt     p1, v13, v7
    v.movi       v7, #1
    v.splat      v7, s13
    @p1 v.sel        v25, v4, v13
    s.add        s24, s9, s1
    s.movz       s1, #0
    s.movz       s25, #0
    s.cmp.lt     s26, s24, s1
    s.movz       s1, #0
    s.sub        s27, s25, s26
    v.splat      v4, s13
    s.movz       s25, #0
    v.splat      v13, s13
    s.cmp.lt     s26, s14, s25
    v.mul        v25, v2, v11
    s.sub        s25, s1, s26
    v.mul        v2, v15, v1
    s.xor        s1, s24, s27
    v.mul        v1, v16, v22
    s.sub        s24, s1, s27
    v.mul        v11, v17, v23
    s.xor        s1, s14, s25
    v.mul        v15, v18, v24
    v.mul        v16, v19, v7
    s.lshri      s26, s24, #7
    v.mul        v7, v21, v4
    s.muli       s28, s26, #128
    v.mul        v4, v14, v13
    s.xor        s29, s27, s25
    s.movz       s27, #0
    s.xor        s30, s26, s29
    s.sub        s26, s1, s25
    s.movz       s1, #0
    s.movz       s25, #0
    s.sub        s26, s24, s28
    s.sub        s24, s30, s29
    s.movz       s26, #1
    s.addi       s28, s27, #0
    s.addi       s29, s1, #0
    s.addi       s1, s25, #0
    s.addi       s25, s6, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_28:
    s.cmp.ge     s30, s28, s24
    br.nz        s30, endfor_29
    s.muli       s30, s10, #2
    s.mul        s31, s28, s14
    s.muli       s32, s29, #2
    s.movz       s33, #0
    v.iota       v13                             // arange(0, VLEN)
    v.splat      v14, s30
    s.sub        s30, s9, s31
    v.mul        v17, v0, v14
    s.add        s31, s33, s30                   // the tile origin
    v.extract    s33, v17, #0
    s.add        s34, s33, s32
    v.splat      v14, s31
    s.add        s31, s3, s34
    v.cmp.lt     p1, v13, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s31, #0]
    s.rdspecial  s31, arg_base
    s.ld.d       s33, [s31, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    vf.cvt.bf16.f32 v18, v14
    s.addi       s31, s33, #0
    v.extract    s34, v17, #1
    s.add        s35, s34, s32
    v.st.w       [s31, #0], v18
    s.add        s34, s3, s35
    v.extract    s35, v17, #2
    s.add        s36, s35, s32
    s.add        s35, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s34, s31, #64
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #3
    s.add        s36, s34, s32
    s.add        s34, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s35, s31, #128
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #4
    s.add        s36, s35, s32
    s.add        s35, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s34, s31, #192
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #5
    s.add        s36, s34, s32
    s.add        s34, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s35, s31, #256
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #6
    s.add        s36, s35, s32
    s.add        s35, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s34, s31, #320
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #7
    s.add        s36, s34, s32
    s.add        s34, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s35, s31, #384
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #8
    s.add        s36, s35, s32
    s.add        s35, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s34, s31, #448
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #9
    s.add        s36, s34, s32
    s.add        s34, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s35, s31, #512
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #10
    s.add        s36, s35, s32
    s.add        s35, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s34, s31, #576
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #11
    s.add        s36, s34, s32
    s.add        s34, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s35, s31, #640
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #12
    s.add        s36, s35, s32
    s.add        s35, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s34, s31, #704
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #13
    s.add        s36, s34, s32
    s.add        s34, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s35, s31, #768
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #14
    s.add        s36, s35, s32
    s.add        s35, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s34, s31, #832
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #15
    s.add        s36, s34, s32
    s.add        s34, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s35, s31, #896
    s.addi       s36, s31, #960
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    s.movz       s31, #0
    s.add        s35, s31, s17                   // the tile origin
    v.extract    s31, v17, #0
    s.add        s37, s31, s32
    v.splat      v14, s35
    s.movz       s31, #0
    s.addi       s35, s37, #32
    s.add        s37, s31, s30                   // the tile origin
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v18, [s34, #0]
    v.add        v19, v13, v14
    v.splat      v14, s37
    s.add        s31, s3, s35
    v.cmp.lt     p1, v19, v14
    s.addi       s34, s33, #1024
    vf.cvt.bf16.f32 v14, v18
    v.st.w       [s36, #0], v14
    fence.acq_rel.device
    v.extract    s35, v17, #1
    s.add        s36, s35, s32
    v.extract    s35, v17, #2
    s.addi       s37, s36, #32
    s.add        s36, s35, s32
    s.add        s35, s3, s37
    s.addi       s37, s36, #32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s31, #0]
    s.addi       s31, s34, #64
    s.add        s36, s3, s37
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    v.extract    s35, v17, #3
    s.add        s37, s35, s32
    s.addi       s35, s37, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s37, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    v.extract    s35, v17, #4
    s.add        s36, s35, s32
    s.addi       s35, s36, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s36, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #192
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    v.extract    s35, v17, #5
    s.add        s37, s35, s32
    s.addi       s35, s37, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s37, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #256
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    v.extract    s35, v17, #6
    s.add        s36, s35, s32
    s.addi       s35, s36, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s36, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #320
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    v.extract    s35, v17, #7
    s.add        s37, s35, s32
    s.addi       s35, s37, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s37, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #384
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    v.extract    s35, v17, #8
    s.add        s36, s35, s32
    s.addi       s35, s36, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s36, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #448
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    v.extract    s35, v17, #9
    s.add        s37, s35, s32
    s.addi       s35, s37, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s37, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #512
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    v.extract    s35, v17, #10
    s.add        s36, s35, s32
    s.addi       s35, s36, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s36, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #576
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    v.extract    s35, v17, #11
    s.add        s37, s35, s32
    s.addi       s35, s37, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s37, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #640
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    v.extract    s35, v17, #12
    s.add        s36, s35, s32
    s.addi       s35, s36, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s36, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #704
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    v.extract    s35, v17, #13
    s.add        s37, s35, s32
    s.addi       s35, s37, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s37, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #768
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    v.extract    s35, v17, #14
    s.add        s36, s35, s32
    s.addi       s35, s36, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s36, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #832
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    v.extract    s35, v17, #15
    s.add        s37, s35, s32
    s.addi       s35, s37, #32
    vf.cvt.bf16.f32 v18, v14
    s.add        s37, s3, s35
    v.st.w       [s31, #0], v18
    s.addi       s31, s34, #896
    s.addi       s35, s34, #960
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    v.extract    s34, v17, #0
    s.add        s36, s34, s32
    s.addi       s34, s36, #64
    vf.cvt.bf16.f32 v18, v14
    s.add        s36, s3, s34
    v.st.w       [s31, #0], v18
    s.movz       s31, #0
    s.add        s34, s31, s18                   // the tile origin
    s.movz       s31, #0
    v.splat      v14, s34
    s.add        s34, s31, s30                   // the tile origin
    v.add        v18, v13, v14
    v.splat      v14, s34
    s.addi       s31, s33, #2048
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v19, [s37, #0]
    v.cmp.lt     p1, v18, v14
    vf.cvt.bf16.f32 v14, v19
    v.st.w       [s35, #0], v14
    fence.acq_rel.device
    v.extract    s34, v17, #1
    s.add        s35, s34, s32
    v.extract    s34, v17, #2
    s.addi       s37, s35, #64
    s.add        s35, s34, s32
    s.add        s34, s3, s37
    s.addi       s37, s35, #64
    s.addi       s35, s31, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.add        s36, s3, s37
    s.addi       s37, s31, #128
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s31, #0], v18
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    v.extract    s34, v17, #3
    s.add        s38, s34, s32
    s.addi       s34, s38, #64
    vf.cvt.bf16.f32 v18, v14
    s.add        s38, s3, s34
    v.st.w       [s35, #0], v18
    v.extract    s34, v17, #4
    s.add        s35, s34, s32
    s.addi       s34, s35, #64
    s.add        s35, s3, s34
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.addi       s34, s31, #192
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s37, #0], v18
    v.extract    s36, v17, #5
    s.add        s37, s36, s32
    s.addi       s36, s37, #64
    s.add        s37, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    s.addi       s36, s31, #256
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #6
    s.add        s38, s34, s32
    s.addi       s34, s38, #64
    s.add        s38, s3, s34
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s34, s31, #320
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s36, #0], v18
    v.extract    s35, v17, #7
    s.add        s36, s35, s32
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.addi       s35, s31, #384
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #8
    s.add        s37, s34, s32
    s.addi       s34, s37, #64
    s.add        s37, s3, s34
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    s.addi       s34, s31, #448
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #9
    s.add        s38, s35, s32
    s.addi       s35, s38, #64
    s.add        s38, s3, s35
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.addi       s35, s31, #512
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #10
    s.add        s36, s34, s32
    s.addi       s34, s36, #64
    s.add        s36, s3, s34
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.addi       s34, s31, #576
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #11
    s.add        s37, s35, s32
    s.addi       s35, s37, #64
    s.add        s37, s3, s35
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    s.addi       s35, s31, #640
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #12
    s.add        s38, s34, s32
    s.addi       s34, s38, #64
    s.add        s38, s3, s34
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.addi       s34, s31, #704
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #13
    s.add        s36, s35, s32
    s.addi       s35, s36, #64
    s.add        s36, s3, s35
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.addi       s35, s31, #768
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #14
    s.add        s37, s34, s32
    s.addi       s34, s37, #64
    s.add        s37, s3, s34
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    s.addi       s34, s31, #832
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #15
    s.add        s38, s35, s32
    s.addi       s35, s38, #64
    s.add        s38, s3, s35
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.addi       s35, s31, #896
    s.addi       s36, s31, #960
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s31, v17, #0
    s.add        s34, s31, s32
    s.addi       s31, s34, #96
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.add        s34, s3, s31
    s.addi       s31, s33, #3072
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    s.movz       s35, #0
    s.add        s37, s35, s19                   // the tile origin
    s.movz       s35, #0
    v.splat      v14, s37
    s.add        s37, s35, s30                   // the tile origin
    v.add        v18, v13, v14
    v.splat      v14, s37
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v19, [s38, #0]
    v.cmp.lt     p1, v18, v14
    vf.cvt.bf16.f32 v14, v19
    v.st.w       [s36, #0], v14
    fence.acq_rel.device
    v.extract    s35, v17, #1
    s.add        s36, s35, s32
    v.extract    s35, v17, #2
    s.addi       s37, s36, #96
    s.add        s36, s35, s32
    s.add        s35, s3, s37
    s.addi       s37, s36, #96
    s.addi       s36, s31, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.add        s34, s3, s37
    s.addi       s37, s31, #128
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s31, #0], v18
    v.extract    s38, v17, #3
    s.add        s39, s38, s32
    s.addi       s38, s39, #96
    s.add        s39, s3, s38
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s35, s31, #192
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s36, #0], v18
    v.extract    s36, v17, #4
    s.add        s38, s36, s32
    s.addi       s36, s38, #96
    s.add        s38, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s34, s31, #256
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s37, #0], v18
    v.extract    s36, v17, #5
    s.add        s37, s36, s32
    s.addi       s36, s37, #96
    s.add        s37, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    s.addi       s36, s31, #320
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #6
    s.add        s39, s35, s32
    s.addi       s35, s39, #96
    s.add        s39, s3, s35
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    s.addi       s35, s31, #384
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #7
    s.add        s38, s34, s32
    s.addi       s34, s38, #96
    s.add        s38, s3, s34
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.addi       s34, s31, #448
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s36, #0], v18
    v.extract    s36, v17, #8
    s.add        s37, s36, s32
    s.addi       s36, s37, #96
    s.add        s37, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    s.addi       s36, s31, #512
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #9
    s.add        s39, s35, s32
    s.addi       s35, s39, #96
    s.add        s39, s3, s35
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    s.addi       s35, s31, #576
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #10
    s.add        s38, s34, s32
    s.addi       s34, s38, #96
    s.add        s38, s3, s34
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.addi       s34, s31, #640
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s36, #0], v18
    v.extract    s36, v17, #11
    s.add        s37, s36, s32
    s.addi       s36, s37, #96
    s.add        s37, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    s.addi       s36, s31, #704
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #12
    s.add        s39, s35, s32
    s.addi       s35, s39, #96
    s.add        s39, s3, s35
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    s.addi       s35, s31, #768
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #13
    s.add        s38, s34, s32
    s.addi       s34, s38, #96
    s.add        s38, s3, s34
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.addi       s34, s31, #832
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s36, #0], v18
    v.extract    s36, v17, #14
    s.add        s37, s36, s32
    s.addi       s36, s37, #96
    s.add        s37, s3, s36
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    s.addi       s36, s31, #896
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #15
    s.add        s39, s35, s32
    s.addi       s35, s31, #960
    s.addi       s31, s39, #96
    s.add        s39, s3, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s31, v17, #0
    s.add        s34, s31, s32
    s.addi       s31, s33, #4096
    s.addi       s38, s34, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.add        s34, s3, s38
    vf.cvt.bf16.f32 v18, v14
    s.movz       s37, #0
    v.st.w       [s36, #0], v18
    s.add        s36, s37, s20                   // the tile origin
    s.movz       s37, #0
    v.splat      v14, s36
    s.add        s36, s37, s30                   // the tile origin
    v.add        v18, v13, v14
    v.splat      v14, s36
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v19, [s39, #0]
    v.cmp.lt     p1, v18, v14
    vf.cvt.bf16.f32 v14, v19
    v.st.w       [s35, #0], v14
    fence.acq_rel.device
    v.extract    s35, v17, #1
    s.add        s36, s35, s32
    v.extract    s35, v17, #2
    s.addi       s37, s36, #128
    s.add        s36, s35, s32
    s.add        s35, s3, s37
    s.addi       s37, s36, #128
    s.addi       s36, s31, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.add        s34, s3, s37
    s.addi       s37, s31, #128
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s31, #0], v18
    v.extract    s38, v17, #3
    s.add        s39, s38, s32
    s.addi       s38, s31, #192
    s.addi       s40, s39, #128
    s.add        s39, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s36, #0], v18
    v.extract    s35, v17, #4
    s.add        s36, s35, s32
    s.addi       s35, s31, #256
    s.addi       s40, s36, #128
    s.add        s36, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s37, #0], v18
    v.extract    s34, v17, #5
    s.add        s37, s34, s32
    s.addi       s34, s31, #320
    s.addi       s40, s37, #128
    s.add        s37, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s38, #0], v18
    v.extract    s38, v17, #6
    s.add        s39, s38, s32
    s.addi       s38, s31, #384
    s.addi       s40, s39, #128
    s.add        s39, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #7
    s.add        s36, s35, s32
    s.addi       s35, s31, #448
    s.addi       s40, s36, #128
    s.add        s36, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #8
    s.add        s37, s34, s32
    s.addi       s34, s31, #512
    s.addi       s40, s37, #128
    s.add        s37, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s38, #0], v18
    v.extract    s38, v17, #9
    s.add        s39, s38, s32
    s.addi       s38, s31, #576
    s.addi       s40, s39, #128
    s.add        s39, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #10
    s.add        s36, s35, s32
    s.addi       s35, s31, #640
    s.addi       s40, s36, #128
    s.add        s36, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #11
    s.add        s37, s34, s32
    s.addi       s34, s31, #704
    s.addi       s40, s37, #128
    s.add        s37, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s38, #0], v18
    v.extract    s38, v17, #12
    s.add        s39, s38, s32
    s.addi       s38, s31, #768
    s.addi       s40, s39, #128
    s.add        s39, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #13
    s.add        s36, s35, s32
    s.addi       s35, s31, #832
    s.addi       s40, s36, #128
    s.add        s36, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #14
    s.add        s37, s34, s32
    s.addi       s34, s31, #896
    s.addi       s40, s37, #128
    s.add        s37, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s38, #0], v18
    v.extract    s38, v17, #15
    s.add        s39, s38, s32
    s.addi       s38, s31, #960
    s.addi       s31, s39, #128
    s.add        s39, s3, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s31, v17, #0
    s.add        s35, s31, s32
    s.addi       s31, s33, #5120
    s.addi       s36, s35, #160
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.add        s35, s3, s36
    vf.cvt.bf16.f32 v18, v14
    s.movz       s36, #0
    v.st.w       [s34, #0], v18
    s.add        s34, s36, s21                   // the tile origin
    s.movz       s36, #0
    v.splat      v14, s34
    s.add        s34, s36, s30                   // the tile origin
    v.add        v18, v13, v14
    v.splat      v14, s34
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v19, [s39, #0]
    v.cmp.lt     p1, v18, v14
    vf.cvt.bf16.f32 v14, v19
    v.st.w       [s38, #0], v14
    fence.acq_rel.device
    v.extract    s34, v17, #1
    s.add        s36, s34, s32
    v.extract    s34, v17, #2
    s.addi       s37, s36, #160
    s.add        s36, s34, s32
    s.add        s34, s3, s37
    s.addi       s37, s36, #160
    s.addi       s36, s31, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.add        s35, s3, s37
    s.addi       s37, s31, #128
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s31, #0], v18
    v.extract    s38, v17, #3
    s.add        s39, s38, s32
    s.addi       s38, s31, #192
    s.addi       s40, s39, #160
    s.add        s39, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s36, #0], v18
    v.extract    s34, v17, #4
    s.add        s36, s34, s32
    s.addi       s34, s31, #256
    s.addi       s40, s36, #160
    s.add        s36, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s37, #0], v18
    v.extract    s35, v17, #5
    s.add        s37, s35, s32
    s.addi       s35, s31, #320
    s.addi       s40, s37, #160
    s.add        s37, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s38, #0], v18
    v.extract    s38, v17, #6
    s.add        s39, s38, s32
    s.addi       s38, s31, #384
    s.addi       s40, s39, #160
    s.add        s39, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #7
    s.add        s36, s34, s32
    s.addi       s34, s31, #448
    s.addi       s40, s36, #160
    s.add        s36, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #8
    s.add        s37, s35, s32
    s.addi       s35, s31, #512
    s.addi       s40, s37, #160
    s.add        s37, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s38, #0], v18
    v.extract    s38, v17, #9
    s.add        s39, s38, s32
    s.addi       s38, s31, #576
    s.addi       s40, s39, #160
    s.add        s39, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #10
    s.add        s36, s34, s32
    s.addi       s34, s31, #640
    s.addi       s40, s36, #160
    s.add        s36, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #11
    s.add        s37, s35, s32
    s.addi       s35, s31, #704
    s.addi       s40, s37, #160
    s.add        s37, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s38, #0], v18
    v.extract    s38, v17, #12
    s.add        s39, s38, s32
    s.addi       s38, s31, #768
    s.addi       s40, s39, #160
    s.add        s39, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #13
    s.add        s36, s34, s32
    s.addi       s34, s31, #832
    s.addi       s40, s36, #160
    s.add        s36, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #14
    s.add        s37, s35, s32
    s.addi       s35, s31, #896
    s.addi       s40, s37, #160
    s.add        s37, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s38, #0], v18
    v.extract    s38, v17, #15
    s.add        s39, s38, s32
    s.addi       s38, s31, #960
    s.addi       s31, s39, #160
    s.add        s39, s3, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s31, v17, #0
    s.add        s34, s31, s32
    s.addi       s31, s33, #6144
    s.addi       s36, s34, #192
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.add        s34, s3, s36
    vf.cvt.bf16.f32 v18, v14
    s.movz       s36, #0
    v.st.w       [s35, #0], v18
    s.add        s35, s36, s22                   // the tile origin
    s.movz       s36, #0
    v.splat      v14, s35
    s.add        s35, s36, s30                   // the tile origin
    v.add        v18, v13, v14
    v.splat      v14, s35
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v19, [s39, #0]
    v.cmp.lt     p1, v18, v14
    vf.cvt.bf16.f32 v14, v19
    v.st.w       [s38, #0], v14
    fence.acq_rel.device
    v.extract    s35, v17, #1
    s.add        s36, s35, s32
    v.extract    s35, v17, #2
    s.addi       s37, s36, #192
    s.add        s36, s35, s32
    s.add        s35, s3, s37
    s.addi       s37, s36, #192
    s.addi       s36, s31, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.add        s34, s3, s37
    s.addi       s37, s31, #128
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s31, #0], v18
    v.extract    s38, v17, #3
    s.add        s39, s38, s32
    s.addi       s38, s31, #192
    s.addi       s40, s39, #192
    s.add        s39, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s36, #0], v18
    v.extract    s35, v17, #4
    s.add        s36, s35, s32
    s.addi       s35, s31, #256
    s.addi       s40, s36, #192
    s.add        s36, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s37, #0], v18
    v.extract    s34, v17, #5
    s.add        s37, s34, s32
    s.addi       s34, s31, #320
    s.addi       s40, s37, #192
    s.add        s37, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s38, #0], v18
    v.extract    s38, v17, #6
    s.add        s39, s38, s32
    s.addi       s38, s31, #384
    s.addi       s40, s39, #192
    s.add        s39, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #7
    s.add        s36, s35, s32
    s.addi       s35, s31, #448
    s.addi       s40, s36, #192
    s.add        s36, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #8
    s.add        s37, s34, s32
    s.addi       s34, s31, #512
    s.addi       s40, s37, #192
    s.add        s37, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s38, #0], v18
    v.extract    s38, v17, #9
    s.add        s39, s38, s32
    s.addi       s38, s31, #576
    s.addi       s40, s39, #192
    s.add        s39, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #10
    s.add        s36, s35, s32
    s.addi       s35, s31, #640
    s.addi       s40, s36, #192
    s.add        s36, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #11
    s.add        s37, s34, s32
    s.addi       s34, s31, #704
    s.addi       s40, s37, #192
    s.add        s37, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s38, #0], v18
    v.extract    s38, v17, #12
    s.add        s39, s38, s32
    s.addi       s38, s31, #768
    s.addi       s40, s39, #192
    s.add        s39, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s35, v17, #13
    s.add        s36, s35, s32
    s.addi       s35, s31, #832
    s.addi       s40, s36, #192
    s.add        s36, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s34, #0], v18
    v.extract    s34, v17, #14
    s.add        s37, s34, s32
    s.addi       s34, s31, #896
    s.addi       s40, s37, #192
    s.add        s37, s3, s40
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s38, #0], v18
    v.extract    s38, v17, #15
    s.add        s39, s38, s32
    s.addi       s38, s31, #960
    s.addi       s31, s39, #192
    s.add        s39, s3, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    vf.cvt.bf16.f32 v18, v14
    v.st.w       [s35, #0], v18
    v.extract    s31, v17, #0
    s.add        s35, s31, s32
    s.addi       s31, s33, #7168
    s.addi       s36, s35, #224
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.add        s35, s3, s36
    vf.cvt.bf16.f32 v18, v14
    s.movz       s36, #0
    v.st.w       [s34, #0], v18
    s.add        s34, s36, s23                   // the tile origin
    s.movz       s36, #0
    v.splat      v14, s34
    s.add        s34, s36, s30                   // the tile origin
    v.add        v18, v13, v14
    v.splat      v13, s34
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    v.cmp.lt     p1, v18, v13
    vf.cvt.bf16.f32 v13, v14
    v.st.w       [s38, #0], v13
    fence.acq_rel.device
    v.extract    s34, v17, #1
    s.add        s36, s34, s32
    v.extract    s34, v17, #2
    s.addi       s37, s36, #224
    s.add        s36, s34, s32
    s.add        s34, s3, s37
    s.addi       s37, s36, #224
    s.addi       s36, s31, #64
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s35, #0]
    s.add        s35, s3, s37
    s.addi       s37, s31, #128
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s31, #0], v14
    v.extract    s38, v17, #3
    s.add        s39, s38, s32
    s.addi       s38, s31, #192
    s.addi       s40, s39, #224
    s.add        s39, s3, s40
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s34, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s36, #0], v14
    v.extract    s34, v17, #4
    s.add        s36, s34, s32
    s.addi       s34, s31, #256
    s.addi       s40, s36, #224
    s.add        s36, s3, s40
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s35, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s37, #0], v14
    v.extract    s35, v17, #5
    s.add        s37, s35, s32
    s.addi       s35, s31, #320
    s.addi       s40, s37, #224
    s.add        s37, s3, s40
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s39, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s38, #0], v14
    v.extract    s38, v17, #6
    s.add        s39, s38, s32
    s.addi       s38, s31, #384
    s.addi       s40, s39, #224
    s.add        s39, s3, s40
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s34, #0], v14
    v.extract    s34, v17, #7
    s.add        s36, s34, s32
    s.addi       s34, s31, #448
    s.addi       s40, s36, #224
    s.add        s36, s3, s40
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s37, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s35, #0], v14
    v.extract    s35, v17, #8
    s.add        s37, s35, s32
    s.addi       s35, s31, #512
    s.addi       s40, s37, #224
    s.add        s37, s3, s40
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s39, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s38, #0], v14
    v.extract    s38, v17, #9
    s.add        s39, s38, s32
    s.addi       s38, s31, #576
    s.addi       s40, s39, #224
    s.add        s39, s3, s40
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s34, #0], v14
    v.extract    s34, v17, #10
    s.add        s36, s34, s32
    s.addi       s34, s31, #640
    s.addi       s40, s36, #224
    s.add        s36, s3, s40
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s37, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s35, #0], v14
    v.extract    s35, v17, #11
    s.add        s37, s35, s32
    s.addi       s35, s31, #704
    s.addi       s40, s37, #224
    s.add        s37, s3, s40
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s39, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s38, #0], v14
    v.extract    s38, v17, #12
    s.add        s39, s38, s32
    s.addi       s38, s31, #768
    s.addi       s40, s39, #224
    s.add        s39, s3, s40
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s34, #0], v14
    v.extract    s34, v17, #13
    s.add        s36, s34, s32
    s.addi       s34, s31, #832
    s.addi       s40, s36, #224
    s.add        s36, s3, s40
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s37, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s35, #0], v14
    v.extract    s35, v17, #14
    s.add        s37, s35, s32
    s.addi       s35, s31, #896
    s.addi       s40, s37, #224
    s.add        s37, s3, s40
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s39, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s38, #0], v14
    v.extract    s38, v17, #15
    s.add        s39, s38, s32
    s.addi       s32, s31, #960
    s.addi       s31, s39, #224
    s.add        s38, s3, s31
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s34, #0], v14
    s.addi       s31, s33, #0
    s.addi       s34, s33, #1024
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s37, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s35, #0], v14
    s.addi       s35, s33, #2048
    s.addi       s36, s33, #3072
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s38, #0]
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s32, #0], v14
    fence.acq_rel.device
    s.addi       s32, s33, #4096
    v.ld.w       v13, [s31, #0]
    v.ld.w       v14, [s34, #0]
    vf.abs       v17, v13
    s.addi       s31, s33, #5120
    v.ld.w       v13, [s35, #0]
    vf.abs       v18, v14
    vf.max.ieee  v14, v17, v18
    s.addi       s34, s33, #6144
    v.ld.w       v17, [s36, #0]
    vf.abs       v18, v13
    vf.max.ieee  v13, v14, v18
    s.addi       s35, s33, #7168
    v.ld.w       v14, [s32, #0]
    vf.abs       v18, v17
    vf.max.ieee  v17, v13, v18
    s.addi       s32, s33, #64
    v.ld.w       v13, [s31, #0]
    vf.abs       v18, v14
    vf.max.ieee  v14, v17, v18
    s.addi       s31, s33, #1088
    v.ld.w       v17, [s32, #0]
    vf.abs       v18, v13
    vf.max.ieee  v13, v14, v18
    s.addi       s32, s33, #2112
    v.ld.w       v14, [s31, #0]
    vf.abs       v18, v17
    vf.abs       v17, v14
    v.ld.w       v14, [s34, #0]
    vf.max.ieee  v19, v18, v17
    v.ld.w       v17, [s32, #0]
    vf.abs       v18, v14
    vf.max.ieee  v14, v13, v18
    s.addi       s31, s33, #3136
    vf.abs       v13, v17
    v.ld.w       v17, [s35, #0]
    vf.max.ieee  v18, v19, v13
    v.ld.w       v13, [s31, #0]
    vf.abs       v19, v17
    vf.max.ieee  v17, v14, v19
    vf.reduce.max.b v14, v17
    s.addi       s31, s33, #4160
    s.addi       s32, s33, #5184
    v.ld.w       v17, [s31, #0]
    vf.abs       v19, v13
    s.addi       s31, s33, #6208
    s.addi       s34, s33, #7232
    vf.max.ieee  v13, v18, v19
    s.addi       s35, s33, #128
    v.ld.w       v18, [s32, #0]
    vf.abs       v19, v17
    vf.max.ieee  v17, v13, v19
    s.addi       s32, s33, #1152
    v.ld.w       v13, [s35, #0]
    vf.abs       v19, v18
    vf.max.ieee  v18, v17, v19
    s.addi       s35, s33, #2176
    v.ld.w       v17, [s32, #0]
    vf.abs       v19, v13
    vf.abs       v13, v17
    v.ld.w       v17, [s31, #0]
    vf.max.ieee  v21, v19, v13
    v.ld.w       v13, [s35, #0]
    vf.abs       v19, v17
    vf.max.ieee  v17, v18, v19
    s.addi       s31, s33, #3200
    vf.abs       v18, v13
    v.ld.w       v13, [s34, #0]
    vf.max.ieee  v19, v21, v18
    v.ld.w       v18, [s31, #0]
    vf.abs       v21, v13
    vf.max.ieee  v13, v17, v21
    vf.reduce.max.b v17, v13
    s.addi       s31, s33, #4224
    s.addi       s32, s33, #5248
    v.ld.w       v13, [s31, #0]
    vf.abs       v21, v18
    s.addi       s31, s33, #6272
    s.addi       s34, s33, #7296
    vf.max.ieee  v18, v19, v21
    s.addi       s35, s33, #192
    v.ld.w       v19, [s32, #0]
    vf.abs       v21, v13
    vf.max.ieee  v13, v18, v21
    s.addi       s32, s33, #1216
    v.ld.w       v18, [s35, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v13, v21
    s.addi       s35, s33, #2240
    v.ld.w       v13, [s32, #0]
    vf.abs       v21, v18
    vf.abs       v18, v13
    v.ld.w       v13, [s31, #0]
    vf.max.ieee  v22, v21, v18
    v.ld.w       v18, [s35, #0]
    vf.abs       v21, v13
    vf.max.ieee  v13, v19, v21
    s.addi       s31, s33, #3264
    vf.abs       v19, v18
    v.ld.w       v18, [s34, #0]
    vf.max.ieee  v21, v22, v19
    v.ld.w       v19, [s31, #0]
    vf.abs       v22, v18
    vf.max.ieee  v18, v13, v22
    vf.reduce.max.b v13, v18
    s.addi       s31, s33, #4288
    s.addi       s32, s33, #5312
    v.ld.w       v18, [s31, #0]
    vf.abs       v22, v19
    s.addi       s31, s33, #6336
    s.addi       s34, s33, #7360
    vf.max.ieee  v19, v21, v22
    s.addi       s35, s33, #256
    v.ld.w       v21, [s32, #0]
    vf.abs       v22, v18
    vf.max.ieee  v18, v19, v22
    s.addi       s32, s33, #1280
    v.ld.w       v19, [s35, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v18, v22
    s.addi       s35, s33, #2304
    v.ld.w       v18, [s32, #0]
    vf.abs       v22, v19
    vf.abs       v19, v18
    v.ld.w       v18, [s31, #0]
    vf.max.ieee  v23, v22, v19
    v.ld.w       v19, [s35, #0]
    vf.abs       v22, v18
    vf.max.ieee  v18, v21, v22
    s.addi       s31, s33, #3328
    vf.abs       v21, v19
    v.ld.w       v19, [s34, #0]
    vf.max.ieee  v22, v23, v21
    v.ld.w       v21, [s31, #0]
    vf.abs       v23, v19
    vf.max.ieee  v19, v18, v23
    vf.reduce.max.b v18, v19
    s.addi       s31, s33, #4352
    s.addi       s32, s33, #5376
    v.ld.w       v19, [s31, #0]
    vf.abs       v23, v21
    s.addi       s31, s33, #6400
    s.addi       s34, s33, #7424
    vf.max.ieee  v21, v22, v23
    s.addi       s35, s33, #320
    v.ld.w       v22, [s32, #0]
    vf.abs       v23, v19
    vf.max.ieee  v19, v21, v23
    s.addi       s32, s33, #1344
    v.ld.w       v21, [s35, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v19, v23
    s.addi       s35, s33, #2368
    v.ld.w       v19, [s32, #0]
    vf.abs       v23, v21
    vf.abs       v21, v19
    v.ld.w       v19, [s31, #0]
    vf.max.ieee  v24, v23, v21
    v.ld.w       v21, [s35, #0]
    vf.abs       v23, v19
    vf.max.ieee  v19, v22, v23
    s.addi       s31, s33, #3392
    vf.abs       v22, v21
    v.ld.w       v21, [s34, #0]
    vf.max.ieee  v23, v24, v22
    v.ld.w       v22, [s31, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v19, v24
    vf.reduce.max.b v19, v21
    s.addi       s31, s33, #4416
    s.addi       s32, s33, #5440
    v.ld.w       v21, [s31, #0]
    vf.abs       v24, v22
    s.addi       s31, s33, #6464
    s.addi       s34, s33, #7488
    vf.max.ieee  v22, v23, v24
    s.addi       s35, s33, #384
    v.ld.w       v23, [s32, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v22, v24
    s.addi       s32, s33, #1408
    v.ld.w       v22, [s35, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v21, v24
    s.addi       s35, s33, #2432
    v.ld.w       v21, [s32, #0]
    vf.abs       v24, v22
    vf.abs       v22, v21
    v.ld.w       v21, [s31, #0]
    vf.max.ieee  v26, v24, v22
    v.ld.w       v22, [s35, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    s.addi       s31, s33, #3456
    vf.abs       v23, v22
    v.ld.w       v22, [s34, #0]
    vf.max.ieee  v24, v26, v23
    v.ld.w       v23, [s31, #0]
    vf.abs       v26, v22
    vf.max.ieee  v22, v21, v26
    vf.reduce.max.b v21, v22
    s.addi       s31, s33, #4480
    s.addi       s32, s33, #5504
    v.ld.w       v22, [s31, #0]
    vf.abs       v26, v23
    s.addi       s31, s33, #6528
    s.addi       s34, s33, #7552
    vf.max.ieee  v23, v24, v26
    s.addi       s35, s33, #448
    v.ld.w       v24, [s32, #0]
    vf.abs       v26, v22
    vf.max.ieee  v22, v23, v26
    s.addi       s32, s33, #1472
    v.ld.w       v23, [s35, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v22, v26
    s.addi       s35, s33, #2496
    v.ld.w       v22, [s32, #0]
    vf.abs       v26, v23
    vf.abs       v23, v22
    v.ld.w       v22, [s31, #0]
    vf.max.ieee  v27, v26, v23
    v.ld.w       v23, [s35, #0]
    vf.abs       v26, v22
    vf.max.ieee  v22, v24, v26
    s.addi       s31, s33, #3520
    vf.abs       v24, v23
    v.ld.w       v23, [s34, #0]
    vf.max.ieee  v26, v27, v24
    v.ld.w       v24, [s31, #0]
    vf.abs       v27, v23
    vf.max.ieee  v23, v22, v27
    vf.reduce.max.b v22, v23
    s.addi       s31, s33, #4544
    s.addi       s32, s33, #5568
    v.ld.w       v23, [s31, #0]
    vf.abs       v27, v24
    s.addi       s31, s33, #6592
    s.addi       s34, s33, #7616
    vf.max.ieee  v24, v26, v27
    s.addi       s35, s33, #512
    v.ld.w       v26, [s32, #0]
    vf.abs       v27, v23
    vf.max.ieee  v23, v24, v27
    s.addi       s32, s33, #1536
    v.ld.w       v24, [s35, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v23, v27
    s.addi       s35, s33, #2560
    v.ld.w       v23, [s32, #0]
    vf.abs       v27, v24
    vf.abs       v24, v23
    v.ld.w       v23, [s31, #0]
    vf.max.ieee  v28, v27, v24
    v.ld.w       v24, [s35, #0]
    vf.abs       v27, v23
    vf.max.ieee  v23, v26, v27
    s.addi       s31, s33, #3584
    vf.abs       v26, v24
    v.ld.w       v24, [s34, #0]
    vf.max.ieee  v27, v28, v26
    v.ld.w       v26, [s31, #0]
    vf.abs       v28, v24
    vf.max.ieee  v24, v23, v28
    vf.reduce.max.b v23, v24
    s.addi       s31, s33, #4608
    s.addi       s32, s33, #5632
    v.ld.w       v24, [s31, #0]
    vf.abs       v28, v26
    s.addi       s31, s33, #6656
    s.addi       s34, s33, #7680
    vf.max.ieee  v26, v27, v28
    s.addi       s35, s33, #576
    v.ld.w       v27, [s32, #0]
    vf.abs       v28, v24
    vf.max.ieee  v24, v26, v28
    s.addi       s32, s33, #1600
    v.ld.w       v26, [s35, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v24, v28
    s.addi       s35, s33, #2624
    v.ld.w       v24, [s32, #0]
    vf.abs       v28, v26
    vf.abs       v26, v24
    v.ld.w       v24, [s31, #0]
    vf.max.ieee  v29, v28, v26
    v.ld.w       v26, [s35, #0]
    vf.abs       v28, v24
    vf.max.ieee  v24, v27, v28
    s.addi       s31, s33, #3648
    vf.abs       v27, v26
    v.ld.w       v26, [s34, #0]
    vf.max.ieee  v28, v29, v27
    v.ld.w       v27, [s31, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v24, v29
    vf.reduce.max.b v24, v26
    s.addi       s31, s33, #4672
    s.addi       s32, s33, #5696
    v.ld.w       v26, [s31, #0]
    vf.abs       v29, v27
    s.addi       s31, s33, #6720
    s.addi       s34, s33, #7744
    vf.max.ieee  v27, v28, v29
    s.addi       s35, s33, #640
    v.ld.w       v28, [s32, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v27, v29
    s.addi       s32, s33, #1664
    v.ld.w       v27, [s35, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v26, v29
    s.addi       s35, s33, #2688
    v.ld.w       v26, [s32, #0]
    vf.abs       v29, v27
    vf.abs       v27, v26
    v.ld.w       v26, [s31, #0]
    vf.max.ieee  v30, v29, v27
    v.ld.w       v27, [s35, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    s.addi       s31, s33, #3712
    vf.abs       v28, v27
    v.ld.w       v27, [s34, #0]
    vf.max.ieee  v29, v30, v28
    v.ld.w       v28, [s31, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v26, v30
    vf.reduce.max.b v26, v27
    s.addi       s31, s33, #4736
    s.addi       s32, s33, #5760
    v.ld.w       v27, [s31, #0]
    vf.abs       v30, v28
    s.addi       s31, s33, #6784
    s.addi       s34, s33, #7808
    vf.max.ieee  v28, v29, v30
    s.addi       s35, s33, #704
    v.ld.w       v29, [s32, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v28, v30
    s.addi       s32, s33, #1728
    v.ld.w       v28, [s35, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v27, v30
    s.addi       s35, s33, #2752
    v.ld.w       v27, [s32, #0]
    vf.abs       v30, v28
    vf.abs       v28, v27
    v.ld.w       v27, [s31, #0]
    vf.max.ieee  v31, v30, v28
    v.ld.w       v28, [s35, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    s.addi       s31, s33, #3776
    vf.abs       v29, v28
    v.ld.w       v28, [s34, #0]
    vf.max.ieee  v30, v31, v29
    v.ld.w       v29, [s31, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v27, v31
    vf.reduce.max.b v27, v28
    s.addi       s31, s33, #4800
    s.addi       s32, s33, #5824
    v.ld.w       v28, [s31, #0]
    vf.abs       v31, v29
    s.addi       s31, s33, #6848
    s.addi       s34, s33, #7872
    vf.max.ieee  v29, v30, v31
    s.addi       s35, s33, #768
    v.ld.w       v30, [s32, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v29, v31
    s.addi       s32, s33, #1792
    v.ld.w       v29, [s35, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v28, v31
    s.addi       s35, s33, #2816
    v.ld.w       v28, [s32, #0]
    vf.abs       v31, v29
    vf.abs       v29, v28
    v.ld.w       v28, [s31, #0]
    vf.max.ieee  v32, v31, v29
    v.ld.w       v29, [s35, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    s.addi       s31, s33, #3840
    vf.abs       v30, v29
    v.ld.w       v29, [s34, #0]
    vf.max.ieee  v31, v32, v30
    v.ld.w       v30, [s31, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v28, v32
    vf.reduce.max.b v28, v29
    s.addi       s31, s33, #4864
    s.addi       s32, s33, #5888
    v.ld.w       v29, [s31, #0]
    vf.abs       v32, v30
    s.addi       s31, s33, #6912
    s.addi       s34, s33, #7936
    vf.max.ieee  v30, v31, v32
    s.addi       s35, s33, #832
    v.ld.w       v31, [s32, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v30, v32
    s.addi       s32, s33, #1856
    v.ld.w       v30, [s35, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v29, v32
    s.addi       s35, s33, #2880
    v.ld.w       v29, [s32, #0]
    vf.abs       v32, v30
    vf.abs       v30, v29
    v.ld.w       v29, [s31, #0]
    vf.max.ieee  v33, v32, v30
    v.ld.w       v30, [s35, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    s.addi       s31, s33, #3904
    vf.abs       v31, v30
    v.ld.w       v30, [s34, #0]
    vf.max.ieee  v32, v33, v31
    v.ld.w       v31, [s31, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v29, v33
    vf.reduce.max.b v29, v30
    s.addi       s31, s33, #4928
    s.addi       s32, s33, #5952
    v.ld.w       v30, [s31, #0]
    s.addi       s31, s33, #6976
    s.addi       s34, s33, #8000
    vf.abs       v33, v31
    vf.max.ieee  v31, v32, v33
    s.addi       s35, s33, #896
    v.ld.w       v32, [s32, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v31, v33
    s.addi       s32, s33, #1920
    v.ld.w       v31, [s35, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v30, v33
    s.addi       s35, s33, #2944
    v.ld.w       v30, [s32, #0]
    vf.abs       v33, v31
    vf.abs       v31, v30
    v.ld.w       v30, [s31, #0]
    vf.max.ieee  v34, v33, v31
    v.ld.w       v31, [s35, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v32, v33
    s.addi       s31, s33, #3968
    vf.abs       v32, v31
    v.ld.w       v31, [s34, #0]
    vf.max.ieee  v33, v34, v32
    v.ld.w       v32, [s31, #0]
    vf.abs       v34, v31
    vf.max.ieee  v31, v30, v34
    vf.reduce.max.b v30, v31
    s.addi       s31, s33, #4992
    s.addi       s32, s33, #6016
    v.ld.w       v31, [s31, #0]
    s.addi       s31, s33, #7040
    s.addi       s34, s33, #8064
    vf.abs       v34, v32
    vf.max.ieee  v32, v33, v34
    s.addi       s35, s33, #960
    v.ld.w       v33, [s32, #0]
    vf.abs       v34, v31
    vf.max.ieee  v31, v32, v34
    s.addi       s32, s33, #1984
    v.ld.w       v32, [s35, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v31, v34
    s.addi       s35, s33, #3008
    v.ld.w       v31, [s32, #0]
    vf.abs       v34, v32
    vf.abs       v32, v31
    vf.max.ieee  v31, v34, v32
    v.ld.w       v32, [s31, #0]
    vf.abs       v34, v32
    vf.max.ieee  v32, v33, v34
    v.ld.w       v33, [s35, #0]
    s.addi       s31, s33, #4032
    vf.abs       v34, v33
    vf.max.ieee  v33, v31, v34
    v.ld.w       v31, [s34, #0]
    vf.abs       v34, v31
    vf.max.ieee  v31, v32, v34
    v.ld.w       v32, [s31, #0]
    vf.reduce.max.b v34, v31
    s.addi       s31, s33, #5056
    s.addi       s32, s33, #6080
    s.addi       s34, s33, #7104
    s.addi       s35, s33, #8128
    vf.abs       v31, v32
    vf.max.ieee  v32, v33, v31
    v.ld.w       v31, [s31, #0]
    vf.abs       v33, v31
    // one value per row into one vector (ISA 0x09)
    v.extract    s31, v14, #0
    v.movi       v14, #0
    vf.max.ieee  v31, v32, v33
    v.ld.w       v32, [s32, #0]
    v.extract    s32, v17, #0
    v.ld.w       v17, [s34, #0]
    vf.abs       v33, v32
    v.extract    s34, v13, #0
    vf.max.ieee  v13, v31, v33
    v.extract    s36, v18, #0
    v.ld.w       v18, [s35, #0]
    v.insert     v14, s31, #0
    vf.abs       v31, v17
    v.insert     v14, s32, #1
    v.extract    s31, v19, #0
    v.insert     v14, s34, #2
    vf.max.ieee  v17, v13, v31
    v.insert     v14, s36, #3
    v.extract    s32, v21, #0
    v.insert     v14, s31, #4
    vf.abs       v13, v18
    v.insert     v14, s32, #5
    v.extract    s31, v22, #0
    vf.max.ieee  v18, v17, v13
    v.insert     v14, s31, #6
    vf.reduce.max.b v13, v18
    v.extract    s31, v23, #0
    v.insert     v14, s31, #7
    v.extract    s31, v24, #0
    .li       s32, #1138753536
    v.splat      v17, s32                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.insert     v14, s31, #8
    v.rcp.approx v18, v17                        // ISA 8.8: <= 2**-22 relative
    v.extract    s31, v26, #0
    .li       s32, #1065353216
    v.splat      v19, s32                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.insert     v14, s31, #9
    v.extract    s31, v27, #0
    v.insert     v14, s31, #10
    v.extract    s31, v28, #0
    v.insert     v14, s31, #11
    v.extract    s31, v29, #0
    v.insert     v14, s31, #12
    v.extract    s31, v30, #0
    v.insert     v14, s31, #13
    v.extract    s31, v34, #0
    v.insert     v14, s31, #14
    v.extract    s31, v13, #0
    v.insert     v14, s31, #15
    .li       s31, #730643660
    v.splat      v13, s31                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v21, s11
    v.splat      v22, s11
    v.mul        v23, v20, v21
    v.mul        v21, v9, v22
    vf.fms       v22, v17, v18, v19
    v.splat      v24, s11
    vf.fms       v26, v18, v22, v18
    v.mul        v22, v12, v24
    vf.neg       v24, v26                        // Newton step: r0*(2 - x*r0)
    v.splat      v26, s11
    vf.cmp.o     p1, v24, v24
    @p1 v.sel        v27, v24, v18
    v.mul        v18, v8, v26
    vf.mul       v24, v14, v27                   // a/y: faithful quotient
    v.splat      v26, s11
    v.mul        v28, v6, v26
    vf.fms       v26, v24, v17, v14
    v.splat      v14, s11
    vf.fms       v17, v26, v27, v24
    v.mul        v26, v5, v14
    vf.neg       v14, v17                        // a/y: one correction to the IEEE quotient
    v.splat      v17, s11
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v27, v14, v24
    v.ld.gather.w v14, [s25, v25]                // index is in elements (ISA sec 9.1)
    s.movz       s31, #16
    // tl.dot 16x128 by 128x128 FP8 as (B^T A^T)^T: B^T rows are contiguous loads, A is scattered into the MMA B operand
    v.iota       v24                             // arange(0, VLEN)
    v.splat      v29, s31
    s.add        s31, s27, s30
    v.mul        v30, v24, v29
    v.mul        v24, v10, v17
    v.iota       v17                             // arange(0, VLEN)
    v.splat      v29, s11
    v.movi       v31, #7
    v.ld.gather.w v32, [s25, v2]                 // index is in elements (ISA sec 9.1)
    v.mul        v33, v3, v29
    v.and        v29, v17, v31
    v.movi       v17, #2
    v.shl        v31, v29, v17
    v.ld.gather.w v17, [s25, v1]                 // index is in elements (ISA sec 9.1)
    v.iota       v29                             // arange(0, VLEN)
    v.ld.gather.w v34, [s25, v11]                // index is in elements (ISA sec 9.1)
    v.movi       v35, #3
    v.ld.gather.w v36, [s25, v15]                // index is in elements (ISA sec 9.1)
    v.lshr       v37, v29, v35
    v.ld.gather.w v29, [s25, v16]                // index is in elements (ISA sec 9.1)
    v.movi       v35, #0
    v.ld.gather.w v38, [s25, v7]                 // index is in elements (ISA sec 9.1)
    v.cmp.eq     p1, v37, v35
    v.ld.gather.w v35, [s25, v4]                 // index is in elements (ISA sec 9.1)
    s.addi       s30, s33, #0
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    v.ld.w       v37, [s30, #0]
    s.addi       s30, s33, #8192                 // 512 bytes of repack scratch
    v.iota       v39                             // arange(0, VLEN)
    v.extract    s32, v27, #0
    v.movi       v40, #3
    v.splat      v41, s32
    v.lshr       v42, v39, v40
    vf.max.ieee  v39, v41, v13
    v.movi       v40, #1
    v.cmp.eq     p2, v42, v40
    v.rcp.approx v40, v39                        // ISA 8.8: <= 2**-22 relative
    v.movi       v41, #24
    v.movi       v42, #128
    vf.fms       v43, v39, v40, v19
    vf.fms       v44, v40, v43, v40
    s.addi       s32, s30, #0
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v44, v43, v40
    s.addi       s34, s33, #64
    vf.mul       v40, v37, v44                   // a/y: faithful quotient
    v.extract    s35, v27, #1
    vf.fms       v43, v40, v39, v37
    v.splat      v37, s35
    vf.fms       v39, v43, v44, v40
    vf.max.ieee  v43, v37, v13
    vf.neg       v37, v39                        // a/y: one correction to the IEEE quotient
    v.rcp.approx v39, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v44, v37, v40
    vf.cvt.f32.e4m3 v37, v44
    v.lshr       v40, v44, v41
    v.and        v44, v40, v42
    v.or         v40, v37, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #1
    vf.fms       v40, v43, v39, v19
    vf.fms       v44, v39, v40, v39
    s.addi       s34, s33, #128
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #2
    @p3 v.sel        v44, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v44                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v43, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v39, v44, v40
    vf.neg       v39, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #2
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #192
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #3
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #3
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #256
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #4
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #4
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #320
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #5
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #5
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #384
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #6
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #6
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #448
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #7
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #7
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #512
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #8
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #8
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #576
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #9
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #9
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #640
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #10
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #10
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #704
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #11
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #11
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #768
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #12
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #12
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #832
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #13
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #13
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #896
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #14
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #14
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #960
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #15
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #15
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #1024
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #0
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #256
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #1088
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #1
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #257
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #1152
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #2
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #258
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #1216
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #3
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #259
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #1280
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #4
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #260
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #1344
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #5
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #261
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #1408
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #6
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #262
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #1472
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #7
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #263
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #1536
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #8
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #264
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #1600
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #9
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #265
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #1664
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #10
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #266
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #1728
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #11
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #267
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #1792
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #12
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #268
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #1856
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #13
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #269
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s34, s33, #1920
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #14
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s35
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v39, [s34, #0]
    s.addi       s32, s30, #270
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s34, s33, #1984
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s35, v27, #15
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s35
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s32, v30], v40
    v.ld.w       v37, [s34, #0]
    s.addi       s32, s30, #271
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v39
    vf.mul       v39, v37, v43                   // a/y: faithful quotient
    s.addi       s34, s30, #64
    vf.fms       v40, v39, v44, v37
    vf.fms       v37, v40, v43, v39
    vf.neg       v40, v37                        // a/y: one correction to the IEEE quotient
    s.addi       s35, s30, #128
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v37, v40, v39
    vf.cvt.f32.e4m3 v39, v37
    v.lshr       v40, v37, v41
    s.addi       s36, s30, #192
    v.and        v37, v40, v42
    v.or         v40, v39, v37                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s37, s30, #256
    v.st.scatter.b [s32, v30], v40
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s32, s30, #320
    v.ld.w       v37, [s30, #0]
    v.mov        v48, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s34, #0]
    s.addi       s34, s30, #384
    v.mov        v49, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s35, #0]
    s.addi       s35, s30, #448
    v.mov        v50, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s36, #0]
    s.addi       s30, s31, #0
    v.splat      v39, s30
    v.sub        v40, v39, v31
    v.mov        v51, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s37, #0]
    v.movi       v39, #0
    v.movi       v43, #0
    v.cmp.gt     p3, v40, v39
    v.mov        v52, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s32, #0]
    v.max.s      v39, v40, v43
    v.movi       v40, #4
    v.min.s      v43, v39, v40
    v.mov        v53, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s34, #0]
    v.movi       v39, #3
    v.movi       v40, #1
    v.shl        v44, v43, v39
    v.mov        v54, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s35, #0]
    v.shl        v39, v40, v44
    v.movi       v40, #1
    v.sub        v44, v39, v40
    v.mov        v55, v37                        // hand off through the shared window (sec 7.3)
    s.add        s30, s2, s1
    v.extract    s32, v23, #1
    s.add        s34, s30, s32
    v.extract    s32, v23, #0
    s.add        s35, s30, s32
    p.and        p4, p1, p3
    s.addi       s32, s34, #-32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    v.movi       v39, #4
    v.movi       v40, #-1
    v.movi       v45, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v45, [s32, #0]
    v.cmp.ge     p4, v43, v39
    @p4 v.sel        v39, v40, v44
    v.extract    s32, v23, #3
    s.add        s34, s30, s32
    v.extract    s32, v23, #2
    s.add        s35, s30, s32
    p.and        p4, p1, p3
    s.addi       s32, s34, #-32
    v.extract    s34, v23, #4
    v.or         v40, v37, v45
    s.add        s36, s30, s34
    v.and        v37, v40, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s34, v23, #5
    s.add        s35, s30, s34
    s.addi       s34, s35, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s32, v23, #6
    v.or         v43, v37, v40
    s.add        s35, s30, s32
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s32, v23, #7
    s.add        s36, s30, s32
    s.addi       s32, s36, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v23, #8
    v.or         v43, v37, v40
    s.add        s36, s30, s34
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s34, v23, #9
    s.add        s35, s30, s34
    s.addi       s34, s35, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s32, v23, #10
    v.or         v43, v37, v40
    s.add        s35, s30, s32
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s32, v23, #11
    s.add        s36, s30, s32
    s.addi       s32, s36, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v23, #12
    v.or         v43, v37, v40
    s.add        s36, s30, s34
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s34, v23, #13
    s.add        s35, s30, s34
    s.addi       s34, s35, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s32, v23, #14
    v.or         v43, v37, v40
    s.add        s35, s30, s32
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s32, v23, #15
    s.add        s36, s30, s32
    s.addi       s30, s36, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s34, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s35, #0]
    p.and        p4, p2, p3
    s.add        s32, s2, s1
    v.extract    s34, v21, #1
    s.add        s35, s32, s34
    v.extract    s34, v21, #0
    s.add        s36, s32, s34
    s.addi       s34, s35, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s30, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s30
    mb.wait      s30
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s35, v21, #3
    s.add        s36, s32, s35
    v.extract    s35, v21, #2
    s.add        s37, s32, s35
    s.addi       s35, s36, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v21, #4
    v.or         v43, v37, v40
    s.add        s36, s32, s34
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s34, v21, #5
    s.add        s37, s32, s34
    s.addi       s34, s37, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v21, #6
    v.or         v43, v37, v40
    s.add        s37, s32, s35
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s35, v21, #7
    s.add        s36, s32, s35
    s.addi       s35, s36, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v21, #8
    v.or         v43, v37, v40
    s.add        s36, s32, s34
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s34, v21, #9
    s.add        s37, s32, s34
    s.addi       s34, s37, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v21, #10
    v.or         v43, v37, v40
    s.add        s37, s32, s35
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s35, v21, #11
    s.add        s36, s32, s35
    s.addi       s35, s36, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v21, #12
    v.or         v43, v37, v40
    s.add        s36, s32, s34
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s34, v21, #13
    s.add        s37, s32, s34
    s.addi       s34, s37, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v21, #14
    v.or         v43, v37, v40
    s.add        s37, s32, s35
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s35, v21, #15
    s.add        s36, s32, s35
    s.addi       s32, s36, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s34, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    s.add        s34, s2, s1
    v.extract    s35, v22, #1
    s.add        s36, s34, s35
    v.extract    s35, v22, #0
    s.add        s37, s34, s35
    s.addi       s35, s36, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s32, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s32, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s36, v22, #3
    s.add        s37, s34, s36
    v.extract    s36, v22, #2
    s.add        s38, s34, s36
    s.addi       s36, s37, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v22, #4
    v.or         v43, v37, v40
    s.add        s37, s34, s35
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s35, v22, #5
    s.add        s38, s34, s35
    s.addi       s35, s38, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v22, #6
    v.or         v43, v37, v40
    s.add        s38, s34, s36
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s36, v22, #7
    s.add        s37, s34, s36
    s.addi       s36, s37, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v22, #8
    v.or         v43, v37, v40
    s.add        s37, s34, s35
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s35, v22, #9
    s.add        s38, s34, s35
    s.addi       s35, s38, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v22, #10
    v.or         v43, v37, v40
    s.add        s38, s34, s36
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s36, v22, #11
    s.add        s37, s34, s36
    s.addi       s36, s37, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v22, #12
    v.or         v43, v37, v40
    s.add        s37, s34, s35
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s35, v22, #13
    s.add        s38, s34, s35
    s.addi       s35, s38, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v22, #14
    v.or         v43, v37, v40
    s.add        s38, s34, s36
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s36, v22, #15
    s.add        s37, s34, s36
    s.addi       s34, s37, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s35, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    s.add        s35, s2, s1
    v.extract    s36, v18, #1
    s.add        s37, s35, s36
    v.extract    s36, v18, #0
    s.add        s38, s35, s36
    s.addi       s36, s37, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s34, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s34, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s37, v18, #3
    s.add        s38, s35, s37
    v.extract    s37, v18, #2
    s.add        s39, s35, s37
    s.addi       s37, s38, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v18, #4
    v.or         v43, v37, v40
    s.add        s38, s35, s36
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s36, v18, #5
    s.add        s39, s35, s36
    s.addi       s36, s39, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v18, #6
    v.or         v43, v37, v40
    s.add        s39, s35, s37
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s37, v18, #7
    s.add        s38, s35, s37
    s.addi       s37, s38, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v18, #8
    v.or         v43, v37, v40
    s.add        s38, s35, s36
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s36, v18, #9
    s.add        s39, s35, s36
    s.addi       s36, s39, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v18, #10
    v.or         v43, v37, v40
    s.add        s39, s35, s37
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s37, v18, #11
    s.add        s38, s35, s37
    s.addi       s37, s38, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v18, #12
    v.or         v43, v37, v40
    s.add        s38, s35, s36
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s36, v18, #13
    s.add        s39, s35, s36
    s.addi       s36, s39, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v18, #14
    v.or         v43, v37, v40
    s.add        s39, s35, s37
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s37, v18, #15
    s.add        s38, s35, s37
    s.addi       s35, s38, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s36, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    s.add        s36, s2, s1
    v.extract    s37, v28, #1
    s.add        s38, s36, s37
    v.extract    s37, v28, #0
    s.add        s39, s36, s37
    s.addi       s37, s38, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s35, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s35, b3, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s38, v28, #3
    s.add        s39, s36, s38
    v.extract    s38, v28, #2
    s.add        s40, s36, s38
    s.addi       s38, s39, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v28, #4
    v.or         v43, v37, v40
    s.add        s39, s36, s37
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s37, v28, #5
    s.add        s40, s36, s37
    s.addi       s37, s40, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v28, #6
    v.or         v43, v37, v40
    s.add        s40, s36, s38
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s38, v28, #7
    s.add        s39, s36, s38
    s.addi       s38, s39, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v28, #8
    v.or         v43, v37, v40
    s.add        s39, s36, s37
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s37, v28, #9
    s.add        s40, s36, s37
    s.addi       s37, s40, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v28, #10
    v.or         v43, v37, v40
    s.add        s40, s36, s38
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s38, v28, #11
    s.add        s39, s36, s38
    s.addi       s38, s39, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v28, #12
    v.or         v43, v37, v40
    s.add        s39, s36, s37
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s37, v28, #13
    s.add        s40, s36, s37
    s.addi       s37, s40, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v28, #14
    v.or         v43, v37, v40
    s.add        s40, s36, s38
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s38, v28, #15
    s.add        s39, s36, s38
    s.addi       s36, s39, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    s.add        s37, s2, s1
    v.extract    s38, v26, #1
    s.add        s39, s37, s38
    v.extract    s38, v26, #0
    s.add        s40, s37, s38
    s.addi       s38, s39, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s36, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b4, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s39, v26, #3
    s.add        s40, s37, s39
    v.extract    s39, v26, #2
    s.add        s41, s37, s39
    s.addi       s39, s40, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v26, #4
    v.or         v43, v37, v40
    s.add        s40, s37, s38
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s38, v26, #5
    s.add        s41, s37, s38
    s.addi       s38, s41, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s39, v26, #6
    v.or         v43, v37, v40
    s.add        s41, s37, s39
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s39, v26, #7
    s.add        s40, s37, s39
    s.addi       s39, s40, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v26, #8
    v.or         v43, v37, v40
    s.add        s40, s37, s38
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s38, v26, #9
    s.add        s41, s37, s38
    s.addi       s38, s41, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s39, v26, #10
    v.or         v43, v37, v40
    s.add        s41, s37, s39
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s39, v26, #11
    s.add        s40, s37, s39
    s.addi       s39, s40, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v26, #12
    v.or         v43, v37, v40
    s.add        s40, s37, s38
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s38, v26, #13
    s.add        s41, s37, s38
    s.addi       s38, s41, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s39, v26, #14
    v.or         v43, v37, v40
    s.add        s41, s37, s39
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s39, v26, #15
    s.add        s40, s37, s39
    s.addi       s37, s40, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s38, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    s.add        s38, s2, s1
    v.extract    s39, v24, #1
    s.add        s40, s38, s39
    v.extract    s39, v24, #0
    s.add        s41, s38, s39
    s.addi       s39, s40, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s37, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b5, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s40, v24, #3
    s.add        s41, s38, s40
    v.extract    s40, v24, #2
    s.add        s42, s38, s40
    s.addi       s40, s41, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s39, v24, #4
    v.or         v43, v37, v40
    s.add        s41, s38, s39
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s39, v24, #5
    s.add        s42, s38, s39
    s.addi       s39, s42, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v24, #6
    v.or         v43, v37, v40
    s.add        s42, s38, s40
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s40, v24, #7
    s.add        s41, s38, s40
    s.addi       s40, s41, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s39, v24, #8
    v.or         v43, v37, v40
    s.add        s41, s38, s39
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s39, v24, #9
    s.add        s42, s38, s39
    s.addi       s39, s42, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v24, #10
    v.or         v43, v37, v40
    s.add        s42, s38, s40
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s40, v24, #11
    s.add        s41, s38, s40
    s.addi       s40, s41, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s39, v24, #12
    v.or         v43, v37, v40
    s.add        s41, s38, s39
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s39, v24, #13
    s.add        s42, s38, s39
    s.addi       s39, s42, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v24, #14
    v.or         v43, v37, v40
    s.add        s42, s38, s40
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s40, v24, #15
    s.add        s41, s38, s40
    s.addi       s38, s41, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s39, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    s.add        s39, s2, s1
    v.extract    s40, v33, #1
    s.add        s41, s39, s40
    v.extract    s40, v33, #0
    s.add        s42, s39, s40
    s.addi       s40, s41, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s38, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s38, b6, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s41, v33, #3
    s.add        s42, s39, s41
    v.extract    s41, v33, #2
    s.add        s43, s39, s41
    s.addi       s41, s42, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v33, #4
    v.or         v43, v37, v40
    s.add        s42, s39, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s40, v33, #5
    s.add        s43, s39, s40
    s.addi       s40, s43, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s41, #0]
    p.and        p4, p1, p3
    v.extract    s41, v33, #6
    v.or         v43, v37, v40
    s.add        s43, s39, s41
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s41, v33, #7
    s.add        s42, s39, s41
    s.addi       s41, s42, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v33, #8
    v.or         v43, v37, v40
    s.add        s42, s39, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s40, v33, #9
    s.add        s43, s39, s40
    s.addi       s40, s43, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s41, #0]
    p.and        p4, p1, p3
    v.extract    s41, v33, #10
    v.or         v43, v37, v40
    s.add        s43, s39, s41
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s41, v33, #11
    s.add        s42, s39, s41
    s.addi       s41, s42, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v33, #12
    v.or         v43, v37, v40
    s.add        s42, s39, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s40, v33, #13
    s.add        s43, s39, s40
    s.addi       s40, s43, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s41, #0]
    p.and        p4, p1, p3
    v.extract    s41, v33, #14
    v.or         v43, v37, v40
    s.add        s43, s39, s41
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s41, v33, #15
    s.add        s42, s39, s41
    s.addi       s39, s42, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    p.and        p5, p2, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v27, #0
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    v.splat      v40, s40
    s.addi       s40, s33, #2048
    vf.max.ieee  v43, v40, v13
    s.addi       s41, s33, #8704                 // 512 bytes of repack scratch
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    v.movi       v44, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v44, [s39, #0]
    v.or         v45, v37, v44
    v.and        v37, v45, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s39, b7, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s39
    mb.wait      s39
    v.ld.w       v37, [s40, #0]
    s.addi       s40, s41, #0
    vf.fms       v39, v43, v40, v19
    vf.fms       v44, v40, v39, v40
    s.addi       s42, s33, #2112
    vf.neg       v39, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v39, v39
    v.extract    s43, v27, #1
    @p3 v.sel        v44, v39, v40
    v.splat      v39, s43
    vf.mul       v40, v37, v44                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v43, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v39, v44, v40
    vf.neg       v39, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #1
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #2176
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #2
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #2
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #2240
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #3
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #3
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #2304
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #4
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #4
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #2368
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #5
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #5
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #2432
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #6
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #6
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #2496
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #7
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #7
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #2560
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #8
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #8
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #2624
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #9
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #9
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #2688
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #10
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #10
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #2752
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #11
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #11
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #2816
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #12
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #12
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #2880
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #13
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #13
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #2944
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #14
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #14
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #3008
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #15
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #15
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #3072
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #0
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #256
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #3136
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #1
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #257
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #3200
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #2
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #258
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #3264
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #3
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #259
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #3328
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #4
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #260
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #3392
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #5
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #261
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #3456
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #6
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #262
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #3520
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #7
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #263
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #3584
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #8
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #264
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #3648
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #9
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #265
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #3712
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #10
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #266
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #3776
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #11
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #267
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #3840
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #12
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #268
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #3904
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #13
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #269
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s42, s33, #3968
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #14
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s43
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s42, #0]
    s.addi       s40, s41, #270
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s42, s33, #4032
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s43, v27, #15
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s43
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s42, #0]
    s.addi       s40, s41, #271
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v37
    vf.mul       v37, v39, v43                   // a/y: faithful quotient
    s.addi       s42, s41, #64
    vf.fms       v40, v37, v45, v39
    vf.fms       v39, v40, v43, v37
    vf.neg       v40, v39                        // a/y: one correction to the IEEE quotient
    s.addi       s43, s41, #128
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v39, v40, v37
    vf.cvt.f32.e4m3 v37, v39
    v.lshr       v40, v39, v41
    s.addi       s44, s41, #192
    v.and        v39, v40, v42
    v.or         v40, v37, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s45, s41, #256
    v.st.scatter.b [s40, v30], v40
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s40, s41, #320
    v.ld.w       v37, [s41, #0]
    v.mov        v48, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s42, #0]
    s.addi       s42, s41, #384
    v.mov        v49, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s43, #0]
    s.addi       s43, s41, #448
    v.mov        v50, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s44, #0]
    s.addi       s41, s31, #-32
    v.splat      v39, s41
    v.sub        v40, v39, v31
    v.mov        v51, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s45, #0]
    v.movi       v39, #0
    v.movi       v43, #0
    v.cmp.gt     p3, v40, v39
    v.mov        v52, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s40, #0]
    v.max.s      v39, v40, v43
    v.movi       v40, #4
    v.min.s      v43, v39, v40
    v.mov        v53, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s42, #0]
    v.movi       v39, #3
    v.movi       v40, #1
    v.shl        v44, v43, v39
    v.mov        v54, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s43, #0]
    v.shl        v39, v40, v44
    v.movi       v40, #1
    v.sub        v44, v39, v40
    v.mov        v55, v37                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s1, #32
    v.extract    s41, v23, #1
    s.add        s42, s2, s40
    v.extract    s40, v23, #0
    s.add        s43, s42, s41
    s.add        s41, s42, s40
    p.and        p4, p1, p3
    s.addi       s40, s43, #-32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s41, #0]
    p.and        p4, p2, p3
    v.movi       v39, #4
    v.movi       v40, #-1
    v.movi       v45, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v45, [s40, #0]
    v.cmp.ge     p4, v43, v39
    @p4 v.sel        v39, v40, v44
    v.extract    s40, v23, #3
    s.add        s41, s42, s40
    v.extract    s40, v23, #2
    s.add        s43, s42, s40
    p.and        p4, p1, p3
    s.addi       s40, s41, #-32
    v.extract    s41, v23, #4
    v.or         v40, v37, v45
    s.add        s44, s42, s41
    v.and        v37, v40, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s41, v23, #5
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v23, #6
    v.or         v43, v37, v40
    s.add        s43, s42, s40
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s40, v23, #7
    s.add        s44, s42, s40
    s.addi       s40, s44, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s41, #0]
    p.and        p4, p1, p3
    v.extract    s41, v23, #8
    v.or         v43, v37, v40
    s.add        s44, s42, s41
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s41, v23, #9
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v23, #10
    v.or         v43, v37, v40
    s.add        s43, s42, s40
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s40, v23, #11
    s.add        s44, s42, s40
    s.addi       s40, s44, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s41, #0]
    p.and        p4, p1, p3
    v.extract    s41, v23, #12
    v.or         v43, v37, v40
    s.add        s44, s42, s41
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s41, v23, #13
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v23, #14
    v.or         v43, v37, v40
    s.add        s43, s42, s40
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s40, v23, #15
    s.add        s44, s42, s40
    s.addi       s40, s44, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s41, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    s.addi       s41, s1, #32
    v.extract    s42, v21, #1
    s.add        s43, s2, s41
    v.extract    s41, v21, #0
    s.add        s44, s43, s42
    s.add        s42, s43, s41
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    s.addi       s40, s44, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s41, b8, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s42, v21, #3
    s.add        s44, s43, s42
    v.extract    s42, v21, #2
    s.add        s45, s43, s42
    s.addi       s42, s44, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v21, #4
    v.or         v43, v37, v40
    s.add        s44, s43, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s40, v21, #5
    s.add        s45, s43, s40
    s.addi       s40, s45, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s42, #0]
    p.and        p4, p1, p3
    v.extract    s42, v21, #6
    v.or         v43, v37, v40
    s.add        s45, s43, s42
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s42, v21, #7
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v21, #8
    v.or         v43, v37, v40
    s.add        s44, s43, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s40, v21, #9
    s.add        s45, s43, s40
    s.addi       s40, s45, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s42, #0]
    p.and        p4, p1, p3
    v.extract    s42, v21, #10
    v.or         v43, v37, v40
    s.add        s45, s43, s42
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s42, v21, #11
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v21, #12
    v.or         v43, v37, v40
    s.add        s44, s43, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s40, v21, #13
    s.add        s45, s43, s40
    s.addi       s40, s45, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s42, #0]
    p.and        p4, p1, p3
    v.extract    s42, v21, #14
    v.or         v43, v37, v40
    s.add        s45, s43, s42
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s42, v21, #15
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    s.addi       s40, s1, #32
    v.extract    s43, v22, #1
    s.add        s44, s2, s40
    v.extract    s40, v22, #0
    s.add        s45, s44, s43
    s.add        s43, s44, s40
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s42, #0]
    p.and        p4, p1, p3
    s.addi       s40, s45, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s42, b9, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s43, #0]
    p.and        p4, p2, p3
    v.extract    s43, v22, #3
    s.add        s45, s44, s43
    v.extract    s43, v22, #2
    s.add        s46, s44, s43
    s.addi       s43, s45, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v22, #4
    v.or         v43, v37, v40
    s.add        s45, s44, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.extract    s40, v22, #5
    s.add        s46, s44, s40
    s.addi       s40, s46, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s43, #0]
    p.and        p4, p1, p3
    v.extract    s43, v22, #6
    v.or         v43, v37, v40
    s.add        s46, s44, s43
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s43, v22, #7
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v22, #8
    v.or         v43, v37, v40
    s.add        s45, s44, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.extract    s40, v22, #9
    s.add        s46, s44, s40
    s.addi       s40, s46, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s43, #0]
    p.and        p4, p1, p3
    v.extract    s43, v22, #10
    v.or         v43, v37, v40
    s.add        s46, s44, s43
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s43, v22, #11
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v22, #12
    v.or         v43, v37, v40
    s.add        s45, s44, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.extract    s40, v22, #13
    s.add        s46, s44, s40
    s.addi       s40, s46, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s43, #0]
    p.and        p4, p1, p3
    v.extract    s43, v22, #14
    v.or         v43, v37, v40
    s.add        s46, s44, s43
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s43, v22, #15
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    s.addi       s40, s1, #32
    v.extract    s44, v18, #1
    s.add        s45, s2, s40
    v.extract    s40, v18, #0
    s.add        s46, s45, s44
    s.add        s44, s45, s40
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s43, #0]
    p.and        p4, p1, p3
    s.addi       s40, s46, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s43, b10, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s44, #0]
    p.and        p4, p2, p3
    v.extract    s44, v18, #3
    s.add        s46, s45, s44
    v.extract    s44, v18, #2
    s.add        s47, s45, s44
    s.addi       s44, s46, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v18, #4
    v.or         v43, v37, v40
    s.add        s46, s45, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s40, v18, #5
    s.add        s47, s45, s40
    s.addi       s40, s47, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s44, #0]
    p.and        p4, p1, p3
    v.extract    s44, v18, #6
    v.or         v43, v37, v40
    s.add        s47, s45, s44
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.extract    s44, v18, #7
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v18, #8
    v.or         v43, v37, v40
    s.add        s46, s45, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s40, v18, #9
    s.add        s47, s45, s40
    s.addi       s40, s47, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s44, #0]
    p.and        p4, p1, p3
    v.extract    s44, v18, #10
    v.or         v43, v37, v40
    s.add        s47, s45, s44
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.extract    s44, v18, #11
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v18, #12
    v.or         v43, v37, v40
    s.add        s46, s45, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s40, v18, #13
    s.add        s47, s45, s40
    s.addi       s40, s47, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s44, #0]
    p.and        p4, p1, p3
    v.extract    s44, v18, #14
    v.or         v43, v37, v40
    s.add        s47, s45, s44
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.extract    s44, v18, #15
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    s.addi       s40, s1, #32
    v.extract    s45, v28, #1
    s.add        s46, s2, s40
    v.extract    s40, v28, #0
    s.add        s47, s46, s45
    s.add        s45, s46, s40
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s44, #0]
    p.and        p4, p1, p3
    s.addi       s40, s47, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s44, b11, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s45, #0]
    p.and        p4, p2, p3
    v.extract    s45, v28, #3
    s.add        s47, s46, s45
    v.extract    s45, v28, #2
    s.add        s48, s46, s45
    s.addi       s45, s47, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v28, #4
    v.or         v43, v37, v40
    s.add        s47, s46, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s40, v28, #5
    s.add        s48, s46, s40
    s.addi       s40, s48, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s45, #0]
    p.and        p4, p1, p3
    v.extract    s45, v28, #6
    v.or         v43, v37, v40
    s.add        s48, s46, s45
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s45, v28, #7
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v28, #8
    v.or         v43, v37, v40
    s.add        s47, s46, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s40, v28, #9
    s.add        s48, s46, s40
    s.addi       s40, s48, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s45, #0]
    p.and        p4, p1, p3
    v.extract    s45, v28, #10
    v.or         v43, v37, v40
    s.add        s48, s46, s45
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s45, v28, #11
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v28, #12
    v.or         v43, v37, v40
    s.add        s47, s46, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s40, v28, #13
    s.add        s48, s46, s40
    s.addi       s40, s48, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s45, #0]
    p.and        p4, p1, p3
    v.extract    s45, v28, #14
    v.or         v43, v37, v40
    s.add        s48, s46, s45
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s45, v28, #15
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    s.addi       s40, s1, #32
    v.extract    s46, v26, #1
    s.add        s47, s2, s40
    v.extract    s40, v26, #0
    s.add        s48, s47, s46
    s.add        s46, s47, s40
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s45, #0]
    p.and        p4, p1, p3
    s.addi       s40, s48, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s45, b12, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s46, #0]
    p.and        p4, p2, p3
    v.extract    s46, v26, #3
    s.add        s48, s47, s46
    v.extract    s46, v26, #2
    s.add        s49, s47, s46
    s.addi       s46, s48, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v26, #4
    v.or         v43, v37, v40
    s.add        s48, s47, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s40, v26, #5
    s.add        s49, s47, s40
    s.addi       s40, s49, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s46, #0]
    p.and        p4, p1, p3
    v.extract    s46, v26, #6
    v.or         v43, v37, v40
    s.add        s49, s47, s46
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s46, v26, #7
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v26, #8
    v.or         v43, v37, v40
    s.add        s48, s47, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s40, v26, #9
    s.add        s49, s47, s40
    s.addi       s40, s49, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s46, #0]
    p.and        p4, p1, p3
    v.extract    s46, v26, #10
    v.or         v43, v37, v40
    s.add        s49, s47, s46
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s46, v26, #11
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v26, #12
    v.or         v43, v37, v40
    s.add        s48, s47, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s40, v26, #13
    s.add        s49, s47, s40
    s.addi       s40, s49, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s46, #0]
    p.and        p4, p1, p3
    v.extract    s46, v26, #14
    v.or         v43, v37, v40
    s.add        s49, s47, s46
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s46, v26, #15
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    s.addi       s40, s1, #32
    v.extract    s47, v24, #1
    s.add        s48, s2, s40
    v.extract    s40, v24, #0
    s.add        s49, s48, s47
    s.add        s47, s48, s40
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s46, #0]
    p.and        p4, p1, p3
    s.addi       s40, s49, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s46, b13, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    p.and        p4, p2, p3
    v.extract    s47, v24, #3
    s.add        s49, s48, s47
    v.extract    s47, v24, #2
    s.add        s50, s48, s47
    s.addi       s47, s49, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v24, #4
    v.or         v43, v37, v40
    s.add        s49, s48, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s40, v24, #5
    s.add        s50, s48, s40
    s.addi       s40, s50, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v24, #6
    v.or         v43, v37, v40
    s.add        s50, s48, s47
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s47, v24, #7
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v24, #8
    v.or         v43, v37, v40
    s.add        s49, s48, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s40, v24, #9
    s.add        s50, s48, s40
    s.addi       s40, s50, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v24, #10
    v.or         v43, v37, v40
    s.add        s50, s48, s47
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s47, v24, #11
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v24, #12
    v.or         v43, v37, v40
    s.add        s49, s48, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s40, v24, #13
    s.add        s50, s48, s40
    s.addi       s40, s50, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v24, #14
    v.or         v43, v37, v40
    s.add        s50, s48, s47
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.extract    s47, v24, #15
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    s.addi       s40, s1, #32
    v.extract    s48, v33, #1
    s.add        s49, s2, s40
    v.extract    s40, v33, #0
    s.add        s50, s49, s48
    s.add        s48, s49, s40
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s47, #0]
    p.and        p4, p1, p3
    s.addi       s40, s50, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s47, b14, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s48, #0]
    p.and        p4, p2, p3
    v.extract    s48, v33, #3
    s.add        s50, s49, s48
    v.extract    s48, v33, #2
    s.add        s51, s49, s48
    s.addi       s48, s50, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v33, #4
    v.or         v43, v37, v40
    s.add        s50, s49, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s40, v33, #5
    s.add        s51, s49, s40
    s.addi       s40, s51, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s48, #0]
    p.and        p4, p1, p3
    v.extract    s48, v33, #6
    v.or         v43, v37, v40
    s.add        s51, s49, s48
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s48, v33, #7
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v33, #8
    v.or         v43, v37, v40
    s.add        s50, s49, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s40, v33, #9
    s.add        s51, s49, s40
    s.addi       s40, s51, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s48, #0]
    p.and        p4, p1, p3
    v.extract    s48, v33, #10
    v.or         v43, v37, v40
    s.add        s51, s49, s48
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s48, v33, #11
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v33, #12
    v.or         v43, v37, v40
    s.add        s50, s49, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s40, v33, #13
    s.add        s51, s49, s40
    s.addi       s40, s51, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s48, #0]
    p.and        p4, p1, p3
    v.extract    s48, v33, #14
    v.or         v43, v37, v40
    s.add        s51, s49, s48
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s48, v33, #15
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    p.and        p5, p2, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v27, #0
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    v.splat      v40, s40
    s.addi       s40, s33, #4096
    vf.max.ieee  v43, v40, v13
    s.addi       s49, s33, #9216                 // 512 bytes of repack scratch
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    v.movi       v44, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v44, [s48, #0]
    v.or         v45, v37, v44
    v.and        v37, v45, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s48, b15, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s48
    mb.wait      s48
    v.ld.w       v37, [s40, #0]
    s.addi       s40, s49, #0
    vf.fms       v39, v43, v40, v19
    vf.fms       v44, v40, v39, v40
    s.addi       s50, s33, #4160
    vf.neg       v39, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v39, v39
    v.extract    s51, v27, #1
    @p3 v.sel        v44, v39, v40
    v.splat      v39, s51
    vf.mul       v40, v37, v44                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v43, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v39, v44, v40
    vf.neg       v39, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #1
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #4224
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #2
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #2
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #4288
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #3
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #3
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #4352
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #4
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #4
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #4416
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #5
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #5
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #4480
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #6
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #6
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #4544
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #7
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #7
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #4608
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #8
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #8
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #4672
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #9
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #9
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #4736
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #10
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #10
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #4800
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #11
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #11
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #4864
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #12
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #12
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #4928
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #13
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #13
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #4992
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #14
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #14
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #5056
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #15
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #15
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #5120
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #0
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #256
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #5184
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #1
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #257
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #5248
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #2
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #258
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #5312
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #3
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #259
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #5376
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #4
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #260
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #5440
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #5
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #261
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #5504
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #6
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #262
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #5568
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #7
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #263
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #5632
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #8
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #264
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #5696
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #9
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #265
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #5760
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #10
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #266
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #5824
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #11
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #267
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #5888
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #12
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #268
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #5952
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #13
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #269
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s50, s33, #6016
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #14
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s51
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s50, #0]
    s.addi       s40, s49, #270
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s50, s33, #6080
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s51, v27, #15
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s51
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s50, #0]
    s.addi       s40, s49, #271
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v37
    vf.mul       v37, v39, v43                   // a/y: faithful quotient
    s.addi       s50, s49, #64
    vf.fms       v40, v37, v45, v39
    vf.fms       v39, v40, v43, v37
    vf.neg       v40, v39                        // a/y: one correction to the IEEE quotient
    s.addi       s51, s49, #128
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v39, v40, v37
    vf.cvt.f32.e4m3 v37, v39
    v.lshr       v40, v39, v41
    s.addi       s52, s49, #192
    v.and        v39, v40, v42
    v.or         v40, v37, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s53, s49, #256
    v.st.scatter.b [s40, v30], v40
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s40, s49, #320
    v.ld.w       v37, [s49, #0]
    v.mov        v48, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s50, #0]
    s.addi       s50, s49, #384
    v.mov        v49, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s51, #0]
    s.addi       s51, s49, #448
    v.mov        v50, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s52, #0]
    s.addi       s49, s31, #-64
    v.splat      v39, s49
    v.sub        v40, v39, v31
    v.mov        v51, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s53, #0]
    v.movi       v39, #0
    v.movi       v43, #0
    v.cmp.gt     p3, v40, v39
    v.mov        v52, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s40, #0]
    v.max.s      v39, v40, v43
    v.movi       v40, #4
    v.min.s      v43, v39, v40
    v.mov        v53, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s50, #0]
    v.movi       v39, #3
    v.movi       v40, #1
    v.shl        v44, v43, v39
    v.mov        v54, v37                        // hand off through the shared window (sec 7.3)
    v.ld.w       v37, [s51, #0]
    v.shl        v39, v40, v44
    v.movi       v40, #1
    v.sub        v44, v39, v40
    v.mov        v55, v37                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s1, #64
    v.extract    s49, v23, #1
    s.add        s50, s2, s40
    v.extract    s40, v23, #0
    s.add        s51, s50, s49
    s.add        s49, s50, s40
    p.and        p4, p1, p3
    s.addi       s40, s51, #-32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s49, #0]
    p.and        p4, p2, p3
    v.movi       v39, #4
    v.movi       v40, #-1
    v.movi       v45, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v45, [s40, #0]
    v.cmp.ge     p4, v43, v39
    @p4 v.sel        v39, v40, v44
    v.extract    s40, v23, #3
    s.add        s49, s50, s40
    v.extract    s40, v23, #2
    s.add        s51, s50, s40
    p.and        p4, p1, p3
    s.addi       s40, s49, #-32
    v.extract    s49, v23, #4
    v.or         v40, v37, v45
    s.add        s52, s50, s49
    v.and        v37, v40, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s49, v23, #5
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v23, #6
    v.or         v43, v37, v40
    s.add        s51, s50, s40
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s40, v23, #7
    s.add        s52, s50, s40
    s.addi       s40, s52, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s49, #0]
    p.and        p4, p1, p3
    v.extract    s49, v23, #8
    v.or         v43, v37, v40
    s.add        s52, s50, s49
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s49, v23, #9
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v23, #10
    v.or         v43, v37, v40
    s.add        s51, s50, s40
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s40, v23, #11
    s.add        s52, s50, s40
    s.addi       s40, s52, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s49, #0]
    p.and        p4, p1, p3
    v.extract    s49, v23, #12
    v.or         v43, v37, v40
    s.add        s52, s50, s49
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s49, v23, #13
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v23, #14
    v.or         v43, v37, v40
    s.add        s51, s50, s40
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s40, v23, #15
    s.add        s52, s50, s40
    s.addi       s40, s52, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s49, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    s.addi       s49, s1, #64
    v.extract    s50, v21, #1
    s.add        s51, s2, s49
    v.extract    s49, v21, #0
    s.add        s52, s51, s50
    s.add        s50, s51, s49
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    s.addi       s40, s52, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s49, b16, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s50, #0]
    p.and        p4, p2, p3
    v.extract    s50, v21, #3
    s.add        s52, s51, s50
    v.extract    s50, v21, #2
    s.add        s53, s51, s50
    s.addi       s50, s52, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v21, #4
    v.or         v43, v37, v40
    s.add        s52, s51, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s40, v21, #5
    s.add        s53, s51, s40
    s.addi       s40, s53, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s50, #0]
    p.and        p4, p1, p3
    v.extract    s50, v21, #6
    v.or         v43, v37, v40
    s.add        s53, s51, s50
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s50, v21, #7
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v21, #8
    v.or         v43, v37, v40
    s.add        s52, s51, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s40, v21, #9
    s.add        s53, s51, s40
    s.addi       s40, s53, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s50, #0]
    p.and        p4, p1, p3
    v.extract    s50, v21, #10
    v.or         v43, v37, v40
    s.add        s53, s51, s50
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s50, v21, #11
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v21, #12
    v.or         v43, v37, v40
    s.add        s52, s51, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s40, v21, #13
    s.add        s53, s51, s40
    s.addi       s40, s53, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s50, #0]
    p.and        p4, p1, p3
    v.extract    s50, v21, #14
    v.or         v43, v37, v40
    s.add        s53, s51, s50
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s50, v21, #15
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    s.addi       s40, s1, #64
    v.extract    s51, v22, #1
    s.add        s52, s2, s40
    v.extract    s40, v22, #0
    s.add        s53, s52, s51
    s.add        s51, s52, s40
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s50, #0]
    p.and        p4, p1, p3
    s.addi       s40, s53, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s50, b17, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s51, #0]
    p.and        p4, p2, p3
    v.extract    s51, v22, #3
    s.add        s53, s52, s51
    v.extract    s51, v22, #2
    s.add        s54, s52, s51
    s.addi       s51, s53, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v22, #4
    v.or         v43, v37, v40
    s.add        s53, s52, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s40, v22, #5
    s.add        s54, s52, s40
    s.addi       s40, s54, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s51, #0]
    p.and        p4, p1, p3
    v.extract    s51, v22, #6
    v.or         v43, v37, v40
    s.add        s54, s52, s51
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s51, v22, #7
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v22, #8
    v.or         v43, v37, v40
    s.add        s53, s52, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s40, v22, #9
    s.add        s54, s52, s40
    s.addi       s40, s54, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s51, #0]
    p.and        p4, p1, p3
    v.extract    s51, v22, #10
    v.or         v43, v37, v40
    s.add        s54, s52, s51
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s51, v22, #11
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v22, #12
    v.or         v43, v37, v40
    s.add        s53, s52, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s40, v22, #13
    s.add        s54, s52, s40
    s.addi       s40, s54, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s51, #0]
    p.and        p4, p1, p3
    v.extract    s51, v22, #14
    v.or         v43, v37, v40
    s.add        s54, s52, s51
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s51, v22, #15
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    s.addi       s40, s1, #64
    v.extract    s52, v18, #1
    s.add        s53, s2, s40
    v.extract    s40, v18, #0
    s.add        s54, s53, s52
    s.add        s52, s53, s40
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s51, #0]
    p.and        p4, p1, p3
    s.addi       s40, s54, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s51, b18, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s52, #0]
    p.and        p4, p2, p3
    v.extract    s52, v18, #3
    s.add        s54, s53, s52
    v.extract    s52, v18, #2
    s.add        s55, s53, s52
    s.addi       s52, s54, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v18, #4
    v.or         v43, v37, v40
    s.add        s54, s53, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s40, v18, #5
    s.add        s55, s53, s40
    s.addi       s40, s55, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s52, #0]
    p.and        p4, p1, p3
    v.extract    s52, v18, #6
    v.or         v43, v37, v40
    s.add        s55, s53, s52
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s52, v18, #7
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v18, #8
    v.or         v43, v37, v40
    s.add        s54, s53, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s40, v18, #9
    s.add        s55, s53, s40
    s.addi       s40, s55, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s52, #0]
    p.and        p4, p1, p3
    v.extract    s52, v18, #10
    v.or         v43, v37, v40
    s.add        s55, s53, s52
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s52, v18, #11
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v18, #12
    v.or         v43, v37, v40
    s.add        s54, s53, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s40, v18, #13
    s.add        s55, s53, s40
    s.addi       s40, s55, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s52, #0]
    p.and        p4, p1, p3
    v.extract    s52, v18, #14
    v.or         v43, v37, v40
    s.add        s55, s53, s52
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s52, v18, #15
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    s.addi       s40, s1, #64
    v.extract    s53, v28, #1
    s.add        s54, s2, s40
    v.extract    s40, v28, #0
    s.add        s55, s54, s53
    s.add        s53, s54, s40
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s52, #0]
    p.and        p4, p1, p3
    s.addi       s40, s55, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s52, b19, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s53, #0]
    p.and        p4, p2, p3
    v.extract    s53, v28, #3
    s.add        s55, s54, s53
    v.extract    s53, v28, #2
    s.add        s56, s54, s53
    s.addi       s53, s55, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v28, #4
    v.or         v43, v37, v40
    s.add        s55, s54, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s40, v28, #5
    s.add        s56, s54, s40
    s.addi       s40, s56, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s53, #0]
    p.and        p4, p1, p3
    v.extract    s53, v28, #6
    v.or         v43, v37, v40
    s.add        s56, s54, s53
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s53, v28, #7
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v28, #8
    v.or         v43, v37, v40
    s.add        s55, s54, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s40, v28, #9
    s.add        s56, s54, s40
    s.addi       s40, s56, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s53, #0]
    p.and        p4, p1, p3
    v.extract    s53, v28, #10
    v.or         v43, v37, v40
    s.add        s56, s54, s53
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s53, v28, #11
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v28, #12
    v.or         v43, v37, v40
    s.add        s55, s54, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s40, v28, #13
    s.add        s56, s54, s40
    s.addi       s40, s56, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s53, #0]
    p.and        p4, p1, p3
    v.extract    s53, v28, #14
    v.or         v43, v37, v40
    s.add        s56, s54, s53
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s53, v28, #15
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s56, #0]
    p.and        p4, p2, p3
    s.addi       s40, s1, #64
    v.extract    s54, v26, #1
    s.add        s55, s2, s40
    v.extract    s40, v26, #0
    s.add        s56, s55, s54
    s.add        s54, s55, s40
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s53, #0]
    p.and        p4, p1, p3
    s.addi       s40, s56, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s53, b20, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s54, #0]
    p.and        p4, p2, p3
    v.extract    s54, v26, #3
    s.add        s56, s55, s54
    v.extract    s54, v26, #2
    s.add        s57, s55, s54
    s.addi       s54, s56, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v26, #4
    v.or         v43, v37, v40
    s.add        s56, s55, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s40, v26, #5
    s.add        s57, s55, s40
    s.addi       s40, s57, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s54, #0]
    p.and        p4, p1, p3
    v.extract    s54, v26, #6
    v.or         v43, v37, v40
    s.add        s57, s55, s54
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s54, v26, #7
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v26, #8
    v.or         v43, v37, v40
    s.add        s56, s55, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s40, v26, #9
    s.add        s57, s55, s40
    s.addi       s40, s57, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s54, #0]
    p.and        p4, p1, p3
    v.extract    s54, v26, #10
    v.or         v43, v37, v40
    s.add        s57, s55, s54
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s54, v26, #11
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v26, #12
    v.or         v43, v37, v40
    s.add        s56, s55, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s40, v26, #13
    s.add        s57, s55, s40
    s.addi       s40, s57, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s54, #0]
    p.and        p4, p1, p3
    v.extract    s54, v26, #14
    v.or         v43, v37, v40
    s.add        s57, s55, s54
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s54, v26, #15
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s57, #0]
    p.and        p4, p2, p3
    s.addi       s40, s1, #64
    v.extract    s55, v24, #1
    s.add        s56, s2, s40
    v.extract    s40, v24, #0
    s.add        s57, s56, s55
    s.add        s55, s56, s40
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s54, #0]
    p.and        p4, p1, p3
    s.addi       s40, s57, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s54, b21, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s55, #0]
    p.and        p4, p2, p3
    v.extract    s55, v24, #3
    s.add        s57, s56, s55
    v.extract    s55, v24, #2
    s.add        s58, s56, s55
    s.addi       s55, s57, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v24, #4
    v.or         v43, v37, v40
    s.add        s57, s56, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s58, #0]
    p.and        p4, p2, p3
    v.extract    s40, v24, #5
    s.add        s58, s56, s40
    s.addi       s40, s58, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s55, #0]
    p.and        p4, p1, p3
    v.extract    s55, v24, #6
    v.or         v43, v37, v40
    s.add        s58, s56, s55
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s55, v24, #7
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v24, #8
    v.or         v43, v37, v40
    s.add        s57, s56, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s58, #0]
    p.and        p4, p2, p3
    v.extract    s40, v24, #9
    s.add        s58, s56, s40
    s.addi       s40, s58, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s55, #0]
    p.and        p4, p1, p3
    v.extract    s55, v24, #10
    v.or         v43, v37, v40
    s.add        s58, s56, s55
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s55, v24, #11
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v24, #12
    v.or         v43, v37, v40
    s.add        s57, s56, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s58, #0]
    p.and        p4, p2, p3
    v.extract    s40, v24, #13
    s.add        s58, s56, s40
    s.addi       s40, s58, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s55, #0]
    p.and        p4, p1, p3
    v.extract    s55, v24, #14
    v.or         v43, v37, v40
    s.add        s58, s56, s55
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s57, #0]
    p.and        p4, p2, p3
    v.extract    s55, v24, #15
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s58, #0]
    p.and        p4, p2, p3
    s.addi       s40, s1, #64
    v.extract    s56, v33, #1
    s.add        s57, s2, s40
    v.extract    s40, v33, #0
    s.add        s58, s57, s56
    s.add        s56, s57, s40
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s55, #0]
    p.and        p4, p1, p3
    s.addi       s40, s58, #-32
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s55, b22, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s55
    mb.wait      s55
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s56, #0]
    p.and        p4, p2, p3
    v.extract    s56, v33, #3
    s.add        s58, s57, s56
    v.extract    s56, v33, #2
    s.add        s59, s57, s56
    s.addi       s56, s58, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v33, #4
    v.or         v43, v37, v40
    s.add        s58, s57, s40
    v.and        v37, v43, v39
    v.mov        v56, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s59, #0]
    p.and        p4, p2, p3
    v.extract    s40, v33, #5
    s.add        s59, s57, s40
    s.addi       s40, s59, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s56, #0]
    p.and        p4, p1, p3
    v.extract    s56, v33, #6
    v.or         v43, v37, v40
    s.add        s59, s57, s56
    v.and        v37, v43, v39
    v.mov        v57, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s58, #0]
    p.and        p4, p2, p3
    v.extract    s56, v33, #7
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v33, #8
    v.or         v43, v37, v40
    s.add        s58, s57, s40
    v.and        v37, v43, v39
    v.mov        v58, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s59, #0]
    p.and        p4, p2, p3
    v.extract    s40, v33, #9
    s.add        s59, s57, s40
    s.addi       s40, s59, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s56, #0]
    p.and        p4, p1, p3
    v.extract    s56, v33, #10
    v.or         v43, v37, v40
    s.add        s59, s57, s56
    v.and        v37, v43, v39
    v.mov        v59, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s58, #0]
    p.and        p4, p2, p3
    v.extract    s56, v33, #11
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s40, v33, #12
    v.or         v43, v37, v40
    s.add        s58, s57, s40
    v.and        v37, v43, v39
    v.mov        v60, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s59, #0]
    p.and        p4, p2, p3
    v.extract    s40, v33, #13
    s.add        s59, s57, s40
    s.addi       s40, s59, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s56, #0]
    p.and        p4, p1, p3
    v.extract    s56, v33, #14
    v.or         v43, v37, v40
    s.add        s59, s57, s56
    v.and        v37, v43, v39
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s58, #0]
    p.and        p4, p2, p3
    v.extract    s56, v33, #15
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s40, #0]
    p.and        p4, p1, p3
    p.and        p5, p2, p3
    v.or         v43, v37, v40
    v.and        v37, v43, v39
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v27, #0
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s59, #0]
    v.splat      v40, s40
    s.addi       s40, s33, #6144
    vf.max.ieee  v43, v40, v13
    s.addi       s57, s33, #9728                 // 512 bytes of repack scratch
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    v.movi       v44, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v44, [s56, #0]
    v.or         v45, v37, v44
    v.and        v37, v45, v39
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s56, b23, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s56
    mb.wait      s56
    v.ld.w       v37, [s40, #0]
    s.addi       s40, s57, #0
    vf.fms       v39, v43, v40, v19
    vf.fms       v44, v40, v39, v40
    s.addi       s58, s33, #6208
    vf.neg       v39, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v39, v39
    v.extract    s59, v27, #1
    @p3 v.sel        v44, v39, v40
    v.splat      v39, s59
    vf.mul       v40, v37, v44                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v43, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v39, v44, v40
    vf.neg       v39, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #1
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #6272
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #2
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #2
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #6336
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #3
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #3
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #6400
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #4
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #4
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #6464
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #5
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #5
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #6528
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #6
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #6
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #6592
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #7
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #7
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #6656
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #8
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #8
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #6720
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #9
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #9
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #6784
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #10
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #10
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #6848
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #11
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #11
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #6912
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #12
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #12
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #6976
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #13
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #13
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #7040
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #14
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #14
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #7104
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #15
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #15
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #7168
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #0
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #256
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #7232
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #1
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #257
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #7296
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #2
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #258
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #7360
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #3
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #259
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #7424
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #4
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #260
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #7488
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #5
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #261
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #7552
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #6
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #262
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #7616
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #7
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #263
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #7680
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #8
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #264
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #7744
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #9
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #265
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #7808
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #10
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #266
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #7872
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #11
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #267
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #7936
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #12
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #268
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #8000
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #13
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v39, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v44, v39, v43, v40
    vf.neg       v39, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v43, v39, v40
    vf.cvt.f32.e4m3 v39, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v39, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v39, [s58, #0]
    s.addi       s40, s57, #269
    vf.fms       v40, v45, v37, v19
    vf.fms       v43, v37, v40, v37
    s.addi       s58, s33, #8064
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #14
    @p3 v.sel        v43, v40, v37
    v.splat      v37, s59
    vf.mul       v40, v39, v43                   // a/y: faithful quotient
    vf.max.ieee  v44, v37, v13
    vf.fms       v37, v40, v45, v39
    v.rcp.approx v39, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v37, v43, v40
    vf.neg       v37, v45                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v40
    vf.cvt.f32.e4m3 v37, v43
    v.lshr       v40, v43, v41
    v.and        v43, v40, v42
    v.or         v40, v37, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v37, [s58, #0]
    s.addi       s40, s57, #270
    vf.fms       v40, v44, v39, v19
    vf.fms       v43, v39, v40, v39
    s.addi       s58, s33, #8128
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v40, v40
    v.extract    s59, v27, #15
    @p3 v.sel        v43, v40, v39
    v.splat      v39, s59
    vf.mul       v40, v37, v43                   // a/y: faithful quotient
    vf.max.ieee  v45, v39, v13
    vf.fms       v13, v40, v44, v37
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v39, v13, v43, v40
    vf.neg       v13, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v13, v13
    @p3 v.sel        v39, v13, v40
    vf.cvt.f32.e4m3 v13, v39
    v.lshr       v40, v39, v41
    v.and        v39, v40, v42
    v.or         v40, v13, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.scatter.b [s40, v30], v40
    v.ld.w       v13, [s58, #0]
    s.addi       s40, s57, #271
    vf.fms       v39, v45, v37, v19
    vf.fms       v19, v37, v39, v37
    vf.neg       v39, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v39, v39
    @p3 v.sel        v19, v39, v37
    vf.mul       v37, v13, v19                   // a/y: faithful quotient
    s.addi       s58, s57, #64
    vf.fms       v39, v37, v45, v13
    vf.fms       v13, v39, v19, v37
    vf.neg       v19, v13                        // a/y: one correction to the IEEE quotient
    s.addi       s59, s57, #128
    vf.cmp.o     p3, v19, v19
    @p3 v.sel        v13, v19, v37
    vf.cvt.f32.e4m3 v19, v13
    v.lshr       v37, v13, v41
    s.addi       s60, s57, #192
    v.and        v13, v37, v42
    v.or         v37, v19, v13                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s57, #256
    v.st.scatter.b [s40, v30], v37
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s32, s57, #320
    v.ld.w       v13, [s57, #0]
    v.mov        v48, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s58, #0]
    s.addi       s34, s57, #384
    v.mov        v49, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s59, #0]
    s.addi       s35, s57, #448
    v.mov        v50, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s60, #0]
    s.addi       s36, s31, #-96
    v.splat      v19, s36
    v.sub        v37, v19, v31
    v.mov        v51, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s30, #0]
    v.movi       v19, #0
    v.movi       v31, #0
    v.cmp.gt     p3, v37, v19
    v.mov        v52, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s32, #0]
    v.max.s      v19, v37, v31
    v.movi       v31, #4
    v.min.s      v37, v19, v31
    v.mov        v53, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s34, #0]
    v.movi       v19, #3
    v.movi       v31, #1
    v.shl        v39, v37, v19
    v.mov        v54, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s35, #0]
    v.shl        v19, v31, v39
    v.movi       v31, #1
    v.sub        v39, v19, v31
    v.mov        v55, v13                        // hand off through the shared window (sec 7.3)
    s.addi       s30, s1, #96
    v.extract    s31, v23, #1
    s.add        s32, s2, s30
    v.extract    s30, v23, #0
    s.add        s34, s32, s31
    s.add        s31, s32, s30
    p.and        p4, p1, p3
    s.addi       s30, s34, #-32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s31, #0]
    p.and        p4, p2, p3
    v.movi       v19, #4
    v.movi       v31, #-1
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v40, [s30, #0]
    v.cmp.ge     p4, v37, v19
    @p4 v.sel        v19, v31, v39
    v.extract    s30, v23, #3
    s.add        s31, s32, s30
    v.extract    s30, v23, #2
    s.add        s34, s32, s30
    p.and        p4, p1, p3
    s.addi       s30, s31, #-32
    v.extract    s31, v23, #4
    v.or         v31, v13, v40
    s.add        s35, s32, s31
    v.and        v13, v31, v19
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s31, v23, #5
    s.add        s34, s32, s31
    s.addi       s31, s34, #-32
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v23, #6
    v.or         v37, v13, v31
    s.add        s34, s32, s30
    v.and        v13, v37, v19
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s30, v23, #7
    s.add        s35, s32, s30
    s.addi       s30, s35, #-32
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s31, #0]
    p.and        p4, p1, p3
    v.extract    s31, v23, #8
    v.or         v37, v13, v31
    s.add        s35, s32, s31
    v.and        v13, v37, v19
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s31, v23, #9
    s.add        s34, s32, s31
    s.addi       s31, s34, #-32
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v23, #10
    v.or         v37, v13, v31
    s.add        s34, s32, s30
    v.and        v13, v37, v19
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s30, v23, #11
    s.add        s35, s32, s30
    s.addi       s30, s35, #-32
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s31, #0]
    p.and        p4, p1, p3
    v.extract    s31, v23, #12
    v.or         v37, v13, v31
    s.add        s35, s32, s31
    v.and        v13, v37, v19
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s31, v23, #13
    s.add        s34, s32, s31
    s.addi       s31, s34, #-32
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v23, #14
    v.or         v37, v13, v31
    s.add        s34, s32, s30
    v.and        v13, v37, v19
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s30, v23, #15
    s.add        s35, s32, s30
    s.addi       s30, s35, #-32
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v23, [s31, #0]
    p.and        p4, p1, p3
    v.or         v31, v13, v23
    v.and        v13, v31, v19
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s34, #0]
    p.and        p4, p2, p3
    s.addi       s31, s1, #96
    v.extract    s32, v21, #1
    s.add        s34, s2, s31
    v.extract    s31, v21, #0
    s.add        s35, s34, s32
    s.add        s32, s34, s31
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v23, [s30, #0]
    p.and        p4, p1, p3
    s.addi       s30, s35, #-32
    v.or         v31, v13, v23
    v.and        v13, v31, v19
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s31, b24, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s32, #0]
    p.and        p4, p2, p3
    v.extract    s32, v21, #3
    s.add        s35, s34, s32
    v.extract    s32, v21, #2
    s.add        s36, s34, s32
    s.addi       s32, s35, #-32
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v23, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v21, #4
    v.or         v31, v13, v23
    s.add        s35, s34, s30
    v.and        v13, v31, v19
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s30, v21, #5
    s.add        s36, s34, s30
    s.addi       s30, s36, #-32
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v23, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s32, v21, #6
    v.or         v31, v13, v23
    s.add        s36, s34, s32
    v.and        v13, v31, v19
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s32, v21, #7
    s.add        s35, s34, s32
    s.addi       s32, s35, #-32
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v23, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v21, #8
    v.or         v31, v13, v23
    s.add        s35, s34, s30
    v.and        v13, v31, v19
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s30, v21, #9
    s.add        s36, s34, s30
    s.addi       s30, s36, #-32
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v23, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s32, v21, #10
    v.or         v31, v13, v23
    s.add        s36, s34, s32
    v.and        v13, v31, v19
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s32, v21, #11
    s.add        s35, s34, s32
    s.addi       s32, s35, #-32
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v23, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v21, #12
    v.or         v31, v13, v23
    s.add        s35, s34, s30
    v.and        v13, v31, v19
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s30, v21, #13
    s.add        s36, s34, s30
    s.addi       s30, s36, #-32
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v23, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s32, v21, #14
    v.or         v31, v13, v23
    s.add        s36, s34, s32
    v.and        v13, v31, v19
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s32, v21, #15
    s.add        s35, s34, s32
    s.addi       s32, s35, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s30, #0]
    p.and        p4, p1, p3
    v.or         v23, v13, v21
    v.and        v13, v23, v19
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s36, #0]
    p.and        p4, p2, p3
    s.addi       s30, s1, #96
    v.extract    s34, v22, #1
    s.add        s35, s2, s30
    v.extract    s30, v22, #0
    s.add        s36, s35, s34
    s.add        s34, s35, s30
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s32, #0]
    p.and        p4, p1, p3
    s.addi       s30, s36, #-32
    v.or         v23, v13, v21
    v.and        v13, v23, v19
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s32, b25, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s34, #0]
    p.and        p4, p2, p3
    v.extract    s34, v22, #3
    s.add        s36, s35, s34
    v.extract    s34, v22, #2
    s.add        s37, s35, s34
    s.addi       s34, s36, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v22, #4
    v.or         v23, v13, v21
    s.add        s36, s35, s30
    v.and        v13, v23, v19
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s30, v22, #5
    s.add        s37, s35, s30
    s.addi       s30, s37, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v22, #6
    v.or         v23, v13, v21
    s.add        s37, s35, s34
    v.and        v13, v23, v19
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s34, v22, #7
    s.add        s36, s35, s34
    s.addi       s34, s36, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v22, #8
    v.or         v23, v13, v21
    s.add        s36, s35, s30
    v.and        v13, v23, v19
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s30, v22, #9
    s.add        s37, s35, s30
    s.addi       s30, s37, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v22, #10
    v.or         v23, v13, v21
    s.add        s37, s35, s34
    v.and        v13, v23, v19
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s34, v22, #11
    s.add        s36, s35, s34
    s.addi       s34, s36, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v22, #12
    v.or         v23, v13, v21
    s.add        s36, s35, s30
    v.and        v13, v23, v19
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s30, v22, #13
    s.add        s37, s35, s30
    s.addi       s30, s37, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s34, v22, #14
    v.or         v23, v13, v21
    s.add        s37, s35, s34
    v.and        v13, v23, v19
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s34, v22, #15
    s.add        s36, s35, s34
    s.addi       s34, s36, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s30, #0]
    p.and        p4, p1, p3
    v.or         v22, v13, v21
    v.and        v13, v22, v19
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s37, #0]
    p.and        p4, p2, p3
    s.addi       s30, s1, #96
    v.extract    s35, v18, #1
    s.add        s36, s2, s30
    v.extract    s30, v18, #0
    s.add        s37, s36, s35
    s.add        s35, s36, s30
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s34, #0]
    p.and        p4, p1, p3
    s.addi       s30, s37, #-32
    v.or         v22, v13, v21
    v.and        v13, v22, v19
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s34, b26, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s35, #0]
    p.and        p4, p2, p3
    v.extract    s35, v18, #3
    s.add        s37, s36, s35
    v.extract    s35, v18, #2
    s.add        s38, s36, s35
    s.addi       s35, s37, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v18, #4
    v.or         v22, v13, v21
    s.add        s37, s36, s30
    v.and        v13, v22, v19
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s30, v18, #5
    s.add        s38, s36, s30
    s.addi       s30, s38, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v18, #6
    v.or         v22, v13, v21
    s.add        s38, s36, s35
    v.and        v13, v22, v19
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s35, v18, #7
    s.add        s37, s36, s35
    s.addi       s35, s37, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v18, #8
    v.or         v22, v13, v21
    s.add        s37, s36, s30
    v.and        v13, v22, v19
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s30, v18, #9
    s.add        s38, s36, s30
    s.addi       s30, s38, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v18, #10
    v.or         v22, v13, v21
    s.add        s38, s36, s35
    v.and        v13, v22, v19
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s35, v18, #11
    s.add        s37, s36, s35
    s.addi       s35, s37, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v18, #12
    v.or         v22, v13, v21
    s.add        s37, s36, s30
    v.and        v13, v22, v19
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s30, v18, #13
    s.add        s38, s36, s30
    s.addi       s30, s38, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v21, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s35, v18, #14
    v.or         v22, v13, v21
    s.add        s38, s36, s35
    v.and        v13, v22, v19
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s35, v18, #15
    s.add        s37, s36, s35
    s.addi       s35, s37, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.or         v21, v13, v18
    v.and        v13, v21, v19
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s38, #0]
    p.and        p4, p2, p3
    s.addi       s30, s1, #96
    v.extract    s36, v28, #1
    s.add        s37, s2, s30
    v.extract    s30, v28, #0
    s.add        s38, s37, s36
    s.add        s36, s37, s30
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s35, #0]
    p.and        p4, p1, p3
    s.addi       s30, s38, #-32
    v.or         v21, v13, v18
    v.and        v13, v21, v19
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s35, b27, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s36, #0]
    p.and        p4, p2, p3
    v.extract    s36, v28, #3
    s.add        s38, s37, s36
    v.extract    s36, v28, #2
    s.add        s39, s37, s36
    s.addi       s36, s38, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v28, #4
    v.or         v21, v13, v18
    s.add        s38, s37, s30
    v.and        v13, v21, v19
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s30, v28, #5
    s.add        s39, s37, s30
    s.addi       s30, s39, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v28, #6
    v.or         v21, v13, v18
    s.add        s39, s37, s36
    v.and        v13, v21, v19
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s36, v28, #7
    s.add        s38, s37, s36
    s.addi       s36, s38, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v28, #8
    v.or         v21, v13, v18
    s.add        s38, s37, s30
    v.and        v13, v21, v19
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s30, v28, #9
    s.add        s39, s37, s30
    s.addi       s30, s39, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v28, #10
    v.or         v21, v13, v18
    s.add        s39, s37, s36
    v.and        v13, v21, v19
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s36, v28, #11
    s.add        s38, s37, s36
    s.addi       s36, s38, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v28, #12
    v.or         v21, v13, v18
    s.add        s38, s37, s30
    v.and        v13, v21, v19
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s30, v28, #13
    s.add        s39, s37, s30
    s.addi       s30, s39, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s36, v28, #14
    v.or         v21, v13, v18
    s.add        s39, s37, s36
    v.and        v13, v21, v19
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s36, v28, #15
    s.add        s38, s37, s36
    s.addi       s36, s38, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.or         v21, v13, v18
    v.and        v13, v21, v19
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s39, #0]
    p.and        p4, p2, p3
    s.addi       s30, s1, #96
    v.extract    s37, v26, #1
    s.add        s38, s2, s30
    v.extract    s30, v26, #0
    s.add        s39, s38, s37
    s.add        s37, s38, s30
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s36, #0]
    p.and        p4, p1, p3
    s.addi       s30, s39, #-32
    v.or         v21, v13, v18
    v.and        v13, v21, v19
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b28, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s37, #0]
    p.and        p4, p2, p3
    v.extract    s37, v26, #3
    s.add        s39, s38, s37
    v.extract    s37, v26, #2
    s.add        s40, s38, s37
    s.addi       s37, s39, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v26, #4
    v.or         v21, v13, v18
    s.add        s39, s38, s30
    v.and        v13, v21, v19
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s30, v26, #5
    s.add        s40, s38, s30
    s.addi       s30, s40, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v26, #6
    v.or         v21, v13, v18
    s.add        s40, s38, s37
    v.and        v13, v21, v19
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s37, v26, #7
    s.add        s39, s38, s37
    s.addi       s37, s39, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v26, #8
    v.or         v21, v13, v18
    s.add        s39, s38, s30
    v.and        v13, v21, v19
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s30, v26, #9
    s.add        s40, s38, s30
    s.addi       s30, s40, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v26, #10
    v.or         v21, v13, v18
    s.add        s40, s38, s37
    v.and        v13, v21, v19
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s37, v26, #11
    s.add        s39, s38, s37
    s.addi       s37, s39, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v26, #12
    v.or         v21, v13, v18
    s.add        s39, s38, s30
    v.and        v13, v21, v19
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s30, v26, #13
    s.add        s40, s38, s30
    s.addi       s30, s40, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v26, #14
    v.or         v21, v13, v18
    s.add        s40, s38, s37
    v.and        v13, v21, v19
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s37, v26, #15
    s.add        s39, s38, s37
    s.addi       s37, s39, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.or         v21, v13, v18
    v.and        v13, v21, v19
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s40, #0]
    p.and        p4, p2, p3
    s.addi       s30, s1, #96
    v.extract    s38, v24, #1
    s.add        s39, s2, s30
    v.extract    s30, v24, #0
    s.add        s40, s39, s38
    s.add        s38, s39, s30
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s37, #0]
    p.and        p4, p1, p3
    s.addi       s30, s40, #-32
    v.or         v21, v13, v18
    v.and        v13, v21, v19
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b29, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s38, #0]
    p.and        p4, p2, p3
    v.extract    s38, v24, #3
    s.add        s40, s39, s38
    v.extract    s38, v24, #2
    s.add        s41, s39, s38
    s.addi       s38, s40, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v24, #4
    v.or         v21, v13, v18
    s.add        s40, s39, s30
    v.and        v13, v21, v19
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s30, v24, #5
    s.add        s41, s39, s30
    s.addi       s30, s41, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v24, #6
    v.or         v21, v13, v18
    s.add        s41, s39, s38
    v.and        v13, v21, v19
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s38, v24, #7
    s.add        s40, s39, s38
    s.addi       s38, s40, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v24, #8
    v.or         v21, v13, v18
    s.add        s40, s39, s30
    v.and        v13, v21, v19
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s30, v24, #9
    s.add        s41, s39, s30
    s.addi       s30, s41, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v24, #10
    v.or         v21, v13, v18
    s.add        s41, s39, s38
    v.and        v13, v21, v19
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s38, v24, #11
    s.add        s40, s39, s38
    s.addi       s38, s40, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v24, #12
    v.or         v21, v13, v18
    s.add        s40, s39, s30
    v.and        v13, v21, v19
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s30, v24, #13
    s.add        s41, s39, s30
    s.addi       s30, s41, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v24, #14
    v.or         v21, v13, v18
    s.add        s41, s39, s38
    v.and        v13, v21, v19
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s40, #0]
    p.and        p4, p2, p3
    v.extract    s38, v24, #15
    s.add        s40, s39, s38
    s.addi       s38, s40, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.or         v21, v13, v18
    v.and        v13, v21, v19
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s41, #0]
    p.and        p4, p2, p3
    s.addi       s30, s1, #96
    v.extract    s39, v33, #1
    s.add        s40, s2, s30
    v.extract    s30, v33, #0
    s.add        s41, s40, s39
    s.add        s39, s40, s30
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s38, #0]
    p.and        p4, p1, p3
    s.addi       s30, s41, #-32
    v.or         v21, v13, v18
    v.and        v13, v21, v19
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s38, b30, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s39, #0]
    p.and        p4, p2, p3
    v.extract    s39, v33, #3
    s.add        s41, s40, s39
    v.extract    s39, v33, #2
    s.add        s42, s40, s39
    s.addi       s39, s41, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v33, #4
    v.or         v21, v13, v18
    s.add        s41, s40, s30
    v.and        v13, v21, v19
    v.mov        v56, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s30, v33, #5
    s.add        s42, s40, s30
    s.addi       s30, s42, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s39, v33, #6
    v.or         v21, v13, v18
    s.add        s42, s40, s39
    v.and        v13, v21, v19
    v.mov        v57, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s39, v33, #7
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v33, #8
    v.or         v21, v13, v18
    s.add        s41, s40, s30
    v.and        v13, v21, v19
    v.mov        v58, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s30, v33, #9
    s.add        s42, s40, s30
    s.addi       s30, s42, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s39, v33, #10
    v.or         v21, v13, v18
    s.add        s42, s40, s39
    v.and        v13, v21, v19
    v.mov        v59, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s41, #0]
    p.and        p4, p2, p3
    v.extract    s39, v33, #11
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v33, #12
    v.or         v21, v13, v18
    s.add        s41, s40, s30
    v.and        v13, v21, v19
    v.mov        v60, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s42, #0]
    p.and        p4, p2, p3
    v.extract    s30, v33, #13
    s.add        s42, s40, s30
    s.addi       s30, s42, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s39, v33, #14
    v.or         v21, v13, v18
    s.add        s42, s40, s39
    v.and        v13, v21, v19
    p.and        p5, p1, p3
    v.mov        v61, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v13, [s41, #0]
    p.and        p1, p2, p3
    v.extract    s39, v33, #15
    s.add        s41, s40, s39
    p.and        p4, p2, p3
    s.addi       s39, s41, #-32
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v18, [s30, #0]
    v.or         v21, v13, v18
    v.and        v13, v21, v19
    v.mov        v62, v13                        // hand off through the shared window (sec 7.3)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v13, [s42, #0]
    s.movz       s30, #0
    s.addi       s40, s33, #10240
    s.movz       s41, #1
    s.addi       s42, s40, #4
    s.addi       s43, s40, #8
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v18, [s39, #0]
    s.movz       s39, #2
    v.or         v21, v13, v18
    v.and        v13, v21, v19
    v.mov        v63, v13                        // hand off through the shared window (sec 7.3)
    mb.arm       s44, b31, #0, #1                // 0 arrival(s), 1 operation(s)
    s.movz       s45, #3
    m.mma.async.k32.e4m3 a15, v56, v48, s44
    mb.wait      s44
    a.vread      v13, a8, s30
    s.addi       s30, s40, #12
    v.st.scatter.w [s40, v30], v13
    a.vread      v13, a8, s41
    s.movz       s41, #4
    s.addi       s46, s40, #16
    s.movz       s47, #5
    s.addi       s48, s40, #20
    v.st.scatter.w [s42, v30], v13
    a.vread      v13, a8, s39
    s.movz       s39, #6
    s.addi       s42, s40, #24
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a8, s45
    s.movz       s43, #7
    s.addi       s45, s40, #28
    v.st.scatter.w [s30, v30], v13
    a.vread      v13, a8, s41
    s.movz       s30, #8
    s.addi       s41, s40, #32
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a8, s47
    s.movz       s46, #9
    s.addi       s47, s40, #36
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a8, s39
    s.movz       s39, #10
    s.addi       s48, s40, #40
    v.st.scatter.w [s42, v30], v13
    a.vread      v13, a8, s43
    s.movz       s42, #11
    s.addi       s43, s40, #44
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a8, s30
    s.movz       s30, #12
    s.addi       s45, s40, #48
    v.st.scatter.w [s41, v30], v13
    a.vread      v13, a8, s46
    s.movz       s41, #13
    s.addi       s46, s40, #52
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a8, s39
    s.movz       s39, #14
    s.addi       s47, s40, #56
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a8, s42
    s.movz       s42, #15
    s.addi       s48, s40, #60
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a8, s30
    s.movz       s30, #0
    s.addi       s40, s33, #11264
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a8, s41
    s.movz       s41, #1
    s.addi       s43, s40, #4
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a8, s39
    s.movz       s39, #2
    s.addi       s45, s40, #8
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a8, s42
    s.movz       s42, #3
    s.addi       s46, s40, #12
    v.st.scatter.w [s48, v30], v13
    fence.acq_rel.device
    a.vread      v13, a9, s30
    s.movz       s30, #4
    s.addi       s47, s40, #16
    v.st.scatter.w [s40, v30], v13
    a.vread      v13, a9, s41
    s.movz       s41, #5
    s.addi       s48, s40, #20
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a9, s39
    s.movz       s39, #6
    s.addi       s43, s40, #24
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a9, s42
    s.movz       s42, #7
    s.addi       s45, s40, #28
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a9, s30
    s.movz       s30, #8
    s.addi       s46, s40, #32
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a9, s41
    s.movz       s41, #9
    s.addi       s47, s40, #36
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a9, s39
    s.movz       s39, #10
    s.addi       s48, s40, #40
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a9, s42
    s.movz       s42, #11
    s.addi       s43, s40, #44
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a9, s30
    s.movz       s30, #12
    s.addi       s45, s40, #48
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a9, s41
    s.movz       s41, #13
    s.addi       s46, s40, #52
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a9, s39
    s.movz       s39, #14
    s.addi       s47, s40, #56
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a9, s42
    s.movz       s42, #15
    s.addi       s48, s40, #60
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a9, s30
    s.movz       s30, #0
    s.addi       s40, s33, #12288
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a9, s41
    s.movz       s41, #1
    s.addi       s43, s40, #4
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a9, s39
    s.movz       s39, #2
    s.addi       s45, s40, #8
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a9, s42
    s.movz       s42, #3
    s.addi       s46, s40, #12
    v.st.scatter.w [s48, v30], v13
    fence.acq_rel.device
    a.vread      v13, a10, s30
    s.movz       s30, #4
    s.addi       s47, s40, #16
    v.st.scatter.w [s40, v30], v13
    a.vread      v13, a10, s41
    s.movz       s41, #5
    s.addi       s48, s40, #20
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a10, s39
    s.movz       s39, #6
    s.addi       s43, s40, #24
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a10, s42
    s.movz       s42, #7
    s.addi       s45, s40, #28
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a10, s30
    s.movz       s30, #8
    s.addi       s46, s40, #32
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a10, s41
    s.movz       s41, #9
    s.addi       s47, s40, #36
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a10, s39
    s.movz       s39, #10
    s.addi       s48, s40, #40
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a10, s42
    s.movz       s42, #11
    s.addi       s43, s40, #44
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a10, s30
    s.movz       s30, #12
    s.addi       s45, s40, #48
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a10, s41
    s.movz       s41, #13
    s.addi       s46, s40, #52
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a10, s39
    s.movz       s39, #14
    s.addi       s47, s40, #56
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a10, s42
    s.movz       s42, #15
    s.addi       s48, s40, #60
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a10, s30
    s.movz       s30, #0
    s.addi       s40, s33, #13312
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a10, s41
    s.movz       s41, #1
    s.addi       s43, s40, #4
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a10, s39
    s.movz       s39, #2
    s.addi       s45, s40, #8
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a10, s42
    s.movz       s42, #3
    s.addi       s46, s40, #12
    v.st.scatter.w [s48, v30], v13
    fence.acq_rel.device
    a.vread      v13, a11, s30
    s.movz       s30, #4
    s.addi       s47, s40, #16
    v.st.scatter.w [s40, v30], v13
    a.vread      v13, a11, s41
    s.movz       s41, #5
    s.addi       s48, s40, #20
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a11, s39
    s.movz       s39, #6
    s.addi       s43, s40, #24
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a11, s42
    s.movz       s42, #7
    s.addi       s45, s40, #28
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a11, s30
    s.movz       s30, #8
    s.addi       s46, s40, #32
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a11, s41
    s.movz       s41, #9
    s.addi       s47, s40, #36
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a11, s39
    s.movz       s39, #10
    s.addi       s48, s40, #40
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a11, s42
    s.movz       s42, #11
    s.addi       s43, s40, #44
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a11, s30
    s.movz       s30, #12
    s.addi       s45, s40, #48
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a11, s41
    s.movz       s41, #13
    s.addi       s46, s40, #52
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a11, s39
    s.movz       s39, #14
    s.addi       s47, s40, #56
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a11, s42
    s.movz       s42, #15
    s.addi       s48, s40, #60
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a11, s30
    s.movz       s30, #0
    s.addi       s40, s33, #14336
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a11, s41
    s.movz       s41, #1
    s.addi       s43, s40, #4
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a11, s39
    s.movz       s39, #2
    s.addi       s45, s40, #8
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a11, s42
    s.movz       s42, #3
    s.addi       s46, s40, #12
    v.st.scatter.w [s48, v30], v13
    fence.acq_rel.device
    a.vread      v13, a12, s30
    s.movz       s30, #4
    s.addi       s47, s40, #16
    v.st.scatter.w [s40, v30], v13
    a.vread      v13, a12, s41
    s.movz       s41, #5
    s.addi       s48, s40, #20
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a12, s39
    s.movz       s39, #6
    s.addi       s43, s40, #24
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a12, s42
    s.movz       s42, #7
    s.addi       s45, s40, #28
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a12, s30
    s.movz       s30, #8
    s.addi       s46, s40, #32
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a12, s41
    s.movz       s41, #9
    s.addi       s47, s40, #36
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a12, s39
    s.movz       s39, #10
    s.addi       s48, s40, #40
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a12, s42
    s.movz       s42, #11
    s.addi       s43, s40, #44
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a12, s30
    s.movz       s30, #12
    s.addi       s45, s40, #48
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a12, s41
    s.movz       s41, #13
    s.addi       s46, s40, #52
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a12, s39
    s.movz       s39, #14
    s.addi       s47, s40, #56
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a12, s42
    s.movz       s42, #15
    s.addi       s48, s40, #60
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a12, s30
    s.movz       s30, #0
    s.addi       s40, s33, #15360
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a12, s41
    s.movz       s41, #1
    s.addi       s43, s40, #4
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a12, s39
    s.movz       s39, #2
    s.addi       s45, s40, #8
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a12, s42
    s.movz       s42, #3
    s.addi       s46, s40, #12
    v.st.scatter.w [s48, v30], v13
    fence.acq_rel.device
    a.vread      v13, a13, s30
    s.movz       s30, #4
    s.addi       s47, s40, #16
    v.st.scatter.w [s40, v30], v13
    a.vread      v13, a13, s41
    s.movz       s41, #5
    s.addi       s48, s40, #20
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a13, s39
    s.movz       s39, #6
    s.addi       s43, s40, #24
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a13, s42
    s.movz       s42, #7
    s.addi       s45, s40, #28
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a13, s30
    s.movz       s30, #8
    s.addi       s46, s40, #32
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a13, s41
    s.movz       s41, #9
    s.addi       s47, s40, #36
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a13, s39
    s.movz       s39, #10
    s.addi       s48, s40, #40
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a13, s42
    s.movz       s42, #11
    s.addi       s43, s40, #44
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a13, s30
    s.movz       s30, #12
    s.addi       s45, s40, #48
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a13, s41
    s.movz       s41, #13
    s.addi       s46, s40, #52
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a13, s39
    s.movz       s39, #14
    s.addi       s47, s40, #56
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a13, s42
    s.movz       s42, #15
    s.addi       s48, s40, #60
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a13, s30
    s.movz       s30, #0
    s.addi       s40, s33, #16384
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a13, s41
    s.movz       s41, #1
    s.addi       s43, s40, #4
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a13, s39
    s.movz       s39, #2
    s.addi       s45, s40, #8
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a13, s42
    s.movz       s42, #3
    s.addi       s46, s40, #12
    v.st.scatter.w [s48, v30], v13
    fence.acq_rel.device
    a.vread      v13, a14, s30
    s.movz       s30, #4
    s.addi       s47, s40, #16
    v.st.scatter.w [s40, v30], v13
    a.vread      v13, a14, s41
    s.movz       s41, #5
    s.addi       s48, s40, #20
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a14, s39
    s.movz       s39, #6
    s.addi       s43, s40, #24
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a14, s42
    s.movz       s42, #7
    s.addi       s45, s40, #28
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a14, s30
    s.movz       s30, #8
    s.addi       s46, s40, #32
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a14, s41
    s.movz       s41, #9
    s.addi       s47, s40, #36
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a14, s39
    s.movz       s39, #10
    s.addi       s48, s40, #40
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a14, s42
    s.movz       s42, #11
    s.addi       s43, s40, #44
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a14, s30
    s.movz       s30, #12
    s.addi       s45, s40, #48
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a14, s41
    s.movz       s41, #13
    s.addi       s46, s40, #52
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a14, s39
    s.movz       s39, #14
    s.addi       s47, s40, #56
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a14, s42
    s.movz       s42, #15
    s.addi       s48, s40, #60
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a14, s30
    s.movz       s30, #0
    s.addi       s40, s33, #17408
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a14, s41
    s.movz       s41, #1
    s.addi       s43, s40, #4
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a14, s39
    s.movz       s39, #2
    s.addi       s45, s40, #8
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a14, s42
    s.movz       s42, #3
    s.addi       s46, s40, #12
    v.st.scatter.w [s48, v30], v13
    fence.acq_rel.device
    a.vread      v13, a15, s30
    s.movz       s30, #4
    s.addi       s47, s40, #16
    v.st.scatter.w [s40, v30], v13
    a.vread      v13, a15, s41
    s.movz       s41, #5
    s.addi       s48, s40, #20
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a15, s39
    s.movz       s39, #6
    s.addi       s43, s40, #24
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a15, s42
    s.movz       s42, #7
    s.addi       s45, s40, #28
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a15, s30
    s.movz       s30, #8
    s.addi       s46, s40, #32
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a15, s41
    s.movz       s41, #9
    s.addi       s47, s40, #36
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a15, s39
    s.movz       s39, #10
    s.addi       s48, s40, #40
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a15, s42
    s.movz       s42, #11
    s.addi       s43, s40, #44
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a15, s30
    s.movz       s30, #12
    s.addi       s45, s40, #48
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a15, s41
    s.movz       s41, #13
    s.addi       s46, s40, #52
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a15, s39
    s.movz       s39, #14
    s.addi       s47, s40, #56
    v.st.scatter.w [s48, v30], v13
    a.vread      v13, a15, s42
    s.movz       s42, #15
    s.addi       s48, s40, #60
    v.st.scatter.w [s43, v30], v13
    a.vread      v13, a15, s30
    s.movz       s30, #0
    s.addi       s40, s33, #18432
    v.st.scatter.w [s45, v30], v13
    a.vread      v13, a15, s41
    s.addi       s41, s33, #10240
    v.extract    s43, v27, #0
    v.st.scatter.w [s46, v30], v13
    a.vread      v13, a15, s39
    v.splat      v18, s43
    v.st.scatter.w [s47, v30], v13
    a.vread      v13, a15, s42
    s.movz       s39, #1
    s.addi       s42, s40, #64
    v.st.scatter.w [s48, v30], v13
    fence.acq_rel.device
    a.vread      v13, a0, s30
    s.addi       s30, s33, #10304
    v.extract    s43, v27, #1
    v.splat      v19, s43
    v.ld.w       v21, [s41, #0]
    s.addi       s41, s40, #128
    vf.mul       v22, v21, v18
    s.movz       s43, #2
    vf.mul       v18, v22, v14
    vf.add       v21, v13, v18
    s.addi       s45, s33, #10368
    v.st.w       [s40, #0], v21
    a.vread      v13, a0, s39
    v.extract    s39, v27, #2
    v.splat      v18, s39
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s40, #192
    vf.mul       v22, v21, v19
    s.movz       s39, #3
    vf.mul       v19, v22, v14
    vf.add       v21, v13, v19
    s.addi       s46, s33, #10432
    v.st.w       [s42, #0], v21
    a.vread      v13, a0, s43
    v.extract    s42, v27, #3
    v.splat      v19, s42
    v.ld.w       v21, [s45, #0]
    s.addi       s42, s40, #256
    vf.mul       v22, v21, v18
    s.movz       s43, #4
    vf.mul       v18, v22, v14
    vf.add       v21, v13, v18
    s.addi       s45, s33, #10496
    v.st.w       [s41, #0], v21
    a.vread      v13, a0, s39
    v.extract    s39, v27, #4
    v.splat      v18, s39
    v.ld.w       v21, [s46, #0]
    s.addi       s39, s40, #320
    vf.mul       v22, v21, v19
    s.movz       s41, #5
    vf.mul       v19, v22, v14
    vf.add       v21, v13, v19
    s.addi       s46, s33, #10560
    v.st.w       [s30, #0], v21
    a.vread      v13, a0, s43
    v.extract    s30, v27, #5
    v.splat      v19, s30
    v.ld.w       v21, [s45, #0]
    s.addi       s30, s40, #384
    vf.mul       v22, v21, v18
    s.movz       s43, #6
    vf.mul       v18, v22, v14
    vf.add       v21, v13, v18
    s.addi       s45, s33, #10624
    v.st.w       [s42, #0], v21
    a.vread      v13, a0, s41
    v.extract    s41, v27, #6
    v.splat      v18, s41
    v.ld.w       v21, [s46, #0]
    s.addi       s41, s40, #448
    vf.mul       v22, v21, v19
    s.movz       s42, #7
    vf.mul       v19, v22, v14
    vf.add       v21, v13, v19
    s.addi       s46, s33, #10688
    v.st.w       [s39, #0], v21
    a.vread      v13, a0, s43
    v.extract    s39, v27, #7
    v.splat      v19, s39
    v.ld.w       v21, [s45, #0]
    s.addi       s39, s40, #512
    vf.mul       v22, v21, v18
    s.movz       s43, #8
    vf.mul       v18, v22, v14
    vf.add       v21, v13, v18
    s.addi       s45, s33, #10752
    v.st.w       [s30, #0], v21
    a.vread      v13, a0, s42
    v.extract    s30, v27, #8
    v.splat      v18, s30
    v.ld.w       v21, [s46, #0]
    s.addi       s30, s40, #576
    vf.mul       v22, v21, v19
    s.movz       s42, #9
    vf.mul       v19, v22, v14
    vf.add       v21, v13, v19
    s.addi       s46, s33, #10816
    v.st.w       [s41, #0], v21
    a.vread      v13, a0, s43
    v.extract    s41, v27, #9
    v.splat      v19, s41
    v.ld.w       v21, [s45, #0]
    s.addi       s41, s40, #640
    vf.mul       v22, v21, v18
    s.movz       s43, #10
    vf.mul       v18, v22, v14
    vf.add       v21, v13, v18
    s.addi       s45, s33, #10880
    v.st.w       [s39, #0], v21
    a.vread      v13, a0, s42
    v.extract    s39, v27, #10
    v.splat      v18, s39
    v.ld.w       v21, [s46, #0]
    s.addi       s39, s40, #704
    vf.mul       v22, v21, v19
    s.movz       s42, #11
    vf.mul       v19, v22, v14
    vf.add       v21, v13, v19
    s.addi       s46, s33, #10944
    v.st.w       [s30, #0], v21
    a.vread      v13, a0, s43
    v.extract    s30, v27, #11
    v.splat      v19, s30
    v.ld.w       v21, [s45, #0]
    s.addi       s30, s40, #768
    vf.mul       v22, v21, v18
    s.movz       s43, #12
    vf.mul       v18, v22, v14
    vf.add       v21, v13, v18
    s.addi       s45, s33, #11008
    v.st.w       [s41, #0], v21
    a.vread      v13, a0, s42
    v.extract    s41, v27, #12
    v.splat      v18, s41
    v.ld.w       v21, [s46, #0]
    s.addi       s41, s40, #832
    vf.mul       v22, v21, v19
    s.movz       s42, #13
    vf.mul       v19, v22, v14
    vf.add       v21, v13, v19
    s.addi       s46, s33, #11072
    v.st.w       [s39, #0], v21
    a.vread      v13, a0, s43
    v.extract    s39, v27, #13
    v.splat      v19, s39
    v.ld.w       v21, [s45, #0]
    s.addi       s39, s40, #896
    vf.mul       v22, v21, v18
    s.movz       s43, #14
    vf.mul       v18, v22, v14
    vf.add       v21, v13, v18
    s.addi       s45, s33, #11136
    v.st.w       [s30, #0], v21
    a.vread      v13, a0, s42
    v.extract    s30, v27, #14
    v.splat      v18, s30
    v.ld.w       v21, [s46, #0]
    s.addi       s30, s40, #960
    vf.mul       v22, v21, v19
    s.movz       s40, #15
    vf.mul       v19, v22, v14
    vf.add       v21, v13, v19
    s.addi       s42, s33, #11200
    v.st.w       [s41, #0], v21
    a.vread      v13, a0, s43
    v.extract    s41, v27, #15
    v.splat      v19, s41
    v.ld.w       v21, [s45, #0]
    vf.mul       v22, v21, v18
    s.addi       s41, s33, #19456
    vf.mul       v18, v22, v14
    s.movz       s43, #0
    vf.add       v21, v13, v18
    v.st.w       [s39, #0], v21
    a.vread      v13, a0, s40
    s.addi       s39, s33, #11264
    v.extract    s40, v27, #0
    v.splat      v18, s40
    v.ld.w       v21, [s42, #0]
    vf.mul       v22, v21, v19
    s.addi       s40, s41, #64
    vf.mul       v19, v22, v14
    s.movz       s42, #1
    vf.add       v14, v13, v19
    v.st.w       [s30, #0], v14
    fence.acq_rel.device
    a.vread      v13, a1, s43
    s.addi       s30, s33, #11328
    v.extract    s43, v27, #1
    v.splat      v14, s43
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s41, #128
    vf.mul       v21, v19, v18
    s.movz       s43, #2
    vf.mul       v18, v21, v32
    vf.add       v19, v13, v18
    s.addi       s45, s33, #11392
    v.st.w       [s41, #0], v19
    a.vread      v13, a1, s42
    v.extract    s42, v27, #2
    v.splat      v18, s42
    v.ld.w       v19, [s30, #0]
    s.addi       s30, s41, #192
    vf.mul       v21, v19, v14
    s.movz       s42, #3
    vf.mul       v14, v21, v32
    vf.add       v19, v13, v14
    s.addi       s46, s33, #11456
    v.st.w       [s40, #0], v19
    a.vread      v13, a1, s43
    v.extract    s40, v27, #3
    v.splat      v14, s40
    v.ld.w       v19, [s45, #0]
    s.addi       s40, s41, #256
    vf.mul       v21, v19, v18
    s.movz       s43, #4
    vf.mul       v18, v21, v32
    vf.add       v19, v13, v18
    s.addi       s45, s33, #11520
    v.st.w       [s39, #0], v19
    a.vread      v13, a1, s42
    v.extract    s39, v27, #4
    v.splat      v18, s39
    v.ld.w       v19, [s46, #0]
    s.addi       s39, s41, #320
    vf.mul       v21, v19, v14
    s.movz       s42, #5
    vf.mul       v14, v21, v32
    vf.add       v19, v13, v14
    s.addi       s46, s33, #11584
    v.st.w       [s30, #0], v19
    a.vread      v13, a1, s43
    v.extract    s30, v27, #5
    v.splat      v14, s30
    v.ld.w       v19, [s45, #0]
    s.addi       s30, s41, #384
    vf.mul       v21, v19, v18
    s.movz       s43, #6
    vf.mul       v18, v21, v32
    vf.add       v19, v13, v18
    s.addi       s45, s33, #11648
    v.st.w       [s40, #0], v19
    a.vread      v13, a1, s42
    v.extract    s40, v27, #6
    v.splat      v18, s40
    v.ld.w       v19, [s46, #0]
    s.addi       s40, s41, #448
    vf.mul       v21, v19, v14
    s.movz       s42, #7
    vf.mul       v14, v21, v32
    vf.add       v19, v13, v14
    s.addi       s46, s33, #11712
    v.st.w       [s39, #0], v19
    a.vread      v13, a1, s43
    v.extract    s39, v27, #7
    v.splat      v14, s39
    v.ld.w       v19, [s45, #0]
    s.addi       s39, s41, #512
    vf.mul       v21, v19, v18
    s.movz       s43, #8
    vf.mul       v18, v21, v32
    vf.add       v19, v13, v18
    s.addi       s45, s33, #11776
    v.st.w       [s30, #0], v19
    a.vread      v13, a1, s42
    v.extract    s30, v27, #8
    v.splat      v18, s30
    v.ld.w       v19, [s46, #0]
    s.addi       s30, s41, #576
    vf.mul       v21, v19, v14
    s.movz       s42, #9
    vf.mul       v14, v21, v32
    vf.add       v19, v13, v14
    s.addi       s46, s33, #11840
    v.st.w       [s40, #0], v19
    a.vread      v13, a1, s43
    v.extract    s40, v27, #9
    v.splat      v14, s40
    v.ld.w       v19, [s45, #0]
    s.addi       s40, s41, #640
    vf.mul       v21, v19, v18
    s.movz       s43, #10
    vf.mul       v18, v21, v32
    vf.add       v19, v13, v18
    s.addi       s45, s33, #11904
    v.st.w       [s39, #0], v19
    a.vread      v13, a1, s42
    v.extract    s39, v27, #10
    v.splat      v18, s39
    v.ld.w       v19, [s46, #0]
    s.addi       s39, s41, #704
    vf.mul       v21, v19, v14
    s.movz       s42, #11
    vf.mul       v14, v21, v32
    vf.add       v19, v13, v14
    s.addi       s46, s33, #11968
    v.st.w       [s30, #0], v19
    a.vread      v13, a1, s43
    v.extract    s30, v27, #11
    v.splat      v14, s30
    v.ld.w       v19, [s45, #0]
    s.addi       s30, s41, #768
    vf.mul       v21, v19, v18
    s.movz       s43, #12
    vf.mul       v18, v21, v32
    vf.add       v19, v13, v18
    s.addi       s45, s33, #12032
    v.st.w       [s40, #0], v19
    a.vread      v13, a1, s42
    v.extract    s40, v27, #12
    v.splat      v18, s40
    v.ld.w       v19, [s46, #0]
    s.addi       s40, s41, #832
    vf.mul       v21, v19, v14
    s.movz       s42, #13
    vf.mul       v14, v21, v32
    vf.add       v19, v13, v14
    s.addi       s46, s33, #12096
    v.st.w       [s39, #0], v19
    a.vread      v13, a1, s43
    v.extract    s39, v27, #13
    v.splat      v14, s39
    v.ld.w       v19, [s45, #0]
    s.addi       s39, s41, #896
    vf.mul       v21, v19, v18
    s.movz       s43, #14
    vf.mul       v18, v21, v32
    vf.add       v19, v13, v18
    s.addi       s45, s33, #12160
    v.st.w       [s30, #0], v19
    a.vread      v13, a1, s42
    v.extract    s30, v27, #14
    v.splat      v18, s30
    v.ld.w       v19, [s46, #0]
    s.addi       s30, s41, #960
    vf.mul       v21, v19, v14
    s.movz       s41, #15
    vf.mul       v14, v21, v32
    vf.add       v19, v13, v14
    s.addi       s42, s33, #12224
    v.st.w       [s40, #0], v19
    a.vread      v13, a1, s43
    v.extract    s40, v27, #15
    v.splat      v14, s40
    v.ld.w       v19, [s45, #0]
    vf.mul       v21, v19, v18
    s.addi       s40, s33, #20480
    vf.mul       v18, v21, v32
    s.movz       s43, #0
    vf.add       v19, v13, v18
    v.st.w       [s39, #0], v19
    a.vread      v13, a1, s41
    s.addi       s39, s33, #12288
    v.extract    s41, v27, #0
    v.splat      v18, s41
    v.ld.w       v19, [s42, #0]
    vf.mul       v21, v19, v14
    s.addi       s41, s40, #64
    vf.mul       v14, v21, v32
    s.movz       s42, #1
    vf.add       v19, v13, v14
    v.st.w       [s30, #0], v19
    fence.acq_rel.device
    a.vread      v13, a2, s43
    s.addi       s30, s33, #12352
    v.extract    s43, v27, #1
    v.splat      v14, s43
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s40, #128
    vf.mul       v21, v19, v18
    s.movz       s43, #2
    vf.mul       v18, v21, v17
    vf.add       v19, v13, v18
    s.addi       s45, s33, #12416
    v.st.w       [s40, #0], v19
    a.vread      v13, a2, s42
    v.extract    s42, v27, #2
    v.splat      v18, s42
    v.ld.w       v19, [s30, #0]
    s.addi       s30, s40, #192
    vf.mul       v21, v19, v14
    s.movz       s42, #3
    vf.mul       v14, v21, v17
    vf.add       v19, v13, v14
    s.addi       s46, s33, #12480
    v.st.w       [s41, #0], v19
    a.vread      v13, a2, s43
    v.extract    s41, v27, #3
    v.splat      v14, s41
    v.ld.w       v19, [s45, #0]
    s.addi       s41, s40, #256
    vf.mul       v21, v19, v18
    s.movz       s43, #4
    vf.mul       v18, v21, v17
    vf.add       v19, v13, v18
    s.addi       s45, s33, #12544
    v.st.w       [s39, #0], v19
    a.vread      v13, a2, s42
    v.extract    s39, v27, #4
    v.splat      v18, s39
    v.ld.w       v19, [s46, #0]
    s.addi       s39, s40, #320
    vf.mul       v21, v19, v14
    s.movz       s42, #5
    vf.mul       v14, v21, v17
    vf.add       v19, v13, v14
    s.addi       s46, s33, #12608
    v.st.w       [s30, #0], v19
    a.vread      v13, a2, s43
    v.extract    s30, v27, #5
    v.splat      v14, s30
    v.ld.w       v19, [s45, #0]
    s.addi       s30, s40, #384
    vf.mul       v21, v19, v18
    s.movz       s43, #6
    vf.mul       v18, v21, v17
    vf.add       v19, v13, v18
    s.addi       s45, s33, #12672
    v.st.w       [s41, #0], v19
    a.vread      v13, a2, s42
    v.extract    s41, v27, #6
    v.splat      v18, s41
    v.ld.w       v19, [s46, #0]
    s.addi       s41, s40, #448
    vf.mul       v21, v19, v14
    s.movz       s42, #7
    vf.mul       v14, v21, v17
    vf.add       v19, v13, v14
    s.addi       s46, s33, #12736
    v.st.w       [s39, #0], v19
    a.vread      v13, a2, s43
    v.extract    s39, v27, #7
    v.splat      v14, s39
    v.ld.w       v19, [s45, #0]
    s.addi       s39, s40, #512
    vf.mul       v21, v19, v18
    s.movz       s43, #8
    vf.mul       v18, v21, v17
    vf.add       v19, v13, v18
    s.addi       s45, s33, #12800
    v.st.w       [s30, #0], v19
    a.vread      v13, a2, s42
    v.extract    s30, v27, #8
    v.splat      v18, s30
    v.ld.w       v19, [s46, #0]
    s.addi       s30, s40, #576
    vf.mul       v21, v19, v14
    s.movz       s42, #9
    vf.mul       v14, v21, v17
    vf.add       v19, v13, v14
    s.addi       s46, s33, #12864
    v.st.w       [s41, #0], v19
    a.vread      v13, a2, s43
    v.extract    s41, v27, #9
    v.splat      v14, s41
    v.ld.w       v19, [s45, #0]
    s.addi       s41, s40, #640
    vf.mul       v21, v19, v18
    s.movz       s43, #10
    vf.mul       v18, v21, v17
    vf.add       v19, v13, v18
    s.addi       s45, s33, #12928
    v.st.w       [s39, #0], v19
    a.vread      v13, a2, s42
    v.extract    s39, v27, #10
    v.splat      v18, s39
    v.ld.w       v19, [s46, #0]
    s.addi       s39, s40, #704
    vf.mul       v21, v19, v14
    s.movz       s42, #11
    vf.mul       v14, v21, v17
    vf.add       v19, v13, v14
    s.addi       s46, s33, #12992
    v.st.w       [s30, #0], v19
    a.vread      v13, a2, s43
    v.extract    s30, v27, #11
    v.splat      v14, s30
    v.ld.w       v19, [s45, #0]
    s.addi       s30, s40, #768
    vf.mul       v21, v19, v18
    s.movz       s43, #12
    vf.mul       v18, v21, v17
    vf.add       v19, v13, v18
    s.addi       s45, s33, #13056
    v.st.w       [s41, #0], v19
    a.vread      v13, a2, s42
    v.extract    s41, v27, #12
    v.splat      v18, s41
    v.ld.w       v19, [s46, #0]
    s.addi       s41, s40, #832
    vf.mul       v21, v19, v14
    s.movz       s42, #13
    vf.mul       v14, v21, v17
    vf.add       v19, v13, v14
    s.addi       s46, s33, #13120
    v.st.w       [s39, #0], v19
    a.vread      v13, a2, s43
    v.extract    s39, v27, #13
    v.splat      v14, s39
    v.ld.w       v19, [s45, #0]
    s.addi       s39, s40, #896
    vf.mul       v21, v19, v18
    s.movz       s43, #14
    vf.mul       v18, v21, v17
    vf.add       v19, v13, v18
    s.addi       s45, s33, #13184
    v.st.w       [s30, #0], v19
    a.vread      v13, a2, s42
    v.extract    s30, v27, #14
    v.splat      v18, s30
    v.ld.w       v19, [s46, #0]
    s.addi       s30, s40, #960
    vf.mul       v21, v19, v14
    s.movz       s40, #15
    vf.mul       v14, v21, v17
    vf.add       v19, v13, v14
    s.addi       s42, s33, #13248
    v.st.w       [s41, #0], v19
    a.vread      v13, a2, s43
    v.extract    s41, v27, #15
    v.splat      v14, s41
    v.ld.w       v19, [s45, #0]
    vf.mul       v21, v19, v18
    s.addi       s41, s33, #21504
    vf.mul       v18, v21, v17
    s.movz       s43, #0
    vf.add       v19, v13, v18
    v.st.w       [s39, #0], v19
    a.vread      v13, a2, s40
    s.addi       s39, s33, #13312
    v.extract    s40, v27, #0
    v.splat      v18, s40
    v.ld.w       v19, [s42, #0]
    vf.mul       v21, v19, v14
    s.addi       s40, s41, #64
    vf.mul       v14, v21, v17
    s.movz       s42, #1
    vf.add       v17, v13, v14
    v.st.w       [s30, #0], v17
    fence.acq_rel.device
    a.vread      v13, a3, s43
    s.addi       s30, s33, #13376
    v.extract    s43, v27, #1
    v.splat      v14, s43
    v.ld.w       v17, [s39, #0]
    s.addi       s39, s41, #128
    vf.mul       v19, v17, v18
    s.movz       s43, #2
    vf.mul       v17, v19, v34
    vf.add       v18, v13, v17
    s.addi       s45, s33, #13440
    v.st.w       [s41, #0], v18
    a.vread      v13, a3, s42
    v.extract    s42, v27, #2
    v.splat      v17, s42
    v.ld.w       v18, [s30, #0]
    s.addi       s30, s41, #192
    vf.mul       v19, v18, v14
    s.movz       s42, #3
    vf.mul       v14, v19, v34
    vf.add       v18, v13, v14
    s.addi       s46, s33, #13504
    v.st.w       [s40, #0], v18
    a.vread      v13, a3, s43
    v.extract    s40, v27, #3
    v.splat      v14, s40
    v.ld.w       v18, [s45, #0]
    s.addi       s40, s41, #256
    vf.mul       v19, v18, v17
    s.movz       s43, #4
    vf.mul       v17, v19, v34
    vf.add       v18, v13, v17
    s.addi       s45, s33, #13568
    v.st.w       [s39, #0], v18
    a.vread      v13, a3, s42
    v.extract    s39, v27, #4
    v.splat      v17, s39
    v.ld.w       v18, [s46, #0]
    s.addi       s39, s41, #320
    vf.mul       v19, v18, v14
    s.movz       s42, #5
    vf.mul       v14, v19, v34
    vf.add       v18, v13, v14
    s.addi       s46, s33, #13632
    v.st.w       [s30, #0], v18
    a.vread      v13, a3, s43
    v.extract    s30, v27, #5
    v.splat      v14, s30
    v.ld.w       v18, [s45, #0]
    s.addi       s30, s41, #384
    vf.mul       v19, v18, v17
    s.movz       s43, #6
    vf.mul       v17, v19, v34
    vf.add       v18, v13, v17
    s.addi       s45, s33, #13696
    v.st.w       [s40, #0], v18
    a.vread      v13, a3, s42
    v.extract    s40, v27, #6
    v.splat      v17, s40
    v.ld.w       v18, [s46, #0]
    s.addi       s40, s41, #448
    vf.mul       v19, v18, v14
    s.movz       s42, #7
    vf.mul       v14, v19, v34
    vf.add       v18, v13, v14
    s.addi       s46, s33, #13760
    v.st.w       [s39, #0], v18
    a.vread      v13, a3, s43
    v.extract    s39, v27, #7
    v.splat      v14, s39
    v.ld.w       v18, [s45, #0]
    s.addi       s39, s41, #512
    vf.mul       v19, v18, v17
    s.movz       s43, #8
    vf.mul       v17, v19, v34
    vf.add       v18, v13, v17
    s.addi       s45, s33, #13824
    v.st.w       [s30, #0], v18
    a.vread      v13, a3, s42
    v.extract    s30, v27, #8
    v.splat      v17, s30
    v.ld.w       v18, [s46, #0]
    s.addi       s30, s41, #576
    vf.mul       v19, v18, v14
    s.movz       s42, #9
    vf.mul       v14, v19, v34
    vf.add       v18, v13, v14
    s.addi       s46, s33, #13888
    v.st.w       [s40, #0], v18
    a.vread      v13, a3, s43
    v.extract    s40, v27, #9
    v.splat      v14, s40
    v.ld.w       v18, [s45, #0]
    s.addi       s40, s41, #640
    vf.mul       v19, v18, v17
    s.movz       s43, #10
    vf.mul       v17, v19, v34
    vf.add       v18, v13, v17
    s.addi       s45, s33, #13952
    v.st.w       [s39, #0], v18
    a.vread      v13, a3, s42
    v.extract    s39, v27, #10
    v.splat      v17, s39
    v.ld.w       v18, [s46, #0]
    s.addi       s39, s41, #704
    vf.mul       v19, v18, v14
    s.movz       s42, #11
    vf.mul       v14, v19, v34
    vf.add       v18, v13, v14
    s.addi       s46, s33, #14016
    v.st.w       [s30, #0], v18
    a.vread      v13, a3, s43
    v.extract    s30, v27, #11
    v.splat      v14, s30
    v.ld.w       v18, [s45, #0]
    s.addi       s30, s41, #768
    vf.mul       v19, v18, v17
    s.movz       s43, #12
    vf.mul       v17, v19, v34
    vf.add       v18, v13, v17
    s.addi       s45, s33, #14080
    v.st.w       [s40, #0], v18
    a.vread      v13, a3, s42
    v.extract    s40, v27, #12
    v.splat      v17, s40
    v.ld.w       v18, [s46, #0]
    s.addi       s40, s41, #832
    vf.mul       v19, v18, v14
    s.movz       s42, #13
    vf.mul       v14, v19, v34
    vf.add       v18, v13, v14
    s.addi       s46, s33, #14144
    v.st.w       [s39, #0], v18
    a.vread      v13, a3, s43
    v.extract    s39, v27, #13
    v.splat      v14, s39
    v.ld.w       v18, [s45, #0]
    s.addi       s39, s41, #896
    vf.mul       v19, v18, v17
    s.movz       s43, #14
    vf.mul       v17, v19, v34
    vf.add       v18, v13, v17
    s.addi       s45, s33, #14208
    v.st.w       [s30, #0], v18
    a.vread      v13, a3, s42
    v.extract    s30, v27, #14
    v.splat      v17, s30
    v.ld.w       v18, [s46, #0]
    s.addi       s30, s41, #960
    vf.mul       v19, v18, v14
    s.movz       s41, #15
    vf.mul       v14, v19, v34
    vf.add       v18, v13, v14
    s.addi       s42, s33, #14272
    v.st.w       [s40, #0], v18
    a.vread      v13, a3, s43
    v.extract    s40, v27, #15
    v.splat      v14, s40
    v.ld.w       v18, [s45, #0]
    vf.mul       v19, v18, v17
    s.addi       s40, s33, #22528
    vf.mul       v17, v19, v34
    s.movz       s43, #0
    vf.add       v18, v13, v17
    v.st.w       [s39, #0], v18
    a.vread      v13, a3, s41
    s.addi       s39, s33, #14336
    v.extract    s41, v27, #0
    v.splat      v17, s41
    v.ld.w       v18, [s42, #0]
    vf.mul       v19, v18, v14
    s.addi       s41, s40, #64
    vf.mul       v14, v19, v34
    s.movz       s42, #1
    vf.add       v18, v13, v14
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    a.vread      v13, a4, s43
    s.addi       s30, s33, #14400
    v.extract    s43, v27, #1
    v.splat      v14, s43
    v.ld.w       v18, [s39, #0]
    s.addi       s39, s40, #128
    vf.mul       v19, v18, v17
    s.movz       s43, #2
    vf.mul       v17, v19, v36
    vf.add       v18, v13, v17
    s.addi       s45, s33, #14464
    v.st.w       [s40, #0], v18
    a.vread      v13, a4, s42
    v.extract    s42, v27, #2
    v.splat      v17, s42
    v.ld.w       v18, [s30, #0]
    s.addi       s30, s40, #192
    vf.mul       v19, v18, v14
    s.movz       s42, #3
    vf.mul       v14, v19, v36
    vf.add       v18, v13, v14
    s.addi       s46, s33, #14528
    v.st.w       [s41, #0], v18
    a.vread      v13, a4, s43
    v.extract    s41, v27, #3
    v.splat      v14, s41
    v.ld.w       v18, [s45, #0]
    s.addi       s41, s40, #256
    vf.mul       v19, v18, v17
    s.movz       s43, #4
    vf.mul       v17, v19, v36
    vf.add       v18, v13, v17
    s.addi       s45, s33, #14592
    v.st.w       [s39, #0], v18
    a.vread      v13, a4, s42
    v.extract    s39, v27, #4
    v.splat      v17, s39
    v.ld.w       v18, [s46, #0]
    s.addi       s39, s40, #320
    vf.mul       v19, v18, v14
    s.movz       s42, #5
    vf.mul       v14, v19, v36
    vf.add       v18, v13, v14
    s.addi       s46, s33, #14656
    v.st.w       [s30, #0], v18
    a.vread      v13, a4, s43
    v.extract    s30, v27, #5
    v.splat      v14, s30
    v.ld.w       v18, [s45, #0]
    s.addi       s30, s40, #384
    vf.mul       v19, v18, v17
    s.movz       s43, #6
    vf.mul       v17, v19, v36
    vf.add       v18, v13, v17
    s.addi       s45, s33, #14720
    v.st.w       [s41, #0], v18
    a.vread      v13, a4, s42
    v.extract    s41, v27, #6
    v.splat      v17, s41
    v.ld.w       v18, [s46, #0]
    s.addi       s41, s40, #448
    vf.mul       v19, v18, v14
    s.movz       s42, #7
    vf.mul       v14, v19, v36
    vf.add       v18, v13, v14
    s.addi       s46, s33, #14784
    v.st.w       [s39, #0], v18
    a.vread      v13, a4, s43
    v.extract    s39, v27, #7
    v.splat      v14, s39
    v.ld.w       v18, [s45, #0]
    s.addi       s39, s40, #512
    vf.mul       v19, v18, v17
    s.movz       s43, #8
    vf.mul       v17, v19, v36
    vf.add       v18, v13, v17
    s.addi       s45, s33, #14848
    v.st.w       [s30, #0], v18
    a.vread      v13, a4, s42
    v.extract    s30, v27, #8
    v.splat      v17, s30
    v.ld.w       v18, [s46, #0]
    s.addi       s30, s40, #576
    vf.mul       v19, v18, v14
    s.movz       s42, #9
    vf.mul       v14, v19, v36
    vf.add       v18, v13, v14
    s.addi       s46, s33, #14912
    v.st.w       [s41, #0], v18
    a.vread      v13, a4, s43
    v.extract    s41, v27, #9
    v.splat      v14, s41
    v.ld.w       v18, [s45, #0]
    s.addi       s41, s40, #640
    vf.mul       v19, v18, v17
    s.movz       s43, #10
    vf.mul       v17, v19, v36
    vf.add       v18, v13, v17
    s.addi       s45, s33, #14976
    v.st.w       [s39, #0], v18
    a.vread      v13, a4, s42
    v.extract    s39, v27, #10
    v.splat      v17, s39
    v.ld.w       v18, [s46, #0]
    s.addi       s39, s40, #704
    vf.mul       v19, v18, v14
    s.movz       s42, #11
    vf.mul       v14, v19, v36
    vf.add       v18, v13, v14
    s.addi       s46, s33, #15040
    v.st.w       [s30, #0], v18
    a.vread      v13, a4, s43
    v.extract    s30, v27, #11
    v.splat      v14, s30
    v.ld.w       v18, [s45, #0]
    s.addi       s30, s40, #768
    vf.mul       v19, v18, v17
    s.movz       s43, #12
    vf.mul       v17, v19, v36
    vf.add       v18, v13, v17
    s.addi       s45, s33, #15104
    v.st.w       [s41, #0], v18
    a.vread      v13, a4, s42
    v.extract    s41, v27, #12
    v.splat      v17, s41
    v.ld.w       v18, [s46, #0]
    s.addi       s41, s40, #832
    vf.mul       v19, v18, v14
    s.movz       s42, #13
    vf.mul       v14, v19, v36
    vf.add       v18, v13, v14
    s.addi       s46, s33, #15168
    v.st.w       [s39, #0], v18
    a.vread      v13, a4, s43
    v.extract    s39, v27, #13
    v.splat      v14, s39
    v.ld.w       v18, [s45, #0]
    s.addi       s39, s40, #896
    vf.mul       v19, v18, v17
    s.movz       s43, #14
    vf.mul       v17, v19, v36
    vf.add       v18, v13, v17
    s.addi       s45, s33, #15232
    v.st.w       [s30, #0], v18
    a.vread      v13, a4, s42
    v.extract    s30, v27, #14
    v.splat      v17, s30
    v.ld.w       v18, [s46, #0]
    s.addi       s30, s40, #960
    vf.mul       v19, v18, v14
    s.movz       s40, #15
    vf.mul       v14, v19, v36
    vf.add       v18, v13, v14
    s.addi       s42, s33, #15296
    v.st.w       [s41, #0], v18
    a.vread      v13, a4, s43
    v.extract    s41, v27, #15
    v.splat      v14, s41
    v.ld.w       v18, [s45, #0]
    vf.mul       v19, v18, v17
    s.addi       s41, s33, #23552
    vf.mul       v17, v19, v36
    s.movz       s43, #0
    vf.add       v18, v13, v17
    v.st.w       [s39, #0], v18
    a.vread      v13, a4, s40
    s.addi       s39, s33, #15360
    v.extract    s40, v27, #0
    v.splat      v17, s40
    v.ld.w       v18, [s42, #0]
    vf.mul       v19, v18, v14
    s.addi       s40, s41, #64
    vf.mul       v14, v19, v36
    s.movz       s42, #1
    vf.add       v18, v13, v14
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    a.vread      v13, a5, s43
    s.addi       s30, s33, #15424
    v.extract    s43, v27, #1
    v.splat      v14, s43
    v.ld.w       v18, [s39, #0]
    s.addi       s39, s41, #128
    vf.mul       v19, v18, v17
    s.movz       s43, #2
    vf.mul       v17, v19, v29
    vf.add       v18, v13, v17
    s.addi       s45, s33, #15488
    v.st.w       [s41, #0], v18
    a.vread      v13, a5, s42
    v.extract    s42, v27, #2
    v.splat      v17, s42
    v.ld.w       v18, [s30, #0]
    s.addi       s30, s41, #192
    vf.mul       v19, v18, v14
    s.movz       s42, #3
    vf.mul       v14, v19, v29
    vf.add       v18, v13, v14
    s.addi       s46, s33, #15552
    v.st.w       [s40, #0], v18
    a.vread      v13, a5, s43
    v.extract    s40, v27, #3
    v.splat      v14, s40
    v.ld.w       v18, [s45, #0]
    s.addi       s40, s41, #256
    vf.mul       v19, v18, v17
    s.movz       s43, #4
    vf.mul       v17, v19, v29
    vf.add       v18, v13, v17
    s.addi       s45, s33, #15616
    v.st.w       [s39, #0], v18
    a.vread      v13, a5, s42
    v.extract    s39, v27, #4
    v.splat      v17, s39
    v.ld.w       v18, [s46, #0]
    s.addi       s39, s41, #320
    vf.mul       v19, v18, v14
    s.movz       s42, #5
    vf.mul       v14, v19, v29
    vf.add       v18, v13, v14
    s.addi       s46, s33, #15680
    v.st.w       [s30, #0], v18
    a.vread      v13, a5, s43
    v.extract    s30, v27, #5
    v.splat      v14, s30
    v.ld.w       v18, [s45, #0]
    s.addi       s30, s41, #384
    vf.mul       v19, v18, v17
    s.movz       s43, #6
    vf.mul       v17, v19, v29
    vf.add       v18, v13, v17
    s.addi       s45, s33, #15744
    v.st.w       [s40, #0], v18
    a.vread      v13, a5, s42
    v.extract    s40, v27, #6
    v.splat      v17, s40
    v.ld.w       v18, [s46, #0]
    s.addi       s40, s41, #448
    vf.mul       v19, v18, v14
    s.movz       s42, #7
    vf.mul       v14, v19, v29
    vf.add       v18, v13, v14
    s.addi       s46, s33, #15808
    v.st.w       [s39, #0], v18
    a.vread      v13, a5, s43
    v.extract    s39, v27, #7
    v.splat      v14, s39
    v.ld.w       v18, [s45, #0]
    s.addi       s39, s41, #512
    vf.mul       v19, v18, v17
    s.movz       s43, #8
    vf.mul       v17, v19, v29
    vf.add       v18, v13, v17
    s.addi       s45, s33, #15872
    v.st.w       [s30, #0], v18
    a.vread      v13, a5, s42
    v.extract    s30, v27, #8
    v.splat      v17, s30
    v.ld.w       v18, [s46, #0]
    s.addi       s30, s41, #576
    vf.mul       v19, v18, v14
    s.movz       s42, #9
    vf.mul       v14, v19, v29
    vf.add       v18, v13, v14
    s.addi       s46, s33, #15936
    v.st.w       [s40, #0], v18
    a.vread      v13, a5, s43
    v.extract    s40, v27, #9
    v.splat      v14, s40
    v.ld.w       v18, [s45, #0]
    s.addi       s40, s41, #640
    vf.mul       v19, v18, v17
    s.movz       s43, #10
    vf.mul       v17, v19, v29
    vf.add       v18, v13, v17
    s.addi       s45, s33, #16000
    v.st.w       [s39, #0], v18
    a.vread      v13, a5, s42
    v.extract    s39, v27, #10
    v.splat      v17, s39
    v.ld.w       v18, [s46, #0]
    s.addi       s39, s41, #704
    vf.mul       v19, v18, v14
    s.movz       s42, #11
    vf.mul       v14, v19, v29
    vf.add       v18, v13, v14
    s.addi       s46, s33, #16064
    v.st.w       [s30, #0], v18
    a.vread      v13, a5, s43
    v.extract    s30, v27, #11
    v.splat      v14, s30
    v.ld.w       v18, [s45, #0]
    s.addi       s30, s41, #768
    vf.mul       v19, v18, v17
    s.movz       s43, #12
    vf.mul       v17, v19, v29
    vf.add       v18, v13, v17
    s.addi       s45, s33, #16128
    v.st.w       [s40, #0], v18
    a.vread      v13, a5, s42
    v.extract    s40, v27, #12
    v.splat      v17, s40
    v.ld.w       v18, [s46, #0]
    s.addi       s40, s41, #832
    vf.mul       v19, v18, v14
    s.movz       s42, #13
    vf.mul       v14, v19, v29
    vf.add       v18, v13, v14
    s.addi       s46, s33, #16192
    v.st.w       [s39, #0], v18
    a.vread      v13, a5, s43
    v.extract    s39, v27, #13
    v.splat      v14, s39
    v.ld.w       v18, [s45, #0]
    s.addi       s39, s41, #896
    vf.mul       v19, v18, v17
    s.movz       s43, #14
    vf.mul       v17, v19, v29
    vf.add       v18, v13, v17
    s.addi       s45, s33, #16256
    v.st.w       [s30, #0], v18
    a.vread      v13, a5, s42
    v.extract    s30, v27, #14
    v.splat      v17, s30
    v.ld.w       v18, [s46, #0]
    s.addi       s30, s41, #960
    vf.mul       v19, v18, v14
    s.movz       s41, #15
    vf.mul       v14, v19, v29
    vf.add       v18, v13, v14
    s.addi       s42, s33, #16320
    v.st.w       [s40, #0], v18
    a.vread      v13, a5, s43
    v.extract    s40, v27, #15
    v.splat      v14, s40
    v.ld.w       v18, [s45, #0]
    vf.mul       v19, v18, v17
    s.addi       s40, s33, #24576
    vf.mul       v17, v19, v29
    s.movz       s43, #0
    vf.add       v18, v13, v17
    v.st.w       [s39, #0], v18
    a.vread      v13, a5, s41
    s.addi       s39, s33, #16384
    v.extract    s41, v27, #0
    v.splat      v17, s41
    v.ld.w       v18, [s42, #0]
    vf.mul       v19, v18, v14
    s.addi       s41, s40, #64
    vf.mul       v14, v19, v29
    s.movz       s42, #1
    vf.add       v18, v13, v14
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    a.vread      v13, a6, s43
    s.addi       s30, s33, #16448
    v.extract    s43, v27, #1
    v.splat      v14, s43
    v.ld.w       v18, [s39, #0]
    s.addi       s39, s40, #128
    vf.mul       v19, v18, v17
    s.movz       s43, #2
    vf.mul       v17, v19, v38
    vf.add       v18, v13, v17
    s.addi       s45, s33, #16512
    v.st.w       [s40, #0], v18
    a.vread      v13, a6, s42
    v.extract    s42, v27, #2
    v.splat      v17, s42
    v.ld.w       v18, [s30, #0]
    s.addi       s30, s40, #192
    vf.mul       v19, v18, v14
    s.movz       s42, #3
    vf.mul       v14, v19, v38
    vf.add       v18, v13, v14
    s.addi       s46, s33, #16576
    v.st.w       [s41, #0], v18
    a.vread      v13, a6, s43
    v.extract    s41, v27, #3
    v.splat      v14, s41
    v.ld.w       v18, [s45, #0]
    s.addi       s41, s40, #256
    vf.mul       v19, v18, v17
    s.movz       s43, #4
    vf.mul       v17, v19, v38
    vf.add       v18, v13, v17
    s.addi       s45, s33, #16640
    v.st.w       [s39, #0], v18
    a.vread      v13, a6, s42
    v.extract    s39, v27, #4
    v.splat      v17, s39
    v.ld.w       v18, [s46, #0]
    s.addi       s39, s40, #320
    vf.mul       v19, v18, v14
    s.movz       s42, #5
    vf.mul       v14, v19, v38
    vf.add       v18, v13, v14
    s.addi       s46, s33, #16704
    v.st.w       [s30, #0], v18
    a.vread      v13, a6, s43
    v.extract    s30, v27, #5
    v.splat      v14, s30
    v.ld.w       v18, [s45, #0]
    s.addi       s30, s40, #384
    vf.mul       v19, v18, v17
    s.movz       s43, #6
    vf.mul       v17, v19, v38
    vf.add       v18, v13, v17
    s.addi       s45, s33, #16768
    v.st.w       [s41, #0], v18
    a.vread      v13, a6, s42
    v.extract    s41, v27, #6
    v.splat      v17, s41
    v.ld.w       v18, [s46, #0]
    s.addi       s41, s40, #448
    vf.mul       v19, v18, v14
    s.movz       s42, #7
    vf.mul       v14, v19, v38
    vf.add       v18, v13, v14
    s.addi       s46, s33, #16832
    v.st.w       [s39, #0], v18
    a.vread      v13, a6, s43
    v.extract    s39, v27, #7
    v.splat      v14, s39
    v.ld.w       v18, [s45, #0]
    s.addi       s39, s40, #512
    vf.mul       v19, v18, v17
    s.movz       s43, #8
    vf.mul       v17, v19, v38
    vf.add       v18, v13, v17
    s.addi       s45, s33, #16896
    v.st.w       [s30, #0], v18
    a.vread      v13, a6, s42
    v.extract    s30, v27, #8
    v.splat      v17, s30
    v.ld.w       v18, [s46, #0]
    s.addi       s30, s40, #576
    vf.mul       v19, v18, v14
    s.movz       s42, #9
    vf.mul       v14, v19, v38
    vf.add       v18, v13, v14
    s.addi       s46, s33, #16960
    v.st.w       [s41, #0], v18
    a.vread      v13, a6, s43
    v.extract    s41, v27, #9
    v.splat      v14, s41
    v.ld.w       v18, [s45, #0]
    s.addi       s41, s40, #640
    vf.mul       v19, v18, v17
    s.movz       s43, #10
    vf.mul       v17, v19, v38
    vf.add       v18, v13, v17
    s.addi       s45, s33, #17024
    v.st.w       [s39, #0], v18
    a.vread      v13, a6, s42
    v.extract    s39, v27, #10
    v.splat      v17, s39
    v.ld.w       v18, [s46, #0]
    s.addi       s39, s40, #704
    vf.mul       v19, v18, v14
    s.movz       s42, #11
    vf.mul       v14, v19, v38
    vf.add       v18, v13, v14
    s.addi       s46, s33, #17088
    v.st.w       [s30, #0], v18
    a.vread      v13, a6, s43
    v.extract    s30, v27, #11
    v.splat      v14, s30
    v.ld.w       v18, [s45, #0]
    s.addi       s30, s40, #768
    vf.mul       v19, v18, v17
    s.movz       s43, #12
    vf.mul       v17, v19, v38
    vf.add       v18, v13, v17
    s.addi       s45, s33, #17152
    v.st.w       [s41, #0], v18
    a.vread      v13, a6, s42
    v.extract    s41, v27, #12
    v.splat      v17, s41
    v.ld.w       v18, [s46, #0]
    s.addi       s41, s40, #832
    vf.mul       v19, v18, v14
    s.movz       s42, #13
    vf.mul       v14, v19, v38
    vf.add       v18, v13, v14
    s.addi       s46, s33, #17216
    v.st.w       [s39, #0], v18
    a.vread      v13, a6, s43
    v.extract    s39, v27, #13
    v.splat      v14, s39
    v.ld.w       v18, [s45, #0]
    s.addi       s39, s40, #896
    vf.mul       v19, v18, v17
    s.movz       s43, #14
    vf.mul       v17, v19, v38
    vf.add       v18, v13, v17
    s.addi       s45, s33, #17280
    v.st.w       [s30, #0], v18
    a.vread      v13, a6, s42
    v.extract    s30, v27, #14
    v.splat      v17, s30
    v.ld.w       v18, [s46, #0]
    s.addi       s30, s40, #960
    vf.mul       v19, v18, v14
    s.movz       s40, #15
    vf.mul       v14, v19, v38
    vf.add       v18, v13, v14
    s.addi       s42, s33, #17344
    v.st.w       [s41, #0], v18
    a.vread      v13, a6, s43
    v.extract    s41, v27, #15
    v.splat      v14, s41
    v.ld.w       v18, [s45, #0]
    vf.mul       v19, v18, v17
    s.addi       s41, s33, #25600
    vf.mul       v17, v19, v38
    s.movz       s43, #0
    vf.add       v18, v13, v17
    v.st.w       [s39, #0], v18
    a.vread      v13, a6, s40
    s.addi       s39, s33, #17408
    v.extract    s40, v27, #0
    v.splat      v17, s40
    v.ld.w       v18, [s42, #0]
    vf.mul       v19, v18, v14
    s.addi       s40, s41, #64
    vf.mul       v14, v19, v38
    s.movz       s42, #1
    vf.add       v18, v13, v14
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    a.vread      v13, a7, s43
    s.addi       s30, s33, #17472
    v.extract    s43, v27, #1
    v.splat      v14, s43
    v.ld.w       v18, [s39, #0]
    s.addi       s39, s41, #128
    vf.mul       v19, v18, v17
    s.movz       s43, #2
    vf.mul       v17, v19, v35
    vf.add       v18, v13, v17
    s.addi       s45, s33, #17536
    v.st.w       [s41, #0], v18
    a.vread      v13, a7, s42
    v.extract    s42, v27, #2
    v.splat      v17, s42
    v.ld.w       v18, [s30, #0]
    s.addi       s30, s41, #192
    vf.mul       v19, v18, v14
    s.movz       s42, #3
    vf.mul       v14, v19, v35
    vf.add       v18, v13, v14
    s.addi       s46, s33, #17600
    v.st.w       [s40, #0], v18
    a.vread      v13, a7, s43
    v.extract    s40, v27, #3
    v.splat      v14, s40
    v.ld.w       v18, [s45, #0]
    s.addi       s40, s41, #256
    vf.mul       v19, v18, v17
    s.movz       s43, #4
    vf.mul       v17, v19, v35
    vf.add       v18, v13, v17
    s.addi       s45, s33, #17664
    v.st.w       [s39, #0], v18
    a.vread      v13, a7, s42
    v.extract    s39, v27, #4
    v.splat      v17, s39
    v.ld.w       v18, [s46, #0]
    s.addi       s39, s41, #320
    vf.mul       v19, v18, v14
    s.movz       s42, #5
    vf.mul       v14, v19, v35
    vf.add       v18, v13, v14
    s.addi       s46, s33, #17728
    v.st.w       [s30, #0], v18
    a.vread      v13, a7, s43
    v.extract    s30, v27, #5
    v.splat      v14, s30
    v.ld.w       v18, [s45, #0]
    s.addi       s30, s41, #384
    vf.mul       v19, v18, v17
    s.movz       s43, #6
    vf.mul       v17, v19, v35
    vf.add       v18, v13, v17
    s.addi       s45, s33, #17792
    v.st.w       [s40, #0], v18
    a.vread      v13, a7, s42
    v.extract    s40, v27, #6
    v.splat      v17, s40
    v.ld.w       v18, [s46, #0]
    s.addi       s40, s41, #448
    vf.mul       v19, v18, v14
    s.movz       s42, #7
    vf.mul       v14, v19, v35
    vf.add       v18, v13, v14
    s.addi       s46, s33, #17856
    v.st.w       [s39, #0], v18
    a.vread      v13, a7, s43
    v.extract    s39, v27, #7
    v.splat      v14, s39
    v.ld.w       v18, [s45, #0]
    s.addi       s39, s41, #512
    vf.mul       v19, v18, v17
    s.movz       s43, #8
    vf.mul       v17, v19, v35
    vf.add       v18, v13, v17
    s.addi       s45, s33, #17920
    v.st.w       [s30, #0], v18
    a.vread      v13, a7, s42
    v.extract    s30, v27, #8
    v.splat      v17, s30
    v.ld.w       v18, [s46, #0]
    s.addi       s30, s41, #576
    vf.mul       v19, v18, v14
    s.movz       s42, #9
    vf.mul       v14, v19, v35
    vf.add       v18, v13, v14
    s.addi       s46, s33, #17984
    v.st.w       [s40, #0], v18
    a.vread      v13, a7, s43
    v.extract    s40, v27, #9
    v.splat      v14, s40
    v.ld.w       v18, [s45, #0]
    s.addi       s40, s41, #640
    vf.mul       v19, v18, v17
    s.movz       s43, #10
    vf.mul       v17, v19, v35
    vf.add       v18, v13, v17
    s.addi       s45, s33, #18048
    v.st.w       [s39, #0], v18
    a.vread      v13, a7, s42
    v.extract    s39, v27, #10
    v.splat      v17, s39
    v.ld.w       v18, [s46, #0]
    s.addi       s39, s41, #704
    vf.mul       v19, v18, v14
    s.movz       s42, #11
    vf.mul       v14, v19, v35
    vf.add       v18, v13, v14
    s.addi       s46, s33, #18112
    v.st.w       [s30, #0], v18
    a.vread      v13, a7, s43
    v.extract    s30, v27, #11
    v.splat      v14, s30
    v.ld.w       v18, [s45, #0]
    s.addi       s30, s41, #768
    vf.mul       v19, v18, v17
    s.movz       s43, #12
    vf.mul       v17, v19, v35
    vf.add       v18, v13, v17
    s.addi       s45, s33, #18176
    v.st.w       [s40, #0], v18
    a.vread      v13, a7, s42
    v.extract    s40, v27, #12
    v.splat      v17, s40
    v.ld.w       v18, [s46, #0]
    s.addi       s40, s41, #832
    vf.mul       v19, v18, v14
    s.movz       s42, #13
    vf.mul       v14, v19, v35
    vf.add       v18, v13, v14
    s.addi       s46, s33, #18240
    v.st.w       [s39, #0], v18
    a.vread      v13, a7, s43
    v.extract    s39, v27, #13
    v.splat      v14, s39
    v.ld.w       v18, [s45, #0]
    s.addi       s39, s41, #896
    vf.mul       v19, v18, v17
    s.movz       s43, #14
    vf.mul       v17, v19, v35
    vf.add       v18, v13, v17
    s.addi       s45, s33, #18304
    v.st.w       [s30, #0], v18
    a.vread      v13, a7, s42
    v.extract    s30, v27, #14
    v.splat      v17, s30
    v.ld.w       v18, [s46, #0]
    s.addi       s30, s41, #960
    vf.mul       v19, v18, v14
    s.movz       s41, #15
    vf.mul       v14, v19, v35
    vf.add       v18, v13, v14
    s.addi       s42, s33, #18368
    v.st.w       [s40, #0], v18
    a.vread      v13, a7, s43
    v.extract    s40, v27, #15
    v.splat      v14, s40
    v.ld.w       v18, [s45, #0]
    vf.mul       v19, v18, v17
    s.addi       s40, s29, #128
    vf.mul       v17, v19, v35
    s.addi       s43, s40, #0
    vf.add       v18, v13, v17
    s.addi       s40, s1, #128
    v.st.w       [s39, #0], v18
    a.vread      v13, a7, s41
    s.addi       s39, s25, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    s.addi       s41, s40, #0
    s.addi       s40, s39, #0
    s.addi       s39, s25, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    s.addi       s39, s25, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    v.ld.w       v17, [s42, #0]
    s.addi       s39, s25, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    s.addi       s39, s25, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    s.addi       s39, s25, #4                    // &ptr_carry_25[1] (a constant offset, x4)
    vf.mul       v18, v17, v14
    s.addi       s39, s25, #4                    // &ptr_carry_26[1] (a constant offset, x4)
    vf.mul       v14, v18, v35
    s.addi       s39, s25, #4                    // &ptr_carry_27[1] (a constant offset, x4)
    vf.add       v17, v13, v14
    v.st.w       [s30, #0], v17
    fence.acq_rel.device
    s.addi       s30, s33, #18432
    s.mov        s29, s43
    s.mov        s1, s41
    s.mov        s25, s40
    s.movz       s39, #0
    s.addi       s40, s33, #18496
    s.movz       s41, #1
    s.addi       s42, s33, #18560
    v.ld.w       v13, [s30, #0]
    s.movz       s30, #2
    s.addi       s43, s33, #18624
    s.movz       s45, #3
    s.addi       s46, s33, #18688
    s.movz       s47, #4
    a.vwrite     a0, s39, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s39, s33, #18752
    s.movz       s40, #5
    a.vwrite     a0, s41, v13
    v.ld.w       v13, [s42, #0]
    s.addi       s41, s33, #18816
    s.movz       s42, #6
    a.vwrite     a0, s30, v13
    v.ld.w       v13, [s43, #0]
    s.addi       s30, s33, #18880
    s.movz       s43, #7
    a.vwrite     a0, s45, v13
    v.ld.w       v13, [s46, #0]
    s.addi       s45, s33, #18944
    s.movz       s46, #8
    a.vwrite     a0, s47, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #19008
    s.movz       s47, #9
    a.vwrite     a0, s40, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s40, s33, #19072
    s.movz       s41, #10
    a.vwrite     a0, s42, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #19136
    s.movz       s42, #11
    a.vwrite     a0, s43, v13
    v.ld.w       v13, [s45, #0]
    s.addi       s43, s33, #19200
    s.movz       s45, #12
    a.vwrite     a0, s46, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #19264
    s.movz       s46, #13
    a.vwrite     a0, s47, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #19328
    s.movz       s47, #14
    a.vwrite     a0, s41, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #19392
    s.movz       s41, #15
    a.vwrite     a0, s42, v13
    v.ld.w       v13, [s43, #0]
    s.addi       s42, s33, #19456
    s.movz       s43, #0
    a.vwrite     a0, s45, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #19520
    s.movz       s45, #1
    a.vwrite     a0, s46, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #19584
    s.movz       s46, #2
    a.vwrite     a0, s47, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #19648
    s.movz       s47, #3
    a.vwrite     a0, s41, v13
    v.ld.w       v13, [s42, #0]
    s.addi       s41, s33, #19712
    s.movz       s42, #4
    a.vwrite     a1, s43, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #19776
    s.movz       s43, #5
    a.vwrite     a1, s45, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #19840
    s.movz       s45, #6
    a.vwrite     a1, s46, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #19904
    s.movz       s46, #7
    a.vwrite     a1, s47, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #19968
    s.movz       s47, #8
    a.vwrite     a1, s42, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #20032
    s.movz       s42, #9
    a.vwrite     a1, s43, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #20096
    s.movz       s43, #10
    a.vwrite     a1, s45, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #20160
    s.movz       s45, #11
    a.vwrite     a1, s46, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #20224
    s.movz       s46, #12
    a.vwrite     a1, s47, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #20288
    s.movz       s47, #13
    a.vwrite     a1, s42, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #20352
    s.movz       s42, #14
    a.vwrite     a1, s43, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #20416
    s.movz       s43, #15
    a.vwrite     a1, s45, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #20480
    s.movz       s45, #0
    a.vwrite     a1, s46, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #20544
    s.movz       s46, #1
    a.vwrite     a1, s47, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #20608
    s.movz       s47, #2
    a.vwrite     a1, s42, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #20672
    s.movz       s42, #3
    a.vwrite     a1, s43, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #20736
    s.movz       s43, #4
    a.vwrite     a2, s45, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #20800
    s.movz       s45, #5
    a.vwrite     a2, s46, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #20864
    s.movz       s46, #6
    a.vwrite     a2, s47, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #20928
    s.movz       s47, #7
    a.vwrite     a2, s42, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #20992
    s.movz       s42, #8
    a.vwrite     a2, s43, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #21056
    s.movz       s43, #9
    a.vwrite     a2, s45, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #21120
    s.movz       s45, #10
    a.vwrite     a2, s46, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #21184
    s.movz       s46, #11
    a.vwrite     a2, s47, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #21248
    s.movz       s47, #12
    a.vwrite     a2, s42, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #21312
    s.movz       s42, #13
    a.vwrite     a2, s43, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #21376
    s.movz       s43, #14
    a.vwrite     a2, s45, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #21440
    s.movz       s45, #15
    a.vwrite     a2, s46, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #21504
    s.movz       s46, #0
    a.vwrite     a2, s47, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #21568
    s.movz       s47, #1
    a.vwrite     a2, s42, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #21632
    s.movz       s42, #2
    a.vwrite     a2, s43, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #21696
    s.movz       s43, #3
    a.vwrite     a2, s45, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #21760
    s.movz       s45, #4
    a.vwrite     a3, s46, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #21824
    s.movz       s46, #5
    a.vwrite     a3, s47, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #21888
    s.movz       s47, #6
    a.vwrite     a3, s42, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #21952
    s.movz       s42, #7
    a.vwrite     a3, s43, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #22016
    s.movz       s43, #8
    a.vwrite     a3, s45, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #22080
    s.movz       s45, #9
    a.vwrite     a3, s46, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #22144
    s.movz       s46, #10
    a.vwrite     a3, s47, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #22208
    s.movz       s47, #11
    a.vwrite     a3, s42, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #22272
    s.movz       s42, #12
    a.vwrite     a3, s43, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #22336
    s.movz       s43, #13
    a.vwrite     a3, s45, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #22400
    s.movz       s45, #14
    a.vwrite     a3, s46, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #22464
    s.movz       s46, #15
    a.vwrite     a3, s47, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #22528
    s.movz       s47, #0
    a.vwrite     a3, s42, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #22592
    s.movz       s42, #1
    a.vwrite     a3, s43, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #22656
    s.movz       s43, #2
    a.vwrite     a3, s45, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #22720
    s.movz       s45, #3
    a.vwrite     a3, s46, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #22784
    s.movz       s46, #4
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #22848
    s.movz       s47, #5
    a.vwrite     a4, s42, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #22912
    s.movz       s42, #6
    a.vwrite     a4, s43, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #22976
    s.movz       s43, #7
    a.vwrite     a4, s45, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #23040
    s.movz       s45, #8
    a.vwrite     a4, s46, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #23104
    s.movz       s46, #9
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #23168
    s.movz       s47, #10
    a.vwrite     a4, s42, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #23232
    s.movz       s42, #11
    a.vwrite     a4, s43, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #23296
    s.movz       s43, #12
    a.vwrite     a4, s45, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #23360
    s.movz       s45, #13
    a.vwrite     a4, s46, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #23424
    s.movz       s46, #14
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #23488
    s.movz       s47, #15
    a.vwrite     a4, s42, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #23552
    s.movz       s42, #0
    a.vwrite     a4, s43, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #23616
    s.movz       s43, #1
    a.vwrite     a4, s45, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #23680
    s.movz       s45, #2
    a.vwrite     a4, s46, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #23744
    s.movz       s46, #3
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #23808
    s.movz       s47, #4
    a.vwrite     a5, s42, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #23872
    s.movz       s42, #5
    a.vwrite     a5, s43, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #23936
    s.movz       s43, #6
    a.vwrite     a5, s45, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #24000
    s.movz       s45, #7
    a.vwrite     a5, s46, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #24064
    s.movz       s46, #8
    a.vwrite     a5, s47, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #24128
    s.movz       s47, #9
    a.vwrite     a5, s42, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #24192
    s.movz       s42, #10
    a.vwrite     a5, s43, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #24256
    s.movz       s43, #11
    a.vwrite     a5, s45, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #24320
    s.movz       s45, #12
    a.vwrite     a5, s46, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #24384
    s.movz       s46, #13
    a.vwrite     a5, s47, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #24448
    s.movz       s47, #14
    a.vwrite     a5, s42, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #24512
    s.movz       s42, #15
    a.vwrite     a5, s43, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #24576
    s.movz       s43, #0
    a.vwrite     a5, s45, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #24640
    s.movz       s45, #1
    a.vwrite     a5, s46, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #24704
    s.movz       s46, #2
    a.vwrite     a5, s47, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #24768
    s.movz       s47, #3
    a.vwrite     a5, s42, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #24832
    s.movz       s42, #4
    a.vwrite     a6, s43, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #24896
    s.movz       s43, #5
    a.vwrite     a6, s45, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #24960
    s.movz       s45, #6
    a.vwrite     a6, s46, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #25024
    s.movz       s46, #7
    a.vwrite     a6, s47, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #25088
    s.movz       s47, #8
    a.vwrite     a6, s42, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #25152
    s.movz       s42, #9
    a.vwrite     a6, s43, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #25216
    s.movz       s43, #10
    a.vwrite     a6, s45, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #25280
    s.movz       s45, #11
    a.vwrite     a6, s46, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #25344
    s.movz       s46, #12
    a.vwrite     a6, s47, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #25408
    s.movz       s47, #13
    a.vwrite     a6, s42, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #25472
    s.movz       s42, #14
    a.vwrite     a6, s43, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #25536
    s.movz       s43, #15
    a.vwrite     a6, s45, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #25600
    s.movz       s45, #0
    a.vwrite     a6, s46, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #25664
    s.movz       s46, #1
    a.vwrite     a6, s47, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #25728
    s.movz       s47, #2
    a.vwrite     a6, s42, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #25792
    s.movz       s42, #3
    a.vwrite     a6, s43, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #25856
    s.movz       s43, #4
    a.vwrite     a7, s45, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #25920
    s.movz       s45, #5
    a.vwrite     a7, s46, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #25984
    s.movz       s46, #6
    a.vwrite     a7, s47, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #26048
    s.movz       s47, #7
    a.vwrite     a7, s42, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #26112
    s.movz       s42, #8
    a.vwrite     a7, s43, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #26176
    s.movz       s43, #9
    a.vwrite     a7, s45, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #26240
    s.movz       s45, #10
    a.vwrite     a7, s46, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #26304
    s.movz       s46, #11
    a.vwrite     a7, s47, v13
    v.ld.w       v13, [s41, #0]
    s.addi       s41, s33, #26368
    s.movz       s47, #12
    a.vwrite     a7, s42, v13
    v.ld.w       v13, [s39, #0]
    s.addi       s39, s33, #26432
    s.movz       s42, #13
    a.vwrite     a7, s43, v13
    v.ld.w       v13, [s40, #0]
    s.addi       s40, s33, #26496
    s.movz       s43, #14
    a.vwrite     a7, s45, v13
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s33, #26560
    s.movz       s33, #15
    a.vwrite     a7, s46, v13
    v.ld.w       v13, [s41, #0]
    s.add        s41, s28, s26
    s.movz       s45, #1
    a.vwrite     a7, s47, v13
    v.ld.w       v13, [s39, #0]
    a.vwrite     a7, s42, v13
    v.ld.w       v13, [s40, #0]
    a.vwrite     a7, s43, v13
    v.ld.w       v13, [s30, #0]
    a.vwrite     a7, s33, v13
    s.mov        s28, s41
    br.nz        s45, for_28
endfor_29:
    s.mul        s1, s16, s12
    s.muli       s14, s12, #2
    s.muli       s17, s15, #2
    s.movz       s18, #0
    s.addi       s19, s15, #16
    s.muli       s20, s1, #2
    s.movz       s1, #0
    a.vread      v0, a0, s18
    s.addi       s18, s15, #32
    s.add        s21, s1, s16                    // the tile origin
    vf.cvt.f32.bf16 v1, v0
    s.add        s1, s20, s17
    s.addi       s16, s15, #48
    v.splat      v0, s21
    s.add        s22, s5, s1
    s.addi       s1, s15, #64
    s.movz       s23, #0
    s.addi       s24, s15, #80
    s.add        s25, s23, s7                    // the tile origin
    s.addi       s23, s15, #96
    v.splat      v2, s25
    s.addi       s25, s15, #112
    s.movz       s26, #0
    s.movz       s27, #0
    s.add        s28, s26, s15                   // the tile origin
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s28
    s.add        s15, s27, s8                    // the tile origin
    v.add        v5, v3, v4
    s.muli       s26, s14, #1
    v.cmp.lt     p1, v0, v2
    v.splat      v0, s15
    s.movz       s15, #1
    v.cmp.lt     p2, v5, v0
    p.and        p3, p1, p2
    s.addi       s27, s21, #1
    @p3 v.st.h       [s22, #0], v1
    a.vread      v0, a0, s15
    s.add        s15, s26, s20
    v.splat      v1, s27
    s.muli       s22, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #2
    s.addi       s27, s21, #2
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #3
    s.addi       s27, s21, #3
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #4
    s.addi       s27, s21, #4
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #5
    s.addi       s27, s21, #5
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #6
    s.addi       s27, s21, #6
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #7
    s.addi       s27, s21, #7
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #8
    s.addi       s27, s21, #8
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #9
    s.addi       s27, s21, #9
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #10
    s.addi       s27, s21, #10
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #11
    s.addi       s27, s21, #11
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #12
    s.addi       s27, s21, #12
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #13
    s.addi       s27, s21, #13
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #14
    s.addi       s27, s21, #14
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    s.muli       s22, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.add        s15, s5, s26
    p.and        p3, p1, p2
    s.movz       s26, #15
    s.addi       s27, s21, #15
    @p3 v.st.h       [s15, #0], v4
    a.vread      v0, a0, s26
    s.add        s15, s22, s20
    v.splat      v1, s27
    vf.cvt.f32.bf16 v4, v0
    s.movz       s22, #0
    s.add        s26, s15, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #2
    s.add        s17, s22, s19                   // the tile origin
    s.add        s19, s5, s26
    s.movz       s22, #0
    p.and        p3, p1, p2
    s.movz       s26, #0
    v.splat      v0, s17
    s.add        s17, s22, s8                    // the tile origin
    @p3 v.st.h       [s19, #0], v4
    a.vread      v1, a1, s26
    v.splat      v4, s21
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s19, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s17
    s.add        s17, s5, s19
    s.muli       s19, s14, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s22, #1
    s.addi       s26, s21, #1
    @p3 v.st.h       [s17, #0], v0
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #2
    s.addi       s26, s21, #2
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #3
    s.addi       s26, s21, #3
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #4
    s.addi       s26, s21, #4
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #5
    s.addi       s26, s21, #5
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #6
    s.addi       s26, s21, #6
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #7
    s.addi       s26, s21, #7
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #8
    s.addi       s26, s21, #8
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #9
    s.addi       s26, s21, #9
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #10
    s.addi       s26, s21, #10
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #11
    s.addi       s26, s21, #11
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #12
    s.addi       s26, s21, #12
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #13
    s.addi       s26, s21, #13
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #14
    s.addi       s26, s21, #14
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    s.muli       s19, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s22
    p.and        p3, p1, p2
    s.movz       s22, #15
    s.addi       s26, s21, #15
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a1, s22
    s.add        s17, s19, s20
    v.splat      v1, s26
    vf.cvt.f32.bf16 v4, v0
    s.movz       s19, #0
    s.add        s22, s17, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s18, #2
    s.add        s17, s19, s18                   // the tile origin
    s.add        s18, s5, s22
    s.movz       s19, #0
    p.and        p3, p1, p2
    s.movz       s22, #0
    v.splat      v0, s17
    s.add        s17, s19, s8                    // the tile origin
    @p3 v.st.h       [s18, #0], v4
    a.vread      v1, a2, s22
    v.splat      v4, s21
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s18, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s17
    s.add        s17, s5, s18
    s.muli       s18, s14, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s19, #1
    s.addi       s22, s21, #1
    @p3 v.st.h       [s17, #0], v0
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #2
    s.addi       s22, s21, #2
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #3
    s.addi       s22, s21, #3
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #4
    s.addi       s22, s21, #4
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #5
    s.addi       s22, s21, #5
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #6
    s.addi       s22, s21, #6
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #7
    s.addi       s22, s21, #7
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #8
    s.addi       s22, s21, #8
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #9
    s.addi       s22, s21, #9
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #10
    s.addi       s22, s21, #10
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #11
    s.addi       s22, s21, #11
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #12
    s.addi       s22, s21, #12
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #13
    s.addi       s22, s21, #13
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #14
    s.addi       s22, s21, #14
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    s.muli       s18, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s19
    p.and        p3, p1, p2
    s.movz       s19, #15
    s.addi       s22, s21, #15
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a2, s19
    s.add        s17, s18, s20
    v.splat      v1, s22
    vf.cvt.f32.bf16 v4, v0
    s.movz       s18, #0
    s.add        s19, s17, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s16, #2
    s.add        s17, s18, s16                   // the tile origin
    s.add        s16, s5, s19
    s.movz       s18, #0
    p.and        p3, p1, p2
    s.movz       s19, #0
    v.splat      v0, s17
    s.add        s17, s18, s8                    // the tile origin
    @p3 v.st.h       [s16, #0], v4
    a.vread      v1, a3, s19
    v.splat      v4, s21
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s16, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s17
    s.add        s17, s5, s16
    s.muli       s16, s14, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s18, #1
    s.addi       s19, s21, #1
    @p3 v.st.h       [s17, #0], v0
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #2
    s.addi       s19, s21, #2
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #3
    s.addi       s19, s21, #3
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #4
    s.addi       s19, s21, #4
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #5
    s.addi       s19, s21, #5
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #6
    s.addi       s19, s21, #6
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #7
    s.addi       s19, s21, #7
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #8
    s.addi       s19, s21, #8
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #9
    s.addi       s19, s21, #9
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #10
    s.addi       s19, s21, #10
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #11
    s.addi       s19, s21, #11
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #12
    s.addi       s19, s21, #12
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #13
    s.addi       s19, s21, #13
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #14
    s.addi       s19, s21, #14
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    s.muli       s16, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.add        s17, s5, s18
    p.and        p3, p1, p2
    s.movz       s18, #15
    s.addi       s19, s21, #15
    @p3 v.st.h       [s17, #0], v4
    a.vread      v0, a3, s18
    s.add        s17, s16, s20
    v.splat      v1, s19
    vf.cvt.f32.bf16 v4, v0
    s.movz       s16, #0
    s.add        s18, s17, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s1, #2
    s.add        s17, s16, s1                    // the tile origin
    s.add        s1, s5, s18
    s.movz       s16, #0
    p.and        p3, p1, p2
    s.movz       s18, #0
    v.splat      v0, s17
    s.add        s17, s16, s8                    // the tile origin
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s18
    v.splat      v4, s21
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s1, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s17
    s.add        s16, s5, s1
    s.muli       s1, s14, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #2
    s.addi       s18, s21, #2
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #3
    s.addi       s18, s21, #3
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #4
    s.addi       s18, s21, #4
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #5
    s.addi       s18, s21, #5
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #6
    s.addi       s18, s21, #6
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #7
    s.addi       s18, s21, #7
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #8
    s.addi       s18, s21, #8
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #9
    s.addi       s18, s21, #9
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #10
    s.addi       s18, s21, #10
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #11
    s.addi       s18, s21, #11
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #12
    s.addi       s18, s21, #12
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #13
    s.addi       s18, s21, #13
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #14
    s.addi       s18, s21, #14
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #15
    s.addi       s18, s21, #15
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a4, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    vf.cvt.f32.bf16 v4, v0
    s.movz       s1, #0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s24, #2
    s.add        s16, s1, s24                    // the tile origin
    s.add        s1, s5, s17
    s.movz       s17, #0
    p.and        p3, p1, p2
    s.movz       s18, #0
    v.splat      v0, s16
    s.add        s16, s17, s8                    // the tile origin
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s18
    v.splat      v4, s21
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s1, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s16
    s.add        s16, s5, s1
    s.muli       s1, s14, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #2
    s.addi       s18, s21, #2
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #3
    s.addi       s18, s21, #3
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #4
    s.addi       s18, s21, #4
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #5
    s.addi       s18, s21, #5
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #6
    s.addi       s18, s21, #6
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #7
    s.addi       s18, s21, #7
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #8
    s.addi       s18, s21, #8
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #9
    s.addi       s18, s21, #9
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #10
    s.addi       s18, s21, #10
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #11
    s.addi       s18, s21, #11
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #12
    s.addi       s18, s21, #12
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #13
    s.addi       s18, s21, #13
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #14
    s.addi       s18, s21, #14
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #15
    s.addi       s18, s21, #15
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a5, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    vf.cvt.f32.bf16 v4, v0
    s.movz       s1, #0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s23, #2
    s.add        s16, s1, s23                    // the tile origin
    s.add        s1, s5, s17
    s.movz       s17, #0
    p.and        p3, p1, p2
    s.movz       s18, #0
    v.splat      v0, s16
    s.add        s16, s17, s8                    // the tile origin
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s18
    v.splat      v4, s21
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s1, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s16
    s.add        s16, s5, s1
    s.muli       s1, s14, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #2
    s.addi       s18, s21, #2
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #3
    s.addi       s18, s21, #3
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #4
    s.addi       s18, s21, #4
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #5
    s.addi       s18, s21, #5
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #6
    s.addi       s18, s21, #6
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #7
    s.addi       s18, s21, #7
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #8
    s.addi       s18, s21, #8
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #9
    s.addi       s18, s21, #9
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #10
    s.addi       s18, s21, #10
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #11
    s.addi       s18, s21, #11
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #12
    s.addi       s18, s21, #12
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #13
    s.addi       s18, s21, #13
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #14
    s.addi       s18, s21, #14
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #15
    s.addi       s18, s21, #15
    @p3 v.st.h       [s16, #0], v4
    a.vread      v0, a6, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    vf.cvt.f32.bf16 v4, v0
    s.movz       s1, #0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s25, #2
    s.add        s16, s1, s25                    // the tile origin
    s.add        s1, s5, s17
    s.movz       s17, #0
    p.and        p3, p1, p2
    s.movz       s18, #0
    v.splat      v0, s16
    s.add        s16, s17, s8                    // the tile origin
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a7, s18
    v.splat      v4, s21
    v.add        v5, v3, v0
    v.splat      v0, s16
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s20, s15
    v.cmp.lt     p1, v4, v2
    v.cmp.lt     p2, v5, v0
    s.add        s16, s5, s1
    s.muli       s1, s14, #1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #2
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #2
    s.addi       s18, s21, #2
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #3
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #3
    s.addi       s18, s21, #3
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #4
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #4
    s.addi       s18, s21, #4
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #5
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #5
    s.addi       s18, s21, #5
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #6
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #6
    s.addi       s18, s21, #6
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #7
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #7
    s.addi       s18, s21, #7
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #8
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #8
    s.addi       s18, s21, #8
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #9
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #9
    s.addi       s18, s21, #9
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #10
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #10
    s.addi       s18, s21, #10
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #11
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #11
    s.addi       s18, s21, #11
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #12
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #12
    s.addi       s18, s21, #12
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #13
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #13
    s.addi       s18, s21, #13
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #14
    vf.cvt.f32.bf16 v3, v0
    s.add        s17, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s17
    p.and        p3, p1, p2
    s.movz       s17, #14
    s.addi       s18, s21, #14
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s17
    s.add        s16, s1, s20
    v.splat      v1, s18
    s.muli       s1, s14, #15
    vf.cvt.f32.bf16 v3, v0
    s.add        s14, s16, s15
    v.cmp.lt     p1, v1, v2
    s.add        s16, s5, s14
    p.and        p3, p1, p2
    s.movz       s14, #15
    s.addi       s17, s21, #15
    @p3 v.st.h       [s16, #0], v3
    a.vread      v0, a7, s14
    s.add        s14, s1, s20
    v.splat      v1, s17
    vf.cvt.f32.bf16 v3, v0
    s.add        s1, s14, s15
    v.cmp.lt     p1, v1, v2
    s.add        s14, s5, s1
    p.and        p3, p1, p2
    s.addi       s1, s4, #16
    @p3 v.st.h       [s14, #0], v3
    s.mov        s4, s1
    s.movz       s1, #128
    s.cmp.lt     s14, s4, s1
    br.nz        s14, rows_1
endrows_2:
    exit
    exit
