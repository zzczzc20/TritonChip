    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    .li       s1, #4286578688
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #100
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    s.ld.d       s8, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    s.mul        s1, s4, s5
    v.splat      v0, s7
    v.movi       v3, #100
    v.movi       v4, #0
    v.add        v5, v0, v2
    s.add        s9, s7, s1
    v.splat      v0, s1
    s.shli       s1, s9, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p1, v5, v3
    s.add        s9, s8, s1                      // &in_ptr0[...]
    s.add        s1, s7, s6
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s9, #0]
    s.movz       s9, #1
    v.add        v6, v5, v0
    vf.max.prop  v0, v1, v3
    @p1 v.sel        v3, v0, v1
    v.mov        v4, v3
    v.mov        v1, v4
    s.mov        s7, s1
    br.nz        s9, for_1
endfor_2:
    v.movi       v0, #1
    v.movi       v3, #0
    vf.cmp.uo    p1, v1, v1
    v.movi       v4, #0
    @p1 v.sel        v5, v0, v3
    vf.reduce.max.b v0, v1
    .li       s1, #2143289344
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.reduce.or.b v3, v5
    v.movi       v5, #0
    v.movi       v6, #0
    v.cmp.ne     p1, v3, v4
    @p1 v.sel        v3, v1, v0
    v.movi       v0, #0
    s.addi       s1, s2, #0
    vf.add       v1, v3, v5
    v.mov        v0, v6
for_3:
    s.cmp.ge     s7, s1, s5
    br.nz        s7, endfor_4
    s.mul        s7, s4, s5
    v.splat      v3, s1
    v.movi       v4, #100
    v.extract    s9, v1, #0
    v.add        v6, v3, v2
    s.add        s10, s1, s7
    v.splat      v3, s9
    s.shli       s9, s10, #2                     // element offset -> bytes (x4)
    v.cmp.lt     p1, v6, v4
    s.add        s10, s8, s9                     // &in_ptr0[...]
    .li       s11, #1069066811
    v.splat      v4, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v7, [s10, #0]
    .li       s10, #1060205080
    v.splat      v8, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #0
    s.add        s10, s3, s9                     // &in_out_ptr0[...]
    v.splat      v10, s7
    s.add        s7, s1, s6
    s.movz       s9, #1
    v.add        v11, v6, v10
    vf.sub       v6, v7, v3
    vf.mul       v3, v6, v4
    v.exp2.approx v7, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v6, v4, v3                 // the exact rounding error of x*log2(e)
    vf.mul       v3, v10, v8
    vf.fma       v4, v7, v3, v7                  // 2**t * 2**d
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v3, v4, v7
    vf.add       v4, v0, v3
    @p1 v.st.w       [s10, #0], v3
    @p1 v.sel        v3, v4, v0
    v.mov        v9, v3
    v.mov        v0, v9
    s.mov        s1, s7
    br.nz        s9, for_3
endfor_4:
    s.rdspecial  s1, arg_base
    s.rdspecial  s7, role_id
    s.ld.d       s8, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #256
    vf.reduce.add.b v1, v0
    s.mul        s9, s7, s1
    s.movz       s1, #8
    s.movz       s7, #100
    s.movz       s10, #400
    s.movz       s11, #4
    .li       s12, #68719476737
    vf.add       v0, v1, v5
    s.movz       s13, #0
    s.add        s13, s8, s9                     // this context's own scratch
    .li       s8, #2207613190144
    s.addi       s9, s13, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.addi       s13, s2, #0
    s.st.d       [s9, #0], s3
    s.st.d       [s9, #8], s1
    s.st.d       [s9, #16], s7
    s.st.d       [s9, #48], s10
    s.st.d       [s9, #56], s11
    s.st.d       [s9, #88], s12
    s.st.d       [s9, #104], s8
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
for_5:
    s.cmp.ge     s1, s13, s5
    br.nz        s1, endfor_6
    v.extract    s1, v0, #0
    v.splat      v1, s13
    v.splat      v3, s1
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s1, #100
    v.rcp.approx v5, v3                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #8
    s.muli       s7, s4, #400
    v.add        v6, v1, v4
    v.movi       v1, #0
    v.splat      v4, s1
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s2
    s.muli       s1, s13, #4
    v.cmp.ge     p1, v6, v1
    v.cmp.lt     p2, v6, v4
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    s.add        s2, s3, s7
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    .li       s7, #1065353216
    v.splat      v1, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s7, s2, s1
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v4, [s7, #0]
    s.mul        s1, s4, s5
    v.splat      v6, s13
    v.movi       v7, #100
    s.add        s2, s13, s6
    v.add        v8, v6, v2
    s.add        s7, s13, s1
    vf.fms       v6, v3, v5, v1
    s.shli       s8, s7, #2                      // element offset -> bytes (x4)
    v.splat      v1, s1
    s.add        s1, s3, s8                      // &in_out_ptr0[...]
    s.movz       s7, #1
    vf.fms       v3, v5, v6, v5
    v.cmp.lt     p1, v8, v7
    v.add        v6, v8, v1
    vf.neg       v1, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v3, v1, v5
    vf.mul       v1, v4, v3                      // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.st.w       [s1, #0], v1
    s.mov        s13, s2
    br.nz        s7, for_5
endfor_6:
__rctx_next:
    exit
