#!/usr/bin/env bash
set +e
(
  set -e
  ulimit -v 16777216
  export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
  source "$HOME/tc_env/env.sh"
  cd "$HOME/r41_merge_gate_f7c3a627"
  mkdir -p compiler/build/tools/tnca-opt sim/build
  cp "$HOME/r41g4_gate4/tree/compiler/build/tools/tnca-opt/tnca-opt" compiler/build/tools/tnca-opt/tnca-opt
  sha256sum compiler/build/tools/tnca-opt/tnca-opt
  make sim/build/tb_core.vvp PYTHON="$HOME/tc_env/torchenv/bin/python"
  iverilog -g2005 -I rtl/common -P tb_tnca_core.MAC_DP=1 -P tb_tnca_core.MAC_CUTS=29 -y rtl/core -y rtl/common -y rtl/gen -y tb/common -o sim/build/tb_core_dp29.vvp tb/core/tb_tnca_core.v
  R1_STRICT=1 TNCA_LLVM="$HOME/tc_env/root/usr/lib/llvm-20" make compiler PYTHON="$HOME/tc_env/torchenv/bin/python" LLVM_PREFIX="$HOME/tc_env/root/usr/lib/llvm-20"
) > "$HOME/r41_merge_gate_f7c3a627.log" 2>&1
rc=$?
printf '%s\n' "$rc" > "$HOME/r41_merge_gate_f7c3a627.exit"
exit "$rc"
