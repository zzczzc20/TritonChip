    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #16
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #4
    s.movz       s6, #8
    s.xor        s8, s5, s3
    s.movz       s9, #1
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s9
    s.movz       s8, #0
    s.cmp.lt     s9, s12, s3
    s.movz       s3, #0
    s.cmp.lt     s13, s4, s11
    s.sub        s11, s8, s9
    s.sub        s8, s3, s13
    s.xor        s3, s12, s11
    s.muli       s9, s5, #16
    s.movz       s5, #0
    s.movz       s13, #1
    s.xor        s14, s4, s8
    s.sub        s15, s3, s11
    s.rdspecial  s3, arg_base
    s.xor        s11, s1, s7
    s.movz       s16, #0
    s.sub        s17, s14, s8
    s.addi       s14, s5, #0
    s.cmp.eq     s5, s15, s13
    s.ld.d       s13, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s18, s11, s7
    s.sub        s7, s2, s9
    s.addi       s2, s16, #0
    s.ld.d       s7, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s9, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s14, s17
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s14, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s17, s3
    s.shli       s11, s2, #1
    s.andi       s16, s5, #1
    s.movz       s5, #0
    s.or         s18, s11, s16
    s.movz       s11, #1
    s.cmp.geu    s16, s18, s15
    s.shl        s19, s11, s3
    s.sub        s11, s5, s16
    s.subi       s5, s3, #1
    s.and        s16, s15, s11
    s.and        s20, s19, s11
    s.sub        s11, s18, s16
    s.or         s16, s14, s20
    s.mov        s2, s11
    s.mov        s14, s16
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s11, s3, s5
    br.nz        s11, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s11, s4, s3
    s.movz       s3, #0
    s.sub        s14, s5, s11
    s.movz       s5, #0
    s.xor        s11, s4, s14
    s.movz       s4, #0
    s.sub        s15, s11, s14
    s.cmp.lt     s11, s12, s3
    s.lshri      s3, s15, #4
    s.movz       s16, #0
    s.muli       s17, s3, #16
    s.movz       s3, #0
    s.sub        s18, s4, s11
    s.movz       s4, #0
    s.cmp.lt     s11, s1, s16
    s.sub        s16, s15, s17
    s.xor        s15, s12, s18
    s.xor        s12, s16, s14
    s.xor        s16, s2, s8
    s.sub        s2, s12, s14
    s.sub        s12, s4, s11
    s.cmp.lt     s4, s2, s5
    s.sub        s5, s15, s18
    s.sub        s11, s3, s4
    s.movz       s3, #0
    s.xor        s4, s2, s11
    s.movz       s2, #1
    s.sub        s14, s16, s8
    s.xor        s8, s1, s12
    s.sub        s15, s4, s11
    s.movz       s4, #0
    s.addi       s16, s3, #0
    s.cmp.eq     s3, s5, s2
    s.add        s2, s10, s14
    s.sub        s10, s8, s12
    s.addi       s8, s4, #0
    s.mov        s16, s15
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s16, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s15, s3
    s.shli       s10, s8, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s14, s10, s12
    s.movz       s10, #1
    s.cmp.geu    s12, s14, s5
    s.shl        s17, s10, s3
    s.sub        s10, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s10
    s.and        s19, s17, s10
    s.sub        s10, s14, s12
    s.or         s12, s16, s19
    s.mov        s8, s10
    s.mov        s16, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s10, s3, s4
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.rdspecial  s3, pid.z
    s.rdspecial  s4, npid.y
    s.xor        s5, s11, s18
    s.mul        s8, s2, s1
    s.mul        s10, s3, s4
    s.xor        s3, s16, s5
    s.rdspecial  s4, pid.y
    s.sub        s11, s3, s5
    s.andi       s3, s8, #127
    s.mul        s5, s11, s1
    s.add        s12, s4, s10
    s.movz       s4, #7
    s.rdspecial  s10, arg_base
    s.min.s      s14, s12, s4
    s.movz       s4, #18432
    s.movz       s15, #36864
    s.ld.d       s16, [s10, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.muli       s10, s3, #144                   // a runtime tile origin, x144
    s.mul        s17, s14, s4
    s.mul        s4, s14, s15
    s.andi       s14, s5, #255
    s.movz       s15, #0
    s.rdspecial  s18, role_id
    s.movz       s19, #9728
    s.add        s20, s15, s10                   // the tile origin
    s.mul        s10, s18, s19
    s.add        s15, s20, s17                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s15
    s.movz       s17, #0
    s.add        s18, s16, s10                   // this context's own scratch
    v.splat      v2, s2
    s.addi       s2, s18, #0
    v.splat      v3, s17
    v.splat      v4, s11
    v.splat      v5, s17
    v.add        v6, v0, v1
    s.addi       s10, s2, #64
    v.cmp.ge     p1, v2, v3
    s.addi       s11, s15, #144
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s11
    v.cmp.ge     p1, v4, v5
    s.addi       s11, s15, #288
    v.splat      v3, s8
    v.splat      v4, s11
    v.add        v5, v0, v2
    s.addi       s11, s2, #128
    v.add        v2, v3, v1
    v.splat      v2, s5
    v.add        v3, v0, v4
    s.addi       s16, s2, #192
    v.add        v4, v2, v1
    s.addi       s19, s15, #432
    v.splat      v1, s3
    v.splat      v2, s19
    s.movz       s3, #144
    s.addi       s19, s17, #0
    v.add        v4, v0, v2
    v.st.w       [s2, #0], v6
    v.iota       v2                              // arange(0, VLEN)
    v.add        v6, v1, v2
    s.addi       s17, s15, #576
    v.splat      v1, s14
    v.splat      v2, s17
    s.addi       s17, s2, #256
    v.st.w       [s10, #0], v5
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v2
    v.add        v2, v1, v5
    s.addi       s10, s15, #720
    s.addi       s20, s15, #864
    s.addi       s21, s15, #1008
    v.splat      v1, s10
    s.addi       s10, s15, #1152
    v.splat      v2, s20
    s.addi       s20, s15, #1296
    v.add        v5, v0, v1
    v.add        v1, v0, v2
    v.st.w       [s11, #0], v3
    s.addi       s11, s15, #1440
    v.splat      v2, s21
    s.addi       s21, s15, #1584
    v.add        v3, v0, v2
    v.st.w       [s16, #0], v4
    s.addi       s16, s15, #1728
    v.splat      v2, s10
    s.addi       s10, s15, #1872
    v.add        v4, v0, v2
    v.st.w       [s17, #0], v6
    s.addi       s17, s15, #2016
    v.splat      v2, s20
    s.addi       s20, s2, #320
    s.addi       s22, s15, #2160
    v.add        v6, v0, v2
    v.st.w       [s20, #0], v5
    v.splat      v2, s11
    s.addi       s11, s2, #384
    s.addi       s15, s18, #1024
    v.add        v5, v0, v2
    v.st.w       [s11, #0], v1
    s.movz       s11, #0
    v.splat      v1, s21
    s.addi       s20, s2, #448
    s.add        s21, s11, s14                   // the tile origin
    v.add        v2, v0, v1
    s.add        s11, s21, s4                    // the tile origin
    s.addi       s4, s2, #512
    s.addi       s14, s2, #576
    v.st.w       [s20, #0], v3
    s.addi       s20, s11, #256
    v.splat      v1, s16
    s.addi       s16, s2, #640
    v.add        v3, v0, v1
    v.st.w       [s4, #0], v4
    s.addi       s4, s11, #512
    v.splat      v1, s10
    s.addi       s10, s2, #704
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v6
    s.addi       s14, s11, #768
    v.splat      v1, s17
    s.addi       s17, s2, #768
    v.add        v6, v0, v1
    v.st.w       [s16, #0], v5
    s.addi       s16, s11, #1024
    v.splat      v1, s22
    s.addi       s21, s2, #832
    v.add        v5, v0, v1
    v.st.w       [s10, #0], v2
    s.addi       s10, s11, #1280
    v.splat      v1, s11
    v.add        v2, v0, v1
    v.st.w       [s17, #0], v3
    s.addi       s17, s11, #1536
    v.splat      v1, s20
    s.addi       s20, s2, #896
    s.addi       s22, s2, #960
    v.add        v3, v0, v1
    v.st.w       [s21, #0], v4
    s.addi       s2, s11, #1792
    v.splat      v1, s4
    s.addi       s4, s15, #64
    v.add        v4, v0, v1
    v.st.w       [s20, #0], v6
    s.addi       s20, s11, #2048
    v.splat      v1, s14
    s.addi       s14, s15, #128
    v.add        v6, v0, v1
    v.st.w       [s22, #0], v5
    v.splat      v1, s16
    s.addi       s16, s15, #192
    s.addi       s21, s15, #256
    v.add        v5, v0, v1
    fence.acq_rel.device
    v.st.w       [s15, #0], v2
    v.splat      v1, s10
    s.addi       s10, s11, #2304
    v.add        v2, v0, v1
    v.st.w       [s4, #0], v3
    s.addi       s4, s11, #2560
    v.splat      v1, s17
    s.addi       s17, s11, #2816
    v.add        v3, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s11, #3072
    v.splat      v1, s2
    s.addi       s2, s11, #3328
    v.add        v4, v0, v1
    v.st.w       [s16, #0], v6
    s.addi       s16, s11, #3584
    v.splat      v1, s20
    s.addi       s20, s15, #320
    v.add        v6, v0, v1
    v.st.w       [s21, #0], v5
    s.addi       s21, s11, #3840
    v.splat      v1, s10
    s.addi       s10, s15, #384
    s.addi       s11, s15, #448
    v.add        v5, v0, v1
    v.st.w       [s20, #0], v2
    v.splat      v1, s4
    s.addi       s4, s15, #512
    s.addi       s20, s15, #576
    v.add        v2, v0, v1
    v.st.w       [s10, #0], v3
    v.splat      v1, s17
    s.addi       s10, s15, #640
    s.addi       s17, s15, #704
    v.add        v3, v0, v1
    v.st.w       [s11, #0], v4
    v.splat      v1, s14
    s.addi       s11, s15, #768
    s.addi       s14, s15, #832
    v.add        v4, v0, v1
    v.st.w       [s4, #0], v6
    v.splat      v1, s2
    s.addi       s2, s15, #896
    s.addi       s4, s15, #960
    v.add        v6, v0, v1
    v.st.w       [s20, #0], v5
    v.splat      v1, s16
    v.add        v5, v0, v1
    v.st.w       [s10, #0], v2
    v.splat      v1, s21
    v.add        v2, v0, v1
    v.st.w       [s17, #0], v3
    v.st.w       [s11, #0], v4
    v.st.w       [s14, #0], v6
    v.st.w       [s2, #0], v5
    v.st.w       [s4, #0], v2
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s2, s19, s3
    br.nz        s2, endfor_6
    s.addi       s2, s18, #0
    s.addi       s4, s18, #2048
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #64
    s.addi       s10, s4, #64
    s.addi       s11, s18, #128
    s.addi       s14, s4, #128
    s.addi       s15, s18, #192
    s.addi       s16, s4, #192
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v2
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #256
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s4, #256
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s18, #320
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s4, #320
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s18, #384
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s4, #384
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #448
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s4, #448
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s18, #512
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s4, #512
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s18, #576
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s4, #576
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #640
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s4, #640
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s18, #704
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s4, #704
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s18, #768
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s4, #768
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #832
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s4, #832
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s18, #896
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s4, #896
    s.addi       s17, s4, #960
    v.ld.w       v1, [s15, #0]
    s.addi       s4, s18, #960
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s15, s18, #1024
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #3072
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s18, #1088
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s2, #64
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s18, #1152
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s2, #128
    v.ld.gather.h v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    s.addi       s16, s18, #1216
    v.st.w       [s17, #0], v2
    fence.acq_rel.device
    s.addi       s17, s2, #192
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s18, #1280
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s2, #0], v2
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s2, #256
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s11, #0], v2
    s.addi       s11, s18, #1344
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s2, #320
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v2
    s.addi       s4, s18, #1408
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #384
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s17, #0], v2
    s.addi       s17, s18, #1472
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s2, #448
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s18, #1536
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s2, #512
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s18, #1600
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s2, #576
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s18, #1664
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s2, #640
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s18, #1728
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s2, #704
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s11, #0], v2
    s.addi       s11, s18, #1792
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s2, #768
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v2
    s.addi       s4, s18, #1856
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #832
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s17, #0], v2
    s.addi       s17, s18, #1920
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s2, #896
    s.addi       s20, s2, #960
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s2, s18, #1984
    v.ld.w       v1, [s11, #0]
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s10, s18, #2048
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s11, s18, #4096                 // 512 bytes of repack scratch
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #2112
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s14, s11, #32                   // row 1
    v.ld.w       v1, [s17, #0]
    s.addi       s16, s18, #2176
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s11, #64                   // row 2
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #2240
    v.ld.gather.h v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s17, s11, #96                   // row 3
    v.st.w       [s20, #0], v2
    fence.acq_rel.device
    s.addi       s20, s18, #2304
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s11, #128                  // row 4
    v.st.h       [s11, #0], v1
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #2368
    v.st.h       [s14, #0], v1
    s.addi       s14, s11, #160                  // row 5
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #2432
    v.st.h       [s15, #0], v1
    s.addi       s15, s11, #192                  // row 6
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #2496
    v.st.h       [s17, #0], v1
    s.addi       s17, s11, #224                  // row 7
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #2560
    s.movz       s21, #0
    v.st.h       [s10, #0], v1
    s.addi       s10, s11, #256                  // row 8
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #2624
    v.st.h       [s14, #0], v1
    s.addi       s14, s11, #288                  // row 9
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #2688
    v.st.h       [s15, #0], v1
    s.addi       s15, s11, #320                  // row 10
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #2752
    v.st.h       [s17, #0], v1
    s.addi       s17, s11, #352                  // row 11
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #2816
    v.st.h       [s10, #0], v1
    s.addi       s10, s11, #384                  // row 12
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #2880
    v.st.h       [s14, #0], v1
    s.addi       s14, s11, #416                  // row 13
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #2944
    v.st.h       [s15, #0], v1
    s.addi       s15, s11, #448                  // row 14
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s18, #3008
    v.st.h       [s17, #0], v1
    s.addi       s17, s11, #480                  // row 15
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #4608                 // TensorMap 0: a repacked tile
    v.st.h       [s10, #0], v1
    s.movz       s10, #16
    v.ld.w       v1, [s4, #0]
    s.movz       s4, #16
    v.st.h       [s14, #0], v1
    s.movz       s14, #32
    v.ld.w       v1, [s16, #0]
    s.movz       s16, #2
    v.st.h       [s15, #0], v1
    .li       s15, #68719476752
    v.ld.w       v1, [s2, #0]
    .li       s2, #1108101562368
    v.st.h       [s17, #0], v1
    s.movz       s17, #0
    s.st.d       [s20, #0], s11
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s11, s18, #3072
    s.st.d       [s20, #8], s10
    s.addi       s10, s18, #4864                 // 512 bytes of repack scratch
    s.st.d       [s20, #16], s4
    s.addi       s4, s18, #3136
    s.st.d       [s20, #48], s14
    s.addi       s14, s10, #32                   // row 1
    s.st.d       [s20, #56], s16
    s.addi       s16, s18, #3200
    s.st.d       [s20, #88], s15
    s.addi       s15, s10, #64                   // row 2
    s.st.d       [s20, #104], s2
    fence.release.device
    td.load      d0, [s20]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s2, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.addi       s20, s18, #3264
    s.addi       s21, s10, #96                   // row 3
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s22, s17                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s23, s17                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s22, s2
    mb.wait      s2
    s.addi       s17, s18, #3328
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #128                  // row 4
    v.st.h       [s10, #0], v1
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #3392
    v.st.h       [s14, #0], v1
    s.addi       s14, s10, #160                  // row 5
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #3456
    v.st.h       [s15, #0], v1
    s.addi       s15, s10, #192                  // row 6
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #3520
    v.st.h       [s21, #0], v1
    s.addi       s21, s10, #224                  // row 7
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #3584
    s.movz       s22, #0
    v.st.h       [s11, #0], v1
    s.addi       s11, s10, #256                  // row 8
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #3648
    v.st.h       [s14, #0], v1
    s.addi       s14, s10, #288                  // row 9
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #3712
    v.st.h       [s15, #0], v1
    s.addi       s15, s10, #320                  // row 10
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #3776
    v.st.h       [s21, #0], v1
    s.addi       s21, s10, #352                  // row 11
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s18, #3840
    v.st.h       [s11, #0], v1
    s.addi       s11, s10, #384                  // row 12
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #3904
    v.st.h       [s14, #0], v1
    s.addi       s14, s10, #416                  // row 13
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #3968
    v.st.h       [s15, #0], v1
    s.addi       s15, s10, #448                  // row 14
    v.splat      v1, s1
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s18, #4032
    v.st.h       [s21, #0], v2
    s.addi       s21, s10, #480                  // row 15
    v.ld.w       v2, [s17, #0]
    s.addi       s17, s18, #5376                 // TensorMap 1: a repacked tile
    v.st.h       [s11, #0], v2
    s.movz       s11, #16
    v.ld.w       v2, [s4, #0]
    s.movz       s4, #16
    v.st.h       [s14, #0], v2
    s.movz       s14, #32
    v.ld.w       v2, [s16, #0]
    s.movz       s16, #2
    v.st.h       [s15, #0], v2
    .li       s15, #68719476752
    v.ld.w       v2, [s20, #0]
    .li       s20, #1108101562368
    v.st.h       [s21, #0], v2
    s.movz       s21, #0
    s.st.d       [s17, #0], s10
    s.addi       s10, s18, #0
    s.st.d       [s17, #8], s11
    s.addi       s11, s18, #5632
    s.st.d       [s17, #16], s4
    s.addi       s4, s18, #64
    s.st.d       [s17, #48], s14
    s.addi       s14, s11, #64
    s.st.d       [s17, #56], s16
    s.addi       s16, s18, #128
    s.st.d       [s17, #88], s15
    s.addi       s15, s11, #128
    s.st.d       [s17, #104], s20
    fence.release.device
    td.load      d1, [s17]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s17, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s20, s18, #192
    s.addi       s22, s11, #192
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s23, s21                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s21                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s23, s17
    mb.wait      s17
    mb.arm       s21, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s23, s18, #256
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v56, v48, s21
    mb.wait      s21
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s11, #256
    v.add        v3, v2, v1
    v.st.w       [s11, #0], v3
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s18, #320
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s11, #320
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s18, #384
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s11, #384
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s18, #448
    v.add        v3, v2, v1
    v.st.w       [s22, #0], v3
    s.addi       s22, s11, #448
    v.ld.w       v2, [s23, #0]
    s.addi       s23, s18, #512
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s11, #512
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s18, #576
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s11, #576
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s18, #640
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s11, #640
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s18, #704
    v.add        v3, v2, v1
    v.st.w       [s22, #0], v3
    s.addi       s22, s11, #704
    v.ld.w       v2, [s23, #0]
    s.addi       s23, s18, #768
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s11, #768
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s18, #832
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s11, #832
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s18, #896
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s11, #896
    s.addi       s24, s11, #960
    v.ld.w       v2, [s20, #0]
    s.addi       s11, s18, #960
    v.add        v3, v2, v1
    v.st.w       [s22, #0], v3
    s.addi       s20, s18, #1024
    v.ld.w       v2, [s23, #0]
    s.movz       s22, #4096
    v.splat      v3, s22
    s.addi       s22, s18, #6656
    v.add        v4, v2, v1
    v.st.w       [s10, #0], v4
    s.addi       s10, s18, #1088
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s22, #64
    v.add        v4, v2, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s18, #1152
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s22, #128
    v.add        v4, v2, v1
    v.st.w       [s15, #0], v4
    s.addi       s15, s18, #1216
    v.ld.w       v2, [s11, #0]
    s.addi       s11, s22, #192
    v.add        v4, v2, v1
    v.st.w       [s24, #0], v4
    fence.acq_rel.device
    s.addi       s23, s18, #1280
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s22, #256
    v.add        v2, v1, v3
    v.st.w       [s22, #0], v2
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #1344
    v.add        v2, v1, v3
    v.st.w       [s4, #0], v2
    s.addi       s4, s22, #320
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #1408
    v.add        v2, v1, v3
    v.st.w       [s16, #0], v2
    s.addi       s16, s22, #384
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s18, #1472
    v.add        v2, v1, v3
    v.st.w       [s11, #0], v2
    s.addi       s11, s22, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #1536
    v.add        v2, v1, v3
    v.st.w       [s20, #0], v2
    s.addi       s20, s22, #512
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #1600
    v.add        v2, v1, v3
    v.st.w       [s4, #0], v2
    s.addi       s4, s22, #576
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #1664
    v.add        v2, v1, v3
    v.st.w       [s16, #0], v2
    s.addi       s16, s22, #640
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s18, #1728
    v.add        v2, v1, v3
    v.st.w       [s11, #0], v2
    s.addi       s11, s22, #704
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #1792
    v.add        v2, v1, v3
    v.st.w       [s20, #0], v2
    s.addi       s20, s22, #768
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #1856
    v.add        v2, v1, v3
    v.st.w       [s4, #0], v2
    s.addi       s4, s22, #832
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #1920
    v.add        v2, v1, v3
    v.st.w       [s16, #0], v2
    s.addi       s16, s22, #896
    s.addi       s24, s22, #960
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s18, #1984
    v.add        v2, v1, v3
    v.st.w       [s11, #0], v2
    s.addi       s11, s18, #5632
    v.ld.w       v1, [s23, #0]
    s.addi       s22, s18, #7680
    v.add        v2, v1, v3
    v.st.w       [s20, #0], v2
    s.addi       s20, s18, #5696
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s22, #64
    v.add        v2, v1, v3
    v.st.w       [s4, #0], v2
    s.addi       s4, s18, #5760
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s22, #128
    v.add        v2, v1, v3
    v.st.w       [s16, #0], v2
    s.addi       s16, s18, #5824
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s22, #192
    v.add        v2, v1, v3
    v.st.w       [s24, #0], v2
    fence.acq_rel.device
    s.addi       s23, s18, #5888
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s22, #256
    v.st.w       [s22, #0], v1
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #5952
    v.st.w       [s10, #0], v1
    s.addi       s10, s22, #320
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #6016
    v.st.w       [s14, #0], v1
    s.addi       s14, s22, #384
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #6080
    v.st.w       [s15, #0], v1
    s.addi       s15, s22, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #6144
    v.st.w       [s11, #0], v1
    s.addi       s11, s22, #512
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #6208
    v.st.w       [s10, #0], v1
    s.addi       s10, s22, #576
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #6272
    v.st.w       [s14, #0], v1
    s.addi       s14, s22, #640
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #6336
    v.st.w       [s15, #0], v1
    s.addi       s15, s22, #704
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #6400
    v.st.w       [s11, #0], v1
    s.addi       s11, s22, #768
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #6464
    v.st.w       [s10, #0], v1
    s.addi       s10, s22, #832
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #6528
    v.st.w       [s14, #0], v1
    s.addi       s14, s22, #896
    s.addi       s24, s22, #960
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #6592
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #6656
    v.ld.w       v1, [s23, #0]
    s.addi       s22, s18, #8704
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #6720
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s22, #64
    v.st.w       [s10, #0], v1
    s.addi       s10, s18, #6784
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s22, #128
    v.st.w       [s14, #0], v1
    s.addi       s14, s18, #6848
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s22, #192
    v.st.w       [s24, #0], v1
    fence.acq_rel.device
    s.addi       s23, s18, #6912
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s22, #256
    v.st.w       [s22, #0], v1
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s18, #6976
    v.st.w       [s20, #0], v1
    s.addi       s20, s22, #320
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #7040
    v.st.w       [s4, #0], v1
    s.addi       s4, s22, #384
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #7104
    v.st.w       [s16, #0], v1
    s.addi       s16, s22, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #7168
    v.st.w       [s15, #0], v1
    s.addi       s15, s22, #512
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s18, #7232
    v.st.w       [s20, #0], v1
    s.addi       s20, s22, #576
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #7296
    v.st.w       [s4, #0], v1
    s.addi       s4, s22, #640
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #7360
    v.st.w       [s16, #0], v1
    s.addi       s16, s22, #704
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #7424
    v.st.w       [s15, #0], v1
    s.addi       s15, s22, #768
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s18, #7488
    v.st.w       [s20, #0], v1
    s.addi       s20, s22, #832
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #7552
    v.st.w       [s4, #0], v1
    s.addi       s4, s22, #896
    s.addi       s24, s22, #960
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #7616
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #7680
    v.ld.w       v1, [s23, #0]
    s.addi       s22, s18, #0
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #7744
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s18, #64
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #7808
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #128
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #7872
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #192
    v.st.w       [s24, #0], v1
    fence.acq_rel.device
    s.addi       s23, s18, #7936
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #256
    v.st.w       [s22, #0], v1
    s.addi       s22, s18, #8000
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s18, #320
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #8064
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #384
    v.st.w       [s10, #0], v1
    s.addi       s10, s18, #8128
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #448
    v.st.w       [s14, #0], v1
    s.addi       s14, s18, #8192
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #512
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #8256
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s18, #576
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #8320
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s18, #640
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #8384
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #704
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #8448
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #768
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #8512
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #832
    v.st.w       [s22, #0], v1
    s.addi       s22, s18, #8576
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s18, #896
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #8640
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #960
    v.st.w       [s10, #0], v1
    s.addi       s10, s18, #8704
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #1024
    v.st.w       [s14, #0], v1
    s.addi       s14, s18, #8768
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #1088
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #8832
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s18, #1152
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #8896
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s18, #1216
    v.st.w       [s20, #0], v1
    fence.acq_rel.device
    s.addi       s20, s18, #8960
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #1280
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #9024
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #1344
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #9088
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s18, #1408
    v.st.w       [s22, #0], v1
    s.addi       s22, s18, #9152
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s18, #1472
    v.st.w       [s11, #0], v1
    s.addi       s11, s18, #9216
    s.add        s24, s19, s1
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s18, #1536
    v.st.w       [s10, #0], v1
    s.addi       s10, s18, #9280
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s18, #1600
    v.st.w       [s14, #0], v1
    s.addi       s14, s18, #9344
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s18, #1664
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #9408
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s18, #1728
    v.st.w       [s15, #0], v1
    s.addi       s15, s18, #9472
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s18, #1792
    v.st.w       [s20, #0], v1
    s.addi       s20, s18, #9536
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s18, #1856
    v.st.w       [s4, #0], v1
    s.addi       s4, s18, #9600
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s18, #1920
    v.st.w       [s23, #0], v1
    s.addi       s23, s18, #9664
    s.addi       s25, s18, #1984
    v.ld.w       v1, [s16, #0]
    s.movz       s16, #1
    v.st.w       [s22, #0], v1
    v.ld.w       v1, [s15, #0]
    v.st.w       [s11, #0], v1
    v.ld.w       v1, [s20, #0]
    v.st.w       [s10, #0], v1
    v.ld.w       v1, [s4, #0]
    v.st.w       [s14, #0], v1
    v.ld.w       v1, [s23, #0]
    v.st.w       [s25, #0], v1
    fence.acq_rel.device
    s.mov        s19, s24
    br.nz        s16, for_5
endfor_6:
    s.movz       s1, #0
    s.movz       s3, #128
    s.add        s4, s1, s8                      // the tile origin
    v.splat      v1, s3
    v.splat      v2, s4
    v.movi       v3, #1
    v.movi       v4, #0
    s.movz       s1, #0
    s.movz       s3, #32768
    v.cmp.lt     p1, v2, v1
    @p1 v.sel        v2, v3, v4
    s.add        s7, s1, s5                      // the tile origin
    s.mul        s1, s12, s3
    s.muli       s3, s5, #2                      // a runtime tile origin, x2
    v.splat      v3, s7
    s.addi       s5, s4, #1
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s7, #0
    s.muli       s10, s8, #512                   // a runtime tile origin, x512
    v.splat      v4, s5
    v.extract    s5, v2, #0
    a.vread      v2, a0, s7
    s.movz       s7, #256
    v.splat      v5, s5
    v.movi       v6, #0
    v.add        v7, v0, v3
    v.splat      v0, s7
    v.movi       v3, #1
    v.movi       v8, #0
    s.muli       s5, s1, #2                      // a runtime tile origin, x2
    s.add        s1, s9, s3                      // the tile origin
    v.cmp.lt     p1, v4, v1
    v.splat      v4, s12
    vf.cvt.f32.bf16 v9, v2
    v.cmp.ne     p2, v5, v6
    v.splat      v2, s6
    v.cmp.lt     p3, v7, v0
    @p1 v.sel        v0, v3, v8
    s.add        s3, s1, s10                     // the tile origin
    p.and        p1, p2, p3
    v.cmp.lt     p2, v4, v2
    s.add        s1, s3, s5                      // the tile origin
    s.addi       s3, s4, #2
    p.and        p4, p1, p2
    s.movz       s5, #1
    v.extract    s6, v0, #0
    v.splat      v0, s3
    @p4 v.st.h       [s1, #0], v9
    a.vread      v2, a0, s5
    v.splat      v3, s6
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v0, v1
    vf.cvt.f32.bf16 v0, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #3
    s.addi       s5, s1, #512                    // row 1
    p.and        p4, p1, p2
    s.movz       s6, #2
    v.extract    s7, v2, #0
    v.splat      v2, s3
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v1
    vf.cvt.f32.bf16 v2, v0
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v0, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #4
    s.addi       s5, s1, #1024                   // row 2
    p.and        p4, p1, p2
    s.movz       s6, #3
    v.extract    s7, v0, #0
    v.splat      v0, s3
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v0, v1
    vf.cvt.f32.bf16 v0, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #5
    s.addi       s5, s1, #1536                   // row 3
    p.and        p4, p1, p2
    s.movz       s6, #4
    v.extract    s7, v2, #0
    v.splat      v2, s3
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v1
    vf.cvt.f32.bf16 v2, v0
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v0, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #6
    s.addi       s5, s1, #2048                   // row 4
    p.and        p4, p1, p2
    s.movz       s6, #5
    v.extract    s7, v0, #0
    v.splat      v0, s3
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v0, v1
    vf.cvt.f32.bf16 v0, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #7
    s.addi       s5, s1, #2560                   // row 5
    p.and        p4, p1, p2
    s.movz       s6, #6
    v.extract    s7, v2, #0
    v.splat      v2, s3
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v1
    vf.cvt.f32.bf16 v2, v0
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v0, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #8
    s.addi       s5, s1, #3072                   // row 6
    p.and        p4, p1, p2
    s.movz       s6, #7
    v.extract    s7, v0, #0
    v.splat      v0, s3
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v0, v1
    vf.cvt.f32.bf16 v0, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #9
    s.addi       s5, s1, #3584                   // row 7
    p.and        p4, p1, p2
    s.movz       s6, #8
    v.extract    s7, v2, #0
    v.splat      v2, s3
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v1
    vf.cvt.f32.bf16 v2, v0
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v0, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #10
    s.addi       s5, s1, #4096                   // row 8
    p.and        p4, p1, p2
    s.movz       s6, #9
    v.extract    s7, v0, #0
    v.splat      v0, s3
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v0, v1
    vf.cvt.f32.bf16 v0, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #11
    s.addi       s5, s1, #4608                   // row 9
    p.and        p4, p1, p2
    s.movz       s6, #10
    v.extract    s7, v2, #0
    v.splat      v2, s3
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v1
    vf.cvt.f32.bf16 v2, v0
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v0, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #12
    s.addi       s5, s1, #5120                   // row 10
    p.and        p4, p1, p2
    s.movz       s6, #11
    v.extract    s7, v0, #0
    v.splat      v0, s3
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v0, v1
    vf.cvt.f32.bf16 v0, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #13
    s.addi       s5, s1, #5632                   // row 11
    p.and        p4, p1, p2
    s.movz       s6, #12
    v.extract    s7, v2, #0
    v.splat      v2, s3
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v1
    vf.cvt.f32.bf16 v2, v0
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v0, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #14
    s.addi       s5, s1, #6144                   // row 12
    p.and        p4, p1, p2
    s.movz       s6, #13
    v.extract    s7, v0, #0
    v.splat      v0, s3
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v0, v1
    vf.cvt.f32.bf16 v0, v2
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v2, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s4, #15
    s.addi       s4, s1, #6656                   // row 13
    p.and        p4, p1, p2
    s.movz       s5, #14
    v.extract    s6, v2, #0
    v.splat      v2, s3
    @p4 v.st.h       [s4, #0], v0
    a.vread      v0, a0, s5
    v.splat      v3, s6
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v1
    vf.cvt.f32.bf16 v1, v0
    v.cmp.ne     p4, v3, v4
    @p1 v.sel        v0, v5, v6
    p.and        p1, p4, p3
    s.addi       s3, s1, #7168                   // row 14
    p.and        p4, p1, p2
    s.movz       s4, #15
    v.extract    s5, v0, #0
    @p4 v.st.h       [s3, #0], v1
    a.vread      v0, a0, s4
    v.splat      v1, s5
    v.movi       v2, #0
    vf.cvt.f32.bf16 v3, v0
    s.addi       s3, s1, #7680                   // row 15
    v.cmp.ne     p1, v1, v2
    p.and        p4, p1, p3
    p.and        p1, p4, p2
    @p1 v.st.h       [s3, #0], v3
__rctx_next:
    exit
