#!/bin/bash
# After the sensitivity runs: transfer-engine occupancy from Chrome trace spans (matmul medium).
W=~/r41-pmac-model-work
while [ ! -f $W/runs/sens.done ]; do sleep 30; done
MONITOR=trace $W/tools/run_cfg.sh t-g1-pf0 trace-g1-pf0 14-15 1 op.matmul/medium/fp16-m128-k192-n128 &
MONITOR=trace $W/tools/run_cfg.sh t-g2g4-pf1 trace-g2g4-pf1 16-17 1 op.matmul/medium/fp16-m128-k192-n128
wait
echo TRACE-DONE > $W/runs/trace.done
