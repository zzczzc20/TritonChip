    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    .li       s1, #-1
    .li       s6, #-1
    .li       s7, #-1
    .li       s8, #-1
    .li       s9, #-1
    .li       s10, #-1
    .li       s11, #-1
    .li       s12, #-1
    .li       s13, #-1
    .li       s14, #-1
    .li       s15, #-1
    .li       s16, #-1
    s.shli       s17, s4, #4                     // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s17
    v.add        v2, v1, v0
    v.movi       v0, #16
    v.movi       v1, #0
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p2, v0, v1
    v.sub        v3, v1, v2
    @p1 v.sel        v4, v3, v2
    v.sub        v3, v1, v0
    @p2 v.sel        v5, v3, v0
    v.movi       v3, #15
    v.and        v5, v4, v3
    v.sub        v3, v1, v5
    @p1 v.sel        v1, v3, v5
    v.movi       v3, #0
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v0, v3
    v.sub        v4, v3, v2
    @p1 v.sel        v5, v4, v2
    v.sub        v4, v3, v0
    @p2 v.sel        v6, v4, v0
    v.movi       v4, #4
    v.lshr       v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.movi       v4, #0
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v0, v4
    v.sub        v5, v4, v3
    @p1 v.sel        v6, v5, v3
    v.sub        v3, v4, v0
    @p2 v.sel        v5, v3, v0
    v.movi       v0, #15
    v.and        v3, v6, v0
    v.sub        v0, v4, v3
    @p1 v.sel        v4, v0, v3
    v.movi       v0, #256
    v.movi       v3, #0
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v0, v3
    v.sub        v5, v3, v2
    @p1 v.sel        v6, v5, v2
    v.sub        v5, v3, v0
    @p2 v.sel        v7, v5, v0
    v.movi       v0, #8
    v.lshr       v5, v6, v0
    v.sub        v0, v3, v5
    @p1 v.sel        v3, v0, v5
    v.movi       v0, #4
    v.movi       v5, #0
    v.cmp.lt     p1, v3, v5
    v.cmp.lt     p2, v0, v5
    v.sub        v6, v5, v3
    @p1 v.sel        v7, v6, v3
    v.sub        v3, v5, v0
    @p2 v.sel        v6, v3, v0
    v.movi       v0, #3
    v.and        v3, v7, v0
    v.sub        v0, v5, v3
    @p1 v.sel        v5, v0, v3
    v.movi       v0, #1024
    v.movi       v3, #0
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v0, v3
    v.sub        v6, v3, v2
    @p1 v.sel        v7, v6, v2
    v.sub        v2, v3, v0
    @p2 v.sel        v6, v2, v0
    v.movi       v0, #10
    v.lshr       v2, v7, v0
    v.sub        v0, v3, v2
    @p1 v.sel        v3, v0, v2
    v.movi       v0, #64
    v.mul        v2, v4, v0
    v.add        v0, v1, v2
    v.movi       v2, #1040
    v.mul        v6, v5, v2
    v.add        v2, v0, v6
    v.movi       v0, #4096
    v.mul        v5, v3, v0
    v.add        v0, v2, v5
    v.ld.gather.w v2, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.sub        v0, v1, v4
    v.movi       v3, #0
    v.movi       v5, #0
    v.extract    s2, v0, #0
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #0
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #0
    v.extract    s2, v0, #1
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #1
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #1
    v.extract    s2, v0, #2
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #2
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #2
    v.extract    s2, v0, #3
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #3
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #3
    v.extract    s2, v0, #4
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #4
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #4
    v.extract    s2, v0, #5
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #5
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #5
    v.extract    s2, v0, #6
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #6
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #6
    v.extract    s2, v0, #7
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #7
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #7
    v.extract    s2, v0, #8
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #8
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #8
    v.extract    s2, v0, #9
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #9
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #9
    v.extract    s2, v0, #10
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #10
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #10
    v.extract    s2, v0, #11
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #11
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #11
    v.extract    s2, v0, #12
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #12
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #12
    v.extract    s2, v0, #13
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #13
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #13
    v.extract    s2, v0, #14
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #14
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #14
    v.extract    s2, v0, #15
    s.shli       s4, s2, #32
    s.ashri      s2, s4, #32
    v.insert     v3, s2, #15
    s.lshri      s4, s2, #32
    v.insert     v5, s4, #15
    v.movi       v0, #0
    v.extract    s2, v3, #0
    v.extract    s4, v5, #0
    s.shli       s18, s4, #32
    s.or         s4, s2, s18
    s.cmp.le     s2, s4, s1
    v.insert     v0, s2, #0
    v.extract    s2, v3, #1
    v.extract    s4, v5, #1
    s.shli       s18, s4, #32
    s.or         s4, s2, s18
    s.cmp.le     s2, s4, s1
    v.insert     v0, s2, #1
    v.extract    s2, v3, #2
    v.extract    s4, v5, #2
    s.shli       s18, s4, #32
    s.or         s4, s2, s18
    s.cmp.le     s2, s4, s1
    v.insert     v0, s2, #2
    v.extract    s2, v3, #3
    v.extract    s4, v5, #3
    s.shli       s18, s4, #32
    s.or         s4, s2, s18
    s.cmp.le     s2, s4, s1
    v.insert     v0, s2, #3
    v.extract    s2, v3, #4
    v.extract    s4, v5, #4
    s.shli       s18, s4, #32
    s.or         s4, s2, s18
    s.cmp.le     s2, s4, s1
    v.insert     v0, s2, #4
    v.extract    s1, v3, #5
    v.extract    s2, v5, #5
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.cmp.le     s1, s2, s6
    v.insert     v0, s1, #5
    v.extract    s1, v3, #6
    v.extract    s2, v5, #6
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.cmp.le     s1, s2, s7
    v.insert     v0, s1, #6
    v.extract    s1, v3, #7
    v.extract    s2, v5, #7
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.cmp.le     s1, s2, s8
    v.insert     v0, s1, #7
    v.extract    s1, v3, #8
    v.extract    s2, v5, #8
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.cmp.le     s1, s2, s9
    v.insert     v0, s1, #8
    v.extract    s1, v3, #9
    v.extract    s2, v5, #9
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.cmp.le     s1, s2, s10
    v.insert     v0, s1, #9
    v.extract    s1, v3, #10
    v.extract    s2, v5, #10
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.cmp.le     s1, s2, s11
    v.insert     v0, s1, #10
    v.extract    s1, v3, #11
    v.extract    s2, v5, #11
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.cmp.le     s1, s2, s12
    v.insert     v0, s1, #11
    v.extract    s1, v3, #12
    v.extract    s2, v5, #12
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.cmp.le     s1, s2, s13
    v.insert     v0, s1, #12
    v.extract    s1, v3, #13
    v.extract    s2, v5, #13
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.cmp.le     s1, s2, s14
    v.insert     v0, s1, #13
    v.extract    s1, v3, #14
    v.extract    s2, v5, #14
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.cmp.le     s1, s2, s15
    v.insert     v0, s1, #14
    v.extract    s1, v3, #15
    v.extract    s2, v5, #15
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.cmp.le     s1, s2, s16
    v.insert     v0, s1, #15
    v.movi       v3, #0
    v.cmp.ne     p1, v0, v3
    v.movi       v0, #0
    @p1 v.sel        v3, v2, v0
    vf.neg       v0, v3
    v.movi       v2, #255
    v.and        v3, v4, v2
    v.movi       v2, #255
    v.and        v4, v1, v2
    v.cmp.eq     p1, v3, v4
    v.movi       v1, #1
    v.movi       v2, #0
    @p1 v.sel        v3, v1, v2
    vf.cvt.u32.f32 v1, v3
    vf.add       v2, v1, v0
    s.shli       s1, s17, #2                     // element offset -> bytes (x4)
    s.add        s2, s3, s1                      // &out_ptr0[...]
    v.st.w       [s2, #0], v0
    s.add        s2, s5, s1                      // &out_ptr1[...]
    v.st.w       [s2, #0], v2
__rctx_next:
    exit
