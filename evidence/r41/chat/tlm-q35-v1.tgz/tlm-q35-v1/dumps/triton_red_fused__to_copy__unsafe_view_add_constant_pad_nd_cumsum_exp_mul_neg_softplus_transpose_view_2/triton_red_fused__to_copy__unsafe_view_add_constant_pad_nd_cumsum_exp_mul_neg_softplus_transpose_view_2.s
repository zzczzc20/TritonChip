    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #1
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.shli       s5, s4, #1                      // element offset -> bytes (x2)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    v.movi       v2, #0
    .li       s2, #1069066811
    v.splat      v3, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p1, v0, v1
    .li       s2, #1060205080
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #2143289344
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v4, #0
    s.movz       s2, #0
    s.add        s6, s3, s5                      // &in_ptr0[...]
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.movz       s7, #64
    s.movz       s8, #16
    v.splat      v5, s4
    v.iota       v5                              // arange(0, VLEN)
    s.addi       s9, s2, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v6, [s6, v2]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v6
    s.ld.d       s6, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    vf.mul       v6, v2, v3
    v.exp2.approx v7, v6                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v3, v6                  // the exact rounding error of x*log2(e)
    s.ld.d       s10, [s1, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    vf.mul       v2, v8, v0
    s.ld.d       s11, [s1, #32]                  // out_ptr2: device_ptr64 at arg_base+32
    s.ld.d       s12, [s1, #40]                  // out_ptr3: device_ptr64 at arg_base+40
    v.mov        v4, v1
    vf.fma       v1, v7, v2, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v2, v1, v7
    vf.neg       v1, v2
for_1:
    s.cmp.ge     s1, s9, s7
    br.nz        s1, endfor_2
    v.splat      v2, s9
    v.add        v6, v2, v5
    v.movi       v2, #64
    v.cmp.lt     p1, v6, v2
    v.movi       v2, #0
    v.movi       v7, #0
    v.extract    s1, v6, #0
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #0
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #0
    v.extract    s1, v6, #1
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #1
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #1
    v.extract    s1, v6, #2
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #2
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #2
    v.extract    s1, v6, #3
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #3
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #3
    v.extract    s1, v6, #4
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #4
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #4
    v.extract    s1, v6, #5
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #5
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #5
    v.extract    s1, v6, #6
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #6
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #6
    v.extract    s1, v6, #7
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #7
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #7
    v.extract    s1, v6, #8
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #8
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #8
    v.extract    s1, v6, #9
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #9
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #9
    v.extract    s1, v6, #10
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #10
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #10
    v.extract    s1, v6, #11
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #11
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #11
    v.extract    s1, v6, #12
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #12
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #12
    v.extract    s1, v6, #13
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #13
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #13
    v.extract    s1, v6, #14
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #14
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #14
    v.extract    s1, v6, #15
    s.shli       s13, s1, #32
    s.ashri      s1, s13, #32
    v.insert     v2, s1, #15
    s.lshri      s13, s1, #32
    v.insert     v7, s13, #15
    v.movi       v8, #0
    v.extract    s1, v2, #0
    v.extract    s13, v7, #0
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #0
    v.extract    s1, v2, #1
    v.extract    s13, v7, #1
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #1
    v.extract    s1, v2, #2
    v.extract    s13, v7, #2
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #2
    v.extract    s1, v2, #3
    v.extract    s13, v7, #3
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #3
    v.extract    s1, v2, #4
    v.extract    s13, v7, #4
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #4
    v.extract    s1, v2, #5
    v.extract    s13, v7, #5
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #5
    v.extract    s1, v2, #6
    v.extract    s13, v7, #6
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #6
    v.extract    s1, v2, #7
    v.extract    s13, v7, #7
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #7
    v.extract    s1, v2, #8
    v.extract    s13, v7, #8
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #8
    v.extract    s1, v2, #9
    v.extract    s13, v7, #9
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #9
    v.extract    s1, v2, #10
    v.extract    s13, v7, #10
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #10
    v.extract    s1, v2, #11
    v.extract    s13, v7, #11
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #11
    v.extract    s1, v2, #12
    v.extract    s13, v7, #12
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #12
    v.extract    s1, v2, #13
    v.extract    s13, v7, #13
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #13
    v.extract    s1, v2, #14
    v.extract    s13, v7, #14
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #14
    v.extract    s1, v2, #15
    v.extract    s13, v7, #15
    s.shli       s14, s13, #32
    s.or         s13, s1, s14
    s.movz       s1, #15
    s.cmp.lt     s14, s13, s1
    v.insert     v8, s14, #15
    v.movi       v2, #0
    v.cmp.ne     p2, v8, v2
    s.movz       s1, #32
    v.movi       v2, #32
    v.mul        v7, v6, v2
    v.splat      v2, s4
    v.add        v8, v2, v7
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v8]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v7, v2
    s.add        s1, s6, s5                      // &in_ptr2[...]
    v.movi       v2, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v8, [s1, v2]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v8
    vf.add       v8, v7, v2
    .li       s1, #1101004800
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.gt    p3, v8, v2
    vf.mul       v2, v8, v3
    vf.fms       v7, v8, v3, v2                  // the exact rounding error of x*log2(e)
    v.exp2.approx v9, v2                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v2, v7, v0
    vf.fma       v7, v9, v2, v9                  // 2**t * 2**d
    vf.cmp.o     p4, v7, v7
    @p4 v.sel        v2, v7, v9
    .li       s1, #1065353216
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v9, v2, v7
    .li       s1, #4913933
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v11, v9, v10
    v.movi       v9, #23
    v.lshr       v10, v11, v9
    v.movi       v9, #127
    v.sub        v11, v10, v9
    v.movi       v9, #25
    v.min.s      v10, v11, v9
    v.movi       v9, #23
    v.shl        v12, v11, v9
    v.sub        v9, v2, v12
    v.movi       v12, #127
    v.sub        v13, v12, v10
    v.movi       v10, #23
    v.shl        v12, v13, v10
    vf.sub       v10, v12, v7
    vf.add       v7, v9, v10                     // f = x*2**-k + (2**-k - 1)
    vf.sub       v12, v7, v9
    vf.sub       v13, v7, v12
    vf.sub       v14, v9, v13
    vf.sub       v9, v10, v12
    vf.add       v10, v14, v9                    // TwoSum: the exact error of f
    vf.mul       v9, v7, v7
    .li       s1, #1032451959
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3186590336
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v14, v12, v7, v13
    .li       s1, #1039390164
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v13, v14, v7, v12
    .li       s1, #3187543230
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v14, v13, v7, v12
    .li       s1, #1041339458
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v13, v14, v7, v12
    .li       s1, #3190467997
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v14, v13, v7, v12
    .li       s1, #1045222078
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v13, v14, v7, v12
    .li       s1, #3196059656
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v14, v13, v7, v12
    .li       s1, #1051372195
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v13, v14, v7, v12
    .li       s1, #3204448256
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v14, v13, v7, v12
    vf.cvt.s32.f32 v12, v11
    vf.neg       v11, v7
    vf.fma       v13, v11, v10, v10              // f_lo/(1 + f_hi)
    .li       s1, #901758606
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v11, v12, v10, v13
    vf.fma       v10, v9, v14, v11
    .li       s1, #1060205056
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v11, v12, v9                    // k*ln2_hi, exact
    vf.add       v9, v11, v7
    vf.sub       v12, v9, v11
    vf.sub       v11, v7, v12                    // Fast2Sum
    vf.add       v7, v11, v10
    vf.add       v10, v9, v7
    vf.abs       v7, v2
    .li       s1, #855638016
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.lt    p4, v7, v9
    @p4 v.sel        v7, v2, v10
    .li       s1, #3212836864
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.eq    p4, v2, v9
    .li       s1, #4286578688
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v11, v10, v7
    vf.cmp.lt    p4, v2, v9
    .li       s1, #2143289344
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v9, v7, v11
    .li       s1, #2139095040
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.eq    p4, v2, v7
    @p4 v.sel        v7, v2, v9
    vf.cmp.uo    p4, v2, v2
    @p4 v.sel        v9, v2, v7
    @p3 v.sel        v2, v8, v9
    v.extract    s1, v1, #0
    v.splat      v7, s1
    vf.mul       v8, v7, v2
    v.movi       v2, #0
    @p2 v.sel        v7, v8, v2
    v.extract    s1, v7, #0
    v.splat      v2, s1
    v.extract    s1, v7, #1
    v.splat      v8, s1
    v.extract    s1, v7, #2
    v.splat      v9, s1
    v.extract    s1, v7, #3
    v.splat      v10, s1
    v.extract    s1, v7, #4
    v.splat      v11, s1
    v.extract    s1, v7, #5
    v.splat      v12, s1
    v.extract    s1, v7, #6
    v.splat      v13, s1
    v.extract    s1, v7, #7
    v.splat      v14, s1
    v.extract    s1, v7, #8
    v.splat      v15, s1
    v.extract    s1, v7, #9
    v.splat      v16, s1
    v.extract    s1, v7, #10
    v.splat      v17, s1
    v.extract    s1, v7, #11
    v.splat      v18, s1
    v.extract    s1, v7, #12
    v.splat      v19, s1
    v.extract    s1, v7, #13
    v.splat      v20, s1
    v.extract    s1, v7, #14
    v.splat      v21, s1
    v.extract    s1, v7, #15
    v.splat      v7, s1
    vf.add       v22, v2, v8
    vf.add       v8, v22, v9
    vf.add       v9, v8, v10
    vf.add       v10, v9, v11
    vf.add       v11, v10, v12
    vf.add       v12, v11, v13
    vf.add       v13, v12, v14
    vf.add       v14, v13, v15
    vf.add       v15, v14, v16
    vf.add       v16, v15, v17
    vf.add       v17, v16, v18
    vf.add       v18, v17, v19
    vf.add       v19, v18, v20
    vf.add       v20, v19, v21
    vf.add       v21, v20, v7
    v.movi       v7, #0
    // one value per row into one vector (ISA 0x09)
    v.extract    s1, v2, #0
    v.insert     v7, s1, #0
    v.extract    s1, v22, #0
    v.insert     v7, s1, #1
    v.extract    s1, v8, #0
    v.insert     v7, s1, #2
    v.extract    s1, v9, #0
    v.insert     v7, s1, #3
    v.extract    s1, v10, #0
    v.insert     v7, s1, #4
    v.extract    s1, v11, #0
    v.insert     v7, s1, #5
    v.extract    s1, v12, #0
    v.insert     v7, s1, #6
    v.extract    s1, v13, #0
    v.insert     v7, s1, #7
    v.extract    s1, v14, #0
    v.insert     v7, s1, #8
    v.extract    s1, v15, #0
    v.insert     v7, s1, #9
    v.extract    s1, v16, #0
    v.insert     v7, s1, #10
    v.extract    s1, v17, #0
    v.insert     v7, s1, #11
    v.extract    s1, v18, #0
    v.insert     v7, s1, #12
    v.extract    s1, v19, #0
    v.insert     v7, s1, #13
    v.extract    s1, v20, #0
    v.insert     v7, s1, #14
    v.extract    s1, v21, #0
    v.insert     v7, s1, #15
    v.movi       v2, #15
    v.cmp.eq     p2, v5, v2
    v.movi       v2, #1
    v.movi       v8, #0
    @p2 v.sel        v9, v2, v8
    v.mul        v2, v7, v9
    v.reduce.add s1, v2
    v.splat      v2, s1
    vf.add       v8, v4, v2
    v.extract    s1, v4, #0
    v.splat      v9, s1
    vf.add       v10, v9, v7
    v.splat      v9, s9
    v.splat      v11, s2
    v.cmp.gt     p2, v9, v11
    @p2 v.sel        v9, v10, v7
    @p2 v.sel        v7, v8, v2
    vf.mul       v2, v9, v3
    vf.fms       v8, v9, v3, v2                  // the exact rounding error of x*log2(e)
    v.exp2.approx v10, v2                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v2, v8, v0
    vf.fma       v8, v10, v2, v10                // 2**t * 2**d
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v2, v8, v10
    s.mul        s1, s4, s7
    v.splat      v8, s1
    v.add        v10, v6, v8
    s.add        s13, s9, s1
    s.shli       s1, s13, #2                     // element offset -> bytes (x4)
    s.add        s13, s10, s1                    // &out_ptr1[...]
    @p1 v.st.w       [s13, #0], v9
    s.add        s13, s11, s1                    // &out_ptr2[...]
    @p1 v.st.w       [s13, #0], v2
    s.add        s13, s12, s1                    // &out_ptr3[...]
    @p1 v.st.w       [s13, #0], v2
    v.movi       v2, #0
    v.mov        v2, v7
    v.mov        v4, v2
    s.add        s1, s9, s8
    s.mov        s9, s1
    s.movz       s1, #1
    br.nz        s1, for_1
endfor_2:
__rctx_next:
    exit
