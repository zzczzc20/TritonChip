#!/bin/bash
# rtl.sh TAG: RTL bench + addr64 compiler suite with RTL execution + X8 RTL tests, in tree-TAG
TAG=$1; W=$HOME/r41-sw-work/reg-$TAG; C=$HOME/r41-sw-work/tree-$TAG
source ~/tc_env/env.sh >/dev/null 2>&1; cd $C
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$C/python:$C/compiler/python
P=$HOME/tc_env/torchenv/bin/python
taskset -c 10-11 nice make core PYTHON=$P > $W/make-core.log 2>&1; echo make_core=$? >> $W/status
taskset -c 10-11 nice $P -m unittest discover -s compiler/test -p test_addr64.py -v > $W/test_addr64_rtl.log 2>&1; echo test_addr64_rtl=$? >> $W/status
taskset -c 10-11 nice make r41-xpose8-rtl PYTHON=$P > $W/xpose8-rtl.log 2>&1; echo xpose8_rtl=$? >> $W/status
echo RTLDONE >> $W/status
