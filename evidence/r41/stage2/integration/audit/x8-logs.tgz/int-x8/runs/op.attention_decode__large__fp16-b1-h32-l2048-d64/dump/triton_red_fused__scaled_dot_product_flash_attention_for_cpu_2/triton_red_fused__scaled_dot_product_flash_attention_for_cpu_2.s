    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    s.rdspecial  s1, role_id
    s.movz       s2, #256
    v.sub        v2, v1, v0
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    v.cmp.lt     p1, v0, v1
    @p1 v.sel        v3, v2, v0
    v.movi       v2, #6
    s.ld.d       s1, [s3, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.lshr       v4, v3, v2
    s.rdspecial  s2, arg_base
    s.movz       s3, #1
    s.add        s6, s1, s5                      // this context's own scratch
    v.sub        v2, v1, v4
    s.ld.d       s1, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v3                              // arange(0, VLEN)
    s.addi       s5, s6, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.ld.d       s6, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.splat      v5, s3
    s.movz       s3, #32
    s.movz       s7, #2048
    s.movz       s8, #8192
    s.movz       s9, #4
    .li       s10, #68719476737
    .li       s11, #2207613190144
    @p1 v.sel        v6, v2, v4
    s.ld.d       s12, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    v.cmp.lt     p1, v3, v5
    s.movz       s13, #1
    s.ld.d       s14, [s2, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    v.movi       v2, #64
    s.movz       s15, #0
    s.ld.d       s16, [s2, #32]                  // out_ptr1: device_ptr64 at arg_base+32
    v.movi       v3, #0
    v.iota       v4                              // arange(0, VLEN)
    s.st.d       [s5, #0], s6
    v.cmp.lt     p2, v0, v3
    v.splat      v5, s13
    s.st.d       [s5, #8], s3
    v.sub        v7, v1, v2
    v.movi       v8, #0
    s.st.d       [s5, #16], s7
    v.cmp.lt     p3, v2, v1
    v.cmp.lt     p4, v4, v5
    s.st.d       [s5, #48], s8
    s.movz       s2, #0
    v.sub        v1, v3, v0
    s.st.d       [s5, #56], s9
    @p2 v.sel        v4, v1, v0
    v.movi       v0, #63
    s.st.d       [s5, #88], s10
    v.and        v1, v4, v0
    v.sub        v0, v3, v2
    s.st.d       [s5, #104], s11
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v4, [s1, v6]              // index is in elements (ISA sec 9.1)
    v.sub        v5, v3, v1
    v.movi       v9, #0
    v.movi       v10, #0
    v.cmp.lt     p1, v2, v3
    s.movz       s1, #2048
    s.movz       s2, #16
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v11, #1
    @p3 v.sel        v11, v7, v2
    v.cmp.ne     p3, v4, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s12, v6]              // index is in elements (ISA sec 9.1)
    v.movi       v7, #1
    @p1 v.sel        v7, v0, v2
    @p2 v.sel        v0, v5, v1
    s.addi       s3, s15, #0
    v.mov        v10, v9
for_1:
    s.cmp.ge     s5, s3, s1
    br.nz        s5, endfor_2
    s.movz       s5, #0
    s.movz       s7, #0
    s.cmp.lt     s8, s4, s5
    s.movz       s5, #64
    s.sub        s9, s7, s8
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s10, s5, s7
    s.xor        s7, s4, s9
    s.sub        s11, s8, s10
    s.sub        s8, s7, s9
    s.xor        s7, s9, s11
    s.lshri      s9, s8, #6
    v.splat      v1, s3
    s.xor        s10, s9, s7
    v.iota       v2                              // arange(0, VLEN)
    s.sub        s12, s10, s7
    s.movz       s7, #2048
    s.muli       s10, s12, #8192
    s.movz       s13, #32
    s.muli       s15, s3, #4
    v.add        v5, v1, v2
    v.movi       v1, #0
    v.splat      v2, s7
    v.splat      v7, s12
    v.movi       v8, #0
    v.splat      v11, s13
    v.cmp.ge     p1, v5, v1
    v.cmp.lt     p2, v5, v2
    v.cmp.ge     p4, v7, v8
    v.cmp.lt     p5, v7, v11
    v.splat      v1, s3
    s.add        s7, s6, s10
    p.and        p6, p1, p2
    p.and        p1, p4, p5
    v.add        v2, v1, v3
    s.add        s10, s7, s15
    p.and        p2, p6, p1
    v.movi       v1, #64
    v.extract    s7, v0, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s10, #0]
    v.mul        v7, v2, v1
    v.splat      v1, s7
    v.movi       v8, #2048
    v.add        v11, v1, v7
    v.cmp.lt     p1, v2, v8
    .li       s7, #131072
    v.splat      v1, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v2, #1
    v.mul        v7, v6, v1
    v.movi       v1, #0
    v.extract    s7, v7, #0
    v.splat      v7, s7
    @p3 v.sel        v8, v2, v1
    v.add        v1, v11, v7
    v.movi       v2, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v7, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.eq     p2, v8, v2
    s.muli       s7, s9, #64
    s.xor        s9, s5, s11
    v.extract    s5, v4, #0
    s.sub        s10, s9, s11
    v.splat      v1, s5
    .li       s5, #1065353216
    v.splat      v2, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v8, v1                          // ISA 8.8: <= 2**-22 relative
    vf.cvt.f16.f32 v11, v7
    s.sub        s5, s8, s7
    v.movi       v7, #1
    v.movi       v12, #0
    v.movi       v13, #0
    @p2 v.sel        v14, v7, v12
    v.movi       v7, #0
    v.extract    s5, v14, #0
    v.splat      v12, s5
    s.add        s5, s3, s2
    v.cmp.ne     p2, v12, v13
    s.movz       s7, #1
    .li       s8, #131072
    vf.fms       v12, v1, v8, v2
    vf.fms       v1, v8, v12, v8
    vf.neg       v2, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v2, v2
    @p4 v.sel        v1, v2, v8
    vf.mul       v2, v5, v1                      // a/y as a refined reciprocal (ISA has no divide)
    @p2 v.sel        v1, v9, v2
    vf.mul       v2, v1, v11
    vf.add       v1, v10, v2
    @p1 v.sel        v2, v1, v10
    v.mov        v7, v2
    v.mov        v10, v7
    s.mov        s3, s5
    br.nz        s7, for_1
endfor_2:
    vf.reduce.add.b v0, v10
    v.movi       v1, #0
    s.movz       s1, #1
    vf.add       v2, v0, v1
    s.shli       s2, s4, #1                      // element offset -> bytes (x2)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    vf.cvt.f32.f16 v3, v2
    s.add        s1, s16, s2                     // &out_ptr1[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.h       [s1, #0], v3
__rctx_next:
    exit
