    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr3: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // in_ptr4: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // out_ptr1: device_ptr64 at arg_base+48
    s.movz       s1, #1
    s.rdspecial  s10, arg_base
    s.ld.d       s11, [s10, #72]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s10, role_id
    s.movz       s12, #768
    s.mul        s13, s10, s12
    s.add        s10, s11, s13                   // this context's own scratch
    s.addi       s11, s10, #0                    // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s2
    s.movz       s12, #64
    s.st.d       [s11, #8], s12
    s.movz       s12, #192
    s.st.d       [s11, #16], s12
    s.movz       s12, #384
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #8589934592
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d0, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s10, #256                  // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s6
    s.movz       s12, #64
    s.st.d       [s11, #8], s12
    s.movz       s12, #192
    s.st.d       [s11, #16], s12
    s.movz       s12, #384
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #8589934592
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d1, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s10, #512                  // TensorMap 2: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #0
    s.st.d       [s11, #0], s7
    s.movz       s10, #64
    s.st.d       [s11, #8], s10
    s.movz       s10, #192
    s.st.d       [s11, #16], s10
    s.movz       s10, #384
    s.st.d       [s11, #48], s10
    s.movz       s10, #2
    s.st.d       [s11, #56], s10
    .li       s10, #68719476737
    s.st.d       [s11, #88], s10
    .li       s10, #8589934592
    s.st.d       [s11, #104], s10
    fence.release.device
    td.load      d2, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s10, #0
    s.movz       s11, #192
    s.movz       s12, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.shli       s13, s4, #3                     // element offset -> bytes (x8)
    s.add        s14, s3, s13                    // &in_ptr0[...]
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s1
    v.cmp.lt     p1, v2, v3
    v.movi       v2, #1
    v.shl        v3, v1, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s1, s14, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s1, v3]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s10, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.mov        v4, v3
for_1:
    s.cmp.ge     s3, s1, s11
    br.nz        s3, endfor_2
    s.muli       s3, s4, #384
    v.splat      v3, s1
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s13, #192
    s.movz       s14, #64
    s.muli       s15, s4, #384
    v.splat      v6, s1
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s16, #192
    s.movz       s17, #64
    v.add        v8, v3, v5
    v.movi       v3, #0
    v.splat      v5, s13
    s.muli       s13, s1, #2
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s14
    s.muli       s14, s1, #2
    v.add        v12, v6, v7
    v.movi       v6, #0
    v.splat      v7, s16
    v.splat      v13, s4
    v.movi       v14, #0
    v.cmp.ge     p1, v8, v3
    v.splat      v3, s17
    v.cmp.lt     p2, v8, v5
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    v.cmp.ge     p5, v12, v6
    s.add        s16, s2, s3
    p.and        p6, p1, p2
    v.cmp.lt     p1, v12, v7
    p.and        p2, p3, p4
    v.cmp.ge     p3, v13, v14
    s.add        s3, s6, s15
    p.and        p4, p5, p1
    v.cmp.lt     p1, v13, v3
    p.and        p5, p3, p1
    s.add        s15, s16, s13
    p.and        p1, p6, p2
    s.add        s13, s3, s14
    p.and        p2, p4, p5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s15, #0]
    v.splat      v5, s1
    v.movi       v6, #192
    v.add        v7, v5, v0
    s.muli       s3, s4, #384
    v.cmp.lt     p1, v7, v6
    v.splat      v5, s1
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s14, #192
    s.movz       s15, #64
    s.muli       s16, s1, #2
    v.add        v8, v5, v6
    v.movi       v5, #0
    v.splat      v6, s14
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s15
    v.cmp.ge     p3, v8, v5
    v.cmp.lt     p4, v8, v6
    v.cmp.ge     p5, v9, v10
    s.add        s14, s7, s3
    p.and        p6, p3, p4
    v.cmp.lt     p3, v9, v11
    p.and        p4, p5, p3
    s.add        s3, s14, s16
    p.and        p3, p6, p4
    v.movi       v5, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v6, [s13, #0]
    vf.cvt.f16.f32 v8, v3
    v.extract    s13, v2, #0
    v.extract    s14, v2, #0
    s.shli       s15, s13, #32
    s.shli       s13, s14, #32
    v.extract    s14, v1, #0
    v.extract    s16, v1, #0
    s.or         s17, s14, s15
    s.movz       s14, #0
    s.or         s15, s16, s13
    s.movz       s13, #640
    s.cmp.ge     s16, s17, s14
    v.movi       v3, #0
    s.cmp.lt     s14, s15, s13
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s3, #0]
    v.insert     v5, s16, #0
    v.movi       v10, #0
    v.insert     v3, s14, #0
    v.movi       v11, #0
    v.cmp.ne     p2, v5, v10
    v.cmp.ne     p3, v3, v11
    p.and        p4, p2, p3
    v.movi       v3, #0
    v.movi       v5, #1
    vf.cvt.f16.f32 v10, v6
    s.movz       s3, #1
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v11, s3
    @p4 v.sel        v12, v3, v5
    v.cmp.lt     p2, v6, v11
    s.movz       s3, #0
    @p2 v.reduce.or  s13, v12
    s.cmp.eq     s14, s13, s3
    vf.cvt.f16.f32 v3, v9
    br.nz        s14, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s3, v2, #0
    s.shli       s13, s3, #32
    v.extract    s3, v1, #0
    s.or         s14, s3, s13
    s.movz       s3, #192
    v.extract    s13, v7, #0
    s.mul        s15, s14, s3
    s.shli       s3, s13, #32
    v.extract    s13, v7, #1
    s.ashri      s14, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #2
    v.movi       v5, #0
    v.movi       v6, #0
    s.lshri      s16, s15, #32
    v.movi       v9, #0
    v.movi       v11, #0
    s.lshri      s17, s14, #32
    s.ashri      s18, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #3
    v.insert     v5, s15, #0
    v.insert     v6, s16, #0
    v.insert     v9, s14, #0
    v.insert     v11, s17, #0
    s.lshri      s14, s18, #32
    s.ashri      s15, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #4
    v.insert     v9, s18, #1
    v.insert     v11, s14, #1
    s.lshri      s14, s15, #32
    s.ashri      s16, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #5
    v.insert     v9, s15, #2
    v.insert     v11, s14, #2
    s.lshri      s14, s16, #32
    s.ashri      s15, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #6
    v.insert     v9, s16, #3
    v.insert     v11, s14, #3
    s.lshri      s14, s15, #32
    s.ashri      s16, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #7
    v.insert     v9, s15, #4
    v.insert     v11, s14, #4
    s.lshri      s14, s16, #32
    s.ashri      s15, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #8
    v.insert     v9, s16, #5
    v.insert     v11, s14, #5
    s.lshri      s14, s15, #32
    s.ashri      s16, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #9
    v.insert     v9, s15, #6
    v.insert     v11, s14, #6
    s.lshri      s14, s16, #32
    s.ashri      s15, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #10
    v.insert     v9, s16, #7
    v.insert     v11, s14, #7
    s.lshri      s14, s15, #32
    s.ashri      s16, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #11
    v.insert     v9, s15, #8
    v.insert     v11, s14, #8
    s.lshri      s14, s16, #32
    s.ashri      s15, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #12
    v.insert     v9, s16, #9
    v.insert     v11, s14, #9
    s.lshri      s14, s15, #32
    s.ashri      s16, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #13
    v.insert     v9, s15, #10
    v.insert     v11, s14, #10
    s.lshri      s14, s16, #32
    s.ashri      s15, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #14
    v.insert     v9, s16, #11
    v.insert     v11, s14, #11
    s.lshri      s14, s15, #32
    s.ashri      s16, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v7, #15
    v.extract    s17, v6, #0
    v.insert     v9, s15, #12
    v.insert     v11, s14, #12
    s.lshri      s14, s16, #32
    s.ashri      s15, s3, #32
    s.shli       s3, s13, #32
    s.shli       s13, s17, #32
    v.extract    s17, v5, #0
    v.extract    s18, v6, #0
    v.insert     v9, s16, #13
    v.insert     v11, s14, #13
    s.lshri      s14, s15, #32
    s.ashri      s16, s3, #32
    s.or         s3, s17, s13
    s.shli       s13, s18, #32
    v.extract    s17, v5, #0
    v.extract    s18, v6, #0
    v.insert     v9, s15, #14
    v.insert     v11, s14, #14
    s.lshri      s14, s16, #32
    v.movi       v12, #0
    v.movi       v13, #0
    s.lshri      s15, s3, #32
    s.or         s19, s17, s13
    s.shli       s13, s18, #32
    v.extract    s17, v5, #0
    v.insert     v9, s16, #15
    v.extract    s16, v6, #0
    v.insert     v11, s14, #15
    v.insert     v12, s3, #0
    v.insert     v13, s15, #0
    s.lshri      s3, s19, #32
    s.or         s14, s17, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.extract    s16, v6, #0
    v.insert     v12, s19, #1
    v.insert     v13, s3, #1
    s.lshri      s3, s14, #32
    s.or         s17, s15, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.extract    s16, v6, #0
    v.insert     v12, s14, #2
    v.insert     v13, s3, #2
    s.lshri      s3, s17, #32
    s.or         s14, s15, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.extract    s16, v6, #0
    v.insert     v12, s17, #3
    v.insert     v13, s3, #3
    s.lshri      s3, s14, #32
    s.or         s17, s15, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.extract    s16, v6, #0
    v.insert     v12, s14, #4
    v.insert     v13, s3, #4
    s.lshri      s3, s17, #32
    s.or         s14, s15, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.extract    s16, v6, #0
    v.insert     v12, s17, #5
    v.insert     v13, s3, #5
    s.lshri      s3, s14, #32
    s.or         s17, s15, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.extract    s16, v6, #0
    v.insert     v12, s14, #6
    v.insert     v13, s3, #6
    s.lshri      s3, s17, #32
    s.or         s14, s15, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.extract    s16, v6, #0
    v.insert     v12, s17, #7
    v.insert     v13, s3, #7
    s.lshri      s3, s14, #32
    s.or         s17, s15, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.extract    s16, v6, #0
    v.insert     v12, s14, #8
    v.insert     v13, s3, #8
    s.lshri      s3, s17, #32
    s.or         s14, s15, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.extract    s16, v6, #0
    v.insert     v12, s17, #9
    v.insert     v13, s3, #9
    s.lshri      s3, s14, #32
    s.or         s17, s15, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.extract    s16, v6, #0
    v.insert     v12, s14, #10
    v.insert     v13, s3, #10
    s.lshri      s3, s17, #32
    s.or         s14, s15, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.extract    s16, v6, #0
    v.insert     v12, s17, #11
    v.insert     v13, s3, #11
    s.lshri      s3, s14, #32
    s.or         s17, s15, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.extract    s16, v6, #0
    v.insert     v12, s14, #12
    v.insert     v13, s3, #12
    s.lshri      s3, s17, #32
    s.or         s14, s15, s13
    s.shli       s13, s16, #32
    v.extract    s15, v5, #0
    v.insert     v12, s17, #13
    v.insert     v13, s3, #13
    s.lshri      s3, s14, #32
    s.or         s16, s15, s13
    v.insert     v12, s14, #14
    v.insert     v13, s3, #14
    s.lshri      s3, s16, #32
    v.insert     v12, s16, #15
    v.insert     v13, s3, #15
    v.extract    s3, v11, #0
    v.extract    s13, v13, #0
    s.shli       s14, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v9, #0
    v.extract    s15, v12, #0
    v.extract    s16, v11, #1
    v.extract    s17, v13, #1
    s.or         s18, s13, s14
    s.or         s13, s15, s3
    s.shli       s3, s16, #32
    s.shli       s14, s17, #32
    v.extract    s15, v9, #1
    v.extract    s16, v12, #1
    v.extract    s17, v11, #2
    v.movi       v5, #0
    s.add        s19, s18, s13
    v.extract    s13, v13, #2
    s.or         s18, s15, s3
    s.or         s3, s16, s14
    s.shli       s14, s17, #32
    s.shli       s15, s13, #32
    v.extract    s13, v9, #2
    v.extract    s16, v12, #2
    v.movi       v6, #0
    v.insert     v5, s19, #0
    s.lshri      s17, s19, #32
    s.add        s19, s18, s3
    v.extract    s3, v11, #3
    s.or         s18, s13, s14
    v.extract    s13, v13, #3
    s.or         s14, s16, s15
    s.shli       s15, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v9, #3
    v.insert     v6, s17, #0
    v.extract    s16, v12, #3
    v.insert     v5, s19, #1
    s.lshri      s17, s19, #32
    s.add        s19, s18, s14
    v.extract    s14, v11, #4
    s.or         s18, s13, s15
    v.extract    s13, v13, #4
    s.or         s15, s16, s3
    s.shli       s3, s14, #32
    s.shli       s14, s13, #32
    v.extract    s13, v9, #4
    v.insert     v6, s17, #1
    v.extract    s16, v12, #4
    v.insert     v5, s19, #2
    s.lshri      s17, s19, #32
    s.add        s19, s18, s15
    v.extract    s15, v11, #5
    s.or         s18, s13, s3
    v.extract    s3, v13, #5
    s.or         s13, s16, s14
    s.shli       s14, s15, #32
    s.shli       s15, s3, #32
    v.extract    s3, v9, #5
    v.insert     v6, s17, #2
    v.extract    s16, v12, #5
    v.insert     v5, s19, #3
    s.lshri      s17, s19, #32
    s.add        s19, s18, s13
    v.extract    s13, v11, #6
    s.or         s18, s3, s14
    v.extract    s3, v13, #6
    s.or         s14, s16, s15
    s.shli       s15, s13, #32
    s.shli       s13, s3, #32
    v.extract    s3, v9, #6
    v.insert     v6, s17, #3
    v.extract    s16, v12, #6
    v.insert     v5, s19, #4
    s.lshri      s17, s19, #32
    s.add        s19, s18, s14
    v.extract    s14, v11, #7
    s.or         s18, s3, s15
    v.extract    s3, v13, #7
    s.or         s15, s16, s13
    s.shli       s13, s14, #32
    s.shli       s14, s3, #32
    v.extract    s3, v9, #7
    v.insert     v6, s17, #4
    v.extract    s16, v12, #7
    v.insert     v5, s19, #5
    s.lshri      s17, s19, #32
    s.add        s19, s18, s15
    v.extract    s15, v11, #8
    s.or         s18, s3, s13
    v.extract    s3, v13, #8
    s.or         s13, s16, s14
    s.shli       s14, s15, #32
    s.shli       s15, s3, #32
    v.extract    s3, v9, #8
    v.insert     v6, s17, #5
    v.extract    s16, v12, #8
    v.insert     v5, s19, #6
    s.lshri      s17, s19, #32
    s.add        s19, s18, s13
    v.extract    s13, v11, #9
    s.or         s18, s3, s14
    v.extract    s3, v13, #9
    s.or         s14, s16, s15
    s.shli       s15, s13, #32
    s.shli       s13, s3, #32
    v.extract    s3, v9, #9
    v.insert     v6, s17, #6
    v.extract    s16, v12, #9
    v.insert     v5, s19, #7
    s.lshri      s17, s19, #32
    s.add        s19, s18, s14
    v.extract    s14, v11, #10
    s.or         s18, s3, s15
    v.extract    s3, v13, #10
    s.or         s15, s16, s13
    s.shli       s13, s14, #32
    s.shli       s14, s3, #32
    v.extract    s3, v9, #10
    v.insert     v6, s17, #7
    v.extract    s16, v12, #10
    v.insert     v5, s19, #8
    s.lshri      s17, s19, #32
    s.add        s19, s18, s15
    v.extract    s15, v11, #11
    s.or         s18, s3, s13
    v.extract    s3, v13, #11
    s.or         s13, s16, s14
    s.shli       s14, s15, #32
    s.shli       s15, s3, #32
    v.extract    s3, v9, #11
    v.insert     v6, s17, #8
    v.extract    s16, v12, #11
    v.insert     v5, s19, #9
    s.lshri      s17, s19, #32
    s.add        s19, s18, s13
    v.extract    s13, v11, #12
    s.or         s18, s3, s14
    v.extract    s3, v13, #12
    s.or         s14, s16, s15
    s.shli       s15, s13, #32
    s.shli       s13, s3, #32
    v.extract    s3, v9, #12
    v.insert     v6, s17, #9
    v.extract    s16, v12, #12
    v.insert     v5, s19, #10
    s.lshri      s17, s19, #32
    s.add        s19, s18, s14
    v.extract    s14, v11, #13
    s.or         s18, s3, s15
    v.extract    s3, v13, #13
    s.or         s15, s16, s13
    s.shli       s13, s14, #32
    s.shli       s14, s3, #32
    v.extract    s3, v9, #13
    v.insert     v6, s17, #10
    v.extract    s16, v12, #13
    v.insert     v5, s19, #11
    s.lshri      s17, s19, #32
    s.add        s19, s18, s15
    v.extract    s15, v11, #14
    s.or         s18, s3, s13
    v.extract    s3, v13, #14
    s.or         s13, s16, s14
    s.shli       s14, s15, #32
    s.shli       s15, s3, #32
    v.extract    s3, v9, #14
    v.insert     v6, s17, #11
    v.extract    s16, v12, #14
    v.insert     v5, s19, #12
    s.lshri      s17, s19, #32
    s.add        s19, s18, s13
    v.extract    s13, v11, #15
    s.or         s18, s3, s14
    v.extract    s3, v13, #15
    s.or         s14, s16, s15
    s.shli       s15, s13, #32
    s.shli       s13, s3, #32
    v.extract    s3, v9, #15
    v.insert     v6, s17, #12
    v.extract    s16, v12, #15
    v.insert     v5, s19, #13
    s.lshri      s17, s19, #32
    s.add        s19, s18, s14
    s.or         s14, s3, s15
    s.or         s3, s16, s13
    v.insert     v6, s17, #13
    v.insert     v5, s19, #14
    s.lshri      s13, s19, #32
    s.add        s15, s14, s3
    v.insert     v6, s13, #14
    v.insert     v5, s15, #15
    s.lshri      s3, s15, #32
    v.movi       v9, #31
    v.insert     v6, s3, #15
    v.ashr       v11, v5, v9
    v.movi       v9, #1
    v.movi       v12, #0
    v.cmp.ne     p2, v6, v11
    @p2 v.sel        v6, v9, v12
    s.movz       s3, #0
    v.reduce.or  s13, v6
    s.cmp.eq     s14, s13, s3
    br.nz        s14, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v6, [s5, v5]               // index is in elements (ISA sec 9.1)
    s.mul        s3, s4, s11
    v.movi       v5, #0
    s.add        s13, s1, s12
    s.movz       s14, #1
    vf.cvt.f16.f32 v9, v6
    s.add        s15, s1, s3
    v.splat      v6, s3
    s.shli       s3, s15, #1                     // element offset -> bytes (x2)
    vf.add       v11, v9, v8
    s.add        s15, s2, s3                     // &in_out_ptr0[...]
    v.add        v8, v7, v6
    vf.add       v6, v11, v10
    vf.add       v7, v6, v3
    vf.mul       v3, v7, v7
    vf.cvt.f32.f16 v6, v7
    vf.add       v7, v4, v3
    @p1 v.st.h       [s15, #0], v6
    @p1 v.sel        v3, v7, v4
    v.mov        v5, v3
    v.mov        v4, v5
    s.mov        s1, s13
    br.nz        s14, for_1
endfor_2:
    vf.reduce.add.b v1, v4
    v.movi       v2, #0
    s.addi       s1, s10, #0
    vf.add       v3, v1, v2
for_5:
    s.cmp.ge     s3, s1, s11
    br.nz        s3, endfor_6
    .li       s3, #1128267776
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1065353216
    v.splat      v2, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v4, v1                          // ISA 8.8: <= 2**-22 relative
    .li       s3, #925353388
    v.splat      v5, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s3, s4, #384
    v.splat      v6, s1
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s5, #192
    s.movz       s6, #64
    s.muli       s7, s1, #2
    v.add        v8, v6, v7
    v.movi       v6, #0
    v.splat      v7, s5
    v.splat      v9, s4
    v.movi       v10, #0
    v.cmp.ge     p1, v8, v6
    v.splat      v6, s6
    v.cmp.lt     p2, v8, v7
    .li       s5, #1077936128
    v.splat      v7, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s5, #3204448256
    v.splat      v8, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v6
    s.add        s5, s2, s3
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s3, s5, s7
    p.and        p2, p5, p1
    v.splat      v6, s1
    fence.acq_rel.device
    vf.fms       v9, v1, v4, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s3, #0]
    s.shli       s3, s1, #1                      // element offset -> bytes (x2)
    v.add        v2, v6, v0
    vf.fms       v6, v4, v9, v4
    v.movi       v9, #192
    s.add        s5, s8, s3                      // &in_ptr4[...]
    v.cmp.lt     p1, v2, v9
    vf.neg       v9, v6                          // Newton step: r0*(2 - x*r0)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s5, #0]
    vf.cvt.f16.f32 v10, v1
    s.mul        s3, s4, s11
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v1, v9, v4
    s.add        s5, s1, s12
    vf.mul       v4, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f16.f32 v1, v6
    s.add        s6, s1, s3
    v.splat      v6, s3
    vf.add       v9, v4, v5
    s.shli       s3, s6, #1                      // element offset -> bytes (x2)
    s.movz       s6, #1
    s.add        s7, s9, s3                      // &out_ptr1[...]
    v.rsqrt.approx v4, v9                        // ISA 8.8: <= 2**-22 relative
    v.add        v5, v2, v6
    vf.mul       v2, v4, v4
    vf.mul       v5, v4, v8
    vf.fms       v6, v9, v2, v7
    vf.mul       v2, v5, v6                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v5, v2, v4
    v.extract    s3, v5, #0
    v.splat      v2, s3
    vf.mul       v4, v10, v2
    vf.mul       v2, v4, v1
    vf.cvt.f32.f16 v1, v2
    @p1 v.st.h       [s7, #0], v1
    s.mov        s1, s5
    br.nz        s6, for_5
endfor_6:
__rctx_next:
    exit
