    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // out_ptr1: device_ptr64 at arg_base+40
    s.rdspecial  s1, arg_base
    s.ld.d       s9, [s1, #64]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s10, #1024
    s.mul        s11, s1, s10
    s.add        s1, s9, s11                     // this context's own scratch
    s.addi       s9, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #0
    s.st.d       [s9, #0], s2
    s.movz       s10, #64
    s.st.d       [s9, #8], s10
    s.movz       s10, #128
    s.st.d       [s9, #16], s10
    s.movz       s10, #256
    s.st.d       [s9, #48], s10
    s.movz       s10, #2
    s.st.d       [s9, #56], s10
    .li       s10, #68719476737
    s.st.d       [s9, #88], s10
    .li       s10, #8589934592
    s.st.d       [s9, #104], s10
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s9, s1, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #0
    s.st.d       [s9, #0], s3
    s.movz       s10, #64
    s.st.d       [s9, #8], s10
    s.movz       s10, #128
    s.st.d       [s9, #16], s10
    s.movz       s10, #256
    s.st.d       [s9, #48], s10
    s.movz       s10, #2
    s.st.d       [s9, #56], s10
    .li       s10, #68719476737
    s.st.d       [s9, #88], s10
    .li       s10, #8589934592
    s.st.d       [s9, #104], s10
    fence.release.device
    td.load      d1, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s9, s1, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #0
    s.st.d       [s9, #0], s5
    s.movz       s10, #64
    s.st.d       [s9, #8], s10
    s.movz       s10, #128
    s.st.d       [s9, #16], s10
    s.movz       s10, #256
    s.st.d       [s9, #48], s10
    s.movz       s10, #2
    s.st.d       [s9, #56], s10
    .li       s10, #68719476737
    s.st.d       [s9, #88], s10
    .li       s10, #8589934592
    s.st.d       [s9, #104], s10
    fence.release.device
    td.load      d2, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s9, s1, #768                    // TensorMap 3: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s9, #0], s6
    s.movz       s1, #64
    s.st.d       [s9, #8], s1
    s.movz       s1, #128
    s.st.d       [s9, #16], s1
    s.movz       s1, #256
    s.st.d       [s9, #48], s1
    s.movz       s1, #2
    s.st.d       [s9, #56], s1
    .li       s1, #68719476737
    s.st.d       [s9, #88], s1
    .li       s1, #8589934592
    s.st.d       [s9, #104], s1
    fence.release.device
    td.load      d3, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s9, #128
    s.movz       s10, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s11, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s12, s11, s9
    br.nz        s12, endfor_2
    s.muli       s12, s4, #256
    v.splat      v1, s11
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s13, #128
    s.movz       s14, #64
    s.muli       s15, s4, #256
    v.splat      v4, s11
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s16, #128
    s.movz       s17, #64
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s13
    s.muli       s13, s11, #2
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s14
    s.muli       s14, s11, #2
    v.add        v10, v4, v5
    v.movi       v4, #0
    v.splat      v5, s16
    v.cmp.ge     p1, v6, v1
    v.splat      v1, s4
    v.cmp.lt     p2, v6, v3
    v.movi       v3, #0
    v.splat      v6, s17
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s16, s2, s12
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v5
    p.and        p2, p3, p4
    v.cmp.ge     p3, v1, v3
    s.add        s12, s3, s15
    p.and        p4, p5, p1
    v.cmp.lt     p1, v1, v6
    p.and        p5, p3, p1
    s.add        s15, s16, s13
    p.and        p1, p6, p2
    s.add        s13, s12, s14
    p.and        p2, p4, p5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s15, #0]
    v.splat      v3, s11
    v.movi       v4, #128
    v.add        v5, v3, v0
    s.muli       s12, s4, #256
    v.cmp.lt     p1, v5, v4
    v.splat      v3, s11
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s14, #128
    s.movz       s15, #64
    s.muli       s16, s11, #2
    v.add        v5, v3, v4
    v.movi       v3, #0
    v.splat      v4, s14
    v.splat      v6, s4
    v.movi       v7, #0
    v.splat      v8, s15
    v.cmp.ge     p3, v5, v3
    v.cmp.lt     p4, v5, v4
    v.cmp.ge     p5, v6, v7
    s.muli       s14, s4, #256
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v3, [s13, #0]
    v.cmp.lt     p2, v6, v8
    s.add        s13, s5, s12
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    s.add        s12, s13, s16
    p.and        p2, p6, p3
    vf.cvt.f16.f32 v4, v1
    v.splat      v1, s11
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s13, #128
    s.movz       s15, #64
    s.muli       s16, s11, #2
    v.add        v6, v1, v5
    v.movi       v1, #0
    v.splat      v5, s13
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s15
    v.cmp.ge     p3, v6, v1
    v.cmp.lt     p4, v6, v5
    v.cmp.ge     p5, v7, v8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s12, #0]
    v.cmp.lt     p2, v7, v9
    s.add        s12, s6, s14
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    vf.cvt.f16.f32 v5, v3
    s.add        s13, s12, s16
    p.and        p2, p6, p3
    vf.cvt.f16.f32 v3, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s13, #0]
    vf.add       v6, v4, v5
    v.movi       v4, #0
    s.add        s12, s11, s10
    s.movz       s13, #1
    vf.add       v5, v6, v3
    vf.cvt.f16.f32 v3, v1
    vf.add       v1, v5, v3
    vf.mul       v3, v1, v1
    vf.add       v1, v2, v3
    @p1 v.sel        v3, v1, v2
    v.mov        v4, v3
    v.mov        v2, v4
    s.mov        s11, s12
    br.nz        s13, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    s.addi       s11, s1, #0
    vf.add       v3, v1, v2
for_3:
    s.cmp.ge     s1, s11, s9
    br.nz        s1, endfor_4
    s.muli       s1, s4, #256
    v.splat      v1, s11
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s12, #128
    s.movz       s13, #64
    s.muli       s14, s4, #256
    v.splat      v4, s11
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s15, #128
    v.add        v6, v1, v2
    v.movi       v1, #0
    v.splat      v2, s12
    s.movz       s12, #64
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s13
    s.muli       s13, s11, #2
    v.add        v10, v4, v5
    v.movi       v4, #0
    v.splat      v5, s15
    s.muli       s15, s11, #2
    v.cmp.ge     p1, v6, v1
    v.splat      v1, s4
    v.cmp.lt     p2, v6, v2
    v.movi       v2, #0
    v.splat      v6, s12
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s12, s2, s1
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v5
    p.and        p2, p3, p4
    v.cmp.ge     p3, v1, v2
    s.add        s1, s3, s14
    p.and        p4, p5, p1
    v.cmp.lt     p1, v1, v6
    p.and        p5, p3, p1
    s.add        s14, s12, s13
    p.and        p1, p6, p2
    s.add        s12, s1, s15
    p.and        p2, p4, p5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s14, #0]
    v.splat      v2, s11
    v.movi       v4, #128
    v.add        v5, v2, v0
    s.muli       s1, s4, #256
    v.cmp.lt     p1, v5, v4
    v.splat      v2, s11
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s13, #128
    s.movz       s14, #64
    s.muli       s15, s11, #2
    v.add        v6, v2, v4
    v.movi       v2, #0
    v.splat      v4, s13
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s14
    v.cmp.ge     p3, v6, v2
    v.cmp.lt     p4, v6, v4
    v.cmp.ge     p5, v7, v8
    s.muli       s13, s4, #256
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s12, #0]
    v.cmp.lt     p2, v7, v9
    s.add        s12, s5, s1
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    s.add        s1, s12, s15
    p.and        p2, p6, p3
    vf.cvt.f16.f32 v4, v1
    v.splat      v1, s11
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s12, #128
    s.movz       s14, #64
    s.muli       s15, s11, #2
    v.add        v7, v1, v6
    v.movi       v1, #0
    v.splat      v6, s12
    v.splat      v8, s4
    v.movi       v9, #0
    v.splat      v10, s14
    v.cmp.ge     p3, v7, v1
    v.cmp.lt     p4, v7, v6
    v.cmp.ge     p5, v8, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s1, #0]
    v.cmp.lt     p2, v8, v10
    s.add        s1, s6, s13
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    vf.cvt.f16.f32 v6, v2
    .li       s12, #1124073472
    v.splat      v2, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s12, #1065353216
    v.splat      v7, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v8, v2                          // ISA 8.8: <= 2**-22 relative
    .li       s12, #925353388
    v.splat      v9, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s12, s1, s15
    p.and        p2, p6, p3
    .li       s1, #1077936128
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.f16.f32 v12, v1
    vf.add       v1, v4, v6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s12, #0]
    s.shli       s1, s11, #1                     // element offset -> bytes (x2)
    s.mul        s12, s4, s9
    s.add        s13, s7, s1                     // &in_ptr4[...]
    vf.add       v6, v1, v12
    s.add        s1, s11, s10
    vf.cvt.f16.f32 v1, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s13, #0]
    s.add        s13, s11, s12
    s.movz       s14, #1
    vf.add       v12, v6, v1
    s.shli       s15, s13, #1                    // element offset -> bytes (x2)
    v.splat      v1, s12
    vf.cvt.f16.f32 v6, v4
    s.add        s12, s8, s15                    // &out_ptr1[...]
    v.add        v4, v5, v1
    vf.fms       v1, v2, v8, v7
    vf.fms       v2, v8, v1, v8
    vf.neg       v1, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v2, v1, v8
    vf.mul       v1, v3, v2                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v2, v1, v9
    v.rsqrt.approx v1, v2                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v1, v1
    vf.mul       v5, v1, v11
    vf.fms       v7, v2, v4, v10
    vf.mul       v2, v5, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v4, v2, v1
    v.extract    s13, v4, #0
    v.splat      v1, s13
    vf.mul       v2, v12, v1
    vf.mul       v1, v2, v6
    vf.cvt.f32.f16 v2, v1
    @p1 v.st.h       [s12, #0], v2
    s.mov        s11, s1
    br.nz        s14, for_3
endfor_4:
__rctx_next:
    exit
