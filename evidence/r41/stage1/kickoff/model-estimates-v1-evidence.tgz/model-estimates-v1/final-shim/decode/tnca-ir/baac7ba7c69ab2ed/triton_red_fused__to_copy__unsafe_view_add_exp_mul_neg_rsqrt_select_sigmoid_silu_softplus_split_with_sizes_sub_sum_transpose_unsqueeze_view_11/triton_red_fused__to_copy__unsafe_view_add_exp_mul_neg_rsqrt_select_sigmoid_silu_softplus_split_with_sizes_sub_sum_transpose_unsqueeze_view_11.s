    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // out_ptr1: device_ptr64 at arg_base+48
    s.movz       s1, #1
    s.rdspecial  s10, arg_base
    s.ld.d       s11, [s10, #72]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s10, role_id
    s.movz       s12, #256
    s.mul        s13, s10, s12
    s.add        s10, s11, s13                   // this context's own scratch
    s.addi       s11, s10, #0                    // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #0
    s.st.d       [s11, #0], s5
    s.movz       s10, #16
    s.st.d       [s11, #8], s10
    s.movz       s10, #128
    s.st.d       [s11, #16], s10
    s.movz       s10, #512
    s.st.d       [s11, #48], s10
    s.movz       s10, #4
    s.st.d       [s11, #56], s10
    .li       s10, #68719476737
    s.st.d       [s11, #88], s10
    .li       s10, #2207613190144
    s.st.d       [s11, #104], s10
    fence.release.device
    td.load      d0, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s10, #1
    s.movz       s11, #0
    s.movz       s12, #128
    s.movz       s13, #16
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #128
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v4, v3, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v4, #127
    v.and        v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.movi       v4, #0
    v.movi       v5, #1
    v.cmp.lt     p1, v0, v4
    v.cmp.lt     p2, v2, v4
    v.sub        v5, v4, v0
    @p1 v.sel        v6, v5, v0
    v.sub        v0, v4, v2
    @p2 v.sel        v5, v0, v2
    v.movi       v0, #7
    v.lshr       v2, v6, v0
    v.sub        v0, v4, v2
    @p1 v.sel        v4, v0, v2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s1
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s3, v4]               // index is in elements (ISA sec 9.1)
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v5, s10
    v.cmp.lt     p1, v2, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s6, v4]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s11, #0
    v.movi       v5, #0
    v.movi       v6, #0
    v.mov        v6, v5
for_1:
    s.cmp.ge     s3, s1, s12
    br.nz        s3, endfor_2
    s.movz       s3, #0
    s.movz       s6, #0
    s.cmp.lt     s10, s4, s3
    s.movz       s3, #0
    s.sub        s11, s6, s10
    s.movz       s6, #0
    s.cmp.lt     s10, s12, s3
    s.xor        s3, s4, s11
    s.sub        s14, s6, s10
    s.sub        s6, s3, s11
    v.splat      v5, s1
    s.lshri      s3, s6, #7
    s.xor        s10, s11, s14
    v.movi       v7, #16384
    s.xor        s11, s3, s10
    v.add        v8, v5, v1
    v.movi       v5, #128
    v.extract    s15, v3, #0
    v.mul        v9, v4, v7
    s.sub        s16, s11, s10
    v.splat      v7, s1
    v.iota       v10                             // arange(0, VLEN)
    s.movz       s10, #128
    s.movz       s11, #16
    v.mul        v11, v8, v5
    v.splat      v12, s15
    s.muli       s15, s16, #512
    v.add        v13, v7, v10
    v.movi       v7, #0
    v.splat      v10, s10
    v.extract    s10, v9, #0
    v.splat      v9, s16
    s.muli       s16, s1, #4
    v.add        v14, v12, v11
    v.movi       v11, #0
    v.cmp.ge     p1, v13, v7
    v.splat      v7, s11
    v.cmp.lt     p2, v13, v10
    v.splat      v10, s10
    v.cmp.ge     p3, v9, v11
    s.add        s10, s5, s15
    p.and        p4, p1, p2
    v.add        v11, v14, v10
    s.add        s11, s10, s16
    v.cmp.lt     p1, v8, v5
    v.cmp.lt     p2, v9, v7
    p.and        p5, p3, p2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s2, v11]              // index is in elements (ISA sec 9.1)
    p.and        p2, p4, p5
    v.extract    s10, v0, #0
    s.muli       s15, s3, #128
    s.xor        s3, s12, s14
    s.movz       s16, #16384
    .li       s16, #897988541
    v.splat      v7, s16                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s16, #1077936128
    v.splat      v8, s16                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s16, #3204448256
    v.splat      v9, s16                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v10, v2, v7
    v.splat      v7, s10
    s.sub        s10, s3, s14
    v.movi       v11, #0
    s.sub        s3, s6, s15
    v.rsqrt.approx v12, v10                      // ISA 8.8: <= 2**-22 relative
    s.add        s3, s1, s13
    s.movz       s6, #1
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s11, #0]
    vf.mul       v14, v5, v7
    vf.mul       v5, v12, v12
    vf.mul       v7, v12, v9
    vf.fms       v9, v10, v5, v8
    vf.mul       v5, v7, v9                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v5, v5
    @p2 v.sel        v7, v5, v12
    v.extract    s10, v7, #0
    v.splat      v5, s10
    vf.mul       v7, v13, v5
    vf.mul       v5, v14, v7
    vf.add       v7, v6, v5
    @p1 v.sel        v5, v7, v6
    v.mov        v11, v5
    v.mov        v6, v11
    s.mov        s1, s3
    br.nz        s6, for_1
endfor_2:
    s.movz       s1, #4096
    s.movz       s2, #1
    s.add        s3, s4, s1
    v.iota       v0                              // arange(0, VLEN)
    s.shli       s1, s3, #2                      // element offset -> bytes (x4)
    v.splat      v1, s2
    v.movi       v2, #0
    s.add        s2, s7, s1                      // &in_ptr4[...]
    v.cmp.lt     p1, v0, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s2, v2]               // index is in elements (ISA sec 9.1)
    .li       s1, #1069066811
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1060205080
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.movz       s1, #1
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v8, s1
    vf.reduce.add.b v9, v6
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v8
    s.movz       s1, #1
    vf.add       v7, v9, v6
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v8, s1
    s.add        s1, s9, s2                      // &out_ptr1[...]
    v.splat      v9, s3
    vf.neg       v9, v0
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v10, [s8, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v8
    vf.mul       v4, v9, v1
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v9, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v8, v2
    vf.fma       v2, v6, v1, v6                  // 2**t * 2**d
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v1, v2, v6
    vf.add       v2, v1, v3
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v2, v1, v5
    vf.fms       v2, v1, v3, v1
    vf.neg       v3, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v2, v3, v1
    vf.mul       v1, v0, v2                      // a/y as a refined reciprocal (ISA has no divide)
    vf.sub       v0, v1, v7
    vf.mul       v1, v0, v10
    @p1 v.st.w       [s1, #0], v1
__rctx_next:
    exit
