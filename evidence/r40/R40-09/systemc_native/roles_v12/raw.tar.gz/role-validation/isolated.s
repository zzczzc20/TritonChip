
        s.rdspecial s1, role_id
        .li s2, #11
        v.splat v0, s2
        .li s2, #22
        v.splat v1, s2
        s.cmp.eq s2, s1, s0
        s.sub s2, s0, s2
        p.frombits p1, s2
        @p1 v.sel v2, v0, v1
        s.rdspecial s3, pid.x
        s.shli s3, s3, #7
        s.shli s1, s1, #6
        s.add s3, s3, s1
        .li s4, #0x60000
        s.add s3, s3, s4
        v.st.w [s3, #0], v2
        exit
    