import os,sys,runpy
from pathlib import Path
root=Path.home()/'r41_event_scan_candidate';src=Path.home()/'r41_vl_reason_dp/src'
sys.path[:0]=[str(root/'python'),str(src/'compiler/python'),str(src/'tools/asm'),str(src/'tools/performance_harness/systemc')]
os.environ.update(TNCA_PROFILE='core-vrf-sync-v5-x8-g2c4-dp',TNCA_BACKEND='systemc-tlm-grid',TNCA_TLM_BINARY=str(Path.home()/'r41_vl_reason_dp/build/tnca-chip'),TNCA_TLM_CONFIG=str(src/'tools/performance_harness/systemc/configs/r41-mma-dp.cfg'),OMP_NUM_THREADS='1',MAX_JOBS='1')
import tlm_backend
tlm_backend.register()
sys.argv=[str(root/'tools/r40/replay_tests.py'),'--replays','2']
runpy.run_path(sys.argv[0],run_name='__main__')
