    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s4, #512
    .li       s5, #2147483647
    s.mul        s6, s1, s4
    .li       s1, #2147483647
    s.movz       s4, #2048
    s.movz       s7, #2
    .li       s8, #68719476752
    .li       s9, #8589934592
    s.rdspecial  s10, arg_base
    s.ld.d       s11, [s2, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.add        s12, s3, s6                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s6, s12, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s12, #512
    .li       s13, #2147483647
    s.mul        s14, s3, s12
    .li       s3, #2147483647
    s.movz       s12, #2048
    s.movz       s15, #2
    .li       s16, #68719476752
    s.ld.d       s17, [s2, #8]                   // arg_B: device_ptr64 at arg_base+8
    s.movz       s18, #176
    .li       s19, #8589934592
    s.movz       s20, #0
    s.movz       s20, #0
    s.ld.d       s20, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.movz       s2, #0
    s.movz       s21, #0
    s.cmp.lt     s22, s18, s2
    s.sub        s2, s21, s22
    s.movz       s21, #0
    s.st.d       [s6, #0], s11
    s.xor        s11, s18, s2
    s.sub        s22, s11, s2
    s.movz       s11, #0
    s.st.d       [s6, #8], s5
    .li       s5, #1952257862
    s.st.d       [s6, #16], s1
    s.movz       s1, #32
    s.st.d       [s6, #48], s4
    s.movz       s4, #1
    s.st.d       [s6, #56], s7
    s.movz       s7, #0
    s.st.d       [s6, #88], s8
    s.movz       s8, #0
    s.st.d       [s6, #104], s9
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s6, #0
    s.movz       s9, #0
    s.ld.d       s22, [s10, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s10, s22, s14                   // this context's own scratch
    s.movz       s14, #0
    s.addi       s22, s10, #256                  // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.st.d       [s22, #0], s17
    s.movz       s10, #0
    s.st.d       [s22, #8], s13
    s.movz       s13, #1
    s.st.d       [s22, #16], s3
    s.rdspecial  s3, role_id
    s.st.d       [s22, #48], s12
    s.rdspecial  s12, npid.x
    s.st.d       [s22, #56], s15
    s.st.d       [s22, #88], s16
    s.st.d       [s22, #104], s19
    fence.release.device
    td.load      d1, [s22]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
__rctx_program:
    s.cmp.lt     s15, s3, s11
    s.cmp.lt     s16, s3, s8
    s.sub        s17, s21, s15
    s.sub        s15, s7, s16
    s.xor        s16, s3, s17
    s.xor        s19, s17, s2
    s.sub        s22, s16, s17
    s.xor        s16, s3, s15
    s.mul        s17, s22, s5
    s.sub        s23, s16, s15
    s.addi       s16, s14, #0
    s.addi       s24, s10, #0
    s.mov        s16, s23
    s.lshri      s25, s17, #32
    s.sub        s17, s22, s25
    s.lshri      s26, s17, #1
    s.add        s17, s25, s26
    s.lshri      s25, s17, #7
    s.xor        s17, s25, s19
    s.muli       s26, s25, #176
    s.sub        s25, s17, s19
    s.sub        s17, s1, s25
    s.min.s      s19, s17, s4
    s.sub        s17, s22, s26
    s.cmp.lt     s17, s19, s9
    s.sub        s22, s6, s17
    s.xor        s17, s19, s22
    s.sub        s26, s17, s22
    s.cmp.eq     s17, s26, s13
    br.nz        s17, sdiv_done_1
    s.movz       s17, #0
    s.movz       s22, #31
    s.mov        s16, s17
    s.addi       s17, s22, #0
sdiv_2:
    s.lshr       s22, s23, s17
    s.shli       s27, s24, #1
    s.andi       s28, s22, #1
    s.movz       s22, #0
    s.or         s29, s27, s28
    s.movz       s27, #1
    s.cmp.geu    s28, s29, s26
    s.shl        s30, s27, s17
    s.sub        s27, s22, s28
    s.subi       s22, s17, #1
    s.and        s28, s26, s27
    s.and        s31, s30, s27
    s.sub        s27, s29, s28
    s.or         s28, s16, s31
    s.mov        s24, s27
    s.mov        s16, s28
    s.mov        s17, s22
    s.movz       s22, #0
    s.cmp.ge     s27, s17, s22
    br.nz        s27, sdiv_2
sdiv_done_1:
    s.movz       s16, #0
    s.movz       s17, #0
    s.cmp.lt     s22, s3, s16
    .li       s16, #1952257862
    s.sub        s23, s17, s22
    s.movz       s17, #0
    s.xor        s22, s3, s23
    s.movz       s26, #0
    s.sub        s27, s22, s23
    s.movz       s22, #0
    s.mul        s28, s27, s16
    s.cmp.lt     s16, s19, s17
    s.movz       s17, #0
    s.movz       s29, #0
    s.sub        s30, s22, s16
    s.lshri      s16, s28, #32
    s.movz       s22, #0
    s.cmp.lt     s28, s18, s17
    s.xor        s17, s19, s30
    s.xor        s19, s24, s15
    s.sub        s24, s22, s28
    s.sub        s22, s27, s16
    s.sub        s28, s17, s30
    s.lshri      s17, s22, #1
    s.sub        s22, s19, s15
    s.add        s15, s16, s17
    s.movz       s16, #0
    s.lshri      s17, s15, #7
    s.movz       s15, #1
    s.muli       s19, s17, #176
    s.addi       s17, s16, #0
    s.cmp.eq     s16, s28, s15
    s.add        s15, s25, s22
    s.xor        s22, s18, s24
    s.sub        s25, s27, s19
    s.movz       s19, #0
    s.xor        s27, s25, s23
    s.sub        s25, s22, s24
    s.sub        s22, s27, s23
    s.addi       s23, s19, #0
    s.cmp.lt     s19, s22, s26
    s.sub        s24, s29, s19
    s.xor        s19, s22, s24
    s.sub        s22, s19, s24
    s.mov        s17, s22
    br.nz        s16, sdiv_done_3
    s.movz       s16, #0
    s.movz       s19, #31
    s.mov        s17, s16
    s.addi       s16, s19, #0
sdiv_4:
    s.lshr       s19, s22, s16
    s.shli       s25, s23, #1
    s.andi       s26, s19, #1
    s.movz       s19, #0
    s.or         s27, s25, s26
    s.movz       s25, #1
    s.cmp.geu    s26, s27, s28
    s.shl        s29, s25, s16
    s.sub        s25, s19, s26
    s.subi       s19, s16, #1
    s.and        s26, s28, s25
    s.and        s31, s29, s25
    s.sub        s25, s27, s26
    s.or         s26, s17, s31
    s.mov        s23, s25
    s.mov        s17, s26
    s.mov        s16, s19
    s.movz       s19, #0
    s.cmp.ge     s25, s16, s19
    br.nz        s25, sdiv_4
sdiv_done_3:
    s.xor        s16, s24, s30
    s.movz       s19, #16
    s.xor        s22, s17, s16
    .li       s17, #1952257862
    s.sub        s23, s22, s16
    s.mul        s16, s15, s19
    s.mul        s22, s23, s19
    s.movz       s24, #0
    v.splat      v0, s15
    v.splat      v1, s24
    s.andi       s15, s16, #511
    s.mul        s25, s22, s17
    v.splat      v2, s23
    v.splat      v3, s24
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s16
    s.lshri      s17, s25, #32
    v.cmp.ge     p1, v0, v1
    s.sub        s23, s22, s17
    v.splat      v0, s22
    s.lshri      s25, s23, #1
    v.splat      v1, s15
    s.add        s23, s17, s25
    v.cmp.ge     p1, v2, v3
    s.lshri      s17, s23, #11
    v.iota       v2                              // arange(0, VLEN)
    s.muli       s23, s17, #2816
    v.iota       v3                              // arange(0, VLEN)
    v.add        v6, v5, v4
    v.add        v5, v0, v4
    v.add        v0, v1, v2
    s.sub        s17, s22, s23
    s.movz       s23, #64
    v.splat      v0, s17
    s.addi       s25, s24, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    v.add        v1, v0, v3
for_5:
    s.cmp.ge     s24, s25, s23
    br.nz        s24, endfor_6
    s.mul        s24, s25, s19
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s27, s25, s4
    s.movz       s28, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s29, s15                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s24                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s29, s26
    mb.wait      s26
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s29, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s30, s17                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s24                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s30, s29
    mb.wait      s29
    mb.arm       s24, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s24
    mb.wait      s24
    s.mov        s25, s27
    br.nz        s28, for_5
endfor_6:
    s.movz       s15, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s17, #0
    s.add        s19, s15, s22                   // the tile origin
    s.movz       s15, #0
    s.muli       s23, s22, #2                    // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s19
    a.vread      v2, a0, s17
    s.add        s17, s15, s16                   // the tile origin
    s.movz       s15, #512
    s.movz       s19, #2816
    s.muli       s22, s16, #5632                 // a runtime tile origin, x5632
    v.splat      v3, s17
    v.splat      v4, s15
    v.add        v5, v0, v1
    v.splat      v0, s19
    vf.cvt.f32.f16 v1, v2
    s.add        s15, s20, s23                   // the tile origin
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s16, s15, s22                   // the tile origin
    p.and        p3, p1, p2
    s.movz       s15, #1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v0, a0, s15
    s.addi       s15, s17, #1
    s.addi       s19, s16, #5632                 // row 1
    v.splat      v1, s15
    vf.cvt.f32.f16 v2, v0
    s.movz       s15, #2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s22, s17, #2
    s.addi       s23, s16, #11264                // row 2
    v.splat      v0, s22
    s.movz       s22, #3
    s.addi       s25, s17, #3
    @p3 v.st.h       [s19, #0], v2
    a.vread      v1, a0, s15
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    v.splat      v1, s25
    s.addi       s15, s16, #16896                // row 3
    s.movz       s19, #4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    s.addi       s25, s17, #4
    s.addi       s27, s16, #22528                // row 4
    v.splat      v1, s25
    s.movz       s25, #5
    @p3 v.st.h       [s23, #0], v0
    a.vread      v0, a0, s22
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s22, s17, #5
    s.addi       s23, s16, #28160                // row 5
    v.splat      v0, s22
    s.movz       s22, #6
    @p4 v.st.h       [s15, #0], v1
    a.vread      v1, a0, s19
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s15, s17, #6
    s.movz       s19, #33792
    v.splat      v1, s15
    s.add        s15, s16, s19                   // row 6
    s.movz       s19, #7
    @p3 v.st.h       [s27, #0], v0
    a.vread      v0, a0, s25
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s25, s17, #7
    s.movz       s27, #39424
    v.splat      v0, s25
    s.add        s25, s16, s27                   // row 7
    s.movz       s27, #8
    @p4 v.st.h       [s23, #0], v1
    a.vread      v1, a0, s22
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s22, s17, #8
    s.movz       s23, #45056
    v.splat      v1, s22
    s.add        s22, s16, s23                   // row 8
    s.movz       s23, #9
    @p3 v.st.h       [s15, #0], v0
    a.vread      v0, a0, s19
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s15, s17, #9
    s.movz       s19, #50688
    v.splat      v0, s15
    s.add        s15, s16, s19                   // row 9
    s.movz       s19, #10
    @p4 v.st.h       [s25, #0], v1
    a.vread      v1, a0, s27
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s25, s17, #10
    s.movz       s27, #56320
    v.splat      v1, s25
    s.add        s25, s16, s27                   // row 10
    s.movz       s27, #11
    @p3 v.st.h       [s22, #0], v0
    a.vread      v0, a0, s23
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s22, s17, #11
    s.movz       s23, #61952
    v.splat      v0, s22
    s.add        s22, s16, s23                   // row 11
    s.movz       s23, #12
    @p4 v.st.h       [s15, #0], v1
    a.vread      v1, a0, s19
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s15, s17, #12
    .li       s19, #67584
    v.splat      v1, s15
    s.add        s15, s16, s19                   // row 12
    s.movz       s19, #13
    @p3 v.st.h       [s25, #0], v0
    a.vread      v0, a0, s27
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s25, s17, #13
    .li       s27, #73216
    v.splat      v0, s25
    s.add        s25, s16, s27                   // row 13
    s.movz       s27, #14
    @p4 v.st.h       [s22, #0], v1
    a.vread      v1, a0, s23
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s22, s17, #14
    .li       s23, #78848
    v.splat      v1, s22
    s.add        s22, s16, s23                   // row 14
    s.movz       s23, #15
    s.addi       s28, s17, #15
    v.splat      v2, s28
    .li       s17, #84480
    @p3 v.st.h       [s15, #0], v0
    a.vread      v0, a0, s19
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.add        s15, s16, s17                   // row 15
    @p4 v.st.h       [s25, #0], v1
    a.vread      v0, a0, s27
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v0
    @p3 v.st.h       [s22, #0], v1
    a.vread      v0, a0, s23
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s15, #0], v1
__rctx_next:
    s.addi       s15, s3, #2                     // the next program of this context: + 2
    s.cmp.lt     s16, s15, s12
    s.mov        s3, s15
    br.nz        s16, __rctx_program
    exit
