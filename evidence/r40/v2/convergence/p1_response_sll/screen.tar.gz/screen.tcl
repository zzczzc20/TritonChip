# Same RTL in both modes; only eligible response FF placement guidance differs.
if {[llength $argv]!=3} {error "expected SOURCE_ROOT FRESH_OUTPUT ANNOTATE_0_OR_1"}
set root [file normalize [lindex $argv 0]]
set out [file normalize [lindex $argv 1]]
set annotate [lindex $argv 2]
if {$annotate ni {0 1} || [file exists $out]} {error "bad mode or reused output"}
file mkdir $out
set_param general.maxThreads 2
read_verilog -sv [list $root/rtl/common/tnca_fifo.v $root/rtl/common/tnca_line_link.v $root/wrapper.v]
synth_design -top r40_line_response_ooc -part xcu280-fsvh2892-2L-e -mode out_of_context -flatten_hierarchy none
create_clock -name clk -period 10 [get_ports raw_clk]
opt_design
set stages [dict create 0 {} 1 {}]
set payloads [dict create 0 {} 1 {}]
set cells [get_cells -hierarchical -quiet -filter {IS_PRIMITIVE == 1}]
foreach cell $cells name [get_property NAME $cells] ref [get_property REF_NAME $cells] {
    if {$ref in {GND VCC}} {continue}
    if {[regexp {^link/g_stage\[([01])\][./]} $name whole stage]} {
        dict lappend stages $stage $cell
        if {[regexp {^FD} $ref] && [string match {*rd_reg*} $name]} {
            dict lappend payloads $stage $cell
        }
    }
}
foreach stage {0 1} slr {2 1} {
    if {[llength [dict get $payloads $stage]]!=517} {error "expected 517 response FFs in stage $stage"}
    set block [create_pblock stage$stage]
    resize_pblock $block -add SLR$slr
    add_cells_to_pblock $block [dict get $stages $stage]
}
set pairs [list]
foreach source [dict get $payloads 1] {
    set q [get_pins -quiet -of_objects $source -filter {REF_PIN_NAME == Q}]
    set nets [get_nets -segments -quiet -of_objects $q]
    set loads [get_pins -leaf -quiet -of_objects $nets -filter {DIRECTION == IN}]
    if {[llength $loads]!=1 || [get_property REF_PIN_NAME $loads] ne "D"} {
        error "response source is not a single-load Q-to-D crossing: $source"
    }
    set destination [get_cells -quiet -of_objects $loads]
    if {[lsearch -exact [dict get $payloads 0] $destination]<0} {error "response destination mismatch: $source"}
    lappend pairs [list $source $destination [lindex [lsort [get_property NAME $nets]] 0]]
}
set response_registers [concat [dict get $payloads 0] [dict get $payloads 1]]
if {$annotate} {set_property USER_SLL_REG TRUE $response_registers}
report_utilization -file $out/optimized_utilization.rpt
place_design -directive SSI_SpreadSLLs
phys_opt_design
route_design
report_route_status -file $out/route_status.rpt
report_utilization -slr -file $out/utilization_slr.rpt
report_timing_summary -delay_type min_max -file $out/timing.rpt
report_timing -from [dict get $payloads 1] -to [dict get $payloads 0] -max_paths 10 -path_type full_clock_expanded -file $out/response_setup.rpt
report_timing -delay_type min -from [dict get $payloads 1] -to [dict get $payloads 0] -max_paths 10 -path_type full_clock_expanded -file $out/response_hold.rpt
check_timing -verbose -file $out/checks.rpt
set f [open $out/response_pairs.tsv {WRONLY CREAT EXCL}]
puts $f "source\tdestination\tnet\tsource_loc\tdestination_loc\tsource_bel\tdestination_bel\tsource_slr\tdestination_slr"
foreach pair $pairs {
    lassign $pair source destination net
    puts $f [join [list $source $destination $net [get_property LOC $source] [get_property LOC $destination] [get_property BEL $source] [get_property BEL $destination] [get_property NAME [get_slrs -quiet -of_objects $source]] [get_property NAME [get_slrs -quiet -of_objects $destination]]] "\t"]
}
close $f
set f [open $out/scope.txt {WRONLY CREAT EXCL}]
puts $f "actual two-stage 582-bit request/517-bit reply line link; no cores/cache/TMU/HBM platform"
puts $f "same 10ns BUFG clock/part/SLR2-to-SLR1 assignments/SSI_SpreadSLLs; USER_SLL_REG $annotate"
puts $f "517 verified single-load response Q-to-D pairs; no RTL, capacity or latency change"
puts $f "external I/O timing unspecified; no full-system timing, packing, CDC, image or workload qualification"
close $f
write_checkpoint $out/routed.dcp
puts "R40_LINE_RESPONSE_MODULE_SCREEN_DONE"
exit
