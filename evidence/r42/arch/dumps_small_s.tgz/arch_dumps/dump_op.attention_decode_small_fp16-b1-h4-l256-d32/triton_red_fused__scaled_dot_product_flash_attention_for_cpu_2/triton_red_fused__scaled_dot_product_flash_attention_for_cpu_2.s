    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #256
    s.movz       s4, #0
    s.mul        s5, s2, s1
    s.movz       s1, #32
    s.rdspecial  s2, arg_base
    s.cmp.lt     s6, s1, s4
    s.movz       s1, #1
    s.movz       s7, #128
    s.movz       s8, #16
    s.sub        s9, s4, s6
    s.ld.d       s6, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.add        s10, s3, s5                     // this context's own scratch
    s.movz       s3, #8
    s.rdspecial  s5, role_id
    s.rdspecial  s10, npid.x
    s.ld.d       s11, [s2, #8]                   // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s12, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s13, [s2, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s14, [s2, #32]                  // out_ptr0: device_ptr64 at arg_base+32
__rctx_program:
    v.splat      v0, s5
    v.movi       v1, #0
    v.movi       v2, #6
    v.iota       v3                              // arange(0, VLEN)
    v.sub        v4, v1, v0
    v.cmp.lt     p1, v0, v1
    v.splat      v5, s1
    @p1 v.sel        v6, v4, v0
    s.cmp.lt     s2, s5, s4
    v.cmp.lt     p2, v3, v5
    v.lshr       v0, v6, v2
    s.sub        s15, s4, s2
    v.movi       v2, #5
    v.sub        v4, v1, v0
    s.xor        s2, s5, s15
    v.movi       v5, #0
    @p1 v.sel        v7, v4, v0
    s.sub        s16, s2, s15
    v.lshr       v0, v6, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s12, v7]              // index is in elements (ISA sec 9.1)
    v.movi       v4, #31
    s.lshri      s2, s16, #5
    s.xor        s16, s15, s9
    v.sub        v8, v1, v0
    v.and        v9, v6, v4
    s.xor        s15, s2, s16
    @p1 v.sel        v4, v8, v0
    s.sub        s2, s15, s16
    v.sub        v0, v1, v9
    s.addi       s15, s4, #0
    s.muli       s16, s2, #512
    v.movi       v6, #64
    v.movi       v8, #32
    @p1 v.sel        v10, v0, v9
    v.splat      v0, s2
    v.splat      v9, s3
    v.sub        v11, v1, v6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v12, [s6, v7]             // index is in elements (ISA sec 9.1)
    v.sub        v7, v1, v8
    v.movi       v13, #0
    v.movi       v14, #0
    s.add        s2, s11, s16
    v.extract    s16, v10, #0
    v.cmp.lt     p1, v6, v1
    v.movi       v10, #4096
    v.cmp.lt     p2, v8, v1
    v.cmp.ge     p3, v0, v1
    v.mul        v15, v4, v10
    v.cmp.lt     p4, v0, v9
    @p1 v.sel        v0, v11, v6
    v.extract    s17, v2, #0
    .li       s18, #1065353216
    v.splat      v0, s18                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v2, s17
    v.movi       v4, #1
    v.extract    s17, v15, #0
    v.rcp.approx v6, v2                          // ISA 8.8: <= 2**-22 relative
    v.cmp.ne     p1, v12, v5
    @p1 v.sel        v5, v4, v1
    @p2 v.sel        v9, v7, v8
    s.muli       s18, s15, #4
    v.cmp.eq     p1, v5, v1
    @p1 v.sel        v5, v4, v1
    v.mov        v14, v13
    p.and        p1, p3, p4
    v.extract    s19, v5, #0
    v.splat      v4, s16
    v.splat      v5, s19
    v.splat      v7, s17
    s.add        s16, s2, s18
    v.cmp.ne     p2, v5, v1
    vf.fms       v1, v2, v6, v0
    vf.fms       v0, v6, v1, v6
    vf.neg       v1, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v1, v1
    @p3 v.sel        v0, v1, v6
for_1:
    v.splat      v1, s15
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s16, #0]
    v.add        v5, v1, v3
    v.mul        v1, v5, v8
    v.add        v5, v4, v1
    v.add        v1, v5, v7
    v.ld.gather.h v5, [s13, v1]                  // index is in elements (ISA sec 9.1)
    vf.mul       v1, v2, v0                      // a/y as a refined reciprocal (ISA has no divide)
    @p2 v.sel        v2, v13, v1
    vf.cvt.f16.f32 v1, v5
    vf.mul       v5, v2, v1
    vf.add       v14, v14, v5
    s.addi       s16, s16, #64                   // the next iteration's address
    s.add        s15, s15, s8
    s.cmp.lt     s2, s15, s7
    br.nz        s2, for_1
endfor_2:
    vf.reduce.add.b v0, v14
    v.movi       v1, #0
    s.movz       s2, #1
    s.shli       s15, s5, #2                     // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    s.add        s2, s14, s15                    // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s2, #0], v2
__rctx_next:
    s.addi       s2, s5, #2                      // the next program of this context: + 2
    s.cmp.lt     s15, s2, s10
    s.mov        s5, s2
    br.nz        s15, __rctx_program
    exit
