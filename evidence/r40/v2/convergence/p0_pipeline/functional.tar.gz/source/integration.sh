source ~/tc_env/env.sh
cd /tmp/r40_p0b_source
python3 tools/r40/cache_maintenance_tests.py --global-grid > /tmp/r40_p0b_integration.log 2>&1
echo $? > /tmp/r40_p0b_integration.exit
