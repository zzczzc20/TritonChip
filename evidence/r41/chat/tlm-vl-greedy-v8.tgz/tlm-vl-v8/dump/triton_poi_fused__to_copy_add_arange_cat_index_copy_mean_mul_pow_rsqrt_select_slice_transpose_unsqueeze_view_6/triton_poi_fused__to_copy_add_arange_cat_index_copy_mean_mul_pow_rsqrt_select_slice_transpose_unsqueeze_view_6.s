    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    v.movi       v0, #0
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #0
    s.movz       s3, #16
    v.iota       v2                              // arange(0, VLEN)
    s.mul        s5, s4, s3
    v.movi       v3, #0
    v.movi       v4, #0
    v.movi       v5, #127
    v.movi       v6, #7
    v.splat      v7, s5
    v.movi       v8, #1024
    s.ld.d       s3, [s2, #0]                    // one element, not a vector
    v.add        v9, v7, v2
    v.movi       v2, #128
    v.movi       v7, #1
    v.sub        v7, v3, v9
    v.sub        v10, v4, v9
    v.cmp.lt     p1, v9, v3
    v.cmp.lt     p2, v9, v4
    @p1 v.sel        v11, v7, v9
    @p2 v.sel        v7, v10, v9
    v.cmp.lt     p3, v9, v8
    s.lshri      s2, s3, #32
    s.ld.d       s4, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.lshri      s6, s3, #32
    v.and        v8, v11, v5
    v.lshr       v5, v7, v6
    v.sub        v6, v3, v2
    v.sub        v7, v3, v8
    v.sub        v10, v4, v5
    v.sub        v11, v4, v2
    @p1 v.sel        v12, v7, v8
    @p2 v.sel        v7, v10, v5
    v.cmp.lt     p1, v2, v3
    s.ld.d       s7, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.lshri      s8, s3, #32
    v.cmp.lt     p2, v2, v4
    @p1 v.sel        v3, v6, v2
    v.movi       v3, #1
    @p2 v.sel        v3, v11, v2
    s.ld.d       s9, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s10, [s1, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s11, [s1, #40]                  // in_ptr5: device_ptr64 at arg_base+40
    s.lshri      s12, s3, #32
    s.ld.d       s13, [s1, #48]                  // in_ptr6: device_ptr64 at arg_base+48
    s.ld.d       s14, [s1, #56]                  // out_ptr0: device_ptr64 at arg_base+56
    v.insert     v0, s3, #0
    v.insert     v1, s2, #0
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #1
    v.insert     v1, s6, #1
    s.lshri      s2, s3, #32
    v.insert     v0, s3, #2
    v.insert     v1, s8, #2
    s.lshri      s6, s3, #32
    v.insert     v0, s3, #3
    v.insert     v1, s12, #3
    s.lshri      s8, s3, #32
    v.insert     v0, s3, #4
    v.insert     v1, s1, #4
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #5
    v.insert     v1, s2, #5
    s.lshri      s2, s3, #32
    v.insert     v0, s3, #6
    v.insert     v1, s6, #6
    s.lshri      s6, s3, #32
    v.insert     v0, s3, #7
    v.insert     v1, s8, #7
    s.lshri      s8, s3, #32
    v.insert     v0, s3, #8
    v.insert     v1, s1, #8
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #9
    v.insert     v1, s2, #9
    s.lshri      s2, s3, #32
    v.insert     v0, s3, #10
    v.insert     v1, s6, #10
    s.lshri      s6, s3, #32
    v.insert     v0, s3, #11
    v.insert     v1, s8, #11
    v.movi       v2, #0
    v.insert     v0, s3, #12
    v.insert     v1, s1, #12
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #13
    v.insert     v1, s2, #13
    v.sub        v3, v2, v9
    v.insert     v0, s3, #14
    v.insert     v1, s6, #14
    v.cmp.lt     p1, v9, v2
    v.insert     v0, s3, #15
    v.insert     v1, s1, #15
    @p1 v.sel        v4, v3, v9
    v.movi       v3, #63
    v.extract    s1, v1, #0
    v.extract    s2, v0, #0
    v.and        v5, v4, v3
    s.shli       s3, s1, #32
    v.extract    s1, v1, #1
    v.sub        v3, v2, v5
    s.or         s6, s2, s3
    s.movz       s2, #64
    v.extract    s3, v0, #1
    s.shli       s8, s1, #32
    s.shli       s1, s5, #1                      // element offset -> bytes (x2)
    s.add        s5, s6, s2
    v.extract    s2, v1, #2
    @p1 v.sel        v4, v3, v5
    v.movi       v3, #0
    v.movi       v5, #0
    s.or         s6, s3, s8
    s.movz       s3, #64
    s.add        s8, s7, s1                      // &in_ptr2[...]
    s.add        s7, s11, s1                     // &in_ptr5[...]
    s.lshri      s1, s5, #32
    v.extract    s11, v0, #2
    s.shli       s12, s2, #32
    s.add        s2, s6, s3
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s4, v12]              // index is in elements (ISA sec 9.1)
    s.or         s3, s11, s12
    s.lshri      s4, s2, #32
    v.movi       v8, #64
    v.movi       v9, #1
    v.sub        v9, v2, v8
    v.cmp.lt     p1, v8, v2
    @p1 v.sel        v2, v9, v8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s8, #0]
    vf.cvt.bf16.f32 v9, v6
    s.movz       s6, #64
    s.add        s8, s3, s6
    s.lshri      s3, s8, #32
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s9, v7]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v10, v2
    v.extract    s6, v1, #3
    v.extract    s9, v0, #3
    s.shli       s11, s6, #32
    v.extract    s6, v1, #4
    s.or         s12, s9, s11
    s.movz       s9, #64
    v.extract    s11, v0, #4
    s.shli       s15, s6, #32
    s.add        s6, s12, s9
    s.or         s9, s11, s15
    s.movz       s11, #64
    s.lshri      s12, s6, #32
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s10, v4]              // index is in elements (ISA sec 9.1)
    s.add        s15, s9, s11
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v11, [s7, #0]
    s.lshri      s7, s15, #32
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v13, [s13, v4]             // index is in elements (ISA sec 9.1)
    v.insert     v3, s5, #0
    v.insert     v5, s1, #0
    vf.cvt.bf16.f32 v14, v11
    v.insert     v3, s2, #1
    v.insert     v5, s4, #1
    v.extract    s1, v1, #5
    v.insert     v3, s8, #2
    v.insert     v5, s3, #2
    v.extract    s2, v0, #5
    s.shli       s3, s1, #32
    v.extract    s1, v1, #6
    v.insert     v3, s6, #3
    v.insert     v5, s12, #3
    s.or         s4, s2, s3
    s.movz       s2, #64
    v.extract    s3, v0, #6
    s.shli       s5, s1, #32
    s.add        s1, s4, s2
    v.extract    s2, v1, #7
    v.insert     v3, s15, #4
    v.insert     v5, s7, #4
    s.or         s4, s3, s5
    s.movz       s3, #64
    s.lshri      s5, s1, #32
    v.extract    s6, v0, #7
    s.shli       s7, s2, #32
    s.add        s2, s4, s3
    v.extract    s3, v1, #8
    v.insert     v3, s1, #5
    v.insert     v5, s5, #5
    s.or         s1, s6, s7
    s.movz       s4, #64
    s.lshri      s5, s2, #32
    v.extract    s6, v0, #8
    s.shli       s7, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v1, #9
    v.insert     v3, s2, #6
    v.insert     v5, s5, #6
    s.or         s2, s6, s7
    s.movz       s4, #64
    s.lshri      s5, s3, #32
    v.extract    s6, v0, #9
    s.shli       s7, s1, #32
    s.add        s1, s2, s4
    v.extract    s2, v1, #10
    v.insert     v3, s3, #7
    v.insert     v5, s5, #7
    s.or         s3, s6, s7
    s.movz       s4, #64
    s.lshri      s5, s1, #32
    v.extract    s6, v0, #10
    s.shli       s7, s2, #32
    s.add        s2, s3, s4
    v.extract    s3, v1, #11
    v.insert     v3, s1, #8
    v.insert     v5, s5, #8
    s.or         s1, s6, s7
    s.movz       s4, #64
    s.lshri      s5, s2, #32
    v.extract    s6, v0, #11
    s.shli       s7, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v1, #12
    v.insert     v3, s2, #9
    v.insert     v5, s5, #9
    s.or         s2, s6, s7
    s.movz       s4, #64
    s.lshri      s5, s3, #32
    v.extract    s6, v0, #12
    s.shli       s7, s1, #32
    s.add        s1, s2, s4
    v.extract    s2, v1, #13
    v.insert     v3, s3, #10
    v.insert     v5, s5, #10
    s.or         s3, s6, s7
    s.movz       s4, #64
    s.lshri      s5, s1, #32
    v.extract    s6, v0, #13
    s.shli       s7, s2, #32
    s.add        s2, s3, s4
    v.extract    s3, v1, #14
    v.insert     v3, s1, #11
    v.insert     v5, s5, #11
    s.or         s1, s6, s7
    s.movz       s4, #64
    s.lshri      s5, s2, #32
    v.extract    s6, v0, #14
    s.shli       s7, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v1, #15
    v.insert     v3, s2, #12
    v.insert     v5, s5, #12
    s.or         s2, s6, s7
    s.movz       s4, #64
    s.lshri      s5, s3, #32
    v.extract    s6, v0, #15
    s.shli       s7, s1, #32
    v.extract    s1, v1, #0
    s.add        s8, s2, s4
    v.insert     v3, s3, #13
    v.insert     v5, s5, #13
    s.or         s2, s6, s7
    s.movz       s3, #64
    v.extract    s4, v0, #0
    s.shli       s5, s1, #32
    s.lshri      s1, s8, #32
    v.extract    s6, v1, #1
    s.add        s7, s2, s3
    s.or         s2, s4, s5
    s.movz       s3, #0
    v.insert     v3, s8, #14
    v.insert     v5, s1, #14
    v.movi       v11, #0
    v.extract    s1, v0, #1
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    s.cmp.lt     s6, s2, s3
    v.extract    s2, v1, #2
    s.or         s3, s1, s4
    s.movz       s1, #0
    v.insert     v3, s7, #15
    v.insert     v5, s5, #15
    v.insert     v11, s6, #0
    v.extract    s4, v0, #2
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s3, s1
    v.extract    s1, v1, #3
    s.or         s3, s4, s5
    s.movz       s4, #0
    v.insert     v11, s2, #1
    v.extract    s2, v0, #3
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s3, s4
    v.extract    s3, v1, #4
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v11, s1, #2
    v.extract    s1, v0, #4
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v1, #5
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v11, s3, #3
    v.extract    s3, v0, #5
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v1, #6
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v11, s2, #4
    v.extract    s2, v0, #6
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v1, #7
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v11, s1, #5
    v.extract    s1, v0, #7
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v1, #8
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v11, s3, #6
    v.extract    s3, v0, #8
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v1, #9
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v11, s2, #7
    v.extract    s2, v0, #9
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v1, #10
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v11, s1, #8
    v.extract    s1, v0, #10
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v1, #11
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v11, s3, #9
    v.extract    s3, v0, #11
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v1, #12
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v11, s2, #10
    v.extract    s2, v0, #12
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v1, #13
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v11, s1, #11
    v.extract    s1, v0, #13
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v1, #14
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v11, s3, #12
    v.extract    s3, v0, #14
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v1, #15
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v11, s2, #13
    v.extract    s2, v0, #15
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s3
    s.or         s3, s2, s5
    s.movz       s2, #0
    v.insert     v11, s1, #14
    s.cmp.lt     s1, s3, s2
    v.movi       v15, #0
    v.insert     v11, s1, #15
    v.movi       v16, #1
    v.movi       v17, #0
    v.extract    s1, v5, #0
    v.extract    s2, v1, #0
    v.cmp.ne     p1, v11, v15
    v.extract    s3, v3, #0
    s.shli       s4, s1, #32
    v.extract    s1, v0, #0
    s.shli       s5, s2, #32
    @p1 v.sel        v11, v16, v17
    v.extract    s2, v5, #1
    v.extract    s6, v1, #1
    s.or         s7, s3, s4
    s.or         s3, s1, s5
    v.extract    s1, v3, #1
    s.shli       s4, s2, #32
    v.extract    s2, v0, #1
    s.shli       s5, s6, #32
    v.extract    s6, v11, #0
    s.sub        s8, s7, s3
    v.extract    s7, v5, #2
    v.extract    s9, v1, #2
    s.or         s11, s1, s4
    s.or         s1, s2, s5
    s.mul        s2, s6, s8
    v.extract    s4, v3, #2
    s.shli       s5, s7, #32
    v.extract    s6, v0, #2
    s.shli       s7, s9, #32
    v.extract    s8, v11, #1
    s.sub        s9, s11, s1
    s.or         s11, s4, s5
    s.or         s4, s6, s7
    s.mul        s5, s8, s9
    v.extract    s6, v11, #2
    s.sub        s7, s11, s4
    s.add        s8, s3, s2
    v.movi       v15, #0
    v.extract    s2, v3, #3
    v.movi       v16, #0
    v.extract    s3, v5, #3
    v.extract    s9, v1, #3
    s.shli       s11, s3, #32
    v.extract    s3, v0, #3
    s.shli       s12, s9, #32
    s.or         s9, s2, s11
    s.or         s2, s3, s12
    s.mul        s3, s6, s7
    s.lshri      s6, s8, #32
    v.extract    s7, v11, #3
    s.sub        s11, s9, s2
    s.add        s9, s1, s5
    v.insert     v15, s8, #0
    v.extract    s1, v3, #4
    v.insert     v16, s6, #0
    v.extract    s5, v5, #4
    v.extract    s6, v1, #4
    s.shli       s8, s5, #32
    v.extract    s5, v0, #4
    s.shli       s12, s6, #32
    s.or         s6, s1, s8
    s.or         s1, s5, s12
    s.mul        s5, s7, s11
    s.lshri      s7, s9, #32
    v.extract    s8, v11, #4
    s.sub        s11, s6, s1
    s.add        s6, s4, s3
    v.insert     v15, s9, #1
    v.extract    s3, v3, #5
    v.insert     v16, s7, #1
    v.extract    s4, v5, #5
    v.extract    s7, v1, #5
    s.shli       s9, s4, #32
    v.extract    s4, v0, #5
    s.shli       s12, s7, #32
    s.or         s7, s3, s9
    s.or         s3, s4, s12
    s.mul        s4, s8, s11
    s.lshri      s8, s6, #32
    v.extract    s9, v11, #5
    s.sub        s11, s7, s3
    s.add        s7, s2, s5
    v.insert     v15, s6, #2
    v.extract    s2, v3, #6
    v.insert     v16, s8, #2
    v.extract    s5, v5, #6
    v.extract    s6, v1, #6
    s.shli       s8, s5, #32
    v.extract    s5, v0, #6
    s.shli       s12, s6, #32
    s.or         s6, s2, s8
    s.or         s2, s5, s12
    s.mul        s5, s9, s11
    s.lshri      s8, s7, #32
    v.extract    s9, v11, #6
    s.sub        s11, s6, s2
    s.add        s6, s1, s4
    v.insert     v15, s7, #3
    v.extract    s1, v3, #7
    v.insert     v16, s8, #3
    v.extract    s4, v5, #7
    v.extract    s7, v1, #7
    s.shli       s8, s4, #32
    v.extract    s4, v0, #7
    s.shli       s12, s7, #32
    s.or         s7, s1, s8
    s.or         s1, s4, s12
    s.mul        s4, s9, s11
    s.lshri      s8, s6, #32
    v.extract    s9, v11, #7
    s.sub        s11, s7, s1
    s.add        s7, s3, s5
    v.insert     v15, s6, #4
    v.extract    s3, v3, #8
    v.insert     v16, s8, #4
    v.extract    s5, v5, #8
    v.extract    s6, v1, #8
    s.shli       s8, s5, #32
    v.extract    s5, v0, #8
    s.shli       s12, s6, #32
    s.or         s6, s3, s8
    s.or         s3, s5, s12
    s.mul        s5, s9, s11
    s.lshri      s8, s7, #32
    v.extract    s9, v11, #8
    s.sub        s11, s6, s3
    s.add        s6, s2, s4
    v.insert     v15, s7, #5
    v.extract    s2, v3, #9
    v.insert     v16, s8, #5
    v.extract    s4, v5, #9
    v.extract    s7, v1, #9
    s.shli       s8, s4, #32
    v.extract    s4, v0, #9
    s.shli       s12, s7, #32
    s.or         s7, s2, s8
    s.or         s2, s4, s12
    s.mul        s4, s9, s11
    s.lshri      s8, s6, #32
    v.extract    s9, v11, #9
    s.sub        s11, s7, s2
    s.add        s7, s1, s5
    v.insert     v15, s6, #6
    v.extract    s1, v3, #10
    v.insert     v16, s8, #6
    v.extract    s5, v5, #10
    v.extract    s6, v1, #10
    s.shli       s8, s5, #32
    v.extract    s5, v0, #10
    s.shli       s12, s6, #32
    s.or         s6, s1, s8
    s.or         s1, s5, s12
    s.mul        s5, s9, s11
    s.lshri      s8, s7, #32
    v.extract    s9, v11, #10
    s.sub        s11, s6, s1
    s.add        s6, s3, s4
    v.insert     v15, s7, #7
    v.extract    s3, v3, #11
    v.insert     v16, s8, #7
    v.extract    s4, v5, #11
    v.extract    s7, v1, #11
    s.shli       s8, s4, #32
    v.extract    s4, v0, #11
    s.shli       s12, s7, #32
    s.or         s7, s3, s8
    s.or         s3, s4, s12
    s.mul        s4, s9, s11
    s.lshri      s8, s6, #32
    v.extract    s9, v11, #11
    s.sub        s11, s7, s3
    s.add        s7, s2, s5
    v.insert     v15, s6, #8
    v.extract    s2, v3, #12
    v.insert     v16, s8, #8
    v.extract    s5, v5, #12
    v.extract    s6, v1, #12
    s.shli       s8, s5, #32
    v.extract    s5, v0, #12
    s.shli       s12, s6, #32
    s.or         s6, s2, s8
    s.or         s2, s5, s12
    s.mul        s5, s9, s11
    s.lshri      s8, s7, #32
    v.extract    s9, v11, #12
    s.sub        s11, s6, s2
    s.add        s6, s1, s4
    v.insert     v15, s7, #9
    v.extract    s1, v3, #13
    v.insert     v16, s8, #9
    v.extract    s4, v5, #13
    v.extract    s7, v1, #13
    s.shli       s8, s4, #32
    v.extract    s4, v0, #13
    s.shli       s12, s7, #32
    s.or         s7, s1, s8
    s.or         s1, s4, s12
    s.mul        s4, s9, s11
    s.lshri      s8, s6, #32
    v.extract    s9, v11, #13
    s.sub        s11, s7, s1
    s.add        s7, s3, s5
    v.insert     v15, s6, #10
    v.extract    s3, v3, #14
    v.insert     v16, s8, #10
    v.extract    s5, v5, #14
    v.extract    s6, v1, #14
    s.shli       s8, s5, #32
    v.extract    s5, v0, #14
    s.shli       s12, s6, #32
    s.or         s6, s3, s8
    s.or         s3, s5, s12
    s.mul        s5, s9, s11
    s.lshri      s8, s7, #32
    v.extract    s9, v11, #14
    s.sub        s11, s6, s3
    s.add        s6, s2, s4
    v.insert     v15, s7, #11
    v.extract    s2, v3, #15
    v.insert     v16, s8, #11
    v.extract    s4, v5, #15
    v.extract    s7, v1, #15
    s.shli       s8, s4, #32
    v.extract    s4, v0, #15
    s.shli       s12, s7, #32
    s.or         s7, s2, s8
    s.or         s2, s4, s12
    s.mul        s4, s9, s11
    s.lshri      s8, s6, #32
    v.extract    s9, v11, #15
    s.sub        s11, s7, s2
    s.add        s7, s1, s5
    v.insert     v15, s6, #12
    v.insert     v16, s8, #12
    s.mul        s1, s9, s11
    s.lshri      s5, s7, #32
    s.add        s6, s3, s4
    v.insert     v15, s7, #13
    v.insert     v16, s5, #13
    s.lshri      s3, s6, #32
    s.add        s4, s2, s1
    v.insert     v15, s6, #14
    v.insert     v16, s3, #14
    s.lshri      s1, s4, #32
    v.insert     v15, s4, #15
    v.insert     v16, s1, #15
    s.movz       s1, #0
    v.extract    s2, v15, #0
    v.extract    s3, v16, #0
    v.extract    s4, v16, #1
    s.shli       s5, s3, #32
    v.movi       v0, #0
    s.or         s3, s2, s5
    v.extract    s2, v15, #1
    s.shli       s5, s4, #32
    s.cmp.ge     s4, s3, s1
    v.extract    s1, v16, #2
    s.or         s3, s2, s5
    s.movz       s2, #0
    v.insert     v0, s4, #0
    v.extract    s4, v15, #2
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s3, s2
    v.extract    s2, v16, #3
    s.or         s3, s4, s5
    s.movz       s4, #0
    v.insert     v0, s1, #1
    v.extract    s1, v15, #3
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s3, s4
    v.extract    s3, v16, #4
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #2
    v.extract    s2, v15, #4
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v16, #5
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v0, s3, #3
    v.extract    s3, v15, #5
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v16, #6
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v0, s1, #4
    v.extract    s1, v15, #6
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v16, #7
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #5
    v.extract    s2, v15, #7
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v16, #8
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v0, s3, #6
    v.extract    s3, v15, #8
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v16, #9
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v0, s1, #7
    v.extract    s1, v15, #9
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v16, #10
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #8
    v.extract    s2, v15, #10
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v16, #11
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v0, s3, #9
    v.extract    s3, v15, #11
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v16, #12
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v0, s1, #10
    v.extract    s1, v15, #12
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v16, #13
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #11
    v.extract    s2, v15, #13
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v16, #14
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v0, s3, #12
    v.extract    s3, v15, #14
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v16, #15
    v.extract    s4, v16, #0
    s.or         s6, s3, s5
    s.movz       s3, #0
    v.insert     v0, s1, #13
    v.extract    s1, v15, #15
    s.shli       s5, s2, #32
    v.extract    s2, v15, #0
    s.shli       s7, s4, #32
    s.cmp.ge     s4, s6, s3
    v.extract    s3, v16, #1
    s.or         s6, s1, s5
    s.movz       s1, #0
    s.or         s5, s2, s7
    s.movz       s2, #64
    v.insert     v0, s4, #14
    v.movi       v1, #0
    v.extract    s4, v15, #1
    s.shli       s7, s3, #32
    s.cmp.ge     s3, s6, s1
    s.cmp.lt     s1, s5, s2
    v.extract    s2, v16, #2
    s.or         s5, s4, s7
    s.movz       s4, #64
    v.insert     v0, s3, #15
    v.insert     v1, s1, #0
    v.extract    s1, v15, #2
    s.shli       s3, s2, #32
    s.cmp.lt     s2, s5, s4
    v.extract    s4, v16, #3
    s.or         s5, s1, s3
    s.movz       s1, #64
    v.insert     v1, s2, #1
    v.extract    s2, v15, #3
    s.shli       s3, s4, #32
    s.cmp.lt     s4, s5, s1
    v.extract    s1, v16, #4
    s.or         s5, s2, s3
    s.movz       s2, #64
    v.insert     v1, s4, #2
    v.extract    s3, v15, #4
    s.shli       s4, s1, #32
    s.cmp.lt     s1, s5, s2
    v.extract    s2, v16, #5
    s.or         s5, s3, s4
    s.movz       s3, #64
    v.insert     v1, s1, #3
    v.extract    s1, v15, #5
    s.shli       s4, s2, #32
    s.cmp.lt     s2, s5, s3
    v.extract    s3, v16, #6
    s.or         s5, s1, s4
    s.movz       s1, #64
    v.insert     v1, s2, #4
    v.extract    s2, v15, #6
    s.shli       s4, s3, #32
    s.cmp.lt     s3, s5, s1
    v.movi       v3, #0
    s.or         s1, s2, s4
    v.insert     v1, s3, #5
    v.cmp.ne     p1, v0, v3
    v.extract    s2, v16, #7
    s.movz       s3, #64
    v.extract    s4, v15, #7
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s1, s3
    v.extract    s1, v16, #8
    s.or         s3, s4, s5
    s.movz       s4, #64
    v.insert     v1, s2, #6
    v.extract    s2, v15, #8
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s3, s4
    v.extract    s3, v16, #9
    s.or         s4, s2, s5
    s.movz       s2, #64
    v.insert     v1, s1, #7
    v.extract    s1, v15, #9
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v16, #10
    s.or         s4, s1, s5
    s.movz       s1, #64
    v.insert     v1, s3, #8
    v.extract    s3, v15, #10
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v16, #11
    s.or         s4, s3, s5
    s.movz       s3, #64
    v.insert     v1, s2, #9
    v.extract    s2, v15, #11
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v16, #12
    s.or         s4, s2, s5
    s.movz       s2, #64
    v.insert     v1, s1, #10
    v.extract    s1, v15, #12
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v16, #13
    s.or         s4, s1, s5
    s.movz       s1, #64
    v.insert     v1, s3, #11
    v.extract    s3, v15, #13
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v16, #14
    s.or         s4, s3, s5
    s.movz       s3, #64
    v.insert     v1, s2, #12
    v.extract    s2, v15, #14
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v16, #15
    s.or         s4, s2, s5
    s.movz       s2, #64
    v.insert     v1, s1, #13
    v.extract    s1, v15, #15
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    s.or         s2, s1, s5
    s.movz       s1, #64
    v.insert     v1, s3, #14
    s.cmp.lt     s3, s2, s1
    v.movi       v0, #0
    v.insert     v1, s3, #15
    v.movi       v3, #0
    v.movi       v5, #1
    v.cmp.ne     p2, v1, v0
    p.and        p4, p1, p2
    s.movz       s1, #0
    @p4 v.sel        v0, v3, v5
    v.reduce.or  s2, v0
    s.cmp.eq     s3, s2, s1
    br.nz        s3, assert_ok_1
    trap         #677351
assert_ok_1:
    v.extract    s1, v4, #0
    v.extract    s2, v4, #1
    s.shli       s3, s1, #32
    v.movi       v0, #0
    s.ashri      s1, s3, #32
    v.movi       v1, #0
    s.shli       s3, s2, #32
    s.lshri      s2, s1, #32
    v.extract    s4, v4, #2
    s.ashri      s5, s3, #32
    v.insert     v0, s1, #0
    v.insert     v1, s2, #0
    s.shli       s1, s4, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v4, #3
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #1
    v.insert     v1, s2, #1
    s.lshri      s1, s4, #32
    v.insert     v0, s4, #2
    v.insert     v1, s1, #2
    .li       s1, #1124073472
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s1, s3, #32
    .li       s2, #1065353216
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v11, v3                         // ISA 8.8: <= 2**-22 relative
    s.ashri      s2, s1, #32
    .li       s1, #897988541
    v.splat      v17, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.insert     v0, s2, #3
    .li       s1, #1077936128
    v.splat      v18, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v19, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v20, v3, v11, v5
    s.lshri      s1, s2, #32
    vf.fms       v5, v11, v20, v11
    v.insert     v1, s1, #3
    vf.neg       v20, v5                         // Newton step: r0*(2 - x*r0)
    v.extract    s1, v4, #4
    vf.cmp.o     p1, v20, v20
    s.shli       s2, s1, #32
    @p1 v.sel        v5, v20, v11
    s.ashri      s1, s2, #32
    vf.mul       v11, v6, v5                     // a/y: faithful quotient
    v.insert     v0, s1, #4
    vf.fms       v20, v11, v3, v6
    s.lshri      s2, s1, #32
    vf.fms       v3, v20, v5, v11
    v.insert     v1, s2, #4
    vf.neg       v5, v3                          // a/y: one correction to the IEEE quotient
    v.extract    s1, v4, #5
    vf.cmp.o     p1, v5, v5
    s.shli       s2, s1, #32
    @p1 v.sel        v3, v5, v11
    s.ashri      s1, s2, #32
    v.insert     v0, s1, #5
    vf.add       v5, v3, v17
    s.lshri      s2, s1, #32
    v.rsqrt.approx v3, v5                        // ISA 8.8: <= 2**-22 relative
    v.insert     v1, s2, #5
    vf.mul       v6, v3, v3
    v.extract    s1, v4, #6
    vf.mul       v11, v3, v19
    s.shli       s2, s1, #32
    vf.fms       v17, v5, v6, v18
    s.ashri      s1, s2, #32
    s.lshri      s2, s1, #32
    v.insert     v0, s1, #6
    vf.mul       v5, v11, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.insert     v1, s2, #6
    vf.cmp.o     p1, v5, v5
    v.extract    s1, v4, #7
    @p1 v.sel        v6, v5, v3
    s.shli       s2, s1, #32
    vf.mul       v3, v10, v6
    s.ashri      s1, s2, #32
    vf.mul       v5, v9, v3
    v.extract    s2, v4, #8
    s.lshri      s3, s1, #32
    s.shli       s4, s2, #32
    v.extract    s2, v4, #9
    s.ashri      s5, s4, #32
    v.insert     v0, s1, #7
    v.insert     v1, s3, #7
    s.shli       s1, s2, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v4, #10
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #8
    v.insert     v1, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v4, #11
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #9
    v.insert     v1, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v4, #12
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #10
    v.insert     v1, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v4, #13
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #11
    v.insert     v1, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v4, #14
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #12
    v.insert     v1, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v4, #15
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #13
    v.insert     v1, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    s.ashri      s3, s1, #32
    v.insert     v0, s5, #14
    v.insert     v1, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #15
    v.insert     v1, s1, #15
    s.movz       s1, #2
    v.extract    s2, v0, #0
    v.extract    s3, v1, #0
    v.extract    s4, v1, #1
    s.shli       s5, s3, #32
    v.movi       v3, #0
    s.or         s3, s2, s5
    v.extract    s2, v0, #1
    s.shli       s5, s4, #32
    s.cmp.ge     s4, s3, s1
    v.extract    s1, v1, #2
    s.or         s3, s2, s5
    s.movz       s2, #2
    v.insert     v3, s4, #0
    v.extract    s4, v0, #2
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s3, s2
    v.extract    s2, v1, #3
    s.or         s3, s4, s5
    s.movz       s4, #2
    v.insert     v3, s1, #1
    v.extract    s1, v0, #3
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s3, s4
    v.extract    s3, v1, #4
    s.or         s4, s1, s5
    s.movz       s1, #2
    v.insert     v3, s2, #2
    v.extract    s2, v0, #4
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v1, #5
    s.or         s4, s2, s5
    s.movz       s2, #2
    v.insert     v3, s3, #3
    v.extract    s3, v0, #5
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v1, #6
    s.or         s4, s3, s5
    s.movz       s3, #2
    v.insert     v3, s1, #4
    v.extract    s1, v0, #6
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v1, #7
    s.or         s4, s1, s5
    s.movz       s1, #2
    v.insert     v3, s2, #5
    v.extract    s2, v0, #7
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v1, #8
    s.or         s4, s2, s5
    s.movz       s2, #2
    v.insert     v3, s3, #6
    v.extract    s3, v0, #8
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v1, #9
    s.or         s4, s3, s5
    s.movz       s3, #2
    v.insert     v3, s1, #7
    v.extract    s1, v0, #9
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v1, #10
    s.or         s4, s1, s5
    s.movz       s1, #2
    v.insert     v3, s2, #8
    v.extract    s2, v0, #10
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v1, #11
    s.or         s4, s2, s5
    s.movz       s2, #2
    v.insert     v3, s3, #9
    v.extract    s3, v0, #11
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v1, #12
    s.or         s4, s3, s5
    s.movz       s3, #2
    v.insert     v3, s1, #10
    v.extract    s1, v0, #12
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v1, #13
    s.or         s4, s1, s5
    s.movz       s1, #2
    v.insert     v3, s2, #11
    v.extract    s2, v0, #13
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v1, #14
    s.or         s4, s2, s5
    s.movz       s2, #2
    v.insert     v3, s3, #12
    v.extract    s3, v0, #14
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v1, #15
    v.extract    s4, v1, #0
    s.or         s6, s3, s5
    s.movz       s3, #2
    v.insert     v3, s1, #13
    v.extract    s1, v0, #15
    s.shli       s5, s2, #32
    v.extract    s2, v0, #0
    s.shli       s7, s4, #32
    s.cmp.ge     s4, s6, s3
    v.extract    s3, v1, #1
    s.or         s6, s1, s5
    s.movz       s1, #2
    s.or         s5, s2, s7
    s.movz       s2, #60
    v.insert     v3, s4, #14
    v.movi       v4, #0
    v.extract    s4, v0, #1
    s.shli       s7, s3, #32
    s.cmp.ge     s3, s6, s1
    s.cmp.lt     s1, s5, s2
    v.extract    s2, v1, #2
    s.or         s5, s4, s7
    s.movz       s4, #60
    v.insert     v3, s3, #15
    v.insert     v4, s1, #0
    v.extract    s1, v0, #2
    s.shli       s3, s2, #32
    s.cmp.lt     s2, s5, s4
    v.extract    s4, v1, #3
    s.or         s5, s1, s3
    s.movz       s1, #60
    v.insert     v4, s2, #1
    v.extract    s2, v0, #3
    s.shli       s3, s4, #32
    s.cmp.lt     s4, s5, s1
    v.extract    s1, v1, #4
    s.or         s5, s2, s3
    s.movz       s2, #60
    v.insert     v4, s4, #2
    v.extract    s3, v0, #4
    s.shli       s4, s1, #32
    s.cmp.lt     s1, s5, s2
    v.extract    s2, v1, #5
    s.or         s5, s3, s4
    s.movz       s3, #60
    v.insert     v4, s1, #3
    v.extract    s1, v0, #5
    s.shli       s4, s2, #32
    s.cmp.lt     s2, s5, s3
    v.extract    s3, v1, #6
    s.or         s5, s1, s4
    s.movz       s1, #60
    v.insert     v4, s2, #4
    v.extract    s2, v0, #6
    s.shli       s4, s3, #32
    s.cmp.lt     s3, s5, s1
    v.movi       v6, #0
    s.or         s1, s2, s4
    v.insert     v4, s3, #5
    v.cmp.ne     p1, v3, v6
    v.extract    s2, v1, #7
    s.movz       s3, #60
    v.extract    s4, v0, #7
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s1, s3
    v.extract    s1, v1, #8
    s.or         s3, s4, s5
    s.movz       s4, #60
    v.insert     v4, s2, #6
    v.extract    s2, v0, #8
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s3, s4
    v.extract    s3, v1, #9
    s.or         s4, s2, s5
    s.movz       s2, #60
    v.insert     v4, s1, #7
    v.extract    s1, v0, #9
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v1, #10
    s.or         s4, s1, s5
    s.movz       s1, #60
    v.insert     v4, s3, #8
    v.extract    s3, v0, #10
    s.shli       s5, s2, #32
    v.movi       v3, #0
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v1, #11
    s.or         s4, s3, s5
    s.movz       s3, #60
    v.insert     v4, s2, #9
    v.extract    s2, v0, #11
    s.shli       s5, s1, #32
    v.sub        v6, v3, v12
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v1, #12
    s.or         s4, s2, s5
    s.movz       s2, #60
    v.cmp.lt     p2, v12, v3
    v.insert     v4, s1, #10
    v.extract    s1, v0, #12
    s.shli       s5, s3, #32
    @p2 v.sel        v9, v6, v12
    v.movi       v6, #63
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v1, #13
    s.or         s4, s1, s5
    s.movz       s1, #60
    v.insert     v4, s3, #11
    v.extract    s3, v0, #13
    s.shli       s5, s2, #32
    v.and        v10, v9, v6
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v1, #14
    s.or         s4, s3, s5
    s.movz       s3, #60
    v.insert     v4, s2, #12
    v.extract    s2, v0, #14
    s.shli       s5, s1, #32
    v.sub        v6, v3, v10
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v1, #15
    s.or         s4, s2, s5
    s.movz       s2, #60
    v.insert     v4, s1, #13
    v.extract    s1, v0, #15
    s.shli       s5, s3, #32
    @p2 v.sel        v0, v6, v10
    v.movi       v1, #-2
    s.cmp.lt     s3, s4, s2
    s.or         s2, s1, s5
    s.movz       s1, #60
    v.insert     v4, s3, #14
    v.add        v6, v0, v1
    v.movi       v0, #3
    v.movi       v1, #0
    s.cmp.lt     s3, s2, s1
    v.movi       v9, #0
    v.insert     v4, s3, #15
    v.sub        v10, v3, v8
    v.sub        v11, v1, v6
    v.sub        v17, v1, v0
    v.cmp.lt     p2, v8, v3
    v.cmp.lt     p4, v6, v1
    v.cmp.lt     p5, v0, v1
    v.cmp.ne     p6, v4, v9
    v.movi       v3, #1
    @p2 v.sel        v3, v10, v8
    .li       s1, #-2
    v.movi       v3, #1
    @p4 v.sel        v4, v11, v6
    @p5 v.sel        v8, v17, v0
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v11, s1
    v.shl        v17, v10, v3
    v.cmp.lt     p2, v10, v1
    v.lshr       v18, v4, v11
    v.shl        v19, v3, v11
    s.subi       s2, s1, #1
    v.and        v11, v18, v3
    s.movz       s3, #0
    v.or         v18, v17, v11
    v.cmp.geu    p5, v18, v8
    p.or         p7, p2, p5
    v.sub        v11, v18, v8
    @p7 v.sel        v17, v19, v1
    @p7 v.sel        v19, v11, v18
    v.or         v11, v9, v17
    v.mov        v10, v19
    v.mov        v9, v11
    s.mov        s1, s2
    s.cmp.ge     s2, s1, s3
    br.nz        s2, idiv_2
    v.sub        v3, v1, v10
    v.movi       v1, #0
    v.movi       v4, #0
    @p4 v.sel        v8, v3, v10
    v.extract    s1, v8, #0
    v.extract    s2, v8, #1
    s.shli       s3, s1, #32
    s.shli       s1, s2, #32
    s.ashri      s2, s3, #32
    v.extract    s3, v8, #2
    s.lshri      s4, s2, #32
    s.ashri      s5, s1, #32
    v.insert     v1, s2, #0
    v.insert     v4, s4, #0
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #3
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #1
    v.insert     v4, s2, #1
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v8, #4
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #2
    v.insert     v4, s2, #2
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #5
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #3
    v.insert     v4, s2, #3
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v8, #6
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #4
    v.insert     v4, s2, #4
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #7
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #5
    v.insert     v4, s2, #5
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v8, #8
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #6
    v.insert     v4, s2, #6
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #9
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #7
    v.insert     v4, s2, #7
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v8, #10
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #8
    v.insert     v4, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #11
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #9
    v.insert     v4, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v8, #12
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #10
    v.insert     v4, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #13
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #11
    v.insert     v4, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v8, #14
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #12
    v.insert     v4, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v8, #15
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #13
    v.insert     v4, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    s.ashri      s3, s1, #32
    v.insert     v1, s4, #14
    v.insert     v4, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v1, s3, #15
    v.insert     v4, s1, #15
    s.movz       s1, #0
    v.extract    s2, v1, #0
    v.extract    s3, v4, #0
    v.extract    s4, v4, #1
    s.shli       s5, s3, #32
    v.movi       v3, #0
    s.or         s3, s2, s5
    v.extract    s2, v1, #1
    s.shli       s5, s4, #32
    s.cmp.eq     s4, s3, s1
    v.extract    s1, v4, #2
    s.or         s3, s2, s5
    s.movz       s2, #0
    v.insert     v3, s4, #0
    v.extract    s4, v1, #2
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s3, s2
    v.extract    s2, v4, #3
    s.or         s3, s4, s5
    s.movz       s4, #0
    v.insert     v3, s1, #1
    v.extract    s1, v1, #3
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s3, s4
    v.extract    s3, v4, #4
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v3, s2, #2
    v.extract    s2, v1, #4
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v4, #5
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v3, s3, #3
    v.extract    s3, v1, #5
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v4, #6
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v3, s1, #4
    v.extract    s1, v1, #6
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    v.extract    s3, v4, #7
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v3, s2, #5
    v.extract    s2, v1, #7
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v4, #8
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v3, s3, #6
    v.extract    s3, v1, #8
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v4, #9
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v3, s1, #7
    v.extract    s1, v1, #9
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    v.extract    s3, v4, #10
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v3, s2, #8
    v.extract    s2, v1, #10
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v4, #11
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v3, s3, #9
    v.extract    s3, v1, #11
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v4, #12
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v3, s1, #10
    v.extract    s1, v1, #12
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    v.extract    s3, v4, #13
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v3, s2, #11
    v.extract    s2, v1, #13
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v4, #14
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v3, s3, #12
    v.extract    s3, v1, #14
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v4, #15
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v3, s1, #13
    v.extract    s1, v1, #15
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    s.or         s3, s1, s5
    s.movz       s1, #0
    v.insert     v3, s2, #14
    s.cmp.eq     s2, s3, s1
    v.movi       v1, #0
    v.insert     v3, s2, #15
    v.movi       v4, #0
    v.sub        v9, v1, v6
    v.sub        v10, v1, v0
    p.and        p2, p1, p6
    v.cmp.ne     p1, v3, v4
    v.cmp.lt     p4, v6, v1
    v.cmp.lt     p5, v0, v1
    p.and        p6, p2, p1
    v.movi       v3, #1
    @p4 v.sel        v4, v9, v6
    @p5 v.sel        v9, v10, v0
    v.movi       v10, #0
    v.movi       v11, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v17, s1
    v.shl        v18, v11, v3
    v.cmp.lt     p1, v11, v1
    v.lshr       v19, v4, v17
    v.shl        v20, v3, v17
    s.subi       s2, s1, #1
    v.and        v17, v19, v3
    s.movz       s3, #0
    v.or         v19, v18, v17
    v.cmp.geu    p2, v19, v9
    p.or         p7, p1, p2
    v.sub        v17, v19, v9
    @p7 v.sel        v18, v20, v1
    @p7 v.sel        v20, v17, v19
    v.or         v17, v10, v18
    v.mov        v11, v20
    v.mov        v10, v17
    s.mov        s1, s2
    s.cmp.ge     s2, s1, s3
    br.nz        s2, idiv_3
    v.sub        v3, v1, v10
    p.xor        p1, p4, p5
    v.movi       v1, #1
    @p1 v.sel        v4, v3, v10
    v.movi       v3, #0
    v.extract    s1, v16, #0
    v.sub        v9, v4, v1
    v.cmp.ne     p1, v8, v3
    v.extract    s2, v15, #0
    @p1 v.sel        v1, v9, v4
    s.shli       s3, s1, #32
    v.cmp.lt     p1, v6, v3
    v.extract    s1, v16, #1
    @p1 v.sel        v3, v1, v4
    s.or         s4, s2, s3
    s.movz       s2, #128
    v.extract    s3, v15, #1
    s.shli       s5, s1, #32
    s.mul        s1, s4, s2
    v.extract    s2, v16, #2
    v.mul        v1, v3, v0
    v.movi       v0, #130
    s.or         s4, s3, s5
    s.movz       s3, #128
    v.extract    s5, v15, #2
    s.shli       s6, s2, #32
    s.mul        s2, s4, s3
    v.add        v3, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    s.or         s3, s5, s6
    s.movz       s4, #128
    p.and        p1, p6, p3
    s.lshri      s5, s1, #32
    s.mul        s6, s3, s4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s10, v3]              // index is in elements (ISA sec 9.1)
    s.lshri      s3, s2, #32
    s.movz       s4, #1
    v.extract    s4, v16, #3
    s.movz       s7, #3
    s.shli       s7, s4, #32
    s.movz       s4, #130
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s13, v3]              // index is in elements (ISA sec 9.1)
    v.extract    s4, v15, #3
    v.insert     v0, s1, #0
    v.extract    s1, v16, #4
    v.insert     v1, s5, #0
    s.or         s5, s4, s7
    s.movz       s4, #128
    v.extract    s7, v15, #4
    s.shli       s8, s1, #32
    s.mul        s1, s5, s4
    v.insert     v0, s2, #1
    v.insert     v1, s3, #1
    s.or         s2, s7, s8
    s.lshri      s3, s6, #32
    v.insert     v0, s6, #2
    v.insert     v1, s3, #2
    s.lshri      s3, s1, #32
    v.insert     v0, s1, #3
    v.insert     v1, s3, #3
    @p6 v.sel        v3, v4, v2
    s.movz       s1, #128
    @p6 v.sel        v2, v6, v13
    vf.mul       v4, v5, v3
    s.mul        s3, s2, s1
    vf.mul       v3, v14, v2
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #4
    v.insert     v1, s1, #4
    vf.add       v2, v4, v3
    v.extract    s1, v16, #5
    v.extract    s2, v15, #5
    s.shli       s3, s1, #32
    v.extract    s1, v16, #6
    s.or         s4, s2, s3
    s.movz       s2, #128
    v.extract    s3, v15, #6
    s.shli       s5, s1, #32
    s.mul        s1, s4, s2
    v.extract    s2, v16, #7
    s.or         s4, s3, s5
    s.movz       s3, #128
    v.extract    s5, v15, #7
    s.shli       s6, s2, #32
    s.mul        s2, s4, s3
    v.extract    s3, v16, #8
    s.or         s4, s5, s6
    s.movz       s5, #128
    s.lshri      s6, s1, #32
    v.extract    s7, v15, #8
    s.shli       s8, s3, #32
    s.mul        s3, s4, s5
    v.extract    s4, v16, #9
    v.insert     v0, s1, #5
    v.insert     v1, s6, #5
    s.or         s1, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s2, #32
    v.extract    s7, v15, #9
    s.shli       s8, s4, #32
    s.mul        s4, s1, s5
    v.extract    s1, v16, #10
    v.insert     v0, s2, #6
    v.insert     v1, s6, #6
    s.or         s2, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s3, #32
    v.extract    s7, v15, #10
    s.shli       s8, s1, #32
    s.mul        s1, s2, s5
    v.extract    s2, v16, #11
    v.insert     v0, s3, #7
    v.insert     v1, s6, #7
    s.or         s3, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s4, #32
    v.extract    s7, v15, #11
    s.shli       s8, s2, #32
    s.mul        s2, s3, s5
    v.extract    s3, v16, #12
    v.insert     v0, s4, #8
    v.insert     v1, s6, #8
    s.or         s4, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s1, #32
    v.extract    s7, v15, #12
    s.shli       s8, s3, #32
    s.mul        s3, s4, s5
    v.extract    s4, v16, #13
    v.insert     v0, s1, #9
    v.insert     v1, s6, #9
    s.or         s1, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s2, #32
    v.extract    s7, v15, #13
    s.shli       s8, s4, #32
    s.mul        s4, s1, s5
    v.extract    s1, v16, #14
    v.insert     v0, s2, #10
    v.insert     v1, s6, #10
    s.or         s2, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s3, #32
    v.extract    s7, v15, #14
    s.shli       s8, s1, #32
    s.mul        s1, s2, s5
    v.extract    s2, v16, #15
    v.insert     v0, s3, #11
    v.insert     v1, s6, #11
    s.or         s3, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s4, #32
    v.extract    s7, v15, #15
    s.shli       s8, s2, #32
    s.mul        s2, s3, s5
    v.insert     v0, s4, #12
    v.insert     v1, s6, #12
    s.or         s3, s7, s8
    s.movz       s4, #128
    s.lshri      s5, s1, #32
    v.extract    s6, v12, #0
    s.mul        s7, s3, s4
    v.insert     v0, s1, #13
    v.insert     v1, s5, #13
    s.shli       s1, s6, #32
    s.lshri      s3, s2, #32
    v.extract    s4, v12, #1
    s.ashri      s5, s1, #32
    v.insert     v0, s2, #14
    v.insert     v1, s3, #14
    v.movi       v3, #0
    v.movi       v4, #0
    s.shli       s1, s4, #32
    s.lshri      s2, s7, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v12, #2
    s.ashri      s6, s1, #32
    v.insert     v0, s7, #15
    v.insert     v1, s2, #15
    v.insert     v3, s5, #0
    v.insert     v4, s3, #0
    s.shli       s1, s4, #32
    s.lshri      s2, s6, #32
    v.extract    s3, v12, #3
    s.ashri      s4, s1, #32
    v.insert     v3, s6, #1
    v.insert     v4, s2, #1
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #4
    s.ashri      s5, s1, #32
    v.insert     v3, s4, #2
    v.insert     v4, s2, #2
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #5
    s.ashri      s4, s1, #32
    v.insert     v3, s5, #3
    v.insert     v4, s2, #3
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #6
    s.ashri      s5, s1, #32
    v.insert     v3, s4, #4
    v.insert     v4, s2, #4
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #7
    s.ashri      s4, s1, #32
    v.insert     v3, s5, #5
    v.insert     v4, s2, #5
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #8
    s.ashri      s5, s1, #32
    v.insert     v3, s4, #6
    v.insert     v4, s2, #6
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #9
    s.ashri      s4, s1, #32
    v.insert     v3, s5, #7
    v.insert     v4, s2, #7
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #10
    s.ashri      s5, s1, #32
    v.insert     v3, s4, #8
    v.insert     v4, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #11
    s.ashri      s4, s1, #32
    v.insert     v3, s5, #9
    v.insert     v4, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #12
    s.ashri      s5, s1, #32
    v.insert     v3, s4, #10
    v.insert     v4, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #13
    s.ashri      s4, s1, #32
    v.insert     v3, s5, #11
    v.insert     v4, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #14
    s.ashri      s5, s1, #32
    v.insert     v3, s4, #12
    v.insert     v4, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #15
    s.ashri      s4, s1, #32
    v.insert     v3, s5, #13
    v.insert     v4, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    s.ashri      s3, s1, #32
    v.insert     v3, s4, #14
    v.insert     v4, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v3, s3, #15
    v.insert     v4, s1, #15
    v.extract    s1, v1, #0
    v.extract    s2, v3, #0
    v.extract    s3, v4, #0
    v.extract    s4, v0, #0
    s.shli       s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v4, #1
    v.extract    s6, v1, #1
    s.or         s7, s2, s5
    s.or         s2, s4, s3
    v.extract    s3, v3, #1
    s.shli       s4, s1, #32
    v.extract    s1, v0, #1
    s.shli       s5, s6, #32
    s.add        s6, s7, s2
    v.extract    s2, v4, #2
    v.extract    s7, v1, #2
    v.movi       v5, #0
    v.movi       v6, #0
    s.or         s8, s3, s4
    s.or         s3, s1, s5
    s.lshri      s1, s6, #32
    v.extract    s4, v3, #2
    s.shli       s5, s2, #32
    s.shli       s2, s7, #32
    s.add        s7, s8, s3
    v.extract    s3, v0, #2
    v.insert     v5, s6, #0
    v.extract    s6, v4, #3
    v.insert     v6, s1, #0
    v.extract    s1, v1, #3
    s.or         s8, s4, s5
    s.or         s4, s3, s2
    s.lshri      s2, s7, #32
    v.extract    s3, v3, #3
    s.shli       s5, s6, #32
    s.shli       s6, s1, #32
    s.add        s1, s8, s4
    v.extract    s4, v0, #3
    v.insert     v5, s7, #1
    v.extract    s7, v4, #4
    v.insert     v6, s2, #1
    v.extract    s2, v1, #4
    s.or         s8, s3, s5
    s.or         s3, s4, s6
    s.lshri      s4, s1, #32
    v.extract    s5, v3, #4
    s.shli       s6, s7, #32
    s.shli       s7, s2, #32
    s.add        s2, s8, s3
    v.extract    s3, v0, #4
    v.insert     v5, s1, #2
    v.extract    s1, v4, #5
    v.insert     v6, s4, #2
    v.extract    s4, v1, #5
    s.or         s8, s5, s6
    s.or         s5, s3, s7
    s.lshri      s3, s2, #32
    v.extract    s6, v3, #5
    s.shli       s7, s1, #32
    s.shli       s1, s4, #32
    s.add        s4, s8, s5
    v.extract    s5, v0, #5
    v.insert     v5, s2, #3
    v.extract    s2, v4, #6
    v.insert     v6, s3, #3
    v.extract    s3, v1, #6
    s.or         s8, s6, s7
    s.or         s6, s5, s1
    s.lshri      s1, s4, #32
    v.extract    s5, v3, #6
    s.shli       s7, s2, #32
    s.shli       s2, s3, #32
    s.add        s3, s8, s6
    v.extract    s6, v0, #6
    v.insert     v5, s4, #4
    v.extract    s4, v4, #7
    v.insert     v6, s1, #4
    v.extract    s1, v1, #7
    s.or         s8, s5, s7
    s.or         s5, s6, s2
    s.lshri      s2, s3, #32
    v.extract    s6, v3, #7
    s.shli       s7, s4, #32
    s.shli       s4, s1, #32
    s.add        s1, s8, s5
    v.extract    s5, v0, #7
    v.insert     v5, s3, #5
    v.extract    s3, v4, #8
    v.insert     v6, s2, #5
    v.extract    s2, v1, #8
    s.or         s8, s6, s7
    s.or         s6, s5, s4
    s.lshri      s4, s1, #32
    v.extract    s5, v3, #8
    s.shli       s7, s3, #32
    s.shli       s3, s2, #32
    s.add        s2, s8, s6
    v.extract    s6, v0, #8
    v.insert     v5, s1, #6
    v.extract    s1, v4, #9
    v.insert     v6, s4, #6
    v.extract    s4, v1, #9
    s.or         s8, s5, s7
    s.or         s5, s6, s3
    s.lshri      s3, s2, #32
    v.extract    s6, v3, #9
    s.shli       s7, s1, #32
    s.shli       s1, s4, #32
    s.add        s4, s8, s5
    v.extract    s5, v0, #9
    v.insert     v5, s2, #7
    v.extract    s2, v4, #10
    v.insert     v6, s3, #7
    v.extract    s3, v1, #10
    s.or         s8, s6, s7
    s.or         s6, s5, s1
    s.lshri      s1, s4, #32
    v.extract    s5, v3, #10
    s.shli       s7, s2, #32
    s.shli       s2, s3, #32
    s.add        s3, s8, s6
    v.extract    s6, v0, #10
    v.insert     v5, s4, #8
    v.extract    s4, v4, #11
    v.insert     v6, s1, #8
    v.extract    s1, v1, #11
    s.or         s8, s5, s7
    s.or         s5, s6, s2
    s.lshri      s2, s3, #32
    v.extract    s6, v3, #11
    s.shli       s7, s4, #32
    s.shli       s4, s1, #32
    s.add        s1, s8, s5
    v.extract    s5, v0, #11
    v.insert     v5, s3, #9
    v.extract    s3, v4, #12
    v.insert     v6, s2, #9
    v.extract    s2, v1, #12
    s.or         s8, s6, s7
    s.or         s6, s5, s4
    s.lshri      s4, s1, #32
    v.extract    s5, v3, #12
    s.shli       s7, s3, #32
    s.shli       s3, s2, #32
    s.add        s2, s8, s6
    v.extract    s6, v0, #12
    v.insert     v5, s1, #10
    v.extract    s1, v4, #13
    v.insert     v6, s4, #10
    v.extract    s4, v1, #13
    s.or         s8, s5, s7
    s.or         s5, s6, s3
    s.lshri      s3, s2, #32
    v.extract    s6, v3, #13
    s.shli       s7, s1, #32
    s.shli       s1, s4, #32
    s.add        s4, s8, s5
    v.extract    s5, v0, #13
    v.insert     v5, s2, #11
    v.extract    s2, v4, #14
    v.insert     v6, s3, #11
    v.movi       v8, #8192
    v.extract    s3, v1, #14
    s.or         s8, s6, s7
    s.or         s6, s5, s1
    s.lshri      s1, s4, #32
    v.extract    s5, v3, #14
    s.shli       s7, s2, #32
    s.shli       s2, s3, #32
    v.mul        v9, v7, v8
    s.add        s3, s8, s6
    v.extract    s6, v0, #14
    v.insert     v5, s4, #12
    v.extract    s4, v4, #15
    v.insert     v6, s1, #12
    v.extract    s1, v1, #15
    s.or         s8, s5, s7
    s.or         s5, s6, s2
    s.lshri      s2, s3, #32
    v.extract    s6, v3, #15
    s.shli       s7, s4, #32
    s.shli       s4, s1, #32
    s.add        s1, s8, s5
    v.extract    s5, v0, #15
    v.insert     v5, s3, #13
    v.extract    s3, v9, #0
    v.insert     v6, s2, #13
    s.or         s2, s6, s7
    s.or         s6, s5, s4
    s.shli       s4, s3, #32
    s.lshri      s3, s1, #32
    v.extract    s5, v9, #1
    s.add        s7, s2, s6
    s.ashri      s2, s4, #32
    v.insert     v5, s1, #14
    v.insert     v6, s3, #14
    v.movi       v0, #0
    v.movi       v1, #0
    s.shli       s1, s5, #32
    s.lshri      s3, s7, #32
    s.lshri      s4, s2, #32
    v.extract    s5, v9, #2
    s.ashri      s6, s1, #32
    v.insert     v5, s7, #15
    v.insert     v6, s3, #15
    v.insert     v0, s2, #0
    v.insert     v1, s4, #0
    s.shli       s1, s5, #32
    s.lshri      s2, s6, #32
    v.extract    s3, v9, #3
    s.ashri      s4, s1, #32
    v.insert     v0, s6, #1
    v.insert     v1, s2, #1
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #4
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #2
    v.insert     v1, s2, #2
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #5
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #3
    v.insert     v1, s2, #3
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #6
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #4
    v.insert     v1, s2, #4
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #7
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #5
    v.insert     v1, s2, #5
    s.lshri      s1, s4, #32
    v.insert     v0, s4, #6
    v.insert     v1, s1, #6
    s.movz       s1, #8192
    s.shli       s1, s3, #32
    v.extract    s2, v9, #8
    s.ashri      s3, s1, #32
    s.shli       s1, s2, #32
    s.lshri      s2, s3, #32
    v.extract    s4, v9, #9
    s.ashri      s5, s1, #32
    v.insert     v0, s3, #7
    v.insert     v1, s2, #7
    s.shli       s1, s4, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #10
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #8
    v.insert     v1, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #11
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #9
    v.insert     v1, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #12
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #10
    v.insert     v1, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #13
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #11
    v.insert     v1, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #14
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #12
    v.insert     v1, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #15
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #13
    v.insert     v1, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    s.ashri      s3, s1, #32
    v.insert     v0, s5, #14
    v.insert     v1, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #15
    v.insert     v1, s1, #15
    v.extract    s1, v6, #0
    v.extract    s2, v5, #0
    v.extract    s3, v1, #0
    s.shli       s4, s1, #32
    v.extract    s1, v0, #0
    s.shli       s5, s3, #32
    v.extract    s3, v6, #1
    v.extract    s6, v1, #1
    s.or         s7, s2, s4
    s.or         s2, s1, s5
    v.movi       v3, #0
    v.extract    s1, v5, #1
    s.shli       s4, s3, #32
    v.extract    s3, v0, #1
    s.shli       s5, s6, #32
    s.add        s6, s7, s2
    v.extract    s2, v6, #2
    v.extract    s7, v1, #2
    s.or         s8, s1, s4
    s.or         s1, s3, s5
    v.movi       v4, #0
    v.insert     v3, s6, #0
    v.extract    s3, v5, #2
    s.shli       s4, s2, #32
    v.extract    s2, v0, #2
    s.shli       s5, s7, #32
    s.lshri      s7, s6, #32
    s.add        s6, s8, s1
    v.extract    s1, v6, #3
    s.or         s8, s3, s4
    v.extract    s3, v1, #3
    s.or         s4, s2, s5
    v.insert     v4, s7, #0
    v.insert     v3, s6, #1
    v.extract    s2, v5, #3
    s.shli       s5, s1, #32
    v.extract    s1, v0, #3
    s.shli       s7, s3, #32
    s.lshri      s3, s6, #32
    s.add        s6, s8, s4
    v.extract    s4, v6, #4
    s.or         s8, s2, s5
    v.extract    s2, v1, #4
    s.or         s5, s1, s7
    v.insert     v4, s3, #1
    v.insert     v3, s6, #2
    v.extract    s1, v5, #4
    s.shli       s3, s4, #32
    v.extract    s4, v0, #4
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s5
    v.extract    s5, v6, #5
    s.or         s8, s1, s3
    v.extract    s1, v1, #5
    s.or         s3, s4, s7
    v.insert     v4, s2, #2
    v.insert     v3, s6, #3
    v.extract    s2, v5, #5
    s.shli       s4, s5, #32
    v.extract    s5, v0, #5
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s3
    v.extract    s3, v6, #6
    s.or         s8, s2, s4
    v.extract    s2, v1, #6
    s.or         s4, s5, s7
    v.insert     v4, s1, #3
    v.insert     v3, s6, #4
    v.extract    s1, v5, #6
    s.shli       s5, s3, #32
    v.extract    s3, v0, #6
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s4
    v.extract    s4, v6, #7
    s.or         s8, s1, s5
    v.extract    s1, v1, #7
    s.or         s5, s3, s7
    v.insert     v4, s2, #4
    v.insert     v3, s6, #5
    v.extract    s2, v5, #7
    s.shli       s3, s4, #32
    v.extract    s4, v0, #7
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s5
    v.extract    s5, v6, #8
    s.or         s8, s2, s3
    v.extract    s2, v1, #8
    s.or         s3, s4, s7
    v.insert     v4, s1, #5
    v.insert     v3, s6, #6
    v.extract    s1, v5, #8
    s.shli       s4, s5, #32
    v.extract    s5, v0, #8
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s3
    v.extract    s3, v6, #9
    s.or         s8, s1, s4
    v.extract    s1, v1, #9
    s.or         s4, s5, s7
    v.insert     v4, s2, #6
    v.insert     v3, s6, #7
    v.extract    s2, v5, #9
    s.shli       s5, s3, #32
    v.extract    s3, v0, #9
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s4
    v.extract    s4, v6, #10
    s.or         s8, s2, s5
    v.extract    s2, v1, #10
    s.or         s5, s3, s7
    v.insert     v4, s1, #7
    v.insert     v3, s6, #8
    v.extract    s1, v5, #10
    s.shli       s3, s4, #32
    v.extract    s4, v0, #10
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s5
    v.extract    s5, v6, #11
    s.or         s8, s1, s3
    v.extract    s1, v1, #11
    s.or         s3, s4, s7
    v.insert     v4, s2, #8
    v.insert     v3, s6, #9
    v.extract    s2, v5, #11
    s.shli       s4, s5, #32
    v.extract    s5, v0, #11
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s3
    v.extract    s3, v6, #12
    s.or         s8, s2, s4
    v.extract    s2, v1, #12
    s.or         s4, s5, s7
    v.insert     v4, s1, #9
    v.insert     v3, s6, #10
    v.extract    s1, v5, #12
    s.shli       s5, s3, #32
    v.extract    s3, v0, #12
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s4
    v.extract    s4, v6, #13
    s.or         s8, s1, s5
    v.extract    s1, v1, #13
    s.or         s5, s3, s7
    v.insert     v4, s2, #10
    v.insert     v3, s6, #11
    v.extract    s2, v5, #13
    s.shli       s3, s4, #32
    v.extract    s4, v0, #13
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s5
    v.extract    s5, v6, #14
    s.or         s8, s2, s3
    v.extract    s2, v1, #14
    s.or         s3, s4, s7
    v.insert     v4, s1, #11
    v.insert     v3, s6, #12
    v.extract    s1, v5, #14
    s.shli       s4, s5, #32
    v.extract    s5, v0, #14
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s3
    v.extract    s3, v6, #15
    s.or         s8, s1, s4
    v.extract    s1, v1, #15
    s.or         s4, s5, s7
    v.insert     v4, s2, #12
    v.insert     v3, s6, #13
    v.extract    s2, v5, #15
    s.shli       s5, s3, #32
    v.extract    s3, v0, #15
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s4
    s.or         s4, s2, s5
    s.or         s2, s3, s7
    v.insert     v4, s1, #13
    v.insert     v3, s6, #14
    s.lshri      s1, s6, #32
    s.add        s3, s4, s2
    v.insert     v4, s1, #14
    v.insert     v3, s3, #15
    v.movi       v0, #31
    s.lshri      s1, s3, #32
    v.movi       v1, #1
    v.insert     v4, s1, #15
    v.ashr       v5, v3, v0
    v.movi       v0, #0
    s.movz       s1, #0
    v.cmp.ne     p1, v4, v5
    @p1 v.sel        v4, v1, v0
    v.reduce.or  s2, v4
    s.cmp.eq     s3, s2, s1
    br.nz        s3, narrow_ok_4
    trap         #677220
narrow_ok_4:
    vf.cvt.f32.bf16 v0, v2
    @p3 v.st.scatter.h [s14, v3], v0
__rctx_next:
    exit
