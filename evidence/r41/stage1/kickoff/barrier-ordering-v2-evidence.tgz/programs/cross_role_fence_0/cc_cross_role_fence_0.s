// cross_role_fence_0 -- emitted by tnca_cc; data and assertions
// appended, the instructions untouched (sec 15 C1).
.org 0
start:
    s.rdspecial s60, role_id
    .li       s59, #2
    s.cmp.geu s58, s60, s59
    br.nz     s58, park
    .li       s59, #1
    s.cmp.eq  s58, s60, s59
    br.nz     s58, role1
    br        role0

park:
    exit

role0:
    w.def        w0, #56, #8                     // v56..v63
    // producer: 1-stage channel, 2 iteration(s), unrolled by stage because W and V are static encoding fields (sec 9)
    .li       s1, #49152
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    // iteration 0: slot 0, generation 1
    mb.arm       s1, b1, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arm       s2, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    .li       s3, #0
    .li       s4, #0
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s6, s4                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s5, s2
    // iteration 1: slot 0, generation 2
    // wait until all 1 consumer(s) released slot 0 (generation 1)
    .li       s3, #65537          // b1 generation 1 (ISA sec 9A.2)
    mb.wait      s3
    mb.arm       s4, b1, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arm       s5, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    .li       s6, #0
    .li       s7, #16
    s.mov        s8, s6                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s9, s7                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s8, s5
    exit

role1:
    // consumer 0: derives each generation from the iteration number, because the scalar file is private per RCTX (sec 7.3)
    // iteration 0: slot 0, generation 1
    .li       s1, #65536          // b0 generation 1 (ISA sec 9A.2)
    mb.wait      s1
    .li       s2, #57600
    v.st.w       [s2, #0], v56
    mb.arrive    b1
    // iteration 1: slot 0, generation 2
    .li       s2, #131072          // b0 generation 2 (ISA sec 9A.2)
    mb.wait      s2
    .li       s3, #57664
    v.st.w       [s3, #0], v56
    mb.arrive    b1

    .li       s20, #57600
    s.ld.w    s21, [s20, #0]
    .assert_eq s21, #0x00010000, #1
    s.ld.w    s21, [s20, #4]
    .assert_eq s21, #0x00030002, #2
    s.ld.w    s21, [s20, #8]
    .assert_eq s21, #0x00050004, #3
    s.ld.w    s21, [s20, #12]
    .assert_eq s21, #0x00070006, #4
    s.ld.w    s21, [s20, #16]
    .assert_eq s21, #0x00090008, #5
    s.ld.w    s21, [s20, #20]
    .assert_eq s21, #0x000b000a, #6
    s.ld.w    s21, [s20, #24]
    .assert_eq s21, #0x000d000c, #7
    s.ld.w    s21, [s20, #28]
    .assert_eq s21, #0x000f000e, #8
    s.ld.w    s21, [s20, #32]
    .assert_eq s21, #0x00210020, #9
    s.ld.w    s21, [s20, #36]
    .assert_eq s21, #0x00230022, #10
    s.ld.w    s21, [s20, #40]
    .assert_eq s21, #0x00250024, #11
    s.ld.w    s21, [s20, #44]
    .assert_eq s21, #0x00270026, #12
    s.ld.w    s21, [s20, #48]
    .assert_eq s21, #0x00290028, #13
    s.ld.w    s21, [s20, #52]
    .assert_eq s21, #0x002b002a, #14
    s.ld.w    s21, [s20, #56]
    .assert_eq s21, #0x002d002c, #15
    s.ld.w    s21, [s20, #60]
    .assert_eq s21, #0x002f002e, #16
    s.ld.w    s21, [s20, #64]
    .assert_eq s21, #0x00110010, #17
    s.ld.w    s21, [s20, #68]
    .assert_eq s21, #0x00130012, #18
    s.ld.w    s21, [s20, #72]
    .assert_eq s21, #0x00150014, #19
    s.ld.w    s21, [s20, #76]
    .assert_eq s21, #0x00170016, #20
    s.ld.w    s21, [s20, #80]
    .assert_eq s21, #0x00190018, #21
    s.ld.w    s21, [s20, #84]
    .assert_eq s21, #0x001b001a, #22
    s.ld.w    s21, [s20, #88]
    .assert_eq s21, #0x001d001c, #23
    s.ld.w    s21, [s20, #92]
    .assert_eq s21, #0x001f001e, #24
    s.ld.w    s21, [s20, #96]
    .assert_eq s21, #0x00310030, #25
    s.ld.w    s21, [s20, #100]
    .assert_eq s21, #0x00330032, #26
    s.ld.w    s21, [s20, #104]
    .assert_eq s21, #0x00350034, #27
    s.ld.w    s21, [s20, #108]
    .assert_eq s21, #0x00370036, #28
    s.ld.w    s21, [s20, #112]
    .assert_eq s21, #0x00390038, #29
    s.ld.w    s21, [s20, #116]
    .assert_eq s21, #0x003b003a, #30
    s.ld.w    s21, [s20, #120]
    .assert_eq s21, #0x003d003c, #31
    s.ld.w    s21, [s20, #124]
    .assert_eq s21, #0x003f003e, #32
    exit

.org 0x8000
input:
    .dword 0x0003000200010000
    .dword 0x0007000600050004
    .dword 0x000b000a00090008
    .dword 0x000f000e000d000c
    .dword 0x0013001200110010
    .dword 0x0017001600150014
    .dword 0x001b001a00190018
    .dword 0x001f001e001d001c
    .dword 0x0023002200210020
    .dword 0x0027002600250024
    .dword 0x002b002a00290028
    .dword 0x002f002e002d002c
    .dword 0x0033003200310030
    .dword 0x0037003600350034
    .dword 0x003b003a00390038
    .dword 0x003f003e003d003c
    .dword 0x0043004200410040
    .dword 0x0047004600450044
    .dword 0x004b004a00490048
    .dword 0x004f004e004d004c
    .dword 0x0053005200510050
    .dword 0x0057005600550054
    .dword 0x005b005a00590058
    .dword 0x005f005e005d005c
    .dword 0x0063006200610060
    .dword 0x0067006600650064
    .dword 0x006b006a00690068
    .dword 0x006f006e006d006c
    .dword 0x0073007200710070
    .dword 0x0077007600750074
    .dword 0x007b007a00790078
    .dword 0x007f007e007d007c
    .dword 0x0083008200810080
    .dword 0x0087008600850084
    .dword 0x008b008a00890088
    .dword 0x008f008e008d008c
    .dword 0x0093009200910090
    .dword 0x0097009600950094
    .dword 0x009b009a00990098
    .dword 0x009f009e009d009c
    .dword 0x00a300a200a100a0
    .dword 0x00a700a600a500a4
    .dword 0x00ab00aa00a900a8
    .dword 0x00af00ae00ad00ac
    .dword 0x00b300b200b100b0
    .dword 0x00b700b600b500b4
    .dword 0x00bb00ba00b900b8
    .dword 0x00bf00be00bd00bc
    .dword 0x00c300c200c100c0
    .dword 0x00c700c600c500c4
    .dword 0x00cb00ca00c900c8
    .dword 0x00cf00ce00cd00cc
    .dword 0x00d300d200d100d0
    .dword 0x00d700d600d500d4
    .dword 0x00db00da00d900d8
    .dword 0x00df00de00dd00dc
    .dword 0x00e300e200e100e0
    .dword 0x00e700e600e500e4
    .dword 0x00eb00ea00e900e8
    .dword 0x00ef00ee00ed00ec
    .dword 0x00f300f200f100f0
    .dword 0x00f700f600f500f4
    .dword 0x00fb00fa00f900f8
    .dword 0x00ff00fe00fd00fc
    .dword 0x0103010201010100
    .dword 0x0107010601050104
    .dword 0x010b010a01090108
    .dword 0x010f010e010d010c
    .dword 0x0113011201110110
    .dword 0x0117011601150114
    .dword 0x011b011a01190118
    .dword 0x011f011e011d011c
    .dword 0x0123012201210120
    .dword 0x0127012601250124
    .dword 0x012b012a01290128
    .dword 0x012f012e012d012c
    .dword 0x0133013201310130
    .dword 0x0137013601350134
    .dword 0x013b013a01390138
    .dword 0x013f013e013d013c
    .dword 0x0143014201410140
    .dword 0x0147014601450144
    .dword 0x014b014a01490148
    .dword 0x014f014e014d014c
    .dword 0x0153015201510150
    .dword 0x0157015601550154
    .dword 0x015b015a01590158
    .dword 0x015f015e015d015c
    .dword 0x0163016201610160
    .dword 0x0167016601650164
    .dword 0x016b016a01690168
    .dword 0x016f016e016d016c
    .dword 0x0173017201710170
    .dword 0x0177017601750174
    .dword 0x017b017a01790178
    .dword 0x017f017e017d017c
    .dword 0x0183018201810180
    .dword 0x0187018601850184
    .dword 0x018b018a01890188
    .dword 0x018f018e018d018c
    .dword 0x0193019201910190
    .dword 0x0197019601950194
    .dword 0x019b019a01990198
    .dword 0x019f019e019d019c
    .dword 0x01a301a201a101a0
    .dword 0x01a701a601a501a4
    .dword 0x01ab01aa01a901a8
    .dword 0x01af01ae01ad01ac
    .dword 0x01b301b201b101b0
    .dword 0x01b701b601b501b4
    .dword 0x01bb01ba01b901b8
    .dword 0x01bf01be01bd01bc
    .dword 0x01c301c201c101c0
    .dword 0x01c701c601c501c4
    .dword 0x01cb01ca01c901c8
    .dword 0x01cf01ce01cd01cc
    .dword 0x01d301d201d101d0
    .dword 0x01d701d601d501d4
    .dword 0x01db01da01d901d8
    .dword 0x01df01de01dd01dc
    .dword 0x01e301e201e101e0
    .dword 0x01e701e601e501e4
    .dword 0x01eb01ea01e901e8
    .dword 0x01ef01ee01ed01ec
    .dword 0x01f301f201f101f0
    .dword 0x01f701f601f501f4
    .dword 0x01fb01fa01f901f8
    .dword 0x01ff01fe01fd01fc

.org 0xc000
descriptor:
    .dword 0x0000000000008000
    .dword 0x0000000000000010
    .dword 0x0000000000000020
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000040
    .dword 0x0000000000000002
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000001000000010
    .dword 0x0000000000000000
    .dword 0x0000000200000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000
    .dword 0x0000000000000000

.org 0xe100
output:
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef
    .dword 0xdeadbeefdeadbeef

