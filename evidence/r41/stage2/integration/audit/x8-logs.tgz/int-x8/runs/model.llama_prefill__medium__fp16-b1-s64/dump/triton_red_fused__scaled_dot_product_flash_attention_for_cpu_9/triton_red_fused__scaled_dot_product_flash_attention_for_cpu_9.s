    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    v.splat      v0, s4
    v.movi       v1, #0
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    v.sub        v2, v1, v0
    s.ld.d       s1, [s3, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.cmp.lt     p1, v0, v1
    @p1 v.sel        v3, v2, v0
    v.movi       v0, #63
    s.rdspecial  s2, arg_base
    s.add        s3, s1, s5                      // this context's own scratch
    v.movi       v2, #64
    v.and        v4, v3, v0
    s.ld.d       s1, [s2, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    v.movi       v0, #0
    v.movi       v3, #0
    s.addi       s5, s3, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s6, #384
    s.movz       s7, #64
    s.movz       s8, #256
    s.movz       s9, #4
    .li       s10, #68719476737
    .li       s11, #2207613190144
    s.movz       s12, #0
    v.sub        v5, v1, v2
    v.sub        v6, v1, v4
    v.cmp.lt     p2, v2, v1
    v.cmp.ne     p3, v0, v3
    s.ld.d       s13, [s2, #0]                   // in_out_ptr0: device_ptr64 at arg_base+0
    .li       s2, #4286578688
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    s.movz       s2, #0
    s.st.d       [s5, #0], s1
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v7, #1
    s.st.d       [s5, #8], s6
    s.movz       s2, #64
    @p2 v.sel        v7, v5, v2
    s.st.d       [s5, #16], s7
    s.movz       s6, #16
    @p1 v.sel        v2, v6, v4
    s.st.d       [s5, #48], s8
    s.addi       s7, s12, #0
    p.mov        p1, p3
    s.st.d       [s5, #56], s9
    s.st.d       [s5, #88], s10
    s.st.d       [s5, #104], s11
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.mov        v1, v0
for_1:
    s.cmp.ge     s5, s7, s2
    br.nz        s5, endfor_2
    v.movi       v4, #-1
    v.splat      v5, s7
    v.mul        v6, v2, v4
    v.add        v4, v5, v3
    v.extract    s5, v6, #0
    v.splat      v5, s5
    s.muli       s5, s4, #256
    v.splat      v6, s7
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s8, #64
    s.movz       s9, #384
    v.add        v8, v4, v5
    s.muli       s10, s7, #4
    v.add        v5, v6, v7
    v.movi       v6, #0
    v.splat      v7, s8
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s9
    v.extract    s8, v8, #0
    s.shli       s9, s8, #32
    v.cmp.ge     p2, v5, v6
    v.cmp.lt     p3, v5, v7
    v.cmp.ge     p4, v9, v10
    v.cmp.lt     p5, v9, v11
    v.extract    s8, v8, #1
    s.add        s11, s1, s5
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.ashri      s5, s9, #32
    s.shli       s9, s8, #32
    v.extract    s8, v8, #2
    s.add        s14, s11, s10
    p.and        p3, p6, p2
    v.movi       v5, #0
    v.movi       v6, #0
    s.lshri      s10, s5, #32
    s.ashri      s11, s9, #32
    s.shli       s9, s8, #32
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v7, [s14, #0]
    v.insert     v5, s5, #0
    v.insert     v6, s10, #0
    s.lshri      s5, s11, #32
    s.ashri      s8, s9, #32
    v.insert     v5, s11, #1
    v.insert     v6, s5, #1
    v.insert     v5, s8, #2
    v.movi       v9, #64
    s.lshri      s5, s8, #32
    v.cmp.lt     p2, v4, v9
    v.extract    s8, v8, #3
    s.shli       s9, s8, #32
    v.extract    s8, v8, #4
    s.ashri      s10, s9, #32
    s.shli       s9, s8, #32
    v.extract    s8, v8, #5
    v.insert     v6, s5, #2
    s.lshri      s5, s10, #32
    s.ashri      s11, s9, #32
    s.shli       s9, s8, #32
    v.extract    s8, v8, #6
    v.insert     v5, s10, #3
    v.insert     v6, s5, #3
    s.lshri      s5, s11, #32
    s.ashri      s10, s9, #32
    s.shli       s9, s8, #32
    v.insert     v5, s11, #4
    v.insert     v6, s5, #4
    s.lshri      s5, s10, #32
    s.ashri      s8, s9, #32
    v.insert     v5, s10, #5
    v.insert     v6, s5, #5
    v.insert     v5, s8, #6
    .li       s5, #-1
    v.extract    s5, v8, #7
    s.shli       s9, s5, #32
    v.extract    s5, v8, #8
    s.lshri      s10, s8, #32
    s.ashri      s8, s9, #32
    s.shli       s9, s5, #32
    v.extract    s5, v8, #9
    v.insert     v6, s10, #6
    s.lshri      s10, s8, #32
    s.ashri      s11, s9, #32
    s.shli       s9, s5, #32
    v.extract    s5, v8, #10
    v.insert     v5, s8, #7
    v.insert     v6, s10, #7
    s.lshri      s8, s11, #32
    s.ashri      s10, s9, #32
    s.shli       s9, s5, #32
    v.extract    s5, v8, #11
    v.insert     v5, s11, #8
    v.insert     v6, s8, #8
    s.lshri      s8, s10, #32
    s.ashri      s11, s9, #32
    s.shli       s9, s5, #32
    v.extract    s5, v8, #12
    v.insert     v5, s10, #9
    v.insert     v6, s8, #9
    s.lshri      s8, s11, #32
    s.ashri      s10, s9, #32
    s.shli       s9, s5, #32
    v.extract    s5, v8, #13
    v.insert     v5, s11, #10
    v.insert     v6, s8, #10
    s.lshri      s8, s10, #32
    s.ashri      s11, s9, #32
    s.shli       s9, s5, #32
    v.extract    s5, v8, #14
    v.insert     v5, s10, #11
    v.insert     v6, s8, #11
    s.lshri      s8, s11, #32
    s.ashri      s10, s9, #32
    s.shli       s9, s5, #32
    v.extract    s5, v8, #15
    v.insert     v5, s11, #12
    v.insert     v6, s8, #12
    s.lshri      s8, s10, #32
    s.ashri      s11, s9, #32
    s.shli       s9, s5, #32
    v.insert     v5, s10, #13
    v.insert     v6, s8, #13
    s.lshri      s5, s11, #32
    s.ashri      s8, s9, #32
    v.insert     v5, s11, #14
    v.insert     v6, s5, #14
    s.lshri      s5, s8, #32
    v.insert     v5, s8, #15
    v.insert     v6, s5, #15
    v.extract    s5, v5, #0
    v.extract    s8, v6, #0
    s.shli       s9, s8, #32
    v.extract    s8, v6, #1
    s.or         s10, s5, s9
    s.movz       s5, #0
    s.shli       s9, s8, #32
    v.extract    s8, v5, #1
    v.extract    s11, v6, #2
    v.movi       v4, #0
    s.cmp.le     s14, s10, s5
    s.or         s5, s8, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #2
    v.extract    s11, v6, #3
    v.insert     v4, s14, #0
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #3
    v.extract    s11, v6, #4
    v.insert     v4, s14, #1
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #4
    v.extract    s11, v6, #5
    v.insert     v4, s14, #2
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #5
    v.extract    s11, v6, #6
    v.insert     v4, s14, #3
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #6
    v.extract    s11, v6, #7
    v.insert     v4, s14, #4
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #7
    v.extract    s11, v6, #8
    v.insert     v4, s14, #5
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #8
    v.extract    s11, v6, #9
    v.insert     v4, s14, #6
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #9
    v.extract    s11, v6, #10
    v.insert     v4, s14, #7
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #10
    v.extract    s11, v6, #11
    v.insert     v4, s14, #8
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #11
    v.extract    s11, v6, #12
    v.insert     v4, s14, #9
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #12
    v.extract    s11, v6, #13
    v.insert     v4, s14, #10
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #13
    v.extract    s11, v6, #14
    v.insert     v4, s14, #11
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #14
    v.extract    s11, v6, #15
    v.insert     v4, s14, #12
    s.cmp.le     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v5, #15
    v.insert     v4, s14, #13
    s.cmp.le     s11, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    v.insert     v4, s11, #14
    s.cmp.le     s9, s5, s8
    v.movi       v5, #0
    v.insert     v4, s9, #15
    v.movi       v6, #0
    v.cmp.ne     p3, v4, v5
    @p3 v.sel        v4, v6, v0
    v.movi       v5, #1
    vf.add       v6, v7, v4
    v.movi       v4, #0
    v.movi       v7, #0
    v.movi       v8, #1
    vf.cmp.eq    p3, v6, v0
    @p3 v.sel        v9, v5, v4
    v.movi       v4, #0
    v.cmp.eq     p3, v9, v7
    @p3 v.sel        v5, v8, v4
    v.movi       v4, #1
    v.movi       v7, #0
    v.extract    s5, v5, #0
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.movi       v8, #0
    v.movi       v9, #0
    s.lshri      s8, s5, #32
    v.extract    s9, v5, #1
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s5, #0
    v.insert     v9, s8, #0
    s.lshri      s5, s9, #32
    v.extract    s8, v5, #2
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s9, #1
    v.insert     v9, s5, #1
    s.lshri      s5, s8, #32
    v.extract    s9, v5, #3
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s8, #2
    v.insert     v9, s5, #2
    s.lshri      s5, s9, #32
    v.extract    s8, v5, #4
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s9, #3
    v.insert     v9, s5, #3
    s.lshri      s5, s8, #32
    v.extract    s9, v5, #5
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s8, #4
    v.insert     v9, s5, #4
    s.lshri      s5, s9, #32
    v.extract    s8, v5, #6
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s9, #5
    v.insert     v9, s5, #5
    s.lshri      s5, s8, #32
    v.extract    s9, v5, #7
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s8, #6
    v.insert     v9, s5, #6
    s.lshri      s5, s9, #32
    v.extract    s8, v5, #8
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s9, #7
    v.insert     v9, s5, #7
    s.lshri      s5, s8, #32
    v.extract    s9, v5, #9
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s8, #8
    v.insert     v9, s5, #8
    s.lshri      s5, s9, #32
    v.extract    s8, v5, #10
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s9, #9
    v.insert     v9, s5, #9
    s.lshri      s5, s8, #32
    v.extract    s9, v5, #11
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s8, #10
    v.insert     v9, s5, #10
    s.lshri      s5, s9, #32
    v.extract    s8, v5, #12
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s9, #11
    v.insert     v9, s5, #11
    s.lshri      s5, s8, #32
    v.extract    s9, v5, #13
    @p3 v.sel        v5, v4, v7
    v.movi       v4, #1
    v.movi       v7, #0
    v.insert     v8, s8, #12
    v.insert     v9, s5, #12
    s.lshri      s5, s9, #32
    v.extract    s8, v5, #14
    @p3 v.sel        v5, v4, v7
    v.insert     v8, s9, #13
    v.insert     v9, s5, #13
    s.lshri      s5, s8, #32
    v.extract    s9, v5, #15
    v.insert     v8, s8, #14
    v.insert     v9, s5, #14
    s.lshri      s5, s9, #32
    v.insert     v8, s9, #15
    v.insert     v9, s5, #15
    v.extract    s5, v8, #0
    v.extract    s8, v9, #0
    s.shli       s9, s8, #32
    v.extract    s8, v9, #1
    s.or         s10, s5, s9
    s.movz       s5, #0
    s.shli       s9, s8, #32
    v.extract    s8, v8, #1
    v.extract    s11, v9, #2
    v.movi       v4, #0
    s.cmp.ne     s14, s10, s5
    s.or         s5, s8, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #2
    v.extract    s11, v9, #3
    v.insert     v4, s14, #0
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #3
    v.extract    s11, v9, #4
    v.insert     v4, s14, #1
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #4
    v.extract    s11, v9, #5
    v.insert     v4, s14, #2
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #5
    v.extract    s11, v9, #6
    v.insert     v4, s14, #3
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #6
    v.extract    s11, v9, #7
    v.insert     v4, s14, #4
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #7
    v.extract    s11, v9, #8
    v.insert     v4, s14, #5
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #8
    v.extract    s11, v9, #9
    v.insert     v4, s14, #6
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #9
    v.extract    s11, v9, #10
    v.insert     v4, s14, #7
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #10
    v.extract    s11, v9, #11
    v.insert     v4, s14, #8
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #11
    v.extract    s11, v9, #12
    v.insert     v4, s14, #9
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #12
    v.extract    s11, v9, #13
    v.insert     v4, s14, #10
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #13
    v.extract    s11, v9, #14
    v.insert     v4, s14, #11
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #14
    v.extract    s11, v9, #15
    v.insert     v4, s14, #12
    s.cmp.ne     s14, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v8, #15
    v.insert     v4, s14, #13
    s.cmp.ne     s11, s5, s8
    s.or         s5, s10, s9
    s.movz       s8, #0
    v.insert     v4, s11, #14
    s.cmp.ne     s9, s5, s8
    v.movi       v5, #0
    v.insert     v4, s9, #15
    p.not        p3, p2
    v.cmp.ne     p4, v4, v5
    p.or         p5, p1, p4
    vf.max       v4, v1, v6
    p.and        p4, p2, p5
    p.and        p5, p3, p1
    v.movi       v5, #0
    p.or         p3, p4, p5
    @p2 v.sel        v6, v4, v1
    p.mov        p2, p3
    v.mov        v5, v6
    s.add        s5, s7, s6
    s.movz       s8, #1
    p.mov        p1, p2
    v.mov        v1, v5
    s.mov        s7, s5
    br.nz        s8, for_1
endfor_2:
    v.movi       v4, #1
    v.movi       v5, #0
    vf.cmp.uo    p2, v1, v1
    @p2 v.sel        v6, v4, v5
    v.movi       v4, #1
    v.movi       v5, #0
    v.reduce.or.b v7, v6
    v.movi       v6, #0
    vf.reduce.max.b v8, v1
    .li       s5, #2143289344
    v.splat      v1, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v9, v4, v5
    v.cmp.ne     p1, v7, v6
    @p1 v.sel        v4, v1, v8
    v.movi       v1, #0
    v.movi       v5, #0
    v.movi       v6, #0
    v.reduce.or  s5, v9
    v.splat      v7, s5
    vf.add       v8, v4, v1
    s.addi       s5, s12, #0
    v.mov        v6, v5
for_3:
    s.cmp.ge     s7, s5, s2
    br.nz        s7, endfor_4
    v.movi       v4, #-1
    v.splat      v9, s5
    v.mul        v10, v2, v4
    v.add        v4, v9, v3
    v.extract    s7, v10, #0
    v.splat      v9, s7
    s.muli       s7, s4, #256
    v.splat      v10, s5
    v.iota       v11                             // arange(0, VLEN)
    s.movz       s8, #64
    s.movz       s9, #384
    v.add        v12, v4, v9
    s.muli       s10, s5, #4
    v.add        v9, v10, v11
    v.movi       v10, #0
    v.splat      v11, s8
    v.splat      v13, s4
    v.movi       v14, #0
    v.splat      v15, s9
    v.extract    s8, v12, #0
    s.shli       s9, s8, #32
    v.cmp.ge     p1, v9, v10
    v.cmp.lt     p2, v9, v11
    v.cmp.ge     p3, v13, v14
    v.cmp.lt     p4, v13, v15
    v.extract    s8, v12, #1
    s.add        s11, s1, s7
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.ashri      s7, s9, #32
    s.shli       s9, s8, #32
    v.extract    s8, v12, #2
    s.add        s14, s11, s10
    p.and        p2, p5, p1
    v.movi       v9, #0
    v.movi       v10, #0
    s.lshri      s10, s7, #32
    s.ashri      s11, s9, #32
    s.shli       s9, s8, #32
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v11, [s14, #0]
    v.insert     v9, s7, #0
    v.insert     v10, s10, #0
    s.lshri      s7, s11, #32
    s.ashri      s8, s9, #32
    v.insert     v9, s11, #1
    v.insert     v10, s7, #1
    v.insert     v9, s8, #2
    v.movi       v13, #64
    s.lshri      s7, s8, #32
    v.cmp.lt     p1, v4, v13
    v.extract    s8, v12, #3
    s.shli       s9, s8, #32
    v.extract    s8, v12, #4
    s.ashri      s10, s9, #32
    s.shli       s9, s8, #32
    v.extract    s8, v12, #5
    v.insert     v10, s7, #2
    s.lshri      s7, s10, #32
    s.ashri      s11, s9, #32
    s.shli       s9, s8, #32
    v.extract    s8, v12, #6
    v.insert     v9, s10, #3
    v.insert     v10, s7, #3
    s.lshri      s7, s11, #32
    s.ashri      s10, s9, #32
    s.shli       s9, s8, #32
    v.insert     v9, s11, #4
    v.insert     v10, s7, #4
    s.lshri      s7, s10, #32
    s.ashri      s8, s9, #32
    v.insert     v9, s10, #5
    v.insert     v10, s7, #5
    v.insert     v9, s8, #6
    .li       s7, #-1
    v.extract    s7, v12, #7
    s.shli       s9, s7, #32
    v.extract    s7, v12, #8
    s.lshri      s10, s8, #32
    s.ashri      s8, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v12, #9
    v.insert     v10, s10, #6
    s.lshri      s10, s8, #32
    s.ashri      s11, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v12, #10
    v.insert     v9, s8, #7
    v.insert     v10, s10, #7
    s.lshri      s8, s11, #32
    s.ashri      s10, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v12, #11
    v.insert     v9, s11, #8
    v.insert     v10, s8, #8
    s.lshri      s8, s10, #32
    s.ashri      s11, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v12, #12
    v.insert     v9, s10, #9
    v.insert     v10, s8, #9
    s.lshri      s8, s11, #32
    s.ashri      s10, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v12, #13
    v.insert     v9, s11, #10
    v.insert     v10, s8, #10
    s.lshri      s8, s10, #32
    s.ashri      s11, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v12, #14
    v.insert     v9, s10, #11
    v.insert     v10, s8, #11
    s.lshri      s8, s11, #32
    s.ashri      s10, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v12, #15
    v.insert     v9, s11, #12
    v.insert     v10, s8, #12
    s.lshri      s8, s10, #32
    s.ashri      s11, s9, #32
    s.shli       s9, s7, #32
    v.insert     v9, s10, #13
    v.insert     v10, s8, #13
    s.lshri      s7, s11, #32
    s.ashri      s8, s9, #32
    v.insert     v9, s11, #14
    v.insert     v10, s7, #14
    s.lshri      s7, s8, #32
    v.insert     v9, s8, #15
    v.insert     v10, s7, #15
    v.extract    s7, v9, #0
    v.extract    s8, v10, #0
    s.shli       s9, s8, #32
    v.extract    s8, v10, #1
    s.or         s10, s7, s9
    s.movz       s7, #0
    s.shli       s9, s8, #32
    v.extract    s8, v9, #1
    v.extract    s11, v10, #2
    v.movi       v12, #0
    s.cmp.le     s14, s10, s7
    s.or         s7, s8, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #2
    v.extract    s11, v10, #3
    v.insert     v12, s14, #0
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #3
    v.extract    s11, v10, #4
    v.insert     v12, s14, #1
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #4
    v.extract    s11, v10, #5
    v.insert     v12, s14, #2
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #5
    v.extract    s11, v10, #6
    v.insert     v12, s14, #3
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #6
    v.extract    s11, v10, #7
    v.insert     v12, s14, #4
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #7
    v.extract    s11, v10, #8
    v.insert     v12, s14, #5
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #8
    v.extract    s11, v10, #9
    v.insert     v12, s14, #6
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #9
    v.extract    s11, v10, #10
    v.insert     v12, s14, #7
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #10
    v.extract    s11, v10, #11
    v.insert     v12, s14, #8
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #11
    v.extract    s11, v10, #12
    v.insert     v12, s14, #9
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #12
    v.extract    s11, v10, #13
    v.insert     v12, s14, #10
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #13
    v.extract    s11, v10, #14
    v.insert     v12, s14, #11
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #14
    v.extract    s11, v10, #15
    v.insert     v12, s14, #12
    s.cmp.le     s14, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v9, #15
    v.insert     v12, s14, #13
    s.cmp.le     s11, s7, s8
    s.or         s7, s10, s9
    s.movz       s8, #0
    v.insert     v12, s11, #14
    s.cmp.le     s9, s7, s8
    v.movi       v9, #0
    v.insert     v12, s9, #15
    v.extract    s7, v8, #0
    v.cmp.ne     p2, v12, v9
    @p2 v.sel        v9, v5, v0
    v.splat      v10, s7
    vf.add       v12, v11, v9
    .li       s7, #1069066811
    v.splat      v9, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s7, #1060205080
    v.splat      v11, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s7, s4, s2
    vf.sub       v13, v12, v10
    v.movi       v10, #0
    s.add        s8, s5, s6
    s.movz       s9, #1
    vf.mul       v12, v13, v9
    s.add        s10, s5, s7
    v.splat      v14, s7
    s.shli       s7, s10, #2                     // element offset -> bytes (x4)
    v.exp2.approx v15, v12                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v13, v9, v12               // the exact rounding error of x*log2(e)
    s.add        s10, s13, s7                    // &in_out_ptr0[...]
    v.add        v9, v4, v14
    vf.mul       v4, v16, v11
    vf.fma       v9, v15, v4, v15                // 2**t * 2**d
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v4, v9, v15
    vf.add       v9, v6, v4
    @p1 v.st.w       [s10, #0], v4
    @p1 v.sel        v4, v9, v6
    v.mov        v10, v4
    v.mov        v6, v10
    s.mov        s5, s8
    br.nz        s9, for_3
endfor_4:
    vf.reduce.add.b v0, v6
    vf.add       v2, v0, v1
    s.addi       s1, s3, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s3, #0
    s.st.d       [s1, #0], s13
    s.movz       s3, #384
    s.st.d       [s1, #8], s3
    s.movz       s3, #64
    s.st.d       [s1, #16], s3
    s.movz       s3, #256
    s.st.d       [s1, #48], s3
    s.movz       s3, #4
    s.st.d       [s1, #56], s3
    .li       s3, #68719476737
    s.st.d       [s1, #88], s3
    .li       s3, #2207613190144
    s.st.d       [s1, #104], s3
    fence.release.device
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s12, #0
for_5:
    s.cmp.ge     s3, s1, s2
    br.nz        s3, endfor_6
    v.extract    s3, v2, #0
    v.splat      v0, s3
    s.muli       s3, s4, #256
    v.rcp.approx v1, v0                          // ISA 8.8: <= 2**-22 relative
    v.splat      v4, s1
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s5, #64
    s.movz       s7, #384
    s.muli       s8, s1, #4
    v.add        v8, v4, v6
    v.movi       v4, #0
    v.splat      v6, s5
    v.splat      v9, s4
    v.movi       v10, #0
    v.cmp.ge     p1, v8, v4
    v.splat      v4, s7
    v.cmp.lt     p2, v8, v6
    .li       s5, #1065353216
    v.splat      v6, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v4
    s.add        s5, s13, s3
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s3, s5, s8
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v4, [s3, #0]
    v.movi       v8, #0
    s.mul        s3, s4, s2
    v.movi       v9, #1
    vf.fms       v10, v0, v1, v6
    v.movi       v0, #0
    v.cmp.eq     p1, v7, v8
    @p1 v.sel        v6, v9, v0
    vf.fms       v0, v1, v10, v1
    v.extract    s5, v6, #0
    v.splat      v6, s1
    v.splat      v8, s5
    vf.neg       v9, v0                          // Newton step: r0*(2 - x*r0)
    v.movi       v0, #0
    v.add        v10, v6, v3
    v.movi       v6, #64
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v11, v9, v1
    s.add        s5, s1, s3
    vf.mul       v1, v4, v11                     // a/y as a refined reciprocal (ISA has no divide)
    v.cmp.ne     p1, v8, v0
    v.splat      v0, s3
    v.cmp.lt     p2, v10, v6
    s.shli       s3, s5, #2                      // element offset -> bytes (x4)
    @p1 v.sel        v4, v5, v1
    s.add        s5, s13, s3                     // &in_out_ptr0[...]
    s.add        s3, s1, s6
    s.movz       s7, #1
    v.add        v1, v10, v0
    @p2 v.st.w       [s5, #0], v4
    s.mov        s1, s3
    br.nz        s7, for_5
endfor_6:
__rctx_next:
    exit
