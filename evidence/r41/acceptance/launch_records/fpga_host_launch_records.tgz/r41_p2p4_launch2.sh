#!/bin/bash
# Lead-only: wait for 15 idle minutes, load the approved run-1 100 MHz image, then run the P2/P4 acceptance queue.
export TNCA_BOARD=u280
source /tools/Xilinx/Vitis/2023.2/settings64.sh >/dev/null 2>&1
source /opt/xilinx/xrt/setup.sh >/dev/null 2>&1
L=~/r41_p2p4_launch2.log
K=/sys/bus/pci/devices/0000:04:00.1/kdsstat; U=/sys/bus/pci/devices/0000:04:00.1/xclbinuuid
WANT=49964b17-e0b4-5bd2-dd40-7fc37b1205d3
X=~/tnca_images/r41s2_run1_c9f25787494a/tnca_u280.xclbin
field() { awk -F: -v f="$1" '$1 ~ f {gsub(/[ \t]/,"",$2); print $2; exit}' $K; }
client() { awk 'f{print $1; exit} /client pid/{f=1}' $K; }
idle() { [ "$(field contexts)" = "0" ] && [ "$(field outstanding)" = "0" ] && [ -z "$(client)" ]; }
log() { echo "$(date -u +%FT%TZ) $*" >> $L; }
n=0; while [ $n -lt 15 ]; do if idle; then n=$((n+1)); else n=0; fi; sleep 60; done
log "card idle for 15 consecutive minutes; loaded $(cat $U)"
if [ "$(cat $U)" != "$WANT" ]; then
  P=~/r41s2_board_86a3d929cf3d/src/flow/fpga/program.sh
  idle || { log "card busy at load time; nothing loaded"; exit 4; }
  bash $P --check $X >> $L 2>&1 || { log "program.sh --check refused; nothing loaded"; exit 4; }
  bash $P --go $X >> $L 2>&1 || { log "program.sh --go failed"; exit 4; }
  for i in $(seq 1 60); do [ "$(cat $U)" = "$WANT" ] && break; sleep 10; done
fi
[ "$(cat $U)" = "$WANT" ] || { log "image is not $WANT; stopping"; exit 5; }
log "100 MHz run-1 image loaded; starting the P2/P4 queue"
cd ~/r41_accept_7b10e7b || exit 6
~/bin/torchenv-python tools/performance_harness/launches/acceptance_queue.py --root "$PWD" --out ~/r41_accept_p2_p4_7b10e7b_try2 --python ~/bin/torchenv-python --budget-seconds 6900 --manifest spec/r41/stage2/acceptance/s2-p2-locality.json --manifest spec/r41/stage2/acceptance/s2-p4-lifecycle.json > ~/r41_accept_p2_p4_7b10e7b_try2.log 2>&1
log "P2/P4 queue exit $?"
