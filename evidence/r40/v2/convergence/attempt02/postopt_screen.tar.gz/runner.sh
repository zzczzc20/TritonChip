source /tools/Xilinx/Vivado/2023.2/settings64.sh
cd "$HOME/tnca_build/r40_hierarchy_postopt"
for variant in 0 1; do
 timeout -k 15 1200 vivado -mode batch -source postopt.tcl -tclargs "$HOME/tnca_build/r40_hierarchy_screen" "$variant" "$PWD/case$variant" > case$variant.log 2>&1
 result=$?
 echo "$result" > case$variant.exit
 if [ "$result" -ne 0 ]; then exit "$result"; fi
done
