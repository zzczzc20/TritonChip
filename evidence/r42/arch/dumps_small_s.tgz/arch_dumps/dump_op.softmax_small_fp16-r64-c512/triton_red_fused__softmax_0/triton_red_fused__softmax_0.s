    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #512
    s.movz       s5, #64
    s.movz       s6, #1
    s.rdspecial  s6, role_id
    s.rdspecial  s7, npid.x
    s.ld.d       s8, [s1, #8]                    // out_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s9, [s1, #16]                   // out_ptr3: device_ptr64 at arg_base+16
__rctx_program:
    s.mul        s1, s6, s4
    s.addi       s10, s2, #0
    .li       s11, #4286578688
    v.splat      v0, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    v.movi       v2, #0
    s.add        s11, s10, s1
    v.movi       v3, #0
    v.movi       v4, #0
    s.shli       s1, s11, #1                     // element offset -> bytes (x2)
    v.mov        v1, v0
    v.mov        v2, v0
    v.mov        v3, v0
    v.mov        v4, v0
    s.add        s11, s3, s1                     // &in_ptr0[...]
for_1:
    v.ld.h       v0, [s11, #0]
    v.ld.h       v5, [s11, #32]
    vf.cvt.f16.f32 v6, v0
    vf.max.prop  v1, v1, v6
    v.ld.h       v0, [s11, #64]
    vf.cvt.f16.f32 v6, v5
    vf.max.prop  v2, v2, v6
    v.ld.h       v5, [s11, #96]
    vf.cvt.f16.f32 v6, v0
    vf.max.prop  v3, v3, v6
    vf.cvt.f16.f32 v0, v5
    vf.max.prop  v4, v4, v0
    s.addi       s11, s11, #128                  // the next iteration's address
    s.add        s10, s10, s5
    s.cmp.lt     s1, s10, s4
    br.nz        s1, for_1
endfor_2:
    v.movi       v0, #1
    v.movi       v5, #0
    vf.cmp.uo    p1, v1, v1
    vf.cmp.uo    p2, v2, v2
    @p1 v.sel        v6, v0, v5
    vf.cmp.uo    p1, v3, v3
    @p2 v.sel        v7, v0, v5
    vf.cmp.uo    p2, v4, v4
    @p1 v.sel        v8, v0, v5
    @p2 v.sel        v9, v0, v5
    v.reduce.or.b v0, v6
    v.reduce.or.b v6, v7
    v.reduce.or.b v7, v8
    v.reduce.or.b v8, v9
    vf.reduce.max.b v9, v1
    .li       s1, #2143289344
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.max.b v10, v2
    vf.reduce.max.b v2, v3
    vf.reduce.max.b v3, v4
    v.cmp.ne     p1, v0, v5
    v.cmp.ne     p2, v6, v5
    @p1 v.sel        v0, v1, v9
    v.cmp.ne     p1, v7, v5
    @p2 v.sel        v4, v1, v10
    v.cmp.ne     p2, v8, v5
    @p1 v.sel        v5, v1, v2
    @p2 v.sel        v2, v1, v3
    vf.max.prop  v1, v0, v4
    v.movi       v0, #0
    vf.max.prop  v3, v5, v2
    s.mul        s1, s6, s4
    s.addi       s10, s2, #0
    v.movi       v2, #0
    v.movi       v4, #0
    vf.max.prop  v5, v1, v3
    s.add        s11, s10, s1
    s.add        s12, s10, s1
    v.movi       v1, #0
    v.movi       v3, #0
    vf.add       v6, v5, v0
    s.shli       s1, s11, #1                     // element offset -> bytes (x2)
    s.shli       s11, s12, #2                    // element offset -> bytes (x4)
    v.mov        v2, v0
    v.mov        v4, v0
    v.extract    s12, v6, #0
    v.mov        v1, v0
    v.mov        v3, v0
    v.splat      v5, s12
    .li       s12, #1069066811
    v.splat      v6, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s12, #1060205080
    v.splat      v7, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.movz       s12, #1
    s.add        s12, s3, s1                     // &in_ptr0[...]
    s.add        s1, s8, s11                     // &out_ptr1[...]
for_3:
    v.ld.h       v8, [s12, #0]
    v.ld.h       v9, [s12, #32]
    vf.cvt.f16.f32 v10, v8
    vf.sub       v8, v10, v5
    vf.mul       v10, v8, v6
    v.ld.h       v11, [s12, #64]
    vf.cvt.f16.f32 v12, v9
    v.exp2.approx v9, v10                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v13, v8, v6, v10                // the exact rounding error of x*log2(e)
    vf.sub       v8, v12, v5
    vf.mul       v10, v13, v7
    vf.mul       v12, v8, v6
    v.ld.h       v13, [s12, #96]
    vf.cvt.f16.f32 v14, v11
    v.exp2.approx v11, v12                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v8, v6, v12                // the exact rounding error of x*log2(e)
    vf.sub       v8, v14, v5
    vf.mul       v12, v15, v7
    vf.mul       v14, v8, v6
    vf.cvt.f16.f32 v15, v13
    v.exp2.approx v13, v14                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v8, v6, v14                // the exact rounding error of x*log2(e)
    vf.fma       v8, v9, v10, v9                 // 2**t * 2**d
    vf.sub       v10, v15, v5
    vf.mul       v14, v16, v7
    vf.cmp.o     p1, v8, v8
    vf.mul       v15, v10, v6
    @p1 v.sel        v16, v8, v9
    vf.add       v2, v2, v16
    v.exp2.approx v8, v15                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v10, v6, v15                // the exact rounding error of x*log2(e)
    vf.fma       v10, v11, v12, v11              // 2**t * 2**d
    v.st.w       [s1, #0], v16
    vf.mul       v12, v9, v7
    vf.cmp.o     p1, v10, v10
    @p1 v.sel        v9, v10, v11
    vf.add       v4, v4, v9
    vf.fma       v10, v13, v14, v13              // 2**t * 2**d
    vf.cmp.o     p1, v10, v10
    @p1 v.sel        v11, v10, v13
    v.st.w       [s1, #64], v9
    vf.add       v1, v1, v11
    vf.fma       v9, v8, v12, v8                 // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v10, v9, v8
    vf.add       v3, v3, v10
    v.st.w       [s1, #128], v11
    v.st.w       [s1, #192], v10
    s.addi       s12, s12, #128                  // the next iteration's address
    s.addi       s1, s1, #256                    // the next iteration's address
    s.add        s10, s10, s5
    s.cmp.lt     s11, s10, s4
    br.nz        s11, for_3
endfor_4:
    vf.reduce.add.b v5, v2
    vf.reduce.add.b v2, v4
    vf.reduce.add.b v4, v1
    vf.reduce.add.b v1, v3
    vf.add       v3, v5, v2
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v5, v4, v1
    s.rdspecial  s1, arg_base
    s.mul        s10, s6, s4
    s.ld.d       s11, [s1, #40]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    vf.add       v1, v3, v5
    s.movz       s12, #512
    s.addi       s13, s2, #0
    s.muli       s14, s6, #2048
    s.movz       s15, #64
    vf.add       v3, v1, v0
    s.mul        s16, s1, s12
    s.muli       s1, s13, #4
    v.splat      v0, s6
    v.movi       v1, #0
    v.extract    s12, v3, #0
    v.splat      v3, s15
    v.splat      v4, s12
    s.add        s12, s13, s10
    s.add        s10, s8, s14
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    s.shli       s14, s12, #1                    // element offset -> bytes (x2)
    v.cmp.ge     p1, v0, v1
    v.cmp.lt     p2, v0, v3
    s.add        s12, s11, s16                   // this context's own scratch
    p.and        p3, p1, p2
    s.movz       s11, #1
    s.add        s11, s10, s1
    s.add        s1, s9, s14                     // &out_ptr3[...]
    vf.fms       v0, v4, v5, v2
    vf.fms       v1, v5, v0, v5
    vf.neg       v0, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v1, v0, v5
for_5:
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s11, #0]
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s11, #64]
    vf.mul       v3, v0, v1                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.f16 v0, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s11, #128]
    vf.mul       v4, v2, v1                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.f16 v2, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s11, #192]
    vf.mul       v5, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.f16 v3, v5
    vf.mul       v5, v4, v1                      // a/y as a refined reciprocal (ISA has no divide)
    v.st.h       [s1, #0], v0
    vf.cvt.f32.f16 v0, v5
    v.st.h       [s1, #32], v2
    v.st.h       [s1, #64], v3
    v.st.h       [s1, #96], v0
    s.addi       s11, s11, #256                  // the next iteration's address
    s.addi       s1, s1, #128                    // the next iteration's address
    s.add        s13, s13, s5
    s.cmp.lt     s10, s13, s4
    br.nz        s10, for_5
endfor_6:
__rctx_next:
    s.addi       s1, s6, #2                      // the next program of this context: + 2
    s.cmp.lt     s10, s1, s7
    s.mov        s6, s1
    br.nz        s10, __rctx_program
    exit
