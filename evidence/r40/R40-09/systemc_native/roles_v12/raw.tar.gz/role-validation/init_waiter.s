
        s.rdspecial s1, role_id
        br.z s1, producer
        .li s5, #0x10000
        mb.wait s5
        exit
producer:
        .li s4, #40
delay:
        s.subi s4, s4, #1
        br.nz s4, delay
        mb.init b0
        exit
    