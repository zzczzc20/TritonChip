    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.sw      s3, [s1, #16]                   // xnumel: i32 at arg_base+16
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    .li       s2, #1073741824
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v3, v1, v0
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.splat      v0, s3
    v.cmp.lt     p1, v3, v0
    s.add        s3, s2, s4                      // &in_ptr0[...]
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    @p1 v.ld.h       v0, [s3, #0]
    s.add        s1, s2, s4                      // &out_ptr0[...]
    vf.cvt.bf16.f32 v1, v0
    vf.mul       v0, v1, v2
    vf.cvt.f32.bf16 v1, v0
    @p1 v.st.h       [s1, #0], v1
__rctx_next:
    exit
