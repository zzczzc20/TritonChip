    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    s.rdspecial  s2, pid.y
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s3, #0
    s.muli       s4, s1, #256                    // a runtime tile origin, x256
    s.shli       s5, s2, #4                      // x16 as a shift
    s.add        s2, s3, s1                      // the tile origin
    s.add        s6, s3, s5                      // the tile origin
    s.movz       s7, #256
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    s.add        s2, s3, s5                      // the tile origin
    s.add        s8, s6, s4                      // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s7
    s.rdspecial  s4, arg_base
    v.add        v4, v0, v1
    v.splat      v0, s2
    v.mul        v1, v2, v3
    v.splat      v2, s8
    s.ld.d       s6, [s4, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.cmpi.lt    p1, v4, #160
    v.cmpi.lt    p2, v0, #256
    v.add        v0, v1, v2
    p.and        p3, p1, p2
    s.addi       s7, s2, #1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    s.addi       s9, s8, #1
    v.splat      v0, s7
    v.splat      v3, s9
    v.cmpi.lt    p2, v0, #256
    v.add        v0, v1, v3
    p.and        p3, p1, p2
    s.addi       s7, s2, #2
    s.addi       s9, s8, #2
    v.splat      v3, s7
    s.ld.d       s7, [s4, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    a.vwrite     a0, s3, v2
    v.splat      v2, s9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v3, #256
    s.movz       s3, #1
    v.add        v0, v1, v2
    p.and        p3, p1, p2
    s.addi       s4, s2, #3
    s.addi       s9, s8, #3
    v.splat      v2, s4
    v.splat      v3, s9
    v.cmpi.lt    p2, v2, #256
    a.vwrite     a0, s3, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    s.movz       s3, #2
    v.add        v0, v1, v3
    p.and        p3, p1, p2
    s.addi       s4, s2, #4
    s.addi       s9, s8, #4
    v.splat      v3, s4
    v.splat      v4, s9
    v.cmpi.lt    p2, v3, #256
    s.movz       s4, #3
    a.vwrite     a0, s3, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.add        v0, v1, v4
    p.and        p3, p1, p2
    s.addi       s3, s2, #5
    s.addi       s9, s8, #5
    v.splat      v3, s3
    v.splat      v4, s9
    v.cmpi.lt    p2, v3, #256
    s.movz       s3, #4
    v.add        v3, v1, v4
    a.vwrite     a0, s4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    p.and        p3, p1, p2
    s.addi       s4, s2, #6
    s.addi       s9, s8, #6
    v.splat      v0, s4
    v.splat      v4, s9
    v.cmpi.lt    p2, v0, #256
    s.movz       s4, #5
    v.add        v0, v1, v4
    p.and        p4, p1, p2
    a.vwrite     a0, s3, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s6, v3]               // index is in elements (ISA sec 9.1)
    s.addi       s3, s2, #7
    s.addi       s9, s8, #7
    v.splat      v3, s3
    v.splat      v4, s9
    v.cmpi.lt    p2, v3, #256
    s.movz       s3, #6
    v.add        v3, v1, v4
    p.and        p3, p1, p2
    s.addi       s9, s2, #8
    a.vwrite     a0, s4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    s.addi       s4, s8, #8
    v.splat      v0, s9
    v.splat      v4, s4
    v.cmpi.lt    p2, v0, #256
    s.movz       s4, #7
    v.add        v0, v1, v4
    p.and        p4, p1, p2
    s.addi       s9, s2, #9
    s.addi       s10, s8, #9
    a.vwrite     a0, s3, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s6, v3]               // index is in elements (ISA sec 9.1)
    v.splat      v3, s9
    v.splat      v4, s10
    v.cmpi.lt    p2, v3, #256
    s.movz       s3, #8
    v.add        v3, v1, v4
    p.and        p3, p1, p2
    s.addi       s9, s2, #10
    s.addi       s10, s8, #10
    v.splat      v4, s9
    a.vwrite     a0, s4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.splat      v0, s10
    v.cmpi.lt    p2, v4, #256
    s.movz       s4, #9
    v.add        v4, v1, v0
    p.and        p4, p1, p2
    s.addi       s9, s2, #11
    s.addi       s10, s8, #11
    v.splat      v0, s9
    v.splat      v5, s10
    a.vwrite     a0, s3, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s6, v3]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v0, #256
    s.movz       s3, #10
    v.add        v0, v1, v5
    p.and        p3, p1, p2
    s.addi       s9, s2, #12
    s.addi       s10, s8, #12
    v.splat      v3, s9
    v.splat      v5, s10
    s.movz       s9, #11
    a.vwrite     a0, s4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s6, v4]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v3, #256
    v.add        v3, v1, v5
    p.and        p4, p1, p2
    s.addi       s4, s2, #13
    s.addi       s10, s8, #13
    v.splat      v4, s4
    v.splat      v5, s10
    s.movz       s4, #12
    v.add        v6, v1, v5
    a.vwrite     a0, s3, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    s.addi       s3, s2, #14
    s.addi       s10, s8, #14
    v.splat      v0, s3
    v.splat      v4, s10
    s.movz       s3, #13
    v.add        v5, v1, v4
    s.addi       s10, s2, #15
    a.vwrite     a0, s9, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s6, v3]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v0, #256
    p.and        p4, p1, p2
    s.addi       s9, s8, #15
    v.splat      v0, s10
    v.splat      v3, s9
    s.movz       s8, #14
    v.add        v4, v1, v3
    s.muli       s9, s1, #4                      // a runtime tile origin, x4
    s.muli       s1, s5, #640                    // a runtime tile origin, x640
    a.vwrite     a0, s4, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s6, v6]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    v.splat      v0, s2
    s.addi       s4, s2, #1
    s.movz       s5, #15
    s.add        s10, s7, s9                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s7, #0
    v.splat      v2, s4
    s.addi       s4, s2, #2
    a.vwrite     a0, s3, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v1, [s6, v5]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v0, #256
    s.add        s3, s10, s1                     // the tile origin
    p.and        p4, p1, p2
    s.movz       s1, #1
    v.splat      v0, s4
    s.addi       s4, s2, #3
    s.addi       s9, s3, #640                    // row 1
    s.movz       s10, #2
    v.splat      v3, s4
    a.vwrite     a0, s8, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s6, v4]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    s.addi       s4, s2, #4
    s.addi       s6, s3, #1280                   // row 2
    s.movz       s8, #3
    v.splat      v2, s4
    s.addi       s4, s2, #5
    s.addi       s11, s3, #1920                  // row 3
    s.movz       s12, #4
    a.vwrite     a0, s5, v1
    a.vread      v1, a0, s7
    v.splat      v4, s4
    @p4 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s1
    v.cmpi.lt    p2, v0, #256
    p.and        p4, p1, p2
    s.addi       s1, s2, #6
    s.addi       s4, s3, #2560                   // row 4
    s.movz       s5, #5
    v.splat      v0, s1
    s.addi       s1, s2, #7
    s.addi       s7, s3, #3200                   // row 5
    @p3 v.st.w       [s9, #0], v1
    a.vread      v1, a0, s10
    v.cmpi.lt    p2, v3, #256
    p.and        p3, p1, p2
    s.movz       s9, #6
    v.splat      v3, s1
    s.addi       s1, s2, #8
    s.addi       s10, s3, #3840                  // row 6
    v.splat      v5, s1
    s.movz       s1, #7
    @p4 v.st.w       [s6, #0], v1
    a.vread      v1, a0, s8
    v.cmpi.lt    p2, v2, #256
    p.and        p4, p1, p2
    s.addi       s6, s2, #9
    s.addi       s8, s3, #4480                   // row 7
    v.splat      v2, s6
    s.movz       s6, #8
    @p3 v.st.w       [s11, #0], v1
    a.vread      v1, a0, s12
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    s.addi       s11, s2, #10
    s.addi       s12, s3, #5120                  // row 8
    v.splat      v4, s11
    s.movz       s11, #9
    @p4 v.st.w       [s4, #0], v1
    a.vread      v1, a0, s5
    v.cmpi.lt    p2, v0, #256
    p.and        p4, p1, p2
    s.addi       s4, s2, #11
    s.addi       s5, s3, #5760                   // row 9
    v.splat      v0, s4
    s.movz       s4, #10
    @p3 v.st.w       [s7, #0], v1
    a.vread      v1, a0, s9
    v.cmpi.lt    p2, v3, #256
    p.and        p3, p1, p2
    s.addi       s7, s2, #12
    s.addi       s9, s3, #6400                   // row 10
    v.splat      v3, s7
    s.movz       s7, #11
    @p4 v.st.w       [s10, #0], v1
    a.vread      v1, a0, s1
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    s.addi       s1, s2, #13
    s.addi       s10, s3, #7040                  // row 11
    v.splat      v5, s1
    s.movz       s1, #12
    @p3 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s6
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    s.addi       s6, s2, #14
    s.addi       s8, s3, #7680                   // row 12
    v.splat      v2, s6
    s.movz       s6, #13
    @p4 v.st.w       [s12, #0], v1
    a.vread      v1, a0, s11
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    s.addi       s11, s2, #15
    s.addi       s2, s3, #8320                   // row 13
    s.movz       s12, #14
    v.splat      v4, s11
    s.addi       s11, s3, #8960                  // row 14
    s.addi       s13, s3, #9600                  // row 15
    @p3 v.st.w       [s5, #0], v1
    a.vread      v1, a0, s4
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    s.movz       s3, #15
    @p4 v.st.w       [s9, #0], v1
    a.vread      v0, a0, s7
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    @p3 v.st.w       [s10, #0], v0
    a.vread      v0, a0, s1
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    @p4 v.st.w       [s8, #0], v0
    a.vread      v0, a0, s6
    v.cmpi.lt    p2, v2, #256
    p.and        p4, p1, p2
    @p3 v.st.w       [s2, #0], v0
    a.vread      v0, a0, s12
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    @p4 v.st.w       [s11, #0], v0
    a.vread      v0, a0, s3
    @p3 v.st.w       [s13, #0], v0
__rctx_next:
    exit
