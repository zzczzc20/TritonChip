    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #6
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    s.rdspecial  s2, arg_base
    v.lshr       v1, v4, v0
    v.movi       v0, #64
    v.sub        v3, v2, v1
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v4, v3, v1
    s.shli       s4, s1, #2                      // element offset -> bytes (x4)
    v.mul        v1, v4, v0
    v.movi       v3, #63
    s.add        s1, s3, s4                      // &in_ptr0[...]
    v.add        v4, v1, v3
    v.ld.w       v1, [s1, #0]
    .li       s1, #1069066811
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1060205080
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v6, v2, v0
    v.cmp.lt     p1, v0, v2
    @p1 v.sel        v2, v6, v0
    v.ld.gather.w v0, [s3, v4]                   // index is in elements (ISA sec 9.1)
    vf.mul       v2, v1, v3
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v1, v3, v2                  // the exact rounding error of x*log2(e)
    vf.sub       v2, v0, v1
    vf.mul       v0, v6, v5
    s.ld.d       s1, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    vf.mul       v1, v2, v3
    s.ld.d       s3, [s2, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    s.add        s2, s1, s4                      // &out_ptr0[...]
    v.exp2.approx v6, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v2, v3, v1                  // the exact rounding error of x*log2(e)
    s.add        s1, s3, s4                      // &out_ptr1[...]
    vf.mul       v1, v7, v5
    vf.fma       v2, v4, v0, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v4
    v.st.w       [s2, #0], v0
    vf.fma       v0, v6, v1, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v1, v0, v6
    v.st.w       [s1, #0], v1
__rctx_next:
    exit
