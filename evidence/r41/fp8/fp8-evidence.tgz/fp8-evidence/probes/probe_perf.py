import os, sys, json
ROOT = os.path.expanduser(os.environ.get('ROOT', '~/r41-fp8-core'))
sys.path[:0] = [ROOT, ROOT+'/python', ROOT+'/compiler/python', ROOT+'/tools/asm', ROOT+'/tools/performance_harness/systemc']
os.environ.update(TNCA_PROFILE='core-vrf-sync-v5', TNCA_TORCH_DEVICE='native', TNCA_INDEX_OPT='1')
os.environ.setdefault('TNCA_BACKEND', 'systemc-tlm-grid')
os.environ.setdefault('TNCA_TLM_BINARY', os.path.expanduser('~/r41-fp8-build/tnca-chip'))
import torch, triton, tnca, tlm_backend
M = tlm_backend.register()
import tnca.torch_device as D; D.register()
from tnca.triton_backend.driver import launch_log
torch._dynamo.config.recompile_limit = 1000
def dev(t): return t.t().contiguous().to('tnca').t() if (t.dim() == 2 and not t.is_contiguous()) else t.to('tnca')
def measure(name, fn, args):
    torch._dynamo.reset()
    f = torch.compile(fn, backend='inductor', fullgraph=True)
    d = [dev(a) for a in args]
    f(*d)
    with launch_log(isolated=True) as L:
        f(*d)
    print(f'{name:40s}', [(e["kernel"][:40], e["device_cycles"]) for e in L], flush=True)
for (m, n, k) in ((64, 96, 128), (128, 192, 384)):
    a8 = torch.randn(m, k).to(torch.float8_e4m3fn); b8 = torch.randn(n, k).to(torch.float8_e4m3fn).t()
    s = torch.tensor(1.0)
    measure(f'fp8 scaled_mm {m}x{n}x{k}', lambda a, b, s, t: torch._scaled_mm(a, b, s, t, out_dtype=torch.bfloat16), (a8, b8, s, s))
    a16 = torch.randn(m, k).to(torch.bfloat16); b16 = torch.randn(n, k).to(torch.bfloat16).t()
    measure(f'bf16 mm (B col-major) {m}x{n}x{k}', lambda a, b: a @ b, (a16, b16))
    b16r = torch.randn(k, n).to(torch.bfloat16)
    measure(f'bf16 mm (B row-major) {m}x{n}x{k}', lambda a, b: a @ b, (a16, b16r))
    b8r = torch.randn(k, n).to(torch.float8_e4m3fn)
    measure(f'fp8 a@b.to(bf16) (B row-major) {m}x{n}x{k}', lambda a, b: a.to(torch.bfloat16) @ b.to(torch.bfloat16), (a8, b8r))
