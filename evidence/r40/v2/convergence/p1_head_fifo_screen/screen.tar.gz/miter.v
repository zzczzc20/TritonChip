module fifo_miter(input wire clk,rst_n,in_valid,out_ready,input wire[7:0] in_data);
 wire rr,rv,hr,hv;
 wire[7:0] rd,hd;
 wire[1:0] rc,hc;
 fifo_ref #(.W(8),.DEPTH(2),.AW(1)) ref_fifo(
  .clk(clk),.rst_n(rst_n),.in_valid(in_valid),.in_ready(rr),.in_data(in_data),
  .out_valid(rv),.out_ready(out_ready),.out_data(rd),.count(rc));
 fifo_head #(.W(8)) head_fifo(
  .clk(clk),.rst_n(rst_n),.in_valid(in_valid),.in_ready(hr),.in_data(in_data),
  .out_valid(hv),.out_ready(out_ready),.out_data(hd),.count(hc));
 reg started=0;
 always @(posedge clk) begin
  started<=1;
  if(!started) assume(!rst_n);
  if(started) begin
   assert(rr==hr);
   assert(rv==hv);
   assert(rc==hc);
   if(rv) assert(rd==hd);
  end
 end
endmodule
