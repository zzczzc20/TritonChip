    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    s.addi       s1, s2, #8192
    s.rdspecial  s2, arg_base
    s.ld.d       s6, [s2, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, role_id
    s.movz       s7, #256
    s.mul        s8, s2, s7
    s.add        s2, s6, s8                      // this context's own scratch
    s.addi       s6, s2, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s2, #0
    s.st.d       [s6, #0], s1
    s.movz       s2, #16
    s.st.d       [s6, #8], s2
    s.movz       s2, #128
    s.st.d       [s6, #16], s2
    s.movz       s2, #512
    s.st.d       [s6, #48], s2
    s.movz       s2, #4
    s.st.d       [s6, #56], s2
    .li       s2, #68719476737
    s.st.d       [s6, #88], s2
    .li       s2, #2207613190144
    s.st.d       [s6, #104], s2
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s2, #0
    s.movz       s6, #128
    s.movz       s7, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s8, s2, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s2, s8, s6
    br.nz        s2, endfor_2
    v.splat      v1, s8
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s2, #128
    s.movz       s9, #16
    s.muli       s10, s4, #512
    v.add        v4, v1, v3
    v.movi       v1, #0
    v.splat      v3, s2
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v7, s9
    s.muli       s2, s8, #4
    v.cmp.ge     p1, v4, v1
    v.cmp.lt     p2, v4, v3
    v.cmp.ge     p3, v5, v6
    v.cmp.lt     p4, v5, v7
    s.add        s9, s1, s10
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s10, s9, s2
    p.and        p2, p5, p1
    .li       s2, #1069066811
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s10, #0]
    .li       s2, #1060205080
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v6, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v7, s8
    v.movi       v8, #128
    v.add        v9, v7, v0
    s.mul        s2, s4, s6
    v.cmp.lt     p1, v9, v8
    v.movi       v7, #0
    s.add        s9, s8, s7
    s.add        s10, s8, s2
    v.splat      v8, s2
    s.shli       s2, s10, #2                     // element offset -> bytes (x4)
    s.movz       s10, #1
    s.add        s11, s3, s2                     // &out_ptr0[...]
    vf.neg       v10, v3
    v.add        v11, v9, v8
    vf.mul       v8, v10, v1
    v.exp2.approx v9, v8                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v11, v10, v1, v8                // the exact rounding error of x*log2(e)
    vf.mul       v1, v11, v4
    vf.fma       v4, v9, v1, v9                  // 2**t * 2**d
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v1, v4, v9
    vf.add       v4, v1, v5
    v.rcp.approx v1, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v4, v1, v6
    vf.fms       v4, v1, v5, v1
    vf.neg       v5, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v5, v5
    @p2 v.sel        v4, v5, v1
    vf.mul       v1, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v1, v1
    @p1 v.st.w       [s11, #0], v1
    vf.add       v1, v2, v3
    @p1 v.sel        v3, v1, v2
    v.mov        v7, v3
    v.mov        v2, v7
    s.mov        s8, s9
    br.nz        s10, for_1
endfor_2:
    vf.reduce.add.b v0, v2
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s5, s2                      // &out_ptr1[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
