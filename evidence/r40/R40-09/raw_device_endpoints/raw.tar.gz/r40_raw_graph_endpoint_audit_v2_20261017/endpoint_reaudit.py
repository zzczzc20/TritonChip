from pathlib import Path
import json,sys,hashlib,time
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'python'),str(Path.cwd()/'tools/r40')]
from tnca.device_timing import clock_span,audit_graph_samples
from archbench.platforms.tnca import _timings
from archbench.provenance import software_tree
import ablate
old=Path.home()/'r40_raw_graph_endpoints_20261017';deadline=time.monotonic()+1800
while not (old/'endpoint_native.exit').exists():
 if time.monotonic()>deadline:raise RuntimeError('original experiment still live; observation expired, not a device verdict')
 time.sleep(5)
assert (old/'endpoint_native.exit').read_text().strip()=='0','original numerical experiment failed; keep its failure'
p=old/'endpoint_result.jsonl';record=json.loads(p.read_text().splitlines()[-1]);assert record['status']=='pass',record.get('problems')
entry=record['timings']['device-graph-makespan'];raw=entry['endpoint_records'];counts=[record['time']['launches']]*len(raw)
assert len(raw)==2
spans=audit_graph_samples(entry['samples'],raw,launch_counts=counts);assert ablate.samples_of(record,'device-graph-makespan')[1]==entry['samples']
steady=[dict(device_cycles=cyc,request_s=call['request_s'],device_timing=span,device_endpoints=edges,launches=count) for cyc,call,span,edges,count in zip(record['timings']['device-cycles-serial-grid']['samples'],record['host']['calls'],spans,raw,counts)]
regenerated=_timings(0,steady,entry['warmup'],entry['clock_hz']);assert regenerated['device-graph-makespan']==entry
report=dict(status='diagnostic-pass',gate_status='not-measured',scope='Exact final raw endpoint writer/auditor and launch completeness against an unchanged original numeric RTL capture; no second device run, no board/performance gate',original_capture=str(p),original_capture_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),original_software_tree=record['platform']['software_tree'],audit_software_tree=software_tree(refresh=True),samples=entry['samples'],launch_counts=counts,endpoint_records=raw,checks=['original frozen tiny add numeric status pass','all original raw graph spans reproduce exactly','launch completeness checked independently of outer interval','current writer regenerates the exact original serialized timing entry'],image_sha256=None,clock_hz=None,required_gate_promotions=[])
Path('endpoint_reaudit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
