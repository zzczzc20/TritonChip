    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, pid.y
    s.movz       s2, #0
    s.shli       s3, s1, #4                      // x16 as a shift
    s.movz       s1, #4096
    s.add        s5, s2, s3                      // the tile origin
    s.rdspecial  s6, arg_base
    s.movz       s7, #1
    s.ld.d       s8, [s6, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s9, #2
    s.movz       s10, #3
    s.ld.d       s11, [s6, #8]                   // out_ptr0: device_ptr64 at arg_base+8
    s.movz       s6, #4
    s.movz       s12, #5
    s.movz       s13, #6
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #9
    s.movz       s17, #10
    s.movz       s18, #11
    s.movz       s19, #12
    s.movz       s20, #13
    s.movz       s21, #14
    s.muli       s22, s3, #16384                 // a runtime tile origin, x16384
    s.movz       s3, #1
    s.movz       s23, #2
    s.muli       s24, s3, #16384
    s.movz       s3, #15
    s.shli       s25, s4, #4                     // x16 as a shift
    s.movz       s4, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.muli       s26, s25, #4096                 // a runtime tile origin, x4096
    s.muli       s27, s23, #16384
    s.movz       s23, #3
    s.movz       s28, #1
    v.iota       v0                              // arange(0, VLEN)
    s.add        s29, s5, s26                    // the tile origin
    v.splat      v1, s1
    s.muli       s1, s23, #16384
    v.mul        v2, v0, v1
    s.movz       s5, #4
    s.movz       s23, #2
    v.splat      v0, s29
    s.muli       s26, s5, #16384
    v.add        v1, v2, v0
    s.movz       s5, #5
    v.ld.gather.w v0, [s8, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s30, #3
    s.addi       s31, s29, #1
    s.muli       s32, s5, #16384
    v.splat      v1, s31
    s.movz       s5, #6
    s.movz       s31, #4
    v.add        v3, v2, v1
    s.muli       s33, s5, #16384
    s.movz       s5, #7
    a.vwrite     a0, s2, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    s.movz       s2, #5
    s.addi       s34, s29, #2
    s.muli       s35, s5, #16384
    v.splat      v1, s34
    s.movz       s5, #8
    v.add        v3, v2, v1
    s.movz       s34, #6
    s.addi       s36, s29, #3
    s.muli       s37, s5, #16384
    a.vwrite     a0, s7, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    s.movz       s5, #9
    s.movz       s7, #7
    v.splat      v1, s36
    s.muli       s36, s5, #16384
    v.add        v3, v2, v1
    s.movz       s5, #10
    s.movz       s38, #8
    s.addi       s39, s29, #4
    s.muli       s40, s5, #16384
    a.vwrite     a0, s9, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s39
    s.movz       s5, #11
    s.movz       s9, #9
    v.add        v3, v2, v1
    s.muli       s39, s5, #16384
    s.movz       s5, #12
    s.movz       s41, #10
    s.addi       s42, s29, #5
    s.muli       s43, s5, #16384
    a.vwrite     a0, s10, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s42
    s.movz       s5, #13
    v.add        v3, v2, v1
    s.movz       s10, #11
    s.addi       s42, s29, #6
    s.muli       s44, s5, #16384
    s.movz       s5, #14
    s.movz       s45, #12
    v.splat      v1, s42
    a.vwrite     a0, s6, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.add        v3, v2, v1
    s.muli       s6, s5, #16384
    s.movz       s5, #15
    s.movz       s42, #13
    s.addi       s46, s29, #7
    s.muli       s47, s5, #16384
    v.splat      v1, s46
    s.movz       s5, #14
    v.add        v4, v2, v1
    a.vwrite     a0, s12, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    s.movz       s12, #15
    s.addi       s46, s29, #8
    s.addi       s48, s29, #9
    v.splat      v1, s46
    v.splat      v3, s48
    v.add        v5, v2, v1
    v.add        v1, v2, v3
    s.addi       s46, s29, #10
    s.addi       s48, s29, #11
    a.vwrite     a0, s13, v0
    v.ld.gather.w v0, [s8, v4]                   // index is in elements (ISA sec 9.1)
    v.splat      v3, s46
    v.splat      v4, s48
    v.add        v6, v2, v3
    v.add        v3, v2, v4
    s.addi       s13, s29, #12
    s.addi       s46, s29, #13
    s.addi       s48, s29, #14
    s.addi       s49, s29, #15
    s.muli       s29, s25, #4                    // a runtime tile origin, x4
    a.vwrite     a0, s14, v0
    v.ld.gather.w v0, [s8, v5]                   // index is in elements (ISA sec 9.1)
    v.splat      v4, s13
    v.add        v5, v2, v4
    s.add        s13, s11, s29                   // the tile origin
    s.add        s11, s13, s22                   // the tile origin
    s.add        s13, s11, s24
    s.add        s14, s11, s27
    a.vwrite     a0, s15, v0
    v.ld.gather.w v0, [s8, v1]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s46
    s.add        s15, s11, s1
    v.add        v4, v2, v1
    s.add        s1, s11, s26
    a.vwrite     a0, s16, v0
    v.ld.gather.w v0, [s8, v6]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s48
    s.add        s16, s11, s32
    v.add        v6, v2, v1
    s.add        s22, s11, s33
    a.vwrite     a0, s17, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s49
    s.add        s17, s11, s35
    v.add        v3, v2, v1
    a.vwrite     a0, s18, v0
    v.ld.gather.w v0, [s8, v5]                   // index is in elements (ISA sec 9.1)
    s.add        s18, s11, s37
    s.add        s24, s11, s36
    a.vwrite     a0, s19, v0
    v.ld.gather.w v0, [s8, v4]                   // index is in elements (ISA sec 9.1)
    s.add        s19, s11, s40
    s.add        s25, s11, s39
    a.vwrite     a0, s20, v0
    v.ld.gather.w v0, [s8, v6]                   // index is in elements (ISA sec 9.1)
    s.add        s20, s11, s43
    a.vwrite     a0, s21, v0
    v.ld.gather.w v0, [s8, v3]                   // index is in elements (ISA sec 9.1)
    s.add        s8, s11, s44
    s.add        s21, s11, s6
    a.vwrite     a0, s3, v0
    // tile epilogue: 16 rows through the vector unit, as f32 (ISA sec 9B)
    a.vread      v0, a0, s4
    s.add        s3, s11, s47
    v.st.w       [s11, #0], v0
    a.vread      v0, a0, s28
    v.st.w       [s13, #0], v0
    a.vread      v0, a0, s23
    v.st.w       [s14, #0], v0
    a.vread      v0, a0, s30
    v.st.w       [s15, #0], v0
    a.vread      v0, a0, s31
    v.st.w       [s1, #0], v0
    a.vread      v0, a0, s2
    v.st.w       [s16, #0], v0
    a.vread      v0, a0, s34
    v.st.w       [s22, #0], v0
    a.vread      v0, a0, s7
    v.st.w       [s17, #0], v0
    a.vread      v0, a0, s38
    v.st.w       [s18, #0], v0
    a.vread      v0, a0, s9
    v.st.w       [s24, #0], v0
    a.vread      v0, a0, s41
    v.st.w       [s19, #0], v0
    a.vread      v0, a0, s10
    v.st.w       [s25, #0], v0
    a.vread      v0, a0, s45
    v.st.w       [s20, #0], v0
    a.vread      v0, a0, s42
    v.st.w       [s8, #0], v0
    a.vread      v0, a0, s5
    v.st.w       [s21, #0], v0
    a.vread      v0, a0, s12
    v.st.w       [s3, #0], v0
__rctx_next:
    exit
