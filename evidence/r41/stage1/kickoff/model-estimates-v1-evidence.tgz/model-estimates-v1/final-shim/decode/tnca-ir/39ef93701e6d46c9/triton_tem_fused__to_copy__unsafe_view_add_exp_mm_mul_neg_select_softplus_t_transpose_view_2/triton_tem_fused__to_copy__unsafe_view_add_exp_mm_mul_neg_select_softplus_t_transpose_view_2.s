    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #1024
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s8, #0], s3
    .li       s1, #2147483647
    s.st.d       [s8, #8], s1
    .li       s1, #2147483647
    s.st.d       [s8, #16], s1
    s.movz       s1, #4096
    s.st.d       [s8, #48], s1
    s.movz       s1, #2
    s.st.d       [s8, #56], s1
    .li       s1, #68719476752
    s.st.d       [s8, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #1
    s.movz       s3, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #1
    s.sub        s14, s1, s4
    s.min.s      s15, s14, s1
    s.cmp.lt     s14, s4, s8
    s.sub        s8, s3, s14
    s.cmp.lt     s3, s15, s10
    s.sub        s10, s9, s3
    s.xor        s3, s4, s8
    s.sub        s9, s3, s8
    s.xor        s3, s15, s10
    s.sub        s14, s3, s10
    s.addi       s3, s11, #0
    s.addi       s10, s12, #0
    s.cmp.eq     s11, s14, s13
    s.mov        s3, s9
    br.nz        s11, sdiv_done_1
    s.movz       s11, #0
    s.movz       s12, #31
    s.mov        s3, s11
    s.addi       s11, s12, #0
sdiv_2:
    s.lshr       s12, s9, s11
    s.shli       s13, s10, #1
    s.andi       s16, s12, #1
    s.movz       s12, #0
    s.or         s17, s13, s16
    s.movz       s13, #1
    s.cmp.geu    s16, s17, s14
    s.shl        s18, s13, s11
    s.sub        s13, s12, s16
    s.subi       s12, s11, #1
    s.and        s16, s14, s13
    s.and        s19, s18, s13
    s.sub        s13, s17, s16
    s.or         s16, s3, s19
    s.mov        s10, s13
    s.mov        s3, s16
    s.mov        s11, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s11, s12
    br.nz        s13, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s9, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.cmp.lt     s13, s15, s3
    s.movz       s3, #0
    s.cmp.lt     s14, s9, s11
    s.sub        s11, s12, s13
    s.sub        s12, s3, s14
    s.xor        s3, s15, s11
    s.xor        s13, s10, s8
    s.xor        s10, s9, s12
    s.sub        s14, s3, s11
    s.movz       s3, #0
    s.movz       s15, #1
    s.sub        s16, s13, s8
    s.sub        s8, s10, s12
    s.movz       s10, #0
    s.addi       s13, s3, #0
    s.cmp.eq     s3, s14, s15
    s.add        s15, s4, s16
    s.addi       s4, s10, #0
    s.mov        s13, s8
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s10, #31
    s.mov        s13, s3
    s.addi       s3, s10, #0
sdiv_4:
    s.lshr       s10, s8, s3
    s.shli       s16, s4, #1
    s.andi       s17, s10, #1
    s.movz       s10, #0
    s.or         s18, s16, s17
    s.movz       s16, #1
    s.cmp.geu    s17, s18, s14
    s.shl        s19, s16, s3
    s.sub        s16, s10, s17
    s.subi       s10, s3, #1
    s.and        s17, s14, s16
    s.and        s20, s19, s16
    s.sub        s16, s18, s17
    s.or         s17, s13, s20
    s.mov        s4, s16
    s.mov        s13, s17
    s.mov        s3, s10
    s.movz       s10, #0
    s.cmp.ge     s16, s3, s10
    br.nz        s16, sdiv_4
sdiv_done_3:
    s.xor        s3, s12, s11
    s.movz       s4, #16
    s.xor        s8, s13, s3
    v.splat      v0, s15
    s.sub        s10, s8, s3
    v.splat      v1, s9
    s.mul        s3, s10, s4
    v.splat      v2, s10
    v.splat      v3, s9
    v.iota       v4                              // arange(0, VLEN)
    v.iota       v5                              // arange(0, VLEN)
    s.andi       s8, s3, #15
    v.splat      v6, s3
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s8
    v.cmp.ge     p1, v2, v3
    v.add        v1, v6, v4
    v.add        v1, v0, v5
    s.movz       s10, #128
    s.addi       s11, s9, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s9, s11, s10
    br.nz        s9, endfor_6
    s.mul        s9, s11, s4
    s.muli       s12, s9, #2                     // a runtime tile origin, x2
    s.add        s13, s2, s12                    // the tile origin
    v.ld.h       v0, [s13, #0]
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s12, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s13, s8                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s9                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s13, s12
    mb.wait      s12
    s.rdspecial  s9, arg_base
    s.ld.d       s13, [s9, #40]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s9, role_id
    s.movz       s14, #1024
    s.mul        s16, s9, s14
    s.add        s9, s13, s16                    // this context's own scratch
    s.addi       s13, s9, #256                   // 512 bytes of repack scratch
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s13, #0], v0
    s.addi       s14, s13, #32                   // row 1
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #64                   // row 2
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #96                   // row 3
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #128                  // row 4
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #160                  // row 5
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #192                  // row 6
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #224                  // row 7
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #256                  // row 8
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #288                  // row 9
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #320                  // row 10
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #352                  // row 11
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #384                  // row 12
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #416                  // row 13
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #448                  // row 14
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #480                  // row 15
    v.st.h       [s14, #0], v0
    s.addi       s14, s9, #768                   // TensorMap 1: a repacked tile
    s.movz       s9, #0
    s.st.d       [s14, #0], s13
    s.movz       s9, #16
    s.st.d       [s14, #8], s9
    s.movz       s9, #16
    s.st.d       [s14, #16], s9
    s.movz       s9, #32
    s.st.d       [s14, #48], s9
    s.movz       s9, #2
    s.st.d       [s14, #56], s9
    .li       s9, #68719476752
    s.st.d       [s14, #88], s9
    .li       s9, #1108101562368
    s.st.d       [s14, #104], s9
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s9, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s16, s9                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s17, s9                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s16, s13
    mb.wait      s13
    mb.arm       s9, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v48, v56, s9
    mb.wait      s9
    s.add        s14, s11, s1
    s.mov        s11, s14
    s.movz       s14, #1
    br.nz        s14, for_5
endfor_6:
    s.mul        s2, s15, s4
    s.movz       s8, #0
    v.splat      v0, s1
    v.movi       v1, #1
    v.movi       v2, #0
    s.add        s1, s8, s2                      // the tile origin
    s.movz       s8, #0
    v.splat      v3, s1
    s.add        s10, s8, s3                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s8, s3, #2                      // a runtime tile origin, x2
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v3, v1, v2
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s10
    v.extract    s10, v3, #0
    s.muli       s11, s2, #32                    // a runtime tile origin, x32
    v.splat      v3, s10
    v.movi       v5, #0
    v.add        v6, v1, v2
    v.splat      v1, s4
    s.add        s4, s6, s8                      // the tile origin
    v.cmp.ne     p1, v3, v5
    v.cmp.lt     p2, v6, v1
    s.add        s6, s4, s11                     // the tile origin
    s.movz       s4, #0
    p.and        p3, p1, p2
    a.vread      v1, a0, s4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    s.addi       s4, s1, #1
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    s.movz       s8, #1
    v.cmp.lt     p1, v1, v0
    vf.cvt.bf16.f32 v1, v3
    s.addi       s10, s6, #32                    // row 1
    s.movz       s11, #1
    s.muli       s14, s3, #4                     // a runtime tile origin, x4
    s.muli       s15, s2, #64                    // a runtime tile origin, x64
    v.splat      v3, s2
    v.movi       v5, #1
    vf.cvt.bf16.f32 v6, v2
    s.add        s16, s5, s14                    // the tile origin
    v.add        v2, v3, v4
    v.movi       v2, #0
    s.add        s5, s16, s15                    // the tile origin
    v.movi       v3, #0
    @p1 v.sel        v4, v5, v2
    vf.add       v2, v1, v6
    s.addi       s14, s1, #2
    v.extract    s15, v4, #0
    v.splat      v1, s14
    v.splat      v4, s15
    a.vwrite     a1, s4, v2
    a.vread      v2, a0, s8
    v.cmp.ne     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s10, #0]
    v.movi       v4, #1
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v0
    vf.cvt.bf16.f32 v1, v3
    @p1 v.sel        v3, v4, v5
    v.movi       v4, #0
    s.movz       s4, #2
    v.extract    s8, v3, #0
    s.addi       s10, s6, #64                    // row 2
    v.splat      v3, s8
    s.addi       s8, s1, #3
    v.movi       v5, #1
    v.cmp.ne     p1, v3, v4
    vf.cvt.bf16.f32 v3, v2
    p.and        p3, p1, p2
    v.splat      v2, s8
    v.movi       v4, #0
    v.movi       v6, #0
    vf.add       v7, v1, v3
    v.cmp.lt     p1, v2, v0
    @p1 v.sel        v1, v5, v4
    s.movz       s8, #2
    s.movz       s14, #3
    a.vwrite     a1, s11, v7
    a.vread      v2, a0, s4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s10, #0]
    v.extract    s4, v1, #0
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s4
    s.addi       s4, s6, #96                     // row 3
    s.addi       s10, s1, #4
    v.cmp.ne     p1, v2, v6
    vf.cvt.bf16.f32 v2, v1
    p.and        p3, p1, p2
    v.splat      v1, s10
    v.movi       v4, #1
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v0
    v.movi       v1, #0
    vf.cvt.bf16.f32 v6, v3
    @p1 v.sel        v3, v4, v5
    s.movz       s10, #3
    s.movz       s11, #4
    v.extract    s15, v3, #0
    vf.add       v3, v2, v6
    v.splat      v2, s15
    s.addi       s15, s6, #128                   // row 4
    s.movz       s16, #4
    v.cmp.ne     p1, v2, v1
    a.vwrite     a1, s8, v3
    a.vread      v1, a0, s14
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s4, s1, #5
    v.movi       v1, #1
    v.splat      v4, s4
    s.movz       s4, #5
    vf.cvt.bf16.f32 v5, v3
    v.movi       v3, #0
    v.cmp.lt     p1, v4, v0
    v.movi       v4, #0
    @p1 v.sel        v6, v1, v3
    s.addi       s8, s6, #160                    // row 5
    s.movz       s14, #5
    vf.cvt.bf16.f32 v1, v2
    vf.add       v2, v5, v1
    a.vwrite     a1, s10, v2
    a.vread      v1, a0, s11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s15, #0]
    v.extract    s10, v6, #0
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s10
    s.addi       s10, s1, #6
    v.movi       v5, #1
    v.cmp.ne     p1, v1, v4
    vf.cvt.bf16.f32 v1, v3
    p.and        p3, p1, p2
    v.splat      v3, s10
    v.movi       v4, #0
    v.movi       v6, #0
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v3, v5, v4
    vf.cvt.bf16.f32 v4, v2
    s.movz       s10, #6
    v.extract    s11, v3, #0
    s.addi       s15, s6, #192                   // row 6
    v.splat      v2, s11
    vf.add       v3, v1, v4
    s.movz       s11, #6
    v.cmp.ne     p1, v2, v6
    p.and        p4, p1, p2
    a.vwrite     a1, s16, v3
    a.vread      v1, a0, s4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s8, #0]
    s.addi       s4, s1, #7
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s4
    v.movi       v4, #1
    s.movz       s4, #7
    v.cmp.lt     p1, v1, v0
    vf.cvt.bf16.f32 v1, v3
    v.movi       v3, #0
    v.movi       v5, #0
    s.addi       s8, s6, #224                    // row 7
    @p1 v.sel        v6, v4, v3
    s.movz       s16, #7
    vf.cvt.bf16.f32 v3, v2
    vf.add       v2, v1, v3
    a.vwrite     a1, s14, v2
    a.vread      v1, a0, s10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s15, #0]
    v.extract    s10, v6, #0
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s10
    s.addi       s10, s1, #8
    v.movi       v4, #1
    v.cmp.ne     p1, v1, v5
    vf.cvt.bf16.f32 v1, v3
    p.and        p3, p1, p2
    v.splat      v3, s10
    v.movi       v5, #0
    v.movi       v6, #0
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v3, v4, v5
    vf.cvt.bf16.f32 v4, v2
    s.movz       s10, #8
    v.extract    s14, v3, #0
    s.addi       s15, s6, #256                   // row 8
    v.splat      v2, s14
    vf.add       v3, v1, v4
    s.movz       s14, #8
    v.cmp.ne     p1, v2, v6
    p.and        p4, p1, p2
    a.vwrite     a1, s11, v3
    a.vread      v1, a0, s4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s8, #0]
    s.addi       s4, s1, #9
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s4
    v.movi       v4, #1
    s.movz       s4, #9
    v.cmp.lt     p1, v1, v0
    vf.cvt.bf16.f32 v1, v3
    v.movi       v3, #0
    v.movi       v5, #0
    s.addi       s8, s6, #288                    // row 9
    @p1 v.sel        v6, v4, v3
    s.movz       s11, #9
    vf.cvt.bf16.f32 v3, v2
    vf.add       v2, v1, v3
    a.vwrite     a1, s16, v2
    a.vread      v1, a0, s10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s15, #0]
    v.extract    s10, v6, #0
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s10
    s.addi       s10, s1, #10
    v.movi       v4, #1
    v.cmp.ne     p1, v1, v5
    vf.cvt.bf16.f32 v1, v3
    p.and        p3, p1, p2
    v.splat      v3, s10
    v.movi       v5, #0
    v.movi       v6, #0
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v3, v4, v5
    vf.cvt.bf16.f32 v4, v2
    s.movz       s10, #10
    v.extract    s15, v3, #0
    s.addi       s16, s6, #320                   // row 10
    v.splat      v2, s15
    vf.add       v3, v1, v4
    s.movz       s15, #10
    v.cmp.ne     p1, v2, v6
    p.and        p4, p1, p2
    a.vwrite     a1, s14, v3
    a.vread      v1, a0, s4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s8, #0]
    s.addi       s4, s1, #11
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s4
    v.movi       v4, #1
    s.movz       s4, #11
    v.cmp.lt     p1, v1, v0
    vf.cvt.bf16.f32 v1, v3
    v.movi       v3, #0
    v.movi       v5, #0
    s.addi       s8, s6, #352                    // row 11
    @p1 v.sel        v6, v4, v3
    s.movz       s14, #11
    vf.cvt.bf16.f32 v3, v2
    vf.add       v2, v1, v3
    a.vwrite     a1, s11, v2
    a.vread      v1, a0, s10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s16, #0]
    v.extract    s10, v6, #0
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s10
    s.addi       s10, s1, #12
    v.movi       v4, #1
    v.cmp.ne     p1, v1, v5
    vf.cvt.bf16.f32 v1, v3
    p.and        p3, p1, p2
    v.splat      v3, s10
    v.movi       v5, #0
    v.movi       v6, #0
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v3, v4, v5
    vf.cvt.bf16.f32 v4, v2
    s.movz       s10, #12
    v.extract    s11, v3, #0
    s.addi       s16, s6, #384                   // row 12
    v.splat      v2, s11
    vf.add       v3, v1, v4
    s.movz       s11, #12
    v.cmp.ne     p1, v2, v6
    p.and        p4, p1, p2
    a.vwrite     a1, s15, v3
    a.vread      v1, a0, s4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s8, #0]
    s.addi       s4, s1, #13
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s4
    v.movi       v4, #1
    s.movz       s4, #13
    v.cmp.lt     p1, v1, v0
    vf.cvt.bf16.f32 v1, v3
    v.movi       v3, #0
    v.movi       v5, #0
    s.addi       s8, s6, #416                    // row 13
    @p1 v.sel        v6, v4, v3
    s.movz       s15, #13
    vf.cvt.bf16.f32 v3, v2
    vf.add       v2, v1, v3
    a.vwrite     a1, s14, v2
    a.vread      v1, a0, s10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s16, #0]
    v.extract    s10, v6, #0
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s10
    s.addi       s10, s1, #14
    v.movi       v4, #1
    v.cmp.ne     p1, v1, v5
    vf.cvt.bf16.f32 v1, v3
    p.and        p3, p1, p2
    v.splat      v3, s10
    v.movi       v5, #0
    v.movi       v6, #0
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v3, v4, v5
    vf.cvt.bf16.f32 v4, v2
    s.movz       s10, #14
    v.extract    s14, v3, #0
    s.addi       s16, s6, #448                   // row 14
    v.splat      v2, s14
    vf.add       v3, v1, v4
    s.movz       s14, #14
    v.cmp.ne     p1, v2, v6
    p.and        p4, p1, p2
    a.vwrite     a1, s11, v3
    a.vread      v1, a0, s4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s8, #0]
    s.addi       s4, s1, #15
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s4
    v.movi       v4, #1
    s.movz       s4, #15
    v.cmp.lt     p1, v1, v0
    vf.cvt.bf16.f32 v1, v3
    v.movi       v3, #0
    v.movi       v5, #0
    s.addi       s8, s6, #480                    // row 15
    @p1 v.sel        v6, v4, v3
    s.movz       s6, #15
    s.movz       s11, #0
    vf.cvt.bf16.f32 v3, v2
    .li       s17, #1101004800
    v.splat      v2, s17                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v4, v1, v3
    .li       s17, #1069066811
    v.splat      v1, s17                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    a.vwrite     a1, s15, v4
    a.vread      v3, a0, s10
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s16, #0]
    v.extract    s10, v6, #0
    vf.cvt.f32.bf16 v6, v3
    v.splat      v3, s10
    .li       s10, #1060205080
    v.splat      v7, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s10, #0
    v.cmp.ne     p1, v3, v5
    vf.cvt.bf16.f32 v3, v6
    p.and        p3, p1, p2
    s.movz       s15, #1
    s.movz       s16, #1
    vf.cvt.bf16.f32 v5, v4
    vf.add       v4, v3, v5
    a.vwrite     a1, s14, v4
    a.vread      v3, a0, s4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s8, #0]
    s.movz       s4, #2
    vf.cvt.f32.bf16 v5, v3
    s.movz       s8, #2
    vf.cvt.bf16.f32 v3, v5
    s.movz       s14, #3
    vf.cvt.bf16.f32 v5, v4
    vf.add       v4, v3, v5
    a.vwrite     a1, s6, v4
    a.vread      v3, a1, s11
    s.movz       s6, #3
    s.movz       s11, #4
    vf.mul       v4, v3, v1
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v3, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v6, v7
    vf.fma       v4, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v5
    a.vwrite     a2, s10, v3
    a.vread      v3, a1, s15
    s.movz       s10, #4
    s.movz       s15, #5
    vf.mul       v4, v3, v1
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v3, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v6, v7
    vf.fma       v4, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v5
    a.vwrite     a2, s16, v3
    a.vread      v3, a1, s4
    s.movz       s4, #5
    s.movz       s16, #6
    vf.mul       v4, v3, v1
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v3, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v6, v7
    vf.fma       v4, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v5
    a.vwrite     a2, s8, v3
    a.vread      v3, a1, s14
    s.movz       s8, #6
    s.movz       s14, #7
    vf.mul       v4, v3, v1
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v3, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v6, v7
    vf.fma       v4, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v5
    a.vwrite     a2, s6, v3
    a.vread      v3, a1, s11
    s.movz       s6, #7
    s.movz       s11, #8
    vf.mul       v4, v3, v1
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v3, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v6, v7
    vf.fma       v4, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v5
    a.vwrite     a2, s10, v3
    a.vread      v3, a1, s15
    s.movz       s10, #8
    s.movz       s15, #9
    vf.mul       v4, v3, v1
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v3, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v6, v7
    vf.fma       v4, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v5
    a.vwrite     a2, s4, v3
    a.vread      v3, a1, s16
    s.movz       s4, #9
    s.movz       s16, #10
    vf.mul       v4, v3, v1
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v3, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v6, v7
    vf.fma       v4, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v5
    a.vwrite     a2, s8, v3
    a.vread      v3, a1, s14
    s.movz       s8, #10
    s.movz       s14, #11
    vf.mul       v4, v3, v1
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v3, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v6, v7
    vf.fma       v4, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v5
    a.vwrite     a2, s6, v3
    a.vread      v3, a1, s11
    s.movz       s6, #11
    s.movz       s11, #12
    vf.mul       v4, v3, v1
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v3, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v6, v7
    vf.fma       v4, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v5
    a.vwrite     a2, s10, v3
    a.vread      v3, a1, s15
    s.movz       s10, #12
    s.movz       s15, #13
    vf.mul       v4, v3, v1
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v3, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v6, v7
    vf.fma       v4, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v5
    a.vwrite     a2, s4, v3
    a.vread      v3, a1, s16
    s.movz       s4, #13
    s.movz       s16, #14
    vf.mul       v4, v3, v1
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v3, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v6, v7
    vf.fma       v4, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v5
    a.vwrite     a2, s8, v3
    a.vread      v3, a1, s14
    s.movz       s8, #14
    s.movz       s14, #15
    vf.mul       v4, v3, v1
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v3, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v6, v7
    vf.fma       v4, v5, v3, v5                  // 2**t * 2**d
    .li       s17, #1065353216
    v.splat      v3, s17                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v6, v4, v5
    a.vwrite     a2, s6, v6
    a.vread      v4, a1, s11
    s.movz       s6, #15
    s.movz       s11, #0
    vf.mul       v5, v4, v1
    v.exp2.approx v6, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v4, v1, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v4, v8, v7
    vf.fma       v5, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v4, v5, v6
    a.vwrite     a2, s10, v4
    a.vread      v4, a1, s15
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s10, #0
    s.movz       s15, #1
    vf.mul       v5, v4, v1
    v.exp2.approx v6, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v4, v1, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v4, v8, v7
    vf.fma       v5, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v4, v5, v6
    a.vwrite     a2, s4, v4
    a.vread      v4, a1, s16
    s.movz       s4, #1
    s.movz       s16, #2
    vf.mul       v5, v4, v1
    v.exp2.approx v6, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v4, v1, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v4, v8, v7
    vf.fma       v5, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v4, v5, v6
    a.vwrite     a2, s8, v4
    a.vread      v4, a1, s14
    s.movz       s8, #2
    s.movz       s14, #3
    vf.mul       v5, v4, v1
    v.exp2.approx v6, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v4, v1, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v4, v8, v7
    vf.fma       v5, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v4, v5, v6
    a.vwrite     a2, s6, v4
    a.vread      v4, a2, s11
    s.movz       s6, #3
    s.movz       s11, #4
    vf.add       v5, v4, v3
    a.vwrite     a3, s10, v5
    a.vread      v4, a2, s15
    s.movz       s10, #4
    s.movz       s15, #5
    vf.add       v5, v4, v3
    a.vwrite     a3, s4, v5
    a.vread      v4, a2, s16
    s.movz       s4, #5
    s.movz       s16, #6
    vf.add       v5, v4, v3
    a.vwrite     a3, s8, v5
    a.vread      v4, a2, s14
    s.movz       s8, #6
    s.movz       s14, #7
    vf.add       v5, v4, v3
    a.vwrite     a3, s6, v5
    a.vread      v4, a2, s11
    s.movz       s6, #7
    s.movz       s11, #8
    vf.add       v5, v4, v3
    a.vwrite     a3, s10, v5
    a.vread      v4, a2, s15
    s.movz       s10, #8
    s.movz       s15, #9
    vf.add       v5, v4, v3
    a.vwrite     a3, s4, v5
    a.vread      v4, a2, s16
    s.movz       s4, #9
    s.movz       s16, #10
    vf.add       v5, v4, v3
    .li       s17, #1065353216
    v.splat      v4, s17                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s17, #1065353216
    v.splat      v6, s17                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    a.vwrite     a3, s8, v5
    a.vread      v5, a2, s14
    s.movz       s8, #10
    s.movz       s14, #11
    vf.add       v8, v5, v3
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    v.splat      v5, s1
    s.muli       s17, s3, #4                     // a runtime tile origin, x4
    s.muli       s3, s2, #64                     // a runtime tile origin, x64
    a.vwrite     a3, s6, v8
    a.vread      v8, a2, s11
    s.movz       s2, #11
    s.movz       s6, #12
    vf.add       v9, v8, v3
    v.movi       v8, #1
    v.movi       v10, #0
    v.cmp.lt     p1, v5, v0
    s.add        s11, s7, s17                    // the tile origin
    a.vwrite     a3, s10, v9
    a.vread      v5, a2, s15
    s.movz       s7, #12
    s.movz       s10, #13
    vf.add       v9, v5, v3
    s.movz       s15, #13
    @p1 v.sel        v5, v8, v10
    v.movi       v8, #0
    s.add        s17, s11, s3                    // the tile origin
    a.vwrite     a3, s4, v9
    a.vread      v9, a2, s16
    s.movz       s3, #14
    s.movz       s4, #14
    vf.add       v10, v9, v3
    s.movz       s11, #15
    a.vwrite     a3, s8, v10
    a.vread      v9, a2, s14
    v.extract    s8, v5, #0
    s.movz       s14, #15
    vf.add       v5, v9, v3
    v.splat      v9, s8
    s.movz       s8, #0
    v.cmp.ne     p1, v9, v8
    a.vwrite     a3, s2, v5
    a.vread      v5, a2, s6
    p.and        p3, p1, p2
    s.movz       s2, #0
    vf.add       v8, v5, v3
    s.movz       s6, #0
    a.vwrite     a3, s7, v8
    a.vread      v5, a2, s10
    s.movz       s7, #0
    s.movz       s10, #0
    vf.add       v8, v5, v3
    a.vwrite     a3, s15, v8
    a.vread      v5, a2, s3
    s.movz       s3, #0
    vf.add       v8, v5, v3
    s.movz       s15, #0
    a.vwrite     a3, s4, v8
    a.vread      v5, a2, s11
    .li       s4, #1065353216
    v.splat      v8, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v9, v5, v3
    a.vwrite     a3, s14, v9
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v3, [s5, #0]
    a.vread      v5, a1, s8
    a.vread      v9, a1, s2
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s10
    a.vread      v13, a2, s3
    a.vread      v14, a3, s15
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s1
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v1
    v.movi       v14, #1
    v.exp2.approx v16, v5                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v17, v3, v1, v5                 // the exact rounding error of x*log2(e)
    v.movi       v3, #0
    @p4 v.sel        v5, v14, v3
    vf.mul       v3, v17, v7
    v.extract    s2, v5, #0
    vf.mul       v5, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v16, v3, v16               // 2**t * 2**d
    v.splat      v3, s2
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v16
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v14, v15, v12
    vf.neg       v12, v10
    s.addi       s2, s1, #1
    vf.mul       v10, v13, v14                   // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v13, s2
    v.movi       v14, #1
    v.movi       v15, #0
    v.cmp.lt     p4, v13, v0
    vf.mul       v13, v5, v10
    @p4 v.sel        v5, v14, v15
    v.movi       v10, #0
    v.movi       v14, #0
    v.extract    s2, v5, #0
    @p1 v.sel        v5, v11, v13
    v.splat      v11, s2
    v.cmp.ne     p1, v3, v10
    @p3 v.sel        v3, v9, v5
    v.cmp.ne     p3, v11, v14
    p.and        p4, p1, p2
    vf.mul       v5, v12, v3
    s.addi       s2, s5, #64                     // row 1
    p.and        p1, p3, p2
    s.movz       s3, #1
    s.movz       s4, #1
    vf.mul       v3, v5, v1
    s.movz       s6, #1
    s.movz       s7, #1
    v.exp2.approx v9, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v5, v1, v3                 // the exact rounding error of x*log2(e)
    s.movz       s8, #1
    vf.mul       v3, v10, v7
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #1
    s.movz       s11, #1
    @p4 v.st.w       [s17, #0], v3
    s.addi       s14, s1, #1
    s.addi       s15, s17, #64                   // row 1
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #2
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #128                    // row 2
    p.and        p1, p3, p2
    s.movz       s3, #2
    vf.mul       v5, v3, v1
    s.movz       s4, #2
    s.movz       s6, #2
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #2
    vf.mul       v3, v10, v7
    s.movz       s8, #2
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #2
    s.movz       s11, #2
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #2
    s.addi       s15, s17, #128                  // row 2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #3
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #192                    // row 3
    p.and        p1, p3, p2
    s.movz       s3, #3
    vf.mul       v5, v3, v1
    s.movz       s4, #3
    s.movz       s6, #3
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #3
    vf.mul       v3, v10, v7
    s.movz       s8, #3
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #3
    s.movz       s11, #3
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #3
    s.addi       s15, s17, #192                  // row 3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #4
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #256                    // row 4
    p.and        p1, p3, p2
    s.movz       s3, #4
    vf.mul       v5, v3, v1
    s.movz       s4, #4
    s.movz       s6, #4
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #4
    vf.mul       v3, v10, v7
    s.movz       s8, #4
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #4
    s.movz       s11, #4
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #4
    s.addi       s15, s17, #256                  // row 4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #5
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #320                    // row 5
    p.and        p1, p3, p2
    s.movz       s3, #5
    vf.mul       v5, v3, v1
    s.movz       s4, #5
    s.movz       s6, #5
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #5
    vf.mul       v3, v10, v7
    s.movz       s8, #5
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #5
    s.movz       s11, #5
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #5
    s.addi       s15, s17, #320                  // row 5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #6
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #384                    // row 6
    p.and        p1, p3, p2
    s.movz       s3, #6
    vf.mul       v5, v3, v1
    s.movz       s4, #6
    s.movz       s6, #6
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #6
    vf.mul       v3, v10, v7
    s.movz       s8, #6
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #6
    s.movz       s11, #6
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #6
    s.addi       s15, s17, #384                  // row 6
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #7
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #448                    // row 7
    p.and        p1, p3, p2
    s.movz       s3, #7
    vf.mul       v5, v3, v1
    s.movz       s4, #7
    s.movz       s6, #7
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #7
    vf.mul       v3, v10, v7
    s.movz       s8, #7
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #7
    s.movz       s11, #7
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #7
    s.addi       s15, s17, #448                  // row 7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #8
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #512                    // row 8
    p.and        p1, p3, p2
    s.movz       s3, #8
    vf.mul       v5, v3, v1
    s.movz       s4, #8
    s.movz       s6, #8
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #8
    vf.mul       v3, v10, v7
    s.movz       s8, #8
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #8
    s.movz       s11, #8
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #8
    s.addi       s15, s17, #512                  // row 8
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #9
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #576                    // row 9
    p.and        p1, p3, p2
    s.movz       s3, #9
    vf.mul       v5, v3, v1
    s.movz       s4, #9
    s.movz       s6, #9
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #9
    vf.mul       v3, v10, v7
    s.movz       s8, #9
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #9
    s.movz       s11, #9
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #9
    s.addi       s15, s17, #576                  // row 9
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #10
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #640                    // row 10
    p.and        p1, p3, p2
    s.movz       s3, #10
    vf.mul       v5, v3, v1
    s.movz       s4, #10
    s.movz       s6, #10
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #10
    vf.mul       v3, v10, v7
    s.movz       s8, #10
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #10
    s.movz       s11, #10
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #10
    s.addi       s15, s17, #640                  // row 10
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #11
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #704                    // row 11
    p.and        p1, p3, p2
    s.movz       s3, #11
    vf.mul       v5, v3, v1
    s.movz       s4, #11
    s.movz       s6, #11
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #11
    vf.mul       v3, v10, v7
    s.movz       s8, #11
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #11
    s.movz       s11, #11
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #11
    s.addi       s15, s17, #704                  // row 11
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #12
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #768                    // row 12
    p.and        p1, p3, p2
    s.movz       s3, #12
    vf.mul       v5, v3, v1
    s.movz       s4, #12
    s.movz       s6, #12
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #12
    vf.mul       v3, v10, v7
    s.movz       s8, #12
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #12
    s.movz       s11, #12
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #12
    s.addi       s15, s17, #768                  // row 12
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #13
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #832                    // row 13
    p.and        p1, p3, p2
    s.movz       s3, #13
    vf.mul       v5, v3, v1
    s.movz       s4, #13
    s.movz       s6, #13
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #13
    vf.mul       v3, v10, v7
    s.movz       s8, #13
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #13
    s.movz       s11, #13
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #13
    s.addi       s15, s17, #832                  // row 13
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #14
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #896                    // row 14
    p.and        p1, p3, p2
    s.movz       s3, #14
    vf.mul       v5, v3, v1
    s.movz       s4, #14
    s.movz       s6, #14
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s7, #14
    vf.mul       v3, v10, v7
    s.movz       s8, #14
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s10, #14
    s.movz       s11, #14
    @p4 v.st.w       [s15, #0], v3
    s.addi       s14, s1, #14
    s.addi       s15, s17, #896                  // row 14
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s6
    a.vread      v11, a2, s7
    a.vread      v12, a3, s8
    a.vread      v13, a2, s10
    a.vread      v14, a3, s11
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v10, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v5, s14
    v.rcp.approx v12, v10                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v3, v1
    v.cmp.lt     p4, v5, v0
    v.exp2.approx v5, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v3, v1, v14                // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v14, #0
    vf.mul       v17, v16, v7
    @p4 v.sel        v16, v3, v14
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v14, v10, v12, v8
    vf.fms       v10, v12, v14, v12
    vf.fma       v14, v5, v17, v5                // 2**t * 2**d
    v.extract    s2, v16, #0
    vf.neg       v15, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v14, v14
    @p4 v.sel        v10, v14, v5
    vf.cmp.o     p4, v15, v15
    @p4 v.sel        v5, v15, v12
    vf.neg       v12, v10
    s.addi       s3, s1, #15
    vf.mul       v10, v13, v5                    // a/y as a refined reciprocal (ISA has no divide)
    v.splat      v5, s3
    v.movi       v13, #1
    v.movi       v14, #0
    v.cmp.lt     p4, v5, v0
    vf.mul       v5, v3, v10
    @p4 v.sel        v3, v13, v14
    v.splat      v10, s2
    v.movi       v13, #0
    v.extract    s2, v3, #0
    @p1 v.sel        v3, v11, v5
    v.splat      v5, s2
    v.movi       v11, #0
    @p3 v.sel        v14, v9, v3
    v.cmp.ne     p1, v10, v13
    v.cmp.ne     p3, v5, v11
    vf.mul       v3, v12, v14
    p.and        p4, p1, p2
    s.addi       s2, s5, #960                    // row 15
    p.and        p1, p3, p2
    s.movz       s3, #15
    vf.mul       v5, v3, v1
    s.movz       s4, #15
    s.movz       s5, #15
    v.exp2.approx v9, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v3, v1, v5                 // the exact rounding error of x*log2(e)
    s.movz       s6, #15
    vf.mul       v3, v10, v7
    s.movz       s7, #15
    vf.fma       v5, v9, v3, v9                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v3, v5, v9
    s.movz       s8, #15
    s.movz       s10, #15
    @p4 v.st.w       [s15, #0], v3
    s.addi       s11, s1, #15
    s.addi       s1, s17, #960                   // row 15
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    a.vread      v5, a1, s3
    a.vread      v9, a1, s4
    a.vread      v10, a3, s5
    a.vread      v11, a2, s6
    a.vread      v12, a3, s7
    a.vread      v13, a2, s8
    a.vread      v14, a3, s10
    v.log2.approx v15, v12                       // ISA 8.8: <= 2**-22, absolute on [0.5, 2]
    vf.cmp.eq    p1, v10, v6
    vf.sub       v6, v14, v4
    vf.cmp.gt    p3, v5, v2
    v.splat      v2, s11
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v3, v1
    v.cmp.lt     p4, v2, v0
    v.exp2.approx v0, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v2, v3, v1, v5                  // the exact rounding error of x*log2(e)
    v.movi       v3, #1
    v.movi       v5, #0
    vf.mul       v10, v2, v7
    @p4 v.sel        v2, v3, v5
    vf.mul       v3, v15, v7                     // ln(x) = log2(x) * ln(2)
    vf.fms       v5, v6, v4, v8
    vf.fms       v6, v4, v5, v4
    vf.fma       v5, v0, v10, v0                 // 2**t * 2**d
    v.extract    s2, v2, #0
    vf.neg       v2, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v5, v5
    @p4 v.sel        v6, v5, v0
    vf.cmp.o     p4, v2, v2
    @p4 v.sel        v0, v2, v4
    vf.neg       v2, v6
    v.splat      v4, s2
    vf.mul       v5, v13, v0                     // a/y as a refined reciprocal (ISA has no divide)
    v.movi       v0, #0
    v.cmp.ne     p4, v4, v0
    vf.mul       v0, v3, v5
    p.and        p5, p4, p2
    @p1 v.sel        v3, v11, v0
    @p3 v.sel        v0, v9, v3
    vf.mul       v3, v2, v0
    vf.mul       v0, v3, v1
    v.exp2.approx v2, v0                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v4, v3, v1, v0                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v4, v7
    vf.fma       v1, v2, v0, v2                  // 2**t * 2**d
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v2
    @p5 v.st.w       [s1, #0], v0
__rctx_next:
    exit
