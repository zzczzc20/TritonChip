#!/bin/bash
# After the r41s2 base kernel synthesis: tile-1 place-and-route screen in SLR1.
set -u
D=$HOME/r41s2-base-544aed841a95
until grep -q "slot . end" $D/kernel_synth.log 2>/dev/null; do sleep 120; done
[ -f $D/kernel_synth/synth.dcp ] || { echo "$(date -u +%FT%TZ) no kernel synth.dcp" >> $D/chain.log; exit 1; }
echo "$(date -u +%FT%TZ) kernel synth done; tile screen queued" >> $D/chain.log
$HOME/r41s2_tools/vivado_slot.sh --min-gb 20 $D/tile1_screen.log -- vivado -mode batch -nojournal -nolog     -source $D/flow/fpga/screen_r41_tile.tcl -tclargs $D/kernel_synth/synth.dcp 1 1 $D/tile1_screen
echo "$(date -u +%FT%TZ) tile screen exit $? CHAIN-DONE" >> $D/chain.log
