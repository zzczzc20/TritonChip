    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #1024
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s3
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #4096
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #8589934592
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #8016
    s.movz       s3, #0
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s1, s8
    s.sub        s8, s7, s9
    s.xor        s7, s1, s8
    s.sub        s9, s7, s8
    .li       s7, #94300680
    s.movz       s9, #1
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #1
    s.cmp.lt     s17, s4, s6
    s.sub        s6, s3, s17
    s.xor        s3, s4, s6
    s.sub        s17, s3, s6
    s.mul        s3, s17, s7
    s.lshri      s7, s3, #32
    s.sub        s3, s17, s7
    s.lshri      s18, s3, #1
    s.add        s3, s7, s18
    s.lshri      s7, s3, #12
    s.muli       s3, s7, #8016
    s.sub        s18, s17, s3
    s.xor        s3, s6, s8
    s.xor        s6, s7, s3
    s.sub        s7, s6, s3
    s.sub        s3, s9, s7
    s.min.s      s6, s3, s9
    s.cmp.lt     s3, s4, s11
    s.sub        s8, s10, s3
    s.cmp.lt     s3, s6, s13
    s.sub        s10, s12, s3
    s.xor        s3, s4, s8
    s.sub        s11, s3, s8
    s.xor        s3, s6, s10
    s.sub        s12, s3, s10
    s.addi       s3, s14, #0
    s.addi       s10, s15, #0
    s.cmp.eq     s13, s12, s16
    s.mov        s3, s11
    br.nz        s13, sdiv_done_1
    s.movz       s13, #0
    s.movz       s14, #31
    s.mov        s3, s13
    s.addi       s13, s14, #0
sdiv_2:
    s.lshr       s14, s11, s13
    s.shli       s15, s10, #1
    s.andi       s16, s14, #1
    s.movz       s14, #0
    s.or         s17, s15, s16
    s.movz       s15, #1
    s.cmp.geu    s16, s17, s12
    s.shl        s18, s15, s13
    s.sub        s15, s14, s16
    s.subi       s14, s13, #1
    s.and        s16, s12, s15
    s.and        s19, s18, s15
    s.sub        s15, s17, s16
    s.or         s16, s3, s19
    s.mov        s10, s15
    s.mov        s3, s16
    s.mov        s13, s14
    s.movz       s14, #0
    s.cmp.ge     s15, s13, s14
    br.nz        s15, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s11, #0
    s.cmp.lt     s12, s4, s3
    .li       s3, #94300680
    s.sub        s13, s11, s12
    s.movz       s11, #0
    s.xor        s12, s4, s13
    s.movz       s4, #0
    s.sub        s14, s12, s13
    s.movz       s12, #0
    s.mul        s15, s14, s3
    s.cmp.lt     s3, s6, s11
    s.movz       s11, #0
    s.sub        s16, s12, s3
    s.movz       s3, #0
    s.lshri      s12, s15, #32
    s.cmp.lt     s15, s1, s11
    s.xor        s11, s6, s16
    s.xor        s6, s10, s8
    s.sub        s10, s11, s16
    s.sub        s11, s6, s8
    s.sub        s6, s14, s12
    s.add        s8, s7, s11
    s.lshri      s7, s6, #1
    s.movz       s6, #0
    s.add        s11, s12, s7
    s.sub        s7, s6, s15
    s.lshri      s6, s11, #12
    s.movz       s11, #0
    s.muli       s12, s6, #8016
    s.movz       s6, #1
    s.xor        s15, s1, s7
    s.addi       s1, s11, #0
    s.cmp.eq     s11, s10, s6
    s.sub        s6, s14, s12
    s.movz       s12, #0
    s.xor        s14, s6, s13
    s.sub        s6, s15, s7
    s.sub        s6, s14, s13
    s.addi       s7, s12, #0
    s.cmp.lt     s12, s6, s4
    s.sub        s4, s3, s12
    s.xor        s3, s6, s4
    s.sub        s6, s3, s4
    s.mov        s1, s6
    br.nz        s11, sdiv_done_3
    s.movz       s3, #0
    s.movz       s11, #31
    s.mov        s1, s3
    s.addi       s3, s11, #0
sdiv_4:
    s.lshr       s11, s6, s3
    s.shli       s12, s7, #1
    s.andi       s13, s11, #1
    s.movz       s11, #0
    s.or         s14, s12, s13
    s.movz       s12, #1
    s.cmp.geu    s13, s14, s10
    s.shl        s15, s12, s3
    s.sub        s12, s11, s13
    s.subi       s11, s3, #1
    s.and        s13, s10, s12
    s.and        s17, s15, s12
    s.sub        s12, s14, s13
    s.or         s13, s1, s17
    s.mov        s7, s12
    s.mov        s1, s13
    s.mov        s3, s11
    s.movz       s11, #0
    s.cmp.ge     s12, s3, s11
    br.nz        s12, sdiv_4
sdiv_done_3:
    s.xor        s3, s4, s16
    s.movz       s4, #16
    s.xor        s6, s1, s3
    .li       s1, #94300680
    s.sub        s7, s6, s3
    .li       s3, #128256
    s.mul        s6, s7, s4
    s.movz       s10, #0
    v.splat      v0, s8
    v.splat      v1, s10
    v.splat      v2, s7
    s.mul        s7, s6, s1
    v.splat      v3, s10
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s6
    v.iota       v6                              // arange(0, VLEN)
    s.lshri      s1, s7, #32
    v.cmp.ge     p1, v0, v1
    s.sub        s7, s6, s1
    v.cmp.ge     p1, v2, v3
    s.lshri      s11, s7, #1
    v.add        v0, v5, v4
    s.add        s7, s1, s11
    s.movz       s1, #128
    s.lshri      s11, s7, #16
    s.addi       s7, s10, #0
    s.mul        s10, s11, s3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.sub        s3, s6, s10
    v.splat      v0, s3
    v.add        v1, v0, v6
for_5:
    s.cmp.ge     s10, s7, s1
    br.nz        s10, endfor_6
    s.mul        s10, s7, s4
    s.rdspecial  s11, role_id
    s.movz       s12, #1024
    s.rdspecial  s13, arg_base
    s.mul        s14, s11, s12
    s.muli       s11, s10, #2                    // a runtime tile origin, x2
    s.movz       s12, #16
    s.movz       s15, #0
    s.add        s15, s2, s11                    // the tile origin
    v.ld.h       v0, [s15, #0]
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s15, #16
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s16, s3                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s17, s10                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s16, s11
    mb.wait      s11
    s.ld.d       s10, [s13, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s13, #32
    s.movz       s16, #2
    s.add        s17, s10, s14                   // this context's own scratch
    .li       s10, #68719476752
    s.addi       s14, s17, #256                  // 512 bytes of repack scratch
    s.addi       s18, s17, #768                  // TensorMap 1: a repacked tile
    s.addi       s17, s14, #32                   // row 1
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s14, #0], v0
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #64                   // row 2
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #96                   // row 3
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #128                  // row 4
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #160                  // row 5
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #192                  // row 6
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #224                  // row 7
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #256                  // row 8
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #288                  // row 9
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #320                  // row 10
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #352                  // row 11
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #384                  // row 12
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #416                  // row 13
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #448                  // row 14
    v.st.h       [s17, #0], v0
    s.addi       s17, s14, #480                  // row 15
    v.st.h       [s17, #0], v0
    .li       s17, #8589934592
    s.st.d       [s18, #0], s14
    s.movz       s14, #0
    s.st.d       [s18, #8], s12
    s.add        s12, s7, s9
    s.st.d       [s18, #16], s15
    s.movz       s15, #1
    s.st.d       [s18, #48], s13
    s.st.d       [s18, #56], s16
    s.st.d       [s18, #88], s10
    s.st.d       [s18, #104], s17
    fence.release.device
    td.load      d1, [s18]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s10, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s16, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s17, s14                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s16, s10
    mb.wait      s10
    mb.arm       s13, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v48, v56, s13
    mb.wait      s13
    s.mov        s7, s12
    br.nz        s15, for_5
endfor_6:
    s.mul        s1, s8, s4
    s.movz       s2, #0
    s.movz       s3, #0
    s.add        s4, s2, s6                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.muli       s7, s6, #2                      // a runtime tile origin, x2
    s.add        s6, s3, s1                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s4
    .li       s3, #128256
    a.vread      v2, a0, s2
    v.splat      v3, s6
    v.splat      v5, s9
    v.add        v6, v0, v1
    v.splat      v0, s3
    vf.cvt.f32.f16 v1, v2
    v.cmp.lt     p1, v3, v5
    v.cmp.lt     p2, v6, v0
    s.add        s2, s5, s7                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s3, #1
    s.addi       s4, s6, #1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v0, a0, s3
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s4, s6, #2
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s3
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s4, s6, #3
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s3
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    s.movz       s3, #4
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s3
    v.splat      v1, s1
    vf.cvt.f32.f16 v2, v0
    v.add        v0, v1, v4
    s.addi       s1, s6, #4
    s.movz       s3, #5
    v.splat      v0, s1
    s.addi       s1, s6, #5
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.splat      v0, s1
    @p3 v.st.h       [s2, #0], v2
    a.vread      v1, a0, s3
    v.cmp.lt     p1, v0, v5
    vf.cvt.f32.f16 v0, v1
    p.and        p3, p1, p2
    s.movz       s1, #6
    s.addi       s3, s6, #6
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s1
    v.splat      v1, s3
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    s.movz       s1, #7
    s.addi       s3, s6, #7
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s1
    v.splat      v1, s3
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    s.movz       s1, #8
    s.addi       s3, s6, #8
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s1
    v.splat      v1, s3
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    s.movz       s1, #9
    s.addi       s3, s6, #9
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s1
    v.splat      v1, s3
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    s.movz       s1, #10
    s.addi       s3, s6, #10
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s1
    v.splat      v1, s3
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    s.movz       s1, #11
    s.addi       s3, s6, #11
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s1
    v.splat      v1, s3
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    s.movz       s1, #12
    s.addi       s3, s6, #12
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s1
    v.splat      v1, s3
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    s.movz       s1, #13
    s.addi       s3, s6, #13
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s1
    v.splat      v1, s3
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    s.movz       s1, #14
    s.addi       s3, s6, #14
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s1
    v.splat      v1, s3
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    s.movz       s1, #15
    s.addi       s3, s6, #15
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s1
    v.splat      v1, s3
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v2
__rctx_next:
    exit
