    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr3: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #256
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s8, #0], s3
    s.movz       s1, #8
    s.st.d       [s8, #8], s1
    s.movz       s1, #144
    s.st.d       [s8, #16], s1
    s.movz       s1, #576
    s.st.d       [s8, #48], s1
    s.movz       s1, #4
    s.st.d       [s8, #56], s1
    .li       s1, #68719476737
    s.st.d       [s8, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #1
    s.movz       s8, #0
    s.movz       s9, #144
    s.movz       s10, #16
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #256
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v4, v3, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v4, #8
    v.lshr       v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s1
    v.cmp.lt     p1, v4, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s5, v3]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    v.movi       v6, #1
    v.cmp.lt     p1, v0, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v0
    @p1 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p2 v.sel        v6, v0, v2
    v.movi       v0, #255
    v.and        v6, v7, v0
    v.sub        v0, v5, v6
    @p1 v.sel        v5, v0, v6
    s.addi       s1, s8, #0
    v.movi       v0, #0
    v.movi       v6, #0
    v.mov        v6, v0
for_1:
    s.cmp.ge     s5, s1, s9
    br.nz        s5, endfor_2
    s.movz       s5, #0
    s.movz       s8, #0
    s.cmp.lt     s11, s4, s5
    s.movz       s5, #256
    s.sub        s12, s8, s11
    s.movz       s8, #0
    s.movz       s11, #0
    s.cmp.lt     s13, s5, s8
    s.xor        s8, s4, s12
    s.sub        s14, s11, s13
    s.sub        s11, s8, s12
    s.xor        s8, s12, s14
    s.lshri      s12, s11, #8
    v.splat      v0, s1
    s.xor        s13, s12, s8
    v.splat      v7, s1
    s.sub        s15, s13, s8
    v.iota       v8                              // arange(0, VLEN)
    s.movz       s8, #144
    s.movz       s13, #8
    s.muli       s16, s15, #576
    v.add        v9, v0, v1
    v.add        v0, v7, v8
    v.movi       v7, #0
    v.splat      v8, s8
    v.splat      v10, s15
    v.movi       v11, #0
    v.splat      v12, s13
    v.movi       v13, #256
    s.muli       s8, s1, #4
    v.extract    s13, v5, #0
    v.cmp.ge     p1, v0, v7
    v.cmp.lt     p2, v0, v8
    v.cmp.ge     p3, v10, v11
    v.cmp.lt     p4, v10, v12
    v.mul        v0, v9, v13
    v.splat      v7, s13
    s.add        s13, s3, s16
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s15, s13, s8
    p.and        p2, p5, p1
    v.add        v8, v7, v0
    v.movi       v0, #144
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s15, #0]
    v.movi       v10, #4
    v.cmp.lt     p1, v9, v0
    v.movi       v0, #0
    v.movi       v9, #2
    s.muli       s8, s12, #256
    v.sub        v11, v0, v3
    v.cmp.lt     p2, v3, v0
    v.sub        v12, v0, v10
    @p2 v.sel        v13, v11, v3
    s.xor        s12, s5, s14
    v.cmp.lt     p3, v10, v0
    v.lshr       v11, v13, v9
    s.sub        s5, s12, s14
    s.movz       s5, #36864
    v.splat      v9, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v13, v0, v11
    s.sub        s5, s11, s8
    v.extract    s5, v4, #0
    @p2 v.sel        v0, v13, v11
    v.splat      v11, s5
    .li       s5, #1065353216
    v.splat      v13, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v14, v0, v9
    v.rcp.approx v0, v11                         // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0
    v.extract    s5, v14, #0
    s.add        s8, s1, s10
    v.splat      v14, s5
    s.movz       s5, #1
    v.movi       v15, #1
    v.add        v15, v8, v14
    @p3 v.sel        v8, v12, v10
    s.movz       s11, #36864
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v8, [s6, v15]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v10, v8
    vf.fms       v8, v11, v0, v13
    vf.fms       v11, v0, v8, v0
    vf.neg       v8, v11                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v11, v8, v0
    vf.mul       v0, v7, v11                     // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v7, v0, v10
    vf.add       v0, v6, v7
    @p1 v.sel        v7, v0, v6
    v.mov        v9, v7
    v.mov        v6, v9
    s.mov        s1, s8
    br.nz        s5, for_1
endfor_2:
    v.movi       v0, #512
    s.movz       s1, #1
    v.iota       v1                              // arange(0, VLEN)
    v.mul        v4, v3, v0
    v.splat      v0, s1
    .li       s1, #1069066811
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v7, v4, v2
    v.cmp.lt     p1, v1, v0
    .li       s1, #1060205080
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v1, v7, v5
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v5, [s7, v1]               // index is in elements (ISA sec 9.1)
    vf.reduce.add.b v1, v6
    v.movi       v6, #0
    s.movz       s1, #1
    s.shli       s3, s4, #1                      // element offset -> bytes (x2)
    vf.add       v7, v1, v6
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v6, s1
    s.add        s1, s2, s3                      // &in_out_ptr0[...]
    s.movz       s2, #512
    v.cmp.lt     p1, v1, v6
    s.movz       s2, #256
    vf.cvt.bf16.f32 v1, v5
    vf.neg       v5, v1
    vf.mul       v1, v5, v3
    v.exp2.approx v6, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v1                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v8, v0
    vf.fma       v0, v6, v1, v6                  // 2**t * 2**d
    vf.cmp.o     p2, v0, v0
    @p2 v.sel        v1, v0, v6
    vf.add       v0, v1, v2
    v.rcp.approx v1, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v0, v1, v4
    vf.fms       v0, v1, v3, v1
    vf.neg       v3, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v0, v3, v1
    vf.mul       v1, v2, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v0, v7, v1
    vf.cvt.f32.bf16 v1, v0
    @p1 v.st.h       [s1, #0], v1
__rctx_next:
    exit
