    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // x_ptr: device_ptr64 at arg_base+0
    s.movz       s5, #32
    s.movz       s6, #48
    s.movz       s7, #64
    s.movz       s8, #80
    s.movz       s9, #96
    s.movz       s10, #112
    s.shli       s11, s4, #7                     // x128 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #32
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #48
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #64
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #80
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #96
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #112
    s.add        s12, s2, s11
    s.add        s2, s5, s11
    s.add        s5, s6, s11
    v.iota       v14                             // arange(0, VLEN)
    v.add        v15, v0, v1
    v.add        v0, v2, v3
    v.add        v1, v4, v5
    v.add        v2, v6, v7
    v.add        v3, v8, v9
    v.add        v4, v10, v11
    v.add        v5, v12, v13
    s.ld.d       s6, [s1, #8]                    // y_ptr: device_ptr64 at arg_base+8
    s.add        s13, s7, s11
    v.splat      v6, s11
    v.splat      v7, s11
    v.splat      v8, s11
    v.splat      v9, s11
    v.splat      v10, s11
    v.splat      v11, s11
    v.splat      v12, s11
    v.splat      v13, s11
    v.add        v16, v6, v14
    s.ld.d       s7, [s1, #16]                   // s_ptr: device_ptr64 at arg_base+16
    s.add        s1, s8, s11
    s.add        s8, s9, s11
    s.add        s9, s10, s11
    v.movi       v6, #128
    s.shli       s10, s11, #1                    // element offset -> bytes (x2)
    v.movi       v16, #128
    s.shli       s14, s12, #1                    // element offset -> bytes (x2)
    v.movi       v17, #128
    s.shli       s15, s2, #1                     // element offset -> bytes (x2)
    v.movi       v18, #128
    s.shli       s16, s5, #1                     // element offset -> bytes (x2)
    v.movi       v19, #128
    s.shli       s17, s13, #1                    // element offset -> bytes (x2)
    v.movi       v20, #128
    v.movi       v21, #128
    s.add        s18, s3, s10                    // &x_ptr[...]
    s.add        s10, s3, s14                    // &x_ptr[...]
    s.add        s14, s3, s15                    // &x_ptr[...]
    s.add        s15, s3, s16                    // &x_ptr[...]
    s.add        s16, s3, s17                    // &x_ptr[...]
    v.cmp.lt     p1, v14, v6
    v.cmp.lt     p2, v15, v16
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s18, #0]
    s.shli       s17, s1, #1                     // element offset -> bytes (x2)
    v.cmp.lt     p1, v0, v17
    s.add        s18, s3, s17                    // &x_ptr[...]
    v.add        v23, v7, v15
    v.movi       v7, #128
    v.add        v23, v8, v0
    v.add        v8, v9, v1
    v.add        v8, v10, v2
    v.add        v8, v11, v3
    v.add        v8, v12, v4
    v.add        v8, v13, v5
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v8, [s10, #0]
    s.shli       s10, s8, #1                     // element offset -> bytes (x2)
    v.cmp.lt     p2, v1, v18
    s.add        s17, s3, s10                    // &x_ptr[...]
    vf.cvt.bf16.f32 v9, v22
    vf.abs       v10, v9
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v11, [s14, #0]
    s.shli       s10, s9, #1                     // element offset -> bytes (x2)
    v.cmp.lt     p1, v2, v19
    s.add        s14, s3, s10                    // &x_ptr[...]
    vf.cvt.bf16.f32 v12, v8
    vf.reduce.max.b v8, v10
    vf.abs       v10, v12
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s15, #0]
    .li       s3, #1138753536
    v.splat      v22, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p2, v3, v20
    vf.cvt.bf16.f32 v23, v11
    vf.reduce.max.b v11, v10
    vf.max       v10, v8, v11
    vf.abs       v8, v23
    vf.reduce.max.b v11, v8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v8, [s16, #0]
    v.rcp.approx v24, v22                        // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p1, v4, v21
    vf.cvt.bf16.f32 v25, v13
    .li       s3, #1065353216
    v.splat      v13, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v26, v25
    vf.reduce.max.b v27, v26
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v26, [s18, #0]
    v.cmp.lt     p2, v5, v7
    vf.cvt.bf16.f32 v28, v8
    vf.max       v8, v11, v27
    vf.abs       v11, v28
    vf.max       v27, v10, v8
    vf.reduce.max.b v8, v11
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v10, [s17, #0]
    vf.cvt.bf16.f32 v11, v26
    vf.fms       v26, v22, v24, v13
    .li       s3, #730643660
    v.splat      v29, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v30, v11
    vf.fms       v31, v24, v26, v24
    vf.reduce.max.b v26, v30
    vf.neg       v30, v31                        // Newton step: r0*(2 - x*r0)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v31, [s14, #0]
    vf.cvt.bf16.f32 v32, v10
    vf.max       v10, v8, v26
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v8, v30, v24
    vf.abs       v24, v32
    vf.reduce.max.b v26, v24
    vf.cvt.bf16.f32 v24, v31
    vf.abs       v30, v24
    vf.reduce.max.b v31, v30
    vf.max       v30, v26, v31
    vf.max       v26, v10, v30
    vf.max       v10, v27, v26
    vf.mul       v26, v10, v8                    // a/y: faithful quotient
    vf.fms       v27, v26, v22, v10
    vf.fms       v10, v27, v8, v26
    vf.neg       v8, v10                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v10, v8, v26
    vf.max.ieee  v8, v10, v29
    v.rcp.approx v22, v8                         // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v26, v8                         // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v27, v8                         // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v29, v8                         // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v30, v8                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v31, v8, v22, v13
    vf.fms       v33, v8, v26, v13
    vf.fms       v34, v8, v27, v13
    vf.fms       v35, v8, v29, v13
    vf.fms       v36, v22, v31, v22
    vf.fms       v31, v26, v33, v26
    vf.fms       v33, v27, v34, v27
    vf.fms       v34, v29, v35, v29
    vf.neg       v35, v36                        // Newton step: r0*(2 - x*r0)
    vf.neg       v36, v31                        // Newton step: r0*(2 - x*r0)
    vf.neg       v31, v33                        // Newton step: r0*(2 - x*r0)
    vf.neg       v33, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v35, v35
    vf.cmp.o     p2, v36, v36
    @p1 v.sel        v34, v35, v22
    vf.fms       v22, v8, v30, v13
    vf.cmp.o     p1, v31, v31
    @p2 v.sel        v35, v36, v26
    vf.cmp.o     p2, v33, v33
    @p1 v.sel        v26, v31, v27
    vf.fms       v27, v30, v22, v30
    @p2 v.sel        v22, v33, v29
    vf.mul       v29, v9, v34                    // a/y: faithful quotient
    vf.mul       v31, v12, v35                   // a/y: faithful quotient
    vf.mul       v33, v23, v26                   // a/y: faithful quotient
    vf.neg       v36, v27                        // Newton step: r0*(2 - x*r0)
    vf.fms       v27, v29, v8, v9
    vf.fms       v9, v31, v8, v12
    vf.fms       v12, v33, v8, v23
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v23, v36, v30
    vf.mul       v30, v25, v22                   // a/y: faithful quotient
    vf.fms       v36, v27, v34, v29
    vf.mul       v27, v28, v23                   // a/y: faithful quotient
    vf.fms       v34, v9, v35, v31
    vf.fms       v9, v12, v26, v33
    vf.fms       v12, v30, v8, v25
    vf.neg       v25, v36                        // a/y: one correction to the IEEE quotient
    vf.fms       v26, v27, v8, v28
    vf.neg       v28, v34                        // a/y: one correction to the IEEE quotient
    vf.neg       v34, v9                         // a/y: one correction to the IEEE quotient
    vf.fms       v9, v12, v22, v30
    vf.cmp.o     p1, v25, v25
    vf.fms       v12, v26, v23, v27
    vf.cmp.o     p2, v28, v28
    @p1 v.sel        v22, v25, v29
    v.rcp.approx v23, v8                         // ISA 8.8: <= 2**-22 relative
    vf.neg       v25, v9                         // a/y: one correction to the IEEE quotient
    vf.neg       v9, v12                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v34, v34
    @p2 v.sel        v12, v28, v31
    v.rcp.approx v26, v8                         // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p2, v25, v25
    @p1 v.sel        v28, v34, v33
    v.rcp.approx v29, v8                         // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v9, v9
    @p2 v.sel        v31, v25, v30
    @p1 v.sel        v25, v9, v27
    v.movi       v9, #24
    v.movi       v27, #128
    vf.cvt.f32.e4m3 v30, v22
    v.lshr       v33, v22, v9
    v.lshr       v22, v12, v9
    v.lshr       v34, v28, v9
    vf.cvt.f32.e4m3 v35, v12
    vf.cvt.f32.e4m3 v12, v28
    v.and        v28, v33, v27
    v.and        v33, v22, v27
    v.and        v22, v34, v27
    v.or         v34, v30, v28                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.or         v28, v35, v33                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v30, v8, v23, v13
    v.or         v33, v12, v22                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v12, v8, v26, v13
    vf.fms       v22, v23, v30, v23
    vf.cvt.f32.e4m3 v30, v31
    vf.fms       v35, v8, v29, v13
    vf.fms       v13, v26, v12, v26
    vf.neg       v12, v22                        // Newton step: r0*(2 - x*r0)
    v.lshr       v22, v31, v9
    vf.fms       v31, v29, v35, v29
    vf.neg       v35, v13                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v12, v12
    @p1 v.sel        v13, v12, v23
    vf.neg       v12, v31                        // Newton step: r0*(2 - x*r0)
    v.and        v23, v22, v27
    vf.cmp.o     p1, v35, v35
    @p1 v.sel        v22, v35, v26
    vf.mul       v26, v11, v13                   // a/y: faithful quotient
    vf.cmp.o     p1, v12, v12
    @p1 v.sel        v31, v12, v29
    vf.mul       v12, v32, v22                   // a/y: faithful quotient
    vf.cvt.f32.e4m3 v29, v25
    vf.mul       v35, v24, v31                   // a/y: faithful quotient
    vf.fms       v36, v26, v8, v11
    v.lshr       v11, v25, v9
    vf.fms       v25, v12, v8, v32
    v.or         v32, v30, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v23, v35, v8, v24
    vf.fms       v8, v36, v13, v26
    v.and        v13, v11, v27
    vf.fms       v11, v25, v22, v12
    vf.fms       v22, v23, v31, v35
    vf.neg       v23, v8                         // a/y: one correction to the IEEE quotient
    v.or         v8, v29, v13                    // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v13, v11                        // a/y: one correction to the IEEE quotient
    vf.neg       v11, v22                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v23, v23
    @p1 v.sel        v22, v23, v26
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v23, v13, v12
    vf.cmp.o     p1, v11, v11
    @p1 v.sel        v12, v11, v35
    v.lshr       v11, v22, v9
    v.lshr       v13, v23, v9
    v.lshr       v24, v12, v9
    vf.cvt.f32.e4m3 v9, v22
    vf.cvt.f32.e4m3 v22, v23
    vf.cvt.f32.e4m3 v23, v12
    v.and        v12, v11, v27
    v.and        v11, v13, v27
    v.and        v13, v24, v27
    s.shli       s3, s11, #0                     // element offset -> bytes (x1)
    s.shli       s10, s12, #0                    // element offset -> bytes (x1)
    s.shli       s11, s2, #0                     // element offset -> bytes (x1)
    s.shli       s2, s5, #0                      // element offset -> bytes (x1)
    s.shli       s5, s13, #0                     // element offset -> bytes (x1)
    s.shli       s12, s1, #0                     // element offset -> bytes (x1)
    s.shli       s1, s8, #0                      // element offset -> bytes (x1)
    s.shli       s8, s9, #0                      // element offset -> bytes (x1)
    s.shli       s9, s4, #2                      // element offset -> bytes (x4)
    v.iota       v24                             // arange(0, VLEN)
    v.or         v25, v9, v12                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.or         v9, v22, v11                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.or         v11, v23, v13                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.add        s4, s6, s3                      // &y_ptr[...]
    s.add        s3, s6, s10                     // &y_ptr[...]
    s.add        s10, s6, s11                    // &y_ptr[...]
    s.add        s11, s6, s2                     // &y_ptr[...]
    s.add        s2, s6, s5                      // &y_ptr[...]
    s.add        s5, s6, s12                     // &y_ptr[...]
    s.add        s12, s6, s1                     // &y_ptr[...]
    s.add        s1, s6, s8                      // &y_ptr[...]
    s.add        s6, s7, s9                      // &s_ptr[...]
    v.cmp.lt     p1, v14, v6
    v.cmp.lt     p2, v15, v16
    @p1 v.st.b       [s4, #0], v34
    v.cmp.lt     p1, v0, v17
    @p2 v.st.b       [s3, #0], v28
    v.cmp.lt     p2, v1, v18
    @p1 v.st.b       [s10, #0], v33
    v.cmp.lt     p1, v2, v19
    @p2 v.st.b       [s11, #0], v32
    v.cmp.lt     p2, v3, v20
    @p1 v.st.b       [s2, #0], v8
    v.cmp.lt     p1, v4, v21
    @p2 v.st.b       [s5, #0], v25
    v.cmp.lt     p2, v5, v7
    @p1 v.st.b       [s12, #0], v9
    v.cmpi.lt    p1, v24, #1
    @p2 v.st.b       [s1, #0], v11
    @p1 v.st.w       [s6, #0], v10
__rctx_next:
    exit
