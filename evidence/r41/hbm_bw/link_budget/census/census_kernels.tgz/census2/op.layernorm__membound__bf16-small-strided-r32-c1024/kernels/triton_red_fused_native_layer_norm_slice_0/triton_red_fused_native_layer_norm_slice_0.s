    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.movi       v0, #0
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #1024
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    s.ld.d       s8, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s9, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s10, [s1, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    s.movz       s1, #2048
    v.splat      v3, s7
    s.mul        s11, s4, s1
    v.movi       v4, #2
    v.add        v5, v3, v2
    v.movi       v3, #1024
    v.movi       v6, #0
    v.mul        v7, v5, v4
    v.splat      v4, s11
    v.cmp.lt     p1, v5, v3
    s.add        s1, s7, s6
    v.add        v3, v7, v4
    s.movz       s11, #1
    s.movz       s12, #2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v4, [s3, v3]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v3, v4
    vf.add       v4, v1, v3
    @p1 v.sel        v3, v4, v1
    v.mov        v6, v3
    v.mov        v1, v6
    s.mov        s7, s1
    br.nz        s11, for_1
endfor_2:
    .li       s1, #1149239296
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.add.b v5, v1
    v.rcp.approx v1, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0
    v.movi       v7, #0
    s.addi       s1, s2, #0
    vf.add       v8, v5, v6
    v.mov        v7, v0
    vf.fms       v0, v3, v1, v4
    vf.fms       v5, v1, v0, v1
    vf.neg       v0, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v5, v0, v1
    vf.mul       v0, v8, v5                      // a/y as a refined reciprocal (ISA has no divide)
for_3:
    s.cmp.ge     s7, s1, s5
    br.nz        s7, endfor_4
    s.movz       s7, #2048
    v.splat      v1, s1
    s.mul        s11, s4, s7
    v.movi       v5, #2
    v.add        v8, v1, v2
    v.movi       v1, #1024
    v.extract    s7, v0, #0
    v.mul        v9, v8, v5
    v.splat      v5, s11
    v.cmp.lt     p1, v8, v1
    v.splat      v1, s7
    v.add        v8, v9, v5
    v.movi       v5, #0
    s.add        s7, s1, s6
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s3, v8]               // index is in elements (ISA sec 9.1)
    s.movz       s11, #1
    s.movz       s12, #2
    vf.cvt.bf16.f32 v8, v9
    vf.sub       v9, v8, v1
    vf.mul       v1, v9, v9
    vf.add       v8, v7, v1
    @p1 v.sel        v1, v8, v7
    v.mov        v5, v1
    v.mov        v7, v5
    s.mov        s1, s7
    br.nz        s11, for_3
endfor_4:
    vf.reduce.add.b v1, v7
    s.addi       s1, s2, #0
    vf.add       v5, v1, v6
for_5:
    s.cmp.ge     s2, s1, s5
    br.nz        s2, endfor_6
    v.rcp.approx v1, v3                          // ISA 8.8: <= 2**-22 relative
    .li       s2, #925353388
    v.splat      v6, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.movz       s2, #2048
    v.splat      v7, s1
    s.mul        s7, s4, s2
    v.movi       v8, #2
    v.add        v9, v7, v2
    v.movi       v7, #1024
    .li       s2, #1077936128
    v.splat      v10, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v11, v9, v8
    v.splat      v8, s7
    v.cmp.lt     p1, v9, v7
    .li       s2, #3204448256
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v12, v11, v8
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    v.extract    s7, v0, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v8, [s3, v12]              // index is in elements (ISA sec 9.1)
    s.add        s11, s8, s2                     // &in_ptr1[...]
    s.add        s12, s9, s2                     // &in_ptr2[...]
    v.splat      v11, s7
    s.mul        s2, s4, s5
    s.movz       s7, #2
    s.add        s7, s1, s6
    s.movz       s13, #1
    s.add        s14, s1, s2
    v.splat      v12, s2
    s.shli       s2, s14, #1                     // element offset -> bytes (x2)
    vf.fms       v13, v3, v1, v4
    s.add        s14, s10, s2                    // &out_ptr1[...]
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s11, #0]
    vf.cvt.bf16.f32 v15, v8
    v.add        v8, v9, v12
    vf.fms       v8, v1, v13, v1
    vf.sub       v9, v15, v11
    vf.neg       v11, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v11, v11
    @p2 v.sel        v8, v11, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s12, #0]
    vf.cvt.bf16.f32 v11, v14
    vf.mul       v12, v5, v8                     // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v8, v12, v6
    v.rsqrt.approx v6, v8                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v12, v1
    vf.mul       v1, v6, v6
    vf.mul       v13, v6, v7
    vf.fms       v7, v8, v1, v10
    vf.mul       v1, v13, v7                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v7, v1, v6
    v.extract    s2, v7, #0
    v.splat      v1, s2
    vf.mul       v6, v9, v1
    vf.mul       v1, v6, v11
    vf.add       v6, v1, v12
    vf.cvt.f32.bf16 v1, v6
    @p1 v.st.h       [s14, #0], v1
    s.mov        s1, s7
    br.nz        s13, for_5
endfor_6:
__rctx_next:
    exit
