source ~/tc_env/env.sh
cd /tmp/r40_balanced_source
python3 run_balanced.py > /tmp/r40_balanced.log 2>&1
echo $? > /tmp/r40_balanced.exit
