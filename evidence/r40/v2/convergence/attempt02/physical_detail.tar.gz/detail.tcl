# Read-only followup; reuse one opened DCP across the two frozen diagnostic scripts.
# No synthesis, placement, routing, timing exceptions or board commands.
if {[llength $argv]!=3} {error "expected CHECKPOINT FRESH_OUTPUT FROZEN_TOOLS_ROOT"}
set input_dcp [file normalize [lindex $argv 0]]
set output_root [file normalize [lindex $argv 1]]
set tool_root [file normalize [lindex $argv 2]]
if {![file isfile $input_dcp] || [file exists $output_root]} {error "checkpoint and fresh output required"}
file mkdir $output_root
set_param general.maxThreads 2
open_checkpoint $input_dcp
proc r40_readonly_report {script argv} {
    set f [open $script r]
    set body [read $f]
    close $f
    # Only remove redundant open and convert process exit to procedure return.
    # The exact input and transformed tools are retained for reproduction.
    set body [string map [list \
        "\nopen_checkpoint \$checkpoint\n" "\n# Same immutable checkpoint already open.\n" \
        "\n    exit\n" "\n    return\n" \
        "\nexit\n" "\nreturn\n"] $body]
    # Do not execute a source copy from a different hardware revision.
    eval $body
}
r40_readonly_report $tool_root/diagnose_r40_checkpoint.tcl [list $input_dcp $output_root/cuts range-slice-cuts]
r40_readonly_report $tool_root/diagnose_r40_boundaries.tcl [list $input_dcp $output_root/boundaries]
set f [open $output_root/conflicted_hbm_endpoints.tsv {WRONLY CREAT EXCL}]
puts $f "net\tpin\tdirection\tcell\tprimitive\tloc\tactual_slr"
foreach bit {91 97} {
    set name [format {level0_i/ulp/hmss_0/inst/path_18/slice0_18/inst/r15.r_multi/triple_slr.resp.slr_slave/Q[%d]} $bit]
    set nets [get_nets -hierarchical -quiet -filter [format {NAME == "%s"} $name]]
    if {![llength $nets]} {error "expected retained conflicted net: $name"}
    set segments [get_nets -segments -quiet -of_objects $nets]
    foreach pin [get_pins -leaf -quiet -of_objects $segments] {
        set cell [get_cells -quiet -of_objects $pin]
        puts $f "$name\t[get_property NAME $pin]\t[get_property DIRECTION $pin]\t[get_property NAME $cell]\t[get_property REF_NAME $cell]\t[get_property LOC $cell]\t[get_property NAME [get_slrs -quiet -of_objects $cell]]"
    }
    set source_pins [get_pins -leaf -quiet -of_objects $segments -filter {DIRECTION == OUT}]
    report_timing -from $source_pins -max_paths 5 -path_type full_clock_expanded -file $output_root/conflicted_hbm_bit${bit}_setup.rpt
    report_timing -delay_type min -from $source_pins -max_paths 5 -path_type full_clock_expanded -file $output_root/conflicted_hbm_bit${bit}_hold.rpt
}
close $f
puts R40_ATTEMPT02_PHYSICAL_DETAIL_DONE_READONLY
exit
