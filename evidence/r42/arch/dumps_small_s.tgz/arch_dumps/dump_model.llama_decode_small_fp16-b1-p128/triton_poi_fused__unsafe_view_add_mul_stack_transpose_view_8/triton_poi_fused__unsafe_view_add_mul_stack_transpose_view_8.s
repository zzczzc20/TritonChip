    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s6, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s7, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s8, [s1, #32]                   // out_ptr0: device_ptr64 at arg_base+32
    s.ld.d       s9, [s1, #40]                   // out_ptr1: device_ptr64 at arg_base+40
__rctx_program:
    s.shli       s1, s2, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #31
    v.add        v4, v1, v0
    v.movi       v0, #64
    s.shli       s10, s1, #1                     // element offset -> bytes (x2)
    v.sub        v1, v2, v4
    v.cmp.lt     p1, v4, v2
    s.add        s1, s3, s10                     // &in_ptr0[...]
    @p1 v.sel        v5, v1, v4
    s.add        s11, s6, s10                    // &in_ptr2[...]
    v.cmp.lt     p2, v4, v0
    v.and        v0, v5, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s1, #0]
    v.movi       v3, #0
    v.sub        v5, v2, v0
    v.movi       v6, #5
    v.sub        v7, v3, v4
    @p1 v.sel        v8, v5, v0
    v.cmp.lt     p1, v4, v3
    @p1 v.sel        v0, v7, v4
    v.movi       v4, #4128
    v.movi       v5, #32
    v.lshr       v7, v0, v6
    s.add        s1, s9, s10                     // &out_ptr1[...]
    v.sub        v0, v2, v5
    v.sub        v6, v3, v7
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v9, [s5, v8]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v10, v1
    @p1 v.sel        v1, v6, v7
    v.sub        v6, v3, v5
    v.cmp.lt     p1, v5, v2
    v.mul        v2, v1, v4
    v.cmp.lt     p3, v5, v3
    @p1 v.sel        v1, v0, v5
    v.add        v0, v8, v2
    @p3 v.sel        v1, v6, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s11, #0]
    vf.cvt.f16.f32 v2, v9
    vf.mul       v3, v10, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v2, [s7, v8]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v4, v1
    vf.cvt.f16.f32 v1, v2
    vf.mul       v2, v4, v1
    vf.add       v1, v3, v2
    vf.cvt.f32.f16 v2, v1
    @p2 v.st.scatter.h [s8, v0], v2
    @p2 v.st.h       [s1, #0], v2
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s10, s1, s4
    s.mov        s2, s1
    br.nz        s10, __rctx_program
    exit
