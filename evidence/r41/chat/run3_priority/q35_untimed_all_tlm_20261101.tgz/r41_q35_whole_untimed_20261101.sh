#!/usr/bin/env bash
set -eu
mode="$1"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= HF_HOME="$HOME/flux-hf" HF_HUB_OFFLINE=0 QWEN_FP8_VIEW_DIR="$HOME/r41-p3/snapview"
export PYTHONPATH="$HOME/r41_q35_multiturn_diag_20261031:$HOME/r41_q35_multiturn_diag_20261031/python:$HOME/r41_q35_multiturn_diag_20261031/compiler/python:$HOME/r41_q35_multiturn_diag_20261031/tools/asm:$HOME/r41_q35_multiturn_diag_20261031/tools/models"
export TNCA_BACKEND=systemc-tlm-grid TNCA_PROFILE=core-vrf-sync-v5-x8-g2c4-dp TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_q35_untimed_cfg_20261101.cfg" TNCA_TLM_MEMORY_BYTES=0x200000000 TNCA_DRAM_PATH=fast TNCA_TLM_UNTIMED_COLD=1 TNCA_DEADLINE=40000000000 TNCA_HOST_TIMEOUT=3600
export TNCA_TLM_OUT="$HOME/r41_q35_whole_untimed_${mode}_20261101_tlm" TRITON_CACHE_DIR="$HOME/r41_q35_whole_untimed_${mode}_20261101_triton" TORCHINDUCTOR_CACHE_DIR="$HOME/r41_q35_whole_untimed_${mode}_20261101_inductor"
cd "$HOME/r41_q35_multiturn_diag_20261031"
if [ "$mode" = base ]; then
  exec "$HOME/flux-venv/bin/python" -u "$PWD/tools/models/diagnose_q35_multiturn_logits.py" --mode tlm --old-chat "$PWD/tools/models/chat.py" --tree "$PWD" --tlm-path whole --cpu-reference "$HOME/r41_q35_multiturn_cpu_diag/logits.safetensors" --out "$HOME/r41_q35_whole_untimed_${mode}_20261101_diag"
fi
export TNCA_MAX_BLOCK=32
if [ "$mode" = ieee ]; then export TNCA_IEEE_DIV=1; fi
exec "$HOME/flux-venv/bin/python" -u "$HOME/r41_precision_cast_wrapper_v2_20261101.py" "$PWD/tools/models/diagnose_q35_multiturn_logits.py" --mode tlm --old-chat "$PWD/tools/models/chat.py" --tree "$PWD" --tlm-path whole --cpu-reference "$HOME/r41_q35_multiturn_cpu_diag/logits.safetensors" --out "$HOME/r41_q35_whole_untimed_${mode}_20261101_diag"
