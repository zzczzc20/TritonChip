    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #64
    s.movz       s10, #4
    .li       s11, #68719476752
    .li       s12, #2207613190144
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.movz       s6, #1
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // out_ptr1: device_ptr64 at arg_base+16
    s.sub        s2, s6, s4
    s.movz       s17, #0
    s.min.s      s17, s2, s6
    s.movz       s2, #0
    s.st.d       [s5, #0], s1
    s.movz       s6, #0
    s.st.d       [s5, #8], s7
    s.movz       s6, #0
    s.cmp.lt     s7, s17, s2
    s.cmp.lt     s2, s4, s6
    s.st.d       [s5, #16], s8
    s.movz       s6, #0
    s.sub        s8, s6, s7
    s.movz       s6, #0
    s.st.d       [s5, #48], s9
    s.sub        s7, s6, s2
    s.xor        s2, s17, s8
    s.st.d       [s5, #56], s10
    s.movz       s6, #0
    s.movz       s9, #1
    s.st.d       [s5, #88], s11
    s.xor        s10, s4, s7
    s.sub        s11, s2, s8
    s.st.d       [s5, #104], s12
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.ld.d       s2, [s13, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    .li       s5, #2147483647
    s.movz       s8, #64
    s.add        s12, s2, s14                    // this context's own scratch
    s.movz       s2, #4
    s.addi       s13, s12, #256                  // TensorMap 1: a 2-D tt.load (built once, at entry)
    .li       s12, #68719476752
    s.sub        s14, s10, s7
    s.addi       s10, s6, #0
    s.cmp.eq     s6, s11, s9
    s.st.d       [s13, #0], s3
    .li       s3, #2207613190144
    s.st.d       [s13, #8], s15
    s.movz       s9, #0
    s.st.d       [s13, #16], s5
    s.addi       s5, s9, #0
    s.st.d       [s13, #48], s8
    s.st.d       [s13, #56], s2
    s.st.d       [s13, #88], s12
    s.st.d       [s13, #104], s3
    fence.release.device
    td.load      d1, [s13]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s10, s14
    br.nz        s6, sdiv_done_1
    s.movz       s2, #0
    s.movz       s3, #31
    s.mov        s10, s2
    s.addi       s2, s3, #0
sdiv_2:
    s.lshr       s3, s14, s2
    s.shli       s6, s5, #1
    s.andi       s8, s3, #1
    s.movz       s3, #0
    s.or         s9, s6, s8
    s.movz       s6, #1
    s.cmp.geu    s8, s9, s11
    s.shl        s12, s6, s2
    s.sub        s6, s3, s8
    s.subi       s3, s2, #1
    s.and        s8, s11, s6
    s.and        s13, s12, s6
    s.sub        s6, s9, s8
    s.or         s8, s10, s13
    s.mov        s5, s6
    s.mov        s10, s8
    s.mov        s2, s3
    s.movz       s3, #0
    s.cmp.ge     s6, s2, s3
    br.nz        s6, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s3, #0
    s.movz       s6, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s17, s2
    s.movz       s2, #0
    s.cmp.lt     s10, s3, s6
    s.sub        s6, s8, s9
    s.sub        s8, s2, s10
    s.xor        s2, s17, s6
    s.xor        s9, s5, s7
    s.xor        s5, s3, s8
    s.sub        s10, s2, s6
    s.movz       s2, #0
    s.movz       s11, #1
    s.sub        s12, s9, s7
    s.sub        s7, s5, s8
    s.movz       s5, #0
    s.addi       s9, s2, #0
    s.cmp.eq     s2, s10, s11
    s.add        s11, s4, s12
    s.addi       s4, s5, #0
    s.mov        s9, s7
    br.nz        s2, sdiv_done_3
    s.movz       s2, #0
    s.movz       s5, #31
    s.mov        s9, s2
    s.addi       s2, s5, #0
sdiv_4:
    s.lshr       s5, s7, s2
    s.shli       s12, s4, #1
    s.andi       s13, s5, #1
    s.movz       s5, #0
    s.or         s14, s12, s13
    s.movz       s12, #1
    s.cmp.geu    s13, s14, s10
    s.shl        s15, s12, s2
    s.sub        s12, s5, s13
    s.subi       s5, s2, #1
    s.and        s13, s10, s12
    s.and        s17, s15, s12
    s.sub        s12, s14, s13
    s.or         s13, s9, s17
    s.mov        s4, s12
    s.mov        s9, s13
    s.mov        s2, s5
    s.movz       s5, #0
    s.cmp.ge     s12, s2, s5
    br.nz        s12, sdiv_4
sdiv_done_3:
    s.rdspecial  s2, pid.z
    s.rdspecial  s4, npid.y
    s.xor        s5, s8, s6
    s.mul        s6, s2, s4
    s.xor        s2, s9, s5
    s.rdspecial  s4, pid.y
    s.sub        s7, s2, s5
    s.movz       s2, #16
    s.add        s5, s4, s6
    s.movz       s4, #127
    s.mul        s6, s11, s2
    s.mul        s8, s7, s2
    s.min.s      s9, s5, s4
    s.movz       s4, #256
    w.def        w0, #48, #16                    // v48..v63
    s.mul        s10, s9, s4
    s.andi       s9, s6, #15
    s.andi       s12, s8, #15
    mb.arm       s13, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s14, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s17, s9                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s10                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w0, d0, s17, s13
    mb.wait      s13
    s.add        s15, s12, s10
    w.def        w1, #32, #16                    // v32..v47
    mb.arm       s10, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.movi       v0, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s17, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s15                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w1, d1, s17, s10
    mb.wait      s10
    v.extract    s14, v48, #0
    v.splat      v1, s14
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s14, #0
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s11
    v.extract    s11, v48, #1
    v.splat      v3, s3
    v.splat      v4, s11
    v.splat      v5, s7
    v.splat      v6, s3
    v.iota       v7                              // arange(0, VLEN)
    v.cmp.ge     p1, v1, v3
    vf.fma       v1, v4, v33, v2
    v.extract    s3, v48, #2
    v.splat      v2, s6
    v.splat      v3, s8
    v.splat      v4, s9
    v.cmp.ge     p1, v5, v6
    v.splat      v5, s3
    v.extract    s3, v48, #3
    vf.fma       v6, v5, v34, v1
    v.splat      v1, s3
    v.iota       v5                              // arange(0, VLEN)
    v.add        v8, v2, v7
    vf.fma       v2, v1, v35, v6
    v.extract    s3, v48, #4
    v.splat      v1, s12
    v.iota       v6                              // arange(0, VLEN)
    v.add        v8, v3, v7
    v.splat      v3, s3
    v.extract    s3, v48, #5
    vf.fma       v7, v3, v36, v2
    v.add        v2, v4, v5
    v.splat      v2, s3
    v.extract    s3, v48, #6
    vf.fma       v3, v2, v37, v7
    v.add        v2, v1, v6
    v.splat      v1, s3
    v.extract    s3, v48, #7
    vf.fma       v2, v1, v38, v3
    v.splat      v1, s3
    v.extract    s3, v48, #8
    v.splat      v3, s3
    vf.fma       v4, v1, v39, v2
    v.extract    s3, v48, #9
    v.splat      v1, s3
    v.extract    s3, v48, #10
    vf.fma       v2, v3, v40, v4
    v.splat      v3, s3
    v.extract    s3, v48, #11
    v.splat      v4, s3
    vf.fma       v5, v1, v41, v2
    v.extract    s3, v48, #12
    v.splat      v1, s3
    v.extract    s3, v48, #13
    vf.fma       v2, v3, v42, v5
    v.splat      v3, s3
    v.extract    s3, v48, #14
    v.splat      v5, s3
    vf.fma       v6, v4, v43, v2
    v.extract    s3, v48, #15
    v.splat      v2, s3
    s.movz       s3, #1
    vf.fma       v4, v1, v44, v6
    vf.fma       v1, v3, v45, v4
    vf.fma       v3, v5, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s14, v1
    v.extract    s7, v49, #0
    v.splat      v1, s7
    v.extract    s7, v49, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v49, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v49, #3
    v.splat      v1, s7
    v.extract    s7, v49, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v49, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v49, #6
    v.splat      v1, s7
    v.extract    s7, v49, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v49, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v49, #9
    v.splat      v2, s7
    v.extract    s7, v49, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v49, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v49, #12
    v.splat      v3, s7
    v.extract    s7, v49, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v49, #14
    v.extract    s9, v49, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s9
    s.movz       s7, #2
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s3, v50, #0
    v.splat      v1, s3
    v.extract    s3, v50, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s3
    v.extract    s3, v50, #2
    v.splat      v3, s3
    vf.fma       v4, v1, v33, v2
    v.extract    s3, v50, #3
    v.splat      v1, s3
    v.extract    s3, v50, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s3
    v.extract    s3, v50, #5
    v.splat      v4, s3
    vf.fma       v5, v1, v35, v2
    v.extract    s3, v50, #6
    v.splat      v1, s3
    v.extract    s3, v50, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s3
    v.extract    s3, v50, #8
    v.splat      v5, s3
    vf.fma       v6, v4, v37, v2
    v.extract    s3, v50, #9
    v.splat      v2, s3
    v.extract    s3, v50, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s3
    v.extract    s3, v50, #11
    v.splat      v6, s3
    vf.fma       v7, v3, v39, v4
    v.extract    s3, v50, #12
    v.splat      v3, s3
    v.extract    s3, v50, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s3
    v.extract    s3, v50, #14
    v.extract    s9, v50, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s3
    v.splat      v4, s9
    s.movz       s3, #3
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v51, #0
    v.splat      v1, s7
    v.extract    s7, v51, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v51, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v51, #3
    v.splat      v1, s7
    v.extract    s7, v51, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v51, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v51, #6
    v.splat      v1, s7
    v.extract    s7, v51, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v51, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v51, #9
    v.splat      v2, s7
    v.extract    s7, v51, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v51, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v51, #12
    v.splat      v3, s7
    v.extract    s7, v51, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v51, #14
    v.extract    s9, v51, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s9
    s.movz       s7, #4
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s3, v52, #0
    v.splat      v1, s3
    v.extract    s3, v52, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s3
    v.extract    s3, v52, #2
    v.splat      v3, s3
    vf.fma       v4, v1, v33, v2
    v.extract    s3, v52, #3
    v.splat      v1, s3
    v.extract    s3, v52, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s3
    v.extract    s3, v52, #5
    v.splat      v4, s3
    vf.fma       v5, v1, v35, v2
    v.extract    s3, v52, #6
    v.splat      v1, s3
    v.extract    s3, v52, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s3
    v.extract    s3, v52, #8
    v.splat      v5, s3
    vf.fma       v6, v4, v37, v2
    v.extract    s3, v52, #9
    v.splat      v2, s3
    v.extract    s3, v52, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s3
    v.extract    s3, v52, #11
    v.splat      v6, s3
    vf.fma       v7, v3, v39, v4
    v.extract    s3, v52, #12
    v.splat      v3, s3
    v.extract    s3, v52, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s3
    v.extract    s3, v52, #14
    v.extract    s9, v52, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s3
    v.splat      v4, s9
    s.movz       s3, #5
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v53, #0
    v.splat      v1, s7
    v.extract    s7, v53, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v53, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v53, #3
    v.splat      v1, s7
    v.extract    s7, v53, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v53, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v53, #6
    v.splat      v1, s7
    v.extract    s7, v53, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v53, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v53, #9
    v.splat      v2, s7
    v.extract    s7, v53, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v53, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v53, #12
    v.splat      v3, s7
    v.extract    s7, v53, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v53, #14
    v.extract    s9, v53, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s9
    s.movz       s7, #6
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s3, v54, #0
    v.splat      v1, s3
    v.extract    s3, v54, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s3
    v.extract    s3, v54, #2
    v.splat      v3, s3
    vf.fma       v4, v1, v33, v2
    v.extract    s3, v54, #3
    v.splat      v1, s3
    v.extract    s3, v54, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s3
    v.extract    s3, v54, #5
    v.splat      v4, s3
    vf.fma       v5, v1, v35, v2
    v.extract    s3, v54, #6
    v.splat      v1, s3
    v.extract    s3, v54, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s3
    v.extract    s3, v54, #8
    v.splat      v5, s3
    vf.fma       v6, v4, v37, v2
    v.extract    s3, v54, #9
    v.splat      v2, s3
    v.extract    s3, v54, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s3
    v.extract    s3, v54, #11
    v.splat      v6, s3
    vf.fma       v7, v3, v39, v4
    v.extract    s3, v54, #12
    v.splat      v3, s3
    v.extract    s3, v54, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s3
    v.extract    s3, v54, #14
    v.extract    s9, v54, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s3
    v.splat      v4, s9
    s.movz       s3, #7
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v55, #0
    v.splat      v1, s7
    v.extract    s7, v55, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v55, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v55, #3
    v.splat      v1, s7
    v.extract    s7, v55, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v55, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v55, #6
    v.splat      v1, s7
    v.extract    s7, v55, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v55, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v55, #9
    v.splat      v2, s7
    v.extract    s7, v55, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v55, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v55, #12
    v.splat      v3, s7
    v.extract    s7, v55, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v55, #14
    v.extract    s9, v55, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s9
    s.movz       s7, #8
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s3, v56, #0
    v.splat      v1, s3
    v.extract    s3, v56, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s3
    v.extract    s3, v56, #2
    v.splat      v3, s3
    vf.fma       v4, v1, v33, v2
    v.extract    s3, v56, #3
    v.splat      v1, s3
    v.extract    s3, v56, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s3
    v.extract    s3, v56, #5
    v.splat      v4, s3
    vf.fma       v5, v1, v35, v2
    v.extract    s3, v56, #6
    v.splat      v1, s3
    v.extract    s3, v56, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s3
    v.extract    s3, v56, #8
    v.splat      v5, s3
    vf.fma       v6, v4, v37, v2
    v.extract    s3, v56, #9
    v.splat      v2, s3
    v.extract    s3, v56, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s3
    v.extract    s3, v56, #11
    v.splat      v6, s3
    vf.fma       v7, v3, v39, v4
    v.extract    s3, v56, #12
    v.splat      v3, s3
    v.extract    s3, v56, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s3
    v.extract    s3, v56, #14
    v.extract    s9, v56, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s3
    v.splat      v4, s9
    s.movz       s3, #9
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v57, #0
    v.splat      v1, s7
    v.extract    s7, v57, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v57, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v57, #3
    v.splat      v1, s7
    v.extract    s7, v57, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v57, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v57, #6
    v.splat      v1, s7
    v.extract    s7, v57, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v57, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v57, #9
    v.splat      v2, s7
    v.extract    s7, v57, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v57, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v57, #12
    v.splat      v3, s7
    v.extract    s7, v57, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v57, #14
    v.extract    s9, v57, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s9
    s.movz       s7, #10
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s3, v58, #0
    v.splat      v1, s3
    v.extract    s3, v58, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s3
    v.extract    s3, v58, #2
    v.splat      v3, s3
    vf.fma       v4, v1, v33, v2
    v.extract    s3, v58, #3
    v.splat      v1, s3
    v.extract    s3, v58, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s3
    v.extract    s3, v58, #5
    v.splat      v4, s3
    vf.fma       v5, v1, v35, v2
    v.extract    s3, v58, #6
    v.splat      v1, s3
    v.extract    s3, v58, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s3
    v.extract    s3, v58, #8
    v.splat      v5, s3
    vf.fma       v6, v4, v37, v2
    v.extract    s3, v58, #9
    v.splat      v2, s3
    v.extract    s3, v58, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s3
    v.extract    s3, v58, #11
    v.splat      v6, s3
    vf.fma       v7, v3, v39, v4
    v.extract    s3, v58, #12
    v.splat      v3, s3
    v.extract    s3, v58, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s3
    v.extract    s3, v58, #14
    v.extract    s9, v58, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s3
    v.splat      v4, s9
    s.movz       s3, #11
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v59, #0
    v.splat      v1, s7
    v.extract    s7, v59, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v59, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v59, #3
    v.splat      v1, s7
    v.extract    s7, v59, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v59, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v59, #6
    v.splat      v1, s7
    v.extract    s7, v59, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v59, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v59, #9
    v.splat      v2, s7
    v.extract    s7, v59, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v59, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v59, #12
    v.splat      v3, s7
    v.extract    s7, v59, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v59, #14
    v.extract    s9, v59, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s9
    s.movz       s7, #12
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s3, v60, #0
    v.splat      v1, s3
    v.extract    s3, v60, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s3
    v.extract    s3, v60, #2
    v.splat      v3, s3
    vf.fma       v4, v1, v33, v2
    v.extract    s3, v60, #3
    v.splat      v1, s3
    v.extract    s3, v60, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s3
    v.extract    s3, v60, #5
    v.splat      v4, s3
    vf.fma       v5, v1, v35, v2
    v.extract    s3, v60, #6
    v.splat      v1, s3
    v.extract    s3, v60, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s3
    v.extract    s3, v60, #8
    v.splat      v5, s3
    vf.fma       v6, v4, v37, v2
    v.extract    s3, v60, #9
    v.splat      v2, s3
    v.extract    s3, v60, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s3
    v.extract    s3, v60, #11
    v.splat      v6, s3
    vf.fma       v7, v3, v39, v4
    v.extract    s3, v60, #12
    v.splat      v3, s3
    v.extract    s3, v60, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s3
    v.extract    s3, v60, #14
    v.extract    s9, v60, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s3
    v.splat      v4, s9
    s.movz       s3, #13
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v61, #0
    v.splat      v1, s7
    v.extract    s7, v61, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v61, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v61, #3
    v.splat      v1, s7
    v.extract    s7, v61, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v61, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v61, #6
    v.splat      v1, s7
    v.extract    s7, v61, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v61, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v61, #9
    v.splat      v2, s7
    v.extract    s7, v61, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v61, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v61, #12
    v.splat      v3, s7
    v.extract    s7, v61, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v61, #14
    v.extract    s9, v61, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s9
    s.movz       s7, #14
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s3, v1
    v.extract    s3, v62, #0
    v.splat      v1, s3
    v.extract    s3, v62, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s3
    v.extract    s3, v62, #2
    v.splat      v3, s3
    vf.fma       v4, v1, v33, v2
    v.extract    s3, v62, #3
    v.splat      v1, s3
    v.extract    s3, v62, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s3
    v.extract    s3, v62, #5
    v.splat      v4, s3
    vf.fma       v5, v1, v35, v2
    v.extract    s3, v62, #6
    v.splat      v1, s3
    v.extract    s3, v62, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s3
    v.extract    s3, v62, #8
    v.splat      v5, s3
    vf.fma       v6, v4, v37, v2
    v.extract    s3, v62, #9
    v.splat      v2, s3
    v.extract    s3, v62, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s3
    v.extract    s3, v62, #11
    v.splat      v6, s3
    vf.fma       v7, v3, v39, v4
    v.extract    s3, v62, #12
    v.splat      v3, s3
    v.extract    s3, v62, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s3
    v.extract    s3, v62, #14
    v.extract    s9, v62, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s3
    v.splat      v4, s9
    s.movz       s3, #15
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v63, #0
    v.splat      v1, s7
    v.extract    s7, v63, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v0, s7
    v.extract    s7, v63, #2
    v.splat      v1, s7
    vf.fma       v3, v0, v33, v2
    v.extract    s7, v63, #3
    v.splat      v0, s7
    v.extract    s7, v63, #4
    vf.fma       v2, v1, v34, v3
    v.splat      v1, s7
    v.extract    s7, v63, #5
    v.splat      v3, s7
    vf.fma       v4, v0, v35, v2
    v.extract    s7, v63, #6
    v.splat      v0, s7
    v.extract    s7, v63, #7
    vf.fma       v2, v1, v36, v4
    v.splat      v1, s7
    v.extract    s7, v63, #8
    v.splat      v4, s7
    vf.fma       v5, v3, v37, v2
    v.extract    s7, v63, #9
    v.splat      v2, s7
    v.extract    s7, v63, #10
    vf.fma       v3, v0, v38, v5
    v.splat      v0, s7
    v.extract    s7, v63, #11
    v.splat      v5, s7
    vf.fma       v6, v1, v39, v3
    v.extract    s7, v63, #12
    v.splat      v1, s7
    v.extract    s7, v63, #13
    vf.fma       v3, v4, v40, v6
    v.splat      v4, s7
    s.mul        s7, s5, s4
    v.extract    s4, v63, #14
    vf.fma       v6, v2, v41, v3
    s.movz       s9, #0
    s.muli       s11, s8, #4                     // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s12, #0
    vf.fma       v2, v0, v42, v6
    s.add        s14, s9, s8                     // the tile origin
    v.splat      v0, s4
    s.muli       s4, s6, #64                     // a runtime tile origin, x64
    vf.fma       v3, v5, v43, v2
    s.add        s9, s12, s6                     // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v5, s14
    vf.fma       v6, v1, v44, v3
    v.extract    s12, v63, #15
    s.movz       s14, #128
    s.muli       s15, s7, #4                     // a runtime tile origin, x4
    vf.fma       v1, v4, v45, v6
    v.splat      v3, s9
    v.splat      v4, s2
    v.add        v6, v2, v5
    vf.fma       v2, v0, v46, v1
    v.splat      v0, s2
    v.splat      v1, s12
    s.add        s2, s1, s11                     // the tile origin
    v.splat      v5, s5
    v.splat      v7, s14
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v6, v0
    vf.fma       v0, v1, v47, v2
    s.add        s1, s2, s4                      // the tile origin
    p.and        p3, p1, p2
    v.cmp.lt     p1, v5, v7
    s.add        s2, s1, s15                     // the tile origin
    p.and        p4, p3, p1
    a.vwrite     a0, s3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s2, #0]
    s.movz       s1, #0
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s3, s8, #4                      // a runtime tile origin, x4
    v.movi       v1, #0
    a.vread      v2, a0, s1
    s.muli       s1, s6, #64                     // a runtime tile origin, x64
    s.addi       s4, s9, #1
    vf.add       v3, v2, v1
    s.muli       s5, s7, #4                      // a runtime tile origin, x4
    v.splat      v2, s9
    v.splat      v5, s4
    s.add        s4, s16, s3                     // the tile origin
    v.cmp.lt     p3, v2, v4
    v.cmp.lt     p4, v5, v4
    s.add        s3, s4, s1                      // the tile origin
    vf.add       v2, v0, v3
    p.and        p5, p3, p2
    p.and        p3, p4, p2
    s.add        s1, s3, s5                      // the tile origin
    p.and        p4, p5, p1
    s.addi       s3, s2, #64                     // row 1
    p.and        p5, p3, p1
    @p4 v.st.w       [s1, #0], v2
    s.movz       s4, #1
    s.addi       s5, s9, #1
    s.addi       s6, s9, #2
    v.splat      v0, s5
    v.splat      v2, s6
    v.cmp.lt     p3, v0, v4
    p.and        p4, p3, p2
    s.addi       s5, s1, #64                     // row 1
    p.and        p3, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v0, [s3, #0]
    a.vread      v3, a0, s4
    v.cmp.lt     p4, v2, v4
    vf.add       v2, v3, v1
    p.and        p5, p4, p2
    s.addi       s3, s2, #128                    // row 2
    p.and        p4, p5, p1
    s.movz       s4, #2
    s.addi       s6, s9, #2
    s.addi       s7, s9, #3
    vf.add       v3, v0, v2
    v.splat      v0, s6
    v.splat      v2, s7
    s.addi       s6, s1, #128                    // row 2
    @p3 v.st.w       [s5, #0], v3
    v.cmp.lt     p3, v0, v4
    p.and        p5, p3, p2
    s.addi       s5, s2, #192                    // row 3
    p.and        p3, p5, p1
    s.movz       s7, #3
    s.addi       s8, s9, #3
    s.addi       s11, s9, #4
    v.splat      v0, s8
    v.splat      v3, s11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s3, #0]
    a.vread      v6, a0, s4
    v.cmp.lt     p4, v2, v4
    vf.add       v2, v6, v1
    p.and        p5, p4, p2
    s.addi       s3, s1, #192                    // row 3
    p.and        p4, p5, p1
    s.addi       s4, s2, #256                    // row 4
    s.movz       s8, #4
    s.addi       s11, s9, #4
    vf.add       v6, v5, v2
    s.addi       s12, s9, #5
    v.splat      v2, s11
    v.splat      v5, s12
    @p3 v.st.w       [s6, #0], v6
    v.cmp.lt     p3, v0, v4
    p.and        p5, p3, p2
    s.addi       s6, s1, #256                    // row 4
    p.and        p3, p5, p1
    s.addi       s11, s2, #320                   // row 5
    s.movz       s12, #5
    s.addi       s14, s9, #5
    s.addi       s15, s1, #320                   // row 5
    v.splat      v0, s14
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s5, #0]
    a.vread      v7, a0, s7
    v.cmp.lt     p4, v3, v4
    vf.add       v3, v7, v1
    p.and        p5, p4, p2
    s.addi       s5, s9, #6
    p.and        p4, p5, p1
    v.splat      v7, s5
    s.addi       s5, s2, #384                    // row 6
    vf.add       v8, v6, v3
    s.movz       s7, #6
    @p3 v.st.w       [s3, #0], v8
    v.cmp.lt     p3, v2, v4
    p.and        p5, p3, p2
    s.addi       s3, s9, #6
    p.and        p3, p5, p1
    v.splat      v2, s3
    s.addi       s3, s1, #384                    // row 6
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s4, #0]
    a.vread      v6, a0, s8
    v.cmp.lt     p4, v5, v4
    vf.add       v5, v6, v1
    p.and        p5, p4, p2
    s.addi       s4, s9, #7
    p.and        p4, p5, p1
    v.splat      v6, s4
    s.addi       s4, s2, #448                    // row 7
    vf.add       v8, v3, v5
    s.movz       s8, #7
    @p3 v.st.w       [s6, #0], v8
    v.cmp.lt     p3, v0, v4
    p.and        p5, p3, p2
    s.addi       s6, s9, #7
    p.and        p3, p5, p1
    v.splat      v0, s6
    s.addi       s6, s1, #448                    // row 7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s11, #0]
    a.vread      v5, a0, s12
    v.cmp.lt     p4, v7, v4
    vf.add       v7, v5, v1
    p.and        p5, p4, p2
    s.addi       s11, s9, #8
    p.and        p4, p5, p1
    v.splat      v5, s11
    s.addi       s11, s2, #512                   // row 8
    vf.add       v8, v3, v7
    s.movz       s12, #8
    @p3 v.st.w       [s15, #0], v8
    v.cmp.lt     p3, v2, v4
    p.and        p5, p3, p2
    s.addi       s14, s9, #8
    p.and        p3, p5, p1
    v.splat      v2, s14
    s.addi       s14, s1, #512                   // row 8
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s5, #0]
    a.vread      v7, a0, s7
    v.cmp.lt     p4, v6, v4
    vf.add       v6, v7, v1
    p.and        p5, p4, p2
    s.addi       s5, s9, #9
    p.and        p4, p5, p1
    v.splat      v7, s5
    s.addi       s5, s2, #576                    // row 9
    vf.add       v8, v3, v6
    s.movz       s7, #9
    @p3 v.st.w       [s3, #0], v8
    v.cmp.lt     p3, v0, v4
    p.and        p5, p3, p2
    s.addi       s3, s9, #9
    p.and        p3, p5, p1
    v.splat      v0, s3
    s.addi       s3, s1, #576                    // row 9
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s4, #0]
    a.vread      v6, a0, s8
    v.cmp.lt     p4, v5, v4
    vf.add       v5, v6, v1
    p.and        p5, p4, p2
    s.addi       s4, s9, #10
    p.and        p4, p5, p1
    v.splat      v6, s4
    s.addi       s4, s2, #640                    // row 10
    vf.add       v8, v3, v5
    s.movz       s8, #10
    @p3 v.st.w       [s6, #0], v8
    v.cmp.lt     p3, v2, v4
    p.and        p5, p3, p2
    s.addi       s6, s9, #10
    p.and        p3, p5, p1
    v.splat      v2, s6
    s.addi       s6, s1, #640                    // row 10
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s11, #0]
    a.vread      v5, a0, s12
    v.cmp.lt     p4, v7, v4
    vf.add       v7, v5, v1
    p.and        p5, p4, p2
    s.addi       s11, s9, #11
    p.and        p4, p5, p1
    v.splat      v5, s11
    s.addi       s11, s2, #704                   // row 11
    vf.add       v8, v3, v7
    s.movz       s12, #11
    @p3 v.st.w       [s14, #0], v8
    v.cmp.lt     p3, v0, v4
    p.and        p5, p3, p2
    s.addi       s14, s9, #11
    p.and        p3, p5, p1
    v.splat      v0, s14
    s.addi       s14, s1, #704                   // row 11
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s5, #0]
    a.vread      v7, a0, s7
    v.cmp.lt     p4, v6, v4
    vf.add       v6, v7, v1
    p.and        p5, p4, p2
    s.addi       s5, s9, #12
    p.and        p4, p5, p1
    v.splat      v7, s5
    s.addi       s5, s2, #768                    // row 12
    vf.add       v8, v3, v6
    s.movz       s7, #12
    @p3 v.st.w       [s3, #0], v8
    v.cmp.lt     p3, v2, v4
    p.and        p5, p3, p2
    s.addi       s3, s9, #12
    p.and        p3, p5, p1
    v.splat      v2, s3
    s.addi       s3, s1, #768                    // row 12
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s4, #0]
    a.vread      v6, a0, s8
    v.cmp.lt     p4, v5, v4
    vf.add       v5, v6, v1
    p.and        p5, p4, p2
    s.addi       s4, s9, #13
    p.and        p4, p5, p1
    v.splat      v6, s4
    s.addi       s4, s2, #832                    // row 13
    vf.add       v8, v3, v5
    s.movz       s8, #13
    @p3 v.st.w       [s6, #0], v8
    v.cmp.lt     p3, v0, v4
    p.and        p5, p3, p2
    s.addi       s6, s9, #13
    p.and        p3, p5, p1
    v.splat      v0, s6
    s.addi       s6, s1, #832                    // row 13
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s11, #0]
    a.vread      v5, a0, s12
    v.cmp.lt     p4, v7, v4
    vf.add       v7, v5, v1
    p.and        p5, p4, p2
    s.addi       s11, s9, #14
    p.and        p4, p5, p1
    v.splat      v5, s11
    s.addi       s11, s2, #896                   // row 14
    vf.add       v8, v3, v7
    s.movz       s12, #14
    @p3 v.st.w       [s14, #0], v8
    v.cmp.lt     p3, v2, v4
    p.and        p5, p3, p2
    s.addi       s14, s9, #14
    p.and        p3, p5, p1
    v.splat      v2, s14
    s.addi       s14, s1, #896                   // row 14
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s5, #0]
    a.vread      v7, a0, s7
    v.cmp.lt     p4, v6, v4
    vf.add       v6, v7, v1
    p.and        p5, p4, p2
    s.addi       s5, s9, #15
    p.and        p4, p5, p1
    v.splat      v7, s5
    s.addi       s5, s2, #960                    // row 15
    vf.add       v8, v3, v6
    s.movz       s2, #15
    @p3 v.st.w       [s3, #0], v8
    v.cmp.lt     p3, v0, v4
    p.and        p5, p3, p2
    s.addi       s3, s9, #15
    p.and        p3, p5, p1
    v.splat      v0, s3
    s.addi       s3, s1, #960                    // row 15
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s4, #0]
    a.vread      v6, a0, s8
    v.cmp.lt     p4, v5, v4
    vf.add       v5, v6, v1
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    vf.add       v6, v3, v5
    @p3 v.st.w       [s6, #0], v6
    v.cmp.lt     p3, v2, v4
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s11, #0]
    a.vread      v3, a0, s12
    v.cmp.lt     p4, v7, v4
    vf.add       v5, v3, v1
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    vf.add       v3, v2, v5
    @p3 v.st.w       [s14, #0], v3
    v.cmp.lt     p3, v0, v4
    p.and        p5, p3, p2
    p.and        p2, p5, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s5, #0]
    a.vread      v2, a0, s2
    vf.add       v3, v2, v1
    vf.add       v1, v0, v3
    @p2 v.st.w       [s3, #0], v1
__rctx_next:
    exit
