# AOT ID: ['2_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/jw/cjwguvh7fz6yd6d45afho644yacpkqiwujeray7wf5cp2hfihp6r.py
# Topologically Sorted Source Nodes: [getitem, float_1, freqs, emb, mul_1, to, mul_2, to_1], Original ATen: [aten.unsqueeze, aten._to_copy, aten.mul, aten.cat]
# Source node to ATen node mapping:
#   emb => clone, expand, unsqueeze_1, view
#   float_1 => convert_element_type
#   freqs => mul
#   getitem => unsqueeze
#   mul_1 => cos
#   mul_2 => sin
#   to => convert_element_type_1
#   to_1 => convert_element_type_2
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 64][64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "f32[16][1]tnca:0" = PlaceHolder[target=arg1_1]
#   %unsqueeze : Tensor "i64[1, 64, 1][64, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg0_1, 2), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 64, 1][64, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %mul : Tensor "f32[1, 64, 16][1024, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %arg1_1), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1, 16][1024, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul, 2), kwargs = {})
#   %expand : Tensor "f32[1, 64, 2, 16][1024, 16, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 64, 2, 16]), kwargs = {})
#   %clone : Tensor "f32[1, 64, 2, 16][2048, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 64, 32][2048, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 64, 32]), kwargs = {})
#   %cos : Tensor "f32[1, 64, 32][2048, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view,), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[1, 64, 32][2048, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%cos, torch.bfloat16), kwargs = {})
#   %sin : Tensor "f32[1, 64, 32][2048, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view,), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 64, 32][2048, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%sin, torch.bfloat16), kwargs = {})
#   return %convert_element_type_1,%convert_element_type_2
triton_poi_fused__to_copy_cat_mul_unsqueeze_0 = async_compile.triton('triton_poi_fused__to_copy_cat_mul_unsqueeze_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2048}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_cat_mul_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 16960}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_cat_mul_unsqueeze_0(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 2048
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = xindex // 32
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x1), xmask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr1 + ((x2 % 16)), xmask, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tmp1 * tmp2
    tmp4 = tl_math.cos(tmp3)
    tmp5 = tmp4.to(tl.float32)
    tmp6 = tl_math.sin(tmp3)
    tmp7 = tmp6.to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp5, xmask)
    tl.store(out_ptr1 + (x2), tmp7, xmask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1), ((1, 64), (16, )), ((64, 1), (1, )), 'input')
        buf0 = empty_strided((1, 64, 32), (2048, 32, 1), device='tnca', dtype=torch.bfloat16)
        buf1 = empty_strided((1, 64, 32), (2048, 32, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [getitem, float_1, freqs, emb, mul_1, to, mul_2, to_1], Original ATen: [aten.unsqueeze, aten._to_copy, aten.mul, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_cat_mul_unsqueeze_0.run(arg0_1, arg1_1, buf0, buf1, 2048, stream=raw_stream0)
        del arg0_1
        del arg1_1
        return (buf0, buf1, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 64), (64, 1), device='tnca:0', dtype=torch.int64)
    arg1_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
