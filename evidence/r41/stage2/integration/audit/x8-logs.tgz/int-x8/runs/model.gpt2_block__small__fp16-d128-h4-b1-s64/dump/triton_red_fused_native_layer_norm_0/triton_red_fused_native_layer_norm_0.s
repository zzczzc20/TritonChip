    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    v.movi       v0, #0
    v.movi       v1, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #128
    s.movz       s6, #16
    s.ld.d       s7, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.ld.d       s8, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.addi       s9, s2, #0
    s.ld.d       s10, [s1, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s9, s5
    br.nz        s1, endfor_2
    s.mul        s1, s4, s5
    v.splat      v3, s9
    v.movi       v4, #128
    v.add        v5, v3, v2
    v.movi       v3, #0
    s.add        s11, s9, s1
    v.cmp.lt     p1, v5, v4
    s.shli       s12, s11, #1                    // element offset -> bytes (x2)
    v.splat      v4, s1
    s.add        s1, s3, s12                     // &in_ptr0[...]
    s.add        s11, s9, s6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s1, #0]
    s.movz       s1, #1
    v.add        v7, v5, v4
    vf.cvt.f16.f32 v4, v6
    vf.add       v5, v1, v4
    @p1 v.sel        v4, v5, v1
    v.mov        v3, v4
    v.mov        v1, v3
    s.mov        s9, s11
    br.nz        s1, for_1
endfor_2:
    .li       s1, #1124073472
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v3                          // ISA 8.8: <= 2**-22 relative
    vf.reduce.add.b v6, v1
    v.movi       v1, #0
    v.movi       v7, #0
    vf.add       v8, v6, v1
    s.addi       s1, s2, #0
    v.mov        v7, v0
    vf.fms       v0, v3, v5, v4
    vf.fms       v6, v5, v0, v5
    vf.neg       v0, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v6, v0, v5
    vf.mul       v0, v8, v6                      // a/y as a refined reciprocal (ISA has no divide)
for_3:
    s.cmp.ge     s9, s1, s5
    br.nz        s9, endfor_4
    s.mul        s9, s4, s5
    v.splat      v5, s1
    v.movi       v6, #128
    v.add        v8, v5, v2
    v.extract    s11, v0, #0
    s.add        s12, s1, s9
    v.cmp.lt     p1, v8, v6
    s.shli       s13, s12, #1                    // element offset -> bytes (x2)
    v.splat      v5, s11
    s.add        s11, s3, s13                    // &in_ptr0[...]
    v.movi       v6, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v9, [s11, #0]
    v.splat      v10, s9
    s.add        s9, s1, s6
    s.movz       s11, #1
    v.add        v11, v8, v10
    vf.cvt.f16.f32 v8, v9
    vf.sub       v9, v8, v5
    vf.mul       v5, v9, v9
    vf.add       v8, v7, v5
    @p1 v.sel        v5, v8, v7
    v.mov        v6, v5
    v.mov        v7, v6
    s.mov        s1, s9
    br.nz        s11, for_3
endfor_4:
    vf.reduce.add.b v5, v7
    s.addi       s1, s2, #0
    vf.add       v6, v5, v1
for_5:
    s.cmp.ge     s2, s1, s5
    br.nz        s2, endfor_6
    v.rcp.approx v1, v3                          // ISA 8.8: <= 2**-22 relative
    .li       s2, #925353388
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s2, s4, s5
    v.splat      v7, s1
    v.movi       v8, #128
    v.add        v9, v7, v2
    .li       s9, #1077936128
    v.splat      v7, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s9, s1, s2
    .li       s11, #3204448256
    v.splat      v10, s11                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s11, s9, #1                     // element offset -> bytes (x2)
    v.cmp.lt     p1, v9, v8
    s.add        s9, s3, s11                     // &in_ptr0[...]
    s.shli       s12, s1, #1                     // element offset -> bytes (x2)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v8, [s9, #0]
    s.add        s9, s7, s12                     // &in_ptr1[...]
    v.extract    s13, v0, #0
    v.splat      v11, s13
    s.add        s13, s8, s12                    // &in_ptr2[...]
    v.splat      v12, s2
    vf.cvt.f16.f32 v13, v8
    s.add        s2, s10, s11                    // &out_ptr1[...]
    s.add        s11, s1, s6
    s.movz       s12, #1
    vf.sub       v8, v13, v11
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v11, [s9, #0]
    v.add        v13, v9, v12
    vf.fms       v9, v3, v1, v4
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s13, #0]
    vf.fms       v13, v1, v9, v1
    vf.cvt.f16.f32 v9, v11
    vf.neg       v11, v13                        // Newton step: r0*(2 - x*r0)
    vf.cvt.f16.f32 v13, v12
    vf.cmp.o     p2, v11, v11
    @p2 v.sel        v12, v11, v1
    vf.mul       v1, v6, v12                     // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v11, v1, v5
    v.rsqrt.approx v1, v11                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v1, v1
    vf.mul       v12, v1, v10
    vf.fms       v10, v11, v5, v7
    vf.mul       v5, v12, v10                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v5, v5
    @p2 v.sel        v7, v5, v1
    v.extract    s9, v7, #0
    v.splat      v1, s9
    vf.mul       v5, v8, v1
    vf.mul       v1, v5, v9
    vf.add       v5, v1, v13
    vf.cvt.f32.f16 v1, v5
    @p1 v.st.h       [s2, #0], v1
    s.mov        s1, s11
    br.nz        s12, for_5
endfor_6:
__rctx_next:
    exit
