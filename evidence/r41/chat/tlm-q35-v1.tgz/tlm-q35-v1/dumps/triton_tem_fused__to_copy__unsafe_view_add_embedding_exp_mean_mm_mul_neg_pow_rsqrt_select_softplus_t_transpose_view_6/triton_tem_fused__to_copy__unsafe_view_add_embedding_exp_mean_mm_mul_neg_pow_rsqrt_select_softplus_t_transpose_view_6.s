    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #1024
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s8, #0], s3
    .li       s1, #2147483647
    s.st.d       [s8, #8], s1
    .li       s1, #2147483647
    s.st.d       [s8, #16], s1
    s.movz       s1, #5120
    s.st.d       [s8, #48], s1
    s.movz       s1, #2
    s.st.d       [s8, #56], s1
    .li       s1, #68719476752
    s.st.d       [s8, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #2
    s.movz       s3, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.cmp.lt     s11, s1, s10
    s.sub        s10, s9, s11
    s.xor        s9, s1, s10
    s.sub        s11, s9, s10
    s.movz       s9, #1
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #1
    s.cmp.lt     s18, s4, s8
    s.sub        s8, s3, s18
    s.xor        s3, s4, s8
    s.sub        s18, s3, s8
    s.lshri      s3, s18, #1
    s.muli       s19, s3, #2
    s.sub        s20, s18, s19
    s.xor        s18, s8, s10
    s.xor        s8, s3, s18
    s.sub        s3, s8, s18
    s.sub        s8, s9, s3
    s.min.s      s10, s8, s9
    s.cmp.lt     s8, s4, s12
    s.sub        s12, s11, s8
    s.cmp.lt     s8, s10, s14
    s.sub        s11, s13, s8
    s.xor        s8, s4, s12
    s.sub        s13, s8, s12
    s.xor        s8, s10, s11
    s.sub        s14, s8, s11
    s.addi       s8, s15, #0
    s.addi       s11, s16, #0
    s.cmp.eq     s15, s14, s17
    s.mov        s8, s13
    br.nz        s15, sdiv_done_1
    s.movz       s15, #0
    s.movz       s16, #31
    s.mov        s8, s15
    s.addi       s15, s16, #0
sdiv_2:
    s.lshr       s16, s13, s15
    s.shli       s17, s11, #1
    s.andi       s18, s16, #1
    s.movz       s16, #0
    s.or         s19, s17, s18
    s.movz       s17, #1
    s.cmp.geu    s18, s19, s14
    s.shl        s20, s17, s15
    s.sub        s17, s16, s18
    s.subi       s16, s15, #1
    s.and        s18, s14, s17
    s.and        s21, s20, s17
    s.sub        s17, s19, s18
    s.or         s18, s8, s21
    s.mov        s11, s17
    s.mov        s8, s18
    s.mov        s15, s16
    s.movz       s16, #0
    s.cmp.ge     s17, s15, s16
    br.nz        s17, sdiv_2
sdiv_done_1:
    s.movz       s8, #0
    s.movz       s13, #0
    s.cmp.lt     s14, s4, s8
    s.movz       s8, #0
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.xor        s14, s4, s15
    s.movz       s4, #0
    s.sub        s16, s14, s15
    s.cmp.lt     s14, s10, s8
    s.lshri      s8, s16, #1
    s.movz       s17, #0
    s.muli       s18, s8, #2
    s.sub        s8, s4, s14
    s.movz       s4, #0
    s.cmp.lt     s14, s1, s17
    s.xor        s17, s10, s8
    s.sub        s10, s16, s18
    s.movz       s16, #0
    s.xor        s18, s10, s15
    s.xor        s10, s11, s12
    s.sub        s11, s18, s15
    s.sub        s15, s16, s14
    s.cmp.lt     s14, s11, s13
    s.sub        s13, s17, s8
    s.sub        s16, s4, s14
    s.movz       s4, #0
    s.xor        s14, s11, s16
    s.movz       s11, #1
    s.sub        s17, s10, s12
    s.xor        s10, s1, s15
    s.sub        s1, s14, s16
    s.movz       s12, #0
    s.addi       s14, s4, #0
    s.cmp.eq     s4, s13, s11
    s.add        s11, s3, s17
    s.sub        s3, s10, s15
    s.addi       s3, s12, #0
    s.mov        s14, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s10, #31
    s.mov        s14, s4
    s.addi       s4, s10, #0
sdiv_4:
    s.lshr       s10, s1, s4
    s.shli       s12, s3, #1
    s.andi       s15, s10, #1
    s.movz       s10, #0
    s.or         s17, s12, s15
    s.movz       s12, #1
    s.cmp.geu    s15, s17, s13
    s.shl        s18, s12, s4
    s.sub        s12, s10, s15
    s.subi       s10, s4, #1
    s.and        s15, s13, s12
    s.and        s19, s18, s12
    s.sub        s12, s17, s15
    s.or         s15, s14, s19
    s.mov        s3, s12
    s.mov        s14, s15
    s.mov        s4, s10
    s.movz       s10, #0
    s.cmp.ge     s12, s4, s10
    br.nz        s12, sdiv_4
sdiv_done_3:
    s.xor        s1, s16, s8
    s.movz       s3, #16
    s.xor        s4, s14, s1
    s.movz       s8, #0
    s.sub        s10, s4, s1
    v.splat      v0, s11
    s.mul        s1, s10, s3
    v.splat      v1, s8
    v.splat      v2, s10
    v.splat      v3, s8
    v.iota       v4                              // arange(0, VLEN)
    s.andi       s4, s1, #31
    v.splat      v5, s1
    v.splat      v6, s4
    v.cmp.ge     p1, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ge     p1, v2, v3
    v.add        v1, v5, v4
    v.add        v1, v6, v0
    s.movz       s10, #160
    s.addi       s12, s8, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s8, s12, s10
    br.nz        s8, endfor_6
    s.mul        s8, s12, s3
    s.muli       s13, s8, #2                     // a runtime tile origin, x2
    s.add        s14, s2, s13                    // the tile origin
    v.ld.h       v0, [s14, #0]
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s13, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s8                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s14, s13
    mb.wait      s13
    s.rdspecial  s8, arg_base
    s.ld.d       s14, [s8, #40]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s8, role_id
    s.movz       s15, #1024
    s.mul        s16, s8, s15
    s.add        s8, s14, s16                    // this context's own scratch
    s.addi       s14, s8, #256                   // 512 bytes of repack scratch
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s14, #0], v0
    s.addi       s15, s14, #32                   // row 1
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #64                   // row 2
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #96                   // row 3
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #128                  // row 4
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #160                  // row 5
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #192                  // row 6
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #224                  // row 7
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #256                  // row 8
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #288                  // row 9
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #320                  // row 10
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #352                  // row 11
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #384                  // row 12
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #416                  // row 13
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #448                  // row 14
    v.st.h       [s15, #0], v0
    s.addi       s15, s14, #480                  // row 15
    v.st.h       [s15, #0], v0
    s.addi       s15, s8, #768                   // TensorMap 1: a repacked tile
    s.movz       s8, #0
    s.st.d       [s15, #0], s14
    s.movz       s8, #16
    s.st.d       [s15, #8], s8
    s.movz       s8, #16
    s.st.d       [s15, #16], s8
    s.movz       s8, #32
    s.st.d       [s15, #48], s8
    s.movz       s8, #2
    s.st.d       [s15, #56], s8
    .li       s8, #68719476752
    s.st.d       [s15, #88], s8
    .li       s8, #1108101562368
    s.st.d       [s15, #104], s8
    fence.release.device
    td.load      d1, [s15]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s8, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s14, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s15, s8                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s8                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s15, s14
    mb.wait      s14
    mb.arm       s8, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v48, v56, s8
    mb.wait      s8
    s.add        s15, s12, s9
    s.mov        s12, s15
    s.movz       s15, #1
    br.nz        s15, for_5
endfor_6:
    s.mul        s2, s11, s3
    s.movz       s3, #0
    s.movz       s4, #0
    s.add        s10, s3, s1                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s3, s1, #2                      // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s10
    s.add        s10, s4, s2                     // the tile origin
    s.movz       s4, #32
    s.muli       s11, s2, #64                    // a runtime tile origin, x64
    v.splat      v2, s10
    v.splat      v3, s9
    v.add        v5, v0, v1
    v.splat      v0, s4
    s.add        s4, s6, s3                      // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v5, v0
    s.add        s3, s4, s11                     // the tile origin
    s.movz       s4, #0
    p.and        p3, p1, p2
    a.vread      v0, a0, s4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    s.addi       s4, s10, #1
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    s.movz       s6, #1
    v.cmp.lt     p1, v0, v3
    vf.cvt.bf16.f32 v0, v2
    s.addi       s9, s3, #64                     // row 1
    p.and        p3, p1, p2
    s.movz       s11, #1
    s.movz       s12, #2
    s.muli       s15, s1, #2                     // a runtime tile origin, x2
    s.muli       s16, s2, #64                    // a runtime tile origin, x64
    vf.cvt.bf16.f32 v2, v1
    v.splat      v1, s2
    s.add        s17, s5, s15                    // the tile origin
    s.movz       s5, #2
    vf.add       v5, v0, v2
    s.add        s15, s17, s16                   // the tile origin
    v.add        v0, v1, v4
    s.addi       s16, s10, #2
    a.vwrite     a1, s4, v5
    a.vread      v0, a0, s6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s9, #0]
    v.splat      v2, s16
    vf.cvt.f32.bf16 v4, v0
    s.addi       s4, s3, #128                    // row 2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.addi       s6, s10, #3
    vf.cvt.bf16.f32 v0, v4
    v.splat      v2, s6
    s.movz       s6, #3
    s.addi       s9, s3, #192                    // row 3
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s16, s10, #4
    vf.cvt.bf16.f32 v2, v1
    v.splat      v1, s16
    s.movz       s16, #3
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v0, v2
    p.and        p5, p1, p2
    a.vwrite     a1, s11, v1
    a.vread      v0, a0, s5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    s.movz       s4, #4
    vf.cvt.f32.bf16 v2, v0
    s.addi       s5, s3, #256                    // row 4
    s.addi       s11, s10, #5
    v.splat      v0, s11
    vf.cvt.bf16.f32 v4, v2
    s.movz       s11, #4
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v0, v1
    vf.add       v1, v4, v0
    a.vwrite     a1, s12, v1
    a.vread      v0, a0, s6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s9, #0]
    s.movz       s6, #5
    vf.cvt.f32.bf16 v2, v0
    s.addi       s9, s3, #320                    // row 5
    s.addi       s12, s10, #6
    v.splat      v0, s12
    vf.cvt.bf16.f32 v4, v2
    s.movz       s12, #5
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    vf.cvt.bf16.f32 v0, v1
    vf.add       v1, v4, v0
    a.vwrite     a1, s16, v1
    a.vread      v0, a0, s4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v1, [s5, #0]
    s.movz       s4, #6
    vf.cvt.f32.bf16 v2, v0
    s.addi       s5, s3, #384                    // row 6
    s.addi       s16, s10, #7
    v.splat      v0, s16
    vf.cvt.bf16.f32 v4, v2
    s.movz       s16, #6
    v.cmp.lt     p1, v0, v3
    p.and        p5, p1, p2
    vf.cvt.bf16.f32 v0, v1
    vf.add       v1, v4, v0
    a.vwrite     a1, s11, v1
    a.vread      v0, a0, s6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s9, #0]
    s.movz       s6, #7
    vf.cvt.f32.bf16 v2, v0
    s.addi       s9, s3, #448                    // row 7
    s.addi       s11, s10, #8
    v.splat      v0, s11
    vf.cvt.bf16.f32 v4, v2
    s.movz       s11, #7
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v0, v1
    vf.add       v1, v4, v0
    a.vwrite     a1, s12, v1
    a.vread      v0, a0, s4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s5, #0]
    s.movz       s4, #8
    vf.cvt.f32.bf16 v2, v0
    s.addi       s5, s3, #512                    // row 8
    s.addi       s12, s10, #9
    v.splat      v0, s12
    vf.cvt.bf16.f32 v4, v2
    s.movz       s12, #8
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    vf.cvt.bf16.f32 v0, v1
    vf.add       v1, v4, v0
    a.vwrite     a1, s16, v1
    a.vread      v0, a0, s6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v1, [s9, #0]
    s.movz       s6, #9
    vf.cvt.f32.bf16 v2, v0
    s.addi       s9, s3, #576                    // row 9
    s.addi       s16, s10, #10
    v.splat      v0, s16
    vf.cvt.bf16.f32 v4, v2
    s.movz       s16, #9
    v.cmp.lt     p1, v0, v3
    p.and        p5, p1, p2
    vf.cvt.bf16.f32 v0, v1
    vf.add       v1, v4, v0
    a.vwrite     a1, s11, v1
    a.vread      v0, a0, s4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    s.movz       s4, #10
    vf.cvt.f32.bf16 v2, v0
    s.addi       s5, s3, #640                    // row 10
    s.addi       s11, s10, #11
    v.splat      v0, s11
    vf.cvt.bf16.f32 v4, v2
    s.movz       s11, #10
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v0, v1
    vf.add       v1, v4, v0
    a.vwrite     a1, s12, v1
    a.vread      v0, a0, s6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s9, #0]
    s.movz       s6, #11
    vf.cvt.f32.bf16 v2, v0
    s.addi       s9, s3, #704                    // row 11
    s.addi       s12, s10, #12
    v.splat      v0, s12
    vf.cvt.bf16.f32 v4, v2
    s.movz       s12, #11
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    vf.cvt.bf16.f32 v0, v1
    vf.add       v1, v4, v0
    a.vwrite     a1, s16, v1
    a.vread      v0, a0, s4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v1, [s5, #0]
    s.movz       s4, #12
    vf.cvt.f32.bf16 v2, v0
    s.addi       s5, s3, #768                    // row 12
    s.addi       s16, s10, #13
    v.splat      v0, s16
    vf.cvt.bf16.f32 v4, v2
    s.movz       s16, #12
    v.cmp.lt     p1, v0, v3
    p.and        p5, p1, p2
    vf.cvt.bf16.f32 v0, v1
    vf.add       v1, v4, v0
    a.vwrite     a1, s11, v1
    a.vread      v0, a0, s6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s9, #0]
    s.movz       s6, #13
    vf.cvt.f32.bf16 v2, v0
    s.addi       s9, s3, #832                    // row 13
    s.addi       s11, s10, #14
    v.splat      v0, s11
    vf.cvt.bf16.f32 v4, v2
    s.movz       s11, #13
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v0, v1
    vf.add       v1, v4, v0
    a.vwrite     a1, s12, v1
    a.vread      v0, a0, s4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s5, #0]
    s.movz       s4, #14
    vf.cvt.f32.bf16 v2, v0
    s.addi       s5, s3, #896                    // row 14
    s.addi       s12, s10, #15
    s.addi       s17, s3, #960                   // row 15
    v.splat      v0, s12
    vf.cvt.bf16.f32 v4, v2
    s.movz       s3, #14
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    .li       s12, #1101004800
    v.splat      v0, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s12, s1, #4                     // a runtime tile origin, x4
    vf.cvt.bf16.f32 v2, v1
    s.muli       s1, s2, #128                    // a runtime tile origin, x128
    s.add        s2, s7, s12                     // the tile origin
    s.movz       s7, #15
    vf.add       v1, v4, v2
    s.add        s12, s2, s1                     // the tile origin
    s.movz       s1, #15
    a.vwrite     a1, s16, v1
    a.vread      v1, a0, s6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v2, [s9, #0]
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    v.splat      v4, s10
    vf.cvt.f32.bf16 v5, v1
    v.cmp.lt     p1, v4, v3
    p.and        p5, p1, p2
    vf.cvt.bf16.f32 v1, v5
    .li       s2, #1069066811
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1060205080
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v6, v2
    vf.add       v2, v1, v6
    a.vwrite     a1, s11, v2
    a.vread      v1, a0, s4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    s.movz       s2, #0
    vf.cvt.f32.bf16 v6, v1
    s.movz       s4, #0
    vf.cvt.bf16.f32 v1, v6
    s.movz       s5, #0
    vf.cvt.bf16.f32 v6, v2
    vf.add       v2, v1, v6
    a.vwrite     a1, s3, v2
    a.vread      v1, a0, s7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s17, #0]
    .li       s3, #1065353216
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.f32.bf16 v7, v1
    .li       s3, #4913933
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v8, v7
    v.movi       v7, #23
    v.movi       v9, #127
    v.movi       v10, #25
    v.movi       v11, #23
    vf.cvt.bf16.f32 v12, v2
    vf.add       v2, v8, v12
    a.vwrite     a1, s1, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v2, [s15, #0]
    a.vread      v8, a1, s2
    a.vread      v12, a1, s4
    a.vread      v13, a1, s5
    v.movi       v14, #127
    v.movi       v15, #23
    vf.mul       v16, v13, v4
    vf.cmp.gt    p1, v8, v0
    v.exp2.approx v8, v16                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v17, v13, v4, v16               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v13, v2
    vf.mul       v2, v17, v5
    vf.mul       v16, v13, v4
    .li       s1, #1032451959
    v.splat      v17, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.exp2.approx v18, v16                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v19, v13, v4, v16               // the exact rounding error of x*log2(e)
    .li       s1, #3186590336
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1039390164
    v.splat      v16, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v20, v19, v5
    vf.fma       v19, v8, v2, v8                 // 2**t * 2**d
    vf.cmp.o     p3, v19, v19
    @p3 v.sel        v2, v19, v8
    vf.add       v8, v2, v6
    vf.fma       v19, v18, v20, v18              // 2**t * 2**d
    v.add        v20, v8, v1
    .li       s1, #3187543230
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.lshr       v8, v20, v7
    vf.cmp.o     p3, v19, v19
    @p3 v.sel        v7, v19, v18
    v.sub        v18, v8, v9
    .li       s1, #1041339458
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v9, v7
    v.min.s      v7, v18, v10
    v.shl        v10, v18, v11
    .li       s1, #3190467997
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v19, v14, v7
    v.sub        v7, v2, v10
    .li       s1, #1045222078
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.shl        v14, v19, v15
    vf.cvt.s32.f32 v15, v18
    .li       s1, #3196059656
    v.splat      v18, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.sub       v19, v14, v6
    .li       s1, #1060205056
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1051372195
    v.splat      v20, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v21, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v22, v15, v14                   // k*ln2_hi, exact
    vf.add       v23, v7, v19                    // f = x*2**-k + (2**-k - 1)
    .li       s1, #901758606
    v.splat      v24, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v25, v2
    .li       s1, #855638016
    v.splat      v26, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3212836864
    v.splat      v27, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v28, v17, v23, v13
    vf.sub       v29, v23, v7
    vf.neg       v30, v23
    vf.add       v31, v22, v23
    vf.mul       v32, v23, v23
    vf.fma       v33, v28, v23, v16
    vf.sub       v28, v23, v29
    vf.sub       v34, v19, v29
    vf.sub       v19, v31, v22
    vf.cmp.lt    p3, v25, v26
    vf.fma       v22, v33, v23, v1
    vf.sub       v25, v7, v28
    .li       s1, #4286578688
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.sub       v28, v23, v19                   // Fast2Sum
    vf.cmp.eq    p4, v2, v27
    vf.fma       v19, v22, v23, v8
    vf.add       v22, v25, v34                   // TwoSum: the exact error of f
    .li       s1, #2143289344
    v.splat      v25, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #2139095040
    v.splat      v29, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v33, s10
    vf.fma       v34, v19, v23, v11
    vf.fma       v19, v30, v22, v22              // f_lo/(1 + f_hi)
    vf.fma       v22, v34, v23, v10
    vf.fma       v30, v15, v24, v19
    s.addi       s1, s15, #64                    // row 1
    vf.fma       v15, v22, v23, v18
    s.addi       s2, s10, #1
    v.splat      v19, s2
    vf.fma       v22, v15, v23, v20
    vf.fma       v15, v22, v23, v21
    vf.fma       v22, v32, v15, v30
    s.movz       s2, #1
    vf.add       v15, v28, v22
    vf.add       v22, v31, v15
    s.movz       s3, #1
    s.movz       s4, #1
    @p3 v.sel        v15, v2, v22
    vf.cmp.lt    p3, v2, v27
    @p4 v.sel        v22, v7, v15
    vf.cmp.eq    p4, v2, v29
    @p3 v.sel        v15, v25, v22
    vf.cmp.uo    p3, v2, v2
    .li       s5, #4913933
    v.splat      v22, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v23, v2, v15
    v.cmp.lt     p4, v33, v3
    p.and        p5, p4, p2
    @p3 v.sel        v15, v2, v23
    v.cmp.lt     p3, v19, v3
    p.and        p4, p3, p2
    @p1 v.sel        v2, v12, v15
    v.movi       v12, #23
    v.movi       v15, #127
    vf.mul       v19, v9, v2
    v.movi       v2, #25
    vf.mul       v9, v19, v4
    v.exp2.approx v23, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v28, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #23
    vf.mul       v19, v28, v5
    vf.fma       v28, v23, v19, v23              // 2**t * 2**d
    v.movi       v19, #127
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v30, v28, v23
    v.movi       v23, #23
    @p5 v.st.w       [s12, #0], v30
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s3
    a.vread      v32, a1, s4
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v28
    vf.mul       v28, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v28, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v28, v32, v33
    vf.add       v32, v28, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v22
    v.lshr       v22, v30, v12
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v12, v33, v34
    v.sub        v30, v22, v15
    vf.neg       v15, v12
    v.min.s      v12, v30, v2
    v.shl        v2, v30, v9
    vf.cvt.s32.f32 v9, v30
    v.sub        v22, v19, v12
    v.sub        v12, v28, v2
    vf.abs       v2, v28
    v.shl        v19, v22, v23
    vf.mul       v22, v9, v14                    // k*ln2_hi, exact
    vf.cmp.eq    p3, v28, v27
    vf.sub       v23, v19, v6
    vf.cmp.lt    p4, v2, v26
    s.addi       s1, s12, #128                   // row 1
    vf.add       v2, v12, v23                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #1
    vf.fma       v19, v17, v2, v13
    vf.sub       v30, v2, v12
    vf.neg       v32, v2
    vf.add       v33, v22, v2
    vf.mul       v34, v2, v2
    vf.fma       v35, v19, v2, v16
    vf.sub       v19, v23, v30
    vf.sub       v23, v2, v30
    vf.sub       v30, v33, v22
    vf.fma       v22, v35, v2, v1
    vf.sub       v35, v12, v23
    vf.sub       v12, v2, v30                    // Fast2Sum
    v.splat      v23, s2
    vf.fma       v30, v22, v2, v8
    vf.add       v22, v35, v19                   // TwoSum: the exact error of f
    s.addi       s2, s10, #2
    s.addi       s3, s15, #128                   // row 2
    vf.fma       v19, v30, v2, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v22, v22              // f_lo/(1 + f_hi)
    vf.fma       v22, v19, v2, v10
    vf.fma       v19, v9, v24, v35
    vf.fma       v9, v22, v2, v18
    vf.fma       v22, v9, v2, v20
    vf.fma       v9, v22, v2, v21
    vf.fma       v2, v34, v9, v19
    s.movz       s2, #2
    s.movz       s4, #2
    vf.add       v9, v12, v2
    s.movz       s5, #2
    vf.add       v2, v33, v9
    @p4 v.sel        v9, v28, v2
    vf.cmp.lt    p4, v28, v27
    @p3 v.sel        v2, v7, v9
    vf.cmp.eq    p3, v28, v29
    @p4 v.sel        v9, v25, v2
    vf.cmp.uo    p4, v28, v28
    @p3 v.sel        v2, v28, v9
    v.cmp.lt     p3, v23, v3
    p.and        p5, p3, p2
    @p4 v.sel        v9, v28, v2
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v2, v31, v9
    .li       s6, #4913933
    v.splat      v9, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v12, #23
    vf.mul       v19, v15, v2
    v.movi       v2, #127
    vf.mul       v15, v19, v4
    v.exp2.approx v22, v15                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v15               // the exact rounding error of x*log2(e)
    v.movi       v15, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v9
    v.lshr       v9, v30, v12
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v12, v33, v34
    v.sub        v30, v9, v2
    vf.neg       v2, v12
    v.min.s      v9, v30, v15
    v.shl        v12, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v9
    v.sub        v9, v19, v12
    vf.abs       v12, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v12, v26
    s.addi       s1, s12, #256                   // row 2
    vf.add       v12, v9, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #2
    vf.fma       v22, v17, v12, v13
    vf.sub       v30, v12, v9
    vf.neg       v32, v12
    vf.add       v33, v23, v12
    vf.mul       v34, v12, v12
    vf.fma       v35, v22, v12, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v12, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v12, v1
    vf.sub       v35, v9, v28
    vf.sub       v9, v12, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v12, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #3
    s.addi       s3, s15, #192                   // row 3
    vf.fma       v22, v30, v12, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v12, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v12, v18
    vf.fma       v23, v15, v12, v20
    vf.fma       v15, v23, v12, v21
    vf.fma       v12, v34, v15, v22
    s.movz       s2, #3
    s.movz       s4, #3
    vf.add       v15, v9, v12
    s.movz       s5, #3
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v12
    v.lshr       v12, v30, v15
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v15, v33, v34
    v.sub        v30, v12, v2
    vf.neg       v2, v15
    v.min.s      v12, v30, v9
    v.shl        v9, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v12
    v.sub        v12, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #384                   // row 3
    vf.add       v9, v12, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #3
    vf.fma       v22, v17, v9, v13
    vf.sub       v30, v9, v12
    vf.neg       v32, v9
    vf.add       v33, v23, v9
    vf.mul       v34, v9, v9
    vf.fma       v35, v22, v9, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v9, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v9, v1
    vf.sub       v35, v12, v28
    vf.sub       v12, v9, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v9, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #4
    s.addi       s3, s15, #256                   // row 4
    vf.fma       v22, v30, v9, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v9, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v9, v18
    vf.fma       v23, v15, v9, v20
    vf.fma       v15, v23, v9, v21
    vf.fma       v9, v34, v15, v22
    s.movz       s2, #4
    s.movz       s4, #4
    vf.add       v15, v12, v9
    s.movz       s5, #4
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v12
    v.lshr       v12, v30, v15
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v15, v33, v34
    v.sub        v30, v12, v2
    vf.neg       v2, v15
    v.min.s      v12, v30, v9
    v.shl        v9, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v12
    v.sub        v12, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #512                   // row 4
    vf.add       v9, v12, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #4
    vf.fma       v22, v17, v9, v13
    vf.sub       v30, v9, v12
    vf.neg       v32, v9
    vf.add       v33, v23, v9
    vf.mul       v34, v9, v9
    vf.fma       v35, v22, v9, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v9, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v9, v1
    vf.sub       v35, v12, v28
    vf.sub       v12, v9, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v9, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #5
    s.addi       s3, s15, #320                   // row 5
    vf.fma       v22, v30, v9, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v9, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v9, v18
    vf.fma       v23, v15, v9, v20
    vf.fma       v15, v23, v9, v21
    vf.fma       v9, v34, v15, v22
    s.movz       s2, #5
    s.movz       s4, #5
    vf.add       v15, v12, v9
    s.movz       s5, #5
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v12
    v.lshr       v12, v30, v15
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v15, v33, v34
    v.sub        v30, v12, v2
    vf.neg       v2, v15
    v.min.s      v12, v30, v9
    v.shl        v9, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v12
    v.sub        v12, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #640                   // row 5
    vf.add       v9, v12, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #5
    vf.fma       v22, v17, v9, v13
    vf.sub       v30, v9, v12
    vf.neg       v32, v9
    vf.add       v33, v23, v9
    vf.mul       v34, v9, v9
    vf.fma       v35, v22, v9, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v9, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v9, v1
    vf.sub       v35, v12, v28
    vf.sub       v12, v9, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v9, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #6
    s.addi       s3, s15, #384                   // row 6
    vf.fma       v22, v30, v9, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v9, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v9, v18
    vf.fma       v23, v15, v9, v20
    vf.fma       v15, v23, v9, v21
    vf.fma       v9, v34, v15, v22
    s.movz       s2, #6
    s.movz       s4, #6
    vf.add       v15, v12, v9
    s.movz       s5, #6
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v12
    v.lshr       v12, v30, v15
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v15, v33, v34
    v.sub        v30, v12, v2
    vf.neg       v2, v15
    v.min.s      v12, v30, v9
    v.shl        v9, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v12
    v.sub        v12, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #768                   // row 6
    vf.add       v9, v12, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #6
    vf.fma       v22, v17, v9, v13
    vf.sub       v30, v9, v12
    vf.neg       v32, v9
    vf.add       v33, v23, v9
    vf.mul       v34, v9, v9
    vf.fma       v35, v22, v9, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v9, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v9, v1
    vf.sub       v35, v12, v28
    vf.sub       v12, v9, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v9, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #7
    s.addi       s3, s15, #448                   // row 7
    vf.fma       v22, v30, v9, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v9, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v9, v18
    vf.fma       v23, v15, v9, v20
    vf.fma       v15, v23, v9, v21
    vf.fma       v9, v34, v15, v22
    s.movz       s2, #7
    s.movz       s4, #7
    vf.add       v15, v12, v9
    s.movz       s5, #7
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v12
    v.lshr       v12, v30, v15
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v15, v33, v34
    v.sub        v30, v12, v2
    vf.neg       v2, v15
    v.min.s      v12, v30, v9
    v.shl        v9, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v12
    v.sub        v12, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #896                   // row 7
    vf.add       v9, v12, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #7
    vf.fma       v22, v17, v9, v13
    vf.sub       v30, v9, v12
    vf.neg       v32, v9
    vf.add       v33, v23, v9
    vf.mul       v34, v9, v9
    vf.fma       v35, v22, v9, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v9, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v9, v1
    vf.sub       v35, v12, v28
    vf.sub       v12, v9, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v9, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #8
    s.addi       s3, s15, #512                   // row 8
    vf.fma       v22, v30, v9, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v9, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v9, v18
    vf.fma       v23, v15, v9, v20
    vf.fma       v15, v23, v9, v21
    vf.fma       v9, v34, v15, v22
    s.movz       s2, #8
    s.movz       s4, #8
    vf.add       v15, v12, v9
    s.movz       s5, #8
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v12
    v.lshr       v12, v30, v15
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v15, v33, v34
    v.sub        v30, v12, v2
    vf.neg       v2, v15
    v.min.s      v12, v30, v9
    v.shl        v9, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v12
    v.sub        v12, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #1024                  // row 8
    vf.add       v9, v12, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #8
    vf.fma       v22, v17, v9, v13
    vf.sub       v30, v9, v12
    vf.neg       v32, v9
    vf.add       v33, v23, v9
    vf.mul       v34, v9, v9
    vf.fma       v35, v22, v9, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v9, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v9, v1
    vf.sub       v35, v12, v28
    vf.sub       v12, v9, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v9, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #9
    s.addi       s3, s15, #576                   // row 9
    vf.fma       v22, v30, v9, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v9, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v9, v18
    vf.fma       v23, v15, v9, v20
    vf.fma       v15, v23, v9, v21
    vf.fma       v9, v34, v15, v22
    s.movz       s2, #9
    s.movz       s4, #9
    vf.add       v15, v12, v9
    s.movz       s5, #9
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v12
    v.lshr       v12, v30, v15
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v15, v33, v34
    v.sub        v30, v12, v2
    vf.neg       v2, v15
    v.min.s      v12, v30, v9
    v.shl        v9, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v12
    v.sub        v12, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #1152                  // row 9
    vf.add       v9, v12, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #9
    vf.fma       v22, v17, v9, v13
    vf.sub       v30, v9, v12
    vf.neg       v32, v9
    vf.add       v33, v23, v9
    vf.mul       v34, v9, v9
    vf.fma       v35, v22, v9, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v9, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v9, v1
    vf.sub       v35, v12, v28
    vf.sub       v12, v9, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v9, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #10
    s.addi       s3, s15, #640                   // row 10
    vf.fma       v22, v30, v9, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v9, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v9, v18
    vf.fma       v23, v15, v9, v20
    vf.fma       v15, v23, v9, v21
    vf.fma       v9, v34, v15, v22
    s.movz       s2, #10
    s.movz       s4, #10
    vf.add       v15, v12, v9
    s.movz       s5, #10
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v12
    v.lshr       v12, v30, v15
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v15, v33, v34
    v.sub        v30, v12, v2
    vf.neg       v2, v15
    v.min.s      v12, v30, v9
    v.shl        v9, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v12
    v.sub        v12, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #1280                  // row 10
    vf.add       v9, v12, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #10
    vf.fma       v22, v17, v9, v13
    vf.sub       v30, v9, v12
    vf.neg       v32, v9
    vf.add       v33, v23, v9
    vf.mul       v34, v9, v9
    vf.fma       v35, v22, v9, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v9, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v9, v1
    vf.sub       v35, v12, v28
    vf.sub       v12, v9, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v9, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #11
    s.addi       s3, s15, #704                   // row 11
    vf.fma       v22, v30, v9, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v9, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v9, v18
    vf.fma       v23, v15, v9, v20
    vf.fma       v15, v23, v9, v21
    vf.fma       v9, v34, v15, v22
    s.movz       s2, #11
    s.movz       s4, #11
    vf.add       v15, v12, v9
    s.movz       s5, #11
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v12
    v.lshr       v12, v30, v15
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v15, v33, v34
    v.sub        v30, v12, v2
    vf.neg       v2, v15
    v.min.s      v12, v30, v9
    v.shl        v9, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v12
    v.sub        v12, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #1408                  // row 11
    vf.add       v9, v12, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #11
    vf.fma       v22, v17, v9, v13
    vf.sub       v30, v9, v12
    vf.neg       v32, v9
    vf.add       v33, v23, v9
    vf.mul       v34, v9, v9
    vf.fma       v35, v22, v9, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v9, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v9, v1
    vf.sub       v35, v12, v28
    vf.sub       v12, v9, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v9, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #12
    s.addi       s3, s15, #768                   // row 12
    vf.fma       v22, v30, v9, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v9, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v9, v18
    vf.fma       v23, v15, v9, v20
    vf.fma       v15, v23, v9, v21
    vf.fma       v9, v34, v15, v22
    s.movz       s2, #12
    s.movz       s4, #12
    vf.add       v15, v12, v9
    s.movz       s5, #12
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v12
    v.lshr       v12, v30, v15
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v15, v33, v34
    v.sub        v30, v12, v2
    vf.neg       v2, v15
    v.min.s      v12, v30, v9
    v.shl        v9, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v12
    v.sub        v12, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #1536                  // row 12
    vf.add       v9, v12, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #12
    vf.fma       v22, v17, v9, v13
    vf.sub       v30, v9, v12
    vf.neg       v32, v9
    vf.add       v33, v23, v9
    vf.mul       v34, v9, v9
    vf.fma       v35, v22, v9, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v9, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v9, v1
    vf.sub       v35, v12, v28
    vf.sub       v12, v9, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v9, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #13
    s.addi       s3, s15, #832                   // row 13
    vf.fma       v22, v30, v9, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v9, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v9, v18
    vf.fma       v23, v15, v9, v20
    vf.fma       v15, v23, v9, v21
    vf.fma       v9, v34, v15, v22
    s.movz       s2, #13
    s.movz       s4, #13
    vf.add       v15, v12, v9
    s.movz       s5, #13
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v12
    v.lshr       v12, v30, v15
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v15, v33, v34
    v.sub        v30, v12, v2
    vf.neg       v2, v15
    v.min.s      v12, v30, v9
    v.shl        v9, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v12
    v.sub        v12, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #1664                  // row 13
    vf.add       v9, v12, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #13
    vf.fma       v22, v17, v9, v13
    vf.sub       v30, v9, v12
    vf.neg       v32, v9
    vf.add       v33, v23, v9
    vf.mul       v34, v9, v9
    vf.fma       v35, v22, v9, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v9, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v9, v1
    vf.sub       v35, v12, v28
    vf.sub       v12, v9, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v9, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #14
    s.addi       s3, s15, #896                   // row 14
    vf.fma       v22, v30, v9, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v9, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v9, v18
    vf.fma       v23, v15, v9, v20
    vf.fma       v15, v23, v9, v21
    vf.fma       v9, v34, v15, v22
    s.movz       s2, #14
    s.movz       s4, #14
    vf.add       v15, v12, v9
    s.movz       s5, #14
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v4
    v.exp2.approx v33, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v4, v30               // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v30, v19
    vf.mul       v19, v34, v5
    vf.mul       v32, v30, v4
    v.exp2.approx v34, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v30, v4, v32               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v5
    vf.fma       v32, v33, v19, v33              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v33
    vf.add       v32, v19, v6
    vf.fma       v33, v34, v30, v34              // 2**t * 2**d
    v.add        v30, v32, v12
    v.lshr       v12, v30, v15
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v15, v33, v34
    v.sub        v30, v12, v2
    vf.neg       v2, v15
    v.min.s      v12, v30, v9
    v.shl        v9, v30, v23
    vf.cvt.s32.f32 v15, v30
    v.sub        v23, v22, v12
    v.sub        v12, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v23, v28
    vf.mul       v23, v15, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v28, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #1792                  // row 14
    vf.add       v9, v12, v28                    // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #14
    vf.fma       v22, v17, v9, v13
    vf.sub       v30, v9, v12
    vf.neg       v32, v9
    vf.add       v33, v23, v9
    vf.mul       v34, v9, v9
    vf.fma       v35, v22, v9, v16
    vf.sub       v22, v28, v30
    vf.sub       v28, v9, v30
    vf.sub       v30, v33, v23
    vf.fma       v23, v35, v9, v1
    vf.sub       v35, v12, v28
    vf.sub       v12, v9, v30                    // Fast2Sum
    v.splat      v28, s2
    vf.fma       v30, v23, v9, v8
    vf.add       v23, v35, v22                   // TwoSum: the exact error of f
    s.addi       s2, s10, #15
    s.addi       s3, s15, #960                   // row 15
    vf.fma       v22, v30, v9, v11
    v.splat      v30, s2
    vf.fma       v35, v32, v23, v23              // f_lo/(1 + f_hi)
    vf.fma       v23, v22, v9, v10
    vf.fma       v22, v15, v24, v35
    vf.fma       v15, v23, v9, v18
    vf.fma       v23, v15, v9, v20
    vf.fma       v15, v23, v9, v21
    vf.fma       v9, v34, v15, v22
    s.movz       s2, #15
    s.movz       s4, #15
    vf.add       v15, v12, v9
    s.movz       s5, #15
    vf.add       v9, v33, v15
    @p4 v.sel        v12, v19, v9
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v9, v7, v12
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v12, v25, v9
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v9, v19, v12
    v.cmp.lt     p3, v28, v3
    p.and        p5, p3, p2
    @p4 v.sel        v12, v19, v9
    v.cmp.lt     p3, v30, v3
    p.and        p4, p3, p2
    @p1 v.sel        v9, v31, v12
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #23
    vf.mul       v19, v2, v9
    v.movi       v2, #127
    vf.mul       v9, v19, v4
    v.exp2.approx v22, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v19, v4, v9                // the exact rounding error of x*log2(e)
    v.movi       v9, #25
    vf.mul       v19, v23, v5
    v.movi       v23, #23
    vf.fma       v28, v22, v19, v22              // 2**t * 2**d
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v19, v28, v22
    v.movi       v22, #127
    v.movi       v28, #23
    @p5 v.st.w       [s1, #0], v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v19, [s3, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v0, v32, v4
    v.exp2.approx v30, v0                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v33, v32, v4, v0                // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v0, v19
    vf.mul       v19, v33, v5
    vf.mul       v32, v0, v4
    v.exp2.approx v33, v32                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v0, v4, v32                // the exact rounding error of x*log2(e)
    vf.mul       v0, v34, v5
    vf.fma       v32, v30, v19, v30              // 2**t * 2**d
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v19, v32, v30
    vf.add       v30, v19, v6
    vf.fma       v32, v33, v0, v33               // 2**t * 2**d
    v.add        v0, v30, v12
    v.lshr       v12, v0, v15
    vf.cmp.o     p3, v32, v32
    @p3 v.sel        v0, v32, v33
    v.sub        v15, v12, v2
    vf.neg       v2, v0
    v.min.s      v0, v15, v9
    v.shl        v9, v15, v23
    vf.cvt.s32.f32 v12, v15
    v.sub        v15, v22, v0
    v.sub        v0, v19, v9
    vf.abs       v9, v19
    v.shl        v22, v15, v28
    vf.mul       v15, v12, v14                   // k*ln2_hi, exact
    vf.cmp.eq    p3, v19, v27
    vf.sub       v14, v22, v6
    vf.cmp.lt    p4, v9, v26
    s.addi       s1, s12, #1920                  // row 15
    vf.add       v6, v0, v14                     // f = x*2**-k + (2**-k - 1)
    s.addi       s2, s10, #15
    vf.fma       v9, v17, v6, v13
    vf.sub       v13, v6, v0
    vf.neg       v17, v6
    vf.add       v22, v15, v6
    vf.mul       v23, v6, v6
    vf.fma       v26, v9, v6, v16
    vf.sub       v9, v6, v13
    vf.sub       v16, v14, v13
    vf.sub       v13, v22, v15
    v.splat      v14, s2
    vf.fma       v15, v26, v6, v1
    vf.sub       v1, v0, v9
    vf.sub       v0, v6, v13                     // Fast2Sum
    vf.fma       v9, v15, v6, v8
    vf.add       v8, v1, v16                     // TwoSum: the exact error of f
    vf.fma       v1, v9, v6, v11
    vf.fma       v9, v17, v8, v8                 // f_lo/(1 + f_hi)
    vf.fma       v8, v1, v6, v10
    vf.fma       v1, v12, v24, v9
    vf.fma       v9, v8, v6, v18
    vf.fma       v8, v9, v6, v20
    vf.fma       v9, v8, v6, v21
    vf.fma       v6, v23, v9, v1
    vf.add       v1, v0, v6
    vf.add       v0, v22, v1
    @p4 v.sel        v1, v19, v0
    vf.cmp.lt    p4, v19, v27
    @p3 v.sel        v0, v7, v1
    vf.cmp.eq    p3, v19, v29
    @p4 v.sel        v1, v25, v0
    vf.cmp.uo    p4, v19, v19
    @p3 v.sel        v0, v19, v1
    v.cmp.lt     p3, v14, v3
    p.and        p5, p3, p2
    @p4 v.sel        v1, v19, v0
    @p1 v.sel        v0, v31, v1
    vf.mul       v1, v2, v0
    vf.mul       v0, v1, v4
    v.exp2.approx v2, v0                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v1, v4, v0                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v3, v5
    vf.fma       v1, v2, v0, v2                  // 2**t * 2**d
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v2
    @p5 v.st.w       [s1, #0], v0
__rctx_next:
    exit
