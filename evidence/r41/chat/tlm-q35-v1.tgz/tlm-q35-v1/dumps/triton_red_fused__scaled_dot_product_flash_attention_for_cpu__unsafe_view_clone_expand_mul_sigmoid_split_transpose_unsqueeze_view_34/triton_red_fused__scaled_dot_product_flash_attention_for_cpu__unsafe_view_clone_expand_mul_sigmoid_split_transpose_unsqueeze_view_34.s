    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // out_ptr1: device_ptr64 at arg_base+40
    s.movz       s1, #1
    s.rdspecial  s9, arg_base
    s.ld.d       s10, [s9, #64]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s9, role_id
    s.movz       s11, #256
    s.mul        s12, s9, s11
    s.add        s9, s10, s12                    // this context's own scratch
    s.addi       s10, s9, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s9, #0
    s.st.d       [s10, #0], s3
    s.movz       s9, #16
    s.st.d       [s10, #8], s9
    s.movz       s9, #64
    s.st.d       [s10, #16], s9
    s.movz       s9, #256
    s.st.d       [s10, #48], s9
    s.movz       s9, #4
    s.st.d       [s10, #56], s9
    .li       s9, #68719476737
    s.st.d       [s10, #88], s9
    .li       s9, #2207613190144
    s.st.d       [s10, #104], s9
    fence.release.device
    td.load      d0, [s10]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s9, #1
    s.movz       s10, #0
    s.movz       s11, #64
    s.movz       s12, #16
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #256
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v4, v3, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v4, #8
    v.lshr       v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s1
    v.cmp.lt     p1, v4, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v4, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    v.cmp.ne     p1, v4, v5
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s9
    v.cmp.lt     p2, v4, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s5, v3]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    v.movi       v6, #1
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #255
    v.and        v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    s.addi       s1, s10, #0
    v.movi       v0, #0
    v.movi       v6, #0
    v.mov        v6, v0
for_1:
    s.cmp.ge     s2, s1, s11
    br.nz        s2, endfor_2
    s.movz       s2, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s2
    s.movz       s2, #256
    s.sub        s10, s5, s9
    s.movz       s5, #0
    s.movz       s9, #0
    s.cmp.lt     s13, s2, s5
    s.xor        s5, s4, s10
    s.sub        s14, s9, s13
    s.sub        s9, s5, s10
    s.xor        s5, s10, s14
    s.lshri      s10, s9, #8
    v.splat      v7, s1
    s.xor        s13, s10, s5
    v.iota       v8                              // arange(0, VLEN)
    s.sub        s15, s13, s5
    s.movz       s5, #64
    s.movz       s13, #16
    s.muli       s16, s15, #256
    v.add        v9, v7, v8
    v.movi       v7, #0
    v.splat      v8, s5
    v.splat      v10, s15
    v.movi       v11, #0
    v.splat      v12, s13
    s.muli       s5, s1, #4
    v.cmp.ge     p2, v9, v7
    v.cmp.lt     p3, v9, v8
    v.cmp.ge     p4, v10, v11
    v.cmp.lt     p5, v10, v12
    s.add        s13, s3, s16
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.add        s15, s13, s5
    p.and        p3, p6, p2
    v.splat      v7, s1
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s15, #0]
    v.movi       v9, #256
    v.add        v10, v7, v1
    v.extract    s5, v5, #0
    v.movi       v7, #64
    v.mul        v11, v10, v9
    v.splat      v9, s5
    v.cmp.lt     p2, v10, v7
    v.movi       v7, #0
    v.movi       v10, #2
    v.add        v12, v9, v11
    v.sub        v9, v7, v3
    v.cmp.lt     p3, v3, v7
    v.movi       v11, #4
    @p3 v.sel        v13, v9, v3
    s.muli       s5, s10, #256
    v.sub        v9, v7, v11
    v.lshr       v14, v13, v10
    s.xor        s10, s2, s14
    v.cmp.lt     p4, v11, v7
    v.sub        v10, v7, v14
    s.sub        s2, s10, s14
    v.movi       v7, #16384
    @p3 v.sel        v13, v10, v14
    s.sub        s2, s9, s5
    v.extract    s2, v4, #0
    .li       s5, #1065353216
    v.splat      v10, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v14, s2
    v.mul        v15, v13, v7
    v.movi       v7, #1
    v.rcp.approx v13, v14                        // ISA 8.8: <= 2**-22 relative
    v.extract    s2, v15, #0
    v.movi       v15, #0
    v.splat      v16, s2
    v.movi       v17, #0
    @p1 v.sel        v18, v7, v15
    v.add        v7, v12, v16
    v.movi       v12, #1
    v.movi       v15, #0
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v16, [s6, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.eq     p3, v18, v17
    @p3 v.sel        v7, v12, v15
    v.movi       v12, #0
    v.movi       v15, #1
    v.extract    s2, v7, #0
    v.movi       v7, #0
    v.splat      v15, s2
    s.add        s2, s1, s12
    @p4 v.sel        v17, v9, v11
    v.cmp.ne     p3, v15, v12
    s.movz       s5, #1
    s.movz       s9, #16384
    vf.cvt.bf16.f32 v9, v16
    vf.fms       v11, v14, v13, v10
    vf.fms       v10, v13, v11, v13
    vf.neg       v11, v10                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v11, v11
    @p4 v.sel        v10, v11, v13
    vf.mul       v11, v8, v10                    // a/y: faithful quotient
    vf.fms       v12, v11, v14, v8
    vf.fms       v8, v12, v10, v11
    vf.neg       v10, v8                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v10, v10
    @p4 v.sel        v8, v10, v11
    @p3 v.sel        v10, v0, v8
    vf.mul       v8, v10, v9
    vf.add       v9, v6, v8
    @p2 v.sel        v8, v9, v6
    v.mov        v7, v8
    v.mov        v6, v7
    s.mov        s1, s2
    br.nz        s5, for_1
endfor_2:
    v.movi       v0, #512
    s.movz       s1, #1
    v.iota       v1                              // arange(0, VLEN)
    v.mul        v4, v3, v0
    v.splat      v0, s1
    .li       s1, #1069066811
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v7, v4, v2
    v.cmp.lt     p1, v1, v0
    .li       s1, #1060205080
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v1, v7, v5
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v5, [s7, v1]               // index is in elements (ISA sec 9.1)
    vf.reduce.add.b v1, v6
    v.movi       v6, #0
    s.movz       s1, #1
    s.shli       s2, s4, #1                      // element offset -> bytes (x2)
    vf.add       v7, v1, v6
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v6, s1
    s.add        s1, s8, s2                      // &out_ptr1[...]
    s.movz       s2, #512
    v.cmp.lt     p1, v1, v6
    s.movz       s2, #256
    vf.cvt.bf16.f32 v1, v5
    vf.neg       v5, v1
    vf.mul       v1, v5, v3
    v.exp2.approx v6, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v1                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v8, v0
    vf.fma       v0, v6, v1, v6                  // 2**t * 2**d
    vf.cmp.o     p2, v0, v0
    @p2 v.sel        v1, v0, v6
    vf.add       v0, v1, v2
    v.rcp.approx v1, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v0, v1, v4
    vf.fms       v4, v1, v3, v1
    vf.neg       v3, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v4, v3, v1
    vf.mul       v1, v2, v4                      // a/y: faithful quotient
    vf.fms       v3, v1, v0, v2
    vf.fms       v0, v3, v4, v1
    vf.neg       v2, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v0, v2, v1
    vf.mul       v1, v7, v0
    vf.cvt.f32.bf16 v0, v1
    @p1 v.st.h       [s1, #0], v0
__rctx_next:
    exit
