
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 90624}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_7(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 4)
    x2 = xindex // 512
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (x0 + 128*x2 + 2048*x1), None).to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x2 + 16*x1), None, eviction_policy='evict_last')
    tmp27 = tl.load(in_ptr3 + (64*x1 + ((x0 % 64))), None, eviction_policy='evict_last')
    tmp32 = tl.load(in_ptr4 + (x4), None).to(tl.float32)
    tmp34 = tl.load(in_ptr5 + (64*x1 + ((x0 % 64))), None, eviction_policy='evict_last')
    tmp2 = tmp1.to(tl.float32)
    tmp4 = tl.full([1], 128.0, tl.float32)
    tmp5 = (tmp3 / tmp4)
    tmp6 = tl.full([1], 1e-06, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = libdevice.rsqrt(tmp7)
    tmp9 = tmp2 * tmp8
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tmp0 * tmp10
    tmp12 = tl.full([1], 0, tl.int32)
    tmp13 = tmp12 == tmp12
    tmp14 = ((x4 % 64)).to(tl.int64)
    tmp15 = (tmp14).to(tl.int64)
    tmp16 = tl.full([1], 2, tl.int64)
    tmp17 = tmp15 >= tmp16
    tmp18 = tl.full([1], 60, tl.int64)
    tmp19 = tmp15 < tmp18
    tmp20 = ((((-2) + ((x0 % 64))) % 3)).to(tl.int64)
    tmp21 = (tmp20).to(tl.int64)
    tmp22 = tl.full([1], 0, tl.int64)
    tmp23 = tmp21 == tmp22
    tmp24 = tmp17 & tmp19
    tmp25 = tmp24 & tmp23
    tmp26 = tl.load(in_ptr3 + (514 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 64)),  3)) + 64*x1), tmp25, eviction_policy='evict_last', other=0.0)
    tmp28 = tl.where(tmp25, tmp26, tmp27)
    tmp29 = tl.where(tmp13, tmp28, tmp27)
    tmp30 = tmp29.to(tl.float32)
    tmp31 = tmp11 * tmp30
    tmp33 = tl.load(in_ptr5 + (514 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 64)),  3)) + 64*x1), tmp25, eviction_policy='evict_last', other=0.0)
    tmp35 = tl.where(tmp25, tmp33, tmp34)
    tmp36 = tl.where(tmp13, tmp35, tmp34)
    tmp37 = tmp36.to(tl.float32)
    tmp38 = tmp32 * tmp37
    tmp39 = tmp31 + tmp38
    tmp40 = tmp39.to(tl.float32)
    tmp41 = tl.full([1], 0.29730177875068026, tl.float32)
    tmp42 = tmp40 * tmp41
    tl.store(out_ptr0 + (x4), tmp42, None)
