
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 2704}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 256*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp30 = tl.load(in_ptr3 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp35 = tl.load(in_ptr4 + (x2), xmask).to(tl.float32)
    tmp37 = tl.load(in_ptr5 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp15 = tl.full([1], 0, tl.int32)
    tmp16 = tmp15 == tmp15
    tmp17 = ((x2 % 32)).to(tl.int64)
    tmp18 = (tmp17).to(tl.int64)
    tmp19 = tl.full([1], 2, tl.int64)
    tmp20 = tmp18 >= tmp19
    tmp21 = tl.full([1], 30, tl.int64)
    tmp22 = tmp18 < tmp21
    tmp23 = ((((-2) + ((x0 % 32))) % 3)).to(tl.int64)
    tmp24 = (tmp23).to(tl.int64)
    tmp25 = tl.full([1], 0, tl.int64)
    tmp26 = tmp24 == tmp25
    tmp27 = tmp20 & tmp22
    tmp28 = tmp27 & tmp26
    tmp29 = tl.load(in_ptr3 + (66 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 32)),  3))), tmp28 & xmask, eviction_policy='evict_last', other=0.0)
    tmp31 = tl.where(tmp28, tmp29, tmp30)
    tmp32 = tl.where(tmp16, tmp31, tmp30)
    tmp33 = tmp32.to(tl.float32)
    tmp34 = tmp14 * tmp33
    tmp36 = tl.load(in_ptr5 + (66 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 32)),  3))), tmp28 & xmask, eviction_policy='evict_last', other=0.0)
    tmp38 = tl.where(tmp28, tmp36, tmp37)
    tmp39 = tl.where(tmp16, tmp38, tmp37)
    tmp40 = tmp39.to(tl.float32)
    tmp41 = tmp35 * tmp40
    tmp42 = tmp34 + tmp41
    tl.store(out_ptr0 + (x0 + 256*x1), tmp42, xmask)
