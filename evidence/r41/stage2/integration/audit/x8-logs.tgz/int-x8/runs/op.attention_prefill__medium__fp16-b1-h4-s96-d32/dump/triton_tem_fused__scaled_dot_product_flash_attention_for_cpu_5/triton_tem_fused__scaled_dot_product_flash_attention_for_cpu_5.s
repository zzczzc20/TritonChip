    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #2
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #1
    s.movz       s6, #6
    s.xor        s8, s5, s3
    s.movz       s9, #1
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s6, #0
    s.min.s      s11, s8, s9
    s.movz       s8, #0
    s.cmp.lt     s9, s11, s3
    s.movz       s3, #0
    s.cmp.lt     s12, s4, s6
    s.sub        s6, s8, s9
    s.sub        s8, s3, s12
    s.xor        s3, s11, s6
    s.muli       s9, s5, #2
    s.movz       s5, #0
    s.movz       s12, #1
    s.xor        s13, s4, s8
    s.sub        s14, s3, s6
    s.rdspecial  s3, arg_base
    s.xor        s6, s1, s7
    s.movz       s15, #0
    s.sub        s16, s13, s8
    s.addi       s13, s5, #0
    s.cmp.eq     s5, s14, s12
    s.ld.d       s12, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s6, s7
    s.sub        s6, s2, s9
    s.ld.d       s2, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.addi       s6, s15, #0
    s.ld.d       s7, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s13, s16
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s13, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s16, s3
    s.shli       s9, s6, #1
    s.andi       s15, s5, #1
    s.movz       s5, #0
    s.or         s17, s9, s15
    s.movz       s9, #1
    s.cmp.geu    s15, s17, s14
    s.shl        s18, s9, s3
    s.sub        s9, s5, s15
    s.subi       s5, s3, #1
    s.and        s15, s14, s9
    s.and        s19, s18, s9
    s.sub        s9, s17, s15
    s.or         s15, s13, s19
    s.mov        s6, s9
    s.mov        s13, s15
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s3, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s3
    s.movz       s3, #0
    s.sub        s13, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s13
    s.movz       s4, #0
    s.sub        s14, s9, s13
    s.cmp.lt     s9, s11, s3
    s.lshri      s3, s14, #1
    s.movz       s15, #0
    s.muli       s16, s3, #2
    s.sub        s3, s4, s9
    s.movz       s4, #0
    s.cmp.lt     s9, s1, s15
    s.xor        s15, s11, s3
    s.sub        s11, s14, s16
    s.movz       s14, #0
    s.xor        s16, s11, s13
    s.xor        s11, s6, s8
    s.sub        s6, s16, s13
    s.sub        s13, s14, s9
    s.cmp.lt     s9, s6, s5
    s.sub        s5, s15, s3
    s.sub        s14, s4, s9
    s.movz       s4, #0
    s.xor        s9, s6, s14
    s.movz       s6, #1
    s.sub        s15, s11, s8
    s.xor        s8, s1, s13
    s.sub        s1, s9, s14
    s.movz       s9, #0
    s.addi       s11, s4, #0
    s.cmp.eq     s4, s5, s6
    s.add        s6, s10, s15
    s.sub        s10, s8, s13
    s.addi       s8, s9, #0
    s.mov        s11, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s9, #31
    s.mov        s11, s4
    s.addi       s4, s9, #0
sdiv_4:
    s.lshr       s9, s1, s4
    s.shli       s10, s8, #1
    s.andi       s13, s9, #1
    s.movz       s9, #0
    s.or         s15, s10, s13
    s.movz       s10, #1
    s.cmp.geu    s13, s15, s5
    s.shl        s16, s10, s4
    s.sub        s10, s9, s13
    s.subi       s9, s4, #1
    s.and        s13, s5, s10
    s.and        s17, s16, s10
    s.sub        s10, s15, s13
    s.or         s13, s11, s17
    s.mov        s8, s10
    s.mov        s11, s13
    s.mov        s4, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s4, s9
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.movz       s1, #16
    .li       s4, #1431655766
    s.mul        s5, s6, s1
    s.rdspecial  s8, pid.z
    s.rdspecial  s9, npid.y
    s.xor        s10, s14, s3
    s.mul        s3, s8, s9
    s.mul        s8, s5, s4
    s.xor        s4, s11, s10
    s.rdspecial  s9, pid.y
    s.sub        s11, s4, s10
    s.add        s4, s9, s3
    s.lshri      s3, s8, #32
    s.mul        s8, s11, s1
    s.sub        s9, s5, s3
    s.movz       s10, #3
    s.lshri      s13, s9, #1
    s.min.s      s9, s4, s10
    s.add        s10, s3, s13
    s.movz       s3, #9216
    s.lshri      s13, s10, #6
    s.movz       s10, #3072
    s.muli       s14, s13, #96
    s.mul        s13, s9, s3
    s.mul        s3, s9, s10
    s.rdspecial  s9, role_id
    s.movz       s15, #6144
    s.sub        s16, s5, s14
    s.andi       s14, s8, #31
    s.rdspecial  s17, arg_base
    s.movz       s18, #0
    s.ld.d       s19, [s17, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v0, s6
    s.mul        s6, s9, s15
    v.splat      v1, s18
    v.splat      v2, s11
    v.splat      v3, s18
    v.iota       v4                              // arange(0, VLEN)
    s.add        s9, s19, s6                     // this context's own scratch
    v.splat      v5, s5
    s.addi       s6, s9, #0
    v.cmp.ge     p1, v0, v1
    s.muli       s11, s16, #96                   // a runtime tile origin, x96
    s.movz       s15, #0
    v.splat      v0, s8
    v.splat      v1, s16
    v.cmp.ge     p1, v2, v3
    s.add        s16, s15, s11                   // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    s.add        s11, s16, s13                   // the tile origin
    v.iota       v3                              // arange(0, VLEN)
    v.add        v6, v5, v4
    s.addi       s13, s11, #96
    v.splat      v5, s11
    s.addi       s15, s6, #64
    v.add        v6, v2, v5
    v.add        v5, v0, v4
    s.addi       s16, s11, #192
    s.addi       s17, s11, #288
    v.splat      v0, s13
    v.splat      v4, s16
    v.add        v5, v2, v0
    s.addi       s13, s6, #128
    v.add        v0, v2, v4
    s.addi       s16, s6, #192
    v.add        v4, v1, v3
    s.addi       s19, s11, #384
    v.splat      v1, s17
    v.splat      v3, s14
    v.add        v4, v2, v1
    s.addi       s17, s6, #256
    s.movz       s20, #96
    s.addi       s21, s18, #0
    v.st.w       [s6, #0], v6
    v.splat      v1, s19
    v.st.w       [s15, #0], v5
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v2, v1
    v.add        v1, v3, v5
    s.addi       s15, s11, #480
    s.addi       s18, s11, #576
    s.addi       s19, s11, #672
    v.splat      v1, s15
    s.addi       s15, s11, #768
    v.splat      v3, s18
    s.addi       s18, s11, #864
    v.add        v5, v2, v1
    v.add        v1, v2, v3
    v.st.w       [s13, #0], v0
    s.addi       s13, s11, #960
    v.splat      v0, s19
    s.addi       s19, s11, #1056
    v.add        v3, v2, v0
    v.st.w       [s16, #0], v4
    s.addi       s16, s11, #1152
    v.splat      v0, s15
    s.addi       s15, s11, #1248
    v.add        v4, v2, v0
    v.st.w       [s17, #0], v6
    s.addi       s17, s11, #1344
    v.splat      v0, s18
    s.addi       s18, s6, #320
    s.addi       s22, s11, #1440
    v.add        v6, v2, v0
    v.st.w       [s18, #0], v5
    v.splat      v0, s13
    s.addi       s11, s6, #384
    s.addi       s13, s9, #1024
    v.add        v5, v2, v0
    v.st.w       [s11, #0], v1
    s.movz       s11, #0
    v.splat      v0, s19
    s.addi       s18, s6, #448
    s.add        s19, s11, s14                   // the tile origin
    s.addi       s11, s6, #512
    s.add        s14, s19, s3                    // the tile origin
    s.addi       s3, s6, #576
    v.add        v1, v2, v0
    v.st.w       [s18, #0], v3
    s.addi       s18, s14, #32
    v.splat      v0, s16
    s.addi       s16, s6, #640
    v.add        v3, v2, v0
    v.st.w       [s11, #0], v4
    s.addi       s11, s14, #64
    v.splat      v0, s15
    s.addi       s15, s6, #704
    v.add        v4, v2, v0
    v.st.w       [s3, #0], v6
    s.addi       s3, s14, #96
    v.splat      v0, s17
    s.addi       s17, s6, #768
    v.add        v6, v2, v0
    v.st.w       [s16, #0], v5
    s.addi       s16, s14, #128
    v.splat      v0, s22
    s.addi       s19, s6, #832
    v.add        v5, v2, v0
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #160
    v.splat      v0, s14
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v3
    s.addi       s17, s14, #192
    v.splat      v0, s18
    s.addi       s18, s6, #896
    s.addi       s22, s6, #960
    v.add        v3, v2, v0
    v.st.w       [s19, #0], v4
    s.addi       s6, s14, #224
    v.splat      v0, s11
    s.addi       s11, s13, #64
    v.add        v4, v2, v0
    v.st.w       [s18, #0], v6
    s.addi       s18, s14, #256
    v.splat      v0, s3
    s.addi       s3, s13, #128
    v.add        v6, v2, v0
    v.st.w       [s22, #0], v5
    v.splat      v0, s16
    s.addi       s16, s13, #192
    s.addi       s19, s13, #256
    v.add        v5, v2, v0
    fence.acq_rel.device
    v.st.w       [s13, #0], v1
    v.splat      v0, s15
    s.addi       s15, s14, #288
    v.add        v1, v2, v0
    v.st.w       [s11, #0], v3
    s.addi       s11, s14, #320
    v.splat      v0, s17
    s.addi       s17, s14, #352
    v.add        v3, v2, v0
    v.st.w       [s3, #0], v4
    s.addi       s3, s14, #384
    v.splat      v0, s6
    s.addi       s6, s14, #416
    v.add        v4, v2, v0
    v.st.w       [s16, #0], v6
    s.addi       s16, s14, #448
    v.splat      v0, s18
    s.addi       s18, s13, #320
    v.add        v6, v2, v0
    v.st.w       [s19, #0], v5
    s.addi       s19, s14, #480
    v.splat      v0, s15
    s.addi       s14, s13, #384
    s.addi       s15, s13, #448
    v.add        v5, v2, v0
    v.st.w       [s18, #0], v1
    v.splat      v0, s11
    s.addi       s11, s13, #512
    s.addi       s18, s13, #576
    v.add        v1, v2, v0
    v.st.w       [s14, #0], v3
    v.splat      v0, s17
    s.addi       s14, s13, #640
    s.addi       s17, s13, #704
    v.add        v3, v2, v0
    v.st.w       [s15, #0], v4
    v.splat      v0, s3
    s.addi       s3, s13, #768
    v.add        v4, v2, v0
    s.addi       s15, s13, #832
    v.st.w       [s11, #0], v6
    v.splat      v0, s6
    s.addi       s6, s13, #896
    v.add        v6, v2, v0
    s.addi       s11, s13, #960
    v.st.w       [s18, #0], v5
    v.splat      v0, s16
    v.add        v5, v2, v0
    v.st.w       [s14, #0], v1
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v3
    v.st.w       [s3, #0], v4
    v.st.w       [s15, #0], v6
    v.st.w       [s6, #0], v5
    v.st.w       [s11, #0], v1
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s3, s21, s20
    br.nz        s3, endfor_6
    s.addi       s3, s9, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s9, #64
    s.movz       s11, #1
    s.addi       s13, s9, #128
    s.movz       s14, #2
    s.addi       s15, s9, #192
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v1
    v.ld.w       v0, [s3, #0]
    s.movz       s3, #3
    s.addi       s6, s9, #256
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s11, v1
    v.ld.w       v0, [s13, #0]
    s.movz       s11, #4
    s.addi       s13, s9, #320
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v1
    v.ld.w       v0, [s15, #0]
    s.movz       s14, #5
    s.addi       s15, s9, #384
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v1
    v.ld.w       v0, [s6, #0]
    s.movz       s3, #6
    s.addi       s6, s9, #448
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s11, v1
    v.ld.w       v0, [s13, #0]
    s.movz       s11, #7
    s.addi       s13, s9, #512
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v1
    v.ld.w       v0, [s15, #0]
    s.movz       s14, #8
    s.addi       s15, s9, #576
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v1
    v.ld.w       v0, [s6, #0]
    s.movz       s3, #9
    s.addi       s6, s9, #640
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s11, v1
    v.ld.w       v0, [s13, #0]
    s.movz       s11, #10
    s.addi       s13, s9, #704
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v1
    v.ld.w       v0, [s15, #0]
    s.movz       s14, #11
    s.addi       s15, s9, #768
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v1
    v.ld.w       v0, [s6, #0]
    s.movz       s3, #12
    s.addi       s6, s9, #832
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s11, v1
    v.ld.w       v0, [s13, #0]
    s.movz       s11, #13
    s.addi       s13, s9, #896
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v1
    v.ld.w       v0, [s15, #0]
    s.movz       s14, #14
    s.addi       s15, s9, #960
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v1
    v.ld.w       v0, [s6, #0]
    s.movz       s3, #15
    s.addi       s6, s9, #1024
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s11, v1
    v.ld.w       v0, [s13, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s11, #0
    s.addi       s13, s9, #1088
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v1
    v.ld.w       v0, [s15, #0]
    s.movz       s14, #1
    s.addi       s15, s9, #1152
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    s.movz       s16, #2
    a.vwrite     a1, s3, v1
    v.ld.w       v0, [s6, #0]
    s.addi       s3, s9, #1216
    s.movz       s6, #3
    v.ld.gather.w v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s11, v1
    v.ld.w       v0, [s13, #0]
    s.addi       s11, s9, #1280
    s.movz       s13, #4
    v.ld.gather.w v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v1
    v.ld.w       v0, [s15, #0]
    s.addi       s14, s9, #1344
    s.movz       s15, #5
    v.ld.gather.w v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v1
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s9, #1408
    s.movz       s16, #6
    v.ld.gather.w v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s6, v1
    v.ld.w       v0, [s11, #0]
    s.addi       s6, s9, #1472
    s.movz       s11, #7
    v.ld.gather.w v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v1
    v.ld.w       v0, [s14, #0]
    s.addi       s13, s9, #1536
    s.movz       s14, #8
    v.ld.gather.w v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v1
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s9, #1600
    s.movz       s15, #9
    v.movi       v1, #0
    v.ld.gather.w v3, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s9, #1664
    s.movz       s16, #10
    v.ld.gather.w v3, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s11, v3
    v.ld.w       v0, [s13, #0]
    s.addi       s11, s9, #1728
    s.movz       s13, #11
    v.ld.gather.w v3, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s9, #1792
    s.movz       s14, #12
    v.ld.gather.w v3, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s9, #1856
    s.movz       s15, #13
    v.ld.gather.w v3, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s9, #1920
    s.movz       s16, #14
    v.ld.gather.w v3, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v3
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s9, #1984
    s.movz       s13, #15
    v.ld.gather.w v3, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v0, [s6, #0]
    s.movz       s6, #0
    s.movz       s14, #0
    v.ld.gather.w v3, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v0, [s11, #0]
    s.movz       s11, #1
    s.movz       s15, #2
    v.ld.gather.w v3, [s2, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v0, [s3, #0]
    s.movz       s3, #3
    s.movz       s16, #4
    v.ld.gather.w v3, [s2, v0]                   // index is in elements (ISA sec 9.1)
    s.movz       s17, #5
    a.vwrite     a2, s13, v3
    a.vread      v0, a1, s6
    a.vread      v3, a2, s14
    v.extract    s6, v0, #0
    v.splat      v4, s6
    v.extract    s6, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s6
    a.vread      v4, a2, s11
    v.extract    s6, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s6
    a.vread      v4, a2, s15
    v.extract    s6, v0, #3
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    v.extract    s3, v0, #4
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    v.extract    s3, v0, #5
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s3
    a.vread      v4, a2, s17
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s3, #0
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #1
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #1
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #2
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #2
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #3
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #4
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #5
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #6
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #7
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #8
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #9
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #9
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #10
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #10
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #11
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #11
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #12
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #12
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #13
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #13
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #14
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v3, s3
    a.vread      v4, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #3
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #4
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #5
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #6
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v0, #7
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v0, #8
    v.splat      v3, s6
    a.vread      v4, a2, s3
    s.movz       s3, #14
    vf.fma       v5, v3, v4, v6
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #10
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #11
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #12
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #13
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v0, #14
    v.splat      v3, s11
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v3, a2, s6
    s.movz       s6, #15
    vf.fma       v4, v0, v3, v5
    s.movz       s11, #0
    s.movz       s13, #1
    s.movz       s14, #2
    a.vwrite     a3, s3, v4
    a.vread      v0, a1, s6
    a.vread      v3, a2, s11
    v.extract    s3, v0, #0
    v.splat      v4, s3
    v.extract    s3, v0, #1
    vf.fma       v5, v4, v3, v1
    v.splat      v1, s3
    a.vread      v3, a2, s13
    v.extract    s3, v0, #2
    vf.fma       v4, v1, v3, v5
    v.splat      v1, s3
    a.vread      v3, a2, s14
    s.movz       s3, #3
    vf.fma       v5, v1, v3, v4
    v.extract    s6, v0, #3
    v.splat      v1, s6
    a.vread      v3, a2, s3
    s.movz       s3, #4
    vf.fma       v4, v1, v3, v5
    v.extract    s6, v0, #4
    v.splat      v1, s6
    a.vread      v3, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v1, v3, v4
    v.extract    s6, v0, #5
    v.splat      v1, s6
    a.vread      v3, a2, s3
    s.movz       s3, #6
    vf.fma       v4, v1, v3, v5
    v.extract    s6, v0, #6
    v.splat      v1, s6
    a.vread      v3, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v1, v3, v4
    v.extract    s6, v0, #7
    v.splat      v1, s6
    a.vread      v3, a2, s3
    s.movz       s3, #8
    vf.fma       v4, v1, v3, v5
    v.extract    s6, v0, #8
    v.splat      v1, s6
    a.vread      v3, a2, s3
    s.movz       s3, #15
    vf.fma       v5, v1, v3, v4
    s.movz       s6, #9
    v.extract    s11, v0, #9
    v.splat      v1, s11
    a.vread      v3, a2, s6
    s.movz       s6, #10
    vf.fma       v4, v1, v3, v5
    v.extract    s11, v0, #10
    v.splat      v1, s11
    a.vread      v3, a2, s6
    s.movz       s6, #11
    vf.fma       v5, v1, v3, v4
    v.extract    s11, v0, #11
    v.splat      v1, s11
    a.vread      v3, a2, s6
    s.movz       s6, #12
    vf.fma       v4, v1, v3, v5
    v.extract    s11, v0, #12
    v.splat      v1, s11
    a.vread      v3, a2, s6
    s.movz       s6, #13
    vf.fma       v5, v1, v3, v4
    v.extract    s11, v0, #13
    v.splat      v1, s11
    a.vread      v3, a2, s6
    s.movz       s6, #14
    vf.fma       v4, v1, v3, v5
    v.extract    s11, v0, #14
    v.splat      v1, s11
    a.vread      v3, a2, s6
    s.movz       s6, #15
    vf.fma       v5, v1, v3, v4
    v.extract    s11, v0, #15
    v.splat      v0, s11
    a.vread      v1, a2, s6
    s.addi       s6, s9, #0
    vf.fma       v3, v0, v1, v5
    v.splat      v0, s1
    s.addi       s11, s9, #2048
    s.addi       s13, s9, #64
    a.vwrite     a3, s3, v3
    v.ld.w       v1, [s6, #0]
    s.addi       s3, s11, #64
    s.addi       s6, s9, #128
    s.addi       s14, s11, #128
    s.addi       s15, s9, #192
    s.addi       s16, s11, #192
    s.addi       s17, s9, #256
    v.add        v3, v1, v0
    v.st.w       [s11, #0], v3
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s11, #256
    v.add        v3, v1, v0
    v.st.w       [s3, #0], v3
    s.addi       s3, s9, #320
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s11, #320
    v.add        v3, v1, v0
    v.st.w       [s14, #0], v3
    s.addi       s14, s9, #384
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s11, #384
    v.add        v3, v1, v0
    v.st.w       [s16, #0], v3
    s.addi       s16, s9, #448
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s11, #448
    v.add        v3, v1, v0
    v.st.w       [s13, #0], v3
    s.addi       s13, s9, #512
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s11, #512
    v.add        v3, v1, v0
    v.st.w       [s6, #0], v3
    s.addi       s6, s9, #576
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s11, #576
    v.add        v3, v1, v0
    v.st.w       [s15, #0], v3
    s.addi       s15, s9, #640
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s11, #640
    v.add        v3, v1, v0
    v.st.w       [s17, #0], v3
    s.addi       s17, s9, #704
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s11, #704
    v.add        v3, v1, v0
    v.st.w       [s3, #0], v3
    s.addi       s3, s9, #768
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s11, #768
    v.add        v3, v1, v0
    v.st.w       [s14, #0], v3
    s.addi       s14, s9, #832
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s11, #832
    v.add        v3, v1, v0
    v.st.w       [s16, #0], v3
    s.addi       s16, s9, #896
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s11, #896
    s.addi       s18, s11, #960
    v.add        v3, v1, v0
    v.st.w       [s13, #0], v3
    s.addi       s11, s9, #960
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s9, #1024
    v.add        v3, v1, v0
    v.st.w       [s6, #0], v3
    s.movz       s6, #512
    v.splat      v1, s6
    s.addi       s6, s9, #3072
    v.ld.w       v3, [s14, #0]
    s.addi       s13, s9, #1088
    v.add        v4, v3, v0
    v.st.w       [s15, #0], v4
    s.addi       s14, s6, #64
    v.ld.w       v3, [s16, #0]
    s.addi       s15, s9, #1152
    v.add        v4, v3, v0
    v.st.w       [s17, #0], v4
    s.addi       s16, s6, #128
    v.ld.w       v3, [s11, #0]
    s.addi       s11, s9, #1216
    v.add        v4, v3, v0
    v.st.w       [s18, #0], v4
    fence.acq_rel.device
    s.addi       s17, s6, #192
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s9, #1280
    v.add        v3, v0, v1
    v.st.w       [s6, #0], v3
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s6, #256
    v.add        v3, v0, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s9, #1344
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s6, #320
    v.add        v3, v0, v1
    v.st.w       [s16, #0], v3
    s.addi       s16, s9, #1408
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s6, #384
    v.add        v3, v0, v1
    v.st.w       [s17, #0], v3
    s.addi       s17, s9, #1472
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s6, #448
    v.add        v3, v0, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s9, #1536
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s6, #512
    v.add        v3, v0, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s9, #1600
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s6, #576
    v.add        v3, v0, v1
    v.st.w       [s11, #0], v3
    s.addi       s11, s9, #1664
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s6, #640
    v.add        v3, v0, v1
    v.st.w       [s3, #0], v3
    s.addi       s3, s9, #1728
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s6, #704
    v.add        v3, v0, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s9, #1792
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s6, #768
    v.add        v3, v0, v1
    v.st.w       [s16, #0], v3
    s.addi       s16, s9, #1856
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s6, #832
    v.add        v3, v0, v1
    v.st.w       [s17, #0], v3
    s.addi       s17, s9, #1920
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s6, #896
    s.addi       s18, s6, #960
    v.add        v3, v0, v1
    v.st.w       [s13, #0], v3
    s.addi       s6, s9, #1984
    v.ld.w       v0, [s14, #0]
    s.addi       s13, s9, #2048
    v.add        v3, v0, v1
    v.st.w       [s15, #0], v3
    s.addi       s14, s9, #4096
    v.ld.w       v0, [s16, #0]
    s.addi       s15, s9, #2112
    v.add        v3, v0, v1
    v.st.w       [s11, #0], v3
    s.addi       s11, s14, #64
    v.ld.w       v0, [s17, #0]
    s.addi       s16, s9, #2176
    v.add        v3, v0, v1
    v.st.w       [s3, #0], v3
    s.addi       s3, s14, #128
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s9, #2240
    v.add        v3, v0, v1
    v.st.w       [s18, #0], v3
    fence.acq_rel.device
    s.addi       s17, s14, #192
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s9, #2304
    v.st.w       [s14, #0], v0
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #256
    v.st.w       [s11, #0], v0
    s.addi       s11, s9, #2368
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #320
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #2432
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #384
    v.st.w       [s17, #0], v0
    s.addi       s17, s9, #2496
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s14, #448
    v.st.w       [s15, #0], v0
    s.addi       s15, s9, #2560
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s14, #512
    v.st.w       [s16, #0], v0
    s.addi       s16, s9, #2624
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s14, #576
    v.st.w       [s6, #0], v0
    s.addi       s6, s9, #2688
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s14, #640
    v.st.w       [s13, #0], v0
    s.addi       s13, s9, #2752
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #704
    v.st.w       [s11, #0], v0
    s.addi       s11, s9, #2816
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #768
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #2880
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #832
    v.st.w       [s17, #0], v0
    s.addi       s17, s9, #2944
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s14, #896
    s.addi       s18, s14, #960
    v.st.w       [s15, #0], v0
    s.addi       s14, s9, #3008
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s9, #3072
    v.st.w       [s16, #0], v0
    s.addi       s15, s9, #5120
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s9, #3136
    v.st.w       [s6, #0], v0
    s.addi       s6, s15, #64
    v.ld.w       v0, [s17, #0]
    s.addi       s16, s9, #3200
    v.st.w       [s13, #0], v0
    s.addi       s13, s15, #128
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #3264
    v.st.w       [s18, #0], v0
    fence.acq_rel.device
    s.addi       s17, s15, #192
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s9, #3328
    v.st.w       [s15, #0], v0
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s15, #256
    v.st.w       [s6, #0], v0
    s.addi       s6, s9, #3392
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s15, #320
    v.st.w       [s13, #0], v0
    s.addi       s13, s9, #3456
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s15, #384
    v.st.w       [s17, #0], v0
    s.addi       s17, s9, #3520
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s15, #448
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #3584
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s15, #512
    v.st.w       [s16, #0], v0
    s.addi       s16, s9, #3648
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s15, #576
    v.st.w       [s14, #0], v0
    s.addi       s14, s9, #3712
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s15, #640
    v.st.w       [s11, #0], v0
    s.addi       s11, s9, #3776
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s15, #704
    v.st.w       [s6, #0], v0
    s.addi       s6, s9, #3840
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s15, #768
    v.st.w       [s13, #0], v0
    s.addi       s13, s9, #3904
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s15, #832
    v.st.w       [s17, #0], v0
    s.addi       s17, s9, #3968
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s15, #896
    s.addi       s18, s15, #960
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #4032
    v.ld.w       v0, [s6, #0]
    s.movz       s6, #0
    v.st.w       [s16, #0], v0
    s.movz       s15, #0
    v.ld.w       v0, [s13, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s13, #0
    v.st.w       [s14, #0], v0
    s.movz       s14, #1
    v.ld.w       v0, [s17, #0]
    s.movz       s16, #1
    v.st.w       [s11, #0], v0
    s.movz       s11, #1
    v.ld.w       v0, [s3, #0]
    s.movz       s3, #2
    v.st.w       [s18, #0], v0
    fence.acq_rel.device
    a.vread      v0, a0, s6
    a.vread      v1, a3, s15
    s.movz       s6, #2
    vf.add       v3, v0, v1
    s.movz       s15, #2
    s.movz       s17, #3
    a.vwrite     a4, s13, v3
    a.vread      v0, a0, s14
    a.vread      v1, a3, s16
    s.movz       s13, #3
    vf.add       v3, v0, v1
    s.movz       s14, #3
    s.movz       s16, #4
    a.vwrite     a4, s11, v3
    a.vread      v0, a0, s3
    a.vread      v1, a3, s6
    s.movz       s3, #4
    vf.add       v3, v0, v1
    s.movz       s6, #4
    s.movz       s11, #5
    a.vwrite     a4, s15, v3
    a.vread      v0, a0, s17
    a.vread      v1, a3, s13
    s.movz       s13, #5
    vf.add       v3, v0, v1
    s.movz       s15, #5
    s.movz       s17, #6
    a.vwrite     a4, s14, v3
    a.vread      v0, a0, s16
    a.vread      v1, a3, s3
    s.movz       s3, #6
    vf.add       v3, v0, v1
    s.movz       s14, #6
    s.movz       s16, #7
    a.vwrite     a4, s6, v3
    a.vread      v0, a0, s11
    a.vread      v1, a3, s13
    s.movz       s6, #7
    vf.add       v3, v0, v1
    s.movz       s11, #7
    s.movz       s13, #8
    a.vwrite     a4, s15, v3
    a.vread      v0, a0, s17
    a.vread      v1, a3, s3
    s.movz       s3, #8
    vf.add       v3, v0, v1
    s.movz       s15, #8
    s.movz       s17, #9
    a.vwrite     a4, s14, v3
    a.vread      v0, a0, s16
    a.vread      v1, a3, s6
    s.movz       s6, #9
    vf.add       v3, v0, v1
    s.movz       s14, #9
    s.movz       s16, #10
    a.vwrite     a4, s11, v3
    a.vread      v0, a0, s13
    a.vread      v1, a3, s3
    s.movz       s3, #10
    vf.add       v3, v0, v1
    s.movz       s11, #10
    s.movz       s13, #11
    a.vwrite     a4, s15, v3
    a.vread      v0, a0, s17
    a.vread      v1, a3, s6
    s.movz       s6, #11
    vf.add       v3, v0, v1
    s.movz       s15, #11
    s.movz       s17, #12
    a.vwrite     a4, s14, v3
    a.vread      v0, a0, s16
    a.vread      v1, a3, s3
    s.movz       s3, #12
    vf.add       v3, v0, v1
    s.movz       s14, #12
    s.movz       s16, #13
    a.vwrite     a4, s11, v3
    a.vread      v0, a0, s13
    a.vread      v1, a3, s6
    s.movz       s6, #13
    vf.add       v3, v0, v1
    s.movz       s11, #13
    s.movz       s13, #14
    a.vwrite     a4, s15, v3
    a.vread      v0, a0, s17
    a.vread      v1, a3, s3
    s.movz       s3, #14
    vf.add       v3, v0, v1
    s.movz       s15, #14
    s.movz       s17, #15
    a.vwrite     a4, s14, v3
    a.vread      v0, a0, s16
    a.vread      v1, a3, s6
    s.movz       s6, #15
    vf.add       v3, v0, v1
    s.movz       s14, #15
    s.addi       s16, s9, #4096
    a.vwrite     a4, s11, v3
    a.vread      v0, a0, s13
    a.vread      v1, a3, s3
    s.addi       s3, s9, #0
    vf.add       v3, v0, v1
    s.addi       s11, s9, #4160
    s.addi       s13, s9, #64
    a.vwrite     a4, s15, v3
    a.vread      v0, a0, s17
    a.vread      v1, a3, s6
    s.addi       s6, s9, #4224
    vf.add       v3, v0, v1
    s.addi       s15, s9, #128
    s.addi       s17, s9, #4288
    a.vwrite     a4, s14, v3
    v.ld.w       v0, [s16, #0]
    s.addi       s14, s9, #192
    s.addi       s16, s9, #4352
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #256
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s9, #4416
    v.st.w       [s13, #0], v0
    s.addi       s13, s9, #320
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s9, #4480
    v.st.w       [s15, #0], v0
    s.addi       s15, s9, #384
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s9, #4544
    v.st.w       [s14, #0], v0
    s.addi       s14, s9, #448
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s9, #4608
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #512
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s9, #4672
    v.st.w       [s13, #0], v0
    s.addi       s13, s9, #576
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s9, #4736
    v.st.w       [s15, #0], v0
    s.addi       s15, s9, #640
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s9, #4800
    v.st.w       [s14, #0], v0
    s.addi       s14, s9, #704
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s9, #4864
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #768
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s9, #4928
    v.st.w       [s13, #0], v0
    s.addi       s13, s9, #832
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s9, #4992
    v.st.w       [s15, #0], v0
    s.addi       s15, s9, #896
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s9, #5056
    v.st.w       [s14, #0], v0
    s.addi       s14, s9, #960
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s9, #5120
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #1024
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s9, #5184
    v.st.w       [s13, #0], v0
    s.addi       s13, s9, #1088
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s9, #5248
    v.st.w       [s15, #0], v0
    s.addi       s15, s9, #1152
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s9, #5312
    v.st.w       [s14, #0], v0
    fence.acq_rel.device
    s.addi       s14, s9, #1216
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s9, #5376
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #1280
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s9, #5440
    v.st.w       [s13, #0], v0
    s.addi       s13, s9, #1344
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s9, #5504
    v.st.w       [s15, #0], v0
    s.addi       s15, s9, #1408
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s9, #5568
    v.st.w       [s14, #0], v0
    s.addi       s14, s9, #1472
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s9, #5632
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #1536
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s9, #5696
    v.st.w       [s13, #0], v0
    s.addi       s13, s9, #1600
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s9, #5760
    v.st.w       [s15, #0], v0
    s.addi       s15, s9, #1664
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s9, #5824
    v.st.w       [s14, #0], v0
    s.addi       s14, s9, #1728
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s9, #5888
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #1792
    v.ld.w       v0, [s11, #0]
    s.addi       s11, s9, #5952
    v.st.w       [s13, #0], v0
    s.addi       s13, s9, #1856
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s9, #6016
    v.st.w       [s15, #0], v0
    s.addi       s15, s9, #1920
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s9, #6080
    s.addi       s18, s9, #1984
    v.st.w       [s14, #0], v0
    s.movz       s14, #0
    v.ld.w       v0, [s16, #0]
    s.movz       s16, #0
    v.st.w       [s3, #0], v0
    s.movz       s3, #1
    v.ld.w       v0, [s11, #0]
    s.movz       s11, #1
    v.st.w       [s13, #0], v0
    s.movz       s13, #2
    v.ld.w       v0, [s6, #0]
    s.movz       s6, #2
    v.st.w       [s15, #0], v0
    s.movz       s15, #3
    v.ld.w       v0, [s17, #0]
    s.movz       s17, #3
    v.st.w       [s18, #0], v0
    fence.acq_rel.device
    a.vread      v0, a4, s14
    s.movz       s14, #4
    a.vwrite     a0, s16, v0
    a.vread      v0, a4, s3
    s.movz       s3, #4
    a.vwrite     a0, s11, v0
    a.vread      v0, a4, s13
    s.movz       s11, #5
    a.vwrite     a0, s6, v0
    a.vread      v0, a4, s15
    s.movz       s6, #5
    a.vwrite     a0, s17, v0
    a.vread      v0, a4, s14
    s.movz       s13, #6
    a.vwrite     a0, s3, v0
    a.vread      v0, a4, s11
    s.movz       s3, #6
    a.vwrite     a0, s6, v0
    a.vread      v0, a4, s13
    s.movz       s6, #7
    a.vwrite     a0, s3, v0
    s.movz       s3, #7
    a.vread      v0, a4, s6
    s.movz       s6, #8
    a.vwrite     a0, s3, v0
    s.movz       s3, #8
    a.vread      v0, a4, s6
    s.movz       s6, #9
    a.vwrite     a0, s3, v0
    s.movz       s3, #9
    a.vread      v0, a4, s6
    s.movz       s6, #10
    a.vwrite     a0, s3, v0
    s.movz       s3, #10
    a.vread      v0, a4, s6
    s.movz       s6, #11
    a.vwrite     a0, s3, v0
    s.movz       s3, #11
    a.vread      v0, a4, s6
    s.movz       s6, #12
    a.vwrite     a0, s3, v0
    s.movz       s3, #12
    a.vread      v0, a4, s6
    s.movz       s6, #13
    a.vwrite     a0, s3, v0
    s.movz       s3, #13
    a.vread      v0, a4, s6
    s.movz       s6, #14
    a.vwrite     a0, s3, v0
    s.movz       s3, #14
    a.vread      v0, a4, s6
    s.movz       s6, #15
    a.vwrite     a0, s3, v0
    s.movz       s3, #15
    a.vread      v0, a4, s6
    s.add        s6, s21, s1
    s.movz       s11, #1
    a.vwrite     a0, s3, v0
    s.mov        s21, s6
    br.nz        s11, for_5
endfor_6:
    s.movz       s1, #0
    s.mul        s2, s4, s10
    s.muli       s3, s8, #4                      // a runtime tile origin, x4
    s.movz       s6, #0
    s.add        s9, s1, s8                      // the tile origin
    s.muli       s1, s5, #128                    // a runtime tile origin, x128
    s.add        s8, s6, s5                      // the tile origin
    v.splat      v0, s9
    s.movz       s5, #32
    s.movz       s6, #4
    s.muli       s9, s2, #4                      // a runtime tile origin, x4
    v.splat      v1, s8
    v.splat      v3, s20
    v.add        v4, v2, v0
    v.splat      v0, s5
    s.addi       s2, s8, #1
    s.add        s5, s7, s3                      // the tile origin
    v.splat      v2, s4
    v.splat      v5, s6
    v.cmp.lt     p1, v1, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s2
    s.addi       s2, s8, #2
    s.add        s3, s5, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    p.and        p3, p1, p2
    v.cmp.lt     p1, v2, v5
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s2
    s.addi       s2, s8, #3
    s.add        s4, s3, s9                      // the tile origin
    a.vread      v1, a0, s1
    p.and        p5, p3, p1
    s.movz       s1, #1
    p.and        p3, p4, p2
    v.splat      v2, s2
    s.addi       s2, s8, #4
    @p5 v.st.w       [s4, #0], v1
    v.cmp.lt     p4, v0, v3
    a.vread      v0, a0, s1
    s.addi       s1, s4, #128                    // row 1
    p.and        p5, p3, p1
    s.movz       s3, #2
    p.and        p3, p4, p2
    v.splat      v1, s2
    s.addi       s2, s8, #5
    s.addi       s5, s4, #256                    // row 2
    @p5 v.st.w       [s1, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s3
    p.and        p5, p3, p1
    s.movz       s1, #3
    p.and        p3, p4, p2
    v.splat      v2, s2
    s.addi       s2, s8, #6
    s.addi       s3, s4, #384                    // row 3
    p.and        p4, p3, p1
    @p5 v.st.w       [s5, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s1
    s.movz       s1, #4
    p.and        p5, p3, p2
    v.splat      v1, s2
    s.addi       s2, s8, #7
    s.addi       s5, s4, #512                    // row 4
    p.and        p3, p5, p1
    s.movz       s6, #5
    @p4 v.st.w       [s3, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s1
    p.and        p5, p4, p2
    v.splat      v2, s2
    s.addi       s1, s8, #8
    s.addi       s2, s4, #640                    // row 5
    p.and        p4, p5, p1
    s.movz       s3, #6
    v.splat      v4, s1
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s6
    p.and        p5, p3, p2
    s.addi       s1, s8, #9
    s.addi       s5, s4, #768                    // row 6
    p.and        p3, p5, p1
    s.movz       s6, #7
    v.splat      v1, s1
    s.addi       s1, s8, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s3
    p.and        p5, p4, p2
    s.addi       s2, s4, #896                    // row 7
    p.and        p4, p5, p1
    s.movz       s3, #8
    v.splat      v2, s1
    s.addi       s1, s8, #11
    s.addi       s7, s4, #1024                   // row 8
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p3, v4, v3
    a.vread      v0, a0, s6
    p.and        p5, p3, p2
    s.movz       s5, #9
    p.and        p3, p5, p1
    v.splat      v4, s1
    s.addi       s1, s8, #12
    s.addi       s6, s4, #1152                   // row 9
    s.movz       s9, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v1, v3
    a.vread      v0, a0, s3
    p.and        p5, p4, p2
    v.splat      v1, s1
    p.and        p4, p5, p1
    s.addi       s1, s8, #13
    s.addi       s2, s4, #1280                   // row 10
    s.movz       s3, #11
    v.splat      v5, s1
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s5
    p.and        p5, p3, p2
    s.addi       s1, s8, #14
    p.and        p3, p5, p1
    s.addi       s5, s4, #1408                   // row 11
    s.movz       s7, #12
    v.splat      v2, s1
    s.addi       s1, s4, #1536                   // row 12
    @p4 v.st.w       [s6, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    s.addi       s6, s8, #15
    p.and        p4, p5, p1
    s.movz       s8, #13
    v.splat      v4, s6
    s.addi       s6, s4, #1664                   // row 13
    s.movz       s9, #14
    @p3 v.st.w       [s2, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s3
    p.and        p5, p3, p2
    s.addi       s2, s4, #1792                   // row 14
    p.and        p3, p5, p1
    s.movz       s3, #15
    s.addi       s10, s4, #1920                  // row 15
    @p4 v.st.w       [s5, #0], v0
    v.cmp.lt     p4, v5, v3
    a.vread      v0, a0, s7
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s8
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s6, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    p.and        p2, p5, p1
    @p3 v.st.w       [s2, #0], v0
    a.vread      v0, a0, s3
    @p2 v.st.w       [s10, #0], v0
__rctx_next:
    exit
