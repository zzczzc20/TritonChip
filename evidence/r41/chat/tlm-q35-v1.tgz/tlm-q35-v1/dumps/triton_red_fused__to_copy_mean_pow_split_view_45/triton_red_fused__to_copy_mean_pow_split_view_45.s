    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s5, #256
    v.movi       v0, #0
    s.mul        s6, s1, s5
    v.movi       v1, #0
    s.movz       s1, #240
    s.movz       s5, #256
    s.movz       s7, #1024
    s.movz       s8, #2
    .li       s9, #68719476737
    s.ld.d       s10, [s2, #0]                   // in_ptr0: device_ptr64 at arg_base+0
    s.add        s11, s3, s6                     // this context's own scratch
    .li       s3, #1108101562368
    s.addi       s6, s11, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s11, #0
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.ld.d       s11, [s2, #8]                   // out_ptr0: device_ptr64 at arg_base+8
    s.st.d       [s6, #0], s10
    s.st.d       [s6, #8], s1
    s.movz       s1, #0
    s.addi       s2, s1, #0
    s.st.d       [s6, #16], s5
    s.movz       s1, #256
    s.st.d       [s6, #48], s7
    s.movz       s5, #16
    s.st.d       [s6, #56], s8
    s.st.d       [s6, #88], s9
    s.st.d       [s6, #104], s3
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.mov        v1, v0
for_1:
    s.cmp.ge     s3, s2, s1
    br.nz        s3, endfor_2
    v.splat      v0, s2
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s3, #256
    s.movz       s6, #240
    s.muli       s7, s4, #1024
    v.add        v4, v0, v3
    v.movi       v0, #0
    v.splat      v3, s3
    v.splat      v5, s4
    v.movi       v6, #0
    s.muli       s3, s2, #2
    v.cmp.ge     p1, v4, v0
    v.splat      v0, s6
    v.cmp.lt     p2, v4, v3
    v.cmp.ge     p3, v5, v6
    v.cmp.lt     p4, v5, v0
    s.add        s6, s10, s7
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s7, s6, s3
    p.and        p2, p5, p1
    v.splat      v0, s2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v3, [s7, #0]
    v.movi       v4, #256
    v.add        v5, v0, v2
    v.movi       v0, #0
    s.add        s3, s2, s5
    v.cmp.lt     p1, v5, v4
    s.movz       s6, #1
    vf.cvt.bf16.f32 v4, v3
    vf.mul       v3, v4, v4
    vf.add       v4, v1, v3
    @p1 v.sel        v3, v4, v1
    v.mov        v0, v3
    v.mov        v1, v0
    s.mov        s2, s3
    br.nz        s6, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s11, s2                     // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
