    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // in_ptr3: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // in_ptr4: device_ptr64 at arg_base+40
    s.ld.d       s8, [s1, #48]                   // out_ptr1: device_ptr64 at arg_base+48
    v.iota       v0                              // arange(0, VLEN)
    s.ld.d       s1, [s3, #0]                    // one element, not a vector
    v.movi       v1, #0
    v.movi       v2, #0
    v.insert     v1, s1, #0
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #0
    v.insert     v1, s1, #1
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #1
    v.insert     v1, s1, #2
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #2
    v.insert     v1, s1, #3
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #3
    v.insert     v1, s1, #4
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #4
    v.insert     v1, s1, #5
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #5
    v.insert     v1, s1, #6
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #6
    v.insert     v1, s1, #7
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #7
    v.insert     v1, s1, #8
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #8
    v.insert     v1, s1, #9
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #9
    v.insert     v1, s1, #10
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #10
    v.insert     v1, s1, #11
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #11
    v.insert     v1, s1, #12
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #12
    v.insert     v1, s1, #13
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #13
    v.insert     v1, s1, #14
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #14
    v.insert     v1, s1, #15
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #15
    s.rdspecial  s1, arg_base
    s.ld.d       s3, [s1, #64]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s1, s3, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s9, #0
    s.st.d       [s1, #0], s2
    s.movz       s9, #64
    s.st.d       [s1, #8], s9
    s.movz       s9, #2
    s.st.d       [s1, #48], s9
    s.movz       s9, #16
    s.st.d       [s1, #88], s9
    .li       s9, #4294967296
    s.st.d       [s1, #104], s9
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s3, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 1)
    s.movz       s9, #0
    s.st.d       [s1, #0], s5
    s.movz       s9, #64
    s.st.d       [s1, #8], s9
    s.movz       s9, #2
    s.st.d       [s1, #48], s9
    s.movz       s9, #16
    s.st.d       [s1, #88], s9
    .li       s9, #4294967296
    s.st.d       [s1, #104], s9
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s3, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 1)
    s.movz       s3, #0
    s.st.d       [s1, #0], s6
    s.movz       s3, #64
    s.st.d       [s1, #8], s3
    s.movz       s3, #2
    s.st.d       [s1, #48], s3
    s.movz       s3, #16
    s.st.d       [s1, #88], s3
    .li       s3, #4294967296
    s.st.d       [s1, #104], s3
    td.load      d2, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s3, #64
    s.movz       s9, #16
    s.addi       s10, s1, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.mov        v4, v3
for_1:
    s.cmp.ge     s11, s10, s3
    br.nz        s11, endfor_2
    s.muli       s11, s10, #2
    v.splat      v3, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s12, #64
    s.muli       s13, s10, #2
    v.splat      v6, s10
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s14, #64
    s.muli       s15, s10, #2
    v.splat      v8, s10
    v.iota       v9                              // arange(0, VLEN)
    s.movz       s16, #64
    v.add        v10, v3, v5
    v.movi       v3, #0
    v.splat      v5, s12
    v.extract    s12, v2, #0
    s.shli       s17, s12, #32
    v.add        v11, v6, v7
    v.movi       v6, #0
    v.splat      v7, s14
    v.add        v12, v8, v9
    v.movi       v8, #0
    v.splat      v9, s16
    v.extract    s12, v1, #0
    s.or         s14, s12, s17
    v.cmp.ge     p1, v10, v3
    v.cmp.lt     p2, v10, v5
    v.cmp.ge     p3, v11, v6
    v.cmp.lt     p4, v11, v7
    s.add        s12, s2, s11
    p.and        p5, p1, p2
    v.cmp.ge     p1, v12, v8
    s.add        s11, s5, s13
    p.and        p2, p3, p4
    v.cmp.lt     p3, v12, v9
    s.add        s13, s6, s15
    p.and        p4, p1, p3
    v.movi       v3, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v5, [s12, #0]
    v.splat      v6, s10
    s.movz       s12, #0
    v.add        v7, v6, v0
    s.cmp.ge     s15, s14, s12
    v.movi       v6, #64
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v8, [s11, #0]
    v.cmp.lt     p1, v7, v6
    v.extract    s11, v2, #1
    s.shli       s12, s11, #32
    v.extract    s11, v1, #1
    v.extract    s14, v2, #2
    s.or         s16, s11, s12
    s.movz       s11, #0
    s.shli       s12, s14, #32
    v.extract    s14, v1, #2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s13, #0]
    v.insert     v3, s15, #0
    s.cmp.ge     s13, s16, s11
    s.or         s11, s14, s12
    s.movz       s12, #0
    v.insert     v3, s13, #1
    s.cmp.ge     s13, s11, s12
    vf.cvt.f16.f32 v9, v5
    v.extract    s11, v2, #3
    s.shli       s12, s11, #32
    v.extract    s11, v1, #3
    v.extract    s14, v2, #4
    s.or         s15, s11, s12
    s.movz       s11, #0
    s.shli       s12, s14, #32
    v.extract    s14, v1, #4
    v.insert     v3, s13, #2
    s.cmp.ge     s13, s15, s11
    s.or         s11, s14, s12
    s.movz       s12, #0
    v.insert     v3, s13, #3
    vf.cvt.f16.f32 v5, v8
    v.extract    s13, v2, #5
    s.shli       s14, s13, #32
    v.extract    s13, v1, #5
    v.extract    s15, v2, #6
    s.cmp.ge     s16, s11, s12
    s.or         s11, s13, s14
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v1, #6
    v.insert     v3, s16, #4
    s.cmp.ge     s15, s11, s12
    s.or         s11, s14, s13
    v.insert     v3, s15, #5
    vf.cvt.f16.f32 v8, v6
    v.extract    s12, v2, #7
    s.movz       s13, #0
    s.shli       s14, s12, #32
    v.extract    s12, v1, #7
    v.extract    s15, v2, #8
    s.cmp.ge     s16, s11, s13
    s.or         s11, s12, s14
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v1, #8
    v.extract    s15, v2, #9
    v.insert     v3, s16, #6
    s.cmp.ge     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v1, #9
    v.extract    s15, v2, #10
    v.insert     v3, s16, #7
    s.cmp.ge     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v1, #10
    v.extract    s15, v2, #11
    v.insert     v3, s16, #8
    s.cmp.ge     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v1, #11
    v.extract    s15, v2, #12
    v.insert     v3, s16, #9
    s.cmp.ge     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v1, #12
    v.extract    s15, v2, #13
    v.insert     v3, s16, #10
    s.cmp.ge     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v1, #13
    v.extract    s15, v2, #14
    v.insert     v3, s16, #11
    s.cmp.ge     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    v.extract    s14, v1, #14
    v.extract    s15, v2, #15
    v.insert     v3, s16, #12
    v.extract    s16, v2, #0
    s.cmp.ge     s17, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #0
    s.shli       s13, s15, #32
    s.shli       s14, s16, #32
    v.extract    s15, v1, #15
    v.insert     v3, s17, #13
    v.extract    s16, v1, #0
    s.cmp.ge     s17, s11, s12
    v.extract    s11, v2, #1
    s.or         s12, s15, s13
    s.movz       s13, #0
    s.or         s15, s16, s14
    s.movz       s14, #256
    s.shli       s16, s11, #32
    v.insert     v3, s17, #14
    v.extract    s11, v1, #1
    s.cmp.ge     s17, s12, s13
    v.extract    s12, v2, #2
    v.movi       v6, #0
    s.cmp.lt     s13, s15, s14
    s.or         s14, s11, s16
    s.movz       s11, #256
    s.shli       s15, s12, #32
    v.extract    s12, v1, #2
    v.insert     v3, s17, #15
    v.extract    s16, v2, #3
    v.insert     v6, s13, #0
    s.cmp.lt     s13, s14, s11
    s.or         s11, s12, s15
    s.movz       s12, #256
    s.shli       s14, s16, #32
    v.extract    s15, v1, #3
    v.extract    s16, v2, #4
    v.insert     v6, s13, #1
    s.cmp.lt     s13, s11, s12
    s.or         s11, s15, s14
    s.movz       s12, #256
    s.shli       s14, s16, #32
    v.extract    s15, v1, #4
    v.extract    s16, v2, #5
    v.insert     v6, s13, #2
    s.cmp.lt     s13, s11, s12
    s.or         s11, s15, s14
    s.movz       s12, #256
    s.shli       s14, s16, #32
    v.extract    s15, v1, #5
    v.extract    s16, v2, #6
    v.insert     v6, s13, #3
    s.cmp.lt     s13, s11, s12
    s.or         s11, s15, s14
    s.movz       s12, #256
    s.shli       s14, s16, #32
    v.extract    s15, v1, #6
    v.insert     v6, s13, #4
    s.cmp.lt     s13, s11, s12
    v.movi       v10, #0
    s.or         s11, s15, s14
    v.insert     v6, s13, #5
    v.cmp.ne     p2, v3, v10
    v.extract    s12, v2, #7
    s.movz       s13, #256
    s.shli       s14, s12, #32
    v.extract    s12, v1, #7
    v.extract    s15, v2, #8
    s.cmp.lt     s16, s11, s13
    s.or         s11, s12, s14
    s.movz       s12, #256
    s.shli       s13, s15, #32
    v.extract    s14, v1, #8
    v.extract    s15, v2, #9
    v.insert     v6, s16, #6
    s.cmp.lt     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #256
    s.shli       s13, s15, #32
    v.extract    s14, v1, #9
    v.extract    s15, v2, #10
    v.insert     v6, s16, #7
    s.cmp.lt     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #256
    s.shli       s13, s15, #32
    v.extract    s14, v1, #10
    v.extract    s15, v2, #11
    v.insert     v6, s16, #8
    s.cmp.lt     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #256
    s.shli       s13, s15, #32
    v.extract    s14, v1, #11
    v.extract    s15, v2, #12
    v.insert     v6, s16, #9
    s.cmp.lt     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #256
    s.shli       s13, s15, #32
    v.extract    s14, v1, #12
    v.extract    s15, v2, #13
    v.insert     v6, s16, #10
    s.cmp.lt     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #256
    s.shli       s13, s15, #32
    v.extract    s14, v1, #13
    v.extract    s15, v2, #14
    v.insert     v6, s16, #11
    s.cmp.lt     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #256
    s.shli       s13, s15, #32
    v.extract    s14, v1, #14
    v.extract    s15, v2, #15
    v.insert     v6, s16, #12
    s.cmp.lt     s16, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #256
    s.shli       s13, s15, #32
    v.extract    s14, v1, #15
    v.insert     v6, s16, #13
    s.cmp.lt     s15, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #256
    v.insert     v6, s15, #14
    s.cmp.lt     s13, s11, s12
    v.movi       v3, #0
    v.insert     v6, s13, #15
    v.movi       v10, #0
    v.cmp.ne     p3, v6, v3
    p.and        p4, p2, p3
    v.movi       v3, #1
    s.movz       s11, #0
    @p4 v.sel        v6, v10, v3
    v.reduce.or  s12, v6
    s.cmp.eq     s13, s12, s11
    br.nz        s13, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s11, v2, #0
    s.shli       s12, s11, #32
    v.extract    s11, v1, #0
    v.extract    s13, v2, #1
    s.or         s14, s11, s12
    s.movz       s11, #64
    s.shli       s12, s13, #32
    v.extract    s13, v1, #1
    v.extract    s15, v2, #2
    s.mul        s16, s14, s11
    s.or         s11, s13, s12
    s.movz       s12, #64
    s.shli       s13, s15, #32
    v.extract    s14, v1, #2
    v.extract    s15, v2, #3
    s.mul        s17, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #64
    s.shli       s13, s15, #32
    v.extract    s14, v1, #3
    v.extract    s15, v2, #4
    s.mul        s18, s11, s12
    s.or         s11, s14, s13
    s.movz       s12, #64
    s.shli       s13, s15, #32
    v.movi       v3, #0
    v.movi       v6, #0
    s.lshri      s14, s16, #32
    s.mul        s15, s11, s12
    v.extract    s11, v1, #4
    s.or         s12, s11, s13
    v.extract    s11, v2, #5
    s.shli       s13, s11, #32
    v.insert     v3, s16, #0
    s.movz       s11, #64
    v.insert     v6, s14, #0
    s.lshri      s14, s17, #32
    s.mul        s16, s12, s11
    v.extract    s11, v1, #5
    s.or         s12, s11, s13
    v.extract    s11, v2, #6
    s.shli       s13, s11, #32
    v.insert     v3, s17, #1
    s.movz       s11, #64
    v.insert     v6, s14, #1
    s.lshri      s14, s18, #32
    s.mul        s17, s12, s11
    v.extract    s11, v1, #6
    s.or         s12, s11, s13
    v.extract    s11, v2, #7
    s.shli       s13, s11, #32
    v.insert     v3, s18, #2
    s.movz       s11, #64
    v.insert     v6, s14, #2
    s.lshri      s14, s15, #32
    s.mul        s18, s12, s11
    v.extract    s11, v1, #7
    s.or         s12, s11, s13
    v.extract    s11, v2, #8
    s.shli       s13, s11, #32
    v.insert     v3, s15, #3
    s.movz       s11, #64
    v.insert     v6, s14, #3
    s.lshri      s14, s16, #32
    s.mul        s15, s12, s11
    v.extract    s11, v1, #8
    s.or         s12, s11, s13
    v.extract    s11, v2, #9
    s.shli       s13, s11, #32
    v.insert     v3, s16, #4
    s.movz       s11, #64
    v.insert     v6, s14, #4
    s.lshri      s14, s17, #32
    s.mul        s16, s12, s11
    v.extract    s11, v1, #9
    s.or         s12, s11, s13
    v.extract    s11, v2, #10
    s.shli       s13, s11, #32
    v.insert     v3, s17, #5
    s.movz       s11, #64
    v.insert     v6, s14, #5
    s.lshri      s14, s18, #32
    s.mul        s17, s12, s11
    v.extract    s11, v1, #10
    s.or         s12, s11, s13
    v.extract    s11, v2, #11
    s.shli       s13, s11, #32
    v.insert     v3, s18, #6
    s.movz       s11, #64
    v.insert     v6, s14, #6
    s.lshri      s14, s15, #32
    s.mul        s18, s12, s11
    v.extract    s11, v1, #11
    s.or         s12, s11, s13
    v.extract    s11, v2, #12
    s.shli       s13, s11, #32
    v.insert     v3, s15, #7
    s.movz       s11, #64
    v.insert     v6, s14, #7
    s.lshri      s14, s16, #32
    s.mul        s15, s12, s11
    v.extract    s11, v1, #12
    s.or         s12, s11, s13
    v.extract    s11, v2, #13
    s.shli       s13, s11, #32
    v.insert     v3, s16, #8
    s.movz       s11, #64
    v.insert     v6, s14, #8
    s.lshri      s14, s17, #32
    s.mul        s16, s12, s11
    v.extract    s11, v1, #13
    s.or         s12, s11, s13
    v.extract    s11, v2, #14
    s.shli       s13, s11, #32
    v.insert     v3, s17, #9
    s.movz       s11, #64
    v.insert     v6, s14, #9
    s.lshri      s14, s18, #32
    s.mul        s17, s12, s11
    v.extract    s11, v1, #14
    s.or         s12, s11, s13
    v.extract    s11, v2, #15
    s.shli       s13, s11, #32
    v.insert     v3, s18, #10
    s.movz       s11, #64
    v.insert     v6, s14, #10
    s.lshri      s14, s15, #32
    s.mul        s18, s12, s11
    v.extract    s11, v1, #15
    s.or         s12, s11, s13
    s.movz       s11, #64
    v.insert     v3, s15, #11
    v.insert     v6, s14, #11
    s.lshri      s13, s16, #32
    s.mul        s14, s12, s11
    v.extract    s11, v7, #0
    v.insert     v3, s16, #12
    v.insert     v6, s13, #12
    s.lshri      s12, s17, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #1
    v.insert     v3, s17, #13
    v.insert     v6, s12, #13
    s.lshri      s12, s18, #32
    s.ashri      s15, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #2
    v.insert     v3, s18, #14
    v.insert     v6, s12, #14
    s.lshri      s12, s14, #32
    v.movi       v10, #0
    v.movi       v11, #0
    s.lshri      s16, s15, #32
    s.ashri      s17, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #3
    v.insert     v3, s14, #15
    v.insert     v6, s12, #15
    v.insert     v10, s15, #0
    v.insert     v11, s16, #0
    s.lshri      s12, s17, #32
    s.ashri      s14, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #4
    v.insert     v10, s17, #1
    v.insert     v11, s12, #1
    s.lshri      s12, s14, #32
    s.ashri      s15, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #5
    v.insert     v10, s14, #2
    v.insert     v11, s12, #2
    s.lshri      s12, s15, #32
    s.ashri      s14, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #6
    v.insert     v10, s15, #3
    v.insert     v11, s12, #3
    s.lshri      s12, s14, #32
    s.ashri      s15, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #7
    v.insert     v10, s14, #4
    v.insert     v11, s12, #4
    s.lshri      s12, s15, #32
    s.ashri      s14, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #8
    v.insert     v10, s15, #5
    v.insert     v11, s12, #5
    s.lshri      s12, s14, #32
    s.ashri      s15, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #9
    v.insert     v10, s14, #6
    v.insert     v11, s12, #6
    s.lshri      s12, s15, #32
    s.ashri      s14, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #10
    v.insert     v10, s15, #7
    v.insert     v11, s12, #7
    s.lshri      s12, s14, #32
    s.ashri      s15, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #11
    v.insert     v10, s14, #8
    v.insert     v11, s12, #8
    s.lshri      s12, s15, #32
    s.ashri      s14, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #12
    v.insert     v10, s15, #9
    v.insert     v11, s12, #9
    s.lshri      s12, s14, #32
    s.ashri      s15, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #13
    v.insert     v10, s14, #10
    v.insert     v11, s12, #10
    s.lshri      s12, s15, #32
    s.ashri      s14, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #14
    v.insert     v10, s15, #11
    v.insert     v11, s12, #11
    s.lshri      s12, s14, #32
    s.ashri      s15, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v7, #15
    v.insert     v10, s14, #12
    v.insert     v11, s12, #12
    s.lshri      s12, s15, #32
    s.ashri      s14, s13, #32
    s.shli       s13, s11, #32
    v.insert     v10, s15, #13
    v.insert     v11, s12, #13
    s.lshri      s11, s14, #32
    s.ashri      s12, s13, #32
    v.insert     v10, s14, #14
    v.insert     v11, s11, #14
    s.lshri      s11, s12, #32
    v.insert     v10, s12, #15
    v.insert     v11, s11, #15
    v.extract    s11, v6, #0
    v.extract    s12, v11, #0
    s.shli       s13, s12, #32
    s.shli       s12, s11, #32
    v.extract    s11, v10, #0
    v.extract    s14, v3, #0
    v.extract    s15, v11, #1
    v.extract    s16, v6, #1
    s.or         s17, s11, s13
    s.or         s11, s14, s12
    s.shli       s12, s15, #32
    s.shli       s13, s16, #32
    v.extract    s14, v10, #1
    v.extract    s15, v3, #1
    v.extract    s16, v11, #2
    v.movi       v7, #0
    s.add        s18, s17, s11
    v.extract    s11, v6, #2
    s.or         s17, s14, s12
    s.or         s12, s15, s13
    s.shli       s13, s16, #32
    s.shli       s14, s11, #32
    v.extract    s11, v10, #2
    v.extract    s15, v3, #2
    v.movi       v12, #0
    v.insert     v7, s18, #0
    s.lshri      s16, s18, #32
    s.add        s18, s17, s12
    v.extract    s12, v11, #3
    s.or         s17, s11, s13
    v.extract    s11, v6, #3
    s.or         s13, s15, s14
    s.shli       s14, s12, #32
    s.shli       s12, s11, #32
    v.extract    s11, v10, #3
    v.insert     v12, s16, #0
    v.extract    s15, v3, #3
    v.insert     v7, s18, #1
    s.lshri      s16, s18, #32
    s.add        s18, s17, s13
    v.extract    s13, v11, #4
    s.or         s17, s11, s14
    v.extract    s11, v6, #4
    s.or         s14, s15, s12
    s.shli       s12, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v10, #4
    v.insert     v12, s16, #1
    v.extract    s15, v3, #4
    v.insert     v7, s18, #2
    s.lshri      s16, s18, #32
    s.add        s18, s17, s14
    v.extract    s14, v11, #5
    s.or         s17, s11, s12
    v.extract    s11, v6, #5
    s.or         s12, s15, s13
    s.shli       s13, s14, #32
    s.shli       s14, s11, #32
    v.extract    s11, v10, #5
    v.insert     v12, s16, #2
    v.extract    s15, v3, #5
    v.insert     v7, s18, #3
    s.lshri      s16, s18, #32
    s.add        s18, s17, s12
    v.extract    s12, v11, #6
    s.or         s17, s11, s13
    v.extract    s11, v6, #6
    s.or         s13, s15, s14
    s.shli       s14, s12, #32
    s.shli       s12, s11, #32
    v.extract    s11, v10, #6
    v.insert     v12, s16, #3
    v.extract    s15, v3, #6
    v.insert     v7, s18, #4
    s.lshri      s16, s18, #32
    s.add        s18, s17, s13
    v.extract    s13, v11, #7
    s.or         s17, s11, s14
    v.extract    s11, v6, #7
    s.or         s14, s15, s12
    s.shli       s12, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v10, #7
    v.insert     v12, s16, #4
    v.extract    s15, v3, #7
    v.insert     v7, s18, #5
    s.lshri      s16, s18, #32
    s.add        s18, s17, s14
    v.extract    s14, v11, #8
    s.or         s17, s11, s12
    v.extract    s11, v6, #8
    s.or         s12, s15, s13
    s.shli       s13, s14, #32
    s.shli       s14, s11, #32
    v.extract    s11, v10, #8
    v.insert     v12, s16, #5
    v.extract    s15, v3, #8
    v.insert     v7, s18, #6
    s.lshri      s16, s18, #32
    s.add        s18, s17, s12
    v.extract    s12, v11, #9
    s.or         s17, s11, s13
    v.extract    s11, v6, #9
    s.or         s13, s15, s14
    s.shli       s14, s12, #32
    s.shli       s12, s11, #32
    v.extract    s11, v10, #9
    v.insert     v12, s16, #6
    v.extract    s15, v3, #9
    v.insert     v7, s18, #7
    s.lshri      s16, s18, #32
    s.add        s18, s17, s13
    v.extract    s13, v11, #10
    s.or         s17, s11, s14
    v.extract    s11, v6, #10
    s.or         s14, s15, s12
    s.shli       s12, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v10, #10
    v.insert     v12, s16, #7
    v.extract    s15, v3, #10
    v.insert     v7, s18, #8
    s.lshri      s16, s18, #32
    s.add        s18, s17, s14
    v.extract    s14, v11, #11
    s.or         s17, s11, s12
    v.extract    s11, v6, #11
    s.or         s12, s15, s13
    s.shli       s13, s14, #32
    s.shli       s14, s11, #32
    v.extract    s11, v10, #11
    v.insert     v12, s16, #8
    v.extract    s15, v3, #11
    v.insert     v7, s18, #9
    s.lshri      s16, s18, #32
    s.add        s18, s17, s12
    v.extract    s12, v11, #12
    s.or         s17, s11, s13
    v.extract    s11, v6, #12
    s.or         s13, s15, s14
    s.shli       s14, s12, #32
    s.shli       s12, s11, #32
    v.extract    s11, v10, #12
    v.insert     v12, s16, #9
    v.extract    s15, v3, #12
    v.insert     v7, s18, #10
    s.lshri      s16, s18, #32
    s.add        s18, s17, s13
    v.extract    s13, v11, #13
    s.or         s17, s11, s14
    v.extract    s11, v6, #13
    s.or         s14, s15, s12
    s.shli       s12, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v10, #13
    v.insert     v12, s16, #10
    v.extract    s15, v3, #13
    v.insert     v7, s18, #11
    s.lshri      s16, s18, #32
    s.add        s18, s17, s14
    v.extract    s14, v11, #14
    s.or         s17, s11, s12
    v.extract    s11, v6, #14
    s.or         s12, s15, s13
    s.shli       s13, s14, #32
    s.shli       s14, s11, #32
    v.extract    s11, v10, #14
    v.insert     v12, s16, #11
    v.extract    s15, v3, #14
    v.insert     v7, s18, #12
    s.lshri      s16, s18, #32
    s.add        s18, s17, s12
    v.extract    s12, v11, #15
    s.or         s17, s11, s13
    v.extract    s11, v6, #15
    s.or         s13, s15, s14
    s.shli       s14, s12, #32
    s.shli       s12, s11, #32
    v.extract    s11, v10, #15
    v.insert     v12, s16, #12
    v.extract    s15, v3, #15
    v.insert     v7, s18, #13
    s.lshri      s16, s18, #32
    s.add        s18, s17, s13
    s.or         s13, s11, s14
    s.or         s11, s15, s12
    v.insert     v12, s16, #13
    v.insert     v7, s18, #14
    s.lshri      s12, s18, #32
    s.add        s14, s13, s11
    v.insert     v12, s12, #14
    v.insert     v7, s14, #15
    s.lshri      s11, s14, #32
    v.movi       v3, #31
    v.insert     v12, s11, #15
    v.ashr       v6, v7, v3
    v.movi       v3, #1
    v.movi       v10, #0
    v.cmp.ne     p2, v12, v6
    @p2 v.sel        v6, v3, v10
    s.movz       s11, #0
    v.reduce.or  s12, v6
    s.cmp.eq     s13, s12, s11
    br.nz        s13, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s4, v7]               // index is in elements (ISA sec 9.1)
    s.shli       s11, s10, #1                    // element offset -> bytes (x2)
    v.movi       v6, #0
    s.add        s12, s2, s11                    // &in_out_ptr0[...]
    s.add        s11, s10, s9
    s.movz       s13, #1
    vf.cvt.f16.f32 v7, v3
    vf.add       v3, v7, v9
    vf.add       v7, v3, v5
    vf.add       v3, v7, v8
    vf.mul       v5, v3, v3
    vf.cvt.f32.f16 v7, v3
    vf.add       v3, v4, v5
    @p1 v.st.h       [s12, #0], v7
    @p1 v.sel        v5, v3, v4
    v.mov        v6, v5
    v.mov        v4, v6
    s.mov        s10, s11
    br.nz        s13, for_1
endfor_2:
    vf.reduce.add.b v1, v4
    v.movi       v2, #0
    s.addi       s4, s1, #0
    vf.add       v3, v1, v2
for_5:
    s.cmp.ge     s1, s4, s3
    br.nz        s1, endfor_6
    .li       s1, #1115684864
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v4, v1                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #925353388
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s1, s4, #2
    v.splat      v6, s4
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s5, #64
    .li       s6, #1077936128
    v.splat      v8, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s6, #3204448256
    v.splat      v9, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v10, v6, v7
    v.movi       v6, #0
    s.add        s6, s2, s1
    v.cmp.ge     p1, v10, v6
    v.splat      v6, s5
    fence.acq_rel.device
    v.cmp.lt     p2, v10, v6
    p.and        p3, p1, p2
    v.splat      v6, s4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s6, #0]
    s.shli       s1, s4, #1                      // element offset -> bytes (x2)
    v.add        v10, v6, v0
    v.movi       v6, #64
    s.add        s5, s7, s1                      // &in_ptr4[...]
    v.cmp.lt     p1, v10, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s5, #0]
    vf.cvt.f16.f32 v10, v7
    s.add        s5, s8, s1                      // &out_ptr1[...]
    s.add        s1, s4, s9
    vf.fms       v7, v1, v4, v2
    s.movz       s6, #1
    vf.cvt.f16.f32 v1, v6
    vf.fms       v2, v4, v7, v4
    vf.neg       v6, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v2, v6, v4
    vf.mul       v4, v3, v2                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v2, v4, v5
    v.rsqrt.approx v4, v2                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v4, v4
    vf.mul       v6, v4, v9
    vf.fms       v7, v2, v5, v8
    vf.mul       v2, v6, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v5, v2, v4
    v.extract    s10, v5, #0
    v.splat      v2, s10
    vf.mul       v4, v10, v2
    vf.mul       v2, v4, v1
    vf.cvt.f32.f16 v1, v2
    @p1 v.st.h       [s5, #0], v1
    s.mov        s4, s1
    br.nz        s6, for_5
endfor_6:
    exit
    exit
