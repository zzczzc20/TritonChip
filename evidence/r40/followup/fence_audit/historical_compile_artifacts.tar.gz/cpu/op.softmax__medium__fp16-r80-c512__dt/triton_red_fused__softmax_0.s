    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    .li       s1, #4286578688
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #512
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    s.ld.d       s8, [s1, #8]                    // out_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s9, [s1, #16]                   // out_ptr3: device_ptr64 at arg_base+16
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    s.mul        s1, s4, s5
    v.splat      v0, s7
    v.movi       v3, #512
    v.movi       v4, #0
    v.add        v5, v0, v2
    s.add        s10, s7, s1
    v.splat      v0, s1
    s.shli       s1, s10, #1                     // element offset -> bytes (x2)
    v.cmp.lt     p1, v5, v3
    s.add        s10, s3, s1                     // &in_ptr0[...]
    s.add        s1, s7, s6
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s10, #0]
    s.movz       s10, #1
    v.add        v6, v5, v0
    vf.cvt.f16.f32 v0, v3
    vf.max.prop  v3, v1, v0
    @p1 v.sel        v0, v3, v1
    v.mov        v4, v0
    v.mov        v1, v4
    s.mov        s7, s1
    br.nz        s10, for_1
endfor_2:
    v.movi       v0, #1
    v.movi       v3, #0
    vf.cmp.uo    p1, v1, v1
    v.movi       v4, #0
    @p1 v.sel        v5, v0, v3
    vf.reduce.max.b v0, v1
    .li       s1, #2143289344
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.reduce.or.b v3, v5
    v.movi       v5, #0
    v.movi       v6, #0
    v.cmp.ne     p1, v3, v4
    @p1 v.sel        v3, v1, v0
    v.movi       v0, #0
    s.addi       s1, s2, #0
    vf.add       v1, v3, v5
    v.mov        v0, v6
for_3:
    s.cmp.ge     s7, s1, s5
    br.nz        s7, endfor_4
    s.mul        s7, s4, s5
    v.splat      v3, s1
    v.movi       v4, #512
    v.extract    s10, v1, #0
    v.add        v6, v3, v2
    s.add        s11, s1, s7
    v.splat      v3, s10
    s.shli       s10, s11, #1                    // element offset -> bytes (x2)
    v.cmp.lt     p1, v6, v4
    s.add        s12, s3, s10                    // &in_ptr0[...]
    .li       s10, #1069066811
    v.splat      v4, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s12, #0]
    .li       s10, #1060205080
    v.splat      v8, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s10, s11, #2                    // element offset -> bytes (x4)
    v.movi       v9, #0
    s.add        s11, s8, s10                    // &out_ptr1[...]
    v.splat      v10, s7
    s.add        s7, s1, s6
    s.movz       s10, #1
    v.add        v11, v6, v10
    vf.cvt.f16.f32 v6, v7
    vf.sub       v7, v6, v3
    vf.mul       v3, v7, v4
    v.exp2.approx v6, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v7, v4, v3                 // the exact rounding error of x*log2(e)
    vf.mul       v3, v10, v8
    vf.fma       v4, v6, v3, v6                  // 2**t * 2**d
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v3, v4, v6
    vf.add       v4, v0, v3
    @p1 v.st.w       [s11, #0], v3
    @p1 v.sel        v3, v4, v0
    v.mov        v9, v3
    v.mov        v0, v9
    s.mov        s1, s7
    br.nz        s10, for_3
endfor_4:
    s.rdspecial  s1, arg_base
    s.rdspecial  s3, role_id
    s.ld.d       s7, [s1, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #256
    vf.reduce.add.b v1, v0
    s.mul        s10, s3, s1
    s.movz       s1, #80
    s.movz       s3, #512
    s.movz       s11, #2048
    s.movz       s12, #4
    .li       s13, #68719476737
    vf.add       v0, v1, v5
    s.movz       s14, #0
    s.add        s14, s7, s10                    // this context's own scratch
    .li       s7, #2207613190144
    s.addi       s10, s14, #0                    // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.addi       s14, s2, #0
    s.st.d       [s10, #0], s8
    s.st.d       [s10, #8], s1
    s.st.d       [s10, #16], s3
    s.st.d       [s10, #48], s11
    s.st.d       [s10, #56], s12
    s.st.d       [s10, #88], s13
    s.st.d       [s10, #104], s7
    fence.release.device
    td.load      d0, [s10]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
for_5:
    s.cmp.ge     s1, s14, s5
    br.nz        s1, endfor_6
    v.extract    s1, v0, #0
    v.splat      v1, s14
    v.splat      v3, s1
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s1, #512
    v.rcp.approx v5, v3                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #80
    s.muli       s3, s4, #2048
    v.add        v6, v1, v4
    v.movi       v1, #0
    v.splat      v4, s1
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s2
    s.muli       s1, s14, #4
    v.cmp.ge     p1, v6, v1
    v.cmp.lt     p2, v6, v4
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    s.add        s2, s8, s3
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    .li       s3, #1065353216
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s3, s2, s1
    p.and        p2, p5, p1
    s.mul        s1, s4, s5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v4, [s3, #0]
    v.splat      v6, s14
    v.movi       v7, #512
    s.add        s2, s14, s6
    s.add        s3, s14, s1
    v.add        v8, v6, v2
    s.shli       s7, s3, #1                      // element offset -> bytes (x2)
    vf.fms       v6, v3, v5, v1
    v.splat      v1, s1
    s.add        s1, s9, s7                      // &out_ptr3[...]
    s.movz       s3, #1
    v.cmp.lt     p1, v8, v7
    vf.fms       v3, v5, v6, v5
    v.add        v6, v8, v1
    vf.neg       v1, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v3, v1, v5
    vf.mul       v1, v4, v3                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.f16 v3, v1
    @p1 v.st.h       [s1, #0], v3
    s.mov        s14, s2
    br.nz        s3, for_5
endfor_6:
__rctx_next:
    exit
