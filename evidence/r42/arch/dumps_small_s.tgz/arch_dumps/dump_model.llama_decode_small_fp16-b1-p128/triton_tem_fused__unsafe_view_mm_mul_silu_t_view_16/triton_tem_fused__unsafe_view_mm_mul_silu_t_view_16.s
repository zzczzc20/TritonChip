    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #512
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: one row broadcast down a tile (outer stride 0) (built once, at entry)
    s.st.d       [s6, #0], s2
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    s.st.d       [s6, #16], s1
    s.movz       s2, #2
    s.st.d       [s6, #56], s2
    .li       s7, #68719476752
    s.st.d       [s6, #88], s7
    .li       s8, #8589934592
    s.st.d       [s6, #104], s8
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s6, arg_base
    s.ld.d       s9, [s6, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s6, role_id
    s.movz       s10, #512
    s.mul        s11, s6, s10
    s.add        s6, s9, s11                     // this context's own scratch
    s.addi       s9, s6, #256                    // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.st.d       [s9, #0], s3
    s.st.d       [s9, #8], s1
    s.st.d       [s9, #16], s1
    s.movz       s1, #256
    s.st.d       [s9, #48], s1
    s.st.d       [s9, #56], s2
    s.st.d       [s9, #88], s7
    s.st.d       [s9, #104], s8
    fence.release.device
    td.load      d1, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #22
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s2
    s.sub        s1, s2, s3
    .li       s3, #1952257862
    s.movz       s6, #1
    s.rdspecial  s7, role_id
    s.rdspecial  s8, npid.x
__rctx_program:
    s.cmp.lt     s9, s7, s2
    s.addi       s10, s2, #0
    s.sub        s11, s2, s9
    s.addi       s9, s2, #0
    s.xor        s12, s7, s11
    s.xor        s13, s11, s1
    s.sub        s14, s12, s11
    s.mul        s15, s14, s3
    s.mov        s10, s14
    s.lshri      s16, s15, #32
    s.sub        s15, s14, s16
    s.lshri      s17, s15, #1
    s.add        s15, s16, s17
    s.lshri      s16, s15, #4
    s.xor        s15, s16, s13
    s.sub        s16, s15, s13
    s.sub        s13, s6, s16
    s.min.s      s15, s13, s6
    s.cmp.lt     s13, s15, s2
    s.sub        s17, s2, s13
    s.xor        s13, s15, s17
    s.sub        s15, s13, s17
    s.cmp.eq     s13, s15, s6
    br.nz        s13, sdiv_done_1
    s.movz       s13, #0
    s.movz       s18, #31
    s.mov        s10, s13
    s.addi       s19, s18, #0
sdiv_2:
    s.lshr       s18, s14, s19
    s.shli       s20, s9, #1
    s.andi       s21, s18, #1
    s.shl        s18, s6, s19
    s.or         s22, s20, s21
    s.cmp.geu    s20, s22, s15
    s.sub        s21, s13, s20
    s.and        s20, s15, s21
    s.and        s23, s18, s21
    s.sub        s9, s22, s20
    s.or         s10, s10, s23
    s.subi       s19, s19, #1
    s.cmp.ge     s18, s19, s13
    br.nz        s18, sdiv_2
sdiv_done_1:
    s.sub        s10, s12, s11
    s.xor        s12, s9, s11
    s.mul        s9, s10, s3
    s.movz       s13, #1
    s.sub        s14, s12, s11
    s.addi       s12, s2, #0
    s.cmp.eq     s18, s15, s13
    s.lshri      s19, s9, #32
    s.add        s9, s16, s14
    s.sub        s14, s10, s19
    s.addi       s16, s2, #0
    s.lshri      s20, s14, #1
    s.add        s14, s19, s20
    s.lshri      s19, s14, #4
    s.muli       s14, s19, #22
    s.sub        s19, s10, s14
    s.xor        s10, s19, s11
    s.sub        s14, s10, s11
    s.cmp.lt     s10, s14, s2
    s.sub        s11, s2, s10
    s.xor        s10, s14, s11
    s.sub        s14, s10, s11
    s.mov        s12, s14
    br.nz        s18, sdiv_done_3
    s.movz       s10, #0
    s.movz       s18, #31
    s.mov        s12, s10
    s.addi       s19, s18, #0
sdiv_4:
    s.lshr       s18, s14, s19
    s.shli       s20, s16, #1
    s.andi       s21, s18, #1
    s.shl        s18, s13, s19
    s.or         s22, s20, s21
    s.cmp.geu    s20, s22, s15
    s.sub        s21, s10, s20
    s.and        s20, s15, s21
    s.and        s23, s18, s21
    s.sub        s16, s22, s20
    s.or         s12, s12, s23
    s.subi       s19, s19, #1
    s.cmp.ge     s18, s19, s10
    br.nz        s18, sdiv_4
sdiv_done_3:
    s.xor        s10, s11, s17
    s.movz       s11, #16
    s.xor        s13, s12, s10
    .li       s12, #1952257862
    s.sub        s14, s13, s10
    s.movz       s10, #0
    s.mul        s13, s14, s11
    s.movz       s14, #8
    s.addi       s15, s10, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.mul        s16, s13, s12
    s.lshri      s12, s16, #32
    s.sub        s16, s13, s12
    s.lshri      s17, s16, #1
    s.add        s16, s12, s17
    s.lshri      s12, s16, #8
    s.muli       s16, s12, #352
    s.sub        s12, s13, s16
for_5:
    s.cmp.ge     s16, s15, s14
    br.nz        s16, endfor_6
    s.mul        s16, s15, s11
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s17, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    // one row broadcast down a tile (outer stride 0): one tile into a window (ISA sec 9E)
    s.mov        s18, s10                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s19, s16                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s18, s17
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s18, s12                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s19, s16                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s18, s17
    mb.wait      s17
gemm_pipe:
    mb.arm       s16, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s18, #1
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v56, v48, s16
    s.add        s15, s15, s6
    s.cmp.ge     s18, s15, s14
    br.nz        s18, gemm_pipe_drain0
    s.mul        s18, s15, s11
    w.def        w2, #40, #8                     // v40..v47
    mb.arm       s19, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s20, #1
    // one row broadcast down a tile (outer stride 0): one tile into a window (ISA sec 9E)
    s.mov        s20, s10                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s21, s18                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w2, d0, s20, s19
    w.def        w3, #32, #8                     // v32..v39
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s20, s12                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s21, s18                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w3, d1, s20, s19
    mb.wait      s19
    mb.wait      s16
    mb.arm       s18, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v40, v32, s18
    s.add        s15, s15, s6
    s.cmp.ge     s20, s15, s14
    br.nz        s20, gemm_pipe_drain1
    s.mul        s20, s15, s11
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s21, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s22, #1
    // one row broadcast down a tile (outer stride 0): one tile into a window (ISA sec 9E)
    s.mov        s23, s10                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s20                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s23, s21
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s23, s12                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s20                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s23, s21
    mb.wait      s21
    mb.wait      s18
    br.nz        s22, gemm_pipe
gemm_pipe_drain0:
    s.movz       s12, #1
    mb.wait      s16
    br.nz        s12, endfor_6
gemm_pipe_drain1:
    mb.wait      s18
endfor_6:
    s.mul        s12, s9, s11
    s.add        s9, s10, s13                    // the tile origin
    s.muli       s11, s13, #2                    // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s9
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.add        s9, s10, s12                    // the tile origin
    s.movz       s13, #352
    s.muli       s14, s12, #704                  // a runtime tile origin, x704
    v.splat      v2, s9
    v.splat      v3, s6
    v.add        v4, v0, v1
    v.splat      v0, s13
    s.add        s12, s4, s11                    // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    s.add        s13, s12, s14                   // the tile origin
    p.and        p3, p1, p2
    s.addi       s12, s9, #1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s13, #0]
    v.splat      v1, s12
    s.addi       s12, s13, #704                  // row 1
    s.addi       s15, s9, #2
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.splat      v1, s15
    s.movz       s15, #1
    s.addi       s20, s13, #1408                 // row 2
    v.cmp.lt     p1, v1, v3
    p.and        p5, p1, p2
    s.addi       s22, s9, #3
    s.movz       s23, #2
    v.splat      v1, s22
    vf.cvt.f16.f32 v2, v0
    s.addi       s22, s13, #2112                 // row 3
    v.cmp.lt     p1, v1, v3
    p.and        p6, p1, p2
    s.addi       s24, s9, #4
    a.vwrite     a1, s10, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s12, #0]
    v.splat      v1, s24
    s.movz       s12, #3
    s.addi       s24, s13, #2816                 // row 4
    v.cmp.lt     p1, v1, v3
    p.and        p7, p1, p2
    s.addi       s25, s9, #5
    s.movz       s26, #4
    v.splat      v1, s25
    s.addi       s25, s13, #3520                 // row 5
    s.addi       s27, s9, #6
    v.cmp.lt     p1, v1, v3
    p.and        p8, p1, p2
    v.splat      v1, s27
    vf.cvt.f16.f32 v2, v0
    s.movz       s27, #5
    v.cmp.lt     p1, v1, v3
    s.addi       s28, s13, #4224                 // row 6
    p.and        p9, p1, p2
    a.vwrite     a1, s15, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v0, [s20, #0]
    s.addi       s20, s9, #7
    s.movz       s29, #6
    v.splat      v1, s20
    s.addi       s20, s13, #4928                 // row 7
    s.movz       s30, #7
    v.cmp.lt     p1, v1, v3
    p.and        p10, p1, p2
    s.movz       s31, #8
    vf.cvt.f16.f32 v1, v0
    s.addi       s32, s13, #5632                 // row 8
    a.vwrite     a1, s23, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v0, [s22, #0]
    s.addi       s22, s9, #8
    s.movz       s33, #9
    v.splat      v1, s22
    v.cmp.lt     p1, v1, v3
    p.and        p11, p1, p2
    vf.cvt.f16.f32 v1, v0
    s.addi       s22, s13, #6336                 // row 9
    a.vwrite     a1, s12, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v0, [s24, #0]
    s.addi       s24, s9, #9
    s.movz       s34, #10
    v.splat      v1, s24
    v.cmp.lt     p1, v1, v3
    p.and        p12, p1, p2
    vf.cvt.f16.f32 v1, v0
    s.addi       s24, s13, #7040                 // row 10
    a.vwrite     a1, s26, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v0, [s25, #0]
    s.addi       s25, s9, #10
    s.movz       s35, #11
    v.splat      v1, s25
    v.cmp.lt     p1, v1, v3
    p.and        p13, p1, p2
    vf.cvt.f16.f32 v1, v0
    s.addi       s25, s13, #7744                 // row 11
    a.vwrite     a1, s27, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p9 v.ld.h       v0, [s28, #0]
    s.addi       s28, s9, #11
    s.movz       s36, #12
    v.splat      v1, s28
    v.cmp.lt     p1, v1, v3
    p.and        p14, p1, p2
    vf.cvt.f16.f32 v1, v0
    s.addi       s28, s13, #8448                 // row 12
    a.vwrite     a1, s29, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p10 v.ld.h       v0, [s20, #0]
    s.addi       s20, s9, #12
    s.movz       s37, #13
    v.splat      v1, s20
    v.cmp.lt     p1, v1, v3
    p.and        p15, p1, p2
    p.ballot     s20, p15
    vf.cvt.f16.f32 v1, v0
    s.addi       s38, s13, #9152                 // row 13
    a.vwrite     a1, s30, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p11 v.ld.h       v0, [s32, #0]
    s.addi       s32, s9, #13
    s.movz       s39, #14
    v.splat      v1, s32
    v.cmp.lt     p1, v1, v3
    p.and        p15, p1, p2
    p.ballot     s32, p15
    vf.cvt.f16.f32 v1, v0
    s.addi       s40, s13, #9856                 // row 14
    a.vwrite     a1, s31, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p12 v.ld.h       v0, [s22, #0]
    s.addi       s22, s9, #14
    v.splat      v1, s22
    s.movz       s22, #15
    v.cmp.lt     p1, v1, v3
    p.and        p15, p1, p2
    p.ballot     s41, p15
    vf.cvt.f16.f32 v1, v0
    s.addi       s42, s13, #10560                // row 15
    a.vwrite     a1, s33, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p13 v.ld.h       v0, [s24, #0]
    s.addi       s13, s9, #15
    .li       s9, #1065353216
    v.splat      v1, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v2, s13
    v.cmp.lt     p1, v2, v3
    p.and        p15, p1, p2
    p.ballot     s9, p15
    vf.cvt.f16.f32 v2, v0
    s.add        s13, s5, s11                    // the tile origin
    a.vwrite     a1, s34, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p14 v.ld.h       v0, [s25, #0]
    .li       s11, #1069066811
    v.splat      v2, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s11, s13, s14                   // the tile origin
    vf.cvt.f16.f32 v3, v0
    .li       s13, #1060205080
    v.splat      v0, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    a.vwrite     a1, s35, v3
    p.frombits   p1, s20
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s28, #0]
    vf.cvt.f16.f32 v4, v3
    a.vwrite     a1, s36, v4
    p.frombits   p1, s32
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s38, #0]
    vf.cvt.f16.f32 v4, v3
    a.vwrite     a1, s37, v4
    p.frombits   p1, s41
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s40, #0]
    vf.cvt.f16.f32 v4, v3
    a.vwrite     a1, s39, v4
    p.frombits   p1, s9
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s42, #0]
    vf.cvt.f16.f32 v4, v3
    a.vwrite     a1, s22, v4
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    a.vread      v3, a1, s10
    a.vread      v4, a1, s10
    a.vread      v5, a0, s10
    s.addi       s10, s11, #704                  // row 1
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    @p3 v.st.h       [s11, #0], v4
    a.vread      v3, a1, s15
    a.vread      v4, a1, s15
    a.vread      v5, a0, s15
    s.addi       s13, s11, #1408                 // row 2
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    @p4 v.st.h       [s10, #0], v4
    a.vread      v3, a1, s23
    a.vread      v4, a1, s23
    a.vread      v5, a0, s23
    s.addi       s10, s11, #2112                 // row 3
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    @p5 v.st.h       [s13, #0], v4
    a.vread      v3, a1, s12
    a.vread      v4, a1, s12
    a.vread      v5, a0, s12
    s.addi       s12, s11, #2816                 // row 4
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    @p6 v.st.h       [s10, #0], v4
    a.vread      v3, a1, s26
    a.vread      v4, a1, s26
    a.vread      v5, a0, s26
    s.addi       s10, s11, #3520                 // row 5
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    @p7 v.st.h       [s12, #0], v4
    a.vread      v3, a1, s27
    a.vread      v4, a1, s27
    a.vread      v5, a0, s27
    s.addi       s12, s11, #4224                 // row 6
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    @p8 v.st.h       [s10, #0], v4
    a.vread      v3, a1, s29
    a.vread      v4, a1, s29
    a.vread      v5, a0, s29
    s.addi       s10, s11, #4928                 // row 7
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    @p9 v.st.h       [s12, #0], v4
    a.vread      v3, a1, s30
    a.vread      v4, a1, s30
    a.vread      v5, a0, s30
    s.addi       s12, s11, #5632                 // row 8
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    @p10 v.st.h       [s10, #0], v4
    a.vread      v3, a1, s31
    a.vread      v4, a1, s31
    a.vread      v5, a0, s31
    s.addi       s10, s11, #6336                 // row 9
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    @p11 v.st.h       [s12, #0], v4
    a.vread      v3, a1, s33
    a.vread      v4, a1, s33
    a.vread      v5, a0, s33
    s.addi       s12, s11, #7040                 // row 10
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    @p12 v.st.h       [s10, #0], v4
    a.vread      v3, a1, s34
    a.vread      v4, a1, s34
    a.vread      v5, a0, s34
    s.addi       s10, s11, #7744                 // row 11
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    @p13 v.st.h       [s12, #0], v4
    a.vread      v3, a1, s35
    a.vread      v4, a1, s35
    a.vread      v5, a0, s35
    s.addi       s12, s11, #8448                 // row 12
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    @p14 v.st.h       [s10, #0], v4
    a.vread      v3, a1, s36
    a.vread      v4, a1, s36
    a.vread      v5, a0, s36
    s.addi       s10, s11, #9152                 // row 13
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    p.frombits   p1, s20
    @p1 v.st.h       [s12, #0], v4
    a.vread      v3, a1, s37
    a.vread      v4, a1, s37
    a.vread      v5, a0, s37
    s.addi       s12, s11, #9856                 // row 14
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    p.frombits   p1, s32
    @p1 v.st.h       [s10, #0], v4
    a.vread      v3, a1, s39
    a.vread      v4, a1, s39
    a.vread      v5, a0, s39
    s.addi       s10, s11, #10560                // row 15
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v5, v8, v0
    vf.fma       v6, v4, v5, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v5, v1
    v.rcp.approx v5, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v4, v5, v1
    vf.fms       v4, v5, v6, v5
    vf.neg       v6, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v5
    vf.mul       v5, v3, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v3, v5, v7
    vf.cvt.f32.f16 v4, v3
    p.frombits   p1, s41
    @p1 v.st.h       [s12, #0], v4
    a.vread      v3, a1, s22
    a.vread      v4, a1, s22
    a.vread      v5, a0, s22
    vf.neg       v6, v4
    vf.cvt.f32.f16 v4, v5
    vf.mul       v5, v6, v2
    vf.cvt.f16.f32 v7, v4
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v2, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v0
    vf.fma       v0, v4, v2, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v2, v0, v4
    vf.add       v0, v2, v1
    v.rcp.approx v2, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v4, v0, v2, v1
    vf.fms       v0, v2, v4, v2
    vf.neg       v1, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v2
    vf.mul       v1, v3, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v0, v1, v7
    vf.cvt.f32.f16 v1, v0
    p.frombits   p1, s9
    @p1 v.st.h       [s10, #0], v1
__rctx_next:
    s.addi       s9, s7, #2                      // the next program of this context: + 2
    s.cmp.lt     s10, s9, s8
    s.mov        s7, s9
    br.nz        s10, __rctx_program
    exit
