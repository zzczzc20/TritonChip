// Isolated P1 screen only. Two slots; accepted transfer cycles match tnca_fifo.
module fifo_head #(parameter W=8)(
 input wire clk,rst_n,in_valid,output wire in_ready,input wire[W-1:0] in_data,
 output wire out_valid,input wire out_ready,output wire[W-1:0] out_data,
 output wire[1:0] count
);
 reg[W-1:0] head,tail;
 reg[1:0] used;
 assign count=used;
 assign in_ready=used<2;
 assign out_valid=used!=0;
 assign out_data=head;
 wire push=in_valid&&in_ready;
 wire pop=out_valid&&out_ready;
 always @(posedge clk) begin
  if(!rst_n) used<=0;
  else begin
   if(push && (used==0 || (used==1 && pop))) head<=in_data;
   if(pop && used==2) head<=in_data;
   if(push && used==1 && !pop) tail<=in_data;
   case({push,pop})
    2'b10:used<=used+1'b1;
    2'b01:used<=used-1'b1;
    default:;
   endcase
  end
 end
endmodule
