    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr0: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // out_ptr2: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // out_ptr3: device_ptr64 at arg_base+48
    s.ld.d       s10, [s1, #56]                  // out_ptr4: device_ptr64 at arg_base+56
    s.rdspecial  s1, arg_base
    s.ld.d       s11, [s1, #80]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s12, #768
    s.mul        s13, s1, s12
    s.add        s1, s11, s13                    // this context's own scratch
    s.addi       s11, s1, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s3
    s.movz       s12, #17
    s.st.d       [s11, #8], s12
    s.movz       s12, #2560
    s.st.d       [s11, #16], s12
    s.movz       s12, #5120
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d0, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #256                   // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s5
    s.movz       s12, #17
    s.st.d       [s11, #8], s12
    s.movz       s12, #2560
    s.st.d       [s11, #16], s12
    s.movz       s12, #5120
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d1, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s11, #0
    s.movz       s12, #2560
    s.movz       s13, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s14, s11, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s15, s14, s12
    br.nz        s15, endfor_2
    s.mul        s15, s4, s12
    s.muli       s16, s4, #5120
    v.splat      v1, s14
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s17, #2560
    s.movz       s18, #17
    s.muli       s19, s14, #2
    v.add        v4, v1, v3
    v.movi       v1, #0
    v.splat      v3, s17
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v7, s18
    s.add        s17, s14, s15
    v.splat      v8, s14
    v.cmp.ge     p1, v4, v1
    v.cmp.lt     p2, v4, v3
    v.cmp.ge     p3, v5, v6
    v.cmp.lt     p4, v5, v7
    s.muli       s18, s4, #5120
    v.splat      v1, s14
    v.iota       v3                              // arange(0, VLEN)
    s.shli       s20, s17, #1                    // element offset -> bytes (x2)
    s.add        s17, s3, s16
    s.movz       s16, #2560
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    v.add        v4, v8, v0
    v.movi       v5, #2560
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s16
    s.muli       s16, s14, #2
    v.splat      v7, s4
    v.movi       v8, #0
    s.add        s21, s2, s20                    // &in_ptr0[...]
    s.add        s22, s17, s19
    p.and        p2, p5, p1
    v.cmp.lt     p1, v4, v5
    s.movz       s17, #17
    v.cmp.ge     p3, v6, v1
    v.splat      v1, s17
    v.cmp.lt     p4, v6, v3
    v.cmp.ge     p5, v7, v8
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s21, #0]
    s.add        s17, s5, s18
    p.and        p6, p3, p4
    s.add        s18, s17, s16
    v.splat      v5, s15
    v.cmp.lt     p3, v7, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s22, #0]
    vf.cvt.bf16.f32 v6, v3
    v.add        v3, v4, v5
    p.and        p2, p5, p3
    s.add        s15, s7, s20                    // &out_ptr0[...]
    p.and        p3, p6, p2
    vf.cvt.bf16.f32 v3, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s18, #0]
    v.movi       v4, #0
    s.add        s16, s14, s13
    vf.add       v5, v6, v3
    s.movz       s17, #1
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v5, v3
    vf.mul       v3, v1, v1
    vf.cvt.f32.bf16 v5, v1
    vf.add       v1, v2, v3
    @p1 v.st.h       [s15, #0], v5
    @p1 v.sel        v3, v1, v2
    v.mov        v4, v3
    v.mov        v2, v4
    s.mov        s14, s16
    br.nz        s17, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    vf.add       v3, v1, v2
    s.addi       s2, s1, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s2, #0], s7
    s.movz       s1, #17
    s.st.d       [s2, #8], s1
    s.movz       s1, #2560
    s.st.d       [s2, #16], s1
    s.movz       s1, #5120
    s.st.d       [s2, #48], s1
    s.movz       s1, #2
    s.st.d       [s2, #56], s1
    .li       s1, #68719476737
    s.st.d       [s2, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s2, #104], s1
    fence.release.device
    td.load      d2, [s2]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s11, #0
for_3:
    s.cmp.ge     s2, s1, s12
    br.nz        s2, endfor_4
    .li       s2, #1159725056
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v4, v1                          // ISA 8.8: <= 2**-22 relative
    s.muli       s2, s4, #5120
    v.splat      v5, s1
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s3, #2560
    s.movz       s5, #17
    s.muli       s11, s1, #2
    v.add        v7, v5, v6
    v.movi       v5, #0
    v.splat      v6, s3
    v.splat      v8, s4
    v.movi       v9, #0
    v.splat      v10, s5
    v.cmp.ge     p1, v7, v5
    v.splat      v5, s1
    v.cmp.lt     p2, v7, v6
    .li       s3, #897988541
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ge     p3, v8, v9
    v.cmp.lt     p4, v8, v10
    s.add        s3, s7, s2
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    v.add        v7, v5, v0
    v.movi       v5, #2560
    s.add        s5, s3, s11
    p.and        p2, p5, p1
    vf.fms       v8, v1, v4, v2
    s.add        s3, s6, s2                      // &in_ptr3[...]
    v.cmp.lt     p1, v7, v5
    fence.acq_rel.device
    vf.fms       v2, v4, v8, v4
    .li       s2, #1077936128
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v9, [s5, #0]
    vf.neg       v10, v2                         // Newton step: r0*(2 - x*r0)
    .li       s2, #1065353216
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s2, s4, s12
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v11, v10, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s3, #0]
    vf.mul       v10, v3, v11                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v12, v9
    s.add        s3, s1, s2
    s.add        s5, s1, s13
    vf.fms       v9, v10, v1, v3
    vf.cvt.bf16.f32 v1, v4
    s.shli       s11, s3, #1                     // element offset -> bytes (x2)
    v.splat      v4, s2
    vf.fms       v13, v9, v11, v10
    vf.add       v9, v1, v2
    s.add        s2, s8, s11                     // &out_ptr2[...]
    s.add        s3, s9, s11                     // &out_ptr3[...]
    vf.neg       v1, v13                         // a/y: one correction to the IEEE quotient
    s.add        s14, s10, s11                   // &out_ptr4[...]
    s.movz       s11, #1
    fence.acq_rel.device
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v2, v1, v10
    fence.acq_rel.device
    vf.add       v1, v2, v6
    v.add        v2, v7, v4
    v.rsqrt.approx v2, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v2, v2
    vf.mul       v6, v2, v8
    vf.fms       v7, v1, v4, v5
    vf.mul       v1, v6, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v4, v1, v2
    v.extract    s15, v4, #0
    v.splat      v1, s15
    vf.mul       v2, v12, v1
    vf.mul       v1, v2, v9
    vf.cvt.f32.bf16 v2, v1
    @p1 v.st.h       [s2, #0], v2
    @p1 v.st.h       [s3, #0], v2
    @p1 v.st.h       [s14, #0], v2
    s.mov        s1, s5
    br.nz        s11, for_3
endfor_4:
__rctx_next:
    exit
