#!/bin/bash
source ~/tc_env/env.sh
cd /tmp/r40_attempt01_functional
for pol in 0 1; do
iverilog -g2012 -I rtl/common -y rtl/common -y rtl/nuca -y tb/common -s tb_nuca_slice -Ptb_nuca_slice.SETS=32 -Ptb_nuca_slice.SET_W=5 -Ptb_nuca_slice.WAYS=8 -Ptb_nuca_slice.WAY_W=3 -Ptb_nuca_slice.DCO_REGISTERED_RANGES=1 -Ptb_nuca_slice.POLICY=$pol -o slice$pol.vvp tb/nuca/tb_nuca_slice.v > build$pol.log 2>&1 || exit 1
timeout 120 vvp slice$pol.vvp > run$pol.log 2>&1 || exit 2
done
rc=$?
printf '%s\n' "$rc" > result.exit
