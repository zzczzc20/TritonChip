    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #256
    s.movz       s3, #0
    s.rdspecial  s5, arg_base
    s.rdspecial  s6, arg_base
    s.mul        s7, s1, s2
    s.muli       s1, s4, #64
    s.ld.d       s2, [s5, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s8, #2
    s.movz       s9, #16
    s.ld.d       s10, [s6, #48]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s6, s2, s1
    s.movz       s1, #64
    s.add        s11, s10, s7                    // this context's own scratch
    s.movz       s7, #4
    s.addi       s10, s11, #0                    // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    .li       s11, #68719476737
    .li       s12, #2207613190144
    s.ld.d       s13, [s5, #8]                   // out_ptr0: device_ptr64 at arg_base+8
    s.add        s14, s6, s3
    s.movz       s6, #0
    s.ld.d       s15, [s5, #16]                  // out_ptr2: device_ptr64 at arg_base+16
    v.splat      v0, s3
    s.movz       s16, #0
    s.ld.d       s17, [s5, #24]                  // out_ptr3: device_ptr64 at arg_base+24
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #0
    v.add        v3, v0, v1
    v.splat      v0, s4
    v.movi       v1, #0
    v.cmp.ge     p1, v3, v2
    v.cmpi.lt    p2, v3, #16
    v.cmp.ge     p3, v0, v1
    p.and        p4, p1, p2
    s.st.d       [s10, #0], s2
    v.cmpi.lt    p1, v0, #2
    p.and        p2, p3, p1
    s.st.d       [s10, #8], s8
    p.and        p1, p4, p2
    s.movz       s5, #0
    s.st.d       [s10, #16], s9
    .li       s8, #4286578688
    v.splat      v0, s8                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.movz       s8, #0
    s.st.d       [s10, #48], s1
    v.movi       v1, #1
    v.movi       v2, #0
    s.st.d       [s10, #56], s7
    v.movi       v3, #0
    s.movz       s1, #0
    s.st.d       [s10, #88], s11
    v.movi       v4, #0
    s.movz       s7, #0
    s.st.d       [s10, #104], s12
    fence.release.device
    td.load      d0, [s10]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s14, #0]
    v.movi       v6, #1
    v.movi       v7, #0
    v.movi       v8, #1
    v.movi       v9, #0
    s.movz       s9, #0
    v.movi       v10, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    vf.cmp.eq    p1, v5, v0
    @p1 v.sel        v11, v1, v2
    s.movz       s14, #0
    v.cmp.eq     p1, v11, v3
    @p1 v.sel        v1, v6, v7
    @p1 v.sel        v2, v8, v10
    v.extract    s18, v1, #0
    s.lshri      s19, s18, #32
    v.extract    s20, v2, #1
    v.insert     v4, s18, #0
    v.insert     v9, s19, #0
    s.lshri      s18, s20, #32
    v.insert     v4, s20, #1
    s.movz       s19, #0
    v.insert     v9, s18, #1
    s.movz       s18, #0
    v.movi       v1, #1
    s.movz       s20, #0
    v.movi       v2, #0
    s.movz       s21, #0
    @p1 v.sel        v3, v1, v2
    s.movz       s22, #0
    v.extract    s23, v3, #2
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #16
    s.muli       s24, s3, #4
    s.lshri      s25, s23, #32
    v.insert     v4, s23, #2
    v.insert     v9, s25, #2
    v.cmp.lt     p2, v1, v2
    v.movi       v2, #1
    v.movi       v3, #0
    v.movi       v6, #1
    @p1 v.sel        v7, v2, v3
    v.movi       v2, #0
    v.extract    s23, v7, #3
    @p1 v.sel        v3, v6, v2
    v.movi       v2, #1
    v.movi       v6, #0
    s.lshri      s25, s23, #32
    v.extract    s26, v3, #4
    @p1 v.sel        v3, v2, v6
    v.movi       v2, #1
    v.movi       v6, #0
    v.insert     v4, s23, #3
    v.insert     v9, s25, #3
    s.lshri      s23, s26, #32
    v.extract    s25, v3, #5
    @p1 v.sel        v3, v2, v6
    v.movi       v2, #1
    v.movi       v6, #0
    v.insert     v4, s26, #4
    v.insert     v9, s23, #4
    s.lshri      s23, s25, #32
    v.extract    s26, v3, #6
    @p1 v.sel        v3, v2, v6
    v.movi       v2, #1
    v.movi       v6, #0
    v.insert     v4, s25, #5
    v.insert     v9, s23, #5
    s.lshri      s23, s26, #32
    v.extract    s25, v3, #7
    @p1 v.sel        v3, v2, v6
    v.movi       v2, #1
    v.movi       v6, #0
    v.insert     v4, s26, #6
    v.insert     v9, s23, #6
    s.lshri      s23, s25, #32
    v.extract    s26, v3, #8
    @p1 v.sel        v3, v2, v6
    v.movi       v2, #1
    v.movi       v6, #0
    v.insert     v4, s25, #7
    v.insert     v9, s23, #7
    s.lshri      s23, s26, #32
    v.extract    s25, v3, #9
    @p1 v.sel        v3, v2, v6
    v.movi       v2, #1
    v.movi       v6, #0
    v.insert     v4, s26, #8
    v.insert     v9, s23, #8
    s.lshri      s23, s25, #32
    v.extract    s26, v3, #10
    @p1 v.sel        v3, v2, v6
    v.movi       v2, #1
    v.movi       v6, #0
    v.insert     v4, s25, #9
    v.insert     v9, s23, #9
    s.lshri      s23, s26, #32
    v.extract    s25, v3, #11
    @p1 v.sel        v3, v2, v6
    v.movi       v2, #1
    v.movi       v6, #0
    v.insert     v4, s26, #10
    v.insert     v9, s23, #10
    s.lshri      s23, s25, #32
    v.extract    s26, v3, #12
    @p1 v.sel        v3, v2, v6
    v.movi       v2, #1
    v.movi       v6, #0
    v.insert     v4, s25, #11
    v.insert     v9, s23, #11
    s.lshri      s23, s26, #32
    v.extract    s25, v3, #13
    @p1 v.sel        v3, v2, v6
    v.movi       v2, #1
    v.movi       v6, #0
    v.insert     v4, s26, #12
    v.insert     v9, s23, #12
    s.lshri      s23, s25, #32
    v.extract    s26, v3, #14
    @p1 v.sel        v3, v2, v6
    v.insert     v4, s25, #13
    v.insert     v9, s23, #13
    s.lshri      s23, s26, #32
    v.extract    s25, v3, #15
    v.insert     v4, s26, #14
    v.insert     v9, s23, #14
    s.lshri      s23, s25, #32
    v.insert     v4, s25, #15
    v.insert     v9, s23, #15
    v.extract    s23, v4, #0
    v.extract    s25, v9, #0
    s.shli       s26, s25, #32
    v.extract    s25, v9, #1
    s.or         s27, s23, s26
    s.shli       s23, s25, #32
    v.extract    s25, v4, #1
    v.extract    s26, v9, #2
    v.movi       v2, #0
    s.cmp.ne     s28, s27, s6
    s.or         s6, s25, s23
    s.shli       s23, s26, #32
    v.extract    s25, v4, #2
    v.extract    s26, v9, #3
    v.insert     v2, s28, #0
    s.cmp.ne     s27, s6, s16
    s.or         s6, s25, s23
    s.shli       s16, s26, #32
    v.extract    s23, v4, #3
    v.extract    s25, v9, #4
    v.insert     v2, s27, #1
    s.cmp.ne     s26, s6, s5
    s.or         s5, s23, s16
    s.shli       s6, s25, #32
    v.extract    s16, v4, #4
    v.extract    s23, v9, #5
    v.insert     v2, s26, #2
    s.cmp.ne     s25, s5, s8
    s.or         s5, s16, s6
    s.shli       s6, s23, #32
    v.extract    s8, v4, #5
    v.extract    s16, v9, #6
    v.insert     v2, s25, #3
    s.cmp.ne     s23, s5, s1
    s.or         s1, s8, s6
    s.shli       s5, s16, #32
    v.extract    s6, v4, #6
    v.extract    s8, v9, #7
    v.insert     v2, s23, #4
    s.cmp.ne     s16, s1, s7
    s.or         s1, s6, s5
    s.shli       s5, s8, #32
    v.extract    s6, v4, #7
    v.extract    s7, v9, #8
    v.insert     v2, s16, #5
    s.cmp.ne     s8, s1, s9
    s.or         s1, s6, s5
    s.shli       s5, s7, #32
    v.extract    s6, v4, #8
    v.extract    s7, v9, #9
    v.insert     v2, s8, #6
    s.cmp.ne     s8, s1, s10
    s.or         s1, s6, s5
    s.shli       s5, s7, #32
    v.extract    s6, v4, #9
    v.extract    s7, v9, #10
    v.insert     v2, s8, #7
    s.cmp.ne     s8, s1, s11
    s.or         s1, s6, s5
    s.shli       s5, s7, #32
    v.extract    s6, v4, #10
    v.extract    s7, v9, #11
    v.insert     v2, s8, #8
    s.cmp.ne     s8, s1, s12
    s.or         s1, s6, s5
    s.shli       s5, s7, #32
    v.extract    s6, v4, #11
    v.extract    s7, v9, #12
    v.insert     v2, s8, #9
    s.cmp.ne     s8, s1, s14
    s.or         s1, s6, s5
    s.shli       s5, s7, #32
    v.extract    s6, v4, #12
    v.extract    s7, v9, #13
    v.insert     v2, s8, #10
    s.cmp.ne     s8, s1, s19
    s.or         s1, s6, s5
    s.shli       s5, s7, #32
    v.extract    s6, v4, #13
    v.extract    s7, v9, #14
    v.insert     v2, s8, #11
    s.cmp.ne     s8, s1, s18
    s.or         s1, s6, s5
    s.shli       s5, s7, #32
    v.extract    s6, v4, #14
    v.extract    s7, v9, #15
    v.insert     v2, s8, #12
    s.cmp.ne     s8, s1, s20
    s.or         s1, s6, s5
    s.shli       s5, s7, #32
    v.extract    s6, v4, #15
    v.insert     v2, s8, #13
    s.cmp.ne     s7, s1, s21
    s.or         s1, s6, s5
    v.insert     v2, s7, #14
    s.cmp.ne     s5, s1, s22
    v.movi       v3, #0
    v.insert     v2, s5, #15
    v.movi       v4, #0
    v.movi       v6, #0
    p.not        p1, p2
    s.muli       s1, s4, #64
    v.splat      v7, s3
    v.iota       v8                              // arange(0, VLEN)
    v.cmp.ne     p3, v2, v3
    v.cmp.ne     p4, v4, v6
    p.and        p5, p2, p3
    p.and        p3, p1, p4
    @p2 v.sel        v2, v5, v0
    v.add        v0, v7, v8
    v.movi       v3, #0
    v.splat      v4, s4
    v.movi       v5, #0
    v.movi       v6, #1
    v.movi       v7, #0
    p.or         p1, p5, p3
    v.movi       v8, #1
    v.movi       v9, #0
    vf.cmp.uo    p3, v2, v2
    v.cmp.ge     p4, v0, v3
    v.cmpi.lt    p5, v0, #16
    @p3 v.sel        v0, v6, v7
    v.cmp.ge     p3, v4, v5
    s.shli       s3, s4, #0                      // element offset -> bytes (x1)
    s.add        s5, s2, s1
    p.and        p6, p4, p5
    v.cmpi.lt    p4, v4, #2
    p.and        p5, p3, p4
    @p1 v.sel        v3, v8, v9
    v.reduce.or.b v4, v0
    v.movi       v0, #0
    s.add        s1, s13, s3                     // &out_ptr0[...]
    s.add        s2, s5, s24
    p.and        p1, p6, p5
    v.reduce.or  s3, v3
    vf.reduce.max.b v3, v2
    .li       s5, #2143289344
    v.splat      v2, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p3, v4, v0
    s.st.b       [s1, #0], s3                    // lane 0 of a broadcast is one word
    @p3 v.sel        v0, v2, v3
    v.movi       v2, #0
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s2, #0]
    vf.add       v4, v0, v2
    .li       s1, #1069066811
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1060205080
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v6, #0
    v.extract    s1, v4, #0
    v.splat      v4, s1
    s.shli       s1, s4, #4                      // x16 as a shift
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    s.shli       s3, s1, #2                      // element offset -> bytes (x4)
    vf.sub       v7, v3, v4
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s1
    s.add        s1, s15, s3                     // &out_ptr2[...]
    vf.mul       v8, v7, v0
    s.add        s3, s17, s2                     // &out_ptr3[...]
    v.cmpi.lt    p1, v3, #1
    v.add        v3, v1, v4
    v.exp2.approx v1, v8                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v7, v0, v8                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v3, v5
    vf.fma       v3, v1, v0, v1                  // 2**t * 2**d
    vf.cmp.o     p3, v3, v3
    @p3 v.sel        v0, v3, v1
    vf.add       v1, v0, v6
    @p2 v.st.w       [s1, #0], v0
    @p2 v.sel        v0, v1, v6
    vf.reduce.add.b v1, v0
    vf.add       v0, v1, v2
    @p1 v.st.w       [s3, #0], v0
__rctx_next:
    exit
