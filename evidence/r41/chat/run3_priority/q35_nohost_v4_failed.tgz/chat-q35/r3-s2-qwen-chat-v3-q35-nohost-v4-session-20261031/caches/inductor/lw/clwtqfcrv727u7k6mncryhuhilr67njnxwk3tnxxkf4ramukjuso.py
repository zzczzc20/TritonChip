# AOT ID: ['2_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/in/cin72u632x4zn6bmlnkfguiklza56nlucqhitrm5tirysc7rypda.py
# Topologically Sorted Source Nodes: [position_ids, position_ids_1, getitem_6, float_1, freqs, sin_1, getitem_8, cos_1, getitem_11], Original ATen: [aten.slice, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.select]
# Source node to ATen node mapping:
#   cos_1 => cos
#   float_1 => convert_element_type
#   freqs => mul
#   getitem_11 => select_13, slice_10
#   getitem_6 => unsqueeze_6
#   getitem_8 => select_1, slice_2
#   position_ids => slice_1
#   position_ids_1 => expand_1
#   sin_1 => sin
# Graph fragment:
#   %arg2_1 : Tensor "i64[4, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg4_1 : Tensor "f32[32][1]tnca:0" = PlaceHolder[target=arg4_1]
#   %slice_1 : Tensor "i64[3, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg2_1, 0, 1, 9223372036854775807), kwargs = {})
#   %expand_1 : Tensor "i64[3, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%slice_1, [3, -1, -1]), kwargs = {})
#   %unsqueeze_6 : Tensor "i64[3, 1, 1, 1][1, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%expand_1, 3), kwargs = {})
#   %convert_element_type : Tensor "f32[3, 1, 1, 1][1, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_6, torch.float32), kwargs = {})
#   %mul : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %arg4_1), kwargs = {})
#   %sin : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul,), kwargs = {})
#   %select_1 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_2 : Tensor "f32[1, 1, 11][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_1, 2, 1, 33, 3), kwargs = {})
#   %select_int : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_2, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default, 0, 0), kwargs = {})
#   %cos : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul,), kwargs = {})
#   %select_13 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_10 : Tensor "f32[1, 1, 11][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_13, 2, 1, 33, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_10, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default_1, 0, 0), kwargs = {})
#   return %select_scatter_default,%select_scatter_default_1
triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0 = async_compile.triton('triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 128}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1688}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 96
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = xindex // 32
    x0 = (xindex % 32)
    x2 = xindex
    tmp21 = tl.load(in_ptr0 + (1))
    tmp22 = tl.broadcast_to(tmp21, [XBLOCK])
    tmp24 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last')
    tmp28 = tl.load(in_ptr0 + (1 + x1), xmask, eviction_policy='evict_last')
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 1, tl.int64)
    tmp6 = tmp4 >= tmp5
    tmp7 = ((((-1) + x0) % 3)).to(tl.int64)
    tmp8 = (tmp7).to(tl.int64)
    tmp9 = tl.full([1], 0, tl.int64)
    tmp10 = tmp8 == tmp9
    tmp11 = tmp6 & tmp10
    tmp12 = tl.load(in_ptr0 + (2))
    tmp13 = tl.broadcast_to(tmp12, [XBLOCK])
    tmp14 = tl.where(tmp11, tmp13, 0)
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp11 & xmask, eviction_policy='evict_last', other=0.0)
    tmp17 = tmp15 * tmp16
    tmp18 = tl_math.sin(tmp17)
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp11, tmp18, tmp19)
    tmp23 = tmp22.to(tl.float32)
    tmp25 = tmp23 * tmp24
    tmp26 = tl_math.sin(tmp25)
    tmp27 = tl.where(tmp11, tmp20, tmp26)
    tmp29 = tmp28.to(tl.float32)
    tmp30 = tmp29 * tmp24
    tmp31 = tl_math.sin(tmp30)
    tmp32 = tl.where(tmp2, tmp27, tmp31)
    tmp33 = tl_math.cos(tmp17)
    tmp34 = tl.full(tmp33.shape, 0.0, tmp33.dtype)
    tmp35 = tl.where(tmp11, tmp33, tmp34)
    tmp36 = tl_math.cos(tmp25)
    tmp37 = tl.where(tmp11, tmp35, tmp36)
    tmp38 = tl_math.cos(tmp30)
    tmp39 = tl.where(tmp2, tmp37, tmp38)
    tl.store(out_ptr0 + (x2), tmp32, xmask)
    tl.store(out_ptr1 + (x2), tmp39, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/mc/cmckkhqrb5j4nhi7f4vjtjr4xgu3a4qeksef6hvyyhz23g2fds2g.py
# Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add_2, rsqrt, output, float_3, add_3, output_1, hidden_states, output_2, output_3], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_2 => add_2
#   add_3 => add_3
#   float_2 => convert_element_type_3
#   float_3 => convert_element_type_4
#   hidden_states => convert_element_type_5
#   inputs_embeds => embedding
#   mean => mean
#   output => mul_3
#   output_1 => mul_4
#   output_2 => triton_kernel_wrapper_mutation_199
#   output_3 => triton_kernel_wrapper_mutation_198
#   pow_1 => pow_1
#   rsqrt => rsqrt
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "bf16[248320, 2560][2560, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf2]
#   %arg5_1 : Tensor "bf16[2560][1]tnca:0" = PlaceHolder[target=arg5_1]
#   %embedding : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type_3 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_3, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add_2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_2,), kwargs = {})
#   %mul_3 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_3, %rsqrt), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_3 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_4, 1.0), kwargs = {})
#   %mul_4 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_3, %add_3), kwargs = {})
#   %convert_element_type_5 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_4, torch.bfloat16), kwargs = {})
#   %triton_kernel_wrapper_mutation_199 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1000, grid: [(1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1)], tma_descriptor_metadata: {}, kwargs: {A: %convert_element_type_5, B: %arg6_1, C: %empty, Bs: %arg7_1, M: 1, N: 8192, K: 2560, stride_am: 2560, stride_ak: 1, stride_bk: 1, stride_bn: 2560, stride_cm: 8192, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 20, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_198 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1001, grid: [(1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1)], tma_descriptor_metadata: {}, kwargs: {A: %convert_element_type_5, B: %arg8_1, C: %empty_1, Bs: %arg9_1, M: 1, N: 4096, K: 2560, stride_am: 2560, stride_ak: 1, stride_bk: 1, stride_bn: 2560, stride_cm: 4096, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 20, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %buf2,%buf4,%buf7,%convert_element_type_5
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 35840}, 'add_persistent_rblock': True, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1(in_ptr0, in_ptr1, in_ptr2, out_ptr1, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    _tmp7 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.device_assert((0 <= tmp1) & (tmp1 < 248320), "index out of bounds: 0 <= tmp1 < 248320")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2560*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp3.to(tl.float32)
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
    tmp7 = triton_helpers.promote_to_tensor(tl.sum(_tmp7, 0))
    tmp9 = tl.load(in_ptr0 + (0))
    tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp20 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp10) & (tmp10 < 248320), "index out of bounds: 0 <= tmp10 < 248320")
        tmp12 = tl.load(in_ptr1 + (r0_0 + 2560*tmp10), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tl.full([1], 2560.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1], 1e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tl.full([1], 1.0, tl.float32)
        tmp23 = tmp21 + tmp22
        tmp24 = tmp19 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp25, r0_mask)
        tl.store(out_ptr2 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp25, r0_mask)
        tl.store(out_ptr3 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp25, r0_mask)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_0 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '64', '1'], 'cpp': ['1L', '64L', '1L'], 'python_slow': ['1', '64', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '64', '1'], 'cpp': ['1L', '64L', '1L'], 'python_slow': ['1', '64', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '64', '1'], 'cpp': ['1L', '64L', '1L'], 'python_slow': ['1', '64', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '64', '1'], 'cpp': ['1L', '64L', '1L'], 'python_slow': ['1', '64', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '64', '1'], 'cpp': ['1L', '64L', '1L'], 'python_slow': ['1', '64', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '64', '1'], 'cpp': ['1L', '64L', '1L'], 'python_slow': ['1', '64', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '64', '1'], 'cpp': ['1L', '64L', '1L'], 'python_slow': ['1', '64', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '64', '1'], 'cpp': ['1L', '64L', '1L'], 'python_slow': ['1', '64', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '64', '1'], 'cpp': ['1L', '64L', '1L'], 'python_slow': ['1', '64', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '64', '1'], 'cpp': ['1L', '64L', '1L'], 'python_slow': ['1', '64', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '64', '1'], 'cpp': ['1L', '64L', '1L'], 'python_slow': ['1', '64', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '64', '1'], 'cpp': ['1L', '64L', '1L'], 'python_slow': ['1', '64', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_0', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'constexpr', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'M': 1, 'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_1 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '32', '1'], 'cpp': ['1L', '32L', '1L'], 'python_slow': ['1', '32', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '32', '1'], 'cpp': ['1L', '32L', '1L'], 'python_slow': ['1', '32', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '32', '1'], 'cpp': ['1L', '32L', '1L'], 'python_slow': ['1', '32', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '32', '1'], 'cpp': ['1L', '32L', '1L'], 'python_slow': ['1', '32', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '32', '1'], 'cpp': ['1L', '32L', '1L'], 'python_slow': ['1', '32', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '32', '1'], 'cpp': ['1L', '32L', '1L'], 'python_slow': ['1', '32', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '32', '1'], 'cpp': ['1L', '32L', '1L'], 'python_slow': ['1', '32', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '32', '1'], 'cpp': ['1L', '32L', '1L'], 'python_slow': ['1', '32', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '32', '1'], 'cpp': ['1L', '32L', '1L'], 'python_slow': ['1', '32', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '32', '1'], 'cpp': ['1L', '32L', '1L'], 'python_slow': ['1', '32', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '32', '1'], 'cpp': ['1L', '32L', '1L'], 'python_slow': ['1', '32', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '32', '1'], 'cpp': ['1L', '32L', '1L'], 'python_slow': ['1', '32', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_1', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'constexpr', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'M': 1, 'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/xs/cxsoatxq262ataabtakj274b47wjlkjjjr65eapviykli5lkxzvj.py
# Topologically Sorted Source Nodes: [cat_2], Original ATen: [aten.transpose, aten.cat]
# Source node to ATen node mapping:
#   cat_2 => cat, permute_3
# Graph fragment:
#   %copy__1 : Tensor "bf16[1, 8192, 4][32768, 4, 1]tnca:0" = PlaceHolder[target=copy__1]
#   %permute_3 : Tensor "bf16[1, 8192, 1][8192, 1, 8192]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%empty, [0, 2, 1]), kwargs = {})
#   %cat : Tensor "bf16[1, 8192, 5][40960, 5, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.cat.default](args = ([%arg13_1, %permute_3], -1), kwargs = {})
#   return %buf9
triton_poi_fused_cat_transpose_2 = async_compile.triton('triton_poi_fused_cat_transpose_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32768}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_transpose_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 196608}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_transpose_2(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32768
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 4)
    x1 = xindex // 4
    tmp0 = tl.load(in_ptr0 + (x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 5*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/mw/cmwgytlniiuxsao47jo3i53etcrwhk4piuzwnhqrm5ovkg7jpafz.py
# Topologically Sorted Source Nodes: [cat_2], Original ATen: [aten.transpose, aten.cat]
# Source node to ATen node mapping:
#   cat_2 => cat, permute_3
# Graph fragment:
#   %buf5 : Tensor  = PlaceHolder[target=buf5]
#   %permute_3 : Tensor "bf16[1, 8192, 1][8192, 1, 8192]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%empty, [0, 2, 1]), kwargs = {})
#   %cat : Tensor "bf16[1, 8192, 5][40960, 5, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.cat.default](args = ([%arg13_1, %permute_3], -1), kwargs = {})
#   return %buf10
triton_poi_fused_cat_transpose_3 = async_compile.triton('triton_poi_fused_cat_transpose_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_transpose_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 0}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_transpose_3(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None).to(tl.float32)
    tl.store(out_ptr0 + (5*x0), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/pk/cpk5d7kc2w3xh24eulnpja2m3l6xys67lb2azefrjp6bwcssofdu.py
# Topologically Sorted Source Nodes: [out, squeeze, unsqueeze, out_1, out_2], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
# Source node to ATen node mapping:
#   out => add_4, add_5, add_6, convert_element_type_10, convert_element_type_11, convert_element_type_12, mul_5, mul_6, mul_7, mul_8, select_24, select_25, select_26, select_27, select_28, select_29, select_30, select_31, slice_19, slice_20, slice_21, slice_22, view_10, view_7, view_8, view_9
#   out_1 => slice_23
#   out_2 => add_7, convert_element_type_13, convert_element_type_14, div, exp, neg
#   squeeze => squeeze
#   unsqueeze => unsqueeze_9
# Graph fragment:
#   %cat : Tensor "bf16[1, 8192, 5][40960, 5, 1]tnca:0" = PlaceHolder[target=cat]
#   %arg12_1 : Tensor "bf16[8192, 1, 4][4, 4, 1]tnca:0" = PlaceHolder[target=arg12_1]
#   %convert_element_type_13 : Tensor "f32[1, 8192, 1][8192, 1, 8192]tnca:0" = PlaceHolder[target=convert_element_type_13]
#   %convert_element_type_10 : Tensor "f32[1, 8192, 5][40960, 5, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%cat, torch.float32), kwargs = {})
#   %slice_19 : Tensor "f32[1, 8192, 2][40960, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_10, 2, 0, 2), kwargs = {})
#   %squeeze : Tensor "bf16[8192, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.squeeze.dim](args = (%arg12_1, 1), kwargs = {})
#   %unsqueeze_9 : Tensor "bf16[8192, 1, 4][4, 4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%squeeze, 1), kwargs = {})
#   %convert_element_type_11 : Tensor "f32[8192, 1, 4][4, 4, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_9, torch.float32), kwargs = {})
#   %select_24 : Tensor "f32[8192, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_11, 1, 0), kwargs = {})
#   %select_25 : Tensor "f32[8192][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_24, 1, 0), kwargs = {})
#   %view_7 : Tensor "f32[1, 8192, 1][32768, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_25, [1, -1, 1]), kwargs = {})
#   %mul_5 : Tensor "f32[1, 8192, 2][16384, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_19, %view_7), kwargs = {})
#   %slice_20 : Tensor "f32[1, 8192, 2][40960, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_10, 2, 1, 3), kwargs = {})
#   %select_26 : Tensor "f32[8192, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_11, 1, 0), kwargs = {})
#   %select_27 : Tensor "f32[8192][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_26, 1, 1), kwargs = {})
#   %view_8 : Tensor "f32[1, 8192, 1][32768, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_27, [1, -1, 1]), kwargs = {})
#   %mul_6 : Tensor "f32[1, 8192, 2][16384, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_20, %view_8), kwargs = {})
#   %add_4 : Tensor "f32[1, 8192, 2][16384, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_5, %mul_6), kwargs = {})
#   %slice_21 : Tensor "f32[1, 8192, 2][40960, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_10, 2, 2, 4), kwargs = {})
#   %select_28 : Tensor "f32[8192, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_11, 1, 0), kwargs = {})
#   %select_29 : Tensor "f32[8192][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_28, 1, 2), kwargs = {})
#   %view_9 : Tensor "f32[1, 8192, 1][32768, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_29, [1, -1, 1]), kwargs = {})
#   %mul_7 : Tensor "f32[1, 8192, 2][16384, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_21, %view_9), kwargs = {})
#   %add_5 : Tensor "f32[1, 8192, 2][16384, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4, %mul_7), kwargs = {})
#   %slice_22 : Tensor "f32[1, 8192, 2][40960, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_10, 2, 3, 5), kwargs = {})
#   %select_30 : Tensor "f32[8192, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_11, 1, 0), kwargs = {})
#   %select_31 : Tensor "f32[8192][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_30, 1, 3), kwargs = {})
#   %view_10 : Tensor "f32[1, 8192, 1][32768, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_31, [1, -1, 1]), kwargs = {})
#   %mul_8 : Tensor "f32[1, 8192, 2][16384, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_22, %view_10), kwargs = {})
#   %add_6 : Tensor "f32[1, 8192, 2][16384, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_5, %mul_8), kwargs = {})
#   %convert_element_type_12 : Tensor "bf16[1, 8192, 2][16384, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_6, torch.bfloat16), kwargs = {})
#   %slice_23 : Tensor "bf16[1, 8192, 1][16384, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_12, 2, -1, 9223372036854775807), kwargs = {})
#   %convert_element_type_13 : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_23, torch.float32), kwargs = {})
#   %neg : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_13,), kwargs = {})
#   %exp : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_7 : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_13, %add_7), kwargs = {})
#   %convert_element_type_14 : Tensor "bf16[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   return %convert_element_type_13,%convert_element_type_14
triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4 = async_compile.triton('triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 32768}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4(in_ptr0, in_ptr1, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (1 + 5*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (4*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp5 = tl.load(in_ptr0 + (2 + 5*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp7 = tl.load(in_ptr1 + (1 + 4*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp11 = tl.load(in_ptr0 + (3 + 5*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp13 = tl.load(in_ptr1 + (2 + 4*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp17 = tl.load(in_ptr0 + (4 + 5*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp19 = tl.load(in_ptr1 + (3 + 4*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp6 = tmp5.to(tl.float32)
    tmp8 = tmp7.to(tl.float32)
    tmp9 = tmp6 * tmp8
    tmp10 = tmp4 + tmp9
    tmp12 = tmp11.to(tl.float32)
    tmp14 = tmp13.to(tl.float32)
    tmp15 = tmp12 * tmp14
    tmp16 = tmp10 + tmp15
    tmp18 = tmp17.to(tl.float32)
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp18 * tmp20
    tmp22 = tmp16 + tmp21
    tmp23 = tmp22.to(tl.float32)
    tmp24 = tmp23.to(tl.float32)
    tmp25 = -tmp24
    tmp26 = libdevice.exp(tmp25)
    tmp27 = tl.full([1], 1.0, tl.float32)
    tmp28 = tmp26 + tmp27
    tmp29 = (tmp24 / tmp28)
    tmp30 = tmp29.to(tl.float32)
    tl.store(out_ptr1 + (x0), tmp30, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/zc/czcmcvfjw4mdidotxi4uplul2njxegif7hvvctpn2wgik6zhjw63.py
# Topologically Sorted Source Nodes: [out_2, mixed_qkv_2, split, key_1, key_2, transpose_3, key_3, mul_8, sum_2], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
# Source node to ATen node mapping:
#   key_1 => view_12
#   key_2 => clone_5, expand_5, unsqueeze_11, view_15
#   key_3 => clone_7, convert_element_type_18
#   mixed_qkv_2 => permute_4
#   mul_8 => mul_12
#   out_2 => add_7, convert_element_type_14, div, exp, neg
#   split => split_with_sizes
#   sum_2 => sum_2
#   transpose_3 => permute_6
# Graph fragment:
#   %convert_element_type_14 : Tensor "bf16[1, 8192, 1][8192, 1, 8192]tnca:0" = PlaceHolder[target=convert_element_type_14]
#   %neg : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_13,), kwargs = {})
#   %exp : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_7 : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_13, %add_7), kwargs = {})
#   %convert_element_type_14 : Tensor "bf16[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %permute_4 : Tensor "bf16[1, 1, 8192][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_14, [0, 2, 1]), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%permute_4, [2048, 2048, 4096], -1), kwargs = {})
#   %view_12 : Tensor "bf16[1, 1, 16, 128][8192, 1, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_3, [1, 1, -1, 128]), kwargs = {})
#   %unsqueeze_11 : Tensor "bf16[1, 1, 16, 1, 128][8192, 1, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view_12, 3), kwargs = {})
#   %expand_5 : Tensor "bf16[1, 1, 16, 2, 128][8192, 1, 128, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_11, [1, 1, 16, 2, 128]), kwargs = {})
#   %clone_5 : Tensor "bf16[1, 1, 16, 2, 128][4096, 4096, 256, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_5,), kwargs = {memory_format: torch.contiguous_format})
#   %view_15 : Tensor "bf16[1, 1, 32, 128][4096, 4096, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_5, [1, 1, 32, 128]), kwargs = {})
#   %permute_6 : Tensor "bf16[1, 32, 1, 128][4096, 128, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_15, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_18 : Tensor "f32[1, 32, 1, 128][4096, 128, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_6, torch.float32), kwargs = {})
#   %clone_7 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_18,), kwargs = {memory_format: torch.contiguous_format})
#   %mul_12 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_7, %clone_7), kwargs = {})
#   %sum_2 : Tensor "f32[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_12, [-1], True), kwargs = {})
#   return %sum_2
triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5 = async_compile.triton('triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 32, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 256, 'r0_': 8192}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 32
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0 + (2048), shape=[16, 128], strides=[128, 1], block_shape=[(1 + XBLOCK) // 2, R0_BLOCK])
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 2, r0_offset])[:, :, None], [(1 + XBLOCK) // 2, R0_BLOCK, ((2) * ((2) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (2)))]), [0, 2, 1]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/si/csiebfqpf6cd7egh4h4fpsyykjmw3tcc7yjgcgyxbhd7yo3axa6v.py
# Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add_2, rsqrt, output, float_3, add_3, output_1, hidden_states, float_4, exp, neg, a, float_5, add_4, softplus, g, transpose_6, getitem_21, exp_1], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
# Source node to ATen node mapping:
#   a => mm_1, permute_2, view_5, view_6
#   add_2 => add_2
#   add_3 => add_3
#   add_4 => add_8
#   exp => exp_1
#   exp_1 => exp_3
#   float_2 => convert_element_type_3
#   float_3 => convert_element_type_4
#   float_4 => convert_element_type_15
#   float_5 => convert_element_type_16
#   g => mul_9
#   getitem_21 => select_35
#   hidden_states => convert_element_type_5
#   inputs_embeds => embedding
#   mean => mean
#   neg => neg_1
#   output => mul_3
#   output_1 => mul_4
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   softplus => exp_2, gt, log1p, where
#   transpose_6 => permute_9
# Graph fragment:
#   %convert_element_type_5 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0" = PlaceHolder[target=convert_element_type_5]
#   %arg11_1 : Tensor "bf16[32, 2560][2560, 1]tnca:0" = PlaceHolder[target=arg11_1]
#   %arg14_1 : Tensor "bf16[32][1]tnca:0" = PlaceHolder[target=arg14_1]
#   %mm_1 : Tensor "bf16[1, 32][32, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %arg15_1 : Tensor "bf16[32][1]tnca:0" = PlaceHolder[target=arg15_1]
#   %embedding : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type_3 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_3, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add_2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_2,), kwargs = {})
#   %mul_3 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_3, %rsqrt), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_3 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_4, 1.0), kwargs = {})
#   %mul_4 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_3, %add_3), kwargs = {})
#   %convert_element_type_5 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_4, torch.bfloat16), kwargs = {})
#   %convert_element_type_15 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg14_1, torch.float32), kwargs = {})
#   %exp_1 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%convert_element_type_15,), kwargs = {})
#   %neg_1 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%exp_1,), kwargs = {})
#   %view_5 : Tensor "bf16[1, 2560][2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_5, [1, 2560]), kwargs = {})
#   %permute_2 : Tensor "bf16[2560, 32][1, 2560]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg11_1, [1, 0]), kwargs = {})
#   %mm_1 : Tensor "bf16[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_5, %permute_2), kwargs = {})
#   %view_6 : Tensor "bf16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 32]), kwargs = {})
#   %convert_element_type_16 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_6, torch.float32), kwargs = {})
#   %add_8 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_16, %arg15_1), kwargs = {})
#   %gt : Tensor "b8[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.gt.Scalar](args = (%add_8, 20), kwargs = {})
#   %exp_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%add_8,), kwargs = {})
#   %log1p : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.log1p.default](args = (%exp_2,), kwargs = {})
#   %where : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%gt, %add_8, %log1p), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%neg_1, %where), kwargs = {})
#   %permute_9 : Tensor "f32[1, 32, 1][32, 1, 32]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_9, [0, 2, 1]), kwargs = {})
#   %select_35 : Tensor "f32[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%permute_9, 2, 0), kwargs = {})
#   %exp_3 : Tensor "f32[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%select_35,), kwargs = {})
#   return %mm_1,%exp_3
triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6(arg_A, arg_B, in_ptr2, in_ptr3, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 32
    K = 2560
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2560

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2560*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 32*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2560*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 32*idx_m
    tmp0 = acc.to(tl.bfloat16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.load(in_ptr2 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp7 = tl.load(in_ptr3 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = libdevice.exp(tmp3)
    tmp5 = -tmp4
    tmp6 = tmp1.to(tl.float32)
    tmp8 = tmp7.to(tl.float32)
    tmp9 = tmp6 + tmp8
    tmp10 = tl.full([1], 20.0, tl.float32)
    tmp11 = tmp9 > tmp10
    tmp12 = libdevice.exp(tmp9)
    tmp13 = libdevice.log1p(tmp12)
    tmp14 = tl.where(tmp11, tmp9, tmp13)
    tmp15 = tmp5 * tmp14
    tmp16 = libdevice.exp(tmp15)
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp16, mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/kb/ckb5enfvelk6qtl7qbuylaw6kksz7v4wbuvwrlvywhijowhoz5fb.py
# Topologically Sorted Source Nodes: [out_2, mixed_qkv_2, split, key_1, key_2, transpose_3, key_3, add_6, inv_norm_1, key_4, k_t, float_4, exp, neg, a, float_5, add_4, softplus, g, transpose_6, getitem_21, exp_1, decay_t, last_recurrent_state_1, unsqueeze_2, mul_11, kv_mem], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
# Source node to ATen node mapping:
#   a => view_6
#   add_4 => add_8
#   add_6 => add_10
#   decay_t => unsqueeze_12, unsqueeze_13
#   exp => exp_1
#   exp_1 => exp_3
#   float_4 => convert_element_type_15
#   float_5 => convert_element_type_16
#   g => mul_9
#   getitem_21 => select_35
#   inv_norm_1 => rsqrt_2
#   k_t => select_33
#   key_1 => view_12
#   key_2 => clone_5, expand_5, unsqueeze_11, view_15
#   key_3 => clone_7, convert_element_type_18
#   key_4 => mul_13
#   kv_mem => sum_3
#   last_recurrent_state_1 => mul_14
#   mixed_qkv_2 => permute_4
#   mul_11 => mul_15
#   neg => neg_1
#   out_2 => add_7, convert_element_type_14, div, exp, neg
#   softplus => exp_2, gt, log1p, where
#   split => split_with_sizes
#   transpose_3 => permute_6
#   transpose_6 => permute_9
#   unsqueeze_2 => unsqueeze_15
# Graph fragment:
#   %copy__2 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]tnca:0" = PlaceHolder[target=copy__2]
#   %exp_3 : Tensor "f32[1, 32][32, 1]tnca:0" = PlaceHolder[target=exp_3]
#   %convert_element_type_14 : Tensor "bf16[1, 8192, 1][8192, 1, 8192]tnca:0" = PlaceHolder[target=convert_element_type_14]
#   %sum_2 : Tensor "f32[1, 32, 1, 1][32, 1, 32, 32]tnca:0" = PlaceHolder[target=sum_2]
#   %neg : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_13,), kwargs = {})
#   %exp : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_7 : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_13, %add_7), kwargs = {})
#   %convert_element_type_14 : Tensor "bf16[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %permute_4 : Tensor "bf16[1, 1, 8192][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_14, [0, 2, 1]), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%permute_4, [2048, 2048, 4096], -1), kwargs = {})
#   %view_12 : Tensor "bf16[1, 1, 16, 128][8192, 1, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_3, [1, 1, -1, 128]), kwargs = {})
#   %unsqueeze_11 : Tensor "bf16[1, 1, 16, 1, 128][8192, 1, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view_12, 3), kwargs = {})
#   %expand_5 : Tensor "bf16[1, 1, 16, 2, 128][8192, 1, 128, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_11, [1, 1, 16, 2, 128]), kwargs = {})
#   %clone_5 : Tensor "bf16[1, 1, 16, 2, 128][4096, 4096, 256, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_5,), kwargs = {memory_format: torch.contiguous_format})
#   %view_15 : Tensor "bf16[1, 1, 32, 128][4096, 4096, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_5, [1, 1, 32, 128]), kwargs = {})
#   %permute_6 : Tensor "bf16[1, 32, 1, 128][4096, 128, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_15, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_18 : Tensor "f32[1, 32, 1, 128][4096, 128, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_6, torch.float32), kwargs = {})
#   %clone_7 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_18,), kwargs = {memory_format: torch.contiguous_format})
#   %add_10 : Tensor "f32[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_10,), kwargs = {})
#   %mul_13 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_7, %rsqrt_2), kwargs = {})
#   %select_33 : Tensor "f32[1, 32, 128][4096, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.select.int](args = (%mul_13, 2, 0), kwargs = {})
#   %convert_element_type_15 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg14_1, torch.float32), kwargs = {})
#   %exp_1 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%convert_element_type_15,), kwargs = {})
#   %neg_1 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%exp_1,), kwargs = {})
#   %view_6 : Tensor "bf16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 32]), kwargs = {})
#   %convert_element_type_16 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_6, torch.float32), kwargs = {})
#   %add_8 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_16, %arg15_1), kwargs = {})
#   %gt : Tensor "b8[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.gt.Scalar](args = (%add_8, 20), kwargs = {})
#   %exp_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%add_8,), kwargs = {})
#   %log1p : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.log1p.default](args = (%exp_2,), kwargs = {})
#   %where : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%gt, %add_8, %log1p), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%neg_1, %where), kwargs = {})
#   %permute_9 : Tensor "f32[1, 32, 1][32, 1, 32]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_9, [0, 2, 1]), kwargs = {})
#   %select_35 : Tensor "f32[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%permute_9, 2, 0), kwargs = {})
#   %exp_3 : Tensor "f32[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%select_35,), kwargs = {})
#   %unsqueeze_12 : Tensor "f32[1, 32, 1][32, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp_3, 2), kwargs = {})
#   %unsqueeze_13 : Tensor "f32[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_12, 3), kwargs = {})
#   %mul_14 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg16_1, %unsqueeze_13), kwargs = {})
#   %unsqueeze_15 : Tensor "f32[1, 32, 128, 1][4096, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_33, -1), kwargs = {})
#   %mul_15 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_14, %unsqueeze_15), kwargs = {})
#   %sum_3 : Tensor "f32[1, 32, 128][4096, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_15, [-2]), kwargs = {})
#   return %sum_3
triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4096, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 2129920, 'r0_': 8192}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4096
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = (xindex % 128)
    x1 = xindex // 128
    tmp1 = tl.load(in_ptr1 + (x1), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2 + (2048), shape=[16, 128], strides=[128, 1], block_shape=[(255 + XBLOCK) // 256, R0_BLOCK])
    tmp5 = tl.load(in_ptr3 + (x1), None, eviction_policy='evict_last')
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (x0 + 128*r0_2 + 16384*x1), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 256, r0_offset])[:, :, None], [(255 + XBLOCK) // 256, R0_BLOCK, ((256) * ((256) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (256)))]), [0, 2, 1]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 * tmp1
        tmp4 = tmp3.to(tl.float32)
        tmp6 = tl.full([1], 1e-06, tl.float32)
        tmp7 = tmp5 + tmp6
        tmp8 = libdevice.rsqrt(tmp7)
        tmp9 = tmp4 * tmp8
        tmp10 = tmp2 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tl.store(out_ptr0 + (x3), tmp12, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/r3/cr3gptxr35g3eskxsuoe7xsbasbt6topblnh3kvkuqfycrdkioga.py
# Topologically Sorted Source Nodes: [b, beta, transpose_5, beta_1], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
# Source node to ATen node mapping:
#   b => mm, permute_1, view_3, view_4
#   beta => sigmoid
#   beta_1 => clone_9, convert_element_type_20
#   transpose_5 => permute_8
# Graph fragment:
#   %convert_element_type_5 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0" = PlaceHolder[target=convert_element_type_5]
#   %arg10_1 : Tensor "bf16[32, 2560][2560, 1]tnca:0" = PlaceHolder[target=arg10_1]
#   %mm : Tensor "bf16[1, 32][32, 1]tnca:0" = PlaceHolder[target=mm]
#   %view_3 : Tensor "bf16[1, 2560][2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_5, [1, 2560]), kwargs = {})
#   %permute_1 : Tensor "bf16[2560, 32][1, 2560]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg10_1, [1, 0]), kwargs = {})
#   %mm : Tensor "bf16[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_3, %permute_1), kwargs = {})
#   %view_4 : Tensor "bf16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 32]), kwargs = {})
#   %sigmoid : Tensor "bf16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%view_4,), kwargs = {})
#   %permute_8 : Tensor "bf16[1, 32, 1][32, 1, 32]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%sigmoid, [0, 2, 1]), kwargs = {})
#   %convert_element_type_20 : Tensor "f32[1, 32, 1][32, 1, 32]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_8, torch.float32), kwargs = {})
#   %clone_9 : Tensor "f32[1, 32, 1][32, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_20,), kwargs = {memory_format: torch.contiguous_format})
#   return %mm,%clone_9
triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr1': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8(arg_A, arg_B, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 32
    K = 2560
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2560
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2560

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2560*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 32*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2560*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 32*idx_m
    tmp0 = acc.to(tl.bfloat16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.sigmoid(tmp1)
    tmp3 = tmp2.to(tl.float32)
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp3, mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/h2/ch2ry5psyutjsfy4pgdz4qzuatrc2xomg2afmyzgkp4h5r44zvsi.py
# Topologically Sorted Source Nodes: [out_2, mixed_qkv_2, split, key_1, key_2, transpose_3, key_3, add_6, inv_norm_1, key_4, k_t, unsqueeze_3, value_1, transpose_4, value_2, v_t, float_4, exp, neg, a, float_5, add_4, softplus, g, transpose_6, getitem_21, exp_1, decay_t, last_recurrent_state_1, sub, b, beta, transpose_5, beta_1, getitem_23, beta_t, delta, unsqueeze_4, mul_13, last_recurrent_state_2], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
# Source node to ATen node mapping:
#   a => view_6
#   add_4 => add_8
#   add_6 => add_10
#   b => view_4
#   beta => sigmoid
#   beta_1 => clone_9, convert_element_type_20
#   beta_t => unsqueeze_14
#   decay_t => unsqueeze_12, unsqueeze_13
#   delta => mul_16
#   exp => exp_1
#   exp_1 => exp_3
#   float_4 => convert_element_type_15
#   float_5 => convert_element_type_16
#   g => mul_9
#   getitem_21 => select_35
#   getitem_23 => select_36
#   inv_norm_1 => rsqrt_2
#   k_t => select_33
#   key_1 => view_12
#   key_2 => clone_5, expand_5, unsqueeze_11, view_15
#   key_3 => clone_7, convert_element_type_18
#   key_4 => mul_13
#   last_recurrent_state_1 => mul_14
#   last_recurrent_state_2 => add_11
#   mixed_qkv_2 => permute_4
#   mul_13 => mul_17
#   neg => neg_1
#   out_2 => add_7, convert_element_type_14, div, exp, neg
#   softplus => exp_2, gt, log1p, where
#   split => split_with_sizes
#   sub => sub
#   transpose_3 => permute_6
#   transpose_4 => permute_7
#   transpose_5 => permute_8
#   transpose_6 => permute_9
#   unsqueeze_3 => unsqueeze_16
#   unsqueeze_4 => unsqueeze_17
#   v_t => select_34
#   value_1 => view_13
#   value_2 => clone_8, convert_element_type_19
# Graph fragment:
#   %copy__2 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]tnca:0" = PlaceHolder[target=copy__2]
#   %exp_3 : Tensor "f32[1, 32][32, 1]tnca:0" = PlaceHolder[target=exp_3]
#   %convert_element_type_14 : Tensor "bf16[1, 8192, 1][8192, 1, 8192]tnca:0" = PlaceHolder[target=convert_element_type_14]
#   %sum_2 : Tensor "f32[1, 32, 1, 1][32, 1, 32, 32]tnca:0" = PlaceHolder[target=sum_2]
#   %sum_3 : Tensor "f32[1, 32, 128][4096, 128, 1]tnca:0" = PlaceHolder[target=sum_3]
#   %clone_9 : Tensor "f32[1, 32, 1][32, 1, 32]tnca:0" = PlaceHolder[target=clone_9]
#   %add_11 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]tnca:0" = PlaceHolder[target=add_11]
#   %neg : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_13,), kwargs = {})
#   %exp : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_7 : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_13, %add_7), kwargs = {})
#   %convert_element_type_14 : Tensor "bf16[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %permute_4 : Tensor "bf16[1, 1, 8192][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_14, [0, 2, 1]), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%permute_4, [2048, 2048, 4096], -1), kwargs = {})
#   %view_12 : Tensor "bf16[1, 1, 16, 128][8192, 1, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_3, [1, 1, -1, 128]), kwargs = {})
#   %unsqueeze_11 : Tensor "bf16[1, 1, 16, 1, 128][8192, 1, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view_12, 3), kwargs = {})
#   %expand_5 : Tensor "bf16[1, 1, 16, 2, 128][8192, 1, 128, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_11, [1, 1, 16, 2, 128]), kwargs = {})
#   %clone_5 : Tensor "bf16[1, 1, 16, 2, 128][4096, 4096, 256, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_5,), kwargs = {memory_format: torch.contiguous_format})
#   %view_15 : Tensor "bf16[1, 1, 32, 128][4096, 4096, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_5, [1, 1, 32, 128]), kwargs = {})
#   %permute_6 : Tensor "bf16[1, 32, 1, 128][4096, 128, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_15, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_18 : Tensor "f32[1, 32, 1, 128][4096, 128, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_6, torch.float32), kwargs = {})
#   %clone_7 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_18,), kwargs = {memory_format: torch.contiguous_format})
#   %add_10 : Tensor "f32[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_10,), kwargs = {})
#   %mul_13 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_7, %rsqrt_2), kwargs = {})
#   %select_33 : Tensor "f32[1, 32, 128][4096, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.select.int](args = (%mul_13, 2, 0), kwargs = {})
#   %unsqueeze_16 : Tensor "f32[1, 32, 128, 1][4096, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_33, -1), kwargs = {})
#   %view_13 : Tensor "bf16[1, 1, 32, 128][8192, 1, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_4, [1, 1, -1, 128]), kwargs = {})
#   %permute_7 : Tensor "bf16[1, 32, 1, 128][8192, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_13, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 32, 1, 128][8192, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_7, torch.float32), kwargs = {})
#   %clone_8 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_19,), kwargs = {memory_format: torch.contiguous_format})
#   %select_34 : Tensor "f32[1, 32, 128][4096, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%clone_8, 2, 0), kwargs = {})
#   %convert_element_type_15 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg14_1, torch.float32), kwargs = {})
#   %exp_1 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%convert_element_type_15,), kwargs = {})
#   %neg_1 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%exp_1,), kwargs = {})
#   %view_6 : Tensor "bf16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 32]), kwargs = {})
#   %convert_element_type_16 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_6, torch.float32), kwargs = {})
#   %add_8 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_16, %arg15_1), kwargs = {})
#   %gt : Tensor "b8[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.gt.Scalar](args = (%add_8, 20), kwargs = {})
#   %exp_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%add_8,), kwargs = {})
#   %log1p : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.log1p.default](args = (%exp_2,), kwargs = {})
#   %where : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%gt, %add_8, %log1p), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%neg_1, %where), kwargs = {})
#   %permute_9 : Tensor "f32[1, 32, 1][32, 1, 32]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_9, [0, 2, 1]), kwargs = {})
#   %select_35 : Tensor "f32[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%permute_9, 2, 0), kwargs = {})
#   %exp_3 : Tensor "f32[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%select_35,), kwargs = {})
#   %unsqueeze_12 : Tensor "f32[1, 32, 1][32, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp_3, 2), kwargs = {})
#   %unsqueeze_13 : Tensor "f32[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_12, 3), kwargs = {})
#   %mul_14 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg16_1, %unsqueeze_13), kwargs = {})
#   %sub : Tensor "f32[1, 32, 128][4096, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%select_34, %sum_3), kwargs = {})
#   %view_4 : Tensor "bf16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 32]), kwargs = {})
#   %sigmoid : Tensor "bf16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%view_4,), kwargs = {})
#   %permute_8 : Tensor "bf16[1, 32, 1][32, 1, 32]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%sigmoid, [0, 2, 1]), kwargs = {})
#   %convert_element_type_20 : Tensor "f32[1, 32, 1][32, 1, 32]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_8, torch.float32), kwargs = {})
#   %clone_9 : Tensor "f32[1, 32, 1][32, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_20,), kwargs = {memory_format: torch.contiguous_format})
#   %select_36 : Tensor "f32[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%clone_9, 2, 0), kwargs = {})
#   %unsqueeze_14 : Tensor "f32[1, 32, 1][32, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_36, -1), kwargs = {})
#   %mul_16 : Tensor "f32[1, 32, 128][4096, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub, %unsqueeze_14), kwargs = {})
#   %unsqueeze_17 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_16, -2), kwargs = {})
#   %mul_17 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%unsqueeze_16, %unsqueeze_17), kwargs = {})
#   %add_11 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_14, %mul_17), kwargs = {})
#   %copy__2 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]tnca:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg16_1, %add_11), kwargs = {})
#   return %add_11,%buf1245
triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9', 'mutated_arg_names': ['in_ptr0', 'out_ptr1'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 10518912}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 524288
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x3 = xindex
    x2 = xindex // 16384
    x1 = ((xindex // 128) % 128)
    x0 = (xindex % 128)
    tmp0 = tl.load(in_ptr0 + (x3), None)
    tmp1 = tl.load(in_ptr1 + (x2), None, eviction_policy='evict_last')
    tmp3 = tl.load(in_ptr2 + (2048 + x1 + 128*(x2 // 2)), None, eviction_policy='evict_last').to(tl.float32)
    tmp5 = tl.load(in_ptr3 + (x2), None, eviction_policy='evict_last')
    tmp10 = tl.load(in_ptr2 + (4096 + x0 + 128*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp12 = tl.load(in_ptr4 + (x0 + 128*x2), None, eviction_policy='evict_last')
    tmp14 = tl.load(in_ptr5 + (x2), None, eviction_policy='evict_last')
    tmp2 = tmp0 * tmp1
    tmp4 = tmp3.to(tl.float32)
    tmp6 = tl.full([1], 1e-06, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = libdevice.rsqrt(tmp7)
    tmp9 = tmp4 * tmp8
    tmp11 = tmp10.to(tl.float32)
    tmp13 = tmp11 - tmp12
    tmp15 = tmp13 * tmp14
    tmp16 = tmp9 * tmp15
    tmp17 = tmp2 + tmp16
    tl.store(out_ptr0 + (x3), tmp17, None)
    tl.store(out_ptr1 + (x3), tmp17, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/kh/ckhq2st76e67poupsg7s4kshjyzicmfcjrej4voz4dkesfdatryg.py
# Topologically Sorted Source Nodes: [out_2, mixed_qkv_2, split, query_1, query_2, transpose_2, query_3, mul_6, sum_1], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
# Source node to ATen node mapping:
#   mixed_qkv_2 => permute_4
#   mul_6 => mul_10
#   out_2 => add_7, convert_element_type_14, div, exp, neg
#   query_1 => view_11
#   query_2 => clone_4, expand_4, unsqueeze_10, view_14
#   query_3 => clone_6, convert_element_type_17
#   split => split_with_sizes
#   sum_1 => sum_1
#   transpose_2 => permute_5
# Graph fragment:
#   %convert_element_type_14 : Tensor "bf16[1, 8192, 1][8192, 1, 8192]tnca:0" = PlaceHolder[target=convert_element_type_14]
#   %neg : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_13,), kwargs = {})
#   %exp : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_7 : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_13, %add_7), kwargs = {})
#   %convert_element_type_14 : Tensor "bf16[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %permute_4 : Tensor "bf16[1, 1, 8192][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_14, [0, 2, 1]), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%permute_4, [2048, 2048, 4096], -1), kwargs = {})
#   %view_11 : Tensor "bf16[1, 1, 16, 128][8192, 1, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_2, [1, 1, -1, 128]), kwargs = {})
#   %unsqueeze_10 : Tensor "bf16[1, 1, 16, 1, 128][8192, 1, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view_11, 3), kwargs = {})
#   %expand_4 : Tensor "bf16[1, 1, 16, 2, 128][8192, 1, 128, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_10, [1, 1, 16, 2, 128]), kwargs = {})
#   %clone_4 : Tensor "bf16[1, 1, 16, 2, 128][4096, 4096, 256, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_4,), kwargs = {memory_format: torch.contiguous_format})
#   %view_14 : Tensor "bf16[1, 1, 32, 128][4096, 4096, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_4, [1, 1, 32, 128]), kwargs = {})
#   %permute_5 : Tensor "bf16[1, 32, 1, 128][4096, 128, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_14, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_17 : Tensor "f32[1, 32, 1, 128][4096, 128, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_5, torch.float32), kwargs = {})
#   %clone_6 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_17,), kwargs = {memory_format: torch.contiguous_format})
#   %mul_10 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_6, %clone_6), kwargs = {})
#   %sum_1 : Tensor "f32[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_10, [-1], True), kwargs = {})
#   return %sum_1
triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10 = async_compile.triton('triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 32, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 256, 'r0_': 8192}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 32
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 128], strides=[128, 1], block_shape=[(1 + XBLOCK) // 2, R0_BLOCK])
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 2, r0_offset])[:, :, None], [(1 + XBLOCK) // 2, R0_BLOCK, ((2) * ((2) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (2)))]), [0, 2, 1]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/lz/clz2svpessalwtmxlgznxagmwy3pyibztxybklwqkjdpfkg4pkat.py
# Topologically Sorted Source Nodes: [out_2, mixed_qkv_2, split, query_1, query_2, transpose_2, query_3, add_5, inv_norm, query_4, query_5, q_t, unsqueeze_5, mul_14, sum_4], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
# Source node to ATen node mapping:
#   add_5 => add_9
#   inv_norm => rsqrt_1
#   mixed_qkv_2 => permute_4
#   mul_14 => mul_18
#   out_2 => add_7, convert_element_type_14, div, exp, neg
#   q_t => select_32
#   query_1 => view_11
#   query_2 => clone_4, expand_4, unsqueeze_10, view_14
#   query_3 => clone_6, convert_element_type_17
#   query_4 => mul_11
#   query_5 => div_1
#   split => split_with_sizes
#   sum_4 => sum_4
#   transpose_2 => permute_5
#   unsqueeze_5 => unsqueeze_18
# Graph fragment:
#   %add_11 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]tnca:0" = PlaceHolder[target=add_11]
#   %convert_element_type_14 : Tensor "bf16[1, 8192, 1][8192, 1, 8192]tnca:0" = PlaceHolder[target=convert_element_type_14]
#   %sum_1 : Tensor "f32[1, 32, 1, 1][32, 1, 32, 32]tnca:0" = PlaceHolder[target=sum_1]
#   %neg : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_13,), kwargs = {})
#   %exp : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_7 : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_13, %add_7), kwargs = {})
#   %convert_element_type_14 : Tensor "bf16[1, 8192, 1][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %permute_4 : Tensor "bf16[1, 1, 8192][8192, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_14, [0, 2, 1]), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%permute_4, [2048, 2048, 4096], -1), kwargs = {})
#   %view_11 : Tensor "bf16[1, 1, 16, 128][8192, 1, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_2, [1, 1, -1, 128]), kwargs = {})
#   %unsqueeze_10 : Tensor "bf16[1, 1, 16, 1, 128][8192, 1, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view_11, 3), kwargs = {})
#   %expand_4 : Tensor "bf16[1, 1, 16, 2, 128][8192, 1, 128, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_10, [1, 1, 16, 2, 128]), kwargs = {})
#   %clone_4 : Tensor "bf16[1, 1, 16, 2, 128][4096, 4096, 256, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_4,), kwargs = {memory_format: torch.contiguous_format})
#   %view_14 : Tensor "bf16[1, 1, 32, 128][4096, 4096, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_4, [1, 1, 32, 128]), kwargs = {})
#   %permute_5 : Tensor "bf16[1, 32, 1, 128][4096, 128, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_14, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_17 : Tensor "f32[1, 32, 1, 128][4096, 128, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_5, torch.float32), kwargs = {})
#   %clone_6 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_17,), kwargs = {memory_format: torch.contiguous_format})
#   %add_9 : Tensor "f32[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 32, 1, 1][32, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_9,), kwargs = {})
#   %mul_11 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_6, %rsqrt_1), kwargs = {})
#   %div_1 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%mul_11, 11.313708498984761), kwargs = {})
#   %select_32 : Tensor "f32[1, 32, 128][4096, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%div_1, 2, 0), kwargs = {})
#   %unsqueeze_18 : Tensor "f32[1, 32, 128, 1][4096, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_32, -1), kwargs = {})
#   %mul_18 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_11, %unsqueeze_18), kwargs = {})
#   %sum_4 : Tensor "f32[1, 32, 128][4096, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_18, [-2]), kwargs = {})
#   return %sum_4
triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11 = async_compile.triton('triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4096, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 2129920, 'r0_': 8192}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4096
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = (xindex % 128)
    x1 = xindex // 128
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr1, shape=[16, 128], strides=[128, 1], block_shape=[(255 + XBLOCK) // 256, R0_BLOCK])
    tmp3 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (x0 + 128*r0_2 + 16384*x1), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 256, r0_offset])[:, :, None], [(255 + XBLOCK) // 256, R0_BLOCK, ((256) * ((256) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (256)))]), [0, 2, 1]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp1.to(tl.float32)
        tmp4 = tl.full([1], 1e-06, tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = libdevice.rsqrt(tmp5)
        tmp7 = tmp2 * tmp6
        tmp8 = tl.full([1], 0.08838834764831843, tl.float32)
        tmp9 = tmp7 * tmp8
        tmp10 = tmp0 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tl.store(out_ptr0 + (x3), tmp12, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/gr/cgrcdxafst5dt7vmaobs55cqdo6wvndldap4c743xull7zhwpizh.py
# Topologically Sorted Source Nodes: [core_attn_out, core_attn_out_1, core_attn_out_2, hidden_states_1, pow_2, variance], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   core_attn_out => full_default
#   core_attn_out_1 => convert_element_type_21, permute_11
#   core_attn_out_2 => view_16
#   hidden_states_1 => convert_element_type_22
#   pow_2 => pow_2
#   variance => mean_1
# Graph fragment:
#   %sum_4 : Tensor "f32[1, 32, 128][4096, 128, 1]tnca:0" = PlaceHolder[target=sum_4]
#   %full_default : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.full.default](args = ([1, 32, 1, 128], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %select_scatter_default_2 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%full_default, %sum_4, 2, 0), kwargs = {})
#   %permute_11 : Tensor "f32[1, 1, 32, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%select_scatter_default_2, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_21 : Tensor "bf16[1, 1, 32, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_11, torch.bfloat16), kwargs = {})
#   %view_16 : Tensor "bf16[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_21, [-1, 128]), kwargs = {})
#   %convert_element_type_22 : Tensor "f32[32, 128][128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_16, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_22, 2), kwargs = {})
#   %mean_1 : Tensor "f32[32, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   return %buf24
triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12 = async_compile.triton('triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 32, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 256, 'r0_': 16384}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 32
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[32, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp2 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp0 = tl.full([1], 0, tl.int32)
        tmp1 = tmp0 == tmp0
        tmp3 = tl.full([1], 0.0, tl.float32)
        tmp4 = tl.where(tmp1, tmp2, tmp3)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tl.store(out_ptr0 + (x0), tmp9, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/ym/cymapjdtt6pib2szw2wmj5tyj52kkj6wpg3hgh5qlpsaqak3mnns.py
# Topologically Sorted Source Nodes: [core_attn_out, core_attn_out_1, core_attn_out_2, hidden_states_1, pow_2, variance, add_8, rsqrt_3, hidden_states_2, to_14, hidden_states_3, to_15, silu_1, hidden_states_4, core_attn_out_3, core_attn_out_4, output_4], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
# Source node to ATen node mapping:
#   add_8 => add_12
#   core_attn_out => full_default
#   core_attn_out_1 => convert_element_type_21, permute_11
#   core_attn_out_2 => view_16
#   core_attn_out_3 => convert_element_type_25
#   core_attn_out_4 => view_21
#   hidden_states_1 => convert_element_type_22
#   hidden_states_2 => mul_19
#   hidden_states_3 => mul_20
#   hidden_states_4 => mul_21
#   output_4 => triton_kernel_wrapper_mutation_197
#   pow_2 => pow_2
#   rsqrt_3 => rsqrt_3
#   silu_1 => add_13, div_2, exp_4, neg_2
#   to_14 => convert_element_type_23
#   to_15 => convert_element_type_24, view_19, view_20
#   variance => mean_1
# Graph fragment:
#   %arg17_1 : Tensor "bf16[128][1]tnca:0" = PlaceHolder[target=arg17_1]
#   %sum_4 : Tensor "f32[1, 32, 128][4096, 128, 1]tnca:0" = PlaceHolder[target=sum_4]
#   %buf24 : Tensor "f32[32, 1][1, 32]tnca:0" = PlaceHolder[target=buf24]
#   %buf8 : Tensor  = PlaceHolder[target=buf8]
#   %full_default : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.full.default](args = ([1, 32, 1, 128], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %select_scatter_default_2 : Tensor "f32[1, 32, 1, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%full_default, %sum_4, 2, 0), kwargs = {})
#   %permute_11 : Tensor "f32[1, 1, 32, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%select_scatter_default_2, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_21 : Tensor "bf16[1, 1, 32, 128][4096, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_11, torch.bfloat16), kwargs = {})
#   %view_16 : Tensor "bf16[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_21, [-1, 128]), kwargs = {})
#   %convert_element_type_22 : Tensor "f32[32, 128][128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_16, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_22, 2), kwargs = {})
#   %mean_1 : Tensor "f32[32, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %add_12 : Tensor "f32[32, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[32, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_12,), kwargs = {})
#   %mul_19 : Tensor "f32[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_22, %rsqrt_3), kwargs = {})
#   %convert_element_type_23 : Tensor "bf16[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_19, torch.bfloat16), kwargs = {})
#   %mul_20 : Tensor "bf16[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg17_1, %convert_element_type_23), kwargs = {})
#   %view_19 : Tensor "bf16[1, 1, 32, 128][4096, 4096, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_1, [1, 1, -1, 128]), kwargs = {})
#   %view_20 : Tensor "bf16[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_19, [-1, 128]), kwargs = {})
#   %convert_element_type_24 : Tensor "f32[32, 128][128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_20, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_24,), kwargs = {})
#   %exp_4 : Tensor "f32[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_13 : Tensor "f32[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_4, 1), kwargs = {})
#   %div_2 : Tensor "f32[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_24, %add_13), kwargs = {})
#   %mul_21 : Tensor "f32[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_20, %div_2), kwargs = {})
#   %convert_element_type_25 : Tensor "bf16[32, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_21, torch.bfloat16), kwargs = {})
#   %view_21 : Tensor "bf16[1, 1, 4096][4096, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_25, [1, 1, -1]), kwargs = {})
#   %triton_kernel_wrapper_mutation_197 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1002, grid: [(1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1)], tma_descriptor_metadata: {}, kwargs: {A: %view_21, B: %arg18_1, C: %empty_2, Bs: %arg19_1, M: 1, N: 2560, K: 4096, stride_am: 4096, stride_ak: 1, stride_bk: 1, stride_bn: 4096, stride_cm: 2560, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 32, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %buf26
triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13 = async_compile.triton('triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 4096}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 33152}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 4096
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + ((x0 % 128)), None).to(tl.float32)
    tmp3 = tl.load(in_ptr1 + (x0), None)
    tmp8 = tl.load(in_ptr2 + (x0 // 128), None, eviction_policy='evict_last')
    tmp18 = tl.load(in_ptr3 + (x0), None).to(tl.float32)
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp1 == tmp1
    tmp4 = tl.full([1], 0.0, tl.float32)
    tmp5 = tl.where(tmp2, tmp3, tmp4)
    tmp6 = tmp5.to(tl.float32)
    tmp7 = tmp6.to(tl.float32)
    tmp9 = tl.full([1], 128.0, tl.float32)
    tmp10 = (tmp8 / tmp9)
    tmp11 = tl.full([1], 1e-06, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = libdevice.rsqrt(tmp12)
    tmp14 = tmp7 * tmp13
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tmp0 * tmp15
    tmp17 = tmp16.to(tl.float32)
    tmp19 = tmp18.to(tl.float32)
    tmp20 = -tmp19
    tmp21 = libdevice.exp(tmp20)
    tmp22 = tl.full([1], 1.0, tl.float32)
    tmp23 = tmp21 + tmp22
    tmp24 = (tmp19 / tmp23)
    tmp25 = tmp17 * tmp24
    tmp26 = tmp25.to(tl.float32)
    tl.store(out_ptr0 + (x0), tmp26, None)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_2 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_2', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'constexpr', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'M': 1, 'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (14,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/ia/ciaqmxoze7pktfydhjihu4q3fqqltf3na42m5ngo7hwijv5evadn.py
# Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_5, float_6, pow_3, mean_2, add_10, rsqrt_4, output_5, float_7, add_11, output_6, hidden_states_6], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_10 => add_15
#   add_11 => add_16
#   float_6 => convert_element_type_26
#   float_7 => convert_element_type_27
#   hidden_states_5 => add_14
#   hidden_states_6 => convert_element_type_28
#   inputs_embeds => embedding
#   mean_2 => mean_2
#   output_5 => mul_22
#   output_6 => mul_23
#   pow_3 => pow_3
#   rsqrt_4 => rsqrt_4
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "bf16[248320, 2560][2560, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf27 : Tensor  = PlaceHolder[target=buf27]
#   %buf28 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf28]
#   %arg20_1 : Tensor "bf16[2560][1]tnca:0" = PlaceHolder[target=arg20_1]
#   %embedding : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %add_14 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %empty_2), kwargs = {})
#   %convert_element_type_26 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_14, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_26, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %add_15 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, 1e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_15,), kwargs = {})
#   %mul_22 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_26, %rsqrt_4), kwargs = {})
#   %convert_element_type_27 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg20_1, torch.float32), kwargs = {})
#   %add_16 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_27, 1.0), kwargs = {})
#   %mul_23 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_22, %add_16), kwargs = {})
#   %convert_element_type_28 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_23, torch.bfloat16), kwargs = {})
#   return %buf28,%convert_element_type_28
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_14 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 15360}, 'add_persistent_rblock': True, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_14(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 248320), "index out of bounds: 0 <= tmp1 < 248320")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2560*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tmp11 = tl.load(in_ptr0 + (0))
    tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp24 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp12) & (tmp12 < 248320), "index out of bounds: 0 <= tmp12 < 248320")
        tmp14 = tl.load(in_ptr1 + (r0_0 + 2560*tmp12), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tl.full([1], 2560.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp20 = tl.full([1], 1e-06, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = libdevice.rsqrt(tmp21)
        tmp23 = tmp17 * tmp22
        tmp25 = tmp24.to(tl.float32)
        tmp26 = tl.full([1], 1.0, tl.float32)
        tmp27 = tmp25 + tmp26
        tmp28 = tmp23 * tmp27
        tmp29 = tmp28.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp29, r0_mask)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_3 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '72', '1'], 'cpp': ['1L', '72L', '1L'], 'python_slow': ['1', '72', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_3', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'constexpr', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'M': 1, 'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/r6/cr6sbuptfdwssibeg6yav3yt3lu5ofrmwxnnko4ejkqsmvoya2ct.py
# Topologically Sorted Source Nodes: [silu_2, mul_20, output_9], Original ATen: [aten.silu, aten.mul]
# Source node to ATen node mapping:
#   mul_20 => mul_24
#   output_9 => triton_kernel_wrapper_mutation_194
#   silu_2 => add_17, convert_element_type_29, convert_element_type_30, div_3, exp_5, neg_3
# Graph fragment:
#   %buf31 : Tensor  = PlaceHolder[target=buf31]
#   %buf33 : Tensor  = PlaceHolder[target=buf33]
#   %convert_element_type_29 : Tensor "f32[1, 1, 9216][9216, 9216, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty_3, torch.float32), kwargs = {})
#   %neg_3 : Tensor "f32[1, 1, 9216][9216, 9216, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_29,), kwargs = {})
#   %exp_5 : Tensor "f32[1, 1, 9216][9216, 9216, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_3,), kwargs = {})
#   %add_17 : Tensor "f32[1, 1, 9216][9216, 9216, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_5, 1), kwargs = {})
#   %div_3 : Tensor "f32[1, 1, 9216][9216, 9216, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_29, %add_17), kwargs = {})
#   %convert_element_type_30 : Tensor "bf16[1, 1, 9216][9216, 9216, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_3, torch.bfloat16), kwargs = {})
#   %mul_24 : Tensor "bf16[1, 1, 9216][9216, 9216, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_30, %empty_4), kwargs = {})
#   %triton_kernel_wrapper_mutation_194 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1005, grid: [(1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_24, B: %arg25_1, C: %empty_5, Bs: %arg26_1, M: 1, N: 2560, K: 9216, stride_am: 9216, stride_ak: 1, stride_bk: 1, stride_bn: 9216, stride_cm: 2560, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 72, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %buf35
triton_poi_fused_mul_silu_15 = async_compile.triton('triton_poi_fused_mul_silu_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_mul_silu_15', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 36864}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_mul_silu_15(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 9216
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tmp8 = tl.load(in_ptr1 + (x0), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = -tmp1
    tmp3 = libdevice.exp(tmp2)
    tmp4 = tl.full([1], 1.0, tl.float32)
    tmp5 = tmp3 + tmp4
    tmp6 = (tmp1 / tmp5)
    tmp7 = tmp6.to(tl.float32)
    tmp9 = tmp7 * tmp8
    tl.store(out_ptr0 + (x0), tmp9, xmask)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_4 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '20', '1'], 'cpp': ['1L', '20L', '1L'], 'python_slow': ['1', '20', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_4', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'constexpr', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'M': 1, 'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/5q/c5qefctpuv5k2bnb6c6fnjtgdwcf2zwg7wftiy2xyeinvyzy3l6m.py
# Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_5, hidden_states_7, float_8, pow_4, mean_3, add_13, rsqrt_5, output_10, float_9, add_14, output_11, hidden_states_8], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_13 => add_19
#   add_14 => add_20
#   float_8 => convert_element_type_31
#   float_9 => convert_element_type_32
#   hidden_states_5 => add_14
#   hidden_states_7 => add_18
#   hidden_states_8 => convert_element_type_33
#   inputs_embeds => embedding
#   mean_3 => mean_3
#   output_10 => mul_25
#   output_11 => mul_26
#   pow_4 => pow_4
#   rsqrt_5 => rsqrt_5
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "bf16[248320, 2560][2560, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf27 : Tensor  = PlaceHolder[target=buf27]
#   %buf36 : Tensor  = PlaceHolder[target=buf36]
#   %buf37 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf37]
#   %arg27_1 : Tensor "bf16[2560][1]tnca:0" = PlaceHolder[target=arg27_1]
#   %embedding : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %add_14 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %empty_2), kwargs = {})
#   %add_18 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_14, %empty_5), kwargs = {})
#   %convert_element_type_31 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_18, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_31, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %add_19 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, 1e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_19,), kwargs = {})
#   %mul_25 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_31, %rsqrt_5), kwargs = {})
#   %convert_element_type_32 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg27_1, torch.float32), kwargs = {})
#   %add_20 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_32, 1.0), kwargs = {})
#   %mul_26 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_25, %add_20), kwargs = {})
#   %convert_element_type_33 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_26, torch.bfloat16), kwargs = {})
#   return %buf37,%convert_element_type_33
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_16 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_16', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 15360}, 'add_persistent_rblock': True, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_16(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 248320), "index out of bounds: 0 <= tmp1 < 248320")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2560*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp13 = tl.load(in_ptr0 + (0))
    tmp14 = tl.broadcast_to(tmp13, [R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp17 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp19 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp28 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp14) & (tmp14 < 248320), "index out of bounds: 0 <= tmp14 < 248320")
        tmp16 = tl.load(in_ptr1 + (r0_0 + 2560*tmp14), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp18 = tmp16 + tmp17
        tmp20 = tmp18 + tmp19
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tl.full([1], 2560.0, tl.float32)
        tmp23 = (tmp11 / tmp22)
        tmp24 = tl.full([1], 1e-06, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = libdevice.rsqrt(tmp25)
        tmp27 = tmp21 * tmp26
        tmp29 = tmp28.to(tl.float32)
        tmp30 = tl.full([1], 1.0, tl.float32)
        tmp31 = tmp29 + tmp30
        tmp32 = tmp27 * tmp31
        tmp33 = tmp32.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp33, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/h4/ch4ugmpmgiw7iddqghlsagorswxoqt3lsiwajlaypmitkgft5fx5.py
# Topologically Sorted Source Nodes: [float_10, exp_2, neg_1, a_1, float_11, add_15, softplus_1, g_1, transpose_14, getitem_32, exp_3], Original ATen: [aten._to_copy, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
# Source node to ATen node mapping:
#   a_1 => mm_3, permute_14, view_25, view_26
#   add_15 => add_25
#   exp_2 => exp_7
#   exp_3 => exp_9
#   float_10 => convert_element_type_43
#   float_11 => convert_element_type_44
#   g_1 => mul_31
#   getitem_32 => select_50
#   neg_1 => neg_5
#   softplus_1 => exp_8, gt_1, log1p_1, where_1
#   transpose_14 => permute_21
# Graph fragment:
#   %convert_element_type_33 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0" = PlaceHolder[target=convert_element_type_33]
#   %arg33_1 : Tensor "bf16[32, 2560][2560, 1]tnca:0" = PlaceHolder[target=arg33_1]
#   %arg36_1 : Tensor "bf16[32][1]tnca:0" = PlaceHolder[target=arg36_1]
#   %mm_3 : Tensor "bf16[1, 32][32, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %arg37_1 : Tensor "bf16[32][1]tnca:0" = PlaceHolder[target=arg37_1]
#   %convert_element_type_43 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg36_1, torch.float32), kwargs = {})
#   %exp_7 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%convert_element_type_43,), kwargs = {})
#   %neg_5 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%exp_7,), kwargs = {})
#   %view_25 : Tensor "bf16[1, 2560][2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_33, [1, 2560]), kwargs = {})
#   %permute_14 : Tensor "bf16[2560, 32][1, 2560]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg33_1, [1, 0]), kwargs = {})
#   %mm_3 : Tensor "bf16[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_25, %permute_14), kwargs = {})
#   %view_26 : Tensor "bf16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 32]), kwargs = {})
#   %convert_element_type_44 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_26, torch.float32), kwargs = {})
#   %add_25 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_44, %arg37_1), kwargs = {})
#   %gt_1 : Tensor "b8[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.gt.Scalar](args = (%add_25, 20), kwargs = {})
#   %exp_8 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%add_25,), kwargs = {})
#   %log1p_1 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.log1p.default](args = (%exp_8,), kwargs = {})
#   %where_1 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%gt_1, %add_25, %log1p_1), kwargs = {})
#   %mul_31 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%neg_5, %where_1), kwargs = {})
#   %permute_21 : Tensor "f32[1, 32, 1][32, 1, 32]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_31, [0, 2, 1]), kwargs = {})
#   %select_50 : Tensor "f32[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%permute_21, 2, 0), kwargs = {})
#   %exp_9 : Tensor "f32[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%select_50,), kwargs = {})
#   return %mm_3,%exp_9
triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_17 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_17', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_17(arg_A, arg_B, in_ptr2, in_ptr3, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 32
    K = 2560
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2560
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2560

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2560*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 32*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2560*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 32*idx_m
    tmp0 = acc.to(tl.bfloat16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.load(in_ptr2 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp7 = tl.load(in_ptr3 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = libdevice.exp(tmp3)
    tmp5 = -tmp4
    tmp6 = tmp1.to(tl.float32)
    tmp8 = tmp7.to(tl.float32)
    tmp9 = tmp6 + tmp8
    tmp10 = tl.full([1], 20.0, tl.float32)
    tmp11 = tmp9 > tmp10
    tmp12 = libdevice.exp(tmp9)
    tmp13 = libdevice.log1p(tmp12)
    tmp14 = tl.where(tmp11, tmp9, tmp13)
    tmp15 = tmp5 * tmp14
    tmp16 = libdevice.exp(tmp15)
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp16, mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/5o/c5o5kbtsdmvjpv2lgu2vyysuh7yzgbu6paesx4oqieivnejvy2w4.py
# Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_5, hidden_states_7, hidden_states_13, float_12, pow_6, mean_5, add_21, rsqrt_9, output_15, float_13, add_22, output_16, hidden_states_14, output_17, output_18], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_21 => add_32
#   add_22 => add_33
#   float_12 => convert_element_type_54
#   float_13 => convert_element_type_55
#   hidden_states_13 => add_31
#   hidden_states_14 => convert_element_type_56
#   hidden_states_5 => add_14
#   hidden_states_7 => add_18
#   inputs_embeds => embedding
#   mean_5 => mean_5
#   output_15 => mul_44
#   output_16 => mul_45
#   output_17 => triton_kernel_wrapper_mutation_190
#   output_18 => triton_kernel_wrapper_mutation_189
#   pow_6 => pow_6
#   rsqrt_9 => rsqrt_9
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "bf16[248320, 2560][2560, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf27 : Tensor  = PlaceHolder[target=buf27]
#   %buf36 : Tensor  = PlaceHolder[target=buf36]
#   %buf60 : Tensor  = PlaceHolder[target=buf60]
#   %add_31 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0" = PlaceHolder[target=add_31]
#   %buf62 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf62]
#   %arg42_1 : Tensor "bf16[2560][1]tnca:0" = PlaceHolder[target=arg42_1]
#   %embedding : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %add_14 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %empty_2), kwargs = {})
#   %add_18 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_14, %empty_5), kwargs = {})
#   %add_31 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_18, %empty_8), kwargs = {})
#   %convert_element_type_54 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_31, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_54, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %add_32 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, 1e-06), kwargs = {})
#   %rsqrt_9 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_32,), kwargs = {})
#   %mul_44 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_54, %rsqrt_9), kwargs = {})
#   %convert_element_type_55 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg42_1, torch.float32), kwargs = {})
#   %add_33 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_55, 1.0), kwargs = {})
#   %mul_45 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_44, %add_33), kwargs = {})
#   %convert_element_type_56 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_45, torch.bfloat16), kwargs = {})
#   %triton_kernel_wrapper_mutation_190 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1009, grid: [(1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1)], tma_descriptor_metadata: {}, kwargs: {A: %convert_element_type_56, B: %arg43_1, C: %empty_9, Bs: %arg44_1, M: 1, N: 9216, K: 2560, stride_am: 2560, stride_ak: 1, stride_bk: 1, stride_bn: 2560, stride_cm: 9216, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 20, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_189 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1010, grid: [(1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1)], tma_descriptor_metadata: {}, kwargs: {A: %convert_element_type_56, B: %arg45_1, C: %empty_10, Bs: %arg46_1, M: 1, N: 9216, K: 2560, stride_am: 2560, stride_ak: 1, stride_bk: 1, stride_bn: 2560, stride_cm: 9216, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 20, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %add_31,%buf62,%buf64,%buf67
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_18 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'in_ptr5': '*bf16', 'out_ptr0': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_18', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 35840}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_18(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr4, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    _tmp13 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 248320), "index out of bounds: 0 <= tmp1 < 248320")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2560*tmp1), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp9 = tmp7 + tmp8
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tmp10 * tmp10
        tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
        tmp14 = _tmp13 + tmp12
        _tmp13 = tl.where(r0_mask, tmp14, _tmp13)
        tl.store(out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp9, r0_mask)
    tmp13 = triton_helpers.promote_to_tensor(tl.sum(_tmp13, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(out_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.debug_barrier()
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp23 = tl.load(in_ptr5 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.debug_barrier()
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1], 2560.0, tl.float32)
        tmp18 = (tmp13 / tmp17)
        tmp19 = tl.full([1], 1e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp24 = tmp23.to(tl.float32)
        tmp25 = tl.full([1], 1.0, tl.float32)
        tmp26 = tmp24 + tmp25
        tmp27 = tmp22 * tmp26
        tmp28 = tmp27.to(tl.float32)
        tl.store(out_ptr2 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp28, r0_mask)
        tl.store(out_ptr3 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp28, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/dc/cdcgvmqt5q5mora4wv2jh24perxjxoggczlkt4qeiumygpw6aezl.py
# Topologically Sorted Source Nodes: [hidden_states_15, float_14, pow_7, mean_6, add_24, rsqrt_10, output_20, float_15, add_25, output_21, hidden_states_16, output_22, output_23], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_24 => add_36
#   add_25 => add_37
#   float_14 => convert_element_type_59
#   float_15 => convert_element_type_60
#   hidden_states_15 => add_35
#   hidden_states_16 => convert_element_type_61
#   mean_6 => mean_6
#   output_20 => mul_47
#   output_21 => mul_48
#   output_22 => triton_kernel_wrapper_mutation_187
#   output_23 => triton_kernel_wrapper_mutation_186
#   pow_7 => pow_7
#   rsqrt_10 => rsqrt_10
# Graph fragment:
#   %add_31 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0" = PlaceHolder[target=add_31]
#   %buf71 : Tensor  = PlaceHolder[target=buf71]
#   %buf72 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf72]
#   %arg49_1 : Tensor "bf16[2560][1]tnca:0" = PlaceHolder[target=arg49_1]
#   %add_35 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_31, %empty_11), kwargs = {})
#   %convert_element_type_59 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_35, torch.float32), kwargs = {})
#   %pow_7 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_59, 2), kwargs = {})
#   %mean_6 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   %add_36 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_6, 1e-06), kwargs = {})
#   %rsqrt_10 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_36,), kwargs = {})
#   %mul_47 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_59, %rsqrt_10), kwargs = {})
#   %convert_element_type_60 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg49_1, torch.float32), kwargs = {})
#   %add_37 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_60, 1.0), kwargs = {})
#   %mul_48 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_47, %add_37), kwargs = {})
#   %convert_element_type_61 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_48, torch.bfloat16), kwargs = {})
#   %triton_kernel_wrapper_mutation_187 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1012, grid: [(1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1), (1, 64, 1)], tma_descriptor_metadata: {}, kwargs: {A: %convert_element_type_61, B: %arg50_1, C: %empty_12, Bs: %arg51_1, M: 1, N: 8192, K: 2560, stride_am: 2560, stride_ak: 1, stride_bk: 1, stride_bn: 2560, stride_cm: 8192, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 20, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_186 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1013, grid: [(1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1), (1, 32, 1)], tma_descriptor_metadata: {}, kwargs: {A: %convert_element_type_61, B: %arg52_1, C: %empty_13, Bs: %arg53_1, M: 1, N: 4096, K: 2560, stride_am: 2560, stride_ak: 1, stride_bk: 1, stride_bn: 2560, stride_cm: 4096, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 20, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %buf72,%buf74,%buf77,%convert_element_type_61
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 40960}, 'add_persistent_rblock': True, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19(in_ptr0, in_ptr1, in_ptr2, out_ptr1, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr1, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 2560.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 1e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 1.0, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = tmp17 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp23, r0_mask)
        tl.store(out_ptr2 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp23, r0_mask)
        tl.store(out_ptr3 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp23, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/ky/cky32wtocdlpbcat6oexnqnlqlj26zpke5wglmmtwouuh3tacxcv.py
# Topologically Sorted Source Nodes: [hidden_states_15, hidden_states_21, float_18, pow_9, mean_8, add_32, rsqrt_14, output_25, float_19, add_33, output_26, hidden_states_22], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_32 => add_49
#   add_33 => add_50
#   float_18 => convert_element_type_82
#   float_19 => convert_element_type_83
#   hidden_states_15 => add_35
#   hidden_states_21 => add_48
#   hidden_states_22 => convert_element_type_84
#   mean_8 => mean_8
#   output_25 => mul_66
#   output_26 => mul_67
#   pow_9 => pow_9
#   rsqrt_14 => rsqrt_14
# Graph fragment:
#   %add_31 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0" = PlaceHolder[target=add_31]
#   %buf71 : Tensor  = PlaceHolder[target=buf71]
#   %buf97 : Tensor  = PlaceHolder[target=buf97]
#   %buf98 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf98]
#   %arg64_1 : Tensor "bf16[2560][1]tnca:0" = PlaceHolder[target=arg64_1]
#   %add_35 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_31, %empty_11), kwargs = {})
#   %add_48 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_35, %empty_14), kwargs = {})
#   %convert_element_type_82 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_48, torch.float32), kwargs = {})
#   %pow_9 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_82, 2), kwargs = {})
#   %mean_8 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_9, [-1], True), kwargs = {})
#   %add_49 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_8, 1e-06), kwargs = {})
#   %rsqrt_14 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_49,), kwargs = {})
#   %mul_66 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_82, %rsqrt_14), kwargs = {})
#   %convert_element_type_83 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg64_1, torch.float32), kwargs = {})
#   %add_50 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_83, 1.0), kwargs = {})
#   %mul_67 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_66, %add_50), kwargs = {})
#   %convert_element_type_84 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_67, torch.bfloat16), kwargs = {})
#   return %buf98,%convert_element_type_84
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 20480}, 'add_persistent_rblock': True, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr1, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr2, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp10 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp11 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 2560.0, tl.float32)
        tmp17 = (tmp8 / tmp16)
        tmp18 = tl.full([1], 1e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tl.full([1], 1.0, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = tmp21 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp27, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/ih/ciheir2xoyakrxpmrpunoyqyzghw4bujbyqomhs43fkdw2tpvpfm.py
# Topologically Sorted Source Nodes: [hidden_states_15, hidden_states_21, hidden_states_23, float_20, pow_10, mean_9, add_35, rsqrt_15, output_30, float_21, add_36, output_31, hidden_states_24], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_35 => add_53
#   add_36 => add_54
#   float_20 => convert_element_type_87
#   float_21 => convert_element_type_88
#   hidden_states_15 => add_35
#   hidden_states_21 => add_48
#   hidden_states_23 => add_52
#   hidden_states_24 => convert_element_type_89
#   mean_9 => mean_9
#   output_30 => mul_69
#   output_31 => mul_70
#   pow_10 => pow_10
#   rsqrt_15 => rsqrt_15
# Graph fragment:
#   %add_31 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0" = PlaceHolder[target=add_31]
#   %buf71 : Tensor  = PlaceHolder[target=buf71]
#   %buf97 : Tensor  = PlaceHolder[target=buf97]
#   %buf106 : Tensor  = PlaceHolder[target=buf106]
#   %buf107 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf107]
#   %arg71_1 : Tensor "bf16[2560][1]tnca:0" = PlaceHolder[target=arg71_1]
#   %add_35 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_31, %empty_11), kwargs = {})
#   %add_48 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_35, %empty_14), kwargs = {})
#   %add_52 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_48, %empty_17), kwargs = {})
#   %convert_element_type_87 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_52, torch.float32), kwargs = {})
#   %pow_10 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_87, 2), kwargs = {})
#   %mean_9 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_10, [-1], True), kwargs = {})
#   %add_53 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_9, 1e-06), kwargs = {})
#   %rsqrt_15 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_53,), kwargs = {})
#   %mul_69 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_87, %rsqrt_15), kwargs = {})
#   %convert_element_type_88 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg71_1, torch.float32), kwargs = {})
#   %add_54 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_88, 1.0), kwargs = {})
#   %mul_70 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_69, %add_54), kwargs = {})
#   %convert_element_type_89 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_70, torch.bfloat16), kwargs = {})
#   return %buf107,%convert_element_type_89
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 20480}, 'add_persistent_rblock': True, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr1, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor6 = tl.make_tensor_descriptor(in_ptr2, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor7 = tl.make_tensor_descriptor(in_ptr3, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp12 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor6.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp17 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor7.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp26 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 2560.0, tl.float32)
        tmp21 = (tmp10 / tmp20)
        tmp22 = tl.full([1], 1e-06, tl.float32)
        tmp23 = tmp21 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp19 * tmp24
        tmp27 = tmp26.to(tl.float32)
        tmp28 = tl.full([1], 1.0, tl.float32)
        tmp29 = tmp27 + tmp28
        tmp30 = tmp25 * tmp29
        tmp31 = tmp30.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp31, r0_mask)
''', device_str='tnca')


# Original path: /home/zzhouch/r41s2_fp8_inputs/hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/0e5764aa5c27d0f005117a92645156481540950a/build/torch-cuda/matmul.py:96
w8a8_block_dynamic_fp8_matmul_kernel_5 = async_compile.triton('w8a8_block_dynamic_fp8_matmul_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '8', '1'], 'cpp': ['1L', '8L', '1L'], 'python_slow': ['1', '8', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_dynamic_fp8_matmul_kernel_5', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*bf16', 'B': '*fp8e4nv', 'C': '*bf16', 'Bs': '*fp32', 'M': 'constexpr', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'M': 1, 'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_dynamic_fp8_matmul_kernel(
    A,  # (M, K) raw BF16/FP16 activations
    B,  # (N, K) FP8 weights
    C,  # (M, N) output
    Bs,  # (N // BLOCK_SIZE_N, K // BLOCK_SIZE_K) weight scales (fp32 or uint8/UE8M0)
    # Shape
    M,
    N,
    K,
    # Strides
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel with fused activation quantization.

    Computes ``C = A @ B.T`` with bf16/fp16 ``A`` quantized to FP8 per-K-tile
    inline (one scale per M-row per BLOCK_SIZE_K) and pre-quantized FP8 weights
    with per-block scales. 2D grid with swizzle for L2 cache locality on B.
    """
    pid_m, pid_n, offs_am, offs_bn, offs_k = _swizzle_offsets(
        M, N, BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M
    )
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a_raw = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0).to(
            tl.float32
        )
        a, a_s = fp8_act_quant_inline(a_raw)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        b_s = decode_ue8m0_scale(tl.load(bs_ptrs))
        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
        bs_ptrs += stride_bs_k

    _store_masked(
        C,
        accumulator,
        pid_m,
        pid_n,
        M,
        N,
        stride_cm,
        stride_cn,
        BLOCK_SIZE_M,
        BLOCK_SIZE_N,
    )

@triton.jit
def _swizzle_offsets(
    M,
    N,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """2D-grid tile scheduling shared by the kernels below: swizzle the
    ``(pid_m, pid_n)`` program ids for L2 locality on B, then build the operand
    offset vectors. Returns ``(pid_m, pid_n, offs_am, offs_bn, offs_k)`` — the
    swizzled ids (reused by the output store) and the ``%``-wrapped row/col offsets
    plus the K range."""
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    return pid_m, pid_n, offs_am, offs_bn, offs_k

@triton.jit
def fp8_act_quant_inline(a_raw):
    """Inline FP8 (E4M3) activation quant for the W8A8 block-scale path.

    Per-row amax → fp32 scale ``amax/448`` (floored at 1e-12 against zero rows)
    → cast values to FP8. Returns ``(a_fp8, a_s)`` with shapes ``(M, K)`` and
    ``(M,)``.
    """
    a_s = tl.max(tl.abs(a_raw), axis=1) / 448.0
    a_fp8 = (a_raw / tl.maximum(a_s[:, None], 1e-12)).to(tl.float8e4nv)
    return a_fp8, a_s

@triton.jit
def decode_ue8m0_scale(scale):
    """Decode a UE8M0 weight scale to fp32: when it was loaded as ``uint8`` exponent
    bits, ``value = 2^(exp - 127)``, built directly as the fp32 bit pattern. fp32
    scales (block-dynamic with float scales) pass through. The dtype branch is a
    compile-time constant, so only the taken path is emitted (single return — Triton
    requires all ``return`` statements to share a type)."""
    if scale.dtype == tl.uint8:
        scale = (scale.to(tl.int32) << 23).to(tl.float32, bitcast=True)
    return scale

@triton.jit
def _store_masked(
    C,
    accumulator,
    pid_m,
    pid_n,
    M,
    N,
    stride_cm,
    stride_cn,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    """Shared output epilogue of the kernels below: cast the fp32 accumulator to
    ``C``'s dtype and store the ``(BLOCK_SIZE_M, BLOCK_SIZE_N)`` tile at the swizzled
    ``(pid_m, pid_n)``, masked to the ``(M, N)`` bounds."""
    c = accumulator.to(C.dtype.element_ty)
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/qm/cqmpfcpvkws2jbdaua5parjm57emwdkoptottgzjkbamwht4ez4v.py
# Topologically Sorted Source Nodes: [float_22, pow_11, mean_10], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   float_22 => convert_element_type_90, split_3, view_68
#   mean_10 => mean_10
#   pow_11 => pow_11
# Graph fragment:
#   %buf110 : Tensor  = PlaceHolder[target=buf110]
#   %view_68 : Tensor "bf16[1, 1, 16, 512][8192, 8192, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_18, [1, 1, -1, 512]), kwargs = {})
#   %split_3 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_68, 256, -1), kwargs = {})
#   %convert_element_type_90 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_34, torch.float32), kwargs = {})
#   %pow_11 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_90, 2), kwargs = {})
#   %mean_10 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_11, [-1], True), kwargs = {})
#   return %buf115
triton_red_fused__to_copy_mean_pow_split_view_22 = async_compile.triton('triton_red_fused__to_copy_mean_pow_split_view_22', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_mean_pow_split_view_22', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 128, 'r0_': 0}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_mean_pow_split_view_22(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 256], strides=[512, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/36/c364liugmx5wk4ba54pjifxxgddexqifryrz2lvo37l3kebmvgqd.py
# Topologically Sorted Source Nodes: [float_22, pow_11, mean_10, add_37, rsqrt_16, output_33, float_23, add_38, output_34, type_as_7, query_states_1, q_rot, x2, neg_3, x1, cat_5], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add_37 => add_55
#   add_38 => add_56
#   cat_5 => cat_3
#   float_22 => convert_element_type_90, split_3, view_68
#   float_23 => convert_element_type_91
#   mean_10 => mean_10
#   neg_3 => neg_12
#   output_33 => mul_71
#   output_34 => mul_72
#   pow_11 => pow_11
#   q_rot => slice_36
#   query_states_1 => permute_36
#   rsqrt_16 => rsqrt_16
#   type_as_7 => convert_element_type_92
#   x1 => slice_40
#   x2 => slice_41
# Graph fragment:
#   %buf110 : Tensor  = PlaceHolder[target=buf110]
#   %buf115 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 16]tnca:0" = PlaceHolder[target=buf115]
#   %arg74_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg74_1]
#   %view_68 : Tensor "bf16[1, 1, 16, 512][8192, 8192, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_18, [1, 1, -1, 512]), kwargs = {})
#   %split_3 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_68, 256, -1), kwargs = {})
#   %convert_element_type_90 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_34, torch.float32), kwargs = {})
#   %pow_11 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_90, 2), kwargs = {})
#   %mean_10 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_11, [-1], True), kwargs = {})
#   %add_55 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_10, 1e-06), kwargs = {})
#   %rsqrt_16 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_55,), kwargs = {})
#   %mul_71 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_90, %rsqrt_16), kwargs = {})
#   %convert_element_type_91 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg74_1, torch.float32), kwargs = {})
#   %add_56 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_91, 1.0), kwargs = {})
#   %mul_72 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_71, %add_56), kwargs = {})
#   %convert_element_type_92 : Tensor "bf16[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_72, torch.bfloat16), kwargs = {})
#   %permute_36 : Tensor "bf16[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_92, [0, 2, 1, 3]), kwargs = {})
#   %slice_36 : Tensor "bf16[1, 16, 1, 64][4096, 256, 4096, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_36, 3, 0, 64), kwargs = {})
#   %slice_41 : Tensor "bf16[1, 16, 1, 32][4096, 256, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_36, 3, 32, 9223372036854775807), kwargs = {})
#   %neg_12 : Tensor "bf16[1, 16, 1, 32][512, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_41,), kwargs = {})
#   %slice_40 : Tensor "bf16[1, 16, 1, 32][4096, 256, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_36, 3, 0, 32), kwargs = {})
#   %cat_3 : Tensor "bf16[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_12, %slice_40], -1), kwargs = {})
#   return %neg_12,%buf117
triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_23 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_23', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_23', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4288}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_23(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 512*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (32 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp16 = tl.load(in_ptr0 + (x0 + 512*x1), xmask).to(tl.float32)
    tmp19 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp15 = -tmp14
    tmp17 = tmp16.to(tl.float32)
    tmp18 = tmp17 * tmp7
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp20 + tmp11
    tmp22 = tmp18 * tmp21
    tmp23 = tmp22.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 64*x1), tmp15, xmask)
    tl.store(out_ptr1 + (x0 + 64*x1), tmp23, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/a6/ca642fxim6dqphjv6b6ycrft3vxnqiudj6v4cyiefyimxmpv4zsf.py
# Topologically Sorted Source Nodes: [float_22, pow_11, mean_10, add_37, rsqrt_16, output_33, float_23, add_38, output_34, type_as_7, query_states_1, q_rot, setitem_3, cos_2, cos_3, cos_4, mul_63, setitem_1, sin_2, sin_3, sin_4, mul_64, q_embed], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.select, aten.cat, aten.unsqueeze]
# Source node to ATen node mapping:
#   add_37 => add_55
#   add_38 => add_56
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_8, view_1
#   cos_3 => convert_element_type_1
#   cos_4 => unsqueeze_39
#   float_22 => convert_element_type_90, split_3, view_68
#   float_23 => convert_element_type_91
#   mean_10 => mean_10
#   mul_63 => mul_75
#   mul_64 => mul_76
#   output_33 => mul_71
#   output_34 => mul_72
#   pow_11 => pow_11
#   q_embed => add_59
#   q_rot => slice_36
#   query_states_1 => permute_36
#   rsqrt_16 => rsqrt_16
#   setitem_1 => select_8, slice_8
#   setitem_3 => select_20, slice_16
#   sin_2 => clone, expand_2, select_11, unsqueeze_7, view
#   sin_3 => convert_element_type_2
#   sin_4 => unsqueeze_40
#   type_as_7 => convert_element_type_92
# Graph fragment:
#   %buf110 : Tensor  = PlaceHolder[target=buf110]
#   %buf115 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 16]tnca:0" = PlaceHolder[target=buf115]
#   %arg74_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg74_1]
#   %select_scatter_default_1 : Tensor "f32[3, 1, 1, 32][32, 96, 96, 1]tnca:0" = PlaceHolder[target=select_scatter_default_1]
#   %cat_3 : Tensor "bf16[1, 16, 1, 64][1024, 64, 64, 1]tnca:0" = PlaceHolder[target=cat_3]
#   %select_scatter_default : Tensor "f32[3, 1, 1, 32][32, 96, 96, 1]tnca:0" = PlaceHolder[target=select_scatter_default]
#   %view_68 : Tensor "bf16[1, 1, 16, 512][8192, 8192, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_18, [1, 1, -1, 512]), kwargs = {})
#   %split_3 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_68, 256, -1), kwargs = {})
#   %convert_element_type_90 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_34, torch.float32), kwargs = {})
#   %pow_11 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_90, 2), kwargs = {})
#   %mean_10 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_11, [-1], True), kwargs = {})
#   %add_55 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_10, 1e-06), kwargs = {})
#   %rsqrt_16 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_55,), kwargs = {})
#   %mul_71 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_90, %rsqrt_16), kwargs = {})
#   %convert_element_type_91 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg74_1, torch.float32), kwargs = {})
#   %add_56 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_91, 1.0), kwargs = {})
#   %mul_72 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_71, %add_56), kwargs = {})
#   %convert_element_type_92 : Tensor "bf16[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_72, torch.bfloat16), kwargs = {})
#   %permute_36 : Tensor "bf16[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_92, [0, 2, 1, 3]), kwargs = {})
#   %slice_36 : Tensor "bf16[1, 16, 1, 64][4096, 256, 4096, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_36, 3, 0, 64), kwargs = {})
#   %select_20 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_16 : Tensor "f32[1, 1, 10][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 30, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_16, 2, 2, 30, 3), kwargs = {})
#   %select_scatter_default_5 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_5, 0, 0), kwargs = {})
#   %unsqueeze_8 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_8, [1, 1, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 64]), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=8] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_39 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 1), kwargs = {})
#   %mul_75 : Tensor "bf16[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_36, %unsqueeze_39), kwargs = {})
#   %select_8 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_8 : Tensor "f32[1, 1, 10][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 30, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_8, 2, 2, 30, 3), kwargs = {})
#   %select_scatter_default_6 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_6, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 1, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=8] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_40 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_76 : Tensor "bf16[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_3, %unsqueeze_40), kwargs = {})
#   %add_59 : Tensor "bf16[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_75, %mul_76), kwargs = {})
#   return %add_59
triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_24 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_24', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_24', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 7360}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_24(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 512*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp30 = tl.load(in_ptr3 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp35 = tl.load(in_ptr4 + (x2), xmask).to(tl.float32)
    tmp37 = tl.load(in_ptr5 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp15 = tl.full([1], 0, tl.int32)
    tmp16 = tmp15 == tmp15
    tmp17 = ((x2 % 32)).to(tl.int64)
    tmp18 = (tmp17).to(tl.int64)
    tmp19 = tl.full([1], 2, tl.int64)
    tmp20 = tmp18 >= tmp19
    tmp21 = tl.full([1], 30, tl.int64)
    tmp22 = tmp18 < tmp21
    tmp23 = ((((-2) + ((x0 % 32))) % 3)).to(tl.int64)
    tmp24 = (tmp23).to(tl.int64)
    tmp25 = tl.full([1], 0, tl.int64)
    tmp26 = tmp24 == tmp25
    tmp27 = tmp20 & tmp22
    tmp28 = tmp27 & tmp26
    tmp29 = tl.load(in_ptr3 + (66 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 32)),  3))), tmp28 & xmask, eviction_policy='evict_last', other=0.0)
    tmp31 = tl.where(tmp28, tmp29, tmp30)
    tmp32 = tl.where(tmp16, tmp31, tmp30)
    tmp33 = tmp32.to(tl.float32)
    tmp34 = tmp14 * tmp33
    tmp36 = tl.load(in_ptr5 + (66 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 32)),  3))), tmp28 & xmask, eviction_policy='evict_last', other=0.0)
    tmp38 = tl.where(tmp28, tmp36, tmp37)
    tmp39 = tl.where(tmp16, tmp38, tmp37)
    tmp40 = tmp39.to(tl.float32)
    tmp41 = tmp35 * tmp40
    tmp42 = tmp34 + tmp41
    tl.store(out_ptr0 + (x0 + 256*x1), tmp42, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/ho/cho3qyfsvkqcly7bxg7ckc2ecicqkkt7dvxg5afujwkvvs6kfywz.py
# Topologically Sorted Source Nodes: [float_22, pow_11, mean_10, add_37, rsqrt_16, output_33, float_23, add_38, output_34, type_as_7, query_states_1, q_rot, setitem_3, cos_2, cos_3, cos_4, mul_63, setitem_1, sin_2, sin_3, sin_4, mul_64, q_embed, q_pass, q_embed_1], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.select, aten.cat, aten.unsqueeze]
# Source node to ATen node mapping:
#   add_37 => add_55
#   add_38 => add_56
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_8, view_1
#   cos_3 => convert_element_type_1
#   cos_4 => unsqueeze_39
#   float_22 => convert_element_type_90, split_3, view_68
#   float_23 => convert_element_type_91
#   mean_10 => mean_10
#   mul_63 => mul_75
#   mul_64 => mul_76
#   output_33 => mul_71
#   output_34 => mul_72
#   pow_11 => pow_11
#   q_embed => add_59
#   q_embed_1 => cat_5
#   q_pass => slice_37
#   q_rot => slice_36
#   query_states_1 => permute_36
#   rsqrt_16 => rsqrt_16
#   setitem_1 => select_8, slice_8
#   setitem_3 => select_20, slice_16
#   sin_2 => clone, expand_2, select_11, unsqueeze_7, view
#   sin_3 => convert_element_type_2
#   sin_4 => unsqueeze_40
#   type_as_7 => convert_element_type_92
# Graph fragment:
#   %buf110 : Tensor  = PlaceHolder[target=buf110]
#   %buf115 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 16]tnca:0" = PlaceHolder[target=buf115]
#   %arg74_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg74_1]
#   %view_68 : Tensor "bf16[1, 1, 16, 512][8192, 8192, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_18, [1, 1, -1, 512]), kwargs = {})
#   %split_3 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_68, 256, -1), kwargs = {})
#   %convert_element_type_90 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_34, torch.float32), kwargs = {})
#   %pow_11 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_90, 2), kwargs = {})
#   %mean_10 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_11, [-1], True), kwargs = {})
#   %add_55 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_10, 1e-06), kwargs = {})
#   %rsqrt_16 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_55,), kwargs = {})
#   %mul_71 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_90, %rsqrt_16), kwargs = {})
#   %convert_element_type_91 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg74_1, torch.float32), kwargs = {})
#   %add_56 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_91, 1.0), kwargs = {})
#   %mul_72 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_71, %add_56), kwargs = {})
#   %convert_element_type_92 : Tensor "bf16[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_72, torch.bfloat16), kwargs = {})
#   %permute_36 : Tensor "bf16[1, 16, 1, 256][4096, 256, 4096, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_92, [0, 2, 1, 3]), kwargs = {})
#   %slice_36 : Tensor "bf16[1, 16, 1, 64][4096, 256, 4096, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_36, 3, 0, 64), kwargs = {})
#   %select_20 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_16 : Tensor "f32[1, 1, 10][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 30, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_16, 2, 2, 30, 3), kwargs = {})
#   %select_scatter_default_5 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_5, 0, 0), kwargs = {})
#   %unsqueeze_8 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_8, [1, 1, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 64]), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=8] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_39 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 1), kwargs = {})
#   %mul_75 : Tensor "bf16[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_36, %unsqueeze_39), kwargs = {})
#   %select_8 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_8 : Tensor "f32[1, 1, 10][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 30, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_8, 2, 2, 30, 3), kwargs = {})
#   %select_scatter_default_6 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_6, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 1, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=8] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_40 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_76 : Tensor "bf16[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_3, %unsqueeze_40), kwargs = {})
#   %add_59 : Tensor "bf16[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_75, %mul_76), kwargs = {})
#   %slice_37 : Tensor "bf16[1, 16, 1, 192][4096, 256, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_36, 3, 64, 9223372036854775807), kwargs = {})
#   %cat_5 : Tensor "bf16[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_59, %slice_37], -1), kwargs = {})
#   return %buf120
triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_25 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_25', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 4096}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_25', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 12736}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_25(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 3072
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 192)
    x1 = xindex // 192
    tmp0 = tl.load(in_ptr0 + (64 + x0 + 512*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (64 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 256*x1), tmp14, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/nw/cnwudmobqsauo7guk5p7iakeayrdl77aqztglsuhenqcmuxenid4.py
# Topologically Sorted Source Nodes: [float_24, pow_12, mean_11], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   float_24 => convert_element_type_93, view_71
#   mean_11 => mean_11
#   pow_12 => pow_12
# Graph fragment:
#   %buf112 : Tensor  = PlaceHolder[target=buf112]
#   %view_71 : Tensor "bf16[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_19, [1, 1, -1, 256]), kwargs = {})
#   %convert_element_type_93 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_71, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_93, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   return %buf122
triton_red_fused__to_copy_mean_pow_view_26 = async_compile.triton('triton_red_fused__to_copy_mean_pow_view_26', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_mean_pow_view_26', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 16, 'r0_': 0}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_mean_pow_view_26(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[4, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/go/cgohkfmohlsqim4dt4znbyybwnb2alnwv3vfuv6ujrw5mbuzrpky.py
# Topologically Sorted Source Nodes: [float_24, pow_12, mean_11, add_39, rsqrt_17, output_36, float_25, add_40, output_37, type_as_8, key_states, k_rot, x2_1, neg_4, x1_1, cat_6], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add_39 => add_57
#   add_40 => add_58
#   cat_6 => cat_4
#   float_24 => convert_element_type_93, view_71
#   float_25 => convert_element_type_94
#   k_rot => slice_38
#   key_states => permute_37
#   mean_11 => mean_11
#   neg_4 => neg_13
#   output_36 => mul_73
#   output_37 => mul_74
#   pow_12 => pow_12
#   rsqrt_17 => rsqrt_17
#   type_as_8 => convert_element_type_95
#   x1_1 => slice_42
#   x2_1 => slice_43
# Graph fragment:
#   %buf112 : Tensor  = PlaceHolder[target=buf112]
#   %buf122 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 4]tnca:0" = PlaceHolder[target=buf122]
#   %arg77_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg77_1]
#   %view_71 : Tensor "bf16[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_19, [1, 1, -1, 256]), kwargs = {})
#   %convert_element_type_93 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_71, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_93, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   %add_57 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_11, 1e-06), kwargs = {})
#   %rsqrt_17 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_57,), kwargs = {})
#   %mul_73 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_93, %rsqrt_17), kwargs = {})
#   %convert_element_type_94 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg77_1, torch.float32), kwargs = {})
#   %add_58 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_94, 1.0), kwargs = {})
#   %mul_74 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_73, %add_58), kwargs = {})
#   %convert_element_type_95 : Tensor "bf16[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_74, torch.bfloat16), kwargs = {})
#   %permute_37 : Tensor "bf16[1, 4, 1, 256][1024, 256, 1024, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_95, [0, 2, 1, 3]), kwargs = {})
#   %slice_38 : Tensor "bf16[1, 4, 1, 64][1024, 256, 1024, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_37, 3, 0, 64), kwargs = {})
#   %slice_43 : Tensor "bf16[1, 4, 1, 32][1024, 256, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_38, 3, 32, 9223372036854775807), kwargs = {})
#   %neg_13 : Tensor "bf16[1, 4, 1, 32][128, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_43,), kwargs = {})
#   %slice_42 : Tensor "bf16[1, 4, 1, 32][1024, 256, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_38, 3, 0, 32), kwargs = {})
#   %cat_4 : Tensor "bf16[1, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_13, %slice_42], -1), kwargs = {})
#   return %neg_13,%buf124
triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_27 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_27', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 128}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_27', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1168}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_27(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 128
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 256*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (32 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp16 = tl.load(in_ptr0 + (x0 + 256*x1), xmask).to(tl.float32)
    tmp19 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp15 = -tmp14
    tmp17 = tmp16.to(tl.float32)
    tmp18 = tmp17 * tmp7
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp20 + tmp11
    tmp22 = tmp18 * tmp21
    tmp23 = tmp22.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 64*x1), tmp15, xmask)
    tl.store(out_ptr1 + (x0 + 64*x1), tmp23, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/ce/ccenrisohysbbh2zixo24b4bvimsdoxz2tnbtdmaryttvquescws.py
# Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, cos_4, setitem_1, sin_2, sin_3, sin_4, float_24, pow_12, mean_11, add_39, rsqrt_17, output_36, float_25, add_40, output_37, type_as_8, key_states, k_rot, mul_65, mul_66, k_embed], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
# Source node to ATen node mapping:
#   add_39 => add_57
#   add_40 => add_58
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_8, view_1
#   cos_3 => convert_element_type_1
#   cos_4 => unsqueeze_39
#   float_24 => convert_element_type_93, view_71
#   float_25 => convert_element_type_94
#   k_embed => add_60
#   k_rot => slice_38
#   key_states => permute_37
#   mean_11 => mean_11
#   mul_65 => mul_77
#   mul_66 => mul_78
#   output_36 => mul_73
#   output_37 => mul_74
#   pow_12 => pow_12
#   rsqrt_17 => rsqrt_17
#   setitem_1 => select_8, slice_8
#   setitem_3 => select_20, slice_16
#   sin_2 => clone, expand_2, select_11, unsqueeze_7, view
#   sin_3 => convert_element_type_2
#   sin_4 => unsqueeze_40
#   type_as_8 => convert_element_type_95
# Graph fragment:
#   %buf112 : Tensor  = PlaceHolder[target=buf112]
#   %buf122 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 4]tnca:0" = PlaceHolder[target=buf122]
#   %arg77_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg77_1]
#   %select_scatter_default_1 : Tensor "f32[3, 1, 1, 32][32, 96, 96, 1]tnca:0" = PlaceHolder[target=select_scatter_default_1]
#   %cat_4 : Tensor "bf16[1, 4, 1, 64][256, 64, 64, 1]tnca:0" = PlaceHolder[target=cat_4]
#   %select_scatter_default : Tensor "f32[3, 1, 1, 32][32, 96, 96, 1]tnca:0" = PlaceHolder[target=select_scatter_default]
#   %select_20 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_16 : Tensor "f32[1, 1, 10][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 30, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_16, 2, 2, 30, 3), kwargs = {})
#   %select_scatter_default_5 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_5, 0, 0), kwargs = {})
#   %unsqueeze_8 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_8, [1, 1, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 64]), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=8] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_39 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 1), kwargs = {})
#   %select_8 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_8 : Tensor "f32[1, 1, 10][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 30, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_8, 2, 2, 30, 3), kwargs = {})
#   %select_scatter_default_6 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_6, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 1, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=8] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_40 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %view_71 : Tensor "bf16[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_19, [1, 1, -1, 256]), kwargs = {})
#   %convert_element_type_93 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_71, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_93, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   %add_57 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_11, 1e-06), kwargs = {})
#   %rsqrt_17 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_57,), kwargs = {})
#   %mul_73 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_93, %rsqrt_17), kwargs = {})
#   %convert_element_type_94 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg77_1, torch.float32), kwargs = {})
#   %add_58 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_94, 1.0), kwargs = {})
#   %mul_74 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_73, %add_58), kwargs = {})
#   %convert_element_type_95 : Tensor "bf16[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_74, torch.bfloat16), kwargs = {})
#   %permute_37 : Tensor "bf16[1, 4, 1, 256][1024, 256, 1024, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_95, [0, 2, 1, 3]), kwargs = {})
#   %slice_38 : Tensor "bf16[1, 4, 1, 64][1024, 256, 1024, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_37, 3, 0, 64), kwargs = {})
#   %mul_77 : Tensor "bf16[1, 4, 1, 64][256, 64, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_38, %unsqueeze_39), kwargs = {})
#   %mul_78 : Tensor "bf16[1, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_4, %unsqueeze_40), kwargs = {})
#   %add_60 : Tensor "bf16[1, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_77, %mul_78), kwargs = {})
#   return %add_60
triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 2704}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 256*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp30 = tl.load(in_ptr3 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp35 = tl.load(in_ptr4 + (x2), xmask).to(tl.float32)
    tmp37 = tl.load(in_ptr5 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp15 = tl.full([1], 0, tl.int32)
    tmp16 = tmp15 == tmp15
    tmp17 = ((x2 % 32)).to(tl.int64)
    tmp18 = (tmp17).to(tl.int64)
    tmp19 = tl.full([1], 2, tl.int64)
    tmp20 = tmp18 >= tmp19
    tmp21 = tl.full([1], 30, tl.int64)
    tmp22 = tmp18 < tmp21
    tmp23 = ((((-2) + ((x0 % 32))) % 3)).to(tl.int64)
    tmp24 = (tmp23).to(tl.int64)
    tmp25 = tl.full([1], 0, tl.int64)
    tmp26 = tmp24 == tmp25
    tmp27 = tmp20 & tmp22
    tmp28 = tmp27 & tmp26
    tmp29 = tl.load(in_ptr3 + (66 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 32)),  3))), tmp28 & xmask, eviction_policy='evict_last', other=0.0)
    tmp31 = tl.where(tmp28, tmp29, tmp30)
    tmp32 = tl.where(tmp16, tmp31, tmp30)
    tmp33 = tmp32.to(tl.float32)
    tmp34 = tmp14 * tmp33
    tmp36 = tl.load(in_ptr5 + (66 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 32)),  3))), tmp28 & xmask, eviction_policy='evict_last', other=0.0)
    tmp38 = tl.where(tmp28, tmp36, tmp37)
    tmp39 = tl.where(tmp16, tmp38, tmp37)
    tmp40 = tmp39.to(tl.float32)
    tmp41 = tmp35 * tmp40
    tmp42 = tmp34 + tmp41
    tl.store(out_ptr0 + (x0 + 256*x1), tmp42, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/3y/c3y4d3gl5t2z4srfy37gtvfpbxhquvrza3ywze4vhy6lyeakix67.py
# Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, cos_4, setitem_1, sin_2, sin_3, sin_4, float_24, pow_12, mean_11, add_39, rsqrt_17, output_36, float_25, add_40, output_37, type_as_8, key_states, k_rot, mul_65, mul_66, k_embed, k_pass, k_embed_1], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
# Source node to ATen node mapping:
#   add_39 => add_57
#   add_40 => add_58
#   cos_2 => clone_2, expand_3, select_23, unsqueeze_8, view_1
#   cos_3 => convert_element_type_1
#   cos_4 => unsqueeze_39
#   float_24 => convert_element_type_93, view_71
#   float_25 => convert_element_type_94
#   k_embed => add_60
#   k_embed_1 => cat_6
#   k_pass => slice_39
#   k_rot => slice_38
#   key_states => permute_37
#   mean_11 => mean_11
#   mul_65 => mul_77
#   mul_66 => mul_78
#   output_36 => mul_73
#   output_37 => mul_74
#   pow_12 => pow_12
#   rsqrt_17 => rsqrt_17
#   setitem_1 => select_8, slice_8
#   setitem_3 => select_20, slice_16
#   sin_2 => clone, expand_2, select_11, unsqueeze_7, view
#   sin_3 => convert_element_type_2
#   sin_4 => unsqueeze_40
#   type_as_8 => convert_element_type_95
# Graph fragment:
#   %buf112 : Tensor  = PlaceHolder[target=buf112]
#   %buf122 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 4]tnca:0" = PlaceHolder[target=buf122]
#   %arg77_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg77_1]
#   %select_20 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_16 : Tensor "f32[1, 1, 10][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 30, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_16, 2, 2, 30, 3), kwargs = {})
#   %select_scatter_default_5 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_5, 0, 0), kwargs = {})
#   %unsqueeze_8 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_8, [1, 1, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 64]), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=8] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_39 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 1), kwargs = {})
#   %select_8 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_8 : Tensor "f32[1, 1, 10][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 30, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_8, 2, 2, 30, 3), kwargs = {})
#   %select_scatter_default_6 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_6, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 1, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=8] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_40 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %view_71 : Tensor "bf16[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_19, [1, 1, -1, 256]), kwargs = {})
#   %convert_element_type_93 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_71, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_93, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   %add_57 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_11, 1e-06), kwargs = {})
#   %rsqrt_17 : Tensor "f32[1, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_57,), kwargs = {})
#   %mul_73 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_93, %rsqrt_17), kwargs = {})
#   %convert_element_type_94 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg77_1, torch.float32), kwargs = {})
#   %add_58 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_94, 1.0), kwargs = {})
#   %mul_74 : Tensor "f32[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_73, %add_58), kwargs = {})
#   %convert_element_type_95 : Tensor "bf16[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_74, torch.bfloat16), kwargs = {})
#   %permute_37 : Tensor "bf16[1, 4, 1, 256][1024, 256, 1024, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_95, [0, 2, 1, 3]), kwargs = {})
#   %slice_38 : Tensor "bf16[1, 4, 1, 64][1024, 256, 1024, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_37, 3, 0, 64), kwargs = {})
#   %mul_77 : Tensor "bf16[1, 4, 1, 64][256, 64, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_38, %unsqueeze_39), kwargs = {})
#   %mul_78 : Tensor "bf16[1, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_4, %unsqueeze_40), kwargs = {})
#   %add_60 : Tensor "bf16[1, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_77, %mul_78), kwargs = {})
#   %slice_39 : Tensor "bf16[1, 4, 1, 192][1024, 256, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_37, 3, 64, 9223372036854775807), kwargs = {})
#   %cat_6 : Tensor "bf16[1, 4, 1, 256][1024, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_60, %slice_39], -1), kwargs = {})
#   return %buf127
triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_29 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_29', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_29', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3472}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_29(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 768
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 192)
    x1 = xindex // 192
    tmp0 = tl.load(in_ptr0 + (64 + x0 + 256*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (64 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 256*x1), tmp14, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/rv/crvexzykgidzjktukxfw55bdcysca47vryjqthkun546whzsgchj.py
# Topologically Sorted Source Nodes: [arange_4, cache_position, index_copy_], Original ATen: [aten.arange, aten.add, aten.index_copy]
# Source node to ATen node mapping:
#   arange_4 => iota_4
#   cache_position => add_61
#   index_copy_ => index_put
# Graph fragment:
#   %copy_ : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy_]
#   %cat_6 : Tensor "bf16[1, 4, 1, 256][1024, 256, 256, 1]tnca:0" = PlaceHolder[target=cat_6]
#   %index_put : Tensor "bf16[1, 4, 64, 256][65536, 16384, 256, 1]tnca:0" = PlaceHolder[target=index_put]
#   %iota_4 : Tensor "i64[1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (1,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %add_61 : Tensor "i64[1][1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota_4, %arg3_1), kwargs = {})
#   %index_put : Tensor "bf16[1, 4, 64, 256][65536, 16384, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg80_1, [None, None, %add_61], %cat_6), kwargs = {})
#   return %buf129
triton_poi_fused_add_arange_index_copy_30 = async_compile.triton('triton_poi_fused_add_arange_index_copy_30', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_arange_index_copy_30', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 2048}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_arange_index_copy_30(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 256)
    x1 = xindex // 256
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp9 = tl.load(in_ptr1 + (x2), xmask).to(tl.float32)
    tmp2 = tl.full([1], 0, tl.int64)
    tmp3 = tmp2 + tmp1
    tmp4 = (tl.full([XBLOCK], 64, tl.int32)).to(tl.int32)
    tmp5 = tmp3 + tmp4
    tmp6 = tmp3 < 0
    tmp7 = tl.where(tmp6, tmp5, tmp3)
    tl.device_assert((0 <= tmp7) & (tmp7 < 64), "index out of bounds: 0 <= tmp7 < 64")
    tl.store(out_ptr0 + (x0 + 256*tmp7 + 16384*x1), tmp9, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/ny/cnywo2kkhhv5bu2n64vfpmhdezv6qmxqx3phm3b7m43zz5qvnzn6.py
# Topologically Sorted Source Nodes: [attn_output, key_15], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
# Source node to ATen node mapping:
#   attn_output => bmm, convert_element_type_96, convert_element_type_97, mul_79, mul_80, permute_40, view_77, view_78
#   key_15 => clone_23, expand_11, unsqueeze_43, view_75
# Graph fragment:
#   %cat_5 : Tensor "bf16[1, 16, 1, 256][4096, 256, 256, 1]tnca:0" = PlaceHolder[target=cat_5]
#   %buf129 : Tensor "bf16[1, 4, 64, 256][65536, 16384, 256, 1]tnca:0" = PlaceHolder[target=buf129]
#   %convert_element_type_96 : Tensor "f32[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%cat_5, torch.float32), kwargs = {})
#   %mul_79 : Tensor "f32[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_96, 0.25), kwargs = {})
#   %view_77 : Tensor "f32[16, 1, 256][256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_14, [16, 1, 256]), kwargs = {})
#   %unsqueeze_43 : Tensor "bf16[1, 4, 1, 64, 256][65536, 16384, 16384, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put, 2), kwargs = {})
#   %expand_11 : Tensor "bf16[1, 4, 4, 64, 256][65536, 16384, 0, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_43, [1, 4, 4, 64, 256]), kwargs = {})
#   %clone_23 : Tensor "bf16[1, 4, 4, 64, 256][262144, 65536, 16384, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_11,), kwargs = {memory_format: torch.contiguous_format})
#   %view_75 : Tensor "bf16[1, 16, 64, 256][262144, 16384, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_23, [1, 16, 64, 256]), kwargs = {})
#   %convert_element_type_97 : Tensor "f32[1, 16, 64, 256][262144, 16384, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_75, torch.float32), kwargs = {})
#   %permute_40 : Tensor "f32[1, 16, 256, 64][262144, 16384, 1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_97, [0, 1, 3, 2]), kwargs = {})
#   %mul_80 : Tensor "f32[1, 16, 256, 64][262144, 16384, 1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_40, 0.25), kwargs = {})
#   %view_78 : Tensor "f32[16, 256, 64][16384, 1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_15, [16, 256, 64]), kwargs = {})
#   %bmm : Tensor "f32[16, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_77, %view_78), kwargs = {})
#   return %bmm
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_31 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_31', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1024, 'r0_': 256},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_31', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 8192, 'r0_': 8192}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_31(in_ptr0, in_ptr1, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1024
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 64
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 256], strides=[256, 1], block_shape=[(63 + XBLOCK) // 64, R0_BLOCK])
    x0 = (xindex % 64)
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 64, r0_offset])[:, :, None], [(63 + XBLOCK) // 64, R0_BLOCK, ((64) * ((64) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (64)))]), [0, 2, 1]), [R0_BLOCK]).to(tl.float32)
        tmp4 = tl.load(in_ptr1 + (r0_2 + 256*x0 + 16384*(x1 // 4)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tl.full([1], 0.25, tl.float32)
        tmp3 = tmp1 * tmp2
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp2
        tmp7 = tmp3 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tl.store(out_ptr0 + (x3), tmp9, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/dc/cdcexpnfmgy6gdpnmacidogpoa2i5274fgm5l6lcmjj6sobvo3fs.py
# Topologically Sorted Source Nodes: [attn_output, kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten.scalar_tensor, aten.where]
# Source node to ATen node mapping:
#   arange_2 => iota_2
#   attention_mask => le
#   attention_mask_1 => expand
#   attn_output => add_63, amax, any_1, eq, exp_18, full_default_3, full_default_4, logical_not, sub_3, sum_13, view_79, where_3
#   kv_arange => iota_3
#   kv_indices => unsqueeze_3, unsqueeze_4, unsqueeze_5
#   q_arange => add
#   q_indices => unsqueeze, unsqueeze_1, unsqueeze_2
# Graph fragment:
#   %bmm : Tensor "f32[16, 1, 64][64, 64, 1]tnca:0" = PlaceHolder[target=bmm]
#   %copy_ : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy_]
#   %amax : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax]
#   %exp_18 : Tensor "f32[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0" = PlaceHolder[target=exp_18]
#   %view_79 : Tensor "f32[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 16, 1, 64]), kwargs = {})
#   %iota_3 : Tensor "i64[64][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (64,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze_3 : Tensor "i64[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota_3, 0), kwargs = {})
#   %unsqueeze_4 : Tensor "i64[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_3, 1), kwargs = {})
#   %unsqueeze_5 : Tensor "i64[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_4, 2), kwargs = {})
#   %iota_2 : Tensor "i64[1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (1,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %add : Tensor "i64[1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota_2, %arg3_1), kwargs = {})
#   %unsqueeze : Tensor "i64[1, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%add, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "i64[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 1), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[1, 1, 1, 1][1, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_1, 3), kwargs = {})
#   %le : Tensor "b8[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.le.Tensor](args = (%unsqueeze_5, %unsqueeze_2), kwargs = {})
#   %expand : Tensor "b8[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=8] = call_function[target=torch.ops.aten.expand.default](args = (%le, [1, -1, 1, 64]), kwargs = {})
#   %full_default_4 : Tensor "bf16[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], 0.0), kwargs = {dtype: torch.bfloat16, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %full_default_3 : Tensor "bf16[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.bfloat16, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %where_3 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%expand, %full_default_4, %full_default_3), kwargs = {})
#   %add_63 : Tensor "f32[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%view_79, %where_3), kwargs = {})
#   %eq : Tensor "b8[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%add_63, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq,), kwargs = {})
#   %any_1 : Tensor "b8[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   %amax : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%add_63, [-1], True), kwargs = {})
#   %sub_3 : Tensor "f32[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%add_63, %amax), kwargs = {})
#   %exp_18 : Tensor "f32[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub_3,), kwargs = {})
#   %sum_13 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp_18, [-1], True), kwargs = {})
#   return %any_1,%amax,%exp_18,%sum_13
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*i64', 'out_ptr0': '*i1', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 3, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 160, 'r0_': 12288}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32(in_ptr0, in_ptr1, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp1 = tl.load(in_ptr1 + (0))
    tmp2 = tl.broadcast_to(tmp1, [R0_BLOCK])
    _tmp18 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp22 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp3 = tl.full([1], 0, tl.int64)
        tmp4 = tmp3 + tmp2
        tmp5 = (r0_1).to(tl.int64)
        tmp6 = (tmp5).to(tl.int64)
        tmp7 = tmp6 <= tmp4
        tmp8 = tl.full([1], 0.0, tl.float32)
        tmp9 = tl.full([1], float("-inf"), tl.float32)
        tmp10 = tl.where(tmp7, tmp8, tmp9)
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tmp0 + tmp11
        tmp13 = tmp12 == tmp9
        tmp14 = tmp13 == 0
        tmp15 = tmp14.to(tl.int64)
        tmp16 = (tmp15 != 0)
        tmp17 = tl.broadcast_to(tmp16, [R0_BLOCK])
        tmp19 = _tmp18 | tmp17
        _tmp18 = tl.where(r0_mask, tmp19, _tmp18)
        tmp21 = tl.broadcast_to(tmp12, [R0_BLOCK])
        tmp23 = tl.maximum(_tmp22, tmp21, tl.PropagateNan.ALL)
        _tmp22 = tl.where(r0_mask, tmp23, _tmp22)
    tmp20 = _tmp18.to(tl.int8)
    tmp18 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp20, 0))
    tmp22 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp22, 0))
    tl.store(out_ptr0 + (x0), tmp18, None)
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp25 = tl.load(in_ptr1 + (0))
    tmp26 = tl.broadcast_to(tmp25, [R0_BLOCK])
    _tmp40 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp24 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp27 = tl.full([1], 0, tl.int64)
        tmp28 = tmp27 + tmp26
        tmp29 = (r0_1).to(tl.int64)
        tmp30 = (tmp29).to(tl.int64)
        tmp31 = tmp30 <= tmp28
        tmp32 = tl.full([1], 0.0, tl.float32)
        tmp33 = tl.full([1], float("-inf"), tl.float32)
        tmp34 = tl.where(tmp31, tmp32, tmp33)
        tmp35 = tmp34.to(tl.float32)
        tmp36 = tmp24 + tmp35
        tmp37 = tmp36 - tmp22
        tmp38 = libdevice.exp(tmp37)
        tmp39 = tl.broadcast_to(tmp38, [R0_BLOCK])
        tmp41 = _tmp40 + tmp39
        _tmp40 = tl.where(r0_mask, tmp41, _tmp40)
        tl.store(out_ptr2 + (r0_1 + 64*x0), tmp38, r0_mask)
    tmp40 = triton_helpers.promote_to_tensor(tl.sum(_tmp40, 0))
    tl.store(out_ptr3 + (x0), tmp40, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/7n/c7ntvjm7bxw67qsvkuadnecml7fvek2ofm3xnnqpuzeovxv5oz3x.py
# Topologically Sorted Source Nodes: [arange_4, cache_position, index_copy__1], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
# Source node to ATen node mapping:
#   arange_4 => iota_4
#   cache_position => add_61
#   index_copy__1 => index_put_1, permute_39, view_74
# Graph fragment:
#   %copy_ : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy_]
#   %buf114 : Tensor  = PlaceHolder[target=buf114]
#   %index_put_1 : Tensor "bf16[1, 4, 64, 256][65536, 16384, 256, 1]tnca:0" = PlaceHolder[target=index_put_1]
#   %iota_4 : Tensor "i64[1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (1,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %add_61 : Tensor "i64[1][1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota_4, %arg3_1), kwargs = {})
#   %view_74 : Tensor "bf16[1, 1, 4, 256][1024, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_20, [1, 1, -1, 256]), kwargs = {})
#   %permute_39 : Tensor "bf16[1, 4, 1, 256][1024, 256, 1024, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_74, [0, 2, 1, 3]), kwargs = {})
#   %index_put_1 : Tensor "bf16[1, 4, 64, 256][65536, 16384, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg81_1, [None, None, %add_61], %permute_39), kwargs = {})
#   return %buf135
triton_poi_fused_add_arange_index_copy_transpose_view_33 = async_compile.triton('triton_poi_fused_add_arange_index_copy_transpose_view_33', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_arange_index_copy_transpose_view_33', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 0}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_arange_index_copy_transpose_view_33(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 256)
    x1 = xindex // 256
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp9 = tl.load(in_ptr1 + (x2), xmask).to(tl.float32)
    tmp2 = tl.full([1], 0, tl.int64)
    tmp3 = tmp2 + tmp1
    tmp4 = (tl.full([XBLOCK], 64, tl.int32)).to(tl.int32)
    tmp5 = tmp3 + tmp4
    tmp6 = tmp3 < 0
    tmp7 = tl.where(tmp6, tmp5, tmp3)
    tl.device_assert((0 <= tmp7) & (tmp7 < 64), "index out of bounds: 0 <= tmp7 < 64")
    tl.store(out_ptr0 + (x0 + 256*tmp7 + 16384*x1), tmp9, xmask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/kt/cktwl7wtacjbeaw7cjl4eoun6lva5qacyzjedrqzminnvv5ttrmx.py
# Topologically Sorted Source Nodes: [gate_1, attn_output, value_9, transpose_27, reshape_24, sigmoid_3, attn_output_3, output_39], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.sigmoid, aten.mul]
# Source node to ATen node mapping:
#   attn_output => bmm_1, convert_element_type_100, convert_element_type_98, div_12, full_default_5, logical_not_1, view_80, view_81, view_82, where_4
#   attn_output_3 => mul_81
#   gate_1 => clone_22, split_1, view_64, view_65
#   output_39 => triton_kernel_wrapper_mutation_178
#   reshape_24 => view_83
#   sigmoid_3 => sigmoid_3
#   transpose_27 => permute_43
#   value_9 => clone_24, expand_13, unsqueeze_46, view_76
# Graph fragment:
#   %any_1 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_1]
#   %exp_18 : Tensor "f32[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0" = PlaceHolder[target=exp_18]
#   %sum_13 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=sum_13]
#   %buf135 : Tensor "bf16[1, 4, 64, 256][65536, 16384, 256, 1]tnca:0" = PlaceHolder[target=buf135]
#   %bmm_1 : Tensor "f32[16, 1, 256][256, 256, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %buf110 : Tensor  = PlaceHolder[target=buf110]
#   %view_64 : Tensor "bf16[1, 1, 16, 512][8192, 8192, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%empty_18, [1, 1, -1, 512]), kwargs = {})
#   %split_1 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_64, 256, -1), kwargs = {})
#   %logical_not_1 : Tensor "b8[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_5 : Tensor "f32[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 1, 64], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %div_12 : Tensor "f32[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_18, %sum_13), kwargs = {})
#   %where_4 : Tensor "f32[1, 16, 1, 64][1024, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_5, %div_12), kwargs = {})
#   %view_80 : Tensor "f32[16, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_16, [16, 1, 64]), kwargs = {})
#   %unsqueeze_46 : Tensor "bf16[1, 4, 1, 64, 256][65536, 16384, 16384, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put_1, 2), kwargs = {})
#   %expand_13 : Tensor "bf16[1, 4, 4, 64, 256][65536, 16384, 0, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_46, [1, 4, 4, 64, 256]), kwargs = {})
#   %clone_24 : Tensor "bf16[1, 4, 4, 64, 256][262144, 65536, 16384, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_13,), kwargs = {memory_format: torch.contiguous_format})
#   %view_76 : Tensor "bf16[1, 16, 64, 256][262144, 16384, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_24, [1, 16, 64, 256]), kwargs = {})
#   %convert_element_type_98 : Tensor "f32[1, 16, 64, 256][262144, 16384, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_76, torch.float32), kwargs = {})
#   %view_81 : Tensor "f32[16, 64, 256][16384, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_17, [16, 64, 256]), kwargs = {})
#   %bmm_1 : Tensor "f32[16, 1, 256][256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_80, %view_81), kwargs = {})
#   %view_82 : Tensor "f32[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 16, 1, 256]), kwargs = {})
#   %convert_element_type_100 : Tensor "bf16[1, 16, 1, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_82, torch.bfloat16), kwargs = {})
#   %permute_43 : Tensor "bf16[1, 1, 16, 256][4096, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_100, [0, 2, 1, 3]), kwargs = {})
#   %view_83 : Tensor "bf16[1, 1, 4096][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%permute_43, [1, 1, -1]), kwargs = {})
#   %clone_22 : Tensor "bf16[1, 1, 16, 256][4096, 4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%getitem_31,), kwargs = {memory_format: torch.contiguous_format})
#   %view_65 : Tensor "bf16[1, 1, 4096][4096, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_22, [1, 1, 4096]), kwargs = {})
#   %sigmoid_3 : Tensor "bf16[1, 1, 4096][4096, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%view_65,), kwargs = {})
#   %mul_81 : Tensor "bf16[1, 1, 4096][4096, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_83, %sigmoid_3), kwargs = {})
#   %triton_kernel_wrapper_mutation_178 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1021, grid: [(1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1), (1, 20, 1)], tma_descriptor_metadata: {}, kwargs: {A: %mul_81, B: %arg82_1, C: %empty_21, Bs: %arg83_1, M: 1, N: 2560, K: 4096, stride_am: 4096, stride_ak: 1, stride_bk: 1, stride_bn: 4096, stride_cm: 2560, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 32, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %bmm_1,%buf138
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4096, 'r0_': 64},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 16384, 'r0_': 4096}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4096
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 256
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last').to(tl.int1)
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr1, shape=[16, 64], strides=[64, 1], block_shape=[(255 + XBLOCK) // 256, R0_BLOCK])
    tmp3 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    x0 = (xindex % 256)
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp2 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 256, r0_offset])[:, :, None, None], [(255 + XBLOCK) // 256, R0_BLOCK, ((1) * ((1) <= ((255 + XBLOCK) // 256)) + ((255 + XBLOCK) // 256) * (((255 + XBLOCK) // 256) < (1))), ((256) * ((256) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (256)))]), [0, 2, 3, 1]), [R0_BLOCK])
        tmp7 = tl.load(in_ptr3 + (x0 + 256*r0_2 + 16384*(x1 // 4)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tmp0 == 0
        tmp4 = (tmp2 / tmp3)
        tmp5 = tl.full([1], 0.0, tl.float32)
        tmp6 = tl.where(tmp1, tmp5, tmp4)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp6 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp14 = tl.load(in_ptr4 + (256 + 512*(x3 // 256) + ((x3 % 256))), None).to(tl.float32)
    tmp13 = tmp11.to(tl.float32)
    tmp15 = tl.sigmoid(tmp14)
    tmp16 = tmp13 * tmp15
    tl.store(out_ptr1 + (x3), tmp16, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/jp/cjp7t5czy2w7cpcqpy7brjcyztrbzc53pwckw3sw422eefuvuucq.py
# Topologically Sorted Source Nodes: [hidden_states_15, hidden_states_21, hidden_states_23, hidden_states_27, float_26, pow_13, mean_12, add_45, rsqrt_18, output_40, float_27, add_46, output_41, hidden_states_28, output_42, output_43], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_45 => add_65
#   add_46 => add_66
#   float_26 => convert_element_type_101
#   float_27 => convert_element_type_102
#   hidden_states_15 => add_35
#   hidden_states_21 => add_48
#   hidden_states_23 => add_52
#   hidden_states_27 => add_64
#   hidden_states_28 => convert_element_type_103
#   mean_12 => mean_12
#   output_40 => mul_82
#   output_41 => mul_83
#   output_42 => triton_kernel_wrapper_mutation_177
#   output_43 => triton_kernel_wrapper_mutation_176
#   pow_13 => pow_13
#   rsqrt_18 => rsqrt_18
# Graph fragment:
#   %add_31 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0" = PlaceHolder[target=add_31]
#   %buf71 : Tensor  = PlaceHolder[target=buf71]
#   %buf97 : Tensor  = PlaceHolder[target=buf97]
#   %buf106 : Tensor  = PlaceHolder[target=buf106]
#   %buf139 : Tensor  = PlaceHolder[target=buf139]
#   %add_64 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0" = PlaceHolder[target=add_64]
#   %buf141 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf141]
#   %arg84_1 : Tensor "bf16[2560][1]tnca:0" = PlaceHolder[target=arg84_1]
#   %add_35 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_31, %empty_11), kwargs = {})
#   %add_48 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_35, %empty_14), kwargs = {})
#   %add_52 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_48, %empty_17), kwargs = {})
#   %add_64 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_52, %empty_21), kwargs = {})
#   %convert_element_type_101 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_64, torch.float32), kwargs = {})
#   %pow_13 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_101, 2), kwargs = {})
#   %mean_12 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_13, [-1], True), kwargs = {})
#   %add_65 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_12, 1e-06), kwargs = {})
#   %rsqrt_18 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_65,), kwargs = {})
#   %mul_82 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_101, %rsqrt_18), kwargs = {})
#   %convert_element_type_102 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg84_1, torch.float32), kwargs = {})
#   %add_66 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_102, 1.0), kwargs = {})
#   %mul_83 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_82, %add_66), kwargs = {})
#   %convert_element_type_103 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_83, torch.bfloat16), kwargs = {})
#   %triton_kernel_wrapper_mutation_177 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1022, grid: [(1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1)], tma_descriptor_metadata: {}, kwargs: {A: %convert_element_type_103, B: %arg85_1, C: %empty_22, Bs: %arg86_1, M: 1, N: 9216, K: 2560, stride_am: 2560, stride_ak: 1, stride_bk: 1, stride_bn: 2560, stride_cm: 9216, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 20, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   %triton_kernel_wrapper_mutation_176 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 0, constant_args_idx: 1023, grid: [(1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1), (1, 72, 1)], tma_descriptor_metadata: {}, kwargs: {A: %convert_element_type_103, B: %arg87_1, C: %empty_23, Bs: %arg88_1, M: 1, N: 9216, K: 2560, stride_am: 2560, stride_ak: 1, stride_bk: 1, stride_bn: 2560, stride_cm: 9216, stride_cn: 1, stride_bs_k: 1, stride_bs_n: 20, BLOCK_SIZE_M: 16, BLOCK_SIZE_N: 128, BLOCK_SIZE_K: 128, GROUP_SIZE_M: 8}, launch_kwargs: (BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K, GROUP_SIZE_M)})
#   return %add_64,%buf141,%buf143,%buf146
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 3, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 40960}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, out_ptr2, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr1, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr2, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr3, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor5 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.debug_barrier()
        tmp14 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.debug_barrier()
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 2560.0, tl.float32)
        tmp17 = (tmp12 / tmp16)
        tmp18 = tl.full([1], 1e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tl.full([1], 1.0, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = tmp21 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp27, r0_mask)
        tl.store(out_ptr2 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp27, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/q6/cq6ivd2o2cvmemf5eirgvm5dbkpxunxeyhj4zvuaxmtilcdtohwe.py
# Topologically Sorted Source Nodes: [hidden_states_239, float_210, pow_105, mean_104, add_370, rsqrt_152, output_360, float_211, add_371, output_361, hidden_states_240], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_370 => add_538
#   add_371 => add_539
#   float_210 => convert_element_type_827
#   float_211 => convert_element_type_828
#   hidden_states_239 => add_537
#   hidden_states_240 => convert_element_type_829
#   mean_104 => mean_104
#   output_360 => mul_659
#   output_361 => mul_660
#   pow_105 => pow_105
#   rsqrt_152 => rsqrt_152
# Graph fragment:
#   %add_533 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0" = PlaceHolder[target=add_533]
#   %buf1193 : Tensor  = PlaceHolder[target=buf1193]
#   %buf1194 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf1194]
#   %arg700_1 : Tensor "bf16[2560][1]tnca:0" = PlaceHolder[target=arg700_1]
#   %add_537 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_533, %empty_199), kwargs = {})
#   %convert_element_type_827 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_537, torch.float32), kwargs = {})
#   %pow_105 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_827, 2), kwargs = {})
#   %mean_104 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_105, [-1], True), kwargs = {})
#   %add_538 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_104, 1e-06), kwargs = {})
#   %rsqrt_152 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_538,), kwargs = {})
#   %mul_659 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_827, %rsqrt_152), kwargs = {})
#   %convert_element_type_828 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg700_1, torch.float32), kwargs = {})
#   %add_539 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_828, 1.0), kwargs = {})
#   %mul_660 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_659, %add_539), kwargs = {})
#   %convert_element_type_829 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_660, torch.bfloat16), kwargs = {})
#   return %buf1194,%convert_element_type_829
triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_36 = async_compile.triton('triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_36', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_36', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 20480}, 'add_persistent_rblock': True, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_36(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2560
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[2560], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 2560.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 1e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 1.0, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = tmp17 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp23, r0_mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/d2/cd2m64wunrgghby4zqpezfeqgxa4a4rjjlaosoq4mk2icptyrnx6.py
# Topologically Sorted Source Nodes: [hidden_states_239, float_210, pow_105, mean_104, add_370, rsqrt_152, output_360, float_211, add_371, output_361, hidden_states_240, getitem_373, logits], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   add_370 => add_538
#   add_371 => add_539
#   float_210 => convert_element_type_827
#   float_211 => convert_element_type_828
#   getitem_373 => slice_226
#   hidden_states_239 => add_537
#   hidden_states_240 => convert_element_type_829
#   logits => mm_48, permute_352, view_658
#   mean_104 => mean_104
#   output_360 => mul_659
#   output_361 => mul_660
#   pow_105 => pow_105
#   rsqrt_152 => rsqrt_152
# Graph fragment:
#   %convert_element_type_829 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0" = PlaceHolder[target=convert_element_type_829]
#   %arg701_1 : Tensor "bf16[248320, 2560][2560, 1]tnca:0" = PlaceHolder[target=arg701_1]
#   %add_537 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_533, %empty_199), kwargs = {})
#   %convert_element_type_827 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_537, torch.float32), kwargs = {})
#   %pow_105 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_827, 2), kwargs = {})
#   %mean_104 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_105, [-1], True), kwargs = {})
#   %add_538 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_104, 1e-06), kwargs = {})
#   %rsqrt_152 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_538,), kwargs = {})
#   %mul_659 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_827, %rsqrt_152), kwargs = {})
#   %convert_element_type_828 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg700_1, torch.float32), kwargs = {})
#   %add_539 : Tensor "f32[2560][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_828, 1.0), kwargs = {})
#   %mul_660 : Tensor "f32[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_659, %add_539), kwargs = {})
#   %convert_element_type_829 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_660, torch.bfloat16), kwargs = {})
#   %slice_226 : Tensor "bf16[1, 1, 2560][2560, 2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_829, 1, -1, 9223372036854775807), kwargs = {})
#   %view_658 : Tensor "bf16[1, 2560][2560, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%slice_226, [1, 2560]), kwargs = {})
#   %permute_352 : Tensor "bf16[2560, 248320][1, 2560]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg701_1, [1, 0]), kwargs = {})
#   %mm_48 : Tensor "bf16[1, 248320][248320, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_658, %permute_352), kwargs = {})
#   return %mm_48
triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_37 = async_compile.triton('triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_37', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_37', 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_37(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 248320
    K = 2560
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2560

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2560*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 248320*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2560*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 248320*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/ed/cedponrbwh6aehf2i7wxcajqbkmpt4i3ig7pwpwxm6duvhft2jxd.py
# Topologically Sorted Source Nodes: [add_], Original ATen: [aten.add, aten.copy_]
# Source node to ATen node mapping:
#   add_ => add_62
# Graph fragment:
#   %copy_ : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy_]
#   %add_62 : Tensor "i64[][]tnca:0" = PlaceHolder[target=add_62]
#   %buf129 : Tensor "bf16[1, 4, 64, 256][65536, 16384, 256, 1]tnca:0" = PlaceHolder[target=buf129]
#   %any_1 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_1]
#   %amax : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax]
#   %exp_18 : Tensor "f32[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0" = PlaceHolder[target=exp_18]
#   %buf135 : Tensor "bf16[1, 4, 64, 256][65536, 16384, 256, 1]tnca:0" = PlaceHolder[target=buf135]
#   %any_2 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_2]
#   %amax_1 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_1]
#   %exp_38 : Tensor "f32[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0" = PlaceHolder[target=exp_38]
#   %any_3 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_3]
#   %amax_2 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_2]
#   %exp_58 : Tensor "f32[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0" = PlaceHolder[target=exp_58]
#   %any_4 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_4]
#   %amax_3 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_3]
#   %exp_78 : Tensor "f32[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0" = PlaceHolder[target=exp_78]
#   %any_5 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_5]
#   %amax_4 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_4]
#   %exp_98 : Tensor "f32[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0" = PlaceHolder[target=exp_98]
#   %any_6 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_6]
#   %amax_5 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_5]
#   %exp_118 : Tensor "f32[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0" = PlaceHolder[target=exp_118]
#   %any_7 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_7]
#   %amax_6 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_6]
#   %exp_138 : Tensor "f32[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0" = PlaceHolder[target=exp_138]
#   %any_8 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=any_8]
#   %amax_7 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=amax_7]
#   %exp_158 : Tensor "f32[1, 16, 1, 64][1024, 64, 1024, 1]tnca:0" = PlaceHolder[target=exp_158]
#   %add_62 : Tensor "i64[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg3_1, 1), kwargs = {})
#   %copy_ : Tensor "i64[][]tnca:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg3_1, %add_62), kwargs = {})
#   return %add_62,%buf1241
triton_poi_fused_add_copy__38 = async_compile.triton('triton_poi_fused_add_copy__38', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'out_ptr1': '*i64', 'xnumel': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_copy__38', 'mutated_arg_names': ['in_ptr0', 'out_ptr1'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_copy__38(in_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp2 = tl.full([1], 1, tl.int64)
    tmp3 = tmp1 + tmp2
    tl.store(out_ptr1 + (tl.full([XBLOCK], 0, tl.int32).broadcast_to(XBLOCK)), tmp3, None)
''', device_str='tnca')


# kernel path: /home/zzhouch/r41run3/chat_nohost_v4_20261031/chat-q35/r3-s2-qwen-chat-v3-q35-nohost-v4-session-20261031/caches/inductor/2j/c2j6h42j42rfwtwf36hleebl2w35l3a75gyuqfgbc3vyzaecdivc.py
# Topologically Sorted Source Nodes: [getitem_13, copy_], Original ATen: [aten.slice, aten.copy, aten.copy_]
# Source node to ATen node mapping:
#   copy_ => copy_4
#   getitem_13 => slice_18
# Graph fragment:
#   %cat : Tensor "bf16[1, 8192, 5][40960, 5, 1]tnca:0" = PlaceHolder[target=cat]
#   %copy__1 : Tensor "bf16[1, 8192, 4][32768, 4, 1]tnca:0" = PlaceHolder[target=copy__1]
#   %buf9 : Tensor "bf16[1, 8192, 4][40960, 5, 1]tnca:0" = PlaceHolder[target=buf9]
#   %slice_18 : Tensor "bf16[1, 8192, 4][40960, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%cat, 2, -4, 9223372036854775807), kwargs = {})
#   %copy_4 : Tensor "bf16[1, 8192, 4][32768, 4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.copy.default](args = (%arg13_1, %slice_18), kwargs = {})
#   %copy__1 : Tensor "bf16[1, 8192, 4][32768, 4, 1]tnca:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg13_1, %copy_4), kwargs = {})
#   return %buf1242
triton_poi_fused_copy_copy__slice_39 = async_compile.triton('triton_poi_fused_copy_copy__slice_39', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32768}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_copy_copy__slice_39', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 196608}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_copy_copy__slice_39(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32768
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 4)
    x1 = xindex // 4
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (1 + x0 + 5*x1), None).to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp0, None)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1, arg484_1, arg485_1, arg486_1, arg487_1, arg488_1, arg489_1, arg490_1, arg491_1, arg492_1, arg493_1, arg494_1, arg495_1, arg496_1, arg497_1, arg498_1, arg499_1, arg500_1, arg501_1, arg502_1, arg503_1, arg504_1, arg505_1, arg506_1, arg507_1, arg508_1, arg509_1, arg510_1, arg511_1, arg512_1, arg513_1, arg514_1, arg515_1, arg516_1, arg517_1, arg518_1, arg519_1, arg520_1, arg521_1, arg522_1, arg523_1, arg524_1, arg525_1, arg526_1, arg527_1, arg528_1, arg529_1, arg530_1, arg531_1, arg532_1, arg533_1, arg534_1, arg535_1, arg536_1, arg537_1, arg538_1, arg539_1, arg540_1, arg541_1, arg542_1, arg543_1, arg544_1, arg545_1, arg546_1, arg547_1, arg548_1, arg549_1, arg550_1, arg551_1, arg552_1, arg553_1, arg554_1, arg555_1, arg556_1, arg557_1, arg558_1, arg559_1, arg560_1, arg561_1, arg562_1, arg563_1, arg564_1, arg565_1, arg566_1, arg567_1, arg568_1, arg569_1, arg570_1, arg571_1, arg572_1, arg573_1, arg574_1, arg575_1, arg576_1, arg577_1, arg578_1, arg579_1, arg580_1, arg581_1, arg582_1, arg583_1, arg584_1, arg585_1, arg586_1, arg587_1, arg588_1, arg589_1, arg590_1, arg591_1, arg592_1, arg593_1, arg594_1, arg595_1, arg596_1, arg597_1, arg598_1, arg599_1, arg600_1, arg601_1, arg602_1, arg603_1, arg604_1, arg605_1, arg606_1, arg607_1, arg608_1, arg609_1, arg610_1, arg611_1, arg612_1, arg613_1, arg614_1, arg615_1, arg616_1, arg617_1, arg618_1, arg619_1, arg620_1, arg621_1, arg622_1, arg623_1, arg624_1, arg625_1, arg626_1, arg627_1, arg628_1, arg629_1, arg630_1, arg631_1, arg632_1, arg633_1, arg634_1, arg635_1, arg636_1, arg637_1, arg638_1, arg639_1, arg640_1, arg641_1, arg642_1, arg643_1, arg644_1, arg645_1, arg646_1, arg647_1, arg648_1, arg649_1, arg650_1, arg651_1, arg652_1, arg653_1, arg654_1, arg655_1, arg656_1, arg657_1, arg658_1, arg659_1, arg660_1, arg661_1, arg662_1, arg663_1, arg664_1, arg665_1, arg666_1, arg667_1, arg668_1, arg669_1, arg670_1, arg671_1, arg672_1, arg673_1, arg674_1, arg675_1, arg676_1, arg677_1, arg678_1, arg679_1, arg680_1, arg681_1, arg682_1, arg683_1, arg684_1, arg685_1, arg686_1, arg687_1, arg688_1, arg689_1, arg690_1, arg691_1, arg692_1, arg693_1, arg694_1, arg695_1, arg696_1, arg697_1, arg698_1, arg699_1, arg700_1, arg701_1 = args
        args.clear()
        assert_size_stride_grouped((arg2_1, arg4_1), ((4, 1, 1), (32, )), ((1, 1, 1), (1, )), 'input')
        buf0 = empty_strided((3, 1, 1, 32), (32, 96, 96, 1), device='tnca', dtype=torch.float32)
        buf1 = empty_strided((3, 1, 1, 32), (32, 96, 96, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [position_ids, position_ids_1, getitem_6, float_1, freqs, sin_1, getitem_8, cos_1, getitem_11], Original ATen: [aten.slice, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0.run(arg2_1, arg4_1, buf0, buf1, 96, stream=raw_stream0)
        del arg2_1
        del arg4_1
        assert_size_stride_grouped((arg1_1, arg0_1, arg5_1), ((1, 1), (248320, 2560), (2560, )), ((1, 1), (2560, 1), (1, )), 'input')
        buf4 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        buf7 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        buf15 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add_2, rsqrt, output, float_3, add_3, output_1, hidden_states, output_2, output_3], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1.run(arg1_1, arg0_1, arg5_1, buf4, buf7, buf15, 1, 2560, stream=raw_stream0)
        del arg5_1
        buf3 = empty_strided((1, 1, 8192), (8192, 8192, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg6_1, arg7_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add_2, rsqrt, output, float_3, add_3, output_1, hidden_states, output_2], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf4, arg6_1, buf3, arg7_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg6_1
        del arg7_1
        buf6 = empty_strided((1, 1, 4096), (4096, 4096, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg8_1, arg9_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add_2, rsqrt, output, float_3, add_3, output_1, hidden_states, output_3], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf7, arg8_1, buf6, arg9_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg8_1
        del arg9_1
        assert_size_stride(arg13_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf11 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf9 = reinterpret_tensor(buf11, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_2], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg13_1, buf9, 32768, stream=raw_stream0)
        buf10 = reinterpret_tensor(buf11, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_2], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf3, buf10, 8192, stream=raw_stream0)
        assert_size_stride(arg12_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf13 = reinterpret_tensor(buf3, (1, 8192, 1), (8192, 1, 8192), 0); del buf3  # reuse
        # Topologically Sorted Source Nodes: [out, squeeze, unsqueeze, out_1, out_2], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf11, arg12_1, buf13, 8192, stream=raw_stream0)
        del arg12_1
        del buf10
        del buf9
        buf14 = empty_strided((1, 32, 1, 1), (32, 1, 32, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_2, mixed_qkv_2, split, key_1, key_2, transpose_3, key_3, mul_8, sum_2], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf13, buf14, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg11_1, arg14_1, arg15_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf17 = empty_strided((1, 32), (32, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add_2, rsqrt, output, float_3, add_3, output_1, hidden_states, float_4, exp, neg, a, float_5, add_4, softplus, g, transpose_6, getitem_21, exp_1], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf15, arg11_1, arg14_1, arg15_1, buf17, 2, 1, 1, stream=raw_stream0)
        del arg11_1
        del arg14_1
        del arg15_1
        assert_size_stride(arg16_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf18 = empty_strided((1, 32, 128), (4096, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_2, mixed_qkv_2, split, key_1, key_2, transpose_3, key_3, add_6, inv_norm_1, key_4, k_t, float_4, exp, neg, a, float_5, add_4, softplus, g, transpose_6, getitem_21, exp_1, decay_t, last_recurrent_state_1, unsqueeze_2, mul_11, kv_mem], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg16_1, buf17, buf13, buf14, buf18, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg10_1, (32, 2560), (2560, 1), 'input')
        buf20 = empty_strided((1, 32, 1), (32, 1, 32), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [b, beta, transpose_5, beta_1], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf15, arg10_1, buf20, 2, 1, 1, stream=raw_stream0)
        del arg10_1
        buf21 = empty_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_2, mixed_qkv_2, split, key_1, key_2, transpose_3, key_3, add_6, inv_norm_1, key_4, k_t, unsqueeze_3, value_1, transpose_4, value_2, v_t, float_4, exp, neg, a, float_5, add_4, softplus, g, transpose_6, getitem_21, exp_1, decay_t, last_recurrent_state_1, sub, b, beta, transpose_5, beta_1, getitem_23, beta_t, delta, unsqueeze_4, mul_13, last_recurrent_state_2], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg16_1, buf17, buf13, buf14, buf18, buf20, buf21, arg16_1, 524288, stream=raw_stream0)
        del arg16_1
        buf22 = reinterpret_tensor(buf20, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf20  # reuse
        # Topologically Sorted Source Nodes: [out_2, mixed_qkv_2, split, query_1, query_2, transpose_2, query_3, mul_6, sum_1], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf13, buf22, 32, 128, stream=raw_stream0)
        buf23 = buf18; del buf18  # reuse
        # Topologically Sorted Source Nodes: [out_2, mixed_qkv_2, split, query_1, query_2, transpose_2, query_3, add_5, inv_norm, query_4, query_5, q_t, unsqueeze_5, mul_14, sum_4], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf21, buf13, buf22, buf23, 4096, 128, stream=raw_stream0)
        buf24 = reinterpret_tensor(buf22, (32, 1), (1, 32), 0); del buf22  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out, core_attn_out_1, core_attn_out_2, hidden_states_1, pow_2, variance], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf23, buf24, 32, 128, stream=raw_stream0)
        buf25 = buf15; del buf15  # reuse
        assert_size_stride(arg17_1, (128, ), (1, ), 'input')
        buf26 = empty_strided((1, 1, 4096), (4096, 4096, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [core_attn_out, core_attn_out_1, core_attn_out_2, hidden_states_1, pow_2, variance, add_8, rsqrt_3, hidden_states_2, to_14, hidden_states_3, to_15, silu_1, hidden_states_4, core_attn_out_3, core_attn_out_4, output_4], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg17_1, buf23, buf24, buf6, buf26, 4096, stream=raw_stream0)
        del arg17_1
        assert_size_stride_grouped((arg18_1, arg19_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out, core_attn_out_1, core_attn_out_2, hidden_states_1, pow_2, variance, add_8, rsqrt_3, hidden_states_2, to_14, hidden_states_3, to_15, silu_1, hidden_states_4, core_attn_out_3, core_attn_out_4, output_4], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf26, arg18_1, buf25, arg19_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg18_1
        del arg19_1
        assert_size_stride(arg20_1, (2560, ), (1, ), 'input')
        buf29 = buf7; del buf7  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_5, float_6, pow_3, mean_2, add_10, rsqrt_4, output_5, float_7, add_11, output_6, hidden_states_6], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_14.run(arg1_1, arg0_1, buf25, arg20_1, buf29, 1, 2560, stream=raw_stream0)
        del arg20_1
        buf30 = empty_strided((1, 1, 9216), (9216, 9216, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg21_1, arg22_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_7], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf29, arg21_1, buf30, arg22_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg21_1
        del arg22_1
        buf32 = empty_strided((1, 1, 9216), (9216, 9216, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg23_1, arg24_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_8], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf29, arg23_1, buf32, arg24_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg23_1
        del arg24_1
        buf34 = buf29; del buf29  # reuse
        buf35 = empty_strided((1, 1, 9216), (9216, 9216, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_2, mul_20, output_9], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf30, buf32, buf35, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg25_1, arg26_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_2, mul_20, output_9], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf35, arg25_1, buf34, arg26_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg25_1
        del arg26_1
        assert_size_stride(arg27_1, (2560, ), (1, ), 'input')
        buf38 = buf4; del buf4  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_5, hidden_states_7, float_8, pow_4, mean_3, add_13, rsqrt_5, output_10, float_9, add_14, output_11, hidden_states_8], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_16.run(arg1_1, arg0_1, buf25, buf34, arg27_1, buf38, 1, 2560, stream=raw_stream0)
        del arg27_1
        buf39 = reinterpret_tensor(buf13, (1, 1, 8192), (8192, 8192, 1), 0); del buf13  # reuse
        assert_size_stride_grouped((arg28_1, arg29_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_12], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf38, arg28_1, buf39, arg29_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg28_1
        del arg29_1
        buf41 = buf26; del buf26  # reuse
        assert_size_stride_grouped((arg30_1, arg31_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_13], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf38, arg30_1, buf41, arg31_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg30_1
        del arg31_1
        assert_size_stride(arg35_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf45 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf43 = reinterpret_tensor(buf45, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_3], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg35_1, buf43, 32768, stream=raw_stream0)
        buf44 = reinterpret_tensor(buf45, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_3], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf39, buf44, 8192, stream=raw_stream0)
        assert_size_stride(arg34_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf47 = reinterpret_tensor(buf39, (1, 8192, 1), (8192, 1, 8192), 0); del buf39  # reuse
        # Topologically Sorted Source Nodes: [out_3, squeeze_1, unsqueeze_6, out_4, out_5], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf45, arg34_1, buf47, 8192, stream=raw_stream0)
        del arg34_1
        del buf43
        del buf44
        buf48 = reinterpret_tensor(buf24, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf24  # reuse
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_5, split_1, key_6, key_7, transpose_11, key_8, mul_26, sum_6], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf47, buf48, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg33_1, arg36_1, arg37_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf50 = buf17; del buf17  # reuse
        # Topologically Sorted Source Nodes: [float_10, exp_2, neg_1, a_1, float_11, add_15, softplus_1, g_1, transpose_14, getitem_32, exp_3], Original ATen: [aten._to_copy, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_17.run(buf38, arg33_1, arg36_1, arg37_1, buf50, 2, 1, 1, stream=raw_stream0)
        del arg33_1
        del arg36_1
        del arg37_1
        assert_size_stride(arg38_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf51 = buf23; del buf23  # reuse
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_5, split_1, key_6, key_7, transpose_11, key_8, add_17, inv_norm_3, key_9, k_t_1, float_10, exp_2, neg_1, a_1, float_11, add_15, softplus_1, g_1, transpose_14, getitem_32, exp_3, decay_t_1, last_recurrent_state_4, unsqueeze_8, mul_29, kv_mem_1], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg38_1, buf50, buf47, buf48, buf51, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg32_1, (32, 2560), (2560, 1), 'input')
        buf53 = reinterpret_tensor(buf14, (1, 32, 1), (32, 1, 32), 0); del buf14  # reuse
        # Topologically Sorted Source Nodes: [b_1, beta_2, transpose_13, beta_3], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf38, arg32_1, buf53, 2, 1, 1, stream=raw_stream0)
        del arg32_1
        buf54 = buf21; del buf21  # reuse
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_5, split_1, key_6, key_7, transpose_11, key_8, add_17, inv_norm_3, key_9, k_t_1, unsqueeze_9, value_4, transpose_12, value_5, v_t_1, float_10, exp_2, neg_1, a_1, float_11, add_15, softplus_1, g_1, transpose_14, getitem_32, exp_3, decay_t_1, last_recurrent_state_4, sub_1, b_1, beta_2, transpose_13, beta_3, getitem_34, beta_t_1, delta_1, unsqueeze_10, mul_31, last_recurrent_state_5], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg38_1, buf50, buf47, buf48, buf51, buf53, buf54, arg38_1, 524288, stream=raw_stream0)
        del arg38_1
        buf55 = reinterpret_tensor(buf53, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf53  # reuse
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_5, split_1, query_7, query_8, transpose_10, query_9, mul_24, sum_5], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf47, buf55, 32, 128, stream=raw_stream0)
        buf56 = buf51; del buf51  # reuse
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_5, split_1, query_7, query_8, transpose_10, query_9, add_16, inv_norm_2, query_10, query_11, q_t_1, unsqueeze_11, mul_32, sum_8], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf54, buf47, buf55, buf56, 4096, 128, stream=raw_stream0)
        buf57 = reinterpret_tensor(buf55, (32, 1), (1, 32), 0); del buf55  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_5, core_attn_out_6, core_attn_out_7, hidden_states_9, pow_5, variance_1], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf56, buf57, 32, 128, stream=raw_stream0)
        buf58 = buf38; del buf38  # reuse
        assert_size_stride(arg39_1, (128, ), (1, ), 'input')
        buf59 = buf6; del buf6  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_5, core_attn_out_6, core_attn_out_7, hidden_states_9, pow_5, variance_1, add_19, rsqrt_8, hidden_states_10, to_27, hidden_states_11, to_28, silu_4, hidden_states_12, core_attn_out_8, core_attn_out_9, output_14], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg39_1, buf56, buf57, buf41, buf59, 4096, stream=raw_stream0)
        del arg39_1
        assert_size_stride_grouped((arg40_1, arg41_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_5, core_attn_out_6, core_attn_out_7, hidden_states_9, pow_5, variance_1, add_19, rsqrt_8, hidden_states_10, to_27, hidden_states_11, to_28, silu_4, hidden_states_12, core_attn_out_8, core_attn_out_9, output_14], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf59, arg40_1, buf58, arg41_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg40_1
        del arg41_1
        assert_size_stride(arg42_1, (2560, ), (1, ), 'input')
        buf61 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        buf64 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        buf67 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states_5, hidden_states_7, hidden_states_13, float_12, pow_6, mean_5, add_21, rsqrt_9, output_15, float_13, add_22, output_16, hidden_states_14, output_17, output_18], Original ATen: [aten.embedding, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_18.run(arg1_1, arg0_1, buf25, buf34, buf58, arg42_1, buf61, buf64, buf67, 1, 2560, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg42_1
        buf63 = buf35; del buf35  # reuse
        assert_size_stride_grouped((arg43_1, arg44_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_12, pow_6, mean_5, add_21, rsqrt_9, output_15, float_13, add_22, output_16, hidden_states_14, output_17], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf64, arg43_1, buf63, arg44_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg43_1
        del arg44_1
        buf66 = buf32; del buf32  # reuse
        assert_size_stride_grouped((arg45_1, arg46_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_12, pow_6, mean_5, add_21, rsqrt_9, output_15, float_13, add_22, output_16, hidden_states_14, output_18], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf67, arg45_1, buf66, arg46_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg45_1
        del arg46_1
        buf69 = buf67; del buf67  # reuse
        buf70 = buf30; del buf30  # reuse
        # Topologically Sorted Source Nodes: [silu_5, mul_38, output_19], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf63, buf66, buf70, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg47_1, arg48_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_5, mul_38, output_19], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf70, arg47_1, buf69, arg48_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg47_1
        del arg48_1
        assert_size_stride(arg49_1, (2560, ), (1, ), 'input')
        buf74 = buf64; del buf64  # reuse
        buf77 = buf58; del buf58  # reuse
        buf85 = buf34; del buf34  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_15, float_14, pow_7, mean_6, add_24, rsqrt_10, output_20, float_15, add_25, output_21, hidden_states_16, output_22, output_23], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf61, buf69, arg49_1, buf74, buf77, buf85, 1, 2560, stream=raw_stream0)
        del arg49_1
        buf73 = reinterpret_tensor(buf47, (1, 1, 8192), (8192, 8192, 1), 0); del buf47  # reuse
        assert_size_stride_grouped((arg50_1, arg51_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_15, float_14, pow_7, mean_6, add_24, rsqrt_10, output_20, float_15, add_25, output_21, hidden_states_16, output_22], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf74, arg50_1, buf73, arg51_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg50_1
        del arg51_1
        buf76 = buf59; del buf59  # reuse
        assert_size_stride_grouped((arg52_1, arg53_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_15, float_14, pow_7, mean_6, add_24, rsqrt_10, output_20, float_15, add_25, output_21, hidden_states_16, output_23], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf77, arg52_1, buf76, arg53_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg52_1
        del arg53_1
        assert_size_stride(arg57_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf81 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf79 = reinterpret_tensor(buf81, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_4], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg57_1, buf79, 32768, stream=raw_stream0)
        buf80 = reinterpret_tensor(buf81, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_4], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf73, buf80, 8192, stream=raw_stream0)
        assert_size_stride(arg56_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf83 = reinterpret_tensor(buf73, (1, 8192, 1), (8192, 1, 8192), 0); del buf73  # reuse
        # Topologically Sorted Source Nodes: [out_6, squeeze_2, unsqueeze_12, out_7, out_8], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf81, arg56_1, buf83, 8192, stream=raw_stream0)
        del arg56_1
        del buf79
        del buf80
        buf84 = reinterpret_tensor(buf57, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf57  # reuse
        # Topologically Sorted Source Nodes: [out_8, mixed_qkv_8, split_2, key_11, key_12, transpose_19, key_13, mul_44, sum_10], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf83, buf84, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg55_1, arg58_1, arg59_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf87 = buf50; del buf50  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_15, float_14, pow_7, mean_6, add_24, rsqrt_10, output_20, float_15, add_25, output_21, hidden_states_16, float_16, exp_4, neg_2, a_2, float_17, add_26, softplus_2, g_2, transpose_22, getitem_43, exp_5], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf85, arg55_1, arg58_1, arg59_1, buf87, 2, 1, 1, stream=raw_stream0)
        del arg55_1
        del arg58_1
        del arg59_1
        assert_size_stride(arg60_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf88 = buf56; del buf56  # reuse
        # Topologically Sorted Source Nodes: [out_8, mixed_qkv_8, split_2, key_11, key_12, transpose_19, key_13, add_28, inv_norm_5, key_14, k_t_2, float_16, exp_4, neg_2, a_2, float_17, add_26, softplus_2, g_2, transpose_22, getitem_43, exp_5, decay_t_2, last_recurrent_state_7, unsqueeze_14, mul_47, kv_mem_2], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg60_1, buf87, buf83, buf84, buf88, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg54_1, (32, 2560), (2560, 1), 'input')
        buf90 = reinterpret_tensor(buf48, (1, 32, 1), (32, 1, 32), 0); del buf48  # reuse
        # Topologically Sorted Source Nodes: [b_2, beta_4, transpose_21, beta_5], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf85, arg54_1, buf90, 2, 1, 1, stream=raw_stream0)
        del arg54_1
        buf91 = buf54; del buf54  # reuse
        # Topologically Sorted Source Nodes: [out_8, mixed_qkv_8, split_2, key_11, key_12, transpose_19, key_13, add_28, inv_norm_5, key_14, k_t_2, unsqueeze_15, value_7, transpose_20, value_8, v_t_2, float_16, exp_4, neg_2, a_2, float_17, add_26, softplus_2, g_2, transpose_22, getitem_43, exp_5, decay_t_2, last_recurrent_state_7, sub_2, b_2, beta_4, transpose_21, beta_5, getitem_45, beta_t_2, delta_2, unsqueeze_16, mul_49, last_recurrent_state_8], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg60_1, buf87, buf83, buf84, buf88, buf90, buf91, arg60_1, 524288, stream=raw_stream0)
        del arg60_1
        buf92 = reinterpret_tensor(buf90, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf90  # reuse
        # Topologically Sorted Source Nodes: [out_8, mixed_qkv_8, split_2, query_13, query_14, transpose_18, query_15, mul_42, sum_9], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf83, buf92, 32, 128, stream=raw_stream0)
        buf93 = buf88; del buf88  # reuse
        # Topologically Sorted Source Nodes: [out_8, mixed_qkv_8, split_2, query_13, query_14, transpose_18, query_15, add_27, inv_norm_4, query_16, query_17, q_t_2, unsqueeze_17, mul_50, sum_12], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf91, buf83, buf92, buf93, 4096, 128, stream=raw_stream0)
        buf94 = reinterpret_tensor(buf92, (32, 1), (1, 32), 0); del buf92  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_10, core_attn_out_11, core_attn_out_12, hidden_states_17, pow_8, variance_2], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf93, buf94, 32, 128, stream=raw_stream0)
        buf95 = buf85; del buf85  # reuse
        assert_size_stride(arg61_1, (128, ), (1, ), 'input')
        buf96 = buf41; del buf41  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_10, core_attn_out_11, core_attn_out_12, hidden_states_17, pow_8, variance_2, add_30, rsqrt_13, hidden_states_18, to_40, hidden_states_19, to_41, silu_7, hidden_states_20, core_attn_out_13, core_attn_out_14, output_24], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg61_1, buf93, buf94, buf76, buf96, 4096, stream=raw_stream0)
        del arg61_1
        assert_size_stride_grouped((arg62_1, arg63_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_10, core_attn_out_11, core_attn_out_12, hidden_states_17, pow_8, variance_2, add_30, rsqrt_13, hidden_states_18, to_40, hidden_states_19, to_41, silu_7, hidden_states_20, core_attn_out_13, core_attn_out_14, output_24], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf96, arg62_1, buf95, arg63_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg62_1
        del arg63_1
        assert_size_stride(arg64_1, (2560, ), (1, ), 'input')
        buf99 = buf77; del buf77  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_15, hidden_states_21, float_18, pow_9, mean_8, add_32, rsqrt_14, output_25, float_19, add_33, output_26, hidden_states_22], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf61, buf69, buf95, arg64_1, buf99, 1, 2560, stream=raw_stream0)
        del arg64_1
        buf100 = buf70; del buf70  # reuse
        assert_size_stride_grouped((arg65_1, arg66_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_27], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf99, arg65_1, buf100, arg66_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg65_1
        del arg66_1
        buf102 = buf66; del buf66  # reuse
        assert_size_stride_grouped((arg67_1, arg68_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_28], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf99, arg67_1, buf102, arg68_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg67_1
        del arg68_1
        buf104 = buf99; del buf99  # reuse
        buf105 = buf63; del buf63  # reuse
        # Topologically Sorted Source Nodes: [silu_8, mul_56, output_29], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf100, buf102, buf105, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg69_1, arg70_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_8, mul_56, output_29], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf105, arg69_1, buf104, arg70_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg69_1
        del arg70_1
        assert_size_stride(arg71_1, (2560, ), (1, ), 'input')
        buf108 = buf74; del buf74  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_15, hidden_states_21, hidden_states_23, float_20, pow_10, mean_9, add_35, rsqrt_15, output_30, float_21, add_36, output_31, hidden_states_24], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf61, buf69, buf95, buf104, arg71_1, buf108, 1, 2560, stream=raw_stream0)
        del arg71_1
        buf109 = reinterpret_tensor(buf83, (1, 1, 8192), (8192, 8192, 1), 0); del buf83  # reuse
        assert_size_stride_grouped((arg72_1, arg73_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_32], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf108, arg72_1, buf109, arg73_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg72_1
        del arg73_1
        buf111 = empty_strided((1, 1, 1024), (1024, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg75_1, arg76_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_35], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf108, arg75_1, buf111, arg76_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg75_1
        del arg76_1
        buf113 = empty_strided((1, 1, 1024), (1024, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg78_1, arg79_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_38], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf108, arg78_1, buf113, arg79_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg78_1
        del arg79_1
        buf115 = empty_strided((1, 1, 16, 1), (16, 16, 1, 16), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [float_22, pow_11, mean_10], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_split_view_22.run(buf109, buf115, 16, 256, stream=raw_stream0)
        assert_size_stride(arg74_1, (256, ), (1, ), 'input')
        buf118 = empty_strided((1, 16, 1, 64), (1024, 64, 64, 1), device='tnca', dtype=torch.bfloat16)
        buf116 = reinterpret_tensor(buf118, (1, 16, 1, 32), (1024, 64, 64, 1), 0)  # alias
        buf117 = reinterpret_tensor(buf118, (1, 16, 1, 32), (1024, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_22, pow_11, mean_10, add_37, rsqrt_16, output_33, float_23, add_38, output_34, type_as_7, query_states_1, q_rot, x2, neg_3, x1, cat_5], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_23.run(buf109, buf115, arg74_1, buf116, buf117, 512, stream=raw_stream0)
        buf121 = reinterpret_tensor(buf96, (1, 16, 1, 256), (4096, 256, 256, 1), 0); del buf96  # reuse
        buf119 = reinterpret_tensor(buf121, (1, 16, 1, 64), (4096, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [float_22, pow_11, mean_10, add_37, rsqrt_16, output_33, float_23, add_38, output_34, type_as_7, query_states_1, q_rot, setitem_3, cos_2, cos_3, cos_4, mul_63, setitem_1, sin_2, sin_3, sin_4, mul_64, q_embed], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.select, aten.cat, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_24.run(buf109, buf115, arg74_1, buf1, buf118, buf0, buf119, 1024, stream=raw_stream0)
        del buf116
        del buf117
        buf120 = reinterpret_tensor(buf121, (1, 16, 1, 192), (4096, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [float_22, pow_11, mean_10, add_37, rsqrt_16, output_33, float_23, add_38, output_34, type_as_7, query_states_1, q_rot, setitem_3, cos_2, cos_3, cos_4, mul_63, setitem_1, sin_2, sin_3, sin_4, mul_64, q_embed, q_pass, q_embed_1], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.select, aten.cat, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_25.run(buf109, buf115, arg74_1, buf120, 3072, stream=raw_stream0)
        del arg74_1
        buf122 = empty_strided((1, 1, 4, 1), (4, 4, 1, 4), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [float_24, pow_12, mean_11], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_26.run(buf111, buf122, 4, 256, stream=raw_stream0)
        del buf119
        del buf120
        assert_size_stride(arg77_1, (256, ), (1, ), 'input')
        buf125 = empty_strided((1, 4, 1, 64), (256, 64, 64, 1), device='tnca', dtype=torch.bfloat16)
        buf123 = reinterpret_tensor(buf125, (1, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        buf124 = reinterpret_tensor(buf125, (1, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_24, pow_12, mean_11, add_39, rsqrt_17, output_36, float_25, add_40, output_37, type_as_8, key_states, k_rot, x2_1, neg_4, x1_1, cat_6], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_27.run(buf111, buf122, arg77_1, buf123, buf124, 128, stream=raw_stream0)
        buf128 = reinterpret_tensor(buf118, (1, 4, 1, 256), (1024, 256, 256, 1), 0); del buf118  # reuse
        buf126 = reinterpret_tensor(buf128, (1, 4, 1, 64), (1024, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, cos_4, setitem_1, sin_2, sin_3, sin_4, float_24, pow_12, mean_11, add_39, rsqrt_17, output_36, float_25, add_40, output_37, type_as_8, key_states, k_rot, mul_65, mul_66, k_embed], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28.run(buf111, buf122, arg77_1, buf1, buf125, buf0, buf126, 256, stream=raw_stream0)
        del buf123
        del buf124
        buf127 = reinterpret_tensor(buf128, (1, 4, 1, 192), (1024, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, cos_4, setitem_1, sin_2, sin_3, sin_4, float_24, pow_12, mean_11, add_39, rsqrt_17, output_36, float_25, add_40, output_37, type_as_8, key_states, k_rot, mul_65, mul_66, k_embed, k_pass, k_embed_1], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_29.run(buf111, buf122, arg77_1, buf127, 768, stream=raw_stream0)
        del arg77_1
        assert_size_stride_grouped((arg3_1, arg80_1), ((), (1, 4, 64, 256)), ((), (65536, 16384, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_4, cache_position, index_copy_], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_30.run(arg3_1, buf128, arg80_1, 1024, stream=raw_stream0)
        del buf126
        del buf127
        buf130 = empty_strided((16, 1, 64), (64, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [attn_output, key_15], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_31.run(buf121, arg80_1, buf130, 1024, 256, stream=raw_stream0)
        del arg80_1
        buf131 = empty_strided((1, 16, 1, 1), (16, 1, 16, 16), device='tnca', dtype=torch.bool)
        buf133 = empty_strided((1, 16, 1, 64), (1024, 64, 1024, 1), device='tnca', dtype=torch.float32)
        buf134 = reinterpret_tensor(buf115, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf115  # reuse
        # Topologically Sorted Source Nodes: [attn_output, kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32.run(buf130, arg3_1, buf131, buf133, buf134, 16, 64, stream=raw_stream0)
        assert_size_stride(arg81_1, (1, 4, 64, 256), (65536, 16384, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_4, cache_position, index_copy__1], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_33.run(arg3_1, buf113, arg81_1, 1024, stream=raw_stream0)
        buf138 = reinterpret_tensor(buf121, (1, 1, 4096), (4096, 4096, 1), 0); del buf121  # reuse
        # Topologically Sorted Source Nodes: [gate_1, attn_output, value_9, transpose_27, reshape_24, sigmoid_3, attn_output_3, output_39], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34.run(buf131, buf133, buf134, arg81_1, buf109, buf138, 4096, 64, stream=raw_stream0)
        del arg81_1
        buf137 = buf108; del buf108  # reuse
        assert_size_stride_grouped((arg82_1, arg83_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [gate_1, attn_output, transpose_27, reshape_24, sigmoid_3, attn_output_3, output_39], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf138, arg82_1, buf137, arg83_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg82_1
        del arg83_1
        assert_size_stride(arg84_1, (2560, ), (1, ), 'input')
        buf140 = buf61; del buf61  # reuse
        buf143 = buf25; del buf25  # reuse
        buf146 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_15, hidden_states_21, hidden_states_23, hidden_states_27, float_26, pow_13, mean_12, add_45, rsqrt_18, output_40, float_27, add_46, output_41, hidden_states_28, output_42, output_43], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf140, buf69, buf95, buf104, buf137, arg84_1, buf143, buf146, 1, 2560, stream=raw_stream0)
        del arg84_1
        buf142 = buf105; del buf105  # reuse
        assert_size_stride_grouped((arg85_1, arg86_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_26, pow_13, mean_12, add_45, rsqrt_18, output_40, float_27, add_46, output_41, hidden_states_28, output_42], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf143, arg85_1, buf142, arg86_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg85_1
        del arg86_1
        buf145 = buf102; del buf102  # reuse
        assert_size_stride_grouped((arg87_1, arg88_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_26, pow_13, mean_12, add_45, rsqrt_18, output_40, float_27, add_46, output_41, hidden_states_28, output_43], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf146, arg87_1, buf145, arg88_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg87_1
        del arg88_1
        buf148 = buf146; del buf146  # reuse
        buf149 = buf100; del buf100  # reuse
        # Topologically Sorted Source Nodes: [silu_9, mul_70, output_44], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf142, buf145, buf149, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg89_1, arg90_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_9, mul_70, output_44], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf149, arg89_1, buf148, arg90_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg89_1
        del arg90_1
        assert_size_stride(arg91_1, (2560, ), (1, ), 'input')
        buf153 = buf143; del buf143  # reuse
        buf156 = buf95; del buf95  # reuse
        buf164 = buf69; del buf69  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_29, float_28, pow_14, mean_13, add_48, rsqrt_19, output_45, float_29, add_49, output_46, hidden_states_30, output_47, output_48], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf140, buf148, arg91_1, buf153, buf156, buf164, 1, 2560, stream=raw_stream0)
        del arg91_1
        buf152 = buf109; del buf109  # reuse
        assert_size_stride_grouped((arg92_1, arg93_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_29, float_28, pow_14, mean_13, add_48, rsqrt_19, output_45, float_29, add_49, output_46, hidden_states_30, output_47], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf153, arg92_1, buf152, arg93_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg92_1
        del arg93_1
        buf155 = buf138; del buf138  # reuse
        assert_size_stride_grouped((arg94_1, arg95_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_29, float_28, pow_14, mean_13, add_48, rsqrt_19, output_45, float_29, add_49, output_46, hidden_states_30, output_48], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf156, arg94_1, buf155, arg95_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg94_1
        del arg95_1
        assert_size_stride(arg99_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf160 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf158 = reinterpret_tensor(buf160, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_9], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg99_1, buf158, 32768, stream=raw_stream0)
        buf159 = reinterpret_tensor(buf160, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_9], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf152, buf159, 8192, stream=raw_stream0)
        assert_size_stride(arg98_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf162 = reinterpret_tensor(buf152, (1, 8192, 1), (8192, 1, 8192), 0); del buf152  # reuse
        # Topologically Sorted Source Nodes: [out_9, squeeze_3, unsqueeze_20, out_10, out_11], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf160, arg98_1, buf162, 8192, stream=raw_stream0)
        del arg98_1
        del buf158
        del buf159
        buf163 = reinterpret_tensor(buf94, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf94  # reuse
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_11, split_3, key_17, key_18, transpose_31, key_19, mul_76, sum_14], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf162, buf163, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg97_1, arg100_1, arg101_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf166 = buf87; del buf87  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_29, float_28, pow_14, mean_13, add_48, rsqrt_19, output_45, float_29, add_49, output_46, hidden_states_30, float_30, exp_6, neg_5, a_3, float_31, add_50, softplus_3, g_3, transpose_34, getitem_66, exp_7], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf164, arg97_1, arg100_1, arg101_1, buf166, 2, 1, 1, stream=raw_stream0)
        del arg100_1
        del arg101_1
        del arg97_1
        assert_size_stride(arg102_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf167 = buf93; del buf93  # reuse
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_11, split_3, key_17, key_18, transpose_31, key_19, add_52, inv_norm_7, key_20, k_t_3, float_30, exp_6, neg_5, a_3, float_31, add_50, softplus_3, g_3, transpose_34, getitem_66, exp_7, decay_t_3, last_recurrent_state_10, unsqueeze_22, mul_79, kv_mem_3], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg102_1, buf166, buf162, buf163, buf167, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg96_1, (32, 2560), (2560, 1), 'input')
        buf169 = reinterpret_tensor(buf84, (1, 32, 1), (32, 1, 32), 0); del buf84  # reuse
        # Topologically Sorted Source Nodes: [b_3, beta_6, transpose_33, beta_7], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf164, arg96_1, buf169, 2, 1, 1, stream=raw_stream0)
        del arg96_1
        buf170 = buf91; del buf91  # reuse
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_11, split_3, key_17, key_18, transpose_31, key_19, add_52, inv_norm_7, key_20, k_t_3, unsqueeze_23, value_11, transpose_32, value_12, v_t_3, float_30, exp_6, neg_5, a_3, float_31, add_50, softplus_3, g_3, transpose_34, getitem_66, exp_7, decay_t_3, last_recurrent_state_10, sub_3, b_3, beta_6, transpose_33, beta_7, getitem_68, beta_t_3, delta_3, unsqueeze_24, mul_81, last_recurrent_state_11], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg102_1, buf166, buf162, buf163, buf167, buf169, buf170, arg102_1, 524288, stream=raw_stream0)
        del arg102_1
        buf171 = reinterpret_tensor(buf169, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf169  # reuse
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_11, split_3, query_19, query_20, transpose_30, query_21, mul_74, sum_13], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf162, buf171, 32, 128, stream=raw_stream0)
        buf172 = buf167; del buf167  # reuse
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_11, split_3, query_19, query_20, transpose_30, query_21, add_51, inv_norm_6, query_22, query_23, q_t_3, unsqueeze_25, mul_82, sum_16], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf170, buf162, buf171, buf172, 4096, 128, stream=raw_stream0)
        buf173 = reinterpret_tensor(buf171, (32, 1), (1, 32), 0); del buf171  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_15, core_attn_out_16, core_attn_out_17, hidden_states_31, pow_15, variance_3], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf172, buf173, 32, 128, stream=raw_stream0)
        buf174 = buf164; del buf164  # reuse
        assert_size_stride(arg103_1, (128, ), (1, ), 'input')
        buf175 = buf76; del buf76  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_15, core_attn_out_16, core_attn_out_17, hidden_states_31, pow_15, variance_3, add_54, rsqrt_22, hidden_states_32, to_53, hidden_states_33, to_54, silu_11, hidden_states_34, core_attn_out_18, core_attn_out_19, output_49], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg103_1, buf172, buf173, buf155, buf175, 4096, stream=raw_stream0)
        del arg103_1
        assert_size_stride_grouped((arg104_1, arg105_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_15, core_attn_out_16, core_attn_out_17, hidden_states_31, pow_15, variance_3, add_54, rsqrt_22, hidden_states_32, to_53, hidden_states_33, to_54, silu_11, hidden_states_34, core_attn_out_18, core_attn_out_19, output_49], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf175, arg104_1, buf174, arg105_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg104_1
        del arg105_1
        assert_size_stride(arg106_1, (2560, ), (1, ), 'input')
        buf178 = buf156; del buf156  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_29, hidden_states_35, float_32, pow_16, mean_15, add_56, rsqrt_23, output_50, float_33, add_57, output_51, hidden_states_36], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf140, buf148, buf174, arg106_1, buf178, 1, 2560, stream=raw_stream0)
        del arg106_1
        buf179 = buf149; del buf149  # reuse
        assert_size_stride_grouped((arg107_1, arg108_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_52], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf178, arg107_1, buf179, arg108_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg107_1
        del arg108_1
        buf181 = buf145; del buf145  # reuse
        assert_size_stride_grouped((arg109_1, arg110_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_53], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf178, arg109_1, buf181, arg110_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg109_1
        del arg110_1
        buf183 = buf178; del buf178  # reuse
        buf184 = buf142; del buf142  # reuse
        # Topologically Sorted Source Nodes: [silu_12, mul_88, output_54], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf179, buf181, buf184, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg111_1, arg112_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_12, mul_88, output_54], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf184, arg111_1, buf183, arg112_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg111_1
        del arg112_1
        assert_size_stride(arg113_1, (2560, ), (1, ), 'input')
        buf187 = buf153; del buf153  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_29, hidden_states_35, hidden_states_37, float_34, pow_17, mean_16, add_59, rsqrt_24, output_55, float_35, add_60, output_56, hidden_states_38], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf140, buf148, buf174, buf183, arg113_1, buf187, 1, 2560, stream=raw_stream0)
        del arg113_1
        buf188 = reinterpret_tensor(buf162, (1, 1, 8192), (8192, 8192, 1), 0); del buf162  # reuse
        assert_size_stride_grouped((arg114_1, arg115_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_57], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf187, arg114_1, buf188, arg115_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg114_1
        del arg115_1
        buf190 = buf175; del buf175  # reuse
        assert_size_stride_grouped((arg116_1, arg117_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_58], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf187, arg116_1, buf190, arg117_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg116_1
        del arg117_1
        assert_size_stride(arg121_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf194 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf192 = reinterpret_tensor(buf194, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_10], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg121_1, buf192, 32768, stream=raw_stream0)
        buf193 = reinterpret_tensor(buf194, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_10], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf188, buf193, 8192, stream=raw_stream0)
        assert_size_stride(arg120_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf196 = reinterpret_tensor(buf188, (1, 8192, 1), (8192, 1, 8192), 0); del buf188  # reuse
        # Topologically Sorted Source Nodes: [out_12, squeeze_4, unsqueeze_26, out_13, out_14], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf194, arg120_1, buf196, 8192, stream=raw_stream0)
        del arg120_1
        del buf192
        del buf193
        buf197 = reinterpret_tensor(buf173, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf173  # reuse
        # Topologically Sorted Source Nodes: [out_14, mixed_qkv_14, split_4, key_22, key_23, transpose_39, key_24, mul_94, sum_18], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf196, buf197, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg119_1, arg122_1, arg123_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf199 = buf166; del buf166  # reuse
        # Topologically Sorted Source Nodes: [float_36, exp_8, neg_6, a_4, float_37, add_61, softplus_4, g_4, transpose_42, getitem_77, exp_9], Original ATen: [aten._to_copy, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_17.run(buf187, arg119_1, arg122_1, arg123_1, buf199, 2, 1, 1, stream=raw_stream0)
        del arg119_1
        del arg122_1
        del arg123_1
        assert_size_stride(arg124_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf200 = buf172; del buf172  # reuse
        # Topologically Sorted Source Nodes: [out_14, mixed_qkv_14, split_4, key_22, key_23, transpose_39, key_24, add_63, inv_norm_9, key_25, k_t_4, float_36, exp_8, neg_6, a_4, float_37, add_61, softplus_4, g_4, transpose_42, getitem_77, exp_9, decay_t_4, last_recurrent_state_13, unsqueeze_28, mul_97, kv_mem_4], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg124_1, buf199, buf196, buf197, buf200, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg118_1, (32, 2560), (2560, 1), 'input')
        buf202 = reinterpret_tensor(buf163, (1, 32, 1), (32, 1, 32), 0); del buf163  # reuse
        # Topologically Sorted Source Nodes: [b_4, beta_8, transpose_41, beta_9], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf187, arg118_1, buf202, 2, 1, 1, stream=raw_stream0)
        del arg118_1
        buf203 = buf170; del buf170  # reuse
        # Topologically Sorted Source Nodes: [out_14, mixed_qkv_14, split_4, key_22, key_23, transpose_39, key_24, add_63, inv_norm_9, key_25, k_t_4, unsqueeze_29, value_14, transpose_40, value_15, v_t_4, float_36, exp_8, neg_6, a_4, float_37, add_61, softplus_4, g_4, transpose_42, getitem_77, exp_9, decay_t_4, last_recurrent_state_13, sub_4, b_4, beta_8, transpose_41, beta_9, getitem_79, beta_t_4, delta_4, unsqueeze_30, mul_99, last_recurrent_state_14], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg124_1, buf199, buf196, buf197, buf200, buf202, buf203, arg124_1, 524288, stream=raw_stream0)
        del arg124_1
        buf204 = reinterpret_tensor(buf202, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf202  # reuse
        # Topologically Sorted Source Nodes: [out_14, mixed_qkv_14, split_4, query_25, query_26, transpose_38, query_27, mul_92, sum_17], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf196, buf204, 32, 128, stream=raw_stream0)
        buf205 = buf200; del buf200  # reuse
        # Topologically Sorted Source Nodes: [out_14, mixed_qkv_14, split_4, query_25, query_26, transpose_38, query_27, add_62, inv_norm_8, query_28, query_29, q_t_4, unsqueeze_31, mul_100, sum_20], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf203, buf196, buf204, buf205, 4096, 128, stream=raw_stream0)
        buf206 = reinterpret_tensor(buf204, (32, 1), (1, 32), 0); del buf204  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_20, core_attn_out_21, core_attn_out_22, hidden_states_39, pow_18, variance_4], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf205, buf206, 32, 128, stream=raw_stream0)
        buf207 = buf187; del buf187  # reuse
        assert_size_stride(arg125_1, (128, ), (1, ), 'input')
        buf208 = buf155; del buf155  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_20, core_attn_out_21, core_attn_out_22, hidden_states_39, pow_18, variance_4, add_65, rsqrt_27, hidden_states_40, to_66, hidden_states_41, to_67, silu_14, hidden_states_42, core_attn_out_23, core_attn_out_24, output_59], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg125_1, buf205, buf206, buf190, buf208, 4096, stream=raw_stream0)
        del arg125_1
        assert_size_stride_grouped((arg126_1, arg127_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_20, core_attn_out_21, core_attn_out_22, hidden_states_39, pow_18, variance_4, add_65, rsqrt_27, hidden_states_40, to_66, hidden_states_41, to_67, silu_14, hidden_states_42, core_attn_out_23, core_attn_out_24, output_59], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf208, arg126_1, buf207, arg127_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg126_1
        del arg127_1
        assert_size_stride(arg128_1, (2560, ), (1, ), 'input')
        buf210 = buf140; del buf140  # reuse
        buf213 = buf137; del buf137  # reuse
        buf216 = buf104; del buf104  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_29, hidden_states_35, hidden_states_37, hidden_states_43, float_38, pow_19, mean_18, add_67, rsqrt_28, output_60, float_39, add_68, output_61, hidden_states_44, output_62, output_63], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf210, buf148, buf174, buf183, buf207, arg128_1, buf213, buf216, 1, 2560, stream=raw_stream0)
        del arg128_1
        buf212 = buf184; del buf184  # reuse
        assert_size_stride_grouped((arg129_1, arg130_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_38, pow_19, mean_18, add_67, rsqrt_28, output_60, float_39, add_68, output_61, hidden_states_44, output_62], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf213, arg129_1, buf212, arg130_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg129_1
        del arg130_1
        buf215 = buf181; del buf181  # reuse
        assert_size_stride_grouped((arg131_1, arg132_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_38, pow_19, mean_18, add_67, rsqrt_28, output_60, float_39, add_68, output_61, hidden_states_44, output_63], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf216, arg131_1, buf215, arg132_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg131_1
        del arg132_1
        buf218 = buf216; del buf216  # reuse
        buf219 = buf179; del buf179  # reuse
        # Topologically Sorted Source Nodes: [silu_15, mul_106, output_64], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf212, buf215, buf219, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg133_1, arg134_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_15, mul_106, output_64], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf219, arg133_1, buf218, arg134_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg133_1
        del arg134_1
        assert_size_stride(arg135_1, (2560, ), (1, ), 'input')
        buf223 = buf213; del buf213  # reuse
        buf226 = buf207; del buf207  # reuse
        buf234 = buf183; del buf183  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_45, float_40, pow_20, mean_19, add_70, rsqrt_29, output_65, float_41, add_71, output_66, hidden_states_46, output_67, output_68], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf210, buf218, arg135_1, buf223, buf226, buf234, 1, 2560, stream=raw_stream0)
        del arg135_1
        buf222 = reinterpret_tensor(buf196, (1, 1, 8192), (8192, 8192, 1), 0); del buf196  # reuse
        assert_size_stride_grouped((arg136_1, arg137_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_45, float_40, pow_20, mean_19, add_70, rsqrt_29, output_65, float_41, add_71, output_66, hidden_states_46, output_67], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf223, arg136_1, buf222, arg137_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg136_1
        del arg137_1
        buf225 = buf208; del buf208  # reuse
        assert_size_stride_grouped((arg138_1, arg139_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_45, float_40, pow_20, mean_19, add_70, rsqrt_29, output_65, float_41, add_71, output_66, hidden_states_46, output_68], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf226, arg138_1, buf225, arg139_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg138_1
        del arg139_1
        assert_size_stride(arg143_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf230 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf228 = reinterpret_tensor(buf230, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_11], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg143_1, buf228, 32768, stream=raw_stream0)
        buf229 = reinterpret_tensor(buf230, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_11], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf222, buf229, 8192, stream=raw_stream0)
        assert_size_stride(arg142_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf232 = reinterpret_tensor(buf222, (1, 8192, 1), (8192, 1, 8192), 0); del buf222  # reuse
        # Topologically Sorted Source Nodes: [out_15, squeeze_5, unsqueeze_32, out_16, out_17], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf230, arg142_1, buf232, 8192, stream=raw_stream0)
        del arg142_1
        del buf228
        del buf229
        buf233 = reinterpret_tensor(buf206, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf206  # reuse
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_17, split_5, key_27, key_28, transpose_47, key_29, mul_112, sum_22], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf232, buf233, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg141_1, arg144_1, arg145_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf236 = buf199; del buf199  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_45, float_40, pow_20, mean_19, add_70, rsqrt_29, output_65, float_41, add_71, output_66, hidden_states_46, float_42, exp_10, neg_7, a_5, float_43, add_72, softplus_5, g_5, transpose_50, getitem_88, exp_11], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf234, arg141_1, arg144_1, arg145_1, buf236, 2, 1, 1, stream=raw_stream0)
        del arg141_1
        del arg144_1
        del arg145_1
        assert_size_stride(arg146_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf237 = buf205; del buf205  # reuse
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_17, split_5, key_27, key_28, transpose_47, key_29, add_74, inv_norm_11, key_30, k_t_5, float_42, exp_10, neg_7, a_5, float_43, add_72, softplus_5, g_5, transpose_50, getitem_88, exp_11, decay_t_5, last_recurrent_state_16, unsqueeze_34, mul_115, kv_mem_5], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg146_1, buf236, buf232, buf233, buf237, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg140_1, (32, 2560), (2560, 1), 'input')
        buf239 = reinterpret_tensor(buf197, (1, 32, 1), (32, 1, 32), 0); del buf197  # reuse
        # Topologically Sorted Source Nodes: [b_5, beta_10, transpose_49, beta_11], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf234, arg140_1, buf239, 2, 1, 1, stream=raw_stream0)
        del arg140_1
        buf240 = buf203; del buf203  # reuse
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_17, split_5, key_27, key_28, transpose_47, key_29, add_74, inv_norm_11, key_30, k_t_5, unsqueeze_35, value_17, transpose_48, value_18, v_t_5, float_42, exp_10, neg_7, a_5, float_43, add_72, softplus_5, g_5, transpose_50, getitem_88, exp_11, decay_t_5, last_recurrent_state_16, sub_5, b_5, beta_10, transpose_49, beta_11, getitem_90, beta_t_5, delta_5, unsqueeze_36, mul_117, last_recurrent_state_17], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg146_1, buf236, buf232, buf233, buf237, buf239, buf240, arg146_1, 524288, stream=raw_stream0)
        del arg146_1
        buf241 = reinterpret_tensor(buf239, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf239  # reuse
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_17, split_5, query_31, query_32, transpose_46, query_33, mul_110, sum_21], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf232, buf241, 32, 128, stream=raw_stream0)
        buf242 = buf237; del buf237  # reuse
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_17, split_5, query_31, query_32, transpose_46, query_33, add_73, inv_norm_10, query_34, query_35, q_t_5, unsqueeze_37, mul_118, sum_24], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf240, buf232, buf241, buf242, 4096, 128, stream=raw_stream0)
        buf243 = reinterpret_tensor(buf241, (32, 1), (1, 32), 0); del buf241  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_25, core_attn_out_26, core_attn_out_27, hidden_states_47, pow_21, variance_5], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf242, buf243, 32, 128, stream=raw_stream0)
        buf244 = buf234; del buf234  # reuse
        assert_size_stride(arg147_1, (128, ), (1, ), 'input')
        buf245 = buf190; del buf190  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_25, core_attn_out_26, core_attn_out_27, hidden_states_47, pow_21, variance_5, add_76, rsqrt_32, hidden_states_48, to_79, hidden_states_49, to_80, silu_17, hidden_states_50, core_attn_out_28, core_attn_out_29, output_69], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg147_1, buf242, buf243, buf225, buf245, 4096, stream=raw_stream0)
        del arg147_1
        assert_size_stride_grouped((arg148_1, arg149_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_25, core_attn_out_26, core_attn_out_27, hidden_states_47, pow_21, variance_5, add_76, rsqrt_32, hidden_states_48, to_79, hidden_states_49, to_80, silu_17, hidden_states_50, core_attn_out_28, core_attn_out_29, output_69], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf245, arg148_1, buf244, arg149_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg148_1
        del arg149_1
        assert_size_stride(arg150_1, (2560, ), (1, ), 'input')
        buf248 = buf226; del buf226  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_45, hidden_states_51, float_44, pow_22, mean_21, add_78, rsqrt_33, output_70, float_45, add_79, output_71, hidden_states_52], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf210, buf218, buf244, arg150_1, buf248, 1, 2560, stream=raw_stream0)
        del arg150_1
        buf249 = buf219; del buf219  # reuse
        assert_size_stride_grouped((arg151_1, arg152_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_72], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf248, arg151_1, buf249, arg152_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg151_1
        del arg152_1
        buf251 = buf215; del buf215  # reuse
        assert_size_stride_grouped((arg153_1, arg154_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_73], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf248, arg153_1, buf251, arg154_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg153_1
        del arg154_1
        buf253 = buf248; del buf248  # reuse
        buf254 = buf212; del buf212  # reuse
        # Topologically Sorted Source Nodes: [silu_18, mul_124, output_74], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf249, buf251, buf254, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg155_1, arg156_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_18, mul_124, output_74], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf254, arg155_1, buf253, arg156_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg155_1
        del arg156_1
        assert_size_stride(arg157_1, (2560, ), (1, ), 'input')
        buf257 = buf223; del buf223  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_45, hidden_states_51, hidden_states_53, float_46, pow_23, mean_22, add_81, rsqrt_34, output_75, float_47, add_82, output_76, hidden_states_54], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf210, buf218, buf244, buf253, arg157_1, buf257, 1, 2560, stream=raw_stream0)
        del arg157_1
        buf258 = reinterpret_tensor(buf232, (1, 1, 8192), (8192, 8192, 1), 0); del buf232  # reuse
        assert_size_stride_grouped((arg158_1, arg159_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_77], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf257, arg158_1, buf258, arg159_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg158_1
        del arg159_1
        buf260 = buf113; del buf113  # reuse
        assert_size_stride_grouped((arg161_1, arg162_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_80], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf257, arg161_1, buf260, arg162_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg161_1
        del arg162_1
        buf262 = reinterpret_tensor(buf128, (1, 1, 1024), (1024, 1024, 1), 0); del buf128  # reuse
        assert_size_stride_grouped((arg164_1, arg165_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_83], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf257, arg164_1, buf262, arg165_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg164_1
        del arg165_1
        buf264 = reinterpret_tensor(buf134, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf134  # reuse
        # Topologically Sorted Source Nodes: [float_48, pow_24, mean_23], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_split_view_22.run(buf258, buf264, 16, 256, stream=raw_stream0)
        assert_size_stride(arg160_1, (256, ), (1, ), 'input')
        buf267 = reinterpret_tensor(buf111, (1, 16, 1, 64), (1024, 64, 64, 1), 0); del buf111  # reuse
        buf265 = reinterpret_tensor(buf267, (1, 16, 1, 32), (1024, 64, 64, 1), 0)  # alias
        buf266 = reinterpret_tensor(buf267, (1, 16, 1, 32), (1024, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_48, pow_24, mean_23, add_83, rsqrt_35, output_78, float_49, add_84, output_79, type_as_17, query_states_3, q_rot_1, x2_2, neg_8, x1_2, cat_12], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_23.run(buf258, buf264, arg160_1, buf265, buf266, 512, stream=raw_stream0)
        buf270 = reinterpret_tensor(buf245, (1, 16, 1, 256), (4096, 256, 256, 1), 0); del buf245  # reuse
        buf268 = reinterpret_tensor(buf270, (1, 16, 1, 64), (4096, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_48, pow_24, mean_23, add_83, rsqrt_35, output_78, float_49, add_84, output_79, type_as_17, query_states_3, q_rot_1, cos_5, mul_131, sin_5, mul_132, q_embed_2], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_24.run(buf258, buf264, arg160_1, buf1, buf267, buf0, buf268, 1024, stream=raw_stream0)
        del buf265
        del buf266
        buf269 = reinterpret_tensor(buf270, (1, 16, 1, 192), (4096, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_48, pow_24, mean_23, add_83, rsqrt_35, output_78, float_49, add_84, output_79, type_as_17, query_states_3, q_rot_1, cos_5, mul_131, sin_5, mul_132, q_embed_2, q_pass_1, q_embed_3], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_25.run(buf258, buf264, arg160_1, buf269, 3072, stream=raw_stream0)
        del arg160_1
        buf271 = buf122; del buf122  # reuse
        # Topologically Sorted Source Nodes: [float_50, pow_25, mean_24], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_26.run(buf260, buf271, 4, 256, stream=raw_stream0)
        del buf268
        del buf269
        assert_size_stride(arg163_1, (256, ), (1, ), 'input')
        buf274 = buf125; del buf125  # reuse
        buf272 = reinterpret_tensor(buf274, (1, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        buf273 = reinterpret_tensor(buf274, (1, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_50, pow_25, mean_24, add_85, rsqrt_36, output_81, float_51, add_86, output_82, type_as_18, key_states_1, k_rot_1, x2_3, neg_9, x1_3, cat_13], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_27.run(buf260, buf271, arg163_1, buf272, buf273, 128, stream=raw_stream0)
        buf277 = reinterpret_tensor(buf267, (1, 4, 1, 256), (1024, 256, 256, 1), 0); del buf267  # reuse
        buf275 = reinterpret_tensor(buf277, (1, 4, 1, 64), (1024, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_5, sin_5, float_50, pow_25, mean_24, add_85, rsqrt_36, output_81, float_51, add_86, output_82, type_as_18, key_states_1, k_rot_1, mul_133, mul_134, k_embed_2], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28.run(buf260, buf271, arg163_1, buf1, buf274, buf0, buf275, 256, stream=raw_stream0)
        del buf272
        del buf273
        buf276 = reinterpret_tensor(buf277, (1, 4, 1, 192), (1024, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_5, sin_5, float_50, pow_25, mean_24, add_85, rsqrt_36, output_81, float_51, add_86, output_82, type_as_18, key_states_1, k_rot_1, mul_133, mul_134, k_embed_2, k_pass_1, k_embed_3], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_29.run(buf260, buf271, arg163_1, buf276, 768, stream=raw_stream0)
        del arg163_1
        assert_size_stride_grouped((arg166_1, arg167_1), ((), (1, 4, 64, 256)), ((), (65536, 16384, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_5, cache_position_1, index_copy__2], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_30.run(arg166_1, buf277, arg167_1, 1024, stream=raw_stream0)
        del buf275
        del buf276
        buf279 = reinterpret_tensor(buf133, (16, 1, 64), (64, 64, 1), 0); del buf133  # reuse
        # Topologically Sorted Source Nodes: [attn_output_4, key_31], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_31.run(buf270, arg167_1, buf279, 1024, 256, stream=raw_stream0)
        del arg167_1
        buf280 = buf131; del buf131  # reuse
        buf282 = reinterpret_tensor(buf130, (1, 16, 1, 64), (1024, 64, 1024, 1), 0); del buf130  # reuse
        buf283 = reinterpret_tensor(buf264, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf264  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_4], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32.run(buf279, arg3_1, buf280, buf282, buf283, 16, 64, stream=raw_stream0)
        assert_size_stride(arg168_1, (1, 4, 64, 256), (65536, 16384, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_5, cache_position_1, index_copy__3], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_33.run(arg166_1, buf262, arg168_1, 1024, stream=raw_stream0)
        buf287 = reinterpret_tensor(buf270, (1, 1, 4096), (4096, 4096, 1), 0); del buf270  # reuse
        # Topologically Sorted Source Nodes: [gate_3, attn_output_4, value_19, transpose_55, reshape_49, sigmoid_7, attn_output_7, output_84], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34.run(buf280, buf282, buf283, arg168_1, buf258, buf287, 4096, 64, stream=raw_stream0)
        del arg168_1
        buf286 = buf257; del buf257  # reuse
        assert_size_stride_grouped((arg169_1, arg170_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [gate_3, attn_output_4, transpose_55, reshape_49, sigmoid_7, attn_output_7, output_84], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf287, arg169_1, buf286, arg170_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg169_1
        del arg170_1
        assert_size_stride(arg171_1, (2560, ), (1, ), 'input')
        buf289 = buf210; del buf210  # reuse
        buf292 = buf174; del buf174  # reuse
        buf295 = buf148; del buf148  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_45, hidden_states_51, hidden_states_53, hidden_states_57, float_52, pow_26, mean_25, add_91, rsqrt_37, output_85, float_53, add_92, output_86, hidden_states_58, output_87, output_88], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf289, buf218, buf244, buf253, buf286, arg171_1, buf292, buf295, 1, 2560, stream=raw_stream0)
        del arg171_1
        buf291 = buf254; del buf254  # reuse
        assert_size_stride_grouped((arg172_1, arg173_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_52, pow_26, mean_25, add_91, rsqrt_37, output_85, float_53, add_92, output_86, hidden_states_58, output_87], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf292, arg172_1, buf291, arg173_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg172_1
        del arg173_1
        buf294 = buf251; del buf251  # reuse
        assert_size_stride_grouped((arg174_1, arg175_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_52, pow_26, mean_25, add_91, rsqrt_37, output_85, float_53, add_92, output_86, hidden_states_58, output_88], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf295, arg174_1, buf294, arg175_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg174_1
        del arg175_1
        buf297 = buf295; del buf295  # reuse
        buf298 = buf249; del buf249  # reuse
        # Topologically Sorted Source Nodes: [silu_19, mul_138, output_89], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf291, buf294, buf298, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg176_1, arg177_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_19, mul_138, output_89], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf298, arg176_1, buf297, arg177_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg176_1
        del arg177_1
        assert_size_stride(arg178_1, (2560, ), (1, ), 'input')
        buf302 = buf292; del buf292  # reuse
        buf305 = buf286; del buf286  # reuse
        buf313 = buf253; del buf253  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_59, float_54, pow_27, mean_26, add_94, rsqrt_38, output_90, float_55, add_95, output_91, hidden_states_60, output_92, output_93], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf289, buf297, arg178_1, buf302, buf305, buf313, 1, 2560, stream=raw_stream0)
        del arg178_1
        buf301 = buf258; del buf258  # reuse
        assert_size_stride_grouped((arg179_1, arg180_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_59, float_54, pow_27, mean_26, add_94, rsqrt_38, output_90, float_55, add_95, output_91, hidden_states_60, output_92], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf302, arg179_1, buf301, arg180_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg179_1
        del arg180_1
        buf304 = buf287; del buf287  # reuse
        assert_size_stride_grouped((arg181_1, arg182_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_59, float_54, pow_27, mean_26, add_94, rsqrt_38, output_90, float_55, add_95, output_91, hidden_states_60, output_93], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf305, arg181_1, buf304, arg182_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg181_1
        del arg182_1
        assert_size_stride(arg186_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf309 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf307 = reinterpret_tensor(buf309, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_16], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg186_1, buf307, 32768, stream=raw_stream0)
        buf308 = reinterpret_tensor(buf309, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_16], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf301, buf308, 8192, stream=raw_stream0)
        assert_size_stride(arg185_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf311 = reinterpret_tensor(buf301, (1, 8192, 1), (8192, 1, 8192), 0); del buf301  # reuse
        # Topologically Sorted Source Nodes: [out_18, squeeze_6, unsqueeze_40, out_19, out_20], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf309, arg185_1, buf311, 8192, stream=raw_stream0)
        del arg185_1
        del buf307
        del buf308
        buf312 = reinterpret_tensor(buf243, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf243  # reuse
        # Topologically Sorted Source Nodes: [out_20, mixed_qkv_20, split_6, key_33, key_34, transpose_59, key_35, mul_144, sum_26], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf311, buf312, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg184_1, arg187_1, arg188_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf315 = buf236; del buf236  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_59, float_54, pow_27, mean_26, add_94, rsqrt_38, output_90, float_55, add_95, output_91, hidden_states_60, float_56, exp_12, neg_10, a_6, float_57, add_96, softplus_6, g_6, transpose_62, getitem_111, exp_13], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf313, arg184_1, arg187_1, arg188_1, buf315, 2, 1, 1, stream=raw_stream0)
        del arg184_1
        del arg187_1
        del arg188_1
        assert_size_stride(arg189_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf316 = buf242; del buf242  # reuse
        # Topologically Sorted Source Nodes: [out_20, mixed_qkv_20, split_6, key_33, key_34, transpose_59, key_35, add_98, inv_norm_13, key_36, k_t_6, float_56, exp_12, neg_10, a_6, float_57, add_96, softplus_6, g_6, transpose_62, getitem_111, exp_13, decay_t_6, last_recurrent_state_19, unsqueeze_42, mul_147, kv_mem_6], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg189_1, buf315, buf311, buf312, buf316, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg183_1, (32, 2560), (2560, 1), 'input')
        buf318 = reinterpret_tensor(buf233, (1, 32, 1), (32, 1, 32), 0); del buf233  # reuse
        # Topologically Sorted Source Nodes: [b_6, beta_12, transpose_61, beta_13], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf313, arg183_1, buf318, 2, 1, 1, stream=raw_stream0)
        del arg183_1
        buf319 = buf240; del buf240  # reuse
        # Topologically Sorted Source Nodes: [out_20, mixed_qkv_20, split_6, key_33, key_34, transpose_59, key_35, add_98, inv_norm_13, key_36, k_t_6, unsqueeze_43, value_21, transpose_60, value_22, v_t_6, float_56, exp_12, neg_10, a_6, float_57, add_96, softplus_6, g_6, transpose_62, getitem_111, exp_13, decay_t_6, last_recurrent_state_19, sub_6, b_6, beta_12, transpose_61, beta_13, getitem_113, beta_t_6, delta_6, unsqueeze_44, mul_149, last_recurrent_state_20], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg189_1, buf315, buf311, buf312, buf316, buf318, buf319, arg189_1, 524288, stream=raw_stream0)
        del arg189_1
        buf320 = reinterpret_tensor(buf318, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf318  # reuse
        # Topologically Sorted Source Nodes: [out_20, mixed_qkv_20, split_6, query_37, query_38, transpose_58, query_39, mul_142, sum_25], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf311, buf320, 32, 128, stream=raw_stream0)
        buf321 = buf316; del buf316  # reuse
        # Topologically Sorted Source Nodes: [out_20, mixed_qkv_20, split_6, query_37, query_38, transpose_58, query_39, add_97, inv_norm_12, query_40, query_41, q_t_6, unsqueeze_45, mul_150, sum_28], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf319, buf311, buf320, buf321, 4096, 128, stream=raw_stream0)
        buf322 = reinterpret_tensor(buf320, (32, 1), (1, 32), 0); del buf320  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_30, core_attn_out_31, core_attn_out_32, hidden_states_61, pow_28, variance_6], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf321, buf322, 32, 128, stream=raw_stream0)
        buf323 = buf313; del buf313  # reuse
        assert_size_stride(arg190_1, (128, ), (1, ), 'input')
        buf324 = buf225; del buf225  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_30, core_attn_out_31, core_attn_out_32, hidden_states_61, pow_28, variance_6, add_100, rsqrt_41, hidden_states_62, to_92, hidden_states_63, to_93, silu_21, hidden_states_64, core_attn_out_33, core_attn_out_34, output_94], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg190_1, buf321, buf322, buf304, buf324, 4096, stream=raw_stream0)
        del arg190_1
        assert_size_stride_grouped((arg191_1, arg192_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_30, core_attn_out_31, core_attn_out_32, hidden_states_61, pow_28, variance_6, add_100, rsqrt_41, hidden_states_62, to_92, hidden_states_63, to_93, silu_21, hidden_states_64, core_attn_out_33, core_attn_out_34, output_94], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf324, arg191_1, buf323, arg192_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg191_1
        del arg192_1
        assert_size_stride(arg193_1, (2560, ), (1, ), 'input')
        buf327 = buf305; del buf305  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_59, hidden_states_65, float_58, pow_29, mean_28, add_102, rsqrt_42, output_95, float_59, add_103, output_96, hidden_states_66], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf289, buf297, buf323, arg193_1, buf327, 1, 2560, stream=raw_stream0)
        del arg193_1
        buf328 = buf298; del buf298  # reuse
        assert_size_stride_grouped((arg194_1, arg195_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_97], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf327, arg194_1, buf328, arg195_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg194_1
        del arg195_1
        buf330 = buf294; del buf294  # reuse
        assert_size_stride_grouped((arg196_1, arg197_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_98], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf327, arg196_1, buf330, arg197_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg196_1
        del arg197_1
        buf332 = buf327; del buf327  # reuse
        buf333 = buf291; del buf291  # reuse
        # Topologically Sorted Source Nodes: [silu_22, mul_156, output_99], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf328, buf330, buf333, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg198_1, arg199_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_22, mul_156, output_99], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf333, arg198_1, buf332, arg199_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg198_1
        del arg199_1
        assert_size_stride(arg200_1, (2560, ), (1, ), 'input')
        buf336 = buf302; del buf302  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_59, hidden_states_65, hidden_states_67, float_60, pow_30, mean_29, add_105, rsqrt_43, output_100, float_61, add_106, output_101, hidden_states_68], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf289, buf297, buf323, buf332, arg200_1, buf336, 1, 2560, stream=raw_stream0)
        del arg200_1
        buf337 = reinterpret_tensor(buf311, (1, 1, 8192), (8192, 8192, 1), 0); del buf311  # reuse
        assert_size_stride_grouped((arg201_1, arg202_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_102], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf336, arg201_1, buf337, arg202_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg201_1
        del arg202_1
        buf339 = buf324; del buf324  # reuse
        assert_size_stride_grouped((arg203_1, arg204_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_103], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf336, arg203_1, buf339, arg204_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg203_1
        del arg204_1
        assert_size_stride(arg208_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf343 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf341 = reinterpret_tensor(buf343, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_17], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg208_1, buf341, 32768, stream=raw_stream0)
        buf342 = reinterpret_tensor(buf343, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_17], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf337, buf342, 8192, stream=raw_stream0)
        assert_size_stride(arg207_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf345 = reinterpret_tensor(buf337, (1, 8192, 1), (8192, 1, 8192), 0); del buf337  # reuse
        # Topologically Sorted Source Nodes: [out_21, squeeze_7, unsqueeze_46, out_22, out_23], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf343, arg207_1, buf345, 8192, stream=raw_stream0)
        del arg207_1
        del buf341
        del buf342
        buf346 = reinterpret_tensor(buf322, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf322  # reuse
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_23, split_7, key_38, key_39, transpose_67, key_40, mul_162, sum_30], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf345, buf346, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg206_1, arg209_1, arg210_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf348 = buf315; del buf315  # reuse
        # Topologically Sorted Source Nodes: [float_62, exp_14, neg_11, a_7, float_63, add_107, softplus_7, g_7, transpose_70, getitem_122, exp_15], Original ATen: [aten._to_copy, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_17.run(buf336, arg206_1, arg209_1, arg210_1, buf348, 2, 1, 1, stream=raw_stream0)
        del arg206_1
        del arg209_1
        del arg210_1
        assert_size_stride(arg211_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf349 = buf321; del buf321  # reuse
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_23, split_7, key_38, key_39, transpose_67, key_40, add_109, inv_norm_15, key_41, k_t_7, float_62, exp_14, neg_11, a_7, float_63, add_107, softplus_7, g_7, transpose_70, getitem_122, exp_15, decay_t_7, last_recurrent_state_22, unsqueeze_48, mul_165, kv_mem_7], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg211_1, buf348, buf345, buf346, buf349, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg205_1, (32, 2560), (2560, 1), 'input')
        buf351 = reinterpret_tensor(buf312, (1, 32, 1), (32, 1, 32), 0); del buf312  # reuse
        # Topologically Sorted Source Nodes: [b_7, beta_14, transpose_69, beta_15], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf336, arg205_1, buf351, 2, 1, 1, stream=raw_stream0)
        del arg205_1
        buf352 = buf319; del buf319  # reuse
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_23, split_7, key_38, key_39, transpose_67, key_40, add_109, inv_norm_15, key_41, k_t_7, unsqueeze_49, value_24, transpose_68, value_25, v_t_7, float_62, exp_14, neg_11, a_7, float_63, add_107, softplus_7, g_7, transpose_70, getitem_122, exp_15, decay_t_7, last_recurrent_state_22, sub_7, b_7, beta_14, transpose_69, beta_15, getitem_124, beta_t_7, delta_7, unsqueeze_50, mul_167, last_recurrent_state_23], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg211_1, buf348, buf345, buf346, buf349, buf351, buf352, arg211_1, 524288, stream=raw_stream0)
        del arg211_1
        buf353 = reinterpret_tensor(buf351, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf351  # reuse
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_23, split_7, query_43, query_44, transpose_66, query_45, mul_160, sum_29], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf345, buf353, 32, 128, stream=raw_stream0)
        buf354 = buf349; del buf349  # reuse
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_23, split_7, query_43, query_44, transpose_66, query_45, add_108, inv_norm_14, query_46, query_47, q_t_7, unsqueeze_51, mul_168, sum_32], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf352, buf345, buf353, buf354, 4096, 128, stream=raw_stream0)
        buf355 = reinterpret_tensor(buf353, (32, 1), (1, 32), 0); del buf353  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_35, core_attn_out_36, core_attn_out_37, hidden_states_69, pow_31, variance_7], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf354, buf355, 32, 128, stream=raw_stream0)
        buf356 = buf336; del buf336  # reuse
        assert_size_stride(arg212_1, (128, ), (1, ), 'input')
        buf357 = buf304; del buf304  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_35, core_attn_out_36, core_attn_out_37, hidden_states_69, pow_31, variance_7, add_111, rsqrt_46, hidden_states_70, to_105, hidden_states_71, to_106, silu_24, hidden_states_72, core_attn_out_38, core_attn_out_39, output_104], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg212_1, buf354, buf355, buf339, buf357, 4096, stream=raw_stream0)
        del arg212_1
        assert_size_stride_grouped((arg213_1, arg214_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_35, core_attn_out_36, core_attn_out_37, hidden_states_69, pow_31, variance_7, add_111, rsqrt_46, hidden_states_70, to_105, hidden_states_71, to_106, silu_24, hidden_states_72, core_attn_out_38, core_attn_out_39, output_104], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf357, arg213_1, buf356, arg214_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg213_1
        del arg214_1
        assert_size_stride(arg215_1, (2560, ), (1, ), 'input')
        buf359 = buf289; del buf289  # reuse
        buf362 = buf244; del buf244  # reuse
        buf365 = buf218; del buf218  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_59, hidden_states_65, hidden_states_67, hidden_states_73, float_64, pow_32, mean_31, add_113, rsqrt_47, output_105, float_65, add_114, output_106, hidden_states_74, output_107, output_108], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf359, buf297, buf323, buf332, buf356, arg215_1, buf362, buf365, 1, 2560, stream=raw_stream0)
        del arg215_1
        buf361 = buf333; del buf333  # reuse
        assert_size_stride_grouped((arg216_1, arg217_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_64, pow_32, mean_31, add_113, rsqrt_47, output_105, float_65, add_114, output_106, hidden_states_74, output_107], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf362, arg216_1, buf361, arg217_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg216_1
        del arg217_1
        buf364 = buf330; del buf330  # reuse
        assert_size_stride_grouped((arg218_1, arg219_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_64, pow_32, mean_31, add_113, rsqrt_47, output_105, float_65, add_114, output_106, hidden_states_74, output_108], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf365, arg218_1, buf364, arg219_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg218_1
        del arg219_1
        buf367 = buf365; del buf365  # reuse
        buf368 = buf328; del buf328  # reuse
        # Topologically Sorted Source Nodes: [silu_25, mul_174, output_109], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf361, buf364, buf368, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg220_1, arg221_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_25, mul_174, output_109], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf368, arg220_1, buf367, arg221_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg220_1
        del arg221_1
        assert_size_stride(arg222_1, (2560, ), (1, ), 'input')
        buf372 = buf362; del buf362  # reuse
        buf375 = buf356; del buf356  # reuse
        buf383 = buf332; del buf332  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_75, float_66, pow_33, mean_32, add_116, rsqrt_48, output_110, float_67, add_117, output_111, hidden_states_76, output_112, output_113], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf359, buf367, arg222_1, buf372, buf375, buf383, 1, 2560, stream=raw_stream0)
        del arg222_1
        buf371 = reinterpret_tensor(buf345, (1, 1, 8192), (8192, 8192, 1), 0); del buf345  # reuse
        assert_size_stride_grouped((arg223_1, arg224_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_75, float_66, pow_33, mean_32, add_116, rsqrt_48, output_110, float_67, add_117, output_111, hidden_states_76, output_112], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf372, arg223_1, buf371, arg224_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg223_1
        del arg224_1
        buf374 = buf357; del buf357  # reuse
        assert_size_stride_grouped((arg225_1, arg226_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_75, float_66, pow_33, mean_32, add_116, rsqrt_48, output_110, float_67, add_117, output_111, hidden_states_76, output_113], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf375, arg225_1, buf374, arg226_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg225_1
        del arg226_1
        assert_size_stride(arg230_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf379 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf377 = reinterpret_tensor(buf379, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_18], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg230_1, buf377, 32768, stream=raw_stream0)
        buf378 = reinterpret_tensor(buf379, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_18], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf371, buf378, 8192, stream=raw_stream0)
        assert_size_stride(arg229_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf381 = reinterpret_tensor(buf371, (1, 8192, 1), (8192, 1, 8192), 0); del buf371  # reuse
        # Topologically Sorted Source Nodes: [out_24, squeeze_8, unsqueeze_52, out_25, out_26], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf379, arg229_1, buf381, 8192, stream=raw_stream0)
        del arg229_1
        del buf377
        del buf378
        buf382 = reinterpret_tensor(buf355, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf355  # reuse
        # Topologically Sorted Source Nodes: [out_26, mixed_qkv_26, split_8, key_43, key_44, transpose_75, key_45, mul_180, sum_34], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf381, buf382, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg228_1, arg231_1, arg232_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf385 = buf348; del buf348  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_75, float_66, pow_33, mean_32, add_116, rsqrt_48, output_110, float_67, add_117, output_111, hidden_states_76, float_68, exp_16, neg_12, a_8, float_69, add_118, softplus_8, g_8, transpose_78, getitem_133, exp_17], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf383, arg228_1, arg231_1, arg232_1, buf385, 2, 1, 1, stream=raw_stream0)
        del arg228_1
        del arg231_1
        del arg232_1
        assert_size_stride(arg233_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf386 = buf354; del buf354  # reuse
        # Topologically Sorted Source Nodes: [out_26, mixed_qkv_26, split_8, key_43, key_44, transpose_75, key_45, add_120, inv_norm_17, key_46, k_t_8, float_68, exp_16, neg_12, a_8, float_69, add_118, softplus_8, g_8, transpose_78, getitem_133, exp_17, decay_t_8, last_recurrent_state_25, unsqueeze_54, mul_183, kv_mem_8], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg233_1, buf385, buf381, buf382, buf386, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg227_1, (32, 2560), (2560, 1), 'input')
        buf388 = reinterpret_tensor(buf346, (1, 32, 1), (32, 1, 32), 0); del buf346  # reuse
        # Topologically Sorted Source Nodes: [b_8, beta_16, transpose_77, beta_17], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf383, arg227_1, buf388, 2, 1, 1, stream=raw_stream0)
        del arg227_1
        buf389 = buf352; del buf352  # reuse
        # Topologically Sorted Source Nodes: [out_26, mixed_qkv_26, split_8, key_43, key_44, transpose_75, key_45, add_120, inv_norm_17, key_46, k_t_8, unsqueeze_55, value_27, transpose_76, value_28, v_t_8, float_68, exp_16, neg_12, a_8, float_69, add_118, softplus_8, g_8, transpose_78, getitem_133, exp_17, decay_t_8, last_recurrent_state_25, sub_8, b_8, beta_16, transpose_77, beta_17, getitem_135, beta_t_8, delta_8, unsqueeze_56, mul_185, last_recurrent_state_26], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg233_1, buf385, buf381, buf382, buf386, buf388, buf389, arg233_1, 524288, stream=raw_stream0)
        del arg233_1
        buf390 = reinterpret_tensor(buf388, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf388  # reuse
        # Topologically Sorted Source Nodes: [out_26, mixed_qkv_26, split_8, query_49, query_50, transpose_74, query_51, mul_178, sum_33], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf381, buf390, 32, 128, stream=raw_stream0)
        buf391 = buf386; del buf386  # reuse
        # Topologically Sorted Source Nodes: [out_26, mixed_qkv_26, split_8, query_49, query_50, transpose_74, query_51, add_119, inv_norm_16, query_52, query_53, q_t_8, unsqueeze_57, mul_186, sum_36], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf389, buf381, buf390, buf391, 4096, 128, stream=raw_stream0)
        buf392 = reinterpret_tensor(buf390, (32, 1), (1, 32), 0); del buf390  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_40, core_attn_out_41, core_attn_out_42, hidden_states_77, pow_34, variance_8], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf391, buf392, 32, 128, stream=raw_stream0)
        buf393 = buf383; del buf383  # reuse
        assert_size_stride(arg234_1, (128, ), (1, ), 'input')
        buf394 = buf339; del buf339  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_40, core_attn_out_41, core_attn_out_42, hidden_states_77, pow_34, variance_8, add_122, rsqrt_51, hidden_states_78, to_118, hidden_states_79, to_119, silu_27, hidden_states_80, core_attn_out_43, core_attn_out_44, output_114], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg234_1, buf391, buf392, buf374, buf394, 4096, stream=raw_stream0)
        del arg234_1
        assert_size_stride_grouped((arg235_1, arg236_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_40, core_attn_out_41, core_attn_out_42, hidden_states_77, pow_34, variance_8, add_122, rsqrt_51, hidden_states_78, to_118, hidden_states_79, to_119, silu_27, hidden_states_80, core_attn_out_43, core_attn_out_44, output_114], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf394, arg235_1, buf393, arg236_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg235_1
        del arg236_1
        assert_size_stride(arg237_1, (2560, ), (1, ), 'input')
        buf397 = buf375; del buf375  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_75, hidden_states_81, float_70, pow_35, mean_34, add_124, rsqrt_52, output_115, float_71, add_125, output_116, hidden_states_82], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf359, buf367, buf393, arg237_1, buf397, 1, 2560, stream=raw_stream0)
        del arg237_1
        buf398 = buf368; del buf368  # reuse
        assert_size_stride_grouped((arg238_1, arg239_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_117], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf397, arg238_1, buf398, arg239_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg238_1
        del arg239_1
        buf400 = buf364; del buf364  # reuse
        assert_size_stride_grouped((arg240_1, arg241_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_118], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf397, arg240_1, buf400, arg241_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg240_1
        del arg241_1
        buf402 = buf397; del buf397  # reuse
        buf403 = buf361; del buf361  # reuse
        # Topologically Sorted Source Nodes: [silu_28, mul_192, output_119], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf398, buf400, buf403, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg242_1, arg243_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_28, mul_192, output_119], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf403, arg242_1, buf402, arg243_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg242_1
        del arg243_1
        assert_size_stride(arg244_1, (2560, ), (1, ), 'input')
        buf406 = buf372; del buf372  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_75, hidden_states_81, hidden_states_83, float_72, pow_36, mean_35, add_127, rsqrt_53, output_120, float_73, add_128, output_121, hidden_states_84], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf359, buf367, buf393, buf402, arg244_1, buf406, 1, 2560, stream=raw_stream0)
        del arg244_1
        buf407 = reinterpret_tensor(buf381, (1, 1, 8192), (8192, 8192, 1), 0); del buf381  # reuse
        assert_size_stride_grouped((arg245_1, arg246_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_122], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf406, arg245_1, buf407, arg246_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg245_1
        del arg246_1
        buf409 = buf262; del buf262  # reuse
        assert_size_stride_grouped((arg248_1, arg249_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_125], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf406, arg248_1, buf409, arg249_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg248_1
        del arg249_1
        buf411 = reinterpret_tensor(buf277, (1, 1, 1024), (1024, 1024, 1), 0); del buf277  # reuse
        assert_size_stride_grouped((arg251_1, arg252_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_128], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf406, arg251_1, buf411, arg252_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg251_1
        del arg252_1
        buf413 = reinterpret_tensor(buf283, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf283  # reuse
        # Topologically Sorted Source Nodes: [float_74, pow_37, mean_36], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_split_view_22.run(buf407, buf413, 16, 256, stream=raw_stream0)
        assert_size_stride(arg247_1, (256, ), (1, ), 'input')
        buf416 = reinterpret_tensor(buf260, (1, 16, 1, 64), (1024, 64, 64, 1), 0); del buf260  # reuse
        buf414 = reinterpret_tensor(buf416, (1, 16, 1, 32), (1024, 64, 64, 1), 0)  # alias
        buf415 = reinterpret_tensor(buf416, (1, 16, 1, 32), (1024, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_74, pow_37, mean_36, add_129, rsqrt_54, output_123, float_75, add_130, output_124, type_as_27, query_states_5, q_rot_2, x2_4, neg_13, x1_4, cat_19], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_23.run(buf407, buf413, arg247_1, buf414, buf415, 512, stream=raw_stream0)
        buf419 = reinterpret_tensor(buf394, (1, 16, 1, 256), (4096, 256, 256, 1), 0); del buf394  # reuse
        buf417 = reinterpret_tensor(buf419, (1, 16, 1, 64), (4096, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_74, pow_37, mean_36, add_129, rsqrt_54, output_123, float_75, add_130, output_124, type_as_27, query_states_5, q_rot_2, cos_6, mul_199, sin_6, mul_200, q_embed_4], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_24.run(buf407, buf413, arg247_1, buf1, buf416, buf0, buf417, 1024, stream=raw_stream0)
        del buf414
        del buf415
        buf418 = reinterpret_tensor(buf419, (1, 16, 1, 192), (4096, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_74, pow_37, mean_36, add_129, rsqrt_54, output_123, float_75, add_130, output_124, type_as_27, query_states_5, q_rot_2, cos_6, mul_199, sin_6, mul_200, q_embed_4, q_pass_2, q_embed_5], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_25.run(buf407, buf413, arg247_1, buf418, 3072, stream=raw_stream0)
        del arg247_1
        buf420 = buf271; del buf271  # reuse
        # Topologically Sorted Source Nodes: [float_76, pow_38, mean_37], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_26.run(buf409, buf420, 4, 256, stream=raw_stream0)
        del buf417
        del buf418
        assert_size_stride(arg250_1, (256, ), (1, ), 'input')
        buf423 = buf274; del buf274  # reuse
        buf421 = reinterpret_tensor(buf423, (1, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        buf422 = reinterpret_tensor(buf423, (1, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_76, pow_38, mean_37, add_131, rsqrt_55, output_126, float_77, add_132, output_127, type_as_28, key_states_2, k_rot_2, x2_5, neg_14, x1_5, cat_20], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_27.run(buf409, buf420, arg250_1, buf421, buf422, 128, stream=raw_stream0)
        buf426 = reinterpret_tensor(buf416, (1, 4, 1, 256), (1024, 256, 256, 1), 0); del buf416  # reuse
        buf424 = reinterpret_tensor(buf426, (1, 4, 1, 64), (1024, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_6, sin_6, float_76, pow_38, mean_37, add_131, rsqrt_55, output_126, float_77, add_132, output_127, type_as_28, key_states_2, k_rot_2, mul_201, mul_202, k_embed_4], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28.run(buf409, buf420, arg250_1, buf1, buf423, buf0, buf424, 256, stream=raw_stream0)
        del buf421
        del buf422
        buf425 = reinterpret_tensor(buf426, (1, 4, 1, 192), (1024, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_6, sin_6, float_76, pow_38, mean_37, add_131, rsqrt_55, output_126, float_77, add_132, output_127, type_as_28, key_states_2, k_rot_2, mul_201, mul_202, k_embed_4, k_pass_2, k_embed_5], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_29.run(buf409, buf420, arg250_1, buf425, 768, stream=raw_stream0)
        del arg250_1
        assert_size_stride_grouped((arg253_1, arg254_1), ((), (1, 4, 64, 256)), ((), (65536, 16384, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_6, cache_position_2, index_copy__4], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_30.run(arg253_1, buf426, arg254_1, 1024, stream=raw_stream0)
        del buf424
        del buf425
        buf428 = reinterpret_tensor(buf282, (16, 1, 64), (64, 64, 1), 0); del buf282  # reuse
        # Topologically Sorted Source Nodes: [attn_output_8, key_47], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_31.run(buf419, arg254_1, buf428, 1024, 256, stream=raw_stream0)
        del arg254_1
        buf429 = buf280; del buf280  # reuse
        buf431 = reinterpret_tensor(buf279, (1, 16, 1, 64), (1024, 64, 1024, 1), 0); del buf279  # reuse
        buf432 = reinterpret_tensor(buf413, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf413  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_8], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32.run(buf428, arg3_1, buf429, buf431, buf432, 16, 64, stream=raw_stream0)
        assert_size_stride(arg255_1, (1, 4, 64, 256), (65536, 16384, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_6, cache_position_2, index_copy__5], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_33.run(arg253_1, buf411, arg255_1, 1024, stream=raw_stream0)
        buf436 = reinterpret_tensor(buf419, (1, 1, 4096), (4096, 4096, 1), 0); del buf419  # reuse
        # Topologically Sorted Source Nodes: [gate_5, attn_output_8, value_29, transpose_83, reshape_74, sigmoid_11, attn_output_11, output_129], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34.run(buf429, buf431, buf432, arg255_1, buf407, buf436, 4096, 64, stream=raw_stream0)
        del arg255_1
        buf435 = buf406; del buf406  # reuse
        assert_size_stride_grouped((arg256_1, arg257_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [gate_5, attn_output_8, transpose_83, reshape_74, sigmoid_11, attn_output_11, output_129], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf436, arg256_1, buf435, arg257_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg256_1
        del arg257_1
        assert_size_stride(arg258_1, (2560, ), (1, ), 'input')
        buf438 = buf359; del buf359  # reuse
        buf441 = buf323; del buf323  # reuse
        buf444 = buf297; del buf297  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_75, hidden_states_81, hidden_states_83, hidden_states_87, float_78, pow_39, mean_38, add_137, rsqrt_56, output_130, float_79, add_138, output_131, hidden_states_88, output_132, output_133], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf438, buf367, buf393, buf402, buf435, arg258_1, buf441, buf444, 1, 2560, stream=raw_stream0)
        del arg258_1
        buf440 = buf403; del buf403  # reuse
        assert_size_stride_grouped((arg259_1, arg260_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_78, pow_39, mean_38, add_137, rsqrt_56, output_130, float_79, add_138, output_131, hidden_states_88, output_132], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf441, arg259_1, buf440, arg260_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg259_1
        del arg260_1
        buf443 = buf400; del buf400  # reuse
        assert_size_stride_grouped((arg261_1, arg262_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_78, pow_39, mean_38, add_137, rsqrt_56, output_130, float_79, add_138, output_131, hidden_states_88, output_133], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf444, arg261_1, buf443, arg262_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg261_1
        del arg262_1
        buf446 = buf444; del buf444  # reuse
        buf447 = buf398; del buf398  # reuse
        # Topologically Sorted Source Nodes: [silu_29, mul_206, output_134], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf440, buf443, buf447, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg263_1, arg264_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_29, mul_206, output_134], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf447, arg263_1, buf446, arg264_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg263_1
        del arg264_1
        assert_size_stride(arg265_1, (2560, ), (1, ), 'input')
        buf451 = buf441; del buf441  # reuse
        buf454 = buf435; del buf435  # reuse
        buf462 = buf402; del buf402  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_89, float_80, pow_40, mean_39, add_140, rsqrt_57, output_135, float_81, add_141, output_136, hidden_states_90, output_137, output_138], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf438, buf446, arg265_1, buf451, buf454, buf462, 1, 2560, stream=raw_stream0)
        del arg265_1
        buf450 = buf407; del buf407  # reuse
        assert_size_stride_grouped((arg266_1, arg267_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_89, float_80, pow_40, mean_39, add_140, rsqrt_57, output_135, float_81, add_141, output_136, hidden_states_90, output_137], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf451, arg266_1, buf450, arg267_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg266_1
        del arg267_1
        buf453 = buf436; del buf436  # reuse
        assert_size_stride_grouped((arg268_1, arg269_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_89, float_80, pow_40, mean_39, add_140, rsqrt_57, output_135, float_81, add_141, output_136, hidden_states_90, output_138], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf454, arg268_1, buf453, arg269_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg268_1
        del arg269_1
        assert_size_stride(arg273_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf458 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf456 = reinterpret_tensor(buf458, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_23], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg273_1, buf456, 32768, stream=raw_stream0)
        buf457 = reinterpret_tensor(buf458, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_23], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf450, buf457, 8192, stream=raw_stream0)
        assert_size_stride(arg272_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf460 = reinterpret_tensor(buf450, (1, 8192, 1), (8192, 1, 8192), 0); del buf450  # reuse
        # Topologically Sorted Source Nodes: [out_27, squeeze_9, unsqueeze_60, out_28, out_29], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf458, arg272_1, buf460, 8192, stream=raw_stream0)
        del arg272_1
        del buf456
        del buf457
        buf461 = reinterpret_tensor(buf392, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf392  # reuse
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_29, split_9, key_49, key_50, transpose_87, key_51, mul_212, sum_38], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf460, buf461, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg271_1, arg274_1, arg275_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf464 = buf385; del buf385  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_89, float_80, pow_40, mean_39, add_140, rsqrt_57, output_135, float_81, add_141, output_136, hidden_states_90, float_82, exp_18, neg_15, a_9, float_83, add_142, softplus_9, g_9, transpose_90, getitem_156, exp_19], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf462, arg271_1, arg274_1, arg275_1, buf464, 2, 1, 1, stream=raw_stream0)
        del arg271_1
        del arg274_1
        del arg275_1
        assert_size_stride(arg276_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf465 = buf391; del buf391  # reuse
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_29, split_9, key_49, key_50, transpose_87, key_51, add_144, inv_norm_19, key_52, k_t_9, float_82, exp_18, neg_15, a_9, float_83, add_142, softplus_9, g_9, transpose_90, getitem_156, exp_19, decay_t_9, last_recurrent_state_28, unsqueeze_62, mul_215, kv_mem_9], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg276_1, buf464, buf460, buf461, buf465, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg270_1, (32, 2560), (2560, 1), 'input')
        buf467 = reinterpret_tensor(buf382, (1, 32, 1), (32, 1, 32), 0); del buf382  # reuse
        # Topologically Sorted Source Nodes: [b_9, beta_18, transpose_89, beta_19], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf462, arg270_1, buf467, 2, 1, 1, stream=raw_stream0)
        del arg270_1
        buf468 = buf389; del buf389  # reuse
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_29, split_9, key_49, key_50, transpose_87, key_51, add_144, inv_norm_19, key_52, k_t_9, unsqueeze_63, value_31, transpose_88, value_32, v_t_9, float_82, exp_18, neg_15, a_9, float_83, add_142, softplus_9, g_9, transpose_90, getitem_156, exp_19, decay_t_9, last_recurrent_state_28, sub_9, b_9, beta_18, transpose_89, beta_19, getitem_158, beta_t_9, delta_9, unsqueeze_64, mul_217, last_recurrent_state_29], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg276_1, buf464, buf460, buf461, buf465, buf467, buf468, arg276_1, 524288, stream=raw_stream0)
        del arg276_1
        buf469 = reinterpret_tensor(buf467, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf467  # reuse
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_29, split_9, query_55, query_56, transpose_86, query_57, mul_210, sum_37], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf460, buf469, 32, 128, stream=raw_stream0)
        buf470 = buf465; del buf465  # reuse
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_29, split_9, query_55, query_56, transpose_86, query_57, add_143, inv_norm_18, query_58, query_59, q_t_9, unsqueeze_65, mul_218, sum_40], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf468, buf460, buf469, buf470, 4096, 128, stream=raw_stream0)
        buf471 = reinterpret_tensor(buf469, (32, 1), (1, 32), 0); del buf469  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_45, core_attn_out_46, core_attn_out_47, hidden_states_91, pow_41, variance_9], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf470, buf471, 32, 128, stream=raw_stream0)
        buf472 = buf462; del buf462  # reuse
        assert_size_stride(arg277_1, (128, ), (1, ), 'input')
        buf473 = buf374; del buf374  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_45, core_attn_out_46, core_attn_out_47, hidden_states_91, pow_41, variance_9, add_146, rsqrt_60, hidden_states_92, to_131, hidden_states_93, to_132, silu_31, hidden_states_94, core_attn_out_48, core_attn_out_49, output_139], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg277_1, buf470, buf471, buf453, buf473, 4096, stream=raw_stream0)
        del arg277_1
        assert_size_stride_grouped((arg278_1, arg279_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_45, core_attn_out_46, core_attn_out_47, hidden_states_91, pow_41, variance_9, add_146, rsqrt_60, hidden_states_92, to_131, hidden_states_93, to_132, silu_31, hidden_states_94, core_attn_out_48, core_attn_out_49, output_139], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf473, arg278_1, buf472, arg279_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg278_1
        del arg279_1
        assert_size_stride(arg280_1, (2560, ), (1, ), 'input')
        buf476 = buf454; del buf454  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_89, hidden_states_95, float_84, pow_42, mean_41, add_148, rsqrt_61, output_140, float_85, add_149, output_141, hidden_states_96], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf438, buf446, buf472, arg280_1, buf476, 1, 2560, stream=raw_stream0)
        del arg280_1
        buf477 = buf447; del buf447  # reuse
        assert_size_stride_grouped((arg281_1, arg282_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_142], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf476, arg281_1, buf477, arg282_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg281_1
        del arg282_1
        buf479 = buf443; del buf443  # reuse
        assert_size_stride_grouped((arg283_1, arg284_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_143], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf476, arg283_1, buf479, arg284_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg283_1
        del arg284_1
        buf481 = buf476; del buf476  # reuse
        buf482 = buf440; del buf440  # reuse
        # Topologically Sorted Source Nodes: [silu_32, mul_224, output_144], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf477, buf479, buf482, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg285_1, arg286_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_32, mul_224, output_144], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf482, arg285_1, buf481, arg286_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg285_1
        del arg286_1
        assert_size_stride(arg287_1, (2560, ), (1, ), 'input')
        buf485 = buf451; del buf451  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_89, hidden_states_95, hidden_states_97, float_86, pow_43, mean_42, add_151, rsqrt_62, output_145, float_87, add_152, output_146, hidden_states_98], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf438, buf446, buf472, buf481, arg287_1, buf485, 1, 2560, stream=raw_stream0)
        del arg287_1
        buf486 = reinterpret_tensor(buf460, (1, 1, 8192), (8192, 8192, 1), 0); del buf460  # reuse
        assert_size_stride_grouped((arg288_1, arg289_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_147], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf485, arg288_1, buf486, arg289_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg288_1
        del arg289_1
        buf488 = buf473; del buf473  # reuse
        assert_size_stride_grouped((arg290_1, arg291_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_148], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf485, arg290_1, buf488, arg291_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg290_1
        del arg291_1
        assert_size_stride(arg295_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf492 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf490 = reinterpret_tensor(buf492, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_24], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg295_1, buf490, 32768, stream=raw_stream0)
        buf491 = reinterpret_tensor(buf492, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_24], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf486, buf491, 8192, stream=raw_stream0)
        assert_size_stride(arg294_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf494 = reinterpret_tensor(buf486, (1, 8192, 1), (8192, 1, 8192), 0); del buf486  # reuse
        # Topologically Sorted Source Nodes: [out_30, squeeze_10, unsqueeze_66, out_31, out_32], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf492, arg294_1, buf494, 8192, stream=raw_stream0)
        del arg294_1
        del buf490
        del buf491
        buf495 = reinterpret_tensor(buf471, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf471  # reuse
        # Topologically Sorted Source Nodes: [out_32, mixed_qkv_32, split_10, key_54, key_55, transpose_95, key_56, mul_230, sum_42], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf494, buf495, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg293_1, arg296_1, arg297_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf497 = buf464; del buf464  # reuse
        # Topologically Sorted Source Nodes: [float_88, exp_20, neg_16, a_10, float_89, add_153, softplus_10, g_10, transpose_98, getitem_167, exp_21], Original ATen: [aten._to_copy, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_17.run(buf485, arg293_1, arg296_1, arg297_1, buf497, 2, 1, 1, stream=raw_stream0)
        del arg293_1
        del arg296_1
        del arg297_1
        assert_size_stride(arg298_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf498 = buf470; del buf470  # reuse
        # Topologically Sorted Source Nodes: [out_32, mixed_qkv_32, split_10, key_54, key_55, transpose_95, key_56, add_155, inv_norm_21, key_57, k_t_10, float_88, exp_20, neg_16, a_10, float_89, add_153, softplus_10, g_10, transpose_98, getitem_167, exp_21, decay_t_10, last_recurrent_state_31, unsqueeze_68, mul_233, kv_mem_10], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg298_1, buf497, buf494, buf495, buf498, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg292_1, (32, 2560), (2560, 1), 'input')
        buf500 = reinterpret_tensor(buf461, (1, 32, 1), (32, 1, 32), 0); del buf461  # reuse
        # Topologically Sorted Source Nodes: [b_10, beta_20, transpose_97, beta_21], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf485, arg292_1, buf500, 2, 1, 1, stream=raw_stream0)
        del arg292_1
        buf501 = buf468; del buf468  # reuse
        # Topologically Sorted Source Nodes: [out_32, mixed_qkv_32, split_10, key_54, key_55, transpose_95, key_56, add_155, inv_norm_21, key_57, k_t_10, unsqueeze_69, value_34, transpose_96, value_35, v_t_10, float_88, exp_20, neg_16, a_10, float_89, add_153, softplus_10, g_10, transpose_98, getitem_167, exp_21, decay_t_10, last_recurrent_state_31, sub_10, b_10, beta_20, transpose_97, beta_21, getitem_169, beta_t_10, delta_10, unsqueeze_70, mul_235, last_recurrent_state_32], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg298_1, buf497, buf494, buf495, buf498, buf500, buf501, arg298_1, 524288, stream=raw_stream0)
        del arg298_1
        buf502 = reinterpret_tensor(buf500, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf500  # reuse
        # Topologically Sorted Source Nodes: [out_32, mixed_qkv_32, split_10, query_61, query_62, transpose_94, query_63, mul_228, sum_41], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf494, buf502, 32, 128, stream=raw_stream0)
        buf503 = buf498; del buf498  # reuse
        # Topologically Sorted Source Nodes: [out_32, mixed_qkv_32, split_10, query_61, query_62, transpose_94, query_63, add_154, inv_norm_20, query_64, query_65, q_t_10, unsqueeze_71, mul_236, sum_44], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf501, buf494, buf502, buf503, 4096, 128, stream=raw_stream0)
        buf504 = reinterpret_tensor(buf502, (32, 1), (1, 32), 0); del buf502  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_50, core_attn_out_51, core_attn_out_52, hidden_states_99, pow_44, variance_10], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf503, buf504, 32, 128, stream=raw_stream0)
        buf505 = buf485; del buf485  # reuse
        assert_size_stride(arg299_1, (128, ), (1, ), 'input')
        buf506 = buf453; del buf453  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_50, core_attn_out_51, core_attn_out_52, hidden_states_99, pow_44, variance_10, add_157, rsqrt_65, hidden_states_100, to_144, hidden_states_101, to_145, silu_34, hidden_states_102, core_attn_out_53, core_attn_out_54, output_149], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg299_1, buf503, buf504, buf488, buf506, 4096, stream=raw_stream0)
        del arg299_1
        assert_size_stride_grouped((arg300_1, arg301_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_50, core_attn_out_51, core_attn_out_52, hidden_states_99, pow_44, variance_10, add_157, rsqrt_65, hidden_states_100, to_144, hidden_states_101, to_145, silu_34, hidden_states_102, core_attn_out_53, core_attn_out_54, output_149], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf506, arg300_1, buf505, arg301_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg300_1
        del arg301_1
        assert_size_stride(arg302_1, (2560, ), (1, ), 'input')
        buf508 = buf438; del buf438  # reuse
        buf511 = buf393; del buf393  # reuse
        buf514 = buf367; del buf367  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_89, hidden_states_95, hidden_states_97, hidden_states_103, float_90, pow_45, mean_44, add_159, rsqrt_66, output_150, float_91, add_160, output_151, hidden_states_104, output_152, output_153], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf508, buf446, buf472, buf481, buf505, arg302_1, buf511, buf514, 1, 2560, stream=raw_stream0)
        del arg302_1
        buf510 = buf482; del buf482  # reuse
        assert_size_stride_grouped((arg303_1, arg304_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_90, pow_45, mean_44, add_159, rsqrt_66, output_150, float_91, add_160, output_151, hidden_states_104, output_152], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf511, arg303_1, buf510, arg304_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg303_1
        del arg304_1
        buf513 = buf479; del buf479  # reuse
        assert_size_stride_grouped((arg305_1, arg306_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_90, pow_45, mean_44, add_159, rsqrt_66, output_150, float_91, add_160, output_151, hidden_states_104, output_153], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf514, arg305_1, buf513, arg306_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg305_1
        del arg306_1
        buf516 = buf514; del buf514  # reuse
        buf517 = buf477; del buf477  # reuse
        # Topologically Sorted Source Nodes: [silu_35, mul_242, output_154], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf510, buf513, buf517, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg307_1, arg308_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_35, mul_242, output_154], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf517, arg307_1, buf516, arg308_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg307_1
        del arg308_1
        assert_size_stride(arg309_1, (2560, ), (1, ), 'input')
        buf521 = buf511; del buf511  # reuse
        buf524 = buf505; del buf505  # reuse
        buf532 = buf481; del buf481  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_105, float_92, pow_46, mean_45, add_162, rsqrt_67, output_155, float_93, add_163, output_156, hidden_states_106, output_157, output_158], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf508, buf516, arg309_1, buf521, buf524, buf532, 1, 2560, stream=raw_stream0)
        del arg309_1
        buf520 = reinterpret_tensor(buf494, (1, 1, 8192), (8192, 8192, 1), 0); del buf494  # reuse
        assert_size_stride_grouped((arg310_1, arg311_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_105, float_92, pow_46, mean_45, add_162, rsqrt_67, output_155, float_93, add_163, output_156, hidden_states_106, output_157], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf521, arg310_1, buf520, arg311_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg310_1
        del arg311_1
        buf523 = buf506; del buf506  # reuse
        assert_size_stride_grouped((arg312_1, arg313_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_105, float_92, pow_46, mean_45, add_162, rsqrt_67, output_155, float_93, add_163, output_156, hidden_states_106, output_158], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf524, arg312_1, buf523, arg313_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg312_1
        del arg313_1
        assert_size_stride(arg317_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf528 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf526 = reinterpret_tensor(buf528, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_25], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg317_1, buf526, 32768, stream=raw_stream0)
        buf527 = reinterpret_tensor(buf528, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_25], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf520, buf527, 8192, stream=raw_stream0)
        assert_size_stride(arg316_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf530 = reinterpret_tensor(buf520, (1, 8192, 1), (8192, 1, 8192), 0); del buf520  # reuse
        # Topologically Sorted Source Nodes: [out_33, squeeze_11, unsqueeze_72, out_34, out_35], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf528, arg316_1, buf530, 8192, stream=raw_stream0)
        del arg316_1
        del buf526
        del buf527
        buf531 = reinterpret_tensor(buf504, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf504  # reuse
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_35, split_11, key_59, key_60, transpose_103, key_61, mul_248, sum_46], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf530, buf531, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg315_1, arg318_1, arg319_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf534 = buf497; del buf497  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_105, float_92, pow_46, mean_45, add_162, rsqrt_67, output_155, float_93, add_163, output_156, hidden_states_106, float_94, exp_22, neg_17, a_11, float_95, add_164, softplus_11, g_11, transpose_106, getitem_178, exp_23], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf532, arg315_1, arg318_1, arg319_1, buf534, 2, 1, 1, stream=raw_stream0)
        del arg315_1
        del arg318_1
        del arg319_1
        assert_size_stride(arg320_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf535 = buf503; del buf503  # reuse
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_35, split_11, key_59, key_60, transpose_103, key_61, add_166, inv_norm_23, key_62, k_t_11, float_94, exp_22, neg_17, a_11, float_95, add_164, softplus_11, g_11, transpose_106, getitem_178, exp_23, decay_t_11, last_recurrent_state_34, unsqueeze_74, mul_251, kv_mem_11], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg320_1, buf534, buf530, buf531, buf535, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg314_1, (32, 2560), (2560, 1), 'input')
        buf537 = reinterpret_tensor(buf495, (1, 32, 1), (32, 1, 32), 0); del buf495  # reuse
        # Topologically Sorted Source Nodes: [b_11, beta_22, transpose_105, beta_23], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf532, arg314_1, buf537, 2, 1, 1, stream=raw_stream0)
        del arg314_1
        buf538 = buf501; del buf501  # reuse
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_35, split_11, key_59, key_60, transpose_103, key_61, add_166, inv_norm_23, key_62, k_t_11, unsqueeze_75, value_37, transpose_104, value_38, v_t_11, float_94, exp_22, neg_17, a_11, float_95, add_164, softplus_11, g_11, transpose_106, getitem_178, exp_23, decay_t_11, last_recurrent_state_34, sub_11, b_11, beta_22, transpose_105, beta_23, getitem_180, beta_t_11, delta_11, unsqueeze_76, mul_253, last_recurrent_state_35], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg320_1, buf534, buf530, buf531, buf535, buf537, buf538, arg320_1, 524288, stream=raw_stream0)
        del arg320_1
        buf539 = reinterpret_tensor(buf537, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf537  # reuse
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_35, split_11, query_67, query_68, transpose_102, query_69, mul_246, sum_45], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf530, buf539, 32, 128, stream=raw_stream0)
        buf540 = buf535; del buf535  # reuse
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_35, split_11, query_67, query_68, transpose_102, query_69, add_165, inv_norm_22, query_70, query_71, q_t_11, unsqueeze_77, mul_254, sum_48], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf538, buf530, buf539, buf540, 4096, 128, stream=raw_stream0)
        buf541 = reinterpret_tensor(buf539, (32, 1), (1, 32), 0); del buf539  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_55, core_attn_out_56, core_attn_out_57, hidden_states_107, pow_47, variance_11], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf540, buf541, 32, 128, stream=raw_stream0)
        buf542 = buf532; del buf532  # reuse
        assert_size_stride(arg321_1, (128, ), (1, ), 'input')
        buf543 = buf488; del buf488  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_55, core_attn_out_56, core_attn_out_57, hidden_states_107, pow_47, variance_11, add_168, rsqrt_70, hidden_states_108, to_157, hidden_states_109, to_158, silu_37, hidden_states_110, core_attn_out_58, core_attn_out_59, output_159], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg321_1, buf540, buf541, buf523, buf543, 4096, stream=raw_stream0)
        del arg321_1
        assert_size_stride_grouped((arg322_1, arg323_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_55, core_attn_out_56, core_attn_out_57, hidden_states_107, pow_47, variance_11, add_168, rsqrt_70, hidden_states_108, to_157, hidden_states_109, to_158, silu_37, hidden_states_110, core_attn_out_58, core_attn_out_59, output_159], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf543, arg322_1, buf542, arg323_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg322_1
        del arg323_1
        assert_size_stride(arg324_1, (2560, ), (1, ), 'input')
        buf546 = buf524; del buf524  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_105, hidden_states_111, float_96, pow_48, mean_47, add_170, rsqrt_71, output_160, float_97, add_171, output_161, hidden_states_112], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf508, buf516, buf542, arg324_1, buf546, 1, 2560, stream=raw_stream0)
        del arg324_1
        buf547 = buf517; del buf517  # reuse
        assert_size_stride_grouped((arg325_1, arg326_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_162], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf546, arg325_1, buf547, arg326_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg325_1
        del arg326_1
        buf549 = buf513; del buf513  # reuse
        assert_size_stride_grouped((arg327_1, arg328_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_163], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf546, arg327_1, buf549, arg328_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg327_1
        del arg328_1
        buf551 = buf546; del buf546  # reuse
        buf552 = buf510; del buf510  # reuse
        # Topologically Sorted Source Nodes: [silu_38, mul_260, output_164], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf547, buf549, buf552, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg329_1, arg330_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_38, mul_260, output_164], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf552, arg329_1, buf551, arg330_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg329_1
        del arg330_1
        assert_size_stride(arg331_1, (2560, ), (1, ), 'input')
        buf555 = buf521; del buf521  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_105, hidden_states_111, hidden_states_113, float_98, pow_49, mean_48, add_173, rsqrt_72, output_165, float_99, add_174, output_166, hidden_states_114], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf508, buf516, buf542, buf551, arg331_1, buf555, 1, 2560, stream=raw_stream0)
        del arg331_1
        buf556 = reinterpret_tensor(buf530, (1, 1, 8192), (8192, 8192, 1), 0); del buf530  # reuse
        assert_size_stride_grouped((arg332_1, arg333_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_167], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf555, arg332_1, buf556, arg333_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg332_1
        del arg333_1
        buf558 = buf411; del buf411  # reuse
        assert_size_stride_grouped((arg335_1, arg336_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_170], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf555, arg335_1, buf558, arg336_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg335_1
        del arg336_1
        buf560 = reinterpret_tensor(buf426, (1, 1, 1024), (1024, 1024, 1), 0); del buf426  # reuse
        assert_size_stride_grouped((arg338_1, arg339_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_173], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf555, arg338_1, buf560, arg339_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg338_1
        del arg339_1
        buf562 = reinterpret_tensor(buf432, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf432  # reuse
        # Topologically Sorted Source Nodes: [float_100, pow_50, mean_49], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_split_view_22.run(buf556, buf562, 16, 256, stream=raw_stream0)
        assert_size_stride(arg334_1, (256, ), (1, ), 'input')
        buf565 = reinterpret_tensor(buf409, (1, 16, 1, 64), (1024, 64, 64, 1), 0); del buf409  # reuse
        buf563 = reinterpret_tensor(buf565, (1, 16, 1, 32), (1024, 64, 64, 1), 0)  # alias
        buf564 = reinterpret_tensor(buf565, (1, 16, 1, 32), (1024, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_100, pow_50, mean_49, add_175, rsqrt_73, output_168, float_101, add_176, output_169, type_as_37, query_states_7, q_rot_3, x2_6, neg_18, x1_6, cat_26], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_23.run(buf556, buf562, arg334_1, buf563, buf564, 512, stream=raw_stream0)
        buf568 = reinterpret_tensor(buf543, (1, 16, 1, 256), (4096, 256, 256, 1), 0); del buf543  # reuse
        buf566 = reinterpret_tensor(buf568, (1, 16, 1, 64), (4096, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_100, pow_50, mean_49, add_175, rsqrt_73, output_168, float_101, add_176, output_169, type_as_37, query_states_7, q_rot_3, cos_7, mul_267, sin_7, mul_268, q_embed_6], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_24.run(buf556, buf562, arg334_1, buf1, buf565, buf0, buf566, 1024, stream=raw_stream0)
        del buf563
        del buf564
        buf567 = reinterpret_tensor(buf568, (1, 16, 1, 192), (4096, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_100, pow_50, mean_49, add_175, rsqrt_73, output_168, float_101, add_176, output_169, type_as_37, query_states_7, q_rot_3, cos_7, mul_267, sin_7, mul_268, q_embed_6, q_pass_3, q_embed_7], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_25.run(buf556, buf562, arg334_1, buf567, 3072, stream=raw_stream0)
        del arg334_1
        buf569 = buf420; del buf420  # reuse
        # Topologically Sorted Source Nodes: [float_102, pow_51, mean_50], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_26.run(buf558, buf569, 4, 256, stream=raw_stream0)
        del buf566
        del buf567
        assert_size_stride(arg337_1, (256, ), (1, ), 'input')
        buf572 = buf423; del buf423  # reuse
        buf570 = reinterpret_tensor(buf572, (1, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        buf571 = reinterpret_tensor(buf572, (1, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_102, pow_51, mean_50, add_177, rsqrt_74, output_171, float_103, add_178, output_172, type_as_38, key_states_3, k_rot_3, x2_7, neg_19, x1_7, cat_27], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_27.run(buf558, buf569, arg337_1, buf570, buf571, 128, stream=raw_stream0)
        buf575 = reinterpret_tensor(buf565, (1, 4, 1, 256), (1024, 256, 256, 1), 0); del buf565  # reuse
        buf573 = reinterpret_tensor(buf575, (1, 4, 1, 64), (1024, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_7, sin_7, float_102, pow_51, mean_50, add_177, rsqrt_74, output_171, float_103, add_178, output_172, type_as_38, key_states_3, k_rot_3, mul_269, mul_270, k_embed_6], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28.run(buf558, buf569, arg337_1, buf1, buf572, buf0, buf573, 256, stream=raw_stream0)
        del buf570
        del buf571
        buf574 = reinterpret_tensor(buf575, (1, 4, 1, 192), (1024, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_7, sin_7, float_102, pow_51, mean_50, add_177, rsqrt_74, output_171, float_103, add_178, output_172, type_as_38, key_states_3, k_rot_3, mul_269, mul_270, k_embed_6, k_pass_3, k_embed_7], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_29.run(buf558, buf569, arg337_1, buf574, 768, stream=raw_stream0)
        del arg337_1
        assert_size_stride_grouped((arg340_1, arg341_1), ((), (1, 4, 64, 256)), ((), (65536, 16384, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_7, cache_position_3, index_copy__6], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_30.run(arg340_1, buf575, arg341_1, 1024, stream=raw_stream0)
        del buf573
        del buf574
        buf577 = reinterpret_tensor(buf431, (16, 1, 64), (64, 64, 1), 0); del buf431  # reuse
        # Topologically Sorted Source Nodes: [attn_output_12, key_63], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_31.run(buf568, arg341_1, buf577, 1024, 256, stream=raw_stream0)
        del arg341_1
        buf578 = buf429; del buf429  # reuse
        buf580 = reinterpret_tensor(buf428, (1, 16, 1, 64), (1024, 64, 1024, 1), 0); del buf428  # reuse
        buf581 = reinterpret_tensor(buf562, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf562  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_12], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32.run(buf577, arg3_1, buf578, buf580, buf581, 16, 64, stream=raw_stream0)
        assert_size_stride(arg342_1, (1, 4, 64, 256), (65536, 16384, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_7, cache_position_3, index_copy__7], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_33.run(arg340_1, buf560, arg342_1, 1024, stream=raw_stream0)
        buf585 = reinterpret_tensor(buf568, (1, 1, 4096), (4096, 4096, 1), 0); del buf568  # reuse
        # Topologically Sorted Source Nodes: [gate_7, attn_output_12, value_39, transpose_111, reshape_99, sigmoid_15, attn_output_15, output_174], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34.run(buf578, buf580, buf581, arg342_1, buf556, buf585, 4096, 64, stream=raw_stream0)
        del arg342_1
        buf584 = buf555; del buf555  # reuse
        assert_size_stride_grouped((arg343_1, arg344_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [gate_7, attn_output_12, transpose_111, reshape_99, sigmoid_15, attn_output_15, output_174], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf585, arg343_1, buf584, arg344_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg343_1
        del arg344_1
        assert_size_stride(arg345_1, (2560, ), (1, ), 'input')
        buf587 = buf508; del buf508  # reuse
        buf590 = buf472; del buf472  # reuse
        buf593 = buf446; del buf446  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_105, hidden_states_111, hidden_states_113, hidden_states_117, float_104, pow_52, mean_51, add_183, rsqrt_75, output_175, float_105, add_184, output_176, hidden_states_118, output_177, output_178], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf587, buf516, buf542, buf551, buf584, arg345_1, buf590, buf593, 1, 2560, stream=raw_stream0)
        del arg345_1
        buf589 = buf552; del buf552  # reuse
        assert_size_stride_grouped((arg346_1, arg347_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_104, pow_52, mean_51, add_183, rsqrt_75, output_175, float_105, add_184, output_176, hidden_states_118, output_177], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf590, arg346_1, buf589, arg347_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg346_1
        del arg347_1
        buf592 = buf549; del buf549  # reuse
        assert_size_stride_grouped((arg348_1, arg349_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_104, pow_52, mean_51, add_183, rsqrt_75, output_175, float_105, add_184, output_176, hidden_states_118, output_178], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf593, arg348_1, buf592, arg349_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg348_1
        del arg349_1
        buf595 = buf593; del buf593  # reuse
        buf596 = buf547; del buf547  # reuse
        # Topologically Sorted Source Nodes: [silu_39, mul_274, output_179], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf589, buf592, buf596, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg350_1, arg351_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_39, mul_274, output_179], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf596, arg350_1, buf595, arg351_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg350_1
        del arg351_1
        assert_size_stride(arg352_1, (2560, ), (1, ), 'input')
        buf600 = buf590; del buf590  # reuse
        buf603 = buf584; del buf584  # reuse
        buf611 = buf551; del buf551  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_119, float_106, pow_53, mean_52, add_186, rsqrt_76, output_180, float_107, add_187, output_181, hidden_states_120, output_182, output_183], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf587, buf595, arg352_1, buf600, buf603, buf611, 1, 2560, stream=raw_stream0)
        del arg352_1
        buf599 = buf556; del buf556  # reuse
        assert_size_stride_grouped((arg353_1, arg354_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_119, float_106, pow_53, mean_52, add_186, rsqrt_76, output_180, float_107, add_187, output_181, hidden_states_120, output_182], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf600, arg353_1, buf599, arg354_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg353_1
        del arg354_1
        buf602 = buf585; del buf585  # reuse
        assert_size_stride_grouped((arg355_1, arg356_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_119, float_106, pow_53, mean_52, add_186, rsqrt_76, output_180, float_107, add_187, output_181, hidden_states_120, output_183], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf603, arg355_1, buf602, arg356_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg355_1
        del arg356_1
        assert_size_stride(arg360_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf607 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf605 = reinterpret_tensor(buf607, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_30], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg360_1, buf605, 32768, stream=raw_stream0)
        buf606 = reinterpret_tensor(buf607, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_30], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf599, buf606, 8192, stream=raw_stream0)
        assert_size_stride(arg359_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf609 = reinterpret_tensor(buf599, (1, 8192, 1), (8192, 1, 8192), 0); del buf599  # reuse
        # Topologically Sorted Source Nodes: [out_36, squeeze_12, unsqueeze_80, out_37, out_38], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf607, arg359_1, buf609, 8192, stream=raw_stream0)
        del arg359_1
        del buf605
        del buf606
        buf610 = reinterpret_tensor(buf541, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf541  # reuse
        # Topologically Sorted Source Nodes: [out_38, mixed_qkv_38, split_12, key_65, key_66, transpose_115, key_67, mul_280, sum_50], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf609, buf610, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg358_1, arg361_1, arg362_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf613 = buf534; del buf534  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_119, float_106, pow_53, mean_52, add_186, rsqrt_76, output_180, float_107, add_187, output_181, hidden_states_120, float_108, exp_24, neg_20, a_12, float_109, add_188, softplus_12, g_12, transpose_118, getitem_201, exp_25], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf611, arg358_1, arg361_1, arg362_1, buf613, 2, 1, 1, stream=raw_stream0)
        del arg358_1
        del arg361_1
        del arg362_1
        assert_size_stride(arg363_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf614 = buf540; del buf540  # reuse
        # Topologically Sorted Source Nodes: [out_38, mixed_qkv_38, split_12, key_65, key_66, transpose_115, key_67, add_190, inv_norm_25, key_68, k_t_12, float_108, exp_24, neg_20, a_12, float_109, add_188, softplus_12, g_12, transpose_118, getitem_201, exp_25, decay_t_12, last_recurrent_state_37, unsqueeze_82, mul_283, kv_mem_12], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg363_1, buf613, buf609, buf610, buf614, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg357_1, (32, 2560), (2560, 1), 'input')
        buf616 = reinterpret_tensor(buf531, (1, 32, 1), (32, 1, 32), 0); del buf531  # reuse
        # Topologically Sorted Source Nodes: [b_12, beta_24, transpose_117, beta_25], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf611, arg357_1, buf616, 2, 1, 1, stream=raw_stream0)
        del arg357_1
        buf617 = buf538; del buf538  # reuse
        # Topologically Sorted Source Nodes: [out_38, mixed_qkv_38, split_12, key_65, key_66, transpose_115, key_67, add_190, inv_norm_25, key_68, k_t_12, unsqueeze_83, value_41, transpose_116, value_42, v_t_12, float_108, exp_24, neg_20, a_12, float_109, add_188, softplus_12, g_12, transpose_118, getitem_201, exp_25, decay_t_12, last_recurrent_state_37, sub_12, b_12, beta_24, transpose_117, beta_25, getitem_203, beta_t_12, delta_12, unsqueeze_84, mul_285, last_recurrent_state_38], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg363_1, buf613, buf609, buf610, buf614, buf616, buf617, arg363_1, 524288, stream=raw_stream0)
        del arg363_1
        buf618 = reinterpret_tensor(buf616, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf616  # reuse
        # Topologically Sorted Source Nodes: [out_38, mixed_qkv_38, split_12, query_73, query_74, transpose_114, query_75, mul_278, sum_49], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf609, buf618, 32, 128, stream=raw_stream0)
        buf619 = buf614; del buf614  # reuse
        # Topologically Sorted Source Nodes: [out_38, mixed_qkv_38, split_12, query_73, query_74, transpose_114, query_75, add_189, inv_norm_24, query_76, query_77, q_t_12, unsqueeze_85, mul_286, sum_52], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf617, buf609, buf618, buf619, 4096, 128, stream=raw_stream0)
        buf620 = reinterpret_tensor(buf618, (32, 1), (1, 32), 0); del buf618  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_60, core_attn_out_61, core_attn_out_62, hidden_states_121, pow_54, variance_12], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf619, buf620, 32, 128, stream=raw_stream0)
        buf621 = buf611; del buf611  # reuse
        assert_size_stride(arg364_1, (128, ), (1, ), 'input')
        buf622 = buf523; del buf523  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_60, core_attn_out_61, core_attn_out_62, hidden_states_121, pow_54, variance_12, add_192, rsqrt_79, hidden_states_122, to_170, hidden_states_123, to_171, silu_41, hidden_states_124, core_attn_out_63, core_attn_out_64, output_184], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg364_1, buf619, buf620, buf602, buf622, 4096, stream=raw_stream0)
        del arg364_1
        assert_size_stride_grouped((arg365_1, arg366_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_60, core_attn_out_61, core_attn_out_62, hidden_states_121, pow_54, variance_12, add_192, rsqrt_79, hidden_states_122, to_170, hidden_states_123, to_171, silu_41, hidden_states_124, core_attn_out_63, core_attn_out_64, output_184], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf622, arg365_1, buf621, arg366_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg365_1
        del arg366_1
        assert_size_stride(arg367_1, (2560, ), (1, ), 'input')
        buf625 = buf603; del buf603  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_119, hidden_states_125, float_110, pow_55, mean_54, add_194, rsqrt_80, output_185, float_111, add_195, output_186, hidden_states_126], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf587, buf595, buf621, arg367_1, buf625, 1, 2560, stream=raw_stream0)
        del arg367_1
        buf626 = buf596; del buf596  # reuse
        assert_size_stride_grouped((arg368_1, arg369_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_187], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf625, arg368_1, buf626, arg369_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg368_1
        del arg369_1
        buf628 = buf592; del buf592  # reuse
        assert_size_stride_grouped((arg370_1, arg371_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_188], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf625, arg370_1, buf628, arg371_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg370_1
        del arg371_1
        buf630 = buf625; del buf625  # reuse
        buf631 = buf589; del buf589  # reuse
        # Topologically Sorted Source Nodes: [silu_42, mul_292, output_189], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf626, buf628, buf631, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg372_1, arg373_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_42, mul_292, output_189], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf631, arg372_1, buf630, arg373_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg372_1
        del arg373_1
        assert_size_stride(arg374_1, (2560, ), (1, ), 'input')
        buf634 = buf600; del buf600  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_119, hidden_states_125, hidden_states_127, float_112, pow_56, mean_55, add_197, rsqrt_81, output_190, float_113, add_198, output_191, hidden_states_128], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf587, buf595, buf621, buf630, arg374_1, buf634, 1, 2560, stream=raw_stream0)
        del arg374_1
        buf635 = reinterpret_tensor(buf609, (1, 1, 8192), (8192, 8192, 1), 0); del buf609  # reuse
        assert_size_stride_grouped((arg375_1, arg376_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_192], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf634, arg375_1, buf635, arg376_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg375_1
        del arg376_1
        buf637 = buf622; del buf622  # reuse
        assert_size_stride_grouped((arg377_1, arg378_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_193], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf634, arg377_1, buf637, arg378_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg377_1
        del arg378_1
        assert_size_stride(arg382_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf641 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf639 = reinterpret_tensor(buf641, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_31], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg382_1, buf639, 32768, stream=raw_stream0)
        buf640 = reinterpret_tensor(buf641, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_31], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf635, buf640, 8192, stream=raw_stream0)
        assert_size_stride(arg381_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf643 = reinterpret_tensor(buf635, (1, 8192, 1), (8192, 1, 8192), 0); del buf635  # reuse
        # Topologically Sorted Source Nodes: [out_39, squeeze_13, unsqueeze_86, out_40, out_41], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf641, arg381_1, buf643, 8192, stream=raw_stream0)
        del arg381_1
        del buf639
        del buf640
        buf644 = reinterpret_tensor(buf620, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf620  # reuse
        # Topologically Sorted Source Nodes: [out_41, mixed_qkv_41, split_13, key_70, key_71, transpose_123, key_72, mul_298, sum_54], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf643, buf644, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg380_1, arg383_1, arg384_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf646 = buf613; del buf613  # reuse
        # Topologically Sorted Source Nodes: [float_114, exp_26, neg_21, a_13, float_115, add_199, softplus_13, g_13, transpose_126, getitem_212, exp_27], Original ATen: [aten._to_copy, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_17.run(buf634, arg380_1, arg383_1, arg384_1, buf646, 2, 1, 1, stream=raw_stream0)
        del arg380_1
        del arg383_1
        del arg384_1
        assert_size_stride(arg385_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf647 = buf619; del buf619  # reuse
        # Topologically Sorted Source Nodes: [out_41, mixed_qkv_41, split_13, key_70, key_71, transpose_123, key_72, add_201, inv_norm_27, key_73, k_t_13, float_114, exp_26, neg_21, a_13, float_115, add_199, softplus_13, g_13, transpose_126, getitem_212, exp_27, decay_t_13, last_recurrent_state_40, unsqueeze_88, mul_301, kv_mem_13], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg385_1, buf646, buf643, buf644, buf647, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg379_1, (32, 2560), (2560, 1), 'input')
        buf649 = reinterpret_tensor(buf610, (1, 32, 1), (32, 1, 32), 0); del buf610  # reuse
        # Topologically Sorted Source Nodes: [b_13, beta_26, transpose_125, beta_27], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf634, arg379_1, buf649, 2, 1, 1, stream=raw_stream0)
        del arg379_1
        buf650 = buf617; del buf617  # reuse
        # Topologically Sorted Source Nodes: [out_41, mixed_qkv_41, split_13, key_70, key_71, transpose_123, key_72, add_201, inv_norm_27, key_73, k_t_13, unsqueeze_89, value_44, transpose_124, value_45, v_t_13, float_114, exp_26, neg_21, a_13, float_115, add_199, softplus_13, g_13, transpose_126, getitem_212, exp_27, decay_t_13, last_recurrent_state_40, sub_13, b_13, beta_26, transpose_125, beta_27, getitem_214, beta_t_13, delta_13, unsqueeze_90, mul_303, last_recurrent_state_41], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg385_1, buf646, buf643, buf644, buf647, buf649, buf650, arg385_1, 524288, stream=raw_stream0)
        del arg385_1
        buf651 = reinterpret_tensor(buf649, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf649  # reuse
        # Topologically Sorted Source Nodes: [out_41, mixed_qkv_41, split_13, query_79, query_80, transpose_122, query_81, mul_296, sum_53], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf643, buf651, 32, 128, stream=raw_stream0)
        buf652 = buf647; del buf647  # reuse
        # Topologically Sorted Source Nodes: [out_41, mixed_qkv_41, split_13, query_79, query_80, transpose_122, query_81, add_200, inv_norm_26, query_82, query_83, q_t_13, unsqueeze_91, mul_304, sum_56], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf650, buf643, buf651, buf652, 4096, 128, stream=raw_stream0)
        buf653 = reinterpret_tensor(buf651, (32, 1), (1, 32), 0); del buf651  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_65, core_attn_out_66, core_attn_out_67, hidden_states_129, pow_57, variance_13], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf652, buf653, 32, 128, stream=raw_stream0)
        buf654 = buf634; del buf634  # reuse
        assert_size_stride(arg386_1, (128, ), (1, ), 'input')
        buf655 = buf602; del buf602  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_65, core_attn_out_66, core_attn_out_67, hidden_states_129, pow_57, variance_13, add_203, rsqrt_84, hidden_states_130, to_183, hidden_states_131, to_184, silu_44, hidden_states_132, core_attn_out_68, core_attn_out_69, output_194], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg386_1, buf652, buf653, buf637, buf655, 4096, stream=raw_stream0)
        del arg386_1
        assert_size_stride_grouped((arg387_1, arg388_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_65, core_attn_out_66, core_attn_out_67, hidden_states_129, pow_57, variance_13, add_203, rsqrt_84, hidden_states_130, to_183, hidden_states_131, to_184, silu_44, hidden_states_132, core_attn_out_68, core_attn_out_69, output_194], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf655, arg387_1, buf654, arg388_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg387_1
        del arg388_1
        assert_size_stride(arg389_1, (2560, ), (1, ), 'input')
        buf657 = buf587; del buf587  # reuse
        buf660 = buf542; del buf542  # reuse
        buf663 = buf516; del buf516  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_119, hidden_states_125, hidden_states_127, hidden_states_133, float_116, pow_58, mean_57, add_205, rsqrt_85, output_195, float_117, add_206, output_196, hidden_states_134, output_197, output_198], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf657, buf595, buf621, buf630, buf654, arg389_1, buf660, buf663, 1, 2560, stream=raw_stream0)
        del arg389_1
        buf659 = buf631; del buf631  # reuse
        assert_size_stride_grouped((arg390_1, arg391_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_116, pow_58, mean_57, add_205, rsqrt_85, output_195, float_117, add_206, output_196, hidden_states_134, output_197], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf660, arg390_1, buf659, arg391_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg390_1
        del arg391_1
        buf662 = buf628; del buf628  # reuse
        assert_size_stride_grouped((arg392_1, arg393_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_116, pow_58, mean_57, add_205, rsqrt_85, output_195, float_117, add_206, output_196, hidden_states_134, output_198], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf663, arg392_1, buf662, arg393_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg392_1
        del arg393_1
        buf665 = buf663; del buf663  # reuse
        buf666 = buf626; del buf626  # reuse
        # Topologically Sorted Source Nodes: [silu_45, mul_310, output_199], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf659, buf662, buf666, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg394_1, arg395_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_45, mul_310, output_199], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf666, arg394_1, buf665, arg395_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg394_1
        del arg395_1
        assert_size_stride(arg396_1, (2560, ), (1, ), 'input')
        buf670 = buf660; del buf660  # reuse
        buf673 = buf654; del buf654  # reuse
        buf681 = buf630; del buf630  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_135, float_118, pow_59, mean_58, add_208, rsqrt_86, output_200, float_119, add_209, output_201, hidden_states_136, output_202, output_203], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf657, buf665, arg396_1, buf670, buf673, buf681, 1, 2560, stream=raw_stream0)
        del arg396_1
        buf669 = reinterpret_tensor(buf643, (1, 1, 8192), (8192, 8192, 1), 0); del buf643  # reuse
        assert_size_stride_grouped((arg397_1, arg398_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_135, float_118, pow_59, mean_58, add_208, rsqrt_86, output_200, float_119, add_209, output_201, hidden_states_136, output_202], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf670, arg397_1, buf669, arg398_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg397_1
        del arg398_1
        buf672 = buf655; del buf655  # reuse
        assert_size_stride_grouped((arg399_1, arg400_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_135, float_118, pow_59, mean_58, add_208, rsqrt_86, output_200, float_119, add_209, output_201, hidden_states_136, output_203], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf673, arg399_1, buf672, arg400_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg399_1
        del arg400_1
        assert_size_stride(arg404_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf677 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf675 = reinterpret_tensor(buf677, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_32], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg404_1, buf675, 32768, stream=raw_stream0)
        buf676 = reinterpret_tensor(buf677, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_32], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf669, buf676, 8192, stream=raw_stream0)
        assert_size_stride(arg403_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf679 = reinterpret_tensor(buf669, (1, 8192, 1), (8192, 1, 8192), 0); del buf669  # reuse
        # Topologically Sorted Source Nodes: [out_42, squeeze_14, unsqueeze_92, out_43, out_44], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf677, arg403_1, buf679, 8192, stream=raw_stream0)
        del arg403_1
        del buf675
        del buf676
        buf680 = reinterpret_tensor(buf653, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf653  # reuse
        # Topologically Sorted Source Nodes: [out_44, mixed_qkv_44, split_14, key_75, key_76, transpose_131, key_77, mul_316, sum_58], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf679, buf680, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg402_1, arg405_1, arg406_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf683 = buf646; del buf646  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_135, float_118, pow_59, mean_58, add_208, rsqrt_86, output_200, float_119, add_209, output_201, hidden_states_136, float_120, exp_28, neg_22, a_14, float_121, add_210, softplus_14, g_14, transpose_134, getitem_223, exp_29], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf681, arg402_1, arg405_1, arg406_1, buf683, 2, 1, 1, stream=raw_stream0)
        del arg402_1
        del arg405_1
        del arg406_1
        assert_size_stride(arg407_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf684 = buf652; del buf652  # reuse
        # Topologically Sorted Source Nodes: [out_44, mixed_qkv_44, split_14, key_75, key_76, transpose_131, key_77, add_212, inv_norm_29, key_78, k_t_14, float_120, exp_28, neg_22, a_14, float_121, add_210, softplus_14, g_14, transpose_134, getitem_223, exp_29, decay_t_14, last_recurrent_state_43, unsqueeze_94, mul_319, kv_mem_14], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg407_1, buf683, buf679, buf680, buf684, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg401_1, (32, 2560), (2560, 1), 'input')
        buf686 = reinterpret_tensor(buf644, (1, 32, 1), (32, 1, 32), 0); del buf644  # reuse
        # Topologically Sorted Source Nodes: [b_14, beta_28, transpose_133, beta_29], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf681, arg401_1, buf686, 2, 1, 1, stream=raw_stream0)
        del arg401_1
        buf687 = buf650; del buf650  # reuse
        # Topologically Sorted Source Nodes: [out_44, mixed_qkv_44, split_14, key_75, key_76, transpose_131, key_77, add_212, inv_norm_29, key_78, k_t_14, unsqueeze_95, value_47, transpose_132, value_48, v_t_14, float_120, exp_28, neg_22, a_14, float_121, add_210, softplus_14, g_14, transpose_134, getitem_223, exp_29, decay_t_14, last_recurrent_state_43, sub_14, b_14, beta_28, transpose_133, beta_29, getitem_225, beta_t_14, delta_14, unsqueeze_96, mul_321, last_recurrent_state_44], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg407_1, buf683, buf679, buf680, buf684, buf686, buf687, arg407_1, 524288, stream=raw_stream0)
        del arg407_1
        buf688 = reinterpret_tensor(buf686, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf686  # reuse
        # Topologically Sorted Source Nodes: [out_44, mixed_qkv_44, split_14, query_85, query_86, transpose_130, query_87, mul_314, sum_57], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf679, buf688, 32, 128, stream=raw_stream0)
        buf689 = buf684; del buf684  # reuse
        # Topologically Sorted Source Nodes: [out_44, mixed_qkv_44, split_14, query_85, query_86, transpose_130, query_87, add_211, inv_norm_28, query_88, query_89, q_t_14, unsqueeze_97, mul_322, sum_60], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf687, buf679, buf688, buf689, 4096, 128, stream=raw_stream0)
        buf690 = reinterpret_tensor(buf688, (32, 1), (1, 32), 0); del buf688  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_70, core_attn_out_71, core_attn_out_72, hidden_states_137, pow_60, variance_14], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf689, buf690, 32, 128, stream=raw_stream0)
        buf691 = buf681; del buf681  # reuse
        assert_size_stride(arg408_1, (128, ), (1, ), 'input')
        buf692 = buf637; del buf637  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_70, core_attn_out_71, core_attn_out_72, hidden_states_137, pow_60, variance_14, add_214, rsqrt_89, hidden_states_138, to_196, hidden_states_139, to_197, silu_47, hidden_states_140, core_attn_out_73, core_attn_out_74, output_204], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg408_1, buf689, buf690, buf672, buf692, 4096, stream=raw_stream0)
        del arg408_1
        assert_size_stride_grouped((arg409_1, arg410_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_70, core_attn_out_71, core_attn_out_72, hidden_states_137, pow_60, variance_14, add_214, rsqrt_89, hidden_states_138, to_196, hidden_states_139, to_197, silu_47, hidden_states_140, core_attn_out_73, core_attn_out_74, output_204], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf692, arg409_1, buf691, arg410_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg409_1
        del arg410_1
        assert_size_stride(arg411_1, (2560, ), (1, ), 'input')
        buf695 = buf673; del buf673  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_135, hidden_states_141, float_122, pow_61, mean_60, add_216, rsqrt_90, output_205, float_123, add_217, output_206, hidden_states_142], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf657, buf665, buf691, arg411_1, buf695, 1, 2560, stream=raw_stream0)
        del arg411_1
        buf696 = buf666; del buf666  # reuse
        assert_size_stride_grouped((arg412_1, arg413_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_207], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf695, arg412_1, buf696, arg413_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg412_1
        del arg413_1
        buf698 = buf662; del buf662  # reuse
        assert_size_stride_grouped((arg414_1, arg415_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_208], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf695, arg414_1, buf698, arg415_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg414_1
        del arg415_1
        buf700 = buf695; del buf695  # reuse
        buf701 = buf659; del buf659  # reuse
        # Topologically Sorted Source Nodes: [silu_48, mul_328, output_209], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf696, buf698, buf701, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg416_1, arg417_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_48, mul_328, output_209], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf701, arg416_1, buf700, arg417_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg416_1
        del arg417_1
        assert_size_stride(arg418_1, (2560, ), (1, ), 'input')
        buf704 = buf670; del buf670  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_135, hidden_states_141, hidden_states_143, float_124, pow_62, mean_61, add_219, rsqrt_91, output_210, float_125, add_220, output_211, hidden_states_144], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf657, buf665, buf691, buf700, arg418_1, buf704, 1, 2560, stream=raw_stream0)
        del arg418_1
        buf705 = reinterpret_tensor(buf679, (1, 1, 8192), (8192, 8192, 1), 0); del buf679  # reuse
        assert_size_stride_grouped((arg419_1, arg420_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_212], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf704, arg419_1, buf705, arg420_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg419_1
        del arg420_1
        buf707 = buf560; del buf560  # reuse
        assert_size_stride_grouped((arg422_1, arg423_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_215], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf704, arg422_1, buf707, arg423_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg422_1
        del arg423_1
        buf709 = reinterpret_tensor(buf575, (1, 1, 1024), (1024, 1024, 1), 0); del buf575  # reuse
        assert_size_stride_grouped((arg425_1, arg426_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_218], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf704, arg425_1, buf709, arg426_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg425_1
        del arg426_1
        buf711 = reinterpret_tensor(buf581, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf581  # reuse
        # Topologically Sorted Source Nodes: [float_126, pow_63, mean_62], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_split_view_22.run(buf705, buf711, 16, 256, stream=raw_stream0)
        assert_size_stride(arg421_1, (256, ), (1, ), 'input')
        buf714 = reinterpret_tensor(buf558, (1, 16, 1, 64), (1024, 64, 64, 1), 0); del buf558  # reuse
        buf712 = reinterpret_tensor(buf714, (1, 16, 1, 32), (1024, 64, 64, 1), 0)  # alias
        buf713 = reinterpret_tensor(buf714, (1, 16, 1, 32), (1024, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_126, pow_63, mean_62, add_221, rsqrt_92, output_213, float_127, add_222, output_214, type_as_47, query_states_9, q_rot_4, x2_8, neg_23, x1_8, cat_33], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_23.run(buf705, buf711, arg421_1, buf712, buf713, 512, stream=raw_stream0)
        buf717 = reinterpret_tensor(buf692, (1, 16, 1, 256), (4096, 256, 256, 1), 0); del buf692  # reuse
        buf715 = reinterpret_tensor(buf717, (1, 16, 1, 64), (4096, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_126, pow_63, mean_62, add_221, rsqrt_92, output_213, float_127, add_222, output_214, type_as_47, query_states_9, q_rot_4, cos_8, mul_335, sin_8, mul_336, q_embed_8], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_24.run(buf705, buf711, arg421_1, buf1, buf714, buf0, buf715, 1024, stream=raw_stream0)
        del buf712
        del buf713
        buf716 = reinterpret_tensor(buf717, (1, 16, 1, 192), (4096, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_126, pow_63, mean_62, add_221, rsqrt_92, output_213, float_127, add_222, output_214, type_as_47, query_states_9, q_rot_4, cos_8, mul_335, sin_8, mul_336, q_embed_8, q_pass_4, q_embed_9], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_25.run(buf705, buf711, arg421_1, buf716, 3072, stream=raw_stream0)
        del arg421_1
        buf718 = buf569; del buf569  # reuse
        # Topologically Sorted Source Nodes: [float_128, pow_64, mean_63], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_26.run(buf707, buf718, 4, 256, stream=raw_stream0)
        del buf715
        del buf716
        assert_size_stride(arg424_1, (256, ), (1, ), 'input')
        buf721 = buf572; del buf572  # reuse
        buf719 = reinterpret_tensor(buf721, (1, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        buf720 = reinterpret_tensor(buf721, (1, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_128, pow_64, mean_63, add_223, rsqrt_93, output_216, float_129, add_224, output_217, type_as_48, key_states_4, k_rot_4, x2_9, neg_24, x1_9, cat_34], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_27.run(buf707, buf718, arg424_1, buf719, buf720, 128, stream=raw_stream0)
        buf724 = reinterpret_tensor(buf714, (1, 4, 1, 256), (1024, 256, 256, 1), 0); del buf714  # reuse
        buf722 = reinterpret_tensor(buf724, (1, 4, 1, 64), (1024, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_8, sin_8, float_128, pow_64, mean_63, add_223, rsqrt_93, output_216, float_129, add_224, output_217, type_as_48, key_states_4, k_rot_4, mul_337, mul_338, k_embed_8], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28.run(buf707, buf718, arg424_1, buf1, buf721, buf0, buf722, 256, stream=raw_stream0)
        del buf719
        del buf720
        buf723 = reinterpret_tensor(buf724, (1, 4, 1, 192), (1024, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_8, sin_8, float_128, pow_64, mean_63, add_223, rsqrt_93, output_216, float_129, add_224, output_217, type_as_48, key_states_4, k_rot_4, mul_337, mul_338, k_embed_8, k_pass_4, k_embed_9], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_29.run(buf707, buf718, arg424_1, buf723, 768, stream=raw_stream0)
        del arg424_1
        assert_size_stride_grouped((arg427_1, arg428_1), ((), (1, 4, 64, 256)), ((), (65536, 16384, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_8, cache_position_4, index_copy__8], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_30.run(arg427_1, buf724, arg428_1, 1024, stream=raw_stream0)
        del buf722
        del buf723
        buf726 = reinterpret_tensor(buf580, (16, 1, 64), (64, 64, 1), 0); del buf580  # reuse
        # Topologically Sorted Source Nodes: [attn_output_16, key_79], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_31.run(buf717, arg428_1, buf726, 1024, 256, stream=raw_stream0)
        del arg428_1
        buf727 = buf578; del buf578  # reuse
        buf729 = reinterpret_tensor(buf577, (1, 16, 1, 64), (1024, 64, 1024, 1), 0); del buf577  # reuse
        buf730 = reinterpret_tensor(buf711, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf711  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_16], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32.run(buf726, arg3_1, buf727, buf729, buf730, 16, 64, stream=raw_stream0)
        assert_size_stride(arg429_1, (1, 4, 64, 256), (65536, 16384, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_8, cache_position_4, index_copy__9], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_33.run(arg427_1, buf709, arg429_1, 1024, stream=raw_stream0)
        buf734 = reinterpret_tensor(buf717, (1, 1, 4096), (4096, 4096, 1), 0); del buf717  # reuse
        # Topologically Sorted Source Nodes: [gate_9, attn_output_16, value_49, transpose_139, reshape_124, sigmoid_19, attn_output_19, output_219], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34.run(buf727, buf729, buf730, arg429_1, buf705, buf734, 4096, 64, stream=raw_stream0)
        del arg429_1
        buf733 = buf704; del buf704  # reuse
        assert_size_stride_grouped((arg430_1, arg431_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [gate_9, attn_output_16, transpose_139, reshape_124, sigmoid_19, attn_output_19, output_219], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf734, arg430_1, buf733, arg431_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg430_1
        del arg431_1
        assert_size_stride(arg432_1, (2560, ), (1, ), 'input')
        buf736 = buf657; del buf657  # reuse
        buf739 = buf621; del buf621  # reuse
        buf742 = buf595; del buf595  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_135, hidden_states_141, hidden_states_143, hidden_states_147, float_130, pow_65, mean_64, add_229, rsqrt_94, output_220, float_131, add_230, output_221, hidden_states_148, output_222, output_223], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf736, buf665, buf691, buf700, buf733, arg432_1, buf739, buf742, 1, 2560, stream=raw_stream0)
        del arg432_1
        buf738 = buf701; del buf701  # reuse
        assert_size_stride_grouped((arg433_1, arg434_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_130, pow_65, mean_64, add_229, rsqrt_94, output_220, float_131, add_230, output_221, hidden_states_148, output_222], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf739, arg433_1, buf738, arg434_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg433_1
        del arg434_1
        buf741 = buf698; del buf698  # reuse
        assert_size_stride_grouped((arg435_1, arg436_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_130, pow_65, mean_64, add_229, rsqrt_94, output_220, float_131, add_230, output_221, hidden_states_148, output_223], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf742, arg435_1, buf741, arg436_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg435_1
        del arg436_1
        buf744 = buf742; del buf742  # reuse
        buf745 = buf696; del buf696  # reuse
        # Topologically Sorted Source Nodes: [silu_49, mul_342, output_224], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf738, buf741, buf745, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg437_1, arg438_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_49, mul_342, output_224], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf745, arg437_1, buf744, arg438_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg437_1
        del arg438_1
        assert_size_stride(arg439_1, (2560, ), (1, ), 'input')
        buf749 = buf739; del buf739  # reuse
        buf752 = buf733; del buf733  # reuse
        buf760 = buf700; del buf700  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_149, float_132, pow_66, mean_65, add_232, rsqrt_95, output_225, float_133, add_233, output_226, hidden_states_150, output_227, output_228], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf736, buf744, arg439_1, buf749, buf752, buf760, 1, 2560, stream=raw_stream0)
        del arg439_1
        buf748 = buf705; del buf705  # reuse
        assert_size_stride_grouped((arg440_1, arg441_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_149, float_132, pow_66, mean_65, add_232, rsqrt_95, output_225, float_133, add_233, output_226, hidden_states_150, output_227], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf749, arg440_1, buf748, arg441_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg440_1
        del arg441_1
        buf751 = buf734; del buf734  # reuse
        assert_size_stride_grouped((arg442_1, arg443_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_149, float_132, pow_66, mean_65, add_232, rsqrt_95, output_225, float_133, add_233, output_226, hidden_states_150, output_228], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf752, arg442_1, buf751, arg443_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg442_1
        del arg443_1
        assert_size_stride(arg447_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf756 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf754 = reinterpret_tensor(buf756, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_37], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg447_1, buf754, 32768, stream=raw_stream0)
        buf755 = reinterpret_tensor(buf756, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_37], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf748, buf755, 8192, stream=raw_stream0)
        assert_size_stride(arg446_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf758 = reinterpret_tensor(buf748, (1, 8192, 1), (8192, 1, 8192), 0); del buf748  # reuse
        # Topologically Sorted Source Nodes: [out_45, squeeze_15, unsqueeze_100, out_46, out_47], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf756, arg446_1, buf758, 8192, stream=raw_stream0)
        del arg446_1
        del buf754
        del buf755
        buf759 = reinterpret_tensor(buf690, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf690  # reuse
        # Topologically Sorted Source Nodes: [out_47, mixed_qkv_47, split_15, key_81, key_82, transpose_143, key_83, mul_348, sum_62], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf758, buf759, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg445_1, arg448_1, arg449_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf762 = buf683; del buf683  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_149, float_132, pow_66, mean_65, add_232, rsqrt_95, output_225, float_133, add_233, output_226, hidden_states_150, float_134, exp_30, neg_25, a_15, float_135, add_234, softplus_15, g_15, transpose_146, getitem_246, exp_31], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf760, arg445_1, arg448_1, arg449_1, buf762, 2, 1, 1, stream=raw_stream0)
        del arg445_1
        del arg448_1
        del arg449_1
        assert_size_stride(arg450_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf763 = buf689; del buf689  # reuse
        # Topologically Sorted Source Nodes: [out_47, mixed_qkv_47, split_15, key_81, key_82, transpose_143, key_83, add_236, inv_norm_31, key_84, k_t_15, float_134, exp_30, neg_25, a_15, float_135, add_234, softplus_15, g_15, transpose_146, getitem_246, exp_31, decay_t_15, last_recurrent_state_46, unsqueeze_102, mul_351, kv_mem_15], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg450_1, buf762, buf758, buf759, buf763, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg444_1, (32, 2560), (2560, 1), 'input')
        buf765 = reinterpret_tensor(buf680, (1, 32, 1), (32, 1, 32), 0); del buf680  # reuse
        # Topologically Sorted Source Nodes: [b_15, beta_30, transpose_145, beta_31], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf760, arg444_1, buf765, 2, 1, 1, stream=raw_stream0)
        del arg444_1
        buf766 = buf687; del buf687  # reuse
        # Topologically Sorted Source Nodes: [out_47, mixed_qkv_47, split_15, key_81, key_82, transpose_143, key_83, add_236, inv_norm_31, key_84, k_t_15, unsqueeze_103, value_51, transpose_144, value_52, v_t_15, float_134, exp_30, neg_25, a_15, float_135, add_234, softplus_15, g_15, transpose_146, getitem_246, exp_31, decay_t_15, last_recurrent_state_46, sub_15, b_15, beta_30, transpose_145, beta_31, getitem_248, beta_t_15, delta_15, unsqueeze_104, mul_353, last_recurrent_state_47], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg450_1, buf762, buf758, buf759, buf763, buf765, buf766, arg450_1, 524288, stream=raw_stream0)
        del arg450_1
        buf767 = reinterpret_tensor(buf765, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf765  # reuse
        # Topologically Sorted Source Nodes: [out_47, mixed_qkv_47, split_15, query_91, query_92, transpose_142, query_93, mul_346, sum_61], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf758, buf767, 32, 128, stream=raw_stream0)
        buf768 = buf763; del buf763  # reuse
        # Topologically Sorted Source Nodes: [out_47, mixed_qkv_47, split_15, query_91, query_92, transpose_142, query_93, add_235, inv_norm_30, query_94, query_95, q_t_15, unsqueeze_105, mul_354, sum_64], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf766, buf758, buf767, buf768, 4096, 128, stream=raw_stream0)
        buf769 = reinterpret_tensor(buf767, (32, 1), (1, 32), 0); del buf767  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_75, core_attn_out_76, core_attn_out_77, hidden_states_151, pow_67, variance_15], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf768, buf769, 32, 128, stream=raw_stream0)
        buf770 = buf760; del buf760  # reuse
        assert_size_stride(arg451_1, (128, ), (1, ), 'input')
        buf771 = buf672; del buf672  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_75, core_attn_out_76, core_attn_out_77, hidden_states_151, pow_67, variance_15, add_238, rsqrt_98, hidden_states_152, to_209, hidden_states_153, to_210, silu_51, hidden_states_154, core_attn_out_78, core_attn_out_79, output_229], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg451_1, buf768, buf769, buf751, buf771, 4096, stream=raw_stream0)
        del arg451_1
        assert_size_stride_grouped((arg452_1, arg453_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_75, core_attn_out_76, core_attn_out_77, hidden_states_151, pow_67, variance_15, add_238, rsqrt_98, hidden_states_152, to_209, hidden_states_153, to_210, silu_51, hidden_states_154, core_attn_out_78, core_attn_out_79, output_229], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf771, arg452_1, buf770, arg453_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg452_1
        del arg453_1
        assert_size_stride(arg454_1, (2560, ), (1, ), 'input')
        buf774 = buf752; del buf752  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_149, hidden_states_155, float_136, pow_68, mean_67, add_240, rsqrt_99, output_230, float_137, add_241, output_231, hidden_states_156], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf736, buf744, buf770, arg454_1, buf774, 1, 2560, stream=raw_stream0)
        del arg454_1
        buf775 = buf745; del buf745  # reuse
        assert_size_stride_grouped((arg455_1, arg456_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_232], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf774, arg455_1, buf775, arg456_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg455_1
        del arg456_1
        buf777 = buf741; del buf741  # reuse
        assert_size_stride_grouped((arg457_1, arg458_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_233], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf774, arg457_1, buf777, arg458_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg457_1
        del arg458_1
        buf779 = buf774; del buf774  # reuse
        buf780 = buf738; del buf738  # reuse
        # Topologically Sorted Source Nodes: [silu_52, mul_360, output_234], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf775, buf777, buf780, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg459_1, arg460_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_52, mul_360, output_234], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf780, arg459_1, buf779, arg460_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg459_1
        del arg460_1
        assert_size_stride(arg461_1, (2560, ), (1, ), 'input')
        buf783 = buf749; del buf749  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_149, hidden_states_155, hidden_states_157, float_138, pow_69, mean_68, add_243, rsqrt_100, output_235, float_139, add_244, output_236, hidden_states_158], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf736, buf744, buf770, buf779, arg461_1, buf783, 1, 2560, stream=raw_stream0)
        del arg461_1
        buf784 = reinterpret_tensor(buf758, (1, 1, 8192), (8192, 8192, 1), 0); del buf758  # reuse
        assert_size_stride_grouped((arg462_1, arg463_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_237], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf783, arg462_1, buf784, arg463_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg462_1
        del arg463_1
        buf786 = buf771; del buf771  # reuse
        assert_size_stride_grouped((arg464_1, arg465_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_238], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf783, arg464_1, buf786, arg465_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg464_1
        del arg465_1
        assert_size_stride(arg469_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf790 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf788 = reinterpret_tensor(buf790, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_38], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg469_1, buf788, 32768, stream=raw_stream0)
        buf789 = reinterpret_tensor(buf790, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_38], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf784, buf789, 8192, stream=raw_stream0)
        assert_size_stride(arg468_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf792 = reinterpret_tensor(buf784, (1, 8192, 1), (8192, 1, 8192), 0); del buf784  # reuse
        # Topologically Sorted Source Nodes: [out_48, squeeze_16, unsqueeze_106, out_49, out_50], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf790, arg468_1, buf792, 8192, stream=raw_stream0)
        del arg468_1
        del buf788
        del buf789
        buf793 = reinterpret_tensor(buf769, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf769  # reuse
        # Topologically Sorted Source Nodes: [out_50, mixed_qkv_50, split_16, key_86, key_87, transpose_151, key_88, mul_366, sum_66], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf792, buf793, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg467_1, arg470_1, arg471_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf795 = buf762; del buf762  # reuse
        # Topologically Sorted Source Nodes: [float_140, exp_32, neg_26, a_16, float_141, add_245, softplus_16, g_16, transpose_154, getitem_257, exp_33], Original ATen: [aten._to_copy, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_17.run(buf783, arg467_1, arg470_1, arg471_1, buf795, 2, 1, 1, stream=raw_stream0)
        del arg467_1
        del arg470_1
        del arg471_1
        assert_size_stride(arg472_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf796 = buf768; del buf768  # reuse
        # Topologically Sorted Source Nodes: [out_50, mixed_qkv_50, split_16, key_86, key_87, transpose_151, key_88, add_247, inv_norm_33, key_89, k_t_16, float_140, exp_32, neg_26, a_16, float_141, add_245, softplus_16, g_16, transpose_154, getitem_257, exp_33, decay_t_16, last_recurrent_state_49, unsqueeze_108, mul_369, kv_mem_16], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg472_1, buf795, buf792, buf793, buf796, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg466_1, (32, 2560), (2560, 1), 'input')
        buf798 = reinterpret_tensor(buf759, (1, 32, 1), (32, 1, 32), 0); del buf759  # reuse
        # Topologically Sorted Source Nodes: [b_16, beta_32, transpose_153, beta_33], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf783, arg466_1, buf798, 2, 1, 1, stream=raw_stream0)
        del arg466_1
        buf799 = buf766; del buf766  # reuse
        # Topologically Sorted Source Nodes: [out_50, mixed_qkv_50, split_16, key_86, key_87, transpose_151, key_88, add_247, inv_norm_33, key_89, k_t_16, unsqueeze_109, value_54, transpose_152, value_55, v_t_16, float_140, exp_32, neg_26, a_16, float_141, add_245, softplus_16, g_16, transpose_154, getitem_257, exp_33, decay_t_16, last_recurrent_state_49, sub_16, b_16, beta_32, transpose_153, beta_33, getitem_259, beta_t_16, delta_16, unsqueeze_110, mul_371, last_recurrent_state_50], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg472_1, buf795, buf792, buf793, buf796, buf798, buf799, arg472_1, 524288, stream=raw_stream0)
        del arg472_1
        buf800 = reinterpret_tensor(buf798, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf798  # reuse
        # Topologically Sorted Source Nodes: [out_50, mixed_qkv_50, split_16, query_97, query_98, transpose_150, query_99, mul_364, sum_65], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf792, buf800, 32, 128, stream=raw_stream0)
        buf801 = buf796; del buf796  # reuse
        # Topologically Sorted Source Nodes: [out_50, mixed_qkv_50, split_16, query_97, query_98, transpose_150, query_99, add_246, inv_norm_32, query_100, query_101, q_t_16, unsqueeze_111, mul_372, sum_68], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf799, buf792, buf800, buf801, 4096, 128, stream=raw_stream0)
        buf802 = reinterpret_tensor(buf800, (32, 1), (1, 32), 0); del buf800  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_80, core_attn_out_81, core_attn_out_82, hidden_states_159, pow_70, variance_16], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf801, buf802, 32, 128, stream=raw_stream0)
        buf803 = buf783; del buf783  # reuse
        assert_size_stride(arg473_1, (128, ), (1, ), 'input')
        buf804 = buf751; del buf751  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_80, core_attn_out_81, core_attn_out_82, hidden_states_159, pow_70, variance_16, add_249, rsqrt_103, hidden_states_160, to_222, hidden_states_161, to_223, silu_54, hidden_states_162, core_attn_out_83, core_attn_out_84, output_239], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg473_1, buf801, buf802, buf786, buf804, 4096, stream=raw_stream0)
        del arg473_1
        assert_size_stride_grouped((arg474_1, arg475_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_80, core_attn_out_81, core_attn_out_82, hidden_states_159, pow_70, variance_16, add_249, rsqrt_103, hidden_states_160, to_222, hidden_states_161, to_223, silu_54, hidden_states_162, core_attn_out_83, core_attn_out_84, output_239], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf804, arg474_1, buf803, arg475_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg474_1
        del arg475_1
        assert_size_stride(arg476_1, (2560, ), (1, ), 'input')
        buf806 = buf736; del buf736  # reuse
        buf809 = buf691; del buf691  # reuse
        buf812 = buf665; del buf665  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_149, hidden_states_155, hidden_states_157, hidden_states_163, float_142, pow_71, mean_70, add_251, rsqrt_104, output_240, float_143, add_252, output_241, hidden_states_164, output_242, output_243], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf806, buf744, buf770, buf779, buf803, arg476_1, buf809, buf812, 1, 2560, stream=raw_stream0)
        del arg476_1
        buf808 = buf780; del buf780  # reuse
        assert_size_stride_grouped((arg477_1, arg478_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_142, pow_71, mean_70, add_251, rsqrt_104, output_240, float_143, add_252, output_241, hidden_states_164, output_242], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf809, arg477_1, buf808, arg478_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg477_1
        del arg478_1
        buf811 = buf777; del buf777  # reuse
        assert_size_stride_grouped((arg479_1, arg480_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_142, pow_71, mean_70, add_251, rsqrt_104, output_240, float_143, add_252, output_241, hidden_states_164, output_243], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf812, arg479_1, buf811, arg480_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg479_1
        del arg480_1
        buf814 = buf812; del buf812  # reuse
        buf815 = buf775; del buf775  # reuse
        # Topologically Sorted Source Nodes: [silu_55, mul_378, output_244], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf808, buf811, buf815, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg481_1, arg482_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_55, mul_378, output_244], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf815, arg481_1, buf814, arg482_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg481_1
        del arg482_1
        assert_size_stride(arg483_1, (2560, ), (1, ), 'input')
        buf819 = buf809; del buf809  # reuse
        buf822 = buf803; del buf803  # reuse
        buf830 = buf779; del buf779  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_165, float_144, pow_72, mean_71, add_254, rsqrt_105, output_245, float_145, add_255, output_246, hidden_states_166, output_247, output_248], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf806, buf814, arg483_1, buf819, buf822, buf830, 1, 2560, stream=raw_stream0)
        del arg483_1
        buf818 = reinterpret_tensor(buf792, (1, 1, 8192), (8192, 8192, 1), 0); del buf792  # reuse
        assert_size_stride_grouped((arg484_1, arg485_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_165, float_144, pow_72, mean_71, add_254, rsqrt_105, output_245, float_145, add_255, output_246, hidden_states_166, output_247], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf819, arg484_1, buf818, arg485_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg484_1
        del arg485_1
        buf821 = buf804; del buf804  # reuse
        assert_size_stride_grouped((arg486_1, arg487_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_165, float_144, pow_72, mean_71, add_254, rsqrt_105, output_245, float_145, add_255, output_246, hidden_states_166, output_248], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf822, arg486_1, buf821, arg487_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg486_1
        del arg487_1
        assert_size_stride(arg491_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf826 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf824 = reinterpret_tensor(buf826, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_39], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg491_1, buf824, 32768, stream=raw_stream0)
        buf825 = reinterpret_tensor(buf826, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_39], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf818, buf825, 8192, stream=raw_stream0)
        assert_size_stride(arg490_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf828 = reinterpret_tensor(buf818, (1, 8192, 1), (8192, 1, 8192), 0); del buf818  # reuse
        # Topologically Sorted Source Nodes: [out_51, squeeze_17, unsqueeze_112, out_52, out_53], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf826, arg490_1, buf828, 8192, stream=raw_stream0)
        del arg490_1
        del buf824
        del buf825
        buf829 = reinterpret_tensor(buf802, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf802  # reuse
        # Topologically Sorted Source Nodes: [out_53, mixed_qkv_53, split_17, key_91, key_92, transpose_159, key_93, mul_384, sum_70], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf828, buf829, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg489_1, arg492_1, arg493_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf832 = buf795; del buf795  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_165, float_144, pow_72, mean_71, add_254, rsqrt_105, output_245, float_145, add_255, output_246, hidden_states_166, float_146, exp_34, neg_27, a_17, float_147, add_256, softplus_17, g_17, transpose_162, getitem_268, exp_35], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf830, arg489_1, arg492_1, arg493_1, buf832, 2, 1, 1, stream=raw_stream0)
        del arg489_1
        del arg492_1
        del arg493_1
        assert_size_stride(arg494_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf833 = buf801; del buf801  # reuse
        # Topologically Sorted Source Nodes: [out_53, mixed_qkv_53, split_17, key_91, key_92, transpose_159, key_93, add_258, inv_norm_35, key_94, k_t_17, float_146, exp_34, neg_27, a_17, float_147, add_256, softplus_17, g_17, transpose_162, getitem_268, exp_35, decay_t_17, last_recurrent_state_52, unsqueeze_114, mul_387, kv_mem_17], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg494_1, buf832, buf828, buf829, buf833, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg488_1, (32, 2560), (2560, 1), 'input')
        buf835 = reinterpret_tensor(buf793, (1, 32, 1), (32, 1, 32), 0); del buf793  # reuse
        # Topologically Sorted Source Nodes: [b_17, beta_34, transpose_161, beta_35], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf830, arg488_1, buf835, 2, 1, 1, stream=raw_stream0)
        del arg488_1
        buf836 = buf799; del buf799  # reuse
        # Topologically Sorted Source Nodes: [out_53, mixed_qkv_53, split_17, key_91, key_92, transpose_159, key_93, add_258, inv_norm_35, key_94, k_t_17, unsqueeze_115, value_57, transpose_160, value_58, v_t_17, float_146, exp_34, neg_27, a_17, float_147, add_256, softplus_17, g_17, transpose_162, getitem_268, exp_35, decay_t_17, last_recurrent_state_52, sub_17, b_17, beta_34, transpose_161, beta_35, getitem_270, beta_t_17, delta_17, unsqueeze_116, mul_389, last_recurrent_state_53], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg494_1, buf832, buf828, buf829, buf833, buf835, buf836, arg494_1, 524288, stream=raw_stream0)
        del arg494_1
        buf837 = reinterpret_tensor(buf835, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf835  # reuse
        # Topologically Sorted Source Nodes: [out_53, mixed_qkv_53, split_17, query_103, query_104, transpose_158, query_105, mul_382, sum_69], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf828, buf837, 32, 128, stream=raw_stream0)
        buf838 = buf833; del buf833  # reuse
        # Topologically Sorted Source Nodes: [out_53, mixed_qkv_53, split_17, query_103, query_104, transpose_158, query_105, add_257, inv_norm_34, query_106, query_107, q_t_17, unsqueeze_117, mul_390, sum_72], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf836, buf828, buf837, buf838, 4096, 128, stream=raw_stream0)
        buf839 = reinterpret_tensor(buf837, (32, 1), (1, 32), 0); del buf837  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_85, core_attn_out_86, core_attn_out_87, hidden_states_167, pow_73, variance_17], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf838, buf839, 32, 128, stream=raw_stream0)
        buf840 = buf830; del buf830  # reuse
        assert_size_stride(arg495_1, (128, ), (1, ), 'input')
        buf841 = buf786; del buf786  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_85, core_attn_out_86, core_attn_out_87, hidden_states_167, pow_73, variance_17, add_260, rsqrt_108, hidden_states_168, to_235, hidden_states_169, to_236, silu_57, hidden_states_170, core_attn_out_88, core_attn_out_89, output_249], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg495_1, buf838, buf839, buf821, buf841, 4096, stream=raw_stream0)
        del arg495_1
        assert_size_stride_grouped((arg496_1, arg497_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_85, core_attn_out_86, core_attn_out_87, hidden_states_167, pow_73, variance_17, add_260, rsqrt_108, hidden_states_168, to_235, hidden_states_169, to_236, silu_57, hidden_states_170, core_attn_out_88, core_attn_out_89, output_249], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf841, arg496_1, buf840, arg497_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg496_1
        del arg497_1
        assert_size_stride(arg498_1, (2560, ), (1, ), 'input')
        buf844 = buf822; del buf822  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_165, hidden_states_171, float_148, pow_74, mean_73, add_262, rsqrt_109, output_250, float_149, add_263, output_251, hidden_states_172], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf806, buf814, buf840, arg498_1, buf844, 1, 2560, stream=raw_stream0)
        del arg498_1
        buf845 = buf815; del buf815  # reuse
        assert_size_stride_grouped((arg499_1, arg500_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_252], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf844, arg499_1, buf845, arg500_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg499_1
        del arg500_1
        buf847 = buf811; del buf811  # reuse
        assert_size_stride_grouped((arg501_1, arg502_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_253], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf844, arg501_1, buf847, arg502_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg501_1
        del arg502_1
        buf849 = buf844; del buf844  # reuse
        buf850 = buf808; del buf808  # reuse
        # Topologically Sorted Source Nodes: [silu_58, mul_396, output_254], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf845, buf847, buf850, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg503_1, arg504_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_58, mul_396, output_254], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf850, arg503_1, buf849, arg504_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg503_1
        del arg504_1
        assert_size_stride(arg505_1, (2560, ), (1, ), 'input')
        buf853 = buf819; del buf819  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_165, hidden_states_171, hidden_states_173, float_150, pow_75, mean_74, add_265, rsqrt_110, output_255, float_151, add_266, output_256, hidden_states_174], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf806, buf814, buf840, buf849, arg505_1, buf853, 1, 2560, stream=raw_stream0)
        del arg505_1
        buf854 = reinterpret_tensor(buf828, (1, 1, 8192), (8192, 8192, 1), 0); del buf828  # reuse
        assert_size_stride_grouped((arg506_1, arg507_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_257], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf853, arg506_1, buf854, arg507_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg506_1
        del arg507_1
        buf856 = buf709; del buf709  # reuse
        assert_size_stride_grouped((arg509_1, arg510_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_260], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf853, arg509_1, buf856, arg510_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg509_1
        del arg510_1
        buf858 = reinterpret_tensor(buf724, (1, 1, 1024), (1024, 1024, 1), 0); del buf724  # reuse
        assert_size_stride_grouped((arg512_1, arg513_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_263], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf853, arg512_1, buf858, arg513_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg512_1
        del arg513_1
        buf860 = reinterpret_tensor(buf730, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf730  # reuse
        # Topologically Sorted Source Nodes: [float_152, pow_76, mean_75], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_split_view_22.run(buf854, buf860, 16, 256, stream=raw_stream0)
        assert_size_stride(arg508_1, (256, ), (1, ), 'input')
        buf863 = reinterpret_tensor(buf707, (1, 16, 1, 64), (1024, 64, 64, 1), 0); del buf707  # reuse
        buf861 = reinterpret_tensor(buf863, (1, 16, 1, 32), (1024, 64, 64, 1), 0)  # alias
        buf862 = reinterpret_tensor(buf863, (1, 16, 1, 32), (1024, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_152, pow_76, mean_75, add_267, rsqrt_111, output_258, float_153, add_268, output_259, type_as_57, query_states_11, q_rot_5, x2_10, neg_28, x1_10, cat_40], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_23.run(buf854, buf860, arg508_1, buf861, buf862, 512, stream=raw_stream0)
        buf866 = reinterpret_tensor(buf841, (1, 16, 1, 256), (4096, 256, 256, 1), 0); del buf841  # reuse
        buf864 = reinterpret_tensor(buf866, (1, 16, 1, 64), (4096, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_152, pow_76, mean_75, add_267, rsqrt_111, output_258, float_153, add_268, output_259, type_as_57, query_states_11, q_rot_5, cos_9, mul_403, sin_9, mul_404, q_embed_10], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_24.run(buf854, buf860, arg508_1, buf1, buf863, buf0, buf864, 1024, stream=raw_stream0)
        del buf861
        del buf862
        buf865 = reinterpret_tensor(buf866, (1, 16, 1, 192), (4096, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_152, pow_76, mean_75, add_267, rsqrt_111, output_258, float_153, add_268, output_259, type_as_57, query_states_11, q_rot_5, cos_9, mul_403, sin_9, mul_404, q_embed_10, q_pass_5, q_embed_11], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_25.run(buf854, buf860, arg508_1, buf865, 3072, stream=raw_stream0)
        del arg508_1
        buf867 = buf718; del buf718  # reuse
        # Topologically Sorted Source Nodes: [float_154, pow_77, mean_76], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_26.run(buf856, buf867, 4, 256, stream=raw_stream0)
        del buf864
        del buf865
        assert_size_stride(arg511_1, (256, ), (1, ), 'input')
        buf870 = buf721; del buf721  # reuse
        buf868 = reinterpret_tensor(buf870, (1, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        buf869 = reinterpret_tensor(buf870, (1, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_154, pow_77, mean_76, add_269, rsqrt_112, output_261, float_155, add_270, output_262, type_as_58, key_states_5, k_rot_5, x2_11, neg_29, x1_11, cat_41], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_27.run(buf856, buf867, arg511_1, buf868, buf869, 128, stream=raw_stream0)
        buf873 = reinterpret_tensor(buf863, (1, 4, 1, 256), (1024, 256, 256, 1), 0); del buf863  # reuse
        buf871 = reinterpret_tensor(buf873, (1, 4, 1, 64), (1024, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_9, sin_9, float_154, pow_77, mean_76, add_269, rsqrt_112, output_261, float_155, add_270, output_262, type_as_58, key_states_5, k_rot_5, mul_405, mul_406, k_embed_10], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28.run(buf856, buf867, arg511_1, buf1, buf870, buf0, buf871, 256, stream=raw_stream0)
        del buf868
        del buf869
        buf872 = reinterpret_tensor(buf873, (1, 4, 1, 192), (1024, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_9, sin_9, float_154, pow_77, mean_76, add_269, rsqrt_112, output_261, float_155, add_270, output_262, type_as_58, key_states_5, k_rot_5, mul_405, mul_406, k_embed_10, k_pass_5, k_embed_11], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_29.run(buf856, buf867, arg511_1, buf872, 768, stream=raw_stream0)
        del arg511_1
        assert_size_stride_grouped((arg514_1, arg515_1), ((), (1, 4, 64, 256)), ((), (65536, 16384, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_9, cache_position_5, index_copy__10], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_30.run(arg514_1, buf873, arg515_1, 1024, stream=raw_stream0)
        del buf871
        del buf872
        buf875 = reinterpret_tensor(buf729, (16, 1, 64), (64, 64, 1), 0); del buf729  # reuse
        # Topologically Sorted Source Nodes: [attn_output_20, key_95], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_31.run(buf866, arg515_1, buf875, 1024, 256, stream=raw_stream0)
        del arg515_1
        buf876 = buf727; del buf727  # reuse
        buf878 = reinterpret_tensor(buf726, (1, 16, 1, 64), (1024, 64, 1024, 1), 0); del buf726  # reuse
        buf879 = reinterpret_tensor(buf860, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf860  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_20], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32.run(buf875, arg3_1, buf876, buf878, buf879, 16, 64, stream=raw_stream0)
        assert_size_stride(arg516_1, (1, 4, 64, 256), (65536, 16384, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_9, cache_position_5, index_copy__11], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_33.run(arg514_1, buf858, arg516_1, 1024, stream=raw_stream0)
        buf883 = reinterpret_tensor(buf866, (1, 1, 4096), (4096, 4096, 1), 0); del buf866  # reuse
        # Topologically Sorted Source Nodes: [gate_11, attn_output_20, value_59, transpose_167, reshape_149, sigmoid_23, attn_output_23, output_264], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34.run(buf876, buf878, buf879, arg516_1, buf854, buf883, 4096, 64, stream=raw_stream0)
        del arg516_1
        buf882 = buf853; del buf853  # reuse
        assert_size_stride_grouped((arg517_1, arg518_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [gate_11, attn_output_20, transpose_167, reshape_149, sigmoid_23, attn_output_23, output_264], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf883, arg517_1, buf882, arg518_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg517_1
        del arg518_1
        assert_size_stride(arg519_1, (2560, ), (1, ), 'input')
        buf885 = buf806; del buf806  # reuse
        buf888 = buf770; del buf770  # reuse
        buf891 = buf744; del buf744  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_165, hidden_states_171, hidden_states_173, hidden_states_177, float_156, pow_78, mean_77, add_275, rsqrt_113, output_265, float_157, add_276, output_266, hidden_states_178, output_267, output_268], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf885, buf814, buf840, buf849, buf882, arg519_1, buf888, buf891, 1, 2560, stream=raw_stream0)
        del arg519_1
        buf887 = buf850; del buf850  # reuse
        assert_size_stride_grouped((arg520_1, arg521_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_156, pow_78, mean_77, add_275, rsqrt_113, output_265, float_157, add_276, output_266, hidden_states_178, output_267], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf888, arg520_1, buf887, arg521_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg520_1
        del arg521_1
        buf890 = buf847; del buf847  # reuse
        assert_size_stride_grouped((arg522_1, arg523_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_156, pow_78, mean_77, add_275, rsqrt_113, output_265, float_157, add_276, output_266, hidden_states_178, output_268], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf891, arg522_1, buf890, arg523_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg522_1
        del arg523_1
        buf893 = buf891; del buf891  # reuse
        buf894 = buf845; del buf845  # reuse
        # Topologically Sorted Source Nodes: [silu_59, mul_410, output_269], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf887, buf890, buf894, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg524_1, arg525_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_59, mul_410, output_269], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf894, arg524_1, buf893, arg525_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg524_1
        del arg525_1
        assert_size_stride(arg526_1, (2560, ), (1, ), 'input')
        buf898 = buf888; del buf888  # reuse
        buf901 = buf882; del buf882  # reuse
        buf909 = buf849; del buf849  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_179, float_158, pow_79, mean_78, add_278, rsqrt_114, output_270, float_159, add_279, output_271, hidden_states_180, output_272, output_273], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf885, buf893, arg526_1, buf898, buf901, buf909, 1, 2560, stream=raw_stream0)
        del arg526_1
        buf897 = buf854; del buf854  # reuse
        assert_size_stride_grouped((arg527_1, arg528_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_179, float_158, pow_79, mean_78, add_278, rsqrt_114, output_270, float_159, add_279, output_271, hidden_states_180, output_272], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf898, arg527_1, buf897, arg528_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg527_1
        del arg528_1
        buf900 = buf883; del buf883  # reuse
        assert_size_stride_grouped((arg529_1, arg530_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_179, float_158, pow_79, mean_78, add_278, rsqrt_114, output_270, float_159, add_279, output_271, hidden_states_180, output_273], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf901, arg529_1, buf900, arg530_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg529_1
        del arg530_1
        assert_size_stride(arg534_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf905 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf903 = reinterpret_tensor(buf905, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_44], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg534_1, buf903, 32768, stream=raw_stream0)
        buf904 = reinterpret_tensor(buf905, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_44], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf897, buf904, 8192, stream=raw_stream0)
        assert_size_stride(arg533_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf907 = reinterpret_tensor(buf897, (1, 8192, 1), (8192, 1, 8192), 0); del buf897  # reuse
        # Topologically Sorted Source Nodes: [out_54, squeeze_18, unsqueeze_120, out_55, out_56], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf905, arg533_1, buf907, 8192, stream=raw_stream0)
        del arg533_1
        del buf903
        del buf904
        buf908 = reinterpret_tensor(buf839, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf839  # reuse
        # Topologically Sorted Source Nodes: [out_56, mixed_qkv_56, split_18, key_97, key_98, transpose_171, key_99, mul_416, sum_74], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf907, buf908, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg532_1, arg535_1, arg536_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf911 = buf832; del buf832  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_179, float_158, pow_79, mean_78, add_278, rsqrt_114, output_270, float_159, add_279, output_271, hidden_states_180, float_160, exp_36, neg_30, a_18, float_161, add_280, softplus_18, g_18, transpose_174, getitem_291, exp_37], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf909, arg532_1, arg535_1, arg536_1, buf911, 2, 1, 1, stream=raw_stream0)
        del arg532_1
        del arg535_1
        del arg536_1
        assert_size_stride(arg537_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf912 = buf838; del buf838  # reuse
        # Topologically Sorted Source Nodes: [out_56, mixed_qkv_56, split_18, key_97, key_98, transpose_171, key_99, add_282, inv_norm_37, key_100, k_t_18, float_160, exp_36, neg_30, a_18, float_161, add_280, softplus_18, g_18, transpose_174, getitem_291, exp_37, decay_t_18, last_recurrent_state_55, unsqueeze_122, mul_419, kv_mem_18], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg537_1, buf911, buf907, buf908, buf912, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg531_1, (32, 2560), (2560, 1), 'input')
        buf914 = reinterpret_tensor(buf829, (1, 32, 1), (32, 1, 32), 0); del buf829  # reuse
        # Topologically Sorted Source Nodes: [b_18, beta_36, transpose_173, beta_37], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf909, arg531_1, buf914, 2, 1, 1, stream=raw_stream0)
        del arg531_1
        buf915 = buf836; del buf836  # reuse
        # Topologically Sorted Source Nodes: [out_56, mixed_qkv_56, split_18, key_97, key_98, transpose_171, key_99, add_282, inv_norm_37, key_100, k_t_18, unsqueeze_123, value_61, transpose_172, value_62, v_t_18, float_160, exp_36, neg_30, a_18, float_161, add_280, softplus_18, g_18, transpose_174, getitem_291, exp_37, decay_t_18, last_recurrent_state_55, sub_18, b_18, beta_36, transpose_173, beta_37, getitem_293, beta_t_18, delta_18, unsqueeze_124, mul_421, last_recurrent_state_56], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg537_1, buf911, buf907, buf908, buf912, buf914, buf915, arg537_1, 524288, stream=raw_stream0)
        del arg537_1
        buf916 = reinterpret_tensor(buf914, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf914  # reuse
        # Topologically Sorted Source Nodes: [out_56, mixed_qkv_56, split_18, query_109, query_110, transpose_170, query_111, mul_414, sum_73], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf907, buf916, 32, 128, stream=raw_stream0)
        buf917 = buf912; del buf912  # reuse
        # Topologically Sorted Source Nodes: [out_56, mixed_qkv_56, split_18, query_109, query_110, transpose_170, query_111, add_281, inv_norm_36, query_112, query_113, q_t_18, unsqueeze_125, mul_422, sum_76], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf915, buf907, buf916, buf917, 4096, 128, stream=raw_stream0)
        buf918 = reinterpret_tensor(buf916, (32, 1), (1, 32), 0); del buf916  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_90, core_attn_out_91, core_attn_out_92, hidden_states_181, pow_80, variance_18], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf917, buf918, 32, 128, stream=raw_stream0)
        buf919 = buf909; del buf909  # reuse
        assert_size_stride(arg538_1, (128, ), (1, ), 'input')
        buf920 = buf821; del buf821  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_90, core_attn_out_91, core_attn_out_92, hidden_states_181, pow_80, variance_18, add_284, rsqrt_117, hidden_states_182, to_248, hidden_states_183, to_249, silu_61, hidden_states_184, core_attn_out_93, core_attn_out_94, output_274], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg538_1, buf917, buf918, buf900, buf920, 4096, stream=raw_stream0)
        del arg538_1
        assert_size_stride_grouped((arg539_1, arg540_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_90, core_attn_out_91, core_attn_out_92, hidden_states_181, pow_80, variance_18, add_284, rsqrt_117, hidden_states_182, to_248, hidden_states_183, to_249, silu_61, hidden_states_184, core_attn_out_93, core_attn_out_94, output_274], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf920, arg539_1, buf919, arg540_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg539_1
        del arg540_1
        assert_size_stride(arg541_1, (2560, ), (1, ), 'input')
        buf923 = buf901; del buf901  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_179, hidden_states_185, float_162, pow_81, mean_80, add_286, rsqrt_118, output_275, float_163, add_287, output_276, hidden_states_186], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf885, buf893, buf919, arg541_1, buf923, 1, 2560, stream=raw_stream0)
        del arg541_1
        buf924 = buf894; del buf894  # reuse
        assert_size_stride_grouped((arg542_1, arg543_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_277], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf923, arg542_1, buf924, arg543_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg542_1
        del arg543_1
        buf926 = buf890; del buf890  # reuse
        assert_size_stride_grouped((arg544_1, arg545_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_278], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf923, arg544_1, buf926, arg545_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg544_1
        del arg545_1
        buf928 = buf923; del buf923  # reuse
        buf929 = buf887; del buf887  # reuse
        # Topologically Sorted Source Nodes: [silu_62, mul_428, output_279], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf924, buf926, buf929, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg546_1, arg547_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_62, mul_428, output_279], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf929, arg546_1, buf928, arg547_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg546_1
        del arg547_1
        assert_size_stride(arg548_1, (2560, ), (1, ), 'input')
        buf932 = buf898; del buf898  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_179, hidden_states_185, hidden_states_187, float_164, pow_82, mean_81, add_289, rsqrt_119, output_280, float_165, add_290, output_281, hidden_states_188], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf885, buf893, buf919, buf928, arg548_1, buf932, 1, 2560, stream=raw_stream0)
        del arg548_1
        buf933 = reinterpret_tensor(buf907, (1, 1, 8192), (8192, 8192, 1), 0); del buf907  # reuse
        assert_size_stride_grouped((arg549_1, arg550_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_282], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf932, arg549_1, buf933, arg550_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg549_1
        del arg550_1
        buf935 = buf920; del buf920  # reuse
        assert_size_stride_grouped((arg551_1, arg552_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_283], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf932, arg551_1, buf935, arg552_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg551_1
        del arg552_1
        assert_size_stride(arg556_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf939 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf937 = reinterpret_tensor(buf939, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_45], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg556_1, buf937, 32768, stream=raw_stream0)
        buf938 = reinterpret_tensor(buf939, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_45], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf933, buf938, 8192, stream=raw_stream0)
        assert_size_stride(arg555_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf941 = reinterpret_tensor(buf933, (1, 8192, 1), (8192, 1, 8192), 0); del buf933  # reuse
        # Topologically Sorted Source Nodes: [out_57, squeeze_19, unsqueeze_126, out_58, out_59], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf939, arg555_1, buf941, 8192, stream=raw_stream0)
        del arg555_1
        del buf937
        del buf938
        buf942 = reinterpret_tensor(buf918, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf918  # reuse
        # Topologically Sorted Source Nodes: [out_59, mixed_qkv_59, split_19, key_102, key_103, transpose_179, key_104, mul_434, sum_78], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf941, buf942, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg554_1, arg557_1, arg558_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf944 = buf911; del buf911  # reuse
        # Topologically Sorted Source Nodes: [float_166, exp_38, neg_31, a_19, float_167, add_291, softplus_19, g_19, transpose_182, getitem_302, exp_39], Original ATen: [aten._to_copy, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_17.run(buf932, arg554_1, arg557_1, arg558_1, buf944, 2, 1, 1, stream=raw_stream0)
        del arg554_1
        del arg557_1
        del arg558_1
        assert_size_stride(arg559_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf945 = buf917; del buf917  # reuse
        # Topologically Sorted Source Nodes: [out_59, mixed_qkv_59, split_19, key_102, key_103, transpose_179, key_104, add_293, inv_norm_39, key_105, k_t_19, float_166, exp_38, neg_31, a_19, float_167, add_291, softplus_19, g_19, transpose_182, getitem_302, exp_39, decay_t_19, last_recurrent_state_58, unsqueeze_128, mul_437, kv_mem_19], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg559_1, buf944, buf941, buf942, buf945, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg553_1, (32, 2560), (2560, 1), 'input')
        buf947 = reinterpret_tensor(buf908, (1, 32, 1), (32, 1, 32), 0); del buf908  # reuse
        # Topologically Sorted Source Nodes: [b_19, beta_38, transpose_181, beta_39], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf932, arg553_1, buf947, 2, 1, 1, stream=raw_stream0)
        del arg553_1
        buf948 = buf915; del buf915  # reuse
        # Topologically Sorted Source Nodes: [out_59, mixed_qkv_59, split_19, key_102, key_103, transpose_179, key_104, add_293, inv_norm_39, key_105, k_t_19, unsqueeze_129, value_64, transpose_180, value_65, v_t_19, float_166, exp_38, neg_31, a_19, float_167, add_291, softplus_19, g_19, transpose_182, getitem_302, exp_39, decay_t_19, last_recurrent_state_58, sub_19, b_19, beta_38, transpose_181, beta_39, getitem_304, beta_t_19, delta_19, unsqueeze_130, mul_439, last_recurrent_state_59], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg559_1, buf944, buf941, buf942, buf945, buf947, buf948, arg559_1, 524288, stream=raw_stream0)
        del arg559_1
        buf949 = reinterpret_tensor(buf947, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf947  # reuse
        # Topologically Sorted Source Nodes: [out_59, mixed_qkv_59, split_19, query_115, query_116, transpose_178, query_117, mul_432, sum_77], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf941, buf949, 32, 128, stream=raw_stream0)
        buf950 = buf945; del buf945  # reuse
        # Topologically Sorted Source Nodes: [out_59, mixed_qkv_59, split_19, query_115, query_116, transpose_178, query_117, add_292, inv_norm_38, query_118, query_119, q_t_19, unsqueeze_131, mul_440, sum_80], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf948, buf941, buf949, buf950, 4096, 128, stream=raw_stream0)
        buf951 = reinterpret_tensor(buf949, (32, 1), (1, 32), 0); del buf949  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_95, core_attn_out_96, core_attn_out_97, hidden_states_189, pow_83, variance_19], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf950, buf951, 32, 128, stream=raw_stream0)
        buf952 = buf932; del buf932  # reuse
        assert_size_stride(arg560_1, (128, ), (1, ), 'input')
        buf953 = buf900; del buf900  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_95, core_attn_out_96, core_attn_out_97, hidden_states_189, pow_83, variance_19, add_295, rsqrt_122, hidden_states_190, to_261, hidden_states_191, to_262, silu_64, hidden_states_192, core_attn_out_98, core_attn_out_99, output_284], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg560_1, buf950, buf951, buf935, buf953, 4096, stream=raw_stream0)
        del arg560_1
        assert_size_stride_grouped((arg561_1, arg562_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_95, core_attn_out_96, core_attn_out_97, hidden_states_189, pow_83, variance_19, add_295, rsqrt_122, hidden_states_190, to_261, hidden_states_191, to_262, silu_64, hidden_states_192, core_attn_out_98, core_attn_out_99, output_284], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf953, arg561_1, buf952, arg562_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg561_1
        del arg562_1
        assert_size_stride(arg563_1, (2560, ), (1, ), 'input')
        buf955 = buf885; del buf885  # reuse
        buf958 = buf840; del buf840  # reuse
        buf961 = buf814; del buf814  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_179, hidden_states_185, hidden_states_187, hidden_states_193, float_168, pow_84, mean_83, add_297, rsqrt_123, output_285, float_169, add_298, output_286, hidden_states_194, output_287, output_288], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf955, buf893, buf919, buf928, buf952, arg563_1, buf958, buf961, 1, 2560, stream=raw_stream0)
        del arg563_1
        buf957 = buf929; del buf929  # reuse
        assert_size_stride_grouped((arg564_1, arg565_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_168, pow_84, mean_83, add_297, rsqrt_123, output_285, float_169, add_298, output_286, hidden_states_194, output_287], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf958, arg564_1, buf957, arg565_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg564_1
        del arg565_1
        buf960 = buf926; del buf926  # reuse
        assert_size_stride_grouped((arg566_1, arg567_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_168, pow_84, mean_83, add_297, rsqrt_123, output_285, float_169, add_298, output_286, hidden_states_194, output_288], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf961, arg566_1, buf960, arg567_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg566_1
        del arg567_1
        buf963 = buf961; del buf961  # reuse
        buf964 = buf924; del buf924  # reuse
        # Topologically Sorted Source Nodes: [silu_65, mul_446, output_289], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf957, buf960, buf964, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg568_1, arg569_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_65, mul_446, output_289], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf964, arg568_1, buf963, arg569_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg568_1
        del arg569_1
        assert_size_stride(arg570_1, (2560, ), (1, ), 'input')
        buf968 = buf958; del buf958  # reuse
        buf971 = buf952; del buf952  # reuse
        buf979 = buf928; del buf928  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_195, float_170, pow_85, mean_84, add_300, rsqrt_124, output_290, float_171, add_301, output_291, hidden_states_196, output_292, output_293], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf955, buf963, arg570_1, buf968, buf971, buf979, 1, 2560, stream=raw_stream0)
        del arg570_1
        buf967 = reinterpret_tensor(buf941, (1, 1, 8192), (8192, 8192, 1), 0); del buf941  # reuse
        assert_size_stride_grouped((arg571_1, arg572_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_195, float_170, pow_85, mean_84, add_300, rsqrt_124, output_290, float_171, add_301, output_291, hidden_states_196, output_292], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf968, arg571_1, buf967, arg572_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg571_1
        del arg572_1
        buf970 = buf953; del buf953  # reuse
        assert_size_stride_grouped((arg573_1, arg574_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_195, float_170, pow_85, mean_84, add_300, rsqrt_124, output_290, float_171, add_301, output_291, hidden_states_196, output_293], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf971, arg573_1, buf970, arg574_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg573_1
        del arg574_1
        assert_size_stride(arg578_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf975 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf973 = reinterpret_tensor(buf975, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_46], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg578_1, buf973, 32768, stream=raw_stream0)
        buf974 = reinterpret_tensor(buf975, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_46], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf967, buf974, 8192, stream=raw_stream0)
        assert_size_stride(arg577_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf977 = reinterpret_tensor(buf967, (1, 8192, 1), (8192, 1, 8192), 0); del buf967  # reuse
        # Topologically Sorted Source Nodes: [out_60, squeeze_20, unsqueeze_132, out_61, out_62], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf975, arg577_1, buf977, 8192, stream=raw_stream0)
        del arg577_1
        del buf973
        del buf974
        buf978 = reinterpret_tensor(buf951, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf951  # reuse
        # Topologically Sorted Source Nodes: [out_62, mixed_qkv_62, split_20, key_107, key_108, transpose_187, key_109, mul_452, sum_82], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf977, buf978, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg576_1, arg579_1, arg580_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf981 = buf944; del buf944  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_195, float_170, pow_85, mean_84, add_300, rsqrt_124, output_290, float_171, add_301, output_291, hidden_states_196, float_172, exp_40, neg_32, a_20, float_173, add_302, softplus_20, g_20, transpose_190, getitem_313, exp_41], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf979, arg576_1, arg579_1, arg580_1, buf981, 2, 1, 1, stream=raw_stream0)
        del arg576_1
        del arg579_1
        del arg580_1
        assert_size_stride(arg581_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf982 = buf950; del buf950  # reuse
        # Topologically Sorted Source Nodes: [out_62, mixed_qkv_62, split_20, key_107, key_108, transpose_187, key_109, add_304, inv_norm_41, key_110, k_t_20, float_172, exp_40, neg_32, a_20, float_173, add_302, softplus_20, g_20, transpose_190, getitem_313, exp_41, decay_t_20, last_recurrent_state_61, unsqueeze_134, mul_455, kv_mem_20], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg581_1, buf981, buf977, buf978, buf982, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg575_1, (32, 2560), (2560, 1), 'input')
        buf984 = reinterpret_tensor(buf942, (1, 32, 1), (32, 1, 32), 0); del buf942  # reuse
        # Topologically Sorted Source Nodes: [b_20, beta_40, transpose_189, beta_41], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf979, arg575_1, buf984, 2, 1, 1, stream=raw_stream0)
        del arg575_1
        buf985 = buf948; del buf948  # reuse
        # Topologically Sorted Source Nodes: [out_62, mixed_qkv_62, split_20, key_107, key_108, transpose_187, key_109, add_304, inv_norm_41, key_110, k_t_20, unsqueeze_135, value_67, transpose_188, value_68, v_t_20, float_172, exp_40, neg_32, a_20, float_173, add_302, softplus_20, g_20, transpose_190, getitem_313, exp_41, decay_t_20, last_recurrent_state_61, sub_20, b_20, beta_40, transpose_189, beta_41, getitem_315, beta_t_20, delta_20, unsqueeze_136, mul_457, last_recurrent_state_62], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg581_1, buf981, buf977, buf978, buf982, buf984, buf985, arg581_1, 524288, stream=raw_stream0)
        del arg581_1
        buf986 = reinterpret_tensor(buf984, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf984  # reuse
        # Topologically Sorted Source Nodes: [out_62, mixed_qkv_62, split_20, query_121, query_122, transpose_186, query_123, mul_450, sum_81], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf977, buf986, 32, 128, stream=raw_stream0)
        buf987 = buf982; del buf982  # reuse
        # Topologically Sorted Source Nodes: [out_62, mixed_qkv_62, split_20, query_121, query_122, transpose_186, query_123, add_303, inv_norm_40, query_124, query_125, q_t_20, unsqueeze_137, mul_458, sum_84], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf985, buf977, buf986, buf987, 4096, 128, stream=raw_stream0)
        buf988 = reinterpret_tensor(buf986, (32, 1), (1, 32), 0); del buf986  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_100, core_attn_out_101, core_attn_out_102, hidden_states_197, pow_86, variance_20], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf987, buf988, 32, 128, stream=raw_stream0)
        buf989 = buf979; del buf979  # reuse
        assert_size_stride(arg582_1, (128, ), (1, ), 'input')
        buf990 = buf935; del buf935  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_100, core_attn_out_101, core_attn_out_102, hidden_states_197, pow_86, variance_20, add_306, rsqrt_127, hidden_states_198, to_274, hidden_states_199, to_275, silu_67, hidden_states_200, core_attn_out_103, core_attn_out_104, output_294], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg582_1, buf987, buf988, buf970, buf990, 4096, stream=raw_stream0)
        del arg582_1
        assert_size_stride_grouped((arg583_1, arg584_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_100, core_attn_out_101, core_attn_out_102, hidden_states_197, pow_86, variance_20, add_306, rsqrt_127, hidden_states_198, to_274, hidden_states_199, to_275, silu_67, hidden_states_200, core_attn_out_103, core_attn_out_104, output_294], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf990, arg583_1, buf989, arg584_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg583_1
        del arg584_1
        assert_size_stride(arg585_1, (2560, ), (1, ), 'input')
        buf993 = buf971; del buf971  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_201, float_174, pow_87, mean_86, add_308, rsqrt_128, output_295, float_175, add_309, output_296, hidden_states_202], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf955, buf963, buf989, arg585_1, buf993, 1, 2560, stream=raw_stream0)
        del arg585_1
        buf994 = buf964; del buf964  # reuse
        assert_size_stride_grouped((arg586_1, arg587_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_297], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf993, arg586_1, buf994, arg587_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg586_1
        del arg587_1
        buf996 = buf960; del buf960  # reuse
        assert_size_stride_grouped((arg588_1, arg589_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_298], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf993, arg588_1, buf996, arg589_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg588_1
        del arg589_1
        buf998 = buf993; del buf993  # reuse
        buf999 = buf957; del buf957  # reuse
        # Topologically Sorted Source Nodes: [silu_68, mul_464, output_299], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf994, buf996, buf999, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg590_1, arg591_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_68, mul_464, output_299], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf999, arg590_1, buf998, arg591_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg590_1
        del arg591_1
        assert_size_stride(arg592_1, (2560, ), (1, ), 'input')
        buf1002 = buf968; del buf968  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_201, hidden_states_203, float_176, pow_88, mean_87, add_311, rsqrt_129, output_300, float_177, add_312, output_301, hidden_states_204], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf955, buf963, buf989, buf998, arg592_1, buf1002, 1, 2560, stream=raw_stream0)
        del arg592_1
        buf1003 = reinterpret_tensor(buf977, (1, 1, 8192), (8192, 8192, 1), 0); del buf977  # reuse
        assert_size_stride_grouped((arg593_1, arg594_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_302], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1002, arg593_1, buf1003, arg594_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg593_1
        del arg594_1
        buf1005 = buf858; del buf858  # reuse
        assert_size_stride_grouped((arg596_1, arg597_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_305], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf1002, arg596_1, buf1005, arg597_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg596_1
        del arg597_1
        buf1007 = reinterpret_tensor(buf873, (1, 1, 1024), (1024, 1024, 1), 0); del buf873  # reuse
        assert_size_stride_grouped((arg599_1, arg600_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_308], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf1002, arg599_1, buf1007, arg600_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg599_1
        del arg600_1
        buf1009 = reinterpret_tensor(buf879, (1, 1, 16, 1), (16, 16, 1, 16), 0); del buf879  # reuse
        # Topologically Sorted Source Nodes: [float_178, pow_89, mean_88], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_split_view_22.run(buf1003, buf1009, 16, 256, stream=raw_stream0)
        assert_size_stride(arg595_1, (256, ), (1, ), 'input')
        buf1012 = reinterpret_tensor(buf856, (1, 16, 1, 64), (1024, 64, 64, 1), 0); del buf856  # reuse
        buf1010 = reinterpret_tensor(buf1012, (1, 16, 1, 32), (1024, 64, 64, 1), 0)  # alias
        buf1011 = reinterpret_tensor(buf1012, (1, 16, 1, 32), (1024, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_178, pow_89, mean_88, add_313, rsqrt_130, output_303, float_179, add_314, output_304, type_as_67, query_states_13, q_rot_6, x2_12, neg_33, x1_12, cat_47], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_23.run(buf1003, buf1009, arg595_1, buf1010, buf1011, 512, stream=raw_stream0)
        buf1015 = reinterpret_tensor(buf990, (1, 16, 1, 256), (4096, 256, 256, 1), 0); del buf990  # reuse
        buf1013 = reinterpret_tensor(buf1015, (1, 16, 1, 64), (4096, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_178, pow_89, mean_88, add_313, rsqrt_130, output_303, float_179, add_314, output_304, type_as_67, query_states_13, q_rot_6, cos_10, mul_471, sin_10, mul_472, q_embed_12], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_24.run(buf1003, buf1009, arg595_1, buf1, buf1012, buf0, buf1013, 1024, stream=raw_stream0)
        del buf1010
        del buf1011
        buf1014 = reinterpret_tensor(buf1015, (1, 16, 1, 192), (4096, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_178, pow_89, mean_88, add_313, rsqrt_130, output_303, float_179, add_314, output_304, type_as_67, query_states_13, q_rot_6, cos_10, mul_471, sin_10, mul_472, q_embed_12, q_pass_6, q_embed_13], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_25.run(buf1003, buf1009, arg595_1, buf1014, 3072, stream=raw_stream0)
        del arg595_1
        buf1016 = buf867; del buf867  # reuse
        # Topologically Sorted Source Nodes: [float_180, pow_90, mean_89], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_26.run(buf1005, buf1016, 4, 256, stream=raw_stream0)
        del buf1013
        del buf1014
        assert_size_stride(arg598_1, (256, ), (1, ), 'input')
        buf1019 = buf870; del buf870  # reuse
        buf1017 = reinterpret_tensor(buf1019, (1, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        buf1018 = reinterpret_tensor(buf1019, (1, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_180, pow_90, mean_89, add_315, rsqrt_131, output_306, float_181, add_316, output_307, type_as_68, key_states_6, k_rot_6, x2_13, neg_34, x1_13, cat_48], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_27.run(buf1005, buf1016, arg598_1, buf1017, buf1018, 128, stream=raw_stream0)
        buf1022 = reinterpret_tensor(buf1012, (1, 4, 1, 256), (1024, 256, 256, 1), 0); del buf1012  # reuse
        buf1020 = reinterpret_tensor(buf1022, (1, 4, 1, 64), (1024, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_10, sin_10, float_180, pow_90, mean_89, add_315, rsqrt_131, output_306, float_181, add_316, output_307, type_as_68, key_states_6, k_rot_6, mul_473, mul_474, k_embed_12], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28.run(buf1005, buf1016, arg598_1, buf1, buf1019, buf0, buf1020, 256, stream=raw_stream0)
        del buf1017
        del buf1018
        del buf1019
        buf1021 = reinterpret_tensor(buf1022, (1, 4, 1, 192), (1024, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_10, sin_10, float_180, pow_90, mean_89, add_315, rsqrt_131, output_306, float_181, add_316, output_307, type_as_68, key_states_6, k_rot_6, mul_473, mul_474, k_embed_12, k_pass_6, k_embed_13], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_29.run(buf1005, buf1016, arg598_1, buf1021, 768, stream=raw_stream0)
        del arg598_1
        del buf1005
        del buf1016
        assert_size_stride_grouped((arg601_1, arg602_1), ((), (1, 4, 64, 256)), ((), (65536, 16384, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_10, cache_position_6, index_copy__12], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_30.run(arg601_1, buf1022, arg602_1, 1024, stream=raw_stream0)
        del buf1020
        del buf1021
        del buf1022
        buf1024 = reinterpret_tensor(buf878, (16, 1, 64), (64, 64, 1), 0); del buf878  # reuse
        # Topologically Sorted Source Nodes: [attn_output_24, key_111], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_31.run(buf1015, arg602_1, buf1024, 1024, 256, stream=raw_stream0)
        del arg602_1
        buf1025 = buf876; del buf876  # reuse
        buf1027 = reinterpret_tensor(buf875, (1, 16, 1, 64), (1024, 64, 1024, 1), 0); del buf875  # reuse
        buf1028 = reinterpret_tensor(buf1009, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf1009  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_24], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32.run(buf1024, arg3_1, buf1025, buf1027, buf1028, 16, 64, stream=raw_stream0)
        del buf1024
        assert_size_stride(arg603_1, (1, 4, 64, 256), (65536, 16384, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_10, cache_position_6, index_copy__13], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_33.run(arg601_1, buf1007, arg603_1, 1024, stream=raw_stream0)
        del buf1007
        buf1032 = reinterpret_tensor(buf1015, (1, 1, 4096), (4096, 4096, 1), 0); del buf1015  # reuse
        # Topologically Sorted Source Nodes: [gate_13, attn_output_24, value_69, transpose_195, reshape_174, sigmoid_27, attn_output_27, output_309], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34.run(buf1025, buf1027, buf1028, arg603_1, buf1003, buf1032, 4096, 64, stream=raw_stream0)
        del arg603_1
        del buf1025
        del buf1027
        del buf1028
        buf1031 = buf1002; del buf1002  # reuse
        assert_size_stride_grouped((arg604_1, arg605_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [gate_13, attn_output_24, transpose_195, reshape_174, sigmoid_27, attn_output_27, output_309], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1032, arg604_1, buf1031, arg605_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg604_1
        del arg605_1
        assert_size_stride(arg606_1, (2560, ), (1, ), 'input')
        buf1034 = buf955; del buf955  # reuse
        buf1037 = buf919; del buf919  # reuse
        buf1040 = buf893; del buf893  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_195, hidden_states_201, hidden_states_203, hidden_states_207, float_182, pow_91, mean_90, add_321, rsqrt_132, output_310, float_183, add_322, output_311, hidden_states_208, output_312, output_313], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf1034, buf963, buf989, buf998, buf1031, arg606_1, buf1037, buf1040, 1, 2560, stream=raw_stream0)
        del arg606_1
        del buf1031
        del buf963
        buf1036 = buf999; del buf999  # reuse
        assert_size_stride_grouped((arg607_1, arg608_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_182, pow_91, mean_90, add_321, rsqrt_132, output_310, float_183, add_322, output_311, hidden_states_208, output_312], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1037, arg607_1, buf1036, arg608_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg607_1
        del arg608_1
        buf1039 = buf996; del buf996  # reuse
        assert_size_stride_grouped((arg609_1, arg610_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_182, pow_91, mean_90, add_321, rsqrt_132, output_310, float_183, add_322, output_311, hidden_states_208, output_313], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1040, arg609_1, buf1039, arg610_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg609_1
        del arg610_1
        buf1042 = buf1040; del buf1040  # reuse
        buf1043 = buf994; del buf994  # reuse
        # Topologically Sorted Source Nodes: [silu_69, mul_478, output_314], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf1036, buf1039, buf1043, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg611_1, arg612_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_69, mul_478, output_314], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf1043, arg611_1, buf1042, arg612_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg611_1
        del arg612_1
        assert_size_stride(arg613_1, (2560, ), (1, ), 'input')
        buf1047 = buf1037; del buf1037  # reuse
        buf1050 = buf998; del buf998  # reuse
        buf1058 = buf989; del buf989  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_209, float_184, pow_92, mean_91, add_324, rsqrt_133, output_315, float_185, add_325, output_316, hidden_states_210, output_317, output_318], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf1034, buf1042, arg613_1, buf1047, buf1050, buf1058, 1, 2560, stream=raw_stream0)
        del arg613_1
        buf1046 = buf1003; del buf1003  # reuse
        assert_size_stride_grouped((arg614_1, arg615_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_209, float_184, pow_92, mean_91, add_324, rsqrt_133, output_315, float_185, add_325, output_316, hidden_states_210, output_317], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1047, arg614_1, buf1046, arg615_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg614_1
        del arg615_1
        buf1049 = buf1032; del buf1032  # reuse
        assert_size_stride_grouped((arg616_1, arg617_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_209, float_184, pow_92, mean_91, add_324, rsqrt_133, output_315, float_185, add_325, output_316, hidden_states_210, output_318], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1050, arg616_1, buf1049, arg617_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg616_1
        del arg617_1
        assert_size_stride(arg621_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf1054 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf1052 = reinterpret_tensor(buf1054, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_51], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg621_1, buf1052, 32768, stream=raw_stream0)
        buf1053 = reinterpret_tensor(buf1054, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_51], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf1046, buf1053, 8192, stream=raw_stream0)
        assert_size_stride(arg620_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf1056 = reinterpret_tensor(buf1046, (1, 8192, 1), (8192, 1, 8192), 0); del buf1046  # reuse
        # Topologically Sorted Source Nodes: [out_63, squeeze_21, unsqueeze_140, out_64, out_65], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf1054, arg620_1, buf1056, 8192, stream=raw_stream0)
        del arg620_1
        del buf1052
        del buf1053
        buf1057 = reinterpret_tensor(buf988, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf988  # reuse
        # Topologically Sorted Source Nodes: [out_65, mixed_qkv_65, split_21, key_113, key_114, transpose_199, key_115, mul_484, sum_86], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf1056, buf1057, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg619_1, arg622_1, arg623_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf1060 = buf981; del buf981  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_209, float_184, pow_92, mean_91, add_324, rsqrt_133, output_315, float_185, add_325, output_316, hidden_states_210, float_186, exp_42, neg_35, a_21, float_187, add_326, softplus_21, g_21, transpose_202, getitem_336, exp_43], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf1058, arg619_1, arg622_1, arg623_1, buf1060, 2, 1, 1, stream=raw_stream0)
        del arg619_1
        del arg622_1
        del arg623_1
        assert_size_stride(arg624_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf1061 = buf987; del buf987  # reuse
        # Topologically Sorted Source Nodes: [out_65, mixed_qkv_65, split_21, key_113, key_114, transpose_199, key_115, add_328, inv_norm_43, key_116, k_t_21, float_186, exp_42, neg_35, a_21, float_187, add_326, softplus_21, g_21, transpose_202, getitem_336, exp_43, decay_t_21, last_recurrent_state_64, unsqueeze_142, mul_487, kv_mem_21], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg624_1, buf1060, buf1056, buf1057, buf1061, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg618_1, (32, 2560), (2560, 1), 'input')
        buf1063 = reinterpret_tensor(buf978, (1, 32, 1), (32, 1, 32), 0); del buf978  # reuse
        # Topologically Sorted Source Nodes: [b_21, beta_42, transpose_201, beta_43], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf1058, arg618_1, buf1063, 2, 1, 1, stream=raw_stream0)
        del arg618_1
        buf1064 = buf985; del buf985  # reuse
        # Topologically Sorted Source Nodes: [out_65, mixed_qkv_65, split_21, key_113, key_114, transpose_199, key_115, add_328, inv_norm_43, key_116, k_t_21, unsqueeze_143, value_71, transpose_200, value_72, v_t_21, float_186, exp_42, neg_35, a_21, float_187, add_326, softplus_21, g_21, transpose_202, getitem_336, exp_43, decay_t_21, last_recurrent_state_64, sub_21, b_21, beta_42, transpose_201, beta_43, getitem_338, beta_t_21, delta_21, unsqueeze_144, mul_489, last_recurrent_state_65], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg624_1, buf1060, buf1056, buf1057, buf1061, buf1063, buf1064, arg624_1, 524288, stream=raw_stream0)
        del arg624_1
        buf1065 = reinterpret_tensor(buf1063, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf1063  # reuse
        # Topologically Sorted Source Nodes: [out_65, mixed_qkv_65, split_21, query_127, query_128, transpose_198, query_129, mul_482, sum_85], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf1056, buf1065, 32, 128, stream=raw_stream0)
        buf1066 = buf1061; del buf1061  # reuse
        # Topologically Sorted Source Nodes: [out_65, mixed_qkv_65, split_21, query_127, query_128, transpose_198, query_129, add_327, inv_norm_42, query_130, query_131, q_t_21, unsqueeze_145, mul_490, sum_88], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf1064, buf1056, buf1065, buf1066, 4096, 128, stream=raw_stream0)
        del buf1064
        buf1067 = reinterpret_tensor(buf1065, (32, 1), (1, 32), 0); del buf1065  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_105, core_attn_out_106, core_attn_out_107, hidden_states_211, pow_93, variance_21], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf1066, buf1067, 32, 128, stream=raw_stream0)
        buf1068 = buf1058; del buf1058  # reuse
        assert_size_stride(arg625_1, (128, ), (1, ), 'input')
        buf1069 = buf970; del buf970  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_105, core_attn_out_106, core_attn_out_107, hidden_states_211, pow_93, variance_21, add_330, rsqrt_136, hidden_states_212, to_287, hidden_states_213, to_288, silu_71, hidden_states_214, core_attn_out_108, core_attn_out_109, output_319], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg625_1, buf1066, buf1067, buf1049, buf1069, 4096, stream=raw_stream0)
        del arg625_1
        assert_size_stride_grouped((arg626_1, arg627_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_105, core_attn_out_106, core_attn_out_107, hidden_states_211, pow_93, variance_21, add_330, rsqrt_136, hidden_states_212, to_287, hidden_states_213, to_288, silu_71, hidden_states_214, core_attn_out_108, core_attn_out_109, output_319], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1069, arg626_1, buf1068, arg627_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg626_1
        del arg627_1
        assert_size_stride(arg628_1, (2560, ), (1, ), 'input')
        buf1072 = buf1050; del buf1050  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_209, hidden_states_215, float_188, pow_94, mean_93, add_332, rsqrt_137, output_320, float_189, add_333, output_321, hidden_states_216], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf1034, buf1042, buf1068, arg628_1, buf1072, 1, 2560, stream=raw_stream0)
        del arg628_1
        buf1073 = buf1043; del buf1043  # reuse
        assert_size_stride_grouped((arg629_1, arg630_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_322], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1072, arg629_1, buf1073, arg630_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg629_1
        del arg630_1
        buf1075 = buf1039; del buf1039  # reuse
        assert_size_stride_grouped((arg631_1, arg632_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_323], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1072, arg631_1, buf1075, arg632_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg631_1
        del arg632_1
        buf1077 = buf1072; del buf1072  # reuse
        buf1078 = buf1036; del buf1036  # reuse
        # Topologically Sorted Source Nodes: [silu_72, mul_496, output_324], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf1073, buf1075, buf1078, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg633_1, arg634_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_72, mul_496, output_324], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf1078, arg633_1, buf1077, arg634_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg633_1
        del arg634_1
        assert_size_stride(arg635_1, (2560, ), (1, ), 'input')
        buf1081 = buf1047; del buf1047  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_209, hidden_states_215, hidden_states_217, float_190, pow_95, mean_94, add_335, rsqrt_138, output_325, float_191, add_336, output_326, hidden_states_218], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf1034, buf1042, buf1068, buf1077, arg635_1, buf1081, 1, 2560, stream=raw_stream0)
        del arg635_1
        buf1082 = reinterpret_tensor(buf1056, (1, 1, 8192), (8192, 8192, 1), 0); del buf1056  # reuse
        assert_size_stride_grouped((arg636_1, arg637_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_327], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1081, arg636_1, buf1082, arg637_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg636_1
        del arg637_1
        buf1084 = buf1069; del buf1069  # reuse
        assert_size_stride_grouped((arg638_1, arg639_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_328], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1081, arg638_1, buf1084, arg639_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg638_1
        del arg639_1
        assert_size_stride(arg643_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf1088 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf1086 = reinterpret_tensor(buf1088, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_52], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg643_1, buf1086, 32768, stream=raw_stream0)
        buf1087 = reinterpret_tensor(buf1088, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_52], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf1082, buf1087, 8192, stream=raw_stream0)
        assert_size_stride(arg642_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf1090 = reinterpret_tensor(buf1082, (1, 8192, 1), (8192, 1, 8192), 0); del buf1082  # reuse
        # Topologically Sorted Source Nodes: [out_66, squeeze_22, unsqueeze_146, out_67, out_68], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf1088, arg642_1, buf1090, 8192, stream=raw_stream0)
        del arg642_1
        del buf1086
        del buf1087
        buf1091 = reinterpret_tensor(buf1067, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf1067  # reuse
        # Topologically Sorted Source Nodes: [out_68, mixed_qkv_68, split_22, key_118, key_119, transpose_207, key_120, mul_502, sum_90], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf1090, buf1091, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg641_1, arg644_1, arg645_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf1093 = buf1060; del buf1060  # reuse
        # Topologically Sorted Source Nodes: [float_192, exp_44, neg_36, a_22, float_193, add_337, softplus_22, g_22, transpose_210, getitem_347, exp_45], Original ATen: [aten._to_copy, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_17.run(buf1081, arg641_1, arg644_1, arg645_1, buf1093, 2, 1, 1, stream=raw_stream0)
        del arg641_1
        del arg644_1
        del arg645_1
        assert_size_stride(arg646_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf1094 = buf1066; del buf1066  # reuse
        # Topologically Sorted Source Nodes: [out_68, mixed_qkv_68, split_22, key_118, key_119, transpose_207, key_120, add_339, inv_norm_45, key_121, k_t_22, float_192, exp_44, neg_36, a_22, float_193, add_337, softplus_22, g_22, transpose_210, getitem_347, exp_45, decay_t_22, last_recurrent_state_67, unsqueeze_148, mul_505, kv_mem_22], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg646_1, buf1093, buf1090, buf1091, buf1094, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg640_1, (32, 2560), (2560, 1), 'input')
        buf1096 = reinterpret_tensor(buf1057, (1, 32, 1), (32, 1, 32), 0); del buf1057  # reuse
        # Topologically Sorted Source Nodes: [b_22, beta_44, transpose_209, beta_45], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf1081, arg640_1, buf1096, 2, 1, 1, stream=raw_stream0)
        del arg640_1
        buf1097 = empty_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_68, mixed_qkv_68, split_22, key_118, key_119, transpose_207, key_120, add_339, inv_norm_45, key_121, k_t_22, unsqueeze_149, value_74, transpose_208, value_75, v_t_22, float_192, exp_44, neg_36, a_22, float_193, add_337, softplus_22, g_22, transpose_210, getitem_347, exp_45, decay_t_22, last_recurrent_state_67, sub_22, b_22, beta_44, transpose_209, beta_45, getitem_349, beta_t_22, delta_22, unsqueeze_150, mul_507, last_recurrent_state_68], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg646_1, buf1093, buf1090, buf1091, buf1094, buf1096, buf1097, arg646_1, 524288, stream=raw_stream0)
        del arg646_1
        buf1098 = reinterpret_tensor(buf1096, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf1096  # reuse
        # Topologically Sorted Source Nodes: [out_68, mixed_qkv_68, split_22, query_133, query_134, transpose_206, query_135, mul_500, sum_89], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf1090, buf1098, 32, 128, stream=raw_stream0)
        buf1099 = buf1094; del buf1094  # reuse
        # Topologically Sorted Source Nodes: [out_68, mixed_qkv_68, split_22, query_133, query_134, transpose_206, query_135, add_338, inv_norm_44, query_136, query_137, q_t_22, unsqueeze_151, mul_508, sum_92], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf1097, buf1090, buf1098, buf1099, 4096, 128, stream=raw_stream0)
        del buf1097
        buf1100 = reinterpret_tensor(buf1098, (32, 1), (1, 32), 0); del buf1098  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_110, core_attn_out_111, core_attn_out_112, hidden_states_219, pow_96, variance_22], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf1099, buf1100, 32, 128, stream=raw_stream0)
        buf1101 = buf1081; del buf1081  # reuse
        assert_size_stride(arg647_1, (128, ), (1, ), 'input')
        buf1102 = buf1049; del buf1049  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_110, core_attn_out_111, core_attn_out_112, hidden_states_219, pow_96, variance_22, add_341, rsqrt_141, hidden_states_220, to_300, hidden_states_221, to_301, silu_74, hidden_states_222, core_attn_out_113, core_attn_out_114, output_329], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg647_1, buf1099, buf1100, buf1084, buf1102, 4096, stream=raw_stream0)
        del arg647_1
        del buf1084
        assert_size_stride_grouped((arg648_1, arg649_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_110, core_attn_out_111, core_attn_out_112, hidden_states_219, pow_96, variance_22, add_341, rsqrt_141, hidden_states_220, to_300, hidden_states_221, to_301, silu_74, hidden_states_222, core_attn_out_113, core_attn_out_114, output_329], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1102, arg648_1, buf1101, arg649_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg648_1
        del arg649_1
        assert_size_stride(arg650_1, (2560, ), (1, ), 'input')
        buf1104 = buf1034; del buf1034  # reuse
        buf1107 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        buf1110 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_209, hidden_states_215, hidden_states_217, hidden_states_223, float_194, pow_97, mean_96, add_343, rsqrt_142, output_330, float_195, add_344, output_331, hidden_states_224, output_332, output_333], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf1104, buf1042, buf1068, buf1077, buf1101, arg650_1, buf1107, buf1110, 1, 2560, stream=raw_stream0)
        del arg650_1
        del buf1042
        del buf1068
        buf1106 = buf1078; del buf1078  # reuse
        assert_size_stride_grouped((arg651_1, arg652_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_194, pow_97, mean_96, add_343, rsqrt_142, output_330, float_195, add_344, output_331, hidden_states_224, output_332], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1107, arg651_1, buf1106, arg652_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg651_1
        del arg652_1
        buf1109 = buf1075; del buf1075  # reuse
        assert_size_stride_grouped((arg653_1, arg654_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_194, pow_97, mean_96, add_343, rsqrt_142, output_330, float_195, add_344, output_331, hidden_states_224, output_333], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1110, arg653_1, buf1109, arg654_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg653_1
        del arg654_1
        buf1112 = buf1110; del buf1110  # reuse
        buf1113 = buf1073; del buf1073  # reuse
        # Topologically Sorted Source Nodes: [silu_75, mul_514, output_334], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf1106, buf1109, buf1113, 9216, stream=raw_stream0)
        del buf1106
        del buf1109
        assert_size_stride_grouped((arg655_1, arg656_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_75, mul_514, output_334], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf1113, arg655_1, buf1112, arg656_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg655_1
        del arg656_1
        del buf1113
        assert_size_stride(arg657_1, (2560, ), (1, ), 'input')
        buf1117 = buf1107; del buf1107  # reuse
        buf1120 = buf1101; del buf1101  # reuse
        buf1128 = buf1077; del buf1077  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_225, float_196, pow_98, mean_97, add_346, rsqrt_143, output_335, float_197, add_347, output_336, hidden_states_226, output_337, output_338], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_19.run(buf1104, buf1112, arg657_1, buf1117, buf1120, buf1128, 1, 2560, stream=raw_stream0)
        del arg657_1
        buf1116 = reinterpret_tensor(buf1090, (1, 1, 8192), (8192, 8192, 1), 0); del buf1090  # reuse
        assert_size_stride_grouped((arg658_1, arg659_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_225, float_196, pow_98, mean_97, add_346, rsqrt_143, output_335, float_197, add_347, output_336, hidden_states_226, output_337], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1117, arg658_1, buf1116, arg659_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg658_1
        del arg659_1
        del buf1117
        buf1119 = buf1102; del buf1102  # reuse
        assert_size_stride_grouped((arg660_1, arg661_1), ((4096, 2560), (32, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [hidden_states_225, float_196, pow_98, mean_97, add_346, rsqrt_143, output_335, float_197, add_347, output_336, hidden_states_226, output_338], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_1.run(buf1120, arg660_1, buf1119, arg661_1, 1, 4096, 2560, 2560, 1, 1, 2560, 4096, 1, 1, 20, stream=raw_stream0)
        del arg660_1
        del arg661_1
        del buf1120
        assert_size_stride(arg665_1, (1, 8192, 4), (32768, 4, 1), 'input')
        buf1124 = empty_strided((1, 8192, 5), (40960, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf1122 = reinterpret_tensor(buf1124, (1, 8192, 4), (40960, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cat_53], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_2.run(arg665_1, buf1122, 32768, stream=raw_stream0)
        buf1123 = reinterpret_tensor(buf1124, (1, 8192, 1), (40960, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [cat_53], Original ATen: [aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_transpose_3.run(buf1116, buf1123, 8192, stream=raw_stream0)
        assert_size_stride(arg664_1, (8192, 1, 4), (4, 4, 1), 'input')
        buf1126 = reinterpret_tensor(buf1116, (1, 8192, 1), (8192, 1, 8192), 0); del buf1116  # reuse
        # Topologically Sorted Source Nodes: [out_69, squeeze_23, unsqueeze_152, out_70, out_71], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_4.run(buf1124, arg664_1, buf1126, 8192, stream=raw_stream0)
        del arg664_1
        del buf1122
        del buf1123
        buf1127 = reinterpret_tensor(buf1100, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf1100  # reuse
        # Topologically Sorted Source Nodes: [out_71, mixed_qkv_71, split_23, key_123, key_124, transpose_215, key_125, mul_520, sum_94], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_5.run(buf1126, buf1127, 32, 128, stream=raw_stream0)
        assert_size_stride_grouped((arg663_1, arg666_1, arg667_1), ((32, 2560), (32, ), (32, )), ((2560, 1), (1, ), (1, )), 'input')
        buf1130 = buf1093; del buf1093  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_225, float_196, pow_98, mean_97, add_346, rsqrt_143, output_335, float_197, add_347, output_336, hidden_states_226, float_198, exp_46, neg_37, a_23, float_199, add_348, softplus_23, g_23, transpose_218, getitem_358, exp_47], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten.softplus, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_embedding_exp_mean_mm_mul_neg_pow_rsqrt_select_softplus_t_transpose_view_6.run(buf1128, arg663_1, arg666_1, arg667_1, buf1130, 2, 1, 1, stream=raw_stream0)
        del arg663_1
        del arg666_1
        del arg667_1
        assert_size_stride(arg668_1, (1, 32, 128, 128), (524288, 16384, 128, 1), 'input')
        buf1131 = buf1099; del buf1099  # reuse
        # Topologically Sorted Source Nodes: [out_71, mixed_qkv_71, split_23, key_123, key_124, transpose_215, key_125, add_350, inv_norm_47, key_126, k_t_23, float_198, exp_46, neg_37, a_23, float_199, add_348, softplus_23, g_23, transpose_218, getitem_358, exp_47, decay_t_23, last_recurrent_state_70, unsqueeze_154, mul_523, kv_mem_23], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_clone_exp_expand_mul_neg_rsqrt_select_silu_softplus_split_with_sizes_sum_transpose_unsqueeze_view_7.run(arg668_1, buf1130, buf1126, buf1127, buf1131, 4096, 128, stream=raw_stream0)
        assert_size_stride(arg662_1, (32, 2560), (2560, 1), 'input')
        buf1133 = reinterpret_tensor(buf1091, (1, 32, 1), (32, 1, 32), 0); del buf1091  # reuse
        # Topologically Sorted Source Nodes: [b_23, beta_46, transpose_217, beta_47], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_8.run(buf1128, arg662_1, buf1133, 2, 1, 1, stream=raw_stream0)
        del arg662_1
        del buf1128
        buf1134 = empty_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_71, mixed_qkv_71, split_23, key_123, key_124, transpose_215, key_125, add_350, inv_norm_47, key_126, k_t_23, unsqueeze_155, value_77, transpose_216, value_78, v_t_23, float_198, exp_46, neg_37, a_23, float_199, add_348, softplus_23, g_23, transpose_218, getitem_358, exp_47, decay_t_23, last_recurrent_state_70, sub_23, b_23, beta_46, transpose_217, beta_47, getitem_360, beta_t_23, delta_23, unsqueeze_156, mul_525, last_recurrent_state_71], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.select, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_clone_copy__exp_expand_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_9.run(arg668_1, buf1130, buf1126, buf1127, buf1131, buf1133, buf1134, arg668_1, 524288, stream=raw_stream0)
        del arg668_1
        del buf1127
        del buf1130
        buf1135 = reinterpret_tensor(buf1133, (1, 32, 1, 1), (32, 1, 32, 32), 0); del buf1133  # reuse
        # Topologically Sorted Source Nodes: [out_71, mixed_qkv_71, split_23, query_139, query_140, transpose_214, query_141, mul_518, sum_93], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_clone_expand_mul_silu_split_with_sizes_sum_transpose_unsqueeze_view_10.run(buf1126, buf1135, 32, 128, stream=raw_stream0)
        buf1136 = buf1131; del buf1131  # reuse
        # Topologically Sorted Source Nodes: [out_71, mixed_qkv_71, split_23, query_139, query_140, transpose_214, query_141, add_349, inv_norm_46, query_142, query_143, q_t_23, unsqueeze_157, mul_526, sum_96], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._to_copy, aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_clone_div_expand_mul_rsqrt_select_silu_split_with_sizes_sum_transpose_unsqueeze_view_11.run(buf1134, buf1126, buf1135, buf1136, 4096, 128, stream=raw_stream0)
        del buf1134
        buf1137 = reinterpret_tensor(buf1135, (32, 1), (1, 32), 0); del buf1135  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_115, core_attn_out_116, core_attn_out_117, hidden_states_227, pow_99, variance_23], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_transpose_view_zeros_like_12.run(buf1136, buf1137, 32, 128, stream=raw_stream0)
        buf1138 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride(arg669_1, (128, ), (1, ), 'input')
        buf1139 = empty_strided((1, 1, 4096), (4096, 4096, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [core_attn_out_115, core_attn_out_116, core_attn_out_117, hidden_states_227, pow_99, variance_23, add_352, rsqrt_146, hidden_states_228, to_313, hidden_states_229, to_314, silu_77, hidden_states_230, core_attn_out_118, core_attn_out_119, output_339], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_13.run(arg669_1, buf1136, buf1137, buf1119, buf1139, 4096, stream=raw_stream0)
        del arg669_1
        del buf1119
        del buf1136
        del buf1137
        assert_size_stride_grouped((arg670_1, arg671_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [core_attn_out_115, core_attn_out_116, core_attn_out_117, hidden_states_227, pow_99, variance_23, add_352, rsqrt_146, hidden_states_228, to_313, hidden_states_229, to_314, silu_77, hidden_states_230, core_attn_out_118, core_attn_out_119, output_339], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.silu]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1139, arg670_1, buf1138, arg671_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg670_1
        del arg671_1
        assert_size_stride(arg672_1, (2560, ), (1, ), 'input')
        buf1142 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_225, hidden_states_231, float_200, pow_100, mean_99, add_354, rsqrt_147, output_340, float_201, add_355, output_341, hidden_states_232], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_20.run(buf1104, buf1112, buf1138, arg672_1, buf1142, 1, 2560, stream=raw_stream0)
        del arg672_1
        buf1143 = empty_strided((1, 1, 9216), (9216, 9216, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg673_1, arg674_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_342], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1142, arg673_1, buf1143, arg674_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg673_1
        del arg674_1
        buf1145 = empty_strided((1, 1, 9216), (9216, 9216, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg675_1, arg676_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_343], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1142, arg675_1, buf1145, arg676_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg675_1
        del arg676_1
        buf1147 = buf1142; del buf1142  # reuse
        buf1148 = empty_strided((1, 1, 9216), (9216, 9216, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [silu_78, mul_532, output_344], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf1143, buf1145, buf1148, 9216, stream=raw_stream0)
        assert_size_stride_grouped((arg677_1, arg678_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_78, mul_532, output_344], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf1148, arg677_1, buf1147, arg678_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg677_1
        del arg678_1
        assert_size_stride(arg679_1, (2560, ), (1, ), 'input')
        buf1151 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_225, hidden_states_231, hidden_states_233, float_202, pow_101, mean_100, add_357, rsqrt_148, output_345, float_203, add_358, output_346, hidden_states_234], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_21.run(buf1104, buf1112, buf1138, buf1147, arg679_1, buf1151, 1, 2560, stream=raw_stream0)
        del arg679_1
        buf1152 = reinterpret_tensor(buf1126, (1, 1, 8192), (8192, 8192, 1), 0); del buf1126  # reuse
        assert_size_stride_grouped((arg680_1, arg681_1), ((8192, 2560), (64, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_347], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_0.run(buf1151, arg680_1, buf1152, arg681_1, 1, 8192, 2560, 2560, 1, 1, 2560, 8192, 1, 1, 20, stream=raw_stream0)
        del arg680_1
        del arg681_1
        buf1154 = empty_strided((1, 1, 1024), (1024, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg683_1, arg684_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_350], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf1151, arg683_1, buf1154, arg684_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg683_1
        del arg684_1
        buf1156 = empty_strided((1, 1, 1024), (1024, 1024, 1), device='tnca', dtype=torch.bfloat16)
        assert_size_stride_grouped((arg686_1, arg687_1), ((1024, 2560), (8, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [output_353], Original ATen: []
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_5.run(buf1151, arg686_1, buf1156, arg687_1, 1, 1024, 2560, 2560, 1, 1, 2560, 1024, 1, 1, 20, stream=raw_stream0)
        del arg686_1
        del arg687_1
        buf1158 = empty_strided((1, 1, 16, 1), (16, 16, 1, 16), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [float_204, pow_102, mean_101], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_split_view_22.run(buf1152, buf1158, 16, 256, stream=raw_stream0)
        assert_size_stride(arg682_1, (256, ), (1, ), 'input')
        buf1161 = empty_strided((1, 16, 1, 64), (1024, 64, 64, 1), device='tnca', dtype=torch.bfloat16)
        buf1159 = reinterpret_tensor(buf1161, (1, 16, 1, 32), (1024, 64, 64, 1), 0)  # alias
        buf1160 = reinterpret_tensor(buf1161, (1, 16, 1, 32), (1024, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_204, pow_102, mean_101, add_359, rsqrt_149, output_348, float_205, add_360, output_349, type_as_77, query_states_15, q_rot_7, x2_14, neg_38, x1_14, cat_54], Original ATen: [aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_23.run(buf1152, buf1158, arg682_1, buf1159, buf1160, 512, stream=raw_stream0)
        buf1164 = reinterpret_tensor(buf1139, (1, 16, 1, 256), (4096, 256, 256, 1), 0); del buf1139  # reuse
        buf1162 = reinterpret_tensor(buf1164, (1, 16, 1, 64), (4096, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_204, pow_102, mean_101, add_359, rsqrt_149, output_348, float_205, add_360, output_349, type_as_77, query_states_15, q_rot_7, cos_11, mul_539, sin_11, mul_540, q_embed_14], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_24.run(buf1152, buf1158, arg682_1, buf1, buf1161, buf0, buf1162, 1024, stream=raw_stream0)
        del buf1159
        del buf1160
        buf1163 = reinterpret_tensor(buf1164, (1, 16, 1, 192), (4096, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, float_204, pow_102, mean_101, add_359, rsqrt_149, output_348, float_205, add_360, output_349, type_as_77, query_states_15, q_rot_7, cos_11, mul_539, sin_11, mul_540, q_embed_14, q_pass_7, q_embed_15], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_25.run(buf1152, buf1158, arg682_1, buf1163, 3072, stream=raw_stream0)
        del arg682_1
        buf1165 = empty_strided((1, 1, 4, 1), (4, 4, 1, 4), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [float_206, pow_103, mean_102], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_view_26.run(buf1154, buf1165, 4, 256, stream=raw_stream0)
        del buf1162
        del buf1163
        assert_size_stride(arg685_1, (256, ), (1, ), 'input')
        buf1168 = empty_strided((1, 4, 1, 64), (256, 64, 64, 1), device='tnca', dtype=torch.bfloat16)
        buf1166 = reinterpret_tensor(buf1168, (1, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        buf1167 = reinterpret_tensor(buf1168, (1, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [float_206, pow_103, mean_102, add_361, rsqrt_150, output_351, float_207, add_362, output_352, type_as_78, key_states_7, k_rot_7, x2_15, neg_39, x1_15, cat_55], Original ATen: [aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_27.run(buf1154, buf1165, arg685_1, buf1166, buf1167, 128, stream=raw_stream0)
        buf1171 = reinterpret_tensor(buf1161, (1, 4, 1, 256), (1024, 256, 256, 1), 0); del buf1161  # reuse
        buf1169 = reinterpret_tensor(buf1171, (1, 4, 1, 64), (1024, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_11, sin_11, float_206, pow_103, mean_102, add_361, rsqrt_150, output_351, float_207, add_362, output_352, type_as_78, key_states_7, k_rot_7, mul_541, mul_542, k_embed_14], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_28.run(buf1154, buf1165, arg685_1, buf1, buf1168, buf0, buf1169, 256, stream=raw_stream0)
        del buf0
        del buf1
        del buf1166
        del buf1167
        del buf1168
        buf1170 = reinterpret_tensor(buf1171, (1, 4, 1, 192), (1024, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [setitem_3, cos_2, cos_3, setitem_1, sin_2, sin_3, cos_11, sin_11, float_206, pow_103, mean_102, add_361, rsqrt_150, output_351, float_207, add_362, output_352, type_as_78, key_states_7, k_rot_7, mul_541, mul_542, k_embed_14, k_pass_7, k_embed_15], Original ATen: [aten.select, aten.slice, aten.cat, aten._to_copy, aten.unsqueeze, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_29.run(buf1154, buf1165, arg685_1, buf1170, 768, stream=raw_stream0)
        del arg685_1
        del buf1154
        del buf1165
        assert_size_stride_grouped((arg688_1, arg689_1), ((), (1, 4, 64, 256)), ((), (65536, 16384, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_11, cache_position_7, index_copy__14], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_30.run(arg688_1, buf1171, arg689_1, 1024, stream=raw_stream0)
        del buf1169
        del buf1170
        del buf1171
        buf1173 = empty_strided((16, 1, 64), (64, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [attn_output_28, key_127], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_31.run(buf1164, arg689_1, buf1173, 1024, 256, stream=raw_stream0)
        del arg689_1
        buf1174 = empty_strided((1, 16, 1, 1), (16, 1, 16, 16), device='tnca', dtype=torch.bool)
        buf1176 = empty_strided((1, 16, 1, 64), (1024, 64, 1024, 1), device='tnca', dtype=torch.float32)
        buf1177 = reinterpret_tensor(buf1158, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf1158  # reuse
        # Topologically Sorted Source Nodes: [kv_arange, kv_indices, arange_2, q_arange, q_indices, attention_mask, attention_mask_1, attn_output_28], Original ATen: [aten.add, aten.unsqueeze, aten.arange, aten.le, aten.expand, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_32.run(buf1173, arg3_1, buf1174, buf1176, buf1177, 16, 64, stream=raw_stream0)
        del buf1173
        assert_size_stride(arg690_1, (1, 4, 64, 256), (65536, 16384, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_11, cache_position_7, index_copy__15], Original ATen: [aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_transpose_view_33.run(arg688_1, buf1156, arg690_1, 1024, stream=raw_stream0)
        del buf1156
        buf1181 = reinterpret_tensor(buf1164, (1, 1, 4096), (4096, 4096, 1), 0); del buf1164  # reuse
        # Topologically Sorted Source Nodes: [gate_15, attn_output_28, value_79, transpose_223, reshape_199, sigmoid_31, attn_output_31, output_354], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_34.run(buf1174, buf1176, buf1177, arg690_1, buf1152, buf1181, 4096, 64, stream=raw_stream0)
        del arg690_1
        del buf1152
        del buf1174
        del buf1176
        del buf1177
        buf1180 = buf1151; del buf1151  # reuse
        assert_size_stride_grouped((arg691_1, arg692_1), ((2560, 4096), (20, 32)), ((4096, 1), (32, 1)), 'input')
        # Topologically Sorted Source Nodes: [gate_15, attn_output_28, transpose_223, reshape_199, sigmoid_31, attn_output_31, output_354], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_2.run(buf1181, arg691_1, buf1180, arg692_1, 1, 2560, 4096, 4096, 1, 1, 4096, 2560, 1, 1, 32, stream=raw_stream0)
        del arg691_1
        del arg692_1
        del buf1181
        assert_size_stride(arg693_1, (2560, ), (1, ), 'input')
        buf1183 = buf1104; del buf1104  # reuse
        buf1186 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        buf1189 = empty_strided((1, 1, 2560), (2560, 2560, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_225, hidden_states_231, hidden_states_233, hidden_states_237, float_208, pow_104, mean_103, add_367, rsqrt_151, output_355, float_209, add_368, output_356, hidden_states_238, output_357, output_358], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_35.run(buf1183, buf1112, buf1138, buf1147, buf1180, arg693_1, buf1186, buf1189, 1, 2560, stream=raw_stream0)
        del arg693_1
        del buf1112
        del buf1138
        del buf1147
        del buf1180
        buf1185 = buf1148; del buf1148  # reuse
        assert_size_stride_grouped((arg694_1, arg695_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_208, pow_104, mean_103, add_367, rsqrt_151, output_355, float_209, add_368, output_356, hidden_states_238, output_357], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1186, arg694_1, buf1185, arg695_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg694_1
        del arg695_1
        del buf1186
        buf1188 = buf1145; del buf1145  # reuse
        assert_size_stride_grouped((arg696_1, arg697_1), ((9216, 2560), (72, 20)), ((2560, 1), (20, 1)), 'input')
        # Topologically Sorted Source Nodes: [float_208, pow_104, mean_103, add_367, rsqrt_151, output_355, float_209, add_368, output_356, hidden_states_238, output_358], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_3.run(buf1189, arg696_1, buf1188, arg697_1, 1, 9216, 2560, 2560, 1, 1, 2560, 9216, 1, 1, 20, stream=raw_stream0)
        del arg696_1
        del arg697_1
        buf1191 = buf1189; del buf1189  # reuse
        buf1192 = buf1143; del buf1143  # reuse
        # Topologically Sorted Source Nodes: [silu_79, mul_546, output_359], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_mul_silu_15.run(buf1185, buf1188, buf1192, 9216, stream=raw_stream0)
        del buf1185
        del buf1188
        assert_size_stride_grouped((arg698_1, arg699_1), ((2560, 9216), (20, 72)), ((9216, 1), (72, 1)), 'input')
        # Topologically Sorted Source Nodes: [silu_79, mul_546, output_359], Original ATen: [aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        w8a8_block_dynamic_fp8_matmul_kernel_4.run(buf1192, arg698_1, buf1191, arg699_1, 1, 2560, 9216, 9216, 1, 1, 9216, 2560, 1, 1, 72, stream=raw_stream0)
        del arg698_1
        del arg699_1
        del buf1192
        assert_size_stride(arg700_1, (2560, ), (1, ), 'input')
        buf1195 = buf1183; del buf1183  # reuse
        # Topologically Sorted Source Nodes: [hidden_states_239, float_210, pow_105, mean_104, add_370, rsqrt_152, output_360, float_211, add_371, output_361, hidden_states_240], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_mean_mul_pow_rsqrt_36.run(buf1195, buf1191, arg700_1, 1, 2560, stream=raw_stream0)
        del arg700_1
        del buf1191
        assert_size_stride(arg701_1, (248320, 2560), (2560, 1), 'input')
        buf1196 = empty_strided((1, 248320), (248320, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [hidden_states_239, float_210, pow_105, mean_104, add_370, rsqrt_152, output_360, float_211, add_371, output_361, hidden_states_240, getitem_373, logits], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_slice_t_view_37.run(buf1195, arg701_1, buf1196, 15520, 1, 1, stream=raw_stream0)
        del arg701_1
        del buf1195
        # Topologically Sorted Source Nodes: [add_], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__38.run(arg3_1, arg3_1, 1, stream=raw_stream0)
        del arg3_1
        # Topologically Sorted Source Nodes: [getitem_13, copy_], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf11, arg13_1, 32768, stream=raw_stream0)
        del arg13_1
        del buf11
        # Topologically Sorted Source Nodes: [getitem_24, copy__2], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf45, arg35_1, 32768, stream=raw_stream0)
        del arg35_1
        del buf45
        # Topologically Sorted Source Nodes: [getitem_35, copy__4], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf81, arg57_1, 32768, stream=raw_stream0)
        del arg57_1
        del buf81
        # Topologically Sorted Source Nodes: [getitem_58, copy__6], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf160, arg99_1, 32768, stream=raw_stream0)
        del arg99_1
        del buf160
        # Topologically Sorted Source Nodes: [getitem_69, copy__8], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf194, arg121_1, 32768, stream=raw_stream0)
        del arg121_1
        del buf194
        # Topologically Sorted Source Nodes: [getitem_80, copy__10], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf230, arg143_1, 32768, stream=raw_stream0)
        del arg143_1
        del buf230
        # Topologically Sorted Source Nodes: [add__1], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__38.run(arg166_1, arg166_1, 1, stream=raw_stream0)
        del arg166_1
        # Topologically Sorted Source Nodes: [getitem_103, copy__12], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf309, arg186_1, 32768, stream=raw_stream0)
        del arg186_1
        del buf309
        # Topologically Sorted Source Nodes: [getitem_114, copy__14], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf343, arg208_1, 32768, stream=raw_stream0)
        del arg208_1
        del buf343
        # Topologically Sorted Source Nodes: [getitem_125, copy__16], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf379, arg230_1, 32768, stream=raw_stream0)
        del arg230_1
        del buf379
        # Topologically Sorted Source Nodes: [add__2], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__38.run(arg253_1, arg253_1, 1, stream=raw_stream0)
        del arg253_1
        # Topologically Sorted Source Nodes: [getitem_148, copy__18], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf458, arg273_1, 32768, stream=raw_stream0)
        del arg273_1
        del buf458
        # Topologically Sorted Source Nodes: [getitem_159, copy__20], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf492, arg295_1, 32768, stream=raw_stream0)
        del arg295_1
        del buf492
        # Topologically Sorted Source Nodes: [getitem_170, copy__22], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf528, arg317_1, 32768, stream=raw_stream0)
        del arg317_1
        del buf528
        # Topologically Sorted Source Nodes: [add__3], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__38.run(arg340_1, arg340_1, 1, stream=raw_stream0)
        del arg340_1
        # Topologically Sorted Source Nodes: [getitem_193, copy__24], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf607, arg360_1, 32768, stream=raw_stream0)
        del arg360_1
        del buf607
        # Topologically Sorted Source Nodes: [getitem_204, copy__26], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf641, arg382_1, 32768, stream=raw_stream0)
        del arg382_1
        del buf641
        # Topologically Sorted Source Nodes: [getitem_215, copy__28], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf677, arg404_1, 32768, stream=raw_stream0)
        del arg404_1
        del buf677
        # Topologically Sorted Source Nodes: [add__4], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__38.run(arg427_1, arg427_1, 1, stream=raw_stream0)
        del arg427_1
        # Topologically Sorted Source Nodes: [getitem_238, copy__30], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf756, arg447_1, 32768, stream=raw_stream0)
        del arg447_1
        del buf756
        # Topologically Sorted Source Nodes: [getitem_249, copy__32], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf790, arg469_1, 32768, stream=raw_stream0)
        del arg469_1
        del buf790
        # Topologically Sorted Source Nodes: [getitem_260, copy__34], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf826, arg491_1, 32768, stream=raw_stream0)
        del arg491_1
        del buf826
        # Topologically Sorted Source Nodes: [add__5], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__38.run(arg514_1, arg514_1, 1, stream=raw_stream0)
        del arg514_1
        # Topologically Sorted Source Nodes: [getitem_283, copy__36], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf905, arg534_1, 32768, stream=raw_stream0)
        del arg534_1
        del buf905
        # Topologically Sorted Source Nodes: [getitem_294, copy__38], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf939, arg556_1, 32768, stream=raw_stream0)
        del arg556_1
        del buf939
        # Topologically Sorted Source Nodes: [getitem_305, copy__40], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf975, arg578_1, 32768, stream=raw_stream0)
        del arg578_1
        del buf975
        # Topologically Sorted Source Nodes: [add__6], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__38.run(arg601_1, arg601_1, 1, stream=raw_stream0)
        del arg601_1
        # Topologically Sorted Source Nodes: [getitem_328, copy__42], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf1054, arg621_1, 32768, stream=raw_stream0)
        del arg621_1
        del buf1054
        # Topologically Sorted Source Nodes: [getitem_339, copy__44], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf1088, arg643_1, 32768, stream=raw_stream0)
        del arg643_1
        del buf1088
        # Topologically Sorted Source Nodes: [getitem_350, copy__46], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_39.run(buf1124, arg665_1, 32768, stream=raw_stream0)
        del arg665_1
        del buf1124
        # Topologically Sorted Source Nodes: [add__7], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__38.run(arg688_1, arg688_1, 1, stream=raw_stream0)
        del arg688_1
        return (buf1196, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((248320, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((1, 1), (1, 1), device='tnca:0', dtype=torch.int64)
    arg2_1 = rand_strided((4, 1, 1), (1, 1, 1), device='tnca:0', dtype=torch.int64)
    arg3_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg4_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg5_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg6_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg7_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg8_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg9_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg10_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg11_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg12_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg13_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg14_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg15_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg16_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg17_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg18_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg19_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg20_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg21_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg22_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg23_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg24_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg25_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg26_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg27_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg28_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg29_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg30_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg31_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg32_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg33_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg34_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg35_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg36_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg37_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg38_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg39_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg40_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg41_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg42_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg43_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg44_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg45_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg46_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg47_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg48_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg49_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg50_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg51_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg52_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg53_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg54_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg55_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg56_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg57_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg58_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg59_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg60_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg61_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg62_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg63_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg64_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg65_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg66_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg67_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg68_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg69_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg70_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg71_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg72_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg73_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg74_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg75_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg76_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg77_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg78_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg79_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg80_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg81_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg82_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg83_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg84_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg85_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg86_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg87_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg88_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg89_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg90_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg91_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg92_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg93_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg94_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg95_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg96_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg97_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg98_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg99_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg100_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg101_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg102_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg103_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg104_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg105_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg106_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg107_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg108_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg109_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg110_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg111_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg112_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg113_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg114_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg115_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg116_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg117_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg118_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg119_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg120_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg121_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg122_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg123_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg124_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg125_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg126_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg127_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg128_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg129_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg130_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg131_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg132_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg133_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg134_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg135_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg136_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg137_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg138_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg139_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg140_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg141_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg142_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg143_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg144_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg145_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg146_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg147_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg148_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg149_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg150_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg151_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg152_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg153_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg154_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg155_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg156_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg157_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg158_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg159_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg160_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg161_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg162_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg163_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg164_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg165_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg166_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg167_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg168_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg169_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg170_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg171_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg172_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg173_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg174_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg175_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg176_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg177_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg178_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg179_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg180_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg181_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg182_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg183_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg184_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg185_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg186_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg187_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg188_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg189_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg190_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg191_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg192_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg193_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg194_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg195_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg196_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg197_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg198_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg199_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg200_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg201_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg202_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg203_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg204_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg205_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg206_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg207_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg208_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg209_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg210_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg211_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg212_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg213_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg214_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg215_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg216_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg217_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg218_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg219_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg220_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg221_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg222_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg223_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg224_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg225_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg226_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg227_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg228_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg229_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg230_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg231_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg232_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg233_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg234_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg235_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg236_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg237_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg238_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg239_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg240_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg241_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg242_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg243_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg244_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg245_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg246_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg247_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg248_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg249_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg250_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg251_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg252_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg253_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg254_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg255_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg256_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg257_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg258_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg259_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg260_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg261_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg262_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg263_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg264_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg265_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg266_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg267_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg268_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg269_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg270_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg271_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg272_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg273_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg274_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg275_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg276_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg277_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg278_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg279_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg280_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg281_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg282_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg283_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg284_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg285_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg286_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg287_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg288_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg289_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg290_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg291_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg292_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg293_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg294_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg295_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg296_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg297_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg298_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg299_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg300_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg301_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg302_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg303_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg304_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg305_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg306_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg307_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg308_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg309_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg310_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg311_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg312_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg313_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg314_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg315_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg316_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg317_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg318_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg319_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg320_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg321_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg322_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg323_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg324_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg325_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg326_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg327_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg328_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg329_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg330_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg331_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg332_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg333_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg334_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg335_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg336_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg337_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg338_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg339_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg340_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg341_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg342_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg343_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg344_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg345_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg346_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg347_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg348_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg349_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg350_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg351_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg352_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg353_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg354_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg355_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg356_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg357_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg358_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg359_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg360_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg361_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg362_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg363_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg364_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg365_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg366_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg367_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg368_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg369_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg370_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg371_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg372_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg373_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg374_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg375_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg376_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg377_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg378_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg379_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg380_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg381_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg382_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg383_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg384_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg385_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg386_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg387_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg388_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg389_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg390_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg391_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg392_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg393_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg394_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg395_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg396_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg397_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg398_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg399_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg400_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg401_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg402_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg403_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg404_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg405_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg406_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg407_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg408_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg409_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg410_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg411_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg412_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg413_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg414_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg415_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg416_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg417_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg418_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg419_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg420_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg421_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg422_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg423_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg424_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg425_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg426_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg427_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg428_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg429_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg430_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg431_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg432_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg433_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg434_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg435_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg436_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg437_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg438_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg439_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg440_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg441_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg442_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg443_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg444_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg445_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg446_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg447_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg448_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg449_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg450_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg451_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg452_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg453_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg454_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg455_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg456_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg457_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg458_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg459_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg460_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg461_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg462_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg463_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg464_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg465_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg466_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg467_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg468_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg469_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg470_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg471_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg472_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg473_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg474_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg475_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg476_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg477_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg478_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg479_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg480_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg481_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg482_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg483_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg484_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg485_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg486_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg487_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg488_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg489_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg490_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg491_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg492_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg493_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg494_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg495_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg496_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg497_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg498_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg499_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg500_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg501_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg502_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg503_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg504_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg505_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg506_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg507_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg508_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg509_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg510_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg511_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg512_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg513_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg514_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg515_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg516_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg517_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg518_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg519_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg520_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg521_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg522_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg523_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg524_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg525_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg526_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg527_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg528_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg529_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg530_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg531_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg532_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg533_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg534_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg535_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg536_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg537_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg538_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg539_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg540_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg541_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg542_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg543_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg544_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg545_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg546_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg547_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg548_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg549_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg550_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg551_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg552_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg553_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg554_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg555_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg556_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg557_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg558_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg559_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg560_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg561_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg562_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg563_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg564_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg565_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg566_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg567_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg568_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg569_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg570_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg571_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg572_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg573_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg574_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg575_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg576_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg577_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg578_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg579_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg580_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg581_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg582_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg583_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg584_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg585_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg586_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg587_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg588_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg589_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg590_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg591_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg592_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg593_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg594_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg595_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg596_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg597_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg598_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg599_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg600_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg601_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg602_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg603_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg604_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg605_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg606_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg607_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg608_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg609_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg610_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg611_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg612_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg613_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg614_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg615_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg616_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg617_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg618_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg619_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg620_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg621_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg622_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg623_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg624_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg625_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg626_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg627_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg628_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg629_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg630_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg631_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg632_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg633_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg634_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg635_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg636_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg637_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg638_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg639_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg640_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg641_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg642_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg643_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg644_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg645_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg646_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg647_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg648_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg649_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg650_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg651_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg652_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg653_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg654_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg655_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg656_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg657_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg658_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg659_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg660_1 = rand_strided((4096, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg661_1 = rand_strided((32, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg662_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg663_1 = rand_strided((32, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    arg664_1 = rand_strided((8192, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg665_1 = rand_strided((1, 8192, 4), (32768, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg666_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg667_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg668_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg669_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg670_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg671_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg672_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg673_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg674_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg675_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg676_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg677_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg678_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg679_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg680_1 = rand_strided((8192, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg681_1 = rand_strided((64, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg682_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg683_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg684_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg685_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg686_1 = rand_strided((1024, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg687_1 = rand_strided((8, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg688_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg689_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg690_1 = rand_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg691_1 = rand_strided((2560, 4096), (4096, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg692_1 = rand_strided((20, 32), (32, 1), device='tnca:0', dtype=torch.float32)
    arg693_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg694_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg695_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg696_1 = rand_strided((9216, 2560), (2560, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg697_1 = rand_strided((72, 20), (20, 1), device='tnca:0', dtype=torch.float32)
    arg698_1 = rand_strided((2560, 9216), (9216, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg699_1 = rand_strided((20, 72), (72, 1), device='tnca:0', dtype=torch.float32)
    arg700_1 = rand_strided((2560, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg701_1 = rand_strided((248320, 2560), (2560, 1), device='tnca:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1, arg398_1, arg399_1, arg400_1, arg401_1, arg402_1, arg403_1, arg404_1, arg405_1, arg406_1, arg407_1, arg408_1, arg409_1, arg410_1, arg411_1, arg412_1, arg413_1, arg414_1, arg415_1, arg416_1, arg417_1, arg418_1, arg419_1, arg420_1, arg421_1, arg422_1, arg423_1, arg424_1, arg425_1, arg426_1, arg427_1, arg428_1, arg429_1, arg430_1, arg431_1, arg432_1, arg433_1, arg434_1, arg435_1, arg436_1, arg437_1, arg438_1, arg439_1, arg440_1, arg441_1, arg442_1, arg443_1, arg444_1, arg445_1, arg446_1, arg447_1, arg448_1, arg449_1, arg450_1, arg451_1, arg452_1, arg453_1, arg454_1, arg455_1, arg456_1, arg457_1, arg458_1, arg459_1, arg460_1, arg461_1, arg462_1, arg463_1, arg464_1, arg465_1, arg466_1, arg467_1, arg468_1, arg469_1, arg470_1, arg471_1, arg472_1, arg473_1, arg474_1, arg475_1, arg476_1, arg477_1, arg478_1, arg479_1, arg480_1, arg481_1, arg482_1, arg483_1, arg484_1, arg485_1, arg486_1, arg487_1, arg488_1, arg489_1, arg490_1, arg491_1, arg492_1, arg493_1, arg494_1, arg495_1, arg496_1, arg497_1, arg498_1, arg499_1, arg500_1, arg501_1, arg502_1, arg503_1, arg504_1, arg505_1, arg506_1, arg507_1, arg508_1, arg509_1, arg510_1, arg511_1, arg512_1, arg513_1, arg514_1, arg515_1, arg516_1, arg517_1, arg518_1, arg519_1, arg520_1, arg521_1, arg522_1, arg523_1, arg524_1, arg525_1, arg526_1, arg527_1, arg528_1, arg529_1, arg530_1, arg531_1, arg532_1, arg533_1, arg534_1, arg535_1, arg536_1, arg537_1, arg538_1, arg539_1, arg540_1, arg541_1, arg542_1, arg543_1, arg544_1, arg545_1, arg546_1, arg547_1, arg548_1, arg549_1, arg550_1, arg551_1, arg552_1, arg553_1, arg554_1, arg555_1, arg556_1, arg557_1, arg558_1, arg559_1, arg560_1, arg561_1, arg562_1, arg563_1, arg564_1, arg565_1, arg566_1, arg567_1, arg568_1, arg569_1, arg570_1, arg571_1, arg572_1, arg573_1, arg574_1, arg575_1, arg576_1, arg577_1, arg578_1, arg579_1, arg580_1, arg581_1, arg582_1, arg583_1, arg584_1, arg585_1, arg586_1, arg587_1, arg588_1, arg589_1, arg590_1, arg591_1, arg592_1, arg593_1, arg594_1, arg595_1, arg596_1, arg597_1, arg598_1, arg599_1, arg600_1, arg601_1, arg602_1, arg603_1, arg604_1, arg605_1, arg606_1, arg607_1, arg608_1, arg609_1, arg610_1, arg611_1, arg612_1, arg613_1, arg614_1, arg615_1, arg616_1, arg617_1, arg618_1, arg619_1, arg620_1, arg621_1, arg622_1, arg623_1, arg624_1, arg625_1, arg626_1, arg627_1, arg628_1, arg629_1, arg630_1, arg631_1, arg632_1, arg633_1, arg634_1, arg635_1, arg636_1, arg637_1, arg638_1, arg639_1, arg640_1, arg641_1, arg642_1, arg643_1, arg644_1, arg645_1, arg646_1, arg647_1, arg648_1, arg649_1, arg650_1, arg651_1, arg652_1, arg653_1, arg654_1, arg655_1, arg656_1, arg657_1, arg658_1, arg659_1, arg660_1, arg661_1, arg662_1, arg663_1, arg664_1, arg665_1, arg666_1, arg667_1, arg668_1, arg669_1, arg670_1, arg671_1, arg672_1, arg673_1, arg674_1, arg675_1, arg676_1, arg677_1, arg678_1, arg679_1, arg680_1, arg681_1, arg682_1, arg683_1, arg684_1, arg685_1, arg686_1, arg687_1, arg688_1, arg689_1, arg690_1, arg691_1, arg692_1, arg693_1, arg694_1, arg695_1, arg696_1, arg697_1, arg698_1, arg699_1, arg700_1, arg701_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
