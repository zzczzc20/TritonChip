    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // SRC: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // DST: device_ptr64 at arg_base+8
__rctx_program:
    s.shli       s1, s2, #7                      // x128 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #32
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #48
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #64
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #80
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #96
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #112
    v.iota       v14                             // arange(0, VLEN)
    v.add        v15, v0, v1
    v.add        v0, v2, v3
    v.add        v1, v4, v5
    v.add        v2, v6, v7
    v.add        v3, v8, v9
    v.add        v4, v10, v11
    v.add        v5, v12, v13
    v.splat      v6, s1
    v.splat      v7, s1
    v.splat      v8, s1
    v.splat      v9, s1
    v.splat      v10, s1
    v.splat      v11, s1
    v.splat      v12, s1
    v.splat      v13, s1
    v.add        v16, v6, v14
    v.add        v6, v7, v15
    v.add        v7, v8, v0
    v.add        v0, v9, v1
    v.add        v1, v10, v2
    v.add        v2, v11, v3
    v.add        v3, v12, v4
    v.add        v4, v13, v5
    v.movi       v5, #0
    v.movi       v8, #0
    v.movi       v9, #0
    v.movi       v10, #0
    v.sub        v11, v5, v16
    v.sub        v12, v8, v6
    v.sub        v13, v9, v7
    v.sub        v14, v10, v0
    v.cmp.lt     p1, v16, v5
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v7, v9
    @p1 v.sel        v15, v11, v16
    v.movi       v11, #1
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #1
    @p3 v.sel        v18, v13, v7
    v.movi       v13, #1
    v.movi       v19, #1
    v.lshr       v20, v15, v11
    v.lshr       v11, v17, v12
    v.lshr       v12, v18, v13
    v.sub        v13, v5, v20
    v.sub        v15, v8, v11
    v.sub        v17, v9, v12
    v.movi       v18, #2
    v.movi       v21, #0
    @p1 v.sel        v22, v13, v20
    v.cmp.lt     p1, v0, v10
    @p1 v.sel        v13, v14, v0
    v.movi       v14, #2
    v.lshr       v20, v13, v19
    @p2 v.sel        v13, v15, v11
    v.cmp.lt     p2, v1, v21
    v.sub        v11, v10, v20
    v.movi       v15, #2
    @p3 v.sel        v19, v17, v12
    v.movi       v12, #2
    @p1 v.sel        v17, v11, v20
    v.movi       v11, #2
    v.sub        v20, v5, v18
    v.sub        v23, v8, v14
    v.sub        v24, v9, v15
    v.sub        v25, v10, v12
    v.cmp.lt     p1, v18, v5
    v.sub        v5, v21, v1
    v.sub        v26, v21, v11
    @p2 v.sel        v27, v5, v1
    v.cmp.lt     p3, v14, v8
    @p1 v.sel        v5, v20, v18
    v.movi       v5, #0
    v.movi       v8, #1
    v.sub        v20, v5, v2
    v.cmp.lt     p1, v2, v5
    @p1 v.sel        v28, v20, v2
    v.lshr       v20, v27, v8
    v.movi       v8, #2
    v.sub        v27, v21, v20
    v.sub        v29, v5, v8
    @p2 v.sel        v30, v27, v20
    v.cmp.lt     p2, v15, v9
    @p3 v.sel        v9, v23, v14
    v.movi       v9, #0
    v.movi       v20, #1
    v.sub        v23, v9, v3
    v.cmp.lt     p3, v3, v9
    @p3 v.sel        v27, v23, v3
    v.lshr       v23, v28, v20
    v.movi       v20, #2
    v.sub        v28, v5, v23
    v.sub        v31, v9, v20
    @p1 v.sel        v32, v28, v23
    v.cmp.lt     p1, v12, v10
    @p2 v.sel        v10, v24, v15
    v.movi       v10, #0
    v.movi       v23, #1
    v.sub        v24, v10, v4
    v.cmp.lt     p2, v4, v10
    @p2 v.sel        v28, v24, v4
    v.lshr       v24, v27, v23
    v.movi       v23, #2
    v.sub        v27, v9, v24
    v.sub        v33, v10, v23
    @p3 v.sel        v34, v27, v24
    v.cmp.lt     p3, v11, v21
    @p1 v.sel        v21, v25, v12
    v.movi       v21, #0
    v.movi       v24, #1
    v.sub        v25, v21, v16
    v.cmp.lt     p1, v16, v21
    v.lshr       v27, v28, v24
    @p1 v.sel        v24, v25, v16
    v.sub        v25, v10, v27
    v.sub        v28, v21, v18
    @p2 v.sel        v35, v25, v27
    v.cmp.lt     p2, v8, v5
    @p3 v.sel        v5, v26, v11
    v.movi       v5, #0
    v.movi       v25, #1
    v.sub        v26, v5, v6
    v.cmp.lt     p3, v6, v5
    @p3 v.sel        v27, v26, v6
    v.movi       v26, #1
    v.and        v36, v24, v25
    v.sub        v24, v5, v14
    v.sub        v25, v21, v36
    @p2 v.sel        v37, v29, v8
    v.movi       v29, #0
    v.and        v37, v27, v26
    v.sub        v26, v29, v7
    v.cmp.lt     p2, v7, v29
    @p2 v.sel        v27, v26, v7
    v.sub        v26, v5, v37
    @p1 v.sel        v38, v25, v36
    @p3 v.sel        v25, v26, v37
    v.cmp.lt     p1, v20, v9
    v.movi       v9, #1
    v.sub        v26, v29, v15
    v.and        v36, v27, v9
    v.cmp.lt     p3, v23, v10
    @p1 v.sel        v9, v31, v20
    v.movi       v9, #0
    v.movi       v10, #1
    v.sub        v27, v9, v0
    v.cmp.lt     p1, v0, v9
    @p1 v.sel        v31, v27, v0
    v.sub        v27, v29, v36
    v.and        v37, v31, v10
    @p2 v.sel        v10, v27, v36
    v.sub        v27, v9, v37
    v.sub        v31, v9, v12
    v.cmp.lt     p2, v18, v21
    @p3 v.sel        v21, v33, v23
    v.movi       v21, #0
    v.movi       v33, #1
    v.sub        v36, v21, v1
    v.cmp.lt     p3, v1, v21
    @p3 v.sel        v39, v36, v1
    @p1 v.sel        v36, v27, v37
    v.and        v27, v39, v33
    v.sub        v33, v21, v11
    v.sub        v37, v21, v27
    v.cmp.lt     p1, v14, v5
    @p2 v.sel        v5, v28, v18
    v.movi       v5, #0
    v.movi       v28, #1
    v.sub        v39, v5, v2
    v.cmp.lt     p2, v2, v5
    @p2 v.sel        v40, v39, v2
    @p3 v.sel        v39, v37, v27
    v.and        v27, v40, v28
    v.sub        v28, v5, v8
    v.sub        v37, v5, v27
    v.cmp.lt     p3, v15, v29
    @p1 v.sel        v29, v24, v14
    v.movi       v24, #0
    v.movi       v29, #1
    v.sub        v40, v24, v3
    v.cmp.lt     p1, v3, v24
    @p1 v.sel        v41, v40, v3
    @p2 v.sel        v40, v37, v27
    v.and        v27, v41, v29
    v.sub        v29, v24, v20
    v.sub        v37, v24, v27
    v.cmp.lt     p2, v12, v9
    @p3 v.sel        v9, v26, v15
    v.movi       v9, #0
    v.movi       v26, #1
    v.sub        v41, v9, v4
    v.cmp.lt     p3, v4, v9
    @p3 v.sel        v42, v41, v4
    @p1 v.sel        v41, v37, v27
    v.and        v27, v42, v26
    v.sub        v26, v9, v23
    v.sub        v37, v9, v27
    v.cmp.lt     p1, v11, v21
    @p2 v.sel        v21, v31, v12
    @p3 v.sel        v21, v37, v27
    v.mul        v27, v22, v18
    v.mul        v22, v13, v14
    v.mul        v13, v19, v15
    v.mul        v19, v17, v12
    v.mul        v17, v30, v11
    v.mul        v30, v32, v8
    v.mul        v31, v34, v20
    v.mul        v32, v35, v23
    v.add        v34, v27, v38                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p2, v16, v18
    v.cmp.lt     p3, v8, v5
    @p1 v.sel        v5, v33, v11
    v.add        v5, v22, v25                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v33, v13, v10                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v35, v19, v36                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v14
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v37, [s3, v34]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v15
    @p3 v.sel        v34, v28, v8
    v.add        v28, v17, v39                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v34, v30, v40                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v42, v31, v41                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p3, v0, v12
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v43, [s3, v5]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v5, [s3, v33]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v8
    v.movi       v33, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v33, [s3, v35]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v3, v20
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v35, [s3, v28]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v20, v24
    v.add        v24, v32, v21                   // per-lane offsets add up, in elements (ISA sec 9.1)
    @p1 v.sel        v28, v29, v20
    v.cmp.lt     p1, v4, v23
    v.add        v28, v27, v38                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v27, v22, v25                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v22, [s3, v34]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v23, v9
    v.add        v9, v13, v10                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v10, v19, v36                   // per-lane offsets add up, in elements (ISA sec 9.1)
    @p2 v.sel        v13, v26, v23
    v.add        v13, v17, v39                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v17, v30, v40                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v19, v31, v41                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v25, v32, v21                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p2, v16, v18
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v16, [s3, v42]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v14
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v6, [s3, v24]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v15
    @p2 v.st.scatter.b [s5, v28], v37
    v.cmp.lt     p2, v0, v12
    @p3 v.st.scatter.b [s5, v27], v43
    v.cmp.lt     p3, v1, v11
    @p1 v.st.scatter.b [s5, v9], v5
    v.cmp.lt     p1, v2, v8
    @p2 v.st.scatter.b [s5, v10], v33
    v.cmp.lt     p2, v3, v20
    @p3 v.st.scatter.b [s5, v13], v35
    v.cmp.lt     p3, v4, v23
    @p1 v.st.scatter.b [s5, v17], v22
    @p2 v.st.scatter.b [s5, v19], v16
    @p3 v.st.scatter.b [s5, v25], v6
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s6, s1, s4
    s.mov        s2, s1
    br.nz        s6, __rctx_program
    exit
