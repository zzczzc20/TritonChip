#!/bin/bash
set -u
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg"
cd "$HOME/r41_k32_descriptor_v5_20261031" || exit 1
root="$HOME/r41_k32_descriptor_roles_v5_results_20261031";mkdir "$root" || exit 1
bad=0
for k in 32 64 96;do
 for kind in unrolled rolled;do
  for mode in control candidate;do
   if [[ "$mode" == control ]];then export TNCA_FP8_FORCE_K32=0;else unset TNCA_FP8_FORCE_K32;fi
   flags=();if [[ "$kind" == rolled ]];then flags+=(--rolled);fi
   label="${mode}_${kind}_${k}"
   "$HOME/flux-venv/bin/python" -u tools/r41/chat_speed/bench_descriptor_roles_k32.py --k "$k" "${flags[@]}" --out "$root/$label" > "$root/$label.log" 2>&1
   rc=$?;echo "$label exit=$rc" | tee -a "$root/status.log";if [[ "$rc" != 0 ]];then bad=1;fi
  done
done
done
exit "$bad"
