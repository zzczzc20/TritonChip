#!/usr/bin/env bash
set -eu
route=$1; m=$2
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= HF_HUB_OFFLINE=1
export HF_HOME="$HOME/r41-fp8-kern-hf"
export TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip"
export TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg"
export TNCA_TLM_OUT="$HOME/r41_astage_proof_${route}_${m}_tlm" TNCA_HOST_TIMEOUT=180
export TNCA_X8_EQUAL_A_STAGE="$route" TNCA_TRACE_EQUAL_A=1
cd "$HOME/r41_chat_astage_proof_20261031"
exec "$HOME/flux-venv/bin/python" -u tools/r41/chat_speed/bench_hoisted_fp8.py --route fused --default-div --m "$m" --n 256 --k 256 --v1 "$HOME/r41-fp8-kern-hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/48f42b23bb4e0122d4775c6d16753dd2efc7f580" --out "$HOME/r41_astage_proof_${route}_${m}"
