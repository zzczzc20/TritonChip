import subprocess,time
from pathlib import Path
home=Path.home()
units=[f'r41-x8-equal-output-vl-l1-{i}-20261101' for i in (0,1)]
while True:
 states=[subprocess.run(['systemctl','--user','show',u,'-p','ActiveState','--value'],text=True,capture_output=True).stdout.strip() for u in units]
 if all(s not in ('active','activating','reloading') for s in states):break
 time.sleep(30)
for i in (0,1):
 if not (home/f'r41_x8_equal_output_vl_l1_{i}_20261101/report.json').is_file():raise RuntimeError(f'profile {i} produced no report')
subprocess.run([str(home/'flux-venv/bin/python'),str(home/'r41_x8_equal_output_vl_l1_compare_20261101.py'),'--model','model','--tree',str(home/'r41_current_x8_equal_output_20261101'),'--out',str(home/'r41_x8_equal_output_vl_l1_compare_20261101.json')],check=True)
