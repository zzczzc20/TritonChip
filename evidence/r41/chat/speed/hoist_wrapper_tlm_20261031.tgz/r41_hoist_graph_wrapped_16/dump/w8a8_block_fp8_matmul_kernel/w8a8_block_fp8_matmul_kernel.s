    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #48]                   // N: i32 at arg_base+48
    s.movz       s4, #0
    s.movz       s5, #128
    s.movz       s6, #15
    s.cmp.lt     s7, s5, s4
    s.rdspecial  s8, pid.x
    s.sub        s9, s4, s7
    s.rdspecial  s7, pid.y
    s.movz       s10, #16
    s.xor        s11, s5, s9
    s.cmp.lt     s12, s10, s4
    s.add        s13, s3, s2
    s.ld.sw      s14, [s1, #40]                  // M: i32 at arg_base+40
    s.cmp.lt     s15, s13, s4
    s.sub        s16, s4, s12
    s.sub        s12, s4, s15
    s.xor        s15, s10, s16
    s.xor        s17, s13, s12
    s.xor        s13, s12, s9
    s.sub        s18, s17, s12
    s.sub        s12, s15, s16
    s.lshri      s12, s18, #7
    s.sub        s15, s11, s9
    s.add        s9, s14, s6
    s.muli       s6, s12, #128
    s.cmp.lt     s11, s9, s4
    s.ld.d       s15, [s1, #0]                   // A: device_ptr64 at arg_base+0
    s.xor        s17, s12, s13
    s.sub        s12, s4, s11
    s.sub        s11, s18, s6
    s.xor        s6, s9, s12
    s.xor        s9, s12, s16
    s.sub        s11, s6, s12
    s.lshri      s6, s11, #4
    s.muli       s12, s6, #16
    s.xor        s16, s6, s9
    s.ld.d       s6, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.sub        s18, s17, s13
    s.sub        s13, s16, s9
    s.sub        s9, s11, s12
    s.ld.d       s9, [s1, #16]                   // C: device_ptr64 at arg_base+16
    s.mul        s11, s8, s18
    s.ld.d       s8, [s1, #24]                   // As: device_ptr64 at arg_base+24
    s.add        s12, s11, s7
    s.ld.d       s7, [s1, #32]                   // Bs: device_ptr64 at arg_base+32
    s.movz       s11, #8
    s.cmp.lt     s16, s12, s4
    s.mul        s17, s18, s11
    s.ld.sw      s18, [s1, #56]                  // K: i32 at arg_base+56
    s.sub        s19, s4, s16
    s.ld.sw      s16, [s1, #64]                  // stride_am: i32 at arg_base+64
    s.cmp.lt     s20, s17, s4
    s.ld.sw      s21, [s1, #72]                  // stride_bn: i32 at arg_base+72
    s.sub        s22, s4, s20
    s.ld.sw      s20, [s1, #80]                  // stride_cm: i32 at arg_base+80
    s.xor        s23, s12, s19
    s.ld.sw      s24, [s1, #88]                  // stride_as_m: i32 at arg_base+88
    s.sub        s25, s23, s19
    s.ld.sw      s23, [s1, #96]                  // stride_bs_n: i32 at arg_base+96
    s.xor        s1, s17, s22
    s.movz       s26, #1
    s.sub        s27, s1, s22
    s.addi       s1, s4, #0
    s.cmp.eq     s28, s27, s26
    s.addi       s29, s4, #0
    s.mov        s1, s25
    br.nz        s28, sdiv_done_1
    s.movz       s4, #0
    s.movz       s28, #31
    s.mov        s1, s4
    s.addi       s4, s28, #0
sdiv_2:
    s.lshr       s28, s25, s4
    s.shli       s30, s29, #1
    s.andi       s31, s28, #1
    s.movz       s28, #0
    s.or         s32, s30, s31
    s.shl        s30, s26, s4
    s.cmp.geu    s31, s32, s27
    s.subi       s33, s4, #1
    s.sub        s34, s28, s31
    s.and        s31, s27, s34
    s.and        s35, s30, s34
    s.sub        s30, s32, s31
    s.or         s31, s1, s35
    s.mov        s29, s30
    s.mov        s1, s31
    s.mov        s4, s33
    s.cmp.ge     s30, s4, s28
    br.nz        s30, sdiv_2
sdiv_done_1:
    s.xor        s4, s19, s22
    s.movz       s19, #0
    s.xor        s22, s1, s4
    s.cmp.lt     s1, s17, s19
    s.sub        s25, s22, s4
    s.cmp.lt     s4, s12, s19
    s.sub        s22, s19, s1
    s.mul        s1, s25, s11
    s.sub        s25, s19, s4
    s.xor        s4, s17, s22
    s.xor        s17, s12, s25
    s.sub        s12, s4, s22
    s.sub        s4, s13, s1
    s.sub        s13, s17, s25
    s.addi       s17, s19, #0
    s.cmp.eq     s22, s12, s26
    s.min.s      s26, s4, s11
    s.addi       s4, s19, #0
    s.mov        s17, s13
    br.nz        s22, sdiv_done_3
    s.movz       s11, #0
    s.movz       s22, #31
    s.mov        s17, s11
    s.addi       s11, s22, #0
sdiv_4:
    s.lshr       s22, s13, s11
    s.shli       s27, s4, #1
    s.andi       s28, s22, #1
    s.movz       s22, #1
    s.or         s29, s27, s28
    s.shl        s27, s22, s11
    s.cmp.geu    s22, s29, s12
    s.subi       s28, s11, #1
    s.sub        s30, s19, s22
    s.and        s22, s12, s30
    s.and        s31, s27, s30
    s.sub        s27, s29, s22
    s.or         s22, s17, s31
    s.mov        s4, s27
    s.mov        s17, s22
    s.mov        s11, s28
    s.cmp.ge     s22, s11, s19
    br.nz        s22, sdiv_4
sdiv_done_3:
    s.xor        s11, s4, s25
    s.cmp.lt     s4, s26, s19
    s.sub        s12, s11, s25
    s.sub        s11, s19, s4
    s.cmp.lt     s4, s12, s19
    s.xor        s13, s26, s11
    s.sub        s17, s19, s4
    s.sub        s4, s13, s11
    s.xor        s11, s12, s17
    s.movz       s13, #1
    s.sub        s22, s11, s17
    s.addi       s11, s19, #0
    s.cmp.eq     s25, s4, s13
    s.addi       s27, s19, #0
    s.mov        s11, s22
    br.nz        s25, sdiv_done_5
    s.movz       s19, #0
    s.movz       s25, #31
    s.mov        s11, s19
    s.addi       s19, s25, #0
sdiv_6:
    s.lshr       s25, s22, s19
    s.shli       s28, s27, #1
    s.andi       s29, s25, #1
    s.movz       s25, #0
    s.or         s30, s28, s29
    s.shl        s28, s13, s19
    s.cmp.geu    s29, s30, s4
    s.subi       s31, s19, #1
    s.sub        s32, s25, s29
    s.and        s29, s4, s32
    s.and        s33, s28, s32
    s.sub        s28, s30, s29
    s.or         s29, s11, s33
    s.mov        s27, s28
    s.mov        s11, s29
    s.mov        s19, s31
    s.cmp.ge     s28, s19, s25
    br.nz        s28, sdiv_6
sdiv_done_5:
    s.movz       s4, #0
    s.xor        s11, s27, s17
    s.cmp.lt     s19, s26, s4
    s.cmp.lt     s22, s12, s4
    s.sub        s25, s4, s19
    s.sub        s19, s4, s22
    s.xor        s22, s26, s25
    s.xor        s26, s12, s19
    s.sub        s12, s22, s25
    s.sub        s22, s11, s17
    s.sub        s11, s26, s19
    s.addi       s17, s4, #0
    s.cmp.eq     s26, s12, s13
    s.add        s13, s1, s22
    s.addi       s1, s4, #0
    s.mov        s17, s11
    br.nz        s26, sdiv_done_7
    s.movz       s22, #0
    s.movz       s26, #31
    s.mov        s17, s22
    s.addi       s22, s26, #0
sdiv_8:
    s.lshr       s26, s11, s22
    s.shli       s27, s1, #1
    s.andi       s28, s26, #1
    s.movz       s26, #1
    s.or         s29, s27, s28
    s.shl        s27, s26, s22
    s.cmp.geu    s26, s29, s12
    s.subi       s28, s22, #1
    s.sub        s30, s4, s26
    s.and        s26, s12, s30
    s.and        s31, s27, s30
    s.sub        s27, s29, s26
    s.or         s26, s17, s31
    s.mov        s1, s27
    s.mov        s17, s26
    s.mov        s22, s28
    s.cmp.ge     s26, s22, s4
    br.nz        s26, sdiv_8
sdiv_done_7:
    s.mul        s1, s13, s10
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s14
    v.movi       v2, #0
    s.xor        s4, s19, s25
    v.splat      v3, s1
    v.sub        v4, v2, v1
    s.xor        s11, s17, s4
    v.add        v5, v3, v0
    v.cmp.lt     p1, v1, v2
    s.sub        s12, s11, s4
    v.sub        v0, v2, v5
    v.cmp.lt     p2, v5, v2
    v.movi       v3, #1
    @p2 v.sel        v6, v0, v5
    @p1 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s4, #31
idiv_9:
    v.splat      v5, s4
    v.shl        v7, v4, v3
    v.cmp.lt     p1, v4, v2
    v.lshr       v8, v6, v5
    v.shl        v9, v3, v5
    s.subi       s11, s4, #1
    v.and        v5, v8, v3
    s.movz       s13, #0
    v.or         v8, v7, v5
    v.cmp.geu    p3, v8, v0
    p.or         p4, p1, p3
    v.sub        v5, v8, v0
    @p4 v.sel        v7, v9, v2
    @p4 v.sel        v9, v5, v8
    v.or         v5, v1, v7
    v.mov        v4, v9
    v.mov        v1, v5
    s.mov        s4, s11
    s.cmp.ge     s11, s4, s13
    br.nz        s11, idiv_9
    s.mul        s4, s12, s5
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.movi       v3, #32
    v.movi       v5, #48
    v.splat      v6, s4
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #64
    v.movi       v9, #80
    v.movi       v10, #96
    v.iota       v11                             // arange(0, VLEN)
    v.movi       v12, #112
    v.add        v13, v6, v0
    v.splat      v14, s3
    v.movi       v15, #0
    v.sub        v16, v2, v4
    v.add        v2, v0, v1
    v.add        v1, v0, v3
    v.add        v3, v0, v5
    v.add        v0, v7, v8
    v.add        v5, v7, v9
    v.add        v8, v7, v10
    v.add        v7, v11, v12
    v.sub        v9, v15, v13
    v.sub        v10, v15, v14
    v.cmp.lt     p1, v13, v15
    v.cmp.lt     p3, v14, v15
    @p2 v.sel        v11, v16, v4
    v.add        v4, v6, v2
    v.add        v2, v6, v1
    v.add        v1, v6, v3
    v.add        v3, v6, v0
    v.add        v0, v6, v5
    v.add        v5, v6, v8
    v.add        v8, v6, v7
    v.movi       v6, #1
    @p1 v.sel        v7, v9, v13
    @p3 v.sel        v9, v10, v14
    v.movi       v10, #0
    v.movi       v12, #0
    s.movz       s11, #31
idiv_10:
    v.splat      v13, s11
    v.shl        v16, v12, v6
    v.cmp.lt     p2, v12, v15
    v.lshr       v17, v7, v13
    v.shl        v18, v6, v13
    s.subi       s12, s11, #1
    v.and        v13, v17, v6
    s.movz       s13, #0
    v.or         v17, v16, v13
    v.cmp.geu    p3, v17, v9
    p.or         p4, p2, p3
    v.sub        v13, v17, v9
    @p4 v.sel        v16, v18, v15
    @p4 v.sel        v18, v13, v17
    v.or         v13, v10, v16
    v.mov        v12, v18
    v.mov        v10, v13
    s.mov        s11, s12
    s.cmp.ge     s12, s11, s13
    br.nz        s12, idiv_10
    v.movi       v6, #0
    v.sub        v7, v15, v12
    v.movi       v9, #1
    v.sub        v10, v6, v4
    v.sub        v13, v6, v14
    v.cmp.lt     p2, v4, v6
    v.cmp.lt     p3, v14, v6
    @p1 v.sel        v15, v7, v12
    @p2 v.sel        v7, v10, v4
    @p3 v.sel        v4, v13, v14
    v.movi       v10, #0
    v.movi       v12, #0
    s.movz       s11, #31
idiv_11:
    v.splat      v13, s11
    v.shl        v16, v12, v9
    v.cmp.lt     p1, v12, v6
    v.lshr       v17, v7, v13
    v.shl        v18, v9, v13
    s.subi       s12, s11, #1
    v.and        v13, v17, v9
    v.or         v17, v16, v13
    v.cmp.geu    p3, v17, v4
    p.or         p4, p1, p3
    v.sub        v13, v17, v4
    @p4 v.sel        v16, v18, v6
    @p4 v.sel        v18, v13, v17
    v.or         v13, v10, v16
    v.mov        v12, v18
    v.mov        v10, v13
    s.mov        s11, s12
    s.cmp.ge     s12, s11, s13
    br.nz        s12, idiv_11
    v.movi       v4, #0
    v.sub        v7, v6, v12
    v.movi       v6, #1
    v.sub        v9, v4, v2
    v.sub        v10, v4, v14
    v.cmp.lt     p1, v2, v4
    v.cmp.lt     p3, v14, v4
    @p2 v.sel        v13, v7, v12
    @p1 v.sel        v7, v9, v2
    @p3 v.sel        v2, v10, v14
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s11, #31
idiv_12:
    v.splat      v12, s11
    v.shl        v16, v10, v6
    v.cmp.lt     p2, v10, v4
    v.lshr       v17, v7, v12
    v.shl        v18, v6, v12
    s.subi       s12, s11, #1
    v.and        v12, v17, v6
    s.movz       s13, #0
    v.or         v17, v16, v12
    v.cmp.geu    p3, v17, v2
    p.or         p4, p2, p3
    v.sub        v12, v17, v2
    @p4 v.sel        v16, v18, v4
    @p4 v.sel        v18, v12, v17
    v.or         v12, v9, v16
    v.mov        v10, v18
    v.mov        v9, v12
    s.mov        s11, s12
    s.cmp.ge     s12, s11, s13
    br.nz        s12, idiv_12
    v.movi       v2, #0
    v.sub        v6, v4, v10
    v.movi       v4, #1
    v.sub        v7, v2, v1
    v.sub        v9, v2, v14
    v.cmp.lt     p2, v1, v2
    v.cmp.lt     p3, v14, v2
    @p1 v.sel        v12, v6, v10
    @p2 v.sel        v6, v7, v1
    @p3 v.sel        v1, v9, v14
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s11, #31
idiv_13:
    v.splat      v10, s11
    v.shl        v16, v9, v4
    v.cmp.lt     p1, v9, v2
    v.lshr       v17, v6, v10
    v.shl        v18, v4, v10
    s.subi       s12, s11, #1
    v.and        v10, v17, v4
    v.or         v17, v16, v10
    v.cmp.geu    p3, v17, v1
    p.or         p4, p1, p3
    v.sub        v10, v17, v1
    @p4 v.sel        v16, v18, v2
    @p4 v.sel        v18, v10, v17
    v.or         v10, v7, v16
    v.mov        v9, v18
    v.mov        v7, v10
    s.mov        s11, s12
    s.cmp.ge     s12, s11, s13
    br.nz        s12, idiv_13
    v.movi       v1, #0
    v.sub        v4, v2, v9
    v.movi       v2, #1
    v.sub        v6, v1, v3
    v.sub        v7, v1, v14
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p3, v14, v1
    @p2 v.sel        v10, v4, v9
    @p1 v.sel        v4, v6, v3
    @p3 v.sel        v3, v7, v14
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s11, #31
idiv_14:
    v.splat      v9, s11
    v.shl        v16, v7, v2
    v.cmp.lt     p2, v7, v1
    v.lshr       v17, v4, v9
    v.shl        v18, v2, v9
    s.subi       s12, s11, #1
    v.and        v9, v17, v2
    s.movz       s13, #0
    v.or         v17, v16, v9
    v.cmp.geu    p3, v17, v3
    p.or         p4, p2, p3
    v.sub        v9, v17, v3
    @p4 v.sel        v16, v18, v1
    @p4 v.sel        v18, v9, v17
    v.or         v9, v6, v16
    v.mov        v7, v18
    v.mov        v6, v9
    s.mov        s11, s12
    s.cmp.ge     s12, s11, s13
    br.nz        s12, idiv_14
    v.movi       v2, #0
    v.sub        v3, v1, v7
    v.movi       v1, #1
    v.sub        v4, v2, v0
    v.sub        v6, v2, v14
    v.cmp.lt     p2, v0, v2
    v.cmp.lt     p3, v14, v2
    @p1 v.sel        v9, v3, v7
    @p2 v.sel        v3, v4, v0
    @p3 v.sel        v0, v6, v14
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s11, #31
idiv_15:
    v.splat      v7, s11
    v.shl        v16, v6, v1
    v.cmp.lt     p1, v6, v2
    v.lshr       v17, v3, v7
    v.shl        v18, v1, v7
    s.subi       s12, s11, #1
    v.and        v7, v17, v1
    v.or         v17, v16, v7
    v.cmp.geu    p3, v17, v0
    p.or         p4, p1, p3
    v.sub        v7, v17, v0
    @p4 v.sel        v16, v18, v2
    @p4 v.sel        v18, v7, v17
    v.or         v7, v4, v16
    v.mov        v6, v18
    v.mov        v4, v7
    s.mov        s11, s12
    s.cmp.ge     s12, s11, s13
    br.nz        s12, idiv_15
    v.movi       v0, #0
    v.sub        v1, v2, v6
    v.movi       v2, #1
    v.sub        v3, v0, v5
    v.sub        v4, v0, v14
    v.cmp.lt     p1, v5, v0
    v.cmp.lt     p3, v14, v0
    @p2 v.sel        v7, v1, v6
    @p1 v.sel        v1, v3, v5
    @p3 v.sel        v3, v4, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s11, #31
idiv_16:
    v.splat      v6, s11
    v.shl        v16, v5, v2
    v.cmp.lt     p2, v5, v0
    v.lshr       v17, v1, v6
    v.shl        v18, v2, v6
    s.subi       s12, s11, #1
    v.and        v6, v17, v2
    s.movz       s13, #0
    v.or         v17, v16, v6
    v.cmp.geu    p3, v17, v3
    p.or         p4, p2, p3
    v.sub        v6, v17, v3
    @p4 v.sel        v16, v18, v0
    @p4 v.sel        v18, v6, v17
    v.or         v6, v4, v16
    v.mov        v5, v18
    v.mov        v4, v6
    s.mov        s11, s12
    s.cmp.ge     s12, s11, s13
    br.nz        s12, idiv_16
    v.movi       v1, #0
    v.sub        v2, v0, v5
    v.movi       v0, #1
    v.sub        v3, v1, v8
    v.sub        v4, v1, v14
    v.cmp.lt     p2, v8, v1
    v.cmp.lt     p3, v14, v1
    @p1 v.sel        v6, v2, v5
    @p2 v.sel        v2, v3, v8
    @p3 v.sel        v3, v4, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s11, #31
idiv_17:
    v.splat      v8, s11
    v.shl        v14, v5, v0
    v.cmp.lt     p1, v5, v1
    v.lshr       v16, v2, v8
    v.shl        v17, v0, v8
    s.subi       s12, s11, #1
    v.and        v8, v16, v0
    v.or         v16, v14, v8
    v.cmp.geu    p3, v16, v3
    p.or         p4, p1, p3
    v.sub        v8, v16, v3
    @p4 v.sel        v14, v17, v1
    @p4 v.sel        v17, v8, v16
    v.or         v8, v4, v14
    v.mov        v5, v17
    v.mov        v4, v8
    s.mov        s11, s12
    s.cmp.ge     s12, s11, s13
    br.nz        s12, idiv_17
    v.sub        v0, v1, v5
    v.movi       v1, #0
    v.movi       v2, #0
    @p2 v.sel        v3, v0, v5
    v.movi       v0, #0
    v.sub        v4, v1, v15
    v.sub        v5, v2, v13
    v.sub        v8, v0, v12
    v.cmp.lt     p1, v15, v1
    v.cmp.lt     p2, v13, v2
    v.cmp.lt     p3, v12, v0
    @p1 v.sel        v14, v4, v15
    v.movi       v4, #7
    @p2 v.sel        v16, v5, v13
    v.movi       v5, #7
    @p3 v.sel        v17, v8, v12
    v.movi       v8, #7
    v.lshr       v18, v14, v4
    v.lshr       v4, v16, v5
    v.lshr       v5, v17, v8
    v.movi       v8, #128
    v.sub        v14, v1, v18
    v.movi       v16, #128
    v.sub        v17, v2, v4
    v.movi       v19, #128
    v.sub        v20, v0, v5
    v.movi       v21, #128
    v.splat      v22, s24
    v.sub        v23, v1, v8
    @p1 v.sel        v24, v14, v18
    v.sub        v14, v2, v16
    @p2 v.sel        v18, v17, v4
    v.sub        v4, v0, v19
    @p3 v.sel        v17, v20, v5
    v.cmp.lt     p1, v8, v1
    v.cmp.lt     p2, v16, v2
    v.cmp.lt     p3, v19, v0
    s.movz       s11, #32
    v.movi       v0, #0
    s.movz       s12, #48
    s.movz       s13, #64
    s.movz       s17, #80
    s.movz       s19, #96
    v.sub        v1, v0, v10
    s.movz       s22, #112
    v.sub        v2, v0, v21
    v.mul        v5, v11, v22
    v.movi       v20, #7
    v.movi       v22, #1
    v.movi       v22, #0
    @p1 v.sel        v25, v23, v8
    v.cmp.lt     p1, v10, v0
    v.sub        v8, v22, v9
    @p1 v.sel        v23, v1, v10
    v.movi       v1, #7
    v.movi       v25, #1
    v.lshr       v25, v23, v20
    v.movi       v20, #0
    @p2 v.sel        v23, v14, v16
    v.cmp.lt     p2, v9, v22
    v.sub        v14, v20, v7
    @p2 v.sel        v16, v8, v9
    v.movi       v8, #7
    v.movi       v23, #1
    v.lshr       v23, v16, v1
    v.movi       v1, #0
    @p3 v.sel        v16, v4, v19
    v.cmp.lt     p3, v7, v20
    v.sub        v4, v1, v6
    @p3 v.sel        v16, v14, v7
    v.movi       v14, #7
    v.movi       v19, #1
    v.lshr       v19, v16, v8
    v.sub        v8, v0, v25
    v.movi       v16, #1
    v.movi       v16, #1
    @p1 v.sel        v16, v8, v25
    v.cmp.lt     p1, v6, v1
    @p1 v.sel        v8, v4, v6
    v.movi       v4, #128
    v.movi       v25, #1
    v.lshr       v25, v8, v14
    v.sub        v8, v22, v23
    @p2 v.sel        v14, v8, v23
    v.movi       v8, #128
    v.cmp.lt     p2, v21, v0
    v.movi       v0, #0
    @p2 v.sel        v23, v2, v21
    v.movi       v2, #7
    v.sub        v21, v0, v3
    v.cmp.lt     p2, v3, v0
    v.movi       v23, #1
    @p2 v.sel        v23, v21, v3
    v.lshr       v21, v23, v2
    v.sub        v2, v20, v19
    @p3 v.sel        v23, v2, v19
    v.movi       v2, #128
    v.cmp.lt     p3, v4, v22
    v.sub        v19, v22, v4
    @p3 v.sel        v22, v19, v4
    s.add        s24, s18, s2
    s.movz       s2, #0
    v.sub        v4, v1, v25
    s.cmp.lt     s25, s24, s2
    v.movi       v19, #128
    s.sub        s26, s2, s25
    @p1 v.sel        v22, v4, v25
    v.sub        v4, v0, v21
    v.cmp.lt     p1, v8, v20
    s.xor        s25, s24, s26
    s.cmp.lt     s24, s5, s2
    v.sub        v25, v20, v8
    s.sub        s27, s25, s26
    s.sub        s25, s2, s24
    @p2 v.sel        v20, v4, v21
    v.sub        v4, v1, v2
    v.cmp.lt     p2, v2, v1
    v.sub        v1, v0, v19
    v.cmp.lt     p3, v19, v0
    v.splat      v0, s23
    @p1 v.sel        v21, v25, v8
    s.lshri      s23, s27, #7
    s.xor        s24, s26, s25
    s.muli       s26, s23, #128
    s.xor        s28, s5, s25
    s.xor        s29, s23, s24
    @p2 v.sel        v8, v4, v2
    @p3 v.sel        v2, v1, v19
    v.mul        v1, v24, v0
    v.mul        v2, v18, v0
    v.mul        v4, v17, v0
    v.mul        v8, v16, v0
    v.mul        v16, v14, v0
    v.mul        v14, v23, v0
    v.mul        v17, v22, v0
    v.mul        v18, v20, v0
    s.sub        s23, s28, s25
    s.sub        s23, s27, s26
    s.sub        s23, s29, s24
    s.movz       s24, #1
    s.addi       s25, s2, #0
    s.addi       s26, s2, #0
    s.addi       s27, s2, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_18:
    s.cmp.ge     s28, s25, s23
    br.nz        s28, endfor_19
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s28, arg_base
    s.mul        s29, s25, s5
    s.ld.d       s30, [s28, #104]                // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v0, s21
    v.splat      v19, s21
    s.shli       s28, s25, #2                    // element offset -> bytes (x4)
    s.sub        s31, s18, s29
    v.mul        v20, v15, v0
    s.add        s29, s2, s31
    v.mul        v21, v13, v0
    v.mul        v22, v12, v0
    v.mul        v23, v10, v0
    v.mul        v24, v9, v0
    v.iota       v0                              // arange(0, VLEN)
    s.movz       s32, #0
    v.mul        v25, v7, v19
    s.cmp.ge     s33, s29, s32
    v.mul        v26, v6, v19
    v.extract    s34, v15, #0
    v.mul        v27, v3, v19
    v.splat      v19, s34
    v.movi       v28, #0
    s.add        s35, s8, s28                    // &As[...]
    s.add        s36, s7, s28                    // &Bs[...]
    s.addi       s28, s30, #0
    s.addi       s37, s30, #64
    s.addi       s38, s30, #128
    s.addi       s39, s30, #192
    s.addi       s40, s30, #256
    s.addi       s41, s30, #320
    s.addi       s42, s30, #384
    s.addi       s43, s30, #448
    v.ld.gather.w v29, [s35, v5]                 // index is in elements (ISA sec 9.1)
    v.movi       v30, #0
    v.splat      v31, s25
    v.add        v31, v19, v0
    v.splat      v19, s25
    s.cmp.ge     s35, s34, s32
    v.sub        v19, v15, v31
    v.splat      v31, s25
    v.splat      v31, s25
    v.splat      v31, s25
    v.splat      v31, s25
    v.splat      v31, s25
    v.splat      v31, s25
    v.splat      v31, s25
    v.ld.gather.w v31, [s36, v1]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v32, [s36, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v33, [s36, v4]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v34, [s36, v8]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s36, v16]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v36, [s36, v14]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v37, [s36, v17]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v38, [s36, v18]                // index is in elements (ISA sec 9.1)
    v.extract    s36, v13, #0
    v.st.w       [s28, #0], v20
    v.splat      v20, s36
    v.extract    s28, v12, #0
    v.add        v39, v20, v0
    v.sub        v20, v13, v39
    v.st.w       [s37, #0], v21
    v.splat      v21, s28
    v.reduce.or  s37, v19
    v.add        v19, v21, v0
    s.cmp.eq     s44, s37, s32
    v.sub        v21, v12, v19
    s.and        s37, s44, s35
    v.reduce.or  s35, v20
    s.and        s44, s37, s33
    s.cmp.eq     s37, s35, s32
    v.st.w       [s38, #0], v22
    s.cmp.ge     s35, s36, s32
    s.and        s38, s37, s35
    v.reduce.or  s35, v21
    s.and        s37, s38, s33
    s.cmp.eq     s38, s35, s32
    v.st.w       [s39, #0], v23
    v.extract    s35, v10, #0
    v.splat      v19, s35
    v.st.w       [s40, #0], v24
    v.add        v20, v19, v0
    s.cmp.ge     s39, s28, s32
    v.sub        v19, v10, v20
    s.and        s40, s38, s39
    s.and        s38, s40, s33
    v.st.w       [s41, #0], v25
    v.reduce.or  s39, v19
    s.cmp.eq     s40, s39, s32
    v.st.w       [s42, #0], v26
    s.cmp.ge     s39, s35, s32
    s.and        s41, s40, s39
    v.st.w       [s43, #0], v27
    fence.acq_rel.device
    v.extract    s39, v9, #0
    v.extract    s40, v7, #0
    v.splat      v19, s39
    v.splat      v20, s40
    v.insert     v28, s44, #0
    v.add        v21, v19, v0
    v.add        v19, v20, v0
    v.insert     v30, s34, #0
    v.extract    s34, v6, #0
    v.sub        v20, v9, v21
    v.insert     v28, s37, #1
    v.splat      v21, s34
    v.reduce.or  s37, v20
    v.sub        v20, v7, v19
    v.insert     v30, s36, #1
    v.extract    s36, v3, #0
    v.add        v19, v21, v0
    v.insert     v28, s38, #2
    v.splat      v21, s36
    s.cmp.eq     s38, s37, s32
    s.cmp.ge     s37, s39, s32
    s.and        s32, s41, s33
    v.reduce.or  s41, v20
    s.movz       s42, #0
    v.sub        v20, v6, v19
    s.and        s43, s38, s37
    v.insert     v30, s28, #2
    v.add        v19, v21, v0
    v.insert     v28, s32, #3
    s.cmp.eq     s28, s41, s42
    s.cmp.ge     s32, s40, s42
    s.and        s37, s43, s33
    v.reduce.or  s38, v20
    v.sub        v0, v3, v19
    s.and        s41, s28, s32
    v.insert     v30, s35, #3
    v.insert     v28, s37, #4
    s.cmp.eq     s28, s38, s42
    s.cmp.ge     s32, s34, s42
    s.and        s35, s41, s33
    v.reduce.or  s37, v0
    s.and        s38, s28, s32
    v.insert     v30, s39, #4
    v.insert     v28, s35, #5
    s.cmp.eq     s28, s37, s42
    s.cmp.ge     s32, s36, s42
    s.and        s35, s38, s33
    s.and        s37, s28, s32
    v.insert     v30, s40, #5
    v.insert     v28, s35, #6
    s.and        s28, s37, s33
    v.insert     v30, s34, #6
    v.insert     v28, s28, #7
    s.add        s28, s6, s27
    s.addi       s32, s30, #512                  // TensorMap 0: W's rows for a transposed FP8 B
    .li       s33, #2147483647
    s.movz       s34, #1
    .li       s35, #137438953488
    .li       s37, #7705171329024
    s.addi       s38, s30, #768
    s.addi       s39, s30, #1792                 // TensorMap 1: the gathered fallback B tile
    s.movz       s40, #32
    s.movz       s41, #16
    .li       s42, #68719476768
    s.addi       s43, s30, #1280
    v.insert     v30, s36, #7
    s.addi       s36, s30, #2048                 // TensorMap 2: the gathered fallback B tile
    s.st.d       [s32, #0], s28
    v.extract    s28, v28, #0
    s.st.d       [s32, #8], s33
    s.movz       s33, #0
    s.st.d       [s32, #16], s29
    s.st.d       [s32, #48], s21
    s.st.d       [s32, #56], s34
    s.st.d       [s32, #88], s35
    s.st.d       [s32, #104], s37
    fence.release.device
    td.load      d0, [s32]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.st.d       [s39, #0], s38
    s.st.d       [s39, #8], s40
    s.st.d       [s39, #16], s41
    s.st.d       [s39, #48], s41
    s.st.d       [s39, #56], s34
    s.st.d       [s39, #88], s42
    s.st.d       [s39, #104], s37
    fence.release.device
    td.load      d1, [s39]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.st.d       [s36, #0], s43
    s.st.d       [s36, #8], s40
    s.st.d       [s36, #16], s41
    s.st.d       [s36, #48], s41
    s.st.d       [s36, #56], s34
    s.st.d       [s36, #88], s42
    s.st.d       [s36, #104], s37
    fence.release.device
    td.load      d2, [s36]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s28, x8dot_done_20
    s.addi       s32, s30, #0
    s.addi       s34, s33, #0
    v.ld.w       v0, [s32, #0]
    s.add        s32, s6, s27
x8dot_row_21:
    s.addi       s35, s29, #0
    v.movi       v19, #0
    s.sub        s36, s35, s34
    s.add        s35, s32, s34
    v.splat      v20, s36
    s.shli       s36, s34, #4
    s.addi       s37, s34, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s35, v0]             // index is in elements (ISA sec 9.1)
    s.add        s35, s38, s36
    v.st.b       [s35, #0], v19
    fence.acq_rel.device
    s.mov        s34, s37
    s.cmp.lt     s35, s34, s40
    br.nz        s35, x8dot_row_21
x8dot_done_20:
    v.splat      v0, s28
    v.movi       v19, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s32, v30, #0
    v.extract    s34, v28, #1
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s35, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s35, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s35, s28          // predicated off still completes once (ISA sec 9A.3)
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s34, x8dot_done_22
    s.movz       s32, #0
    s.addi       s33, s30, #64
    s.addi       s35, s32, #0
    v.ld.w       v0, [s33, #0]
    s.add        s32, s6, s27
    s.addi       s33, s30, #1280
x8dot_row_23:
    s.addi       s36, s29, #0
    v.movi       v19, #0
    s.sub        s37, s36, s35
    s.add        s36, s32, s35
    v.splat      v20, s37
    s.shli       s37, s35, #4
    s.addi       s38, s35, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s36, v0]             // index is in elements (ISA sec 9.1)
    s.add        s36, s33, s37
    s.movz       s37, #32
    v.st.b       [s36, #0], v19
    fence.acq_rel.device
    s.mov        s35, s38
    s.cmp.lt     s36, s35, s37
    br.nz        s36, x8dot_row_23
x8dot_done_22:
    v.splat      v0, s16
    s.movz       s32, #0
    v.splat      v19, s34
    v.mul        v20, v11, v0
    s.add        s33, s32, s31                   // the tile origin
    v.movi       v0, #0
    v.extract    s34, v20, #0
    v.iota       v21                             // arange(0, VLEN)
    s.add        s35, s34, s26
    v.splat      v22, s33
    mb.arm       s33, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s34, v30, #1
    s.add        s36, s15, s35
    v.cmp.ne     p1, v19, v0
    v.cmp.eq     p2, v19, v0
    v.cmp.lt     p3, v21, v22
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s37, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s33          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s36, #0]
    v.extract    s32, v20, #1
    s.addi       s34, s30, #2304                 // 512 bytes of repack scratch
    s.add        s35, s32, s26
    s.addi       s32, s34, #0
    s.add        s36, s15, s35
    v.extract    s35, v20, #2
    s.addi       s37, s34, #32
    s.add        s38, s35, s26
    v.extract    s35, v20, #3
    s.add        s39, s15, s38
    s.add        s38, s35, s26
    v.st.b       [s32, #0], v0
    s.addi       s32, s34, #64
    s.add        s35, s15, s38
    v.extract    s38, v20, #4
    s.addi       s40, s34, #96
    s.add        s41, s38, s26
    s.add        s38, s15, s41
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s36, #0]
    v.extract    s36, v20, #5
    s.add        s41, s36, s26
    s.add        s36, s15, s41
    v.st.b       [s37, #0], v0
    s.addi       s37, s34, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s39, #0]
    v.extract    s39, v20, #6
    s.add        s41, s39, s26
    s.add        s39, s15, s41
    v.st.b       [s32, #0], v0
    s.addi       s32, s34, #160
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s35, #0]
    v.extract    s35, v20, #7
    s.add        s41, s35, s26
    s.add        s35, s15, s41
    v.st.b       [s40, #0], v0
    s.addi       s40, s34, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s38, #0]
    v.extract    s38, v20, #8
    s.add        s41, s38, s26
    s.add        s38, s15, s41
    v.st.b       [s37, #0], v0
    s.addi       s37, s34, #224
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s36, #0]
    v.extract    s36, v20, #9
    s.add        s41, s36, s26
    s.add        s36, s15, s41
    v.st.b       [s32, #0], v0
    s.addi       s32, s34, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s39, #0]
    v.extract    s39, v20, #10
    s.add        s41, s39, s26
    s.add        s39, s15, s41
    v.st.b       [s40, #0], v0
    s.addi       s40, s34, #288
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s35, #0]
    v.extract    s35, v20, #11
    s.add        s41, s35, s26
    s.add        s35, s15, s41
    v.st.b       [s37, #0], v0
    s.addi       s37, s34, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s38, #0]
    v.extract    s38, v20, #12
    s.add        s41, s38, s26
    s.add        s38, s15, s41
    v.st.b       [s32, #0], v0
    s.addi       s32, s34, #352
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s36, #0]
    v.extract    s36, v20, #13
    s.add        s41, s36, s26
    s.add        s36, s15, s41
    v.st.b       [s40, #0], v0
    s.addi       s40, s34, #384
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s39, #0]
    v.extract    s39, v20, #14
    s.add        s41, s39, s26
    s.add        s39, s15, s41
    v.st.b       [s37, #0], v0
    s.addi       s37, s34, #416
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s35, #0]
    v.extract    s35, v20, #15
    s.add        s41, s35, s26
    s.add        s35, s15, s41
    v.st.b       [s32, #0], v0
    s.addi       s32, s34, #448
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s38, #0]
    s.movz       s38, #0
    v.st.b       [s40, #0], v0
    s.add        s40, s38, s10                   // the tile origin
    s.add        s41, s38, s31                   // the tile origin
    v.splat      v0, s40
    v.extract    s38, v20, #0
    v.splat      v19, s41
    s.add        s40, s38, s26
    v.add        v22, v21, v0
    s.addi       s38, s40, #16
    s.addi       s40, s34, #480
    s.add        s41, s15, s38
    v.cmp.lt     p1, v22, v19
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s36, #0]
    v.extract    s36, v20, #1
    s.add        s38, s36, s26
    s.addi       s36, s38, #16
    s.add        s38, s15, s36
    v.st.b       [s37, #0], v0
    s.addi       s36, s34, #16
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s39, #0]
    v.extract    s37, v20, #2
    s.add        s39, s37, s26
    s.addi       s37, s39, #16
    s.add        s39, s15, s37
    v.st.b       [s32, #0], v0
    s.addi       s32, s34, #48
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s35, #0]
    v.extract    s35, v20, #3
    s.add        s37, s35, s26
    s.addi       s35, s37, #16
    s.add        s37, s15, s35
    v.st.b       [s40, #0], v0
    s.addi       s35, s34, #80
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s41, #0]
    v.extract    s40, v20, #4
    s.add        s41, s40, s26
    s.addi       s40, s41, #16
    s.add        s41, s15, s40
    v.st.b       [s36, #0], v0
    s.addi       s36, s34, #112
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    v.extract    s38, v20, #5
    s.add        s40, s38, s26
    s.addi       s38, s40, #16
    s.add        s40, s15, s38
    v.st.b       [s32, #0], v0
    s.addi       s32, s34, #144
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    v.extract    s38, v20, #6
    s.add        s39, s38, s26
    s.addi       s38, s39, #16
    s.add        s39, s15, s38
    v.st.b       [s35, #0], v0
    s.addi       s35, s34, #176
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s37, #0]
    v.extract    s37, v20, #7
    s.add        s38, s37, s26
    s.addi       s37, s38, #16
    s.add        s38, s15, s37
    v.st.b       [s36, #0], v0
    s.addi       s36, s34, #208
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s41, #0]
    v.extract    s37, v20, #8
    s.add        s41, s37, s26
    s.addi       s37, s41, #16
    s.add        s41, s15, s37
    v.st.b       [s32, #0], v0
    s.addi       s32, s34, #240
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s40, #0]
    v.extract    s37, v20, #9
    s.add        s40, s37, s26
    s.addi       s37, s40, #16
    s.add        s40, s15, s37
    v.st.b       [s35, #0], v0
    s.addi       s35, s34, #272
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    v.extract    s37, v20, #10
    s.add        s39, s37, s26
    s.addi       s37, s39, #16
    s.add        s39, s15, s37
    v.st.b       [s36, #0], v0
    s.addi       s36, s34, #304
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    v.extract    s37, v20, #11
    s.add        s38, s37, s26
    s.addi       s37, s38, #16
    s.add        s38, s15, s37
    v.st.b       [s32, #0], v0
    s.addi       s32, s34, #336
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s41, #0]
    v.extract    s37, v20, #12
    s.add        s41, s37, s26
    s.addi       s37, s41, #16
    s.add        s41, s15, s37
    v.st.b       [s35, #0], v0
    s.addi       s35, s34, #368
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s40, #0]
    v.extract    s37, v20, #13
    s.add        s40, s37, s26
    s.addi       s37, s40, #16
    s.add        s40, s15, s37
    v.st.b       [s36, #0], v0
    s.addi       s36, s34, #400
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    v.extract    s37, v20, #14
    s.add        s39, s37, s26
    s.addi       s37, s39, #16
    s.add        s39, s15, s37
    v.st.b       [s32, #0], v0
    s.addi       s32, s34, #432
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    v.extract    s37, v20, #15
    s.add        s38, s37, s26
    s.addi       s37, s38, #16
    s.add        s38, s15, s37
    v.st.b       [s35, #0], v0
    s.addi       s35, s34, #464
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s41, #0]
    s.addi       s37, s34, #496
    v.st.b       [s36, #0], v0
    s.addi       s36, s34, #64
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s40, #0]
    s.addi       s40, s34, #128
    v.st.b       [s32, #0], v0
    s.addi       s32, s34, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    s.addi       s39, s34, #256
    v.st.b       [s35, #0], v0
    s.addi       s35, s34, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    s.addi       s38, s34, #384
    v.st.b       [s37, #0], v0
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s37, s34, #448
    v.ld.w       v0, [s34, #0]
    v.extract    s34, v28, #2
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s36, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s40, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s32, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s39, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s35, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s38, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s37, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.wait      s28
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s32
    mb.wait      s32
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s34, x8dot_done_24
    s.movz       s35, #0
    s.addi       s36, s30, #128
    s.addi       s37, s35, #0
    v.ld.w       v0, [s36, #0]
    s.add        s35, s6, s27
    s.addi       s36, s30, #768
x8dot_row_25:
    s.addi       s38, s29, #0
    v.movi       v19, #0
    s.sub        s39, s38, s37
    s.add        s38, s35, s37
    v.splat      v22, s39
    s.shli       s39, s37, #4
    s.addi       s40, s37, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s38, v0]             // index is in elements (ISA sec 9.1)
    s.add        s38, s36, s39
    s.movz       s39, #32
    v.st.b       [s38, #0], v19
    fence.acq_rel.device
    s.mov        s37, s40
    s.cmp.lt     s38, s37, s39
    br.nz        s38, x8dot_row_25
x8dot_done_24:
    v.splat      v0, s34
    v.movi       v19, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    v.extract    s36, v30, #2
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s37, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s37, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s36, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v28, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s36
    mb.wait      s36
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s37, x8dot_done_26
    s.addi       s38, s30, #192
    s.addi       s39, s35, #0
    v.ld.w       v0, [s38, #0]
    s.add        s38, s6, s27
    s.addi       s40, s30, #1280
x8dot_row_27:
    s.addi       s41, s29, #0
    v.movi       v19, #0
    s.sub        s42, s41, s39
    s.add        s41, s38, s39
    v.splat      v22, s42
    s.shli       s42, s39, #4
    s.addi       s43, s39, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s41, v0]             // index is in elements (ISA sec 9.1)
    s.add        s41, s40, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v19
    fence.acq_rel.device
    s.mov        s39, s43
    s.cmp.lt     s41, s39, s42
    br.nz        s41, x8dot_row_27
x8dot_done_26:
    v.splat      v0, s37
    v.movi       v19, #0
    mb.arm       s37, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s38, v30, #3
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s39, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v28, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s38
    mb.wait      s38
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s39, x8dot_done_28
    s.addi       s40, s30, #256
    s.addi       s41, s35, #0
    v.ld.w       v0, [s40, #0]
    s.add        s35, s6, s27
    s.addi       s40, s30, #768
x8dot_row_29:
    s.addi       s42, s29, #0
    v.movi       v19, #0
    s.sub        s43, s42, s41
    s.add        s42, s35, s41
    v.splat      v22, s43
    s.shli       s43, s41, #4
    s.addi       s44, s41, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s42, v0]             // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.movz       s43, #32
    v.st.b       [s42, #0], v19
    fence.acq_rel.device
    s.mov        s41, s44
    s.cmp.lt     s42, s41, s43
    br.nz        s42, x8dot_row_29
x8dot_done_28:
    v.splat      v0, s39
    v.movi       v19, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    v.extract    s40, v30, #4
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s41, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s41, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s40, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v28, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s40
    mb.wait      s40
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s41, x8dot_done_30
    s.addi       s42, s30, #320
    s.addi       s43, s39, #0
    v.ld.w       v0, [s42, #0]
    s.add        s42, s6, s27
    s.addi       s44, s30, #1280
x8dot_row_31:
    s.addi       s45, s29, #0
    v.movi       v19, #0
    s.sub        s46, s45, s43
    s.add        s45, s42, s43
    v.splat      v22, s46
    s.shli       s46, s43, #4
    s.addi       s47, s43, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s45, v0]             // index is in elements (ISA sec 9.1)
    s.add        s45, s44, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v19
    fence.acq_rel.device
    s.mov        s43, s47
    s.cmp.lt     s45, s43, s46
    br.nz        s45, x8dot_row_31
x8dot_done_30:
    v.splat      v0, s41
    v.movi       v19, #0
    mb.arm       s41, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s42, v30, #5
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v28, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s42
    mb.wait      s42
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s43, x8dot_done_32
    s.addi       s44, s30, #384
    s.addi       s45, s39, #0
    v.ld.w       v0, [s44, #0]
    s.add        s39, s6, s27
    s.addi       s44, s30, #768
x8dot_row_33:
    s.addi       s46, s29, #0
    v.movi       v19, #0
    s.sub        s47, s46, s45
    s.add        s46, s39, s45
    v.splat      v22, s47
    s.shli       s47, s45, #4
    s.addi       s48, s45, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s46, v0]             // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.movz       s47, #32
    v.st.b       [s46, #0], v19
    fence.acq_rel.device
    s.mov        s45, s48
    s.cmp.lt     s46, s45, s47
    br.nz        s46, x8dot_row_33
x8dot_done_32:
    v.splat      v0, s43
    v.movi       v19, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    v.extract    s44, v30, #6
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s45, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s45, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s44, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v28, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s44
    mb.wait      s44
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s45, x8dot_done_34
    s.addi       s46, s30, #448
    s.addi       s47, s43, #0
    v.ld.w       v0, [s46, #0]
    s.add        s46, s6, s27
    s.addi       s48, s30, #1280
x8dot_row_35:
    s.addi       s49, s29, #0
    v.movi       v19, #0
    s.sub        s50, s49, s47
    s.add        s49, s46, s47
    v.splat      v22, s50
    s.shli       s50, s47, #4
    s.addi       s51, s47, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s49, v0]             // index is in elements (ISA sec 9.1)
    s.add        s49, s48, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v19
    fence.acq_rel.device
    s.mov        s47, s51
    s.cmp.lt     s49, s47, s50
    br.nz        s49, x8dot_row_35
x8dot_done_34:
    v.splat      v0, s45
    v.movi       v19, #0
    mb.arm       s45, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s46, v30, #7
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s47, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v28, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s46
    mb.wait      s46
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s47, x8dot_done_36
    s.addi       s48, s30, #0
    s.add        s49, s6, s27
    s.addi       s50, s43, #0
    v.ld.w       v0, [s48, #0]
    s.addi       s43, s49, #32
    s.addi       s48, s30, #768
x8dot_row_37:
    s.addi       s49, s29, #-32
    v.movi       v19, #0
    s.sub        s51, s49, s50
    s.add        s49, s43, s50
    v.splat      v22, s51
    s.shli       s51, s50, #4
    s.addi       s52, s50, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s49, v0]             // index is in elements (ISA sec 9.1)
    s.add        s49, s48, s51
    s.movz       s51, #32
    v.st.b       [s49, #0], v19
    fence.acq_rel.device
    s.mov        s50, s52
    s.cmp.lt     s49, s50, s51
    br.nz        s49, x8dot_row_37
x8dot_done_36:
    v.splat      v0, s47
    v.movi       v19, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    v.extract    s48, v30, #0
    s.movz       s49, #32
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s50, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s50, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s50, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s48, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v28, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s48
    mb.wait      s48
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s50, x8dot_done_38
    s.addi       s51, s30, #64
    s.add        s52, s6, s27
    s.addi       s53, s47, #0
    v.ld.w       v0, [s51, #0]
    s.addi       s51, s52, #32
    s.addi       s52, s30, #1280
x8dot_row_39:
    s.addi       s54, s29, #-32
    v.movi       v19, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v22, s55
    s.shli       s55, s53, #4
    s.addi       s56, s53, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s54, v0]             // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    v.st.b       [s54, #0], v19
    fence.acq_rel.device
    s.mov        s53, s56
    s.cmp.lt     s54, s53, s49
    br.nz        s54, x8dot_row_39
x8dot_done_38:
    s.add        s51, s47, s11                   // the tile origin
    v.extract    s52, v20, #0
    v.splat      v0, s51
    s.add        s51, s52, s26
    s.add        s52, s47, s31                   // the tile origin
    v.splat      v19, s50
    v.movi       v22, #0
    s.addi       s50, s51, #32
    v.add        v23, v21, v0
    v.splat      v0, s52
    mb.arm       s51, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s52, v30, #1
    s.add        s53, s15, s50
    v.cmp.ne     p1, v19, v22
    v.cmp.eq     p2, v19, v22
    v.cmp.lt     p3, v23, v0
    s.mov        s54, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s54, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s51          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s53, #0]
    v.extract    s47, v20, #1
    s.addi       s49, s30, #2816                 // 512 bytes of repack scratch
    s.add        s50, s47, s26
    s.addi       s47, s49, #0
    s.addi       s52, s50, #32
    v.extract    s50, v20, #2
    s.add        s53, s15, s52
    s.add        s52, s50, s26
    s.addi       s50, s49, #32
    s.addi       s54, s52, #32
    v.extract    s52, v20, #3
    v.st.b       [s47, #0], v0
    s.add        s47, s15, s54
    s.add        s54, s52, s26
    s.addi       s52, s49, #64
    s.addi       s55, s54, #32
    v.extract    s54, v20, #4
    s.add        s56, s15, s55
    s.add        s55, s54, s26
    s.addi       s54, s49, #96
    s.addi       s57, s55, #32
    s.add        s55, s15, s57
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s53, #0]
    v.extract    s53, v20, #5
    s.add        s57, s53, s26
    s.addi       s53, s57, #32
    s.add        s57, s15, s53
    v.st.b       [s50, #0], v0
    s.addi       s50, s49, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s47, #0]
    v.extract    s47, v20, #6
    s.add        s53, s47, s26
    s.addi       s47, s53, #32
    s.add        s53, s15, s47
    v.st.b       [s52, #0], v0
    s.addi       s47, s49, #160
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s56, #0]
    v.extract    s52, v20, #7
    s.add        s56, s52, s26
    s.addi       s52, s56, #32
    s.add        s56, s15, s52
    v.st.b       [s54, #0], v0
    s.addi       s52, s49, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s55, #0]
    v.extract    s54, v20, #8
    s.add        s55, s54, s26
    s.addi       s54, s55, #32
    s.add        s55, s15, s54
    v.st.b       [s50, #0], v0
    s.addi       s50, s49, #224
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s57, #0]
    v.extract    s54, v20, #9
    s.add        s57, s54, s26
    s.addi       s54, s57, #32
    s.add        s57, s15, s54
    v.st.b       [s47, #0], v0
    s.addi       s47, s49, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s53, #0]
    v.extract    s53, v20, #10
    s.add        s54, s53, s26
    s.addi       s53, s54, #32
    s.add        s54, s15, s53
    v.st.b       [s52, #0], v0
    s.addi       s52, s49, #288
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s56, #0]
    v.extract    s53, v20, #11
    s.add        s56, s53, s26
    s.addi       s53, s56, #32
    s.add        s56, s15, s53
    v.st.b       [s50, #0], v0
    s.addi       s50, s49, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s55, #0]
    v.extract    s53, v20, #12
    s.add        s55, s53, s26
    s.addi       s53, s55, #32
    s.add        s55, s15, s53
    v.st.b       [s47, #0], v0
    s.addi       s47, s49, #352
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s57, #0]
    v.extract    s53, v20, #13
    s.add        s57, s53, s26
    s.addi       s53, s57, #32
    s.add        s57, s15, s53
    v.st.b       [s52, #0], v0
    s.addi       s52, s49, #384
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s54, #0]
    v.extract    s53, v20, #14
    s.add        s54, s53, s26
    s.addi       s53, s54, #32
    s.add        s54, s15, s53
    v.st.b       [s50, #0], v0
    s.addi       s50, s49, #416
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s56, #0]
    v.extract    s53, v20, #15
    s.add        s56, s53, s26
    s.addi       s53, s56, #32
    s.add        s56, s15, s53
    v.st.b       [s47, #0], v0
    s.addi       s47, s49, #448
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s55, #0]
    s.movz       s53, #0
    v.st.b       [s52, #0], v0
    s.add        s52, s53, s12                   // the tile origin
    s.add        s55, s53, s31                   // the tile origin
    v.splat      v0, s52
    v.extract    s52, v20, #0
    v.splat      v19, s55
    s.add        s53, s52, s26
    v.add        v22, v21, v0
    s.addi       s52, s53, #48
    s.addi       s53, s49, #480
    s.add        s55, s15, s52
    v.cmp.lt     p1, v22, v19
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s57, #0]
    v.extract    s52, v20, #1
    s.add        s57, s52, s26
    s.addi       s52, s57, #48
    s.add        s57, s15, s52
    v.st.b       [s50, #0], v0
    s.addi       s50, s49, #16
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s54, #0]
    v.extract    s52, v20, #2
    s.add        s54, s52, s26
    s.addi       s52, s54, #48
    s.add        s54, s15, s52
    v.st.b       [s47, #0], v0
    s.addi       s47, s49, #48
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s56, #0]
    v.extract    s52, v20, #3
    s.add        s56, s52, s26
    s.addi       s52, s56, #48
    s.add        s56, s15, s52
    v.st.b       [s53, #0], v0
    s.addi       s52, s49, #80
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s55, #0]
    v.extract    s53, v20, #4
    s.add        s55, s53, s26
    s.addi       s53, s55, #48
    s.add        s55, s15, s53
    v.st.b       [s50, #0], v0
    s.addi       s50, s49, #112
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s57, #0]
    v.extract    s53, v20, #5
    s.add        s57, s53, s26
    s.addi       s53, s57, #48
    s.add        s57, s15, s53
    v.st.b       [s47, #0], v0
    s.addi       s47, s49, #144
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s54, #0]
    v.extract    s53, v20, #6
    s.add        s54, s53, s26
    s.addi       s53, s54, #48
    s.add        s54, s15, s53
    v.st.b       [s52, #0], v0
    s.addi       s52, s49, #176
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s56, #0]
    v.extract    s53, v20, #7
    s.add        s56, s53, s26
    s.addi       s53, s56, #48
    s.add        s56, s15, s53
    v.st.b       [s50, #0], v0
    s.addi       s50, s49, #208
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s55, #0]
    v.extract    s53, v20, #8
    s.add        s55, s53, s26
    s.addi       s53, s55, #48
    s.add        s55, s15, s53
    v.st.b       [s47, #0], v0
    s.addi       s47, s49, #240
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s57, #0]
    v.extract    s53, v20, #9
    s.add        s57, s53, s26
    s.addi       s53, s57, #48
    s.add        s57, s15, s53
    v.st.b       [s52, #0], v0
    s.addi       s52, s49, #272
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s54, #0]
    v.extract    s53, v20, #10
    s.add        s54, s53, s26
    s.addi       s53, s54, #48
    s.add        s54, s15, s53
    v.st.b       [s50, #0], v0
    s.addi       s50, s49, #304
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s56, #0]
    v.extract    s53, v20, #11
    s.add        s56, s53, s26
    s.addi       s53, s56, #48
    s.add        s56, s15, s53
    v.st.b       [s47, #0], v0
    s.addi       s47, s49, #336
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s55, #0]
    v.extract    s53, v20, #12
    s.add        s55, s53, s26
    s.addi       s53, s55, #48
    s.add        s55, s15, s53
    v.st.b       [s52, #0], v0
    s.addi       s52, s49, #368
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s57, #0]
    v.extract    s53, v20, #13
    s.add        s57, s53, s26
    s.addi       s53, s57, #48
    s.add        s57, s15, s53
    v.st.b       [s50, #0], v0
    s.addi       s50, s49, #400
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s54, #0]
    v.extract    s53, v20, #14
    s.add        s54, s53, s26
    s.addi       s53, s54, #48
    s.add        s54, s15, s53
    v.st.b       [s47, #0], v0
    s.addi       s47, s49, #432
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s56, #0]
    v.extract    s53, v20, #15
    s.add        s56, s53, s26
    s.addi       s53, s56, #48
    s.add        s56, s15, s53
    v.st.b       [s52, #0], v0
    s.addi       s52, s49, #464
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s55, #0]
    s.addi       s53, s49, #496
    v.st.b       [s50, #0], v0
    s.addi       s50, s49, #64
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s57, #0]
    s.addi       s55, s49, #128
    v.st.b       [s47, #0], v0
    s.addi       s47, s49, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s54, #0]
    s.addi       s54, s49, #256
    v.st.b       [s52, #0], v0
    s.addi       s52, s49, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s56, #0]
    s.addi       s56, s49, #384
    v.st.b       [s53, #0], v0
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s53, s49, #448
    v.ld.w       v0, [s49, #0]
    v.extract    s49, v28, #2
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s50, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s55, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s47, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s54, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s52, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s56, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s53, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.wait      s43
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s47
    mb.wait      s47
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s49, x8dot_done_40
    s.movz       s50, #0
    s.addi       s52, s30, #128
    s.add        s53, s6, s27
    s.addi       s54, s50, #0
    v.ld.w       v0, [s52, #0]
    s.addi       s50, s53, #32
    s.addi       s52, s30, #768
x8dot_row_41:
    s.addi       s53, s29, #-32
    v.movi       v19, #0
    s.sub        s55, s53, s54
    s.add        s53, s50, s54
    v.splat      v22, s55
    s.shli       s55, s54, #4
    s.addi       s56, s54, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s53, v0]             // index is in elements (ISA sec 9.1)
    s.add        s53, s52, s55
    s.movz       s55, #32
    v.st.b       [s53, #0], v19
    fence.acq_rel.device
    s.mov        s54, s56
    s.cmp.lt     s53, s54, s55
    br.nz        s53, x8dot_row_41
x8dot_done_40:
    v.splat      v0, s49
    v.movi       v19, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.extract    s52, v30, #2
    s.movz       s53, #32
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s54, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s54, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s52, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v28, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s52
    mb.wait      s52
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s54, x8dot_done_42
    s.addi       s55, s30, #192
    s.add        s56, s6, s27
    s.addi       s57, s50, #0
    v.ld.w       v0, [s55, #0]
    s.addi       s55, s56, #32
    s.addi       s56, s30, #1280
x8dot_row_43:
    s.addi       s58, s29, #-32
    v.movi       v19, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v22, s59
    s.shli       s59, s57, #4
    s.addi       s60, s57, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s58, v0]             // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    v.st.b       [s58, #0], v19
    fence.acq_rel.device
    s.mov        s57, s60
    s.cmp.lt     s58, s57, s53
    br.nz        s58, x8dot_row_43
x8dot_done_42:
    v.splat      v0, s54
    v.movi       v19, #0
    mb.arm       s54, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s55, v30, #3
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s56, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s56, s54            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s56, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v28, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s53
    mb.wait      s53
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s55, x8dot_done_44
    s.addi       s56, s30, #256
    s.add        s57, s6, s27
    s.addi       s58, s50, #0
    v.ld.w       v0, [s56, #0]
    s.addi       s50, s57, #32
    s.addi       s56, s30, #768
x8dot_row_45:
    s.addi       s57, s29, #-32
    v.movi       v19, #0
    s.sub        s59, s57, s58
    s.add        s57, s50, s58
    v.splat      v22, s59
    s.shli       s59, s58, #4
    s.addi       s60, s58, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s57, v0]             // index is in elements (ISA sec 9.1)
    s.add        s57, s56, s59
    s.movz       s59, #32
    v.st.b       [s57, #0], v19
    fence.acq_rel.device
    s.mov        s58, s60
    s.cmp.lt     s57, s58, s59
    br.nz        s57, x8dot_row_45
x8dot_done_44:
    v.splat      v0, s55
    v.movi       v19, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s55, #0
    v.extract    s56, v30, #4
    s.movz       s57, #32
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s58, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s58, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s58, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s56, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s58, v28, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s56
    mb.wait      s56
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s58, x8dot_done_46
    s.addi       s59, s30, #320
    s.add        s60, s6, s27
    s.addi       s28, s55, #0
    v.ld.w       v0, [s59, #0]
    s.addi       s32, s60, #32
    s.addi       s33, s30, #1280
x8dot_row_47:
    s.addi       s34, s29, #-32
    v.movi       v19, #0
    s.sub        s35, s34, s28
    s.add        s34, s32, s28
    v.splat      v22, s35
    s.shli       s35, s28, #4
    s.addi       s36, s28, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s34, v0]             // index is in elements (ISA sec 9.1)
    s.add        s34, s33, s35
    v.st.b       [s34, #0], v19
    fence.acq_rel.device
    s.mov        s28, s36
    s.cmp.lt     s34, s28, s57
    br.nz        s34, x8dot_row_47
x8dot_done_46:
    v.splat      v0, s58
    v.movi       v19, #0
    mb.arm       s28, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s32, v30, #5
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s33, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s33, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v28, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s32
    mb.wait      s32
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s33, x8dot_done_48
    s.addi       s34, s30, #384
    s.add        s35, s6, s27
    s.addi       s36, s55, #0
    v.ld.w       v0, [s34, #0]
    s.addi       s34, s35, #32
    s.addi       s35, s30, #768
x8dot_row_49:
    s.addi       s37, s29, #-32
    v.movi       v19, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v22, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s37, v0]             // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v19
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_49
x8dot_done_48:
    v.splat      v0, s33
    v.movi       v19, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.extract    s35, v30, #6
    s.movz       s36, #32
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s37, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s37, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s35, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v28, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s35
    mb.wait      s35
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s37, x8dot_done_50
    s.addi       s38, s30, #448
    s.add        s39, s6, s27
    s.addi       s40, s34, #0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s39, #32
    s.addi       s39, s30, #1280
x8dot_row_51:
    s.addi       s41, s29, #-32
    v.movi       v19, #0
    s.sub        s42, s41, s40
    s.add        s41, s38, s40
    v.splat      v22, s42
    s.shli       s42, s40, #4
    s.addi       s43, s40, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s41, v0]             // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    v.st.b       [s41, #0], v19
    fence.acq_rel.device
    s.mov        s40, s43
    s.cmp.lt     s41, s40, s36
    br.nz        s41, x8dot_row_51
x8dot_done_50:
    v.splat      v0, s37
    v.movi       v19, #0
    mb.arm       s37, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s38, v30, #7
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s39, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v28, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s36
    mb.wait      s36
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s38, x8dot_done_52
    s.addi       s39, s30, #0
    s.add        s40, s6, s27
    s.addi       s41, s34, #0
    v.ld.w       v0, [s39, #0]
    s.addi       s34, s40, #64
    s.addi       s39, s30, #768
x8dot_row_53:
    s.addi       s40, s29, #-64
    v.movi       v19, #0
    s.sub        s42, s40, s41
    s.add        s40, s34, s41
    v.splat      v22, s42
    s.shli       s42, s41, #4
    s.addi       s43, s41, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s40, v0]             // index is in elements (ISA sec 9.1)
    s.add        s40, s39, s42
    s.movz       s42, #32
    v.st.b       [s40, #0], v19
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s40, s41, s42
    br.nz        s40, x8dot_row_53
x8dot_done_52:
    v.splat      v0, s38
    v.movi       v19, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s39, v30, #0
    s.movz       s40, #64
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s41, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s41, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s39, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v28, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s39
    mb.wait      s39
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s41, x8dot_done_54
    s.addi       s42, s30, #64
    s.add        s43, s6, s27
    s.addi       s44, s38, #0
    v.ld.w       v0, [s42, #0]
    s.addi       s42, s43, #64
    s.addi       s43, s30, #1280
x8dot_row_55:
    s.addi       s45, s29, #-64
    v.movi       v19, #0
    s.sub        s46, s45, s44
    s.add        s45, s42, s44
    v.splat      v22, s46
    s.shli       s46, s44, #4
    s.addi       s47, s44, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s45, v0]             // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v19
    fence.acq_rel.device
    s.mov        s44, s47
    s.cmp.lt     s45, s44, s46
    br.nz        s45, x8dot_row_55
x8dot_done_54:
    s.add        s42, s38, s13                   // the tile origin
    v.extract    s43, v20, #0
    v.splat      v0, s42
    s.add        s42, s43, s26
    s.add        s43, s38, s31                   // the tile origin
    v.splat      v19, s41
    v.movi       v22, #0
    s.addi       s41, s42, #64
    v.add        v23, v21, v0
    v.splat      v0, s43
    mb.arm       s42, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s43, v30, #1
    s.add        s44, s15, s41
    v.cmp.ne     p1, v19, v22
    v.cmp.eq     p2, v19, v22
    v.cmp.lt     p3, v23, v0
    s.mov        s45, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s45, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s42          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s44, #0]
    v.extract    s38, v20, #1
    s.addi       s40, s30, #3328                 // 512 bytes of repack scratch
    s.add        s41, s38, s26
    s.addi       s38, s40, #0
    s.addi       s43, s41, #64
    v.extract    s41, v20, #2
    s.add        s44, s15, s43
    s.add        s43, s41, s26
    s.addi       s41, s40, #32
    s.addi       s45, s43, #64
    v.extract    s43, v20, #3
    v.st.b       [s38, #0], v0
    s.add        s38, s15, s45
    s.add        s45, s43, s26
    s.addi       s43, s40, #64
    s.addi       s46, s45, #64
    v.extract    s45, v20, #4
    s.add        s47, s15, s46
    s.add        s46, s45, s26
    s.addi       s45, s40, #96
    s.addi       s48, s46, #64
    s.add        s46, s15, s48
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s44, #0]
    v.extract    s44, v20, #5
    s.add        s48, s44, s26
    s.addi       s44, s48, #64
    s.add        s48, s15, s44
    v.st.b       [s41, #0], v0
    s.addi       s41, s40, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s38, #0]
    v.extract    s38, v20, #6
    s.add        s44, s38, s26
    s.addi       s38, s44, #64
    s.add        s44, s15, s38
    v.st.b       [s43, #0], v0
    s.addi       s38, s40, #160
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s47, #0]
    v.extract    s43, v20, #7
    s.add        s47, s43, s26
    s.addi       s43, s47, #64
    s.add        s47, s15, s43
    v.st.b       [s45, #0], v0
    s.addi       s43, s40, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s46, #0]
    v.extract    s45, v20, #8
    s.add        s46, s45, s26
    s.addi       s45, s46, #64
    s.add        s46, s15, s45
    v.st.b       [s41, #0], v0
    s.addi       s41, s40, #224
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s48, #0]
    v.extract    s45, v20, #9
    s.add        s48, s45, s26
    s.addi       s45, s48, #64
    s.add        s48, s15, s45
    v.st.b       [s38, #0], v0
    s.addi       s38, s40, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s44, #0]
    v.extract    s44, v20, #10
    s.add        s45, s44, s26
    s.addi       s44, s45, #64
    s.add        s45, s15, s44
    v.st.b       [s43, #0], v0
    s.addi       s43, s40, #288
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s47, #0]
    v.extract    s44, v20, #11
    s.add        s47, s44, s26
    s.addi       s44, s47, #64
    s.add        s47, s15, s44
    v.st.b       [s41, #0], v0
    s.addi       s41, s40, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s46, #0]
    v.extract    s44, v20, #12
    s.add        s46, s44, s26
    s.addi       s44, s46, #64
    s.add        s46, s15, s44
    v.st.b       [s38, #0], v0
    s.addi       s38, s40, #352
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s48, #0]
    v.extract    s44, v20, #13
    s.add        s48, s44, s26
    s.addi       s44, s48, #64
    s.add        s48, s15, s44
    v.st.b       [s43, #0], v0
    s.addi       s43, s40, #384
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s45, #0]
    v.extract    s44, v20, #14
    s.add        s45, s44, s26
    s.addi       s44, s45, #64
    s.add        s45, s15, s44
    v.st.b       [s41, #0], v0
    s.addi       s41, s40, #416
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s47, #0]
    v.extract    s44, v20, #15
    s.add        s47, s44, s26
    s.addi       s44, s47, #64
    s.add        s47, s15, s44
    v.st.b       [s38, #0], v0
    s.addi       s38, s40, #448
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s46, #0]
    s.movz       s44, #0
    v.st.b       [s43, #0], v0
    s.add        s43, s44, s17                   // the tile origin
    s.add        s46, s44, s31                   // the tile origin
    v.splat      v0, s43
    v.extract    s43, v20, #0
    v.splat      v19, s46
    s.add        s44, s43, s26
    v.add        v22, v21, v0
    s.addi       s43, s44, #80
    s.addi       s44, s40, #480
    s.add        s46, s15, s43
    v.cmp.lt     p1, v22, v19
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s48, #0]
    v.extract    s43, v20, #1
    s.add        s48, s43, s26
    s.addi       s43, s48, #80
    s.add        s48, s15, s43
    v.st.b       [s41, #0], v0
    s.addi       s41, s40, #16
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s45, #0]
    v.extract    s43, v20, #2
    s.add        s45, s43, s26
    s.addi       s43, s45, #80
    s.add        s45, s15, s43
    v.st.b       [s38, #0], v0
    s.addi       s38, s40, #48
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s47, #0]
    v.extract    s43, v20, #3
    s.add        s47, s43, s26
    s.addi       s43, s47, #80
    s.add        s47, s15, s43
    v.st.b       [s44, #0], v0
    s.addi       s43, s40, #80
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s46, #0]
    v.extract    s44, v20, #4
    s.add        s46, s44, s26
    s.addi       s44, s46, #80
    s.add        s46, s15, s44
    v.st.b       [s41, #0], v0
    s.addi       s41, s40, #112
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s48, #0]
    v.extract    s44, v20, #5
    s.add        s48, s44, s26
    s.addi       s44, s48, #80
    s.add        s48, s15, s44
    v.st.b       [s38, #0], v0
    s.addi       s38, s40, #144
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s45, #0]
    v.extract    s44, v20, #6
    s.add        s45, s44, s26
    s.addi       s44, s45, #80
    s.add        s45, s15, s44
    v.st.b       [s43, #0], v0
    s.addi       s43, s40, #176
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s47, #0]
    v.extract    s44, v20, #7
    s.add        s47, s44, s26
    s.addi       s44, s47, #80
    s.add        s47, s15, s44
    v.st.b       [s41, #0], v0
    s.addi       s41, s40, #208
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s46, #0]
    v.extract    s44, v20, #8
    s.add        s46, s44, s26
    s.addi       s44, s46, #80
    s.add        s46, s15, s44
    v.st.b       [s38, #0], v0
    s.addi       s38, s40, #240
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s48, #0]
    v.extract    s44, v20, #9
    s.add        s48, s44, s26
    s.addi       s44, s48, #80
    s.add        s48, s15, s44
    v.st.b       [s43, #0], v0
    s.addi       s43, s40, #272
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s45, #0]
    v.extract    s44, v20, #10
    s.add        s45, s44, s26
    s.addi       s44, s45, #80
    s.add        s45, s15, s44
    v.st.b       [s41, #0], v0
    s.addi       s41, s40, #304
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s47, #0]
    v.extract    s44, v20, #11
    s.add        s47, s44, s26
    s.addi       s44, s47, #80
    s.add        s47, s15, s44
    v.st.b       [s38, #0], v0
    s.addi       s38, s40, #336
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s46, #0]
    v.extract    s44, v20, #12
    s.add        s46, s44, s26
    s.addi       s44, s46, #80
    s.add        s46, s15, s44
    v.st.b       [s43, #0], v0
    s.addi       s43, s40, #368
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s48, #0]
    v.extract    s44, v20, #13
    s.add        s48, s44, s26
    s.addi       s44, s48, #80
    s.add        s48, s15, s44
    v.st.b       [s41, #0], v0
    s.addi       s41, s40, #400
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s45, #0]
    v.extract    s44, v20, #14
    s.add        s45, s44, s26
    s.addi       s44, s45, #80
    s.add        s45, s15, s44
    v.st.b       [s38, #0], v0
    s.addi       s38, s40, #432
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s47, #0]
    v.extract    s44, v20, #15
    s.add        s47, s44, s26
    s.addi       s44, s47, #80
    s.add        s47, s15, s44
    v.st.b       [s43, #0], v0
    s.addi       s43, s40, #464
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s46, #0]
    s.addi       s44, s40, #496
    v.st.b       [s41, #0], v0
    s.addi       s41, s40, #64
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s48, #0]
    s.addi       s46, s40, #128
    v.st.b       [s38, #0], v0
    s.addi       s38, s40, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s45, #0]
    s.addi       s45, s40, #256
    v.st.b       [s43, #0], v0
    s.addi       s43, s40, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s47, #0]
    s.addi       s47, s40, #384
    v.st.b       [s44, #0], v0
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s44, s40, #448
    v.ld.w       v0, [s40, #0]
    v.extract    s40, v28, #2
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s41, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s46, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s38, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s45, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s43, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s47, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s44, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.wait      s34
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s38
    mb.wait      s38
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s40, x8dot_done_56
    s.movz       s41, #0
    s.addi       s43, s30, #128
    s.add        s44, s6, s27
    s.addi       s45, s41, #0
    v.ld.w       v0, [s43, #0]
    s.addi       s41, s44, #64
    s.addi       s43, s30, #768
x8dot_row_57:
    s.addi       s44, s29, #-64
    v.movi       v19, #0
    s.sub        s46, s44, s45
    s.add        s44, s41, s45
    v.splat      v22, s46
    s.shli       s46, s45, #4
    s.addi       s47, s45, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s44, v0]             // index is in elements (ISA sec 9.1)
    s.add        s44, s43, s46
    s.movz       s46, #32
    v.st.b       [s44, #0], v19
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s44, s45, s46
    br.nz        s44, x8dot_row_57
x8dot_done_56:
    v.splat      v0, s40
    v.movi       v19, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    v.extract    s43, v30, #2
    s.movz       s44, #64
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s45, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s45, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s43, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v28, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s43
    mb.wait      s43
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s45, x8dot_done_58
    s.addi       s46, s30, #192
    s.add        s47, s6, s27
    s.addi       s48, s41, #0
    v.ld.w       v0, [s46, #0]
    s.addi       s46, s47, #64
    s.addi       s47, s30, #1280
x8dot_row_59:
    s.addi       s49, s29, #-64
    v.movi       v19, #0
    s.sub        s51, s49, s48
    s.add        s49, s46, s48
    v.splat      v22, s51
    s.shli       s51, s48, #4
    s.addi       s52, s48, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s49, v0]             // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s51
    s.movz       s51, #32
    v.st.b       [s49, #0], v19
    fence.acq_rel.device
    s.mov        s48, s52
    s.cmp.lt     s49, s48, s51
    br.nz        s49, x8dot_row_59
x8dot_done_58:
    v.splat      v0, s45
    v.movi       v19, #0
    mb.arm       s45, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s46, v30, #3
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s47, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s47, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v28, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s44
    mb.wait      s44
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s46, x8dot_done_60
    s.addi       s47, s30, #256
    s.add        s48, s6, s27
    s.addi       s49, s41, #0
    v.ld.w       v0, [s47, #0]
    s.addi       s41, s48, #64
    s.addi       s47, s30, #768
x8dot_row_61:
    s.addi       s48, s29, #-64
    v.movi       v19, #0
    s.sub        s51, s48, s49
    s.add        s48, s41, s49
    v.splat      v22, s51
    s.shli       s51, s49, #4
    s.addi       s52, s49, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s48, v0]             // index is in elements (ISA sec 9.1)
    s.add        s48, s47, s51
    s.movz       s51, #32
    v.st.b       [s48, #0], v19
    fence.acq_rel.device
    s.mov        s49, s52
    s.cmp.lt     s48, s49, s51
    br.nz        s48, x8dot_row_61
x8dot_done_60:
    v.splat      v0, s46
    v.movi       v19, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.extract    s47, v30, #4
    s.movz       s48, #64
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s51, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s51, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s47, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v28, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s47
    mb.wait      s47
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s49, x8dot_done_62
    s.addi       s51, s30, #320
    s.add        s52, s6, s27
    s.addi       s53, s46, #0
    v.ld.w       v0, [s51, #0]
    s.addi       s51, s52, #64
    s.addi       s52, s30, #1280
x8dot_row_63:
    s.addi       s54, s29, #-64
    v.movi       v19, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v22, s55
    s.shli       s55, s53, #4
    s.addi       s56, s53, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s54, v0]             // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.movz       s55, #32
    v.st.b       [s54, #0], v19
    fence.acq_rel.device
    s.mov        s53, s56
    s.cmp.lt     s54, s53, s55
    br.nz        s54, x8dot_row_63
x8dot_done_62:
    v.splat      v0, s49
    v.movi       v19, #0
    mb.arm       s49, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s51, v30, #5
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s52, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s52, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v28, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s48
    mb.wait      s48
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s51, x8dot_done_64
    s.addi       s52, s30, #384
    s.add        s53, s6, s27
    s.addi       s54, s46, #0
    v.ld.w       v0, [s52, #0]
    s.addi       s46, s53, #64
    s.addi       s52, s30, #768
x8dot_row_65:
    s.addi       s53, s29, #-64
    v.movi       v19, #0
    s.sub        s55, s53, s54
    s.add        s53, s46, s54
    v.splat      v22, s55
    s.shli       s55, s54, #4
    s.addi       s56, s54, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s53, v0]             // index is in elements (ISA sec 9.1)
    s.add        s53, s52, s55
    s.movz       s55, #32
    v.st.b       [s53, #0], v19
    fence.acq_rel.device
    s.mov        s54, s56
    s.cmp.lt     s53, s54, s55
    br.nz        s53, x8dot_row_65
x8dot_done_64:
    v.splat      v0, s51
    v.movi       v19, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s51, #0
    v.extract    s52, v30, #6
    s.movz       s53, #64
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s54, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s54, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s54, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s52, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v28, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s52
    mb.wait      s52
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s54, x8dot_done_66
    s.addi       s55, s30, #448
    s.add        s56, s6, s27
    s.addi       s57, s51, #0
    v.ld.w       v0, [s55, #0]
    s.addi       s55, s56, #64
    s.addi       s56, s30, #1280
x8dot_row_67:
    s.addi       s58, s29, #-64
    v.movi       v19, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v22, s59
    s.shli       s59, s57, #4
    s.addi       s60, s57, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s58, v0]             // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    s.movz       s59, #32
    v.st.b       [s58, #0], v19
    fence.acq_rel.device
    s.mov        s57, s60
    s.cmp.lt     s58, s57, s59
    br.nz        s58, x8dot_row_67
x8dot_done_66:
    v.splat      v0, s54
    v.movi       v19, #0
    mb.arm       s54, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s55, v30, #7
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s56, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s56, s54            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s56, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v28, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s53
    mb.wait      s53
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s55, x8dot_done_68
    s.addi       s56, s30, #0
    s.add        s57, s6, s27
    s.addi       s58, s51, #0
    v.ld.w       v0, [s56, #0]
    s.addi       s51, s57, #96
    s.addi       s56, s30, #768
x8dot_row_69:
    s.addi       s57, s29, #-96
    v.movi       v19, #0
    s.sub        s59, s57, s58
    s.add        s57, s51, s58
    v.splat      v22, s59
    s.shli       s59, s58, #4
    s.addi       s60, s58, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s57, v0]             // index is in elements (ISA sec 9.1)
    s.add        s57, s56, s59
    s.movz       s59, #32
    v.st.b       [s57, #0], v19
    fence.acq_rel.device
    s.mov        s58, s60
    s.cmp.lt     s57, s58, s59
    br.nz        s57, x8dot_row_69
x8dot_done_68:
    v.splat      v0, s55
    v.movi       v19, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s55, #0
    v.extract    s56, v30, #0
    s.movz       s57, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s58, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s58, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s58, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s56, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s58, v28, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s56
    mb.wait      s56
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s58, x8dot_done_70
    s.addi       s59, s30, #64
    s.add        s60, s6, s27
    s.addi       s28, s55, #0
    v.ld.w       v0, [s59, #0]
    s.addi       s32, s60, #96
    s.addi       s33, s30, #1280
x8dot_row_71:
    s.addi       s34, s29, #-96
    v.movi       v19, #0
    s.sub        s35, s34, s28
    s.add        s34, s32, s28
    v.splat      v22, s35
    s.shli       s35, s28, #4
    s.addi       s36, s28, #1
    v.cmp.gt     p1, v22, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s34, v0]             // index is in elements (ISA sec 9.1)
    s.add        s34, s33, s35
    s.movz       s35, #32
    v.st.b       [s34, #0], v19
    fence.acq_rel.device
    s.mov        s28, s36
    s.cmp.lt     s34, s28, s35
    br.nz        s34, x8dot_row_71
x8dot_done_70:
    s.add        s28, s55, s19                   // the tile origin
    v.extract    s32, v20, #0
    v.splat      v0, s28
    s.add        s28, s32, s26
    s.add        s32, s55, s31                   // the tile origin
    v.splat      v19, s58
    v.movi       v22, #0
    s.addi       s33, s28, #96
    v.add        v23, v21, v0
    v.splat      v0, s32
    mb.arm       s28, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s32, v30, #1
    s.add        s34, s15, s33
    v.cmp.ne     p1, v19, v22
    v.cmp.eq     p2, v19, v22
    v.cmp.lt     p3, v23, v0
    s.mov        s35, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s35, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s28          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s34, #0]
    v.extract    s32, v20, #1
    s.addi       s33, s30, #3840                 // 512 bytes of repack scratch
    s.add        s34, s32, s26
    s.addi       s32, s33, #0
    s.addi       s35, s34, #96
    v.extract    s34, v20, #2
    s.add        s36, s15, s35
    s.add        s35, s34, s26
    s.addi       s34, s33, #32
    s.addi       s37, s35, #96
    v.extract    s35, v20, #3
    v.st.b       [s32, #0], v0
    s.add        s32, s15, s37
    s.add        s37, s35, s26
    s.addi       s35, s33, #64
    s.addi       s38, s37, #96
    v.extract    s37, v20, #4
    s.add        s39, s15, s38
    s.add        s38, s37, s26
    s.addi       s37, s33, #96
    s.addi       s40, s38, #96
    s.add        s38, s15, s40
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s36, #0]
    v.extract    s36, v20, #5
    s.add        s40, s36, s26
    s.addi       s36, s40, #96
    s.add        s40, s15, s36
    v.st.b       [s34, #0], v0
    s.addi       s34, s33, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s32, #0]
    v.extract    s32, v20, #6
    s.add        s36, s32, s26
    s.addi       s32, s36, #96
    s.add        s36, s15, s32
    v.st.b       [s35, #0], v0
    s.addi       s32, s33, #160
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s39, #0]
    v.extract    s35, v20, #7
    s.add        s39, s35, s26
    s.addi       s35, s39, #96
    s.add        s39, s15, s35
    v.st.b       [s37, #0], v0
    s.addi       s35, s33, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s38, #0]
    v.extract    s37, v20, #8
    s.add        s38, s37, s26
    s.addi       s37, s38, #96
    s.add        s38, s15, s37
    v.st.b       [s34, #0], v0
    s.addi       s34, s33, #224
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s40, #0]
    v.extract    s37, v20, #9
    s.add        s40, s37, s26
    s.addi       s37, s40, #96
    s.add        s40, s15, s37
    v.st.b       [s32, #0], v0
    s.addi       s32, s33, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s36, #0]
    v.extract    s36, v20, #10
    s.add        s37, s36, s26
    s.addi       s36, s37, #96
    s.add        s37, s15, s36
    v.st.b       [s35, #0], v0
    s.addi       s35, s33, #288
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s39, #0]
    v.extract    s36, v20, #11
    s.add        s39, s36, s26
    s.addi       s36, s39, #96
    s.add        s39, s15, s36
    v.st.b       [s34, #0], v0
    s.addi       s34, s33, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s38, #0]
    v.extract    s36, v20, #12
    s.add        s38, s36, s26
    s.addi       s36, s38, #96
    s.add        s38, s15, s36
    v.st.b       [s32, #0], v0
    s.addi       s32, s33, #352
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s40, #0]
    v.extract    s36, v20, #13
    s.add        s40, s36, s26
    s.addi       s36, s40, #96
    s.add        s40, s15, s36
    v.st.b       [s35, #0], v0
    s.addi       s35, s33, #384
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s37, #0]
    v.extract    s36, v20, #14
    s.add        s37, s36, s26
    s.addi       s36, s37, #96
    s.add        s37, s15, s36
    v.st.b       [s34, #0], v0
    s.addi       s34, s33, #416
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s39, #0]
    v.extract    s36, v20, #15
    s.add        s39, s36, s26
    s.addi       s36, s39, #96
    s.add        s39, s15, s36
    v.st.b       [s32, #0], v0
    s.addi       s32, s33, #448
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s38, #0]
    s.movz       s36, #0
    s.add        s38, s36, s31                   // the tile origin
    s.add        s31, s36, s22                   // the tile origin
    v.splat      v19, s38
    v.extract    s36, v20, #0
    v.splat      v22, s31
    s.add        s31, s36, s26
    s.addi       s36, s33, #480
    s.addi       s38, s31, #112
    v.add        v23, v21, v22
    v.st.b       [s35, #0], v0
    s.add        s31, s15, s38
    v.cmp.lt     p1, v23, v19
    v.extract    s35, v20, #1
    s.add        s38, s35, s26
    s.addi       s35, s38, #112
    s.add        s38, s15, s35
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s40, #0]
    s.addi       s35, s33, #16
    v.st.b       [s34, #0], v0
    v.extract    s34, v20, #2
    s.add        s40, s34, s26
    s.addi       s34, s40, #112
    s.add        s40, s15, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s37, #0]
    s.addi       s34, s33, #48
    v.st.b       [s32, #0], v0
    v.extract    s32, v20, #3
    s.add        s37, s32, s26
    s.addi       s32, s37, #112
    s.add        s37, s15, s32
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s39, #0]
    s.addi       s32, s33, #80
    v.st.b       [s36, #0], v0
    v.extract    s36, v20, #4
    s.add        s39, s36, s26
    s.addi       s36, s39, #112
    s.add        s39, s15, s36
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s31, #0]
    s.addi       s31, s33, #112
    v.st.b       [s35, #0], v0
    v.extract    s35, v20, #5
    s.add        s36, s35, s26
    s.addi       s35, s36, #112
    s.add        s36, s15, s35
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    s.addi       s35, s33, #144
    v.st.b       [s34, #0], v0
    v.extract    s34, v20, #6
    s.add        s38, s34, s26
    s.addi       s34, s38, #112
    s.add        s38, s15, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s40, #0]
    s.addi       s34, s33, #176
    v.st.b       [s32, #0], v0
    v.extract    s32, v20, #7
    s.add        s40, s32, s26
    s.addi       s32, s40, #112
    s.add        s40, s15, s32
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s37, #0]
    s.addi       s32, s33, #208
    v.st.b       [s31, #0], v0
    v.extract    s31, v20, #8
    s.add        s37, s31, s26
    s.addi       s31, s37, #112
    s.add        s37, s15, s31
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    s.addi       s31, s33, #240
    v.st.b       [s35, #0], v0
    v.extract    s35, v20, #9
    s.add        s39, s35, s26
    s.addi       s35, s39, #112
    s.add        s39, s15, s35
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s36, #0]
    s.addi       s35, s33, #272
    v.st.b       [s34, #0], v0
    v.extract    s34, v20, #10
    s.add        s36, s34, s26
    s.addi       s34, s36, #112
    s.add        s36, s15, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    s.addi       s34, s33, #304
    v.st.b       [s32, #0], v0
    v.extract    s32, v20, #11
    s.add        s38, s32, s26
    s.addi       s32, s38, #112
    s.add        s38, s15, s32
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s40, #0]
    s.addi       s32, s33, #336
    v.st.b       [s31, #0], v0
    v.extract    s31, v20, #12
    s.add        s40, s31, s26
    s.addi       s31, s40, #112
    s.add        s40, s15, s31
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s37, #0]
    s.addi       s31, s33, #368
    v.st.b       [s35, #0], v0
    v.extract    s35, v20, #13
    s.add        s37, s35, s26
    s.addi       s35, s37, #112
    s.add        s37, s15, s35
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    s.addi       s35, s33, #400
    v.st.b       [s34, #0], v0
    v.extract    s34, v20, #14
    s.add        s39, s34, s26
    s.addi       s34, s39, #112
    s.add        s39, s15, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s36, #0]
    s.addi       s34, s33, #432
    v.st.b       [s32, #0], v0
    v.extract    s32, v20, #15
    s.add        s36, s32, s26
    s.addi       s32, s36, #112
    s.add        s36, s15, s32
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    s.addi       s32, s33, #464
    v.st.b       [s31, #0], v0
    s.addi       s31, s33, #496
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s40, #0]
    s.addi       s38, s33, #64
    v.st.b       [s35, #0], v0
    s.addi       s35, s33, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s37, #0]
    s.addi       s37, s33, #192
    v.st.b       [s34, #0], v0
    s.addi       s34, s33, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    s.addi       s39, s33, #320
    v.st.b       [s32, #0], v0
    s.addi       s32, s33, #384
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s36, #0]
    s.addi       s36, s33, #448
    v.st.b       [s31, #0], v0
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.extract    s31, v28, #2
    v.ld.w       v0, [s33, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s38, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s35, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s37, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s34, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s39, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s32, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s36, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.wait      s51
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s32
    mb.wait      s32
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s31, x8dot_done_72
    s.movz       s33, #0
    s.addi       s34, s30, #128
    s.add        s35, s6, s27
    s.addi       s36, s33, #0
    v.ld.w       v0, [s34, #0]
    s.addi       s33, s35, #96
    s.addi       s34, s30, #768
x8dot_row_73:
    s.addi       s35, s29, #-96
    v.movi       v19, #0
    s.sub        s37, s35, s36
    s.add        s35, s33, s36
    v.splat      v20, s37
    s.shli       s37, s36, #4
    s.addi       s38, s36, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s35, v0]             // index is in elements (ISA sec 9.1)
    s.add        s35, s34, s37
    s.movz       s37, #32
    v.st.b       [s35, #0], v19
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s35, s36, s37
    br.nz        s35, x8dot_row_73
x8dot_done_72:
    v.splat      v0, s31
    v.movi       v19, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.extract    s34, v30, #2
    s.movz       s35, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s36, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s36, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s36, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s34, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v28, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s34
    mb.wait      s34
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s36, x8dot_done_74
    s.addi       s37, s30, #192
    s.add        s38, s6, s27
    s.addi       s39, s33, #0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s38, #96
    s.addi       s38, s30, #1280
x8dot_row_75:
    s.addi       s40, s29, #-96
    v.movi       v19, #0
    s.sub        s41, s40, s39
    s.add        s40, s37, s39
    v.splat      v20, s41
    s.shli       s41, s39, #4
    s.addi       s42, s39, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s40, v0]             // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    s.movz       s41, #32
    v.st.b       [s40, #0], v19
    fence.acq_rel.device
    s.mov        s39, s42
    s.cmp.lt     s40, s39, s41
    br.nz        s40, x8dot_row_75
x8dot_done_74:
    v.splat      v0, s36
    v.movi       v19, #0
    mb.arm       s36, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s37, v30, #3
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s38, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v28, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s35
    mb.wait      s35
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s37, x8dot_done_76
    s.addi       s38, s30, #256
    s.add        s39, s6, s27
    s.addi       s40, s33, #0
    v.ld.w       v0, [s38, #0]
    s.addi       s33, s39, #96
    s.addi       s38, s30, #768
x8dot_row_77:
    s.addi       s39, s29, #-96
    v.movi       v19, #0
    s.sub        s41, s39, s40
    s.add        s39, s33, s40
    v.splat      v20, s41
    s.shli       s41, s40, #4
    s.addi       s42, s40, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s39, v0]             // index is in elements (ISA sec 9.1)
    s.add        s39, s38, s41
    s.movz       s41, #32
    v.st.b       [s39, #0], v19
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s39, s40, s41
    br.nz        s39, x8dot_row_77
x8dot_done_76:
    v.splat      v0, s37
    v.movi       v19, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.extract    s38, v30, #4
    s.movz       s39, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s40, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s40, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s38, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v28, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s38
    mb.wait      s38
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s40, x8dot_done_78
    s.addi       s41, s30, #320
    s.add        s42, s6, s27
    s.addi       s43, s37, #0
    v.ld.w       v0, [s41, #0]
    s.addi       s41, s42, #96
    s.addi       s42, s30, #1280
x8dot_row_79:
    s.addi       s44, s29, #-96
    v.movi       v19, #0
    s.sub        s45, s44, s43
    s.add        s44, s41, s43
    v.splat      v20, s45
    s.shli       s45, s43, #4
    s.addi       s46, s43, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s44, v0]             // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v19
    fence.acq_rel.device
    s.mov        s43, s46
    s.cmp.lt     s44, s43, s45
    br.nz        s44, x8dot_row_79
x8dot_done_78:
    v.splat      v0, s40
    v.movi       v19, #0
    mb.arm       s40, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s41, v30, #5
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s42, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v28, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s39
    mb.wait      s39
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s41, x8dot_done_80
    s.addi       s42, s30, #384
    s.add        s43, s6, s27
    s.addi       s44, s37, #0
    v.ld.w       v0, [s42, #0]
    s.addi       s37, s43, #96
    s.addi       s42, s30, #768
x8dot_row_81:
    s.addi       s43, s29, #-96
    v.movi       v19, #0
    s.sub        s45, s43, s44
    s.add        s43, s37, s44
    v.splat      v20, s45
    s.shli       s45, s44, #4
    s.addi       s46, s44, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s43, v0]             // index is in elements (ISA sec 9.1)
    s.add        s43, s42, s45
    s.movz       s45, #32
    v.st.b       [s43, #0], v19
    fence.acq_rel.device
    s.mov        s44, s46
    s.cmp.lt     s43, s44, s45
    br.nz        s43, x8dot_row_81
x8dot_done_80:
    v.splat      v0, s41
    v.movi       v19, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    v.extract    s42, v30, #6
    s.movz       s43, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s44, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s44, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s44, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s42, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v28, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s42
    mb.wait      s42
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s44, x8dot_done_82
    s.addi       s45, s30, #448
    s.add        s46, s6, s27
    s.addi       s47, s41, #0
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s46, #96
    s.addi       s46, s30, #1280
x8dot_row_83:
    s.addi       s48, s29, #-96
    v.movi       v19, #0
    s.sub        s49, s48, s47
    s.add        s48, s45, s47
    v.splat      v20, s49
    s.shli       s49, s47, #4
    s.addi       s50, s47, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s48, v0]             // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.movz       s49, #32
    v.st.b       [s48, #0], v19
    fence.acq_rel.device
    s.mov        s47, s50
    s.cmp.lt     s48, s47, s49
    br.nz        s48, x8dot_row_83
x8dot_done_82:
    v.splat      v0, s44
    v.movi       v19, #0
    mb.arm       s29, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s44, v30, #7
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s45, s29            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s29          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s44, s30, #4352
    s.movz       s45, #1
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s43
    mb.wait      s43
    mb.wait      s29
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s47, s44, #64
    s.movz       s48, #2
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s46
    mb.wait      s46
    a.vread      v0, a8, s41
    s.addi       s41, s44, #128
    s.movz       s49, #3
    v.st.w       [s44, #0], v0
    a.vread      v0, a8, s45
    s.addi       s45, s44, #192
    s.movz       s50, #4
    s.addi       s52, s44, #256
    s.movz       s53, #5
    s.addi       s54, s44, #320
    s.movz       s55, #6
    s.addi       s56, s44, #384
    s.movz       s57, #7
    s.addi       s58, s44, #448
    s.movz       s59, #8
    s.addi       s60, s44, #512
    s.movz       s28, #9
    s.addi       s29, s44, #576
    s.movz       s31, #10
    v.st.w       [s47, #0], v0
    a.vread      v0, a8, s48
    s.addi       s32, s44, #640
    s.movz       s33, #11
    v.st.w       [s41, #0], v0
    a.vread      v0, a8, s49
    s.addi       s34, s44, #704
    s.movz       s35, #12
    v.st.w       [s45, #0], v0
    a.vread      v0, a8, s50
    s.addi       s36, s44, #768
    s.movz       s37, #13
    v.st.w       [s52, #0], v0
    a.vread      v0, a8, s53
    s.addi       s38, s44, #832
    s.movz       s39, #14
    v.st.w       [s54, #0], v0
    a.vread      v0, a8, s55
    s.addi       s40, s44, #896
    s.movz       s41, #15
    s.addi       s42, s44, #960
    v.st.w       [s56, #0], v0
    a.vread      v0, a8, s57
    s.movz       s43, #0
    s.addi       s44, s30, #5376
    v.st.w       [s58, #0], v0
    a.vread      v0, a8, s59
    s.movz       s45, #1
    s.addi       s46, s44, #64
    v.st.w       [s60, #0], v0
    a.vread      v0, a8, s28
    s.movz       s28, #2
    s.addi       s47, s44, #128
    v.st.w       [s29, #0], v0
    a.vread      v0, a8, s31
    s.movz       s29, #3
    s.addi       s31, s44, #192
    v.st.w       [s32, #0], v0
    a.vread      v0, a8, s33
    s.movz       s32, #4
    s.addi       s33, s44, #256
    v.st.w       [s34, #0], v0
    a.vread      v0, a8, s35
    s.movz       s34, #5
    s.addi       s35, s44, #320
    v.st.w       [s36, #0], v0
    a.vread      v0, a8, s37
    s.movz       s36, #6
    s.addi       s37, s44, #384
    v.st.w       [s38, #0], v0
    a.vread      v0, a8, s39
    s.movz       s38, #7
    s.addi       s39, s44, #448
    v.st.w       [s40, #0], v0
    a.vread      v0, a8, s41
    s.movz       s40, #8
    s.addi       s41, s44, #512
    v.st.w       [s42, #0], v0
    fence.acq_rel.device
    a.vread      v0, a9, s43
    s.movz       s42, #9
    s.addi       s43, s44, #576
    v.st.w       [s44, #0], v0
    a.vread      v0, a9, s45
    s.movz       s45, #10
    v.st.w       [s46, #0], v0
    a.vread      v0, a9, s28
    s.addi       s28, s44, #640
    s.movz       s46, #11
    v.st.w       [s47, #0], v0
    a.vread      v0, a9, s29
    s.addi       s29, s44, #704
    s.movz       s47, #12
    v.st.w       [s31, #0], v0
    a.vread      v0, a9, s32
    s.addi       s31, s44, #768
    s.movz       s32, #13
    v.st.w       [s33, #0], v0
    a.vread      v0, a9, s34
    s.addi       s33, s44, #832
    s.movz       s34, #14
    v.st.w       [s35, #0], v0
    a.vread      v0, a9, s36
    s.addi       s35, s44, #896
    s.movz       s36, #15
    s.addi       s48, s44, #960
    v.st.w       [s37, #0], v0
    a.vread      v0, a9, s38
    s.movz       s37, #0
    s.addi       s38, s30, #6400
    v.st.w       [s39, #0], v0
    a.vread      v0, a9, s40
    s.movz       s39, #1
    s.addi       s40, s38, #64
    v.st.w       [s41, #0], v0
    a.vread      v0, a9, s42
    s.movz       s41, #2
    s.addi       s42, s38, #128
    v.st.w       [s43, #0], v0
    a.vread      v0, a9, s45
    s.movz       s43, #3
    s.addi       s44, s38, #192
    v.st.w       [s28, #0], v0
    a.vread      v0, a9, s46
    s.movz       s28, #4
    s.addi       s45, s38, #256
    v.st.w       [s29, #0], v0
    a.vread      v0, a9, s47
    s.movz       s29, #5
    s.addi       s46, s38, #320
    v.st.w       [s31, #0], v0
    a.vread      v0, a9, s32
    s.movz       s31, #6
    s.addi       s32, s38, #384
    v.st.w       [s33, #0], v0
    a.vread      v0, a9, s34
    s.movz       s33, #7
    s.addi       s34, s38, #448
    v.st.w       [s35, #0], v0
    a.vread      v0, a9, s36
    s.movz       s35, #8
    s.addi       s36, s38, #512
    v.st.w       [s48, #0], v0
    fence.acq_rel.device
    a.vread      v0, a10, s37
    s.movz       s37, #9
    s.addi       s47, s38, #576
    v.st.w       [s38, #0], v0
    a.vread      v0, a10, s39
    s.movz       s39, #10
    v.st.w       [s40, #0], v0
    a.vread      v0, a10, s41
    s.addi       s40, s38, #640
    s.movz       s41, #11
    v.st.w       [s42, #0], v0
    a.vread      v0, a10, s43
    s.addi       s42, s38, #704
    s.movz       s43, #12
    v.st.w       [s44, #0], v0
    a.vread      v0, a10, s28
    s.addi       s28, s38, #768
    s.movz       s44, #13
    v.st.w       [s45, #0], v0
    a.vread      v0, a10, s29
    s.addi       s29, s38, #832
    s.movz       s45, #14
    v.st.w       [s46, #0], v0
    a.vread      v0, a10, s31
    s.addi       s31, s38, #896
    s.movz       s46, #15
    s.addi       s48, s38, #960
    v.st.w       [s32, #0], v0
    a.vread      v0, a10, s33
    s.movz       s32, #0
    s.addi       s33, s30, #7424
    v.st.w       [s34, #0], v0
    a.vread      v0, a10, s35
    s.movz       s34, #1
    s.addi       s35, s33, #64
    v.st.w       [s36, #0], v0
    a.vread      v0, a10, s37
    s.movz       s36, #2
    s.addi       s37, s33, #128
    v.st.w       [s47, #0], v0
    a.vread      v0, a10, s39
    s.movz       s38, #3
    s.addi       s39, s33, #192
    v.st.w       [s40, #0], v0
    a.vread      v0, a10, s41
    s.movz       s40, #4
    s.addi       s41, s33, #256
    v.st.w       [s42, #0], v0
    a.vread      v0, a10, s43
    s.movz       s42, #5
    s.addi       s43, s33, #320
    v.st.w       [s28, #0], v0
    a.vread      v0, a10, s44
    s.movz       s28, #6
    s.addi       s44, s33, #384
    v.st.w       [s29, #0], v0
    a.vread      v0, a10, s45
    s.movz       s29, #7
    s.addi       s45, s33, #448
    v.st.w       [s31, #0], v0
    a.vread      v0, a10, s46
    s.movz       s31, #8
    s.addi       s46, s33, #512
    v.st.w       [s48, #0], v0
    fence.acq_rel.device
    a.vread      v0, a11, s32
    s.movz       s32, #9
    s.addi       s47, s33, #576
    v.st.w       [s33, #0], v0
    a.vread      v0, a11, s34
    s.movz       s34, #10
    v.st.w       [s35, #0], v0
    a.vread      v0, a11, s36
    s.addi       s35, s33, #640
    s.movz       s36, #11
    v.st.w       [s37, #0], v0
    a.vread      v0, a11, s38
    s.addi       s37, s33, #704
    s.movz       s38, #12
    v.st.w       [s39, #0], v0
    a.vread      v0, a11, s40
    s.addi       s39, s33, #768
    s.movz       s40, #13
    v.st.w       [s41, #0], v0
    a.vread      v0, a11, s42
    s.addi       s41, s33, #832
    s.movz       s42, #14
    v.st.w       [s43, #0], v0
    a.vread      v0, a11, s28
    s.addi       s28, s33, #896
    s.movz       s43, #15
    s.addi       s48, s33, #960
    v.st.w       [s44, #0], v0
    a.vread      v0, a11, s29
    s.movz       s29, #0
    s.addi       s33, s30, #8448
    v.st.w       [s45, #0], v0
    a.vread      v0, a11, s31
    s.movz       s31, #1
    s.addi       s44, s33, #64
    v.st.w       [s46, #0], v0
    a.vread      v0, a11, s32
    s.movz       s32, #2
    s.addi       s45, s33, #128
    v.st.w       [s47, #0], v0
    a.vread      v0, a11, s34
    s.movz       s34, #3
    s.addi       s46, s33, #192
    v.st.w       [s35, #0], v0
    a.vread      v0, a11, s36
    s.movz       s35, #4
    s.addi       s36, s33, #256
    v.st.w       [s37, #0], v0
    a.vread      v0, a11, s38
    s.movz       s37, #5
    s.addi       s38, s33, #320
    v.st.w       [s39, #0], v0
    a.vread      v0, a11, s40
    s.movz       s39, #6
    s.addi       s40, s33, #384
    v.st.w       [s41, #0], v0
    a.vread      v0, a11, s42
    s.movz       s41, #7
    s.addi       s42, s33, #448
    v.st.w       [s28, #0], v0
    a.vread      v0, a11, s43
    s.movz       s28, #8
    s.addi       s43, s33, #512
    v.st.w       [s48, #0], v0
    fence.acq_rel.device
    a.vread      v0, a12, s29
    s.movz       s29, #9
    s.addi       s47, s33, #576
    v.st.w       [s33, #0], v0
    a.vread      v0, a12, s31
    s.movz       s31, #10
    v.st.w       [s44, #0], v0
    a.vread      v0, a12, s32
    s.addi       s32, s33, #640
    s.movz       s44, #11
    v.st.w       [s45, #0], v0
    a.vread      v0, a12, s34
    s.addi       s34, s33, #704
    s.movz       s45, #12
    v.st.w       [s46, #0], v0
    a.vread      v0, a12, s35
    s.addi       s35, s33, #768
    s.movz       s46, #13
    v.st.w       [s36, #0], v0
    a.vread      v0, a12, s37
    s.addi       s36, s33, #832
    s.movz       s37, #14
    v.st.w       [s38, #0], v0
    a.vread      v0, a12, s39
    s.addi       s38, s33, #896
    s.movz       s39, #15
    s.addi       s48, s33, #960
    v.st.w       [s40, #0], v0
    a.vread      v0, a12, s41
    s.movz       s33, #0
    s.addi       s40, s30, #9472
    v.st.w       [s42, #0], v0
    a.vread      v0, a12, s28
    s.movz       s28, #1
    s.addi       s41, s40, #64
    v.st.w       [s43, #0], v0
    a.vread      v0, a12, s29
    s.movz       s29, #2
    s.addi       s42, s40, #128
    v.st.w       [s47, #0], v0
    a.vread      v0, a12, s31
    s.movz       s31, #3
    s.addi       s43, s40, #192
    v.st.w       [s32, #0], v0
    a.vread      v0, a12, s44
    s.movz       s32, #4
    s.addi       s44, s40, #256
    v.st.w       [s34, #0], v0
    a.vread      v0, a12, s45
    s.movz       s34, #5
    s.addi       s45, s40, #320
    v.st.w       [s35, #0], v0
    a.vread      v0, a12, s46
    s.movz       s35, #6
    s.addi       s46, s40, #384
    v.st.w       [s36, #0], v0
    a.vread      v0, a12, s37
    s.movz       s36, #7
    s.addi       s37, s40, #448
    v.st.w       [s38, #0], v0
    a.vread      v0, a12, s39
    s.movz       s38, #8
    s.addi       s39, s40, #512
    v.st.w       [s48, #0], v0
    fence.acq_rel.device
    a.vread      v0, a13, s33
    s.movz       s33, #9
    s.addi       s47, s40, #576
    v.st.w       [s40, #0], v0
    a.vread      v0, a13, s28
    s.movz       s28, #10
    v.st.w       [s41, #0], v0
    a.vread      v0, a13, s29
    s.addi       s29, s40, #640
    s.movz       s41, #11
    v.st.w       [s42, #0], v0
    a.vread      v0, a13, s31
    s.addi       s31, s40, #704
    s.movz       s42, #12
    v.st.w       [s43, #0], v0
    a.vread      v0, a13, s32
    s.addi       s32, s40, #768
    s.movz       s43, #13
    v.st.w       [s44, #0], v0
    a.vread      v0, a13, s34
    s.addi       s34, s40, #832
    s.movz       s44, #14
    v.st.w       [s45, #0], v0
    a.vread      v0, a13, s35
    s.addi       s35, s40, #896
    s.movz       s45, #15
    s.addi       s48, s40, #960
    v.st.w       [s46, #0], v0
    a.vread      v0, a13, s36
    s.movz       s36, #0
    s.addi       s40, s30, #10496
    v.st.w       [s37, #0], v0
    a.vread      v0, a13, s38
    s.movz       s37, #1
    s.addi       s38, s40, #64
    v.st.w       [s39, #0], v0
    a.vread      v0, a13, s33
    s.movz       s33, #2
    s.addi       s39, s40, #128
    v.st.w       [s47, #0], v0
    a.vread      v0, a13, s28
    s.movz       s28, #3
    s.addi       s46, s40, #192
    v.st.w       [s29, #0], v0
    a.vread      v0, a13, s41
    s.movz       s29, #4
    s.addi       s41, s40, #256
    v.st.w       [s31, #0], v0
    a.vread      v0, a13, s42
    s.movz       s31, #5
    s.addi       s42, s40, #320
    v.st.w       [s32, #0], v0
    a.vread      v0, a13, s43
    s.movz       s32, #6
    s.addi       s43, s40, #384
    v.st.w       [s34, #0], v0
    a.vread      v0, a13, s44
    s.movz       s34, #7
    s.addi       s44, s40, #448
    v.st.w       [s35, #0], v0
    a.vread      v0, a13, s45
    s.movz       s35, #8
    s.addi       s45, s40, #512
    v.st.w       [s48, #0], v0
    fence.acq_rel.device
    a.vread      v0, a14, s36
    s.movz       s36, #9
    s.addi       s47, s40, #576
    v.st.w       [s40, #0], v0
    a.vread      v0, a14, s37
    s.movz       s37, #10
    v.st.w       [s38, #0], v0
    a.vread      v0, a14, s33
    s.addi       s33, s40, #640
    s.movz       s38, #11
    v.st.w       [s39, #0], v0
    a.vread      v0, a14, s28
    s.addi       s28, s40, #704
    s.movz       s39, #12
    v.st.w       [s46, #0], v0
    a.vread      v0, a14, s29
    s.addi       s29, s40, #768
    s.movz       s46, #13
    v.st.w       [s41, #0], v0
    a.vread      v0, a14, s31
    s.addi       s31, s40, #832
    s.movz       s41, #14
    v.st.w       [s42, #0], v0
    a.vread      v0, a14, s32
    s.addi       s32, s40, #896
    s.movz       s42, #15
    s.addi       s48, s40, #960
    v.st.w       [s43, #0], v0
    a.vread      v0, a14, s34
    s.movz       s34, #0
    s.addi       s40, s30, #11520
    v.st.w       [s44, #0], v0
    a.vread      v0, a14, s35
    s.movz       s35, #1
    s.addi       s43, s40, #64
    v.st.w       [s45, #0], v0
    a.vread      v0, a14, s36
    s.movz       s36, #2
    s.addi       s44, s40, #128
    v.st.w       [s47, #0], v0
    a.vread      v0, a14, s37
    s.movz       s37, #3
    s.addi       s45, s40, #192
    v.st.w       [s33, #0], v0
    a.vread      v0, a14, s38
    s.movz       s33, #4
    s.addi       s38, s40, #256
    v.st.w       [s28, #0], v0
    a.vread      v0, a14, s39
    s.movz       s28, #5
    s.addi       s39, s40, #320
    v.st.w       [s29, #0], v0
    a.vread      v0, a14, s46
    s.movz       s29, #6
    s.addi       s46, s40, #384
    v.st.w       [s31, #0], v0
    a.vread      v0, a14, s41
    s.movz       s31, #7
    s.addi       s41, s40, #448
    v.st.w       [s32, #0], v0
    a.vread      v0, a14, s42
    s.movz       s32, #8
    s.addi       s42, s40, #512
    v.st.w       [s48, #0], v0
    fence.acq_rel.device
    a.vread      v0, a15, s34
    s.movz       s34, #9
    s.addi       s47, s40, #576
    v.st.w       [s40, #0], v0
    a.vread      v0, a15, s35
    s.movz       s35, #10
    v.st.w       [s43, #0], v0
    a.vread      v0, a15, s36
    s.addi       s36, s40, #640
    s.movz       s43, #11
    v.st.w       [s44, #0], v0
    a.vread      v0, a15, s37
    s.addi       s37, s40, #704
    s.movz       s44, #12
    v.st.w       [s45, #0], v0
    a.vread      v0, a15, s33
    s.addi       s33, s40, #768
    s.movz       s45, #13
    v.st.w       [s38, #0], v0
    a.vread      v0, a15, s28
    s.addi       s28, s40, #832
    s.movz       s38, #14
    v.st.w       [s39, #0], v0
    a.vread      v0, a15, s29
    s.addi       s29, s40, #896
    s.movz       s39, #15
    s.addi       s48, s40, #960
    v.st.w       [s46, #0], v0
    a.vread      v0, a15, s31
    s.movz       s31, #0
    s.addi       s40, s30, #4352
    v.st.w       [s41, #0], v0
    a.vread      v0, a15, s32
    v.extract    s32, v29, #0
    s.addi       s41, s30, #12544
    v.splat      v19, s32
    s.movz       s32, #1
    v.st.w       [s42, #0], v0
    a.vread      v0, a15, s34
    s.addi       s34, s30, #4416
    v.extract    s42, v29, #1
    v.splat      v20, s42
    s.addi       s42, s41, #64
    v.st.w       [s47, #0], v0
    a.vread      v0, a15, s35
    s.movz       s35, #2
    s.addi       s46, s30, #4480
    v.st.w       [s36, #0], v0
    a.vread      v0, a15, s43
    v.extract    s36, v29, #2
    s.addi       s43, s41, #128
    v.splat      v21, s36
    v.st.w       [s37, #0], v0
    a.vread      v0, a15, s44
    s.addi       s36, s41, #192
    v.st.w       [s33, #0], v0
    a.vread      v0, a15, s45
    s.movz       s33, #3
    s.addi       s37, s30, #4544
    v.st.w       [s28, #0], v0
    a.vread      v0, a15, s38
    v.extract    s28, v29, #3
    v.splat      v22, s28
    v.st.w       [s29, #0], v0
    a.vread      v0, a15, s39
    s.movz       s28, #4
    s.addi       s29, s41, #256
    v.st.w       [s48, #0], v0
    fence.acq_rel.device
    a.vread      v0, a0, s31
    s.addi       s31, s30, #4608
    v.extract    s38, v29, #4
    v.splat      v23, s38
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    s.addi       s38, s41, #320
    vf.mul       v19, v25, v31
    s.movz       s39, #5
    vf.add       v24, v0, v19
    v.st.w       [s41, #0], v24
    a.vread      v0, a0, s32
    s.addi       s32, s30, #4672
    v.extract    s40, v29, #5
    v.splat      v19, s40
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v20
    s.addi       s34, s41, #384
    vf.mul       v20, v25, v31
    s.movz       s40, #6
    vf.add       v24, v0, v20
    v.st.w       [s42, #0], v24
    a.vread      v0, a0, s35
    s.addi       s35, s30, #4736
    v.extract    s42, v29, #6
    v.splat      v20, s42
    v.ld.w       v24, [s46, #0]
    vf.mul       v25, v24, v21
    s.addi       s42, s41, #448
    vf.mul       v21, v25, v31
    s.movz       s44, #7
    vf.add       v24, v0, v21
    v.st.w       [s43, #0], v24
    a.vread      v0, a0, s33
    s.addi       s33, s30, #4800
    v.extract    s43, v29, #7
    v.splat      v21, s43
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    s.addi       s37, s41, #512
    vf.mul       v22, v25, v31
    s.movz       s43, #8
    vf.add       v24, v0, v22
    v.st.w       [s36, #0], v24
    a.vread      v0, a0, s28
    s.addi       s28, s30, #4864
    v.extract    s36, v29, #8
    v.splat      v22, s36
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v23
    s.addi       s31, s41, #576
    vf.mul       v23, v25, v31
    s.movz       s36, #9
    vf.add       v24, v0, v23
    v.st.w       [s29, #0], v24
    a.vread      v0, a0, s39
    s.addi       s29, s30, #4928
    v.extract    s39, v29, #9
    v.splat      v23, s39
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v19
    s.addi       s32, s41, #640
    vf.mul       v19, v25, v31
    s.movz       s39, #10
    vf.add       v24, v0, v19
    v.st.w       [s38, #0], v24
    a.vread      v0, a0, s40
    s.addi       s38, s30, #4992
    v.extract    s40, v29, #10
    v.splat      v19, s40
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s41, #704
    vf.mul       v20, v25, v31
    s.movz       s40, #11
    vf.add       v24, v0, v20
    v.st.w       [s34, #0], v24
    a.vread      v0, a0, s44
    s.addi       s34, s30, #5056
    v.extract    s44, v29, #11
    v.splat      v20, s44
    v.ld.w       v24, [s33, #0]
    vf.mul       v25, v24, v21
    s.addi       s33, s41, #768
    vf.mul       v21, v25, v31
    s.movz       s44, #12
    vf.add       v24, v0, v21
    v.st.w       [s42, #0], v24
    a.vread      v0, a0, s43
    s.addi       s42, s30, #5120
    v.extract    s43, v29, #12
    v.splat      v21, s43
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v22
    s.addi       s28, s41, #832
    vf.mul       v22, v25, v31
    s.movz       s43, #13
    vf.add       v24, v0, v22
    v.st.w       [s37, #0], v24
    a.vread      v0, a0, s36
    s.addi       s36, s30, #5184
    v.extract    s37, v29, #13
    v.splat      v22, s37
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v23
    s.addi       s29, s41, #896
    vf.mul       v23, v25, v31
    s.movz       s37, #14
    vf.add       v24, v0, v23
    v.st.w       [s31, #0], v24
    a.vread      v0, a0, s39
    s.addi       s31, s30, #5248
    v.extract    s39, v29, #14
    v.splat      v23, s39
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    s.addi       s38, s41, #960
    vf.mul       v19, v25, v31
    s.movz       s39, #15
    vf.add       v24, v0, v19
    v.st.w       [s32, #0], v24
    a.vread      v0, a0, s40
    s.addi       s32, s30, #5312
    v.extract    s40, v29, #15
    v.splat      v19, s40
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v31
    s.addi       s34, s30, #13568
    vf.add       v24, v0, v20
    s.movz       s40, #0
    v.st.w       [s35, #0], v24
    a.vread      v0, a0, s44
    s.addi       s35, s30, #5376
    v.extract    s41, v29, #0
    v.splat      v20, s41
    v.ld.w       v24, [s42, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v31
    s.addi       s41, s34, #64
    vf.add       v24, v0, v21
    s.movz       s42, #1
    v.st.w       [s33, #0], v24
    a.vread      v0, a0, s43
    s.addi       s33, s30, #5440
    v.extract    s43, v29, #1
    v.splat      v21, s43
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v31
    s.addi       s36, s34, #128
    vf.add       v24, v0, v22
    s.movz       s43, #2
    v.st.w       [s28, #0], v24
    a.vread      v0, a0, s37
    s.addi       s28, s30, #5504
    v.extract    s37, v29, #2
    v.splat      v22, s37
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v31
    s.addi       s31, s34, #192
    vf.add       v24, v0, v23
    s.movz       s37, #3
    v.st.w       [s29, #0], v24
    a.vread      v0, a0, s39
    s.addi       s29, s30, #5568
    v.extract    s39, v29, #3
    v.splat      v23, s39
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v31
    s.addi       s32, s34, #256
    vf.add       v24, v0, v19
    s.movz       s39, #4
    v.st.w       [s38, #0], v24
    fence.acq_rel.device
    a.vread      v0, a1, s40
    s.addi       s38, s30, #5632
    v.extract    s40, v29, #4
    v.splat      v19, s40
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s34, #320
    vf.mul       v20, v25, v32
    s.movz       s40, #5
    vf.add       v24, v0, v20
    v.st.w       [s34, #0], v24
    a.vread      v0, a1, s42
    s.addi       s42, s30, #5696
    v.extract    s44, v29, #5
    v.splat      v20, s44
    v.ld.w       v24, [s33, #0]
    vf.mul       v25, v24, v21
    s.addi       s33, s34, #384
    vf.mul       v21, v25, v32
    s.movz       s44, #6
    vf.add       v24, v0, v21
    v.st.w       [s41, #0], v24
    a.vread      v0, a1, s43
    s.addi       s41, s30, #5760
    v.extract    s43, v29, #6
    v.splat      v21, s43
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v22
    s.addi       s28, s34, #448
    vf.mul       v22, v25, v32
    s.movz       s43, #7
    vf.add       v24, v0, v22
    v.st.w       [s36, #0], v24
    a.vread      v0, a1, s37
    s.addi       s36, s30, #5824
    v.extract    s37, v29, #7
    v.splat      v22, s37
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v23
    s.addi       s29, s34, #512
    vf.mul       v23, v25, v32
    s.movz       s37, #8
    vf.add       v24, v0, v23
    v.st.w       [s31, #0], v24
    a.vread      v0, a1, s39
    s.addi       s31, s30, #5888
    v.extract    s39, v29, #8
    v.splat      v23, s39
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    s.addi       s38, s34, #576
    vf.mul       v19, v25, v32
    s.movz       s39, #9
    vf.add       v24, v0, v19
    v.st.w       [s32, #0], v24
    a.vread      v0, a1, s40
    s.addi       s32, s30, #5952
    v.extract    s40, v29, #9
    v.splat      v19, s40
    v.ld.w       v24, [s42, #0]
    vf.mul       v25, v24, v20
    s.addi       s40, s34, #640
    vf.mul       v20, v25, v32
    s.movz       s42, #10
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a1, s44
    s.addi       s35, s30, #6016
    v.extract    s44, v29, #10
    v.splat      v20, s44
    v.ld.w       v24, [s41, #0]
    vf.mul       v25, v24, v21
    s.addi       s41, s34, #704
    vf.mul       v21, v25, v32
    s.movz       s44, #11
    vf.add       v24, v0, v21
    v.st.w       [s33, #0], v24
    a.vread      v0, a1, s43
    s.addi       s33, s30, #6080
    v.extract    s43, v29, #11
    v.splat      v21, s43
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v22
    s.addi       s36, s34, #768
    vf.mul       v22, v25, v32
    s.movz       s43, #12
    vf.add       v24, v0, v22
    v.st.w       [s28, #0], v24
    a.vread      v0, a1, s37
    s.addi       s28, s30, #6144
    v.extract    s37, v29, #12
    v.splat      v22, s37
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v23
    s.addi       s31, s34, #832
    vf.mul       v23, v25, v32
    s.movz       s37, #13
    vf.add       v24, v0, v23
    v.st.w       [s29, #0], v24
    a.vread      v0, a1, s39
    s.addi       s29, s30, #6208
    v.extract    s39, v29, #13
    v.splat      v23, s39
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v19
    s.addi       s32, s34, #896
    vf.mul       v19, v25, v32
    s.movz       s39, #14
    vf.add       v24, v0, v19
    v.st.w       [s38, #0], v24
    a.vread      v0, a1, s42
    s.addi       s38, s30, #6272
    v.extract    s42, v29, #14
    v.splat      v19, s42
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s34, #960
    vf.mul       v20, v25, v32
    s.movz       s34, #15
    vf.add       v24, v0, v20
    v.st.w       [s40, #0], v24
    a.vread      v0, a1, s44
    s.addi       s40, s30, #6336
    v.extract    s42, v29, #15
    v.splat      v20, s42
    v.ld.w       v24, [s33, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v32
    s.addi       s33, s30, #14592
    vf.add       v24, v0, v21
    s.movz       s42, #0
    v.st.w       [s41, #0], v24
    a.vread      v0, a1, s43
    s.addi       s41, s30, #6400
    v.extract    s43, v29, #0
    v.splat      v21, s43
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v32
    s.addi       s28, s33, #64
    vf.add       v24, v0, v22
    s.movz       s43, #1
    v.st.w       [s36, #0], v24
    a.vread      v0, a1, s37
    s.addi       s36, s30, #6464
    v.extract    s37, v29, #1
    v.splat      v22, s37
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v32
    s.addi       s29, s33, #128
    vf.add       v24, v0, v23
    s.movz       s37, #2
    v.st.w       [s31, #0], v24
    a.vread      v0, a1, s39
    s.addi       s31, s30, #6528
    v.extract    s39, v29, #2
    v.splat      v23, s39
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v32
    s.addi       s38, s33, #192
    vf.add       v24, v0, v19
    s.movz       s39, #3
    v.st.w       [s32, #0], v24
    a.vread      v0, a1, s34
    s.addi       s32, s30, #6592
    v.extract    s34, v29, #3
    v.splat      v19, s34
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v32
    s.addi       s34, s33, #256
    vf.add       v24, v0, v20
    s.movz       s40, #4
    v.st.w       [s35, #0], v24
    fence.acq_rel.device
    a.vread      v0, a2, s42
    s.addi       s35, s30, #6656
    v.extract    s42, v29, #4
    v.splat      v20, s42
    v.ld.w       v24, [s41, #0]
    vf.mul       v25, v24, v21
    s.addi       s41, s33, #320
    vf.mul       v21, v25, v33
    s.movz       s42, #5
    vf.add       v24, v0, v21
    v.st.w       [s33, #0], v24
    a.vread      v0, a2, s43
    s.addi       s43, s30, #6720
    v.extract    s44, v29, #5
    v.splat      v21, s44
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v22
    s.addi       s36, s33, #384
    vf.mul       v22, v25, v33
    s.movz       s44, #6
    vf.add       v24, v0, v22
    v.st.w       [s28, #0], v24
    a.vread      v0, a2, s37
    s.addi       s28, s30, #6784
    v.extract    s37, v29, #6
    v.splat      v22, s37
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v23
    s.addi       s31, s33, #448
    vf.mul       v23, v25, v33
    s.movz       s37, #7
    vf.add       v24, v0, v23
    v.st.w       [s29, #0], v24
    a.vread      v0, a2, s39
    s.addi       s29, s30, #6848
    v.extract    s39, v29, #7
    v.splat      v23, s39
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v19
    s.addi       s32, s33, #512
    vf.mul       v19, v25, v33
    s.movz       s39, #8
    vf.add       v24, v0, v19
    v.st.w       [s38, #0], v24
    a.vread      v0, a2, s40
    s.addi       s38, s30, #6912
    v.extract    s40, v29, #8
    v.splat      v19, s40
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s33, #576
    vf.mul       v20, v25, v33
    s.movz       s40, #9
    vf.add       v24, v0, v20
    v.st.w       [s34, #0], v24
    a.vread      v0, a2, s42
    s.addi       s34, s30, #6976
    v.extract    s42, v29, #9
    v.splat      v20, s42
    v.ld.w       v24, [s43, #0]
    vf.mul       v25, v24, v21
    s.addi       s42, s33, #640
    vf.mul       v21, v25, v33
    s.movz       s43, #10
    vf.add       v24, v0, v21
    v.st.w       [s41, #0], v24
    a.vread      v0, a2, s44
    s.addi       s41, s30, #7040
    v.extract    s44, v29, #10
    v.splat      v21, s44
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v22
    s.addi       s28, s33, #704
    vf.mul       v22, v25, v33
    s.movz       s44, #11
    vf.add       v24, v0, v22
    v.st.w       [s36, #0], v24
    a.vread      v0, a2, s37
    s.addi       s36, s30, #7104
    v.extract    s37, v29, #11
    v.splat      v22, s37
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v23
    s.addi       s29, s33, #768
    vf.mul       v23, v25, v33
    s.movz       s37, #12
    vf.add       v24, v0, v23
    v.st.w       [s31, #0], v24
    a.vread      v0, a2, s39
    s.addi       s31, s30, #7168
    v.extract    s39, v29, #12
    v.splat      v23, s39
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    s.addi       s38, s33, #832
    vf.mul       v19, v25, v33
    s.movz       s39, #13
    vf.add       v24, v0, v19
    v.st.w       [s32, #0], v24
    a.vread      v0, a2, s40
    s.addi       s32, s30, #7232
    v.extract    s40, v29, #13
    v.splat      v19, s40
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v20
    s.addi       s34, s33, #896
    vf.mul       v20, v25, v33
    s.movz       s40, #14
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a2, s43
    s.addi       s35, s30, #7296
    v.extract    s43, v29, #14
    v.splat      v20, s43
    v.ld.w       v24, [s41, #0]
    vf.mul       v25, v24, v21
    s.addi       s41, s33, #960
    vf.mul       v21, v25, v33
    s.movz       s33, #15
    vf.add       v24, v0, v21
    v.st.w       [s42, #0], v24
    a.vread      v0, a2, s44
    s.addi       s42, s30, #7360
    v.extract    s43, v29, #15
    v.splat      v21, s43
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v33
    s.addi       s36, s30, #15616
    vf.add       v24, v0, v22
    s.movz       s43, #0
    v.st.w       [s28, #0], v24
    a.vread      v0, a2, s37
    s.addi       s28, s30, #7424
    v.extract    s37, v29, #0
    v.splat      v22, s37
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v33
    s.addi       s31, s36, #64
    vf.add       v24, v0, v23
    s.movz       s37, #1
    v.st.w       [s29, #0], v24
    a.vread      v0, a2, s39
    s.addi       s29, s30, #7488
    v.extract    s39, v29, #1
    v.splat      v23, s39
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v33
    s.addi       s32, s36, #128
    vf.add       v24, v0, v19
    s.movz       s39, #2
    v.st.w       [s38, #0], v24
    a.vread      v0, a2, s40
    s.addi       s38, s30, #7552
    v.extract    s40, v29, #2
    v.splat      v19, s40
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v33
    s.addi       s35, s36, #192
    vf.add       v24, v0, v20
    s.movz       s40, #3
    v.st.w       [s34, #0], v24
    a.vread      v0, a2, s33
    s.addi       s33, s30, #7616
    v.extract    s34, v29, #3
    v.splat      v20, s34
    v.ld.w       v24, [s42, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v33
    s.addi       s34, s36, #256
    vf.add       v24, v0, v21
    s.movz       s42, #4
    v.st.w       [s41, #0], v24
    fence.acq_rel.device
    a.vread      v0, a3, s43
    s.addi       s41, s30, #7680
    v.extract    s43, v29, #4
    v.splat      v21, s43
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v22
    s.addi       s28, s36, #320
    vf.mul       v22, v25, v34
    s.movz       s43, #5
    vf.add       v24, v0, v22
    v.st.w       [s36, #0], v24
    a.vread      v0, a3, s37
    s.addi       s37, s30, #7744
    v.extract    s44, v29, #5
    v.splat      v22, s44
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v23
    s.addi       s29, s36, #384
    vf.mul       v23, v25, v34
    s.movz       s44, #6
    vf.add       v24, v0, v23
    v.st.w       [s31, #0], v24
    a.vread      v0, a3, s39
    s.addi       s31, s30, #7808
    v.extract    s39, v29, #6
    v.splat      v23, s39
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    s.addi       s38, s36, #448
    vf.mul       v19, v25, v34
    s.movz       s39, #7
    vf.add       v24, v0, v19
    v.st.w       [s32, #0], v24
    a.vread      v0, a3, s40
    s.addi       s32, s30, #7872
    v.extract    s40, v29, #7
    v.splat      v19, s40
    v.ld.w       v24, [s33, #0]
    vf.mul       v25, v24, v20
    s.addi       s33, s36, #512
    vf.mul       v20, v25, v34
    s.movz       s40, #8
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a3, s42
    s.addi       s35, s30, #7936
    v.extract    s42, v29, #8
    v.splat      v20, s42
    v.ld.w       v24, [s41, #0]
    vf.mul       v25, v24, v21
    s.addi       s41, s36, #576
    vf.mul       v21, v25, v34
    s.movz       s42, #9
    vf.add       v24, v0, v21
    v.st.w       [s34, #0], v24
    a.vread      v0, a3, s43
    s.addi       s34, s30, #8000
    v.extract    s43, v29, #9
    v.splat      v21, s43
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    s.addi       s37, s36, #640
    vf.mul       v22, v25, v34
    s.movz       s43, #10
    vf.add       v24, v0, v22
    v.st.w       [s28, #0], v24
    a.vread      v0, a3, s44
    s.addi       s28, s30, #8064
    v.extract    s44, v29, #10
    v.splat      v22, s44
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v23
    s.addi       s31, s36, #704
    vf.mul       v23, v25, v34
    s.movz       s44, #11
    vf.add       v24, v0, v23
    v.st.w       [s29, #0], v24
    a.vread      v0, a3, s39
    s.addi       s29, s30, #8128
    v.extract    s39, v29, #11
    v.splat      v23, s39
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v19
    s.addi       s32, s36, #768
    vf.mul       v19, v25, v34
    s.movz       s39, #12
    vf.add       v24, v0, v19
    v.st.w       [s38, #0], v24
    a.vread      v0, a3, s40
    s.addi       s38, s30, #8192
    v.extract    s40, v29, #12
    v.splat      v19, s40
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s36, #832
    vf.mul       v20, v25, v34
    s.movz       s40, #13
    vf.add       v24, v0, v20
    v.st.w       [s33, #0], v24
    a.vread      v0, a3, s42
    s.addi       s33, s30, #8256
    v.extract    s42, v29, #13
    v.splat      v20, s42
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v21
    s.addi       s34, s36, #896
    vf.mul       v21, v25, v34
    s.movz       s42, #14
    vf.add       v24, v0, v21
    v.st.w       [s41, #0], v24
    a.vread      v0, a3, s43
    s.addi       s41, s30, #8320
    v.extract    s43, v29, #14
    v.splat      v21, s43
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v22
    s.addi       s28, s36, #960
    vf.mul       v22, v25, v34
    s.movz       s36, #15
    vf.add       v24, v0, v22
    v.st.w       [s37, #0], v24
    a.vread      v0, a3, s44
    s.addi       s37, s30, #8384
    v.extract    s43, v29, #15
    v.splat      v22, s43
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v34
    s.addi       s29, s30, #16640
    vf.add       v24, v0, v23
    s.movz       s43, #0
    v.st.w       [s31, #0], v24
    a.vread      v0, a3, s39
    s.addi       s31, s30, #8448
    v.extract    s39, v29, #0
    v.splat      v23, s39
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v34
    s.addi       s38, s29, #64
    vf.add       v24, v0, v19
    s.movz       s39, #1
    v.st.w       [s32, #0], v24
    a.vread      v0, a3, s40
    s.addi       s32, s30, #8512
    v.extract    s40, v29, #1
    v.splat      v19, s40
    v.ld.w       v24, [s33, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v34
    s.addi       s33, s29, #128
    vf.add       v24, v0, v20
    s.movz       s40, #2
    v.st.w       [s35, #0], v24
    a.vread      v0, a3, s42
    s.addi       s35, s30, #8576
    v.extract    s42, v29, #2
    v.splat      v20, s42
    v.ld.w       v24, [s41, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v34
    s.addi       s41, s29, #192
    vf.add       v24, v0, v21
    s.movz       s42, #3
    v.st.w       [s34, #0], v24
    a.vread      v0, a3, s36
    s.addi       s34, s30, #8640
    v.extract    s36, v29, #3
    v.splat      v21, s36
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v34
    s.addi       s36, s29, #256
    vf.add       v24, v0, v22
    s.movz       s37, #4
    v.st.w       [s28, #0], v24
    fence.acq_rel.device
    a.vread      v0, a4, s43
    s.addi       s28, s30, #8704
    v.extract    s43, v29, #4
    v.splat      v22, s43
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v23
    s.addi       s31, s29, #320
    vf.mul       v23, v25, v35
    s.movz       s43, #5
    vf.add       v24, v0, v23
    v.st.w       [s29, #0], v24
    a.vread      v0, a4, s39
    s.addi       s39, s30, #8768
    v.extract    s44, v29, #5
    v.splat      v23, s44
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v19
    s.addi       s32, s29, #384
    vf.mul       v19, v25, v35
    s.movz       s44, #6
    vf.add       v24, v0, v19
    v.st.w       [s38, #0], v24
    a.vread      v0, a4, s40
    s.addi       s38, s30, #8832
    v.extract    s40, v29, #6
    v.splat      v19, s40
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s29, #448
    vf.mul       v20, v25, v35
    s.movz       s40, #7
    vf.add       v24, v0, v20
    v.st.w       [s33, #0], v24
    a.vread      v0, a4, s42
    s.addi       s33, s30, #8896
    v.extract    s42, v29, #7
    v.splat      v20, s42
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v21
    s.addi       s34, s29, #512
    vf.mul       v21, v25, v35
    s.movz       s42, #8
    vf.add       v24, v0, v21
    v.st.w       [s41, #0], v24
    a.vread      v0, a4, s37
    s.addi       s37, s30, #8960
    v.extract    s41, v29, #8
    v.splat      v21, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v22
    s.addi       s28, s29, #576
    vf.mul       v22, v25, v35
    s.movz       s41, #9
    vf.add       v24, v0, v22
    v.st.w       [s36, #0], v24
    a.vread      v0, a4, s43
    s.addi       s36, s30, #9024
    v.extract    s43, v29, #9
    v.splat      v22, s43
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v23
    s.addi       s39, s29, #640
    vf.mul       v23, v25, v35
    s.movz       s43, #10
    vf.add       v24, v0, v23
    v.st.w       [s31, #0], v24
    a.vread      v0, a4, s44
    s.addi       s31, s30, #9088
    v.extract    s44, v29, #10
    v.splat      v23, s44
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    s.addi       s38, s29, #704
    vf.mul       v19, v25, v35
    s.movz       s44, #11
    vf.add       v24, v0, v19
    v.st.w       [s32, #0], v24
    a.vread      v0, a4, s40
    s.addi       s32, s30, #9152
    v.extract    s40, v29, #11
    v.splat      v19, s40
    v.ld.w       v24, [s33, #0]
    vf.mul       v25, v24, v20
    s.addi       s33, s29, #768
    vf.mul       v20, v25, v35
    s.movz       s40, #12
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a4, s42
    s.addi       s35, s30, #9216
    v.extract    s42, v29, #12
    v.splat      v20, s42
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v21
    s.addi       s37, s29, #832
    vf.mul       v21, v25, v35
    s.movz       s42, #13
    vf.add       v24, v0, v21
    v.st.w       [s34, #0], v24
    a.vread      v0, a4, s41
    s.addi       s34, s30, #9280
    v.extract    s41, v29, #13
    v.splat      v21, s41
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v22
    s.addi       s36, s29, #896
    vf.mul       v22, v25, v35
    s.movz       s41, #14
    vf.add       v24, v0, v22
    v.st.w       [s28, #0], v24
    a.vread      v0, a4, s43
    s.addi       s28, s30, #9344
    v.extract    s43, v29, #14
    v.splat      v22, s43
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v23
    s.addi       s31, s29, #960
    vf.mul       v23, v25, v35
    s.movz       s29, #15
    vf.add       v24, v0, v23
    v.st.w       [s39, #0], v24
    a.vread      v0, a4, s44
    s.addi       s39, s30, #9408
    v.extract    s43, v29, #15
    v.splat      v23, s43
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v35
    s.addi       s32, s30, #17664
    vf.add       v24, v0, v19
    s.movz       s43, #0
    v.st.w       [s38, #0], v24
    a.vread      v0, a4, s40
    s.addi       s38, s30, #9472
    v.extract    s40, v29, #0
    v.splat      v19, s40
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v35
    s.addi       s35, s32, #64
    vf.add       v24, v0, v20
    s.movz       s40, #1
    v.st.w       [s33, #0], v24
    a.vread      v0, a4, s42
    s.addi       s33, s30, #9536
    v.extract    s42, v29, #1
    v.splat      v20, s42
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v35
    s.addi       s34, s32, #128
    vf.add       v24, v0, v21
    s.movz       s42, #2
    v.st.w       [s37, #0], v24
    a.vread      v0, a4, s41
    s.addi       s37, s30, #9600
    v.extract    s41, v29, #2
    v.splat      v21, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v35
    s.addi       s28, s32, #192
    vf.add       v24, v0, v22
    s.movz       s41, #3
    v.st.w       [s36, #0], v24
    a.vread      v0, a4, s29
    s.addi       s29, s30, #9664
    v.extract    s36, v29, #3
    v.splat      v22, s36
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v35
    s.addi       s36, s32, #256
    vf.add       v24, v0, v23
    s.movz       s39, #4
    v.st.w       [s31, #0], v24
    fence.acq_rel.device
    a.vread      v0, a5, s43
    s.addi       s31, s30, #9728
    v.extract    s43, v29, #4
    v.splat      v23, s43
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    s.addi       s38, s32, #320
    vf.mul       v19, v25, v36
    s.movz       s43, #5
    vf.add       v24, v0, v19
    v.st.w       [s32, #0], v24
    a.vread      v0, a5, s40
    s.addi       s40, s30, #9792
    v.extract    s44, v29, #5
    v.splat      v19, s44
    v.ld.w       v24, [s33, #0]
    vf.mul       v25, v24, v20
    s.addi       s33, s32, #384
    vf.mul       v20, v25, v36
    s.movz       s44, #6
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a5, s42
    s.addi       s35, s30, #9856
    v.extract    s42, v29, #6
    v.splat      v20, s42
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v21
    s.addi       s37, s32, #448
    vf.mul       v21, v25, v36
    s.movz       s42, #7
    vf.add       v24, v0, v21
    v.st.w       [s34, #0], v24
    a.vread      v0, a5, s41
    s.addi       s34, s30, #9920
    v.extract    s41, v29, #7
    v.splat      v21, s41
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v22
    s.addi       s29, s32, #512
    vf.mul       v22, v25, v36
    s.movz       s41, #8
    vf.add       v24, v0, v22
    v.st.w       [s28, #0], v24
    a.vread      v0, a5, s39
    s.addi       s28, s30, #9984
    v.extract    s39, v29, #8
    v.splat      v22, s39
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v23
    s.addi       s31, s32, #576
    vf.mul       v23, v25, v36
    s.movz       s39, #9
    vf.add       v24, v0, v23
    v.st.w       [s36, #0], v24
    a.vread      v0, a5, s43
    s.addi       s36, s30, #10048
    v.extract    s43, v29, #9
    v.splat      v23, s43
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    s.addi       s40, s32, #640
    vf.mul       v19, v25, v36
    s.movz       s43, #10
    vf.add       v24, v0, v19
    v.st.w       [s38, #0], v24
    a.vread      v0, a5, s44
    s.addi       s38, s30, #10112
    v.extract    s44, v29, #10
    v.splat      v19, s44
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s32, #704
    vf.mul       v20, v25, v36
    s.movz       s44, #11
    vf.add       v24, v0, v20
    v.st.w       [s33, #0], v24
    a.vread      v0, a5, s42
    s.addi       s33, s30, #10176
    v.extract    s42, v29, #11
    v.splat      v20, s42
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v21
    s.addi       s34, s32, #768
    vf.mul       v21, v25, v36
    s.movz       s42, #12
    vf.add       v24, v0, v21
    v.st.w       [s37, #0], v24
    a.vread      v0, a5, s41
    s.addi       s37, s30, #10240
    v.extract    s41, v29, #12
    v.splat      v21, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v22
    s.addi       s28, s32, #832
    vf.mul       v22, v25, v36
    s.movz       s41, #13
    vf.add       v24, v0, v22
    v.st.w       [s29, #0], v24
    a.vread      v0, a5, s39
    s.addi       s29, s30, #10304
    v.extract    s39, v29, #13
    v.splat      v22, s39
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v23
    s.addi       s36, s32, #896
    vf.mul       v23, v25, v36
    s.movz       s39, #14
    vf.add       v24, v0, v23
    v.st.w       [s31, #0], v24
    a.vread      v0, a5, s43
    s.addi       s31, s30, #10368
    v.extract    s43, v29, #14
    v.splat      v23, s43
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    s.addi       s38, s32, #960
    vf.mul       v19, v25, v36
    s.movz       s32, #15
    vf.add       v24, v0, v19
    v.st.w       [s40, #0], v24
    a.vread      v0, a5, s44
    s.addi       s40, s30, #10432
    v.extract    s43, v29, #15
    v.splat      v19, s43
    v.ld.w       v24, [s33, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v36
    s.addi       s33, s30, #18688
    vf.add       v24, v0, v20
    s.movz       s43, #0
    v.st.w       [s35, #0], v24
    a.vread      v0, a5, s42
    s.addi       s35, s30, #10496
    v.extract    s42, v29, #0
    v.splat      v20, s42
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v36
    s.addi       s37, s33, #64
    vf.add       v24, v0, v21
    s.movz       s42, #1
    v.st.w       [s34, #0], v24
    a.vread      v0, a5, s41
    s.addi       s34, s30, #10560
    v.extract    s41, v29, #1
    v.splat      v21, s41
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v36
    s.addi       s29, s33, #128
    vf.add       v24, v0, v22
    s.movz       s41, #2
    v.st.w       [s28, #0], v24
    a.vread      v0, a5, s39
    s.addi       s28, s30, #10624
    v.extract    s39, v29, #2
    v.splat      v22, s39
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v36
    s.addi       s31, s33, #192
    vf.add       v24, v0, v23
    s.movz       s39, #3
    v.st.w       [s36, #0], v24
    a.vread      v0, a5, s32
    s.addi       s32, s30, #10688
    v.extract    s36, v29, #3
    v.splat      v23, s36
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v36
    s.addi       s36, s33, #256
    vf.add       v24, v0, v19
    s.movz       s40, #4
    v.st.w       [s38, #0], v24
    fence.acq_rel.device
    a.vread      v0, a6, s43
    s.addi       s38, s30, #10752
    v.extract    s43, v29, #4
    v.splat      v19, s43
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s33, #320
    vf.mul       v20, v25, v37
    s.movz       s43, #5
    vf.add       v24, v0, v20
    v.st.w       [s33, #0], v24
    a.vread      v0, a6, s42
    s.addi       s42, s30, #10816
    v.extract    s44, v29, #5
    v.splat      v20, s44
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v21
    s.addi       s34, s33, #384
    vf.mul       v21, v25, v37
    s.movz       s44, #6
    vf.add       v24, v0, v21
    v.st.w       [s37, #0], v24
    a.vread      v0, a6, s41
    s.addi       s37, s30, #10880
    v.extract    s41, v29, #6
    v.splat      v21, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v22
    s.addi       s28, s33, #448
    vf.mul       v22, v25, v37
    s.movz       s41, #7
    vf.add       v24, v0, v22
    v.st.w       [s29, #0], v24
    a.vread      v0, a6, s39
    s.addi       s29, s30, #10944
    v.extract    s39, v29, #7
    v.splat      v22, s39
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v23
    s.addi       s32, s33, #512
    vf.mul       v23, v25, v37
    s.movz       s39, #8
    vf.add       v24, v0, v23
    v.st.w       [s31, #0], v24
    a.vread      v0, a6, s40
    s.addi       s31, s30, #11008
    v.extract    s40, v29, #8
    v.splat      v23, s40
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    s.addi       s38, s33, #576
    vf.mul       v19, v25, v37
    s.movz       s40, #9
    vf.add       v24, v0, v19
    v.st.w       [s36, #0], v24
    a.vread      v0, a6, s43
    s.addi       s36, s30, #11072
    v.extract    s43, v29, #9
    v.splat      v19, s43
    v.ld.w       v24, [s42, #0]
    vf.mul       v25, v24, v20
    s.addi       s42, s33, #640
    vf.mul       v20, v25, v37
    s.movz       s43, #10
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a6, s44
    s.addi       s35, s30, #11136
    v.extract    s44, v29, #10
    v.splat      v20, s44
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v21
    s.addi       s37, s33, #704
    vf.mul       v21, v25, v37
    s.movz       s44, #11
    vf.add       v24, v0, v21
    v.st.w       [s34, #0], v24
    a.vread      v0, a6, s41
    s.addi       s34, s30, #11200
    v.extract    s41, v29, #11
    v.splat      v21, s41
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v22
    s.addi       s29, s33, #768
    vf.mul       v22, v25, v37
    s.movz       s41, #12
    vf.add       v24, v0, v22
    v.st.w       [s28, #0], v24
    a.vread      v0, a6, s39
    s.addi       s28, s30, #11264
    v.extract    s39, v29, #12
    v.splat      v22, s39
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v23
    s.addi       s31, s33, #832
    vf.mul       v23, v25, v37
    s.movz       s39, #13
    vf.add       v24, v0, v23
    v.st.w       [s32, #0], v24
    a.vread      v0, a6, s40
    s.addi       s32, s30, #11328
    v.extract    s40, v29, #13
    v.splat      v23, s40
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v19
    s.addi       s36, s33, #896
    vf.mul       v19, v25, v37
    s.movz       s40, #14
    vf.add       v24, v0, v19
    v.st.w       [s38, #0], v24
    a.vread      v0, a6, s43
    s.addi       s38, s30, #11392
    v.extract    s43, v29, #14
    v.splat      v19, s43
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s33, #960
    vf.mul       v20, v25, v37
    s.movz       s33, #15
    vf.add       v24, v0, v20
    v.st.w       [s42, #0], v24
    a.vread      v0, a6, s44
    s.addi       s42, s30, #11456
    v.extract    s43, v29, #15
    v.splat      v20, s43
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v37
    s.addi       s34, s30, #19712
    vf.add       v24, v0, v21
    s.movz       s43, #0
    v.st.w       [s37, #0], v24
    a.vread      v0, a6, s41
    s.addi       s37, s30, #11520
    v.extract    s41, v29, #0
    v.splat      v21, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v37
    s.addi       s28, s34, #64
    vf.add       v24, v0, v22
    s.movz       s41, #1
    v.st.w       [s29, #0], v24
    a.vread      v0, a6, s39
    s.addi       s29, s30, #11584
    v.extract    s39, v29, #1
    v.splat      v22, s39
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v37
    s.addi       s32, s34, #128
    vf.add       v24, v0, v23
    s.movz       s39, #2
    v.st.w       [s31, #0], v24
    a.vread      v0, a6, s40
    s.addi       s31, s30, #11648
    v.extract    s40, v29, #2
    v.splat      v23, s40
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v37
    s.addi       s38, s34, #192
    vf.add       v24, v0, v19
    s.movz       s40, #3
    v.st.w       [s36, #0], v24
    a.vread      v0, a6, s33
    s.addi       s33, s30, #11712
    v.extract    s36, v29, #3
    v.splat      v19, s36
    v.ld.w       v24, [s42, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v37
    s.addi       s36, s34, #256
    vf.add       v24, v0, v20
    s.movz       s42, #4
    v.st.w       [s35, #0], v24
    fence.acq_rel.device
    a.vread      v0, a7, s43
    s.addi       s35, s30, #11776
    v.extract    s43, v29, #4
    v.splat      v20, s43
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v21
    s.addi       s37, s34, #320
    vf.mul       v21, v25, v38
    s.movz       s43, #5
    vf.add       v24, v0, v21
    v.st.w       [s34, #0], v24
    a.vread      v0, a7, s41
    s.addi       s41, s30, #11840
    v.extract    s44, v29, #5
    v.splat      v21, s44
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v22
    s.addi       s29, s34, #384
    vf.mul       v22, v25, v38
    s.movz       s44, #6
    vf.add       v24, v0, v22
    v.st.w       [s28, #0], v24
    a.vread      v0, a7, s39
    s.addi       s28, s30, #11904
    v.extract    s39, v29, #6
    v.splat      v22, s39
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v23
    s.addi       s31, s34, #448
    vf.mul       v23, v25, v38
    s.movz       s39, #7
    vf.add       v24, v0, v23
    v.st.w       [s32, #0], v24
    a.vread      v0, a7, s40
    s.addi       s32, s30, #11968
    v.extract    s40, v29, #7
    v.splat      v23, s40
    v.ld.w       v24, [s33, #0]
    vf.mul       v25, v24, v19
    s.addi       s33, s34, #512
    vf.mul       v19, v25, v38
    s.movz       s40, #8
    vf.add       v24, v0, v19
    v.st.w       [s38, #0], v24
    a.vread      v0, a7, s42
    s.addi       s38, s30, #12032
    v.extract    s42, v29, #8
    v.splat      v19, s42
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s34, #576
    vf.mul       v20, v25, v38
    s.movz       s42, #9
    vf.add       v24, v0, v20
    v.st.w       [s36, #0], v24
    a.vread      v0, a7, s43
    s.addi       s36, s30, #12096
    v.extract    s43, v29, #9
    v.splat      v20, s43
    v.ld.w       v24, [s41, #0]
    vf.mul       v25, v24, v21
    s.addi       s41, s34, #640
    vf.mul       v21, v25, v38
    s.movz       s43, #10
    vf.add       v24, v0, v21
    v.st.w       [s37, #0], v24
    a.vread      v0, a7, s44
    s.addi       s37, s30, #12160
    v.extract    s44, v29, #10
    v.splat      v21, s44
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v22
    s.addi       s28, s34, #704
    vf.mul       v22, v25, v38
    s.movz       s44, #11
    vf.add       v24, v0, v22
    v.st.w       [s29, #0], v24
    a.vread      v0, a7, s39
    s.addi       s29, s30, #12224
    v.extract    s39, v29, #11
    v.splat      v22, s39
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v23
    s.addi       s32, s34, #768
    vf.mul       v23, v25, v38
    s.movz       s39, #12
    vf.add       v24, v0, v23
    v.st.w       [s31, #0], v24
    a.vread      v0, a7, s40
    s.addi       s31, s30, #12288
    v.extract    s40, v29, #12
    v.splat      v23, s40
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    s.addi       s38, s34, #832
    vf.mul       v19, v25, v38
    s.movz       s40, #13
    vf.add       v24, v0, v19
    v.st.w       [s33, #0], v24
    a.vread      v0, a7, s42
    s.addi       s33, s30, #12352
    v.extract    s42, v29, #13
    v.splat      v19, s42
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v20
    s.addi       s36, s34, #896
    vf.mul       v20, v25, v38
    s.movz       s42, #14
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a7, s43
    s.addi       s35, s30, #12416
    v.extract    s43, v29, #14
    v.splat      v20, s43
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v21
    s.addi       s37, s34, #960
    vf.mul       v21, v25, v38
    s.movz       s34, #15
    vf.add       v24, v0, v21
    v.st.w       [s41, #0], v24
    a.vread      v0, a7, s44
    s.addi       s41, s30, #12480
    v.extract    s43, v29, #15
    v.splat      v21, s43
    v.ld.w       v24, [s29, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v38
    s.addi       s29, s26, #128
    vf.add       v24, v0, v22
    s.addi       s43, s29, #0
    v.st.w       [s28, #0], v24
    a.vread      v0, a7, s39
    s.addi       s28, s27, #128
    s.movz       s29, #0
    s.addi       s39, s28, #0
    v.ld.w       v22, [s31, #0]
    s.addi       s28, s30, #12544
    vf.mul       v24, v22, v23
    s.movz       s31, #1
    vf.mul       v22, v24, v38
    s.addi       s44, s30, #12608
    vf.add       v23, v0, v22
    v.st.w       [s32, #0], v23
    a.vread      v0, a7, s40
    s.addi       s32, s30, #12672
    s.movz       s40, #2
    v.ld.w       v22, [s33, #0]
    s.addi       s33, s30, #12736
    s.movz       s45, #3
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v38
    s.movz       s46, #4
    vf.add       v22, v0, v19
    s.addi       s47, s30, #12800
    v.st.w       [s38, #0], v22
    a.vread      v0, a7, s42
    s.addi       s38, s30, #12864
    s.movz       s42, #5
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s30, #12928
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v38
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    a.vread      v0, a7, s34
    s.movz       s34, #6
    s.addi       s36, s30, #12992
    v.ld.w       v19, [s41, #0]
    s.movz       s41, #7
    vf.mul       v20, v19, v21
    vf.mul       v19, v20, v38
    vf.add       v20, v0, v19
    v.st.w       [s37, #0], v20
    fence.acq_rel.device
    s.mov        s26, s43
    s.mov        s27, s39
    s.addi       s37, s30, #13056
    s.movz       s39, #8
    s.addi       s43, s30, #13120
    s.movz       s48, #9
    s.addi       s49, s30, #13184
    v.ld.w       v0, [s28, #0]
    s.movz       s28, #10
    a.vwrite     a0, s29, v0
    v.ld.w       v0, [s44, #0]
    s.addi       s44, s30, #13248
    a.vwrite     a0, s31, v0
    v.ld.w       v0, [s32, #0]
    s.movz       s32, #11
    a.vwrite     a0, s40, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s30, #13312
    a.vwrite     a0, s45, v0
    v.ld.w       v0, [s47, #0]
    s.movz       s47, #12
    a.vwrite     a0, s46, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #13376
    a.vwrite     a0, s42, v0
    v.ld.w       v0, [s35, #0]
    s.movz       s35, #13
    a.vwrite     a0, s34, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s30, #13440
    a.vwrite     a0, s41, v0
    v.ld.w       v0, [s37, #0]
    s.movz       s37, #14
    a.vwrite     a0, s39, v0
    v.ld.w       v0, [s43, #0]
    s.addi       s43, s30, #13504
    a.vwrite     a0, s48, v0
    v.ld.w       v0, [s49, #0]
    s.movz       s49, #15
    a.vwrite     a0, s28, v0
    v.ld.w       v0, [s44, #0]
    s.addi       s44, s30, #13568
    a.vwrite     a0, s32, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s30, #13632
    a.vwrite     a0, s47, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #13696
    a.vwrite     a0, s35, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s30, #13760
    a.vwrite     a0, s37, v0
    v.ld.w       v0, [s43, #0]
    s.addi       s43, s30, #13824
    a.vwrite     a0, s49, v0
    v.ld.w       v0, [s44, #0]
    s.addi       s44, s30, #13888
    a.vwrite     a1, s29, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s29, s30, #13952
    s.addi       s33, s30, #14016
    a.vwrite     a1, s31, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s31, s30, #14080
    s.addi       s38, s30, #14144
    a.vwrite     a1, s40, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s30, #14208
    s.addi       s40, s30, #14272
    a.vwrite     a1, s45, v0
    v.ld.w       v0, [s43, #0]
    s.addi       s43, s30, #14336
    s.addi       s45, s30, #14400
    a.vwrite     a1, s46, v0
    v.ld.w       v0, [s44, #0]
    s.addi       s44, s30, #14464
    s.addi       s46, s30, #14528
    a.vwrite     a1, s42, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s30, #14592
    s.movz       s42, #0
    a.vwrite     a1, s34, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s30, #14656
    s.movz       s34, #1
    a.vwrite     a1, s41, v0
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s30, #14720
    s.movz       s41, #2
    a.vwrite     a1, s39, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #14784
    s.movz       s39, #3
    a.vwrite     a1, s48, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s30, #14848
    s.movz       s48, #4
    a.vwrite     a1, s28, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s28, s30, #14912
    s.movz       s40, #5
    a.vwrite     a1, s32, v0
    v.ld.w       v0, [s43, #0]
    s.addi       s32, s30, #14976
    s.movz       s43, #6
    a.vwrite     a1, s47, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s30, #15040
    s.movz       s47, #7
    a.vwrite     a1, s35, v0
    v.ld.w       v0, [s44, #0]
    s.addi       s35, s30, #15104
    s.movz       s44, #8
    a.vwrite     a1, s37, v0
    v.ld.w       v0, [s46, #0]
    s.addi       s37, s30, #15168
    s.movz       s46, #9
    a.vwrite     a1, s49, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s30, #15232
    s.movz       s49, #10
    a.vwrite     a2, s42, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s30, #15296
    a.vwrite     a2, s34, v0
    v.ld.w       v0, [s31, #0]
    s.movz       s31, #11
    a.vwrite     a2, s41, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #15360
    a.vwrite     a2, s39, v0
    v.ld.w       v0, [s36, #0]
    s.movz       s36, #12
    a.vwrite     a2, s48, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s30, #15424
    a.vwrite     a2, s40, v0
    v.ld.w       v0, [s32, #0]
    s.movz       s32, #13
    a.vwrite     a2, s43, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s30, #15488
    a.vwrite     a2, s47, v0
    v.ld.w       v0, [s35, #0]
    s.movz       s35, #14
    a.vwrite     a2, s44, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s30, #15552
    a.vwrite     a2, s46, v0
    v.ld.w       v0, [s29, #0]
    s.movz       s29, #15
    a.vwrite     a2, s49, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s30, #15616
    a.vwrite     a2, s31, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #15680
    a.vwrite     a2, s36, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s30, #15744
    a.vwrite     a2, s32, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s30, #15808
    a.vwrite     a2, s35, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s30, #15872
    a.vwrite     a2, s29, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s30, #15936
    a.vwrite     a3, s42, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #16000
    s.addi       s42, s30, #16064
    a.vwrite     a3, s34, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s30, #16128
    s.addi       s34, s30, #16192
    a.vwrite     a3, s41, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s41, s30, #16256
    s.addi       s45, s30, #16320
    a.vwrite     a3, s39, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s30, #16384
    s.addi       s39, s30, #16448
    a.vwrite     a3, s48, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s30, #16512
    s.addi       s48, s30, #16576
    a.vwrite     a3, s40, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #16640
    s.movz       s40, #0
    a.vwrite     a3, s43, v0
    v.ld.w       v0, [s42, #0]
    s.addi       s42, s30, #16704
    s.movz       s43, #1
    a.vwrite     a3, s47, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s30, #16768
    s.movz       s47, #2
    a.vwrite     a3, s44, v0
    v.ld.w       v0, [s34, #0]
    s.addi       s34, s30, #16832
    s.movz       s44, #3
    a.vwrite     a3, s46, v0
    v.ld.w       v0, [s41, #0]
    s.addi       s41, s30, #16896
    s.movz       s46, #4
    a.vwrite     a3, s49, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s30, #16960
    s.movz       s49, #5
    a.vwrite     a3, s31, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s31, s30, #17024
    s.movz       s37, #6
    a.vwrite     a3, s36, v0
    v.ld.w       v0, [s39, #0]
    s.addi       s36, s30, #17088
    s.movz       s39, #7
    a.vwrite     a3, s32, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s32, s30, #17152
    s.movz       s33, #8
    a.vwrite     a3, s35, v0
    v.ld.w       v0, [s48, #0]
    s.addi       s35, s30, #17216
    s.movz       s48, #9
    a.vwrite     a3, s29, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s29, s30, #17280
    s.movz       s38, #10
    a.vwrite     a4, s40, v0
    v.ld.w       v0, [s42, #0]
    s.addi       s42, s30, #17344
    a.vwrite     a4, s43, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s28, #11
    a.vwrite     a4, s47, v0
    v.ld.w       v0, [s34, #0]
    s.addi       s34, s30, #17408
    a.vwrite     a4, s44, v0
    v.ld.w       v0, [s41, #0]
    s.movz       s41, #12
    a.vwrite     a4, s46, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s30, #17472
    a.vwrite     a4, s49, v0
    v.ld.w       v0, [s31, #0]
    s.movz       s31, #13
    a.vwrite     a4, s37, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s30, #17536
    a.vwrite     a4, s39, v0
    v.ld.w       v0, [s32, #0]
    s.movz       s32, #14
    a.vwrite     a4, s33, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s35, s30, #17600
    a.vwrite     a4, s48, v0
    v.ld.w       v0, [s29, #0]
    s.movz       s29, #15
    a.vwrite     a4, s38, v0
    v.ld.w       v0, [s42, #0]
    s.addi       s42, s30, #17664
    a.vwrite     a4, s28, v0
    v.ld.w       v0, [s34, #0]
    s.addi       s34, s30, #17728
    a.vwrite     a4, s41, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s30, #17792
    a.vwrite     a4, s31, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s30, #17856
    a.vwrite     a4, s32, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s35, s30, #17920
    a.vwrite     a4, s29, v0
    v.ld.w       v0, [s42, #0]
    s.addi       s42, s30, #17984
    a.vwrite     a5, s40, v0
    v.ld.w       v0, [s34, #0]
    s.addi       s34, s30, #18048
    s.addi       s40, s30, #18112
    a.vwrite     a5, s43, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s43, s30, #18176
    s.addi       s45, s30, #18240
    a.vwrite     a5, s47, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s30, #18304
    s.addi       s47, s30, #18368
    a.vwrite     a5, s44, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s35, s30, #18432
    s.addi       s44, s30, #18496
    a.vwrite     a5, s46, v0
    v.ld.w       v0, [s42, #0]
    s.addi       s42, s30, #18560
    s.addi       s46, s30, #18624
    a.vwrite     a5, s49, v0
    v.ld.w       v0, [s34, #0]
    s.addi       s34, s30, #18688
    s.movz       s49, #0
    a.vwrite     a5, s37, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s37, s30, #18752
    s.movz       s40, #1
    a.vwrite     a5, s39, v0
    v.ld.w       v0, [s43, #0]
    s.addi       s39, s30, #18816
    s.movz       s43, #2
    a.vwrite     a5, s33, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s33, s30, #18880
    s.movz       s45, #3
    a.vwrite     a5, s48, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s30, #18944
    s.movz       s48, #4
    a.vwrite     a5, s38, v0
    v.ld.w       v0, [s47, #0]
    s.addi       s38, s30, #19008
    s.movz       s47, #5
    a.vwrite     a5, s28, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s28, s30, #19072
    s.movz       s35, #6
    a.vwrite     a5, s41, v0
    v.ld.w       v0, [s44, #0]
    s.addi       s41, s30, #19136
    s.movz       s44, #7
    a.vwrite     a5, s31, v0
    v.ld.w       v0, [s42, #0]
    s.addi       s31, s30, #19200
    s.movz       s42, #8
    a.vwrite     a5, s32, v0
    v.ld.w       v0, [s46, #0]
    s.addi       s32, s30, #19264
    s.movz       s46, #9
    a.vwrite     a5, s29, v0
    v.ld.w       v0, [s34, #0]
    s.addi       s29, s30, #19328
    s.movz       s34, #10
    a.vwrite     a6, s49, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s30, #19392
    a.vwrite     a6, s40, v0
    v.ld.w       v0, [s39, #0]
    s.movz       s39, #11
    a.vwrite     a6, s43, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s30, #19456
    a.vwrite     a6, s45, v0
    v.ld.w       v0, [s36, #0]
    s.movz       s36, #12
    a.vwrite     a6, s48, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #19520
    a.vwrite     a6, s47, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s28, #13
    a.vwrite     a6, s35, v0
    v.ld.w       v0, [s41, #0]
    s.addi       s41, s30, #19584
    a.vwrite     a6, s44, v0
    v.ld.w       v0, [s31, #0]
    s.movz       s31, #14
    a.vwrite     a6, s42, v0
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s30, #19648
    a.vwrite     a6, s46, v0
    v.ld.w       v0, [s29, #0]
    s.movz       s29, #15
    a.vwrite     a6, s34, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s30, #19712
    a.vwrite     a6, s39, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s30, #19776
    a.vwrite     a6, s36, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #19840
    a.vwrite     a6, s28, v0
    v.ld.w       v0, [s41, #0]
    s.addi       s41, s30, #19904
    a.vwrite     a6, s31, v0
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s30, #19968
    a.vwrite     a6, s29, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s30, #20032
    s.add        s50, s25, s24
    a.vwrite     a7, s49, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s30, #20096
    s.addi       s49, s30, #20160
    a.vwrite     a7, s40, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s30, #20224
    s.addi       s40, s30, #20288
    a.vwrite     a7, s43, v0
    v.ld.w       v0, [s41, #0]
    s.addi       s41, s30, #20352
    s.addi       s43, s30, #20416
    a.vwrite     a7, s45, v0
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s30, #20480
    s.addi       s45, s30, #20544
    a.vwrite     a7, s48, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s30, #20608
    s.addi       s48, s30, #20672
    s.movz       s30, #1
    a.vwrite     a7, s47, v0
    v.ld.w       v0, [s33, #0]
    a.vwrite     a7, s35, v0
    v.ld.w       v0, [s49, #0]
    a.vwrite     a7, s44, v0
    v.ld.w       v0, [s38, #0]
    a.vwrite     a7, s42, v0
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s46, v0
    v.ld.w       v0, [s41, #0]
    a.vwrite     a7, s34, v0
    v.ld.w       v0, [s43, #0]
    a.vwrite     a7, s39, v0
    v.ld.w       v0, [s32, #0]
    a.vwrite     a7, s36, v0
    v.ld.w       v0, [s45, #0]
    a.vwrite     a7, s28, v0
    v.ld.w       v0, [s37, #0]
    a.vwrite     a7, s31, v0
    v.ld.w       v0, [s48, #0]
    a.vwrite     a7, s29, v0
    s.mov        s25, s50
    br.nz        s30, for_18
endfor_19:
    s.mul        s2, s1, s20
    s.movz       s5, #0
    s.muli       s6, s4, #2
    s.add        s7, s5, s4                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    s.muli       s8, s2, #2
    v.splat      v1, s7
    a.vread      v2, a0, s5
    s.muli       s2, s20, #2
    s.add        s7, s5, s1                      // the tile origin
    s.add        s1, s5, s14                     // the tile origin
    s.add        s10, s5, s3                     // the tile origin
    v.splat      v3, s7
    v.splat      v4, s1
    v.add        v5, v0, v1
    v.splat      v1, s10
    vf.cvt.f32.bf16 v6, v2
    s.add        s1, s8, s6
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.muli       s5, s2, #1
    s.add        s10, s9, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    @p3 v.st.h       [s10, #0], v6
    a.vread      v1, a0, s1
    s.addi       s1, s7, #1
    s.add        s10, s5, s8
    v.splat      v2, s1
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s10, s6
    v.cmp.lt     p1, v2, v4
    s.muli       s5, s2, #2
    s.add        s10, s9, s1
    p.and        p3, p1, p2
    s.movz       s1, #2
    s.addi       s11, s4, #16
    s.add        s12, s5, s8
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s1
    s.add        s1, s12, s6
    s.addi       s5, s4, #32
    s.addi       s10, s7, #2
    vf.cvt.f32.bf16 v2, v1
    s.add        s12, s9, s1
    s.addi       s1, s4, #48
    v.splat      v1, s10
    s.addi       s10, s4, #64
    s.addi       s13, s4, #80
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s14, s4, #96
    @p3 v.st.h       [s12, #0], v2
    s.addi       s12, s4, #112
    s.muli       s4, s2, #3
    s.movz       s15, #3
    s.addi       s16, s7, #3
    a.vread      v1, a0, s15
    v.splat      v2, s16
    s.add        s15, s4, s8
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s15, s6
    v.cmp.lt     p1, v2, v4
    s.muli       s15, s2, #4
    s.add        s16, s9, s4
    p.and        p3, p1, p2
    s.movz       s4, #4
    @p3 v.st.h       [s16, #0], v3
    a.vread      v1, a0, s4
    s.addi       s4, s7, #4
    s.add        s16, s15, s8
    v.splat      v2, s4
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s16, s6
    v.cmp.lt     p1, v2, v4
    s.muli       s15, s2, #5
    s.add        s16, s9, s4
    p.and        p3, p1, p2
    s.movz       s4, #5
    s.addi       s17, s7, #5
    s.add        s18, s15, s8
    @p3 v.st.h       [s16, #0], v3
    a.vread      v1, a0, s4
    v.splat      v2, s17
    s.add        s4, s18, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s15, s2, #6
    s.add        s16, s9, s4
    p.and        p3, p1, p2
    s.movz       s4, #6
    s.addi       s17, s7, #6
    s.add        s18, s15, s8
    v.splat      v1, s17
    s.add        s15, s18, s6
    @p3 v.st.h       [s16, #0], v3
    a.vread      v2, a0, s4
    v.cmp.lt     p1, v1, v4
    s.muli       s4, s2, #7
    vf.cvt.f32.bf16 v1, v2
    s.add        s16, s9, s15
    p.and        p3, p1, p2
    s.movz       s15, #7
    s.addi       s17, s7, #7
    s.add        s18, s4, s8
    v.splat      v2, s17
    s.add        s4, s18, s6
    s.muli       s17, s2, #8
    v.cmp.lt     p1, v2, v4
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a0, s15
    s.add        s15, s9, s4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.movz       s4, #8
    s.addi       s16, s7, #8
    s.add        s18, s17, s8
    v.splat      v1, s16
    s.add        s16, s18, s6
    s.muli       s17, s2, #9
    v.cmp.lt     p1, v1, v4
    s.add        s18, s9, s16
    p.and        p4, p1, p2
    @p3 v.st.h       [s15, #0], v2
    a.vread      v1, a0, s4
    s.movz       s4, #9
    s.addi       s15, s7, #9
    vf.cvt.f32.bf16 v2, v1
    s.add        s16, s17, s8
    v.splat      v1, s15
    s.add        s15, s16, s6
    s.muli       s16, s2, #10
    v.cmp.lt     p1, v1, v4
    s.add        s17, s9, s15
    p.and        p3, p1, p2
    s.movz       s15, #10
    s.addi       s19, s7, #10
    @p4 v.st.h       [s18, #0], v2
    a.vread      v1, a0, s4
    s.add        s4, s16, s8
    v.splat      v2, s19
    vf.cvt.f32.bf16 v3, v1
    s.add        s16, s4, s6
    v.cmp.lt     p1, v2, v4
    s.muli       s4, s2, #11
    s.add        s18, s9, s16
    p.and        p4, p1, p2
    s.movz       s16, #11
    s.addi       s19, s7, #11
    s.add        s20, s4, s8
    v.splat      v1, s19
    @p3 v.st.h       [s17, #0], v3
    a.vread      v2, a0, s15
    s.add        s4, s20, s6
    v.cmp.lt     p1, v1, v4
    vf.cvt.f32.bf16 v1, v2
    s.muli       s15, s2, #12
    s.add        s17, s9, s4
    p.and        p3, p1, p2
    s.movz       s4, #12
    s.addi       s19, s7, #12
    s.add        s20, s15, s8
    v.splat      v2, s19
    s.add        s15, s20, s6
    s.muli       s19, s2, #13
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v2, v4
    s.add        s16, s9, s15
    vf.cvt.f32.bf16 v2, v1
    p.and        p4, p1, p2
    s.movz       s15, #13
    s.addi       s18, s7, #13
    s.add        s20, s19, s8
    v.splat      v1, s18
    s.add        s18, s20, s6
    s.muli       s19, s2, #14
    s.add        s20, s9, s18
    s.movz       s18, #14
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a0, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s4, s7, #14
    s.add        s17, s19, s8
    v.splat      v2, s4
    s.add        s4, s17, s6
    s.muli       s17, s2, #15
    s.add        s19, s9, s4
    s.movz       s4, #15
    s.addi       s21, s7, #15
    v.splat      v3, s7
    @p4 v.st.h       [s16, #0], v1
    a.vread      v1, a0, s15
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s15, s17, s8
    v.splat      v1, s21
    s.movz       s16, #0
    s.add        s17, s15, s6
    s.add        s6, s16, s11                    // the tile origin
    s.add        s15, s9, s17
    s.muli       s17, s11, #2
    v.splat      v5, s6
    s.add        s6, s16, s3                     // the tile origin
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a0, s18
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.add        v2, v0, v5
    v.splat      v5, s6
    s.add        s6, s8, s17
    v.cmp.lt     p1, v3, v4
    s.muli       s11, s2, #1
    s.add        s18, s9, s6
    s.movz       s6, #1
    s.addi       s20, s7, #1
    s.muli       s21, s2, #2
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p2, v2, v5
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s4, s11, s8
    v.splat      v1, s20
    s.add        s11, s4, s17
    s.movz       s4, #2
    s.add        s19, s9, s11
    s.addi       s11, s7, #2
    s.add        s20, s21, s8
    v.splat      v3, s11
    s.add        s11, s20, s17
    @p3 v.st.h       [s15, #0], v2
    a.vread      v2, a1, s16
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s15, s2, #3
    s.add        s16, s9, s11
    s.movz       s11, #3
    s.addi       s20, s7, #3
    s.muli       s21, s2, #4
    s.add        s22, s15, s8
    v.splat      v2, s20
    s.add        s15, s22, s17
    s.movz       s20, #4
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s6
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s6, s9, s15
    s.addi       s15, s7, #4
    s.add        s18, s21, s8
    v.splat      v1, s15
    s.add        s15, s18, s17
    s.muli       s18, s2, #5
    s.add        s21, s9, s15
    s.movz       s15, #5
    @p3 v.st.h       [s19, #0], v3
    a.vread      v3, a1, s4
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s4, s7, #5
    s.add        s19, s18, s8
    v.splat      v3, s4
    s.add        s4, s19, s17
    s.muli       s18, s2, #6
    s.add        s19, s9, s4
    s.movz       s4, #6
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s11, s7, #6
    s.add        s16, s18, s8
    v.splat      v2, s11
    s.add        s11, s16, s17
    s.muli       s16, s2, #7
    s.add        s18, s9, s11
    s.movz       s11, #7
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a1, s20
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s6, s7, #7
    s.add        s20, s16, s8
    v.splat      v1, s6
    s.add        s6, s20, s17
    s.muli       s16, s2, #8
    s.add        s20, s9, s6
    s.movz       s6, #8
    @p4 v.st.h       [s21, #0], v3
    a.vread      v3, a1, s15
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s15, s7, #8
    s.add        s21, s16, s8
    v.splat      v3, s15
    s.add        s15, s21, s17
    s.muli       s16, s2, #9
    s.add        s21, s9, s15
    s.movz       s15, #9
    @p3 v.st.h       [s19, #0], v2
    a.vread      v2, a1, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s4, s7, #9
    s.add        s19, s16, s8
    v.splat      v2, s4
    s.add        s4, s19, s17
    s.muli       s16, s2, #10
    s.add        s19, s9, s4
    s.movz       s4, #10
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s11
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s7, #10
    s.add        s18, s16, s8
    v.splat      v1, s11
    s.add        s11, s18, s17
    s.muli       s16, s2, #11
    s.add        s18, s9, s11
    s.movz       s11, #11
    @p3 v.st.h       [s20, #0], v3
    a.vread      v3, a1, s6
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s6, s7, #11
    s.add        s20, s16, s8
    v.splat      v3, s6
    s.add        s6, s20, s17
    s.muli       s16, s2, #12
    s.add        s20, s9, s6
    s.movz       s6, #12
    @p4 v.st.h       [s21, #0], v2
    a.vread      v2, a1, s15
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s15, s7, #12
    s.add        s21, s16, s8
    v.splat      v2, s15
    s.add        s15, s21, s17
    s.muli       s16, s2, #13
    s.add        s21, s9, s15
    s.movz       s15, #13
    @p3 v.st.h       [s19, #0], v1
    a.vread      v1, a1, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s4, s7, #13
    s.add        s19, s16, s8
    v.splat      v1, s4
    s.add        s4, s19, s17
    s.muli       s16, s2, #14
    s.add        s19, s9, s4
    s.movz       s4, #14
    @p4 v.st.h       [s18, #0], v3
    a.vread      v3, a1, s11
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s11, s7, #14
    s.add        s18, s16, s8
    v.splat      v3, s11
    s.add        s11, s18, s17
    s.muli       s16, s2, #15
    s.add        s18, s9, s11
    s.movz       s11, #15
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a1, s6
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s6, s7, #15
    s.add        s20, s16, s8
    v.splat      v2, s6
    s.movz       s6, #0
    s.add        s16, s20, s17
    s.add        s17, s6, s5                     // the tile origin
    s.add        s20, s9, s16
    s.muli       s16, s5, #2
    v.splat      v5, s17
    @p4 v.st.h       [s21, #0], v1
    a.vread      v1, a1, s15
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s5, s6, s3                      // the tile origin
    v.splat      v1, s7
    v.add        v6, v0, v5
    v.splat      v5, s5
    s.add        s5, s8, s16
    s.muli       s15, s2, #1
    s.add        s17, s9, s5
    s.movz       s5, #1
    @p3 v.st.h       [s19, #0], v3
    a.vread      v3, a1, s4
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    v.cmp.lt     p1, v1, v4
    s.addi       s4, s7, #1
    s.add        s19, s15, s8
    v.splat      v1, s4
    s.add        s4, s19, s16
    s.muli       s15, s2, #2
    s.add        s19, s9, s4
    s.movz       s4, #2
    @p4 v.st.h       [s18, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p2, v6, v5
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s11, s7, #2
    s.add        s18, s15, s8
    v.splat      v2, s11
    s.add        s11, s18, s16
    s.muli       s15, s2, #3
    s.add        s18, s9, s11
    s.movz       s11, #3
    @p3 v.st.h       [s20, #0], v3
    a.vread      v3, a2, s6
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s6, s7, #3
    s.add        s20, s15, s8
    v.splat      v3, s6
    s.add        s6, s20, s16
    s.muli       s15, s2, #4
    s.add        s20, s9, s6
    s.movz       s6, #4
    s.addi       s21, s7, #4
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a2, s5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s5, s15, s8
    v.splat      v1, s21
    s.add        s15, s5, s16
    s.muli       s5, s2, #5
    s.add        s17, s9, s15
    s.movz       s15, #5
    s.addi       s21, s7, #5
    s.add        s22, s5, s8
    @p3 v.st.h       [s19, #0], v2
    a.vread      v2, a2, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s21
    s.add        s4, s22, s16
    s.muli       s5, s2, #6
    s.add        s19, s9, s4
    s.movz       s4, #6
    s.addi       s21, s7, #6
    s.add        s22, s5, s8
    v.splat      v5, s21
    @p4 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s5, s22, s16
    s.muli       s11, s2, #7
    s.add        s18, s9, s5
    s.movz       s5, #7
    s.addi       s21, s7, #7
    s.add        s22, s11, s8
    v.splat      v3, s21
    s.add        s11, s22, s16
    @p3 v.st.h       [s20, #0], v1
    a.vread      v1, a2, s6
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s6, s2, #8
    s.add        s20, s9, s11
    s.movz       s11, #8
    s.addi       s21, s7, #8
    s.add        s22, s6, s8
    v.splat      v1, s21
    s.add        s6, s22, s16
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s15
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s15, s2, #9
    s.add        s17, s9, s6
    s.movz       s6, #9
    s.addi       s21, s7, #9
    s.add        s22, s15, s8
    v.splat      v2, s21
    s.add        s15, s22, s16
    @p3 v.st.h       [s19, #0], v5
    a.vread      v5, a2, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s4, s2, #10
    s.add        s19, s9, s15
    s.movz       s15, #10
    s.addi       s21, s7, #10
    s.add        s22, s4, s8
    v.splat      v5, s21
    s.add        s4, s22, s16
    @p4 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s5, s2, #11
    s.add        s18, s9, s4
    s.movz       s4, #11
    s.addi       s21, s7, #11
    s.add        s22, s5, s8
    v.splat      v3, s21
    s.add        s5, s22, s16
    @p3 v.st.h       [s20, #0], v1
    a.vread      v1, a2, s11
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s11, s2, #12
    s.add        s20, s9, s5
    s.movz       s5, #12
    s.addi       s21, s7, #12
    s.add        s22, s11, s8
    v.splat      v1, s21
    s.add        s11, s22, s16
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s6
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s6, s2, #13
    s.add        s17, s9, s11
    s.movz       s11, #13
    s.addi       s21, s7, #13
    s.add        s22, s6, s8
    v.splat      v2, s21
    s.add        s6, s22, s16
    @p3 v.st.h       [s19, #0], v5
    a.vread      v5, a2, s15
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s15, s2, #14
    s.add        s19, s9, s6
    s.movz       s6, #14
    s.addi       s21, s7, #14
    s.add        s22, s15, s8
    v.splat      v5, s21
    s.add        s15, s22, s16
    @p4 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s2, #15
    s.add        s18, s9, s15
    s.movz       s15, #15
    s.addi       s21, s7, #15
    s.add        s22, s4, s8
    v.splat      v3, s21
    s.add        s4, s22, s16
    @p3 v.st.h       [s20, #0], v1
    a.vread      v1, a2, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.movz       s5, #0
    s.add        s16, s9, s4
    s.add        s4, s5, s1                      // the tile origin
    s.muli       s20, s1, #2
    v.splat      v1, s4
    v.splat      v6, s7
    v.add        v7, v0, v1
    s.add        s1, s8, s20
    @p4 v.st.h       [s17, #0], v2
    a.vread      v1, a2, s11
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s4, s5, s3                      // the tile origin
    s.muli       s11, s2, #1
    v.splat      v1, s4
    s.add        s4, s9, s1
    s.movz       s1, #1
    s.add        s17, s11, s8
    s.add        s11, s17, s20
    @p3 v.st.h       [s19, #0], v2
    a.vread      v2, a2, s6
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s6, s7, #1
    s.muli       s17, s2, #2
    v.splat      v2, s6
    s.add        s6, s9, s11
    s.movz       s11, #2
    s.add        s19, s17, s8
    @p4 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s15
    v.cmp.lt     p2, v7, v1
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s15, s7, #2
    s.add        s17, s19, s20
    v.splat      v3, s15
    s.muli       s15, s2, #3
    s.add        s18, s9, s17
    s.movz       s17, #3
    s.add        s19, s15, s8
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a3, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s5, s7, #3
    s.add        s15, s19, s20
    v.splat      v1, s5
    s.muli       s5, s2, #4
    s.add        s16, s9, s15
    s.movz       s15, #4
    s.addi       s19, s7, #4
    s.add        s21, s5, s8
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s19
    s.add        s1, s21, s20
    s.muli       s4, s2, #5
    s.add        s5, s9, s1
    s.movz       s1, #5
    s.addi       s19, s7, #5
    s.add        s21, s4, s8
    v.splat      v5, s19
    @p3 v.st.h       [s6, #0], v3
    a.vread      v3, a3, s11
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s4, s21, s20
    s.muli       s6, s2, #6
    s.add        s11, s9, s4
    s.movz       s4, #6
    s.addi       s19, s7, #6
    s.add        s21, s6, s8
    v.splat      v3, s19
    s.add        s6, s21, s20
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s17
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s17, s2, #7
    s.add        s18, s9, s6
    s.movz       s6, #7
    s.addi       s19, s7, #7
    s.add        s21, s17, s8
    v.splat      v1, s19
    s.add        s17, s21, s20
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s15
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s15, s2, #8
    s.add        s16, s9, s17
    s.movz       s17, #8
    s.addi       s19, s7, #8
    s.add        s21, s15, s8
    v.splat      v2, s19
    s.add        s15, s21, s20
    @p4 v.st.h       [s5, #0], v5
    a.vread      v5, a3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s1, s2, #9
    s.add        s5, s9, s15
    s.movz       s15, #9
    s.addi       s19, s7, #9
    s.add        s21, s1, s8
    v.splat      v5, s19
    s.add        s1, s21, s20
    @p3 v.st.h       [s11, #0], v3
    a.vread      v3, a3, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s2, #10
    s.add        s11, s9, s1
    s.movz       s1, #10
    s.addi       s19, s7, #10
    s.add        s21, s4, s8
    v.splat      v3, s19
    s.add        s4, s21, s20
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s6
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s6, s2, #11
    s.add        s18, s9, s4
    s.movz       s4, #11
    s.addi       s19, s7, #11
    s.add        s21, s6, s8
    v.splat      v1, s19
    s.add        s6, s21, s20
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s17
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s16, s2, #12
    s.add        s17, s9, s6
    s.movz       s6, #12
    s.addi       s19, s7, #12
    s.add        s21, s16, s8
    v.splat      v2, s19
    s.add        s16, s21, s20
    @p4 v.st.h       [s5, #0], v5
    a.vread      v5, a3, s15
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s5, s2, #13
    s.add        s15, s9, s16
    s.movz       s16, #13
    s.addi       s19, s7, #13
    s.add        s21, s5, s8
    v.splat      v5, s19
    s.add        s5, s21, s20
    @p3 v.st.h       [s11, #0], v3
    a.vread      v3, a3, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s1, s2, #14
    s.add        s11, s9, s5
    s.movz       s5, #14
    s.addi       s19, s7, #14
    s.add        s21, s1, s8
    v.splat      v3, s19
    s.add        s1, s21, s20
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s4, s2, #15
    s.add        s18, s9, s1
    s.movz       s1, #15
    s.addi       s19, s7, #15
    s.add        s21, s4, s8
    v.splat      v1, s19
    s.add        s4, s21, s20
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a3, s6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s6, #0
    s.add        s17, s9, s4
    s.add        s4, s6, s10                     // the tile origin
    s.muli       s19, s10, #2
    v.splat      v2, s4
    v.splat      v6, s7
    v.add        v7, v0, v2
    s.add        s4, s8, s19
    @p4 v.st.h       [s15, #0], v5
    a.vread      v2, a3, s16
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s10, s6, s3                     // the tile origin
    s.muli       s15, s2, #1
    v.splat      v2, s10
    s.add        s10, s9, s4
    s.movz       s4, #1
    s.add        s16, s15, s8
    s.add        s15, s16, s19
    @p3 v.st.h       [s11, #0], v3
    a.vread      v3, a3, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v6, v4
    s.addi       s5, s7, #1
    s.muli       s11, s2, #2
    v.splat      v3, s5
    s.add        s5, s9, s15
    s.movz       s15, #2
    s.add        s16, s11, s8
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s1
    v.cmp.lt     p2, v7, v2
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s1, s7, #2
    s.add        s11, s16, s19
    v.splat      v1, s1
    s.muli       s1, s2, #3
    s.add        s16, s9, s11
    s.movz       s11, #3
    s.add        s18, s1, s8
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s6
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s1, s7, #3
    s.add        s6, s18, s19
    v.splat      v2, s1
    s.muli       s1, s2, #4
    s.add        s17, s9, s6
    s.movz       s6, #4
    s.addi       s18, s7, #4
    s.add        s20, s1, s8
    @p4 v.st.h       [s10, #0], v3
    a.vread      v3, a4, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    v.splat      v3, s18
    s.add        s1, s20, s19
    s.muli       s4, s2, #5
    s.add        s10, s9, s1
    s.movz       s1, #5
    s.addi       s18, s7, #5
    s.add        s20, s4, s8
    v.splat      v5, s18
    @p3 v.st.h       [s5, #0], v1
    a.vread      v1, a4, s15
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s4, s20, s19
    s.muli       s5, s2, #6
    s.add        s15, s9, s4
    s.movz       s4, #6
    s.addi       s18, s7, #6
    s.add        s20, s5, s8
    v.splat      v1, s18
    s.add        s5, s20, s19
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a4, s11
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s11, s2, #7
    s.add        s16, s9, s5
    s.movz       s5, #7
    s.addi       s18, s7, #7
    s.add        s20, s11, s8
    v.splat      v2, s18
    s.add        s11, s20, s19
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a4, s6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.muli       s6, s2, #8
    s.add        s17, s9, s11
    s.movz       s11, #8
    s.addi       s18, s7, #8
    s.add        s20, s6, s8
    v.splat      v3, s18
    s.add        s6, s20, s19
    @p4 v.st.h       [s10, #0], v5
    a.vread      v5, a4, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s1, s2, #9
    s.add        s10, s9, s6
    s.movz       s6, #9
    s.addi       s18, s7, #9
    s.add        s20, s1, s8
    v.splat      v5, s18
    s.add        s1, s20, s19
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a4, s4
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s4, s2, #10
    s.add        s15, s9, s1
    s.movz       s1, #10
    s.addi       s18, s7, #10
    s.add        s20, s4, s8
    v.splat      v1, s18
    s.add        s4, s20, s19
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a4, s5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s5, s2, #11
    s.add        s16, s9, s4
    s.movz       s4, #11
    s.addi       s18, s7, #11
    s.add        s20, s5, s8
    v.splat      v2, s18
    s.add        s5, s20, s19
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a4, s11
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.muli       s11, s2, #12
    s.add        s17, s9, s5
    s.movz       s5, #12
    s.addi       s18, s7, #12
    s.add        s20, s11, s8
    v.splat      v3, s18
    s.add        s11, s20, s19
    @p4 v.st.h       [s10, #0], v5
    a.vread      v5, a4, s6
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s6, s2, #13
    s.add        s10, s9, s11
    s.movz       s11, #13
    s.addi       s18, s7, #13
    s.add        s20, s6, s8
    v.splat      v5, s18
    s.add        s6, s20, s19
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a4, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s1, s2, #14
    s.add        s15, s9, s6
    s.movz       s6, #14
    s.addi       s18, s7, #14
    s.add        s20, s1, s8
    v.splat      v1, s18
    s.add        s1, s20, s19
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a4, s4
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s4, s2, #15
    s.add        s16, s9, s1
    s.movz       s1, #15
    s.addi       s18, s7, #15
    s.add        s20, s4, s8
    v.splat      v2, s18
    s.add        s4, s20, s19
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a4, s5
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.movz       s5, #0
    s.add        s17, s9, s4
    s.add        s4, s5, s13                     // the tile origin
    s.muli       s18, s13, #2
    v.splat      v3, s4
    v.splat      v6, s7
    v.add        v7, v0, v3
    s.add        s4, s8, s18
    @p4 v.st.h       [s10, #0], v5
    a.vread      v3, a4, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s10, s5, s3                     // the tile origin
    s.muli       s11, s2, #1
    v.splat      v3, s10
    s.add        s10, s9, s4
    s.movz       s4, #1
    s.add        s13, s11, s8
    s.add        s11, s13, s18
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a4, s6
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.cmp.lt     p1, v6, v4
    s.addi       s6, s7, #1
    s.muli       s13, s2, #2
    v.splat      v1, s6
    s.add        s6, s9, s11
    s.movz       s11, #2
    s.add        s15, s13, s8
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a4, s1
    v.cmp.lt     p2, v7, v3
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s1, s7, #2
    s.add        s13, s15, s18
    v.splat      v2, s1
    s.muli       s1, s2, #3
    s.add        s15, s9, s13
    s.movz       s13, #3
    s.add        s16, s1, s8
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a5, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s1, s7, #3
    s.add        s5, s16, s18
    v.splat      v3, s1
    s.muli       s1, s2, #4
    s.add        s16, s9, s5
    s.movz       s5, #4
    s.addi       s17, s7, #4
    s.add        s19, s1, s8
    @p4 v.st.h       [s10, #0], v1
    a.vread      v1, a5, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s17
    s.add        s1, s19, s18
    s.muli       s4, s2, #5
    s.add        s10, s9, s1
    s.movz       s1, #5
    s.addi       s17, s7, #5
    s.add        s19, s4, s8
    v.splat      v5, s17
    @p3 v.st.h       [s6, #0], v2
    a.vread      v2, a5, s11
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s4, s19, s18
    s.muli       s6, s2, #6
    s.add        s11, s9, s4
    s.movz       s4, #6
    s.addi       s17, s7, #6
    s.add        s19, s6, s8
    v.splat      v2, s17
    s.add        s6, s19, s18
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a5, s13
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s13, s2, #7
    s.add        s15, s9, s6
    s.movz       s6, #7
    s.addi       s17, s7, #7
    s.add        s19, s13, s8
    v.splat      v3, s17
    s.add        s13, s19, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a5, s5
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s5, s2, #8
    s.add        s16, s9, s13
    s.movz       s13, #8
    s.addi       s17, s7, #8
    s.add        s19, s5, s8
    v.splat      v1, s17
    s.add        s5, s19, s18
    @p4 v.st.h       [s10, #0], v5
    a.vread      v5, a5, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s1, s2, #9
    s.add        s10, s9, s5
    s.movz       s5, #9
    s.addi       s17, s7, #9
    s.add        s19, s1, s8
    v.splat      v5, s17
    s.add        s1, s19, s18
    @p3 v.st.h       [s11, #0], v2
    a.vread      v2, a5, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s4, s2, #10
    s.add        s11, s9, s1
    s.movz       s1, #10
    s.addi       s17, s7, #10
    s.add        s19, s4, s8
    v.splat      v2, s17
    s.add        s4, s19, s18
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a5, s6
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s6, s2, #11
    s.add        s15, s9, s4
    s.movz       s4, #11
    s.addi       s17, s7, #11
    s.add        s19, s6, s8
    v.splat      v3, s17
    s.add        s6, s19, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a5, s13
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s13, s2, #12
    s.add        s16, s9, s6
    s.movz       s6, #12
    s.addi       s17, s7, #12
    s.add        s19, s13, s8
    v.splat      v1, s17
    s.add        s13, s19, s18
    @p4 v.st.h       [s10, #0], v5
    a.vread      v5, a5, s5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s5, s2, #13
    s.add        s10, s9, s13
    s.movz       s13, #13
    s.addi       s17, s7, #13
    s.add        s19, s5, s8
    v.splat      v5, s17
    s.add        s5, s19, s18
    @p3 v.st.h       [s11, #0], v2
    a.vread      v2, a5, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s2, #14
    s.add        s11, s9, s5
    s.movz       s5, #14
    s.addi       s17, s7, #14
    s.add        s19, s1, s8
    v.splat      v2, s17
    s.add        s1, s19, s18
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a5, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s2, #15
    s.add        s15, s9, s1
    s.movz       s1, #15
    s.addi       s17, s7, #15
    s.add        s19, s4, s8
    v.splat      v3, s17
    s.add        s4, s19, s18
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a5, s6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s6, #0
    s.add        s16, s9, s4
    s.add        s4, s6, s14                     // the tile origin
    s.muli       s17, s14, #2
    v.splat      v1, s4
    v.splat      v6, s7
    v.add        v7, v0, v1
    s.add        s4, s8, s17
    @p4 v.st.h       [s10, #0], v5
    a.vread      v1, a5, s13
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s10, s6, s3                     // the tile origin
    s.muli       s13, s2, #1
    v.splat      v1, s10
    s.add        s10, s9, s4
    s.movz       s4, #1
    s.add        s14, s13, s8
    s.add        s13, s14, s17
    @p3 v.st.h       [s11, #0], v2
    a.vread      v2, a5, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s5, s7, #1
    s.muli       s11, s2, #2
    v.splat      v2, s5
    s.add        s5, s9, s13
    s.movz       s13, #2
    s.add        s14, s11, s8
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a5, s1
    v.cmp.lt     p2, v7, v1
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s1, s7, #2
    s.add        s11, s14, s17
    v.splat      v3, s1
    s.muli       s1, s2, #3
    s.add        s14, s9, s11
    s.movz       s11, #3
    s.add        s15, s1, s8
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a6, s6
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s1, s7, #3
    s.add        s6, s15, s17
    v.splat      v1, s1
    s.muli       s1, s2, #4
    s.add        s15, s9, s6
    s.movz       s6, #4
    s.addi       s16, s7, #4
    s.add        s18, s1, s8
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a6, s4
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s16
    s.add        s1, s18, s17
    s.muli       s4, s2, #5
    s.add        s10, s9, s1
    s.movz       s1, #5
    s.addi       s16, s7, #5
    s.add        s18, s4, s8
    v.splat      v5, s16
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a6, s13
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s4, s18, s17
    s.muli       s5, s2, #6
    s.add        s13, s9, s4
    s.movz       s4, #6
    s.addi       s16, s7, #6
    s.add        s18, s5, s8
    v.splat      v3, s16
    s.add        s5, s18, s17
    @p4 v.st.h       [s14, #0], v1
    a.vread      v1, a6, s11
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s11, s2, #7
    s.add        s14, s9, s5
    s.movz       s5, #7
    s.addi       s16, s7, #7
    s.add        s18, s11, s8
    v.splat      v1, s16
    s.add        s11, s18, s17
    @p3 v.st.h       [s15, #0], v2
    a.vread      v2, a6, s6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s6, s2, #8
    s.add        s15, s9, s11
    s.movz       s11, #8
    s.addi       s16, s7, #8
    s.add        s18, s6, s8
    v.splat      v2, s16
    s.add        s6, s18, s17
    @p4 v.st.h       [s10, #0], v5
    a.vread      v5, a6, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s1, s2, #9
    s.add        s10, s9, s6
    s.movz       s6, #9
    s.addi       s16, s7, #9
    s.add        s18, s1, s8
    v.splat      v5, s16
    s.add        s1, s18, s17
    @p3 v.st.h       [s13, #0], v3
    a.vread      v3, a6, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s2, #10
    s.add        s13, s9, s1
    s.movz       s1, #10
    s.addi       s16, s7, #10
    s.add        s18, s4, s8
    v.splat      v3, s16
    s.add        s4, s18, s17
    @p4 v.st.h       [s14, #0], v1
    a.vread      v1, a6, s5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s5, s2, #11
    s.add        s14, s9, s4
    s.movz       s4, #11
    s.addi       s16, s7, #11
    s.add        s18, s5, s8
    v.splat      v1, s16
    s.add        s5, s18, s17
    @p3 v.st.h       [s15, #0], v2
    a.vread      v2, a6, s11
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s11, s2, #12
    s.add        s15, s9, s5
    s.movz       s5, #12
    s.addi       s16, s7, #12
    s.add        s18, s11, s8
    v.splat      v2, s16
    s.add        s11, s18, s17
    @p4 v.st.h       [s10, #0], v5
    a.vread      v5, a6, s6
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s6, s2, #13
    s.add        s10, s9, s11
    s.movz       s11, #13
    s.addi       s16, s7, #13
    s.add        s18, s6, s8
    v.splat      v5, s16
    s.add        s6, s18, s17
    @p3 v.st.h       [s13, #0], v3
    a.vread      v3, a6, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s1, s2, #14
    s.add        s13, s9, s6
    s.movz       s6, #14
    s.addi       s16, s7, #14
    s.add        s18, s1, s8
    v.splat      v3, s16
    s.add        s1, s18, s17
    @p4 v.st.h       [s14, #0], v1
    a.vread      v1, a6, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s4, s2, #15
    s.add        s14, s9, s1
    s.movz       s1, #15
    s.addi       s16, s7, #15
    s.add        s18, s4, s8
    v.splat      v1, s16
    s.add        s4, s18, s17
    @p3 v.st.h       [s15, #0], v2
    a.vread      v2, a6, s5
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s5, #0
    s.add        s15, s9, s4
    s.add        s4, s5, s12                     // the tile origin
    s.muli       s16, s12, #2
    v.splat      v2, s4
    v.splat      v6, s7
    v.add        v7, v0, v2
    s.add        s4, s8, s16
    @p4 v.st.h       [s10, #0], v5
    a.vread      v0, a6, s11
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.add        s10, s5, s3                     // the tile origin
    s.muli       s3, s2, #1
    v.splat      v0, s10
    s.add        s10, s9, s4
    s.movz       s4, #1
    s.add        s11, s3, s8
    s.add        s3, s11, s16
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s6
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s6, s7, #1
    s.muli       s11, s2, #2
    v.splat      v2, s6
    s.add        s6, s9, s3
    s.movz       s3, #2
    s.add        s12, s11, s8
    @p4 v.st.h       [s14, #0], v1
    a.vread      v1, a6, s1
    v.cmp.lt     p2, v7, v0
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s7, #2
    s.add        s11, s12, s16
    v.splat      v1, s1
    s.muli       s1, s2, #3
    s.add        s12, s9, s11
    s.movz       s11, #3
    s.add        s13, s1, s8
    @p3 v.st.h       [s15, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.addi       s1, s7, #3
    s.add        s5, s13, s16
    v.splat      v0, s1
    s.muli       s1, s2, #4
    s.add        s13, s9, s5
    s.movz       s5, #4
    s.addi       s14, s7, #4
    s.add        s15, s1, s8
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a7, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s14
    s.add        s1, s15, s16
    s.muli       s4, s2, #5
    s.add        s10, s9, s1
    s.movz       s1, #5
    s.addi       s14, s7, #5
    s.add        s15, s4, s8
    v.splat      v3, s14
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a7, s3
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.add        s3, s15, s16
    s.muli       s4, s2, #6
    s.add        s6, s9, s3
    s.movz       s3, #6
    s.addi       s14, s7, #6
    s.add        s15, s4, s8
    v.splat      v1, s14
    s.add        s4, s15, s16
    @p4 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s11
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s11, s2, #7
    s.add        s12, s9, s4
    s.movz       s4, #7
    s.addi       s14, s7, #7
    s.add        s15, s11, s8
    v.splat      v0, s14
    s.add        s11, s15, s16
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a7, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s5, s2, #8
    s.add        s13, s9, s11
    s.movz       s11, #8
    s.addi       s14, s7, #8
    s.add        s15, s5, s8
    v.splat      v2, s14
    s.add        s5, s15, s16
    @p4 v.st.h       [s10, #0], v3
    a.vread      v3, a7, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s1, s2, #9
    s.add        s10, s9, s5
    s.movz       s5, #9
    s.addi       s14, s7, #9
    s.add        s15, s1, s8
    v.splat      v3, s14
    s.add        s1, s15, s16
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a7, s3
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s3, s2, #10
    s.add        s6, s9, s1
    s.movz       s1, #10
    s.addi       s14, s7, #10
    s.add        s15, s3, s8
    v.splat      v1, s14
    s.add        s3, s15, s16
    @p4 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s4, s2, #11
    s.add        s12, s9, s3
    s.movz       s3, #11
    s.addi       s14, s7, #11
    s.add        s15, s4, s8
    v.splat      v0, s14
    s.add        s4, s15, s16
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a7, s11
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s11, s2, #12
    s.add        s13, s9, s4
    s.movz       s4, #12
    s.addi       s14, s7, #12
    s.add        s15, s11, s8
    v.splat      v2, s14
    s.add        s11, s15, s16
    @p4 v.st.h       [s10, #0], v3
    a.vread      v3, a7, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s5, s2, #13
    s.add        s10, s9, s11
    s.movz       s11, #13
    s.addi       s14, s7, #13
    s.add        s15, s5, s8
    v.splat      v3, s14
    s.add        s5, s15, s16
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a7, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s1, s2, #14
    s.add        s6, s9, s5
    s.movz       s5, #14
    s.addi       s14, s7, #14
    s.add        s15, s1, s8
    v.splat      v1, s14
    s.add        s1, s15, s16
    @p4 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s3, s2, #15
    s.add        s2, s9, s1
    s.movz       s1, #15
    s.addi       s12, s7, #15
    s.add        s7, s3, s8
    v.splat      v0, s12
    s.add        s3, s7, s16
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a7, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s4, s9, s3
    @p4 v.st.h       [s10, #0], v3
    a.vread      v2, a7, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a7, s5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s2, #0], v0
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s4, #0], v1
    exit
    exit
