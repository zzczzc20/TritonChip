    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #8
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #3
    s.movz       s6, #6
    s.xor        s8, s5, s3
    s.movz       s9, #1
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s9
    s.movz       s8, #0
    s.cmp.lt     s13, s12, s3
    s.movz       s3, #0
    s.cmp.lt     s14, s4, s11
    s.sub        s11, s8, s13
    s.sub        s8, s3, s14
    s.xor        s3, s12, s11
    s.muli       s13, s5, #8
    s.movz       s5, #0
    s.movz       s14, #1
    s.xor        s15, s4, s8
    s.sub        s16, s3, s11
    s.rdspecial  s3, arg_base
    s.xor        s11, s1, s7
    s.movz       s17, #0
    s.sub        s18, s15, s8
    s.addi       s15, s5, #0
    s.cmp.eq     s5, s16, s14
    s.ld.d       s14, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s19, s11, s7
    s.sub        s7, s2, s13
    s.ld.d       s2, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.addi       s7, s17, #0
    s.ld.d       s11, [s3, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s15, s18
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s15, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s18, s3
    s.shli       s13, s7, #1
    s.andi       s17, s5, #1
    s.movz       s5, #0
    s.or         s19, s13, s17
    s.movz       s13, #1
    s.cmp.geu    s17, s19, s16
    s.shl        s20, s13, s3
    s.sub        s13, s5, s17
    s.subi       s5, s3, #1
    s.and        s17, s16, s13
    s.and        s21, s20, s13
    s.sub        s13, s19, s17
    s.or         s17, s15, s21
    s.mov        s7, s13
    s.mov        s15, s17
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s13, s3, s5
    br.nz        s13, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s13, s4, s3
    s.movz       s3, #0
    s.sub        s15, s5, s13
    s.movz       s5, #0
    s.xor        s13, s4, s15
    s.movz       s4, #0
    s.sub        s16, s13, s15
    s.cmp.lt     s13, s12, s3
    s.lshri      s3, s16, #3
    s.movz       s17, #0
    s.muli       s18, s3, #8
    s.movz       s3, #0
    s.sub        s19, s4, s13
    s.movz       s4, #0
    s.cmp.lt     s13, s1, s17
    s.sub        s17, s16, s18
    s.xor        s16, s12, s19
    s.xor        s12, s17, s15
    s.xor        s17, s7, s8
    s.sub        s7, s12, s15
    s.sub        s12, s4, s13
    s.cmp.lt     s4, s7, s5
    s.sub        s5, s16, s19
    s.sub        s13, s3, s4
    s.movz       s3, #0
    s.xor        s4, s7, s13
    s.movz       s7, #1
    s.sub        s15, s17, s8
    s.xor        s8, s1, s12
    s.sub        s16, s4, s13
    s.movz       s4, #0
    s.addi       s17, s3, #0
    s.cmp.eq     s3, s5, s7
    s.add        s7, s10, s15
    s.sub        s10, s8, s12
    s.addi       s8, s4, #0
    s.mov        s17, s16
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s17, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s16, s3
    s.shli       s10, s8, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s15, s10, s12
    s.movz       s10, #1
    s.cmp.geu    s12, s15, s5
    s.shl        s18, s10, s3
    s.sub        s10, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s10
    s.and        s20, s18, s10
    s.sub        s10, s15, s12
    s.or         s12, s17, s20
    s.mov        s8, s10
    s.mov        s17, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s10, s3, s4
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.xor        s3, s13, s19
    s.movz       s4, #16
    s.xor        s5, s17, s3
    s.mul        s8, s7, s4
    s.sub        s10, s5, s3
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s3, s10, s4
    s.movz       s5, #0
    v.splat      v1, s8
    v.movi       v2, #81
    v.add        v3, v1, v0
    v.movi       v1, #0
    v.splat      v4, s7
    v.splat      v5, s5
    v.splat      v6, s10
    v.splat      v7, s5
    v.splat      v8, s3
    v.sub        v9, v1, v3
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v2, v1
    v.cmp.ge     p3, v4, v5
    v.sub        v4, v1, v2
    v.cmp.ge     p3, v6, v7
    v.add        v5, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v3
    @p2 v.sel        v3, v4, v2
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s7, #31
idiv_5:
    v.splat      v6, s7
    v.shl        v7, v4, v0
    v.lshr       v8, v5, v6
    v.cmp.lt     p2, v4, v1
    v.and        v9, v8, v0
    v.shl        v8, v0, v6
    v.or         v6, v7, v9
    s.subi       s10, s7, #1
    v.cmp.geu    p3, v6, v3
    p.or         p4, p2, p3
    v.sub        v7, v6, v3
    @p4 v.sel        v9, v8, v1
    @p4 v.sel        v8, v7, v6
    v.or         v6, v2, v9
    v.mov        v4, v8
    v.mov        v2, v6
    s.mov        s7, s10
    s.movz       s10, #0
    s.cmp.ge     s12, s7, s10
    br.nz        s12, idiv_5
    v.sub        v0, v1, v4
    @p1 v.sel        v1, v0, v4
    s.andi       s7, s3, #127
    v.splat      v0, s7
    v.iota       v2                              // arange(0, VLEN)
    v.add        v3, v0, v2
    s.rdspecial  s10, pid.y
    s.rdspecial  s12, pid.z
    s.rdspecial  s13, npid.y
    s.mul        s15, s12, s13
    s.add        s12, s10, s15
    s.movz       s10, #15
    s.min.s      s13, s12, s10
    s.movz       s15, #6561
    s.mul        s16, s13, s15
    s.rdspecial  s15, arg_base
    s.ld.d       s17, [s15, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s15, role_id
    s.movz       s18, #7168
    s.mul        s19, s15, s18
    s.add        s15, s17, s19                   // this context's own scratch
    s.addi       s17, s15, #0
    v.splat      v0, s5
    v.extract    s18, v1, #0
    v.splat      v2, s18
    s.movz       s18, #81
    v.splat      v3, s18
    v.mul        v4, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.add        v5, v4, v2
    s.movz       s19, #0
    s.add        s20, s19, s16                   // the tile origin
    v.splat      v4, s20
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s17, #0], v5
    s.addi       s16, s17, #64
    v.extract    s19, v1, #1
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #128
    v.extract    s19, v1, #2
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #192
    v.extract    s19, v1, #3
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #256
    v.extract    s19, v1, #4
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #320
    v.extract    s19, v1, #5
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #384
    v.extract    s19, v1, #6
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #448
    v.extract    s19, v1, #7
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #512
    v.extract    s19, v1, #8
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #576
    v.extract    s19, v1, #9
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #640
    v.extract    s19, v1, #10
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #704
    v.extract    s19, v1, #11
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #768
    v.extract    s19, v1, #12
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #832
    v.extract    s19, v1, #13
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #896
    v.extract    s19, v1, #14
    v.splat      v5, s19
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s17, #960
    v.extract    s17, v1, #15
    v.splat      v1, s17
    v.mul        v5, v1, v3
    v.add        v1, v5, v2
    v.add        v5, v1, v4
    v.add        v1, v0, v5
    v.st.w       [s16, #0], v1
    fence.acq_rel.device
    s.movz       s16, #10368
    s.mul        s17, s13, s16
    s.addi       s13, s5, #0
    s.addi       s19, s15, #1024
    s.addi       s20, s15, #0
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s20, s19, #64
    s.addi       s21, s15, #64
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #128
    s.addi       s21, s15, #128
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #192
    s.addi       s21, s15, #192
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #256
    s.addi       s21, s15, #256
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #320
    s.addi       s21, s15, #320
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #384
    s.addi       s21, s15, #384
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #448
    s.addi       s21, s15, #448
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #512
    s.addi       s21, s15, #512
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #576
    s.addi       s21, s15, #576
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #640
    s.addi       s21, s15, #640
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #704
    s.addi       s21, s15, #704
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #768
    s.addi       s21, s15, #768
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #832
    s.addi       s21, s15, #832
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #896
    s.addi       s21, s15, #896
    v.ld.w       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s19, #960
    s.addi       s19, s15, #960
    v.ld.w       v0, [s19, #0]
    v.st.w       [s20, #0], v0
    fence.acq_rel.device
    s.addi       s19, s15, #2048
    s.movz       s20, #0
    s.add        s21, s20, s7                    // the tile origin
    s.add        s7, s21, s17                    // the tile origin
    v.splat      v0, s7
    v.add        v1, v2, v0
    v.st.w       [s19, #0], v1
    s.addi       s17, s19, #64
    s.addi       s20, s7, #128
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #128
    s.addi       s20, s7, #256
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #192
    s.addi       s20, s7, #384
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #256
    s.addi       s20, s7, #512
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #320
    s.addi       s20, s7, #640
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #384
    s.addi       s20, s7, #768
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #448
    s.addi       s20, s7, #896
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #512
    s.addi       s20, s7, #1024
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #576
    s.addi       s20, s7, #1152
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #640
    s.addi       s20, s7, #1280
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #704
    s.addi       s20, s7, #1408
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #768
    s.addi       s20, s7, #1536
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #832
    s.addi       s20, s7, #1664
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #896
    s.addi       s20, s7, #1792
    v.splat      v0, s20
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s19, #960
    s.addi       s19, s7, #1920
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v1
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_6:
    s.cmp.ge     s7, s13, s18
    br.nz        s7, endfor_7
    s.addi       s7, s15, #1024
    s.sub        s17, s18, s13
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s19, #0
    s.add        s20, s7, s17                    // the tile origin
    s.addi       s7, s15, #1088
    v.splat      v1, s20
    s.movz       s20, #1
    v.cmp.lt     p1, v2, v1
    s.addi       s21, s15, #1152
    s.movz       s22, #2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    s.addi       s23, s15, #1216
    a.vwrite     a1, s19, v1
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #3
    s.addi       s19, s15, #1280
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s20, v1
    v.ld.w       v0, [s21, #0]
    s.movz       s20, #4
    s.addi       s21, s15, #1344
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s22, v1
    v.ld.w       v0, [s23, #0]
    s.movz       s22, #5
    s.addi       s23, s15, #1408
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v1
    v.ld.w       v0, [s19, #0]
    s.movz       s7, #6
    s.addi       s19, s15, #1472
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s20, v1
    v.ld.w       v0, [s21, #0]
    s.movz       s20, #7
    s.addi       s21, s15, #1536
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s22, v1
    v.ld.w       v0, [s23, #0]
    s.movz       s22, #8
    s.addi       s23, s15, #1600
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v1
    v.ld.w       v0, [s19, #0]
    s.movz       s7, #9
    s.addi       s19, s15, #1664
    v.splat      v1, s5
    s.movz       s24, #10
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s20, v4
    v.ld.w       v0, [s21, #0]
    s.addi       s20, s15, #1728
    s.movz       s21, #11
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s22, v4
    v.ld.w       v0, [s23, #0]
    s.addi       s22, s15, #1792
    s.movz       s23, #12
    v.splat      v4, s9
    s.addi       s25, s15, #1856
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v5
    v.ld.w       v0, [s19, #0]
    s.movz       s7, #13
    s.addi       s19, s15, #1920
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s24, v5
    v.ld.w       v0, [s20, #0]
    s.movz       s20, #14
    s.addi       s24, s15, #1984
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s21, v5
    v.ld.w       v0, [s22, #0]
    s.movz       s21, #15
    s.addi       s22, s15, #2048
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s23, v5
    v.ld.w       v0, [s25, #0]
    s.movz       s23, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s25, #0
    s.add        s26, s23, s17                   // the tile origin
    s.addi       s17, s15, #2112
    v.splat      v5, s26
    s.movz       s23, #1
    v.cmp.lt     p2, v1, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v1
    v.ld.w       v0, [s19, #0]
    s.addi       s7, s15, #2176
    s.movz       s19, #2
    v.splat      v1, s19
    s.movz       s19, #2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s20, v6
    v.ld.w       v0, [s24, #0]
    s.addi       s20, s15, #2240
    s.movz       s24, #3
    v.splat      v6, s24
    s.movz       s24, #3
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v5
    s.addi       s26, s15, #2304
    a.vwrite     a1, s21, v7
    v.ld.w       v0, [s22, #0]
    s.movz       s21, #4
    s.movz       s22, #4
    v.splat      v4, s21
    s.addi       s21, s15, #2368
    v.splat      v7, s6
    s.movz       s27, #5
    v.splat      v8, s27
    s.movz       s27, #5
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v5
    a.vwrite     a2, s25, v9
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s15, #2432
    s.movz       s25, #6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v5
    a.vwrite     a2, s23, v1
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s15, #2496
    s.movz       s23, #7
    v.splat      v1, s1
    v.splat      v6, s23
    s.movz       s23, #7
    s.addi       s28, s15, #2560
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v5
    a.vwrite     a2, s19, v9
    v.ld.w       v0, [s20, #0]
    s.movz       s19, #8
    s.addi       s20, s15, #2624
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v8, v5
    a.vwrite     a2, s24, v4
    v.ld.w       v0, [s26, #0]
    s.movz       s24, #9
    s.movz       s26, #9
    v.splat      v4, s24
    s.addi       s24, s15, #2688
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v5
    a.vwrite     a2, s22, v8
    v.ld.w       v0, [s21, #0]
    s.movz       s21, #10
    s.movz       s22, #10
    v.splat      v7, s21
    s.addi       s21, s15, #2752
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v5
    a.vwrite     a2, s27, v8
    v.ld.w       v0, [s17, #0]
    s.movz       s17, #11
    s.movz       s27, #11
    v.splat      v6, s17
    s.addi       s17, s15, #2816
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v5
    a.vwrite     a2, s25, v8
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #12
    s.movz       s25, #12
    v.splat      v1, s7
    s.addi       s7, s15, #2880
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v5
    a.vwrite     a2, s23, v8
    v.ld.w       v0, [s28, #0]
    s.movz       s23, #13
    s.movz       s28, #13
    v.splat      v4, s23
    s.addi       s23, s15, #2944
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v5
    a.vwrite     a2, s19, v8
    v.ld.w       v0, [s20, #0]
    s.movz       s19, #14
    s.movz       s20, #14
    v.splat      v7, s19
    s.addi       s19, s15, #3008
    v.splat      v8, s10
    s.movz       s29, #15
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v9, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v5
    a.vwrite     a2, s26, v9
    v.ld.w       v0, [s24, #0]
    s.movz       s24, #0
    s.movz       s26, #0
    v.movi       v6, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v5
    a.vwrite     a2, s22, v9
    v.ld.w       v0, [s21, #0]
    s.movz       s21, #1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s22, #0
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v5
    a.vwrite     a2, s27, v1
    v.ld.w       v0, [s17, #0]
    s.movz       s17, #2
    s.movz       s27, #3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v5
    a.vwrite     a2, s25, v1
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v8, v5
    s.movz       s25, #5
    a.vwrite     a2, s28, v1
    v.ld.w       v0, [s23, #0]
    s.movz       s23, #6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s20, v1
    v.ld.w       v0, [s19, #0]
    s.movz       s19, #7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    s.movz       s20, #8
    a.vwrite     a2, s29, v1
    a.vread      v0, a1, s24
    a.vread      v1, a2, s26
    v.extract    s24, v0, #0
    v.splat      v4, s24
    v.extract    s24, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s24
    a.vread      v4, a2, s21
    v.extract    s21, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s21
    a.vread      v4, a2, s17
    v.extract    s17, v0, #3
    vf.fma       v5, v1, v4, v7
    v.splat      v1, s17
    a.vread      v4, a2, s27
    v.extract    s17, v0, #4
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    v.extract    s7, v0, #5
    vf.fma       v5, v1, v4, v7
    v.splat      v1, s7
    a.vread      v4, a2, s25
    v.extract    s7, v0, #6
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s23
    v.extract    s7, v0, #7
    vf.fma       v5, v1, v4, v7
    v.splat      v1, s7
    a.vread      v4, a2, s19
    v.extract    s7, v0, #8
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s20
    s.movz       s7, #9
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #9
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #10
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #11
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #12
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #13
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #14
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #15
    v.splat      v0, s17
    a.vread      v1, a2, s7
    s.movz       s7, #1
    vf.fma       v4, v0, v1, v5
    s.movz       s17, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s22, v4
    a.vread      v0, a1, s7
    a.vread      v1, a2, s17
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s20
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #1
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #2
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #2
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #3
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #4
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #5
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #6
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #7
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #8
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #9
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #9
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #10
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #11
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #12
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #13
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #14
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v7
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v5, v1, v4, v7
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v7, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v7
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.movz       s17, #15
    vf.fma       v4, v0, v1, v5
    s.movz       s19, #0
    s.movz       s20, #1
    s.movz       s21, #2
    a.vwrite     a3, s7, v4
    a.vread      v0, a1, s17
    a.vread      v1, a2, s19
    v.extract    s7, v0, #0
    v.splat      v4, s7
    v.extract    s7, v0, #1
    vf.fma       v5, v4, v1, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    v.extract    s7, v0, #2
    vf.fma       v6, v1, v4, v5
    v.splat      v1, s7
    a.vread      v4, a2, s21
    s.movz       s7, #3
    vf.fma       v5, v1, v4, v6
    v.extract    s17, v0, #3
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v1, v4, v5
    v.extract    s17, v0, #4
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v1, v4, v6
    v.extract    s17, v0, #5
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v1, v4, v5
    v.extract    s17, v0, #6
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v1, v4, v6
    v.extract    s17, v0, #7
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v1, v4, v5
    v.extract    s17, v0, #8
    v.splat      v1, s17
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v5, v1, v4, v6
    s.movz       s17, #9
    v.extract    s19, v0, #9
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #10
    vf.fma       v6, v1, v4, v5
    v.extract    s19, v0, #10
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #11
    vf.fma       v5, v1, v4, v6
    v.extract    s19, v0, #11
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #12
    vf.fma       v6, v1, v4, v5
    v.extract    s19, v0, #12
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #13
    vf.fma       v5, v1, v4, v6
    v.extract    s19, v0, #13
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #14
    vf.fma       v6, v1, v4, v5
    v.extract    s19, v0, #14
    v.splat      v1, s19
    a.vread      v4, a2, s17
    s.movz       s17, #15
    vf.fma       v5, v1, v4, v6
    v.extract    s19, v0, #15
    v.splat      v0, s19
    a.vread      v1, a2, s17
    s.addi       s17, s15, #1024
    vf.fma       v4, v0, v1, v5
    v.splat      v0, s4
    s.addi       s19, s15, #3072
    s.addi       s20, s15, #1088
    a.vwrite     a3, s7, v4
    v.ld.w       v1, [s17, #0]
    s.addi       s7, s19, #64
    s.addi       s17, s15, #1152
    s.addi       s21, s19, #128
    s.addi       s22, s15, #1216
    s.addi       s23, s19, #192
    s.addi       s24, s15, #1280
    s.addi       s25, s19, #256
    s.addi       s26, s15, #1344
    s.addi       s27, s19, #320
    v.add        v4, v1, v0
    s.addi       s28, s15, #1408
    v.st.w       [s19, #0], v4
    s.addi       s29, s19, #384
    s.addi       s30, s15, #1472
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s19, #448
    v.add        v4, v1, v0
    v.st.w       [s7, #0], v4
    s.addi       s7, s15, #1536
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s19, #512
    v.add        v4, v1, v0
    v.st.w       [s21, #0], v4
    s.addi       s21, s15, #1600
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s19, #576
    v.add        v4, v1, v0
    v.st.w       [s23, #0], v4
    s.addi       s23, s15, #1664
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s19, #640
    v.add        v4, v1, v0
    v.st.w       [s25, #0], v4
    s.addi       s25, s15, #1728
    v.ld.w       v1, [s26, #0]
    s.addi       s26, s19, #704
    v.add        v4, v1, v0
    v.st.w       [s27, #0], v4
    s.addi       s27, s15, #1792
    v.ld.w       v1, [s28, #0]
    s.addi       s28, s19, #768
    v.add        v4, v1, v0
    v.st.w       [s29, #0], v4
    s.addi       s29, s15, #1856
    v.ld.w       v1, [s30, #0]
    s.addi       s30, s19, #832
    v.add        v4, v1, v0
    v.st.w       [s20, #0], v4
    s.addi       s20, s15, #1920
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s19, #896
    s.addi       s31, s19, #960
    v.add        v4, v1, v0
    v.st.w       [s17, #0], v4
    s.addi       s17, s15, #1984
    v.ld.w       v1, [s21, #0]
    s.addi       s19, s15, #2048
    v.add        v4, v1, v0
    v.st.w       [s22, #0], v4
    s.movz       s21, #2048
    v.splat      v1, s21
    s.addi       s21, s15, #4096
    v.ld.w       v4, [s23, #0]
    s.addi       s22, s15, #2112
    v.add        v5, v4, v0
    v.st.w       [s24, #0], v5
    s.addi       s23, s21, #64
    v.ld.w       v4, [s25, #0]
    s.addi       s24, s15, #2176
    v.add        v5, v4, v0
    v.st.w       [s26, #0], v5
    s.addi       s25, s21, #128
    v.ld.w       v4, [s27, #0]
    s.addi       s26, s15, #2240
    v.add        v5, v4, v0
    v.st.w       [s28, #0], v5
    s.addi       s27, s21, #192
    v.ld.w       v4, [s29, #0]
    s.addi       s28, s15, #2304
    v.add        v5, v4, v0
    v.st.w       [s30, #0], v5
    s.addi       s29, s21, #256
    v.ld.w       v4, [s20, #0]
    s.addi       s20, s15, #2368
    v.add        v5, v4, v0
    v.st.w       [s7, #0], v5
    s.addi       s7, s21, #320
    v.ld.w       v4, [s17, #0]
    s.addi       s17, s15, #2432
    v.add        v5, v4, v0
    v.st.w       [s31, #0], v5
    fence.acq_rel.device
    s.addi       s30, s21, #384
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s15, #2496
    v.add        v4, v0, v1
    v.st.w       [s21, #0], v4
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s21, #448
    v.add        v4, v0, v1
    v.st.w       [s23, #0], v4
    s.addi       s23, s15, #2560
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s21, #512
    v.add        v4, v0, v1
    v.st.w       [s25, #0], v4
    s.addi       s25, s15, #2624
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s21, #576
    v.add        v4, v0, v1
    v.st.w       [s27, #0], v4
    s.addi       s27, s15, #2688
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s21, #640
    v.add        v4, v0, v1
    v.st.w       [s29, #0], v4
    s.addi       s29, s15, #2752
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s21, #704
    v.add        v4, v0, v1
    v.st.w       [s7, #0], v4
    s.addi       s7, s15, #2816
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s21, #768
    v.add        v4, v0, v1
    v.st.w       [s30, #0], v4
    s.addi       s30, s15, #2880
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s21, #832
    v.add        v4, v0, v1
    v.st.w       [s22, #0], v4
    s.addi       s22, s15, #2944
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s21, #896
    s.addi       s31, s21, #960
    v.add        v4, v0, v1
    v.st.w       [s24, #0], v4
    s.addi       s21, s15, #3008
    v.ld.w       v0, [s25, #0]
    s.addi       s24, s15, #3072
    v.add        v4, v0, v1
    v.st.w       [s26, #0], v4
    s.addi       s25, s15, #5120
    v.ld.w       v0, [s27, #0]
    s.addi       s26, s15, #3136
    v.add        v4, v0, v1
    v.st.w       [s28, #0], v4
    s.addi       s27, s25, #64
    v.ld.w       v0, [s29, #0]
    s.addi       s28, s15, #3200
    v.add        v4, v0, v1
    v.st.w       [s20, #0], v4
    s.addi       s20, s25, #128
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s15, #3264
    v.add        v4, v0, v1
    v.st.w       [s17, #0], v4
    s.addi       s17, s25, #192
    v.ld.w       v0, [s30, #0]
    s.addi       s29, s15, #3328
    v.add        v4, v0, v1
    v.st.w       [s19, #0], v4
    s.addi       s19, s25, #256
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s15, #3392
    v.add        v4, v0, v1
    v.st.w       [s23, #0], v4
    s.addi       s23, s25, #320
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s15, #3456
    v.add        v4, v0, v1
    v.st.w       [s31, #0], v4
    fence.acq_rel.device
    s.addi       s30, s25, #384
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s15, #3520
    v.st.w       [s25, #0], v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s25, #448
    v.st.w       [s27, #0], v0
    s.addi       s27, s15, #3584
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s25, #512
    v.st.w       [s20, #0], v0
    s.addi       s20, s15, #3648
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s25, #576
    v.st.w       [s17, #0], v0
    s.addi       s17, s15, #3712
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s25, #640
    v.st.w       [s19, #0], v0
    s.addi       s19, s15, #3776
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s25, #704
    v.st.w       [s23, #0], v0
    s.addi       s23, s15, #3840
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s25, #768
    v.st.w       [s30, #0], v0
    s.addi       s30, s15, #3904
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s25, #832
    v.st.w       [s26, #0], v0
    s.addi       s26, s15, #3968
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s25, #896
    s.addi       s31, s25, #960
    v.st.w       [s28, #0], v0
    s.addi       s25, s15, #4032
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s15, #4096
    v.st.w       [s7, #0], v0
    s.addi       s7, s15, #6144
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s15, #4160
    v.st.w       [s29, #0], v0
    s.addi       s28, s7, #64
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s15, #4224
    v.st.w       [s22, #0], v0
    s.addi       s22, s7, #128
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s15, #4288
    v.st.w       [s21, #0], v0
    s.addi       s21, s7, #192
    v.ld.w       v0, [s30, #0]
    s.addi       s29, s15, #4352
    v.st.w       [s24, #0], v0
    s.addi       s24, s7, #256
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s15, #4416
    v.st.w       [s27, #0], v0
    s.addi       s27, s7, #320
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s15, #4480
    v.st.w       [s31, #0], v0
    fence.acq_rel.device
    s.addi       s30, s7, #384
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s15, #4544
    v.st.w       [s7, #0], v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s7, #448
    v.st.w       [s28, #0], v0
    s.addi       s28, s15, #4608
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s7, #512
    v.st.w       [s22, #0], v0
    s.addi       s22, s15, #4672
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s7, #576
    v.st.w       [s21, #0], v0
    s.addi       s21, s15, #4736
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s7, #640
    v.st.w       [s24, #0], v0
    s.addi       s24, s15, #4800
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s7, #704
    v.st.w       [s27, #0], v0
    s.addi       s27, s15, #4864
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s7, #768
    v.st.w       [s30, #0], v0
    s.addi       s30, s15, #4928
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s7, #832
    v.st.w       [s17, #0], v0
    s.addi       s17, s15, #4992
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s7, #896
    s.addi       s31, s7, #960
    v.st.w       [s19, #0], v0
    s.addi       s7, s15, #5056
    v.ld.w       v0, [s22, #0]
    s.movz       s19, #0
    v.st.w       [s23, #0], v0
    s.movz       s22, #0
    v.ld.w       v0, [s21, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s21, #0
    v.st.w       [s29, #0], v0
    s.movz       s23, #1
    v.ld.w       v0, [s24, #0]
    s.movz       s24, #1
    v.st.w       [s26, #0], v0
    s.movz       s26, #1
    v.ld.w       v0, [s27, #0]
    s.movz       s27, #2
    v.st.w       [s25, #0], v0
    s.movz       s25, #2
    v.ld.w       v0, [s30, #0]
    s.movz       s29, #2
    v.st.w       [s20, #0], v0
    s.movz       s20, #3
    v.ld.w       v0, [s17, #0]
    s.movz       s17, #3
    v.st.w       [s28, #0], v0
    s.movz       s28, #3
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #4
    v.st.w       [s31, #0], v0
    fence.acq_rel.device
    a.vread      v0, a0, s19
    a.vread      v1, a3, s22
    s.movz       s19, #4
    vf.add       v4, v0, v1
    s.movz       s22, #4
    s.movz       s30, #5
    a.vwrite     a4, s21, v4
    a.vread      v0, a0, s23
    a.vread      v1, a3, s24
    s.movz       s21, #5
    vf.add       v4, v0, v1
    s.movz       s23, #5
    s.movz       s24, #6
    a.vwrite     a4, s26, v4
    a.vread      v0, a0, s27
    a.vread      v1, a3, s25
    s.movz       s25, #6
    vf.add       v4, v0, v1
    s.movz       s26, #6
    s.movz       s27, #7
    a.vwrite     a4, s29, v4
    a.vread      v0, a0, s20
    a.vread      v1, a3, s17
    s.movz       s17, #7
    vf.add       v4, v0, v1
    s.movz       s20, #7
    s.movz       s29, #8
    a.vwrite     a4, s28, v4
    a.vread      v0, a0, s7
    a.vread      v1, a3, s19
    s.movz       s7, #8
    vf.add       v4, v0, v1
    s.movz       s19, #8
    s.movz       s28, #9
    a.vwrite     a4, s22, v4
    a.vread      v0, a0, s30
    a.vread      v1, a3, s21
    s.movz       s21, #9
    vf.add       v4, v0, v1
    s.movz       s22, #9
    s.movz       s30, #10
    a.vwrite     a4, s23, v4
    a.vread      v0, a0, s24
    a.vread      v1, a3, s25
    s.movz       s23, #10
    vf.add       v4, v0, v1
    s.movz       s24, #10
    s.movz       s25, #11
    a.vwrite     a4, s26, v4
    a.vread      v0, a0, s27
    a.vread      v1, a3, s17
    s.movz       s17, #11
    vf.add       v4, v0, v1
    s.movz       s26, #11
    s.movz       s27, #12
    a.vwrite     a4, s20, v4
    a.vread      v0, a0, s29
    a.vread      v1, a3, s7
    s.movz       s7, #12
    vf.add       v4, v0, v1
    s.movz       s20, #12
    s.movz       s29, #13
    a.vwrite     a4, s19, v4
    a.vread      v0, a0, s28
    a.vread      v1, a3, s21
    s.movz       s19, #13
    vf.add       v4, v0, v1
    s.movz       s21, #13
    s.movz       s28, #14
    a.vwrite     a4, s22, v4
    a.vread      v0, a0, s30
    a.vread      v1, a3, s23
    s.movz       s22, #14
    vf.add       v4, v0, v1
    s.movz       s23, #14
    s.movz       s30, #15
    a.vwrite     a4, s24, v4
    a.vread      v0, a0, s25
    a.vread      v1, a3, s17
    s.movz       s17, #15
    vf.add       v4, v0, v1
    s.movz       s24, #15
    s.addi       s25, s15, #5120
    a.vwrite     a4, s26, v4
    a.vread      v0, a0, s27
    a.vread      v1, a3, s7
    s.addi       s7, s15, #1024
    vf.add       v4, v0, v1
    s.addi       s26, s15, #5184
    s.addi       s27, s15, #1088
    a.vwrite     a4, s20, v4
    a.vread      v0, a0, s29
    a.vread      v1, a3, s19
    s.addi       s19, s15, #5248
    vf.add       v4, v0, v1
    s.addi       s20, s15, #1152
    s.addi       s29, s15, #5312
    a.vwrite     a4, s21, v4
    a.vread      v0, a0, s28
    a.vread      v1, a3, s22
    s.addi       s21, s15, #1216
    vf.add       v4, v0, v1
    s.addi       s22, s15, #5376
    s.addi       s28, s15, #1280
    a.vwrite     a4, s23, v4
    a.vread      v0, a0, s30
    a.vread      v1, a3, s17
    s.addi       s17, s15, #5440
    vf.add       v4, v0, v1
    s.addi       s23, s15, #1344
    s.addi       s30, s15, #5504
    a.vwrite     a4, s24, v4
    v.ld.w       v0, [s25, #0]
    s.addi       s24, s15, #1408
    s.addi       s25, s15, #5568
    v.st.w       [s7, #0], v0
    s.addi       s7, s15, #1472
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s15, #5632
    v.st.w       [s27, #0], v0
    s.addi       s27, s15, #1536
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s15, #5696
    v.st.w       [s20, #0], v0
    s.addi       s20, s15, #1600
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s15, #5760
    v.st.w       [s21, #0], v0
    s.addi       s21, s15, #1664
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s15, #5824
    v.st.w       [s28, #0], v0
    s.addi       s28, s15, #1728
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s15, #5888
    v.st.w       [s23, #0], v0
    s.addi       s23, s15, #1792
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s15, #5952
    v.st.w       [s24, #0], v0
    s.addi       s24, s15, #1856
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s15, #6016
    v.st.w       [s7, #0], v0
    s.addi       s7, s15, #1920
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s15, #6080
    v.st.w       [s27, #0], v0
    s.addi       s27, s15, #1984
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s15, #6144
    v.st.w       [s20, #0], v0
    s.addi       s20, s15, #2048
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s15, #6208
    v.st.w       [s21, #0], v0
    s.addi       s21, s15, #2112
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s15, #6272
    v.st.w       [s28, #0], v0
    s.addi       s28, s15, #2176
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s15, #6336
    v.st.w       [s23, #0], v0
    s.addi       s23, s15, #2240
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s15, #6400
    v.st.w       [s24, #0], v0
    s.addi       s24, s15, #2304
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s15, #6464
    v.st.w       [s7, #0], v0
    s.addi       s7, s15, #2368
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s15, #6528
    v.st.w       [s27, #0], v0
    fence.acq_rel.device
    s.addi       s27, s15, #2432
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s15, #6592
    v.st.w       [s20, #0], v0
    s.addi       s20, s15, #2496
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s15, #6656
    v.st.w       [s21, #0], v0
    s.addi       s21, s15, #2560
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s15, #6720
    v.st.w       [s28, #0], v0
    s.addi       s28, s15, #2624
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s15, #6784
    v.st.w       [s23, #0], v0
    s.addi       s23, s15, #2688
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s15, #6848
    v.st.w       [s24, #0], v0
    s.addi       s24, s15, #2752
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s15, #6912
    v.st.w       [s7, #0], v0
    s.addi       s7, s15, #2816
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s15, #6976
    v.st.w       [s27, #0], v0
    s.addi       s27, s15, #2880
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s15, #7040
    v.st.w       [s20, #0], v0
    s.addi       s20, s15, #2944
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s15, #7104
    s.addi       s31, s15, #3008
    v.st.w       [s21, #0], v0
    s.movz       s21, #0
    v.ld.w       v0, [s22, #0]
    s.movz       s22, #0
    v.st.w       [s28, #0], v0
    s.movz       s28, #1
    v.ld.w       v0, [s17, #0]
    s.movz       s17, #1
    v.st.w       [s23, #0], v0
    s.movz       s23, #2
    v.ld.w       v0, [s30, #0]
    s.movz       s30, #2
    v.st.w       [s24, #0], v0
    s.movz       s24, #3
    v.ld.w       v0, [s25, #0]
    s.movz       s25, #3
    v.st.w       [s7, #0], v0
    s.movz       s7, #4
    v.ld.w       v0, [s26, #0]
    s.movz       s26, #4
    v.st.w       [s27, #0], v0
    s.movz       s27, #5
    v.ld.w       v0, [s19, #0]
    s.movz       s19, #5
    v.st.w       [s20, #0], v0
    s.movz       s20, #6
    v.ld.w       v0, [s29, #0]
    s.movz       s29, #6
    v.st.w       [s31, #0], v0
    fence.acq_rel.device
    a.vread      v0, a4, s21
    s.movz       s21, #7
    a.vwrite     a0, s22, v0
    a.vread      v0, a4, s28
    s.movz       s22, #7
    a.vwrite     a0, s17, v0
    a.vread      v0, a4, s23
    s.movz       s17, #8
    a.vwrite     a0, s30, v0
    a.vread      v0, a4, s24
    s.movz       s23, #8
    a.vwrite     a0, s25, v0
    a.vread      v0, a4, s7
    s.movz       s7, #9
    a.vwrite     a0, s26, v0
    a.vread      v0, a4, s27
    s.movz       s24, #9
    a.vwrite     a0, s19, v0
    a.vread      v0, a4, s20
    s.movz       s19, #10
    a.vwrite     a0, s29, v0
    a.vread      v0, a4, s21
    s.movz       s20, #10
    a.vwrite     a0, s22, v0
    a.vread      v0, a4, s17
    s.movz       s17, #11
    a.vwrite     a0, s23, v0
    a.vread      v0, a4, s7
    s.movz       s7, #11
    a.vwrite     a0, s24, v0
    a.vread      v0, a4, s19
    s.movz       s19, #12
    a.vwrite     a0, s20, v0
    a.vread      v0, a4, s17
    s.movz       s17, #12
    a.vwrite     a0, s7, v0
    a.vread      v0, a4, s19
    s.movz       s7, #13
    a.vwrite     a0, s17, v0
    s.movz       s17, #13
    a.vread      v0, a4, s7
    s.movz       s7, #14
    a.vwrite     a0, s17, v0
    s.movz       s17, #14
    a.vread      v0, a4, s7
    s.movz       s7, #15
    a.vwrite     a0, s17, v0
    s.movz       s17, #15
    a.vread      v0, a4, s7
    s.add        s7, s13, s4
    s.movz       s19, #1
    a.vwrite     a0, s17, v0
    s.mov        s13, s7
    br.nz        s19, for_6
endfor_7:
    s.movz       s1, #0
    s.mul        s2, s12, s16
    s.muli       s5, s3, #4                      // a runtime tile origin, x4
    s.movz       s6, #0
    s.add        s7, s1, s3                      // the tile origin
    s.muli       s1, s8, #512                    // a runtime tile origin, x512
    s.add        s3, s6, s8                      // the tile origin
    v.splat      v0, s7
    s.movz       s6, #128
    s.muli       s7, s2, #4                      // a runtime tile origin, x4
    v.splat      v1, s3
    v.add        v4, v2, v0
    v.splat      v0, s6
    s.addi       s2, s3, #1
    s.add        s6, s11, s5                     // the tile origin
    v.splat      v2, s12
    v.splat      v5, s4
    v.cmp.lt     p1, v1, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s2
    s.addi       s2, s3, #2
    s.add        s4, s6, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    p.and        p3, p1, p2
    v.cmp.lt     p1, v2, v5
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s2
    s.addi       s2, s3, #3
    s.add        s5, s4, s7                      // the tile origin
    a.vread      v1, a0, s1
    p.and        p5, p3, p1
    s.movz       s1, #1
    p.and        p3, p4, p2
    v.splat      v2, s2
    s.addi       s2, s3, #4
    @p5 v.st.w       [s5, #0], v1
    v.cmp.lt     p4, v0, v3
    a.vread      v0, a0, s1
    s.addi       s1, s5, #512                    // row 1
    p.and        p5, p3, p1
    s.movz       s4, #2
    p.and        p3, p4, p2
    v.splat      v1, s2
    s.addi       s2, s3, #5
    s.addi       s6, s5, #1024                   // row 2
    @p5 v.st.w       [s1, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s4
    p.and        p5, p3, p1
    s.movz       s1, #3
    p.and        p3, p4, p2
    v.splat      v2, s2
    s.addi       s2, s3, #6
    s.addi       s4, s5, #1536                   // row 3
    p.and        p4, p3, p1
    @p5 v.st.w       [s6, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s1
    s.movz       s1, #4
    p.and        p5, p3, p2
    v.splat      v1, s2
    s.addi       s2, s3, #7
    s.addi       s6, s5, #2048                   // row 4
    p.and        p3, p5, p1
    s.movz       s7, #5
    @p4 v.st.w       [s4, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s1
    p.and        p5, p4, p2
    v.splat      v2, s2
    s.addi       s1, s3, #8
    s.addi       s2, s5, #2560                   // row 5
    p.and        p4, p5, p1
    s.movz       s4, #6
    v.splat      v4, s1
    @p3 v.st.w       [s6, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s7
    p.and        p5, p3, p2
    s.addi       s1, s3, #9
    s.addi       s6, s5, #3072                   // row 6
    p.and        p3, p5, p1
    s.movz       s7, #7
    v.splat      v1, s1
    s.addi       s1, s3, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s4
    p.and        p5, p4, p2
    s.addi       s2, s5, #3584                   // row 7
    p.and        p4, p5, p1
    s.movz       s4, #8
    v.splat      v2, s1
    s.addi       s1, s3, #11
    s.addi       s8, s5, #4096                   // row 8
    @p3 v.st.w       [s6, #0], v0
    v.cmp.lt     p3, v4, v3
    a.vread      v0, a0, s7
    p.and        p5, p3, p2
    s.movz       s6, #9
    p.and        p3, p5, p1
    v.splat      v4, s1
    s.addi       s1, s3, #12
    s.addi       s7, s5, #4608                   // row 9
    s.movz       s9, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v1, v3
    a.vread      v0, a0, s4
    p.and        p5, p4, p2
    v.splat      v1, s1
    p.and        p4, p5, p1
    s.addi       s1, s3, #13
    s.addi       s2, s5, #5120                   // row 10
    s.movz       s4, #11
    v.splat      v5, s1
    @p3 v.st.w       [s8, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s6
    p.and        p5, p3, p2
    s.addi       s1, s3, #14
    p.and        p3, p5, p1
    s.addi       s6, s5, #5632                   // row 11
    s.movz       s8, #12
    v.splat      v2, s1
    s.addi       s1, s5, #6144                   // row 12
    @p4 v.st.w       [s7, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    s.addi       s7, s3, #15
    p.and        p4, p5, p1
    s.movz       s3, #13
    v.splat      v4, s7
    s.addi       s7, s5, #6656                   // row 13
    s.movz       s9, #14
    @p3 v.st.w       [s2, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s4
    p.and        p5, p3, p2
    s.addi       s2, s5, #7168                   // row 14
    p.and        p3, p5, p1
    s.movz       s4, #15
    s.addi       s10, s5, #7680                  // row 15
    @p4 v.st.w       [s6, #0], v0
    v.cmp.lt     p4, v5, v3
    a.vread      v0, a0, s8
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s3
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s7, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    p.and        p2, p5, p1
    @p3 v.st.w       [s2, #0], v0
    a.vread      v0, a0, s4
    @p2 v.st.w       [s10, #0], v0
__rctx_next:
    exit
