    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.movz       s5, #0
    s.rdspecial  s6, role_id
    s.movz       s7, #512
    s.muli       s8, s5, #4
    s.mul        s9, s6, s7
    s.movz       s6, #32
    s.movz       s7, #16
    s.movz       s10, #64
    s.movz       s11, #4
    .li       s12, #68719476737
    s.ld.d       s13, [s2, #32]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    .li       s2, #2207613190144
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #0
    s.movz       s18, #0
    s.movz       s19, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.ld.d       s23, [s1, #0]                   // in_out_ptr0: device_ptr64 at arg_base+0
    s.add        s1, s13, s9                     // this context's own scratch
    s.movz       s9, #0
    s.addi       s13, s1, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s24, #0
    s.movz       s25, #0
    s.movz       s26, #0
    s.movz       s27, #0
    s.movz       s28, #0
    s.movz       s29, #0
    s.movz       s30, #0
    s.st.d       [s13, #0], s3
    s.addi       s31, s1, #256                   // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.movz       s32, #0
    s.movz       s33, #0
    s.movz       s34, #0
    s.movz       s35, #0
    s.movz       s36, #0
    s.movz       s37, #0
    s.movz       s38, #0
    s.movz       s39, #0
    s.st.d       [s13, #8], s6
    s.movz       s6, #32
    s.movz       s40, #0
    s.movz       s41, #0
    s.movz       s42, #0
    s.movz       s43, #0
    s.st.d       [s13, #16], s7
    s.movz       s7, #16
    s.st.d       [s13, #48], s10
    s.movz       s10, #64
    s.st.d       [s13, #56], s11
    s.movz       s11, #4
    s.st.d       [s13, #88], s12
    .li       s12, #68719476737
    s.st.d       [s13, #104], s2
    .li       s2, #2207613190144
    fence.release.device
    td.load      d0, [s13]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.splat      v0, s4
    v.movi       v1, #0
    v.movi       v2, #15
    v.iota       v3                              // arange(0, VLEN)
    v.sub        v4, v1, v0
    v.cmp.lt     p1, v0, v1
    v.splat      v5, s5
    @p1 v.sel        v6, v4, v0
    v.iota       v0                              // arange(0, VLEN)
    s.muli       s13, s4, #64
    v.and        v4, v6, v2
    v.add        v2, v5, v0
    v.movi       v0, #0
    v.sub        v5, v1, v4
    v.splat      v6, s4
    v.movi       v7, #0
    @p1 v.sel        v8, v5, v4
    v.cmp.ge     p1, v2, v0
    v.cmpi.lt    p2, v2, #16
    v.cmp.ge     p3, v6, v7
    s.add        s44, s3, s13
    p.and        p4, p1, p2
    s.add        s3, s44, s8
    s.st.d       [s31, #0], s23
    v.movi       v0, #16
    s.movz       s8, #0
    v.cmpi.lt    p1, v6, #32
    v.cmp.lt     p2, v3, v0
    s.movz       s13, #0
    v.movi       v0, #-1
    p.and        p5, p3, p1
    v.movi       v2, #16
    p.and        p1, p4, p5
    s.st.d       [s31, #8], s6
    v.mul        v4, v8, v0
    s.muli       s6, s5, #4
    v.sub        v0, v1, v2
    v.cmp.lt     p3, v2, v1
    @p3 v.sel        v1, v0, v2
    s.st.d       [s31, #16], s7
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.add        v1, v3, v0
    s.st.d       [s31, #48], s10
    v.movi       v0, #0
    v.movi       v2, #0
    s.st.d       [s31, #56], s11
    v.extract    s7, v1, #0
    s.shli       s10, s7, #32
    s.st.d       [s31, #88], s12
    s.ashri      s7, s10, #32
    s.st.d       [s31, #104], s2
    s.lshri      s2, s7, #32
    fence.release.device
    td.load      d1, [s31]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.extract    s10, v1, #1
    v.extract    s11, v1, #2
    s.shli       s12, s10, #32
    s.shli       s10, s11, #32
    s.ashri      s11, s12, #32
    v.extract    s12, v1, #3
    s.lshri      s31, s11, #32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s3, #0]
    v.insert     v0, s7, #0
    v.insert     v2, s2, #0
    s.ashri      s2, s10, #32
    v.insert     v0, s11, #1
    v.insert     v2, s31, #1
    s.shli       s3, s12, #32
    s.lshri      s7, s2, #32
    v.extract    s10, v1, #4
    s.ashri      s11, s3, #32
    v.insert     v0, s2, #2
    v.insert     v2, s7, #2
    s.shli       s2, s10, #32
    s.lshri      s3, s11, #32
    v.extract    s7, v1, #5
    s.ashri      s10, s2, #32
    v.insert     v0, s11, #3
    v.insert     v2, s3, #3
    s.shli       s2, s7, #32
    s.lshri      s3, s10, #32
    v.extract    s7, v1, #6
    s.ashri      s11, s2, #32
    v.insert     v0, s10, #4
    v.insert     v2, s3, #4
    s.shli       s2, s7, #32
    s.lshri      s3, s11, #32
    v.extract    s7, v1, #7
    s.ashri      s10, s2, #32
    v.insert     v0, s11, #5
    v.insert     v2, s3, #5
    s.shli       s2, s7, #32
    s.lshri      s3, s10, #32
    v.extract    s7, v1, #8
    s.ashri      s11, s2, #32
    v.insert     v0, s10, #6
    v.insert     v2, s3, #6
    s.shli       s2, s7, #32
    s.lshri      s3, s11, #32
    v.extract    s7, v1, #9
    s.ashri      s10, s2, #32
    v.insert     v0, s11, #7
    v.insert     v2, s3, #7
    s.shli       s2, s7, #32
    s.lshri      s3, s10, #32
    v.extract    s7, v1, #10
    s.ashri      s11, s2, #32
    v.insert     v0, s10, #8
    v.insert     v2, s3, #8
    s.shli       s2, s7, #32
    s.lshri      s3, s11, #32
    v.extract    s7, v1, #11
    s.ashri      s10, s2, #32
    v.insert     v0, s11, #9
    v.insert     v2, s3, #9
    s.shli       s2, s7, #32
    s.lshri      s3, s10, #32
    v.extract    s7, v1, #12
    s.ashri      s11, s2, #32
    v.insert     v0, s10, #10
    v.insert     v2, s3, #10
    s.shli       s2, s7, #32
    s.lshri      s3, s11, #32
    v.extract    s7, v1, #13
    s.ashri      s10, s2, #32
    v.insert     v0, s11, #11
    v.insert     v2, s3, #11
    s.shli       s2, s7, #32
    s.lshri      s3, s10, #32
    v.extract    s7, v1, #14
    s.ashri      s11, s2, #32
    v.insert     v0, s10, #12
    v.insert     v2, s3, #12
    s.shli       s2, s7, #32
    s.lshri      s3, s11, #32
    v.extract    s7, v1, #15
    s.ashri      s10, s2, #32
    v.insert     v0, s11, #13
    v.insert     v2, s3, #13
    s.shli       s2, s7, #32
    s.lshri      s3, s10, #32
    s.ashri      s7, s2, #32
    v.insert     v0, s10, #14
    v.insert     v2, s3, #14
    s.lshri      s2, s7, #32
    v.insert     v0, s7, #15
    v.insert     v2, s2, #15
    v.movi       v1, #0
    v.extract    s2, v0, #0
    v.extract    s3, v2, #0
    v.extract    s7, v2, #1
    s.shli       s10, s3, #32
    v.extract    s3, v0, #1
    s.or         s11, s2, s10
    s.shli       s2, s7, #32
    s.cmp.le     s7, s11, s14
    v.extract    s10, v2, #2
    s.or         s11, s3, s2
    v.insert     v1, s7, #0
    v.extract    s2, v0, #2
    s.shli       s3, s10, #32
    s.cmp.le     s7, s11, s15
    v.extract    s10, v2, #3
    s.or         s11, s2, s3
    v.insert     v1, s7, #1
    v.extract    s2, v0, #3
    s.shli       s3, s10, #32
    s.cmp.le     s7, s11, s16
    v.extract    s10, v2, #4
    s.or         s11, s2, s3
    v.insert     v1, s7, #2
    v.extract    s2, v0, #4
    s.shli       s3, s10, #32
    s.cmp.le     s7, s11, s17
    v.extract    s10, v2, #5
    s.or         s11, s2, s3
    v.insert     v1, s7, #3
    v.extract    s2, v0, #5
    s.shli       s3, s10, #32
    s.cmp.le     s7, s11, s18
    v.extract    s10, v2, #6
    s.or         s11, s2, s3
    v.insert     v1, s7, #4
    v.extract    s2, v0, #6
    s.shli       s3, s10, #32
    s.cmp.le     s7, s11, s19
    v.extract    s10, v2, #7
    s.or         s11, s2, s3
    v.insert     v1, s7, #5
    v.extract    s2, v0, #7
    s.shli       s3, s10, #32
    s.cmp.le     s7, s11, s20
    v.extract    s10, v2, #8
    s.or         s11, s2, s3
    v.insert     v1, s7, #6
    v.extract    s2, v0, #8
    s.shli       s3, s10, #32
    s.cmp.le     s7, s11, s21
    v.extract    s10, v2, #9
    s.or         s11, s2, s3
    v.insert     v1, s7, #7
    v.extract    s2, v0, #9
    s.shli       s3, s10, #32
    s.cmp.le     s7, s11, s22
    v.extract    s10, v2, #10
    s.or         s11, s2, s3
    v.insert     v1, s7, #8
    v.extract    s2, v0, #10
    s.shli       s3, s10, #32
    s.cmp.le     s7, s11, s9
    v.extract    s9, v2, #11
    s.or         s10, s2, s3
    v.insert     v1, s7, #9
    v.extract    s2, v0, #11
    s.shli       s3, s9, #32
    s.cmp.le     s7, s10, s24
    v.extract    s9, v2, #12
    s.or         s10, s2, s3
    v.insert     v1, s7, #10
    v.extract    s2, v0, #12
    s.shli       s3, s9, #32
    s.cmp.le     s7, s10, s25
    v.extract    s9, v2, #13
    s.or         s10, s2, s3
    v.insert     v1, s7, #11
    v.extract    s2, v0, #13
    s.shli       s3, s9, #32
    s.cmp.le     s7, s10, s26
    v.extract    s9, v2, #14
    s.or         s10, s2, s3
    v.insert     v1, s7, #12
    v.extract    s2, v0, #14
    s.shli       s3, s9, #32
    s.cmp.le     s7, s10, s27
    v.extract    s9, v2, #15
    s.or         s10, s2, s3
    v.insert     v1, s7, #13
    v.extract    s2, v0, #15
    s.shli       s3, s9, #32
    s.cmp.le     s7, s10, s28
    s.or         s9, s2, s3
    v.insert     v1, s7, #14
    s.cmp.le     s2, s9, s29
    v.movi       v0, #0
    v.insert     v1, s2, #15
    v.movi       v2, #0
    .li       s2, #4286578688
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p1, v1, v0
    v.movi       v0, #1
    @p1 v.sel        v1, v2, v5
    v.movi       v6, #0
    v.movi       v7, #0
    vf.add       v8, v4, v1
    v.movi       v1, #1
    v.movi       v4, #0
    v.movi       v9, #1
    v.movi       v10, #0
    vf.cmp.eq    p1, v8, v5
    @p1 v.sel        v11, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.cmp.eq     p1, v11, v7
    @p1 v.sel        v7, v1, v4
    @p1 v.sel        v1, v9, v10
    v.movi       v4, #0
    v.extract    s2, v7, #0
    v.movi       v7, #0
    s.lshri      s3, s2, #32
    v.extract    s7, v1, #1
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s2, #0
    v.insert     v7, s3, #0
    s.lshri      s2, s7, #32
    v.extract    s3, v1, #2
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s7, #1
    v.insert     v7, s2, #1
    s.lshri      s2, s3, #32
    v.extract    s7, v1, #3
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s3, #2
    v.insert     v7, s2, #2
    s.lshri      s2, s7, #32
    v.extract    s3, v1, #4
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s7, #3
    v.insert     v7, s2, #3
    s.lshri      s2, s3, #32
    v.extract    s7, v1, #5
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s3, #4
    v.insert     v7, s2, #4
    s.lshri      s2, s7, #32
    v.extract    s3, v1, #6
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s7, #5
    v.insert     v7, s2, #5
    s.lshri      s2, s3, #32
    v.extract    s7, v1, #7
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s3, #6
    v.insert     v7, s2, #6
    s.lshri      s2, s7, #32
    v.extract    s3, v1, #8
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s7, #7
    v.insert     v7, s2, #7
    s.lshri      s2, s3, #32
    v.extract    s7, v1, #9
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s3, #8
    v.insert     v7, s2, #8
    s.lshri      s2, s7, #32
    v.extract    s3, v1, #10
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s7, #9
    v.insert     v7, s2, #9
    s.lshri      s2, s3, #32
    v.extract    s7, v1, #11
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s3, #10
    v.insert     v7, s2, #10
    s.lshri      s2, s7, #32
    v.extract    s3, v1, #12
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s7, #11
    v.insert     v7, s2, #11
    s.lshri      s2, s3, #32
    v.extract    s7, v1, #13
    @p1 v.sel        v1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.insert     v4, s3, #12
    v.insert     v7, s2, #12
    s.lshri      s2, s7, #32
    v.extract    s3, v1, #14
    @p1 v.sel        v1, v0, v6
    v.insert     v4, s7, #13
    v.insert     v7, s2, #13
    s.lshri      s2, s3, #32
    v.extract    s7, v1, #15
    v.insert     v4, s3, #14
    v.insert     v7, s2, #14
    s.lshri      s2, s7, #32
    v.insert     v4, s7, #15
    v.insert     v7, s2, #15
    v.movi       v0, #0
    v.extract    s2, v4, #0
    v.extract    s3, v7, #0
    v.extract    s7, v7, #1
    s.shli       s9, s3, #32
    v.extract    s3, v4, #1
    s.or         s10, s2, s9
    s.shli       s2, s7, #32
    s.cmp.ne     s7, s10, s30
    v.extract    s9, v7, #2
    s.or         s10, s3, s2
    v.insert     v0, s7, #0
    v.extract    s2, v4, #2
    s.shli       s3, s9, #32
    s.cmp.ne     s7, s10, s1
    v.extract    s1, v7, #3
    s.or         s9, s2, s3
    v.insert     v0, s7, #1
    v.extract    s2, v4, #3
    s.shli       s3, s1, #32
    s.cmp.ne     s1, s9, s32
    v.extract    s7, v7, #4
    s.or         s9, s2, s3
    v.insert     v0, s1, #2
    v.extract    s1, v4, #4
    s.shli       s2, s7, #32
    s.cmp.ne     s3, s9, s33
    v.extract    s7, v7, #5
    s.or         s9, s1, s2
    v.insert     v0, s3, #3
    v.extract    s1, v4, #5
    s.shli       s2, s7, #32
    s.cmp.ne     s3, s9, s34
    v.extract    s7, v7, #6
    s.or         s9, s1, s2
    v.insert     v0, s3, #4
    v.extract    s1, v4, #6
    s.shli       s2, s7, #32
    s.cmp.ne     s3, s9, s35
    v.extract    s7, v7, #7
    s.or         s9, s1, s2
    v.insert     v0, s3, #5
    v.extract    s1, v4, #7
    s.shli       s2, s7, #32
    s.cmp.ne     s3, s9, s36
    v.extract    s7, v7, #8
    s.or         s9, s1, s2
    v.insert     v0, s3, #6
    v.extract    s1, v4, #8
    s.shli       s2, s7, #32
    s.cmp.ne     s3, s9, s37
    v.extract    s7, v7, #9
    s.or         s9, s1, s2
    v.insert     v0, s3, #7
    v.extract    s1, v4, #9
    s.shli       s2, s7, #32
    s.cmp.ne     s3, s9, s38
    v.extract    s7, v7, #10
    s.or         s9, s1, s2
    v.insert     v0, s3, #8
    @p2 v.sel        v1, v8, v5
    v.extract    s1, v4, #10
    s.shli       s2, s7, #32
    s.cmp.ne     s3, s9, s39
    v.extract    s7, v7, #11
    s.or         s9, s1, s2
    v.insert     v0, s3, #9
    vf.reduce.max.b v5, v1
    v.extract    s1, v4, #11
    s.shli       s2, s7, #32
    s.cmp.ne     s3, s9, s40
    vf.cmp.uo    p1, v1, v1
    v.extract    s7, v7, #12
    s.or         s9, s1, s2
    v.insert     v0, s3, #10
    v.movi       v1, #1
    v.movi       v6, #0
    v.movi       v9, #0
    v.extract    s1, v4, #12
    @p1 v.sel        v10, v1, v6
    s.shli       s2, s7, #32
    s.cmp.ne     s3, s9, s41
    v.reduce.or.b v1, v10
    v.extract    s7, v7, #13
    s.or         s9, s1, s2
    v.cmp.ne     p1, v1, v9
    v.insert     v0, s3, #11
    .li       s1, #2143289344
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v6, #0
    v.extract    s1, v4, #13
    @p1 v.sel        v9, v1, v5
    s.shli       s2, s7, #32
    s.cmp.ne     s3, s9, s42
    vf.add       v1, v9, v6
    v.extract    s7, v7, #14
    s.or         s9, s1, s2
    v.insert     v0, s3, #12
    .li       s1, #1069066811
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s1, v1, #0
    v.extract    s2, v4, #14
    v.splat      v1, s1
    s.shli       s1, s7, #32
    s.cmp.ne     s3, s9, s43
    vf.sub       v9, v8, v1
    .li       s7, #1060205080
    v.splat      v1, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s7, v7, #15
    s.or         s9, s2, s1
    v.insert     v0, s3, #13
    vf.mul       v7, v9, v5
    v.extract    s1, v4, #15
    s.shli       s2, s7, #32
    s.cmp.ne     s3, s9, s8
    s.or         s7, s1, s2
    v.exp2.approx v4, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v9, v5, v7                  // the exact rounding error of x*log2(e)
    v.insert     v0, s3, #14
    s.shli       s1, s4, #4                      // x16 as a shift
    s.cmp.ne     s2, s7, s13
    s.shli       s3, s1, #2                      // element offset -> bytes (x4)
    vf.mul       v5, v8, v1
    v.insert     v0, s2, #15
    v.movi       v1, #0
    v.movi       v7, #0
    v.movi       v8, #0
    s.add        s2, s23, s3                     // &in_out_ptr0[...]
    p.not        p1, p2
    v.cmp.ne     p3, v0, v1
    s.muli       s7, s4, #64
    v.cmp.ne     p4, v7, v8
    p.and        p5, p2, p3
    v.splat      v0, s5
    v.iota       v1                              // arange(0, VLEN)
    s.add        s5, s23, s7
    p.and        p3, p1, p4
    v.add        v7, v0, v1
    s.add        s7, s5, s6
    v.movi       v0, #1
    v.movi       v1, #0
    p.or         p1, p5, p3
    v.movi       v8, #0
    v.cmpi.lt    p3, v7, #16
    vf.fma       v9, v4, v5, v4                  // 2**t * 2**d
    v.cmp.ge     p4, v7, v8
    p.and        p5, p4, p3
    @p1 v.sel        v5, v0, v1
    v.splat      v0, s4
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v1, v9, v4
    v.reduce.or  s4, v5
    v.movi       v4, #0
    vf.add       v5, v1, v2
    @p2 v.st.w       [s2, #0], v1
    fence.acq_rel.device
    v.splat      v1, s4
    v.cmp.ge     p1, v0, v4
    @p2 v.sel        v4, v5, v2
    v.cmpi.lt    p3, v0, #32
    p.and        p4, p1, p3
    vf.reduce.add.b v0, v4
    .li       s2, #1065353216
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    p.and        p1, p5, p4
    vf.add       v5, v0, v6
    v.movi       v0, #0
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.eq     p3, v1, v0
    v.extract    s2, v5, #0
    @p3 v.sel        v0, v6, v7
    v.splat      v1, s2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s7, #0]
    v.extract    s2, v0, #0
    v.rcp.approx v0, v1                          // ISA 8.8: <= 2**-22 relative
    v.splat      v6, s2
    v.movi       v7, #0
    v.splat      v8, s1
    s.add        s1, s23, s3                     // &in_out_ptr0[...]
    v.cmp.ne     p1, v6, v7
    v.add        v6, v3, v8
    vf.fms       v3, v1, v0, v4
    vf.fms       v1, v0, v3, v0
    vf.neg       v3, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v3, v3
    @p3 v.sel        v1, v3, v0
    vf.mul       v0, v5, v1                      // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v1, v2, v0
    @p2 v.st.w       [s1, #0], v1
__rctx_next:
    exit
