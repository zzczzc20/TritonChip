module mon;
 initial begin
  #300;
  repeat(30) begin @(posedge tb_line_axi_hbm8.clk); #2;
   $display("t=%0t rst=%b rv=%b rr=%b iv=%b act=%b sent=%b wr=%b arv=%b rvalid=%b rid=%0d rlast=%b rbeat0=%0d fault=%b idle=%b arc=%0d",
    $time, tb_line_axi_hbm8.rst_n, tb_line_axi_hbm8.req_valid, tb_line_axi_hbm8.req_ready, tb_line_axi_hbm8.dut.issue_valid,
    tb_line_axi_hbm8.dut.active, tb_line_axi_hbm8.dut.sent, tb_line_axi_hbm8.dut.writing, tb_line_axi_hbm8.m_arvalid,
    tb_line_axi_hbm8.m_rvalid, tb_line_axi_hbm8.m_rid, tb_line_axi_hbm8.m_rlast, tb_line_axi_hbm8.dut.rbeat[0], tb_line_axi_hbm8.fault, tb_line_axi_hbm8.idle, tb_line_axi_hbm8.ar_count);
  end
 end
endmodule
