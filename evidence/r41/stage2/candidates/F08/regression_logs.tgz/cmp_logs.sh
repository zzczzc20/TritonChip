#!/bin/bash
# cmp_logs.sh BASE_LOG CAND_LOG -- compare run_test.sh result lines (name, verdict, stats)
norm() { grep -E "^  [^ -].* (PASS|FAIL|ERROR|NO RESULT)( |$)" "$1" | sed "s/  */ /g"; }
b=$(mktemp); c=$(mktemp)
norm "$1" > $b; norm "$2" > $c
echo "base $(wc -l < $b) results ($(grep -c ' PASS' $b) PASS), candidate $(wc -l < $c) results ($(grep -c ' PASS' $c) PASS)"
if diff $b $c > /dev/null; then echo "IDENTICAL result lines (incl. cycles=)"; else diff $b $c | head -20; fi
rm -f $b $c
