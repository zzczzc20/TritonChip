    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #6144
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.movi       v3, #1
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v0, v5, v1
    v.sub        v4, v2, v6
    v.cmp.lt     p2, v6, v2
    v.movi       v5, #0
    @p2 v.sel        v7, v4, v6
    v.movi       v4, #0
    s.movz       s4, #31
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s6, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
idiv_1:
    v.splat      v8, s4
    v.shl        v9, v4, v3
    v.cmp.lt     p3, v4, v2
    v.lshr       v10, v7, v8
    v.shl        v11, v3, v8
    s.subi       s1, s4, #1
    v.and        v8, v10, v3
    s.movz       s7, #0
    v.or         v10, v9, v8
    v.cmp.geu    p4, v10, v0
    p.or         p5, p3, p4
    v.sub        v8, v10, v0
    @p5 v.sel        v9, v11, v2
    @p5 v.sel        v11, v8, v10
    v.or         v8, v5, v9
    v.mov        v4, v11
    v.mov        v5, v8
    s.mov        s4, s1
    s.cmp.ge     s1, s4, s7
    br.nz        s1, idiv_1
    v.movi       v0, #0
    v.sub        v3, v2, v5
    p.xor        p3, p2, p1
    v.sub        v2, v0, v6
    v.sub        v4, v0, v1
    v.cmp.lt     p1, v6, v0
    v.cmp.lt     p2, v1, v0
    @p3 v.sel        v7, v3, v5
    v.movi       v3, #1
    @p1 v.sel        v5, v2, v6
    @p2 v.sel        v2, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v8, s1
    v.shl        v9, v4, v3
    v.cmp.lt     p2, v4, v0
    v.lshr       v10, v5, v8
    v.shl        v11, v3, v8
    s.subi       s4, s1, #1
    v.and        v8, v10, v3
    s.movz       s7, #0
    v.or         v10, v9, v8
    v.cmp.geu    p3, v10, v2
    p.or         p4, p2, p3
    v.sub        v8, v10, v2
    @p4 v.sel        v9, v11, v0
    @p4 v.sel        v11, v8, v10
    v.or         v8, v1, v9
    v.mov        v4, v11
    v.mov        v1, v8
    s.mov        s1, s4
    s.cmp.ge     s4, s1, s7
    br.nz        s4, idiv_2
    v.movi       v1, #-3
    v.sub        v2, v0, v4
    v.movi       v0, #4
    v.add        v3, v7, v1
    @p1 v.sel        v1, v2, v4
    v.movi       v2, #1
    v.extract    s1, v3, #0
    v.mul        v4, v1, v0
    v.movi       v0, #2
    v.movi       v1, #3
    s.shli       s4, s1, #32
    v.extract    s1, v3, #1
    s.ashri      s7, s4, #32
    v.add        v5, v4, v2
    v.add        v2, v4, v0
    v.add        v0, v4, v1
    v.movi       v1, #0
    v.movi       v8, #0
    s.shli       s4, s1, #32
    s.lshri      s1, s7, #32
    v.extract    s8, v3, #2
    s.ashri      s9, s4, #32
    v.ld.gather.h v9, [s5, v4]                   // index is in elements (ISA sec 9.1)
    s.shli       s4, s8, #32
    s.lshri      s8, s9, #32
    s.ashri      s10, s4, #32
    s.movz       s4, #4
    s.movz       s4, #1
    s.movz       s4, #2
    s.movz       s4, #3
    .li       s4, #-3
    v.ld.gather.h v4, [s5, v5]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v5, v9
    v.ld.gather.h v9, [s5, v2]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v4
    v.ld.gather.h v4, [s5, v0]                   // index is in elements (ISA sec 9.1)
    v.insert     v1, s7, #0
    v.insert     v8, s1, #0
    v.extract    s1, v3, #3
    v.insert     v1, s9, #1
    v.insert     v8, s8, #1
    s.shli       s4, s1, #32
    s.lshri      s1, s10, #32
    v.extract    s5, v3, #4
    s.ashri      s7, s4, #32
    v.insert     v1, s10, #2
    v.insert     v8, s1, #2
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v3, #5
    s.ashri      s8, s1, #32
    v.insert     v1, s7, #3
    v.insert     v8, s4, #3
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v3, #6
    s.ashri      s7, s1, #32
    v.insert     v1, s8, #4
    v.insert     v8, s4, #4
    s.lshri      s1, s7, #32
    v.insert     v1, s7, #5
    v.insert     v8, s1, #5
    vf.cvt.bf16.f32 v0, v9
    s.shli       s1, s5, #32
    vf.cvt.bf16.f32 v9, v4
    v.extract    s4, v3, #7
    s.ashri      s5, s1, #32
    s.shli       s1, s4, #32
    s.lshri      s4, s5, #32
    v.extract    s7, v3, #8
    s.ashri      s8, s1, #32
    v.insert     v1, s5, #6
    v.insert     v8, s4, #6
    s.shli       s1, s7, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v3, #9
    s.ashri      s7, s1, #32
    v.insert     v1, s8, #7
    v.insert     v8, s4, #7
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v3, #10
    s.ashri      s8, s1, #32
    v.insert     v1, s7, #8
    v.insert     v8, s4, #8
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v3, #11
    s.ashri      s7, s1, #32
    v.insert     v1, s8, #9
    v.insert     v8, s4, #9
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v3, #12
    s.ashri      s8, s1, #32
    v.insert     v1, s7, #10
    v.insert     v8, s4, #10
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v3, #13
    s.ashri      s7, s1, #32
    v.insert     v1, s8, #11
    v.insert     v8, s4, #11
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v3, #14
    s.ashri      s8, s1, #32
    v.insert     v1, s7, #12
    v.insert     v8, s4, #12
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v3, #15
    s.ashri      s7, s1, #32
    v.insert     v1, s8, #13
    v.insert     v8, s4, #13
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s1, #32
    v.insert     v1, s7, #14
    v.insert     v8, s4, #14
    s.lshri      s1, s5, #32
    v.insert     v1, s5, #15
    v.insert     v8, s1, #15
    s.movz       s1, #0
    v.extract    s4, v1, #0
    v.extract    s5, v8, #0
    v.extract    s7, v8, #1
    s.shli       s8, s5, #32
    v.movi       v3, #0
    s.or         s5, s4, s8
    v.extract    s4, v1, #1
    s.shli       s8, s7, #32
    s.cmp.ge     s7, s5, s1
    v.extract    s1, v8, #2
    s.or         s5, s4, s8
    s.movz       s4, #0
    v.insert     v3, s7, #0
    v.extract    s7, v1, #2
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s5, s4
    v.extract    s4, v8, #3
    s.or         s5, s7, s8
    s.movz       s7, #0
    v.insert     v3, s1, #1
    v.extract    s1, v1, #3
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s5, s7
    v.extract    s5, v8, #4
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v3, s4, #2
    v.extract    s4, v1, #4
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v8, #5
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v3, s5, #3
    v.extract    s5, v1, #5
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v8, #6
    s.or         s7, s5, s8
    s.movz       s5, #0
    v.insert     v3, s1, #4
    v.extract    s1, v1, #6
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s7, s5
    v.extract    s5, v8, #7
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v3, s4, #5
    v.extract    s4, v1, #7
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v8, #8
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v3, s5, #6
    v.extract    s5, v1, #8
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v8, #9
    s.or         s7, s5, s8
    s.movz       s5, #0
    v.insert     v3, s1, #7
    v.extract    s1, v1, #9
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s7, s5
    v.extract    s5, v8, #10
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v3, s4, #8
    v.extract    s4, v1, #10
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v8, #11
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v3, s5, #9
    v.extract    s5, v1, #11
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v8, #12
    s.or         s7, s5, s8
    s.movz       s5, #0
    v.insert     v3, s1, #10
    v.extract    s1, v1, #12
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s7, s5
    v.extract    s5, v8, #13
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v3, s4, #11
    v.extract    s4, v1, #13
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v8, #14
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v3, s5, #12
    v.extract    s5, v1, #14
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v8, #15
    v.extract    s7, v8, #0
    s.or         s9, s5, s8
    s.movz       s5, #0
    v.insert     v3, s1, #13
    v.extract    s1, v1, #15
    s.shli       s8, s4, #32
    v.extract    s4, v1, #0
    s.shli       s10, s7, #32
    s.cmp.ge     s7, s9, s5
    v.extract    s5, v8, #1
    s.or         s9, s1, s8
    s.movz       s1, #0
    s.or         s8, s4, s10
    s.movz       s4, #128
    v.insert     v3, s7, #14
    v.movi       v4, #0
    v.extract    s7, v1, #1
    s.shli       s10, s5, #32
    s.cmp.ge     s5, s9, s1
    s.cmp.lt     s1, s8, s4
    v.extract    s4, v8, #2
    s.or         s8, s7, s10
    s.movz       s7, #128
    v.insert     v3, s5, #15
    v.insert     v4, s1, #0
    v.extract    s1, v1, #2
    s.shli       s5, s4, #32
    s.cmp.lt     s4, s8, s7
    v.extract    s7, v8, #3
    s.or         s8, s1, s5
    s.movz       s1, #128
    v.insert     v4, s4, #1
    v.extract    s4, v1, #3
    s.shli       s5, s7, #32
    s.cmp.lt     s7, s8, s1
    v.extract    s1, v8, #4
    s.or         s8, s4, s5
    s.movz       s4, #128
    v.insert     v4, s7, #2
    v.extract    s5, v1, #4
    s.shli       s7, s1, #32
    s.cmp.lt     s1, s8, s4
    v.extract    s4, v8, #5
    s.or         s8, s5, s7
    s.movz       s5, #128
    v.insert     v4, s1, #3
    v.extract    s1, v1, #5
    s.shli       s7, s4, #32
    s.cmp.lt     s4, s8, s5
    v.extract    s5, v8, #6
    s.or         s8, s1, s7
    s.movz       s1, #128
    v.insert     v4, s4, #4
    v.extract    s4, v1, #6
    s.shli       s7, s5, #32
    s.cmp.lt     s5, s8, s1
    v.movi       v10, #0
    s.or         s1, s4, s7
    v.insert     v4, s5, #5
    v.cmp.ne     p1, v3, v10
    v.extract    s4, v8, #7
    s.movz       s5, #128
    v.extract    s7, v1, #7
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s1, s5
    v.extract    s1, v8, #8
    s.or         s5, s7, s8
    s.movz       s7, #128
    v.insert     v4, s4, #6
    v.extract    s4, v1, #8
    s.shli       s8, s1, #32
    s.cmp.lt     s1, s5, s7
    v.extract    s5, v8, #9
    s.or         s7, s4, s8
    s.movz       s4, #128
    v.insert     v4, s1, #7
    v.extract    s1, v1, #9
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s7, s4
    v.extract    s4, v8, #10
    s.or         s7, s1, s8
    s.movz       s1, #128
    v.insert     v4, s5, #8
    v.extract    s5, v1, #10
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s7, s1
    v.extract    s1, v8, #11
    s.or         s7, s5, s8
    s.movz       s5, #128
    v.insert     v4, s4, #9
    v.extract    s4, v1, #11
    s.shli       s8, s1, #32
    s.cmp.lt     s1, s7, s5
    v.extract    s5, v8, #12
    s.or         s7, s4, s8
    s.movz       s4, #128
    v.insert     v4, s1, #10
    v.extract    s1, v1, #12
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s7, s4
    v.extract    s4, v8, #13
    s.or         s7, s1, s8
    s.movz       s1, #128
    v.insert     v4, s5, #11
    v.extract    s5, v1, #13
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s7, s1
    v.extract    s1, v8, #14
    s.or         s7, s5, s8
    s.movz       s5, #128
    v.insert     v4, s4, #12
    v.extract    s4, v1, #14
    s.shli       s8, s1, #32
    s.cmp.lt     s1, s7, s5
    v.extract    s5, v8, #15
    v.movi       v3, #-2
    s.or         s7, s4, s8
    s.movz       s4, #128
    v.insert     v4, s1, #13
    v.extract    s1, v1, #15
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s7, s4
    v.add        v1, v7, v3
    s.or         s4, s1, s8
    s.movz       s1, #128
    v.insert     v4, s5, #14
    s.cmp.lt     s5, s4, s1
    v.extract    s1, v1, #0
    v.insert     v4, s5, #15
    v.movi       v3, #0
    v.movi       v8, #-18432
    s.shli       s4, s1, #32
    v.extract    s1, v1, #1
    s.ashri      s5, s4, #32
    v.cmp.ne     p2, v4, v3
    v.add        v3, v6, v8
    v.movi       v4, #0
    v.movi       v8, #0
    s.shli       s4, s1, #32
    p.and        p3, p1, p2
    s.lshri      s1, s5, #32
    v.extract    s7, v1, #2
    s.ashri      s8, s4, #32
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v10, [s3, v3]              // index is in elements (ISA sec 9.1)
    v.insert     v4, s5, #0
    v.insert     v8, s1, #0
    s.shli       s1, s7, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v1, #3
    s.ashri      s7, s1, #32
    v.insert     v4, s8, #1
    v.insert     v8, s4, #1
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v1, #4
    s.ashri      s8, s1, #32
    v.insert     v4, s7, #2
    v.insert     v8, s4, #2
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v1, #5
    s.ashri      s7, s1, #32
    v.insert     v4, s8, #3
    v.insert     v8, s4, #3
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s1, #32
    v.insert     v4, s7, #4
    v.insert     v8, s4, #4
    s.lshri      s1, s5, #32
    v.insert     v4, s5, #5
    vf.cvt.bf16.f32 v3, v10
    v.movi       v10, #0
    .li       s4, #-18432
    v.extract    s4, v1, #6
    v.insert     v8, s1, #5
    s.shli       s1, s4, #32
    @p3 v.sel        v11, v3, v10
    s.ashri      s4, s1, #32
    .li       s1, #-2
    s.lshri      s1, s4, #32
    v.insert     v4, s4, #6
    v.insert     v8, s1, #6
    vf.mul       v3, v11, v5
    v.extract    s1, v1, #7
    v.extract    s4, v1, #8
    s.shli       s5, s1, #32
    s.shli       s1, s4, #32
    s.ashri      s4, s5, #32
    v.extract    s5, v1, #9
    s.lshri      s7, s4, #32
    s.ashri      s8, s1, #32
    v.insert     v4, s4, #7
    v.insert     v8, s7, #7
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v1, #10
    s.ashri      s7, s1, #32
    v.insert     v4, s8, #8
    v.insert     v8, s4, #8
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v1, #11
    s.ashri      s8, s1, #32
    v.insert     v4, s7, #9
    v.insert     v8, s4, #9
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v1, #12
    s.ashri      s7, s1, #32
    v.insert     v4, s8, #10
    v.insert     v8, s4, #10
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v1, #13
    s.ashri      s8, s1, #32
    v.insert     v4, s7, #11
    v.insert     v8, s4, #11
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v1, #14
    s.ashri      s7, s1, #32
    v.insert     v4, s8, #12
    v.insert     v8, s4, #12
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v1, #15
    s.ashri      s8, s1, #32
    v.insert     v4, s7, #13
    v.insert     v8, s4, #13
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    s.ashri      s5, s1, #32
    v.insert     v4, s8, #14
    v.insert     v8, s4, #14
    s.lshri      s1, s5, #32
    v.insert     v4, s5, #15
    v.insert     v8, s1, #15
    s.movz       s1, #0
    v.extract    s4, v4, #0
    v.extract    s5, v8, #0
    v.extract    s7, v8, #1
    s.shli       s8, s5, #32
    v.movi       v1, #0
    s.or         s5, s4, s8
    v.extract    s4, v4, #1
    s.shli       s8, s7, #32
    s.cmp.ge     s7, s5, s1
    v.extract    s1, v8, #2
    s.or         s5, s4, s8
    s.movz       s4, #0
    v.insert     v1, s7, #0
    v.extract    s7, v4, #2
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s5, s4
    v.extract    s4, v8, #3
    s.or         s5, s7, s8
    s.movz       s7, #0
    v.insert     v1, s1, #1
    v.extract    s1, v4, #3
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s5, s7
    v.extract    s5, v8, #4
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v1, s4, #2
    v.extract    s4, v4, #4
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v8, #5
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v1, s5, #3
    v.extract    s5, v4, #5
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v8, #6
    s.or         s7, s5, s8
    s.movz       s5, #0
    v.insert     v1, s1, #4
    v.extract    s1, v4, #6
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s7, s5
    v.extract    s5, v8, #7
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v1, s4, #5
    v.extract    s4, v4, #7
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v8, #8
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v1, s5, #6
    v.extract    s5, v4, #8
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v8, #9
    s.or         s7, s5, s8
    s.movz       s5, #0
    v.insert     v1, s1, #7
    v.extract    s1, v4, #9
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s7, s5
    v.extract    s5, v8, #10
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v1, s4, #8
    v.extract    s4, v4, #10
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v8, #11
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v1, s5, #9
    v.extract    s5, v4, #11
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v8, #12
    s.or         s7, s5, s8
    s.movz       s5, #0
    v.insert     v1, s1, #10
    v.extract    s1, v4, #12
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s7, s5
    v.extract    s5, v8, #13
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v1, s4, #11
    v.extract    s4, v4, #13
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v8, #14
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v1, s5, #12
    v.extract    s5, v4, #14
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v8, #15
    v.extract    s7, v8, #0
    s.or         s9, s5, s8
    s.movz       s5, #0
    v.insert     v1, s1, #13
    v.extract    s1, v4, #15
    s.shli       s8, s4, #32
    v.extract    s4, v4, #0
    s.shli       s10, s7, #32
    s.cmp.ge     s7, s9, s5
    v.extract    s5, v8, #1
    s.or         s9, s1, s8
    s.movz       s1, #0
    s.or         s8, s4, s10
    s.movz       s4, #128
    v.insert     v1, s7, #14
    v.movi       v5, #0
    v.extract    s7, v4, #1
    s.shli       s10, s5, #32
    s.cmp.ge     s5, s9, s1
    s.cmp.lt     s1, s8, s4
    v.extract    s4, v8, #2
    s.or         s8, s7, s10
    s.movz       s7, #128
    v.insert     v1, s5, #15
    v.insert     v5, s1, #0
    v.extract    s1, v4, #2
    s.shli       s5, s4, #32
    s.cmp.lt     s4, s8, s7
    v.extract    s7, v8, #3
    s.or         s8, s1, s5
    s.movz       s1, #128
    v.insert     v5, s4, #1
    v.extract    s4, v4, #3
    s.shli       s5, s7, #32
    s.cmp.lt     s7, s8, s1
    v.extract    s1, v8, #4
    s.or         s8, s4, s5
    s.movz       s4, #128
    v.insert     v5, s7, #2
    v.extract    s5, v4, #4
    s.shli       s7, s1, #32
    s.cmp.lt     s1, s8, s4
    v.extract    s4, v8, #5
    s.or         s8, s5, s7
    s.movz       s5, #128
    v.insert     v5, s1, #3
    v.extract    s1, v4, #5
    s.shli       s7, s4, #32
    s.cmp.lt     s4, s8, s5
    v.extract    s5, v8, #6
    s.or         s8, s1, s7
    s.movz       s1, #128
    v.insert     v5, s4, #4
    v.extract    s4, v4, #6
    s.shli       s7, s5, #32
    s.cmp.lt     s5, s8, s1
    v.movi       v11, #0
    s.or         s1, s4, s7
    v.insert     v5, s5, #5
    v.cmp.ne     p1, v1, v11
    v.extract    s4, v8, #7
    s.movz       s5, #128
    v.extract    s7, v4, #7
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s1, s5
    v.extract    s1, v8, #8
    s.or         s5, s7, s8
    s.movz       s7, #128
    v.insert     v5, s4, #6
    v.extract    s4, v4, #8
    s.shli       s8, s1, #32
    s.cmp.lt     s1, s5, s7
    v.extract    s5, v8, #9
    s.or         s7, s4, s8
    s.movz       s4, #128
    v.insert     v5, s1, #7
    v.extract    s1, v4, #9
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s7, s4
    v.extract    s4, v8, #10
    s.or         s7, s1, s8
    s.movz       s1, #128
    v.insert     v5, s5, #8
    v.extract    s5, v4, #10
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s7, s1
    v.extract    s1, v8, #11
    s.or         s7, s5, s8
    s.movz       s5, #128
    v.insert     v5, s4, #9
    v.extract    s4, v4, #11
    s.shli       s8, s1, #32
    s.cmp.lt     s1, s7, s5
    v.extract    s5, v8, #12
    s.or         s7, s4, s8
    s.movz       s4, #128
    v.insert     v5, s1, #10
    v.extract    s1, v4, #12
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s7, s4
    v.extract    s4, v8, #13
    s.or         s7, s1, s8
    s.movz       s1, #128
    v.insert     v5, s5, #11
    v.extract    s5, v4, #13
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s7, s1
    v.extract    s1, v8, #14
    s.or         s7, s5, s8
    s.movz       s5, #128
    v.insert     v5, s4, #12
    v.extract    s4, v4, #14
    s.shli       s8, s1, #32
    s.cmp.lt     s1, s7, s5
    v.extract    s5, v8, #15
    v.movi       v1, #-1
    s.or         s7, s4, s8
    s.movz       s4, #128
    v.insert     v5, s1, #13
    v.extract    s1, v4, #15
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s7, s4
    v.add        v4, v7, v1
    s.or         s4, s1, s8
    s.movz       s1, #128
    v.insert     v5, s5, #14
    s.cmp.lt     s5, s4, s1
    v.extract    s1, v4, #0
    v.insert     v5, s5, #15
    v.movi       v1, #0
    v.movi       v8, #-12288
    s.shli       s4, s1, #32
    v.extract    s1, v4, #1
    s.ashri      s5, s4, #32
    v.cmp.ne     p2, v5, v1
    v.add        v1, v6, v8
    v.movi       v5, #0
    v.movi       v8, #0
    s.shli       s4, s1, #32
    p.and        p3, p1, p2
    s.lshri      s1, s5, #32
    v.extract    s7, v4, #2
    s.ashri      s8, s4, #32
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v11, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.insert     v5, s5, #0
    v.insert     v8, s1, #0
    s.shli       s1, s7, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v4, #3
    s.ashri      s7, s1, #32
    v.insert     v5, s8, #1
    v.insert     v8, s4, #1
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v4, #4
    s.ashri      s8, s1, #32
    v.insert     v5, s7, #2
    v.insert     v8, s4, #2
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v4, #5
    s.ashri      s7, s1, #32
    v.insert     v5, s8, #3
    v.insert     v8, s4, #3
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    s.ashri      s5, s1, #32
    v.insert     v5, s7, #4
    v.insert     v8, s4, #4
    s.lshri      s1, s5, #32
    v.insert     v5, s5, #5
    vf.cvt.bf16.f32 v1, v11
    .li       s4, #-12288
    v.extract    s4, v4, #6
    v.insert     v8, s1, #5
    s.shli       s1, s4, #32
    @p3 v.sel        v11, v1, v10
    s.ashri      s4, s1, #32
    .li       s1, #-1
    s.lshri      s1, s4, #32
    v.insert     v5, s4, #6
    vf.mul       v1, v11, v2
    v.insert     v8, s1, #6
    vf.add       v2, v3, v1
    v.extract    s1, v4, #7
    v.extract    s4, v4, #8
    s.shli       s5, s1, #32
    s.shli       s1, s4, #32
    s.ashri      s4, s5, #32
    v.extract    s5, v4, #9
    s.lshri      s7, s4, #32
    s.ashri      s8, s1, #32
    v.insert     v5, s4, #7
    v.insert     v8, s7, #7
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v4, #10
    s.ashri      s7, s1, #32
    v.insert     v5, s8, #8
    v.insert     v8, s4, #8
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v4, #11
    s.ashri      s8, s1, #32
    v.insert     v5, s7, #9
    v.insert     v8, s4, #9
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v4, #12
    s.ashri      s7, s1, #32
    v.insert     v5, s8, #10
    v.insert     v8, s4, #10
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v4, #13
    s.ashri      s8, s1, #32
    v.insert     v5, s7, #11
    v.insert     v8, s4, #11
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v4, #14
    s.ashri      s7, s1, #32
    v.insert     v5, s8, #12
    v.insert     v8, s4, #12
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v4, #15
    s.ashri      s8, s1, #32
    v.insert     v5, s7, #13
    v.insert     v8, s4, #13
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    s.ashri      s5, s1, #32
    v.insert     v5, s8, #14
    v.insert     v8, s4, #14
    s.lshri      s1, s5, #32
    v.insert     v5, s5, #15
    v.insert     v8, s1, #15
    s.movz       s1, #0
    v.extract    s4, v5, #0
    v.extract    s5, v8, #0
    v.extract    s7, v8, #1
    s.shli       s8, s5, #32
    v.movi       v1, #0
    s.or         s5, s4, s8
    v.extract    s4, v5, #1
    s.shli       s8, s7, #32
    s.cmp.ge     s7, s5, s1
    v.extract    s1, v8, #2
    s.or         s5, s4, s8
    s.movz       s4, #0
    v.insert     v1, s7, #0
    v.extract    s7, v5, #2
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s5, s4
    v.extract    s4, v8, #3
    s.or         s5, s7, s8
    s.movz       s7, #0
    v.insert     v1, s1, #1
    v.extract    s1, v5, #3
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s5, s7
    v.extract    s5, v8, #4
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v1, s4, #2
    v.extract    s4, v5, #4
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v8, #5
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v1, s5, #3
    v.extract    s5, v5, #5
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v8, #6
    s.or         s7, s5, s8
    s.movz       s5, #0
    v.insert     v1, s1, #4
    v.extract    s1, v5, #6
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s7, s5
    v.extract    s5, v8, #7
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v1, s4, #5
    v.extract    s4, v5, #7
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v8, #8
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v1, s5, #6
    v.extract    s5, v5, #8
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v8, #9
    s.or         s7, s5, s8
    s.movz       s5, #0
    v.insert     v1, s1, #7
    v.extract    s1, v5, #9
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s7, s5
    v.extract    s5, v8, #10
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v1, s4, #8
    v.extract    s4, v5, #10
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v8, #11
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v1, s5, #9
    v.extract    s5, v5, #11
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v8, #12
    s.or         s7, s5, s8
    s.movz       s5, #0
    v.insert     v1, s1, #10
    v.extract    s1, v5, #12
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s7, s5
    v.extract    s5, v8, #13
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v1, s4, #11
    v.extract    s4, v5, #13
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v8, #14
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v1, s5, #12
    v.extract    s5, v5, #14
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v8, #15
    v.extract    s7, v8, #0
    s.or         s9, s5, s8
    s.movz       s5, #0
    v.insert     v1, s1, #13
    v.extract    s1, v5, #15
    s.shli       s8, s4, #32
    v.extract    s4, v5, #0
    s.shli       s10, s7, #32
    s.cmp.ge     s7, s9, s5
    v.extract    s5, v8, #1
    s.or         s9, s1, s8
    s.movz       s1, #0
    s.or         s8, s4, s10
    s.movz       s4, #128
    v.insert     v1, s7, #14
    v.movi       v3, #0
    v.extract    s7, v5, #1
    s.shli       s10, s5, #32
    s.cmp.ge     s5, s9, s1
    s.cmp.lt     s1, s8, s4
    v.extract    s4, v8, #2
    s.or         s8, s7, s10
    s.movz       s7, #128
    v.insert     v1, s5, #15
    v.insert     v3, s1, #0
    v.extract    s1, v5, #2
    s.shli       s5, s4, #32
    s.cmp.lt     s4, s8, s7
    v.extract    s7, v8, #3
    s.or         s8, s1, s5
    s.movz       s1, #128
    v.insert     v3, s4, #1
    v.extract    s4, v5, #3
    s.shli       s5, s7, #32
    s.cmp.lt     s7, s8, s1
    v.extract    s1, v8, #4
    s.or         s8, s4, s5
    s.movz       s4, #128
    v.insert     v3, s7, #2
    v.extract    s5, v5, #4
    s.shli       s7, s1, #32
    s.cmp.lt     s1, s8, s4
    v.extract    s4, v8, #5
    s.or         s8, s5, s7
    s.movz       s5, #128
    v.insert     v3, s1, #3
    v.extract    s1, v5, #5
    s.shli       s7, s4, #32
    s.cmp.lt     s4, s8, s5
    v.extract    s5, v8, #6
    s.or         s8, s1, s7
    s.movz       s1, #128
    v.insert     v3, s4, #4
    v.extract    s4, v5, #6
    s.shli       s7, s5, #32
    s.cmp.lt     s5, s8, s1
    v.movi       v4, #0
    s.or         s1, s4, s7
    v.insert     v3, s5, #5
    v.cmp.ne     p1, v1, v4
    v.extract    s4, v8, #7
    s.movz       s5, #128
    v.extract    s7, v5, #7
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s1, s5
    v.extract    s1, v8, #8
    s.or         s5, s7, s8
    s.movz       s7, #128
    v.insert     v3, s4, #6
    v.extract    s4, v5, #8
    s.shli       s8, s1, #32
    s.cmp.lt     s1, s5, s7
    v.extract    s5, v8, #9
    s.or         s7, s4, s8
    s.movz       s4, #128
    v.insert     v3, s1, #7
    v.extract    s1, v5, #9
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s7, s4
    v.extract    s4, v8, #10
    s.or         s7, s1, s8
    s.movz       s1, #128
    v.insert     v3, s5, #8
    v.extract    s5, v5, #10
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s7, s1
    v.extract    s1, v8, #11
    s.or         s7, s5, s8
    s.movz       s5, #128
    v.insert     v3, s4, #9
    v.extract    s4, v5, #11
    s.shli       s8, s1, #32
    s.cmp.lt     s1, s7, s5
    v.extract    s5, v8, #12
    s.or         s7, s4, s8
    s.movz       s4, #128
    v.insert     v3, s1, #10
    v.extract    s1, v5, #12
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s7, s4
    v.extract    s4, v8, #13
    s.or         s7, s1, s8
    s.movz       s1, #128
    v.insert     v3, s5, #11
    v.extract    s5, v5, #13
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s7, s1
    v.extract    s1, v8, #14
    s.or         s7, s5, s8
    s.movz       s5, #128
    v.insert     v3, s4, #12
    v.extract    s4, v5, #14
    s.shli       s8, s1, #32
    s.cmp.lt     s1, s7, s5
    v.extract    s5, v8, #15
    s.or         s7, s4, s8
    s.movz       s4, #128
    v.insert     v3, s1, #13
    v.extract    s1, v5, #15
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s7, s4
    s.or         s4, s1, s8
    s.movz       s1, #128
    v.insert     v3, s5, #14
    s.cmp.lt     s5, s4, s1
    v.extract    s1, v7, #0
    v.insert     v3, s5, #15
    v.movi       v1, #0
    v.movi       v4, #-6144
    s.shli       s4, s1, #32
    v.extract    s1, v7, #1
    s.ashri      s5, s4, #32
    v.cmp.ne     p2, v3, v1
    v.add        v1, v6, v4
    v.movi       v3, #0
    v.movi       v4, #0
    s.shli       s4, s1, #32
    p.and        p3, p1, p2
    s.lshri      s1, s5, #32
    v.extract    s7, v7, #2
    s.ashri      s8, s4, #32
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s3, v1]               // index is in elements (ISA sec 9.1)
    v.insert     v3, s5, #0
    v.insert     v4, s1, #0
    s.shli       s1, s7, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v7, #3
    s.ashri      s7, s1, #32
    v.insert     v3, s8, #1
    v.insert     v4, s4, #1
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v7, #4
    s.ashri      s8, s1, #32
    v.insert     v3, s7, #2
    v.insert     v4, s4, #2
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v7, #5
    s.ashri      s7, s1, #32
    v.insert     v3, s8, #3
    v.insert     v4, s4, #3
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v7, #6
    s.ashri      s8, s1, #32
    v.insert     v3, s7, #4
    v.insert     v4, s4, #4
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.insert     v3, s8, #5
    v.insert     v4, s4, #5
    vf.cvt.bf16.f32 v1, v5
    .li       s4, #-6144
    v.extract    s4, v7, #7
    s.ashri      s5, s1, #32
    s.lshri      s1, s5, #32
    v.insert     v3, s5, #6
    v.insert     v4, s1, #6
    @p3 v.sel        v5, v1, v10
    s.shli       s1, s4, #32
    vf.mul       v1, v5, v0
    s.ashri      s4, s1, #32
    vf.add       v0, v2, v1
    v.extract    s1, v7, #8
    s.lshri      s5, s4, #32
    s.shli       s7, s1, #32
    v.extract    s1, v7, #9
    s.ashri      s8, s7, #32
    v.insert     v3, s4, #7
    v.insert     v4, s5, #7
    s.shli       s4, s1, #32
    s.lshri      s1, s8, #32
    v.extract    s5, v7, #10
    s.ashri      s7, s4, #32
    v.insert     v3, s8, #8
    v.insert     v4, s1, #8
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v7, #11
    s.ashri      s8, s1, #32
    v.insert     v3, s7, #9
    v.insert     v4, s4, #9
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v7, #12
    s.ashri      s7, s1, #32
    v.insert     v3, s8, #10
    v.insert     v4, s4, #10
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v7, #13
    s.ashri      s8, s1, #32
    v.insert     v3, s7, #11
    v.insert     v4, s4, #11
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    v.extract    s5, v7, #14
    s.ashri      s7, s1, #32
    v.insert     v3, s8, #12
    v.insert     v4, s4, #12
    s.shli       s1, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v7, #15
    s.ashri      s8, s1, #32
    v.insert     v3, s7, #13
    v.insert     v4, s4, #13
    s.shli       s1, s5, #32
    s.lshri      s4, s8, #32
    s.ashri      s5, s1, #32
    v.insert     v3, s8, #14
    v.insert     v4, s4, #14
    s.lshri      s1, s5, #32
    v.insert     v3, s5, #15
    v.insert     v4, s1, #15
    s.movz       s1, #0
    v.extract    s4, v3, #0
    v.extract    s5, v4, #0
    v.extract    s7, v4, #1
    s.shli       s8, s5, #32
    v.movi       v1, #0
    s.or         s5, s4, s8
    v.extract    s4, v3, #1
    s.shli       s8, s7, #32
    s.cmp.ge     s7, s5, s1
    v.extract    s1, v4, #2
    s.or         s5, s4, s8
    s.movz       s4, #0
    v.insert     v1, s7, #0
    v.extract    s7, v3, #2
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s5, s4
    v.extract    s4, v4, #3
    s.or         s5, s7, s8
    s.movz       s7, #0
    v.insert     v1, s1, #1
    v.extract    s1, v3, #3
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s5, s7
    v.extract    s5, v4, #4
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v1, s4, #2
    v.extract    s4, v3, #4
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v4, #5
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v1, s5, #3
    v.extract    s5, v3, #5
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v4, #6
    s.or         s7, s5, s8
    s.movz       s5, #0
    v.insert     v1, s1, #4
    v.extract    s1, v3, #6
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s7, s5
    v.extract    s5, v4, #7
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v1, s4, #5
    v.extract    s4, v3, #7
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v4, #8
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v1, s5, #6
    v.extract    s5, v3, #8
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v4, #9
    s.or         s7, s5, s8
    s.movz       s5, #0
    v.insert     v1, s1, #7
    v.extract    s1, v3, #9
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s7, s5
    v.extract    s5, v4, #10
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v1, s4, #8
    v.extract    s4, v3, #10
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v4, #11
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v1, s5, #9
    v.extract    s5, v3, #11
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v4, #12
    s.or         s7, s5, s8
    s.movz       s5, #0
    v.insert     v1, s1, #10
    v.extract    s1, v3, #12
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s7, s5
    v.extract    s5, v4, #13
    s.or         s7, s1, s8
    s.movz       s1, #0
    v.insert     v1, s4, #11
    v.extract    s4, v3, #13
    s.shli       s8, s5, #32
    s.cmp.ge     s5, s7, s1
    v.extract    s1, v4, #14
    s.or         s7, s4, s8
    s.movz       s4, #0
    v.insert     v1, s5, #12
    v.extract    s5, v3, #14
    s.shli       s8, s1, #32
    s.cmp.ge     s1, s7, s4
    v.extract    s4, v4, #15
    v.extract    s7, v4, #0
    s.or         s9, s5, s8
    s.movz       s5, #0
    v.insert     v1, s1, #13
    v.extract    s1, v3, #15
    s.shli       s8, s4, #32
    v.extract    s4, v3, #0
    s.shli       s10, s7, #32
    s.cmp.ge     s7, s9, s5
    v.extract    s5, v4, #1
    s.or         s9, s1, s8
    s.movz       s1, #0
    s.or         s8, s4, s10
    s.movz       s4, #128
    v.insert     v1, s7, #14
    v.movi       v2, #0
    v.extract    s7, v3, #1
    s.shli       s10, s5, #32
    s.cmp.ge     s5, s9, s1
    s.cmp.lt     s1, s8, s4
    v.extract    s4, v4, #2
    s.or         s8, s7, s10
    s.movz       s7, #128
    v.insert     v1, s5, #15
    v.insert     v2, s1, #0
    v.extract    s1, v3, #2
    s.shli       s5, s4, #32
    s.cmp.lt     s4, s8, s7
    v.extract    s7, v4, #3
    s.or         s8, s1, s5
    s.movz       s1, #128
    v.insert     v2, s4, #1
    v.extract    s4, v3, #3
    s.shli       s5, s7, #32
    s.cmp.lt     s7, s8, s1
    v.extract    s1, v4, #4
    s.or         s8, s4, s5
    s.movz       s4, #128
    v.insert     v2, s7, #2
    v.extract    s5, v3, #4
    s.shli       s7, s1, #32
    s.cmp.lt     s1, s8, s4
    v.extract    s4, v4, #5
    s.or         s8, s5, s7
    s.movz       s5, #128
    v.insert     v2, s1, #3
    v.extract    s1, v3, #5
    s.shli       s7, s4, #32
    s.cmp.lt     s4, s8, s5
    v.extract    s5, v4, #6
    s.or         s8, s1, s7
    s.movz       s1, #128
    v.insert     v2, s4, #4
    v.extract    s4, v3, #6
    s.shli       s7, s5, #32
    s.cmp.lt     s5, s8, s1
    v.movi       v5, #0
    s.or         s1, s4, s7
    v.insert     v2, s5, #5
    v.cmp.ne     p1, v1, v5
    v.extract    s4, v4, #7
    s.movz       s5, #128
    v.extract    s7, v3, #7
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s1, s5
    v.extract    s1, v4, #8
    s.or         s5, s7, s8
    s.movz       s7, #128
    v.insert     v2, s4, #6
    v.extract    s4, v3, #8
    s.shli       s8, s1, #32
    s.cmp.lt     s1, s5, s7
    v.extract    s5, v4, #9
    s.or         s7, s4, s8
    s.movz       s4, #128
    v.insert     v2, s1, #7
    v.extract    s1, v3, #9
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s7, s4
    v.extract    s4, v4, #10
    s.or         s7, s1, s8
    s.movz       s1, #128
    v.insert     v2, s5, #8
    v.extract    s5, v3, #10
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s7, s1
    v.extract    s1, v4, #11
    s.or         s7, s5, s8
    s.movz       s5, #128
    v.insert     v2, s4, #9
    v.extract    s4, v3, #11
    s.shli       s8, s1, #32
    s.cmp.lt     s1, s7, s5
    v.extract    s5, v4, #12
    s.or         s7, s4, s8
    s.movz       s4, #128
    v.insert     v2, s1, #10
    v.extract    s1, v3, #12
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s7, s4
    v.extract    s4, v4, #13
    s.or         s7, s1, s8
    s.movz       s1, #128
    v.insert     v2, s5, #11
    v.extract    s5, v3, #13
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s7, s1
    v.extract    s1, v4, #14
    s.or         s7, s5, s8
    s.movz       s5, #128
    v.insert     v2, s4, #12
    v.extract    s4, v3, #14
    s.shli       s8, s1, #32
    s.cmp.lt     s1, s7, s5
    v.extract    s5, v4, #15
    s.or         s7, s4, s8
    s.movz       s4, #128
    v.insert     v2, s1, #13
    v.extract    s1, v3, #15
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s7, s4
    s.or         s4, s1, s8
    s.movz       s1, #128
    v.insert     v2, s5, #14
    s.cmp.lt     s5, s4, s1
    v.movi       v1, #0
    v.insert     v2, s5, #15
    s.shli       s1, s2, #1                      // element offset -> bytes (x2)
    s.shli       s4, s2, #2                      // element offset -> bytes (x4)
    v.cmp.ne     p2, v2, v1
    p.and        p3, p1, p2
    s.add        s2, s3, s1                      // &in_ptr0[...]
    s.add        s1, s6, s4                      // &out_ptr0[...]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.bf16.f32 v2, v1
    @p3 v.sel        v1, v2, v10
    vf.mul       v2, v1, v9
    vf.add       v1, v0, v2
    v.st.w       [s1, #0], v1
__rctx_next:
    exit
