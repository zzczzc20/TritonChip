    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // arg_B: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #3072
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #2048                   // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s7, #0], s5
    .li       s1, #2147483647
    s.st.d       [s7, #8], s1
    .li       s1, #2147483647
    s.st.d       [s7, #16], s1
    s.movz       s1, #192
    s.st.d       [s7, #48], s1
    s.movz       s1, #2
    s.st.d       [s7, #56], s1
    .li       s1, #68719476752
    s.st.d       [s7, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s7, #104], s1
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #5
    s.movz       s5, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s1, s9
    s.sub        s9, s8, s10
    s.xor        s8, s1, s9
    s.sub        s10, s8, s9
    .li       s8, #2576980378
    s.movz       s10, #2
    s.movz       s11, #1
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #0
    s.movz       s18, #1
    s.cmp.lt     s19, s4, s7
    s.sub        s7, s5, s19
    s.xor        s5, s4, s7
    s.sub        s19, s5, s7
    s.mul        s5, s19, s8
    s.lshri      s8, s5, #32
    s.sub        s5, s19, s8
    s.lshri      s20, s5, #1
    s.add        s5, s8, s20
    s.lshri      s8, s5, #2
    s.muli       s5, s8, #5
    s.sub        s20, s19, s5
    s.xor        s5, s7, s9
    s.xor        s7, s8, s5
    s.sub        s8, s7, s5
    s.sub        s5, s10, s8
    s.min.s      s7, s5, s11
    s.cmp.lt     s5, s4, s13
    s.sub        s9, s12, s5
    s.cmp.lt     s5, s7, s15
    s.sub        s10, s14, s5
    s.xor        s5, s4, s9
    s.sub        s12, s5, s9
    s.xor        s5, s7, s10
    s.sub        s13, s5, s10
    s.addi       s5, s16, #0
    s.addi       s10, s17, #0
    s.cmp.eq     s14, s13, s18
    s.mov        s5, s12
    br.nz        s14, sdiv_done_1
    s.movz       s14, #0
    s.movz       s15, #31
    s.mov        s5, s14
    s.addi       s14, s15, #0
sdiv_2:
    s.lshr       s15, s12, s14
    s.shli       s16, s10, #1
    s.andi       s17, s15, #1
    s.movz       s15, #0
    s.or         s18, s16, s17
    s.movz       s16, #1
    s.cmp.geu    s17, s18, s13
    s.shl        s19, s16, s14
    s.sub        s16, s15, s17
    s.subi       s15, s14, #1
    s.and        s17, s13, s16
    s.and        s20, s19, s16
    s.sub        s16, s18, s17
    s.or         s17, s5, s20
    s.mov        s10, s16
    s.mov        s5, s17
    s.mov        s14, s15
    s.movz       s15, #0
    s.cmp.ge     s16, s14, s15
    br.nz        s16, sdiv_2
sdiv_done_1:
    s.movz       s5, #0
    s.movz       s12, #0
    s.cmp.lt     s13, s4, s5
    .li       s5, #2576980378
    s.sub        s14, s12, s13
    s.movz       s12, #0
    s.xor        s13, s4, s14
    s.movz       s4, #0
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.mul        s16, s15, s5
    s.cmp.lt     s5, s7, s12
    s.movz       s12, #0
    s.sub        s17, s13, s5
    s.movz       s5, #0
    s.lshri      s13, s16, #32
    s.cmp.lt     s16, s1, s12
    s.xor        s12, s7, s17
    s.xor        s7, s10, s9
    s.sub        s10, s12, s17
    s.sub        s12, s7, s9
    s.sub        s7, s15, s13
    s.add        s9, s8, s12
    s.lshri      s8, s7, #1
    s.movz       s7, #0
    s.add        s12, s13, s8
    s.sub        s8, s7, s16
    s.lshri      s7, s12, #2
    s.movz       s12, #0
    s.muli       s13, s7, #5
    s.movz       s7, #1
    s.xor        s16, s1, s8
    s.addi       s1, s12, #0
    s.cmp.eq     s12, s10, s7
    s.sub        s7, s15, s13
    s.movz       s13, #0
    s.xor        s15, s7, s14
    s.sub        s7, s16, s8
    s.sub        s7, s15, s14
    s.addi       s8, s13, #0
    s.cmp.lt     s13, s7, s4
    s.sub        s4, s5, s13
    s.xor        s5, s7, s4
    s.sub        s7, s5, s4
    s.mov        s1, s7
    br.nz        s12, sdiv_done_3
    s.movz       s5, #0
    s.movz       s12, #31
    s.mov        s1, s5
    s.addi       s5, s12, #0
sdiv_4:
    s.lshr       s12, s7, s5
    s.shli       s13, s8, #1
    s.andi       s14, s12, #1
    s.movz       s12, #0
    s.or         s15, s13, s14
    s.movz       s13, #1
    s.cmp.geu    s14, s15, s10
    s.shl        s16, s13, s5
    s.sub        s13, s12, s14
    s.subi       s12, s5, #1
    s.and        s14, s10, s13
    s.and        s18, s16, s13
    s.sub        s13, s15, s14
    s.or         s14, s1, s18
    s.mov        s8, s13
    s.mov        s1, s14
    s.mov        s5, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s5, s12
    br.nz        s13, sdiv_4
sdiv_done_3:
    s.movz       s5, #16
    s.xor        s7, s4, s17
    s.mul        s4, s9, s5
    s.xor        s8, s1, s7
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s1, s8, s7
    v.movi       v1, #26
    v.splat      v2, s4
    s.mul        s7, s1, s5
    v.movi       v3, #0
    v.add        v4, v2, v0
    s.movz       s8, #0
    v.splat      v2, s9
    v.splat      v5, s8
    v.splat      v6, s1
    v.splat      v7, s8
    v.splat      v8, s7
    v.sub        v9, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.cmp.ge     p3, v2, v5
    v.sub        v2, v3, v1
    v.cmp.ge     p3, v6, v7
    v.add        v5, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v4
    @p2 v.sel        v4, v2, v1
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s1, #31
idiv_5:
    v.splat      v6, s1
    v.shl        v7, v2, v0
    v.cmp.lt     p2, v2, v3
    v.lshr       v8, v5, v6
    v.shl        v9, v0, v6
    s.subi       s9, s1, #1
    v.and        v6, v8, v0
    s.movz       s10, #0
    v.or         v8, v7, v6
    v.cmp.geu    p3, v8, v4
    p.or         p4, p2, p3
    v.sub        v6, v8, v4
    @p4 v.sel        v7, v9, v3
    @p4 v.sel        v9, v6, v8
    v.or         v6, v1, v7
    v.mov        v2, v9
    v.mov        v1, v6
    s.mov        s1, s9
    s.cmp.ge     s9, s1, s10
    br.nz        s9, idiv_5
    .li       s1, #2576980378
    v.sub        v0, v3, v2
    s.mul        s9, s7, s1
    v.iota       v1                              // arange(0, VLEN)
    @p1 v.sel        v3, v0, v2
    s.movz       s1, #6
    s.addi       s10, s8, #0
    s.lshri      s12, s9, #32
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.sub        s9, s7, s12
    s.lshri      s13, s9, #1
    s.add        s9, s12, s13
    s.lshri      s12, s9, #6
    s.muli       s9, s12, #80
    s.sub        s12, s7, s9
    v.splat      v0, s12
    v.add        v2, v0, v1
for_6:
    s.cmp.ge     s9, s10, s1
    br.nz        s9, endfor_7
    s.mul        s9, s10, s5
    s.rdspecial  s13, arg_base
    s.ld.d       s14, [s13, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s13, role_id
    s.movz       s15, #3072
    s.mul        s16, s13, s15
    s.add        s13, s14, s16                   // this context's own scratch
    s.addi       s14, s13, #0
    v.splat      v0, s8
    s.movz       s15, #0
    s.add        s16, s15, s9                    // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s16
    v.add        v4, v1, v2
    v.extract    s15, v3, #0
    v.splat      v1, s15
    s.movz       s15, #96
    v.splat      v2, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s15, s14, #64
    v.extract    s16, v3, #1
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #128
    v.extract    s16, v3, #2
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #192
    v.extract    s16, v3, #3
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #256
    v.extract    s16, v3, #4
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #320
    v.extract    s16, v3, #5
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #384
    v.extract    s16, v3, #6
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #448
    v.extract    s16, v3, #7
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #512
    v.extract    s16, v3, #8
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #576
    v.extract    s16, v3, #9
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #640
    v.extract    s16, v3, #10
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #704
    v.extract    s16, v3, #11
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #768
    v.extract    s16, v3, #12
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #832
    v.extract    s16, v3, #13
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #896
    v.extract    s16, v3, #14
    v.splat      v1, s16
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #960
    v.extract    s14, v3, #15
    v.splat      v1, s14
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v2, v0, v1
    v.st.w       [s15, #0], v2
    fence.acq_rel.device
    s.addi       s14, s13, #1024
    s.addi       s15, s13, #0
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s15, s14, #64
    s.addi       s16, s13, #64
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #128
    s.addi       s16, s13, #128
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #192
    s.addi       s16, s13, #192
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #256
    s.addi       s16, s13, #256
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #320
    s.addi       s16, s13, #320
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #384
    s.addi       s16, s13, #384
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #448
    s.addi       s16, s13, #448
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #512
    s.addi       s16, s13, #512
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #576
    s.addi       s16, s13, #576
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #640
    s.addi       s16, s13, #640
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #704
    s.addi       s16, s13, #704
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #768
    s.addi       s16, s13, #768
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #832
    s.addi       s16, s13, #832
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #896
    s.addi       s16, s13, #896
    v.ld.w       v0, [s16, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    s.addi       s15, s14, #960
    s.addi       s14, s13, #960
    v.ld.w       v0, [s14, #0]
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v1
    fence.acq_rel.device
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s14, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s15, s12                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s9                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s15, s14
    mb.wait      s14
    s.addi       s9, s13, #2304                  // 512 bytes of repack scratch
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s15, s13, #1024
    v.ld.w       v0, [s15, #0]
    v.st.h       [s9, #0], v0
    s.addi       s15, s13, #1088
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #32                    // row 1
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1152
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #64                    // row 2
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1216
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #96                    // row 3
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1280
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #128                   // row 4
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1344
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #160                   // row 5
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1408
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #192                   // row 6
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1472
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #224                   // row 7
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1536
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #256                   // row 8
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1600
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #288                   // row 9
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1664
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #320                   // row 10
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1728
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #352                   // row 11
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1792
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #384                   // row 12
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1856
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #416                   // row 13
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1920
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #448                   // row 14
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #1984
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #480                   // row 15
    v.st.h       [s15, #0], v0
    s.addi       s15, s13, #2816                 // TensorMap 1: a repacked tile
    s.movz       s13, #0
    s.st.d       [s15, #0], s9
    s.movz       s9, #16
    s.st.d       [s15, #8], s9
    s.movz       s9, #16
    s.st.d       [s15, #16], s9
    s.movz       s9, #32
    s.st.d       [s15, #48], s9
    s.movz       s9, #2
    s.st.d       [s15, #56], s9
    .li       s9, #68719476752
    s.st.d       [s15, #88], s9
    .li       s9, #1108101562368
    s.st.d       [s15, #104], s9
    fence.release.device
    td.load      d1, [s15]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s9, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s15, s9                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s9                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s15, s13
    mb.wait      s13
    mb.arm       s9, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v48, v56, s9
    mb.wait      s9
    s.add        s15, s10, s11
    s.mov        s10, s15
    s.movz       s15, #1
    br.nz        s15, for_6
endfor_7:
    s.movz       s1, #0
    s.movz       s3, #0
    s.add        s5, s1, s7                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s5
    s.add        s1, s3, s4                      // the tile origin
    s.movz       s3, #26
    s.movz       s5, #80
    s.muli       s8, s7, #2                      // a runtime tile origin, x2
    v.splat      v2, s1
    v.splat      v3, s3
    v.add        v4, v0, v1
    v.splat      v0, s5
    v.cmp.lt     p1, v2, v3
    s.add        s3, s2, s8                      // the tile origin
    v.cmp.lt     p2, v4, v0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    p.and        p3, p1, p2
    a.vread      v0, a0, s2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s2, s7, #2                      // a runtime tile origin, x2
    s.addi       s5, s1, #1
    s.muli       s7, s4, #160                    // a runtime tile origin, x160
    v.splat      v2, s1
    v.splat      v4, s5
    s.add        s4, s6, s2                      // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p3, v4, v3
    s.add        s2, s4, s7                      // the tile origin
    p.and        p4, p1, p2
    s.movz       s4, #1
    p.and        p1, p3, p2
    s.addi       s5, s1, #1
    vf.cvt.bf16.f32 v2, v1
    s.addi       s6, s1, #2
    v.splat      v1, s5
    v.splat      v4, s6
    s.addi       s5, s2, #160                    // row 1
    vf.add       v5, v0, v2
    s.movz       s6, #2
    s.addi       s7, s1, #2
    s.addi       s8, s1, #3
    v.splat      v0, s7
    vf.cvt.f32.bf16 v2, v5
    v.splat      v5, s8
    s.addi       s7, s2, #320                    // row 2
    s.movz       s8, #3
    s.addi       s10, s1, #3
    @p4 v.st.h       [s2, #0], v2
    a.vread      v2, a0, s4
    v.cmp.lt     p3, v1, v3
    p.and        p4, p3, p2
    s.addi       s4, s1, #4
    v.splat      v1, s10
    v.splat      v6, s4
    s.addi       s4, s2, #480                    // row 3
    s.movz       s10, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v4, v7
    vf.add       v7, v2, v4
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s5, s1, #4
    s.addi       s6, s1, #5
    v.splat      v0, s5
    v.splat      v4, s6
    s.addi       s5, s2, #640                    // row 4
    s.movz       s6, #5
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v5, v7
    vf.add       v7, v2, v5
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s8
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s7, s1, #5
    s.addi       s8, s1, #6
    v.splat      v1, s7
    v.splat      v5, s8
    s.addi       s7, s2, #800                    // row 5
    s.movz       s8, #6
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v6, v7
    vf.add       v7, v2, v6
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a0, s10
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s4, s1, #6
    s.addi       s10, s1, #7
    v.splat      v0, s4
    v.splat      v6, s10
    s.addi       s4, s2, #960                    // row 6
    s.movz       s10, #7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v4, v7
    vf.add       v7, v2, v4
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s5, s1, #7
    s.addi       s6, s1, #8
    v.splat      v1, s5
    v.splat      v4, s6
    s.addi       s5, s2, #1120                   // row 7
    s.movz       s6, #8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v5, v7
    vf.add       v7, v2, v5
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s8
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s7, s1, #8
    s.addi       s8, s1, #9
    v.splat      v0, s7
    v.splat      v5, s8
    s.addi       s7, s2, #1280                   // row 8
    s.movz       s8, #9
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v6, v7
    vf.add       v7, v2, v6
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a0, s10
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s4, s1, #9
    s.addi       s10, s1, #10
    v.splat      v1, s4
    v.splat      v6, s10
    s.addi       s4, s2, #1440                   // row 9
    s.movz       s10, #10
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v4, v7
    vf.add       v7, v2, v4
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s5, s1, #10
    s.addi       s6, s1, #11
    v.splat      v0, s5
    v.splat      v4, s6
    s.addi       s5, s2, #1600                   // row 10
    s.movz       s6, #11
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v5, v7
    vf.add       v7, v2, v5
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s8
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s7, s1, #11
    s.addi       s8, s1, #12
    v.splat      v1, s7
    v.splat      v5, s8
    s.addi       s7, s2, #1760                   // row 11
    s.movz       s8, #12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v6, v7
    vf.add       v7, v2, v6
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a0, s10
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s4, s1, #12
    s.addi       s10, s1, #13
    v.splat      v0, s4
    v.splat      v6, s10
    s.addi       s4, s2, #1920                   // row 12
    s.movz       s10, #13
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v4, v7
    vf.add       v7, v2, v4
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s5, s1, #13
    s.addi       s6, s1, #14
    v.splat      v1, s5
    v.splat      v4, s6
    s.addi       s5, s2, #2080                   // row 13
    s.movz       s6, #14
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v5, v7
    vf.add       v7, v2, v5
    vf.cvt.f32.bf16 v2, v7
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s8
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s7, s1, #14
    s.addi       s8, s1, #15
    v.splat      v0, s7
    v.splat      v5, s8
    s.addi       s7, s2, #2240                   // row 14
    s.movz       s8, #15
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v6, v7
    vf.add       v7, v2, v6
    vf.cvt.f32.bf16 v2, v7
    s.addi       s11, s1, #15
    s.addi       s1, s2, #2400                   // row 15
    v.splat      v6, s11
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a0, s10
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v4, v1
    vf.add       v1, v2, v4
    vf.cvt.f32.bf16 v2, v1
    @p4 v.st.h       [s5, #0], v2
    a.vread      v1, a0, s6
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v2, v0
    vf.add       v0, v1, v2
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s7, #0], v1
    a.vread      v0, a0, s8
    v.cmp.lt     p1, v6, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    vf.cvt.bf16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s1, #0], v0
__rctx_next:
    exit
