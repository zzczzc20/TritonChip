source ~/tc_env/env.sh
cd /home/zhongchun/r40_final_llama_progress_20261018
export OMP_NUM_THREADS=2 MAX_JOBS=2 CUDA_VISIBLE_DEVICES= TNCA_HOST_TIMEOUT=14400 TNCA_DEADLINE=200000000
export PYTHONPATH="$PWD:$PWD/python:$PWD/compiler/python:$PWD/tools/asm"
/home/zhongchun/tc_env/torchenv/bin/python -u -m archbench.run --platform tnca --profile core-vrf-sync-v5 --backend fpga-multicore-sim --backend-args '{"core_count": 3, "memory_ports": 3, "memory_bytes": 8388608, "link_stages": 2, "noc_link_stages": 2, "dispatch_stages": 2, "home_stages": 2, "code_stages": 2, "board_top": true, "maintenance": true, "memory_controls": true, "hbm_dma": true, "journal": true}' --point model.llama_decode/medium/fp16-b1-p256 --jobs 1 --seed 0 --warmup 0 --timed 1 --timeout 21600 --bundle-dir /home/zhongchun/r40_final_llama_progress_20261018/results/bundles --set TNCA_TORCH_DEVICE=native --set TNCA_TRANSFER_POLICY=resident --set TNCA_ACTIVE_CORES=3 --out /home/zhongchun/r40_final_llama_progress_20261018/results/raw.jsonl > results/runner.log 2>&1
echo $? > results/runner.exit
