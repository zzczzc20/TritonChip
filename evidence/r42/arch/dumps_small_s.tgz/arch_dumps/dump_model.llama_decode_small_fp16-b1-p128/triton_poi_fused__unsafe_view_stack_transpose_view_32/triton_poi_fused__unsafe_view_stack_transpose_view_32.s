    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    s.shli       s1, s2, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #64
    s.shli       s6, s1, #1                      // element offset -> bytes (x2)
    v.add        v3, v1, v0
    s.add        s1, s3, s6                      // &in_ptr0[...]
    s.add        s7, s5, s6                      // &out_ptr0[...]
    v.cmp.lt     p1, v3, v2
    @p1 v.ld.h       v0, [s1, #0]
    @p1 v.st.h       [s7, #0], v0
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s6, s1, s4
    s.mov        s2, s1
    br.nz        s6, __rctx_program
    exit
