    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #256
    s.movz       s5, #16
    s.movz       s6, #1
    s.rdspecial  s6, role_id
    s.rdspecial  s7, npid.x
    s.ld.d       s8, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    s.mul        s1, s6, s4
    s.addi       s9, s2, #0
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #15
    .li       s10, #2143289344
    v.splat      v2, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s10, s9, s1
    s.add        s11, s9, s1
    v.movi       v3, #0
    v.movi       v4, #1
    v.movi       v5, #0
    s.shli       s1, s10, #2                     // element offset -> bytes (x4)
    s.shli       s10, s11, #2                    // element offset -> bytes (x4)
    v.cmp.eq     p1, v0, v1
    v.mov        v3, v2
    @p1 v.sel        v0, v4, v5
    v.splat      v1, s2
    s.add        s11, s3, s1                     // &in_ptr0[...]
    s.add        s1, s8, s10                     // &out_ptr0[...]
for_1:
    v.ld.w       v2, [s11, #0]
    v.movi       v4, #0
    v.extract    s10, v2, #0
    v.extract    s12, v2, #1
    v.splat      v5, s10
    v.splat      v6, s12
    v.extract    s10, v2, #2
    v.extract    s12, v2, #3
    vf.add       v7, v5, v6
    v.splat      v6, s10
    v.splat      v8, s12
    v.extract    s10, v2, #4
    v.extract    s12, v2, #5
    vf.add       v9, v7, v6
    v.splat      v6, s10
    v.splat      v10, s12
    v.extract    s10, v2, #6
    v.extract    s12, v2, #7
    vf.add       v11, v9, v8
    v.splat      v8, s10
    v.splat      v12, s12
    v.extract    s10, v2, #8
    // one value per row into one vector (ISA 0x09)
    v.extract    s12, v5, #0
    vf.add       v5, v11, v6
    v.splat      v6, s10
    v.insert     v4, s12, #0
    v.extract    s10, v7, #0
    v.extract    s12, v2, #9
    vf.add       v7, v5, v10
    v.insert     v4, s10, #1
    v.extract    s10, v9, #0
    v.splat      v9, s12
    v.insert     v4, s10, #2
    vf.add       v10, v7, v8
    v.extract    s10, v11, #0
    v.extract    s12, v2, #10
    v.insert     v4, s10, #3
    v.splat      v8, s12
    vf.add       v11, v10, v12
    v.extract    s10, v5, #0
    v.extract    s12, v2, #11
    v.insert     v4, s10, #4
    v.extract    s10, v7, #0
    vf.add       v5, v11, v6
    v.splat      v6, s12
    v.insert     v4, s10, #5
    v.extract    s10, v10, #0
    v.extract    s12, v2, #12
    vf.add       v7, v5, v9
    v.insert     v4, s10, #6
    v.extract    s10, v11, #0
    v.splat      v9, s12
    v.insert     v4, s10, #7
    vf.add       v10, v7, v8
    v.extract    s10, v5, #0
    v.extract    s12, v2, #13
    v.insert     v4, s10, #8
    v.splat      v5, s12
    vf.add       v8, v10, v6
    v.extract    s10, v7, #0
    v.extract    s12, v2, #14
    v.insert     v4, s10, #9
    v.extract    s10, v10, #0
    vf.add       v6, v8, v9
    v.splat      v7, s12
    v.insert     v4, s10, #10
    v.extract    s10, v8, #0
    v.extract    s12, v2, #15
    vf.add       v2, v6, v5
    v.insert     v4, s10, #11
    v.extract    s10, v6, #0
    v.splat      v5, s12
    v.insert     v4, s10, #12
    vf.add       v6, v2, v7
    v.extract    s10, v2, #0
    v.extract    s12, v3, #0
    v.insert     v4, s10, #13
    v.splat      v2, s12
    vf.add       v7, v6, v5
    v.extract    s10, v6, #0
    v.splat      v5, s9
    v.insert     v4, s10, #14
    v.extract    s10, v7, #0
    v.cmp.gt     p1, v5, v1
    v.insert     v4, s10, #15
    v.mul        v5, v4, v0
    vf.add       v6, v2, v4
    v.reduce.add s10, v5
    v.splat      v2, s10
    @p1 v.sel        v5, v6, v4
    vf.add       v4, v3, v2
    v.st.w       [s1, #0], v5
    @p1 v.sel        v3, v4, v2
    s.addi       s11, s11, #64                   // the next iteration's address
    s.addi       s1, s1, #64                     // the next iteration's address
    s.add        s9, s9, s5
    s.cmp.lt     s10, s9, s4
    br.nz        s10, for_1
endfor_2:
__rctx_next:
    s.addi       s1, s6, #4                      // the next program of this context: + 4
    s.cmp.lt     s9, s1, s7
    s.mov        s6, s1
    br.nz        s9, __rctx_program
    exit
