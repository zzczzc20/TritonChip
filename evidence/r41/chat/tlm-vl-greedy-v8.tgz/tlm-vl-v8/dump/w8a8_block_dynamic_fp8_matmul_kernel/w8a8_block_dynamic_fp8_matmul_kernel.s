    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #32]                   // N: i32 at arg_base+32
    s.movz       s4, #0
    s.movz       s5, #0
    s.movz       s6, #128
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s6, s7
    s.rdspecial  s7, pid.x
    s.sub        s10, s8, s9
    s.movz       s8, #8
    s.rdspecial  s9, pid.y
    s.add        s11, s3, s2
    s.movz       s12, #0
    s.cmp.lt     s13, s11, s4
    s.movz       s4, #0
    s.sub        s14, s5, s13
    s.movz       s5, #0
    s.xor        s13, s11, s14
    s.xor        s11, s14, s10
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.lshri      s14, s15, #7
    s.xor        s16, s6, s10
    s.xor        s17, s14, s11
    s.muli       s18, s14, #128
    s.sub        s14, s17, s11
    s.ld.d       s11, [s1, #0]                   // A: device_ptr64 at arg_base+0
    s.mul        s17, s7, s14
    s.mul        s7, s14, s8
    s.movz       s14, #0
    s.sub        s19, s16, s10
    s.sub        s10, s15, s18
    s.add        s10, s17, s9
    s.cmp.lt     s9, s7, s12
    s.cmp.lt     s12, s10, s4
    s.sub        s4, s5, s9
    s.sub        s5, s13, s12
    s.xor        s9, s7, s4
    s.xor        s12, s10, s5
    s.sub        s13, s9, s4
    s.sub        s9, s12, s5
    s.ld.d       s12, [s1, #8]                   // B: device_ptr64 at arg_base+8
    s.movz       s15, #0
    s.ld.d       s16, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.addi       s17, s14, #0
    s.ld.d       s14, [s1, #24]                  // Bs: device_ptr64 at arg_base+24
    s.movz       s18, #1
    s.addi       s19, s15, #0
    s.ld.sw      s15, [s1, #40]                  // K: i32 at arg_base+40
    s.cmp.eq     s20, s13, s18
    s.ld.sw      s18, [s1, #56]                  // stride_bn: i32 at arg_base+56
    s.ld.sw      s21, [s1, #64]                  // stride_cm: i32 at arg_base+64
    s.ld.sw      s22, [s1, #72]                  // stride_bs_n: i32 at arg_base+72
    s.mov        s17, s9
    br.nz        s20, sdiv_done_1
    s.movz       s1, #0
    s.movz       s20, #31
    s.mov        s17, s1
    s.addi       s1, s20, #0
sdiv_2:
    s.lshr       s20, s9, s1
    s.shli       s23, s19, #1
    s.andi       s24, s20, #1
    s.movz       s20, #0
    s.or         s25, s23, s24
    s.movz       s23, #1
    s.cmp.geu    s24, s25, s13
    s.shl        s26, s23, s1
    s.sub        s23, s20, s24
    s.subi       s20, s1, #1
    s.and        s24, s13, s23
    s.and        s27, s26, s23
    s.sub        s23, s25, s24
    s.or         s24, s17, s27
    s.mov        s19, s23
    s.mov        s17, s24
    s.mov        s1, s20
    s.movz       s20, #0
    s.cmp.ge     s23, s1, s20
    br.nz        s23, sdiv_2
sdiv_done_1:
    s.xor        s1, s5, s4
    s.movz       s4, #0
    s.xor        s5, s17, s1
    s.movz       s9, #0
    s.movz       s13, #0
    s.cmp.lt     s17, s7, s4
    s.sub        s4, s5, s1
    s.movz       s1, #0
    s.cmp.lt     s5, s10, s9
    s.sub        s9, s13, s17
    s.mul        s13, s4, s8
    s.sub        s4, s1, s5
    s.xor        s1, s7, s9
    s.movz       s5, #1
    s.xor        s7, s10, s4
    s.sub        s10, s1, s9
    s.movz       s1, #0
    s.movz       s9, #1
    s.sub        s17, s5, s13
    s.sub        s19, s7, s4
    s.movz       s7, #0
    s.addi       s20, s1, #0
    s.cmp.eq     s1, s10, s9
    s.min.s      s9, s17, s8
    s.addi       s8, s7, #0
    s.mov        s20, s19
    br.nz        s1, sdiv_done_3
    s.movz       s1, #0
    s.movz       s7, #31
    s.mov        s20, s1
    s.addi       s1, s7, #0
sdiv_4:
    s.lshr       s7, s19, s1
    s.shli       s17, s8, #1
    s.andi       s23, s7, #1
    s.movz       s7, #0
    s.or         s24, s17, s23
    s.movz       s17, #1
    s.cmp.geu    s23, s24, s10
    s.shl        s25, s17, s1
    s.sub        s17, s7, s23
    s.subi       s7, s1, #1
    s.and        s23, s10, s17
    s.and        s26, s25, s17
    s.sub        s17, s24, s23
    s.or         s23, s20, s26
    s.mov        s8, s17
    s.mov        s20, s23
    s.mov        s1, s7
    s.movz       s7, #0
    s.cmp.ge     s17, s1, s7
    br.nz        s17, sdiv_4
sdiv_done_3:
    s.xor        s1, s8, s4
    s.movz       s7, #0
    s.sub        s8, s1, s4
    s.movz       s1, #0
    s.movz       s4, #0
    s.cmp.lt     s10, s9, s7
    s.movz       s7, #0
    s.cmp.lt     s17, s8, s1
    s.sub        s1, s4, s10
    s.sub        s4, s7, s17
    s.xor        s7, s9, s1
    s.xor        s10, s8, s4
    s.sub        s17, s7, s1
    s.movz       s1, #0
    s.movz       s7, #1
    s.sub        s19, s10, s4
    s.movz       s10, #0
    s.addi       s20, s1, #0
    s.cmp.eq     s1, s17, s7
    s.addi       s7, s10, #0
    s.mov        s20, s19
    br.nz        s1, sdiv_done_5
    s.movz       s1, #0
    s.movz       s10, #31
    s.mov        s20, s1
    s.addi       s1, s10, #0
sdiv_6:
    s.lshr       s10, s19, s1
    s.shli       s23, s7, #1
    s.andi       s24, s10, #1
    s.movz       s10, #0
    s.or         s25, s23, s24
    s.movz       s23, #1
    s.cmp.geu    s24, s25, s17
    s.shl        s26, s23, s1
    s.sub        s23, s10, s24
    s.subi       s10, s1, #1
    s.and        s24, s17, s23
    s.and        s27, s26, s23
    s.sub        s23, s25, s24
    s.or         s24, s20, s27
    s.mov        s7, s23
    s.mov        s20, s24
    s.mov        s1, s10
    s.movz       s10, #0
    s.cmp.ge     s23, s1, s10
    br.nz        s23, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.movz       s10, #0
    s.movz       s17, #0
    s.cmp.lt     s19, s9, s1
    s.movz       s1, #0
    s.cmp.lt     s20, s8, s10
    s.sub        s10, s17, s19
    s.sub        s17, s1, s20
    s.xor        s1, s9, s10
    s.xor        s9, s7, s4
    s.xor        s7, s8, s17
    s.sub        s8, s1, s10
    s.movz       s1, #0
    s.movz       s19, #1
    s.sub        s20, s9, s4
    s.sub        s4, s7, s17
    s.movz       s7, #0
    s.addi       s9, s1, #0
    s.cmp.eq     s1, s8, s19
    s.add        s19, s13, s20
    s.addi       s13, s7, #0
    s.mov        s9, s4
    br.nz        s1, sdiv_done_7
    s.movz       s1, #0
    s.movz       s7, #31
    s.mov        s9, s1
    s.addi       s1, s7, #0
sdiv_8:
    s.lshr       s7, s4, s1
    s.shli       s20, s13, #1
    s.andi       s23, s7, #1
    s.movz       s7, #0
    s.or         s24, s20, s23
    s.movz       s20, #1
    s.cmp.geu    s23, s24, s8
    s.shl        s25, s20, s1
    s.sub        s20, s7, s23
    s.subi       s7, s1, #1
    s.and        s23, s8, s20
    s.and        s26, s25, s20
    s.sub        s20, s24, s23
    s.or         s23, s9, s26
    s.mov        s13, s20
    s.mov        s9, s23
    s.mov        s1, s7
    s.movz       s7, #0
    s.cmp.ge     s20, s1, s7
    br.nz        s20, sdiv_8
sdiv_done_7:
    s.xor        s1, s17, s10
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s4, s9, s1
    v.iota       v1                              // arange(0, VLEN)
    s.sub        s7, s4, s1
    v.movi       v2, #16
    s.mul        s1, s7, s6
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #32
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #48
    v.splat      v7, s1
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #64
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #80
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #96
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #112
    v.add        v16, v7, v0
    v.splat      v0, s3
    v.movi       v7, #0
    v.add        v17, v1, v2
    v.add        v1, v3, v4
    v.add        v2, v5, v6
    v.add        v3, v8, v9
    v.add        v4, v10, v11
    v.add        v5, v12, v13
    v.add        v6, v14, v15
    v.splat      v8, s1
    v.splat      v9, s1
    v.splat      v10, s1
    v.splat      v11, s1
    v.splat      v12, s1
    v.splat      v13, s1
    v.splat      v14, s1
    v.sub        v15, v7, v16
    v.sub        v18, v7, v0
    v.cmp.lt     p1, v16, v7
    v.cmp.lt     p2, v0, v7
    v.add        v19, v8, v17
    v.add        v8, v9, v1
    v.add        v1, v10, v2
    v.add        v2, v11, v3
    v.add        v3, v12, v4
    v.add        v4, v13, v5
    v.add        v5, v14, v6
    v.splat      v6, s3
    v.splat      v9, s3
    v.splat      v10, s3
    v.splat      v11, s3
    v.splat      v12, s3
    v.splat      v13, s3
    v.splat      v14, s3
    v.movi       v17, #1
    @p1 v.sel        v20, v15, v16
    @p2 v.sel        v15, v18, v0
    v.movi       v0, #0
    v.movi       v16, #0
    s.movz       s4, #31
idiv_9:
    v.splat      v18, s4
    v.shl        v21, v16, v17
    v.cmp.lt     p2, v16, v7
    v.lshr       v22, v20, v18
    v.shl        v23, v17, v18
    s.subi       s7, s4, #1
    v.and        v18, v22, v17
    s.movz       s8, #0
    v.or         v22, v21, v18
    v.cmp.geu    p3, v22, v15
    p.or         p4, p2, p3
    v.sub        v18, v22, v15
    @p4 v.sel        v21, v23, v7
    @p4 v.sel        v23, v18, v22
    v.or         v18, v0, v21
    v.mov        v16, v23
    v.mov        v0, v18
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_9
    v.movi       v0, #0
    v.sub        v15, v7, v16
    v.movi       v7, #1
    v.sub        v17, v0, v19
    v.sub        v18, v0, v6
    v.cmp.lt     p2, v19, v0
    v.cmp.lt     p3, v6, v0
    @p1 v.sel        v20, v15, v16
    @p2 v.sel        v15, v17, v19
    @p3 v.sel        v16, v18, v6
    v.movi       v6, #0
    v.movi       v17, #0
    s.movz       s4, #31
idiv_10:
    v.splat      v18, s4
    v.shl        v19, v17, v7
    v.cmp.lt     p1, v17, v0
    v.lshr       v21, v15, v18
    v.shl        v22, v7, v18
    s.subi       s7, s4, #1
    v.and        v18, v21, v7
    s.movz       s8, #0
    v.or         v21, v19, v18
    v.cmp.geu    p3, v21, v16
    p.or         p4, p1, p3
    v.sub        v18, v21, v16
    @p4 v.sel        v19, v22, v0
    @p4 v.sel        v22, v18, v21
    v.or         v18, v6, v19
    v.mov        v17, v22
    v.mov        v6, v18
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_10
    v.movi       v6, #0
    v.sub        v7, v0, v17
    v.movi       v0, #1
    v.sub        v15, v6, v8
    v.sub        v16, v6, v9
    v.cmp.lt     p1, v8, v6
    v.cmp.lt     p3, v9, v6
    @p2 v.sel        v18, v7, v17
    @p1 v.sel        v7, v15, v8
    @p3 v.sel        v8, v16, v9
    v.movi       v9, #0
    v.movi       v15, #0
    s.movz       s4, #31
idiv_11:
    v.splat      v16, s4
    v.shl        v17, v15, v0
    v.cmp.lt     p2, v15, v6
    v.lshr       v19, v7, v16
    v.shl        v21, v0, v16
    s.subi       s7, s4, #1
    v.and        v16, v19, v0
    s.movz       s8, #0
    v.or         v19, v17, v16
    v.cmp.geu    p3, v19, v8
    p.or         p4, p2, p3
    v.sub        v16, v19, v8
    @p4 v.sel        v17, v21, v6
    @p4 v.sel        v21, v16, v19
    v.or         v16, v9, v17
    v.mov        v15, v21
    v.mov        v9, v16
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_11
    v.movi       v0, #0
    v.sub        v7, v6, v15
    v.movi       v6, #1
    v.sub        v8, v0, v1
    v.sub        v9, v0, v10
    v.cmp.lt     p2, v1, v0
    v.cmp.lt     p3, v10, v0
    @p1 v.sel        v16, v7, v15
    @p2 v.sel        v7, v8, v1
    @p3 v.sel        v1, v9, v10
    v.movi       v8, #0
    v.movi       v9, #0
    s.movz       s4, #31
idiv_12:
    v.splat      v10, s4
    v.shl        v15, v9, v6
    v.cmp.lt     p1, v9, v0
    v.lshr       v17, v7, v10
    v.shl        v19, v6, v10
    s.subi       s7, s4, #1
    v.and        v10, v17, v6
    s.movz       s8, #0
    v.or         v17, v15, v10
    v.cmp.geu    p3, v17, v1
    p.or         p4, p1, p3
    v.sub        v10, v17, v1
    @p4 v.sel        v15, v19, v0
    @p4 v.sel        v19, v10, v17
    v.or         v10, v8, v15
    v.mov        v9, v19
    v.mov        v8, v10
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_12
    v.movi       v1, #0
    v.sub        v6, v0, v9
    v.movi       v0, #1
    v.sub        v7, v1, v2
    v.sub        v8, v1, v11
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p3, v11, v1
    @p2 v.sel        v10, v6, v9
    @p1 v.sel        v6, v7, v2
    @p3 v.sel        v2, v8, v11
    v.movi       v7, #0
    v.movi       v8, #0
    s.movz       s4, #31
idiv_13:
    v.splat      v9, s4
    v.shl        v11, v8, v0
    v.cmp.lt     p2, v8, v1
    v.lshr       v15, v6, v9
    v.shl        v17, v0, v9
    s.subi       s7, s4, #1
    v.and        v9, v15, v0
    s.movz       s8, #0
    v.or         v15, v11, v9
    v.cmp.geu    p3, v15, v2
    p.or         p4, p2, p3
    v.sub        v9, v15, v2
    @p4 v.sel        v11, v17, v1
    @p4 v.sel        v17, v9, v15
    v.or         v9, v7, v11
    v.mov        v8, v17
    v.mov        v7, v9
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_13
    v.movi       v0, #0
    v.sub        v2, v1, v8
    v.movi       v1, #1
    v.sub        v6, v0, v3
    v.sub        v7, v0, v12
    v.cmp.lt     p2, v3, v0
    v.cmp.lt     p3, v12, v0
    @p1 v.sel        v9, v2, v8
    @p2 v.sel        v2, v6, v3
    @p3 v.sel        v3, v7, v12
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s4, #31
idiv_14:
    v.splat      v8, s4
    v.shl        v11, v7, v1
    v.cmp.lt     p1, v7, v0
    v.lshr       v12, v2, v8
    v.shl        v15, v1, v8
    s.subi       s7, s4, #1
    v.and        v8, v12, v1
    s.movz       s8, #0
    v.or         v12, v11, v8
    v.cmp.geu    p3, v12, v3
    p.or         p4, p1, p3
    v.sub        v8, v12, v3
    @p4 v.sel        v11, v15, v0
    @p4 v.sel        v15, v8, v12
    v.or         v8, v6, v11
    v.mov        v7, v15
    v.mov        v6, v8
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_14
    v.movi       v1, #0
    v.sub        v2, v0, v7
    v.movi       v0, #1
    v.sub        v3, v1, v4
    v.sub        v6, v1, v13
    v.cmp.lt     p1, v4, v1
    v.cmp.lt     p3, v13, v1
    @p2 v.sel        v8, v2, v7
    @p1 v.sel        v2, v3, v4
    @p3 v.sel        v3, v6, v13
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s4, #31
idiv_15:
    v.splat      v7, s4
    v.shl        v11, v6, v0
    v.cmp.lt     p2, v6, v1
    v.lshr       v12, v2, v7
    v.shl        v13, v0, v7
    s.subi       s7, s4, #1
    v.and        v7, v12, v0
    s.movz       s8, #0
    v.or         v12, v11, v7
    v.cmp.geu    p3, v12, v3
    p.or         p4, p2, p3
    v.sub        v7, v12, v3
    @p4 v.sel        v11, v13, v1
    @p4 v.sel        v13, v7, v12
    v.or         v7, v4, v11
    v.mov        v6, v13
    v.mov        v4, v7
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_15
    v.movi       v0, #0
    v.sub        v2, v1, v6
    v.movi       v1, #1
    v.sub        v3, v0, v5
    v.sub        v4, v0, v14
    v.cmp.lt     p2, v5, v0
    v.cmp.lt     p3, v14, v0
    @p1 v.sel        v7, v2, v6
    @p2 v.sel        v2, v3, v5
    @p3 v.sel        v3, v4, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s4, #31
idiv_16:
    v.splat      v6, s4
    v.shl        v11, v5, v1
    v.cmp.lt     p1, v5, v0
    v.lshr       v12, v2, v6
    v.shl        v13, v1, v6
    s.subi       s7, s4, #1
    v.and        v6, v12, v1
    s.movz       s8, #0
    v.or         v12, v11, v6
    v.cmp.geu    p3, v12, v3
    p.or         p4, p1, p3
    v.sub        v6, v12, v3
    @p4 v.sel        v11, v13, v0
    @p4 v.sel        v13, v6, v12
    v.or         v6, v4, v11
    v.mov        v5, v13
    v.mov        v4, v6
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_16
    v.sub        v1, v0, v5
    v.movi       v0, #0
    v.movi       v2, #0
    @p2 v.sel        v3, v1, v5
    v.movi       v1, #0
    v.movi       v4, #0
    v.sub        v5, v0, v20
    v.sub        v6, v2, v18
    v.sub        v11, v1, v16
    v.cmp.lt     p1, v20, v0
    v.cmp.lt     p2, v18, v2
    v.cmp.lt     p3, v16, v1
    @p1 v.sel        v12, v5, v20
    v.movi       v5, #7
    @p2 v.sel        v13, v6, v18
    v.movi       v6, #7
    @p3 v.sel        v14, v11, v16
    v.movi       v11, #7
    v.lshr       v15, v12, v5
    v.lshr       v5, v13, v6
    v.lshr       v6, v14, v11
    v.movi       v11, #128
    v.sub        v12, v0, v15
    v.movi       v13, #128
    v.sub        v14, v2, v5
    v.movi       v17, #128
    v.sub        v19, v1, v6
    v.movi       v21, #128
    v.sub        v22, v0, v11
    @p1 v.sel        v23, v12, v15
    v.sub        v12, v2, v13
    @p2 v.sel        v15, v14, v5
    v.sub        v5, v1, v17
    @p3 v.sel        v14, v19, v6
    v.cmp.lt     p1, v11, v0
    v.cmp.lt     p2, v13, v2
    v.cmp.lt     p3, v17, v1
    s.movz       s4, #16
    s.movz       s7, #32
    s.movz       s8, #48
    s.movz       s9, #64
    v.sub        v0, v4, v10
    s.movz       s10, #80
    s.movz       s13, #96
    v.sub        v1, v4, v21
    s.movz       s17, #112
    v.movi       v2, #7
    v.movi       v6, #1
    v.movi       v6, #0
    v.movi       v19, #128
    @p1 v.sel        v24, v22, v11
    v.sub        v11, v6, v9
    v.cmp.lt     p1, v10, v4
    @p1 v.sel        v22, v0, v10
    v.movi       v0, #7
    v.sub        v24, v6, v19
    v.lshr       v25, v22, v2
    v.movi       v2, #1
    v.movi       v2, #0
    v.sub        v22, v4, v25
    v.movi       v26, #128
    @p2 v.sel        v27, v12, v13
    v.sub        v12, v2, v8
    v.cmp.lt     p2, v9, v6
    @p2 v.sel        v13, v11, v9
    v.movi       v11, #7
    @p1 v.sel        v27, v22, v25
    v.cmp.lt     p1, v8, v2
    @p1 v.sel        v22, v12, v8
    v.lshr       v12, v13, v0
    v.sub        v0, v2, v26
    v.lshr       v13, v22, v11
    v.sub        v11, v6, v12
    v.movi       v22, #1
    v.movi       v22, #0
    v.sub        v25, v2, v13
    @p2 v.sel        v28, v11, v12
    v.cmp.lt     p2, v7, v22
    v.movi       v11, #128
    @p1 v.sel        v12, v25, v13
    v.cmp.lt     p1, v21, v4
    @p3 v.sel        v4, v5, v17
    v.sub        v4, v22, v7
    v.movi       v5, #7
    v.sub        v13, v22, v11
    @p2 v.sel        v17, v4, v7
    v.cmp.lt     p3, v19, v6
    v.movi       v4, #1
    v.movi       v4, #0
    v.lshr       v6, v17, v5
    v.movi       v5, #128
    @p1 v.sel        v17, v1, v21
    v.sub        v1, v4, v3
    v.cmp.lt     p1, v3, v4
    v.movi       v17, #7
    @p1 v.sel        v21, v1, v3
    v.sub        v1, v22, v6
    v.movi       v25, #1
    v.lshr       v25, v21, v17
    @p2 v.sel        v17, v1, v6
    v.sub        v1, v4, v5
    v.sub        v6, v4, v25
    v.cmp.lt     p2, v26, v2
    v.splat      v2, s22
    @p1 v.sel        v21, v6, v25
    v.splat      v6, s22
    v.cmp.lt     p1, v11, v22
    v.splat      v22, s22
    @p3 v.sel        v25, v24, v19
    v.splat      v19, s22
    v.splat      v24, s22
    v.cmp.lt     p3, v5, v4
    v.splat      v4, s22
    v.movi       v25, #1
    s.add        s20, s15, s2
    @p2 v.sel        v25, v0, v26
    s.movz       s2, #0
    s.movz       s23, #0
    s.cmp.lt     s24, s20, s2
    s.movz       s2, #0
    s.sub        s25, s23, s24
    s.movz       s23, #0
    s.cmp.lt     s24, s6, s2
    v.splat      v0, s22
    v.splat      v25, s22
    v.movi       v26, #1
    s.xor        s2, s20, s25
    s.sub        s20, s23, s24
    s.sub        s22, s2, s25
    s.xor        s2, s6, s20
    s.lshri      s23, s22, #7
    @p1 v.sel        v26, v13, v11
    s.muli       s24, s23, #128
    s.xor        s26, s25, s20
    s.movz       s25, #0
    s.xor        s27, s23, s26
    v.movi       v11, #1
    s.movz       s23, #0
    s.movz       s28, #0
    @p3 v.sel        v11, v1, v5
    v.mul        v1, v23, v2
    v.mul        v2, v15, v6
    v.mul        v5, v14, v22
    v.mul        v6, v27, v19
    v.mul        v11, v28, v24
    v.mul        v13, v12, v4
    v.mul        v4, v17, v0
    v.mul        v0, v21, v25
    s.sub        s29, s2, s20
    s.sub        s2, s22, s24
    s.sub        s2, s27, s26
    s.addi       s20, s25, #0
    s.addi       s22, s23, #0
    s.addi       s23, s28, #0
    s.addi       s24, s14, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_25:
    s.cmp.ge     s14, s20, s2
    br.nz        s14, endfor_26
    s.mul        s14, s20, s6
    s.movz       s26, #0
    s.muli       s27, s22, #2
    v.iota       v12                             // arange(0, VLEN)
    s.rdspecial  s28, arg_base
    s.sub        s29, s15, s14
    s.ld.d       s14, [s28, #80]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s28, s26, s29                   // the tile origin
    s.add        s26, s11, s27
    v.splat      v14, s28
    s.add        s28, s11, s27
    s.add        s30, s11, s27
    v.cmp.lt     p1, v12, v14
    s.add        s31, s11, s27
    s.add        s32, s11, s27
    s.add        s33, s11, s27
    s.add        s34, s11, s27
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s26, #0]
    s.addi       s26, s14, #0
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s28, #0]
    s.addi       s28, s26, #64
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s26, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s30, #0]
    s.addi       s30, s26, #192
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s26, #256
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s31, #0]
    s.addi       s31, s26, #320
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s26, #384
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.add        s32, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s26, #448
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.add        s33, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s26, #512
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.add        s34, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s26, #576
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.add        s32, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s26, #640
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.add        s33, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s26, #704
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.add        s34, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s26, #768
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.add        s32, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s26, #832
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.add        s33, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s26, #896
    s.addi       s35, s26, #960
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.add        s26, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.movz       s30, #0
    s.add        s34, s30, s4                    // the tile origin
    v.splat      v14, s34
    s.movz       s30, #0
    s.add        s34, s30, s29                   // the tile origin
    v.add        v15, v12, v14
    v.splat      v14, s34
    s.addi       s30, s27, #32
    s.add        s34, s11, s30
    v.cmp.lt     p2, v15, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s30, s27, #32
    s.add        s32, s11, s30
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s14, #1024
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s30, s27, #32
    s.add        s33, s11, s30
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s30, s28, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s26, #0]
    s.addi       s26, s27, #32
    s.add        s31, s11, s26
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s35, #0], v15
    fence.acq_rel.device
    s.addi       s26, s28, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s34, s27, #32
    s.add        s35, s11, s34
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s32, s28, #192
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #32
    s.add        s34, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s28, #256
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #32
    s.add        s33, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s31, #0]
    s.addi       s26, s28, #320
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s31, s27, #32
    s.add        s32, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s31, s28, #384
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #32
    s.add        s35, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s30, s28, #448
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #32
    s.add        s34, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s26, s28, #512
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #32
    s.add        s33, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s31, s28, #576
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #32
    s.add        s32, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s30, s28, #640
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #32
    s.add        s35, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s26, s28, #704
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #32
    s.add        s34, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s31, s28, #768
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #32
    s.add        s33, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s30, s28, #832
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #32
    s.add        s32, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s26, s28, #896
    s.addi       s35, s28, #960
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.movz       s28, #0
    s.add        s31, s28, s7                    // the tile origin
    s.movz       s28, #0
    v.splat      v14, s31
    s.add        s31, s28, s29                   // the tile origin
    s.addi       s28, s27, #64
    v.add        v15, v12, v14
    v.splat      v14, s31
    s.add        s31, s11, s28
    s.addi       s28, s27, #64
    v.cmp.lt     p1, v15, v14
    s.add        s36, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s28, s14, #2048
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #64
    s.add        s34, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s28, #64
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #64
    s.add        s33, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s26, s28, #128
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s35, #0], v15
    fence.acq_rel.device
    s.addi       s32, s27, #64
    s.add        s35, s11, s32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s31, #0]
    s.addi       s31, s28, #192
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.addi       s32, s27, #64
    s.add        s36, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s28, #256
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s32, s27, #64
    s.add        s34, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s28, #320
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s32, s27, #64
    s.add        s33, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s28, #384
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s32, s27, #64
    s.add        s35, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s28, #448
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.addi       s32, s27, #64
    s.add        s36, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s28, #512
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s32, s27, #64
    s.add        s34, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s28, #576
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s32, s27, #64
    s.add        s33, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s28, #640
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s32, s27, #64
    s.add        s35, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s28, #704
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.addi       s32, s27, #64
    s.add        s36, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s28, #768
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s32, s27, #64
    s.add        s34, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s28, #832
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s32, s27, #64
    s.add        s33, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s28, #896
    s.addi       s32, s28, #960
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.movz       s28, #0
    s.add        s35, s28, s8                    // the tile origin
    s.movz       s28, #0
    v.splat      v15, s35
    s.add        s35, s28, s29                   // the tile origin
    s.addi       s28, s27, #96
    v.add        v17, v12, v15
    v.splat      v15, s35
    s.add        s35, s11, s28
    s.addi       s28, s27, #96
    v.cmp.lt     p2, v17, v15
    s.add        s37, s11, s28
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s28, s14, #3072
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.addi       s31, s27, #96
    s.add        s36, s11, s31
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s28, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s31, s27, #96
    s.add        s34, s11, s31
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s28, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s31, s27, #96
    s.add        s33, s11, s31
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    fence.acq_rel.device
    s.addi       s31, s28, #192
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s32, s27, #96
    s.add        s35, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s37, #0]
    s.addi       s32, s28, #256
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #96
    s.add        s37, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s36, #0]
    s.addi       s30, s28, #320
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #96
    s.add        s36, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s26, s28, #384
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #96
    s.add        s34, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s31, s28, #448
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s32, s27, #96
    s.add        s33, s11, s32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s32, s28, #512
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #96
    s.add        s35, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s37, #0]
    s.addi       s30, s28, #576
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #96
    s.add        s37, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s36, #0]
    s.addi       s26, s28, #640
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #96
    s.add        s36, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s31, s28, #704
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s32, s27, #96
    s.add        s34, s11, s32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s32, s28, #768
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #96
    s.add        s33, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s30, s28, #832
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #96
    s.add        s35, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s37, #0]
    s.addi       s26, s28, #896
    s.addi       s37, s28, #960
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.movz       s28, #0
    s.add        s31, s28, s9                    // the tile origin
    s.movz       s28, #0
    v.splat      v14, s31
    s.add        s31, s28, s29                   // the tile origin
    s.addi       s28, s27, #128
    v.add        v15, v12, v14
    v.splat      v14, s31
    s.add        s31, s11, s28
    s.addi       s28, s27, #128
    v.cmp.lt     p1, v15, v14
    s.add        s38, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s36, #0]
    s.addi       s28, s14, #4096
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s32, s27, #128
    s.add        s36, s11, s32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s32, s28, #64
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #128
    s.add        s34, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s28, #128
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #128
    s.add        s33, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s26, s28, #192
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s37, #0], v15
    fence.acq_rel.device
    s.addi       s35, s27, #128
    s.add        s37, s11, s35
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s31, #0]
    s.addi       s31, s28, #256
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    s.addi       s35, s27, #128
    s.add        s38, s11, s35
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s32, s28, #320
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.addi       s35, s27, #128
    s.add        s36, s11, s35
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s28, #384
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s34, s27, #128
    s.add        s35, s11, s34
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s28, #448
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s33, s27, #128
    s.add        s34, s11, s33
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s28, #512
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.addi       s33, s27, #128
    s.add        s37, s11, s33
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s32, s28, #576
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    s.addi       s33, s27, #128
    s.add        s38, s11, s33
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s28, #640
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.addi       s33, s27, #128
    s.add        s36, s11, s33
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s28, #704
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s33, s27, #128
    s.add        s35, s11, s33
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s28, #768
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s33, s27, #128
    s.add        s34, s11, s33
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s32, s28, #832
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.addi       s33, s27, #128
    s.add        s37, s11, s33
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s28, #896
    s.addi       s33, s28, #960
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    s.movz       s28, #0
    s.add        s38, s28, s10                   // the tile origin
    s.movz       s28, #0
    v.splat      v15, s38
    s.add        s38, s28, s29                   // the tile origin
    s.addi       s28, s27, #160
    v.add        v17, v12, v15
    v.splat      v15, s38
    s.add        s38, s11, s28
    s.addi       s28, s27, #160
    v.cmp.lt     p2, v17, v15
    s.add        s39, s11, s28
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s14, #5120
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.addi       s28, s27, #160
    s.add        s36, s11, s28
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s28, s26, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s31, s27, #160
    s.add        s35, s11, s31
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s31, s26, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s32, s27, #160
    s.add        s34, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s26, #192
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.addi       s32, s27, #160
    s.add        s37, s11, s32
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s33, #0], v15
    fence.acq_rel.device
    s.addi       s32, s26, #256
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s38, #0]
    s.addi       s33, s27, #160
    s.add        s38, s11, s33
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s39, #0]
    s.addi       s33, s26, #320
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #160
    s.add        s39, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s36, #0]
    s.addi       s28, s26, #384
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #160
    s.add        s36, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s31, s26, #448
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #160
    s.add        s35, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s30, s26, #512
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s32, s27, #160
    s.add        s34, s11, s32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s37, #0]
    s.addi       s32, s26, #576
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s33, #0], v15
    s.addi       s33, s27, #160
    s.add        s37, s11, s33
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s38, #0]
    s.addi       s33, s26, #640
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #160
    s.add        s38, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s39, #0]
    s.addi       s28, s26, #704
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #160
    s.add        s39, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s36, #0]
    s.addi       s31, s26, #768
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #160
    s.add        s36, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s30, s26, #832
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s32, s27, #160
    s.add        s35, s11, s32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s32, s26, #896
    s.addi       s34, s26, #960
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s33, #0], v15
    s.movz       s26, #0
    s.add        s33, s26, s13                   // the tile origin
    s.movz       s26, #0
    v.splat      v14, s33
    s.add        s33, s26, s29                   // the tile origin
    s.addi       s26, s27, #192
    v.add        v15, v12, v14
    v.splat      v14, s33
    s.add        s33, s11, s26
    s.addi       s26, s27, #192
    v.cmp.lt     p1, v15, v14
    s.add        s40, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s37, #0]
    s.addi       s26, s14, #6144
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #192
    s.add        s37, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s38, #0]
    s.addi       s28, s26, #64
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #192
    s.add        s38, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s39, #0]
    s.addi       s31, s26, #128
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #192
    s.add        s39, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s36, #0]
    s.addi       s30, s26, #192
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s32, s27, #192
    s.add        s36, s11, s32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s32, s26, #256
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s34, #0], v15
    fence.acq_rel.device
    s.addi       s34, s27, #192
    s.add        s35, s11, s34
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s33, s26, #320
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s40, #0]
    s.addi       s34, s27, #192
    s.add        s40, s11, s34
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s26, #384
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.addi       s34, s27, #192
    s.add        s37, s11, s34
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s26, #448
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    s.addi       s34, s27, #192
    s.add        s38, s11, s34
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s26, #512
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    s.addi       s34, s27, #192
    s.add        s39, s11, s34
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s32, s26, #576
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s36, #0]
    s.addi       s34, s27, #192
    s.add        s36, s11, s34
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s33, #0], v15
    s.addi       s33, s26, #640
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s34, s27, #192
    s.add        s35, s11, s34
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s26, #704
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s40, #0]
    s.addi       s34, s27, #192
    s.add        s40, s11, s34
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s26, #768
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s37, #0]
    s.addi       s34, s27, #192
    s.add        s37, s11, s34
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s26, #832
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s38, #0]
    s.addi       s34, s27, #192
    s.add        s38, s11, s34
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s32, s26, #896
    s.addi       s34, s26, #960
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s39, #0]
    s.movz       s26, #0
    s.add        s39, s26, s17                   // the tile origin
    s.movz       s26, #0
    v.splat      v15, s39
    s.add        s39, s26, s29                   // the tile origin
    s.addi       s26, s27, #224
    v.add        v17, v12, v15
    v.splat      v12, s39
    s.add        s39, s11, s26
    s.addi       s26, s14, #7168
    v.cmp.lt     p2, v17, v12
    vf.cvt.bf16.f32 v12, v14
    v.st.w       [s33, #0], v12
    s.addi       s33, s27, #224
    s.add        s41, s11, s33
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s36, #0]
    s.addi       s33, s26, #64
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s28, #0], v14
    s.addi       s28, s27, #224
    s.add        s36, s11, s28
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s35, #0]
    s.addi       s28, s26, #128
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s31, #0], v14
    s.addi       s31, s27, #224
    s.add        s35, s11, s31
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s40, #0]
    s.addi       s31, s26, #192
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s30, #0], v14
    s.addi       s30, s27, #224
    s.add        s40, s11, s30
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s37, #0]
    s.addi       s30, s26, #256
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s32, #0], v14
    s.addi       s32, s27, #224
    s.add        s37, s11, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s38, #0]
    s.addi       s32, s26, #320
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s34, #0], v14
    fence.acq_rel.device
    s.addi       s34, s27, #224
    s.add        s38, s11, s34
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s39, #0]
    s.addi       s34, s27, #224
    s.add        s39, s11, s34
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s26, #0], v14
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s41, #0]
    s.addi       s34, s26, #384
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s33, #0], v14
    s.addi       s33, s27, #224
    s.add        s41, s11, s33
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s36, #0]
    s.addi       s33, s26, #448
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s28, #0], v14
    s.addi       s28, s27, #224
    s.add        s36, s11, s28
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s35, #0]
    s.addi       s28, s26, #512
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s31, #0], v14
    s.addi       s31, s27, #224
    s.add        s35, s11, s31
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s40, #0]
    s.addi       s31, s26, #576
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s30, #0], v14
    s.addi       s30, s27, #224
    s.add        s40, s11, s30
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s37, #0]
    s.addi       s30, s26, #640
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s32, #0], v14
    s.addi       s32, s27, #224
    s.add        s37, s11, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s38, #0]
    s.addi       s32, s26, #704
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s34, #0], v14
    s.addi       s34, s27, #224
    s.add        s38, s11, s34
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s39, #0]
    s.addi       s34, s26, #768
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s33, #0], v14
    s.addi       s33, s27, #224
    s.addi       s39, s27, #224
    s.add        s27, s11, s33
    s.add        s33, s11, s39
    s.addi       s39, s26, #832
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s41, #0]
    s.addi       s41, s26, #896
    s.addi       s42, s26, #960
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s28, #0], v14
    s.addi       s26, s14, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s36, #0]
    s.addi       s28, s14, #1024
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s31, #0], v14
    s.addi       s31, s14, #2048
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s35, #0]
    s.addi       s35, s14, #3072
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s30, #0], v14
    s.addi       s30, s14, #4096
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s40, #0]
    s.addi       s36, s14, #5120
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s32, #0], v14
    s.addi       s32, s14, #6144
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s37, #0]
    vf.cvt.bf16.f32 v14, v12
    s.addi       s37, s14, #7168
    v.st.w       [s34, #0], v14
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s38, #0]
    s.addi       s34, s14, #64
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s39, #0], v14
    s.addi       s38, s14, #1088
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s27, #0]
    vf.cvt.bf16.f32 v14, v12
    s.addi       s27, s14, #2112
    v.st.w       [s41, #0], v14
    s.addi       s39, s14, #3136
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s42, #0], v14
    fence.acq_rel.device
    s.addi       s33, s14, #4160
    v.ld.w       v12, [s26, #0]
    v.ld.w       v14, [s28, #0]
    vf.abs       v15, v12
    s.addi       s26, s14, #5184
    v.ld.w       v12, [s34, #0]
    vf.abs       v17, v14
    vf.max.ieee  v14, v15, v17
    s.addi       s28, s14, #6208
    v.ld.w       v15, [s38, #0]
    vf.abs       v17, v12
    v.ld.w       v12, [s31, #0]
    vf.abs       v19, v15
    vf.max.ieee  v15, v17, v19
    v.ld.w       v17, [s27, #0]
    vf.abs       v19, v12
    vf.max.ieee  v12, v14, v19
    s.addi       s27, s14, #7232
    v.ld.w       v14, [s35, #0]
    vf.abs       v19, v17
    vf.max.ieee  v17, v15, v19
    v.ld.w       v15, [s39, #0]
    vf.abs       v19, v14
    vf.max.ieee  v14, v12, v19
    v.ld.w       v12, [s30, #0]
    s.addi       s30, s14, #128
    vf.abs       v19, v15
    vf.max.ieee  v15, v17, v19
    v.ld.w       v17, [s33, #0]
    vf.abs       v19, v12
    vf.max.ieee  v12, v14, v19
    s.addi       s31, s14, #1152
    v.ld.w       v14, [s30, #0]
    vf.abs       v19, v17
    vf.max.ieee  v17, v15, v19
    v.ld.w       v15, [s36, #0]
    vf.abs       v19, v14
    v.ld.w       v14, [s31, #0]
    vf.abs       v21, v15
    vf.max.ieee  v15, v12, v21
    s.addi       s30, s14, #2176
    v.ld.w       v12, [s26, #0]
    vf.abs       v21, v14
    vf.max.ieee  v14, v19, v21
    v.ld.w       v19, [s32, #0]
    vf.abs       v21, v12
    vf.max.ieee  v12, v17, v21
    v.ld.w       v17, [s30, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v15, v21
    s.addi       s26, s14, #3200
    v.ld.w       v15, [s28, #0]
    vf.abs       v21, v17
    vf.max.ieee  v17, v14, v21
    v.ld.w       v14, [s37, #0]
    vf.abs       v21, v15
    vf.max.ieee  v15, v12, v21
    v.ld.w       v12, [s26, #0]
    vf.abs       v21, v14
    vf.max.ieee  v14, v19, v21
    vf.reduce.max.b v19, v14
    s.addi       s26, s14, #192
    s.addi       s28, s14, #1216
    s.addi       s30, s14, #2240
    s.addi       s31, s14, #3264
    s.addi       s32, s14, #4224
    s.addi       s33, s14, #5248
    v.ld.w       v14, [s26, #0]
    s.addi       s26, s14, #6272
    vf.abs       v21, v12
    s.addi       s34, s14, #7296
    vf.max.ieee  v12, v17, v21
    v.ld.w       v17, [s28, #0]
    vf.abs       v21, v14
    v.ld.w       v14, [s30, #0]
    vf.abs       v22, v17
    vf.max.ieee  v17, v21, v22
    v.ld.w       v21, [s32, #0]
    vf.abs       v22, v14
    vf.max.ieee  v14, v17, v22
    v.ld.w       v17, [s33, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v12, v22
    v.ld.w       v12, [s26, #0]
    vf.abs       v22, v17
    vf.max.ieee  v17, v21, v22
    v.ld.w       v21, [s27, #0]
    vf.abs       v22, v12
    vf.max.ieee  v12, v17, v22
    v.ld.w       v17, [s31, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v15, v22
    vf.reduce.max.b v15, v21
    s.addi       s26, s14, #256
    s.addi       s27, s14, #1280
    s.addi       s28, s14, #2304
    s.addi       s30, s14, #3328
    s.addi       s31, s14, #4288
    s.addi       s32, s14, #5312
    v.ld.w       v21, [s26, #0]
    s.addi       s26, s14, #6336
    vf.abs       v22, v17
    s.addi       s33, s14, #7360
    vf.max.ieee  v17, v14, v22
    v.ld.w       v14, [s27, #0]
    vf.abs       v22, v21
    v.ld.w       v21, [s28, #0]
    vf.abs       v23, v14
    vf.max.ieee  v14, v22, v23
    v.ld.w       v22, [s31, #0]
    vf.abs       v23, v21
    vf.max.ieee  v21, v14, v23
    v.ld.w       v14, [s32, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v17, v23
    v.ld.w       v17, [s26, #0]
    vf.abs       v23, v14
    vf.max.ieee  v14, v22, v23
    v.ld.w       v22, [s34, #0]
    vf.abs       v23, v17
    vf.max.ieee  v17, v14, v23
    v.ld.w       v14, [s30, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v12, v23
    vf.reduce.max.b v12, v22
    s.addi       s26, s14, #320
    s.addi       s27, s14, #1344
    s.addi       s28, s14, #2368
    s.addi       s30, s14, #3392
    s.addi       s31, s14, #4352
    s.addi       s32, s14, #5376
    v.ld.w       v22, [s26, #0]
    s.addi       s26, s14, #6400
    vf.abs       v23, v14
    s.addi       s34, s14, #7424
    vf.max.ieee  v14, v21, v23
    v.ld.w       v21, [s27, #0]
    vf.abs       v23, v22
    v.ld.w       v22, [s28, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    v.ld.w       v23, [s31, #0]
    vf.abs       v24, v22
    vf.max.ieee  v22, v21, v24
    v.ld.w       v21, [s32, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v14, v24
    v.ld.w       v14, [s26, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    v.ld.w       v23, [s33, #0]
    vf.abs       v24, v14
    vf.max.ieee  v14, v21, v24
    v.ld.w       v21, [s30, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v17, v24
    vf.reduce.max.b v17, v23
    s.addi       s26, s14, #384
    s.addi       s27, s14, #1408
    s.addi       s28, s14, #2432
    s.addi       s30, s14, #3456
    s.addi       s31, s14, #4416
    s.addi       s32, s14, #5440
    v.ld.w       v23, [s26, #0]
    s.addi       s26, s14, #6464
    vf.abs       v24, v21
    s.addi       s33, s14, #7488
    vf.max.ieee  v21, v22, v24
    v.ld.w       v22, [s27, #0]
    vf.abs       v24, v23
    v.ld.w       v23, [s28, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    v.ld.w       v24, [s31, #0]
    vf.abs       v25, v23
    vf.max.ieee  v23, v22, v25
    v.ld.w       v22, [s32, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v21, v25
    v.ld.w       v21, [s26, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    v.ld.w       v24, [s34, #0]
    vf.abs       v25, v21
    vf.max.ieee  v21, v22, v25
    v.ld.w       v22, [s30, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v14, v25
    vf.reduce.max.b v14, v24
    s.addi       s26, s14, #448
    s.addi       s27, s14, #1472
    s.addi       s28, s14, #2496
    s.addi       s30, s14, #3520
    s.addi       s31, s14, #4480
    s.addi       s32, s14, #5504
    v.ld.w       v24, [s26, #0]
    s.addi       s26, s14, #6528
    vf.abs       v25, v22
    s.addi       s34, s14, #7552
    vf.max.ieee  v22, v23, v25
    v.ld.w       v23, [s27, #0]
    vf.abs       v25, v24
    v.ld.w       v24, [s28, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    v.ld.w       v25, [s31, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v23, v26
    v.ld.w       v23, [s32, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v22, v26
    v.ld.w       v22, [s26, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    v.ld.w       v25, [s33, #0]
    vf.abs       v26, v22
    vf.max.ieee  v22, v23, v26
    v.ld.w       v23, [s30, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v21, v26
    vf.reduce.max.b v21, v25
    s.addi       s26, s14, #512
    s.addi       s27, s14, #1536
    s.addi       s28, s14, #2560
    s.addi       s30, s14, #3584
    s.addi       s31, s14, #4544
    s.addi       s32, s14, #5568
    v.ld.w       v25, [s26, #0]
    s.addi       s26, s14, #6592
    vf.abs       v26, v23
    s.addi       s33, s14, #7616
    vf.max.ieee  v23, v24, v26
    v.ld.w       v24, [s27, #0]
    vf.abs       v26, v25
    v.ld.w       v25, [s28, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    v.ld.w       v26, [s31, #0]
    vf.abs       v27, v25
    vf.max.ieee  v25, v24, v27
    v.ld.w       v24, [s32, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v23, v27
    v.ld.w       v23, [s26, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    v.ld.w       v26, [s34, #0]
    vf.abs       v27, v23
    vf.max.ieee  v23, v24, v27
    v.ld.w       v24, [s30, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v22, v27
    vf.reduce.max.b v22, v26
    s.addi       s26, s14, #576
    s.addi       s27, s14, #1600
    s.addi       s28, s14, #2624
    s.addi       s30, s14, #3648
    s.addi       s31, s14, #4608
    s.addi       s32, s14, #5632
    v.ld.w       v26, [s26, #0]
    s.addi       s26, s14, #6656
    vf.abs       v27, v24
    s.addi       s34, s14, #7680
    vf.max.ieee  v24, v25, v27
    v.ld.w       v25, [s27, #0]
    vf.abs       v27, v26
    v.ld.w       v26, [s28, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    v.ld.w       v27, [s31, #0]
    vf.abs       v28, v26
    vf.max.ieee  v26, v25, v28
    v.ld.w       v25, [s32, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v24, v28
    v.ld.w       v24, [s26, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    v.ld.w       v27, [s33, #0]
    vf.abs       v28, v24
    vf.max.ieee  v24, v25, v28
    v.ld.w       v25, [s30, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v23, v28
    vf.reduce.max.b v23, v27
    s.addi       s26, s14, #640
    s.addi       s27, s14, #1664
    s.addi       s28, s14, #2688
    s.addi       s30, s14, #3712
    s.addi       s31, s14, #4672
    s.addi       s32, s14, #5696
    v.ld.w       v27, [s26, #0]
    s.addi       s26, s14, #6720
    vf.abs       v28, v25
    s.addi       s33, s14, #7744
    vf.max.ieee  v25, v26, v28
    v.ld.w       v26, [s27, #0]
    vf.abs       v28, v27
    v.ld.w       v27, [s28, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    v.ld.w       v28, [s31, #0]
    vf.abs       v29, v27
    vf.max.ieee  v27, v26, v29
    v.ld.w       v26, [s32, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v25, v29
    v.ld.w       v25, [s26, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    v.ld.w       v28, [s34, #0]
    vf.abs       v29, v25
    vf.max.ieee  v25, v26, v29
    v.ld.w       v26, [s30, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v24, v29
    vf.reduce.max.b v24, v28
    s.addi       s26, s14, #704
    s.addi       s27, s14, #1728
    s.addi       s28, s14, #2752
    s.addi       s30, s14, #3776
    s.addi       s31, s14, #4736
    s.addi       s32, s14, #5760
    v.ld.w       v28, [s26, #0]
    s.addi       s26, s14, #6784
    vf.abs       v29, v26
    s.addi       s34, s14, #7808
    vf.max.ieee  v26, v27, v29
    v.ld.w       v27, [s27, #0]
    vf.abs       v29, v28
    v.ld.w       v28, [s28, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    v.ld.w       v29, [s31, #0]
    vf.abs       v30, v28
    vf.max.ieee  v28, v27, v30
    v.ld.w       v27, [s32, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v26, v30
    v.ld.w       v26, [s26, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    v.ld.w       v29, [s33, #0]
    vf.abs       v30, v26
    vf.max.ieee  v26, v27, v30
    v.ld.w       v27, [s30, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v25, v30
    vf.reduce.max.b v25, v29
    s.addi       s26, s14, #768
    s.addi       s27, s14, #1792
    s.addi       s28, s14, #2816
    s.addi       s30, s14, #3840
    s.addi       s31, s14, #4800
    s.addi       s32, s14, #5824
    v.ld.w       v29, [s26, #0]
    s.addi       s26, s14, #6848
    vf.abs       v30, v27
    s.addi       s33, s14, #7872
    vf.max.ieee  v27, v28, v30
    v.ld.w       v28, [s27, #0]
    vf.abs       v30, v29
    v.ld.w       v29, [s28, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    v.ld.w       v30, [s31, #0]
    vf.abs       v31, v29
    vf.max.ieee  v29, v28, v31
    v.ld.w       v28, [s32, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v27, v31
    v.ld.w       v27, [s26, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    v.ld.w       v30, [s34, #0]
    vf.abs       v31, v27
    vf.max.ieee  v27, v28, v31
    v.ld.w       v28, [s30, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v26, v31
    vf.reduce.max.b v26, v30
    s.addi       s26, s14, #832
    s.addi       s27, s14, #1856
    s.addi       s28, s14, #2880
    s.addi       s30, s14, #3904
    s.addi       s31, s14, #4864
    s.addi       s32, s14, #5888
    v.ld.w       v30, [s26, #0]
    s.addi       s26, s14, #6912
    s.addi       s34, s14, #7936
    vf.abs       v31, v28
    vf.max.ieee  v28, v29, v31
    v.ld.w       v29, [s27, #0]
    vf.abs       v31, v30
    v.ld.w       v30, [s28, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    v.ld.w       v31, [s31, #0]
    vf.abs       v32, v30
    vf.max.ieee  v30, v29, v32
    v.ld.w       v29, [s32, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v28, v32
    v.ld.w       v28, [s26, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    v.ld.w       v31, [s33, #0]
    vf.abs       v32, v28
    vf.max.ieee  v28, v29, v32
    v.ld.w       v29, [s30, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v27, v32
    vf.reduce.max.b v27, v31
    s.addi       s26, s14, #896
    s.addi       s27, s14, #1920
    s.addi       s28, s14, #2944
    s.addi       s30, s14, #3968
    s.addi       s31, s14, #4928
    s.addi       s32, s14, #5952
    v.ld.w       v31, [s26, #0]
    s.addi       s26, s14, #6976
    s.addi       s33, s14, #8000
    vf.abs       v32, v29
    vf.max.ieee  v29, v30, v32
    v.ld.w       v30, [s27, #0]
    vf.abs       v32, v31
    v.ld.w       v31, [s28, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v32, v33
    v.ld.w       v32, [s31, #0]
    vf.abs       v33, v31
    vf.max.ieee  v31, v30, v33
    v.ld.w       v30, [s32, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v29, v33
    v.ld.w       v29, [s34, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v32, v33
    v.ld.w       v32, [s30, #0]
    vf.abs       v33, v29
    vf.max.ieee  v29, v28, v33
    vf.reduce.max.b v28, v29
    s.addi       s27, s14, #960
    s.addi       s28, s14, #1984
    s.addi       s30, s14, #3008
    s.addi       s31, s14, #4992
    s.addi       s32, s14, #6016
    s.addi       s34, s14, #7040
    v.ld.w       v29, [s27, #0]
    s.addi       s27, s14, #8064
    vf.abs       v33, v32
    vf.max.ieee  v32, v31, v33
    v.ld.w       v31, [s28, #0]
    vf.abs       v33, v29
    v.ld.w       v29, [s31, #0]
    vf.abs       v34, v31
    vf.max.ieee  v31, v33, v34
    v.ld.w       v33, [s32, #0]
    vf.abs       v34, v29
    vf.max.ieee  v29, v32, v34
    v.ld.w       v32, [s26, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v29, v34
    v.ld.w       v29, [s30, #0]
    vf.abs       v34, v32
    vf.max.ieee  v32, v30, v34
    s.addi       s26, s14, #4032
    v.ld.w       v30, [s33, #0]
    vf.abs       v34, v29
    vf.max.ieee  v29, v31, v34
    v.ld.w       v31, [s26, #0]
    vf.abs       v34, v30
    vf.max.ieee  v30, v32, v34
    vf.reduce.max.b v32, v30
    s.addi       s26, s14, #5056
    v.movi       v30, #0
    s.addi       s28, s14, #6080
    s.addi       s30, s14, #7104
    s.addi       s31, s14, #8128
    // one value per row into one vector (ISA 0x09)
    v.extract    s32, v19, #0
    v.ld.w       v19, [s26, #0]
    v.extract    s26, v15, #0
    v.extract    s33, v12, #0
    v.extract    s35, v17, #0
    vf.abs       v12, v31
    vf.max.ieee  v15, v29, v12
    v.ld.w       v12, [s34, #0]
    vf.abs       v17, v19
    vf.max.ieee  v19, v15, v17
    v.ld.w       v15, [s27, #0]
    vf.abs       v17, v12
    v.extract    s27, v14, #0
    vf.max.ieee  v12, v33, v17
    v.extract    s34, v21, #0
    v.ld.w       v14, [s28, #0]
    vf.abs       v17, v15
    v.extract    s28, v22, #0
    vf.max.ieee  v15, v12, v17
    vf.reduce.max.b v12, v15
    .li       s36, #1138753536
    v.splat      v15, s36                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s36, v23, #0
    v.extract    s37, v24, #0
    v.rcp.approx v17, v15                        // ISA 8.8: <= 2**-22 relative
    v.extract    s38, v25, #0
    .li       s39, #1065353216
    v.splat      v21, s39                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v22, [s30, #0]
    vf.abs       v23, v14
    v.extract    s30, v26, #0
    v.extract    s39, v27, #0
    v.extract    s40, v28, #0
    v.extract    s41, v32, #0
    vf.max.ieee  v14, v19, v23
    v.ld.w       v19, [s31, #0]
    v.insert     v30, s32, #0
    vf.abs       v23, v22
    v.extract    s31, v12, #0
    v.insert     v30, s26, #1
    v.insert     v30, s33, #2
    vf.fms       v12, v15, v17, v21
    vf.max.ieee  v22, v14, v23
    v.insert     v30, s35, #3
    v.insert     v30, s27, #4
    vf.fms       v14, v17, v12, v17
    v.insert     v30, s34, #5
    vf.abs       v12, v19
    v.insert     v30, s28, #6
    vf.neg       v19, v14                        // Newton step: r0*(2 - x*r0)
    v.insert     v30, s36, #7
    vf.max.ieee  v14, v22, v12
    v.insert     v30, s37, #8
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v12, v19, v17
    v.insert     v30, s38, #9
    vf.reduce.max.b v17, v14
    .li       s26, #730643660
    v.splat      v14, s26                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.insert     v30, s30, #10
    v.extract    s26, v17, #0
    v.splat      v17, s18
    v.insert     v30, s39, #11
    // tl.dot 16x128 by 128x128 FP8 as (B^T A^T)^T: B^T rows are contiguous loads, A is scattered into the MMA B operand
    v.iota       v19                             // arange(0, VLEN)
    s.add        s27, s25, s29
    v.insert     v30, s40, #12
    s.movz       s28, #16
    v.mul        v22, v20, v17
    v.insert     v30, s41, #13
    v.splat      v17, s28
    v.iota       v23                             // arange(0, VLEN)
    v.insert     v30, s31, #14
    v.mul        v24, v19, v17
    v.movi       v17, #7
    v.insert     v30, s26, #15
    v.ld.gather.w v19, [s24, v1]                 // index is in elements (ISA sec 9.1)
    v.and        v25, v23, v17
    vf.mul       v17, v30, v12                   // a/y: faithful quotient
    v.movi       v23, #2
    v.iota       v26                             // arange(0, VLEN)
    v.movi       v27, #3
    v.shl        v28, v25, v23
    vf.fms       v23, v17, v15, v30
    v.iota       v15                             // arange(0, VLEN)
    v.movi       v25, #3
    v.lshr       v29, v26, v27
    v.movi       v26, #0
    vf.fms       v27, v23, v12, v17
    v.lshr       v12, v15, v25
    v.movi       v15, #1
    v.cmp.eq     p1, v29, v26
    v.splat      v23, s18
    vf.neg       v25, v27                        // a/y: one correction to the IEEE quotient
    v.ld.gather.w v26, [s24, v2]                 // index is in elements (ISA sec 9.1)
    v.cmp.eq     p2, v12, v15
    v.mul        v12, v18, v23
    v.splat      v15, s18
    vf.cmp.o     p3, v25, v25
    @p3 v.sel        v23, v25, v17
    s.addi       s26, s14, #8192                 // 512 bytes of repack scratch
    v.mul        v17, v16, v15
    s.addi       s28, s14, #0
    v.splat      v15, s18
    v.splat      v25, s18
    v.splat      v27, s18
    v.mul        v29, v10, v15
    v.extract    s29, v23, #0
    v.mul        v15, v9, v25
    v.splat      v25, s29
    v.mul        v30, v8, v27
    v.splat      v27, s18
    vf.max.ieee  v31, v25, v14
    v.ld.gather.w v25, [s24, v5]                 // index is in elements (ISA sec 9.1)
    v.mul        v32, v7, v27
    v.splat      v27, s18
    v.rcp.approx v33, v31                        // ISA 8.8: <= 2**-22 relative
    v.mul        v34, v3, v27
    v.ld.gather.w v27, [s24, v6]                 // index is in elements (ISA sec 9.1)
    vf.fms       v35, v31, v33, v21
    v.ld.gather.w v36, [s24, v11]                // index is in elements (ISA sec 9.1)
    vf.fms       v37, v33, v35, v33
    vf.neg       v35, v37                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v35, v35
    @p3 v.sel        v37, v35, v33
    v.ld.gather.w v33, [s24, v13]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s24, v4]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v38, [s24, v0]                 // index is in elements (ISA sec 9.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    v.extract    s29, v23, #1
    v.movi       v39, #24
    v.splat      v40, s29
    v.movi       v41, #128
    s.addi       s29, s26, #0
    vf.max.ieee  v42, v40, v14
    s.addi       s30, s14, #64
    s.addi       s31, s26, #1
    s.addi       s32, s14, #128
    v.ld.w       v40, [s28, #0]
    v.rcp.approx v43, v42                        // ISA 8.8: <= 2**-22 relative
    v.extract    s28, v23, #2
    v.splat      v44, s28
    vf.max.ieee  v45, v44, v14
    v.rcp.approx v44, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v31, v40
    vf.fms       v31, v47, v37, v46
    vf.fms       v37, v42, v43, v21
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v43
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v37, v40, v46
    vf.neg       v40, v31                        // Newton step: r0*(2 - x*r0)
    vf.fms       v31, v45, v44, v21
    v.lshr       v46, v37, v39
    vf.cvt.f32.e4m3 v47, v37
    v.and        v37, v46, v41
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v46, v40, v43
    v.or         v40, v47, v37                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v37, v44, v31, v44
    s.addi       s28, s26, #2
    v.st.scatter.b [s29, v24], v40
    v.extract    s29, v23, #3
    s.addi       s33, s14, #192
    vf.neg       v31, v37                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v44
    v.ld.w       v31, [s30, #0]
    v.splat      v40, s29
    vf.max.ieee  v43, v40, v14
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v31, v46                   // a/y: faithful quotient
    vf.fms       v47, v44, v42, v31
    vf.fms       v31, v47, v46, v44
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v46, v42, v44
    v.lshr       v42, v46, v39
    vf.cvt.f32.e4m3 v44, v46
    vf.fms       v46, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s29, s26, #3
    v.or         v42, v44, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v46                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #256
    v.st.scatter.b [s31, v24], v42
    v.extract    s31, v23, #4
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s32, #0]
    v.splat      v40, s31
    vf.max.ieee  v44, v40, v14
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v45, v37, v46
    v.lshr       v37, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s31, s26, #4
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s14, #320
    v.st.scatter.b [s28, v24], v37
    v.extract    s28, v23, #5
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s33, #0]
    v.splat      v40, s28
    vf.max.ieee  v45, v40, v14
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s28, s26, #5
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #384
    v.st.scatter.b [s29, v24], v42
    v.extract    s29, v23, #6
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s30, #0]
    v.splat      v40, s29
    vf.max.ieee  v43, v40, v14
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v44, v37, v46
    v.lshr       v37, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s29, s26, #6
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #448
    v.st.scatter.b [s31, v24], v37
    v.extract    s31, v23, #7
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s32, #0]
    v.splat      v40, s31
    vf.max.ieee  v44, v40, v14
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s31, s26, #7
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s14, #512
    v.st.scatter.b [s28, v24], v42
    v.extract    s28, v23, #8
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s33, #0]
    v.splat      v40, s28
    vf.max.ieee  v45, v40, v14
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v46
    v.lshr       v37, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s28, s26, #8
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #576
    v.st.scatter.b [s29, v24], v37
    v.extract    s29, v23, #9
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s30, #0]
    v.splat      v40, s29
    vf.max.ieee  v43, v40, v14
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s29, s26, #9
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #640
    v.st.scatter.b [s31, v24], v42
    v.extract    s31, v23, #10
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s32, #0]
    v.splat      v40, s31
    vf.max.ieee  v44, v40, v14
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v45, v37, v46
    v.lshr       v37, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s31, s26, #10
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s14, #704
    v.st.scatter.b [s28, v24], v37
    v.extract    s28, v23, #11
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s33, #0]
    v.splat      v40, s28
    vf.max.ieee  v45, v40, v14
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s28, s26, #11
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #768
    v.st.scatter.b [s29, v24], v42
    v.extract    s29, v23, #12
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s30, #0]
    v.splat      v40, s29
    vf.max.ieee  v43, v40, v14
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v44, v37, v46
    v.lshr       v37, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s29, s26, #12
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #832
    v.st.scatter.b [s31, v24], v37
    v.extract    s31, v23, #13
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s32, #0]
    v.splat      v40, s31
    vf.max.ieee  v44, v40, v14
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s31, s26, #13
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s14, #896
    v.st.scatter.b [s28, v24], v42
    v.extract    s28, v23, #14
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s33, #0]
    v.splat      v40, s28
    vf.max.ieee  v45, v40, v14
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v46
    v.lshr       v37, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s28, s26, #14
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #960
    v.st.scatter.b [s29, v24], v37
    v.extract    s29, v23, #15
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s30, #0]
    v.splat      v40, s29
    vf.max.ieee  v43, v40, v14
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s29, s26, #15
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #1024
    v.st.scatter.b [s31, v24], v42
    v.extract    s31, v23, #0
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s32, #0]
    v.splat      v40, s31
    vf.max.ieee  v44, v40, v14
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v45, v37, v46
    v.lshr       v37, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s31, s26, #256
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s14, #1088
    v.st.scatter.b [s28, v24], v37
    v.extract    s28, v23, #1
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s33, #0]
    v.splat      v40, s28
    vf.max.ieee  v45, v40, v14
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s28, s26, #257
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #1152
    v.st.scatter.b [s29, v24], v42
    v.extract    s29, v23, #2
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s30, #0]
    v.splat      v40, s29
    vf.max.ieee  v43, v40, v14
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v44, v37, v46
    v.lshr       v37, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s29, s26, #258
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #1216
    v.st.scatter.b [s31, v24], v37
    v.extract    s31, v23, #3
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s32, #0]
    v.splat      v40, s31
    vf.max.ieee  v44, v40, v14
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s31, s26, #259
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s14, #1280
    v.st.scatter.b [s28, v24], v42
    v.extract    s28, v23, #4
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s33, #0]
    v.splat      v40, s28
    vf.max.ieee  v45, v40, v14
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v46
    v.lshr       v37, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s28, s26, #260
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #1344
    v.st.scatter.b [s29, v24], v37
    v.extract    s29, v23, #5
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s30, #0]
    v.splat      v40, s29
    vf.max.ieee  v43, v40, v14
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s29, s26, #261
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #1408
    v.st.scatter.b [s31, v24], v42
    v.extract    s31, v23, #6
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s32, #0]
    v.splat      v40, s31
    vf.max.ieee  v44, v40, v14
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v45, v37, v46
    v.lshr       v37, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s31, s26, #262
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s14, #1472
    v.st.scatter.b [s28, v24], v37
    v.extract    s28, v23, #7
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s33, #0]
    v.splat      v40, s28
    vf.max.ieee  v45, v40, v14
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s28, s26, #263
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #1536
    v.st.scatter.b [s29, v24], v42
    v.extract    s29, v23, #8
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s30, #0]
    v.splat      v40, s29
    vf.max.ieee  v43, v40, v14
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v44, v37, v46
    v.lshr       v37, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s29, s26, #264
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #1600
    v.st.scatter.b [s31, v24], v37
    v.extract    s31, v23, #9
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s32, #0]
    v.splat      v40, s31
    vf.max.ieee  v44, v40, v14
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s31, s26, #265
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s14, #1664
    v.st.scatter.b [s28, v24], v42
    v.extract    s28, v23, #10
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s33, #0]
    v.splat      v40, s28
    vf.max.ieee  v45, v40, v14
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v43, v37, v46
    v.lshr       v37, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s28, s26, #266
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #1728
    v.st.scatter.b [s29, v24], v37
    v.extract    s29, v23, #11
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s30, #0]
    v.splat      v40, s29
    vf.max.ieee  v43, v40, v14
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s29, s26, #267
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #1792
    v.st.scatter.b [s31, v24], v42
    v.extract    s31, v23, #12
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s32, #0]
    v.splat      v40, s31
    vf.max.ieee  v44, v40, v14
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v45, v37, v46
    v.lshr       v37, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s31, s26, #268
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s14, #1856
    v.st.scatter.b [s28, v24], v37
    v.extract    s28, v23, #13
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s33, #0]
    v.splat      v40, s28
    vf.max.ieee  v45, v40, v14
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s28, s26, #269
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #1920
    v.st.scatter.b [s29, v24], v42
    v.extract    s29, v23, #14
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s30, #0]
    v.splat      v40, s29
    vf.max.ieee  v43, v40, v14
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v37                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v37, v46
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v40, v21
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v44, v37, v46
    v.lshr       v37, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v31, v40
    v.and        v31, v37, v41
    s.addi       s29, s26, #270
    v.or         v37, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #1984
    v.st.scatter.b [s31, v24], v37
    v.extract    s31, v23, #15
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v37, v31, v40
    v.ld.w       v31, [s32, #0]
    v.splat      v40, s31
    vf.max.ieee  v44, v40, v14
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v40, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v31, v40
    v.and        v31, v42, v41
    s.addi       s31, s26, #271
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    v.st.scatter.b [s28, v24], v42
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v40
    v.ld.w       v31, [s33, #0]
    s.addi       s28, s26, #64
    s.addi       s32, s26, #128
    s.addi       s33, s26, #192
    vf.mul       v40, v31, v37                   // a/y: faithful quotient
    s.addi       s34, s26, #256
    vf.fms       v45, v40, v43, v31
    vf.fms       v31, v45, v37, v40
    vf.neg       v37, v31                        // a/y: one correction to the IEEE quotient
    s.addi       s35, s26, #320
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v31, v37, v40
    v.lshr       v37, v31, v39
    vf.cvt.f32.e4m3 v40, v31
    s.addi       s36, s26, #384
    v.and        v31, v37, v41
    v.or         v37, v40, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s37, s26, #448
    v.st.scatter.b [s29, v24], v37
    s.addi       s29, s27, #0
    v.ld.w       v31, [s30, #0]
    v.splat      v37, s29
    v.movi       v40, #0
    v.movi       v43, #0
    v.sub        v45, v37, v28
    v.movi       v37, #4
    v.movi       v46, #3
    v.cmp.gt     p3, v45, v40
    v.max.s      v40, v45, v43
    v.movi       v43, #1
    v.min.s      v45, v40, v37
    vf.mul       v37, v31, v42                   // a/y: faithful quotient
    v.shl        v40, v45, v46
    vf.fms       v46, v37, v44, v31
    v.shl        v31, v43, v40
    vf.fms       v40, v46, v42, v37
    v.movi       v42, #1
    vf.neg       v43, v40                        // a/y: one correction to the IEEE quotient
    v.sub        v40, v31, v42
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v31, v43, v37
    v.movi       v37, #4
    v.lshr       v42, v31, v39
    vf.cvt.f32.e4m3 v43, v31
    v.movi       v31, #-1
    v.and        v44, v42, v41
    s.add        s29, s12, s23
    v.cmp.ge     p4, v45, v37
    v.or         v37, v43, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s30, v22, #0
    @p4 v.sel        v42, v31, v40
    v.st.scatter.b [s31, v24], v37
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.add        s31, s29, s30
    p.and        p4, p1, p3
    v.ld.w       v31, [s26, #0]
    v.extract    s26, v22, #1
    v.mov        v48, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s28, #0]
    s.add        s28, s29, s26
    p.and        p5, p2, p3
    s.addi       s26, s28, #-32
    v.mov        v49, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s32, #0]
    v.mov        v50, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s33, #0]
    v.extract    s28, v22, #2
    s.add        s30, s29, s28
    v.mov        v51, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s34, #0]
    v.extract    s28, v22, #3
    v.mov        v52, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s35, #0]
    s.add        s32, s29, s28
    s.addi       s28, s32, #-32
    v.mov        v53, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s36, #0]
    v.mov        v54, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s37, #0]
    v.extract    s32, v22, #4
    s.add        s33, s29, s32
    v.mov        v55, v31                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s31, #0]
    p.and        p4, p1, p3
    v.extract    s31, v22, #5
    v.extract    s32, v22, #7
    s.add        s34, s29, s31
    v.extract    s31, v22, #6
    s.addi       s35, s34, #-32
    s.add        s34, s29, s32
    s.add        s32, s29, s31
    s.addi       s31, s34, #-32
    v.extract    s34, v22, #9
    v.extract    s36, v22, #8
    s.add        s37, s29, s34
    s.add        s34, s29, s36
    s.addi       s36, s37, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s26, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s26, v22, #11
    v.extract    s30, v22, #10
    s.add        s37, s29, s26
    s.add        s26, s29, s30
    s.addi       s30, s37, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s33, #0]
    p.and        p4, p1, p3
    v.extract    s28, v22, #13
    v.extract    s33, v22, #12
    s.add        s37, s29, s28
    s.add        s28, s29, s33
    s.addi       s33, s37, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s35, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s32, v22, #15
    v.extract    s35, v22, #14
    s.add        s37, s29, s32
    s.add        s32, s29, s35
    s.addi       s29, s37, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s31, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s34, #0]
    p.and        p4, p1, p3
    s.add        s31, s12, s23
    v.extract    s34, v12, #0
    s.add        s35, s31, s34
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s36, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s34, v12, #1
    v.and        v31, v40, v42
    s.add        s36, s31, s34
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.addi       s26, s36, #-32
    v.extract    s34, v12, #2
    s.add        s36, s31, s34
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s30, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s30, v12, #3
    v.and        v31, v40, v42
    s.add        s34, s31, s30
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s34, #-32
    v.extract    s30, v12, #4
    s.add        s34, s31, s30
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s33, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s30, v12, #5
    v.and        v31, v40, v42
    s.add        s33, s31, s30
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s32, #0]
    p.and        p4, p1, p3
    s.addi       s30, s33, #-32
    v.extract    s32, v12, #6
    s.add        s33, s31, s32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s29, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s29, v12, #7
    v.and        v31, v40, v42
    s.add        s32, s31, s29
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s37, s32, #-32
    m.mma.async.k32.e4m3 a8, v56, v48, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s32, v12, #9
    v.extract    s35, v12, #8
    s.add        s38, s31, s32
    s.add        s32, s31, s35
    s.addi       s35, s38, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s26, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s26, v12, #11
    v.extract    s36, v12, #10
    s.add        s38, s31, s26
    s.add        s26, s31, s36
    s.addi       s36, s38, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s28, v12, #13
    v.extract    s34, v12, #12
    s.add        s38, s31, s28
    s.add        s28, s31, s34
    s.addi       s34, s38, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s30, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s33, #0]
    p.and        p4, p1, p3
    v.extract    s30, v12, #15
    v.extract    s33, v12, #14
    s.add        s38, s31, s30
    s.add        s30, s31, s33
    s.addi       s31, s38, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s37, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s32, #0]
    p.and        p4, p1, p3
    s.add        s32, s12, s23
    v.extract    s33, v17, #0
    s.add        s37, s32, s33
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s35, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s33, v17, #1
    v.and        v31, v40, v42
    s.add        s35, s32, s33
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.addi       s26, s35, #-32
    v.extract    s33, v17, #2
    s.add        s35, s32, s33
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s36, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s33, v17, #3
    v.and        v31, v40, v42
    s.add        s36, s32, s33
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s36, #-32
    v.extract    s33, v17, #4
    s.add        s36, s32, s33
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s34, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s33, v17, #5
    v.and        v31, v40, v42
    s.add        s34, s32, s33
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s30, #0]
    p.and        p4, p1, p3
    s.addi       s30, s34, #-32
    v.extract    s33, v17, #6
    s.add        s34, s32, s33
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s31, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s31, v17, #7
    v.and        v31, v40, v42
    s.add        s33, s32, s31
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s31, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s38, s33, #-32
    m.mma.async.k32.e4m3 a9, v56, v48, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s33, v17, #9
    v.extract    s37, v17, #8
    s.add        s39, s32, s33
    s.add        s33, s32, s37
    s.addi       s37, s39, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s26, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s26, v17, #11
    v.extract    s35, v17, #10
    s.add        s39, s32, s26
    s.add        s26, s32, s35
    s.addi       s35, s39, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s28, v17, #13
    v.extract    s36, v17, #12
    s.add        s39, s32, s28
    s.add        s28, s32, s36
    s.addi       s36, s39, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s30, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s34, #0]
    p.and        p4, p1, p3
    v.extract    s30, v17, #15
    v.extract    s34, v17, #14
    s.add        s39, s32, s30
    s.add        s30, s32, s34
    s.addi       s32, s39, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s33, #0]
    p.and        p4, p1, p3
    s.add        s33, s12, s23
    v.extract    s34, v29, #0
    s.add        s38, s33, s34
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s37, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s34, v29, #1
    v.and        v31, v40, v42
    s.add        s37, s33, s34
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.addi       s26, s37, #-32
    v.extract    s34, v29, #2
    s.add        s37, s33, s34
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s35, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s34, v29, #3
    v.and        v31, v40, v42
    s.add        s35, s33, s34
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s35, #-32
    v.extract    s34, v29, #4
    s.add        s35, s33, s34
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s36, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s34, v29, #5
    v.and        v31, v40, v42
    s.add        s36, s33, s34
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s30, #0]
    p.and        p4, p1, p3
    s.addi       s30, s36, #-32
    v.extract    s34, v29, #6
    s.add        s36, s33, s34
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s32, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s32, v29, #7
    v.and        v31, v40, v42
    s.add        s34, s33, s32
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s32, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s39, s34, #-32
    m.mma.async.k32.e4m3 a10, v56, v48, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s34, v29, #9
    v.extract    s38, v29, #8
    s.add        s40, s33, s34
    s.add        s34, s33, s38
    s.addi       s38, s40, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s26, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s26, v29, #11
    v.extract    s37, v29, #10
    s.add        s40, s33, s26
    s.add        s26, s33, s37
    s.addi       s37, s40, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s35, #0]
    p.and        p4, p1, p3
    v.extract    s28, v29, #13
    v.extract    s35, v29, #12
    s.add        s40, s33, s28
    s.add        s28, s33, s35
    s.addi       s35, s40, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s30, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s30, v29, #15
    v.extract    s36, v29, #14
    s.add        s40, s33, s30
    s.add        s30, s33, s36
    s.addi       s33, s40, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s39, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s34, #0]
    p.and        p4, p1, p3
    s.add        s34, s12, s23
    v.extract    s36, v15, #0
    s.add        s39, s34, s36
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s36, v15, #1
    v.and        v31, v40, v42
    s.add        s38, s34, s36
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.addi       s26, s38, #-32
    v.extract    s36, v15, #2
    s.add        s38, s34, s36
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s37, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s36, v15, #3
    v.and        v31, v40, v42
    s.add        s37, s34, s36
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s37, #-32
    v.extract    s36, v15, #4
    s.add        s37, s34, s36
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s35, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s35, v15, #5
    v.and        v31, v40, v42
    s.add        s36, s34, s35
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s30, #0]
    p.and        p4, p1, p3
    s.addi       s30, s36, #-32
    v.extract    s35, v15, #6
    s.add        s36, s34, s35
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s33, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s33, v15, #7
    v.and        v31, v40, v42
    s.add        s35, s34, s33
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s33, b3, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s40, s35, #-32
    m.mma.async.k32.e4m3 a11, v56, v48, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s35, v15, #9
    v.extract    s39, v15, #8
    s.add        s41, s34, s35
    s.add        s35, s34, s39
    s.addi       s39, s41, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s26, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s26, v15, #11
    v.extract    s38, v15, #10
    s.add        s41, s34, s26
    s.add        s26, s34, s38
    s.addi       s38, s41, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s28, v15, #13
    v.extract    s37, v15, #12
    s.add        s41, s34, s28
    s.add        s28, s34, s37
    s.addi       s37, s41, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s30, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s36, #0]
    p.and        p4, p1, p3
    v.extract    s30, v15, #15
    v.extract    s36, v15, #14
    s.add        s41, s34, s30
    s.add        s30, s34, s36
    s.addi       s34, s41, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s40, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s35, #0]
    p.and        p4, p1, p3
    s.add        s35, s12, s23
    v.extract    s36, v30, #0
    s.add        s40, s35, s36
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s39, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s36, v30, #1
    v.and        v31, v40, v42
    s.add        s39, s35, s36
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.addi       s26, s39, #-32
    v.extract    s36, v30, #2
    s.add        s39, s35, s36
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s36, v30, #3
    v.and        v31, v40, v42
    s.add        s38, s35, s36
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s38, #-32
    v.extract    s36, v30, #4
    s.add        s38, s35, s36
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s37, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s36, v30, #5
    v.and        v31, v40, v42
    s.add        s37, s35, s36
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s30, #0]
    p.and        p4, p1, p3
    s.addi       s30, s37, #-32
    v.extract    s36, v30, #6
    s.add        s37, s35, s36
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s34, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s34, v30, #7
    v.and        v31, v40, v42
    s.add        s36, s35, s34
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s34, b4, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s41, s36, #-32
    m.mma.async.k32.e4m3 a12, v56, v48, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s36, v30, #9
    v.extract    s40, v30, #8
    s.add        s42, s35, s36
    s.add        s36, s35, s40
    s.addi       s40, s42, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s26, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s26, v30, #11
    v.extract    s39, v30, #10
    s.add        s42, s35, s26
    s.add        s26, s35, s39
    s.addi       s39, s42, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s28, v30, #13
    v.extract    s38, v30, #12
    s.add        s42, s35, s28
    s.add        s28, s35, s38
    s.addi       s38, s42, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s30, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s30, v30, #15
    v.extract    s37, v30, #14
    s.add        s42, s35, s30
    s.add        s30, s35, s37
    s.addi       s35, s42, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s41, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s36, #0]
    p.and        p4, p1, p3
    s.add        s36, s12, s23
    v.extract    s37, v32, #0
    s.add        s41, s36, s37
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s40, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s37, v32, #1
    v.and        v31, v40, v42
    s.add        s40, s36, s37
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.addi       s26, s40, #-32
    v.extract    s37, v32, #2
    s.add        s40, s36, s37
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s39, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s37, v32, #3
    v.and        v31, v40, v42
    s.add        s39, s36, s37
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s39, #-32
    v.extract    s37, v32, #4
    s.add        s39, s36, s37
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s37, v32, #5
    v.and        v31, v40, v42
    s.add        s38, s36, s37
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s30, #0]
    p.and        p4, p1, p3
    s.addi       s30, s38, #-32
    v.extract    s37, v32, #6
    s.add        s38, s36, s37
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s35, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s35, v32, #7
    v.and        v31, v40, v42
    s.add        s37, s36, s35
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s35, b5, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s42, s37, #-32
    m.mma.async.k32.e4m3 a13, v56, v48, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s41, #0]
    p.and        p4, p1, p3
    v.extract    s37, v32, #9
    v.extract    s41, v32, #8
    s.add        s43, s36, s37
    s.add        s37, s36, s41
    s.addi       s41, s43, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s26, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s26, v32, #11
    v.extract    s40, v32, #10
    s.add        s43, s36, s26
    s.add        s26, s36, s40
    s.addi       s40, s43, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s28, v32, #13
    v.extract    s39, v32, #12
    s.add        s43, s36, s28
    s.add        s28, s36, s39
    s.addi       s39, s43, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s30, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s30, v32, #15
    v.extract    s38, v32, #14
    s.add        s43, s36, s30
    s.add        s30, s36, s38
    s.addi       s36, s43, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s42, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    s.add        s37, s12, s23
    v.extract    s38, v34, #0
    s.add        s42, s37, s38
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s41, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s38, v34, #1
    v.and        v31, v40, v42
    s.add        s41, s37, s38
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.addi       s26, s41, #-32
    v.extract    s38, v34, #2
    s.add        s41, s37, s38
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s40, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s38, v34, #3
    v.and        v31, v40, v42
    s.add        s40, s37, s38
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s40, #-32
    v.extract    s38, v34, #4
    s.add        s40, s37, s38
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s39, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s38, v34, #5
    v.and        v31, v40, v42
    s.add        s39, s37, s38
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s30, #0]
    p.and        p4, p1, p3
    s.addi       s30, s39, #-32
    v.extract    s38, v34, #6
    s.add        s39, s37, s38
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s36, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.extract    s36, v34, #7
    v.and        v31, v40, v42
    s.add        s38, s37, s36
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b6, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s43, s38, #-32
    m.mma.async.k32.e4m3 a14, v56, v48, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s42, #0]
    p.and        p4, p1, p3
    v.extract    s38, v34, #9
    v.extract    s42, v34, #8
    s.add        s44, s37, s38
    s.add        s38, s37, s42
    s.addi       s42, s44, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s26, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s41, #0]
    p.and        p4, p1, p3
    v.extract    s26, v34, #11
    v.extract    s41, v34, #10
    s.add        s44, s37, s26
    s.add        s26, s37, s41
    s.addi       s41, s44, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s28, v34, #13
    v.extract    s40, v34, #12
    s.add        s44, s37, s28
    s.add        s28, s37, s40
    s.addi       s40, s44, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s30, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s30, v34, #15
    v.extract    s39, v34, #14
    s.add        s44, s37, s30
    s.add        s30, s37, s39
    s.addi       s37, s44, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s43, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v23, #0
    s.addi       s39, s14, #2048
    v.splat      v37, s38
    s.addi       s38, s14, #8704                 // 512 bytes of repack scratch
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v40, [s42, #0]
    p.and        p5, p2, p3
    vf.max.ieee  v43, v37, v14
    v.or         v37, v31, v40
    v.rcp.approx v31, v43                        // ISA 8.8: <= 2**-22 relative
    v.and        v40, v37, v42
    v.mov        v60, v40                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s26, #0]
    p.and        p4, p1, p3
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v40, [s41, #0]
    p.and        p5, p2, p3
    vf.fms       v44, v43, v31, v21
    vf.fms       v45, v31, v44, v31
    vf.neg       v44, v45                        // Newton step: r0*(2 - x*r0)
    v.or         v45, v37, v40
    v.and        v37, v45, v42
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s28, #0]
    p.and        p4, p1, p3
    p.and        p6, p2, p3
    v.extract    s26, v23, #1
    s.addi       s28, s38, #0
    v.splat      v40, s26
    s.addi       s26, s14, #2112
    vf.max.ieee  v45, v40, v14
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v40, [s40, #0]
    vf.cmp.o     p3, v44, v44
    @p3 v.sel        v46, v44, v31
    v.rcp.approx v31, v45                        // ISA 8.8: <= 2**-22 relative
    v.or         v44, v37, v40
    v.and        v37, v44, v42
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s30, #0]
    vf.fms       v40, v45, v31, v21
    vf.fms       v44, v31, v40, v31
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    v.movi       v44, #0                         // other=, materialised (sec 12)
    @p6 v.ld.w       v44, [s37, #0]
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v47, v40, v31
    v.or         v31, v37, v44
    v.and        v37, v31, v42
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s30, b7, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s37, s38, #1
    m.mma.async.k32.e4m3 a15, v56, v48, s30
    mb.wait      s30
    v.ld.w       v31, [s39, #0]
    v.extract    s39, v23, #2
    s.addi       s40, s14, #2176
    v.splat      v37, s39
    vf.max.ieee  v40, v37, v14
    v.rcp.approx v37, v40                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v42, v31, v46                   // a/y: faithful quotient
    vf.fms       v44, v42, v43, v31
    vf.fms       v31, v44, v46, v42
    vf.neg       v43, v31                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v31, v43, v42
    vf.fms       v42, v40, v37, v21
    v.lshr       v43, v31, v39
    vf.cvt.f32.e4m3 v44, v31
    v.and        v31, v43, v41
    vf.fms       v43, v37, v42, v37
    s.addi       s39, s38, #2
    v.or         v42, v44, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s41, s14, #2240
    v.st.scatter.b [s28, v24], v42
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    v.extract    s28, v23, #3
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s26, #0]
    v.splat      v37, s28
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v31, v47                   // a/y: faithful quotient
    vf.fms       v46, v44, v45, v31
    vf.fms       v31, v46, v47, v44
    vf.neg       v45, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v45, v45
    @p3 v.sel        v46, v45, v44
    v.lshr       v44, v46, v39
    vf.cvt.f32.e4m3 v45, v46
    vf.fms       v46, v37, v31, v37
    v.and        v31, v44, v41
    s.addi       s26, s38, #3
    v.or         v44, v45, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v46                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #2304
    v.st.scatter.b [s37, v24], v44
    v.extract    s37, v23, #4
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v44, v31, v37
    v.ld.w       v31, [s40, #0]
    v.splat      v37, s37
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v40, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v42, v40, v46
    v.lshr       v40, v42, v39
    vf.cvt.f32.e4m3 v46, v42
    vf.fms       v42, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s37, s38, #4
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v42                        // Newton step: r0*(2 - x*r0)
    s.addi       s40, s14, #2368
    v.st.scatter.b [s39, v24], v40
    v.extract    s39, v23, #5
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s41, #0]
    v.splat      v37, s39
    vf.max.ieee  v42, v37, v14
    v.rcp.approx v37, v42                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v44                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v44, v46
    vf.neg       v43, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v42, v37, v21
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v44, v43, v46
    v.lshr       v43, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v43, v41
    s.addi       s39, s38, #5
    v.or         v43, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s41, s14, #2432
    v.st.scatter.b [s26, v24], v43
    v.extract    s26, v23, #6
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v43, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s38, #6
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #2496
    v.st.scatter.b [s37, v24], v40
    v.extract    s37, v23, #7
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s40, #0]
    v.splat      v37, s37
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v42, v31
    vf.fms       v31, v47, v43, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s37, s38, #7
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s40, s14, #2560
    v.st.scatter.b [s39, v24], v42
    v.extract    s39, v23, #8
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s41, #0]
    v.splat      v37, s39
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v44, v40, v46
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s39, s38, #8
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s41, s14, #2624
    v.st.scatter.b [s26, v24], v40
    v.extract    s26, v23, #9
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s26, s38, #9
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #2688
    v.st.scatter.b [s37, v24], v42
    v.extract    s37, v23, #10
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s40, #0]
    v.splat      v37, s37
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v46
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s37, s38, #10
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s40, s14, #2752
    v.st.scatter.b [s39, v24], v40
    v.extract    s39, v23, #11
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s41, #0]
    v.splat      v37, s39
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s39, s38, #11
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s41, s14, #2816
    v.st.scatter.b [s26, v24], v42
    v.extract    s26, v23, #12
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s38, #12
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #2880
    v.st.scatter.b [s37, v24], v40
    v.extract    s37, v23, #13
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s40, #0]
    v.splat      v37, s37
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s37, s38, #13
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s40, s14, #2944
    v.st.scatter.b [s39, v24], v42
    v.extract    s39, v23, #14
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s41, #0]
    v.splat      v37, s39
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v44, v40, v46
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s39, s38, #14
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s41, s14, #3008
    v.st.scatter.b [s26, v24], v40
    v.extract    s26, v23, #15
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s26, s38, #15
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #3072
    v.st.scatter.b [s37, v24], v42
    v.extract    s37, v23, #0
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s40, #0]
    v.splat      v37, s37
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v46
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s37, s38, #256
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s40, s14, #3136
    v.st.scatter.b [s39, v24], v40
    v.extract    s39, v23, #1
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s41, #0]
    v.splat      v37, s39
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s39, s38, #257
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s41, s14, #3200
    v.st.scatter.b [s26, v24], v42
    v.extract    s26, v23, #2
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s38, #258
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #3264
    v.st.scatter.b [s37, v24], v40
    v.extract    s37, v23, #3
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s40, #0]
    v.splat      v37, s37
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s37, s38, #259
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s40, s14, #3328
    v.st.scatter.b [s39, v24], v42
    v.extract    s39, v23, #4
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s41, #0]
    v.splat      v37, s39
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v44, v40, v46
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s39, s38, #260
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s41, s14, #3392
    v.st.scatter.b [s26, v24], v40
    v.extract    s26, v23, #5
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s26, s38, #261
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #3456
    v.st.scatter.b [s37, v24], v42
    v.extract    s37, v23, #6
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s40, #0]
    v.splat      v37, s37
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v46
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s37, s38, #262
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s40, s14, #3520
    v.st.scatter.b [s39, v24], v40
    v.extract    s39, v23, #7
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s41, #0]
    v.splat      v37, s39
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s39, s38, #263
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s41, s14, #3584
    v.st.scatter.b [s26, v24], v42
    v.extract    s26, v23, #8
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s38, #264
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #3648
    v.st.scatter.b [s37, v24], v40
    v.extract    s37, v23, #9
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s40, #0]
    v.splat      v37, s37
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s37, s38, #265
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s40, s14, #3712
    v.st.scatter.b [s39, v24], v42
    v.extract    s39, v23, #10
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s41, #0]
    v.splat      v37, s39
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v44, v40, v46
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s39, s38, #266
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s41, s14, #3776
    v.st.scatter.b [s26, v24], v40
    v.extract    s26, v23, #11
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s26, s38, #267
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #3840
    v.st.scatter.b [s37, v24], v42
    v.extract    s37, v23, #12
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s40, #0]
    v.splat      v37, s37
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v46
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s37, s38, #268
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s40, s14, #3904
    v.st.scatter.b [s39, v24], v40
    v.extract    s39, v23, #13
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s41, #0]
    v.splat      v37, s39
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s39, s38, #269
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s41, s14, #3968
    v.st.scatter.b [s26, v24], v42
    v.extract    s26, v23, #14
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s38, #270
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #4032
    v.st.scatter.b [s37, v24], v40
    v.extract    s37, v23, #15
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s40, #0]
    v.splat      v37, s37
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s37, s38, #271
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    v.st.scatter.b [s39, v24], v42
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s41, #0]
    s.addi       s39, s38, #64
    s.addi       s40, s38, #128
    s.addi       s41, s38, #192
    vf.mul       v37, v31, v40                   // a/y: faithful quotient
    s.addi       s42, s38, #256
    vf.fms       v43, v37, v44, v31
    vf.fms       v31, v43, v40, v37
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    s.addi       s43, s38, #320
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v31, v40, v37
    v.lshr       v37, v31, v39
    vf.cvt.f32.e4m3 v40, v31
    s.addi       s44, s38, #384
    v.and        v31, v37, v41
    v.or         v37, v40, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s45, s38, #448
    v.st.scatter.b [s26, v24], v37
    s.addi       s26, s27, #-32
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    v.movi       v40, #0
    v.movi       v43, #0
    v.sub        v44, v37, v28
    v.movi       v37, #4
    v.movi       v46, #3
    v.cmp.gt     p3, v44, v40
    v.max.s      v40, v44, v43
    v.movi       v43, #1
    v.min.s      v44, v40, v37
    vf.mul       v37, v31, v42                   // a/y: faithful quotient
    v.shl        v40, v44, v46
    vf.fms       v46, v37, v45, v31
    v.shl        v31, v43, v40
    vf.fms       v40, v46, v42, v37
    v.movi       v42, #1
    vf.neg       v43, v40                        // a/y: one correction to the IEEE quotient
    v.sub        v40, v31, v42
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v31, v43, v37
    v.movi       v37, #4
    v.lshr       v42, v31, v39
    vf.cvt.f32.e4m3 v43, v31
    v.movi       v31, #-1
    v.and        v45, v42, v41
    s.addi       s26, s23, #32
    v.cmp.ge     p4, v44, v37
    v.or         v37, v43, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.add        s28, s12, s26
    @p4 v.sel        v42, v31, v40
    v.st.scatter.b [s37, v24], v37
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.extract    s26, v22, #0
    p.and        p4, p1, p3
    s.add        s37, s28, s26
    v.ld.w       v31, [s38, #0]
    v.mov        v48, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s39, #0]
    v.extract    s26, v22, #1
    s.add        s38, s28, s26
    s.addi       s26, s38, #-32
    v.mov        v49, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s40, #0]
    p.and        p5, p2, p3
    v.mov        v50, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s41, #0]
    v.extract    s38, v22, #2
    v.mov        v51, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s42, #0]
    s.add        s39, s28, s38
    v.mov        v52, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s43, #0]
    v.extract    s38, v22, #3
    s.add        s40, s28, s38
    s.addi       s38, s40, #-32
    v.mov        v53, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s44, #0]
    v.mov        v54, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s45, #0]
    v.extract    s40, v22, #4
    v.mov        v55, v31                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v22, #5
    s.add        s41, s28, s40
    s.add        s40, s28, s37
    v.extract    s37, v22, #7
    s.addi       s42, s40, #-32
    v.extract    s40, v22, #6
    s.add        s43, s28, s37
    s.add        s37, s28, s40
    s.addi       s40, s43, #-32
    v.extract    s43, v22, #9
    v.extract    s44, v22, #8
    s.add        s45, s28, s43
    s.add        s43, s28, s44
    s.addi       s44, s45, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s26, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s39, #0]
    p.and        p4, p1, p3
    v.extract    s26, v22, #11
    v.extract    s39, v22, #10
    s.add        s45, s28, s26
    s.add        s26, s28, s39
    s.addi       s39, s45, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s41, #0]
    p.and        p4, p1, p3
    v.extract    s38, v22, #13
    v.extract    s41, v22, #12
    s.add        s45, s28, s38
    s.add        s38, s28, s41
    s.addi       s41, s45, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s42, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v22, #15
    v.extract    s42, v22, #14
    s.add        s45, s28, s37
    s.add        s37, s28, s42
    s.addi       s28, s45, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s40, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s43, #0]
    p.and        p4, p1, p3
    s.addi       s40, s23, #32
    v.extract    s42, v12, #0
    s.add        s43, s12, s40
    s.add        s40, s43, s42
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s44, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s42, v12, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s43, s42
    v.extract    s42, v12, #2
    s.addi       s44, s26, #-32
    s.add        s26, s43, s42
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s39, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s39, v12, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.add        s38, s43, s39
    v.extract    s39, v12, #4
    s.addi       s42, s38, #-32
    s.add        s38, s43, s39
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s41, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s39, v12, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    s.add        s37, s43, s39
    v.extract    s39, v12, #6
    s.addi       s41, s37, #-32
    s.add        s37, s43, s39
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s28, v12, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s39, b8, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s45, s43, s28
    m.mma.async.k32.e4m3 a8, v56, v48, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s40, #0]
    p.and        p4, p1, p3
    s.addi       s28, s45, #-32
    v.extract    s40, v12, #9
    v.extract    s45, v12, #8
    s.add        s46, s43, s40
    s.add        s40, s43, s45
    s.addi       s45, s46, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s44, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v12, #11
    v.extract    s44, v12, #10
    s.add        s46, s43, s26
    s.add        s26, s43, s44
    s.addi       s44, s46, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s42, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v12, #13
    v.extract    s42, v12, #12
    s.add        s46, s43, s38
    s.add        s38, s43, s42
    s.addi       s42, s46, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s41, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v12, #15
    v.extract    s41, v12, #14
    s.add        s46, s43, s37
    s.add        s37, s43, s41
    s.addi       s41, s46, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s40, #0]
    p.and        p4, p1, p3
    s.addi       s28, s23, #32
    v.extract    s40, v17, #0
    s.add        s43, s12, s28
    s.add        s28, s43, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s45, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v17, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s43, s40
    v.extract    s40, v17, #2
    s.addi       s45, s26, #-32
    s.add        s26, s43, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s44, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v17, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.add        s38, s43, s40
    v.extract    s40, v17, #4
    s.addi       s44, s38, #-32
    s.add        s38, s43, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s42, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v17, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    s.add        s37, s43, s40
    v.extract    s40, v17, #6
    s.addi       s42, s37, #-32
    s.add        s37, s43, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s41, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v17, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s41, b9, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s46, s43, s40
    m.mma.async.k32.e4m3 a9, v56, v48, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s46, #-32
    v.extract    s40, v17, #9
    v.extract    s46, v17, #8
    s.add        s47, s43, s40
    s.add        s40, s43, s46
    s.addi       s46, s47, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s45, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v17, #11
    v.extract    s45, v17, #10
    s.add        s47, s43, s26
    s.add        s26, s43, s45
    s.addi       s45, s47, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s44, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v17, #13
    v.extract    s44, v17, #12
    s.add        s47, s43, s38
    s.add        s38, s43, s44
    s.addi       s44, s47, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s42, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v17, #15
    v.extract    s42, v17, #14
    s.add        s47, s43, s37
    s.add        s37, s43, s42
    s.addi       s42, s47, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s40, #0]
    p.and        p4, p1, p3
    s.addi       s28, s23, #32
    v.extract    s40, v29, #0
    s.add        s43, s12, s28
    s.add        s28, s43, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s46, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v29, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s43, s40
    v.extract    s40, v29, #2
    s.addi       s46, s26, #-32
    s.add        s26, s43, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s45, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v29, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.add        s38, s43, s40
    v.extract    s40, v29, #4
    s.addi       s45, s38, #-32
    s.add        s38, s43, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s44, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v29, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    s.add        s37, s43, s40
    v.extract    s40, v29, #6
    s.addi       s44, s37, #-32
    s.add        s37, s43, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s42, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v29, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s42, b10, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s47, s43, s40
    m.mma.async.k32.e4m3 a10, v56, v48, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s47, #-32
    v.extract    s40, v29, #9
    v.extract    s47, v29, #8
    s.add        s48, s43, s40
    s.add        s40, s43, s47
    s.addi       s47, s48, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s46, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v29, #11
    v.extract    s46, v29, #10
    s.add        s48, s43, s26
    s.add        s26, s43, s46
    s.addi       s46, s48, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s45, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v29, #13
    v.extract    s45, v29, #12
    s.add        s48, s43, s38
    s.add        s38, s43, s45
    s.addi       s45, s48, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s44, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v29, #15
    v.extract    s44, v29, #14
    s.add        s48, s43, s37
    s.add        s37, s43, s44
    s.addi       s43, s48, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s40, #0]
    p.and        p4, p1, p3
    s.addi       s28, s23, #32
    v.extract    s40, v15, #0
    s.add        s44, s12, s28
    s.add        s28, s44, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s47, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v15, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s44, s40
    v.extract    s40, v15, #2
    s.addi       s47, s26, #-32
    s.add        s26, s44, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s46, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v15, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.add        s38, s44, s40
    v.extract    s40, v15, #4
    s.addi       s46, s38, #-32
    s.add        s38, s44, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s45, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v15, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    s.add        s37, s44, s40
    v.extract    s40, v15, #6
    s.addi       s45, s37, #-32
    s.add        s37, s44, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s43, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v15, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s43, b11, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s48, s44, s40
    m.mma.async.k32.e4m3 a11, v56, v48, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s48, #-32
    v.extract    s40, v15, #9
    v.extract    s48, v15, #8
    s.add        s49, s44, s40
    s.add        s40, s44, s48
    s.addi       s48, s49, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s47, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v15, #11
    v.extract    s47, v15, #10
    s.add        s49, s44, s26
    s.add        s26, s44, s47
    s.addi       s47, s49, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s46, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v15, #13
    v.extract    s46, v15, #12
    s.add        s49, s44, s38
    s.add        s38, s44, s46
    s.addi       s46, s49, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s45, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v15, #15
    v.extract    s45, v15, #14
    s.add        s49, s44, s37
    s.add        s37, s44, s45
    s.addi       s44, s49, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s40, #0]
    p.and        p4, p1, p3
    s.addi       s28, s23, #32
    v.extract    s40, v30, #0
    s.add        s45, s12, s28
    s.add        s28, s45, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s48, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v30, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s45, s40
    v.extract    s40, v30, #2
    s.addi       s48, s26, #-32
    s.add        s26, s45, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s47, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v30, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.add        s38, s45, s40
    v.extract    s40, v30, #4
    s.addi       s47, s38, #-32
    s.add        s38, s45, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s46, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v30, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    s.add        s37, s45, s40
    v.extract    s40, v30, #6
    s.addi       s46, s37, #-32
    s.add        s37, s45, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s44, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v30, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s44, b12, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s49, s45, s40
    m.mma.async.k32.e4m3 a12, v56, v48, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s49, #-32
    v.extract    s40, v30, #9
    v.extract    s49, v30, #8
    s.add        s50, s45, s40
    s.add        s40, s45, s49
    s.addi       s49, s50, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s48, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v30, #11
    v.extract    s48, v30, #10
    s.add        s50, s45, s26
    s.add        s26, s45, s48
    s.addi       s48, s50, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s47, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v30, #13
    v.extract    s47, v30, #12
    s.add        s50, s45, s38
    s.add        s38, s45, s47
    s.addi       s47, s50, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s46, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v30, #15
    v.extract    s46, v30, #14
    s.add        s50, s45, s37
    s.add        s37, s45, s46
    s.addi       s45, s50, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s40, #0]
    p.and        p4, p1, p3
    s.addi       s28, s23, #32
    v.extract    s40, v32, #0
    s.add        s46, s12, s28
    s.add        s28, s46, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s49, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v32, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s46, s40
    v.extract    s40, v32, #2
    s.addi       s49, s26, #-32
    s.add        s26, s46, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s48, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v32, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.add        s38, s46, s40
    v.extract    s40, v32, #4
    s.addi       s48, s38, #-32
    s.add        s38, s46, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s47, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v32, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    s.add        s37, s46, s40
    v.extract    s40, v32, #6
    s.addi       s47, s37, #-32
    s.add        s37, s46, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s45, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v32, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s45, b13, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s50, s46, s40
    m.mma.async.k32.e4m3 a13, v56, v48, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s50, #-32
    v.extract    s40, v32, #9
    v.extract    s50, v32, #8
    s.add        s51, s46, s40
    s.add        s40, s46, s50
    s.addi       s50, s51, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s49, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v32, #11
    v.extract    s49, v32, #10
    s.add        s51, s46, s26
    s.add        s26, s46, s49
    s.addi       s49, s51, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s48, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v32, #13
    v.extract    s48, v32, #12
    s.add        s51, s46, s38
    s.add        s38, s46, s48
    s.addi       s48, s51, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s47, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v32, #15
    v.extract    s47, v32, #14
    s.add        s51, s46, s37
    s.add        s37, s46, s47
    s.addi       s46, s51, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s40, #0]
    p.and        p4, p1, p3
    s.addi       s28, s23, #32
    v.extract    s40, v34, #0
    s.add        s47, s12, s28
    s.add        s28, s47, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s50, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v34, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s47, s40
    v.extract    s40, v34, #2
    s.addi       s50, s26, #-32
    s.add        s26, s47, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s49, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v34, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.add        s38, s47, s40
    v.extract    s40, v34, #4
    s.addi       s49, s38, #-32
    s.add        s38, s47, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s48, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v34, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    s.add        s37, s47, s40
    v.extract    s40, v34, #6
    s.addi       s48, s37, #-32
    s.add        s37, s47, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s46, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v34, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s46, b14, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s51, s47, s40
    m.mma.async.k32.e4m3 a14, v56, v48, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.addi       s28, s51, #-32
    v.extract    s40, v34, #9
    v.extract    s51, v34, #8
    s.add        s52, s47, s40
    s.add        s40, s47, s51
    s.addi       s51, s52, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s50, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v34, #11
    v.extract    s50, v34, #10
    s.add        s52, s47, s26
    s.add        s26, s47, s50
    s.addi       s50, s52, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s49, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    v.extract    s38, v34, #13
    v.extract    s49, v34, #12
    s.add        s52, s47, s38
    s.add        s38, s47, s49
    s.addi       s49, s52, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s48, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s37, #0]
    p.and        p4, p1, p3
    v.extract    s37, v34, #15
    v.extract    s48, v34, #14
    s.add        s52, s47, s37
    s.add        s37, s47, s48
    s.addi       s47, s52, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s28, v23, #0
    s.addi       s40, s14, #4096
    v.splat      v37, s28
    s.addi       s28, s14, #9216                 // 512 bytes of repack scratch
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v40, [s51, #0]
    p.and        p5, p2, p3
    vf.max.ieee  v43, v37, v14
    v.or         v37, v31, v40
    v.rcp.approx v31, v43                        // ISA 8.8: <= 2**-22 relative
    v.and        v40, v37, v42
    v.mov        v60, v40                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s26, #0]
    p.and        p4, p1, p3
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v40, [s50, #0]
    p.and        p5, p2, p3
    vf.fms       v44, v43, v31, v21
    vf.fms       v45, v31, v44, v31
    vf.neg       v44, v45                        // Newton step: r0*(2 - x*r0)
    v.or         v45, v37, v40
    v.and        v37, v45, v42
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s38, #0]
    p.and        p4, p1, p3
    p.and        p6, p2, p3
    v.extract    s26, v23, #1
    s.addi       s38, s28, #0
    v.splat      v40, s26
    s.addi       s26, s14, #4160
    vf.max.ieee  v45, v40, v14
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v40, [s49, #0]
    vf.cmp.o     p3, v44, v44
    @p3 v.sel        v46, v44, v31
    v.rcp.approx v31, v45                        // ISA 8.8: <= 2**-22 relative
    v.or         v44, v37, v40
    v.and        v37, v44, v42
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s37, #0]
    vf.fms       v40, v45, v31, v21
    vf.fms       v44, v31, v40, v31
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    v.movi       v44, #0                         // other=, materialised (sec 12)
    @p6 v.ld.w       v44, [s47, #0]
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v47, v40, v31
    v.or         v31, v37, v44
    v.and        v37, v31, v42
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b15, #0, #1                // 0 arrival(s), 1 operation(s)
    s.addi       s47, s28, #1
    m.mma.async.k32.e4m3 a15, v56, v48, s37
    mb.wait      s37
    v.ld.w       v31, [s40, #0]
    v.extract    s40, v23, #2
    s.addi       s48, s14, #4224
    v.splat      v37, s40
    vf.max.ieee  v40, v37, v14
    v.rcp.approx v37, v40                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v42, v31, v46                   // a/y: faithful quotient
    vf.fms       v44, v42, v43, v31
    vf.fms       v31, v44, v46, v42
    vf.neg       v43, v31                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v31, v43, v42
    vf.fms       v42, v40, v37, v21
    v.lshr       v43, v31, v39
    vf.cvt.f32.e4m3 v44, v31
    v.and        v31, v43, v41
    vf.fms       v43, v37, v42, v37
    s.addi       s40, s28, #2
    v.or         v42, v44, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s49, s14, #4288
    v.st.scatter.b [s38, v24], v42
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    v.extract    s38, v23, #3
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s26, #0]
    v.splat      v37, s38
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v31, v47                   // a/y: faithful quotient
    vf.fms       v46, v44, v45, v31
    vf.fms       v31, v46, v47, v44
    vf.neg       v45, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v45, v45
    @p3 v.sel        v46, v45, v44
    v.lshr       v44, v46, v39
    vf.cvt.f32.e4m3 v45, v46
    vf.fms       v46, v37, v31, v37
    v.and        v31, v44, v41
    s.addi       s26, s28, #3
    v.or         v44, v45, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v46                        // Newton step: r0*(2 - x*r0)
    s.addi       s38, s14, #4352
    v.st.scatter.b [s47, v24], v44
    v.extract    s47, v23, #4
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v44, v31, v37
    v.ld.w       v31, [s48, #0]
    v.splat      v37, s47
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v40, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v42, v40, v46
    v.lshr       v40, v42, v39
    vf.cvt.f32.e4m3 v46, v42
    vf.fms       v42, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s47, s28, #4
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v42                        // Newton step: r0*(2 - x*r0)
    s.addi       s48, s14, #4416
    v.st.scatter.b [s40, v24], v40
    v.extract    s40, v23, #5
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s49, #0]
    v.splat      v37, s40
    vf.max.ieee  v42, v37, v14
    v.rcp.approx v37, v42                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v44                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v44, v46
    vf.neg       v43, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v42, v37, v21
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v44, v43, v46
    v.lshr       v43, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v43, v41
    s.addi       s40, s28, #5
    v.or         v43, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s49, s14, #4480
    v.st.scatter.b [s26, v24], v43
    v.extract    s26, v23, #6
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v43, v31, v37
    v.ld.w       v31, [s38, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s28, #6
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s38, s14, #4544
    v.st.scatter.b [s47, v24], v40
    v.extract    s47, v23, #7
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s48, #0]
    v.splat      v37, s47
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v42, v31
    vf.fms       v31, v47, v43, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s47, s28, #7
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s48, s14, #4608
    v.st.scatter.b [s40, v24], v42
    v.extract    s40, v23, #8
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s49, #0]
    v.splat      v37, s40
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v44, v40, v46
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s40, s28, #8
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s49, s14, #4672
    v.st.scatter.b [s26, v24], v40
    v.extract    s26, v23, #9
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s38, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s26, s28, #9
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s38, s14, #4736
    v.st.scatter.b [s47, v24], v42
    v.extract    s47, v23, #10
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s48, #0]
    v.splat      v37, s47
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v46
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s47, s28, #10
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s48, s14, #4800
    v.st.scatter.b [s40, v24], v40
    v.extract    s40, v23, #11
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s49, #0]
    v.splat      v37, s40
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s40, s28, #11
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s49, s14, #4864
    v.st.scatter.b [s26, v24], v42
    v.extract    s26, v23, #12
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s38, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s28, #12
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s38, s14, #4928
    v.st.scatter.b [s47, v24], v40
    v.extract    s47, v23, #13
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s48, #0]
    v.splat      v37, s47
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s47, s28, #13
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s48, s14, #4992
    v.st.scatter.b [s40, v24], v42
    v.extract    s40, v23, #14
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s49, #0]
    v.splat      v37, s40
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v44, v40, v46
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s40, s28, #14
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s49, s14, #5056
    v.st.scatter.b [s26, v24], v40
    v.extract    s26, v23, #15
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s38, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s26, s28, #15
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s38, s14, #5120
    v.st.scatter.b [s47, v24], v42
    v.extract    s47, v23, #0
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s48, #0]
    v.splat      v37, s47
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v46
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s47, s28, #256
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s48, s14, #5184
    v.st.scatter.b [s40, v24], v40
    v.extract    s40, v23, #1
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s49, #0]
    v.splat      v37, s40
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s40, s28, #257
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s49, s14, #5248
    v.st.scatter.b [s26, v24], v42
    v.extract    s26, v23, #2
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s38, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s28, #258
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s38, s14, #5312
    v.st.scatter.b [s47, v24], v40
    v.extract    s47, v23, #3
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s48, #0]
    v.splat      v37, s47
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s47, s28, #259
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s48, s14, #5376
    v.st.scatter.b [s40, v24], v42
    v.extract    s40, v23, #4
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s49, #0]
    v.splat      v37, s40
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v44, v40, v46
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s40, s28, #260
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s49, s14, #5440
    v.st.scatter.b [s26, v24], v40
    v.extract    s26, v23, #5
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s38, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s26, s28, #261
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s38, s14, #5504
    v.st.scatter.b [s47, v24], v42
    v.extract    s47, v23, #6
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s48, #0]
    v.splat      v37, s47
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v46
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s47, s28, #262
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s48, s14, #5568
    v.st.scatter.b [s40, v24], v40
    v.extract    s40, v23, #7
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s49, #0]
    v.splat      v37, s40
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s40, s28, #263
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s49, s14, #5632
    v.st.scatter.b [s26, v24], v42
    v.extract    s26, v23, #8
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s38, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s28, #264
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s38, s14, #5696
    v.st.scatter.b [s47, v24], v40
    v.extract    s47, v23, #9
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s48, #0]
    v.splat      v37, s47
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s47, s28, #265
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s48, s14, #5760
    v.st.scatter.b [s40, v24], v42
    v.extract    s40, v23, #10
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s49, #0]
    v.splat      v37, s40
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v44, v40, v46
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s40, s28, #266
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s49, s14, #5824
    v.st.scatter.b [s26, v24], v40
    v.extract    s26, v23, #11
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s38, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s26, s28, #267
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s38, s14, #5888
    v.st.scatter.b [s47, v24], v42
    v.extract    s47, v23, #12
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s48, #0]
    v.splat      v37, s47
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v46
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s47, s28, #268
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s48, s14, #5952
    v.st.scatter.b [s40, v24], v40
    v.extract    s40, v23, #13
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s49, #0]
    v.splat      v37, s40
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s40, s28, #269
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s49, s14, #6016
    v.st.scatter.b [s26, v24], v42
    v.extract    s26, v23, #14
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s38, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s28, #270
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s38, s14, #6080
    v.st.scatter.b [s47, v24], v40
    v.extract    s47, v23, #15
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s48, #0]
    v.splat      v37, s47
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s47, s28, #271
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    v.st.scatter.b [s40, v24], v42
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s49, #0]
    s.addi       s40, s28, #64
    s.addi       s48, s28, #128
    s.addi       s49, s28, #192
    vf.mul       v37, v31, v40                   // a/y: faithful quotient
    s.addi       s50, s28, #256
    vf.fms       v43, v37, v44, v31
    vf.fms       v31, v43, v40, v37
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    s.addi       s51, s28, #320
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v31, v40, v37
    v.lshr       v37, v31, v39
    vf.cvt.f32.e4m3 v40, v31
    s.addi       s52, s28, #384
    v.and        v31, v37, v41
    v.or         v37, v40, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s53, s28, #448
    v.st.scatter.b [s26, v24], v37
    s.addi       s26, s27, #-64
    v.ld.w       v31, [s38, #0]
    v.splat      v37, s26
    v.movi       v40, #0
    v.movi       v43, #0
    v.sub        v44, v37, v28
    v.movi       v37, #4
    v.movi       v46, #3
    v.cmp.gt     p3, v44, v40
    v.max.s      v40, v44, v43
    v.movi       v43, #1
    v.min.s      v44, v40, v37
    vf.mul       v37, v31, v42                   // a/y: faithful quotient
    v.shl        v40, v44, v46
    vf.fms       v46, v37, v45, v31
    v.shl        v31, v43, v40
    vf.fms       v40, v46, v42, v37
    v.movi       v42, #1
    vf.neg       v43, v40                        // a/y: one correction to the IEEE quotient
    v.sub        v40, v31, v42
    vf.cmp.o     p4, v43, v43
    @p4 v.sel        v31, v43, v37
    v.movi       v37, #4
    v.lshr       v42, v31, v39
    vf.cvt.f32.e4m3 v43, v31
    v.movi       v31, #-1
    v.and        v45, v42, v41
    s.addi       s26, s23, #64
    v.cmp.ge     p4, v44, v37
    v.or         v37, v43, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.add        s38, s12, s26
    @p4 v.sel        v42, v31, v40
    v.st.scatter.b [s47, v24], v37
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.extract    s26, v22, #0
    p.and        p4, p1, p3
    s.add        s47, s38, s26
    v.ld.w       v31, [s28, #0]
    v.mov        v48, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s40, #0]
    v.extract    s26, v22, #1
    s.add        s28, s38, s26
    s.addi       s26, s28, #-32
    v.mov        v49, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s48, #0]
    p.and        p5, p2, p3
    v.mov        v50, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s49, #0]
    v.extract    s28, v22, #2
    v.mov        v51, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s50, #0]
    s.add        s40, s38, s28
    v.mov        v52, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s51, #0]
    v.extract    s28, v22, #3
    s.add        s48, s38, s28
    s.addi       s28, s48, #-32
    v.mov        v53, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s52, #0]
    v.mov        v54, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s53, #0]
    v.extract    s48, v22, #4
    v.mov        v55, v31                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v22, #5
    s.add        s49, s38, s48
    s.add        s48, s38, s47
    v.extract    s47, v22, #7
    s.addi       s50, s48, #-32
    v.extract    s48, v22, #6
    s.add        s51, s38, s47
    s.add        s47, s38, s48
    s.addi       s48, s51, #-32
    v.extract    s51, v22, #9
    v.extract    s52, v22, #8
    s.add        s53, s38, s51
    s.add        s51, s38, s52
    s.addi       s52, s53, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s26, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s40, #0]
    p.and        p4, p1, p3
    v.extract    s26, v22, #11
    v.extract    s40, v22, #10
    s.add        s53, s38, s26
    s.add        s26, s38, s40
    s.addi       s40, s53, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s28, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s49, #0]
    p.and        p4, p1, p3
    v.extract    s28, v22, #13
    v.extract    s49, v22, #12
    s.add        s53, s38, s28
    s.add        s28, s38, s49
    s.addi       s49, s53, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s50, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v22, #15
    v.extract    s50, v22, #14
    s.add        s53, s38, s47
    s.add        s47, s38, s50
    s.addi       s38, s53, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s48, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s51, #0]
    p.and        p4, p1, p3
    s.addi       s48, s23, #64
    v.extract    s50, v12, #0
    s.add        s51, s12, s48
    s.add        s48, s51, s50
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s52, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s50, v12, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s51, s50
    v.extract    s50, v12, #2
    s.addi       s52, s26, #-32
    s.add        s26, s51, s50
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s40, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v12, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s51, s40
    v.extract    s40, v12, #4
    s.addi       s50, s28, #-32
    s.add        s28, s51, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s49, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s40, v12, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    s.add        s47, s51, s40
    v.extract    s40, v12, #6
    s.addi       s49, s47, #-32
    s.add        s47, s51, s40
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s38, v12, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s40, b16, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s53, s51, s38
    m.mma.async.k32.e4m3 a8, v56, v48, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s48, #0]
    p.and        p4, p1, p3
    s.addi       s38, s53, #-32
    v.extract    s48, v12, #9
    v.extract    s53, v12, #8
    s.add        s54, s51, s48
    s.add        s48, s51, s53
    s.addi       s53, s54, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s52, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v12, #11
    v.extract    s52, v12, #10
    s.add        s54, s51, s26
    s.add        s26, s51, s52
    s.addi       s52, s54, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s50, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v12, #13
    v.extract    s50, v12, #12
    s.add        s54, s51, s28
    s.add        s28, s51, s50
    s.addi       s50, s54, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s49, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v12, #15
    v.extract    s49, v12, #14
    s.add        s54, s51, s47
    s.add        s47, s51, s49
    s.addi       s49, s54, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s48, #0]
    p.and        p4, p1, p3
    s.addi       s38, s23, #64
    v.extract    s48, v17, #0
    s.add        s51, s12, s38
    s.add        s38, s51, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s53, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v17, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s51, s48
    v.extract    s48, v17, #2
    s.addi       s53, s26, #-32
    s.add        s26, s51, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s52, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v17, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s51, s48
    v.extract    s48, v17, #4
    s.addi       s52, s28, #-32
    s.add        s28, s51, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s50, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v17, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    s.add        s47, s51, s48
    v.extract    s48, v17, #6
    s.addi       s50, s47, #-32
    s.add        s47, s51, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s49, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v17, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s49, b17, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s54, s51, s48
    m.mma.async.k32.e4m3 a9, v56, v48, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.addi       s38, s54, #-32
    v.extract    s48, v17, #9
    v.extract    s54, v17, #8
    s.add        s55, s51, s48
    s.add        s48, s51, s54
    s.addi       s54, s55, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s53, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v17, #11
    v.extract    s53, v17, #10
    s.add        s55, s51, s26
    s.add        s26, s51, s53
    s.addi       s53, s55, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s52, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v17, #13
    v.extract    s52, v17, #12
    s.add        s55, s51, s28
    s.add        s28, s51, s52
    s.addi       s52, s55, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s50, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v17, #15
    v.extract    s50, v17, #14
    s.add        s55, s51, s47
    s.add        s47, s51, s50
    s.addi       s50, s55, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s48, #0]
    p.and        p4, p1, p3
    s.addi       s38, s23, #64
    v.extract    s48, v29, #0
    s.add        s51, s12, s38
    s.add        s38, s51, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s54, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v29, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s51, s48
    v.extract    s48, v29, #2
    s.addi       s54, s26, #-32
    s.add        s26, s51, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s53, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v29, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s51, s48
    v.extract    s48, v29, #4
    s.addi       s53, s28, #-32
    s.add        s28, s51, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s52, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v29, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    s.add        s47, s51, s48
    v.extract    s48, v29, #6
    s.addi       s52, s47, #-32
    s.add        s47, s51, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s50, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v29, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s50, b18, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s55, s51, s48
    m.mma.async.k32.e4m3 a10, v56, v48, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.addi       s38, s55, #-32
    v.extract    s48, v29, #9
    v.extract    s55, v29, #8
    s.add        s56, s51, s48
    s.add        s48, s51, s55
    s.addi       s55, s56, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s54, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v29, #11
    v.extract    s54, v29, #10
    s.add        s56, s51, s26
    s.add        s26, s51, s54
    s.addi       s54, s56, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s53, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v29, #13
    v.extract    s53, v29, #12
    s.add        s56, s51, s28
    s.add        s28, s51, s53
    s.addi       s53, s56, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s52, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v29, #15
    v.extract    s52, v29, #14
    s.add        s56, s51, s47
    s.add        s47, s51, s52
    s.addi       s51, s56, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s48, #0]
    p.and        p4, p1, p3
    s.addi       s38, s23, #64
    v.extract    s48, v15, #0
    s.add        s52, s12, s38
    s.add        s38, s52, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s55, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v15, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s52, s48
    v.extract    s48, v15, #2
    s.addi       s55, s26, #-32
    s.add        s26, s52, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s54, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v15, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s52, s48
    v.extract    s48, v15, #4
    s.addi       s54, s28, #-32
    s.add        s28, s52, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s53, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v15, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    s.add        s47, s52, s48
    v.extract    s48, v15, #6
    s.addi       s53, s47, #-32
    s.add        s47, s52, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s51, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v15, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s51, b19, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s56, s52, s48
    m.mma.async.k32.e4m3 a11, v56, v48, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.addi       s38, s56, #-32
    v.extract    s48, v15, #9
    v.extract    s56, v15, #8
    s.add        s57, s52, s48
    s.add        s48, s52, s56
    s.addi       s56, s57, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s55, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v15, #11
    v.extract    s55, v15, #10
    s.add        s57, s52, s26
    s.add        s26, s52, s55
    s.addi       s55, s57, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s54, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v15, #13
    v.extract    s54, v15, #12
    s.add        s57, s52, s28
    s.add        s28, s52, s54
    s.addi       s54, s57, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s53, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v15, #15
    v.extract    s53, v15, #14
    s.add        s57, s52, s47
    s.add        s47, s52, s53
    s.addi       s52, s57, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s48, #0]
    p.and        p4, p1, p3
    s.addi       s38, s23, #64
    v.extract    s48, v30, #0
    s.add        s53, s12, s38
    s.add        s38, s53, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s56, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v30, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s53, s48
    v.extract    s48, v30, #2
    s.addi       s56, s26, #-32
    s.add        s26, s53, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s55, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v30, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s53, s48
    v.extract    s48, v30, #4
    s.addi       s55, s28, #-32
    s.add        s28, s53, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s54, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v30, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    s.add        s47, s53, s48
    v.extract    s48, v30, #6
    s.addi       s54, s47, #-32
    s.add        s47, s53, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s52, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v30, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s52, b20, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s57, s53, s48
    m.mma.async.k32.e4m3 a12, v56, v48, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.addi       s38, s57, #-32
    v.extract    s48, v30, #9
    v.extract    s57, v30, #8
    s.add        s58, s53, s48
    s.add        s48, s53, s57
    s.addi       s57, s58, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s56, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v30, #11
    v.extract    s56, v30, #10
    s.add        s58, s53, s26
    s.add        s26, s53, s56
    s.addi       s56, s58, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s55, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v30, #13
    v.extract    s55, v30, #12
    s.add        s58, s53, s28
    s.add        s28, s53, s55
    s.addi       s55, s58, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s54, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v30, #15
    v.extract    s54, v30, #14
    s.add        s58, s53, s47
    s.add        s47, s53, s54
    s.addi       s53, s58, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s48, #0]
    p.and        p4, p1, p3
    s.addi       s38, s23, #64
    v.extract    s48, v32, #0
    s.add        s54, s12, s38
    s.add        s38, s54, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s57, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v32, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s54, s48
    v.extract    s48, v32, #2
    s.addi       s57, s26, #-32
    s.add        s26, s54, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s56, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v32, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s54, s48
    v.extract    s48, v32, #4
    s.addi       s56, s28, #-32
    s.add        s28, s54, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s55, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v32, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    s.add        s47, s54, s48
    v.extract    s48, v32, #6
    s.addi       s55, s47, #-32
    s.add        s47, s54, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s53, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v32, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s53, b21, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s58, s54, s48
    m.mma.async.k32.e4m3 a13, v56, v48, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.addi       s38, s58, #-32
    v.extract    s48, v32, #9
    v.extract    s58, v32, #8
    s.add        s59, s54, s48
    s.add        s48, s54, s58
    s.addi       s58, s59, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s57, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v32, #11
    v.extract    s57, v32, #10
    s.add        s59, s54, s26
    s.add        s26, s54, s57
    s.addi       s57, s59, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s56, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v32, #13
    v.extract    s56, v32, #12
    s.add        s59, s54, s28
    s.add        s28, s54, s56
    s.addi       s56, s59, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s55, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v32, #15
    v.extract    s55, v32, #14
    s.add        s59, s54, s47
    s.add        s47, s54, s55
    s.addi       s54, s59, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s48, #0]
    p.and        p4, p1, p3
    s.addi       s38, s23, #64
    v.extract    s48, v34, #0
    s.add        s55, s12, s38
    s.add        s38, s55, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s58, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v34, #1
    v.mov        v60, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s55, s48
    v.extract    s48, v34, #2
    s.addi       s58, s26, #-32
    s.add        s26, s55, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s57, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v34, #3
    v.mov        v61, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s55, s48
    v.extract    s48, v34, #4
    s.addi       s57, s28, #-32
    s.add        s28, s55, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s56, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v34, #5
    v.mov        v62, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    s.add        s47, s55, s48
    v.extract    s48, v34, #6
    s.addi       s56, s47, #-32
    s.add        s47, s55, s48
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s54, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.extract    s48, v34, #7
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    mb.arm       s54, b22, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s59, s55, s48
    m.mma.async.k32.e4m3 a14, v56, v48, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s38, #0]
    p.and        p4, p1, p3
    s.addi       s38, s59, #-32
    v.extract    s48, v34, #9
    v.extract    s59, v34, #8
    s.add        s60, s55, s48
    s.add        s48, s55, s59
    s.addi       s59, s60, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s58, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v56, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v34, #11
    v.extract    s58, v34, #10
    s.add        s60, s55, s26
    s.add        s26, s55, s58
    s.addi       s58, s60, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s57, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v57, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v34, #13
    v.extract    s57, v34, #12
    s.add        s60, s55, s28
    s.add        s28, s55, s57
    s.addi       s57, s60, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s56, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v58, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s47, #0]
    p.and        p4, p1, p3
    v.extract    s47, v34, #15
    v.extract    s56, v34, #14
    s.add        s60, s55, s47
    s.add        s47, s55, s56
    s.addi       s55, s60, #-32
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v37, [s38, #0]
    p.and        p5, p2, p3
    v.or         v40, v31, v37
    v.and        v31, v40, v42
    v.mov        v59, v31                        // hand off through the shared window (sec 7.3)
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v31, [s48, #0]
    p.and        p4, p1, p3
    v.extract    s38, v23, #0
    s.addi       s48, s14, #6144
    v.splat      v37, s38
    s.addi       s38, s14, #9728                 // 512 bytes of repack scratch
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v40, [s59, #0]
    p.and        p5, p2, p3
    vf.max.ieee  v43, v37, v14
    v.or         v37, v31, v40
    v.rcp.approx v31, v43                        // ISA 8.8: <= 2**-22 relative
    v.and        v40, v37, v42
    v.mov        v60, v40                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s26, #0]
    p.and        p4, p1, p3
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v40, [s58, #0]
    p.and        p5, p2, p3
    vf.fms       v44, v43, v31, v21
    vf.fms       v45, v31, v44, v31
    vf.neg       v44, v45                        // Newton step: r0*(2 - x*r0)
    v.or         v45, v37, v40
    v.and        v37, v45, v42
    v.mov        v61, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s28, #0]
    p.and        p4, p1, p3
    p.and        p6, p2, p3
    v.extract    s26, v23, #1
    s.addi       s28, s38, #0
    v.splat      v40, s26
    s.addi       s26, s14, #6208
    vf.max.ieee  v45, v40, v14
    v.movi       v40, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v40, [s57, #0]
    vf.cmp.o     p3, v44, v44
    @p3 v.sel        v46, v44, v31
    v.rcp.approx v31, v45                        // ISA 8.8: <= 2**-22 relative
    v.or         v44, v37, v40
    v.and        v37, v44, v42
    v.mov        v62, v37                        // hand off through the shared window (sec 7.3)
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v37, [s47, #0]
    vf.fms       v40, v45, v31, v21
    vf.fms       v44, v31, v40, v31
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    v.movi       v44, #0                         // other=, materialised (sec 12)
    @p6 v.ld.w       v44, [s55, #0]
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v47, v40, v31
    v.or         v31, v37, v44
    v.and        v37, v31, v42
    v.mov        v63, v37                        // hand off through the shared window (sec 7.3)
    mb.arm       s47, b23, #0, #1                // 0 arrival(s), 1 operation(s)
    s.addi       s55, s38, #1
    m.mma.async.k32.e4m3 a15, v56, v48, s47
    mb.wait      s47
    v.ld.w       v31, [s48, #0]
    v.extract    s48, v23, #2
    s.addi       s56, s14, #6272
    v.splat      v37, s48
    vf.max.ieee  v40, v37, v14
    v.rcp.approx v37, v40                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v42, v31, v46                   // a/y: faithful quotient
    vf.fms       v44, v42, v43, v31
    vf.fms       v31, v44, v46, v42
    vf.neg       v43, v31                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v31, v43, v42
    vf.fms       v42, v40, v37, v21
    v.lshr       v43, v31, v39
    vf.cvt.f32.e4m3 v44, v31
    v.and        v31, v43, v41
    vf.fms       v43, v37, v42, v37
    s.addi       s48, s38, #2
    v.or         v42, v44, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s57, s14, #6336
    v.st.scatter.b [s28, v24], v42
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    v.extract    s28, v23, #3
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s26, #0]
    v.splat      v37, s28
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v31, v47                   // a/y: faithful quotient
    vf.fms       v46, v44, v45, v31
    vf.fms       v31, v46, v47, v44
    vf.neg       v45, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v45, v45
    @p3 v.sel        v46, v45, v44
    v.lshr       v44, v46, v39
    vf.cvt.f32.e4m3 v45, v46
    vf.fms       v46, v37, v31, v37
    v.and        v31, v44, v41
    s.addi       s26, s38, #3
    v.or         v44, v45, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v46                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #6400
    v.st.scatter.b [s55, v24], v44
    v.extract    s55, v23, #4
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v44, v31, v37
    v.ld.w       v31, [s56, #0]
    v.splat      v37, s55
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v40, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v42, v40, v46
    v.lshr       v40, v42, v39
    vf.cvt.f32.e4m3 v46, v42
    vf.fms       v42, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s55, s38, #4
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v42                        // Newton step: r0*(2 - x*r0)
    s.addi       s56, s14, #6464
    v.st.scatter.b [s48, v24], v40
    v.extract    s48, v23, #5
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s57, #0]
    v.splat      v37, s48
    vf.max.ieee  v42, v37, v14
    v.rcp.approx v37, v42                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v44                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v44, v46
    vf.neg       v43, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v42, v37, v21
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v44, v43, v46
    v.lshr       v43, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v43, v41
    s.addi       s48, s38, #5
    v.or         v43, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s57, s14, #6528
    v.st.scatter.b [s26, v24], v43
    v.extract    s26, v23, #6
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v43, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s38, #6
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #6592
    v.st.scatter.b [s55, v24], v40
    v.extract    s55, v23, #7
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s56, #0]
    v.splat      v37, s55
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v42, v31
    vf.fms       v31, v47, v43, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s55, s38, #7
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s56, s14, #6656
    v.st.scatter.b [s48, v24], v42
    v.extract    s48, v23, #8
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s57, #0]
    v.splat      v37, s48
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v44, v40, v46
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s48, s38, #8
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s57, s14, #6720
    v.st.scatter.b [s26, v24], v40
    v.extract    s26, v23, #9
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s26, s38, #9
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #6784
    v.st.scatter.b [s55, v24], v42
    v.extract    s55, v23, #10
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s56, #0]
    v.splat      v37, s55
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v46
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s55, s38, #10
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s56, s14, #6848
    v.st.scatter.b [s48, v24], v40
    v.extract    s48, v23, #11
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s57, #0]
    v.splat      v37, s48
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s48, s38, #11
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s57, s14, #6912
    v.st.scatter.b [s26, v24], v42
    v.extract    s26, v23, #12
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s38, #12
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #6976
    v.st.scatter.b [s55, v24], v40
    v.extract    s55, v23, #13
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s56, #0]
    v.splat      v37, s55
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s55, s38, #13
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s56, s14, #7040
    v.st.scatter.b [s48, v24], v42
    v.extract    s48, v23, #14
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s57, #0]
    v.splat      v37, s48
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v44, v40, v46
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s48, s38, #14
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s57, s14, #7104
    v.st.scatter.b [s26, v24], v40
    v.extract    s26, v23, #15
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s26, s38, #15
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #7168
    v.st.scatter.b [s55, v24], v42
    v.extract    s55, v23, #0
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s56, #0]
    v.splat      v37, s55
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v46
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s55, s38, #256
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s56, s14, #7232
    v.st.scatter.b [s48, v24], v40
    v.extract    s48, v23, #1
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s57, #0]
    v.splat      v37, s48
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s48, s38, #257
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s57, s14, #7296
    v.st.scatter.b [s26, v24], v42
    v.extract    s26, v23, #2
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s38, #258
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #7360
    v.st.scatter.b [s55, v24], v40
    v.extract    s55, v23, #3
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s56, #0]
    v.splat      v37, s55
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s55, s38, #259
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s56, s14, #7424
    v.st.scatter.b [s48, v24], v42
    v.extract    s48, v23, #4
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s57, #0]
    v.splat      v37, s48
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v44, v40, v46
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s48, s38, #260
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s57, s14, #7488
    v.st.scatter.b [s26, v24], v40
    v.extract    s26, v23, #5
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s26, s38, #261
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #7552
    v.st.scatter.b [s55, v24], v42
    v.extract    s55, v23, #6
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s56, #0]
    v.splat      v37, s55
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v46
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s55, s38, #262
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s56, s14, #7616
    v.st.scatter.b [s48, v24], v40
    v.extract    s48, v23, #7
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s57, #0]
    v.splat      v37, s48
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s48, s38, #263
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s57, s14, #7680
    v.st.scatter.b [s26, v24], v42
    v.extract    s26, v23, #8
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s38, #264
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #7744
    v.st.scatter.b [s55, v24], v40
    v.extract    s55, v23, #9
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s56, #0]
    v.splat      v37, s55
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v43, v42, v46
    v.lshr       v42, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s55, s38, #265
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s56, s14, #7808
    v.st.scatter.b [s48, v24], v42
    v.extract    s48, v23, #10
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s57, #0]
    v.splat      v37, s48
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v44, v40, v46
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s48, s38, #266
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s57, s14, #7872
    v.st.scatter.b [s26, v24], v40
    v.extract    s26, v23, #11
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v45, v42, v46
    v.lshr       v42, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s26, s38, #267
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #7936
    v.st.scatter.b [s55, v24], v42
    v.extract    s55, v23, #12
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s56, #0]
    v.splat      v37, s55
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v43, v40, v46
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s55, s38, #268
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s56, s14, #8000
    v.st.scatter.b [s48, v24], v40
    v.extract    s48, v23, #13
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s57, #0]
    v.splat      v37, s48
    vf.max.ieee  v43, v37, v14
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v31
    vf.fms       v31, v47, v42, v46
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v43, v37, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v44, v42, v46
    v.lshr       v42, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v37, v31, v37
    v.and        v31, v42, v41
    s.addi       s48, s38, #269
    v.or         v42, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s57, s14, #8064
    v.st.scatter.b [s26, v24], v42
    v.extract    s26, v23, #14
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v42, v31, v37
    v.ld.w       v31, [s28, #0]
    v.splat      v37, s26
    vf.max.ieee  v44, v37, v14
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v31, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v31
    vf.fms       v31, v47, v40, v46
    vf.neg       v40, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v44, v37, v21
    vf.cmp.o     p3, v40, v40
    @p3 v.sel        v45, v40, v46
    v.lshr       v40, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v37, v31, v37
    v.and        v31, v40, v41
    s.addi       s26, s38, #270
    v.or         v40, v46, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #8128
    v.st.scatter.b [s55, v24], v40
    v.extract    s55, v23, #15
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v40, v31, v37
    v.ld.w       v31, [s56, #0]
    v.splat      v37, s55
    vf.max.ieee  v45, v37, v14
    v.rcp.approx v14, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v37, v31, v42                   // a/y: faithful quotient
    vf.fms       v46, v37, v43, v31
    vf.fms       v31, v46, v42, v37
    vf.neg       v42, v31                        // a/y: one correction to the IEEE quotient
    vf.fms       v31, v45, v14, v21
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v21, v42, v37
    v.lshr       v37, v21, v39
    vf.cvt.f32.e4m3 v42, v21
    vf.fms       v21, v14, v31, v14
    v.and        v31, v37, v41
    s.addi       s55, s38, #271
    v.or         v37, v42, v31                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v31, v21                        // Newton step: r0*(2 - x*r0)
    v.st.scatter.b [s48, v24], v37
    vf.cmp.o     p3, v31, v31
    @p3 v.sel        v21, v31, v14
    v.ld.w       v14, [s57, #0]
    s.addi       s48, s38, #64
    s.addi       s56, s38, #128
    s.addi       s57, s38, #192
    vf.mul       v31, v14, v40                   // a/y: faithful quotient
    s.addi       s58, s38, #256
    vf.fms       v37, v31, v44, v14
    vf.fms       v14, v37, v40, v31
    vf.neg       v37, v14                        // a/y: one correction to the IEEE quotient
    s.addi       s59, s38, #320
    vf.cmp.o     p3, v37, v37
    @p3 v.sel        v14, v37, v31
    v.lshr       v31, v14, v39
    vf.cvt.f32.e4m3 v37, v14
    s.addi       s60, s38, #384
    v.and        v14, v31, v41
    v.or         v31, v37, v14                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s29, s38, #448
    v.st.scatter.b [s26, v24], v31
    s.addi       s26, s27, #-96
    v.ld.w       v14, [s28, #0]
    v.splat      v31, s26
    v.movi       v37, #0
    v.movi       v40, #0
    v.sub        v42, v31, v28
    v.movi       v28, #4
    v.movi       v31, #3
    v.cmp.gt     p3, v42, v37
    v.max.s      v37, v42, v40
    v.movi       v40, #1
    v.min.s      v42, v37, v28
    vf.mul       v28, v14, v21                   // a/y: faithful quotient
    v.shl        v37, v42, v31
    vf.fms       v31, v28, v45, v14
    v.shl        v14, v40, v37
    vf.fms       v37, v31, v21, v28
    v.movi       v21, #1
    vf.neg       v31, v37                        // a/y: one correction to the IEEE quotient
    v.sub        v37, v14, v21
    vf.cmp.o     p4, v31, v31
    @p4 v.sel        v14, v31, v28
    v.movi       v21, #4
    v.lshr       v28, v14, v39
    vf.cvt.f32.e4m3 v31, v14
    v.movi       v14, #-1
    v.and        v39, v28, v41
    s.addi       s26, s23, #96
    v.cmp.ge     p4, v42, v21
    v.or         v21, v31, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.add        s27, s12, s26
    @p4 v.sel        v28, v14, v37
    v.st.scatter.b [s55, v24], v21
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.extract    s26, v22, #0
    p.and        p4, p1, p3
    s.add        s28, s27, s26
    v.ld.w       v14, [s38, #0]
    v.mov        v48, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s48, #0]
    v.extract    s26, v22, #1
    s.add        s30, s27, s26
    s.addi       s26, s30, #-32
    v.mov        v49, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s56, #0]
    p.and        p5, p2, p3
    v.mov        v50, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s57, #0]
    v.extract    s30, v22, #2
    v.mov        v51, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s58, #0]
    s.add        s31, s27, s30
    v.mov        v52, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s59, #0]
    v.extract    s30, v22, #3
    s.add        s32, s27, s30
    s.addi       s30, s32, #-32
    v.mov        v53, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s60, #0]
    v.mov        v54, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s29, #0]
    v.extract    s29, v22, #4
    v.mov        v55, v14                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v14, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v22, #5
    s.add        s32, s27, s29
    s.add        s29, s27, s28
    v.extract    s28, v22, #7
    s.addi       s33, s29, #-32
    v.extract    s29, v22, #6
    s.add        s34, s27, s28
    s.add        s28, s27, s29
    s.addi       s29, s34, #-32
    v.extract    s34, v22, #9
    v.extract    s35, v22, #8
    s.add        s36, s27, s34
    s.add        s34, s27, s35
    s.addi       s35, s36, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v21, [s26, #0]
    p.and        p5, p2, p3
    v.or         v31, v14, v21
    v.and        v14, v31, v28
    v.mov        v56, v14                        // hand off through the shared window (sec 7.3)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v14, [s31, #0]
    p.and        p4, p1, p3
    v.extract    s26, v22, #11
    v.extract    s31, v22, #10
    s.add        s36, s27, s26
    s.add        s26, s27, s31
    s.addi       s31, s36, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v21, [s30, #0]
    p.and        p5, p2, p3
    v.or         v31, v14, v21
    v.and        v14, v31, v28
    v.mov        v57, v14                        // hand off through the shared window (sec 7.3)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v14, [s32, #0]
    p.and        p4, p1, p3
    v.extract    s30, v22, #13
    v.extract    s32, v22, #12
    s.add        s36, s27, s30
    s.add        s30, s27, s32
    s.addi       s32, s36, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v21, [s33, #0]
    p.and        p5, p2, p3
    v.or         v31, v14, v21
    v.and        v14, v31, v28
    v.mov        v58, v14                        // hand off through the shared window (sec 7.3)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v14, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v22, #15
    v.extract    s33, v22, #14
    s.add        s36, s27, s28
    s.add        s28, s27, s33
    s.addi       s27, s36, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v21, [s29, #0]
    p.and        p5, p2, p3
    v.or         v22, v14, v21
    v.and        v14, v22, v28
    v.mov        v59, v14                        // hand off through the shared window (sec 7.3)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v14, [s34, #0]
    p.and        p4, p1, p3
    s.addi       s29, s23, #96
    v.extract    s33, v12, #0
    s.add        s34, s12, s29
    s.add        s29, s34, s33
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v21, [s35, #0]
    p.and        p5, p2, p3
    v.or         v22, v14, v21
    v.and        v14, v22, v28
    v.extract    s33, v12, #1
    v.mov        v60, v14                        // hand off through the shared window (sec 7.3)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v14, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s34, s33
    v.extract    s33, v12, #2
    s.addi       s35, s26, #-32
    s.add        s26, s34, s33
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v21, [s31, #0]
    p.and        p5, p2, p3
    v.or         v22, v14, v21
    v.and        v14, v22, v28
    v.extract    s31, v12, #3
    v.mov        v61, v14                        // hand off through the shared window (sec 7.3)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v14, [s30, #0]
    p.and        p4, p1, p3
    s.add        s30, s34, s31
    v.extract    s31, v12, #4
    s.addi       s33, s30, #-32
    s.add        s30, s34, s31
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v21, [s32, #0]
    p.and        p5, p2, p3
    v.or         v22, v14, v21
    v.and        v14, v22, v28
    v.extract    s31, v12, #5
    v.mov        v62, v14                        // hand off through the shared window (sec 7.3)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v14, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s34, s31
    v.extract    s31, v12, #6
    s.addi       s32, s28, #-32
    s.add        s28, s34, s31
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v21, [s27, #0]
    p.and        p5, p2, p3
    v.or         v22, v14, v21
    v.and        v14, v22, v28
    v.extract    s27, v12, #7
    v.mov        v63, v14                        // hand off through the shared window (sec 7.3)
    mb.arm       s31, b24, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s36, s34, s27
    m.mma.async.k32.e4m3 a8, v56, v48, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v14, [s29, #0]
    p.and        p4, p1, p3
    s.addi       s27, s36, #-32
    v.extract    s29, v12, #9
    v.extract    s36, v12, #8
    s.add        s37, s34, s29
    s.add        s29, s34, s36
    s.addi       s36, s37, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v21, [s35, #0]
    p.and        p5, p2, p3
    v.or         v22, v14, v21
    v.and        v14, v22, v28
    v.mov        v56, v14                        // hand off through the shared window (sec 7.3)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v14, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v12, #11
    v.extract    s35, v12, #10
    s.add        s37, s34, s26
    s.add        s26, s34, s35
    s.addi       s35, s37, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v21, [s33, #0]
    p.and        p5, p2, p3
    v.or         v22, v14, v21
    v.and        v14, v22, v28
    v.mov        v57, v14                        // hand off through the shared window (sec 7.3)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v14, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v12, #13
    v.extract    s33, v12, #12
    s.add        s37, s34, s30
    s.add        s30, s34, s33
    s.addi       s33, s37, #-32
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v21, [s32, #0]
    p.and        p5, p2, p3
    v.or         v22, v14, v21
    v.and        v14, v22, v28
    v.mov        v58, v14                        // hand off through the shared window (sec 7.3)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v14, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v12, #15
    v.extract    s32, v12, #14
    s.add        s37, s34, s28
    s.add        s28, s34, s32
    s.addi       s32, s37, #-32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v12, [s27, #0]
    p.and        p5, p2, p3
    v.or         v21, v14, v12
    v.and        v12, v21, v28
    v.mov        v59, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s29, #0]
    p.and        p4, p1, p3
    s.addi       s27, s23, #96
    v.extract    s29, v17, #0
    s.add        s34, s12, s27
    s.add        s27, s34, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s36, #0]
    p.and        p5, p2, p3
    v.or         v21, v12, v14
    v.and        v12, v21, v28
    v.extract    s29, v17, #1
    v.mov        v60, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s34, s29
    v.extract    s29, v17, #2
    s.addi       s36, s26, #-32
    s.add        s26, s34, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s35, #0]
    p.and        p5, p2, p3
    v.or         v21, v12, v14
    v.and        v12, v21, v28
    v.extract    s29, v17, #3
    v.mov        v61, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    p.and        p4, p1, p3
    s.add        s30, s34, s29
    v.extract    s29, v17, #4
    s.addi       s35, s30, #-32
    s.add        s30, s34, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s33, #0]
    p.and        p5, p2, p3
    v.or         v21, v12, v14
    v.and        v12, v21, v28
    v.extract    s29, v17, #5
    v.mov        v62, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s34, s29
    v.extract    s29, v17, #6
    s.addi       s33, s28, #-32
    s.add        s28, s34, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s32, #0]
    p.and        p5, p2, p3
    v.or         v21, v12, v14
    v.and        v12, v21, v28
    v.extract    s29, v17, #7
    v.mov        v63, v12                        // hand off through the shared window (sec 7.3)
    mb.arm       s32, b25, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s37, s34, s29
    m.mma.async.k32.e4m3 a9, v56, v48, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s27, #0]
    p.and        p4, p1, p3
    s.addi       s27, s37, #-32
    v.extract    s29, v17, #9
    v.extract    s37, v17, #8
    s.add        s38, s34, s29
    s.add        s29, s34, s37
    s.addi       s37, s38, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s36, #0]
    p.and        p5, p2, p3
    v.or         v21, v12, v14
    v.and        v12, v21, v28
    v.mov        v56, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v17, #11
    v.extract    s36, v17, #10
    s.add        s38, s34, s26
    s.add        s26, s34, s36
    s.addi       s36, s38, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s35, #0]
    p.and        p5, p2, p3
    v.or         v21, v12, v14
    v.and        v12, v21, v28
    v.mov        v57, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v17, #13
    v.extract    s35, v17, #12
    s.add        s38, s34, s30
    s.add        s30, s34, s35
    s.addi       s35, s38, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s33, #0]
    p.and        p5, p2, p3
    v.or         v21, v12, v14
    v.and        v12, v21, v28
    v.mov        v58, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v17, #15
    v.extract    s33, v17, #14
    s.add        s38, s34, s28
    s.add        s28, s34, s33
    s.addi       s33, s38, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s27, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.mov        v59, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s29, #0]
    p.and        p4, p1, p3
    s.addi       s27, s23, #96
    v.extract    s29, v29, #0
    s.add        s34, s12, s27
    s.add        s27, s34, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s37, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.extract    s29, v29, #1
    v.mov        v60, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s34, s29
    v.extract    s29, v29, #2
    s.addi       s37, s26, #-32
    s.add        s26, s34, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s36, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.extract    s29, v29, #3
    v.mov        v61, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    p.and        p4, p1, p3
    s.add        s30, s34, s29
    v.extract    s29, v29, #4
    s.addi       s36, s30, #-32
    s.add        s30, s34, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s35, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.extract    s29, v29, #5
    v.mov        v62, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s34, s29
    v.extract    s29, v29, #6
    s.addi       s35, s28, #-32
    s.add        s28, s34, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s33, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.extract    s29, v29, #7
    v.mov        v63, v12                        // hand off through the shared window (sec 7.3)
    mb.arm       s33, b26, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s38, s34, s29
    m.mma.async.k32.e4m3 a10, v56, v48, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s27, #0]
    p.and        p4, p1, p3
    s.addi       s27, s38, #-32
    v.extract    s29, v29, #9
    v.extract    s38, v29, #8
    s.add        s39, s34, s29
    s.add        s29, s34, s38
    s.addi       s38, s39, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s37, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.mov        v56, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v29, #11
    v.extract    s37, v29, #10
    s.add        s39, s34, s26
    s.add        s26, s34, s37
    s.addi       s37, s39, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s36, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.mov        v57, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v29, #13
    v.extract    s36, v29, #12
    s.add        s39, s34, s30
    s.add        s30, s34, s36
    s.addi       s36, s39, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s35, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.mov        v58, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v29, #15
    v.extract    s35, v29, #14
    s.add        s39, s34, s28
    s.add        s28, s34, s35
    s.addi       s34, s39, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s27, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.mov        v59, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s29, #0]
    p.and        p4, p1, p3
    s.addi       s27, s23, #96
    v.extract    s29, v15, #0
    s.add        s35, s12, s27
    s.add        s27, s35, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s38, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.extract    s29, v15, #1
    v.mov        v60, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s35, s29
    v.extract    s29, v15, #2
    s.addi       s38, s26, #-32
    s.add        s26, s35, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s37, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.extract    s29, v15, #3
    v.mov        v61, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    p.and        p4, p1, p3
    s.add        s30, s35, s29
    v.extract    s29, v15, #4
    s.addi       s37, s30, #-32
    s.add        s30, s35, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s36, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.extract    s29, v15, #5
    v.mov        v62, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s35, s29
    v.extract    s29, v15, #6
    s.addi       s36, s28, #-32
    s.add        s28, s35, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s34, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.extract    s29, v15, #7
    v.mov        v63, v12                        // hand off through the shared window (sec 7.3)
    mb.arm       s34, b27, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s39, s35, s29
    m.mma.async.k32.e4m3 a11, v56, v48, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s27, #0]
    p.and        p4, p1, p3
    s.addi       s27, s39, #-32
    v.extract    s29, v15, #9
    v.extract    s39, v15, #8
    s.add        s40, s35, s29
    s.add        s29, s35, s39
    s.addi       s39, s40, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s38, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.mov        v56, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v15, #11
    v.extract    s38, v15, #10
    s.add        s40, s35, s26
    s.add        s26, s35, s38
    s.addi       s38, s40, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s37, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.mov        v57, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v15, #13
    v.extract    s37, v15, #12
    s.add        s40, s35, s30
    s.add        s30, s35, s37
    s.addi       s37, s40, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s36, #0]
    p.and        p5, p2, p3
    v.or         v17, v12, v14
    v.and        v12, v17, v28
    v.mov        v58, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v15, #15
    v.extract    s36, v15, #14
    s.add        s40, s35, s28
    s.add        s28, s35, s36
    s.addi       s35, s40, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s27, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v59, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s29, #0]
    p.and        p4, p1, p3
    s.addi       s27, s23, #96
    v.extract    s29, v30, #0
    s.add        s36, s12, s27
    s.add        s27, s36, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s39, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.extract    s29, v30, #1
    v.mov        v60, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s36, s29
    v.extract    s29, v30, #2
    s.addi       s39, s26, #-32
    s.add        s26, s36, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s38, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.extract    s29, v30, #3
    v.mov        v61, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    p.and        p4, p1, p3
    s.add        s30, s36, s29
    v.extract    s29, v30, #4
    s.addi       s38, s30, #-32
    s.add        s30, s36, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s37, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.extract    s29, v30, #5
    v.mov        v62, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s36, s29
    v.extract    s29, v30, #6
    s.addi       s37, s28, #-32
    s.add        s28, s36, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s35, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.extract    s29, v30, #7
    v.mov        v63, v12                        // hand off through the shared window (sec 7.3)
    mb.arm       s35, b28, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s40, s36, s29
    m.mma.async.k32.e4m3 a12, v56, v48, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s27, #0]
    p.and        p4, p1, p3
    s.addi       s27, s40, #-32
    v.extract    s29, v30, #9
    v.extract    s40, v30, #8
    s.add        s41, s36, s29
    s.add        s29, s36, s40
    s.addi       s40, s41, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s39, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v56, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v30, #11
    v.extract    s39, v30, #10
    s.add        s41, s36, s26
    s.add        s26, s36, s39
    s.addi       s39, s41, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s38, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v57, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v30, #13
    v.extract    s38, v30, #12
    s.add        s41, s36, s30
    s.add        s30, s36, s38
    s.addi       s38, s41, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s37, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v58, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v30, #15
    v.extract    s37, v30, #14
    s.add        s41, s36, s28
    s.add        s28, s36, s37
    s.addi       s36, s41, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s27, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v59, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s29, #0]
    p.and        p4, p1, p3
    s.addi       s27, s23, #96
    v.extract    s29, v32, #0
    s.add        s37, s12, s27
    s.add        s27, s37, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s40, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.extract    s29, v32, #1
    v.mov        v60, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s37, s29
    v.extract    s29, v32, #2
    s.addi       s40, s26, #-32
    s.add        s26, s37, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s39, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.extract    s29, v32, #3
    v.mov        v61, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    p.and        p4, p1, p3
    s.add        s30, s37, s29
    v.extract    s29, v32, #4
    s.addi       s39, s30, #-32
    s.add        s30, s37, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s38, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.extract    s29, v32, #5
    v.mov        v62, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s37, s29
    v.extract    s29, v32, #6
    s.addi       s38, s28, #-32
    s.add        s28, s37, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s36, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.extract    s29, v32, #7
    v.mov        v63, v12                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b29, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s41, s37, s29
    m.mma.async.k32.e4m3 a13, v56, v48, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s27, #0]
    p.and        p4, p1, p3
    s.addi       s27, s41, #-32
    v.extract    s29, v32, #9
    v.extract    s41, v32, #8
    s.add        s42, s37, s29
    s.add        s29, s37, s41
    s.addi       s41, s42, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s40, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v56, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v32, #11
    v.extract    s40, v32, #10
    s.add        s42, s37, s26
    s.add        s26, s37, s40
    s.addi       s40, s42, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s39, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v57, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v32, #13
    v.extract    s39, v32, #12
    s.add        s42, s37, s30
    s.add        s30, s37, s39
    s.addi       s39, s42, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s38, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v58, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v32, #15
    v.extract    s38, v32, #14
    s.add        s42, s37, s28
    s.add        s28, s37, s38
    s.addi       s37, s42, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s27, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v59, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s29, #0]
    p.and        p4, p1, p3
    s.addi       s27, s23, #96
    v.extract    s29, v34, #0
    s.add        s38, s12, s27
    s.add        s27, s38, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s41, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.extract    s29, v34, #1
    v.mov        v60, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    s.add        s26, s38, s29
    v.extract    s29, v34, #2
    s.addi       s41, s26, #-32
    s.add        s26, s38, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s40, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.extract    s29, v34, #3
    v.mov        v61, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    p.and        p4, p1, p3
    s.add        s30, s38, s29
    v.extract    s29, v34, #4
    s.addi       s40, s30, #-32
    s.add        s30, s38, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s39, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.extract    s29, v34, #5
    v.mov        v62, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s28, #0]
    p.and        p4, p1, p3
    s.add        s28, s38, s29
    v.extract    s29, v34, #6
    s.addi       s39, s28, #-32
    s.add        s28, s38, s29
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s37, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.extract    s29, v34, #7
    v.mov        v63, v12                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b30, #0, #1                // 0 arrival(s), 1 operation(s)
    s.add        s42, s38, s29
    m.mma.async.k32.e4m3 a14, v56, v48, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s27, #0]
    p.and        p4, p1, p3
    s.addi       s27, s42, #-32
    v.extract    s29, v34, #9
    v.extract    s42, v34, #8
    s.add        s43, s38, s29
    s.add        s29, s38, s42
    s.addi       s42, s43, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s41, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v56, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    v.extract    s26, v34, #11
    v.extract    s41, v34, #10
    s.add        s43, s38, s26
    s.add        s26, s38, s41
    s.addi       s41, s43, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s40, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v57, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    p.and        p4, p1, p3
    v.extract    s30, v34, #13
    v.extract    s40, v34, #12
    s.add        s43, s38, s30
    s.add        s30, s38, s40
    s.addi       s40, s43, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s39, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v58, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s28, #0]
    p.and        p4, p1, p3
    v.extract    s28, v34, #15
    v.extract    s39, v34, #14
    s.add        s43, s38, s28
    s.add        s28, s38, s39
    s.addi       s38, s43, #-32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s27, #0]
    p.and        p5, p2, p3
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v59, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s29, #0]
    p.and        p4, p1, p3
    s.movz       s27, #0
    s.addi       s29, s14, #10240
    s.addi       s39, s29, #4
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s42, #0]
    p.and        p5, p2, p3
    s.movz       s42, #1
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v60, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s26, #0]
    p.and        p4, p1, p3
    p.and        p6, p1, p3
    s.movz       s26, #2
    s.addi       s43, s29, #8
    s.movz       s44, #3
    s.addi       s45, s29, #12
    s.addi       s46, s29, #16
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s41, #0]
    p.and        p1, p2, p3
    p.and        p5, p2, p3
    s.movz       s41, #4
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v61, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v12, [s30, #0]
    s.movz       s30, #5
    s.addi       s47, s29, #20
    s.movz       s48, #6
    s.addi       s49, s29, #24
    s.addi       s50, s29, #28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v14, [s40, #0]
    s.movz       s40, #7
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v62, v12                        // hand off through the shared window (sec 7.3)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p6 v.ld.w       v12, [s28, #0]
    s.movz       s28, #8
    s.addi       s51, s29, #32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v14, [s38, #0]
    s.movz       s38, #9
    v.or         v15, v12, v14
    v.and        v12, v15, v28
    v.mov        v63, v12                        // hand off through the shared window (sec 7.3)
    mb.arm       s52, b31, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s52
    mb.wait      s52
    a.vread      v12, a8, s27
    s.addi       s27, s29, #36
    v.st.scatter.w [s29, v24], v12
    a.vread      v12, a8, s42
    s.movz       s42, #10
    v.st.scatter.w [s39, v24], v12
    a.vread      v12, a8, s26
    s.addi       s26, s29, #40
    s.movz       s39, #11
    v.st.scatter.w [s43, v24], v12
    a.vread      v12, a8, s44
    s.addi       s43, s29, #44
    s.movz       s44, #12
    v.st.scatter.w [s45, v24], v12
    a.vread      v12, a8, s41
    s.addi       s41, s29, #48
    s.movz       s45, #13
    v.st.scatter.w [s46, v24], v12
    a.vread      v12, a8, s30
    s.addi       s30, s29, #52
    s.movz       s46, #14
    v.st.scatter.w [s47, v24], v12
    a.vread      v12, a8, s48
    s.addi       s47, s29, #56
    s.movz       s48, #15
    s.addi       s53, s29, #60
    v.st.scatter.w [s49, v24], v12
    a.vread      v12, a8, s40
    s.movz       s29, #0
    s.addi       s40, s14, #11264
    v.st.scatter.w [s50, v24], v12
    a.vread      v12, a8, s28
    s.movz       s28, #1
    s.addi       s49, s40, #4
    v.st.scatter.w [s51, v24], v12
    a.vread      v12, a8, s38
    s.movz       s38, #2
    s.addi       s50, s40, #8
    v.st.scatter.w [s27, v24], v12
    a.vread      v12, a8, s42
    s.movz       s27, #3
    s.addi       s42, s40, #12
    v.st.scatter.w [s26, v24], v12
    a.vread      v12, a8, s39
    s.movz       s26, #4
    s.addi       s39, s40, #16
    v.st.scatter.w [s43, v24], v12
    a.vread      v12, a8, s44
    s.movz       s43, #5
    s.addi       s44, s40, #20
    v.st.scatter.w [s41, v24], v12
    a.vread      v12, a8, s45
    s.movz       s41, #6
    s.addi       s45, s40, #24
    v.st.scatter.w [s30, v24], v12
    a.vread      v12, a8, s46
    s.movz       s30, #7
    s.addi       s46, s40, #28
    v.st.scatter.w [s47, v24], v12
    a.vread      v12, a8, s48
    s.movz       s47, #8
    s.addi       s48, s40, #32
    v.st.scatter.w [s53, v24], v12
    fence.acq_rel.device
    a.vread      v12, a9, s29
    s.movz       s29, #9
    s.addi       s51, s40, #36
    v.st.scatter.w [s40, v24], v12
    a.vread      v12, a9, s28
    s.movz       s28, #10
    v.st.scatter.w [s49, v24], v12
    a.vread      v12, a9, s38
    s.addi       s38, s40, #40
    s.movz       s49, #11
    v.st.scatter.w [s50, v24], v12
    a.vread      v12, a9, s27
    s.addi       s27, s40, #44
    s.movz       s50, #12
    v.st.scatter.w [s42, v24], v12
    a.vread      v12, a9, s26
    s.addi       s26, s40, #48
    s.movz       s42, #13
    v.st.scatter.w [s39, v24], v12
    a.vread      v12, a9, s43
    s.addi       s39, s40, #52
    s.movz       s43, #14
    v.st.scatter.w [s44, v24], v12
    a.vread      v12, a9, s41
    s.addi       s41, s40, #56
    s.movz       s44, #15
    s.addi       s53, s40, #60
    v.st.scatter.w [s45, v24], v12
    a.vread      v12, a9, s30
    s.movz       s30, #0
    s.addi       s40, s14, #12288
    v.st.scatter.w [s46, v24], v12
    a.vread      v12, a9, s47
    s.movz       s45, #1
    s.addi       s46, s40, #4
    v.st.scatter.w [s48, v24], v12
    a.vread      v12, a9, s29
    s.movz       s29, #2
    s.addi       s47, s40, #8
    v.st.scatter.w [s51, v24], v12
    a.vread      v12, a9, s28
    s.movz       s28, #3
    s.addi       s48, s40, #12
    v.st.scatter.w [s38, v24], v12
    a.vread      v12, a9, s49
    s.movz       s38, #4
    s.addi       s49, s40, #16
    v.st.scatter.w [s27, v24], v12
    a.vread      v12, a9, s50
    s.movz       s27, #5
    s.addi       s50, s40, #20
    v.st.scatter.w [s26, v24], v12
    a.vread      v12, a9, s42
    s.movz       s26, #6
    s.addi       s42, s40, #24
    v.st.scatter.w [s39, v24], v12
    a.vread      v12, a9, s43
    s.movz       s39, #7
    s.addi       s43, s40, #28
    v.st.scatter.w [s41, v24], v12
    a.vread      v12, a9, s44
    s.movz       s41, #8
    s.addi       s44, s40, #32
    v.st.scatter.w [s53, v24], v12
    fence.acq_rel.device
    a.vread      v12, a10, s30
    s.movz       s30, #9
    s.addi       s51, s40, #36
    v.st.scatter.w [s40, v24], v12
    a.vread      v12, a10, s45
    s.movz       s45, #10
    v.st.scatter.w [s46, v24], v12
    a.vread      v12, a10, s29
    s.addi       s29, s40, #40
    s.movz       s46, #11
    v.st.scatter.w [s47, v24], v12
    a.vread      v12, a10, s28
    s.addi       s28, s40, #44
    s.movz       s47, #12
    v.st.scatter.w [s48, v24], v12
    a.vread      v12, a10, s38
    s.addi       s38, s40, #48
    s.movz       s48, #13
    v.st.scatter.w [s49, v24], v12
    a.vread      v12, a10, s27
    s.addi       s27, s40, #52
    s.movz       s49, #14
    v.st.scatter.w [s50, v24], v12
    a.vread      v12, a10, s26
    s.addi       s26, s40, #56
    s.movz       s50, #15
    s.addi       s53, s40, #60
    v.st.scatter.w [s42, v24], v12
    a.vread      v12, a10, s39
    s.movz       s39, #0
    s.addi       s40, s14, #13312
    v.st.scatter.w [s43, v24], v12
    a.vread      v12, a10, s41
    s.movz       s41, #1
    s.addi       s42, s40, #4
    v.st.scatter.w [s44, v24], v12
    a.vread      v12, a10, s30
    s.movz       s30, #2
    s.addi       s43, s40, #8
    v.st.scatter.w [s51, v24], v12
    a.vread      v12, a10, s45
    s.movz       s44, #3
    s.addi       s45, s40, #12
    v.st.scatter.w [s29, v24], v12
    a.vread      v12, a10, s46
    s.movz       s29, #4
    s.addi       s46, s40, #16
    v.st.scatter.w [s28, v24], v12
    a.vread      v12, a10, s47
    s.movz       s28, #5
    s.addi       s47, s40, #20
    v.st.scatter.w [s38, v24], v12
    a.vread      v12, a10, s48
    s.movz       s38, #6
    s.addi       s48, s40, #24
    v.st.scatter.w [s27, v24], v12
    a.vread      v12, a10, s49
    s.movz       s27, #7
    s.addi       s49, s40, #28
    v.st.scatter.w [s26, v24], v12
    a.vread      v12, a10, s50
    s.movz       s26, #8
    s.addi       s50, s40, #32
    v.st.scatter.w [s53, v24], v12
    fence.acq_rel.device
    a.vread      v12, a11, s39
    s.movz       s39, #9
    s.addi       s51, s40, #36
    v.st.scatter.w [s40, v24], v12
    a.vread      v12, a11, s41
    s.movz       s41, #10
    v.st.scatter.w [s42, v24], v12
    a.vread      v12, a11, s30
    s.addi       s30, s40, #40
    s.movz       s42, #11
    v.st.scatter.w [s43, v24], v12
    a.vread      v12, a11, s44
    s.addi       s43, s40, #44
    s.movz       s44, #12
    v.st.scatter.w [s45, v24], v12
    a.vread      v12, a11, s29
    s.addi       s29, s40, #48
    s.movz       s45, #13
    v.st.scatter.w [s46, v24], v12
    a.vread      v12, a11, s28
    s.addi       s28, s40, #52
    s.movz       s46, #14
    v.st.scatter.w [s47, v24], v12
    a.vread      v12, a11, s38
    s.addi       s38, s40, #56
    s.movz       s47, #15
    s.addi       s53, s40, #60
    v.st.scatter.w [s48, v24], v12
    a.vread      v12, a11, s27
    s.movz       s27, #0
    s.addi       s40, s14, #14336
    v.st.scatter.w [s49, v24], v12
    a.vread      v12, a11, s26
    s.movz       s26, #1
    s.addi       s48, s40, #4
    v.st.scatter.w [s50, v24], v12
    a.vread      v12, a11, s39
    s.movz       s39, #2
    s.addi       s49, s40, #8
    v.st.scatter.w [s51, v24], v12
    a.vread      v12, a11, s41
    s.movz       s41, #3
    s.addi       s50, s40, #12
    v.st.scatter.w [s30, v24], v12
    a.vread      v12, a11, s42
    s.movz       s30, #4
    s.addi       s42, s40, #16
    v.st.scatter.w [s43, v24], v12
    a.vread      v12, a11, s44
    s.movz       s43, #5
    s.addi       s44, s40, #20
    v.st.scatter.w [s29, v24], v12
    a.vread      v12, a11, s45
    s.movz       s29, #6
    s.addi       s45, s40, #24
    v.st.scatter.w [s28, v24], v12
    a.vread      v12, a11, s46
    s.movz       s28, #7
    s.addi       s46, s40, #28
    v.st.scatter.w [s38, v24], v12
    a.vread      v12, a11, s47
    s.movz       s38, #8
    s.addi       s47, s40, #32
    v.st.scatter.w [s53, v24], v12
    fence.acq_rel.device
    a.vread      v12, a12, s27
    s.movz       s27, #9
    s.addi       s51, s40, #36
    v.st.scatter.w [s40, v24], v12
    a.vread      v12, a12, s26
    s.movz       s26, #10
    v.st.scatter.w [s48, v24], v12
    a.vread      v12, a12, s39
    s.addi       s39, s40, #40
    s.movz       s48, #11
    v.st.scatter.w [s49, v24], v12
    a.vread      v12, a12, s41
    s.addi       s41, s40, #44
    s.movz       s49, #12
    v.st.scatter.w [s50, v24], v12
    a.vread      v12, a12, s30
    s.addi       s30, s40, #48
    s.movz       s50, #13
    v.st.scatter.w [s42, v24], v12
    a.vread      v12, a12, s43
    s.addi       s42, s40, #52
    s.movz       s43, #14
    v.st.scatter.w [s44, v24], v12
    a.vread      v12, a12, s29
    s.addi       s29, s40, #56
    s.movz       s44, #15
    s.addi       s53, s40, #60
    v.st.scatter.w [s45, v24], v12
    a.vread      v12, a12, s28
    s.movz       s28, #0
    s.addi       s40, s14, #15360
    v.st.scatter.w [s46, v24], v12
    a.vread      v12, a12, s38
    s.movz       s38, #1
    s.addi       s45, s40, #4
    v.st.scatter.w [s47, v24], v12
    a.vread      v12, a12, s27
    s.movz       s27, #2
    s.addi       s46, s40, #8
    v.st.scatter.w [s51, v24], v12
    a.vread      v12, a12, s26
    s.movz       s26, #3
    s.addi       s47, s40, #12
    v.st.scatter.w [s39, v24], v12
    a.vread      v12, a12, s48
    s.movz       s39, #4
    s.addi       s48, s40, #16
    v.st.scatter.w [s41, v24], v12
    a.vread      v12, a12, s49
    s.movz       s41, #5
    s.addi       s49, s40, #20
    v.st.scatter.w [s30, v24], v12
    a.vread      v12, a12, s50
    s.movz       s30, #6
    s.addi       s50, s40, #24
    v.st.scatter.w [s42, v24], v12
    a.vread      v12, a12, s43
    s.movz       s42, #7
    s.addi       s43, s40, #28
    v.st.scatter.w [s29, v24], v12
    a.vread      v12, a12, s44
    s.movz       s29, #8
    s.addi       s44, s40, #32
    v.st.scatter.w [s53, v24], v12
    fence.acq_rel.device
    a.vread      v12, a13, s28
    s.movz       s28, #9
    s.addi       s51, s40, #36
    v.st.scatter.w [s40, v24], v12
    a.vread      v12, a13, s38
    s.movz       s38, #10
    v.st.scatter.w [s45, v24], v12
    a.vread      v12, a13, s27
    s.addi       s27, s40, #40
    s.movz       s45, #11
    v.st.scatter.w [s46, v24], v12
    a.vread      v12, a13, s26
    s.addi       s26, s40, #44
    s.movz       s46, #12
    v.st.scatter.w [s47, v24], v12
    a.vread      v12, a13, s39
    s.addi       s39, s40, #48
    s.movz       s47, #13
    v.st.scatter.w [s48, v24], v12
    a.vread      v12, a13, s41
    s.addi       s41, s40, #52
    s.movz       s48, #14
    v.st.scatter.w [s49, v24], v12
    a.vread      v12, a13, s30
    s.addi       s30, s40, #56
    s.movz       s49, #15
    s.addi       s53, s40, #60
    v.st.scatter.w [s50, v24], v12
    a.vread      v12, a13, s42
    s.movz       s40, #0
    s.addi       s42, s14, #16384
    v.st.scatter.w [s43, v24], v12
    a.vread      v12, a13, s29
    s.movz       s29, #1
    s.addi       s43, s42, #4
    v.st.scatter.w [s44, v24], v12
    a.vread      v12, a13, s28
    s.movz       s28, #2
    s.addi       s44, s42, #8
    v.st.scatter.w [s51, v24], v12
    a.vread      v12, a13, s38
    s.movz       s38, #3
    s.addi       s50, s42, #12
    v.st.scatter.w [s27, v24], v12
    a.vread      v12, a13, s45
    s.movz       s27, #4
    s.addi       s45, s42, #16
    v.st.scatter.w [s26, v24], v12
    a.vread      v12, a13, s46
    s.movz       s26, #5
    s.addi       s46, s42, #20
    v.st.scatter.w [s39, v24], v12
    a.vread      v12, a13, s47
    s.movz       s39, #6
    s.addi       s47, s42, #24
    v.st.scatter.w [s41, v24], v12
    a.vread      v12, a13, s48
    s.movz       s41, #7
    s.addi       s48, s42, #28
    v.st.scatter.w [s30, v24], v12
    a.vread      v12, a13, s49
    s.movz       s30, #8
    s.addi       s49, s42, #32
    v.st.scatter.w [s53, v24], v12
    fence.acq_rel.device
    a.vread      v12, a14, s40
    s.movz       s40, #9
    s.addi       s51, s42, #36
    v.st.scatter.w [s42, v24], v12
    a.vread      v12, a14, s29
    s.movz       s29, #10
    v.st.scatter.w [s43, v24], v12
    a.vread      v12, a14, s28
    s.addi       s28, s42, #40
    s.movz       s43, #11
    v.st.scatter.w [s44, v24], v12
    a.vread      v12, a14, s38
    s.addi       s38, s42, #44
    s.movz       s44, #12
    v.st.scatter.w [s50, v24], v12
    a.vread      v12, a14, s27
    s.addi       s27, s42, #48
    s.movz       s50, #13
    v.st.scatter.w [s45, v24], v12
    a.vread      v12, a14, s26
    s.addi       s26, s42, #52
    s.movz       s45, #14
    v.st.scatter.w [s46, v24], v12
    a.vread      v12, a14, s39
    s.addi       s39, s42, #56
    s.movz       s46, #15
    s.addi       s53, s42, #60
    v.st.scatter.w [s47, v24], v12
    a.vread      v12, a14, s41
    s.movz       s41, #0
    s.addi       s42, s14, #17408
    v.st.scatter.w [s48, v24], v12
    a.vread      v12, a14, s30
    s.movz       s30, #1
    s.addi       s47, s42, #4
    v.st.scatter.w [s49, v24], v12
    a.vread      v12, a14, s40
    s.movz       s40, #2
    s.addi       s48, s42, #8
    v.st.scatter.w [s51, v24], v12
    a.vread      v12, a14, s29
    s.movz       s29, #3
    s.addi       s49, s42, #12
    v.st.scatter.w [s28, v24], v12
    a.vread      v12, a14, s43
    s.movz       s28, #4
    s.addi       s43, s42, #16
    v.st.scatter.w [s38, v24], v12
    a.vread      v12, a14, s44
    s.movz       s38, #5
    s.addi       s44, s42, #20
    v.st.scatter.w [s27, v24], v12
    a.vread      v12, a14, s50
    s.movz       s27, #6
    s.addi       s50, s42, #24
    v.st.scatter.w [s26, v24], v12
    a.vread      v12, a14, s45
    s.movz       s26, #7
    s.addi       s45, s42, #28
    v.st.scatter.w [s39, v24], v12
    a.vread      v12, a14, s46
    s.movz       s39, #8
    s.addi       s46, s42, #32
    v.st.scatter.w [s53, v24], v12
    fence.acq_rel.device
    a.vread      v12, a15, s41
    s.movz       s41, #9
    s.addi       s51, s42, #36
    v.st.scatter.w [s42, v24], v12
    a.vread      v12, a15, s30
    s.movz       s30, #10
    v.st.scatter.w [s47, v24], v12
    a.vread      v12, a15, s40
    s.addi       s40, s42, #40
    s.movz       s47, #11
    v.st.scatter.w [s48, v24], v12
    a.vread      v12, a15, s29
    s.addi       s29, s42, #44
    s.movz       s48, #12
    v.st.scatter.w [s49, v24], v12
    a.vread      v12, a15, s28
    s.addi       s28, s42, #48
    s.movz       s49, #13
    v.st.scatter.w [s43, v24], v12
    a.vread      v12, a15, s38
    s.addi       s38, s42, #52
    s.movz       s43, #14
    v.st.scatter.w [s44, v24], v12
    a.vread      v12, a15, s27
    s.addi       s27, s42, #56
    s.movz       s44, #15
    s.addi       s53, s42, #60
    v.st.scatter.w [s50, v24], v12
    a.vread      v12, a15, s26
    s.movz       s26, #0
    s.addi       s42, s14, #10240
    v.st.scatter.w [s45, v24], v12
    a.vread      v12, a15, s39
    v.extract    s39, v23, #0
    s.addi       s45, s14, #18432
    v.splat      v14, s39
    s.movz       s39, #1
    v.st.scatter.w [s46, v24], v12
    a.vread      v12, a15, s41
    s.addi       s41, s14, #10304
    v.extract    s46, v23, #1
    v.splat      v15, s46
    s.addi       s46, s45, #64
    v.st.scatter.w [s51, v24], v12
    a.vread      v12, a15, s30
    s.movz       s30, #2
    s.addi       s50, s14, #10368
    v.st.scatter.w [s40, v24], v12
    a.vread      v12, a15, s47
    v.extract    s40, v23, #2
    s.addi       s47, s45, #128
    v.splat      v17, s40
    v.st.scatter.w [s29, v24], v12
    a.vread      v12, a15, s48
    s.addi       s29, s45, #192
    v.st.scatter.w [s28, v24], v12
    a.vread      v12, a15, s49
    s.movz       s28, #3
    s.addi       s40, s14, #10432
    v.st.scatter.w [s38, v24], v12
    a.vread      v12, a15, s43
    v.extract    s38, v23, #3
    v.splat      v21, s38
    v.st.scatter.w [s27, v24], v12
    a.vread      v12, a15, s44
    s.movz       s27, #4
    s.addi       s38, s45, #256
    v.st.scatter.w [s53, v24], v12
    fence.acq_rel.device
    a.vread      v12, a0, s26
    s.addi       s26, s14, #10496
    v.extract    s43, v23, #4
    v.splat      v22, s43
    v.ld.w       v24, [s42, #0]
    vf.mul       v28, v24, v14
    s.addi       s42, s45, #320
    vf.mul       v14, v28, v19
    s.movz       s43, #5
    vf.add       v24, v12, v14
    v.st.w       [s45, #0], v24
    a.vread      v12, a0, s39
    s.addi       s39, s14, #10560
    v.extract    s44, v23, #5
    v.splat      v14, s44
    v.ld.w       v24, [s41, #0]
    vf.mul       v28, v24, v15
    s.addi       s41, s45, #384
    vf.mul       v15, v28, v19
    s.movz       s44, #6
    vf.add       v24, v12, v15
    v.st.w       [s46, #0], v24
    a.vread      v12, a0, s30
    s.addi       s30, s14, #10624
    v.extract    s46, v23, #6
    v.splat      v15, s46
    v.ld.w       v24, [s50, #0]
    vf.mul       v28, v24, v17
    s.addi       s46, s45, #448
    vf.mul       v17, v28, v19
    s.movz       s48, #7
    vf.add       v24, v12, v17
    v.st.w       [s47, #0], v24
    a.vread      v12, a0, s28
    s.addi       s28, s14, #10688
    v.extract    s47, v23, #7
    v.splat      v17, s47
    v.ld.w       v24, [s40, #0]
    vf.mul       v28, v24, v21
    s.addi       s40, s45, #512
    vf.mul       v21, v28, v19
    s.movz       s47, #8
    vf.add       v24, v12, v21
    v.st.w       [s29, #0], v24
    a.vread      v12, a0, s27
    s.addi       s27, s14, #10752
    v.extract    s29, v23, #8
    v.splat      v21, s29
    v.ld.w       v24, [s26, #0]
    vf.mul       v28, v24, v22
    s.addi       s26, s45, #576
    vf.mul       v22, v28, v19
    s.movz       s29, #9
    vf.add       v24, v12, v22
    v.st.w       [s38, #0], v24
    a.vread      v12, a0, s43
    s.addi       s38, s14, #10816
    v.extract    s43, v23, #9
    v.splat      v22, s43
    v.ld.w       v24, [s39, #0]
    vf.mul       v28, v24, v14
    s.addi       s39, s45, #640
    vf.mul       v14, v28, v19
    s.movz       s43, #10
    vf.add       v24, v12, v14
    v.st.w       [s42, #0], v24
    a.vread      v12, a0, s44
    s.addi       s42, s14, #10880
    v.extract    s44, v23, #10
    v.splat      v14, s44
    v.ld.w       v24, [s30, #0]
    vf.mul       v28, v24, v15
    s.addi       s30, s45, #704
    vf.mul       v15, v28, v19
    s.movz       s44, #11
    vf.add       v24, v12, v15
    v.st.w       [s41, #0], v24
    a.vread      v12, a0, s48
    s.addi       s41, s14, #10944
    v.extract    s48, v23, #11
    v.splat      v15, s48
    v.ld.w       v24, [s28, #0]
    vf.mul       v28, v24, v17
    s.addi       s28, s45, #768
    vf.mul       v17, v28, v19
    s.movz       s48, #12
    vf.add       v24, v12, v17
    v.st.w       [s46, #0], v24
    a.vread      v12, a0, s47
    s.addi       s46, s14, #11008
    v.extract    s47, v23, #12
    v.splat      v17, s47
    v.ld.w       v24, [s27, #0]
    vf.mul       v28, v24, v21
    s.addi       s27, s45, #832
    vf.mul       v21, v28, v19
    s.movz       s47, #13
    vf.add       v24, v12, v21
    v.st.w       [s40, #0], v24
    a.vread      v12, a0, s29
    s.addi       s29, s14, #11072
    v.extract    s40, v23, #13
    v.splat      v21, s40
    v.ld.w       v24, [s38, #0]
    vf.mul       v28, v24, v22
    s.addi       s38, s45, #896
    vf.mul       v22, v28, v19
    s.movz       s40, #14
    vf.add       v24, v12, v22
    v.st.w       [s26, #0], v24
    a.vread      v12, a0, s43
    s.addi       s26, s14, #11136
    v.extract    s43, v23, #14
    v.splat      v22, s43
    v.ld.w       v24, [s42, #0]
    vf.mul       v28, v24, v14
    s.addi       s42, s45, #960
    vf.mul       v14, v28, v19
    s.movz       s43, #15
    vf.add       v24, v12, v14
    v.st.w       [s39, #0], v24
    a.vread      v12, a0, s44
    s.addi       s39, s14, #11200
    v.extract    s44, v23, #15
    v.splat      v14, s44
    v.ld.w       v24, [s41, #0]
    vf.mul       v28, v24, v15
    vf.mul       v15, v28, v19
    s.addi       s41, s14, #19456
    vf.add       v24, v12, v15
    s.movz       s44, #0
    v.st.w       [s30, #0], v24
    a.vread      v12, a0, s48
    s.addi       s30, s14, #11264
    v.extract    s45, v23, #0
    v.splat      v15, s45
    v.ld.w       v24, [s46, #0]
    vf.mul       v28, v24, v17
    vf.mul       v17, v28, v19
    s.addi       s45, s41, #64
    vf.add       v24, v12, v17
    s.movz       s46, #1
    v.st.w       [s28, #0], v24
    a.vread      v12, a0, s47
    s.addi       s28, s14, #11328
    v.extract    s47, v23, #1
    v.splat      v17, s47
    v.ld.w       v24, [s29, #0]
    vf.mul       v28, v24, v21
    vf.mul       v21, v28, v19
    s.addi       s29, s41, #128
    vf.add       v24, v12, v21
    s.movz       s47, #2
    v.st.w       [s27, #0], v24
    a.vread      v12, a0, s40
    s.addi       s27, s14, #11392
    v.extract    s40, v23, #2
    v.splat      v21, s40
    v.ld.w       v24, [s26, #0]
    vf.mul       v28, v24, v22
    vf.mul       v22, v28, v19
    s.addi       s26, s41, #192
    vf.add       v24, v12, v22
    s.movz       s40, #3
    v.st.w       [s38, #0], v24
    a.vread      v12, a0, s43
    s.addi       s38, s14, #11456
    v.extract    s43, v23, #3
    v.splat      v22, s43
    v.ld.w       v24, [s39, #0]
    vf.mul       v28, v24, v14
    vf.mul       v14, v28, v19
    s.addi       s39, s41, #256
    vf.add       v19, v12, v14
    s.movz       s43, #4
    v.st.w       [s42, #0], v19
    fence.acq_rel.device
    a.vread      v12, a1, s44
    s.addi       s42, s14, #11520
    v.extract    s44, v23, #4
    v.splat      v14, s44
    v.ld.w       v19, [s30, #0]
    vf.mul       v24, v19, v15
    s.addi       s30, s41, #320
    vf.mul       v15, v24, v26
    s.movz       s44, #5
    vf.add       v19, v12, v15
    v.st.w       [s41, #0], v19
    a.vread      v12, a1, s46
    s.addi       s46, s14, #11584
    v.extract    s48, v23, #5
    v.splat      v15, s48
    v.ld.w       v19, [s28, #0]
    vf.mul       v24, v19, v17
    s.addi       s28, s41, #384
    vf.mul       v17, v24, v26
    s.movz       s48, #6
    vf.add       v19, v12, v17
    v.st.w       [s45, #0], v19
    a.vread      v12, a1, s47
    s.addi       s45, s14, #11648
    v.extract    s47, v23, #6
    v.splat      v17, s47
    v.ld.w       v19, [s27, #0]
    vf.mul       v24, v19, v21
    s.addi       s27, s41, #448
    vf.mul       v19, v24, v26
    s.movz       s47, #7
    vf.add       v21, v12, v19
    v.st.w       [s29, #0], v21
    a.vread      v12, a1, s40
    s.addi       s29, s14, #11712
    v.extract    s40, v23, #7
    v.splat      v19, s40
    v.ld.w       v21, [s38, #0]
    vf.mul       v24, v21, v22
    s.addi       s38, s41, #512
    vf.mul       v21, v24, v26
    s.movz       s40, #8
    vf.add       v22, v12, v21
    v.st.w       [s26, #0], v22
    a.vread      v12, a1, s43
    s.addi       s26, s14, #11776
    v.extract    s43, v23, #8
    v.splat      v21, s43
    v.ld.w       v22, [s42, #0]
    vf.mul       v24, v22, v14
    s.addi       s42, s41, #576
    vf.mul       v14, v24, v26
    s.movz       s43, #9
    vf.add       v22, v12, v14
    v.st.w       [s39, #0], v22
    a.vread      v12, a1, s44
    s.addi       s39, s14, #11840
    v.extract    s44, v23, #9
    v.splat      v14, s44
    v.ld.w       v22, [s46, #0]
    vf.mul       v24, v22, v15
    s.addi       s44, s41, #640
    vf.mul       v15, v24, v26
    s.movz       s46, #10
    vf.add       v22, v12, v15
    v.st.w       [s30, #0], v22
    a.vread      v12, a1, s48
    s.addi       s30, s14, #11904
    v.extract    s48, v23, #10
    v.splat      v15, s48
    v.ld.w       v22, [s45, #0]
    vf.mul       v24, v22, v17
    s.addi       s45, s41, #704
    vf.mul       v17, v24, v26
    s.movz       s48, #11
    vf.add       v22, v12, v17
    v.st.w       [s28, #0], v22
    a.vread      v12, a1, s47
    s.addi       s28, s14, #11968
    v.extract    s47, v23, #11
    v.splat      v17, s47
    v.ld.w       v22, [s29, #0]
    vf.mul       v24, v22, v19
    s.addi       s29, s41, #768
    vf.mul       v19, v24, v26
    s.movz       s47, #12
    vf.add       v22, v12, v19
    v.st.w       [s27, #0], v22
    a.vread      v12, a1, s40
    s.addi       s27, s14, #12032
    v.extract    s40, v23, #12
    v.splat      v19, s40
    v.ld.w       v22, [s26, #0]
    vf.mul       v24, v22, v21
    s.addi       s26, s41, #832
    vf.mul       v21, v24, v26
    s.movz       s40, #13
    vf.add       v22, v12, v21
    v.st.w       [s38, #0], v22
    a.vread      v12, a1, s43
    s.addi       s38, s14, #12096
    v.extract    s43, v23, #13
    v.splat      v21, s43
    v.ld.w       v22, [s39, #0]
    vf.mul       v24, v22, v14
    s.addi       s39, s41, #896
    vf.mul       v14, v24, v26
    s.movz       s43, #14
    vf.add       v22, v12, v14
    v.st.w       [s42, #0], v22
    a.vread      v12, a1, s46
    s.addi       s42, s14, #12160
    v.extract    s46, v23, #14
    v.splat      v14, s46
    v.ld.w       v22, [s30, #0]
    vf.mul       v24, v22, v15
    s.addi       s30, s41, #960
    vf.mul       v15, v24, v26
    s.movz       s41, #15
    vf.add       v22, v12, v15
    v.st.w       [s44, #0], v22
    a.vread      v12, a1, s48
    s.addi       s44, s14, #12224
    v.extract    s46, v23, #15
    v.splat      v15, s46
    v.ld.w       v22, [s28, #0]
    vf.mul       v24, v22, v17
    vf.mul       v17, v24, v26
    s.addi       s28, s14, #20480
    vf.add       v22, v12, v17
    s.movz       s46, #0
    v.st.w       [s45, #0], v22
    a.vread      v12, a1, s47
    s.addi       s45, s14, #12288
    v.extract    s47, v23, #0
    v.splat      v17, s47
    v.ld.w       v22, [s27, #0]
    vf.mul       v24, v22, v19
    vf.mul       v19, v24, v26
    s.addi       s27, s28, #64
    vf.add       v22, v12, v19
    s.movz       s47, #1
    v.st.w       [s29, #0], v22
    a.vread      v12, a1, s40
    s.addi       s29, s14, #12352
    v.extract    s40, v23, #1
    v.splat      v19, s40
    v.ld.w       v22, [s38, #0]
    vf.mul       v24, v22, v21
    vf.mul       v21, v24, v26
    s.addi       s38, s28, #128
    vf.add       v22, v12, v21
    s.movz       s40, #2
    v.st.w       [s26, #0], v22
    a.vread      v12, a1, s43
    s.addi       s26, s14, #12416
    v.extract    s43, v23, #2
    v.splat      v21, s43
    v.ld.w       v22, [s42, #0]
    vf.mul       v24, v22, v14
    vf.mul       v14, v24, v26
    s.addi       s42, s28, #192
    vf.add       v22, v12, v14
    s.movz       s43, #3
    v.st.w       [s39, #0], v22
    a.vread      v12, a1, s41
    s.addi       s39, s14, #12480
    v.extract    s41, v23, #3
    v.splat      v14, s41
    v.ld.w       v22, [s44, #0]
    vf.mul       v24, v22, v15
    vf.mul       v15, v24, v26
    s.addi       s41, s28, #256
    vf.add       v22, v12, v15
    s.movz       s44, #4
    v.st.w       [s30, #0], v22
    fence.acq_rel.device
    a.vread      v12, a2, s46
    s.addi       s30, s14, #12544
    v.extract    s46, v23, #4
    v.splat      v15, s46
    v.ld.w       v22, [s45, #0]
    vf.mul       v24, v22, v17
    s.addi       s45, s28, #320
    vf.mul       v17, v24, v25
    s.movz       s46, #5
    vf.add       v22, v12, v17
    v.st.w       [s28, #0], v22
    a.vread      v12, a2, s47
    s.addi       s47, s14, #12608
    v.extract    s48, v23, #5
    v.splat      v17, s48
    v.ld.w       v22, [s29, #0]
    vf.mul       v24, v22, v19
    s.addi       s29, s28, #384
    vf.mul       v19, v24, v25
    s.movz       s48, #6
    vf.add       v22, v12, v19
    v.st.w       [s27, #0], v22
    a.vread      v12, a2, s40
    s.addi       s27, s14, #12672
    v.extract    s40, v23, #6
    v.splat      v19, s40
    v.ld.w       v22, [s26, #0]
    vf.mul       v24, v22, v21
    s.addi       s26, s28, #448
    vf.mul       v21, v24, v25
    s.movz       s40, #7
    vf.add       v22, v12, v21
    v.st.w       [s38, #0], v22
    a.vread      v12, a2, s43
    s.addi       s38, s14, #12736
    v.extract    s43, v23, #7
    v.splat      v21, s43
    v.ld.w       v22, [s39, #0]
    vf.mul       v24, v22, v14
    s.addi       s39, s28, #512
    vf.mul       v14, v24, v25
    s.movz       s43, #8
    vf.add       v22, v12, v14
    v.st.w       [s42, #0], v22
    a.vread      v12, a2, s44
    s.addi       s42, s14, #12800
    v.extract    s44, v23, #8
    v.splat      v14, s44
    v.ld.w       v22, [s30, #0]
    vf.mul       v24, v22, v15
    s.addi       s30, s28, #576
    vf.mul       v15, v24, v25
    s.movz       s44, #9
    vf.add       v22, v12, v15
    v.st.w       [s41, #0], v22
    a.vread      v12, a2, s46
    s.addi       s41, s14, #12864
    v.extract    s46, v23, #9
    v.splat      v15, s46
    v.ld.w       v22, [s47, #0]
    vf.mul       v24, v22, v17
    s.addi       s46, s28, #640
    vf.mul       v17, v24, v25
    s.movz       s47, #10
    vf.add       v22, v12, v17
    v.st.w       [s45, #0], v22
    a.vread      v12, a2, s48
    s.addi       s45, s14, #12928
    v.extract    s48, v23, #10
    v.splat      v17, s48
    v.ld.w       v22, [s27, #0]
    vf.mul       v24, v22, v19
    s.addi       s27, s28, #704
    vf.mul       v19, v24, v25
    s.movz       s48, #11
    vf.add       v22, v12, v19
    v.st.w       [s29, #0], v22
    a.vread      v12, a2, s40
    s.addi       s29, s14, #12992
    v.extract    s40, v23, #11
    v.splat      v19, s40
    v.ld.w       v22, [s38, #0]
    vf.mul       v24, v22, v21
    s.addi       s38, s28, #768
    vf.mul       v21, v24, v25
    s.movz       s40, #12
    vf.add       v22, v12, v21
    v.st.w       [s26, #0], v22
    a.vread      v12, a2, s43
    s.addi       s26, s14, #13056
    v.extract    s43, v23, #12
    v.splat      v21, s43
    v.ld.w       v22, [s42, #0]
    vf.mul       v24, v22, v14
    s.addi       s42, s28, #832
    vf.mul       v14, v24, v25
    s.movz       s43, #13
    vf.add       v22, v12, v14
    v.st.w       [s39, #0], v22
    a.vread      v12, a2, s44
    s.addi       s39, s14, #13120
    v.extract    s44, v23, #13
    v.splat      v14, s44
    v.ld.w       v22, [s41, #0]
    vf.mul       v24, v22, v15
    s.addi       s41, s28, #896
    vf.mul       v15, v24, v25
    s.movz       s44, #14
    vf.add       v22, v12, v15
    v.st.w       [s30, #0], v22
    a.vread      v12, a2, s47
    s.addi       s30, s14, #13184
    v.extract    s47, v23, #14
    v.splat      v15, s47
    v.ld.w       v22, [s45, #0]
    vf.mul       v24, v22, v17
    s.addi       s45, s28, #960
    vf.mul       v17, v24, v25
    s.movz       s28, #15
    vf.add       v22, v12, v17
    v.st.w       [s46, #0], v22
    a.vread      v12, a2, s48
    s.addi       s46, s14, #13248
    v.extract    s47, v23, #15
    v.splat      v17, s47
    v.ld.w       v22, [s29, #0]
    vf.mul       v24, v22, v19
    vf.mul       v19, v24, v25
    s.addi       s29, s14, #21504
    vf.add       v22, v12, v19
    s.movz       s47, #0
    v.st.w       [s27, #0], v22
    a.vread      v12, a2, s40
    s.addi       s27, s14, #13312
    v.extract    s40, v23, #0
    v.splat      v19, s40
    v.ld.w       v22, [s26, #0]
    vf.mul       v24, v22, v21
    vf.mul       v21, v24, v25
    s.addi       s26, s29, #64
    vf.add       v22, v12, v21
    s.movz       s40, #1
    v.st.w       [s38, #0], v22
    a.vread      v12, a2, s43
    s.addi       s38, s14, #13376
    v.extract    s43, v23, #1
    v.splat      v21, s43
    v.ld.w       v22, [s39, #0]
    vf.mul       v24, v22, v14
    vf.mul       v14, v24, v25
    s.addi       s39, s29, #128
    vf.add       v22, v12, v14
    s.movz       s43, #2
    v.st.w       [s42, #0], v22
    a.vread      v12, a2, s44
    s.addi       s42, s14, #13440
    v.extract    s44, v23, #2
    v.splat      v14, s44
    v.ld.w       v22, [s30, #0]
    vf.mul       v24, v22, v15
    vf.mul       v15, v24, v25
    s.addi       s30, s29, #192
    vf.add       v22, v12, v15
    s.movz       s44, #3
    v.st.w       [s41, #0], v22
    a.vread      v12, a2, s28
    s.addi       s28, s14, #13504
    v.extract    s41, v23, #3
    v.splat      v15, s41
    v.ld.w       v22, [s46, #0]
    vf.mul       v24, v22, v17
    vf.mul       v17, v24, v25
    s.addi       s41, s29, #256
    vf.add       v22, v12, v17
    s.movz       s46, #4
    v.st.w       [s45, #0], v22
    fence.acq_rel.device
    a.vread      v12, a3, s47
    s.addi       s45, s14, #13568
    v.extract    s47, v23, #4
    v.splat      v17, s47
    v.ld.w       v22, [s27, #0]
    vf.mul       v24, v22, v19
    s.addi       s27, s29, #320
    vf.mul       v19, v24, v27
    s.movz       s47, #5
    vf.add       v22, v12, v19
    v.st.w       [s29, #0], v22
    a.vread      v12, a3, s40
    s.addi       s40, s14, #13632
    v.extract    s48, v23, #5
    v.splat      v19, s48
    v.ld.w       v22, [s38, #0]
    vf.mul       v24, v22, v21
    s.addi       s38, s29, #384
    vf.mul       v21, v24, v27
    s.movz       s48, #6
    vf.add       v22, v12, v21
    v.st.w       [s26, #0], v22
    a.vread      v12, a3, s43
    s.addi       s26, s14, #13696
    v.extract    s43, v23, #6
    v.splat      v21, s43
    v.ld.w       v22, [s42, #0]
    vf.mul       v24, v22, v14
    s.addi       s42, s29, #448
    vf.mul       v14, v24, v27
    s.movz       s43, #7
    vf.add       v22, v12, v14
    v.st.w       [s39, #0], v22
    a.vread      v12, a3, s44
    s.addi       s39, s14, #13760
    v.extract    s44, v23, #7
    v.splat      v14, s44
    v.ld.w       v22, [s28, #0]
    vf.mul       v24, v22, v15
    s.addi       s28, s29, #512
    vf.mul       v15, v24, v27
    s.movz       s44, #8
    vf.add       v22, v12, v15
    v.st.w       [s30, #0], v22
    a.vread      v12, a3, s46
    s.addi       s30, s14, #13824
    v.extract    s46, v23, #8
    v.splat      v15, s46
    v.ld.w       v22, [s45, #0]
    vf.mul       v24, v22, v17
    s.addi       s45, s29, #576
    vf.mul       v17, v24, v27
    s.movz       s46, #9
    vf.add       v22, v12, v17
    v.st.w       [s41, #0], v22
    a.vread      v12, a3, s47
    s.addi       s41, s14, #13888
    v.extract    s47, v23, #9
    v.splat      v17, s47
    v.ld.w       v22, [s40, #0]
    vf.mul       v24, v22, v19
    s.addi       s40, s29, #640
    vf.mul       v19, v24, v27
    s.movz       s47, #10
    vf.add       v22, v12, v19
    v.st.w       [s27, #0], v22
    a.vread      v12, a3, s48
    s.addi       s27, s14, #13952
    v.extract    s48, v23, #10
    v.splat      v19, s48
    v.ld.w       v22, [s26, #0]
    vf.mul       v24, v22, v21
    s.addi       s26, s29, #704
    vf.mul       v21, v24, v27
    s.movz       s48, #11
    vf.add       v22, v12, v21
    v.st.w       [s38, #0], v22
    a.vread      v12, a3, s43
    s.addi       s38, s14, #14016
    v.extract    s43, v23, #11
    v.splat      v21, s43
    v.ld.w       v22, [s39, #0]
    vf.mul       v24, v22, v14
    s.addi       s39, s29, #768
    vf.mul       v14, v24, v27
    s.movz       s43, #12
    vf.add       v22, v12, v14
    v.st.w       [s42, #0], v22
    a.vread      v12, a3, s44
    s.addi       s42, s14, #14080
    v.extract    s44, v23, #12
    v.splat      v14, s44
    v.ld.w       v22, [s30, #0]
    vf.mul       v24, v22, v15
    s.addi       s30, s29, #832
    vf.mul       v15, v24, v27
    s.movz       s44, #13
    vf.add       v22, v12, v15
    v.st.w       [s28, #0], v22
    a.vread      v12, a3, s46
    s.addi       s28, s14, #14144
    v.extract    s46, v23, #13
    v.splat      v15, s46
    v.ld.w       v22, [s41, #0]
    vf.mul       v24, v22, v17
    s.addi       s41, s29, #896
    vf.mul       v17, v24, v27
    s.movz       s46, #14
    vf.add       v22, v12, v17
    v.st.w       [s45, #0], v22
    a.vread      v12, a3, s47
    s.addi       s45, s14, #14208
    v.extract    s47, v23, #14
    v.splat      v17, s47
    v.ld.w       v22, [s27, #0]
    vf.mul       v24, v22, v19
    s.addi       s27, s29, #960
    vf.mul       v19, v24, v27
    s.movz       s29, #15
    vf.add       v22, v12, v19
    v.st.w       [s40, #0], v22
    a.vread      v12, a3, s48
    s.addi       s40, s14, #14272
    v.extract    s47, v23, #15
    v.splat      v19, s47
    v.ld.w       v22, [s38, #0]
    vf.mul       v24, v22, v21
    vf.mul       v21, v24, v27
    s.addi       s38, s14, #22528
    vf.add       v22, v12, v21
    s.movz       s47, #0
    v.st.w       [s26, #0], v22
    a.vread      v12, a3, s43
    s.addi       s26, s14, #14336
    v.extract    s43, v23, #0
    v.splat      v21, s43
    v.ld.w       v22, [s42, #0]
    vf.mul       v24, v22, v14
    vf.mul       v14, v24, v27
    s.addi       s42, s38, #64
    vf.add       v22, v12, v14
    s.movz       s43, #1
    v.st.w       [s39, #0], v22
    a.vread      v12, a3, s44
    s.addi       s39, s14, #14400
    v.extract    s44, v23, #1
    v.splat      v14, s44
    v.ld.w       v22, [s28, #0]
    vf.mul       v24, v22, v15
    vf.mul       v15, v24, v27
    s.addi       s28, s38, #128
    vf.add       v22, v12, v15
    s.movz       s44, #2
    v.st.w       [s30, #0], v22
    a.vread      v12, a3, s46
    s.addi       s30, s14, #14464
    v.extract    s46, v23, #2
    v.splat      v15, s46
    v.ld.w       v22, [s45, #0]
    vf.mul       v24, v22, v17
    vf.mul       v17, v24, v27
    s.addi       s45, s38, #192
    vf.add       v22, v12, v17
    s.movz       s46, #3
    v.st.w       [s41, #0], v22
    a.vread      v12, a3, s29
    s.addi       s29, s14, #14528
    v.extract    s41, v23, #3
    v.splat      v17, s41
    v.ld.w       v22, [s40, #0]
    vf.mul       v24, v22, v19
    vf.mul       v19, v24, v27
    s.addi       s40, s38, #256
    vf.add       v22, v12, v19
    s.movz       s41, #4
    v.st.w       [s27, #0], v22
    fence.acq_rel.device
    a.vread      v12, a4, s47
    s.addi       s27, s14, #14592
    v.extract    s47, v23, #4
    v.splat      v19, s47
    v.ld.w       v22, [s26, #0]
    vf.mul       v24, v22, v21
    s.addi       s26, s38, #320
    vf.mul       v21, v24, v36
    s.movz       s47, #5
    vf.add       v22, v12, v21
    v.st.w       [s38, #0], v22
    a.vread      v12, a4, s43
    s.addi       s43, s14, #14656
    v.extract    s48, v23, #5
    v.splat      v21, s48
    v.ld.w       v22, [s39, #0]
    vf.mul       v24, v22, v14
    s.addi       s39, s38, #384
    vf.mul       v14, v24, v36
    s.movz       s48, #6
    vf.add       v22, v12, v14
    v.st.w       [s42, #0], v22
    a.vread      v12, a4, s44
    s.addi       s42, s14, #14720
    v.extract    s44, v23, #6
    v.splat      v14, s44
    v.ld.w       v22, [s30, #0]
    vf.mul       v24, v22, v15
    s.addi       s30, s38, #448
    vf.mul       v15, v24, v36
    s.movz       s44, #7
    vf.add       v22, v12, v15
    v.st.w       [s28, #0], v22
    a.vread      v12, a4, s46
    s.addi       s28, s14, #14784
    v.extract    s46, v23, #7
    v.splat      v15, s46
    v.ld.w       v22, [s29, #0]
    vf.mul       v24, v22, v17
    s.addi       s29, s38, #512
    vf.mul       v17, v24, v36
    s.movz       s46, #8
    vf.add       v22, v12, v17
    v.st.w       [s45, #0], v22
    a.vread      v12, a4, s41
    s.addi       s41, s14, #14848
    v.extract    s45, v23, #8
    v.splat      v17, s45
    v.ld.w       v22, [s27, #0]
    vf.mul       v24, v22, v19
    s.addi       s27, s38, #576
    vf.mul       v19, v24, v36
    s.movz       s45, #9
    vf.add       v22, v12, v19
    v.st.w       [s40, #0], v22
    a.vread      v12, a4, s47
    s.addi       s40, s14, #14912
    v.extract    s47, v23, #9
    v.splat      v19, s47
    v.ld.w       v22, [s43, #0]
    vf.mul       v24, v22, v21
    s.addi       s43, s38, #640
    vf.mul       v21, v24, v36
    s.movz       s47, #10
    vf.add       v22, v12, v21
    v.st.w       [s26, #0], v22
    a.vread      v12, a4, s48
    s.addi       s26, s14, #14976
    v.extract    s48, v23, #10
    v.splat      v21, s48
    v.ld.w       v22, [s42, #0]
    vf.mul       v24, v22, v14
    s.addi       s42, s38, #704
    vf.mul       v14, v24, v36
    s.movz       s48, #11
    vf.add       v22, v12, v14
    v.st.w       [s39, #0], v22
    a.vread      v12, a4, s44
    s.addi       s39, s14, #15040
    v.extract    s44, v23, #11
    v.splat      v14, s44
    v.ld.w       v22, [s28, #0]
    vf.mul       v24, v22, v15
    s.addi       s28, s38, #768
    vf.mul       v15, v24, v36
    s.movz       s44, #12
    vf.add       v22, v12, v15
    v.st.w       [s30, #0], v22
    a.vread      v12, a4, s46
    s.addi       s30, s14, #15104
    v.extract    s46, v23, #12
    v.splat      v15, s46
    v.ld.w       v22, [s41, #0]
    vf.mul       v24, v22, v17
    s.addi       s41, s38, #832
    vf.mul       v17, v24, v36
    s.movz       s46, #13
    vf.add       v22, v12, v17
    v.st.w       [s29, #0], v22
    a.vread      v12, a4, s45
    s.addi       s29, s14, #15168
    v.extract    s45, v23, #13
    v.splat      v17, s45
    v.ld.w       v22, [s40, #0]
    vf.mul       v24, v22, v19
    s.addi       s40, s38, #896
    vf.mul       v19, v24, v36
    s.movz       s45, #14
    vf.add       v22, v12, v19
    v.st.w       [s27, #0], v22
    a.vread      v12, a4, s47
    s.addi       s27, s14, #15232
    v.extract    s47, v23, #14
    v.splat      v19, s47
    v.ld.w       v22, [s26, #0]
    vf.mul       v24, v22, v21
    s.addi       s26, s38, #960
    vf.mul       v21, v24, v36
    s.movz       s38, #15
    vf.add       v22, v12, v21
    v.st.w       [s43, #0], v22
    a.vread      v12, a4, s48
    s.addi       s43, s14, #15296
    v.extract    s47, v23, #15
    v.splat      v21, s47
    v.ld.w       v22, [s39, #0]
    vf.mul       v24, v22, v14
    vf.mul       v14, v24, v36
    s.addi       s39, s14, #23552
    vf.add       v22, v12, v14
    s.movz       s47, #0
    v.st.w       [s42, #0], v22
    a.vread      v12, a4, s44
    s.addi       s42, s14, #15360
    v.extract    s44, v23, #0
    v.splat      v14, s44
    v.ld.w       v22, [s30, #0]
    vf.mul       v24, v22, v15
    vf.mul       v15, v24, v36
    s.addi       s30, s39, #64
    vf.add       v22, v12, v15
    s.movz       s44, #1
    v.st.w       [s28, #0], v22
    a.vread      v12, a4, s46
    s.addi       s28, s14, #15424
    v.extract    s46, v23, #1
    v.splat      v15, s46
    v.ld.w       v22, [s29, #0]
    vf.mul       v24, v22, v17
    vf.mul       v17, v24, v36
    s.addi       s29, s39, #128
    vf.add       v22, v12, v17
    s.movz       s46, #2
    v.st.w       [s41, #0], v22
    a.vread      v12, a4, s45
    s.addi       s41, s14, #15488
    v.extract    s45, v23, #2
    v.splat      v17, s45
    v.ld.w       v22, [s27, #0]
    vf.mul       v24, v22, v19
    vf.mul       v19, v24, v36
    s.addi       s27, s39, #192
    vf.add       v22, v12, v19
    s.movz       s45, #3
    v.st.w       [s40, #0], v22
    a.vread      v12, a4, s38
    s.addi       s38, s14, #15552
    v.extract    s40, v23, #3
    v.splat      v19, s40
    v.ld.w       v22, [s43, #0]
    vf.mul       v24, v22, v21
    vf.mul       v21, v24, v36
    s.addi       s40, s39, #256
    vf.add       v22, v12, v21
    s.movz       s43, #4
    v.st.w       [s26, #0], v22
    fence.acq_rel.device
    a.vread      v12, a5, s47
    s.addi       s26, s14, #15616
    v.extract    s47, v23, #4
    v.splat      v21, s47
    v.ld.w       v22, [s42, #0]
    vf.mul       v24, v22, v14
    s.addi       s42, s39, #320
    vf.mul       v14, v24, v33
    s.movz       s47, #5
    vf.add       v22, v12, v14
    v.st.w       [s39, #0], v22
    a.vread      v12, a5, s44
    s.addi       s44, s14, #15680
    v.extract    s48, v23, #5
    v.splat      v14, s48
    v.ld.w       v22, [s28, #0]
    vf.mul       v24, v22, v15
    s.addi       s28, s39, #384
    vf.mul       v15, v24, v33
    s.movz       s48, #6
    vf.add       v22, v12, v15
    v.st.w       [s30, #0], v22
    a.vread      v12, a5, s46
    s.addi       s30, s14, #15744
    v.extract    s46, v23, #6
    v.splat      v15, s46
    v.ld.w       v22, [s41, #0]
    vf.mul       v24, v22, v17
    s.addi       s41, s39, #448
    vf.mul       v17, v24, v33
    s.movz       s46, #7
    vf.add       v22, v12, v17
    v.st.w       [s29, #0], v22
    a.vread      v12, a5, s45
    s.addi       s29, s14, #15808
    v.extract    s45, v23, #7
    v.splat      v17, s45
    v.ld.w       v22, [s38, #0]
    vf.mul       v24, v22, v19
    s.addi       s38, s39, #512
    vf.mul       v19, v24, v33
    s.movz       s45, #8
    vf.add       v22, v12, v19
    v.st.w       [s27, #0], v22
    a.vread      v12, a5, s43
    s.addi       s27, s14, #15872
    v.extract    s43, v23, #8
    v.splat      v19, s43
    v.ld.w       v22, [s26, #0]
    vf.mul       v24, v22, v21
    s.addi       s26, s39, #576
    vf.mul       v21, v24, v33
    s.movz       s43, #9
    vf.add       v22, v12, v21
    v.st.w       [s40, #0], v22
    a.vread      v12, a5, s47
    s.addi       s40, s14, #15936
    v.extract    s47, v23, #9
    v.splat      v21, s47
    v.ld.w       v22, [s44, #0]
    vf.mul       v24, v22, v14
    s.addi       s44, s39, #640
    vf.mul       v14, v24, v33
    s.movz       s47, #10
    vf.add       v22, v12, v14
    v.st.w       [s42, #0], v22
    a.vread      v12, a5, s48
    s.addi       s42, s14, #16000
    v.extract    s48, v23, #10
    v.splat      v14, s48
    v.ld.w       v22, [s30, #0]
    vf.mul       v24, v22, v15
    s.addi       s30, s39, #704
    vf.mul       v15, v24, v33
    s.movz       s48, #11
    vf.add       v22, v12, v15
    v.st.w       [s28, #0], v22
    a.vread      v12, a5, s46
    s.addi       s28, s14, #16064
    v.extract    s46, v23, #11
    v.splat      v15, s46
    v.ld.w       v22, [s29, #0]
    vf.mul       v24, v22, v17
    s.addi       s29, s39, #768
    vf.mul       v17, v24, v33
    s.movz       s46, #12
    vf.add       v22, v12, v17
    v.st.w       [s41, #0], v22
    a.vread      v12, a5, s45
    s.addi       s41, s14, #16128
    v.extract    s45, v23, #12
    v.splat      v17, s45
    v.ld.w       v22, [s27, #0]
    vf.mul       v24, v22, v19
    s.addi       s27, s39, #832
    vf.mul       v19, v24, v33
    s.movz       s45, #13
    vf.add       v22, v12, v19
    v.st.w       [s38, #0], v22
    a.vread      v12, a5, s43
    s.addi       s38, s14, #16192
    v.extract    s43, v23, #13
    v.splat      v19, s43
    v.ld.w       v22, [s40, #0]
    vf.mul       v24, v22, v21
    s.addi       s40, s39, #896
    vf.mul       v21, v24, v33
    s.movz       s43, #14
    vf.add       v22, v12, v21
    v.st.w       [s26, #0], v22
    a.vread      v12, a5, s47
    s.addi       s26, s14, #16256
    v.extract    s47, v23, #14
    v.splat      v21, s47
    v.ld.w       v22, [s42, #0]
    vf.mul       v24, v22, v14
    s.addi       s42, s39, #960
    vf.mul       v14, v24, v33
    s.movz       s39, #15
    vf.add       v22, v12, v14
    v.st.w       [s44, #0], v22
    a.vread      v12, a5, s48
    s.addi       s44, s14, #16320
    v.extract    s47, v23, #15
    v.splat      v14, s47
    v.ld.w       v22, [s28, #0]
    vf.mul       v24, v22, v15
    vf.mul       v15, v24, v33
    s.addi       s28, s14, #24576
    vf.add       v22, v12, v15
    s.movz       s47, #0
    v.st.w       [s30, #0], v22
    a.vread      v12, a5, s46
    s.addi       s30, s14, #16384
    v.extract    s46, v23, #0
    v.splat      v15, s46
    v.ld.w       v22, [s41, #0]
    vf.mul       v24, v22, v17
    vf.mul       v17, v24, v33
    s.addi       s41, s28, #64
    vf.add       v22, v12, v17
    s.movz       s46, #1
    v.st.w       [s29, #0], v22
    a.vread      v12, a5, s45
    s.addi       s29, s14, #16448
    v.extract    s45, v23, #1
    v.splat      v17, s45
    v.ld.w       v22, [s38, #0]
    vf.mul       v24, v22, v19
    vf.mul       v19, v24, v33
    s.addi       s38, s28, #128
    vf.add       v22, v12, v19
    s.movz       s45, #2
    v.st.w       [s27, #0], v22
    a.vread      v12, a5, s43
    s.addi       s27, s14, #16512
    v.extract    s43, v23, #2
    v.splat      v19, s43
    v.ld.w       v22, [s26, #0]
    vf.mul       v24, v22, v21
    vf.mul       v21, v24, v33
    s.addi       s26, s28, #192
    vf.add       v22, v12, v21
    s.movz       s43, #3
    v.st.w       [s40, #0], v22
    a.vread      v12, a5, s39
    s.addi       s39, s14, #16576
    v.extract    s40, v23, #3
    v.splat      v21, s40
    v.ld.w       v22, [s44, #0]
    vf.mul       v24, v22, v14
    vf.mul       v14, v24, v33
    s.addi       s40, s28, #256
    vf.add       v22, v12, v14
    s.movz       s44, #4
    v.st.w       [s42, #0], v22
    fence.acq_rel.device
    a.vread      v12, a6, s47
    s.addi       s42, s14, #16640
    v.extract    s47, v23, #4
    v.splat      v14, s47
    v.ld.w       v22, [s30, #0]
    vf.mul       v24, v22, v15
    s.addi       s30, s28, #320
    vf.mul       v15, v24, v35
    s.movz       s47, #5
    vf.add       v22, v12, v15
    v.st.w       [s28, #0], v22
    a.vread      v12, a6, s46
    s.addi       s46, s14, #16704
    v.extract    s48, v23, #5
    v.splat      v15, s48
    v.ld.w       v22, [s29, #0]
    vf.mul       v24, v22, v17
    s.addi       s29, s28, #384
    vf.mul       v17, v24, v35
    s.movz       s48, #6
    vf.add       v22, v12, v17
    v.st.w       [s41, #0], v22
    a.vread      v12, a6, s45
    s.addi       s41, s14, #16768
    v.extract    s45, v23, #6
    v.splat      v17, s45
    v.ld.w       v22, [s27, #0]
    vf.mul       v24, v22, v19
    s.addi       s27, s28, #448
    vf.mul       v19, v24, v35
    s.movz       s45, #7
    vf.add       v22, v12, v19
    v.st.w       [s38, #0], v22
    a.vread      v12, a6, s43
    s.addi       s38, s14, #16832
    v.extract    s43, v23, #7
    v.splat      v19, s43
    v.ld.w       v22, [s39, #0]
    vf.mul       v24, v22, v21
    s.addi       s39, s28, #512
    vf.mul       v21, v24, v35
    s.movz       s43, #8
    vf.add       v22, v12, v21
    v.st.w       [s26, #0], v22
    a.vread      v12, a6, s44
    s.addi       s26, s14, #16896
    v.extract    s44, v23, #8
    v.splat      v21, s44
    v.ld.w       v22, [s42, #0]
    vf.mul       v24, v22, v14
    s.addi       s42, s28, #576
    vf.mul       v14, v24, v35
    s.movz       s44, #9
    vf.add       v22, v12, v14
    v.st.w       [s40, #0], v22
    a.vread      v12, a6, s47
    s.addi       s40, s14, #16960
    v.extract    s47, v23, #9
    v.splat      v14, s47
    v.ld.w       v22, [s46, #0]
    vf.mul       v24, v22, v15
    s.addi       s46, s28, #640
    vf.mul       v15, v24, v35
    s.movz       s47, #10
    vf.add       v22, v12, v15
    v.st.w       [s30, #0], v22
    a.vread      v12, a6, s48
    s.addi       s30, s14, #17024
    v.extract    s48, v23, #10
    v.splat      v15, s48
    v.ld.w       v22, [s41, #0]
    vf.mul       v24, v22, v17
    s.addi       s41, s28, #704
    vf.mul       v17, v24, v35
    s.movz       s48, #11
    vf.add       v22, v12, v17
    v.st.w       [s29, #0], v22
    a.vread      v12, a6, s45
    s.addi       s29, s14, #17088
    v.extract    s45, v23, #11
    v.splat      v17, s45
    v.ld.w       v22, [s38, #0]
    vf.mul       v24, v22, v19
    s.addi       s38, s28, #768
    vf.mul       v19, v24, v35
    s.movz       s45, #12
    vf.add       v22, v12, v19
    v.st.w       [s27, #0], v22
    a.vread      v12, a6, s43
    s.addi       s27, s14, #17152
    v.extract    s43, v23, #12
    v.splat      v19, s43
    v.ld.w       v22, [s26, #0]
    vf.mul       v24, v22, v21
    s.addi       s26, s28, #832
    vf.mul       v21, v24, v35
    s.movz       s43, #13
    vf.add       v22, v12, v21
    v.st.w       [s39, #0], v22
    a.vread      v12, a6, s44
    s.addi       s39, s14, #17216
    v.extract    s44, v23, #13
    v.splat      v21, s44
    v.ld.w       v22, [s40, #0]
    vf.mul       v24, v22, v14
    s.addi       s40, s28, #896
    vf.mul       v14, v24, v35
    s.movz       s44, #14
    vf.add       v22, v12, v14
    v.st.w       [s42, #0], v22
    a.vread      v12, a6, s47
    s.addi       s42, s14, #17280
    v.extract    s47, v23, #14
    v.splat      v14, s47
    v.ld.w       v22, [s30, #0]
    vf.mul       v24, v22, v15
    s.addi       s30, s28, #960
    vf.mul       v15, v24, v35
    s.movz       s28, #15
    vf.add       v22, v12, v15
    v.st.w       [s46, #0], v22
    a.vread      v12, a6, s48
    s.addi       s46, s14, #17344
    v.extract    s47, v23, #15
    v.splat      v15, s47
    v.ld.w       v22, [s29, #0]
    vf.mul       v24, v22, v17
    vf.mul       v17, v24, v35
    s.addi       s29, s14, #25600
    vf.add       v22, v12, v17
    s.movz       s47, #0
    v.st.w       [s41, #0], v22
    a.vread      v12, a6, s45
    s.addi       s41, s14, #17408
    v.extract    s45, v23, #0
    v.splat      v17, s45
    v.ld.w       v22, [s27, #0]
    vf.mul       v24, v22, v19
    vf.mul       v19, v24, v35
    s.addi       s27, s29, #64
    vf.add       v22, v12, v19
    s.movz       s45, #1
    v.st.w       [s38, #0], v22
    a.vread      v12, a6, s43
    s.addi       s38, s14, #17472
    v.extract    s43, v23, #1
    v.splat      v19, s43
    v.ld.w       v22, [s39, #0]
    vf.mul       v24, v22, v21
    vf.mul       v21, v24, v35
    s.addi       s39, s29, #128
    vf.add       v22, v12, v21
    s.movz       s43, #2
    v.st.w       [s26, #0], v22
    a.vread      v12, a6, s44
    s.addi       s26, s14, #17536
    v.extract    s44, v23, #2
    v.splat      v21, s44
    v.ld.w       v22, [s42, #0]
    vf.mul       v24, v22, v14
    vf.mul       v14, v24, v35
    s.addi       s42, s29, #192
    vf.add       v22, v12, v14
    s.movz       s44, #3
    v.st.w       [s40, #0], v22
    a.vread      v12, a6, s28
    s.addi       s28, s14, #17600
    v.extract    s40, v23, #3
    v.splat      v14, s40
    v.ld.w       v22, [s46, #0]
    vf.mul       v24, v22, v15
    vf.mul       v15, v24, v35
    s.addi       s40, s29, #256
    vf.add       v22, v12, v15
    s.movz       s46, #4
    v.st.w       [s30, #0], v22
    fence.acq_rel.device
    a.vread      v12, a7, s47
    s.addi       s30, s14, #17664
    v.extract    s47, v23, #4
    v.splat      v15, s47
    v.ld.w       v22, [s41, #0]
    vf.mul       v24, v22, v17
    s.addi       s41, s29, #320
    vf.mul       v17, v24, v38
    s.movz       s47, #5
    vf.add       v22, v12, v17
    v.st.w       [s29, #0], v22
    a.vread      v12, a7, s45
    s.addi       s45, s14, #17728
    v.extract    s48, v23, #5
    v.splat      v17, s48
    v.ld.w       v22, [s38, #0]
    vf.mul       v24, v22, v19
    s.addi       s38, s29, #384
    vf.mul       v19, v24, v38
    s.movz       s48, #6
    vf.add       v22, v12, v19
    v.st.w       [s27, #0], v22
    a.vread      v12, a7, s43
    s.addi       s27, s14, #17792
    v.extract    s43, v23, #6
    v.splat      v19, s43
    v.ld.w       v22, [s26, #0]
    vf.mul       v24, v22, v21
    s.addi       s26, s29, #448
    vf.mul       v21, v24, v38
    s.movz       s43, #7
    vf.add       v22, v12, v21
    v.st.w       [s39, #0], v22
    a.vread      v12, a7, s44
    s.addi       s39, s14, #17856
    v.extract    s44, v23, #7
    v.splat      v21, s44
    v.ld.w       v22, [s28, #0]
    vf.mul       v24, v22, v14
    s.addi       s28, s29, #512
    vf.mul       v14, v24, v38
    s.movz       s44, #8
    vf.add       v22, v12, v14
    v.st.w       [s42, #0], v22
    a.vread      v12, a7, s46
    s.addi       s42, s14, #17920
    v.extract    s46, v23, #8
    v.splat      v14, s46
    v.ld.w       v22, [s30, #0]
    vf.mul       v24, v22, v15
    s.addi       s30, s29, #576
    vf.mul       v15, v24, v38
    s.movz       s46, #9
    vf.add       v22, v12, v15
    v.st.w       [s40, #0], v22
    a.vread      v12, a7, s47
    s.addi       s40, s14, #17984
    v.extract    s47, v23, #9
    v.splat      v15, s47
    v.ld.w       v22, [s45, #0]
    vf.mul       v24, v22, v17
    s.addi       s45, s29, #640
    vf.mul       v17, v24, v38
    s.movz       s47, #10
    vf.add       v22, v12, v17
    v.st.w       [s41, #0], v22
    a.vread      v12, a7, s48
    s.addi       s41, s14, #18048
    v.extract    s48, v23, #10
    v.splat      v17, s48
    v.ld.w       v22, [s27, #0]
    vf.mul       v24, v22, v19
    s.addi       s27, s29, #704
    vf.mul       v19, v24, v38
    s.movz       s48, #11
    vf.add       v22, v12, v19
    v.st.w       [s38, #0], v22
    a.vread      v12, a7, s43
    s.addi       s38, s14, #18112
    v.extract    s43, v23, #11
    v.splat      v19, s43
    v.ld.w       v22, [s39, #0]
    vf.mul       v24, v22, v21
    s.addi       s39, s29, #768
    vf.mul       v21, v24, v38
    s.movz       s43, #12
    vf.add       v22, v12, v21
    v.st.w       [s26, #0], v22
    a.vread      v12, a7, s44
    s.addi       s26, s14, #18176
    v.extract    s44, v23, #12
    v.splat      v21, s44
    v.ld.w       v22, [s42, #0]
    vf.mul       v24, v22, v14
    s.addi       s42, s29, #832
    vf.mul       v14, v24, v38
    s.movz       s44, #13
    vf.add       v22, v12, v14
    v.st.w       [s28, #0], v22
    a.vread      v12, a7, s46
    s.addi       s28, s14, #18240
    v.extract    s46, v23, #13
    v.splat      v14, s46
    v.ld.w       v22, [s40, #0]
    vf.mul       v24, v22, v15
    s.addi       s40, s29, #896
    vf.mul       v15, v24, v38
    s.movz       s46, #14
    vf.add       v22, v12, v15
    v.st.w       [s30, #0], v22
    a.vread      v12, a7, s47
    s.addi       s30, s14, #18304
    v.extract    s47, v23, #14
    v.splat      v15, s47
    v.ld.w       v22, [s41, #0]
    vf.mul       v24, v22, v17
    s.addi       s41, s29, #960
    vf.mul       v17, v24, v38
    s.movz       s29, #15
    vf.add       v22, v12, v17
    v.st.w       [s45, #0], v22
    a.vread      v12, a7, s48
    s.addi       s45, s14, #18368
    v.extract    s47, v23, #15
    v.splat      v17, s47
    v.ld.w       v22, [s38, #0]
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v38
    s.addi       s38, s22, #128
    vf.add       v22, v12, v19
    s.addi       s47, s38, #0
    v.st.w       [s27, #0], v22
    a.vread      v12, a7, s43
    s.addi       s27, s23, #128
    s.addi       s38, s24, #4                    // &ptr_carry_17[1] (a constant offset, x4)
    s.addi       s43, s27, #0
    s.addi       s27, s38, #0
    s.addi       s38, s24, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    v.ld.w       v19, [s26, #0]
    s.addi       s26, s24, #4                    // &ptr_carry_19[1] (a constant offset, x4)
    s.addi       s26, s24, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    s.addi       s26, s24, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    vf.mul       v22, v19, v21
    s.addi       s26, s24, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    vf.mul       v19, v22, v38
    s.addi       s26, s24, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    vf.add       v21, v12, v19
    s.addi       s26, s24, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    v.st.w       [s39, #0], v21
    a.vread      v12, a7, s44
    s.addi       s26, s14, #18432
    s.movz       s38, #0
    v.ld.w       v19, [s28, #0]
    s.movz       s28, #1
    vf.mul       v21, v19, v14
    s.addi       s39, s14, #18496
    vf.mul       v14, v21, v38
    vf.add       v19, v12, v14
    v.st.w       [s42, #0], v19
    a.vread      v12, a7, s46
    s.addi       s42, s14, #18560
    s.movz       s44, #2
    s.movz       s46, #3
    v.ld.w       v14, [s30, #0]
    s.addi       s30, s14, #18624
    vf.mul       v19, v14, v15
    s.movz       s48, #4
    vf.mul       v14, v19, v38
    s.addi       s49, s14, #18688
    vf.add       v15, v12, v14
    v.st.w       [s40, #0], v15
    a.vread      v12, a7, s29
    s.addi       s29, s14, #18752
    s.movz       s40, #5
    v.ld.w       v14, [s45, #0]
    s.addi       s45, s14, #18816
    s.movz       s50, #6
    vf.mul       v15, v14, v17
    vf.mul       v14, v15, v38
    s.movz       s51, #7
    vf.add       v15, v12, v14
    v.st.w       [s41, #0], v15
    fence.acq_rel.device
    s.mov        s22, s47
    s.mov        s23, s43
    s.mov        s24, s27
    s.addi       s27, s14, #18880
    s.addi       s41, s14, #18944
    s.movz       s43, #8
    s.addi       s47, s14, #19008
    s.movz       s53, #9
    s.addi       s54, s14, #19072
    s.movz       s55, #10
    v.ld.w       v12, [s26, #0]
    s.addi       s26, s14, #19136
    a.vwrite     a0, s38, v12
    v.ld.w       v12, [s39, #0]
    s.movz       s38, #11
    s.addi       s39, s14, #19200
    a.vwrite     a0, s28, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s28, #12
    s.addi       s42, s14, #19264
    a.vwrite     a0, s44, v12
    v.ld.w       v12, [s30, #0]
    s.movz       s30, #13
    s.addi       s44, s14, #19328
    a.vwrite     a0, s46, v12
    v.ld.w       v12, [s49, #0]
    s.movz       s46, #14
    s.addi       s49, s14, #19392
    a.vwrite     a0, s48, v12
    v.ld.w       v12, [s29, #0]
    s.movz       s29, #15
    s.addi       s48, s14, #19456
    a.vwrite     a0, s40, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s40, #0
    s.addi       s45, s14, #19520
    a.vwrite     a0, s50, v12
    v.ld.w       v12, [s27, #0]
    s.movz       s27, #1
    s.addi       s50, s14, #19584
    a.vwrite     a0, s51, v12
    v.ld.w       v12, [s41, #0]
    s.movz       s41, #2
    s.addi       s51, s14, #19648
    a.vwrite     a0, s43, v12
    v.ld.w       v12, [s47, #0]
    s.movz       s43, #3
    s.addi       s47, s14, #19712
    a.vwrite     a0, s53, v12
    v.ld.w       v12, [s54, #0]
    s.movz       s53, #4
    s.addi       s54, s14, #19776
    a.vwrite     a0, s55, v12
    v.ld.w       v12, [s26, #0]
    s.movz       s26, #5
    s.addi       s55, s14, #19840
    a.vwrite     a0, s38, v12
    v.ld.w       v12, [s39, #0]
    s.movz       s38, #6
    s.addi       s39, s14, #19904
    a.vwrite     a0, s28, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s28, #7
    s.addi       s42, s14, #19968
    a.vwrite     a0, s30, v12
    v.ld.w       v12, [s44, #0]
    s.movz       s30, #8
    s.addi       s44, s14, #20032
    a.vwrite     a0, s46, v12
    v.ld.w       v12, [s49, #0]
    s.movz       s46, #9
    s.addi       s49, s14, #20096
    a.vwrite     a0, s29, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s29, #10
    s.addi       s48, s14, #20160
    a.vwrite     a1, s40, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s40, #11
    s.addi       s45, s14, #20224
    a.vwrite     a1, s27, v12
    v.ld.w       v12, [s50, #0]
    s.movz       s27, #12
    s.addi       s50, s14, #20288
    a.vwrite     a1, s41, v12
    v.ld.w       v12, [s51, #0]
    s.movz       s41, #13
    s.addi       s51, s14, #20352
    a.vwrite     a1, s43, v12
    v.ld.w       v12, [s47, #0]
    s.movz       s43, #14
    s.addi       s47, s14, #20416
    a.vwrite     a1, s53, v12
    v.ld.w       v12, [s54, #0]
    s.movz       s53, #15
    s.addi       s54, s14, #20480
    a.vwrite     a1, s26, v12
    v.ld.w       v12, [s55, #0]
    s.movz       s26, #0
    s.addi       s55, s14, #20544
    a.vwrite     a1, s38, v12
    v.ld.w       v12, [s39, #0]
    s.movz       s38, #1
    s.addi       s39, s14, #20608
    a.vwrite     a1, s28, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s28, #2
    s.addi       s42, s14, #20672
    a.vwrite     a1, s30, v12
    v.ld.w       v12, [s44, #0]
    s.movz       s30, #3
    s.addi       s44, s14, #20736
    a.vwrite     a1, s46, v12
    v.ld.w       v12, [s49, #0]
    s.movz       s46, #4
    s.addi       s49, s14, #20800
    a.vwrite     a1, s29, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s29, #5
    s.addi       s48, s14, #20864
    a.vwrite     a1, s40, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s40, #6
    s.addi       s45, s14, #20928
    a.vwrite     a1, s27, v12
    v.ld.w       v12, [s50, #0]
    s.movz       s27, #7
    s.addi       s50, s14, #20992
    a.vwrite     a1, s41, v12
    v.ld.w       v12, [s51, #0]
    s.movz       s41, #8
    s.addi       s51, s14, #21056
    a.vwrite     a1, s43, v12
    v.ld.w       v12, [s47, #0]
    s.movz       s43, #9
    s.addi       s47, s14, #21120
    a.vwrite     a1, s53, v12
    v.ld.w       v12, [s54, #0]
    s.movz       s53, #10
    s.addi       s54, s14, #21184
    a.vwrite     a2, s26, v12
    v.ld.w       v12, [s55, #0]
    s.movz       s26, #11
    s.addi       s55, s14, #21248
    a.vwrite     a2, s38, v12
    v.ld.w       v12, [s39, #0]
    s.movz       s38, #12
    s.addi       s39, s14, #21312
    a.vwrite     a2, s28, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s28, #13
    s.addi       s42, s14, #21376
    a.vwrite     a2, s30, v12
    v.ld.w       v12, [s44, #0]
    s.movz       s30, #14
    s.addi       s44, s14, #21440
    a.vwrite     a2, s46, v12
    v.ld.w       v12, [s49, #0]
    s.movz       s46, #15
    s.addi       s49, s14, #21504
    a.vwrite     a2, s29, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s29, #0
    s.addi       s48, s14, #21568
    a.vwrite     a2, s40, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s40, #1
    s.addi       s45, s14, #21632
    a.vwrite     a2, s27, v12
    v.ld.w       v12, [s50, #0]
    s.movz       s27, #2
    s.addi       s50, s14, #21696
    a.vwrite     a2, s41, v12
    v.ld.w       v12, [s51, #0]
    s.movz       s41, #3
    s.addi       s51, s14, #21760
    a.vwrite     a2, s43, v12
    v.ld.w       v12, [s47, #0]
    s.movz       s43, #4
    s.addi       s47, s14, #21824
    a.vwrite     a2, s53, v12
    v.ld.w       v12, [s54, #0]
    s.movz       s53, #5
    s.addi       s54, s14, #21888
    a.vwrite     a2, s26, v12
    v.ld.w       v12, [s55, #0]
    s.movz       s26, #6
    s.addi       s55, s14, #21952
    a.vwrite     a2, s38, v12
    v.ld.w       v12, [s39, #0]
    s.movz       s38, #7
    s.addi       s39, s14, #22016
    a.vwrite     a2, s28, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s28, #8
    s.addi       s42, s14, #22080
    a.vwrite     a2, s30, v12
    v.ld.w       v12, [s44, #0]
    s.movz       s30, #9
    s.addi       s44, s14, #22144
    a.vwrite     a2, s46, v12
    v.ld.w       v12, [s49, #0]
    s.movz       s46, #10
    s.addi       s49, s14, #22208
    a.vwrite     a3, s29, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s29, #11
    s.addi       s48, s14, #22272
    a.vwrite     a3, s40, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s40, #12
    s.addi       s45, s14, #22336
    a.vwrite     a3, s27, v12
    v.ld.w       v12, [s50, #0]
    s.movz       s27, #13
    s.addi       s50, s14, #22400
    a.vwrite     a3, s41, v12
    v.ld.w       v12, [s51, #0]
    s.movz       s41, #14
    s.addi       s51, s14, #22464
    a.vwrite     a3, s43, v12
    v.ld.w       v12, [s47, #0]
    s.movz       s43, #15
    s.addi       s47, s14, #22528
    a.vwrite     a3, s53, v12
    v.ld.w       v12, [s54, #0]
    s.movz       s53, #0
    s.addi       s54, s14, #22592
    a.vwrite     a3, s26, v12
    v.ld.w       v12, [s55, #0]
    s.movz       s26, #1
    s.addi       s55, s14, #22656
    a.vwrite     a3, s38, v12
    v.ld.w       v12, [s39, #0]
    s.movz       s38, #2
    s.addi       s39, s14, #22720
    a.vwrite     a3, s28, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s28, #3
    s.addi       s42, s14, #22784
    a.vwrite     a3, s30, v12
    v.ld.w       v12, [s44, #0]
    s.movz       s30, #4
    s.addi       s44, s14, #22848
    a.vwrite     a3, s46, v12
    v.ld.w       v12, [s49, #0]
    s.movz       s46, #5
    s.addi       s49, s14, #22912
    a.vwrite     a3, s29, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s29, #6
    s.addi       s48, s14, #22976
    a.vwrite     a3, s40, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s40, #7
    s.addi       s45, s14, #23040
    a.vwrite     a3, s27, v12
    v.ld.w       v12, [s50, #0]
    s.movz       s27, #8
    s.addi       s50, s14, #23104
    a.vwrite     a3, s41, v12
    v.ld.w       v12, [s51, #0]
    s.movz       s41, #9
    s.addi       s51, s14, #23168
    a.vwrite     a3, s43, v12
    v.ld.w       v12, [s47, #0]
    s.movz       s43, #10
    s.addi       s47, s14, #23232
    a.vwrite     a4, s53, v12
    v.ld.w       v12, [s54, #0]
    s.movz       s53, #11
    s.addi       s54, s14, #23296
    a.vwrite     a4, s26, v12
    v.ld.w       v12, [s55, #0]
    s.movz       s26, #12
    s.addi       s55, s14, #23360
    a.vwrite     a4, s38, v12
    v.ld.w       v12, [s39, #0]
    s.movz       s38, #13
    s.addi       s39, s14, #23424
    a.vwrite     a4, s28, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s28, #14
    s.addi       s42, s14, #23488
    a.vwrite     a4, s30, v12
    v.ld.w       v12, [s44, #0]
    s.movz       s30, #15
    s.addi       s44, s14, #23552
    a.vwrite     a4, s46, v12
    v.ld.w       v12, [s49, #0]
    s.movz       s46, #0
    s.addi       s49, s14, #23616
    a.vwrite     a4, s29, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s29, #1
    s.addi       s48, s14, #23680
    a.vwrite     a4, s40, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s40, #2
    s.addi       s45, s14, #23744
    a.vwrite     a4, s27, v12
    v.ld.w       v12, [s50, #0]
    s.movz       s27, #3
    s.addi       s50, s14, #23808
    a.vwrite     a4, s41, v12
    v.ld.w       v12, [s51, #0]
    s.movz       s41, #4
    s.addi       s51, s14, #23872
    a.vwrite     a4, s43, v12
    v.ld.w       v12, [s47, #0]
    s.movz       s43, #5
    s.addi       s47, s14, #23936
    a.vwrite     a4, s53, v12
    v.ld.w       v12, [s54, #0]
    s.movz       s53, #6
    s.addi       s54, s14, #24000
    a.vwrite     a4, s26, v12
    v.ld.w       v12, [s55, #0]
    s.movz       s26, #7
    s.addi       s55, s14, #24064
    a.vwrite     a4, s38, v12
    v.ld.w       v12, [s39, #0]
    s.movz       s38, #8
    s.addi       s39, s14, #24128
    a.vwrite     a4, s28, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s28, #9
    s.addi       s42, s14, #24192
    a.vwrite     a4, s30, v12
    v.ld.w       v12, [s44, #0]
    s.movz       s30, #10
    s.addi       s44, s14, #24256
    a.vwrite     a5, s46, v12
    v.ld.w       v12, [s49, #0]
    s.movz       s46, #11
    s.addi       s49, s14, #24320
    a.vwrite     a5, s29, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s29, #12
    s.addi       s48, s14, #24384
    a.vwrite     a5, s40, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s40, #13
    s.addi       s45, s14, #24448
    a.vwrite     a5, s27, v12
    v.ld.w       v12, [s50, #0]
    s.movz       s27, #14
    s.addi       s50, s14, #24512
    a.vwrite     a5, s41, v12
    v.ld.w       v12, [s51, #0]
    s.movz       s41, #15
    s.addi       s51, s14, #24576
    a.vwrite     a5, s43, v12
    v.ld.w       v12, [s47, #0]
    s.movz       s43, #0
    s.addi       s47, s14, #24640
    a.vwrite     a5, s53, v12
    v.ld.w       v12, [s54, #0]
    s.movz       s53, #1
    s.addi       s54, s14, #24704
    a.vwrite     a5, s26, v12
    v.ld.w       v12, [s55, #0]
    s.movz       s26, #2
    s.addi       s55, s14, #24768
    a.vwrite     a5, s38, v12
    v.ld.w       v12, [s39, #0]
    s.movz       s38, #3
    s.addi       s39, s14, #24832
    a.vwrite     a5, s28, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s28, #4
    s.addi       s42, s14, #24896
    a.vwrite     a5, s30, v12
    v.ld.w       v12, [s44, #0]
    s.movz       s30, #5
    s.addi       s44, s14, #24960
    a.vwrite     a5, s46, v12
    v.ld.w       v12, [s49, #0]
    s.movz       s46, #6
    s.addi       s49, s14, #25024
    a.vwrite     a5, s29, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s29, #7
    s.addi       s48, s14, #25088
    a.vwrite     a5, s40, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s40, #8
    s.addi       s45, s14, #25152
    a.vwrite     a5, s27, v12
    v.ld.w       v12, [s50, #0]
    s.movz       s27, #9
    s.addi       s50, s14, #25216
    a.vwrite     a5, s41, v12
    v.ld.w       v12, [s51, #0]
    s.movz       s41, #10
    s.addi       s51, s14, #25280
    a.vwrite     a6, s43, v12
    v.ld.w       v12, [s47, #0]
    s.movz       s43, #11
    s.addi       s47, s14, #25344
    a.vwrite     a6, s53, v12
    v.ld.w       v12, [s54, #0]
    s.movz       s53, #12
    s.addi       s54, s14, #25408
    a.vwrite     a6, s26, v12
    v.ld.w       v12, [s55, #0]
    s.movz       s26, #13
    s.addi       s55, s14, #25472
    a.vwrite     a6, s38, v12
    v.ld.w       v12, [s39, #0]
    s.movz       s38, #14
    s.addi       s39, s14, #25536
    a.vwrite     a6, s28, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s28, #15
    s.addi       s42, s14, #25600
    a.vwrite     a6, s30, v12
    v.ld.w       v12, [s44, #0]
    s.movz       s30, #0
    s.addi       s44, s14, #25664
    a.vwrite     a6, s46, v12
    v.ld.w       v12, [s49, #0]
    s.movz       s46, #1
    s.addi       s49, s14, #25728
    a.vwrite     a6, s29, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s29, #2
    s.addi       s48, s14, #25792
    a.vwrite     a6, s40, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s40, #3
    s.addi       s45, s14, #25856
    a.vwrite     a6, s27, v12
    v.ld.w       v12, [s50, #0]
    s.movz       s27, #4
    s.addi       s50, s14, #25920
    a.vwrite     a6, s41, v12
    v.ld.w       v12, [s51, #0]
    s.movz       s41, #5
    s.addi       s51, s14, #25984
    a.vwrite     a6, s43, v12
    v.ld.w       v12, [s47, #0]
    s.movz       s43, #6
    s.addi       s47, s14, #26048
    a.vwrite     a6, s53, v12
    v.ld.w       v12, [s54, #0]
    s.movz       s53, #7
    s.addi       s54, s14, #26112
    a.vwrite     a6, s26, v12
    v.ld.w       v12, [s55, #0]
    s.movz       s26, #8
    s.addi       s55, s14, #26176
    a.vwrite     a6, s38, v12
    v.ld.w       v12, [s39, #0]
    s.movz       s38, #9
    s.addi       s39, s14, #26240
    a.vwrite     a6, s28, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s28, #10
    s.addi       s42, s14, #26304
    a.vwrite     a7, s30, v12
    v.ld.w       v12, [s44, #0]
    s.movz       s30, #11
    s.addi       s44, s14, #26368
    a.vwrite     a7, s46, v12
    v.ld.w       v12, [s49, #0]
    s.movz       s46, #12
    s.addi       s49, s14, #26432
    a.vwrite     a7, s29, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s29, #13
    s.addi       s48, s14, #26496
    s.addi       s56, s14, #26560
    a.vwrite     a7, s40, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s14, #14
    s.movz       s40, #15
    a.vwrite     a7, s27, v12
    v.ld.w       v12, [s50, #0]
    s.add        s27, s20, s5
    s.movz       s45, #1
    a.vwrite     a7, s41, v12
    v.ld.w       v12, [s51, #0]
    a.vwrite     a7, s43, v12
    v.ld.w       v12, [s47, #0]
    a.vwrite     a7, s53, v12
    v.ld.w       v12, [s54, #0]
    a.vwrite     a7, s26, v12
    v.ld.w       v12, [s55, #0]
    a.vwrite     a7, s38, v12
    v.ld.w       v12, [s39, #0]
    a.vwrite     a7, s28, v12
    v.ld.w       v12, [s42, #0]
    a.vwrite     a7, s30, v12
    v.ld.w       v12, [s44, #0]
    a.vwrite     a7, s46, v12
    v.ld.w       v12, [s49, #0]
    a.vwrite     a7, s29, v12
    v.ld.w       v12, [s48, #0]
    a.vwrite     a7, s14, v12
    v.ld.w       v12, [s56, #0]
    a.vwrite     a7, s40, v12
    s.mov        s20, s27
    br.nz        s45, for_25
endfor_26:
    s.mul        s2, s19, s4
    s.movz       s4, #0
    s.movz       s6, #0
    s.add        s7, s4, s1                      // the tile origin
    s.movz       s4, #0
    s.mul        s8, s2, s21
    s.movz       s9, #0
    s.muli       s10, s1, #2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    s.muli       s7, s8, #2
    a.vread      v2, a0, s6
    s.muli       s6, s21, #2
    s.add        s8, s4, s2                      // the tile origin
    s.add        s4, s9, s3                      // the tile origin
    v.splat      v3, s8
    v.splat      v4, s5
    v.add        v5, v0, v1
    v.splat      v1, s4
    vf.cvt.f32.bf16 v6, v2
    s.add        s4, s7, s10
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.muli       s5, s6, #1
    s.add        s9, s16, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    @p3 v.st.h       [s9, #0], v6
    a.vread      v1, a0, s4
    s.addi       s4, s8, #1
    s.add        s9, s5, s7
    v.splat      v2, s4
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s9, s10
    v.cmp.lt     p1, v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.addi       s9, s1, #16
    s.addi       s11, s1, #32
    s.addi       s12, s1, #48
    @p3 v.st.h       [s5, #0], v3
    s.addi       s5, s1, #64
    s.addi       s13, s1, #80
    s.addi       s14, s1, #96
    s.addi       s15, s1, #112
    v.iota       v1                              // arange(0, VLEN)
    a.vread      v2, a0, s4
    v.splat      v3, s2
    vf.cvt.f32.bf16 v5, v2
    v.add        v2, v3, v1
    s.muli       s1, s6, #2
    s.addi       s2, s8, #2
    s.muli       s4, s6, #3
    v.splat      v1, s2
    s.movz       s2, #3
    s.add        s17, s1, s7
    v.cmp.lt     p1, v1, v4
    s.add        s1, s17, s10
    p.and        p3, p1, p2
    s.add        s17, s16, s1
    s.addi       s1, s8, #3
    @p3 v.st.h       [s17, #0], v5
    a.vread      v1, a0, s2
    s.add        s2, s4, s7
    v.splat      v2, s1
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s2, s10
    v.cmp.lt     p1, v2, v4
    s.muli       s2, s6, #4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    s.movz       s1, #4
    s.addi       s17, s8, #4
    s.add        s18, s2, s7
    v.splat      v1, s17
    @p3 v.st.h       [s4, #0], v3
    a.vread      v2, a0, s1
    s.add        s1, s18, s10
    v.cmp.lt     p1, v1, v4
    vf.cvt.f32.bf16 v1, v2
    s.muli       s2, s6, #5
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    s.movz       s1, #5
    s.addi       s17, s8, #5
    s.add        s18, s2, s7
    v.splat      v2, s17
    s.add        s2, s18, s10
    s.muli       s17, s6, #6
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v2, v4
    s.add        s1, s16, s2
    vf.cvt.f32.bf16 v2, v1
    p.and        p3, p1, p2
    s.movz       s2, #6
    s.addi       s4, s8, #6
    s.add        s18, s17, s7
    v.splat      v1, s4
    s.add        s4, s18, s10
    s.muli       s17, s6, #7
    v.cmp.lt     p1, v1, v4
    s.add        s18, s16, s4
    @p3 v.st.h       [s1, #0], v2
    a.vread      v1, a0, s2
    p.and        p3, p1, p2
    s.movz       s1, #7
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #7
    s.add        s4, s17, s7
    v.splat      v1, s2
    s.add        s2, s4, s10
    s.muli       s4, s6, #8
    v.cmp.lt     p1, v1, v4
    s.add        s17, s16, s2
    p.and        p4, p1, p2
    s.movz       s2, #8
    @p3 v.st.h       [s18, #0], v2
    a.vread      v1, a0, s1
    s.addi       s1, s8, #8
    s.add        s18, s4, s7
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s1
    s.add        s1, s18, s10
    s.muli       s4, s6, #9
    v.cmp.lt     p1, v1, v4
    s.add        s18, s16, s1
    p.and        p3, p1, p2
    s.movz       s1, #9
    s.addi       s19, s8, #9
    s.add        s20, s4, s7
    @p4 v.st.h       [s17, #0], v2
    a.vread      v1, a0, s2
    v.splat      v2, s19
    s.add        s2, s20, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s4, s6, #10
    s.add        s17, s16, s2
    p.and        p4, p1, p2
    s.movz       s2, #10
    s.addi       s19, s8, #10
    s.add        s20, s4, s7
    v.splat      v1, s19
    s.add        s4, s20, s10
    @p3 v.st.h       [s18, #0], v3
    a.vread      v2, a0, s1
    v.cmp.lt     p1, v1, v4
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v1, v2
    s.add        s18, s16, s4
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.addi       s19, s8, #11
    s.add        s20, s1, s7
    v.splat      v2, s19
    s.add        s1, s20, s10
    s.muli       s19, s6, #12
    s.add        s20, s16, s1
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.movz       s1, #12
    s.addi       s2, s8, #12
    s.add        s17, s19, s7
    v.splat      v1, s2
    s.add        s2, s17, s10
    s.muli       s17, s6, #13
    s.add        s19, s16, s2
    s.movz       s2, #13
    s.addi       s21, s8, #13
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a0, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s4, s17, s7
    v.splat      v2, s21
    s.add        s17, s4, s10
    s.muli       s4, s6, #14
    s.add        s18, s16, s17
    s.movz       s17, #14
    s.addi       s21, s8, #14
    s.add        s22, s4, s7
    @p4 v.st.h       [s20, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s21
    s.add        s1, s22, s10
    s.muli       s4, s6, #15
    s.add        s20, s16, s1
    s.movz       s1, #15
    s.addi       s21, s8, #15
    v.splat      v3, s8
    s.add        s22, s4, s7
    v.splat      v5, s21
    @p3 v.st.h       [s19, #0], v2
    a.vread      v2, a0, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s2, #0
    s.add        s4, s22, s10
    s.add        s10, s2, s9                     // the tile origin
    s.add        s2, s16, s4
    s.movz       s4, #0
    s.movz       s19, #0
    s.muli       s21, s9, #2
    v.splat      v2, s10
    s.add        s9, s19, s3                     // the tile origin
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v1
    v.add        v1, v0, v2
    v.splat      v2, s9
    s.add        s9, s7, s21
    v.cmp.lt     p1, v3, v4
    s.muli       s10, s6, #1
    s.add        s17, s16, s9
    s.movz       s9, #1
    s.addi       s18, s8, #1
    s.muli       s19, s6, #2
    @p3 v.st.h       [s20, #0], v5
    a.vread      v3, a0, s1
    v.cmp.lt     p2, v1, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s10, s7
    v.splat      v2, s18
    s.add        s10, s1, s21
    s.movz       s1, #2
    s.add        s18, s16, s10
    s.addi       s10, s8, #2
    s.add        s20, s19, s7
    v.splat      v3, s10
    s.add        s10, s20, s21
    @p4 v.st.h       [s2, #0], v1
    a.vread      v1, a1, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s2, s6, #3
    s.add        s4, s16, s10
    s.movz       s10, #3
    s.addi       s19, s8, #3
    s.muli       s20, s6, #4
    s.add        s22, s2, s7
    v.splat      v1, s19
    s.add        s2, s22, s21
    s.movz       s19, #4
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s9
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s9, s16, s2
    s.addi       s2, s8, #4
    s.add        s17, s20, s7
    v.splat      v2, s2
    s.add        s2, s17, s21
    s.muli       s17, s6, #5
    s.add        s20, s16, s2
    s.movz       s2, #5
    @p4 v.st.h       [s18, #0], v3
    a.vread      v3, a1, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s1, s8, #5
    s.add        s18, s17, s7
    v.splat      v3, s1
    s.add        s1, s18, s21
    s.muli       s17, s6, #6
    s.add        s18, s16, s1
    s.movz       s1, #6
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a1, s10
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s4, s8, #6
    s.add        s10, s17, s7
    v.splat      v1, s4
    s.add        s4, s10, s21
    s.muli       s10, s6, #7
    s.add        s17, s16, s4
    s.movz       s4, #7
    @p4 v.st.h       [s9, #0], v2
    a.vread      v2, a1, s19
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s9, s8, #7
    s.add        s19, s10, s7
    v.splat      v2, s9
    s.add        s9, s19, s21
    s.muli       s10, s6, #8
    s.add        s19, s16, s9
    s.movz       s9, #8
    @p3 v.st.h       [s20, #0], v3
    a.vread      v3, a1, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s2, s8, #8
    s.add        s20, s10, s7
    v.splat      v3, s2
    s.add        s2, s20, s21
    s.muli       s10, s6, #9
    s.add        s20, s16, s2
    s.movz       s2, #9
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s1, s8, #9
    s.add        s18, s10, s7
    v.splat      v1, s1
    s.add        s1, s18, s21
    s.muli       s10, s6, #10
    s.add        s18, s16, s1
    s.movz       s1, #10
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s4, s8, #10
    s.add        s17, s10, s7
    v.splat      v2, s4
    s.add        s4, s17, s21
    s.muli       s10, s6, #11
    s.add        s17, s16, s4
    s.movz       s4, #11
    @p4 v.st.h       [s19, #0], v3
    a.vread      v3, a1, s9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s9, s8, #11
    s.add        s19, s10, s7
    v.splat      v3, s9
    s.add        s9, s19, s21
    s.muli       s10, s6, #12
    s.add        s19, s16, s9
    s.movz       s9, #12
    @p3 v.st.h       [s20, #0], v1
    a.vread      v1, a1, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #12
    s.add        s20, s10, s7
    v.splat      v1, s2
    s.add        s2, s20, s21
    s.muli       s10, s6, #13
    s.add        s20, s16, s2
    s.movz       s2, #13
    @p4 v.st.h       [s18, #0], v2
    a.vread      v2, a1, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s1, s8, #13
    s.add        s18, s10, s7
    v.splat      v2, s1
    s.add        s1, s18, s21
    s.muli       s10, s6, #14
    s.add        s18, s16, s1
    s.movz       s1, #14
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s4, s8, #14
    s.add        s17, s10, s7
    v.splat      v3, s4
    s.add        s4, s17, s21
    s.muli       s10, s6, #15
    s.add        s17, s16, s4
    s.movz       s4, #15
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a1, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s9, s8, #15
    s.add        s19, s10, s7
    v.splat      v1, s9
    s.movz       s9, #0
    s.add        s10, s19, s21
    s.add        s19, s9, s11                    // the tile origin
    s.add        s9, s16, s10
    s.movz       s10, #0
    s.muli       s21, s11, #2
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a1, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.movz       s2, #0
    v.splat      v2, s19
    s.add        s11, s2, s3                     // the tile origin
    v.splat      v5, s8
    v.add        v6, v0, v2
    v.splat      v2, s11
    s.add        s2, s7, s21
    s.muli       s11, s6, #1
    s.add        s19, s16, s2
    @p4 v.st.h       [s18, #0], v3
    a.vread      v3, a1, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v5, v4
    s.movz       s1, #1
    s.addi       s2, s8, #1
    s.add        s18, s11, s7
    v.splat      v3, s2
    s.add        s2, s18, s21
    s.muli       s11, s6, #2
    s.add        s18, s16, s2
    s.movz       s2, #2
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a1, s4
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s4, s8, #2
    s.add        s17, s11, s7
    v.splat      v1, s4
    s.add        s4, s17, s21
    s.muli       s11, s6, #3
    s.add        s17, s16, s4
    s.movz       s4, #3
    @p4 v.st.h       [s9, #0], v2
    a.vread      v2, a2, s10
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s9, s8, #3
    s.add        s10, s11, s7
    v.splat      v2, s9
    s.add        s9, s10, s21
    s.muli       s10, s6, #4
    s.add        s11, s16, s9
    s.movz       s9, #4
    s.addi       s20, s8, #4
    @p3 v.st.h       [s19, #0], v3
    a.vread      v3, a2, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s10, s7
    v.splat      v3, s20
    s.add        s10, s1, s21
    s.muli       s1, s6, #5
    s.add        s19, s16, s10
    s.movz       s10, #5
    s.addi       s20, s8, #5
    s.add        s22, s1, s7
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s20
    s.add        s1, s22, s21
    s.muli       s2, s6, #6
    s.add        s18, s16, s1
    s.movz       s1, #6
    s.addi       s20, s8, #6
    s.add        s22, s2, s7
    v.splat      v5, s20
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s2, s22, s21
    s.muli       s4, s6, #7
    s.add        s17, s16, s2
    s.movz       s2, #7
    s.addi       s20, s8, #7
    s.add        s22, s4, s7
    v.splat      v2, s20
    s.add        s4, s22, s21
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a2, s9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s9, s6, #8
    s.add        s11, s16, s4
    s.movz       s4, #8
    s.addi       s20, s8, #8
    s.add        s22, s9, s7
    v.splat      v3, s20
    s.add        s9, s22, s21
    @p3 v.st.h       [s19, #0], v1
    a.vread      v1, a2, s10
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s10, s6, #9
    s.add        s19, s16, s9
    s.movz       s9, #9
    s.addi       s20, s8, #9
    s.add        s22, s10, s7
    v.splat      v1, s20
    s.add        s10, s22, s21
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a2, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s1, s6, #10
    s.add        s18, s16, s10
    s.movz       s10, #10
    s.addi       s20, s8, #10
    s.add        s22, s1, s7
    v.splat      v5, s20
    s.add        s1, s22, s21
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s2, s6, #11
    s.add        s17, s16, s1
    s.movz       s1, #11
    s.addi       s20, s8, #11
    s.add        s22, s2, s7
    v.splat      v2, s20
    s.add        s2, s22, s21
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a2, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s6, #12
    s.add        s11, s16, s2
    s.movz       s2, #12
    s.addi       s20, s8, #12
    s.add        s22, s4, s7
    v.splat      v3, s20
    s.add        s4, s22, s21
    @p3 v.st.h       [s19, #0], v1
    a.vread      v1, a2, s9
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s9, s6, #13
    s.add        s19, s16, s4
    s.movz       s4, #13
    s.addi       s20, s8, #13
    s.add        s22, s9, s7
    v.splat      v1, s20
    s.add        s9, s22, s21
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a2, s10
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s10, s6, #14
    s.add        s18, s16, s9
    s.movz       s9, #14
    s.addi       s20, s8, #14
    s.add        s22, s10, s7
    v.splat      v5, s20
    s.add        s10, s22, s21
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s6, #15
    s.add        s17, s16, s10
    s.movz       s10, #15
    s.addi       s20, s8, #15
    s.add        s22, s1, s7
    v.splat      v2, s20
    s.add        s1, s22, s21
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a2, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.movz       s2, #0
    s.add        s11, s16, s1
    s.add        s1, s2, s12                     // the tile origin
    s.movz       s2, #0
    s.muli       s20, s12, #2
    v.splat      v3, s1
    v.splat      v6, s8
    @p3 v.st.h       [s19, #0], v1
    a.vread      v1, a2, s4
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s1, #0
    v.add        v1, v0, v3
    s.add        s4, s1, s3                      // the tile origin
    s.add        s1, s7, s20
    v.splat      v3, s4
    s.muli       s4, s6, #1
    s.add        s12, s16, s1
    s.movz       s1, #1
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a2, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    v.cmp.lt     p1, v6, v4
    s.addi       s9, s8, #1
    s.add        s18, s4, s7
    v.splat      v5, s9
    s.add        s4, s18, s20
    s.muli       s9, s6, #2
    s.add        s18, s16, s4
    s.movz       s4, #2
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s10
    v.cmp.lt     p2, v1, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s10, s8, #2
    s.add        s17, s9, s7
    v.splat      v2, s10
    s.add        s9, s17, s20
    s.muli       s10, s6, #3
    s.add        s17, s16, s9
    s.movz       s9, #3
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a3, s2
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s2, s8, #3
    s.add        s11, s10, s7
    v.splat      v1, s2
    s.add        s2, s11, s20
    s.muli       s10, s6, #4
    s.add        s11, s16, s2
    s.movz       s2, #4
    s.addi       s19, s8, #4
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a3, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.add        s1, s10, s7
    v.splat      v3, s19
    s.add        s10, s1, s20
    s.muli       s1, s6, #5
    s.add        s12, s16, s10
    s.movz       s10, #5
    s.addi       s19, s8, #5
    s.add        s21, s1, s7
    @p4 v.st.h       [s18, #0], v2
    a.vread      v2, a3, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s19
    s.add        s1, s21, s20
    s.muli       s4, s6, #6
    s.add        s18, s16, s1
    s.movz       s1, #6
    s.addi       s19, s8, #6
    s.add        s21, s4, s7
    v.splat      v5, s19
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s9
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s21, s20
    s.muli       s9, s6, #7
    s.add        s17, s16, s4
    s.movz       s4, #7
    s.addi       s19, s8, #7
    s.add        s21, s9, s7
    v.splat      v1, s19
    s.add        s9, s21, s20
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a3, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s2, s6, #8
    s.add        s11, s16, s9
    s.movz       s9, #8
    s.addi       s19, s8, #8
    s.add        s21, s2, s7
    v.splat      v3, s19
    s.add        s2, s21, s20
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a3, s10
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s10, s6, #9
    s.add        s12, s16, s2
    s.movz       s2, #9
    s.addi       s19, s8, #9
    s.add        s21, s10, s7
    v.splat      v2, s19
    s.add        s10, s21, s20
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a3, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s1, s6, #10
    s.add        s18, s16, s10
    s.movz       s10, #10
    s.addi       s19, s8, #10
    s.add        s21, s1, s7
    v.splat      v5, s19
    s.add        s1, s21, s20
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s4, s6, #11
    s.add        s17, s16, s1
    s.movz       s1, #11
    s.addi       s19, s8, #11
    s.add        s21, s4, s7
    v.splat      v1, s19
    s.add        s4, s21, s20
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a3, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s9, s6, #12
    s.add        s11, s16, s4
    s.movz       s4, #12
    s.addi       s19, s8, #12
    s.add        s21, s9, s7
    v.splat      v3, s19
    s.add        s9, s21, s20
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a3, s2
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s2, s6, #13
    s.add        s12, s16, s9
    s.movz       s9, #13
    s.addi       s19, s8, #13
    s.add        s21, s2, s7
    v.splat      v2, s19
    s.add        s2, s21, s20
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a3, s10
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s10, s6, #14
    s.add        s18, s16, s2
    s.movz       s2, #14
    s.addi       s19, s8, #14
    s.add        s21, s10, s7
    v.splat      v5, s19
    s.add        s10, s21, s20
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s1, s6, #15
    s.add        s17, s16, s10
    s.movz       s10, #15
    s.addi       s19, s8, #15
    s.add        s21, s1, s7
    v.splat      v1, s19
    s.add        s1, s21, s20
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a3, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.movz       s4, #0
    s.add        s11, s16, s1
    s.add        s1, s4, s5                      // the tile origin
    s.movz       s4, #0
    s.muli       s19, s5, #2
    v.splat      v3, s1
    v.splat      v6, s8
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a3, s9
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s1, #0
    v.add        v2, v0, v3
    s.add        s5, s1, s3                      // the tile origin
    s.add        s1, s7, s19
    v.splat      v3, s5
    s.muli       s5, s6, #1
    s.add        s9, s16, s1
    s.movz       s1, #1
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a3, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    v.cmp.lt     p1, v6, v4
    s.addi       s2, s8, #1
    s.add        s12, s5, s7
    v.splat      v5, s2
    s.add        s2, s12, s19
    s.muli       s5, s6, #2
    s.add        s12, s16, s2
    s.movz       s2, #2
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s10
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s10, s8, #2
    s.add        s17, s5, s7
    v.splat      v1, s10
    s.add        s5, s17, s19
    s.muli       s10, s6, #3
    s.add        s17, s16, s5
    s.movz       s5, #3
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a4, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s4, s8, #3
    s.add        s11, s10, s7
    v.splat      v2, s4
    s.add        s4, s11, s19
    s.muli       s10, s6, #4
    s.add        s11, s16, s4
    s.movz       s4, #4
    s.addi       s18, s8, #4
    @p3 v.st.h       [s9, #0], v3
    a.vread      v3, a4, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s10, s7
    v.splat      v3, s18
    s.add        s9, s1, s19
    s.muli       s1, s6, #5
    s.add        s10, s16, s9
    s.movz       s9, #5
    s.addi       s18, s8, #5
    s.add        s20, s1, s7
    @p4 v.st.h       [s12, #0], v1
    a.vread      v1, a4, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s18
    s.add        s1, s20, s19
    s.muli       s2, s6, #6
    s.add        s12, s16, s1
    s.movz       s1, #6
    s.addi       s18, s8, #6
    s.add        s20, s2, s7
    v.splat      v5, s18
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s2, s20, s19
    s.muli       s5, s6, #7
    s.add        s17, s16, s2
    s.movz       s2, #7
    s.addi       s18, s8, #7
    s.add        s20, s5, s7
    v.splat      v2, s18
    s.add        s5, s20, s19
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a4, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s6, #8
    s.add        s11, s16, s5
    s.movz       s5, #8
    s.addi       s18, s8, #8
    s.add        s20, s4, s7
    v.splat      v3, s18
    s.add        s4, s20, s19
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a4, s9
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s9, s6, #9
    s.add        s10, s16, s4
    s.movz       s4, #9
    s.addi       s18, s8, #9
    s.add        s20, s9, s7
    v.splat      v1, s18
    s.add        s9, s20, s19
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a4, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s1, s6, #10
    s.add        s12, s16, s9
    s.movz       s9, #10
    s.addi       s18, s8, #10
    s.add        s20, s1, s7
    v.splat      v5, s18
    s.add        s1, s20, s19
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s2, s6, #11
    s.add        s17, s16, s1
    s.movz       s1, #11
    s.addi       s18, s8, #11
    s.add        s20, s2, s7
    v.splat      v2, s18
    s.add        s2, s20, s19
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a4, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s5, s6, #12
    s.add        s11, s16, s2
    s.movz       s2, #12
    s.addi       s18, s8, #12
    s.add        s20, s5, s7
    v.splat      v3, s18
    s.add        s5, s20, s19
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a4, s4
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s4, s6, #13
    s.add        s10, s16, s5
    s.movz       s5, #13
    s.addi       s18, s8, #13
    s.add        s20, s4, s7
    v.splat      v1, s18
    s.add        s4, s20, s19
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a4, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s9, s6, #14
    s.add        s12, s16, s4
    s.movz       s4, #14
    s.addi       s18, s8, #14
    s.add        s20, s9, s7
    v.splat      v5, s18
    s.add        s9, s20, s19
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s6, #15
    s.add        s17, s16, s9
    s.movz       s9, #15
    s.addi       s18, s8, #15
    s.add        s20, s1, s7
    v.splat      v2, s18
    s.add        s1, s20, s19
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a4, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.movz       s2, #0
    s.add        s11, s16, s1
    s.add        s1, s2, s13                     // the tile origin
    s.movz       s2, #0
    s.muli       s18, s13, #2
    v.splat      v3, s1
    v.splat      v6, s8
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a4, s5
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s1, #0
    v.add        v1, v0, v3
    s.add        s5, s1, s3                      // the tile origin
    s.add        s1, s7, s18
    v.splat      v3, s5
    s.muli       s5, s6, #1
    s.add        s10, s16, s1
    s.movz       s1, #1
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a4, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    v.cmp.lt     p1, v6, v4
    s.addi       s4, s8, #1
    s.add        s12, s5, s7
    v.splat      v5, s4
    s.add        s4, s12, s18
    s.muli       s5, s6, #2
    s.add        s12, s16, s4
    s.movz       s4, #2
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s9
    v.cmp.lt     p2, v1, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s9, s8, #2
    s.add        s13, s5, s7
    v.splat      v2, s9
    s.add        s5, s13, s18
    s.muli       s9, s6, #3
    s.add        s13, s16, s5
    s.movz       s5, #3
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a5, s2
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s2, s8, #3
    s.add        s11, s9, s7
    v.splat      v1, s2
    s.add        s2, s11, s18
    s.muli       s9, s6, #4
    s.add        s11, s16, s2
    s.movz       s2, #4
    s.addi       s17, s8, #4
    @p3 v.st.h       [s10, #0], v3
    a.vread      v3, a5, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.add        s1, s9, s7
    v.splat      v3, s17
    s.add        s9, s1, s18
    s.muli       s1, s6, #5
    s.add        s10, s16, s9
    s.movz       s9, #5
    s.addi       s17, s8, #5
    s.add        s19, s1, s7
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a5, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s17
    s.add        s1, s19, s18
    s.muli       s4, s6, #6
    s.add        s12, s16, s1
    s.movz       s1, #6
    s.addi       s17, s8, #6
    s.add        s19, s4, s7
    v.splat      v5, s17
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s19, s18
    s.muli       s5, s6, #7
    s.add        s13, s16, s4
    s.movz       s4, #7
    s.addi       s17, s8, #7
    s.add        s19, s5, s7
    v.splat      v1, s17
    s.add        s5, s19, s18
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a5, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s2, s6, #8
    s.add        s11, s16, s5
    s.movz       s5, #8
    s.addi       s17, s8, #8
    s.add        s19, s2, s7
    v.splat      v3, s17
    s.add        s2, s19, s18
    @p3 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s9
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s9, s6, #9
    s.add        s10, s16, s2
    s.movz       s2, #9
    s.addi       s17, s8, #9
    s.add        s19, s9, s7
    v.splat      v2, s17
    s.add        s9, s19, s18
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a5, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s1, s6, #10
    s.add        s12, s16, s9
    s.movz       s9, #10
    s.addi       s17, s8, #10
    s.add        s19, s1, s7
    v.splat      v5, s17
    s.add        s1, s19, s18
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s4, s6, #11
    s.add        s13, s16, s1
    s.movz       s1, #11
    s.addi       s17, s8, #11
    s.add        s19, s4, s7
    v.splat      v1, s17
    s.add        s4, s19, s18
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a5, s5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s5, s6, #12
    s.add        s11, s16, s4
    s.movz       s4, #12
    s.addi       s17, s8, #12
    s.add        s19, s5, s7
    v.splat      v3, s17
    s.add        s5, s19, s18
    @p3 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s2
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s2, s6, #13
    s.add        s10, s16, s5
    s.movz       s5, #13
    s.addi       s17, s8, #13
    s.add        s19, s2, s7
    v.splat      v2, s17
    s.add        s2, s19, s18
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a5, s9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s9, s6, #14
    s.add        s12, s16, s2
    s.movz       s2, #14
    s.addi       s17, s8, #14
    s.add        s19, s9, s7
    v.splat      v5, s17
    s.add        s9, s19, s18
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s1, s6, #15
    s.add        s13, s16, s9
    s.movz       s9, #15
    s.addi       s17, s8, #15
    s.add        s19, s1, s7
    v.splat      v1, s17
    s.add        s1, s19, s18
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a5, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.movz       s4, #0
    s.add        s11, s16, s1
    s.add        s1, s4, s14                     // the tile origin
    s.movz       s4, #0
    s.muli       s17, s14, #2
    v.splat      v3, s1
    v.splat      v6, s8
    @p3 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s5
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s1, #0
    v.add        v2, v0, v3
    s.add        s5, s1, s3                      // the tile origin
    s.add        s1, s7, s17
    v.splat      v3, s5
    s.muli       s5, s6, #1
    s.add        s10, s16, s1
    s.movz       s1, #1
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a5, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    v.cmp.lt     p1, v6, v4
    s.addi       s2, s8, #1
    s.add        s12, s5, s7
    v.splat      v5, s2
    s.add        s2, s12, s17
    s.muli       s5, s6, #2
    s.add        s12, s16, s2
    s.movz       s2, #2
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s9
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s9, s8, #2
    s.add        s13, s5, s7
    v.splat      v1, s9
    s.add        s5, s13, s17
    s.muli       s9, s6, #3
    s.add        s13, s16, s5
    s.movz       s5, #3
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a6, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s4, s8, #3
    s.add        s11, s9, s7
    v.splat      v2, s4
    s.add        s4, s11, s17
    s.muli       s9, s6, #4
    s.add        s11, s16, s4
    s.movz       s4, #4
    s.addi       s14, s8, #4
    @p3 v.st.h       [s10, #0], v3
    a.vread      v3, a6, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s9, s7
    v.splat      v3, s14
    s.add        s9, s1, s17
    s.muli       s1, s6, #5
    s.add        s10, s16, s9
    s.movz       s9, #5
    s.addi       s14, s8, #5
    s.add        s18, s1, s7
    @p4 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s14
    s.add        s1, s18, s17
    s.muli       s2, s6, #6
    s.add        s12, s16, s1
    s.movz       s1, #6
    s.addi       s14, s8, #6
    s.add        s18, s2, s7
    v.splat      v5, s14
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s2, s18, s17
    s.muli       s5, s6, #7
    s.add        s13, s16, s2
    s.movz       s2, #7
    s.addi       s14, s8, #7
    s.add        s18, s5, s7
    v.splat      v2, s14
    s.add        s5, s18, s17
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a6, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s6, #8
    s.add        s11, s16, s5
    s.movz       s5, #8
    s.addi       s14, s8, #8
    s.add        s18, s4, s7
    v.splat      v3, s14
    s.add        s4, s18, s17
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a6, s9
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s9, s6, #9
    s.add        s10, s16, s4
    s.movz       s4, #9
    s.addi       s14, s8, #9
    s.add        s18, s9, s7
    v.splat      v1, s14
    s.add        s9, s18, s17
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a6, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s1, s6, #10
    s.add        s12, s16, s9
    s.movz       s9, #10
    s.addi       s14, s8, #10
    s.add        s18, s1, s7
    v.splat      v5, s14
    s.add        s1, s18, s17
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s2, s6, #11
    s.add        s13, s16, s1
    s.movz       s1, #11
    s.addi       s14, s8, #11
    s.add        s18, s2, s7
    v.splat      v2, s14
    s.add        s2, s18, s17
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a6, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s5, s6, #12
    s.add        s11, s16, s2
    s.movz       s2, #12
    s.addi       s14, s8, #12
    s.add        s18, s5, s7
    v.splat      v3, s14
    s.add        s5, s18, s17
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a6, s4
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s4, s6, #13
    s.add        s10, s16, s5
    s.movz       s5, #13
    s.addi       s14, s8, #13
    s.add        s18, s4, s7
    v.splat      v1, s14
    s.add        s4, s18, s17
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a6, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s9, s6, #14
    s.add        s12, s16, s4
    s.movz       s4, #14
    s.addi       s14, s8, #14
    s.add        s18, s9, s7
    v.splat      v5, s14
    s.add        s9, s18, s17
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s6, #15
    s.add        s13, s16, s9
    s.movz       s9, #15
    s.addi       s14, s8, #15
    s.add        s18, s1, s7
    v.splat      v2, s14
    s.add        s1, s18, s17
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a6, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.movz       s2, #0
    s.add        s11, s16, s1
    s.add        s1, s2, s15                     // the tile origin
    s.movz       s2, #0
    s.muli       s14, s15, #2
    v.splat      v3, s1
    v.splat      v6, s8
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a6, s5
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s1, #0
    v.add        v1, v0, v3
    s.add        s5, s1, s3                      // the tile origin
    s.add        s1, s7, s14
    v.splat      v0, s5
    s.muli       s3, s6, #1
    s.add        s5, s16, s1
    s.movz       s1, #1
    @p4 v.st.h       [s12, #0], v5
    a.vread      v3, a6, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    v.cmp.lt     p1, v6, v4
    s.addi       s4, s8, #1
    s.add        s10, s3, s7
    v.splat      v3, s4
    s.add        s3, s10, s14
    s.muli       s4, s6, #2
    s.add        s10, s16, s3
    s.movz       s3, #2
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s9
    v.cmp.lt     p2, v1, v0
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v2
    s.addi       s9, s8, #2
    s.add        s12, s4, s7
    v.splat      v1, s9
    s.add        s4, s12, s14
    s.muli       s9, s6, #3
    s.add        s12, s16, s4
    s.movz       s4, #3
    @p4 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s2
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.addi       s2, s8, #3
    s.add        s11, s9, s7
    v.splat      v0, s2
    s.add        s2, s11, s14
    s.muli       s9, s6, #4
    s.add        s11, s16, s2
    s.movz       s2, #4
    s.addi       s13, s8, #4
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a7, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s1, s9, s7
    v.splat      v2, s13
    s.add        s5, s1, s14
    s.muli       s1, s6, #5
    s.add        s9, s16, s5
    s.movz       s5, #5
    s.addi       s13, s8, #5
    s.add        s15, s1, s7
    @p4 v.st.h       [s10, #0], v1
    a.vread      v1, a7, s3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    v.splat      v1, s13
    s.add        s1, s15, s14
    s.muli       s3, s6, #6
    s.add        s10, s16, s1
    s.movz       s1, #6
    s.addi       s13, s8, #6
    s.add        s15, s3, s7
    v.splat      v3, s13
    @p3 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s4
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.add        s3, s15, s14
    s.muli       s4, s6, #7
    s.add        s12, s16, s3
    s.movz       s3, #7
    s.addi       s13, s8, #7
    s.add        s15, s4, s7
    v.splat      v0, s13
    s.add        s4, s15, s14
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a7, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s2, s6, #8
    s.add        s11, s16, s4
    s.movz       s4, #8
    s.addi       s13, s8, #8
    s.add        s15, s2, s7
    v.splat      v2, s13
    s.add        s2, s15, s14
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a7, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s5, s6, #9
    s.add        s9, s16, s2
    s.movz       s2, #9
    s.addi       s13, s8, #9
    s.add        s15, s5, s7
    v.splat      v1, s13
    s.add        s5, s15, s14
    @p4 v.st.h       [s10, #0], v3
    a.vread      v3, a7, s1
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v3
    s.muli       s1, s6, #10
    s.add        s10, s16, s5
    s.movz       s5, #10
    s.addi       s13, s8, #10
    s.add        s15, s1, s7
    v.splat      v3, s13
    s.add        s1, s15, s14
    @p3 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s3, s6, #11
    s.add        s12, s16, s1
    s.movz       s1, #11
    s.addi       s13, s8, #11
    s.add        s15, s3, s7
    v.splat      v0, s13
    s.add        s3, s15, s14
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a7, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s4, s6, #12
    s.add        s11, s16, s3
    s.movz       s3, #12
    s.addi       s13, s8, #12
    s.add        s15, s4, s7
    v.splat      v2, s13
    s.add        s4, s15, s14
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a7, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s2, s6, #13
    s.add        s9, s16, s4
    s.movz       s4, #13
    s.addi       s13, s8, #13
    s.add        s15, s2, s7
    v.splat      v1, s13
    s.add        s2, s15, s14
    @p4 v.st.h       [s10, #0], v3
    a.vread      v3, a7, s5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v3
    s.muli       s5, s6, #14
    s.add        s10, s16, s2
    s.movz       s2, #14
    s.addi       s13, s8, #14
    s.add        s15, s5, s7
    v.splat      v3, s13
    s.add        s5, s15, s14
    @p3 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s1, s6, #15
    s.add        s6, s16, s5
    s.movz       s5, #15
    s.addi       s12, s8, #15
    s.add        s8, s1, s7
    v.splat      v0, s12
    s.add        s1, s8, s14
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a7, s3
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s3, s16, s1
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a7, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    @p4 v.st.h       [s10, #0], v2
    a.vread      v1, a7, s2
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a7, s5
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s3, #0], v1
    exit
    exit
