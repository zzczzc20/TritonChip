    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.movi       v0, #0
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #1024
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    s.ld.d       s8, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s9, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    s.movz       s1, #2048
    v.splat      v0, s7
    s.mul        s10, s4, s1
    v.movi       v3, #2
    v.add        v4, v0, v2
    v.movi       v0, #1024
    v.movi       v5, #0
    v.mul        v6, v4, v3
    v.splat      v3, s10
    v.cmp.lt     p1, v4, v0
    s.add        s1, s7, s6
    v.add        v0, v6, v3
    s.movz       s10, #1
    s.movz       s11, #2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s3, v0]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v0, v3
    vf.mul       v3, v0, v0
    vf.add       v0, v1, v3
    @p1 v.sel        v3, v0, v1
    v.mov        v5, v3
    v.mov        v1, v5
    s.mov        s7, s1
    br.nz        s10, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s1, s2, #0
    vf.add       v3, v0, v1
for_3:
    s.cmp.ge     s2, s1, s5
    br.nz        s2, endfor_4
    .li       s2, #1149239296
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #925353388
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #2048
    v.splat      v6, s1
    s.mul        s7, s4, s2
    v.movi       v7, #2
    v.add        v8, v6, v2
    v.movi       v6, #1024
    .li       s2, #1077936128
    v.splat      v9, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v10, v8, v7
    v.splat      v7, s7
    .li       s2, #3204448256
    v.splat      v11, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p1, v8, v6
    v.add        v6, v10, v7
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    s.mul        s7, s4, s5
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v7, [s3, v6]               // index is in elements (ISA sec 9.1)
    s.add        s10, s8, s2                     // &in_ptr1[...]
    s.add        s2, s1, s6
    s.movz       s11, #1
    s.add        s12, s1, s7
    v.splat      v6, s7
    s.shli       s7, s12, #1                     // element offset -> bytes (x2)
    s.movz       s12, #2
    s.add        s12, s9, s7                     // &out_ptr1[...]
    v.add        v10, v8, v6
    vf.fms       v6, v0, v5, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s10, #0]
    vf.cvt.bf16.f32 v1, v7
    vf.fms       v7, v5, v6, v5
    vf.neg       v6, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v7, v6, v5
    vf.cvt.bf16.f32 v5, v0
    vf.mul       v0, v3, v7                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v6, v0, v4
    v.rsqrt.approx v0, v6                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v0, v0
    vf.mul       v7, v0, v11
    vf.fms       v8, v6, v4, v9
    vf.mul       v4, v7, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v6, v4, v0
    v.extract    s7, v6, #0
    v.splat      v0, s7
    vf.mul       v4, v1, v0
    vf.mul       v0, v4, v5
    vf.cvt.f32.bf16 v1, v0
    @p1 v.st.h       [s12, #0], v1
    s.mov        s1, s2
    br.nz        s11, for_3
endfor_4:
__rctx_next:
    exit
