    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #8
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #3
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s8, #0
    s.cmp.lt     s13, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s13
    s.sub        s11, s8, s9
    s.xor        s8, s12, s3
    s.muli       s9, s5, #8
    s.movz       s5, #0
    s.movz       s13, #1
    s.xor        s14, s4, s11
    s.sub        s15, s8, s3
    s.rdspecial  s3, arg_base
    s.xor        s8, s1, s7
    s.movz       s16, #0
    s.sub        s17, s14, s11
    s.addi       s14, s5, #0
    s.cmp.eq     s5, s15, s13
    s.ld.d       s13, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s18, s8, s7
    s.sub        s7, s2, s9
    s.ld.d       s2, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.addi       s7, s16, #0
    s.ld.d       s8, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s14, s17
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s14, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s17, s3
    s.shli       s9, s7, #1
    s.andi       s16, s5, #1
    s.movz       s5, #0
    s.or         s18, s9, s16
    s.movz       s9, #1
    s.cmp.geu    s16, s18, s15
    s.shl        s19, s9, s3
    s.sub        s9, s5, s16
    s.subi       s5, s3, #1
    s.and        s16, s15, s9
    s.and        s20, s19, s9
    s.sub        s9, s18, s16
    s.or         s16, s14, s20
    s.mov        s7, s9
    s.mov        s14, s16
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s3, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s3
    s.movz       s3, #0
    s.sub        s14, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s14
    s.movz       s4, #0
    s.sub        s15, s9, s14
    s.cmp.lt     s9, s12, s3
    s.lshri      s3, s15, #3
    s.movz       s16, #0
    s.muli       s17, s3, #8
    s.movz       s3, #0
    s.sub        s18, s4, s9
    s.movz       s4, #0
    s.cmp.lt     s9, s1, s16
    s.sub        s16, s15, s17
    s.xor        s15, s12, s18
    s.xor        s12, s16, s14
    s.xor        s16, s7, s11
    s.sub        s7, s12, s14
    s.sub        s12, s4, s9
    s.cmp.lt     s4, s7, s5
    s.sub        s5, s15, s18
    s.sub        s9, s3, s4
    s.movz       s3, #0
    s.xor        s4, s7, s9
    s.movz       s7, #1
    s.sub        s14, s16, s11
    s.xor        s11, s1, s12
    s.sub        s15, s4, s9
    s.movz       s4, #0
    s.addi       s16, s3, #0
    s.cmp.eq     s3, s5, s7
    s.add        s7, s10, s14
    s.sub        s10, s11, s12
    s.addi       s10, s4, #0
    s.mov        s16, s15
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s16, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s15, s3
    s.shli       s11, s10, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s14, s11, s12
    s.movz       s11, #1
    s.cmp.geu    s12, s14, s5
    s.shl        s17, s11, s3
    s.sub        s11, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s11
    s.and        s19, s17, s11
    s.sub        s11, s14, s12
    s.or         s12, s16, s19
    s.mov        s10, s11
    s.mov        s16, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s11, s3, s4
    br.nz        s11, sdiv_4
sdiv_done_3:
    s.xor        s3, s9, s18
    s.movz       s4, #16
    s.xor        s5, s16, s3
    s.mul        s9, s7, s4
    s.sub        s10, s5, s3
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s3, s10, s4
    s.movz       s5, #0
    v.splat      v1, s9
    v.movi       v2, #13
    v.add        v3, v1, v0
    v.movi       v1, #0
    v.splat      v4, s7
    v.splat      v5, s5
    v.splat      v6, s10
    v.splat      v7, s5
    v.splat      v8, s3
    v.sub        v9, v1, v3
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v2, v1
    v.cmp.ge     p3, v4, v5
    v.sub        v4, v1, v2
    v.cmp.ge     p3, v6, v7
    v.add        v5, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v3
    @p2 v.sel        v3, v4, v2
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s7, #31
idiv_5:
    v.splat      v6, s7
    v.shl        v7, v4, v0
    v.lshr       v8, v5, v6
    v.cmp.lt     p2, v4, v1
    v.and        v9, v8, v0
    v.shl        v8, v0, v6
    v.or         v6, v7, v9
    s.subi       s10, s7, #1
    v.cmp.geu    p3, v6, v3
    p.or         p4, p2, p3
    v.sub        v7, v6, v3
    @p4 v.sel        v9, v8, v1
    @p4 v.sel        v8, v7, v6
    v.or         v6, v2, v9
    v.mov        v4, v8
    v.mov        v2, v6
    s.mov        s7, s10
    s.movz       s10, #0
    s.cmp.ge     s11, s7, s10
    br.nz        s11, idiv_5
    s.rdspecial  s7, pid.z
    s.rdspecial  s10, npid.y
    s.rdspecial  s11, pid.y
    s.mul        s12, s7, s10
    s.movz       s7, #15
    v.sub        v0, v1, v4
    s.movz       s10, #169
    @p1 v.sel        v1, v0, v4
    s.add        s14, s11, s12
    s.rdspecial  s11, role_id
    s.min.s      s12, s14, s7
    s.movz       s15, #1024
    s.mul        s16, s12, s10
    s.movz       s10, #13
    s.rdspecial  s17, arg_base
    s.mul        s18, s11, s15
    v.extract    s11, v1, #0
    v.extract    s15, v1, #1
    v.extract    s19, v1, #2
    v.splat      v0, s11
    v.splat      v2, s10
    s.movz       s11, #0
    v.splat      v3, s15
    v.splat      v4, s19
    s.ld.d       s15, [s17, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.mul        v5, v0, v2
    v.iota       v0                              // arange(0, VLEN)
    s.add        s17, s11, s16                   // the tile origin
    v.mul        v6, v3, v2
    v.mul        v3, v4, v2
    s.add        s11, s15, s18                   // this context's own scratch
    v.add        v4, v5, v0
    v.splat      v5, s17
    v.add        v7, v6, v0
    v.add        v6, v3, v0
    s.addi       s15, s11, #0
    v.splat      v3, s5
    v.add        v8, v4, v5
    v.add        v4, v7, v5
    v.add        v7, v6, v5
    v.add        v6, v3, v8
    s.addi       s16, s15, #64
    v.add        v8, v3, v4
    s.addi       s17, s15, #128
    v.st.w       [s15, #0], v6
    s.andi       s18, s3, #127
    v.add        v4, v3, v7
    v.splat      v6, s18
    v.iota       v7                              // arange(0, VLEN)
    s.addi       s19, s15, #192
    v.add        v9, v6, v7
    v.extract    s20, v1, #3
    v.extract    s21, v1, #4
    v.extract    s22, v1, #5
    v.extract    s23, v1, #6
    v.extract    s24, v1, #7
    v.splat      v6, s20
    v.splat      v7, s21
    v.splat      v9, s22
    v.splat      v10, s23
    v.mul        v11, v6, v2
    v.mul        v6, v7, v2
    v.mul        v7, v9, v2
    v.mul        v9, v10, v2
    v.add        v10, v11, v0
    v.add        v11, v6, v0
    v.add        v6, v7, v0
    v.add        v7, v9, v0
    v.add        v9, v10, v5
    v.add        v10, v11, v5
    v.add        v11, v6, v5
    v.add        v6, v7, v5
    v.add        v7, v3, v9
    s.addi       s20, s15, #256
    v.add        v9, v3, v10
    s.addi       s21, s15, #320
    v.add        v10, v3, v11
    s.addi       s22, s15, #384
    v.add        v11, v3, v6
    s.addi       s23, s15, #448
    v.st.w       [s16, #0], v8
    v.extract    s16, v1, #8
    v.splat      v6, s24
    s.addi       s24, s15, #512
    v.mul        v8, v6, v2
    v.add        v6, v8, v0
    v.add        v8, v6, v5
    v.add        v6, v3, v8
    v.st.w       [s17, #0], v4
    v.extract    s17, v1, #9
    v.splat      v4, s16
    s.addi       s16, s15, #576
    v.mul        v8, v4, v2
    v.add        v4, v8, v0
    v.add        v8, v4, v5
    v.add        v4, v3, v8
    v.st.w       [s19, #0], v7
    v.extract    s19, v1, #10
    v.splat      v7, s17
    s.addi       s17, s15, #640
    v.mul        v8, v7, v2
    v.add        v7, v8, v0
    v.add        v8, v7, v5
    v.add        v7, v3, v8
    v.st.w       [s20, #0], v9
    v.extract    s20, v1, #11
    v.splat      v8, s19
    s.addi       s19, s15, #704
    v.mul        v9, v8, v2
    v.add        v8, v9, v0
    v.add        v9, v8, v5
    v.add        v8, v3, v9
    v.st.w       [s21, #0], v10
    v.extract    s21, v1, #12
    v.splat      v9, s20
    s.addi       s20, s15, #768
    v.mul        v10, v9, v2
    v.add        v9, v10, v0
    v.add        v10, v9, v5
    v.add        v9, v3, v10
    v.st.w       [s22, #0], v11
    v.extract    s22, v1, #13
    v.splat      v10, s21
    s.addi       s21, s15, #832
    v.mul        v11, v10, v2
    v.add        v10, v11, v0
    v.add        v11, v10, v5
    v.add        v10, v3, v11
    v.st.w       [s23, #0], v6
    v.extract    s23, v1, #14
    v.splat      v6, s22
    s.addi       s22, s15, #896
    v.mul        v11, v6, v2
    v.add        v6, v11, v0
    v.add        v11, v6, v5
    v.add        v6, v3, v11
    v.st.w       [s24, #0], v4
    v.extract    s24, v1, #15
    v.splat      v1, s23
    v.splat      v4, s24
    v.mul        v11, v1, v2
    v.mul        v1, v4, v2
    v.add        v4, v11, v0
    v.add        v11, v1, v0
    v.add        v1, v4, v5
    v.add        v4, v11, v5
    v.add        v5, v3, v1
    s.addi       s23, s15, #960
    v.add        v1, v3, v4
    v.st.w       [s16, #0], v7
    s.addi       s15, s11, #0
    v.splat      v3, s10
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s16, #0
    s.movz       s24, #1664
    s.mul        s25, s12, s24
    v.st.w       [s17, #0], v8
    v.cmp.lt     p1, v0, v3
    s.addi       s12, s11, #64
    s.movz       s17, #1
    v.st.w       [s19, #0], v9
    s.addi       s19, s11, #128
    s.movz       s26, #2
    s.addi       s27, s11, #192
    s.movz       s28, #3
    v.st.w       [s20, #0], v10
    s.addi       s20, s11, #256
    s.movz       s29, #4
    v.st.w       [s21, #0], v6
    s.addi       s21, s11, #320
    v.st.w       [s22, #0], v5
    s.movz       s22, #5
    v.st.w       [s23, #0], v1
    fence.acq_rel.device
    s.addi       s23, s11, #384
    v.ld.w       v1, [s15, #0]
    s.movz       s15, #6
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s16, v3
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s11, #448
    s.movz       s16, #7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s17, v3
    v.ld.w       v1, [s19, #0]
    s.addi       s17, s11, #512
    s.movz       s19, #8
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s26, v3
    v.ld.w       v1, [s27, #0]
    s.addi       s26, s11, #576
    s.movz       s27, #9
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s28, v3
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s11, #640
    s.movz       s28, #10
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s29, v3
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s11, #704
    s.movz       s29, #11
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s22, v3
    v.ld.w       v1, [s23, #0]
    s.addi       s22, s11, #768
    s.movz       s23, #12
    s.muli       s30, s18, #4                    // a runtime tile origin, x4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    s.add        s18, s2, s30                    // the tile origin
    s.addi       s2, s11, #832
    a.vwrite     a0, s15, v3
    v.ld.w       v1, [s12, #0]
    s.movz       s12, #13
    s.addi       s15, s11, #896
    s.addi       s30, s11, #960
    s.muli       s11, s25, #4                    // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    v.movi       v3, #0
    s.add        s25, s18, s11                   // the tile origin
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v1]              // index is in elements (ISA sec 9.1)
    s.movz       s11, #14
    a.vwrite     a0, s16, v4
    v.ld.w       v1, [s17, #0]
    v.splat      v4, s5
    s.movz       s16, #15
    s.movz       s17, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s13, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v2
    a.vwrite     a0, s19, v5
    v.ld.w       v1, [s26, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s18, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v1]              // index is in elements (ISA sec 9.1)
    s.addi       s19, s25, #512                  // row 1
    a.vwrite     a0, s27, v4
    v.ld.w       v1, [s20, #0]
    v.splat      v4, s6
    v.cmp.lt     p3, v4, v2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s28, v4
    v.ld.w       v1, [s21, #0]
    s.movz       s20, #2
    s.addi       s21, s25, #1024                 // row 2
    v.splat      v4, s20
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s13, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v4, v2
    a.vwrite     a0, s29, v5
    v.ld.w       v1, [s22, #0]
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v1]              // index is in elements (ISA sec 9.1)
    s.addi       s22, s25, #1536                 // row 3
    a.vwrite     a0, s23, v4
    v.ld.w       v1, [s2, #0]
    s.movz       s2, #3
    v.splat      v4, s2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s12, v5
    v.ld.w       v1, [s15, #0]
    s.movz       s12, #4
    s.addi       s15, s25, #2048                 // row 4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s13, v1]              // index is in elements (ISA sec 9.1)
    v.splat      v1, s12
    a.vwrite     a0, s11, v5
    v.ld.w       v5, [s30, #0]
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s13, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v2
    a.vwrite     a0, s16, v6
    a.vread      v4, a0, s17
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s11, v4, #0
    v.splat      v6, s11
    v.extract    s11, v4, #1
    v.splat      v7, s11
    v.extract    s11, v4, #2
    v.cmp.lt     p2, v1, v2
    s.movz       s13, #5
    v.splat      v1, s11
    v.splat      v8, s13
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s19, #0]
    vf.fma       v10, v6, v5, v3
    s.addi       s11, s25, #2560                 // row 5
    v.extract    s16, v4, #3
    v.cmp.lt     p3, v8, v2
    s.movz       s17, #6
    v.splat      v5, s16
    v.splat      v6, s17
    s.addi       s16, s25, #3072                 // row 6
    v.extract    s19, v4, #4
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s21, #0]
    vf.fma       v11, v7, v9, v10
    v.cmp.lt     p4, v6, v2
    s.movz       s21, #7
    v.splat      v6, s19
    v.splat      v7, s21
    s.addi       s19, s25, #3584                 // row 7
    v.extract    s23, v4, #5
    v.splat      v9, s23
    s.addi       s23, s25, #4096                 // row 8
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s1
    v.extract    s22, v4, #6
    s.movz       s26, #9
    v.splat      v8, s22
    s.addi       s22, s25, #4608                 // row 9
    v.extract    s27, v4, #7
    v.extract    s28, v4, #8
    v.extract    s29, v4, #9
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s15, #0]
    v.cmp.lt     p2, v7, v2
    v.splat      v5, s26
    s.movz       s15, #10
    v.splat      v7, s27
    s.addi       s27, s25, #5120                 // row 10
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s11, #0]
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s15
    s.movz       s11, #11
    v.splat      v6, s28
    s.addi       s28, s25, #5632                 // row 11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s16, #0]
    v.cmp.lt     p4, v5, v2
    v.splat      v5, s11
    s.movz       s16, #12
    v.splat      v9, s29
    s.addi       s29, s25, #6144                 // row 12
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s16
    v.extract    s19, v4, #10
    v.splat      v8, s19
    s.addi       s19, s25, #6656                 // row 13
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s23, #0]
    v.cmp.lt     p2, v5, v2
    v.splat      v5, s10
    v.extract    s23, v4, #11
    v.splat      v7, s23
    s.movz       s23, #14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s22, #0]
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s23
    s.addi       s22, s25, #7168                 // row 14
    v.splat      v6, s7
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #12
    v.cmp.lt     p4, v5, v2
    v.splat      v5, s27
    s.addi       s27, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #13
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s28
    v.extract    s28, v4, #14
    v.splat      v8, s28
    v.extract    s28, v4, #15
    v.splat      v4, s28
    s.movz       s28, #1
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s29, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v7, s6
    s.addi       s29, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v7, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v5, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s22, #0]
    vf.fma       v11, v6, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s22, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s27, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v5, v2
    s.addi       s27, s25, #2048                 // row 4
    v.splat      v5, s13
    vf.fma       v7, v4, v6, v9
    a.vwrite     a1, s18, v7
    a.vread      v4, a0, s28
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s25, #0]
    v.extract    s18, v4, #0
    v.splat      v7, s18
    v.extract    s18, v4, #1
    v.splat      v8, s18
    v.extract    s18, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s18
    s.addi       s18, s25, #2560                 // row 5
    v.extract    s28, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s29, #0]
    vf.fma       v10, v7, v6, v3
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s28
    v.splat      v6, s17
    s.addi       s28, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #1
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    s.addi       s22, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s27, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s18
    s.addi       s18, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s28
    s.addi       s28, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s22
    s.addi       s22, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s27
    s.addi       s27, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s18
    s.addi       s18, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s28
    v.extract    s28, v4, #14
    v.splat      v8, s28
    v.extract    s28, v4, #15
    v.splat      v4, s28
    s.movz       s28, #2
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s22, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s22, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s27, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s27, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s18, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s18, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s28
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s28, v4, #0
    v.splat      v7, s28
    v.extract    s28, v4, #1
    v.splat      v8, s28
    v.extract    s28, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s28
    s.addi       s28, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s22, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s22, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #2
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s27, #0]
    s.addi       s27, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s18, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s18, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s28
    s.addi       s28, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s22
    s.addi       s22, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s27
    s.addi       s27, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s18
    s.addi       s18, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s28
    s.addi       s28, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s22
    v.extract    s22, v4, #14
    v.splat      v8, s22
    v.extract    s22, v4, #15
    v.splat      v4, s22
    s.movz       s22, #3
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s27, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s18, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s18, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s28, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s28, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s22
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s22, v4, #0
    v.splat      v7, s22
    v.extract    s22, v4, #1
    v.splat      v8, s22
    v.extract    s22, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s22
    s.addi       s22, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s27, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s27, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #3
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s18, #0]
    s.addi       s18, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s28, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s28, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s22
    s.addi       s22, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s27
    s.addi       s27, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s18
    s.addi       s18, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s28
    s.addi       s28, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s22
    s.addi       s22, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s27
    v.extract    s27, v4, #14
    v.splat      v8, s27
    v.extract    s27, v4, #15
    v.splat      v4, s27
    s.movz       s27, #4
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s18, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s18, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s28, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s28, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s22, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s22, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s27
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s27, v4, #0
    v.splat      v7, s27
    v.extract    s27, v4, #1
    v.splat      v8, s27
    v.extract    s27, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s27
    s.addi       s27, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s18, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s18, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #4
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s28, #0]
    s.addi       s28, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s22, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s22, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s27
    s.addi       s27, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s18
    s.addi       s18, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s28
    s.addi       s28, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s22
    s.addi       s22, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s27
    s.addi       s27, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s18
    v.extract    s18, v4, #14
    v.splat      v8, s18
    v.extract    s18, v4, #15
    v.splat      v4, s18
    s.movz       s18, #5
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s28, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s28, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s22, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s22, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s27, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s27, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s18
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s18, v4, #0
    v.splat      v7, s18
    v.extract    s18, v4, #1
    v.splat      v8, s18
    v.extract    s18, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s18
    s.addi       s18, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s28, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s28, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #5
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    s.addi       s22, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s27, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s18
    s.addi       s18, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s28
    s.addi       s28, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s22
    s.addi       s22, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s27
    s.addi       s27, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s18
    s.addi       s18, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s28
    v.extract    s28, v4, #14
    v.splat      v8, s28
    v.extract    s28, v4, #15
    v.splat      v4, s28
    s.movz       s28, #6
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s22, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s22, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s27, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s27, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s18, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s18, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s28
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s28, v4, #0
    v.splat      v7, s28
    v.extract    s28, v4, #1
    v.splat      v8, s28
    v.extract    s28, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s28
    s.addi       s28, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s22, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s22, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #6
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s27, #0]
    s.addi       s27, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s18, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s18, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s28
    s.addi       s28, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s22
    s.addi       s22, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s27
    s.addi       s27, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s18
    s.addi       s18, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s28
    s.addi       s28, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s22
    v.extract    s22, v4, #14
    v.splat      v8, s22
    v.extract    s22, v4, #15
    v.splat      v4, s22
    s.movz       s22, #7
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s27, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s18, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s18, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s28, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s28, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s22
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s22, v4, #0
    v.splat      v7, s22
    v.extract    s22, v4, #1
    v.splat      v8, s22
    v.extract    s22, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s22
    s.addi       s22, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s27, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s27, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #7
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s18, #0]
    s.addi       s18, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s28, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s28, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s22
    s.addi       s22, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s27
    s.addi       s27, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s18
    s.addi       s18, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s28
    s.addi       s28, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s22
    s.addi       s22, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s27
    v.extract    s27, v4, #14
    v.splat      v8, s27
    v.extract    s27, v4, #15
    v.splat      v4, s27
    s.movz       s27, #8
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s18, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s18, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s28, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s28, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s22, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s22, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s27
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s27, v4, #0
    v.splat      v7, s27
    v.extract    s27, v4, #1
    v.splat      v8, s27
    v.extract    s27, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s27
    s.addi       s27, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s18, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s18, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s28, #0]
    s.addi       s28, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s22, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s22, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s27
    s.addi       s27, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s18
    s.addi       s18, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s28
    s.addi       s28, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s22
    s.addi       s22, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s27
    s.addi       s27, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s18
    v.extract    s18, v4, #14
    v.splat      v8, s18
    v.extract    s18, v4, #15
    v.splat      v4, s18
    s.movz       s18, #9
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s28, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s28, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s22, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s22, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s27, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s27, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s18
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s18, v4, #0
    v.splat      v7, s18
    v.extract    s18, v4, #1
    v.splat      v8, s18
    v.extract    s18, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s18
    s.addi       s18, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s28, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s28, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #9
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    s.addi       s22, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s27, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s18
    s.addi       s18, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s28
    s.addi       s28, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s22
    s.addi       s22, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s27
    s.addi       s27, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s18
    s.addi       s18, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s28
    v.extract    s28, v4, #14
    v.splat      v8, s28
    v.extract    s28, v4, #15
    v.splat      v4, s28
    s.movz       s28, #10
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s22, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s22, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s27, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s27, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s18, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s18, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s28
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s28, v4, #0
    v.splat      v7, s28
    v.extract    s28, v4, #1
    v.splat      v8, s28
    v.extract    s28, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s28
    s.addi       s28, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s22, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s22, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #10
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s27, #0]
    s.addi       s27, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s18, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s18, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s28
    s.addi       s28, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s22
    s.addi       s22, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s27
    s.addi       s27, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s18
    s.addi       s18, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s28
    s.addi       s28, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s22
    v.extract    s22, v4, #14
    v.splat      v8, s22
    v.extract    s22, v4, #15
    v.splat      v4, s22
    s.movz       s22, #11
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s27, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s18, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s18, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s28, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s28, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s22
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s22, v4, #0
    v.splat      v7, s22
    v.extract    s22, v4, #1
    v.splat      v8, s22
    v.extract    s22, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s22
    s.addi       s22, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s27, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s27, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #11
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s18, #0]
    s.addi       s18, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s28, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s28, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s22
    s.addi       s22, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s27
    s.addi       s27, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s18
    s.addi       s18, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s28
    s.addi       s28, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s22
    s.addi       s22, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s27
    v.extract    s27, v4, #14
    v.splat      v8, s27
    v.extract    s27, v4, #15
    v.splat      v4, s27
    s.movz       s27, #12
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s18, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s18, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s28, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s28, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s22, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s22, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s27
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s27, v4, #0
    v.splat      v7, s27
    v.extract    s27, v4, #1
    v.splat      v8, s27
    v.extract    s27, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s27
    s.addi       s27, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s18, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s18, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #12
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s28, #0]
    s.addi       s28, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s22, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s22, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s27
    s.addi       s27, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s18
    s.addi       s18, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s28
    s.addi       s28, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s22
    s.addi       s22, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s27
    s.addi       s27, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s18
    v.extract    s18, v4, #14
    v.splat      v8, s18
    v.extract    s18, v4, #15
    v.splat      v4, s18
    s.movz       s18, #13
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s28, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s28, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s22, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s22, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s27, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s27, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s18
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s18, v4, #0
    v.splat      v7, s18
    v.extract    s18, v4, #1
    v.splat      v8, s18
    v.extract    s18, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s18
    s.addi       s18, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s28, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s28, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #13
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    s.addi       s22, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s27, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s18
    s.addi       s18, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s28
    s.addi       s28, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s22
    s.addi       s22, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s27
    s.addi       s27, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s18
    s.addi       s18, s25, #7680                 // row 15
    v.splat      v9, s5
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #13
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s28
    v.extract    s28, v4, #14
    v.splat      v8, s28
    v.extract    s28, v4, #15
    v.splat      v4, s28
    s.movz       s28, #14
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s22, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    s.addi       s22, s25, #512                  // row 1
    v.splat      v9, s20
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s19, s25, #1024                 // row 2
    v.splat      v6, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s27, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    s.addi       s27, s25, #1536                 // row 3
    v.splat      v1, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s18, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    s.addi       s18, s25, #2048                 // row 4
    v.splat      v6, s13
    vf.fma       v7, v4, v5, v9
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s28
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s28, v4, #0
    v.splat      v7, s28
    v.extract    s28, v4, #1
    v.splat      v8, s28
    v.extract    s28, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s28
    s.addi       s28, s25, #2560                 // row 5
    v.extract    s29, v4, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s22, #0]
    vf.fma       v10, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v5, s29
    v.splat      v6, s17
    s.addi       s22, s25, #3072                 // row 6
    v.extract    s29, v4, #4
    v.splat      v7, s29
    v.extract    s29, v4, #5
    vf.fma       v11, v8, v9, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.splat      v9, s29
    v.extract    s19, v4, #6
    s.movz       s29, #14
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s21
    vf.fma       v10, v1, v8, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s27, #0]
    s.addi       s27, s25, #3584                 // row 7
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v8, s19
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s18, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v5, s26
    s.addi       s18, s25, #4608                 // row 9
    v.splat      v6, s15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #7
    v.cmp.lt     p3, v5, v2
    v.splat      v5, s28
    s.addi       s28, s25, #5120                 // row 10
    v.splat      v7, s11
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s22, #0]
    v.extract    s22, v4, #8
    v.cmp.lt     p4, v6, v2
    v.splat      v6, s22
    s.addi       s22, s25, #5632                 // row 11
    v.splat      v9, s16
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s27, #0]
    v.extract    s27, v4, #9
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s27
    s.addi       s27, s25, #6144                 // row 12
    v.splat      v8, s10
    vf.fma       v11, v5, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.extract    s19, v4, #10
    v.cmp.lt     p2, v9, v2
    v.splat      v5, s19
    s.addi       s19, s25, #6656                 // row 13
    v.splat      v9, s23
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s18, #0]
    v.extract    s18, v4, #11
    v.cmp.lt     p3, v8, v2
    v.splat      v6, s18
    s.addi       s18, s25, #7168                 // row 14
    v.splat      v8, s7
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s28, #0]
    v.extract    s28, v4, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v7, s28
    s.addi       s28, s25, #7680                 // row 15
    v.splat      v9, s5
    v.extract    s5, v4, #13
    vf.fma       v10, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s22, #0]
    v.cmp.lt     p1, v8, v2
    v.splat      v5, s5
    v.extract    s5, v4, #14
    v.splat      v8, s5
    v.extract    s5, v4, #15
    v.splat      v4, s5
    s.movz       s5, #15
    s.addi       s22, s25, #512                  // row 1
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p2, v9, v2
    v.splat      v6, s6
    v.splat      v9, s20
    s.addi       s6, s25, #1024                  // row 2
    s.movz       s20, #15
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p3, v6, v2
    v.splat      v6, s2
    s.addi       s2, s25, #1536                  // row 3
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s18, #0]
    vf.fma       v11, v5, v1, v10
    v.cmp.lt     p4, v9, v2
    v.splat      v1, s12
    s.addi       s12, s25, #2048                 // row 4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s28, #0]
    vf.fma       v9, v8, v7, v11
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s13
    s.addi       s13, s25, #2560                 // row 5
    vf.fma       v7, v4, v5, v9
    s.addi       s18, s25, #3072                 // row 6
    a.vwrite     a1, s29, v7
    a.vread      v4, a0, s5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s25, #0]
    v.extract    s5, v4, #0
    v.splat      v7, s5
    v.extract    s5, v4, #1
    v.splat      v8, s5
    v.extract    s5, v4, #2
    v.cmp.lt     p2, v1, v2
    v.splat      v1, s5
    v.extract    s5, v4, #3
    v.splat      v9, s5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s22, #0]
    vf.fma       v11, v7, v5, v3
    v.cmp.lt     p3, v6, v2
    v.splat      v3, s17
    v.extract    s5, v4, #4
    v.splat      v5, s5
    v.splat      v6, s21
    s.addi       s5, s25, #3584                  // row 7
    v.extract    s17, v4, #5
    s.addi       s19, s25, #4096                 // row 8
    vf.fma       v7, v8, v10, v11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s6, #0]
    v.cmp.lt     p4, v3, v2
    v.splat      v3, s17
    v.splat      v10, s1
    v.extract    s1, v4, #6
    s.addi       s6, s25, #4608                  // row 9
    v.extract    s17, v4, #7
    v.extract    s21, v4, #8
    v.extract    s22, v4, #9
    vf.fma       v11, v1, v8, v7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s2, #0]
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s1
    v.splat      v7, s26
    s.addi       s1, s25, #5120                  // row 10
    v.extract    s2, v4, #10
    vf.fma       v8, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p2, v10, v2
    v.splat      v9, s17
    v.splat      v10, s15
    s.addi       s12, s25, #5632                 // row 11
    v.extract    s15, v4, #11
    vf.fma       v11, v5, v1, v8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s13, #0]
    v.cmp.lt     p3, v7, v2
    v.splat      v5, s21
    v.splat      v7, s11
    s.addi       s11, s25, #6144                 // row 12
    v.extract    s13, v4, #12
    vf.fma       v8, v3, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s18, #0]
    v.cmp.lt     p4, v10, v2
    v.splat      v3, s22
    v.splat      v10, s16
    s.addi       s16, s25, #6656                 // row 13
    v.extract    s17, v4, #13
    vf.fma       v11, v6, v1, v8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s5, #0]
    v.cmp.lt     p1, v7, v2
    v.splat      v6, s2
    v.splat      v7, s10
    s.addi       s2, s25, #7168                  // row 14
    v.extract    s5, v4, #14
    vf.fma       v8, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p2, v10, v2
    v.splat      v9, s15
    v.splat      v10, s23
    s.addi       s10, s25, #7680                 // row 15
    v.extract    s15, v4, #15
    v.splat      v4, s13
    vf.fma       v11, v5, v1, v8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s6, #0]
    v.cmp.lt     p3, v7, v2
    v.splat      v5, s7
    v.splat      v7, s17
    vf.fma       v8, v3, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s1, #0]
    v.cmp.lt     p4, v10, v2
    v.splat      v3, s5
    v.splat      v10, s15
    s.mul        s1, s14, s24
    s.muli       s5, s3, #4                      // a runtime tile origin, x4
    s.muli       s6, s9, #512                    // a runtime tile origin, x512
    s.muli       s7, s1, #4                      // a runtime tile origin, x4
    vf.fma       v11, v6, v1, v8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p1, v5, v2
    s.movz       s1, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s12, #0
    s.add        s13, s1, s9                     // the tile origin
    v.movi       v5, #0
    v.splat      v6, s13
    s.add        s1, s8, s5                      // the tile origin
    s.add        s5, s1, s6                      // the tile origin
    vf.fma       v8, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s11, #0]
    s.movz       s1, #0
    s.movz       s6, #128
    s.add        s8, s1, s3                      // the tile origin
    v.splat      v9, s6
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s8
    s.add        s1, s5, s7                      // the tile origin
    v.add        v11, v0, v6
    v.splat      v0, s14
    vf.fma       v6, v4, v1, v8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s16, #0]
    v.splat      v4, s4
    v.cmp.lt     p3, v11, v9
    p.and        p5, p2, p3
    s.movz       s3, #1
    s.addi       s4, s1, #512                    // row 1
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s2, #0]
    vf.fma       v9, v7, v1, v6
    v.cmp.lt     p2, v0, v4
    s.addi       s2, s13, #1
    p.and        p4, p5, p2
    v.splat      v0, s2
    s.movz       s2, #2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s10, #0]
    vf.fma       v4, v3, v8, v9
    v.cmp.lt     p1, v0, v2
    p.and        p5, p1, p3
    s.addi       s5, s13, #2
    p.and        p1, p5, p2
    v.splat      v0, s5
    s.addi       s5, s1, #1024                   // row 2
    vf.fma       v3, v10, v1, v4
    a.vwrite     a1, s20, v3
    a.vread      v1, a1, s12
    s.addi       s6, s13, #3
    vf.add       v3, v1, v5
    s.movz       s7, #3
    v.splat      v1, s6
    s.addi       s6, s13, #4
    @p4 v.st.w       [s1, #0], v3
    a.vread      v3, a1, s3
    v.cmp.lt     p4, v0, v2
    vf.add       v0, v3, v5
    p.and        p5, p4, p3
    s.addi       s3, s1, #1536                   // row 3
    p.and        p4, p5, p2
    s.movz       s8, #4
    v.splat      v3, s6
    s.addi       s6, s13, #5
    @p1 v.st.w       [s4, #0], v0
    a.vread      v0, a1, s2
    v.cmp.lt     p1, v1, v2
    vf.add       v1, v0, v5
    p.and        p5, p1, p3
    s.addi       s2, s1, #2048                   // row 4
    p.and        p1, p5, p2
    s.movz       s4, #5
    v.splat      v0, s6
    s.addi       s6, s13, #6
    @p4 v.st.w       [s5, #0], v1
    a.vread      v1, a1, s7
    v.cmp.lt     p4, v3, v2
    vf.add       v3, v1, v5
    p.and        p5, p4, p3
    s.addi       s5, s1, #2560                   // row 5
    p.and        p4, p5, p2
    s.movz       s7, #6
    v.splat      v1, s6
    s.addi       s6, s13, #7
    @p1 v.st.w       [s3, #0], v3
    a.vread      v3, a1, s8
    v.cmp.lt     p1, v0, v2
    vf.add       v0, v3, v5
    p.and        p5, p1, p3
    s.addi       s3, s1, #3072                   // row 6
    p.and        p1, p5, p2
    s.movz       s8, #7
    v.splat      v3, s6
    s.addi       s6, s13, #8
    @p4 v.st.w       [s2, #0], v0
    a.vread      v0, a1, s4
    v.cmp.lt     p4, v1, v2
    vf.add       v1, v0, v5
    p.and        p5, p4, p3
    s.addi       s2, s1, #3584                   // row 7
    p.and        p4, p5, p2
    s.movz       s4, #8
    v.splat      v0, s6
    s.addi       s6, s13, #9
    @p1 v.st.w       [s5, #0], v1
    a.vread      v1, a1, s7
    v.cmp.lt     p1, v3, v2
    vf.add       v3, v1, v5
    p.and        p5, p1, p3
    s.addi       s5, s1, #4096                   // row 8
    p.and        p1, p5, p2
    s.movz       s7, #9
    v.splat      v1, s6
    s.addi       s6, s13, #10
    @p4 v.st.w       [s3, #0], v3
    a.vread      v3, a1, s8
    v.cmp.lt     p4, v0, v2
    vf.add       v0, v3, v5
    p.and        p5, p4, p3
    s.addi       s3, s1, #4608                   // row 9
    p.and        p4, p5, p2
    s.movz       s8, #10
    v.splat      v3, s6
    s.addi       s6, s13, #11
    @p1 v.st.w       [s2, #0], v0
    a.vread      v0, a1, s4
    v.cmp.lt     p1, v1, v2
    vf.add       v1, v0, v5
    p.and        p5, p1, p3
    s.addi       s2, s1, #5120                   // row 10
    p.and        p1, p5, p2
    s.movz       s4, #11
    v.splat      v0, s6
    s.addi       s6, s13, #12
    @p4 v.st.w       [s5, #0], v1
    a.vread      v1, a1, s7
    v.cmp.lt     p4, v3, v2
    vf.add       v3, v1, v5
    p.and        p5, p4, p3
    s.addi       s5, s1, #5632                   // row 11
    p.and        p4, p5, p2
    s.movz       s7, #12
    v.splat      v1, s6
    s.addi       s6, s13, #13
    @p1 v.st.w       [s3, #0], v3
    a.vread      v3, a1, s8
    v.cmp.lt     p1, v0, v2
    vf.add       v0, v3, v5
    p.and        p5, p1, p3
    s.addi       s3, s1, #6144                   // row 12
    p.and        p1, p5, p2
    s.movz       s8, #13
    v.splat      v3, s6
    s.addi       s6, s13, #14
    @p4 v.st.w       [s2, #0], v0
    a.vread      v0, a1, s4
    v.cmp.lt     p4, v1, v2
    vf.add       v1, v0, v5
    p.and        p5, p4, p3
    s.addi       s2, s1, #6656                   // row 13
    p.and        p4, p5, p2
    s.movz       s4, #14
    v.splat      v0, s6
    s.addi       s6, s13, #15
    @p1 v.st.w       [s5, #0], v1
    a.vread      v1, a1, s7
    v.cmp.lt     p1, v3, v2
    vf.add       v3, v1, v5
    p.and        p5, p1, p3
    s.addi       s5, s1, #7168                   // row 14
    p.and        p1, p5, p2
    s.movz       s7, #15
    v.splat      v1, s6
    s.addi       s6, s1, #7680                   // row 15
    @p4 v.st.w       [s3, #0], v3
    a.vread      v3, a1, s8
    v.cmp.lt     p4, v0, v2
    vf.add       v0, v3, v5
    p.and        p5, p4, p3
    p.and        p4, p5, p2
    @p1 v.st.w       [s2, #0], v0
    a.vread      v0, a1, s4
    v.cmp.lt     p1, v1, v2
    vf.add       v1, v0, v5
    p.and        p5, p1, p3
    p.and        p1, p5, p2
    @p4 v.st.w       [s5, #0], v1
    a.vread      v0, a1, s7
    vf.add       v1, v0, v5
    @p1 v.st.w       [s6, #0], v1
__rctx_next:
    exit
