    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    .li       s1, #4286578688
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #37
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    s.ld.d       s8, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    s.mul        s1, s4, s5
    v.splat      v0, s7
    v.movi       v3, #37
    v.movi       v4, #0
    v.add        v5, v0, v2
    s.add        s9, s7, s1
    v.splat      v0, s1
    s.shli       s1, s9, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p1, v5, v3
    s.add        s9, s8, s1                      // &in_ptr0[...]
    s.add        s1, s7, s6
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s9, #0]
    s.movz       s9, #1
    v.add        v6, v5, v0
    vf.max.prop  v0, v1, v3
    @p1 v.sel        v3, v0, v1
    v.mov        v4, v3
    v.mov        v1, v4
    s.mov        s7, s1
    br.nz        s9, for_1
endfor_2:
    v.movi       v0, #1
    v.movi       v3, #0
    vf.cmp.uo    p1, v1, v1
    v.movi       v4, #0
    @p1 v.sel        v5, v0, v3
    vf.reduce.max.b v0, v1
    .li       s1, #2143289344
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.reduce.or.b v3, v5
    v.movi       v5, #0
    v.movi       v6, #0
    v.cmp.ne     p1, v3, v4
    @p1 v.sel        v3, v1, v0
    v.movi       v0, #0
    s.addi       s1, s2, #0
    vf.add       v1, v3, v5
    v.mov        v0, v6
for_3:
    s.cmp.ge     s7, s1, s5
    br.nz        s7, endfor_4
    s.mul        s7, s4, s5
    v.splat      v3, s1
    v.movi       v4, #37
    v.extract    s9, v1, #0
    v.add        v6, v3, v2
    s.add        s10, s1, s7
    v.splat      v3, s9
    s.shli       s9, s10, #2                     // element offset -> bytes (x4)
    v.cmp.lt     p1, v6, v4
    s.add        s10, s8, s9                     // &in_ptr0[...]
    .li       s11, #1069066811
    v.splat      v4, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v7, [s10, #0]
    .li       s10, #1060205080
    v.splat      v8, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #0
    s.add        s10, s3, s9                     // &in_out_ptr0[...]
    v.splat      v10, s7
    s.add        s7, s1, s6
    s.movz       s9, #1
    v.add        v11, v6, v10
    vf.sub       v6, v7, v3
    vf.mul       v3, v6, v4
    v.exp2.approx v7, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v6, v4, v3                 // the exact rounding error of x*log2(e)
    vf.mul       v3, v10, v8
    vf.fma       v4, v7, v3, v7                  // 2**t * 2**d
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v3, v4, v7
    vf.add       v4, v0, v3
    @p1 v.st.w       [s10, #0], v3
    @p1 v.sel        v3, v4, v0
    v.mov        v9, v3
    v.mov        v0, v9
    s.mov        s1, s7
    br.nz        s9, for_3
endfor_4:
    vf.reduce.add.b v1, v0
    s.addi       s1, s2, #0
    vf.add       v0, v1, v5
for_5:
    s.cmp.ge     s2, s1, s5
    br.nz        s2, endfor_6
    v.extract    s2, v0, #0
    s.mul        s7, s4, s5
    v.splat      v1, s2
    v.splat      v3, s1
    v.movi       v4, #37
    v.rcp.approx v5, v1                          // ISA 8.8: <= 2**-22 relative
    s.add        s2, s1, s7
    v.add        v6, v3, v2
    s.shli       s8, s2, #2                      // element offset -> bytes (x4)
    .li       s2, #1065353216
    v.splat      v3, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s2, s3, s8                      // &in_out_ptr0[...]
    v.cmp.lt     p1, v6, v4
    fence.acq_rel.device
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s2, #0]
    v.splat      v7, s7
    s.add        s2, s3, s8                      // &in_out_ptr0[...]
    s.add        s7, s1, s6
    s.movz       s8, #1
    v.add        v8, v6, v7
    vf.fms       v6, v1, v5, v3
    vf.fms       v1, v5, v6, v5
    vf.neg       v3, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v1, v3, v5
    vf.mul       v3, v4, v1                      // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.st.w       [s2, #0], v3
    s.mov        s1, s7
    br.nz        s8, for_5
endfor_6:
__rctx_next:
    exit
