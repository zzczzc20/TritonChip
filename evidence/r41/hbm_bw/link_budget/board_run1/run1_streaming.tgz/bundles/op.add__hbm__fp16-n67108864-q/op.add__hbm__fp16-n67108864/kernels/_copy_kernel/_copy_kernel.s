    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #7                      // x128 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #32
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #48
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #64
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #80
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #96
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #112
    v.iota       v14                             // arange(0, VLEN)
    v.add        v15, v0, v1
    v.add        v0, v2, v3
    v.add        v1, v4, v5
    v.add        v2, v6, v7
    v.add        v3, v8, v9
    v.add        v4, v10, v11
    v.add        v5, v12, v13
    v.splat      v6, s1
    v.splat      v7, s1
    v.splat      v8, s1
    v.splat      v9, s1
    v.splat      v10, s1
    v.splat      v11, s1
    v.splat      v12, s1
    v.splat      v13, s1
    v.add        v16, v6, v14
    v.add        v6, v7, v15
    v.add        v7, v8, v0
    v.add        v0, v9, v1
    v.add        v1, v10, v2
    v.add        v2, v11, v3
    v.add        v3, v12, v4
    v.add        v4, v13, v5
    v.movi       v5, #0
    v.movi       v8, #2
    v.sub        v9, v5, v16
    v.cmp.lt     p1, v16, v5
    @p1 v.sel        v10, v9, v16
    s.rdspecial  s1, arg_base
    v.sub        v9, v5, v8
    s.ld.d       s2, [s1, #0]                    // SRC: device_ptr64 at arg_base+0
    v.cmp.lt     p2, v8, v5
    @p2 v.sel        v11, v9, v8
    s.ld.d       s3, [s1, #8]                    // DST: device_ptr64 at arg_base+8
    v.movi       v9, #0
    v.movi       v11, #0
    v.movi       v12, #0
    v.movi       v13, #0
    v.sub        v14, v9, v6
    v.sub        v15, v11, v7
    v.sub        v17, v12, v0
    v.sub        v18, v13, v1
    v.cmp.lt     p2, v6, v9
    v.cmp.lt     p3, v7, v11
    v.movi       v19, #1
    @p2 v.sel        v20, v14, v6
    v.movi       v14, #1
    @p3 v.sel        v21, v15, v7
    v.movi       v15, #1
    v.movi       v22, #1
    v.movi       v23, #1
    v.lshr       v24, v10, v19
    v.lshr       v10, v20, v14
    v.lshr       v14, v21, v15
    v.sub        v15, v5, v24
    v.sub        v5, v9, v10
    v.sub        v19, v11, v14
    @p1 v.sel        v20, v15, v24
    v.cmp.lt     p1, v0, v12
    @p1 v.sel        v15, v17, v0
    v.movi       v17, #2
    v.movi       v21, #0
    v.lshr       v24, v15, v22
    @p2 v.sel        v15, v5, v10
    v.cmp.lt     p2, v1, v13
    @p2 v.sel        v5, v18, v1
    v.sub        v10, v12, v24
    v.lshr       v18, v5, v23
    v.movi       v5, #2
    v.sub        v22, v13, v18
    @p3 v.sel        v23, v19, v14
    v.cmp.lt     p3, v2, v21
    v.movi       v14, #2
    @p1 v.sel        v19, v10, v24
    v.movi       v10, #2
    @p2 v.sel        v24, v22, v18
    v.movi       v18, #2
    v.sub        v22, v9, v17
    v.sub        v25, v11, v5
    v.sub        v26, v12, v14
    v.sub        v27, v13, v10
    v.cmp.lt     p1, v17, v9
    v.sub        v9, v21, v2
    v.sub        v28, v21, v18
    @p3 v.sel        v29, v9, v2
    v.cmp.lt     p2, v5, v11
    @p1 v.sel        v9, v22, v17
    v.movi       v9, #0
    v.movi       v11, #1
    v.sub        v22, v9, v3
    v.cmp.lt     p1, v3, v9
    @p1 v.sel        v30, v22, v3
    v.lshr       v22, v29, v11
    v.movi       v11, #2
    v.sub        v29, v21, v22
    v.sub        v31, v9, v11
    @p3 v.sel        v32, v29, v22
    v.cmp.lt     p3, v14, v12
    @p2 v.sel        v12, v25, v5
    v.movi       v12, #0
    v.movi       v22, #1
    v.sub        v25, v12, v4
    v.cmp.lt     p2, v4, v12
    @p2 v.sel        v29, v25, v4
    v.lshr       v25, v30, v22
    v.movi       v22, #2
    v.sub        v30, v9, v25
    v.sub        v33, v12, v22
    @p1 v.sel        v34, v30, v25
    v.cmp.lt     p1, v10, v13
    @p3 v.sel        v13, v26, v14
    v.movi       v13, #0
    v.movi       v25, #1
    v.sub        v26, v13, v16
    v.cmp.lt     p3, v16, v13
    v.lshr       v30, v29, v25
    @p3 v.sel        v25, v26, v16
    v.sub        v26, v12, v30
    v.sub        v29, v13, v8
    @p2 v.sel        v35, v26, v30
    v.cmp.lt     p2, v18, v21
    @p1 v.sel        v21, v27, v10
    v.movi       v21, #0
    v.movi       v26, #1
    v.sub        v27, v21, v6
    v.cmp.lt     p1, v6, v21
    @p1 v.sel        v30, v27, v6
    v.movi       v27, #1
    v.and        v36, v25, v26
    v.sub        v25, v21, v17
    v.sub        v26, v13, v36
    @p2 v.sel        v37, v28, v18
    v.movi       v28, #0
    v.and        v37, v30, v27
    v.sub        v27, v28, v7
    v.cmp.lt     p2, v7, v28
    @p2 v.sel        v30, v27, v7
    v.sub        v27, v21, v37
    @p3 v.sel        v38, v26, v36
    @p1 v.sel        v26, v27, v37
    v.cmp.lt     p1, v11, v9
    v.movi       v9, #1
    v.sub        v27, v28, v5
    v.and        v36, v30, v9
    v.cmp.lt     p3, v22, v12
    @p1 v.sel        v9, v31, v11
    v.movi       v9, #0
    v.movi       v12, #1
    v.sub        v30, v9, v0
    v.cmp.lt     p1, v0, v9
    @p1 v.sel        v31, v30, v0
    v.sub        v30, v28, v36
    v.and        v37, v31, v12
    @p2 v.sel        v12, v30, v36
    v.sub        v30, v9, v37
    v.sub        v31, v9, v14
    v.cmp.lt     p2, v8, v13
    @p3 v.sel        v13, v33, v22
    v.movi       v13, #0
    v.movi       v33, #1
    v.sub        v36, v13, v1
    v.cmp.lt     p3, v1, v13
    @p3 v.sel        v39, v36, v1
    @p1 v.sel        v36, v30, v37
    v.and        v30, v39, v33
    v.sub        v33, v13, v10
    v.sub        v37, v13, v30
    v.cmp.lt     p1, v17, v21
    @p2 v.sel        v21, v29, v8
    v.movi       v21, #0
    v.movi       v29, #1
    v.sub        v39, v21, v2
    v.cmp.lt     p2, v2, v21
    @p2 v.sel        v40, v39, v2
    @p3 v.sel        v39, v37, v30
    v.and        v30, v40, v29
    v.sub        v29, v21, v18
    v.sub        v37, v21, v30
    v.cmp.lt     p3, v5, v28
    @p1 v.sel        v28, v25, v17
    v.movi       v25, #0
    v.movi       v28, #1
    v.sub        v40, v25, v3
    v.cmp.lt     p1, v3, v25
    @p1 v.sel        v41, v40, v3
    @p2 v.sel        v40, v37, v30
    v.and        v30, v41, v28
    v.sub        v28, v25, v11
    v.sub        v37, v25, v30
    v.cmp.lt     p2, v14, v9
    @p3 v.sel        v9, v27, v5
    v.movi       v9, #0
    v.movi       v27, #1
    v.sub        v41, v9, v4
    v.cmp.lt     p3, v4, v9
    @p3 v.sel        v42, v41, v4
    @p1 v.sel        v41, v37, v30
    v.and        v30, v42, v27
    v.sub        v27, v9, v22
    v.sub        v37, v9, v30
    v.cmp.lt     p1, v10, v13
    @p2 v.sel        v13, v31, v14
    @p3 v.sel        v13, v37, v30
    v.mul        v30, v20, v8
    v.mul        v20, v15, v17
    v.mul        v15, v23, v5
    v.mul        v23, v19, v14
    v.mul        v19, v24, v10
    v.mul        v24, v32, v18
    v.mul        v31, v34, v11
    v.mul        v32, v35, v22
    v.add        v34, v30, v38                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p2, v16, v8
    v.cmp.lt     p3, v18, v21
    @p1 v.sel        v21, v33, v10
    v.add        v21, v20, v26                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v33, v15, v12                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v35, v23, v36                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v17
    v.movi       v37, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v37, [s2, v34]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v5
    @p3 v.sel        v34, v29, v18
    v.add        v29, v19, v39                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v34, v24, v40                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v42, v31, v41                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p3, v0, v14
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v43, [s2, v21]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v10
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v21, [s2, v33]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v18
    v.movi       v33, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v33, [s2, v35]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v3, v11
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v35, [s2, v29]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v11, v25
    v.add        v25, v32, v13                   // per-lane offsets add up, in elements (ISA sec 9.1)
    @p1 v.sel        v29, v28, v11
    v.cmp.lt     p1, v4, v22
    v.add        v28, v30, v38                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v29, v20, v26                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v20, [s2, v34]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v22, v9
    v.add        v9, v15, v12                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v12, v23, v36                   // per-lane offsets add up, in elements (ISA sec 9.1)
    @p2 v.sel        v15, v27, v22
    v.add        v15, v19, v39                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v19, v24, v40                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v23, v31, v41                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v24, v32, v13                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p2, v16, v8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v8, [s2, v42]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v17
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v6, [s2, v25]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v5
    @p2 v.st.scatter.b [s3, v28], v37
    v.cmp.lt     p2, v0, v14
    @p3 v.st.scatter.b [s3, v29], v43
    v.cmp.lt     p3, v1, v10
    @p1 v.st.scatter.b [s3, v9], v21
    v.cmp.lt     p1, v2, v18
    @p2 v.st.scatter.b [s3, v12], v33
    v.cmp.lt     p2, v3, v11
    @p3 v.st.scatter.b [s3, v15], v35
    v.cmp.lt     p3, v4, v22
    @p1 v.st.scatter.b [s3, v19], v20
    @p2 v.st.scatter.b [s3, v23], v8
    @p3 v.st.scatter.b [s3, v24], v6
__rctx_next:
    exit
