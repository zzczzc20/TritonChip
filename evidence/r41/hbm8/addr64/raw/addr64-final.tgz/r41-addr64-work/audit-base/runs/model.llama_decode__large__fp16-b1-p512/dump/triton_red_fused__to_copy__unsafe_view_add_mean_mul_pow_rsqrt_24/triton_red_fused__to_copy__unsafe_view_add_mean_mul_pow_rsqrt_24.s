    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    v.iota       v0                              // arange(0, VLEN)
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s1, s7, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s8, #0
    s.st.d       [s1, #0], s2
    s.movz       s8, #2048
    s.st.d       [s1, #8], s8
    s.movz       s8, #2
    s.st.d       [s1, #48], s8
    s.movz       s8, #16
    s.st.d       [s1, #88], s8
    .li       s8, #4294967296
    s.st.d       [s1, #104], s8
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s7, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 1)
    s.movz       s8, #0
    s.st.d       [s1, #0], s3
    s.movz       s8, #2048
    s.st.d       [s1, #8], s8
    s.movz       s8, #2
    s.st.d       [s1, #48], s8
    s.movz       s8, #16
    s.st.d       [s1, #88], s8
    .li       s8, #4294967296
    s.st.d       [s1, #104], s8
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s7, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 1)
    s.movz       s7, #0
    s.st.d       [s1, #0], s4
    s.movz       s7, #2048
    s.st.d       [s1, #8], s7
    s.movz       s7, #2
    s.st.d       [s1, #48], s7
    s.movz       s7, #16
    s.st.d       [s1, #88], s7
    .li       s7, #4294967296
    s.st.d       [s1, #104], s7
    td.load      d2, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s7, #2048
    s.movz       s8, #16
    s.addi       s9, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s10, s9, s7
    br.nz        s10, endfor_2
    v.splat      v1, s9
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s9
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s10, #2048
    s.movz       s11, #2048
    s.muli       s12, s9, #2
    s.muli       s13, s9, #2
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s10
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s11
    v.splat      v8, s9
    v.iota       v9                              // arange(0, VLEN)
    v.cmp.ge     p1, v6, v1
    v.cmp.lt     p2, v6, v3
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    s.movz       s10, #2048
    s.add        s11, s2, s12
    p.and        p5, p1, p2
    s.add        s12, s3, s13
    p.and        p1, p3, p4
    s.muli       s13, s9, #2
    v.add        v1, v8, v9
    v.movi       v3, #0
    v.splat      v4, s10
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v5, [s11, #0]
    v.cmp.ge     p2, v1, v3
    v.cmp.lt     p3, v1, v4
    s.add        s10, s4, s13
    p.and        p4, p2, p3
    v.splat      v1, s9
    v.movi       v3, #2048
    v.movi       v4, #0
    v.add        v6, v1, v0
    v.cmp.lt     p2, v6, v3
    s.add        s11, s9, s8
    s.movz       s13, #1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v3, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s10, #0]
    vf.cvt.f16.f32 v6, v1
    vf.add       v1, v3, v6
    vf.cvt.f16.f32 v3, v5
    vf.add       v5, v1, v3
    vf.mul       v1, v5, v5
    vf.add       v3, v2, v1
    @p2 v.sel        v1, v3, v2
    v.mov        v4, v1
    v.mov        v2, v4
    s.mov        s9, s11
    br.nz        s13, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    s.addi       s9, s1, #0
    vf.add       v3, v1, v2
for_3:
    s.cmp.ge     s1, s9, s7
    br.nz        s1, endfor_4
    v.splat      v1, s9
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s9
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s1, #2048
    s.movz       s10, #2048
    s.muli       s11, s9, #2
    s.muli       s12, s9, #2
    v.add        v6, v1, v2
    v.movi       v1, #0
    v.splat      v2, s1
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s10
    v.splat      v8, s9
    v.iota       v9                              // arange(0, VLEN)
    v.cmp.ge     p1, v6, v1
    v.cmp.lt     p2, v6, v2
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    s.movz       s1, #2048
    s.add        s10, s2, s11
    p.and        p5, p1, p2
    s.add        s11, s3, s12
    p.and        p1, p3, p4
    s.muli       s12, s9, #2
    v.add        v1, v8, v9
    v.movi       v2, #0
    v.splat      v4, s1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v5, [s10, #0]
    v.cmp.ge     p2, v1, v2
    v.cmp.lt     p3, v1, v4
    s.add        s1, s4, s12
    p.and        p4, p2, p3
    v.splat      v1, s9
    v.movi       v2, #2048
    s.shli       s10, s9, #1                     // element offset -> bytes (x2)
    v.add        v4, v1, v0
    .li       s12, #1157627904
    v.splat      v1, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s12, s5, s10                    // &in_ptr3[...]
    v.cmp.lt     p2, v4, v2
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    .li       s13, #1065353216
    v.splat      v4, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s13, #925353388
    v.splat      v6, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s11, #0]
    .li       s11, #1077936128
    v.splat      v8, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.f16.f32 v9, v5
    .li       s11, #3204448256
    v.splat      v5, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s11, s6, s10                    // &out_ptr1[...]
    s.add        s10, s9, s8
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v10, [s1, #0]
    vf.cvt.f16.f32 v11, v7
    s.movz       s1, #1
    vf.add       v7, v9, v11
    vf.fms       v9, v1, v2, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v4, v10
    vf.fms       v10, v2, v9, v2
    vf.add       v9, v7, v4
    vf.neg       v4, v10                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v7, v4, v2
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v3, v7                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v4, v1, v6
    v.rsqrt.approx v1, v4                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v6, v1, v1
    vf.mul       v7, v1, v5
    vf.fms       v5, v4, v6, v8
    vf.mul       v4, v7, v5                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v5, v4, v1
    v.extract    s12, v5, #0
    v.splat      v1, s12
    vf.mul       v4, v9, v1
    vf.mul       v1, v4, v2
    vf.cvt.f32.f16 v2, v1
    @p2 v.st.h       [s11, #0], v2
    s.mov        s9, s10
    br.nz        s1, for_3
endfor_4:
    exit
    exit
