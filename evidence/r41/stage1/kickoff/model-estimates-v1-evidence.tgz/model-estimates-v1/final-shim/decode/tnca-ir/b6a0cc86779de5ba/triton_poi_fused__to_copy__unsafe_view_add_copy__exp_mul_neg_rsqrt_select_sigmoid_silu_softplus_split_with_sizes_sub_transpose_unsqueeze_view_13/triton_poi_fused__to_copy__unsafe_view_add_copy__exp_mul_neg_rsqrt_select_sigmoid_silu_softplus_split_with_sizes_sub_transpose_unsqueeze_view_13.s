    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s2, arg_base
    v.add        v3, v1, v0
    v.movi       v0, #14
    s.ld.d       s3, [s2, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.movi       v4, #0
    @p1 v.sel        v5, v1, v3
    v.movi       v1, #0
    v.sub        v6, v4, v3
    v.lshr       v7, v5, v0
    v.cmp.lt     p2, v3, v4
    v.sub        v0, v1, v3
    v.sub        v5, v2, v7
    @p2 v.sel        v8, v6, v3
    v.movi       v6, #7
    @p1 v.sel        v9, v5, v7
    s.ld.d       s4, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.cmp.lt     p1, v3, v1
    @p1 v.sel        v5, v0, v3
    v.movi       v0, #127
    v.lshr       v3, v8, v6
    v.movi       v6, #128
    v.and        v7, v5, v0
    v.sub        v0, v4, v3
    s.shli       s5, s1, #2                      // element offset -> bytes (x4)
    v.sub        v5, v1, v7
    @p2 v.sel        v8, v0, v3
    s.ld.d       s1, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v0, v5, v7
    v.movi       v3, #16384
    v.sub        v5, v4, v6
    v.sub        v7, v1, v6
    v.sub        v10, v2, v3
    v.cmp.lt     p1, v3, v2
    v.cmp.lt     p2, v6, v4
    v.cmp.lt     p3, v6, v1
    @p1 v.sel        v1, v10, v3
    @p2 v.sel        v1, v5, v6
    s.ld.d       s6, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.add        s7, s1, s5                      // &in_ptr0[...]
    @p3 v.sel        v1, v7, v6
    v.ld.gather.w v1, [s3, v9]                   // index is in elements (ISA sec 9.1)
    s.ld.d       s1, [s2, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    v.mul        v2, v9, v6
    v.ld.gather.w v3, [s4, v8]                   // index is in elements (ISA sec 9.1)
    v.ld.w       v4, [s7, #0]
    v.ld.gather.w v5, [s6, v9]                   // index is in elements (ISA sec 9.1)
    s.ld.d       s3, [s2, #40]                   // out_ptr0: device_ptr64 at arg_base+40
    v.add        v6, v0, v2
    s.ld.d       s4, [s2, #48]                   // out_ptr1: device_ptr64 at arg_base+48
    .li       s2, #897988541
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1077936128
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v8, v1, v0
    vf.mul       v0, v4, v5
    s.add        s2, s3, s5                      // &out_ptr0[...]
    v.rsqrt.approx v1, v8                        // ISA 8.8: <= 2**-22 relative
    v.ld.gather.w v4, [s1, v6]                   // index is in elements (ISA sec 9.1)
    s.add        s1, s4, s5                      // &out_ptr1[...]
    vf.mul       v5, v1, v1
    vf.mul       v6, v1, v7
    vf.fms       v7, v8, v5, v2
    vf.mul       v2, v6, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v5, v2, v1
    vf.mul       v1, v3, v5
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    v.st.w       [s2, #0], v1
    v.st.w       [s1, #0], v1
__rctx_next:
    exit
