    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.add        v3, v1, v0
    v.movi       v0, #6
    s.ld.d       s2, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.movi       v4, #9216
    @p1 v.sel        v5, v1, v3
    v.movi       v1, #0
    v.cmp.lt     p2, v3, v4
    v.lshr       v4, v5, v0
    v.sub        v0, v1, v3
    v.cmp.lt     p3, v3, v1
    v.sub        v5, v2, v4
    @p3 v.sel        v6, v0, v3
    v.movi       v0, #63
    @p1 v.sel        v7, v5, v4
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.and        v4, v6, v0
    v.movi       v0, #64
    v.movi       v5, #0
    v.sub        v6, v1, v4
    v.movi       v8, #0
    v.movi       v9, #7
    @p3 v.sel        v10, v6, v4
    v.sub        v4, v8, v7
    v.cmp.lt     p1, v7, v8
    v.movi       v6, #8
    s.ld.d       s4, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v11, v5, v3
    v.cmp.lt     p3, v3, v5
    @p1 v.sel        v12, v4, v7
    v.movi       v4, #512
    v.sub        v13, v1, v0
    v.and        v14, v12, v9
    v.sub        v9, v2, v0
    v.sub        v12, v8, v6
    v.sub        v15, v8, v14
    v.cmp.lt     p4, v0, v1
    s.ld.d       s5, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    @p3 v.sel        v1, v11, v3
    @p1 v.sel        v3, v15, v14
    v.cmp.lt     p1, v0, v2
    @p4 v.sel        v2, v13, v0
    v.cmp.lt     p4, v6, v8
    @p1 v.sel        v2, v9, v0
    v.cmp.lt     p1, v4, v5
    @p4 v.sel        v2, v12, v6
    s.ld.d       s6, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    .li       s1, #1124073472
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #897988541
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v9, v2                          // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #128
    v.add        v12, v10, v0
    .li       s1, #1077936128
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v13, v7, v11
    .li       s1, #3204448256
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #9
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v16, [s2, v7]              // index is in elements (ISA sec 9.1)
    v.lshr       v7, v1, v15
    v.add        v1, v12, v13
    v.add        v15, v10, v13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v13, [s3, v1]              // index is in elements (ISA sec 9.1)
    vf.fms       v1, v2, v9, v6
    vf.fms       v6, v9, v1, v9
    vf.neg       v1, v6                          // Newton step: r0*(2 - x*r0)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v6, [s4, v12]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v12, v13
    vf.cmp.o     p4, v1, v1
    @p4 v.sel        v13, v1, v9
    v.sub        v1, v5, v7
    v.sub        v9, v5, v4
    @p3 v.sel        v5, v1, v7
    vf.mul       v1, v16, v13                    // a/y: faithful quotient
    @p1 v.sel        v7, v9, v4
    v.mul        v4, v5, v11
    v.movi       v5, #2304
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v7, [s3, v15]              // index is in elements (ISA sec 9.1)
    vf.fms       v9, v1, v2, v16
    vf.cvt.bf16.f32 v2, v6
    v.add        v6, v10, v4
    v.mul        v4, v3, v5
    vf.fms       v3, v9, v13, v1
    v.add        v5, v6, v4
    vf.neg       v4, v3                          // a/y: one correction to the IEEE quotient
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v3, [s4, v10]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v6, v7
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v7, v4, v1
    vf.add       v1, v7, v8
    v.rsqrt.approx v4, v1                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v7, v3
    vf.mul       v3, v4, v4
    vf.mul       v8, v4, v14
    vf.fms       v9, v1, v3, v0
    vf.mul       v0, v8, v9                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v1, v0, v4
    vf.mul       v0, v12, v1
    vf.mul       v3, v6, v1
    vf.mul       v1, v2, v0
    vf.mul       v0, v7, v3
    vf.neg       v2, v1
    vf.cvt.f32.bf16 v1, v0
    vf.cvt.f32.bf16 v0, v2
    @p2 v.st.scatter.h [s5, v5], v0
    @p2 v.st.scatter.h [s6, v5], v1
__rctx_next:
    exit
