    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #56
    v.movi       v2, #0
    s.rdspecial  s3, arg_base
    v.movi       v3, #1
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    s.ld.d       s2, [s3, #0]                    // arg_X: device_ptr64 at arg_base+0
    @p1 v.sel        v4, v5, v1
    v.sub        v5, v2, v6
    v.cmp.lt     p1, v6, v2
    v.movi       v7, #0
    @p1 v.sel        v8, v5, v6
    v.movi       v5, #0
    s.movz       s4, #31
    s.ld.d       s5, [s3, #8]                    // arg_W: device_ptr64 at arg_base+8
    s.ld.d       s6, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s7, [s3, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s8, [s3, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s9, [s3, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s10, [s3, #48]                  // in_ptr6: device_ptr64 at arg_base+48
    s.ld.d       s11, [s3, #56]                  // out_ptr1: device_ptr64 at arg_base+56
idiv_1:
    v.splat      v9, s4
    v.shl        v10, v5, v3
    v.cmp.lt     p2, v5, v2
    v.lshr       v11, v8, v9
    v.shl        v12, v3, v9
    s.subi       s3, s4, #1
    v.and        v9, v11, v3
    s.movz       s12, #0
    v.or         v11, v10, v9
    v.cmp.geu    p3, v11, v4
    p.or         p4, p2, p3
    v.sub        v9, v11, v4
    @p4 v.sel        v10, v12, v2
    @p4 v.sel        v12, v9, v11
    v.or         v9, v7, v10
    v.mov        v5, v12
    v.mov        v7, v9
    s.mov        s4, s3
    s.cmp.ge     s3, s4, s12
    br.nz        s3, idiv_1
    v.movi       v3, #0
    v.sub        v4, v2, v5
    v.movi       v2, #1
    v.sub        v7, v3, v6
    v.sub        v8, v3, v1
    v.cmp.lt     p2, v6, v3
    v.cmp.lt     p3, v1, v3
    @p1 v.sel        v9, v4, v5
    @p2 v.sel        v4, v7, v6
    @p3 v.sel        v5, v8, v1
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_2:
    v.splat      v8, s3
    v.shl        v10, v7, v2
    v.cmp.lt     p1, v7, v3
    v.lshr       v11, v4, v8
    v.shl        v12, v2, v8
    s.subi       s4, s3, #1
    v.and        v8, v11, v2
    s.movz       s12, #0
    v.or         v11, v10, v8
    v.cmp.geu    p4, v11, v5
    p.or         p5, p1, p4
    v.sub        v8, v11, v5
    @p5 v.sel        v10, v12, v3
    @p5 v.sel        v12, v8, v11
    v.or         v8, v6, v10
    v.mov        v7, v12
    v.mov        v6, v8
    s.mov        s3, s4
    s.cmp.ge     s4, s3, s12
    br.nz        s4, idiv_2
    v.sub        v2, v3, v6
    p.xor        p1, p2, p3
    v.movi       v3, #0
    @p1 v.sel        v4, v2, v6
    v.movi       v2, #1
    v.sub        v5, v3, v1
    v.sub        v6, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    @p1 v.sel        v7, v6, v4
    @p2 v.sel        v6, v5, v1
    v.movi       v5, #0
    v.movi       v8, #0
    s.movz       s3, #31
idiv_3:
    v.splat      v10, s3
    v.shl        v11, v8, v2
    v.cmp.lt     p2, v8, v3
    v.lshr       v12, v7, v10
    v.shl        v13, v2, v10
    s.subi       s4, s3, #1
    v.and        v10, v12, v2
    s.movz       s12, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v6
    p.or         p4, p2, p3
    v.sub        v10, v12, v6
    @p4 v.sel        v11, v13, v3
    @p4 v.sel        v13, v10, v12
    v.or         v10, v5, v11
    v.mov        v8, v13
    v.mov        v5, v10
    s.mov        s3, s4
    s.cmp.ge     s4, s3, s12
    br.nz        s4, idiv_3
    v.movi       v2, #0
    v.sub        v5, v3, v8
    v.movi       v3, #1
    v.sub        v6, v2, v4
    v.sub        v7, v2, v1
    v.cmp.lt     p2, v4, v2
    v.cmp.lt     p3, v1, v2
    @p1 v.sel        v10, v5, v8
    @p2 v.sel        v5, v6, v4
    @p3 v.sel        v4, v7, v1
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_4:
    v.splat      v8, s3
    v.shl        v11, v7, v3
    v.cmp.lt     p1, v7, v2
    v.lshr       v12, v5, v8
    v.shl        v13, v3, v8
    s.subi       s4, s3, #1
    v.and        v8, v12, v3
    s.movz       s12, #0
    v.or         v12, v11, v8
    v.cmp.geu    p4, v12, v4
    p.or         p5, p1, p4
    v.sub        v8, v12, v4
    @p5 v.sel        v11, v13, v2
    @p5 v.sel        v13, v8, v12
    v.or         v8, v6, v11
    v.mov        v7, v13
    v.mov        v6, v8
    s.mov        s3, s4
    s.cmp.ge     s4, s3, s12
    br.nz        s4, idiv_4
    s.rdspecial  s3, pid.y
    s.rdspecial  s4, arg_base
    v.sub        v3, v2, v6
    s.mul        s12, s3, s1
    s.ld.d       s3, [s4, #64]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    p.xor        p1, p2, p3
    .li       s4, #200704
    v.splat      v2, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v4, v3, v6
    s.rdspecial  s4, role_id
    s.movz       s13, #6208
    v.splat      v3, s12
    v.mul        v5, v4, v2
    s.mul        s14, s4, s13
    v.add        v2, v3, v0
    s.movz       s4, #0
    v.extract    s13, v5, #0
    v.extract    s15, v5, #1
    v.extract    s16, v5, #2
    v.extract    s17, v5, #3
    v.extract    s18, v5, #4
    v.extract    s19, v5, #5
    v.extract    s20, v5, #6
    s.add        s21, s3, s14                    // this context's own scratch
    v.extract    s3, v5, #7
    v.splat      v3, s4
    v.splat      v6, s13
    v.splat      v7, s15
    v.splat      v8, s16
    v.splat      v11, s17
    v.splat      v12, s18
    s.addi       s13, s21, #0
    v.add        v13, v3, v6
    v.add        v6, v3, v7
    v.add        v7, v3, v8
    v.add        v8, v3, v11
    v.add        v11, v3, v12
    s.addi       s14, s13, #64
    s.addi       s15, s13, #128
    s.addi       s16, s13, #192
    s.addi       s17, s13, #256
    v.st.w       [s13, #0], v13
    v.splat      v12, s19
    s.addi       s18, s13, #320
    v.add        v13, v3, v12
    v.st.w       [s14, #0], v6
    v.splat      v6, s20
    s.addi       s14, s13, #384
    s.addi       s19, s13, #448
    v.add        v12, v3, v6
    v.st.w       [s15, #0], v7
    .li       s15, #200704
    v.splat      v6, s3
    v.extract    s3, v5, #8
    v.add        v7, v3, v6
    v.st.w       [s16, #0], v8
    v.extract    s16, v5, #9
    v.splat      v6, s3
    v.extract    s3, v5, #10
    v.add        v8, v3, v6
    v.st.w       [s17, #0], v11
    v.extract    s17, v5, #11
    v.splat      v6, s16
    v.extract    s16, v5, #12
    v.add        v11, v3, v6
    v.st.w       [s18, #0], v13
    v.extract    s18, v5, #13
    v.splat      v6, s3
    v.extract    s3, v5, #14
    s.movz       s20, #576
    v.add        v13, v3, v6
    v.st.w       [s14, #0], v12
    v.movi       v6, #576
    v.extract    s14, v5, #15
    v.splat      v5, s17
    v.mul        v12, v2, v6
    s.addi       s17, s13, #512
    v.add        v6, v3, v5
    v.st.w       [s19, #0], v7
    v.splat      v5, s16
    s.addi       s16, s13, #576
    s.addi       s19, s13, #640
    v.add        v7, v3, v5
    v.st.w       [s17, #0], v8
    v.splat      v5, s18
    s.addi       s17, s13, #704
    s.addi       s18, s13, #768
    v.add        v8, v3, v5
    v.st.w       [s16, #0], v11
    v.splat      v5, s3
    s.addi       s3, s13, #832
    s.addi       s16, s13, #896
    v.add        v11, v3, v5
    s.addi       s20, s13, #960
    v.st.w       [s19, #0], v13
    v.splat      v5, s14
    s.addi       s13, s21, #1024
    s.movz       s14, #36
    v.add        v13, v3, v5
    v.splat      v3, s4
    v.add        v5, v3, v12
    v.st.w       [s17, #0], v6
    s.movz       s17, #1
    v.st.w       [s18, #0], v7
    s.addi       s18, s4, #0
    v.st.w       [s3, #0], v8
    v.st.w       [s16, #0], v11
    v.st.w       [s20, #0], v13
    fence.acq_rel.device
    v.st.w       [s13, #0], v5
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s3, s18, s14
    br.nz        s3, endfor_6
    s.movz       s3, #0
    s.movz       s13, #0
    s.cmp.lt     s16, s18, s3
    s.movz       s3, #4
    s.sub        s19, s13, s16
    s.movz       s13, #0
    s.movz       s16, #0
    s.cmp.lt     s20, s3, s13
    s.xor        s13, s18, s19
    s.sub        s22, s16, s20
    s.sub        s16, s13, s19
    s.xor        s13, s19, s22
    s.lshri      s19, s16, #2
    s.movz       s20, #0
    s.xor        s23, s19, s13
    s.movz       s24, #0
    s.sub        s25, s23, s13
    s.movz       s13, #0
    s.cmp.lt     s23, s25, s20
    s.movz       s20, #0
    s.sub        s26, s24, s23
    .li       s23, #1431655766
    s.xor        s24, s25, s26
    s.cmp.lt     s27, s18, s13
    s.sub        s13, s24, s26
    s.sub        s24, s20, s27
    s.mul        s20, s13, s23
    s.movz       s23, #3
    s.movz       s27, #0
    s.muli       s28, s19, #4
    s.cmp.lt     s19, s23, s27
    s.lshri      s27, s20, #32
    s.sub        s20, s16, s28
    s.xor        s16, s18, s24
    s.movz       s20, #0
    s.sub        s28, s16, s24
    s.sub        s16, s20, s19
    s.lshri      s19, s28, #2
    s.muli       s20, s19, #4
    s.sub        s19, s28, s20
    s.movz       s20, #0
    s.xor        s28, s19, s24
    s.cmp.lt     s19, s3, s20
    s.sub        s20, s28, s24
    s.movz       s24, #0
    s.mul        s28, s20, s1
    s.sub        s20, s13, s27
    s.sub        s29, s24, s19
    s.lshri      s19, s20, #1
    s.xor        s20, s3, s29
    s.add        s24, s27, s19
    s.xor        s19, s26, s16
    s.lshri      s26, s24, #1
    s.xor        s24, s3, s22
    s.muli       s3, s26, #3
    s.sub        s27, s20, s29
    s.movz       s20, #0
    s.movz       s27, #0
    s.cmp.lt     s29, s25, s20
    s.xor        s20, s26, s19
    s.sub        s26, s27, s29
    .li       s27, #1431655766
    s.xor        s29, s25, s26
    s.sub        s25, s20, s19
    s.sub        s19, s29, s26
    s.movz       s20, #0
    s.mul        s29, s19, s27
    s.cmp.lt     s27, s23, s20
    s.sub        s20, s24, s22
    s.sub        s20, s25, s17
    v.movi       v3, #3584
    s.lshri      s22, s29, #32
    v.splat      v5, s20
    s.sub        s20, s19, s22
    v.splat      v6, s28
    s.lshri      s24, s20, #1
    v.add        v7, v5, v10
    s.add        s20, s22, s24
    v.add        v5, v0, v6
    s.lshri      s22, s20, #1
    v.mul        v6, v7, v3
    s.muli       s20, s22, #3
    s.movz       s22, #0
    s.xor        s24, s23, s16
    s.sub        s29, s22, s27
    s.movz       s22, #64
    s.sub        s27, s19, s20
    s.xor        s19, s23, s29
    s.xor        s20, s27, s26
    s.sub        s23, s24, s16
    s.sub        s16, s20, s26
    s.addi       s20, s21, #0
    s.sub        s23, s16, s17
    v.ld.w       v3, [s20, #0]
    v.splat      v8, s23
    v.movi       v11, #64
    v.extract    s20, v6, #0
    v.add        v12, v8, v9
    v.splat      v8, s20
    s.addi       s20, s21, #1088
    v.mul        v13, v12, v11
    s.sub        s23, s13, s3
    s.movz       s3, #0
    v.extract    s13, v13, #0
    s.add        s23, s3, s28                    // the tile origin
    v.splat      v14, s13
    v.iota       v15                             // arange(0, VLEN)
    v.splat      v16, s23
    v.add        v17, v8, v14
    s.addi       s3, s21, #64
    v.add        v8, v15, v16
    v.extract    s13, v6, #1
    v.extract    s23, v13, #1
    v.add        v14, v17, v8
    v.splat      v16, s13
    s.addi       s13, s20, #64
    v.add        v17, v3, v14
    s.sub        s24, s19, s29
    v.splat      v3, s23
    v.st.w       [s20, #0], v17
    s.addi       s19, s21, #128
    v.add        v14, v16, v3
    v.extract    s23, v6, #2
    v.extract    s24, v13, #2
    v.add        v3, v14, v8
    v.splat      v14, s23
    v.splat      v16, s24
    s.addi       s23, s20, #128
    s.addi       s24, s21, #192
    v.add        v17, v14, v16
    v.extract    s26, v6, #3
    s.addi       s27, s20, #192
    v.add        v14, v17, v8
    s.movz       s29, #3584
    v.splat      v16, s26
    v.extract    s26, v13, #3
    v.ld.w       v17, [s3, #0]
    v.splat      v18, s26
    s.addi       s3, s21, #256
    v.extract    s26, v6, #4
    v.add        v19, v16, v18
    v.splat      v16, s26
    v.extract    s26, v13, #4
    v.add        v18, v19, v8
    v.splat      v19, s26
    s.addi       s26, s20, #256
    v.add        v20, v16, v19
    v.add        v16, v20, v8
    v.add        v19, v17, v3
    v.st.w       [s13, #0], v19
    s.addi       s13, s21, #320
    v.ld.w       v3, [s19, #0]
    v.extract    s19, v6, #5
    v.splat      v17, s19
    v.extract    s19, v13, #5
    v.splat      v19, s19
    s.addi       s19, s20, #320
    v.add        v20, v17, v19
    v.add        v17, v20, v8
    v.add        v19, v3, v14
    v.st.w       [s23, #0], v19
    s.addi       s23, s21, #384
    v.ld.w       v3, [s24, #0]
    v.extract    s24, v6, #6
    v.splat      v14, s24
    v.extract    s24, v13, #6
    v.splat      v19, s24
    s.addi       s24, s20, #384
    v.add        v20, v14, v19
    v.add        v14, v20, v8
    v.add        v19, v3, v18
    v.st.w       [s27, #0], v19
    s.addi       s27, s21, #448
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v6, #7
    v.splat      v18, s3
    v.extract    s3, v13, #7
    v.splat      v19, s3
    s.addi       s3, s20, #448
    v.add        v20, v18, v19
    v.add        v18, v20, v8
    v.add        v19, v3, v16
    v.st.w       [s26, #0], v19
    s.addi       s26, s21, #512
    v.ld.w       v3, [s13, #0]
    v.extract    s13, v6, #8
    v.splat      v16, s13
    v.extract    s13, v13, #8
    v.splat      v19, s13
    s.addi       s13, s20, #512
    v.add        v20, v16, v19
    v.add        v16, v20, v8
    v.add        v19, v3, v17
    v.st.w       [s19, #0], v19
    s.addi       s19, s21, #576
    v.ld.w       v3, [s23, #0]
    v.extract    s23, v6, #9
    v.splat      v17, s23
    v.extract    s23, v13, #9
    v.splat      v19, s23
    s.addi       s23, s20, #576
    v.add        v20, v17, v19
    v.add        v17, v20, v8
    v.add        v19, v3, v14
    v.st.w       [s24, #0], v19
    s.addi       s24, s21, #640
    v.ld.w       v3, [s27, #0]
    v.extract    s27, v6, #10
    v.splat      v14, s27
    v.extract    s27, v13, #10
    v.splat      v19, s27
    s.addi       s27, s20, #640
    v.add        v20, v14, v19
    v.add        v14, v20, v8
    v.add        v19, v3, v18
    v.st.w       [s3, #0], v19
    s.addi       s3, s21, #704
    v.ld.w       v3, [s26, #0]
    v.extract    s26, v6, #11
    v.splat      v18, s26
    v.extract    s26, v13, #11
    v.splat      v19, s26
    s.addi       s26, s20, #704
    v.add        v20, v18, v19
    v.add        v18, v20, v8
    v.add        v19, v3, v16
    v.st.w       [s13, #0], v19
    s.addi       s13, s21, #768
    v.ld.w       v3, [s19, #0]
    v.extract    s19, v6, #12
    v.splat      v16, s19
    v.extract    s19, v13, #12
    v.splat      v19, s19
    s.addi       s19, s20, #768
    v.add        v20, v16, v19
    v.add        v16, v20, v8
    v.add        v19, v3, v17
    v.st.w       [s23, #0], v19
    s.addi       s23, s21, #832
    v.ld.w       v3, [s24, #0]
    v.extract    s24, v6, #13
    v.splat      v17, s24
    v.extract    s24, v13, #13
    v.splat      v19, s24
    s.addi       s24, s20, #832
    v.add        v20, v17, v19
    v.add        v17, v20, v8
    v.add        v19, v3, v14
    v.st.w       [s27, #0], v19
    s.addi       s27, s21, #896
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v6, #14
    v.movi       v14, #8
    v.splat      v19, s3
    v.extract    s3, v13, #14
    v.splat      v20, s3
    s.addi       s3, s20, #896
    s.addi       s29, s20, #960
    v.add        v21, v19, v20
    v.add        v19, v21, v8
    v.add        v20, v3, v18
    v.cmp.lt     p1, v4, v14
    v.st.w       [s26, #0], v20
    s.addi       s20, s21, #960
    v.movi       v3, #1
    v.movi       v14, #0
    @p1 v.sel        v18, v3, v14
    v.ld.w       v3, [s13, #0]
    v.extract    s13, v6, #15
    v.movi       v6, #0
    v.splat      v14, s13
    v.extract    s13, v13, #15
    v.movi       v13, #1
    v.splat      v20, s13
    v.cmp.ge     p1, v7, v6
    v.cmp.lt     p2, v7, v1
    v.add        v7, v14, v20
    v.movi       v14, #0
    v.movi       v20, #1
    v.add        v21, v7, v8
    @p1 v.sel        v7, v13, v14
    v.add        v8, v3, v16
    v.movi       v3, #0
    v.st.w       [s19, #0], v8
    v.movi       v8, #1
    @p2 v.sel        v13, v20, v3
    v.cmp.ge     p1, v12, v6
    v.ld.w       v3, [s23, #0]
    v.movi       v6, #0
    v.movi       v14, #1
    v.movi       v16, #0
    @p1 v.sel        v20, v8, v6
    v.cmp.lt     p1, v12, v1
    @p1 v.sel        v6, v14, v16
    v.cmp.lt     p1, v5, v11
    v.add        v5, v3, v17
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s13, #0
    v.st.w       [s24, #0], v5
    s.addi       s19, s21, #1088
    v.extract    s23, v18, #0
    v.ld.w       v3, [s27, #0]
    v.extract    s24, v7, #0
    v.splat      v5, s23
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p3, v11, v12
    v.add        v5, v3, v19
    p.and        p4, p2, p3
    v.st.w       [s3, #0], v5
    v.extract    s3, v13, #0
    v.movi       v3, #0
    v.splat      v5, s3
    v.ld.w       v8, [s20, #0]
    v.extract    s3, v20, #0
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v5, v3
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p3, p2
    v.add        v3, v8, v21
    v.extract    s3, v6, #0
    v.st.w       [s29, #0], v3
    fence.acq_rel.device
    v.splat      v3, s3
    v.movi       v5, #0
    s.addi       s3, s21, #1152
    v.extract    s20, v18, #1
    v.cmp.ne     p2, v3, v5
    p.and        p3, p4, p2
    v.extract    s23, v7, #1
    p.and        p2, p3, p1
    v.splat      v3, s20
    v.movi       v5, #0
    v.splat      v8, s23
    v.movi       v11, #0
    v.extract    s20, v13, #1
    v.movi       v12, #0
    v.splat      v14, s20
    v.extract    s20, v20, #1
    v.ld.w       v16, [s19, #0]
    v.cmp.ne     p3, v3, v5
    v.cmp.ne     p4, v8, v11
    p.and        p5, p3, p4
    v.splat      v3, s20
    v.movi       v5, #0
    v.extract    s19, v6, #1
    v.cmp.ne     p3, v14, v12
    p.and        p4, p5, p3
    v.splat      v8, s19
    v.movi       v11, #0
    v.cmp.ne     p3, v3, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v8, v11
    p.and        p4, p5, p3
    s.movz       s19, #1
    p.and        p3, p4, p1
    s.addi       s20, s21, #1216
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v3, [s2, v16]              // index is in elements (ISA sec 9.1)
    v.extract    s23, v18, #2
    v.extract    s24, v7, #2
    v.splat      v5, s23
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0
    v.extract    s23, v13, #2
    v.movi       v14, #0
    v.splat      v16, s23
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v12
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s23, #2
    a.vwrite     a1, s13, v3
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #2
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #2
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s21, #1280
    p.and        p2, p4, p1
    v.extract    s13, v18, #3
    v.extract    s24, v7, #3
    v.splat      v5, s13
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v13, #3
    v.movi       v14, #0
    v.splat      v16, s13
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s13, #3
    a.vwrite     a1, s19, v12
    v.ld.w       v3, [s20, #0]
    v.extract    s19, v20, #3
    v.movi       v5, #0
    v.splat      v8, s19
    v.extract    s19, v6, #3
    v.movi       v11, #0
    v.splat      v12, s19
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s19, s21, #1344
    p.and        p3, p4, p1
    v.extract    s20, v18, #4
    v.extract    s24, v7, #4
    v.splat      v5, s20
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s20, v13, #4
    v.movi       v14, #0
    v.splat      v16, s20
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s20, #4
    a.vwrite     a1, s23, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #4
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #4
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s21, #1408
    p.and        p2, p4, p1
    v.extract    s23, v18, #5
    v.extract    s24, v7, #5
    v.splat      v5, s23
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s23, v13, #5
    v.movi       v14, #0
    v.splat      v16, s23
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s23, #5
    a.vwrite     a1, s13, v12
    v.ld.w       v3, [s19, #0]
    v.extract    s13, v20, #5
    v.movi       v5, #0
    v.splat      v8, s13
    v.extract    s13, v6, #5
    v.movi       v11, #0
    v.splat      v12, s13
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s13, s21, #1472
    p.and        p3, p4, p1
    v.extract    s19, v18, #6
    v.extract    s24, v7, #6
    v.splat      v5, s19
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s19, v13, #6
    v.movi       v14, #0
    v.splat      v16, s19
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s19, #6
    a.vwrite     a1, s20, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #6
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #6
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s21, #1536
    p.and        p2, p4, p1
    v.extract    s20, v18, #7
    v.extract    s24, v7, #7
    v.splat      v5, s20
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s20, v13, #7
    v.movi       v14, #0
    v.splat      v16, s20
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s20, #7
    a.vwrite     a1, s23, v12
    v.ld.w       v3, [s13, #0]
    v.extract    s13, v20, #7
    v.movi       v5, #0
    v.splat      v8, s13
    v.extract    s13, v6, #7
    v.movi       v11, #0
    v.splat      v12, s13
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s13, s21, #1600
    p.and        p3, p4, p1
    v.extract    s23, v18, #8
    v.extract    s24, v7, #8
    v.splat      v5, s23
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s23, v13, #8
    v.movi       v14, #0
    v.splat      v16, s23
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s23, #8
    a.vwrite     a1, s19, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #8
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #8
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s21, #1664
    p.and        p2, p4, p1
    v.extract    s19, v18, #9
    v.extract    s24, v7, #9
    v.splat      v5, s19
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s19, v13, #9
    v.movi       v14, #0
    v.splat      v16, s19
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s19, #9
    a.vwrite     a1, s20, v12
    v.ld.w       v3, [s13, #0]
    v.extract    s13, v20, #9
    v.movi       v5, #0
    v.splat      v8, s13
    v.extract    s13, v6, #9
    v.movi       v11, #0
    v.splat      v12, s13
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s13, s21, #1728
    p.and        p3, p4, p1
    v.extract    s20, v18, #10
    v.extract    s24, v7, #10
    v.splat      v5, s20
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s20, v13, #10
    v.movi       v14, #0
    v.splat      v16, s20
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s20, #10
    a.vwrite     a1, s23, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #10
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #10
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s21, #1792
    p.and        p2, p4, p1
    v.extract    s23, v18, #11
    v.extract    s24, v7, #11
    v.splat      v5, s23
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s23, v13, #11
    v.movi       v14, #0
    v.splat      v16, s23
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s23, #11
    a.vwrite     a1, s19, v12
    v.ld.w       v3, [s13, #0]
    v.extract    s13, v20, #11
    v.movi       v5, #0
    v.splat      v8, s13
    v.extract    s13, v6, #11
    v.movi       v11, #0
    v.splat      v12, s13
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s13, s21, #1856
    p.and        p3, p4, p1
    v.extract    s19, v18, #12
    v.extract    s24, v7, #12
    v.splat      v5, s19
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s19, v13, #12
    v.movi       v14, #0
    v.splat      v16, s19
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s19, #12
    a.vwrite     a1, s20, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #12
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #12
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s21, #1920
    p.and        p2, p4, p1
    v.extract    s20, v18, #13
    v.extract    s24, v7, #13
    v.splat      v5, s20
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s20, v13, #13
    v.movi       v14, #0
    v.splat      v16, s20
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s20, #13
    a.vwrite     a1, s23, v12
    v.ld.w       v3, [s13, #0]
    v.extract    s13, v20, #13
    v.movi       v5, #0
    v.splat      v8, s13
    v.extract    s13, v6, #13
    v.movi       v11, #0
    v.splat      v12, s13
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s13, s21, #1984
    p.and        p3, p4, p1
    v.extract    s23, v18, #14
    v.extract    s24, v7, #14
    v.splat      v5, s23
    v.movi       v8, #0
    v.splat      v11, s24
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s23, v13, #14
    v.movi       v14, #0
    v.splat      v16, s23
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s23, #14
    a.vwrite     a1, s19, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #14
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #14
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s21, #2048
    p.and        p2, p4, p1
    v.extract    s19, v18, #15
    v.extract    s24, v7, #15
    v.splat      v5, s19
    v.movi       v7, #0
    v.splat      v8, s24
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s19, v13, #15
    v.movi       v12, #0
    v.splat      v13, s19
    v.cmp.ne     p3, v5, v7
    v.cmp.ne     p4, v8, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v13, v12
    p.and        p4, p5, p3
    s.movz       s19, #15
    a.vwrite     a1, s20, v11
    v.ld.w       v3, [s13, #0]
    v.extract    s13, v20, #15
    v.movi       v5, #0
    v.splat      v7, s13
    v.extract    s13, v6, #15
    v.movi       v6, #0
    v.splat      v8, s13
    v.cmp.ne     p3, v7, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v8, v6
    p.and        p4, p5, p3
    s.addi       s13, s21, #1024
    p.and        p3, p4, p1
    s.movz       s20, #192
    s.movz       s24, #0
    s.mul        s26, s25, s20
    s.mul        s20, s16, s22
    s.add        s16, s24, s28                   // the tile origin
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v3]               // index is in elements (ISA sec 9.1)
    s.addi       s24, s21, #2112
    s.add        s25, s16, s26                   // the tile origin
    s.addi       s16, s21, #1024
    s.add        s26, s25, s20                   // the tile origin
    s.addi       s20, s24, #64
    v.splat      v3, s26
    s.addi       s25, s26, #1
    a.vwrite     a1, s23, v5
    v.ld.w       v5, [s3, #0]
    v.splat      v6, s25
    s.addi       s3, s21, #1024
    s.addi       s23, s26, #2
    s.addi       s25, s24, #128
    v.splat      v7, s23
    s.addi       s23, s21, #1024
    s.addi       s27, s26, #3
    v.splat      v8, s27
    s.addi       s27, s24, #192
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s2, v5]              // index is in elements (ISA sec 9.1)
    s.addi       s29, s21, #1024
    a.vwrite     a1, s19, v11
    v.ld.w       v5, [s13, #0]
    s.addi       s13, s26, #4
    s.addi       s19, s24, #256
    v.splat      v11, s13
    s.addi       s13, s21, #1024
    v.add        v12, v5, v3
    v.st.w       [s24, #0], v12
    v.ld.w       v3, [s16, #0]
    s.addi       s16, s26, #5
    v.splat      v5, s16
    s.addi       s16, s24, #320
    v.add        v12, v3, v6
    v.st.w       [s20, #0], v12
    s.addi       s20, s21, #1024
    v.ld.w       v3, [s3, #0]
    s.addi       s3, s26, #6
    v.splat      v6, s3
    s.addi       s3, s24, #384
    v.add        v12, v3, v7
    v.st.w       [s25, #0], v12
    s.addi       s25, s21, #1024
    v.ld.w       v3, [s23, #0]
    s.addi       s23, s26, #7
    v.splat      v7, s23
    s.addi       s23, s24, #448
    v.add        v12, v3, v8
    v.st.w       [s27, #0], v12
    s.addi       s27, s21, #1024
    v.ld.w       v3, [s29, #0]
    s.addi       s29, s26, #8
    v.splat      v8, s29
    s.addi       s29, s24, #512
    v.add        v12, v3, v11
    v.st.w       [s19, #0], v12
    s.addi       s19, s21, #1024
    v.ld.w       v3, [s13, #0]
    s.addi       s13, s26, #9
    v.splat      v11, s13
    s.addi       s13, s24, #576
    v.add        v12, v3, v5
    v.st.w       [s16, #0], v12
    s.addi       s16, s21, #1024
    v.ld.w       v3, [s20, #0]
    s.addi       s20, s26, #10
    v.splat      v5, s20
    s.addi       s20, s24, #640
    v.add        v12, v3, v6
    v.st.w       [s3, #0], v12
    s.addi       s3, s21, #1024
    v.ld.w       v3, [s25, #0]
    s.addi       s25, s26, #11
    v.splat      v6, s25
    s.addi       s25, s24, #704
    v.add        v12, v3, v7
    v.st.w       [s23, #0], v12
    s.addi       s23, s21, #1024
    v.ld.w       v3, [s27, #0]
    s.addi       s27, s26, #12
    v.splat      v7, s27
    s.addi       s27, s24, #768
    v.add        v12, v3, v8
    v.st.w       [s29, #0], v12
    s.addi       s29, s21, #1024
    v.ld.w       v3, [s19, #0]
    s.addi       s19, s26, #13
    v.splat      v8, s19
    s.addi       s19, s24, #832
    v.add        v12, v3, v11
    v.st.w       [s13, #0], v12
    s.addi       s13, s21, #1024
    v.splat      v3, s22
    v.ld.w       v11, [s16, #0]
    s.addi       s16, s26, #14
    s.addi       s30, s26, #15
    v.splat      v12, s16
    s.addi       s16, s24, #896
    v.splat      v13, s30
    s.addi       s26, s21, #1024
    s.addi       s30, s24, #960
    v.add        v14, v11, v5
    v.st.w       [s20, #0], v14
    s.addi       s20, s21, #2112
    v.splat      v5, s22
    s.movz       s22, #0
    s.add        s24, s22, s12                   // the tile origin
    v.splat      v11, s24
    s.movz       s22, #0
    s.add        s24, s22, s28                   // the tile origin
    v.add        v14, v15, v11
    v.splat      v11, s24
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s22, #0
    v.cmp.lt     p1, v14, v5
    v.cmp.lt     p2, v11, v3
    v.ld.w       v5, [s3, #0]
    p.and        p3, p2, p1
    v.add        v11, v5, v6
    s.movz       s3, #1
    v.st.w       [s25, #0], v11
    s.addi       s25, s21, #2176
    v.ld.w       v5, [s23, #0]
    s.addi       s23, s24, #1
    v.splat      v6, s23
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    v.add        v6, v5, v7
    v.st.w       [s27, #0], v6
    s.addi       s23, s21, #2240
    s.movz       s27, #2
    v.ld.w       v5, [s29, #0]
    s.addi       s28, s24, #2
    v.splat      v6, s28
    v.add        v7, v5, v8
    v.cmp.lt     p2, v6, v3
    v.st.w       [s19, #0], v7
    p.and        p5, p2, p1
    v.ld.w       v5, [s13, #0]
    s.addi       s13, s21, #2304
    s.movz       s19, #3
    v.add        v6, v5, v12
    s.addi       s28, s24, #3
    v.st.w       [s16, #0], v6
    v.splat      v5, s28
    v.ld.w       v6, [s26, #0]
    s.movz       s16, #4
    v.add        v7, v6, v13
    s.addi       s26, s21, #2368
    v.st.w       [s30, #0], v7
    fence.acq_rel.device
    s.addi       s28, s24, #4
    v.splat      v6, s28
    v.ld.w       v7, [s20, #0]
    s.addi       s20, s21, #2432
    s.addi       s28, s24, #5
    s.movz       s29, #5
    v.splat      v8, s28
    s.movz       s28, #6
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s5, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s22, v11
    v.ld.w       v5, [s25, #0]
    s.addi       s22, s21, #2496
    s.addi       s25, s24, #6
    v.splat      v7, s25
    s.movz       s25, #7
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    a.vwrite     a2, s3, v11
    v.ld.w       v5, [s23, #0]
    s.addi       s3, s21, #2560
    s.addi       s23, s24, #7
    v.splat      v6, s23
    s.movz       s23, #8
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v3
    p.and        p5, p2, p1
    a.vwrite     a2, s27, v11
    v.ld.w       v5, [s13, #0]
    s.addi       s13, s21, #2624
    s.addi       s27, s24, #8
    v.splat      v8, s27
    s.movz       s27, #9
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s19, v11
    v.ld.w       v5, [s26, #0]
    s.addi       s19, s21, #2688
    s.addi       s26, s24, #9
    v.splat      v7, s26
    s.movz       s26, #10
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    a.vwrite     a2, s16, v11
    v.ld.w       v5, [s20, #0]
    s.addi       s16, s21, #2752
    s.addi       s20, s24, #10
    v.splat      v6, s20
    s.movz       s20, #11
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v3
    p.and        p5, p2, p1
    a.vwrite     a2, s29, v11
    v.ld.w       v5, [s22, #0]
    s.addi       s22, s21, #2816
    s.addi       s29, s24, #11
    v.splat      v8, s29
    s.movz       s29, #12
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s28, v11
    v.ld.w       v5, [s3, #0]
    s.addi       s3, s21, #2880
    s.addi       s28, s24, #12
    v.splat      v7, s28
    s.movz       s28, #13
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    a.vwrite     a2, s25, v11
    v.ld.w       v5, [s13, #0]
    s.addi       s13, s21, #2944
    s.addi       s25, s24, #13
    v.splat      v6, s25
    s.movz       s25, #14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v3
    p.and        p5, p2, p1
    a.vwrite     a2, s23, v11
    v.ld.w       v5, [s19, #0]
    s.addi       s19, s21, #3008
    s.addi       s23, s24, #14
    v.splat      v8, s23
    s.movz       s23, #15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s27, v11
    v.ld.w       v5, [s16, #0]
    s.addi       s16, s21, #3072
    s.addi       s27, s24, #15
    v.movi       v7, #0
    v.splat      v11, s27
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v12, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s24, #0
    a.vwrite     a2, s26, v12
    v.ld.w       v5, [s22, #0]
    s.movz       s22, #0
    s.movz       s26, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v6, [s5, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v3
    p.and        p5, p2, p1
    a.vwrite     a2, s20, v6
    v.ld.w       v5, [s3, #0]
    s.movz       s3, #1
    s.movz       s20, #2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s5, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v11, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s29, v6
    v.ld.w       v3, [s13, #0]
    s.movz       s13, #3
    s.movz       s27, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v5, [s5, v3]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s28, v5
    v.ld.w       v3, [s19, #0]
    s.movz       s19, #5
    s.movz       s28, #6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v5, [s5, v3]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s25, v5
    v.ld.w       v3, [s16, #0]
    s.movz       s16, #7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v5, [s5, v3]               // index is in elements (ISA sec 9.1)
    s.movz       s25, #8
    a.vwrite     a2, s23, v5
    a.vread      v3, a1, s22
    a.vread      v5, a2, s26
    a.vread      v6, a2, s3
    v.extract    s3, v3, #0
    v.extract    s22, v3, #1
    v.splat      v8, s3
    v.splat      v11, s22
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s20
    v.extract    s3, v3, #3
    a.vread      v13, a2, s13
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s27
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s19
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s28
    v.extract    s3, v3, #7
    a.vread      v15, a2, s16
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #1
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s25, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s26, #7
    s.movz       s27, #8
    s.movz       s28, #1
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s24, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s25
    v.extract    s3, v3, #7
    a.vread      v15, a2, s26
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s27
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #2
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s27, #2
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s28, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #3
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s28, #3
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #4
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s27, #4
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s28, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #5
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s28, #5
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #6
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s27, #6
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s28, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #7
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s28, #7
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #8
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s27, #8
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s28, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #9
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s28, #9
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #10
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s27, #10
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s28, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #11
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s28, #11
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #12
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s27, #12
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s28, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #13
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s28, #13
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #14
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s27, #14
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s28, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s20
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v15, a2, s13
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v14, a2, s13
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v13, a2, s13
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #15
    s.movz       s13, #0
    s.movz       s16, #1
    s.movz       s19, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s20, #3
    s.movz       s22, #4
    s.movz       s23, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s28, #15
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s13
    a.vread      v6, a2, s16
    v.extract    s3, v3, #0
    v.extract    s13, v3, #1
    v.splat      v8, s3
    v.splat      v11, s13
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v7, a2, s19
    v.extract    s3, v3, #3
    a.vread      v8, a2, s20
    vf.fma       v13, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s22
    v.splat      v12, s3
    vf.fma       v14, v5, v7, v13
    v.extract    s3, v3, #5
    a.vread      v5, a2, s23
    v.splat      v7, s3
    v.extract    s3, v3, #6
    vf.fma       v13, v6, v8, v14
    v.splat      v6, s3
    a.vread      v8, a2, s24
    v.extract    s3, v3, #7
    a.vread      v14, a2, s25
    vf.fma       v15, v12, v11, v13
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v13, s3
    vf.fma       v16, v7, v5, v15
    v.extract    s3, v3, #9
    s.movz       s13, #9
    v.splat      v5, s3
    a.vread      v7, a2, s13
    vf.fma       v15, v6, v8, v16
    v.extract    s3, v3, #10
    s.movz       s13, #10
    v.splat      v6, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v11, v14, v15
    v.extract    s3, v3, #11
    s.movz       s13, #11
    v.splat      v11, s3
    a.vread      v14, a2, s13
    vf.fma       v15, v13, v12, v16
    v.extract    s3, v3, #12
    s.movz       s13, #12
    v.splat      v12, s3
    a.vread      v13, a2, s13
    vf.fma       v16, v5, v7, v15
    v.extract    s3, v3, #13
    s.movz       s13, #13
    v.splat      v5, s3
    a.vread      v7, a2, s13
    vf.fma       v15, v6, v8, v16
    v.extract    s3, v3, #14
    s.movz       s13, #14
    v.splat      v6, s3
    a.vread      v8, a2, s13
    vf.fma       v16, v11, v14, v15
    v.extract    s3, v3, #15
    s.movz       s13, #15
    v.splat      v3, s3
    a.vread      v11, a2, s13
    vf.fma       v14, v12, v13, v16
    s.movz       s3, #0
    s.movz       s13, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s16, #0
    s.movz       s19, #1
    vf.fma       v12, v5, v7, v14
    s.movz       s20, #1
    s.movz       s22, #1
    s.movz       s23, #2
    s.movz       s24, #2
    vf.fma       v5, v6, v8, v12
    s.movz       s25, #2
    s.movz       s26, #3
    s.movz       s27, #3
    s.movz       s29, #3
    vf.fma       v6, v3, v11, v5
    s.movz       s30, #4
    a.vwrite     a3, s28, v6
    a.vread      v3, a0, s3
    a.vread      v5, a3, s13
    s.movz       s3, #4
    s.movz       s13, #4
    vf.add       v6, v3, v5
    s.movz       s28, #5
    a.vwrite     a4, s16, v6
    a.vread      v3, a0, s19
    a.vread      v5, a3, s20
    s.movz       s16, #5
    s.movz       s19, #5
    vf.add       v6, v3, v5
    s.movz       s20, #6
    a.vwrite     a4, s22, v6
    a.vread      v3, a0, s23
    a.vread      v5, a3, s24
    s.movz       s22, #6
    s.movz       s23, #6
    vf.add       v6, v3, v5
    s.movz       s24, #7
    a.vwrite     a4, s25, v6
    a.vread      v3, a0, s26
    a.vread      v5, a3, s27
    s.movz       s25, #7
    s.movz       s26, #7
    vf.add       v6, v3, v5
    s.movz       s27, #8
    a.vwrite     a4, s29, v6
    a.vread      v3, a0, s30
    a.vread      v5, a3, s3
    s.movz       s3, #8
    s.movz       s29, #8
    vf.add       v6, v3, v5
    s.movz       s30, #9
    a.vwrite     a4, s13, v6
    a.vread      v3, a0, s28
    a.vread      v5, a3, s16
    s.movz       s13, #9
    s.movz       s16, #9
    vf.add       v6, v3, v5
    s.movz       s28, #10
    a.vwrite     a4, s19, v6
    a.vread      v3, a0, s20
    a.vread      v5, a3, s22
    s.movz       s19, #10
    s.movz       s20, #10
    vf.add       v6, v3, v5
    s.movz       s22, #11
    a.vwrite     a4, s23, v6
    a.vread      v3, a0, s24
    a.vread      v5, a3, s25
    s.movz       s23, #11
    s.movz       s24, #11
    vf.add       v6, v3, v5
    s.movz       s25, #12
    a.vwrite     a4, s26, v6
    a.vread      v3, a0, s27
    a.vread      v5, a3, s3
    s.movz       s3, #12
    s.movz       s26, #12
    vf.add       v6, v3, v5
    s.movz       s27, #13
    a.vwrite     a4, s29, v6
    a.vread      v3, a0, s30
    a.vread      v5, a3, s13
    s.movz       s13, #13
    s.movz       s29, #13
    vf.add       v6, v3, v5
    s.movz       s30, #14
    a.vwrite     a4, s16, v6
    a.vread      v3, a0, s28
    a.vread      v5, a3, s19
    s.movz       s16, #14
    s.movz       s19, #14
    vf.add       v6, v3, v5
    s.movz       s28, #15
    a.vwrite     a4, s20, v6
    a.vread      v3, a0, s22
    a.vread      v5, a3, s23
    s.movz       s20, #15
    s.movz       s22, #15
    vf.add       v6, v3, v5
    s.movz       s23, #0
    a.vwrite     a4, s24, v6
    a.vread      v3, a0, s25
    a.vread      v5, a3, s3
    s.movz       s3, #0
    s.movz       s24, #1
    vf.add       v6, v3, v5
    s.movz       s25, #1
    a.vwrite     a4, s26, v6
    a.vread      v3, a0, s27
    a.vread      v5, a3, s13
    s.movz       s13, #2
    s.movz       s26, #2
    vf.add       v6, v3, v5
    s.movz       s27, #3
    a.vwrite     a4, s29, v6
    a.vread      v3, a0, s30
    a.vread      v5, a3, s16
    s.movz       s16, #3
    s.movz       s29, #4
    vf.add       v6, v3, v5
    s.movz       s30, #4
    a.vwrite     a4, s19, v6
    a.vread      v3, a0, s28
    a.vread      v5, a3, s20
    s.movz       s19, #5
    s.movz       s20, #5
    vf.add       v6, v3, v5
    s.movz       s28, #6
    a.vwrite     a4, s22, v6
    a.vread      v3, a4, s23
    s.movz       s22, #6
    s.movz       s23, #7
    a.vwrite     a0, s3, v3
    a.vread      v3, a4, s24
    s.movz       s3, #7
    s.movz       s24, #8
    a.vwrite     a0, s25, v3
    a.vread      v3, a4, s13
    s.movz       s13, #8
    s.movz       s25, #9
    a.vwrite     a0, s26, v3
    a.vread      v3, a4, s27
    s.movz       s26, #9
    s.movz       s27, #10
    a.vwrite     a0, s16, v3
    a.vread      v3, a4, s29
    s.movz       s16, #10
    s.movz       s29, #11
    a.vwrite     a0, s30, v3
    a.vread      v3, a4, s19
    s.movz       s19, #11
    s.movz       s30, #12
    a.vwrite     a0, s20, v3
    a.vread      v3, a4, s28
    s.movz       s20, #12
    s.movz       s28, #13
    a.vwrite     a0, s22, v3
    a.vread      v3, a4, s23
    s.movz       s22, #13
    s.movz       s23, #14
    a.vwrite     a0, s3, v3
    a.vread      v3, a4, s24
    s.movz       s3, #14
    s.movz       s24, #15
    a.vwrite     a0, s13, v3
    a.vread      v3, a4, s25
    s.movz       s13, #15
    s.add        s25, s18, s17
    a.vwrite     a0, s26, v3
    a.vread      v3, a4, s27
    s.movz       s26, #1
    a.vwrite     a0, s16, v3
    a.vread      v3, a4, s29
    a.vwrite     a0, s19, v3
    a.vread      v3, a4, s30
    a.vwrite     a0, s20, v3
    a.vread      v3, a4, s28
    a.vwrite     a0, s22, v3
    a.vread      v3, a4, s23
    a.vwrite     a0, s3, v3
    a.vread      v3, a4, s24
    a.vwrite     a0, s13, v3
    s.mov        s18, s25
    br.nz        s26, for_5
endfor_6:
    s.muli       s1, s12, #3136                  // a runtime tile origin, x3136
    v.extract    s2, v10, #0
    s.movz       s3, #56
    s.movz       s5, #3136
    s.movz       s13, #0
    v.splat      v0, s2
    v.splat      v3, s3
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s5
    v.extract    s2, v9, #0
    s.add        s3, s13, s1                     // the tile origin
    v.splat      v7, s2
    v.mul        v8, v0, v3
    v.mul        v0, v5, v6
    v.splat      v5, s3
    v.extract    s1, v4, #0
    v.add        v6, v7, v8
    v.add        v7, v0, v5
    v.splat      v0, s1
    v.splat      v5, s15
    v.add        v8, v6, v7
    s.movz       s1, #3136
    v.mul        v6, v0, v5
    s.muli       s2, s12, #4                     // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s3, s12, #4                     // a runtime tile origin, x4
    v.add        v0, v8, v6
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s5, s12, #4                     // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s13, s12, #4                    // a runtime tile origin, x4
    v.movi       v6, #8
    v.splat      v8, s1
    v.movi       v11, #1
    v.movi       v12, #0
    v.movi       v13, #1
    v.movi       v14, #0
    v.movi       v15, #1
    v.movi       v16, #0
    v.movi       v17, #64
    v.cmp.lt     p1, v4, v6
    v.movi       v6, #0
    v.cmp.lt     p2, v10, v1
    v.cmp.lt     p3, v9, v1
    v.cmp.lt     p4, v0, v6
    @p1 v.sel        v1, v11, v12
    v.sub        v11, v6, v0
    v.sub        v12, v6, v8
    v.cmp.lt     p1, v8, v6
    @p2 v.sel        v18, v13, v14
    @p3 v.sel        v13, v15, v16
    v.cmp.lt     p2, v2, v17
    s.add        s1, s6, s2                      // the tile origin
    s.add        s2, s7, s3                      // the tile origin
    s.add        s3, s8, s5                      // the tile origin
    s.add        s5, s9, s13                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s6, s21, #3136
    v.movi       v2, #1
    @p4 v.sel        v14, v11, v0
    @p1 v.sel        v0, v12, v8
    v.movi       v11, #0
    v.movi       v12, #0
    s.movz       s7, #31
idiv_7:
    v.splat      v15, s7
    v.shl        v16, v12, v2
    v.cmp.lt     p1, v12, v6
    v.lshr       v17, v14, v15
    v.shl        v19, v2, v15
    s.subi       s8, s7, #1
    v.and        v15, v17, v2
    s.movz       s9, #0
    v.or         v17, v16, v15
    v.cmp.geu    p3, v17, v0
    p.or         p5, p1, p3
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v6
    @p5 v.sel        v19, v15, v17
    v.or         v15, v11, v16
    v.mov        v12, v19
    v.mov        v11, v15
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_7
    v.extract    s7, v10, #1
    v.extract    s8, v9, #1
    v.splat      v0, s7
    v.splat      v2, s8
    v.extract    s7, v4, #1
    v.mul        v11, v0, v3
    v.sub        v0, v6, v12
    v.splat      v6, s7
    v.add        v14, v2, v11
    v.extract    s7, v4, #0
    @p4 v.sel        v2, v0, v12
    v.splat      v0, s7
    v.add        v11, v14, v7
    v.mul        v12, v6, v5
    v.add        v6, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v11, v12
    v.movi       v11, #0
    v.add        v12, v6, v2
    s.addi       s7, s6, #64
    v.sub        v2, v11, v0
    v.sub        v6, v11, v8
    v.cmp.lt     p1, v0, v11
    v.cmp.lt     p3, v8, v11
    v.st.w       [s6, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v6, v8
    v.movi       v2, #0
    v.movi       v6, #0
    s.movz       s8, #31
idiv_8:
    v.splat      v15, s8
    v.shl        v16, v6, v12
    v.cmp.lt     p3, v6, v11
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s8, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v11
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v6, v19
    v.mov        v2, v15
    s.mov        s8, s9
    s.cmp.ge     s9, s8, s12
    br.nz        s9, idiv_8
    v.extract    s8, v10, #2
    v.extract    s9, v9, #2
    v.splat      v0, s8
    v.splat      v2, s9
    v.extract    s8, v4, #2
    v.mul        v12, v0, v3
    v.sub        v0, v11, v6
    v.splat      v11, s8
    v.add        v14, v2, v12
    v.extract    s8, v4, #1
    @p1 v.sel        v2, v0, v6
    v.splat      v0, s8
    v.add        v6, v14, v7
    v.mul        v12, v11, v5
    v.add        v11, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v6, v12
    v.movi       v6, #0
    v.add        v12, v11, v2
    s.addi       s8, s6, #128
    v.sub        v2, v6, v0
    v.sub        v11, v6, v8
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v8, v6
    v.st.w       [s7, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v11, v8
    v.movi       v2, #0
    v.movi       v11, #0
    s.movz       s7, #31
idiv_9:
    v.splat      v15, s7
    v.shl        v16, v11, v12
    v.cmp.lt     p3, v11, v6
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s7, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v6
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v11, v19
    v.mov        v2, v15
    s.mov        s7, s9
    s.cmp.ge     s9, s7, s12
    br.nz        s9, idiv_9
    v.extract    s7, v10, #3
    v.extract    s9, v9, #3
    v.splat      v0, s7
    v.splat      v2, s9
    v.extract    s7, v4, #3
    v.mul        v12, v0, v3
    v.sub        v0, v6, v11
    v.splat      v6, s7
    v.add        v14, v2, v12
    v.extract    s7, v4, #2
    @p1 v.sel        v2, v0, v11
    v.splat      v0, s7
    v.add        v11, v14, v7
    v.mul        v12, v6, v5
    v.add        v6, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v11, v12
    v.movi       v11, #0
    v.add        v12, v6, v2
    s.addi       s7, s6, #192
    v.sub        v2, v11, v0
    v.sub        v6, v11, v8
    v.cmp.lt     p1, v0, v11
    v.cmp.lt     p3, v8, v11
    v.st.w       [s8, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v6, v8
    v.movi       v2, #0
    v.movi       v6, #0
    s.movz       s8, #31
idiv_10:
    v.splat      v15, s8
    v.shl        v16, v6, v12
    v.cmp.lt     p3, v6, v11
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s8, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v11
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v6, v19
    v.mov        v2, v15
    s.mov        s8, s9
    s.cmp.ge     s9, s8, s12
    br.nz        s9, idiv_10
    v.extract    s8, v10, #4
    v.extract    s9, v9, #4
    v.splat      v0, s8
    v.splat      v2, s9
    v.extract    s8, v4, #4
    v.mul        v12, v0, v3
    v.sub        v0, v11, v6
    v.splat      v11, s8
    v.add        v14, v2, v12
    v.extract    s8, v4, #3
    @p1 v.sel        v2, v0, v6
    v.splat      v0, s8
    v.add        v6, v14, v7
    v.mul        v12, v11, v5
    v.add        v11, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v6, v12
    v.movi       v6, #0
    v.add        v12, v11, v2
    s.addi       s8, s6, #256
    v.sub        v2, v6, v0
    v.sub        v11, v6, v8
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v8, v6
    v.st.w       [s7, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v11, v8
    v.movi       v2, #0
    v.movi       v11, #0
    s.movz       s7, #31
idiv_11:
    v.splat      v15, s7
    v.shl        v16, v11, v12
    v.cmp.lt     p3, v11, v6
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s7, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v6
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v11, v19
    v.mov        v2, v15
    s.mov        s7, s9
    s.cmp.ge     s9, s7, s12
    br.nz        s9, idiv_11
    v.extract    s7, v10, #5
    v.extract    s9, v9, #5
    v.splat      v0, s7
    v.splat      v2, s9
    v.extract    s7, v4, #5
    v.mul        v12, v0, v3
    v.sub        v0, v6, v11
    v.splat      v6, s7
    v.add        v14, v2, v12
    v.extract    s7, v4, #4
    @p1 v.sel        v2, v0, v11
    v.splat      v0, s7
    v.add        v11, v14, v7
    v.mul        v12, v6, v5
    v.add        v6, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v11, v12
    v.movi       v11, #0
    v.add        v12, v6, v2
    s.addi       s7, s6, #320
    v.sub        v2, v11, v0
    v.sub        v6, v11, v8
    v.cmp.lt     p1, v0, v11
    v.cmp.lt     p3, v8, v11
    v.st.w       [s8, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v6, v8
    v.movi       v2, #0
    v.movi       v6, #0
    s.movz       s8, #31
idiv_12:
    v.splat      v15, s8
    v.shl        v16, v6, v12
    v.cmp.lt     p3, v6, v11
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s8, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v11
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v6, v19
    v.mov        v2, v15
    s.mov        s8, s9
    s.cmp.ge     s9, s8, s12
    br.nz        s9, idiv_12
    v.extract    s8, v10, #6
    v.extract    s9, v9, #6
    v.splat      v0, s8
    v.splat      v2, s9
    v.extract    s8, v4, #6
    v.mul        v12, v0, v3
    v.sub        v0, v11, v6
    v.splat      v11, s8
    v.add        v14, v2, v12
    v.extract    s8, v4, #5
    @p1 v.sel        v2, v0, v6
    v.splat      v0, s8
    v.add        v6, v14, v7
    v.mul        v12, v11, v5
    v.add        v11, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v6, v12
    v.movi       v6, #0
    v.add        v12, v11, v2
    s.addi       s8, s6, #384
    v.sub        v2, v6, v0
    v.sub        v11, v6, v8
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v8, v6
    v.st.w       [s7, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v11, v8
    v.movi       v2, #0
    v.movi       v11, #0
    s.movz       s7, #31
idiv_13:
    v.splat      v15, s7
    v.shl        v16, v11, v12
    v.cmp.lt     p3, v11, v6
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s7, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v6
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v11, v19
    v.mov        v2, v15
    s.mov        s7, s9
    s.cmp.ge     s9, s7, s12
    br.nz        s9, idiv_13
    v.extract    s7, v10, #7
    v.extract    s9, v9, #7
    v.splat      v0, s7
    v.splat      v2, s9
    v.extract    s7, v4, #7
    v.mul        v12, v0, v3
    v.sub        v0, v6, v11
    v.splat      v6, s7
    v.add        v14, v2, v12
    v.extract    s7, v4, #6
    @p1 v.sel        v2, v0, v11
    v.splat      v0, s7
    v.add        v11, v14, v7
    v.mul        v12, v6, v5
    v.add        v6, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v11, v12
    v.movi       v11, #0
    v.add        v12, v6, v2
    s.addi       s7, s6, #448
    v.sub        v2, v11, v0
    v.sub        v6, v11, v8
    v.cmp.lt     p1, v0, v11
    v.cmp.lt     p3, v8, v11
    v.st.w       [s8, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v6, v8
    v.movi       v2, #0
    v.movi       v6, #0
    s.movz       s8, #31
idiv_14:
    v.splat      v15, s8
    v.shl        v16, v6, v12
    v.cmp.lt     p3, v6, v11
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s8, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v11
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v6, v19
    v.mov        v2, v15
    s.mov        s8, s9
    s.cmp.ge     s9, s8, s12
    br.nz        s9, idiv_14
    v.extract    s8, v10, #8
    v.extract    s9, v9, #8
    v.splat      v0, s8
    v.splat      v2, s9
    v.extract    s8, v4, #8
    v.mul        v12, v0, v3
    v.sub        v0, v11, v6
    v.splat      v11, s8
    v.add        v14, v2, v12
    v.extract    s8, v4, #7
    @p1 v.sel        v2, v0, v6
    v.splat      v0, s8
    v.add        v6, v14, v7
    v.mul        v12, v11, v5
    v.add        v11, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v6, v12
    v.movi       v6, #0
    v.add        v12, v11, v2
    s.addi       s8, s6, #512
    v.sub        v2, v6, v0
    v.sub        v11, v6, v8
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v8, v6
    v.st.w       [s7, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v11, v8
    v.movi       v2, #0
    v.movi       v11, #0
    s.movz       s7, #31
idiv_15:
    v.splat      v15, s7
    v.shl        v16, v11, v12
    v.cmp.lt     p3, v11, v6
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s7, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v6
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v11, v19
    v.mov        v2, v15
    s.mov        s7, s9
    s.cmp.ge     s9, s7, s12
    br.nz        s9, idiv_15
    v.extract    s7, v10, #9
    v.extract    s9, v9, #9
    v.splat      v0, s7
    v.splat      v2, s9
    v.extract    s7, v4, #9
    v.mul        v12, v0, v3
    v.sub        v0, v6, v11
    v.splat      v6, s7
    v.add        v14, v2, v12
    v.extract    s7, v4, #8
    @p1 v.sel        v2, v0, v11
    v.splat      v0, s7
    v.add        v11, v14, v7
    v.mul        v12, v6, v5
    v.add        v6, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v11, v12
    v.movi       v11, #0
    v.add        v12, v6, v2
    s.addi       s7, s6, #576
    v.sub        v2, v11, v0
    v.sub        v6, v11, v8
    v.cmp.lt     p1, v0, v11
    v.cmp.lt     p3, v8, v11
    v.st.w       [s8, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v6, v8
    v.movi       v2, #0
    v.movi       v6, #0
    s.movz       s8, #31
idiv_16:
    v.splat      v15, s8
    v.shl        v16, v6, v12
    v.cmp.lt     p3, v6, v11
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s8, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v11
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v6, v19
    v.mov        v2, v15
    s.mov        s8, s9
    s.cmp.ge     s9, s8, s12
    br.nz        s9, idiv_16
    v.extract    s8, v10, #10
    v.extract    s9, v9, #10
    v.splat      v0, s8
    v.splat      v2, s9
    v.extract    s8, v4, #10
    v.mul        v12, v0, v3
    v.sub        v0, v11, v6
    v.splat      v11, s8
    v.add        v14, v2, v12
    v.extract    s8, v4, #9
    @p1 v.sel        v2, v0, v6
    v.splat      v0, s8
    v.add        v6, v14, v7
    v.mul        v12, v11, v5
    v.add        v11, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v6, v12
    v.movi       v6, #0
    v.add        v12, v11, v2
    s.addi       s8, s6, #640
    v.sub        v2, v6, v0
    v.sub        v11, v6, v8
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v8, v6
    v.st.w       [s7, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v11, v8
    v.movi       v2, #0
    v.movi       v11, #0
    s.movz       s7, #31
idiv_17:
    v.splat      v15, s7
    v.shl        v16, v11, v12
    v.cmp.lt     p3, v11, v6
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s7, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v6
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v11, v19
    v.mov        v2, v15
    s.mov        s7, s9
    s.cmp.ge     s9, s7, s12
    br.nz        s9, idiv_17
    v.extract    s7, v10, #11
    v.extract    s9, v9, #11
    v.splat      v0, s7
    v.splat      v2, s9
    v.extract    s7, v4, #11
    v.mul        v12, v0, v3
    v.sub        v0, v6, v11
    v.splat      v6, s7
    v.add        v14, v2, v12
    v.extract    s7, v4, #10
    @p1 v.sel        v2, v0, v11
    v.splat      v0, s7
    v.add        v11, v14, v7
    v.mul        v12, v6, v5
    v.add        v6, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v11, v12
    v.movi       v11, #0
    v.add        v12, v6, v2
    s.addi       s7, s6, #704
    v.sub        v2, v11, v0
    v.sub        v6, v11, v8
    v.cmp.lt     p1, v0, v11
    v.cmp.lt     p3, v8, v11
    v.st.w       [s8, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v6, v8
    v.movi       v2, #0
    v.movi       v6, #0
    s.movz       s8, #31
idiv_18:
    v.splat      v15, s8
    v.shl        v16, v6, v12
    v.cmp.lt     p3, v6, v11
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s8, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v11
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v6, v19
    v.mov        v2, v15
    s.mov        s8, s9
    s.cmp.ge     s9, s8, s12
    br.nz        s9, idiv_18
    v.extract    s8, v10, #12
    v.extract    s9, v9, #12
    v.splat      v0, s8
    v.splat      v2, s9
    v.extract    s8, v4, #12
    v.mul        v12, v0, v3
    v.sub        v0, v11, v6
    v.splat      v11, s8
    v.add        v14, v2, v12
    v.extract    s8, v4, #11
    @p1 v.sel        v2, v0, v6
    v.splat      v0, s8
    v.add        v6, v14, v7
    v.mul        v12, v11, v5
    v.add        v11, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v6, v12
    v.movi       v6, #0
    v.add        v12, v11, v2
    s.addi       s8, s6, #768
    v.sub        v2, v6, v0
    v.sub        v11, v6, v8
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v8, v6
    v.st.w       [s7, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v11, v8
    v.movi       v2, #0
    v.movi       v11, #0
    s.movz       s7, #31
idiv_19:
    v.splat      v15, s7
    v.shl        v16, v11, v12
    v.cmp.lt     p3, v11, v6
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s7, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v6
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v11, v19
    v.mov        v2, v15
    s.mov        s7, s9
    s.cmp.ge     s9, s7, s12
    br.nz        s9, idiv_19
    v.extract    s7, v10, #13
    v.extract    s9, v9, #13
    v.splat      v0, s7
    v.splat      v2, s9
    v.extract    s7, v4, #13
    v.mul        v12, v0, v3
    v.sub        v0, v6, v11
    v.splat      v6, s7
    v.add        v14, v2, v12
    v.extract    s7, v4, #12
    @p1 v.sel        v2, v0, v11
    v.splat      v0, s7
    v.add        v11, v14, v7
    v.mul        v12, v6, v5
    v.add        v6, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v11, v12
    v.movi       v11, #0
    v.add        v12, v6, v2
    s.addi       s7, s6, #832
    v.sub        v2, v11, v0
    v.sub        v6, v11, v8
    v.cmp.lt     p1, v0, v11
    v.cmp.lt     p3, v8, v11
    v.st.w       [s8, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v6, v8
    v.movi       v2, #0
    v.movi       v6, #0
    s.movz       s8, #31
idiv_20:
    v.splat      v15, s8
    v.shl        v16, v6, v12
    v.cmp.lt     p3, v6, v11
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s8, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v11
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v6, v19
    v.mov        v2, v15
    s.mov        s8, s9
    s.cmp.ge     s9, s8, s12
    br.nz        s9, idiv_20
    v.extract    s8, v10, #14
    v.extract    s9, v9, #14
    v.splat      v0, s8
    v.splat      v2, s9
    v.extract    s8, v4, #14
    v.mul        v12, v0, v3
    v.sub        v0, v11, v6
    v.splat      v11, s8
    v.add        v14, v2, v12
    v.extract    s8, v4, #13
    @p1 v.sel        v2, v0, v6
    v.splat      v0, s8
    v.add        v6, v14, v7
    v.mul        v12, v11, v5
    v.add        v11, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v6, v12
    v.movi       v6, #0
    v.add        v12, v11, v2
    s.addi       s8, s6, #896
    v.sub        v2, v6, v0
    v.sub        v11, v6, v8
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v8, v6
    v.st.w       [s7, #0], v12
    v.movi       v12, #1
    @p1 v.sel        v14, v2, v0
    @p3 v.sel        v0, v11, v8
    v.movi       v2, #0
    v.movi       v11, #0
    s.movz       s7, #31
idiv_21:
    v.splat      v15, s7
    v.shl        v16, v11, v12
    v.cmp.lt     p3, v11, v6
    v.lshr       v17, v14, v15
    v.shl        v19, v12, v15
    s.subi       s9, s7, #1
    v.and        v15, v17, v12
    s.movz       s12, #0
    v.or         v17, v16, v15
    v.cmp.geu    p4, v17, v0
    p.or         p5, p3, p4
    v.sub        v15, v17, v0
    @p5 v.sel        v16, v19, v6
    @p5 v.sel        v19, v15, v17
    v.or         v15, v2, v16
    v.mov        v11, v19
    v.mov        v2, v15
    s.mov        s7, s9
    s.cmp.ge     s9, s7, s12
    br.nz        s9, idiv_21
    v.extract    s7, v10, #15
    v.extract    s9, v9, #15
    v.splat      v0, s7
    v.splat      v2, s9
    v.extract    s7, v4, #15
    v.mul        v9, v0, v3
    v.sub        v0, v6, v11
    v.splat      v3, s7
    v.add        v6, v2, v9
    v.extract    s7, v4, #14
    @p1 v.sel        v2, v0, v11
    v.splat      v0, s7
    v.add        v9, v6, v7
    v.mul        v6, v3, v5
    v.add        v3, v2, v7
    v.mul        v2, v0, v5
    v.add        v0, v9, v6
    v.movi       v6, #0
    v.add        v9, v3, v2
    s.addi       s7, s6, #960
    v.sub        v2, v6, v0
    v.sub        v3, v6, v8
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p3, v8, v6
    v.st.w       [s8, #0], v9
    v.movi       v9, #1
    @p1 v.sel        v10, v2, v0
    @p3 v.sel        v0, v3, v8
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s6, #31
idiv_22:
    v.splat      v8, s6
    v.shl        v11, v3, v9
    v.cmp.lt     p3, v3, v6
    v.lshr       v12, v10, v8
    v.shl        v14, v9, v8
    s.subi       s8, s6, #1
    v.and        v8, v12, v9
    s.movz       s9, #0
    v.or         v12, v11, v8
    v.cmp.geu    p4, v12, v0
    p.or         p5, p3, p4
    v.sub        v8, v12, v0
    @p5 v.sel        v11, v14, v6
    @p5 v.sel        v14, v8, v12
    v.or         v8, v2, v11
    v.mov        v3, v14
    v.mov        v2, v8
    s.mov        s6, s8
    s.cmp.ge     s8, s6, s9
    br.nz        s8, idiv_22
    v.sub        v0, v6, v3
    v.extract    s6, v4, #15
    s.addi       s8, s21, #3136
    @p1 v.sel        v2, v0, v3
    v.splat      v0, s6
    v.splat      v3, s4
    v.add        v4, v2, v7
    v.mul        v2, v0, v5
    s.addi       s6, s21, #4160
    s.addi       s9, s21, #3200
    v.add        v0, v4, v2
    s.addi       s12, s6, #64
    s.addi       s13, s21, #3264
    v.st.w       [s7, #0], v0
    fence.acq_rel.device
    s.addi       s7, s6, #128
    s.addi       s14, s21, #3328
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s6, #192
    v.add        v2, v3, v0
    v.st.w       [s6, #0], v2
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s21, #3392
    v.add        v2, v3, v0
    v.st.w       [s12, #0], v2
    s.addi       s12, s6, #256
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s21, #3456
    v.add        v2, v3, v0
    v.st.w       [s7, #0], v2
    s.addi       s7, s6, #320
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s21, #3520
    v.add        v2, v3, v0
    v.st.w       [s8, #0], v2
    s.addi       s8, s6, #384
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s21, #3584
    v.add        v2, v3, v0
    v.st.w       [s12, #0], v2
    s.addi       s12, s6, #448
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s21, #3648
    v.add        v2, v3, v0
    v.st.w       [s7, #0], v2
    s.addi       s7, s6, #512
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s21, #3712
    v.add        v2, v3, v0
    v.st.w       [s8, #0], v2
    s.addi       s8, s6, #576
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s21, #3776
    v.add        v2, v3, v0
    v.movi       v0, #0
    v.st.w       [s12, #0], v2
    s.addi       s12, s6, #640
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s21, #3840
    v.movi       v4, #0
    v.add        v5, v3, v2
    v.st.w       [s7, #0], v5
    s.addi       s7, s6, #704
    v.ld.w       v2, [s14, #0]
    s.addi       s14, s21, #3904
    v.movi       v5, #0
    v.add        v6, v3, v2
    v.st.w       [s8, #0], v6
    s.addi       s8, s6, #768
    v.ld.w       v2, [s9, #0]
    s.addi       s9, s21, #3968
    v.add        v6, v3, v2
    v.st.w       [s12, #0], v6
    s.addi       s12, s6, #832
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s21, #4032
    v.add        v6, v3, v2
    v.movi       v2, #0
    v.st.w       [s7, #0], v6
    s.addi       s7, s6, #896
    s.addi       s15, s6, #960
    v.ld.w       v6, [s14, #0]
    s.addi       s6, s21, #4096
    v.movi       v7, #0
    v.add        v8, v3, v6
    v.st.w       [s8, #0], v8
    s.addi       s8, s21, #4160
    v.ld.w       v6, [s9, #0]
    v.extract    s9, v1, #0
    v.movi       v8, #0
    v.splat      v9, s9
    v.extract    s9, v18, #0
    v.splat      v10, s9
    v.extract    s9, v13, #0
    v.cmp.ne     p1, v9, v0
    v.splat      v0, s9
    v.cmp.ne     p3, v10, v4
    p.and        p4, p1, p3
    v.cmp.ne     p1, v0, v5
    p.and        p3, p4, p1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    p.and        p1, p3, p2
    v.add        v0, v3, v6
    v.st.w       [s12, #0], v0
    s.addi       s12, s21, #4224
    v.ld.w       v0, [s13, #0]
    v.extract    s13, v1, #1
    v.splat      v4, s13
    v.extract    s13, v18, #1
    v.splat      v5, s13
    v.extract    s13, v13, #1
    v.cmp.ne     p3, v4, v2
    v.splat      v2, s13
    v.cmp.ne     p4, v5, v7
    p.and        p5, p3, p4
    v.cmp.ne     p3, v2, v8
    p.and        p4, p5, p3
    s.movz       s13, #1
    p.and        p3, p4, p2
    v.add        v2, v3, v0
    v.st.w       [s7, #0], v2
    s.addi       s7, s21, #4288
    v.ld.w       v0, [s6, #0]
    v.extract    s6, v1, #2
    v.splat      v2, s6
    s.movz       s6, #2
    v.add        v4, v3, v0
    v.movi       v0, #0
    v.st.w       [s15, #0], v4
    fence.acq_rel.device
    v.extract    s14, v18, #2
    v.movi       v3, #0
    v.splat      v4, s14
    v.cmp.ne     p4, v2, v0
    v.ld.w       v0, [s8, #0]
    v.extract    s8, v13, #2
    v.movi       v2, #0
    v.splat      v5, s8
    s.addi       s8, s21, #4352
    v.extract    s14, v1, #3
    v.movi       v6, #0
    v.splat      v7, s14
    s.movz       s14, #3
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p1, v4, v3
    p.and        p5, p4, p1
    v.cmp.ne     p1, v5, v2
    p.and        p4, p5, p1
    v.cmp.ne     p1, v7, v6
    p.and        p5, p4, p2
    a.vwrite     a5, s9, v8
    v.ld.w       v0, [s12, #0]
    v.extract    s9, v18, #3
    v.movi       v2, #0
    v.splat      v3, s9
    v.extract    s9, v13, #3
    v.movi       v4, #0
    v.splat      v5, s9
    s.addi       s9, s21, #4416
    v.extract    s12, v1, #4
    v.movi       v6, #0
    v.splat      v7, s12
    s.movz       s12, #4
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p4, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p4, p1
    v.cmp.ne     p1, v7, v6
    p.and        p4, p3, p2
    a.vwrite     a5, s13, v8
    v.ld.w       v0, [s7, #0]
    v.extract    s7, v18, #4
    v.movi       v2, #0
    v.splat      v3, s7
    v.extract    s7, v13, #4
    v.movi       v4, #0
    v.splat      v5, s7
    s.addi       s7, s21, #4480
    v.extract    s13, v1, #5
    v.movi       v6, #0
    v.splat      v7, s13
    s.movz       s13, #5
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p5, p1
    v.cmp.ne     p1, v7, v6
    p.and        p5, p3, p2
    a.vwrite     a5, s6, v8
    v.ld.w       v0, [s8, #0]
    v.extract    s6, v18, #5
    v.movi       v2, #0
    v.splat      v3, s6
    v.extract    s6, v13, #5
    v.movi       v4, #0
    v.splat      v5, s6
    s.addi       s6, s21, #4544
    v.extract    s8, v1, #6
    v.movi       v6, #0
    v.splat      v7, s8
    s.movz       s8, #6
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p4, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p4, p1
    v.cmp.ne     p1, v7, v6
    p.and        p4, p3, p2
    a.vwrite     a5, s14, v8
    v.ld.w       v0, [s9, #0]
    v.extract    s9, v18, #6
    v.movi       v2, #0
    v.splat      v3, s9
    v.extract    s9, v13, #6
    v.movi       v4, #0
    v.splat      v5, s9
    s.addi       s9, s21, #4608
    v.extract    s14, v1, #7
    v.movi       v6, #0
    v.splat      v7, s14
    s.movz       s14, #7
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p5, p1
    v.cmp.ne     p1, v7, v6
    p.and        p5, p3, p2
    a.vwrite     a5, s12, v8
    v.ld.w       v0, [s7, #0]
    v.extract    s7, v18, #7
    v.movi       v2, #0
    v.splat      v3, s7
    v.extract    s7, v13, #7
    v.movi       v4, #0
    v.splat      v5, s7
    s.addi       s7, s21, #4672
    v.extract    s12, v1, #8
    v.movi       v6, #0
    v.splat      v7, s12
    s.movz       s12, #8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p4, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p4, p1
    v.cmp.ne     p1, v7, v6
    p.and        p4, p3, p2
    a.vwrite     a5, s13, v8
    v.ld.w       v0, [s6, #0]
    v.extract    s6, v18, #8
    v.movi       v2, #0
    v.splat      v3, s6
    v.extract    s6, v13, #8
    v.movi       v4, #0
    v.splat      v5, s6
    s.addi       s6, s21, #4736
    v.extract    s13, v1, #9
    v.movi       v6, #0
    v.splat      v7, s13
    s.movz       s13, #9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p5, p1
    v.cmp.ne     p1, v7, v6
    p.and        p5, p3, p2
    a.vwrite     a5, s8, v8
    v.ld.w       v0, [s9, #0]
    v.extract    s8, v18, #9
    v.movi       v2, #0
    v.splat      v3, s8
    v.extract    s8, v13, #9
    v.movi       v4, #0
    v.splat      v5, s8
    s.addi       s8, s21, #4800
    v.extract    s9, v1, #10
    v.movi       v6, #0
    v.splat      v7, s9
    s.movz       s9, #10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p4, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p4, p1
    v.cmp.ne     p1, v7, v6
    p.and        p4, p3, p2
    a.vwrite     a5, s14, v8
    v.ld.w       v0, [s7, #0]
    v.extract    s7, v18, #10
    v.movi       v2, #0
    v.splat      v3, s7
    v.extract    s7, v13, #10
    v.movi       v4, #0
    v.splat      v5, s7
    s.addi       s7, s21, #4864
    v.extract    s14, v1, #11
    v.movi       v6, #0
    v.splat      v7, s14
    s.movz       s14, #11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p5, p1
    v.cmp.ne     p1, v7, v6
    p.and        p5, p3, p2
    a.vwrite     a5, s12, v8
    v.ld.w       v0, [s6, #0]
    v.extract    s6, v18, #11
    v.movi       v2, #0
    v.splat      v3, s6
    v.extract    s6, v13, #11
    v.movi       v4, #0
    v.splat      v5, s6
    s.addi       s6, s21, #4928
    v.extract    s12, v1, #12
    v.movi       v6, #0
    v.splat      v7, s12
    s.movz       s12, #12
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p4, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p4, p1
    v.cmp.ne     p1, v7, v6
    p.and        p4, p3, p2
    a.vwrite     a5, s13, v8
    v.ld.w       v0, [s8, #0]
    v.extract    s8, v18, #12
    v.movi       v2, #0
    v.splat      v3, s8
    v.extract    s8, v13, #12
    v.movi       v4, #0
    v.splat      v5, s8
    s.addi       s8, s21, #4992
    v.extract    s13, v1, #13
    v.movi       v6, #0
    v.splat      v7, s13
    s.movz       s13, #13
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p5, p1
    v.cmp.ne     p1, v7, v6
    p.and        p5, p3, p2
    a.vwrite     a5, s9, v8
    v.ld.w       v0, [s7, #0]
    v.extract    s7, v18, #13
    v.movi       v2, #0
    v.splat      v3, s7
    v.extract    s7, v13, #13
    v.movi       v4, #0
    v.splat      v5, s7
    s.addi       s7, s21, #5056
    v.extract    s9, v1, #14
    v.movi       v6, #0
    v.splat      v7, s9
    s.movz       s9, #14
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p4, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p4, p1
    v.cmp.ne     p1, v7, v6
    p.and        p4, p3, p2
    a.vwrite     a5, s14, v8
    v.ld.w       v0, [s6, #0]
    v.extract    s6, v18, #14
    v.movi       v2, #0
    v.splat      v3, s6
    v.extract    s6, v13, #14
    v.movi       v4, #0
    v.splat      v5, s6
    s.addi       s6, s21, #5120
    v.extract    s14, v1, #15
    v.movi       v6, #0
    v.splat      v7, s14
    s.movz       s14, #15
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p5, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p5, p1
    v.cmp.ne     p1, v7, v6
    p.and        p5, p3, p2
    a.vwrite     a5, s12, v8
    v.ld.w       v0, [s8, #0]
    v.extract    s8, v18, #15
    v.movi       v2, #0
    v.splat      v3, s8
    v.extract    s8, v13, #15
    v.movi       v4, #0
    v.splat      v5, s8
    s.addi       s8, s21, #3136
    v.splat      v6, s4
    s.addi       s4, s21, #5184
    .li       s12, #925353388
    v.splat      v7, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s10, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v3, v2
    p.and        p4, p1, p3
    v.cmp.ne     p1, v5, v4
    p.and        p3, p4, p1
    p.and        p1, p3, p2
    a.vwrite     a5, s13, v9
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s21, #3200
    s.addi       s12, s4, #64
    s.addi       s13, s21, #3264
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v2, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s9, v2
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s4, #128
    s.addi       s9, s21, #3328
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s10, v0]              // index is in elements (ISA sec 9.1)
    s.addi       s10, s4, #192
    a.vwrite     a5, s14, v2
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s21, #3392
    s.addi       s14, s4, #256
    v.add        v2, v6, v0
    v.st.w       [s4, #0], v2
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s21, #3456
    v.add        v2, v6, v0
    v.st.w       [s12, #0], v2
    s.addi       s12, s4, #320
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s21, #3520
    v.add        v2, v6, v0
    v.st.w       [s6, #0], v2
    s.addi       s6, s4, #384
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s21, #3584
    v.add        v2, v6, v0
    v.st.w       [s10, #0], v2
    s.addi       s10, s4, #448
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s21, #3648
    v.add        v2, v6, v0
    v.st.w       [s14, #0], v2
    s.addi       s14, s4, #512
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s21, #3712
    v.add        v2, v6, v0
    v.st.w       [s12, #0], v2
    s.addi       s12, s4, #576
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s21, #3776
    v.add        v2, v6, v0
    v.st.w       [s6, #0], v2
    s.addi       s6, s4, #640
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s21, #3840
    v.movi       v2, #0
    v.add        v3, v6, v0
    v.st.w       [s10, #0], v3
    s.addi       s10, s4, #704
    v.movi       v0, #0
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s21, #3904
    v.add        v4, v6, v3
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #768
    v.movi       v3, #0
    v.ld.w       v4, [s7, #0]
    s.addi       s7, s21, #3968
    v.add        v5, v6, v4
    v.st.w       [s12, #0], v5
    s.addi       s12, s4, #832
    v.ld.w       v4, [s13, #0]
    s.addi       s13, s21, #4032
    v.add        v5, v6, v4
    v.st.w       [s6, #0], v5
    s.addi       s6, s4, #896
    v.movi       v4, #0
    s.addi       s15, s4, #960
    v.ld.w       v5, [s9, #0]
    s.addi       s4, s21, #4096
    v.add        v9, v6, v5
    v.movi       v5, #0
    v.st.w       [s10, #0], v9
    v.extract    s9, v1, #0
    v.splat      v9, s9
    v.extract    s9, v18, #0
    v.splat      v10, s9
    v.extract    s9, v13, #0
    v.cmp.ne     p1, v9, v4
    v.cmp.ne     p3, v10, v5
    p.and        p4, p1, p3
    v.ld.w       v4, [s8, #0]
    v.splat      v5, s9
    s.movz       s8, #0
    v.extract    s9, v1, #0
    v.splat      v9, s9
    v.extract    s9, v18, #0
    v.splat      v10, s9
    v.extract    s9, v13, #0
    v.cmp.ne     p1, v9, v2
    v.splat      v2, s9
    v.cmp.ne     p3, v10, v0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v2, v3
    p.and        p3, p5, p1
    p.and        p1, p3, p2
    v.add        v0, v6, v4
    v.movi       v2, #0
    v.st.w       [s14, #0], v0
    v.cmp.ne     p3, v5, v2
    p.and        p5, p4, p3
    p.and        p3, p5, p2
    v.ld.w       v0, [s7, #0]
    v.add        v2, v6, v0
    v.st.w       [s12, #0], v2
    .li       s7, #1077936128
    v.splat      v0, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v2, [s13, #0]
    v.add        v3, v6, v2
    .li       s7, #3204448256
    v.splat      v2, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s6, #0], v3
    v.ld.w       v3, [s4, #0]
    v.add        v4, v6, v3
    v.st.w       [s15, #0], v4
    fence.acq_rel.device
    a.vread      v3, a0, s8
    v.extract    s4, v1, #0
    v.extract    s6, v18, #0
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #0
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p4, v4, v5
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s2, #0]
    v.cmp.ne     p3, v6, v9
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    p.and        p3, p4, p2
    vf.add       v6, v5, v7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s1, #0]
    v.movi       v9, #0
    v.rsqrt.approx v10, v6                       // ISA 8.8: <= 2**-22 relative
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v11, [s3, #0]
    vf.sub       v12, v3, v5
    v.extract    s4, v18, #0
    v.movi       v3, #0
    v.splat      v5, s4
    v.extract    s4, v13, #0
    v.cmp.ne     p1, v4, v9
    v.splat      v4, s4
    v.movi       v9, #0
    v.cmp.ne     p3, v5, v3
    p.and        p4, p1, p3
    v.cmp.ne     p1, v4, v9
    p.and        p3, p4, p1
    s.movz       s4, #0
    vf.mul       v3, v10, v10
    vf.mul       v4, v10, v2
    p.and        p1, p3, p2
    s.addi       s6, s21, #5184
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s5, #0]
    vf.fms       v9, v6, v3, v0
    a.vread      v3, a5, s4
    v.extract    s4, v1, #0
    v.movi       v6, #0
    vf.mul       v14, v4, v9                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s7, v18, #0
    v.splat      v4, s4
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v9, v14, v10
    v.splat      v10, s7
    v.cmp.ne     p1, v4, v6
    vf.mul       v4, v12, v9
    v.movi       v6, #0
    v.extract    s4, v13, #0
    v.ld.w       v9, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v11
    v.extract    s4, v1, #1
    v.extract    s6, v18, #1
    v.splat      v4, s4
    v.cmp.ne     p3, v10, v6
    vf.add       v6, v14, v5
    v.movi       v5, #0
    v.splat      v10, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v5
    vf.add       v4, v6, v3
    v.extract    s4, v13, #1
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v10, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #1
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v9], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #1
    v.extract    s6, v18, #1
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #1
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #1
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #1
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #1
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #1
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #1
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #1
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #1
    p.and        p1, p3, p2
    s.addi       s6, s21, #5248
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #1
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #1
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #1
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #2
    v.extract    s6, v18, #2
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #2
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #2
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #2
    v.extract    s6, v18, #2
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #2
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #2
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #2
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #2
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #2
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #2
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #2
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #2
    p.and        p1, p3, p2
    s.addi       s6, s21, #5312
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #2
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #2
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #2
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #3
    v.extract    s6, v18, #3
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #3
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #3
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #3
    v.extract    s6, v18, #3
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #3
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #3
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #3
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #3
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #3
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #3
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #3
    p.and        p1, p3, p2
    s.addi       s6, s21, #5376
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #3
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #3
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #3
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #4
    v.extract    s6, v18, #4
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #4
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #4
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #4
    v.extract    s6, v18, #4
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #4
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #4
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #4
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #4
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #4
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #4
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #4
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #4
    p.and        p1, p3, p2
    s.addi       s6, s21, #5440
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #4
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #4
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #4
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #5
    v.extract    s6, v18, #5
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #5
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #5
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #5
    v.extract    s6, v18, #5
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #5
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #5
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #5
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #5
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #5
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #5
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #5
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #5
    p.and        p1, p3, p2
    s.addi       s6, s21, #5504
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #5
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #5
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #5
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #6
    v.extract    s6, v18, #6
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #6
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #6
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #6
    v.extract    s6, v18, #6
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #6
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #6
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #6
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #6
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #6
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #6
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #6
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #6
    p.and        p1, p3, p2
    s.addi       s6, s21, #5568
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #6
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #6
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #6
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #7
    v.extract    s6, v18, #7
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #7
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #7
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #7
    v.extract    s6, v18, #7
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #7
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #7
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #7
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #7
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #7
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #7
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #7
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #7
    p.and        p1, p3, p2
    s.addi       s6, s21, #5632
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #7
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #7
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #7
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #8
    v.extract    s6, v18, #8
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #8
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #8
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #8
    v.extract    s6, v18, #8
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #8
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #8
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #8
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #8
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #8
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #8
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #8
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #8
    p.and        p1, p3, p2
    s.addi       s6, s21, #5696
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #8
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #8
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #8
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #9
    v.extract    s6, v18, #9
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #9
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #9
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #9
    v.extract    s6, v18, #9
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #9
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #9
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #9
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #9
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #9
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #9
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #9
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #9
    p.and        p1, p3, p2
    s.addi       s6, s21, #5760
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #9
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #9
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #9
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #10
    v.extract    s6, v18, #10
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #10
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #10
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #10
    v.extract    s6, v18, #10
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #10
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #10
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #10
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #10
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #10
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #10
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #10
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #10
    p.and        p1, p3, p2
    s.addi       s6, s21, #5824
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #10
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #10
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #10
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #11
    v.extract    s6, v18, #11
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #11
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #11
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #11
    v.extract    s6, v18, #11
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #11
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #11
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #11
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #11
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #11
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #11
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #11
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #11
    p.and        p1, p3, p2
    s.addi       s6, s21, #5888
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #11
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #11
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #11
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #12
    v.extract    s6, v18, #12
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #12
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #12
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #12
    v.extract    s6, v18, #12
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #12
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #12
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #12
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #12
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #12
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #12
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #12
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #12
    p.and        p1, p3, p2
    s.addi       s6, s21, #5952
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #12
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #12
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #12
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #13
    v.extract    s6, v18, #13
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #13
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #13
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #13
    v.extract    s6, v18, #13
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #13
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #13
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #13
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #13
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #13
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #13
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #13
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #13
    p.and        p1, p3, p2
    s.addi       s6, s21, #6016
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #13
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #13
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #13
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #14
    v.extract    s6, v18, #14
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #14
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #14
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #14
    v.extract    s6, v18, #14
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #14
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #14
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s6, v18, #14
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v13, #14
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #14
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s4
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s4, v18, #14
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v10, v3, v4
    v.splat      v3, s4
    v.movi       v4, #0
    v.extract    s4, v13, #14
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v12, v11
    p.and        p3, p4, p1
    s.movz       s4, #14
    p.and        p1, p3, p2
    s.addi       s6, s21, #6080
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s7, v1, #14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v11, [s5, #0]
    vf.fms       v12, v9, v3, v0
    a.vread      v3, a5, s4
    v.splat      v9, s7
    vf.mul       v14, v4, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s4, v18, #14
    v.movi       v4, #0
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v5
    v.splat      v5, s4
    v.cmp.ne     p1, v9, v4
    vf.mul       v4, v10, v12
    v.movi       v9, #0
    v.extract    s4, v13, #14
    v.ld.w       v10, [s6, #0]
    v.splat      v12, s4
    vf.mul       v14, v4, v6
    v.extract    s4, v1, #15
    v.extract    s6, v18, #15
    v.splat      v4, s4
    v.cmp.ne     p3, v5, v9
    vf.add       v5, v14, v11
    v.movi       v6, #0
    v.splat      v9, s6
    v.movi       v11, #0
    v.cmp.ne     p4, v4, v6
    vf.add       v4, v5, v3
    v.extract    s4, v13, #15
    v.movi       v3, #0
    p.and        p5, p1, p3
    v.cmp.ne     p1, v9, v11
    p.and        p3, p4, p1
    vf.max.prop  v5, v4, v8
    v.splat      v4, s4
    v.movi       v6, #0
    v.cmp.ne     p1, v12, v3
    p.and        p4, p5, p1
    v.cmp.ne     p1, v4, v6
    p.and        p5, p3, p1
    p.and        p1, p4, p2
    s.movz       s4, #15
    p.and        p3, p5, p2
    @p1 v.st.scatter.w [s11, v10], v5
    a.vread      v3, a0, s4
    v.extract    s4, v1, #15
    v.extract    s6, v18, #15
    v.splat      v4, s4
    v.movi       v5, #0
    v.splat      v6, s6
    v.movi       v9, #0
    v.extract    s4, v13, #15
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v4, v5
    v.cmp.ne     p4, v6, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #15
    p.and        p1, p4, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.extract    s2, v18, #15
    v.splat      v5, s4
    v.movi       v6, #0
    v.splat      v9, s2
    v.movi       v10, #0
    v.extract    s2, v13, #15
    v.movi       v11, #0
    v.splat      v12, s2
    v.cmp.ne     p3, v5, v6
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v1, #15
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v11
    v.splat      v5, s2
    v.movi       v6, #0
    p.and        p4, p5, p3
    vf.add       v9, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s1, #0]
    v.extract    s1, v18, #15
    p.and        p1, p4, p2
    v.cmp.ne     p3, v5, v6
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s3, #0]
    vf.sub       v7, v3, v4
    v.splat      v3, s1
    v.movi       v4, #0
    v.extract    s1, v13, #15
    v.movi       v10, #0
    v.splat      v11, s1
    v.cmp.ne     p1, v3, v4
    p.and        p4, p3, p1
    v.cmp.ne     p1, v11, v10
    p.and        p3, p4, p1
    s.movz       s1, #15
    p.and        p1, p3, p2
    s.addi       s2, s21, #6144
    vf.mul       v3, v5, v5
    vf.mul       v4, v5, v2
    v.extract    s3, v1, #15
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s5, #0]
    vf.fms       v2, v9, v3, v0
    a.vread      v0, a5, s1
    v.splat      v3, s3
    v.movi       v9, #0
    vf.mul       v10, v4, v2                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.extract    s1, v18, #15
    v.cmp.ne     p1, v3, v9
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v2, v10, v5
    v.splat      v3, s1
    v.movi       v4, #0
    vf.mul       v5, v7, v2
    v.extract    s1, v13, #15
    v.movi       v2, #0
    v.ld.w       v7, [s2, #0]
    v.splat      v9, s1
    vf.mul       v10, v5, v6
    v.cmp.ne     p3, v3, v4
    p.and        p4, p1, p3
    v.cmp.ne     p1, v9, v2
    p.and        p3, p4, p1
    vf.add       v2, v10, v1
    p.and        p1, p3, p2
    vf.add       v1, v2, v0
    vf.max.prop  v0, v1, v8
    @p1 v.st.scatter.w [s11, v7], v0
__rctx_next:
    exit
