    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, pid.y
    s.rdspecial  s2, arg_base
    s.shli       s3, s1, #4                      // x16 as a shift
    s.movz       s1, #0
    s.ld.d       s5, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s6, #8192
    s.add        s7, s1, s3                      // the tile origin
    s.movz       s8, #1
    s.movz       s9, #2
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    s.movz       s14, #7
    s.movz       s15, #8
    s.ld.d       s16, [s2, #8]                   // out_ptr0: device_ptr64 at arg_base+8
    s.movz       s2, #9
    s.movz       s17, #10
    s.movz       s18, #11
    s.movz       s19, #12
    s.movz       s20, #13
    s.movz       s21, #14
    s.shli       s22, s4, #4                     // x16 as a shift
    s.movz       s4, #15
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.muli       s23, s22, #8192                 // a runtime tile origin, x8192
    s.movz       s24, #0
    s.shli       s25, s3, #15                    // x32768 as a shift
    s.movz       s3, #1
    s.movz       s26, #32768
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    s.add        s6, s7, s23                     // the tile origin
    s.movz       s7, #2
    v.mul        v2, v0, v1
    s.movz       s23, #2
    v.splat      v0, s6
    s.shli       s27, s7, #15                    // x32768 as a shift
    s.movz       s7, #3
    v.add        v1, v2, v0
    s.movz       s28, #3
    s.addi       s29, s6, #1
    v.ld.gather.w v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.shli       s30, s7, #15                    // x32768 as a shift
    v.splat      v1, s29
    s.movz       s7, #4
    s.movz       s29, #4
    v.add        v3, v2, v1
    s.shli       s31, s7, #15                    // x32768 as a shift
    s.movz       s7, #5
    s.movz       s32, #5
    s.addi       s33, s6, #2
    s.shli       s34, s7, #15                    // x32768 as a shift
    v.splat      v1, s33
    s.movz       s7, #6
    s.movz       s33, #6
    v.add        v4, v2, v1
    s.shli       s35, s7, #15                    // x32768 as a shift
    s.addi       s7, s6, #3
    s.movz       s36, #7
    a.vwrite     a0, s1, v0
    v.ld.gather.w v0, [s5, v3]                   // index is in elements (ISA sec 9.1)
    s.movz       s1, #7
    v.splat      v1, s7
    s.shli       s7, s36, #15                    // x32768 as a shift
    s.movz       s36, #8
    v.add        v3, v2, v1
    s.movz       s37, #8
    s.addi       s38, s6, #4
    s.shli       s39, s36, #15                   // x32768 as a shift
    v.splat      v1, s38
    s.movz       s36, #9
    s.movz       s38, #9
    v.add        v5, v2, v1
    s.shli       s40, s36, #15                   // x32768 as a shift
    s.movz       s36, #10
    s.movz       s41, #10
    s.addi       s42, s6, #5
    s.shli       s43, s36, #15                   // x32768 as a shift
    a.vwrite     a0, s8, v0
    v.ld.gather.w v0, [s5, v4]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s42
    s.movz       s8, #11
    s.movz       s36, #11
    v.add        v4, v2, v1
    s.shli       s42, s8, #15                    // x32768 as a shift
    s.addi       s8, s6, #6
    s.movz       s44, #12
    s.movz       s45, #12
    v.splat      v1, s8
    s.shli       s8, s44, #15                    // x32768 as a shift
    s.movz       s44, #13
    v.add        v6, v2, v1
    s.movz       s46, #13
    s.addi       s47, s6, #7
    s.shli       s48, s44, #15                   // x32768 as a shift
    s.movz       s44, #14
    s.movz       s49, #14
    a.vwrite     a0, s9, v0
    v.ld.gather.w v0, [s5, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s47
    s.shli       s9, s44, #15                    // x32768 as a shift
    s.movz       s44, #15
    v.add        v3, v2, v1
    s.movz       s47, #15
    s.addi       s50, s6, #8
    s.shli       s51, s44, #15                   // x32768 as a shift
    s.addi       s44, s6, #9
    s.addi       s52, s6, #10
    s.addi       s53, s6, #11
    s.addi       s54, s6, #12
    s.addi       s55, s6, #13
    a.vwrite     a0, s10, v0
    v.ld.gather.w v0, [s5, v5]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s50
    s.addi       s10, s6, #14
    v.add        v5, v2, v1
    a.vwrite     a0, s11, v0
    v.ld.gather.w v0, [s5, v4]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s44
    s.addi       s11, s6, #15
    v.add        v4, v2, v1
    a.vwrite     a0, s12, v0
    v.ld.gather.w v0, [s5, v6]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s52
    s.muli       s6, s22, #4                     // a runtime tile origin, x4
    v.add        v6, v2, v1
    s.add        s12, s16, s6                    // the tile origin
    a.vwrite     a0, s13, v0
    v.ld.gather.w v0, [s5, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s53
    s.add        s6, s12, s25                    // the tile origin
    v.add        v3, v2, v1
    s.add        s12, s6, s26
    a.vwrite     a0, s14, v0
    v.ld.gather.w v0, [s5, v5]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s54
    s.add        s13, s6, s27
    v.add        v5, v2, v1
    a.vwrite     a0, s15, v0
    v.ld.gather.w v0, [s5, v4]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s55
    s.add        s14, s6, s30
    s.add        s15, s6, s31
    v.add        v4, v2, v1
    a.vwrite     a0, s2, v0
    v.ld.gather.w v0, [s5, v6]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s10
    s.add        s2, s6, s34
    s.add        s10, s6, s35
    v.add        v6, v2, v1
    a.vwrite     a0, s17, v0
    v.ld.gather.w v0, [s5, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v1, s11
    s.add        s11, s6, s7
    v.add        v3, v2, v1
    a.vwrite     a0, s18, v0
    v.ld.gather.w v0, [s5, v5]                   // index is in elements (ISA sec 9.1)
    s.add        s7, s6, s39
    s.add        s16, s6, s40
    a.vwrite     a0, s19, v0
    v.ld.gather.w v0, [s5, v4]                   // index is in elements (ISA sec 9.1)
    s.add        s17, s6, s43
    s.add        s18, s6, s42
    a.vwrite     a0, s20, v0
    v.ld.gather.w v0, [s5, v6]                   // index is in elements (ISA sec 9.1)
    s.add        s19, s6, s8
    a.vwrite     a0, s21, v0
    v.ld.gather.w v0, [s5, v3]                   // index is in elements (ISA sec 9.1)
    s.add        s5, s6, s48
    s.add        s8, s6, s9
    a.vwrite     a0, s4, v0
    // tile epilogue: 16 rows through the vector unit, as f32 (ISA sec 9B)
    a.vread      v0, a0, s24
    s.add        s4, s6, s51
    v.st.w       [s6, #0], v0
    a.vread      v0, a0, s3
    v.st.w       [s12, #0], v0
    a.vread      v0, a0, s23
    v.st.w       [s13, #0], v0
    a.vread      v0, a0, s28
    v.st.w       [s14, #0], v0
    a.vread      v0, a0, s29
    v.st.w       [s15, #0], v0
    a.vread      v0, a0, s32
    v.st.w       [s2, #0], v0
    a.vread      v0, a0, s33
    v.st.w       [s10, #0], v0
    a.vread      v0, a0, s1
    v.st.w       [s11, #0], v0
    a.vread      v0, a0, s37
    v.st.w       [s7, #0], v0
    a.vread      v0, a0, s38
    v.st.w       [s16, #0], v0
    a.vread      v0, a0, s41
    v.st.w       [s17, #0], v0
    a.vread      v0, a0, s36
    v.st.w       [s18, #0], v0
    a.vread      v0, a0, s45
    v.st.w       [s19, #0], v0
    a.vread      v0, a0, s46
    v.st.w       [s5, #0], v0
    a.vread      v0, a0, s49
    v.st.w       [s8, #0], v0
    a.vread      v0, a0, s47
    v.st.w       [s4, #0], v0
__rctx_next:
    exit
