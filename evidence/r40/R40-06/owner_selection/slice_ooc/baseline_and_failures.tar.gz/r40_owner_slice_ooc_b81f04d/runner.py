import hashlib,json,os,sys
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(Path.home()/'tnca_srcR40convergence_8abf527/tools/r1'))
import r1lib as R
manifest=root/'input/experiment.json'
identity=json.loads(manifest.read_text())
def verify():
    for name,digest in identity['input_sha256'].items():
        if hashlib.sha256((root/'input'/name).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('input changed: '+name)
verify()
report=dict(schema='tnca-slice-ooc-run/1',status='running',pid=os.getpid(),
            experiment_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
            supervisor_sha256=hashlib.sha256(Path(R.__file__).read_bytes()).hexdigest(),
            runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            per_variant_timeout_seconds=1800,results=[],gate_status='not-measured')
out=root/'run.json'
out.write_text(json.dumps(report,indent=2)+'\n')
for variant in ('baseline','candidate'):
    work=root/variant
    work.mkdir(exist_ok=False)
    print('START '+variant,flush=True)
    result=R.run_step(['bash',str(root/'run_variant.sh'),str(root),variant],kind='build',
                       case_dir=str(work),cwd=str(work),name='vivado',cap_seconds=1800)
    report['results'].append(result)
    out.write_text(json.dumps(report,indent=2)+'\n')
    print(variant+' '+result['status'],flush=True)
    if result['status']!=R.PASS:break
verify()
passed=len(report['results'])==2 and all(r['status']==R.PASS for r in report['results'])
report['status']='complete-diagnostic' if passed else 'incomplete-or-fail'
out.write_text(json.dumps(report,indent=2)+'\n')
(root/'experiment.exit').write_text(str(int(not passed))+'\n')
