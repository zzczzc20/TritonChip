# AOT ID: ['84_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/fp8w/runs3/tlm-full/inductor-cache/iy/ciytkmn2zbrxm444ewi26xrpfoh2z3ws6qeyf72455gvalanfore.py
# Topologically Sorted Source Nodes: [truediv, clamp, q], Original ATen: [aten.div, aten.clamp, aten._to_copy]
# Source node to ATen node mapping:
#   clamp => clamp_max, clamp_min, convert_element_type, convert_element_type_1
#   q => convert_element_type_2
#   truediv => div
# Graph fragment:
#   %arg0_1 : Tensor "bf16[7, 40][40, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "f32[][]tnca:0" = PlaceHolder[target=arg1_1]
#   %div : Tensor "bf16[7, 40][40, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type : Tensor "f32[7, 40][40, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.float32), kwargs = {})
#   %clamp_min : Tensor "f32[7, 40][40, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%convert_element_type, -448.0), kwargs = {})
#   %clamp_max : Tensor "f32[7, 40][40, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min, 448.0), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[7, 40][40, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max, torch.bfloat16), kwargs = {})
#   %convert_element_type_2 : Tensor "f8e4m3fn[7, 40][40, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%convert_element_type_1, torch.float8_e4m3fn), kwargs = {})
#   return %convert_element_type_2
triton_poi_fused__to_copy_clamp_div_0 = async_compile.triton('triton_poi_fused__to_copy_clamp_div_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'out_ptr0': '*fp8e4nv', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_clamp_div_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1120}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=2
)
@triton.jit
def triton_poi_fused__to_copy_clamp_div_0(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 280
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (0))
    tmp2 = tl.broadcast_to(tmp1, [XBLOCK])
    tmp3 = tmp2.to(tl.float32)
    tmp4 = (tmp0 / tmp3)
    tmp5 = tmp4.to(tl.float32)
    tmp6 = tl.full([1], -448.0, tl.float32)
    tmp7 = tl.maximum(tmp5, tmp6, tl.PropagateNan.ALL)
    tmp8 = tl.full([1], 448.0, tl.float32)
    tmp9 = tl.minimum(tmp7, tmp8, tl.PropagateNan.ALL)
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tmp10.to(tl.float8e4nv)
    tl.store(out_ptr0 + (x0), tmp11, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/fp8w/runs3/tlm-full/inductor-cache/ti/ctit2vor5d6vvm72ytapy2m2wxkmn523frv7zn634nsyggdxc5ca.py
# Topologically Sorted Source Nodes: [t, y], Original ATen: [aten.t, aten._scaled_mm]
# Source node to ATen node mapping:
#   t => permute
#   y => _scaled_mm
# Graph fragment:
#   %convert_element_type_2 : Tensor "f8e4m3fn[7, 40][40, 1]tnca:0" = PlaceHolder[target=convert_element_type_2]
#   %arg2_1 : Tensor "f8e4m3fn[24, 40][40, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg1_1 : Tensor "f32[][]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg3_1 : Tensor "f32[][]tnca:0" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "bf16[24][1]tnca:0" = PlaceHolder[target=arg4_1]
#   %permute : Tensor "f8e4m3fn[40, 24][1, 40]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg2_1, [1, 0]), kwargs = {})
#   %_scaled_mm : Tensor "bf16[7, 24][24, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten._scaled_mm.default](args = (%convert_element_type_2, %permute, %arg1_1, %arg3_1, %arg4_1, None, torch.bfloat16), kwargs = {})
#   return %_scaled_mm
triton_tem_fused__scaled_mm_t_1 = async_compile.triton('triton_tem_fused__scaled_mm_t_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp8e4nv', 'arg_B': '*fp8e4nv', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_mm_t_1', 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': False, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_mm_t_1(arg_A, arg_B, in_ptr2, in_ptr3, in_ptr4, out_ptr0):
    EVEN_K : tl.constexpr = False
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 7
    N = 24
    K = 40
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 40
    stride_ak = 1
    stride_bk = 1
    stride_bn = 40

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_mask = offs_k[None, :] < (K - k_idx * BLOCK_K)
        b_mask = offs_k[:, None] < (K - k_idx * BLOCK_K)

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 40*idx_m
        a = tl.load(A + (xindex), mask=a_mask, other=0.0)

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 24*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 40*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)), mask=b_mask, other=0.0)


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 24*idx_m
    tmp0 = tl.load(in_ptr2 + (0))
    tmp1 = tl.broadcast_to(tmp0, [BLOCK_M, BLOCK_N])
    tmp2 = tl.load(in_ptr3 + (0))
    tmp3 = tl.broadcast_to(tmp2, [BLOCK_M, BLOCK_N])
    tmp4 = tl.load(in_ptr4 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last').to(tl.float32)
    tmp5 = tmp1 * tmp3
    tmp6 = acc * tmp5
    tmp7 = tmp6 + tmp4
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp7, mask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1), ((7, 40), ()), ((40, 1), ()), 'input')
        buf0 = empty_strided((7, 40), (40, 1), device='tnca', dtype=torch.float8_e4m3fn)
        # Topologically Sorted Source Nodes: [truediv, clamp, q], Original ATen: [aten.div, aten.clamp, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_clamp_div_0.run(arg0_1, arg1_1, buf0, 280, stream=raw_stream0)
        del arg0_1
        assert_size_stride_grouped((arg2_1, arg3_1, arg4_1), ((24, 40), (), (24, )), ((40, 1), (), (1, )), 'input')
        buf1 = empty_strided((7, 24), (24, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [t, y], Original ATen: [aten.t, aten._scaled_mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_mm_t_1.run(buf0, arg2_1, arg1_1, arg3_1, arg4_1, buf1, 2, 1, 1, stream=raw_stream0)
        del arg1_1
        del arg2_1
        del arg3_1
        del arg4_1
        return (buf0, buf1, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((7, 40), (40, 1), device='tnca:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((), (), device='tnca:0', dtype=torch.float32)
    arg2_1 = rand_strided((24, 40), (40, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg3_1 = rand_strided((), (), device='tnca:0', dtype=torch.float32)
    arg4_1 = rand_strided((24, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
