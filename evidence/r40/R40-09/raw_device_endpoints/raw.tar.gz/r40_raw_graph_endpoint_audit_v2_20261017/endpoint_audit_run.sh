source ~/tc_env/env.sh
cd /home/zhongchun/r40_raw_graph_endpoint_audit_v2_20261017
export OMP_NUM_THREADS=2 MAX_JOBS=2 CUDA_VISIBLE_DEVICES=
export PYTHONPATH="$PWD:$PWD/python:$PWD/compiler/python:$PWD/tools/asm"
/home/zhongchun/tc_env/torchenv/bin/python tools/r40/device_clock_tests.py > endpoint_unit.log 2>&1
echo $? > endpoint_unit.exit
/home/zhongchun/tc_env/torchenv/bin/python endpoint_reaudit.py > endpoint_reaudit.log 2>&1
echo $? > endpoint_reaudit.exit
