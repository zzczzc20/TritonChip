    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // in_ptr3: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // in_ptr4: device_ptr64 at arg_base+40
    s.ld.d       s8, [s1, #48]                   // out_ptr1: device_ptr64 at arg_base+48
    v.iota       v0                              // arange(0, VLEN)
    s.rdspecial  s1, arg_base
    s.ld.d       s9, [s1, #64]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s1, s9, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s10, #0
    s.st.d       [s1, #0], s2
    s.movz       s10, #192
    s.st.d       [s1, #8], s10
    s.movz       s10, #2
    s.st.d       [s1, #48], s10
    s.movz       s10, #16
    s.st.d       [s1, #88], s10
    .li       s10, #4294967296
    s.st.d       [s1, #104], s10
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s9, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 1)
    s.movz       s10, #0
    s.st.d       [s1, #0], s3
    s.movz       s10, #192
    s.st.d       [s1, #8], s10
    s.movz       s10, #2
    s.st.d       [s1, #48], s10
    s.movz       s10, #16
    s.st.d       [s1, #88], s10
    .li       s10, #4294967296
    s.st.d       [s1, #104], s10
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s9, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 1)
    s.movz       s10, #0
    s.st.d       [s1, #0], s4
    s.movz       s10, #192
    s.st.d       [s1, #8], s10
    s.movz       s10, #2
    s.st.d       [s1, #48], s10
    s.movz       s10, #16
    s.st.d       [s1, #88], s10
    .li       s10, #4294967296
    s.st.d       [s1, #104], s10
    td.load      d2, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s9, #768                    // TensorMap 3: tl.make_tensor_descriptor (rank 1)
    s.movz       s10, #0
    s.st.d       [s1, #0], s5
    s.movz       s10, #192
    s.st.d       [s1, #8], s10
    s.movz       s10, #2
    s.st.d       [s1, #48], s10
    s.movz       s10, #16
    s.st.d       [s1, #88], s10
    .li       s10, #4294967296
    s.st.d       [s1, #104], s10
    td.load      d3, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s9, #1024                   // TensorMap 4: tl.make_tensor_descriptor (rank 1)
    s.movz       s9, #0
    s.st.d       [s1, #0], s6
    s.movz       s9, #192
    s.st.d       [s1, #8], s9
    s.movz       s9, #2
    s.st.d       [s1, #48], s9
    s.movz       s9, #16
    s.st.d       [s1, #88], s9
    .li       s9, #4294967296
    s.st.d       [s1, #104], s9
    td.load      d4, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s9, #192
    s.movz       s10, #16
    s.addi       s11, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s12, s11, s9
    br.nz        s12, endfor_2
    v.splat      v1, s11
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s11
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s12, #192
    s.movz       s13, #192
    s.muli       s14, s11, #2
    s.muli       s15, s11, #2
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s12
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s13
    v.splat      v8, s11
    v.iota       v9                              // arange(0, VLEN)
    v.cmp.ge     p1, v6, v1
    v.cmp.lt     p2, v6, v3
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    s.movz       s12, #192
    s.add        s13, s2, s14
    p.and        p5, p1, p2
    s.add        s14, s3, s15
    p.and        p1, p3, p4
    s.muli       s15, s11, #2
    v.add        v1, v8, v9
    v.movi       v3, #0
    v.splat      v4, s12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v5, [s13, #0]
    v.splat      v6, s11
    v.iota       v7                              // arange(0, VLEN)
    v.cmp.ge     p2, v1, v3
    v.cmp.lt     p3, v1, v4
    s.add        s12, s4, s15
    p.and        p4, p2, p3
    s.muli       s13, s11, #2
    v.add        v1, v6, v7
    v.splat      v3, s11
    v.movi       v4, #0
    v.movi       v6, #192
    s.add        s15, s5, s13
    v.add        v7, v3, v0
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s14, #0]
    s.movz       s13, #192
    v.cmp.ge     p1, v1, v4
    vf.cvt.f16.f32 v4, v5
    v.cmp.lt     p2, v7, v6
    v.splat      v5, s13
    v.splat      v6, s11
    v.iota       v7                              // arange(0, VLEN)
    v.cmp.lt     p3, v1, v5
    s.movz       s13, #192
    p.and        p5, p1, p3
    s.muli       s14, s11, #2
    v.add        v1, v6, v7
    v.movi       v5, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s12, #0]
    v.splat      v7, s13
    v.cmp.ge     p1, v1, v5
    s.add        s12, s6, s14
    v.cmp.lt     p3, v1, v7
    p.and        p4, p1, p3
    vf.cvt.f16.f32 v1, v3
    s.shli       s13, s11, #1                    // element offset -> bytes (x2)
    v.movi       v3, #0
    s.add        s14, s2, s13                    // &in_out_ptr0[...]
    s.add        s13, s11, s10
    vf.add       v5, v4, v1
    s.movz       s16, #1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v1, [s15, #0]
    vf.cvt.f16.f32 v4, v6
    vf.add       v6, v5, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s12, #0]
    vf.cvt.f16.f32 v5, v1
    vf.add       v1, v6, v5
    vf.cvt.f16.f32 v5, v4
    vf.add       v4, v1, v5
    vf.mul       v1, v4, v4
    vf.cvt.f32.f16 v5, v4
    vf.add       v4, v2, v1
    @p2 v.st.h       [s14, #0], v5
    @p2 v.sel        v1, v4, v2
    v.mov        v3, v1
    v.mov        v2, v3
    s.mov        s11, s13
    br.nz        s16, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    s.addi       s3, s1, #0
    vf.add       v3, v1, v2
for_3:
    s.cmp.ge     s1, s3, s9
    br.nz        s1, endfor_4
    .li       s1, #1128267776
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #925353388
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v1                          // ISA 8.8: <= 2**-22 relative
    v.splat      v6, s3
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s1, #192
    s.muli       s4, s3, #2
    v.add        v8, v6, v7
    v.movi       v6, #0
    v.splat      v7, s1
    .li       s1, #1077936128
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ge     p1, v8, v6
    v.cmp.lt     p2, v8, v7
    .li       s1, #3204448256
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v7, s3
    s.add        s1, s2, s4
    p.and        p3, p1, p2
    fence.acq_rel.device
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v8, [s1, #0]
    v.add        v10, v7, v0
    v.movi       v7, #192
    s.shli       s1, s3, #1                      // element offset -> bytes (x2)
    s.add        s4, s3, s10
    s.add        s5, s7, s1                      // &in_ptr4[...]
    v.cmp.lt     p1, v10, v7
    s.add        s6, s8, s1                      // &out_ptr1[...]
    s.movz       s1, #1
    vf.fms       v7, v1, v5, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s5, #0]
    vf.cvt.f16.f32 v2, v8
    vf.fms       v8, v5, v7, v5
    vf.neg       v7, v8                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v7, v7
    @p2 v.sel        v8, v7, v5
    vf.cvt.f16.f32 v5, v1
    vf.mul       v1, v3, v8                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v7, v1, v4
    v.rsqrt.approx v1, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v1, v1
    vf.mul       v8, v1, v6
    vf.fms       v6, v7, v4, v9
    vf.mul       v4, v8, v6                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v6, v4, v1
    v.extract    s5, v6, #0
    v.splat      v1, s5
    vf.mul       v4, v2, v1
    vf.mul       v1, v4, v5
    vf.cvt.f32.f16 v2, v1
    @p1 v.st.h       [s6, #0], v2
    s.mov        s3, s4
    br.nz        s1, for_3
endfor_4:
    exit
    exit
