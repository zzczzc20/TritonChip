#!/bin/bash
# Default-change audit (113 points), FMA miter and the stream-removal unit tests.
set -u
source ~/tc_env/env.sh
G=~/r41fix_gate; L=$G/logs/aux; mkdir -p $L
P=~/tc_env/torchenv/bin/python
stamp() { date -u +%FT%TZ; }
lane() { local n=$1 d=$2; shift 2
  echo "# $(stamp) start $n in $d: $*" > $L/$n.log
  # The torchenv carries an editable tnca install from ~/tritonchip; import this tree.
  ( cd $d && export PYTHONPATH=$d/python:$d/compiler/python:$d && echo "# PYTHONPATH=$PYTHONPATH" && nice -n 10 "$@" ) >> $L/$n.log 2>&1; local rc=$?
  echo "# $(stamp) end $n exit $rc" >> $L/$n.log; echo "$n $rc" >> $L/exit_codes.txt; }
: > $L/exit_codes.txt
echo "aux started $(stamp) host $(hostname)" > $L/run.txt
for T in base head; do
  tree=$(cd $G/$T && PYTHONPATH=$G/$T $P -c 'from archbench.provenance import software_tree; print(software_tree(".", refresh=True))')
  echo "$T $(cat $G/$T/.gate_commit) $tree" >> $L/trees.txt
  rm -rf $G/audit-$T
  lane audit-run-$T $G/$T $P tools/performance_harness/default_change_audit.py run --source-root $G/$T --software-tree $tree --label $T --out $G/audit-$T --jobs 4
done
lane audit-compare $G/head $P tools/performance_harness/default_change_audit.py compare --control $G/audit-base/report.json --candidate $G/audit-head/report.json --out $G/logs/aux/default_change_audit.json
lane audit-compare-r41s1 $G/head $P tools/performance_harness/default_change_audit.py compare --control /home/zhongchun/r41-fp8-audit/run-ctrl/report.json --candidate $G/audit-head/report.json --out $G/logs/aux/default_change_audit_vs_r41s1.json
lane fma-miter $G/head bash $G/miter/run_miter.sh $G/base/rtl/gen $G/head/rtl 1000000 1
for t in tools/r41/hbm_layout_tests.py tools/r40/multicore_mmio_option_tests.py tools/r40/reserved_memory_tests.py \
         tools/r40/copy_range_tests.py tools/r40/device_copy_tests.py tools/r40/host_copy_tests.py \
         tools/r40/memory_control_host_tests.py tools/r40/memory_control_tests.py tools/r40/hbm_topology_tests.py \
         tools/r40/image_geometry_tests.py tools/r40/storage_owner_tests.py tools/r40/physical_grid_runtime_tests.py \
         tools/r40/physical_chunk_runtime_tests.py tools/r40/large_grid_tests.py tools/r40/lifetime_tests.py \
         tools/r40/allocation_pressure_tests.py tools/r40/device_clock_tests.py tools/r40/code_cache_epoch_tests.py \
         tools/r40/hbm_probe_storage_tests.py tools/r40/physical_grid_clock_tests.py tools/r40/dma_handoff_guard_tests.py \
         tools/r40/replay_tests.py tools/r36/fpga_tests.py tools/r36/backend_tests.py tools/r36/io_tests.py \
         tools/r36/config_tests.py tools/r2/runtime_tests.py tools/r2/memory_tests.py \
         tools/performance_harness/test_hbm8.py tools/performance_harness/test_measurement_scope.py \
         tools/performance_harness/test_locality_plan.py; do
  n=unit-$(echo $t | tr / _ | sed 's/\.py$//')
  lane $n $G/head $P $t
done
lane bash-n-link $G/head bash -n flow/fpga/link.sh
echo "finished $(stamp)" >> $L/run.txt
