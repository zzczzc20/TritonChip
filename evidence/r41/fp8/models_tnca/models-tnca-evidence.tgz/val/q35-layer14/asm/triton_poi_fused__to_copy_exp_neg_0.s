    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    v.add        v2, v1, v0
    v.movi       v0, #32
    s.add        s5, s3, s4                      // &in_ptr0[...]
    v.cmp.lt     p1, v2, v0
    @p1 v.ld.h       v0, [s5, #0]
    .li       s3, #1069066811
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1060205080
    v.splat      v2, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s3, s2, #2                      // element offset -> bytes (x4)
    vf.cvt.bf16.f32 v3, v0
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    vf.mul       v0, v3, v1
    s.add        s1, s2, s3                      // &out_ptr0[...]
    v.exp2.approx v4, v0                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v3, v1, v0                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v2
    vf.fma       v1, v4, v0, v4                  // 2**t * 2**d
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v0, v1, v4
    vf.neg       v1, v0
    @p1 v.st.w       [s1, #0], v1
__rctx_next:
    exit
