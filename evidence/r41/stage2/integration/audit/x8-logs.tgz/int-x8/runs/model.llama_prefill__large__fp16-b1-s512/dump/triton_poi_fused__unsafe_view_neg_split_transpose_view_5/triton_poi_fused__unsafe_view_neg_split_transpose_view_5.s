    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #5
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.sub        v6, v1, v3
    @p1 v.sel        v7, v4, v5
    v.movi       v4, #0
    v.sub        v5, v0, v3
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v3, v0
    @p1 v.sel        v8, v6, v3
    v.movi       v6, #31
    v.sub        v9, v4, v7
    @p2 v.sel        v10, v5, v3
    v.cmp.lt     p3, v7, v4
    v.and        v3, v8, v6
    @p3 v.sel        v5, v9, v7
    v.movi       v6, #511
    v.sub        v8, v1, v3
    v.and        v9, v5, v6
    v.movi       v5, #32
    @p1 v.sel        v6, v8, v3
    v.sub        v3, v4, v9
    v.movi       v8, #512
    @p3 v.sel        v11, v3, v9
    s.rdspecial  s1, arg_base
    v.movi       v3, #16384
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v9, v1, v5
    v.sub        v12, v2, v5
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.cmp.lt     p1, v5, v1
    v.movi       v1, #14
    v.mul        v13, v11, v8
    v.lshr       v11, v10, v1
    v.movi       v1, #64
    v.cmp.lt     p3, v5, v2
    v.sub        v2, v0, v11
    @p1 v.sel        v10, v9, v5
    @p2 v.sel        v9, v2, v11
    v.add        v2, v6, v5
    v.mul        v10, v9, v1
    v.mul        v9, v7, v1
    v.add        v1, v2, v10
    v.sub        v2, v4, v8
    v.add        v7, v1, v13
    v.sub        v1, v0, v3
    v.ld.gather.h v10, [s2, v7]                  // index is in elements (ISA sec 9.1)
    v.add        v7, v6, v9
    v.cmp.lt     p1, v8, v4
    v.cmp.lt     p2, v3, v0
    @p3 v.sel        v0, v12, v5
    @p1 v.sel        v0, v2, v8
    vf.cvt.f16.f32 v0, v10
    @p2 v.sel        v2, v1, v3
    vf.neg       v1, v0
    vf.cvt.f32.f16 v0, v1
    v.st.scatter.h [s3, v7], v0
__rctx_next:
    exit
