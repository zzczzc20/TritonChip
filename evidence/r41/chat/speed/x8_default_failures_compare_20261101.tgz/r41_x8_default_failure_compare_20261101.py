import hashlib,json
from pathlib import Path
h=Path.home(); roots=[h/f'r41_x8_equal_output_suite_default_{i}_20261101' for i in (0,1)]
a,b=[json.loads((p/'report.json').read_text()) for p in roots]
failed=[]
for x,y in zip(a['cases'],b['cases']):
 if x['case']!=y['case'] or x['status']!=y['status']:raise ValueError('case or status differs')
 if x['status']=='fail':failed.append({'case':x['case'],'identical_compare_records':x['compare']==y['compare'],'control':x['compare'],'candidate':y['compare']})
hashes=[]
for p in roots:
 data=(p/'dump/_fp8_act_quant_kernel/_fp8_act_quant_kernel.s').read_bytes();hashes.append(hashlib.sha256(data).hexdigest())
out={'scope':'default-division suite; one dumped standalone kernel per route','failed_cases':failed,'standalone_assembly_sha256':hashes,'assembly_equal':hashes[0]==hashes[1]}
(h/'r41_x8_default_failure_compare_20261101.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
