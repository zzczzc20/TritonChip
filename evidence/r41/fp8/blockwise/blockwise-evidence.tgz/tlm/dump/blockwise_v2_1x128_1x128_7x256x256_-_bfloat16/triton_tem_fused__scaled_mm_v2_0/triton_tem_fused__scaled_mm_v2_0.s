    s.rdspecial  s1, pid.x
    s.movz       s2, #0
    s.movz       s3, #0
    s.cmp.lt     s4, s1, s2
    s.movz       s2, #0
    s.sub        s5, s3, s4
    s.movz       s3, #0
    s.cmp.lt     s4, s1, s2
    s.xor        s2, s1, s5
    s.movz       s6, #2
    s.sub        s7, s3, s4
    s.movz       s3, #0
    s.sub        s4, s2, s5
    s.movz       s2, #0
    s.cmp.lt     s8, s6, s3
    s.xor        s3, s1, s7
    s.lshri      s1, s4, #1
    s.sub        s9, s2, s8
    s.sub        s2, s3, s7
    s.muli       s3, s1, #2
    s.lshri      s1, s2, #1
    s.xor        s8, s7, s9
    s.movz       s7, #16
    s.xor        s10, s1, s8
    s.sub        s11, s4, s3
    s.sub        s3, s10, s8
    s.xor        s4, s11, s5
    s.mul        s8, s3, s7
    s.sub        s3, s4, s5
    s.movz       s4, #0
    s.movz       s5, #0
    s.cmp.lt     s10, s6, s4
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s8
    s.muli       s4, s1, #2
    s.sub        s1, s5, s10
    v.add        v2, v1, v0
    s.rdspecial  s5, arg_base
    s.movz       s10, #128
    s.xor        s11, s6, s9
    s.xor        s12, s6, s1
    s.ld.d       s13, [s5, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.mul        s14, s3, s10
    s.sub        s3, s11, s9
    s.ld.d       s3, [s5, #8]                    // arg_B: device_ptr64 at arg_base+8
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s9, s2, s4
    s.ld.d       s2, [s5, #16]                   // arg_SA: device_ptr64 at arg_base+16
    v.iota       v1                              // arange(0, VLEN)
    s.sub        s4, s12, s1
    s.ld.d       s1, [s5, #24]                   // arg_SB: device_ptr64 at arg_base+24
    v.movi       v3, #16
    s.ld.d       s4, [s5, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #32
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #48
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #64
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #80
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #96
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #112
    v.movi       v16, #7
    v.movi       v17, #0
    v.add        v18, v1, v3
    v.add        v1, v4, v5
    v.add        v3, v6, v7
    v.add        v4, v8, v9
    v.add        v5, v10, v11
    v.add        v6, v12, v13
    v.add        v7, v14, v15
    v.splat      v8, s14
    v.splat      v9, s14
    v.splat      v10, s14
    v.splat      v11, s14
    v.splat      v12, s14
    v.splat      v13, s14
    v.splat      v14, s14
    v.splat      v15, s14
    v.sub        v19, v17, v2
    v.sub        v20, v17, v16
    v.cmp.lt     p1, v2, v17
    v.cmp.lt     p2, v16, v17
    v.add        v21, v8, v0
    v.add        v0, v9, v18
    v.add        v8, v10, v1
    v.add        v1, v11, v3
    v.add        v3, v12, v4
    v.add        v4, v13, v5
    v.add        v5, v14, v6
    v.add        v6, v15, v7
    v.movi       v7, #1
    @p1 v.sel        v9, v19, v2
    @p2 v.sel        v2, v20, v16
    v.movi       v10, #0
    v.movi       v11, #0
    s.movz       s5, #31
idiv_1:
    v.splat      v12, s5
    v.shl        v13, v11, v7
    v.lshr       v14, v9, v12
    v.cmp.lt     p2, v11, v17
    v.and        v15, v14, v7
    v.shl        v14, v7, v12
    v.or         v12, v13, v15
    s.subi       s9, s5, #1
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v13, v12, v2
    @p4 v.sel        v15, v14, v17
    @p4 v.sel        v14, v13, v12
    v.or         v12, v10, v15
    v.mov        v11, v14
    v.mov        v10, v12
    s.mov        s5, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s5, s9
    br.nz        s11, idiv_1
    v.sub        v2, v17, v11
    @p1 v.sel        v7, v2, v11
    v.movi       v2, #256
    v.movi       v9, #0
    v.movi       v10, #1
    v.cmp.lt     p1, v21, v9
    v.cmp.lt     p2, v2, v9
    v.sub        v10, v9, v21
    @p1 v.sel        v11, v10, v21
    v.sub        v10, v9, v2
    @p2 v.sel        v12, v10, v2
    v.movi       v2, #255
    v.and        v10, v11, v2
    v.sub        v2, v9, v10
    @p1 v.sel        v9, v2, v10
    v.movi       v2, #256
    v.movi       v10, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v0, v10
    v.cmp.lt     p2, v2, v10
    v.sub        v11, v10, v0
    @p1 v.sel        v12, v11, v0
    v.sub        v0, v10, v2
    @p2 v.sel        v11, v0, v2
    v.movi       v0, #255
    v.and        v2, v12, v0
    v.sub        v0, v10, v2
    @p1 v.sel        v10, v0, v2
    v.movi       v0, #256
    v.movi       v2, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v8, v2
    v.cmp.lt     p2, v0, v2
    v.sub        v11, v2, v8
    @p1 v.sel        v12, v11, v8
    v.sub        v8, v2, v0
    @p2 v.sel        v11, v8, v0
    v.movi       v0, #255
    v.and        v8, v12, v0
    v.sub        v0, v2, v8
    @p1 v.sel        v2, v0, v8
    v.movi       v0, #256
    v.movi       v8, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v1, v8
    v.cmp.lt     p2, v0, v8
    v.sub        v11, v8, v1
    @p1 v.sel        v12, v11, v1
    v.sub        v1, v8, v0
    @p2 v.sel        v11, v1, v0
    v.movi       v0, #255
    v.and        v1, v12, v0
    v.sub        v0, v8, v1
    @p1 v.sel        v8, v0, v1
    v.movi       v0, #256
    v.movi       v1, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v0, v1
    v.sub        v11, v1, v3
    @p1 v.sel        v12, v11, v3
    v.sub        v3, v1, v0
    @p2 v.sel        v11, v3, v0
    v.movi       v0, #255
    v.and        v3, v12, v0
    v.sub        v0, v1, v3
    @p1 v.sel        v1, v0, v3
    v.movi       v0, #256
    v.movi       v3, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v0, v3
    v.sub        v11, v3, v4
    @p1 v.sel        v12, v11, v4
    v.sub        v4, v3, v0
    @p2 v.sel        v11, v4, v0
    v.movi       v0, #255
    v.and        v4, v12, v0
    v.sub        v0, v3, v4
    @p1 v.sel        v3, v0, v4
    v.movi       v0, #256
    v.movi       v4, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v5, v4
    v.cmp.lt     p2, v0, v4
    v.sub        v11, v4, v5
    @p1 v.sel        v12, v11, v5
    v.sub        v5, v4, v0
    @p2 v.sel        v11, v5, v0
    v.movi       v0, #255
    v.and        v5, v12, v0
    v.sub        v0, v4, v5
    @p1 v.sel        v4, v0, v5
    v.movi       v0, #256
    v.movi       v5, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v6, v5
    v.cmp.lt     p2, v0, v5
    v.sub        v11, v5, v6
    @p1 v.sel        v12, v11, v6
    v.sub        v6, v5, v0
    @p2 v.sel        v11, v6, v0
    v.movi       v0, #255
    v.and        v6, v12, v0
    v.sub        v0, v5, v6
    @p1 v.sel        v5, v0, v6
    s.movz       s5, #32
    s.movz       s9, #48
    s.movz       s11, #64
    s.movz       s12, #80
    s.movz       s15, #96
    s.movz       s16, #112
    s.movz       s17, #0
    s.movz       s18, #1
    s.addi       s19, s17, #0
    s.movz       s20, #0
    s.addi       s21, s20, #0
    s.movz       s20, #0
    s.addi       s22, s20, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_2:
    s.cmp.ge     s20, s19, s6
    br.nz        s20, endfor_3
    s.mul        s20, s19, s10
    s.movz       s23, #256
    s.movz       s24, #7
    s.mul        s25, s19, s23
    s.mul        s26, s19, s24
    s.sub        s24, s23, s20
    s.movz       s20, #256
    s.movz       s23, #256
    s.shli       s27, s25, #2                    // element offset -> bytes (x4)
    s.shli       s28, s26, #2                    // element offset -> bytes (x4)
    s.add        s29, s1, s27                    // &arg_SB[...]
    s.add        s30, s2, s28                    // &arg_SA[...]
    s.add        s28, s1, s27                    // &arg_SB[...]
    s.add        s31, s1, s27                    // &arg_SB[...]
    s.add        s32, s1, s27                    // &arg_SB[...]
    v.ld.gather.w v0, [s30, v7]                  // index is in elements (ISA sec 9.1)
    s.add        s30, s1, s27                    // &arg_SB[...]
    v.splat      v6, s20
    s.add        s20, s1, s27                    // &arg_SB[...]
    v.splat      v11, s23
    s.add        s23, s1, s27                    // &arg_SB[...]
    s.add        s33, s1, s27                    // &arg_SB[...]
    v.splat      v12, s26
    s.movz       s26, #256
    v.splat      v12, s25
    v.ld.gather.w v12, [s29, v9]                 // index is in elements (ISA sec 9.1)
    s.movz       s27, #256
    v.splat      v13, s26
    s.movz       s26, #256
    v.splat      v14, s27
    s.movz       s27, #256
    v.splat      v15, s26
    s.movz       s26, #256
    v.splat      v16, s27
    s.movz       s27, #256
    v.ld.gather.w v17, [s28, v10]                // index is in elements (ISA sec 9.1)
    v.splat      v18, s26
    v.splat      v19, s27
    v.splat      v20, s25
    s.add        s26, s17, s24
    v.splat      v20, s25
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s27, arg_base
    v.splat      v20, s25
    v.splat      v20, s25
    v.movi       v20, #0
    v.ld.gather.w v21, [s31, v2]                 // index is in elements (ISA sec 9.1)
    v.splat      v22, s25
    v.movi       v22, #0
    v.splat      v23, s25
    v.iota       v23                             // arange(0, VLEN)
    v.splat      v24, s25
    v.extract    s25, v9, #0
    v.splat      v24, s25
    s.movz       s28, #0
    v.add        v25, v24, v23
    s.movz       s29, #0
    v.sub        v24, v9, v25
    s.cmp.ge     s31, s26, s29
    v.ld.gather.w v25, [s32, v8]                 // index is in elements (ISA sec 9.1)
    s.movz       s29, #0
    v.mul        v26, v9, v6
    s.cmp.ge     s32, s25, s29
    v.mul        v6, v10, v11
    v.mul        v11, v2, v13
    v.mul        v13, v8, v14
    v.mul        v14, v1, v15
    v.mul        v15, v3, v16
    v.mul        v16, v4, v18
    v.ld.gather.w v18, [s30, v1]                 // index is in elements (ISA sec 9.1)
    v.reduce.or  s29, v24
    s.cmp.eq     s30, s29, s28
    v.mul        v24, v5, v19
    s.and        s28, s30, s32
    s.and        s29, s28, s31
    v.ld.gather.w v19, [s20, v3]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v27, [s23, v4]                 // index is in elements (ISA sec 9.1)
    v.extract    s20, v10, #0
    v.splat      v28, s20
    v.ld.gather.w v29, [s33, v5]                 // index is in elements (ISA sec 9.1)
    v.extract    s23, v2, #0
    v.add        v30, v28, v23
    v.splat      v28, s23
    v.extract    s28, v8, #0
    v.sub        v31, v10, v30
    v.add        v30, v28, v23
    v.splat      v28, s28
    s.movz       s30, #0
    s.movz       s32, #0
    v.sub        v32, v2, v30
    v.add        v30, v28, v23
    s.cmp.ge     s33, s20, s32
    s.ld.d       s32, [s27, #40]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.sub        v28, v8, v30
    v.insert     v20, s29, #0
    v.extract    s27, v1, #0
    v.splat      v30, s27
    v.insert     v22, s25, #0
    v.reduce.or  s25, v31
    s.cmp.eq     s29, s25, s30
    s.movz       s25, #0
    v.add        v31, v30, v23
    s.and        s30, s29, s33
    s.movz       s29, #0
    v.sub        v30, v1, v31
    s.cmp.ge     s33, s23, s29
    s.and        s29, s30, s31
    v.insert     v20, s29, #1
    v.extract    s29, v3, #0
    v.splat      v31, s29
    v.insert     v22, s20, #1
    v.reduce.or  s20, v32
    s.cmp.eq     s30, s20, s25
    s.movz       s20, #0
    v.add        v32, v31, v23
    s.and        s25, s30, s33
    s.movz       s30, #0
    v.sub        v31, v3, v32
    s.cmp.ge     s33, s28, s30
    s.and        s30, s25, s31
    v.insert     v20, s30, #2
    v.extract    s25, v4, #0
    v.splat      v32, s25
    v.insert     v22, s23, #2
    v.reduce.or  s23, v28
    s.cmp.eq     s30, s23, s20
    s.movz       s20, #0
    v.add        v28, v32, v23
    s.and        s23, s30, s33
    s.movz       s30, #0
    v.sub        v32, v4, v28
    s.cmp.ge     s33, s27, s30
    s.and        s30, s23, s31
    v.insert     v20, s30, #3
    v.extract    s23, v5, #0
    v.splat      v28, s23
    v.insert     v22, s28, #3
    v.reduce.or  s28, v30
    s.cmp.eq     s30, s28, s20
    s.movz       s20, #0
    v.add        v30, v28, v23
    s.and        s28, s30, s33
    s.movz       s30, #0
    v.sub        v23, v5, v30
    s.cmp.ge     s33, s29, s30
    s.and        s30, s28, s31
    s.movz       s28, #0
    v.insert     v20, s30, #4
    v.reduce.or  s28, v31
    s.cmp.eq     s30, s28, s20
    s.movz       s20, #0
    s.and        s28, s30, s33
    s.movz       s30, #0
    v.insert     v22, s27, #4
    v.reduce.or  s27, v32
    s.cmp.eq     s33, s27, s20
    s.cmp.ge     s20, s25, s30
    s.movz       s27, #0
    s.and        s30, s28, s31
    s.and        s28, s33, s20
    s.movz       s20, #0
    v.insert     v20, s30, #5
    v.reduce.or  s30, v23
    s.cmp.eq     s33, s30, s27
    s.cmp.ge     s27, s23, s20
    v.insert     v22, s29, #5
    s.and        s20, s28, s31
    s.and        s28, s33, s27
    v.insert     v20, s20, #6
    v.insert     v22, s25, #6
    s.movz       s20, #256
    s.and        s25, s28, s31
    v.splat      v23, s20
    s.add        s20, s3, s22
    v.mul        v28, v7, v23
    s.addi       s27, s32, #0                    // TensorMap 0: W's rows for a transposed FP8 B
    v.extract    s28, v28, #0
    .li       s29, #2147483647
    s.movz       s30, #256
    s.movz       s31, #1
    v.insert     v20, s25, #7
    s.add        s25, s28, s21
    .li       s28, #137438953488
    v.insert     v22, s23, #7
    s.movz       s23, #0
    v.iota       v23                             // arange(0, VLEN)
    s.add        s33, s23, s24                   // the tile origin
    s.add        s23, s13, s25
    s.st.d       [s27, #0], s20
    v.splat      v30, s33
    .li       s20, #7705171329024
    s.addi       s25, s32, #256
    v.cmp.lt     p1, v23, v30
    s.st.d       [s27, #8], s29
    s.addi       s29, s32, #768                  // TensorMap 1: the gathered fallback B tile
    s.movz       s33, #0
    s.st.d       [s27, #16], s26
    s.st.d       [s27, #48], s30
    s.movz       s30, #32
    s.st.d       [s27, #56], s31
    s.movz       s31, #16
    s.st.d       [s27, #88], s28
    s.movz       s28, #16
    s.st.d       [s27, #104], s20
    s.movz       s20, #1
    td.load      d0, [s27]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s27, #68719476768
    s.st.d       [s29, #0], s25
    .li       s25, #7705171329024
    s.st.d       [s29, #8], s30
    v.extract    s30, v28, #1
    s.add        s33, s30, s21
    s.st.d       [s29, #16], s31
    s.addi       s30, s32, #1024                 // 512 bytes of repack scratch
    s.add        s31, s13, s33
    s.st.d       [s29, #48], s28
    s.addi       s28, s30, #0
    s.st.d       [s29, #56], s20
    v.extract    s20, v28, #2
    s.add        s33, s20, s21
    s.st.d       [s29, #88], s27
    s.addi       s20, s30, #32
    s.add        s27, s13, s33
    s.st.d       [s29, #104], s25
    td.load      d1, [s29]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s23, #0]
    v.extract    s23, v28, #3
    s.add        s25, s23, s21
    s.addi       s23, s30, #64
    v.st.b       [s28, #0], v30
    s.add        s28, s13, s25
    v.extract    s25, v28, #4
    s.add        s29, s25, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s31, #0]
    s.addi       s25, s30, #96
    s.add        s31, s13, s29
    v.extract    s29, v28, #5
    v.st.b       [s20, #0], v30
    s.add        s20, s29, s21
    s.addi       s29, s30, #128
    s.add        s33, s13, s20
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s27, #0]
    v.extract    s20, v28, #6
    s.add        s27, s20, s21
    v.st.b       [s23, #0], v30
    s.addi       s20, s30, #160
    s.add        s23, s13, s27
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s28, #0]
    v.extract    s27, v28, #7
    s.add        s28, s27, s21
    v.st.b       [s25, #0], v30
    s.addi       s25, s30, #192
    s.add        s27, s13, s28
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s31, #0]
    v.extract    s28, v28, #8
    s.add        s31, s28, s21
    v.st.b       [s29, #0], v30
    s.addi       s28, s30, #224
    s.add        s29, s13, s31
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s33, #0]
    v.extract    s31, v28, #9
    s.add        s33, s31, s21
    v.st.b       [s20, #0], v30
    s.addi       s20, s30, #256
    s.add        s31, s13, s33
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s23, #0]
    v.extract    s23, v28, #10
    s.add        s33, s23, s21
    v.st.b       [s25, #0], v30
    s.addi       s23, s30, #288
    s.add        s25, s13, s33
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s27, #0]
    v.extract    s27, v28, #11
    s.add        s33, s27, s21
    v.st.b       [s28, #0], v30
    s.addi       s27, s30, #320
    s.add        s28, s13, s33
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s29, #0]
    v.extract    s29, v28, #12
    s.add        s33, s29, s21
    v.st.b       [s20, #0], v30
    s.addi       s20, s30, #352
    s.add        s29, s13, s33
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s31, #0]
    v.extract    s31, v28, #13
    s.add        s33, s31, s21
    v.st.b       [s23, #0], v30
    s.addi       s23, s30, #384
    s.add        s31, s13, s33
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s25, #0]
    v.extract    s25, v28, #14
    s.add        s33, s25, s21
    v.st.b       [s27, #0], v30
    s.addi       s25, s30, #416
    s.add        s27, s13, s33
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s28, #0]
    v.extract    s28, v28, #15
    s.add        s33, s28, s21
    v.st.b       [s20, #0], v30
    s.movz       s20, #0
    s.add        s28, s13, s33
    s.add        s33, s20, s7                    // the tile origin
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s29, #0]
    v.extract    s20, v28, #0
    s.add        s29, s20, s21
    v.splat      v31, s33
    v.st.b       [s23, #0], v30
    s.movz       s20, #0
    s.addi       s23, s30, #448
    s.add        s33, s20, s24                   // the tile origin
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s31, #0]
    s.addi       s20, s29, #16
    v.add        v32, v23, v31
    v.splat      v31, s33
    v.st.b       [s25, #0], v30
    v.extract    s25, v28, #1
    s.addi       s29, s30, #480
    s.add        s31, s13, s20
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s27, #0]
    s.add        s20, s25, s21
    v.cmp.lt     p2, v32, v31
    s.addi       s25, s20, #16
    v.st.b       [s23, #0], v30
    v.extract    s20, v28, #2
    s.addi       s23, s30, #16
    s.add        s27, s13, s25
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s28, #0]
    s.add        s25, s20, s21
    v.extract    s20, v28, #3
    s.addi       s28, s25, #16
    v.st.b       [s29, #0], v30
    s.addi       s25, s30, #48
    s.add        s29, s13, s28
    s.add        s28, s20, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s31, #0]
    s.addi       s20, s28, #16
    v.extract    s28, v28, #4
    s.addi       s31, s30, #80
    v.st.b       [s23, #0], v30
    s.add        s23, s13, s20
    s.add        s20, s28, s21
    v.extract    s28, v28, #5
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s27, #0]
    s.addi       s27, s20, #16
    s.addi       s20, s30, #112
    s.add        s33, s13, s27
    v.st.b       [s25, #0], v30
    s.add        s25, s28, s21
    v.extract    s27, v28, #6
    s.addi       s28, s25, #16
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s29, #0]
    s.addi       s25, s30, #144
    s.add        s29, s13, s28
    s.add        s28, s27, s21
    v.st.b       [s31, #0], v30
    s.addi       s27, s28, #16
    v.extract    s28, v28, #7
    s.add        s31, s13, s27
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s23, #0]
    s.addi       s23, s30, #176
    s.add        s27, s28, s21
    v.st.b       [s20, #0], v30
    s.addi       s20, s27, #16
    v.extract    s27, v28, #8
    s.add        s28, s13, s20
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s33, #0]
    s.addi       s20, s30, #208
    s.add        s33, s27, s21
    v.st.b       [s25, #0], v30
    s.addi       s25, s33, #16
    v.extract    s27, v28, #9
    s.add        s33, s13, s25
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s29, #0]
    s.addi       s25, s30, #240
    s.add        s29, s27, s21
    v.st.b       [s23, #0], v30
    s.addi       s23, s29, #16
    v.extract    s27, v28, #10
    s.add        s29, s13, s23
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s31, #0]
    s.addi       s23, s30, #272
    s.add        s31, s27, s21
    v.st.b       [s20, #0], v30
    s.addi       s20, s31, #16
    v.extract    s27, v28, #11
    s.add        s31, s13, s20
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s28, #0]
    s.addi       s20, s30, #304
    s.add        s28, s27, s21
    v.st.b       [s25, #0], v30
    s.addi       s25, s28, #16
    v.extract    s27, v28, #12
    s.add        s28, s13, s25
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s33, #0]
    s.addi       s25, s30, #336
    s.add        s33, s27, s21
    v.st.b       [s23, #0], v30
    s.addi       s23, s33, #16
    v.extract    s27, v28, #13
    s.add        s33, s13, s23
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s29, #0]
    s.addi       s23, s30, #368
    s.add        s29, s27, s21
    v.st.b       [s20, #0], v30
    s.addi       s20, s29, #16
    v.extract    s27, v28, #14
    s.add        s29, s13, s20
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s31, #0]
    s.addi       s20, s30, #400
    s.add        s31, s27, s21
    v.st.b       [s25, #0], v30
    s.addi       s25, s31, #16
    v.extract    s27, v28, #15
    s.add        s31, s13, s25
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s28, #0]
    s.addi       s25, s30, #432
    s.add        s28, s27, s21
    v.st.b       [s23, #0], v30
    s.addi       s23, s28, #16
    s.addi       s27, s30, #464
    s.add        s28, s13, s23
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s33, #0]
    s.addi       s23, s30, #496
    v.st.b       [s20, #0], v30
    s.addi       s20, s30, #64
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s29, #0]
    s.addi       s29, s30, #128
    v.st.b       [s25, #0], v30
    s.addi       s25, s30, #192
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s31, #0]
    s.addi       s31, s30, #256
    v.st.b       [s27, #0], v30
    s.addi       s27, s30, #320
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s28, #0]
    s.addi       s28, s30, #384
    v.st.b       [s23, #0], v30
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s23, s30, #448
    v.ld.w       v30, [s30, #0]
    v.extract    s30, v20, #0
    v.mov        v48, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s20, #0]
    v.mov        v49, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s29, #0]
    v.mov        v50, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s25, #0]
    v.mov        v51, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s31, #0]
    v.mov        v52, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s27, #0]
    v.mov        v53, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s28, #0]
    v.mov        v54, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s23, #0]
    v.mov        v55, v30                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_4
    s.movz       s20, #0
    s.add        s23, s3, s22
    s.addi       s25, s20, #0
    s.addi       s20, s32, #256
x8dot_row_5:
    s.addi       s27, s26, #0
    v.movi       v30, #0
    s.sub        s28, s27, s25
    s.add        s27, s23, s25
    v.splat      v31, s28
    s.shli       s28, s25, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s27, v26]            // index is in elements (ISA sec 9.1)
    s.add        s27, s20, s28
    s.addi       s28, s25, #1
    s.movz       s29, #32
    v.st.b       [s27, #0], v30
    fence.acq_rel.device
    s.mov        s25, s28
    s.cmp.lt     s27, s25, s29
    br.nz        s27, x8dot_row_5
x8dot_done_4:
    v.splat      v30, s30
    v.movi       v31, #0
    v.splat      v32, s30
    v.movi       v33, #0
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s23, #0
    s.movz       s25, #0
    s.movz       s27, #0
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s28, v22, #0
    s.mov        s29, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s25                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s29, s20            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s20          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s20
    mb.arm       s23, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s25, v20, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s23
    mb.wait      s23
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s25, x8dot_done_6
    s.movz       s27, #0
    s.add        s28, s3, s22
    s.addi       s29, s27, #0
    s.addi       s27, s32, #256
x8dot_row_7:
    s.addi       s30, s26, #0
    v.movi       v30, #0
    s.sub        s31, s30, s29
    s.add        s30, s28, s29
    v.splat      v31, s31
    s.shli       s31, s29, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s30, v6]             // index is in elements (ISA sec 9.1)
    s.add        s30, s27, s31
    s.addi       s31, s29, #1
    s.movz       s33, #32
    v.st.b       [s30, #0], v30
    fence.acq_rel.device
    s.mov        s29, s31
    s.cmp.lt     s30, s29, s33
    br.nz        s30, x8dot_row_7
x8dot_done_6:
    v.splat      v30, s25
    v.movi       v31, #0
    v.splat      v32, s25
    v.movi       v33, #0
    mb.arm       s25, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s27, #0
    s.movz       s28, #0
    s.movz       s29, #0
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s30, v22, #1
    s.mov        s33, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s33, s25            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s27, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s27, s25          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s25
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s28, v20, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s27
    mb.wait      s27
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s28, x8dot_done_8
    s.movz       s29, #0
    s.add        s30, s3, s22
    s.addi       s31, s29, #0
    s.addi       s29, s32, #256
x8dot_row_9:
    s.addi       s33, s26, #0
    v.movi       v30, #0
    s.sub        s34, s33, s31
    s.add        s33, s30, s31
    v.splat      v31, s34
    s.shli       s34, s31, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s33, v11]            // index is in elements (ISA sec 9.1)
    s.add        s33, s29, s34
    s.addi       s34, s31, #1
    s.movz       s35, #32
    v.st.b       [s33, #0], v30
    fence.acq_rel.device
    s.mov        s31, s34
    s.cmp.lt     s33, s31, s35
    br.nz        s33, x8dot_row_9
x8dot_done_8:
    v.splat      v30, s28
    v.movi       v31, #0
    v.splat      v32, s28
    v.movi       v33, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    s.movz       s30, #0
    s.movz       s31, #0
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s33, v22, #2
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s30, v20, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_10
    s.movz       s31, #0
    s.add        s33, s3, s22
    s.addi       s34, s31, #0
    s.addi       s31, s32, #256
x8dot_row_11:
    s.addi       s35, s26, #0
    v.movi       v30, #0
    s.sub        s36, s35, s34
    s.add        s35, s33, s34
    v.splat      v31, s36
    s.shli       s36, s34, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s35, v13]            // index is in elements (ISA sec 9.1)
    s.add        s35, s31, s36
    s.addi       s36, s34, #1
    s.movz       s37, #32
    v.st.b       [s35, #0], v30
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s35, s34, s37
    br.nz        s35, x8dot_row_11
x8dot_done_10:
    v.splat      v30, s30
    v.movi       v31, #0
    v.splat      v32, s30
    v.movi       v33, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    s.movz       s33, #0
    s.movz       s34, #0
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s35, v22, #3
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v20, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_12
    s.movz       s34, #0
    s.add        s35, s3, s22
    s.addi       s36, s34, #0
    s.addi       s34, s32, #256
x8dot_row_13:
    s.addi       s37, s26, #0
    v.movi       v30, #0
    s.sub        s38, s37, s36
    s.add        s37, s35, s36
    v.splat      v31, s38
    s.shli       s38, s36, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s37, v14]            // index is in elements (ISA sec 9.1)
    s.add        s37, s34, s38
    s.addi       s38, s36, #1
    s.movz       s39, #32
    v.st.b       [s37, #0], v30
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_13
x8dot_done_12:
    v.splat      v30, s33
    v.movi       v31, #0
    v.splat      v32, s33
    v.movi       v33, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    s.movz       s35, #0
    s.movz       s36, #0
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s37, v22, #4
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v20, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_14
    s.movz       s36, #0
    s.add        s37, s3, s22
    s.addi       s38, s36, #0
    s.addi       s36, s32, #256
x8dot_row_15:
    s.addi       s39, s26, #0
    v.movi       v30, #0
    s.sub        s40, s39, s38
    s.add        s39, s37, s38
    v.splat      v31, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s39, v15]            // index is in elements (ISA sec 9.1)
    s.add        s39, s36, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v30
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_15
x8dot_done_14:
    v.splat      v30, s35
    v.movi       v31, #0
    v.splat      v32, s35
    v.movi       v33, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    s.movz       s37, #0
    s.movz       s38, #0
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s39, v22, #5
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v20, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_16
    s.movz       s38, #0
    s.add        s39, s3, s22
    s.addi       s40, s38, #0
    s.addi       s38, s32, #256
x8dot_row_17:
    s.addi       s41, s26, #0
    v.movi       v30, #0
    s.sub        s42, s41, s40
    s.add        s41, s39, s40
    v.splat      v31, s42
    s.shli       s42, s40, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s41, v16]            // index is in elements (ISA sec 9.1)
    s.add        s41, s38, s42
    s.addi       s42, s40, #1
    s.movz       s43, #32
    v.st.b       [s41, #0], v30
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s41, s40, s43
    br.nz        s41, x8dot_row_17
x8dot_done_16:
    v.splat      v30, s37
    v.movi       v31, #0
    v.splat      v32, s37
    v.movi       v33, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    s.movz       s39, #0
    s.movz       s40, #0
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s41, v22, #6
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v20, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_18
    s.movz       s40, #0
    s.add        s41, s3, s22
    s.addi       s42, s40, #0
    s.addi       s40, s32, #256
x8dot_row_19:
    s.addi       s43, s26, #0
    v.movi       v30, #0
    s.sub        s44, s43, s42
    s.add        s43, s41, s42
    v.splat      v31, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s43, v24]            // index is in elements (ISA sec 9.1)
    s.add        s43, s40, s44
    s.addi       s44, s42, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v30
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s45
    br.nz        s43, x8dot_row_19
x8dot_done_18:
    s.movz       s40, #0
    v.extract    s41, v28, #0
    s.add        s42, s40, s5                    // the tile origin
    s.movz       s40, #0
    s.add        s43, s41, s21
    v.splat      v30, s39
    v.movi       v31, #0
    v.splat      v32, s39
    v.movi       v33, #0
    v.splat      v34, s42
    s.add        s39, s40, s24                   // the tile origin
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    s.movz       s42, #0
    s.movz       s44, #0
    s.addi       s45, s43, #32
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s43, v22, #7
    v.add        v30, v23, v34
    v.splat      v31, s39
    v.extract    s39, v28, #1
    s.mov        s46, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s46, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s42, s13, s45
    s.add        s43, s39, s21
    v.cmp.lt     p1, v30, v31
    m.mma.async.k32.e4m3 a15, v48, v56, s41
    mb.wait      s41
    s.addi       s39, s32, #1536                 // 512 bytes of repack scratch
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s42, #0]
    s.addi       s42, s43, #32
    v.extract    s43, v28, #2
    s.addi       s44, s39, #0
    s.add        s45, s13, s42
    s.add        s42, s43, s21
    v.st.b       [s44, #0], v30
    s.addi       s43, s42, #32
    v.extract    s42, v28, #3
    s.addi       s44, s39, #32
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s45, #0]
    s.add        s45, s13, s43
    s.add        s43, s42, s21
    v.extract    s42, v28, #4
    v.st.b       [s44, #0], v30
    s.addi       s44, s43, #32
    s.addi       s43, s39, #64
    s.add        s46, s13, s44
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s45, #0]
    s.add        s44, s42, s21
    v.extract    s42, v28, #5
    s.addi       s45, s44, #32
    v.st.b       [s43, #0], v30
    s.addi       s43, s39, #96
    s.add        s44, s13, s45
    s.add        s45, s42, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s46, #0]
    s.addi       s42, s45, #32
    v.extract    s45, v28, #6
    s.addi       s46, s39, #128
    v.st.b       [s43, #0], v30
    s.add        s43, s13, s42
    s.add        s42, s45, s21
    v.extract    s45, v28, #7
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s44, #0]
    s.addi       s44, s42, #32
    s.addi       s42, s39, #160
    s.add        s47, s13, s44
    v.st.b       [s46, #0], v30
    s.add        s44, s45, s21
    v.extract    s45, v28, #8
    s.addi       s46, s44, #32
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s43, #0]
    s.addi       s43, s39, #192
    s.add        s44, s13, s46
    s.add        s46, s45, s21
    v.st.b       [s42, #0], v30
    s.addi       s42, s46, #32
    v.extract    s45, v28, #9
    s.addi       s46, s39, #224
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s47, #0]
    s.add        s47, s13, s42
    s.add        s42, s45, s21
    v.extract    s45, v28, #10
    v.st.b       [s43, #0], v30
    s.addi       s43, s42, #32
    s.addi       s42, s39, #256
    s.add        s48, s13, s43
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s44, #0]
    s.add        s43, s45, s21
    v.extract    s44, v28, #11
    s.addi       s45, s43, #32
    v.st.b       [s46, #0], v30
    s.addi       s43, s39, #288
    s.add        s46, s13, s45
    s.add        s45, s44, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s47, #0]
    s.addi       s44, s45, #32
    v.extract    s45, v28, #12
    s.add        s47, s13, s44
    v.st.b       [s42, #0], v30
    s.addi       s42, s39, #320
    s.add        s44, s45, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s48, #0]
    s.addi       s45, s44, #32
    v.extract    s44, v28, #13
    s.add        s48, s13, s45
    v.st.b       [s43, #0], v30
    s.addi       s43, s39, #352
    s.add        s45, s44, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s46, #0]
    s.addi       s44, s45, #32
    v.extract    s45, v28, #14
    s.add        s46, s13, s44
    v.st.b       [s42, #0], v30
    s.addi       s42, s39, #384
    s.add        s44, s45, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s47, #0]
    s.addi       s45, s44, #32
    v.extract    s44, v28, #15
    s.add        s47, s13, s45
    v.st.b       [s43, #0], v30
    s.addi       s43, s39, #416
    s.add        s45, s44, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s48, #0]
    s.movz       s44, #0
    s.addi       s48, s45, #32
    s.add        s45, s44, s9                    // the tile origin
    v.st.b       [s42, #0], v30
    v.extract    s42, v28, #0
    s.add        s44, s13, s48
    s.add        s48, s42, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s46, #0]
    s.movz       s42, #0
    v.splat      v31, s45
    s.addi       s45, s39, #448
    v.st.b       [s43, #0], v30
    s.add        s43, s42, s24                   // the tile origin
    s.addi       s42, s48, #48
    v.add        v30, v23, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s47, #0]
    v.splat      v32, s43
    v.extract    s43, v28, #1
    s.addi       s46, s39, #480
    v.st.b       [s45, #0], v31
    s.add        s45, s13, s42
    s.add        s42, s43, s21
    v.cmp.lt     p2, v30, v32
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s44, #0]
    s.addi       s43, s42, #48
    v.extract    s42, v28, #2
    s.addi       s44, s39, #16
    v.st.b       [s46, #0], v30
    s.add        s46, s13, s43
    s.add        s43, s42, s21
    v.extract    s42, v28, #3
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s45, #0]
    s.addi       s45, s43, #48
    s.addi       s43, s39, #48
    s.add        s47, s13, s45
    v.st.b       [s44, #0], v30
    s.add        s44, s42, s21
    v.extract    s42, v28, #4
    s.addi       s45, s44, #48
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s46, #0]
    s.addi       s44, s39, #80
    s.add        s46, s13, s45
    s.add        s45, s42, s21
    v.st.b       [s43, #0], v30
    s.addi       s42, s45, #48
    v.extract    s43, v28, #5
    s.addi       s45, s39, #112
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s47, #0]
    s.add        s47, s13, s42
    s.add        s42, s43, s21
    v.extract    s43, v28, #6
    v.st.b       [s44, #0], v30
    s.addi       s44, s42, #48
    s.addi       s42, s39, #144
    s.add        s48, s13, s44
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s46, #0]
    s.add        s44, s43, s21
    v.extract    s43, v28, #7
    s.addi       s46, s44, #48
    v.st.b       [s45, #0], v30
    s.addi       s44, s39, #176
    s.add        s45, s13, s46
    s.add        s46, s43, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s47, #0]
    s.addi       s43, s46, #48
    v.extract    s46, v28, #8
    s.add        s47, s13, s43
    v.st.b       [s42, #0], v30
    s.addi       s42, s39, #208
    s.add        s43, s46, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s48, #0]
    s.addi       s46, s43, #48
    v.extract    s43, v28, #9
    s.add        s48, s13, s46
    v.st.b       [s44, #0], v30
    s.addi       s44, s39, #240
    s.add        s46, s43, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s45, #0]
    s.addi       s43, s46, #48
    v.extract    s45, v28, #10
    s.add        s46, s13, s43
    v.st.b       [s42, #0], v30
    s.addi       s42, s39, #272
    s.add        s43, s45, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s47, #0]
    s.addi       s45, s43, #48
    v.extract    s43, v28, #11
    s.add        s47, s13, s45
    v.st.b       [s44, #0], v30
    s.addi       s44, s39, #304
    s.add        s45, s43, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s48, #0]
    s.addi       s43, s45, #48
    v.extract    s45, v28, #12
    s.add        s48, s13, s43
    v.st.b       [s42, #0], v30
    s.addi       s42, s39, #336
    s.add        s43, s45, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s46, #0]
    s.addi       s45, s43, #48
    v.extract    s43, v28, #13
    s.add        s46, s13, s45
    v.st.b       [s44, #0], v30
    s.addi       s44, s39, #368
    s.add        s45, s43, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s47, #0]
    s.addi       s43, s45, #48
    v.extract    s45, v28, #14
    s.add        s47, s13, s43
    v.st.b       [s42, #0], v30
    s.addi       s42, s39, #400
    s.add        s43, s45, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s48, #0]
    s.addi       s45, s43, #48
    v.extract    s43, v28, #15
    s.add        s48, s13, s45
    v.st.b       [s44, #0], v30
    s.addi       s44, s39, #432
    s.add        s45, s43, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s46, #0]
    s.addi       s43, s45, #48
    s.addi       s45, s39, #464
    s.add        s46, s13, s43
    v.st.b       [s42, #0], v30
    s.addi       s42, s39, #496
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s47, #0]
    s.addi       s43, s39, #64
    v.st.b       [s44, #0], v30
    s.addi       s44, s39, #128
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s48, #0]
    s.addi       s47, s39, #192
    v.st.b       [s45, #0], v30
    s.addi       s45, s39, #256
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s46, #0]
    s.addi       s46, s39, #320
    v.st.b       [s42, #0], v30
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s42, s39, #384
    v.ld.w       v30, [s39, #0]
    s.addi       s48, s39, #448
    v.mov        v48, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s43, #0]
    v.extract    s39, v20, #0
    v.mov        v49, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s44, #0]
    v.mov        v50, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s47, #0]
    v.mov        v51, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s45, #0]
    v.mov        v52, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s46, #0]
    v.mov        v53, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s42, #0]
    v.mov        v54, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s48, #0]
    v.mov        v55, v30                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_20
    s.movz       s42, #0
    s.add        s43, s3, s22
    s.addi       s44, s42, #0
    s.addi       s42, s43, #32
    s.addi       s43, s32, #256
x8dot_row_21:
    s.addi       s45, s26, #-32
    v.movi       v30, #0
    s.sub        s46, s45, s44
    s.add        s45, s42, s44
    v.splat      v31, s46
    s.shli       s46, s44, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s45, v26]            // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.addi       s46, s44, #1
    s.movz       s47, #32
    v.st.b       [s45, #0], v30
    fence.acq_rel.device
    s.mov        s44, s46
    s.cmp.lt     s45, s44, s47
    br.nz        s45, x8dot_row_21
x8dot_done_20:
    v.splat      v30, s39
    v.movi       v31, #0
    v.splat      v32, s39
    v.movi       v33, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    s.movz       s43, #0
    s.movz       s44, #32
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s45, v22, #0
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s46, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v20, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s43, x8dot_done_22
    s.movz       s44, #0
    s.add        s45, s3, s22
    s.addi       s46, s44, #0
    s.addi       s44, s45, #32
    s.addi       s45, s32, #256
x8dot_row_23:
    s.addi       s47, s26, #-32
    v.movi       v30, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v31, s48
    s.shli       s48, s46, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s47, v6]             // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.addi       s48, s46, #1
    s.movz       s49, #32
    v.st.b       [s47, #0], v30
    fence.acq_rel.device
    s.mov        s46, s48
    s.cmp.lt     s47, s46, s49
    br.nz        s47, x8dot_row_23
x8dot_done_22:
    v.splat      v30, s43
    v.movi       v31, #0
    v.splat      v32, s43
    v.movi       v33, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    s.movz       s45, #0
    s.movz       s46, #32
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s47, v22, #1
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s48, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v20, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s45, x8dot_done_24
    s.movz       s46, #0
    s.add        s47, s3, s22
    s.addi       s48, s46, #0
    s.addi       s46, s47, #32
    s.addi       s47, s32, #256
x8dot_row_25:
    s.addi       s49, s26, #-32
    v.movi       v30, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v31, s50
    s.shli       s50, s48, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s49, v11]            // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.addi       s50, s48, #1
    s.movz       s51, #32
    v.st.b       [s49, #0], v30
    fence.acq_rel.device
    s.mov        s48, s50
    s.cmp.lt     s49, s48, s51
    br.nz        s49, x8dot_row_25
x8dot_done_24:
    v.splat      v30, s45
    v.movi       v31, #0
    v.splat      v32, s45
    v.movi       v33, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    s.movz       s47, #0
    s.movz       s48, #32
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s49, v22, #2
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s50, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v20, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s47, x8dot_done_26
    s.movz       s48, #0
    s.add        s49, s3, s22
    s.addi       s50, s48, #0
    s.addi       s48, s49, #32
    s.addi       s49, s32, #256
x8dot_row_27:
    s.addi       s51, s26, #-32
    v.movi       v30, #0
    s.sub        s52, s51, s50
    s.add        s51, s48, s50
    v.splat      v31, s52
    s.shli       s52, s50, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s51, v13]            // index is in elements (ISA sec 9.1)
    s.add        s51, s49, s52
    s.addi       s52, s50, #1
    s.movz       s53, #32
    v.st.b       [s51, #0], v30
    fence.acq_rel.device
    s.mov        s50, s52
    s.cmp.lt     s51, s50, s53
    br.nz        s51, x8dot_row_27
x8dot_done_26:
    v.splat      v30, s47
    v.movi       v31, #0
    v.splat      v32, s47
    v.movi       v33, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    s.movz       s49, #0
    s.movz       s50, #32
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s51, v22, #3
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s52, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s48, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s48, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v20, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s49, x8dot_done_28
    s.movz       s50, #0
    s.add        s51, s3, s22
    s.addi       s52, s50, #0
    s.addi       s50, s51, #32
    s.addi       s51, s32, #256
x8dot_row_29:
    s.addi       s53, s26, #-32
    v.movi       v30, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v31, s54
    s.shli       s54, s52, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s53, v14]            // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.addi       s54, s52, #1
    s.movz       s55, #32
    v.st.b       [s53, #0], v30
    fence.acq_rel.device
    s.mov        s52, s54
    s.cmp.lt     s53, s52, s55
    br.nz        s53, x8dot_row_29
x8dot_done_28:
    v.splat      v30, s49
    v.movi       v31, #0
    v.splat      v32, s49
    v.movi       v33, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    s.movz       s51, #0
    s.movz       s52, #32
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s53, v22, #4
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s54, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v20, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s51, x8dot_done_30
    s.movz       s52, #0
    s.add        s53, s3, s22
    s.addi       s54, s52, #0
    s.addi       s52, s53, #32
    s.addi       s53, s32, #256
x8dot_row_31:
    s.addi       s55, s26, #-32
    v.movi       v30, #0
    s.sub        s56, s55, s54
    s.add        s55, s52, s54
    v.splat      v31, s56
    s.shli       s56, s54, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s55, v15]            // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    s.addi       s56, s54, #1
    s.movz       s57, #32
    v.st.b       [s55, #0], v30
    fence.acq_rel.device
    s.mov        s54, s56
    s.cmp.lt     s55, s54, s57
    br.nz        s55, x8dot_row_31
x8dot_done_30:
    v.splat      v30, s51
    v.movi       v31, #0
    v.splat      v32, s51
    v.movi       v33, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    s.movz       s53, #0
    s.movz       s54, #32
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s55, v22, #5
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s56, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v20, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_32
    s.movz       s54, #0
    s.add        s55, s3, s22
    s.addi       s56, s54, #0
    s.addi       s54, s55, #32
    s.addi       s55, s32, #256
x8dot_row_33:
    s.addi       s57, s26, #-32
    v.movi       v30, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v31, s58
    s.shli       s58, s56, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s57, v16]            // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.addi       s58, s56, #1
    s.movz       s59, #32
    v.st.b       [s57, #0], v30
    fence.acq_rel.device
    s.mov        s56, s58
    s.cmp.lt     s57, s56, s59
    br.nz        s57, x8dot_row_33
x8dot_done_32:
    v.splat      v30, s53
    v.movi       v31, #0
    v.splat      v32, s53
    v.movi       v33, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    s.movz       s55, #0
    s.movz       s56, #32
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s57, v22, #6
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s58, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s57                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v20, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s55, x8dot_done_34
    s.movz       s56, #0
    s.add        s57, s3, s22
    s.addi       s58, s56, #0
    s.addi       s56, s57, #32
    s.addi       s57, s32, #256
x8dot_row_35:
    s.addi       s59, s26, #-32
    v.movi       v30, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v31, s60
    s.shli       s60, s58, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s59, v24]            // index is in elements (ISA sec 9.1)
    s.add        s59, s57, s60
    s.addi       s60, s58, #1
    s.movz       s20, #32
    v.st.b       [s59, #0], v30
    fence.acq_rel.device
    s.mov        s58, s60
    s.cmp.lt     s23, s58, s20
    br.nz        s23, x8dot_row_35
x8dot_done_34:
    s.movz       s20, #0
    v.extract    s23, v28, #0
    s.add        s25, s20, s11                   // the tile origin
    s.movz       s20, #0
    s.add        s27, s23, s21
    v.splat      v30, s55
    v.movi       v31, #0
    v.splat      v32, s55
    v.movi       v33, #0
    v.splat      v34, s25
    s.add        s23, s20, s24                   // the tile origin
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s25, #0
    s.movz       s28, #0
    s.movz       s29, #32
    s.addi       s30, s27, #64
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s27, v22, #7
    v.add        v30, v23, v34
    v.splat      v31, s23
    v.extract    s23, v28, #1
    s.mov        s33, s25                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s33, s20            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s20          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s20
    mb.arm       s25, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s27, s13, s30
    s.add        s28, s23, s21
    v.cmp.lt     p1, v30, v31
    m.mma.async.k32.e4m3 a15, v48, v56, s25
    mb.wait      s25
    s.addi       s23, s32, #2048                 // 512 bytes of repack scratch
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s27, #0]
    s.addi       s27, s28, #64
    v.extract    s28, v28, #2
    s.addi       s29, s23, #0
    s.add        s30, s13, s27
    s.add        s27, s28, s21
    v.st.b       [s29, #0], v30
    s.addi       s28, s27, #64
    v.extract    s27, v28, #3
    s.addi       s29, s23, #32
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s30, #0]
    s.add        s30, s13, s28
    s.add        s28, s27, s21
    v.extract    s27, v28, #4
    v.st.b       [s29, #0], v30
    s.addi       s29, s28, #64
    s.addi       s28, s23, #64
    s.add        s31, s13, s29
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s30, #0]
    s.add        s29, s27, s21
    v.extract    s27, v28, #5
    s.addi       s30, s29, #64
    v.st.b       [s28, #0], v30
    s.addi       s28, s23, #96
    s.add        s29, s13, s30
    s.add        s30, s27, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s31, #0]
    s.addi       s27, s30, #64
    v.extract    s30, v28, #6
    s.addi       s31, s23, #128
    v.st.b       [s28, #0], v30
    s.add        s28, s13, s27
    s.add        s27, s30, s21
    v.extract    s30, v28, #7
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s29, #0]
    s.addi       s29, s27, #64
    s.addi       s27, s23, #160
    s.add        s33, s13, s29
    v.st.b       [s31, #0], v30
    s.add        s29, s30, s21
    v.extract    s30, v28, #8
    s.addi       s31, s29, #64
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s28, #0]
    s.addi       s28, s23, #192
    s.add        s29, s13, s31
    s.add        s31, s30, s21
    v.st.b       [s27, #0], v30
    s.addi       s27, s31, #64
    v.extract    s30, v28, #9
    s.addi       s31, s23, #224
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s33, #0]
    s.add        s33, s13, s27
    s.add        s27, s30, s21
    v.extract    s30, v28, #10
    v.st.b       [s28, #0], v30
    s.addi       s28, s27, #64
    s.addi       s27, s23, #256
    s.add        s34, s13, s28
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s29, #0]
    s.add        s28, s30, s21
    v.extract    s29, v28, #11
    s.addi       s30, s28, #64
    v.st.b       [s31, #0], v30
    s.addi       s28, s23, #288
    s.add        s31, s13, s30
    s.add        s30, s29, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s33, #0]
    s.addi       s29, s30, #64
    v.extract    s30, v28, #12
    s.add        s33, s13, s29
    v.st.b       [s27, #0], v30
    s.addi       s27, s23, #320
    s.add        s29, s30, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s34, #0]
    s.addi       s30, s29, #64
    v.extract    s29, v28, #13
    s.add        s34, s13, s30
    v.st.b       [s28, #0], v30
    s.addi       s28, s23, #352
    s.add        s30, s29, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s31, #0]
    s.addi       s29, s30, #64
    v.extract    s30, v28, #14
    s.add        s31, s13, s29
    v.st.b       [s27, #0], v30
    s.addi       s27, s23, #384
    s.add        s29, s30, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s33, #0]
    s.addi       s30, s29, #64
    v.extract    s29, v28, #15
    s.add        s33, s13, s30
    v.st.b       [s28, #0], v30
    s.addi       s28, s23, #416
    s.add        s30, s29, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s34, #0]
    s.movz       s29, #0
    s.addi       s34, s30, #64
    s.add        s30, s29, s12                   // the tile origin
    v.st.b       [s27, #0], v30
    v.extract    s27, v28, #0
    s.add        s29, s13, s34
    s.add        s34, s27, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s31, #0]
    s.movz       s27, #0
    v.splat      v31, s30
    s.addi       s30, s23, #448
    v.st.b       [s28, #0], v30
    s.add        s28, s27, s24                   // the tile origin
    s.addi       s27, s34, #80
    v.add        v30, v23, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s33, #0]
    v.splat      v32, s28
    v.extract    s28, v28, #1
    s.addi       s31, s23, #480
    v.st.b       [s30, #0], v31
    s.add        s30, s13, s27
    s.add        s27, s28, s21
    v.cmp.lt     p2, v30, v32
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s29, #0]
    s.addi       s28, s27, #80
    v.extract    s27, v28, #2
    s.addi       s29, s23, #16
    v.st.b       [s31, #0], v30
    s.add        s31, s13, s28
    s.add        s28, s27, s21
    v.extract    s27, v28, #3
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s30, #0]
    s.addi       s30, s28, #80
    s.addi       s28, s23, #48
    s.add        s33, s13, s30
    v.st.b       [s29, #0], v30
    s.add        s29, s27, s21
    v.extract    s27, v28, #4
    s.addi       s30, s29, #80
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s31, #0]
    s.addi       s29, s23, #80
    s.add        s31, s13, s30
    s.add        s30, s27, s21
    v.st.b       [s28, #0], v30
    s.addi       s27, s30, #80
    v.extract    s28, v28, #5
    s.addi       s30, s23, #112
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s33, #0]
    s.add        s33, s13, s27
    s.add        s27, s28, s21
    v.extract    s28, v28, #6
    v.st.b       [s29, #0], v30
    s.addi       s29, s27, #80
    s.addi       s27, s23, #144
    s.add        s34, s13, s29
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s31, #0]
    s.add        s29, s28, s21
    v.extract    s28, v28, #7
    s.addi       s31, s29, #80
    v.st.b       [s30, #0], v30
    s.addi       s29, s23, #176
    s.add        s30, s13, s31
    s.add        s31, s28, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s33, #0]
    s.addi       s28, s31, #80
    v.extract    s31, v28, #8
    s.add        s33, s13, s28
    v.st.b       [s27, #0], v30
    s.addi       s27, s23, #208
    s.add        s28, s31, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s34, #0]
    s.addi       s31, s28, #80
    v.extract    s28, v28, #9
    s.add        s34, s13, s31
    v.st.b       [s29, #0], v30
    s.addi       s29, s23, #240
    s.add        s31, s28, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s30, #0]
    s.addi       s28, s31, #80
    v.extract    s30, v28, #10
    s.add        s31, s13, s28
    v.st.b       [s27, #0], v30
    s.addi       s27, s23, #272
    s.add        s28, s30, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s33, #0]
    s.addi       s30, s28, #80
    v.extract    s28, v28, #11
    s.add        s33, s13, s30
    v.st.b       [s29, #0], v30
    s.addi       s29, s23, #304
    s.add        s30, s28, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s34, #0]
    s.addi       s28, s30, #80
    v.extract    s30, v28, #12
    s.add        s34, s13, s28
    v.st.b       [s27, #0], v30
    s.addi       s27, s23, #336
    s.add        s28, s30, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s31, #0]
    s.addi       s30, s28, #80
    v.extract    s28, v28, #13
    s.add        s31, s13, s30
    v.st.b       [s29, #0], v30
    s.addi       s29, s23, #368
    s.add        s30, s28, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s33, #0]
    s.addi       s28, s30, #80
    v.extract    s30, v28, #14
    s.add        s33, s13, s28
    v.st.b       [s27, #0], v30
    s.addi       s27, s23, #400
    s.add        s28, s30, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s34, #0]
    s.addi       s30, s28, #80
    v.extract    s28, v28, #15
    s.add        s34, s13, s30
    v.st.b       [s29, #0], v30
    s.addi       s29, s23, #432
    s.add        s30, s28, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s31, #0]
    s.addi       s28, s30, #80
    s.addi       s30, s23, #464
    s.add        s31, s13, s28
    v.st.b       [s27, #0], v30
    s.addi       s27, s23, #496
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s33, #0]
    s.addi       s28, s23, #64
    v.st.b       [s29, #0], v30
    s.addi       s29, s23, #128
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s34, #0]
    s.addi       s33, s23, #192
    v.st.b       [s30, #0], v30
    s.addi       s30, s23, #256
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v30, [s31, #0]
    s.addi       s31, s23, #320
    v.st.b       [s27, #0], v30
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s27, s23, #384
    v.ld.w       v30, [s23, #0]
    s.addi       s34, s23, #448
    v.mov        v48, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s28, #0]
    v.extract    s23, v20, #0
    v.mov        v49, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s29, #0]
    v.mov        v50, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s33, #0]
    v.mov        v51, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s30, #0]
    v.mov        v52, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s31, #0]
    v.mov        v53, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s27, #0]
    v.mov        v54, v30                        // hand off through the shared window (sec 7.3)
    v.ld.w       v30, [s34, #0]
    v.mov        v55, v30                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s23, x8dot_done_36
    s.movz       s27, #0
    s.add        s28, s3, s22
    s.addi       s29, s27, #0
    s.addi       s27, s28, #64
    s.addi       s28, s32, #256
x8dot_row_37:
    s.addi       s30, s26, #-64
    v.movi       v30, #0
    s.sub        s31, s30, s29
    s.add        s30, s27, s29
    v.splat      v31, s31
    s.shli       s31, s29, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s30, v26]            // index is in elements (ISA sec 9.1)
    s.add        s30, s28, s31
    s.addi       s31, s29, #1
    s.movz       s33, #32
    v.st.b       [s30, #0], v30
    fence.acq_rel.device
    s.mov        s29, s31
    s.cmp.lt     s30, s29, s33
    br.nz        s30, x8dot_row_37
x8dot_done_36:
    v.splat      v30, s23
    v.movi       v31, #0
    v.splat      v32, s23
    v.movi       v33, #0
    mb.arm       s23, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s27, #0
    s.movz       s28, #0
    s.movz       s29, #64
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s30, v22, #0
    s.mov        s33, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s33, s23            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s27, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s27, s23          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s23
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s28, v20, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s27
    mb.wait      s27
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s28, x8dot_done_38
    s.movz       s29, #0
    s.add        s30, s3, s22
    s.addi       s31, s29, #0
    s.addi       s29, s30, #64
    s.addi       s30, s32, #256
x8dot_row_39:
    s.addi       s33, s26, #-64
    v.movi       v30, #0
    s.sub        s34, s33, s31
    s.add        s33, s29, s31
    v.splat      v31, s34
    s.shli       s34, s31, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s33, v6]             // index is in elements (ISA sec 9.1)
    s.add        s33, s30, s34
    s.addi       s34, s31, #1
    s.movz       s35, #32
    v.st.b       [s33, #0], v30
    fence.acq_rel.device
    s.mov        s31, s34
    s.cmp.lt     s33, s31, s35
    br.nz        s33, x8dot_row_39
x8dot_done_38:
    v.splat      v30, s28
    v.movi       v31, #0
    v.splat      v32, s28
    v.movi       v33, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    s.movz       s30, #0
    s.movz       s31, #64
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s33, v22, #1
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s30, v20, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_40
    s.movz       s31, #0
    s.add        s33, s3, s22
    s.addi       s34, s31, #0
    s.addi       s31, s33, #64
    s.addi       s33, s32, #256
x8dot_row_41:
    s.addi       s35, s26, #-64
    v.movi       v30, #0
    s.sub        s36, s35, s34
    s.add        s35, s31, s34
    v.splat      v31, s36
    s.shli       s36, s34, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s35, v11]            // index is in elements (ISA sec 9.1)
    s.add        s35, s33, s36
    s.addi       s36, s34, #1
    s.movz       s37, #32
    v.st.b       [s35, #0], v30
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s35, s34, s37
    br.nz        s35, x8dot_row_41
x8dot_done_40:
    v.splat      v30, s30
    v.movi       v31, #0
    v.splat      v32, s30
    v.movi       v33, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    s.movz       s33, #0
    s.movz       s34, #64
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s35, v22, #2
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v20, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_42
    s.movz       s34, #0
    s.add        s35, s3, s22
    s.addi       s36, s34, #0
    s.addi       s34, s35, #64
    s.addi       s35, s32, #256
x8dot_row_43:
    s.addi       s37, s26, #-64
    v.movi       v30, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v31, s38
    s.shli       s38, s36, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s37, v13]            // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.addi       s38, s36, #1
    s.movz       s39, #32
    v.st.b       [s37, #0], v30
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_43
x8dot_done_42:
    v.splat      v30, s33
    v.movi       v31, #0
    v.splat      v32, s33
    v.movi       v33, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    s.movz       s35, #0
    s.movz       s36, #64
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s37, v22, #3
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v20, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_44
    s.movz       s36, #0
    s.add        s37, s3, s22
    s.addi       s38, s36, #0
    s.addi       s36, s37, #64
    s.addi       s37, s32, #256
x8dot_row_45:
    s.addi       s39, s26, #-64
    v.movi       v30, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v31, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s39, v14]            // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v30
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_45
x8dot_done_44:
    v.splat      v30, s35
    v.movi       v31, #0
    v.splat      v32, s35
    v.movi       v33, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    s.movz       s37, #0
    s.movz       s38, #64
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s39, v22, #4
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v20, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_46
    s.movz       s38, #0
    s.add        s39, s3, s22
    s.addi       s40, s38, #0
    s.addi       s38, s39, #64
    s.addi       s39, s32, #256
x8dot_row_47:
    s.addi       s41, s26, #-64
    v.movi       v30, #0
    s.sub        s42, s41, s40
    s.add        s41, s38, s40
    v.splat      v31, s42
    s.shli       s42, s40, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s41, v15]            // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.addi       s42, s40, #1
    s.movz       s43, #32
    v.st.b       [s41, #0], v30
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s41, s40, s43
    br.nz        s41, x8dot_row_47
x8dot_done_46:
    v.splat      v30, s37
    v.movi       v31, #0
    v.splat      v32, s37
    v.movi       v33, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    s.movz       s39, #0
    s.movz       s40, #64
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s41, v22, #5
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v20, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_48
    s.movz       s40, #0
    s.add        s41, s3, s22
    s.addi       s42, s40, #0
    s.addi       s40, s41, #64
    s.addi       s41, s32, #256
x8dot_row_49:
    s.addi       s43, s26, #-64
    v.movi       v30, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v31, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s43, v16]            // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.addi       s44, s42, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v30
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s45
    br.nz        s43, x8dot_row_49
x8dot_done_48:
    v.splat      v30, s39
    v.movi       v31, #0
    v.splat      v32, s39
    v.movi       v33, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    s.movz       s41, #0
    s.movz       s42, #64
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s43, v22, #6
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s44, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v20, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s41, x8dot_done_50
    s.movz       s42, #0
    s.add        s43, s3, s22
    s.addi       s44, s42, #0
    s.addi       s42, s43, #64
    s.addi       s43, s32, #256
x8dot_row_51:
    s.addi       s45, s26, #-64
    v.movi       v30, #0
    s.sub        s46, s45, s44
    s.add        s45, s42, s44
    v.splat      v31, s46
    s.shli       s46, s44, #4
    v.cmp.gt     p1, v31, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v30, [s45, v24]            // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.addi       s46, s44, #1
    s.movz       s47, #32
    v.st.b       [s45, #0], v30
    fence.acq_rel.device
    s.mov        s44, s46
    s.cmp.lt     s45, s44, s47
    br.nz        s45, x8dot_row_51
x8dot_done_50:
    s.movz       s42, #0
    v.extract    s43, v28, #0
    s.add        s44, s42, s15                   // the tile origin
    s.movz       s42, #0
    s.add        s45, s43, s21
    v.splat      v30, s41
    v.movi       v31, #0
    v.splat      v32, s41
    v.movi       v33, #0
    v.splat      v34, s44
    s.add        s41, s42, s24                   // the tile origin
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    s.movz       s44, #0
    s.movz       s46, #64
    s.addi       s47, s45, #96
    v.cmp.ne     p1, v30, v31
    v.cmp.eq     p2, v32, v33
    v.extract    s45, v22, #7
    v.add        v30, v23, v34
    v.splat      v31, s41
    v.extract    s41, v28, #1
    s.mov        s48, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s48, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s44, s13, s47
    s.add        s45, s41, s21
    v.cmp.lt     p1, v30, v31
    m.mma.async.k32.e4m3 a15, v48, v56, s43
    mb.wait      s43
    s.addi       s41, s32, #2560                 // 512 bytes of repack scratch
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s44, #0]
    s.addi       s44, s45, #96
    v.extract    s45, v28, #2
    s.addi       s46, s41, #0
    s.add        s47, s13, s44
    s.add        s44, s45, s21
    v.st.b       [s46, #0], v30
    s.addi       s45, s44, #96
    v.extract    s44, v28, #3
    s.addi       s46, s41, #32
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s47, #0]
    s.add        s47, s13, s45
    s.add        s45, s44, s21
    v.extract    s44, v28, #4
    v.st.b       [s46, #0], v30
    s.addi       s46, s45, #96
    s.addi       s45, s41, #64
    s.add        s48, s13, s46
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s47, #0]
    s.add        s46, s44, s21
    v.extract    s44, v28, #5
    s.addi       s47, s46, #96
    v.st.b       [s45, #0], v30
    s.addi       s45, s41, #96
    s.add        s46, s13, s47
    s.add        s47, s44, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s48, #0]
    s.addi       s44, s47, #96
    v.extract    s47, v28, #6
    s.addi       s48, s41, #128
    v.st.b       [s45, #0], v30
    s.add        s45, s13, s44
    s.add        s44, s47, s21
    v.extract    s47, v28, #7
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s46, #0]
    s.addi       s46, s44, #96
    s.addi       s44, s41, #160
    s.add        s49, s13, s46
    v.st.b       [s48, #0], v30
    s.add        s46, s47, s21
    v.extract    s47, v28, #8
    s.addi       s48, s46, #96
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s45, #0]
    s.addi       s45, s41, #192
    s.add        s46, s13, s48
    s.add        s48, s47, s21
    v.st.b       [s44, #0], v30
    s.addi       s44, s48, #96
    v.extract    s47, v28, #9
    s.addi       s48, s41, #224
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s49, #0]
    s.add        s49, s13, s44
    s.add        s44, s47, s21
    v.extract    s47, v28, #10
    v.st.b       [s45, #0], v30
    s.addi       s45, s44, #96
    s.addi       s44, s41, #256
    s.add        s50, s13, s45
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s46, #0]
    s.add        s45, s47, s21
    v.extract    s46, v28, #11
    s.addi       s47, s45, #96
    v.st.b       [s48, #0], v30
    s.addi       s45, s41, #288
    s.add        s48, s13, s47
    s.add        s47, s46, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s49, #0]
    s.addi       s46, s47, #96
    v.extract    s47, v28, #12
    s.add        s49, s13, s46
    v.st.b       [s44, #0], v30
    s.addi       s44, s41, #320
    s.add        s46, s47, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s50, #0]
    s.addi       s47, s46, #96
    v.extract    s46, v28, #13
    s.add        s50, s13, s47
    v.st.b       [s45, #0], v30
    s.addi       s45, s41, #352
    s.add        s47, s46, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s48, #0]
    s.addi       s46, s47, #96
    v.extract    s47, v28, #14
    s.add        s48, s13, s46
    v.st.b       [s44, #0], v30
    s.addi       s44, s41, #384
    s.add        s46, s47, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s49, #0]
    s.addi       s47, s46, #96
    v.extract    s46, v28, #15
    s.add        s49, s13, s47
    v.st.b       [s45, #0], v30
    s.addi       s45, s41, #416
    s.add        s47, s46, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s50, #0]
    s.movz       s46, #0
    s.addi       s50, s47, #96
    s.add        s47, s46, s16                   // the tile origin
    v.st.b       [s44, #0], v30
    v.extract    s44, v28, #0
    s.add        s46, s13, s50
    s.add        s50, s44, s21
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v30, [s48, #0]
    s.movz       s44, #0
    v.splat      v31, s47
    s.addi       s47, s41, #448
    v.st.b       [s45, #0], v30
    s.add        s45, s44, s24                   // the tile origin
    s.addi       s24, s50, #112
    v.add        v30, v23, v31
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v23, [s49, #0]
    v.splat      v31, s45
    v.extract    s44, v28, #1
    s.addi       s45, s41, #480
    v.st.b       [s47, #0], v23
    s.add        s47, s13, s24
    s.add        s24, s44, s21
    v.cmp.lt     p2, v30, v31
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v23, [s46, #0]
    s.addi       s44, s24, #112
    v.extract    s24, v28, #2
    s.addi       s46, s41, #16
    v.st.b       [s45, #0], v23
    s.add        s45, s13, s44
    s.add        s44, s24, s21
    v.extract    s24, v28, #3
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s47, #0]
    s.addi       s47, s44, #112
    s.addi       s44, s41, #48
    s.add        s48, s13, s47
    v.st.b       [s46, #0], v23
    s.add        s46, s24, s21
    v.extract    s24, v28, #4
    s.addi       s47, s46, #112
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s45, #0]
    s.addi       s45, s41, #80
    s.add        s46, s13, s47
    s.add        s47, s24, s21
    v.st.b       [s44, #0], v23
    s.addi       s24, s47, #112
    v.extract    s44, v28, #5
    s.addi       s47, s41, #112
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s48, #0]
    s.add        s48, s13, s24
    s.add        s24, s44, s21
    v.extract    s44, v28, #6
    v.st.b       [s45, #0], v23
    s.addi       s45, s24, #112
    s.addi       s24, s41, #144
    s.add        s49, s13, s45
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s46, #0]
    s.add        s45, s44, s21
    v.extract    s44, v28, #7
    s.addi       s46, s45, #112
    v.st.b       [s47, #0], v23
    s.addi       s45, s41, #176
    s.add        s47, s13, s46
    s.add        s46, s44, s21
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s48, #0]
    s.addi       s44, s46, #112
    v.extract    s46, v28, #8
    s.addi       s48, s41, #208
    v.st.b       [s24, #0], v23
    s.add        s24, s13, s44
    s.add        s44, s46, s21
    v.extract    s46, v28, #9
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s49, #0]
    s.addi       s49, s44, #112
    s.addi       s44, s41, #240
    s.add        s50, s13, s49
    v.st.b       [s45, #0], v23
    s.add        s45, s46, s21
    v.extract    s46, v28, #10
    s.addi       s49, s45, #112
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s47, #0]
    s.addi       s45, s41, #272
    s.add        s47, s13, s49
    s.add        s49, s46, s21
    v.st.b       [s48, #0], v23
    s.addi       s46, s49, #112
    v.extract    s48, v28, #11
    s.add        s49, s13, s46
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s24, #0]
    s.addi       s24, s41, #304
    s.add        s46, s48, s21
    v.st.b       [s44, #0], v23
    s.addi       s44, s46, #112
    v.extract    s46, v28, #12
    s.add        s48, s13, s44
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s50, #0]
    s.addi       s44, s41, #336
    s.add        s50, s46, s21
    v.st.b       [s45, #0], v23
    s.addi       s45, s50, #112
    v.extract    s46, v28, #13
    s.add        s50, s13, s45
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s47, #0]
    s.addi       s45, s41, #368
    s.add        s47, s46, s21
    v.st.b       [s24, #0], v23
    s.addi       s24, s47, #112
    v.extract    s46, v28, #14
    s.add        s47, s13, s24
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s49, #0]
    s.addi       s24, s41, #400
    s.add        s49, s46, s21
    v.st.b       [s44, #0], v23
    s.addi       s44, s49, #112
    v.extract    s46, v28, #15
    s.add        s49, s13, s44
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s48, #0]
    s.addi       s44, s41, #432
    s.add        s48, s46, s21
    v.st.b       [s45, #0], v23
    s.addi       s45, s48, #112
    s.addi       s46, s41, #464
    s.add        s48, s13, s45
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s50, #0]
    s.addi       s45, s41, #496
    v.st.b       [s24, #0], v23
    s.addi       s24, s41, #64
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s47, #0]
    s.addi       s47, s41, #128
    v.st.b       [s44, #0], v23
    s.addi       s44, s41, #192
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s49, #0]
    s.addi       s49, s41, #256
    v.st.b       [s46, #0], v23
    s.addi       s46, s41, #320
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v23, [s48, #0]
    s.addi       s48, s41, #384
    v.st.b       [s45, #0], v23
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s45, s41, #448
    v.ld.w       v23, [s41, #0]
    v.extract    s41, v20, #0
    v.mov        v48, v23                        // hand off through the shared window (sec 7.3)
    v.ld.w       v23, [s24, #0]
    v.mov        v49, v23                        // hand off through the shared window (sec 7.3)
    v.ld.w       v23, [s47, #0]
    v.mov        v50, v23                        // hand off through the shared window (sec 7.3)
    v.ld.w       v23, [s44, #0]
    v.mov        v51, v23                        // hand off through the shared window (sec 7.3)
    v.ld.w       v23, [s49, #0]
    v.mov        v52, v23                        // hand off through the shared window (sec 7.3)
    v.ld.w       v23, [s46, #0]
    v.mov        v53, v23                        // hand off through the shared window (sec 7.3)
    v.ld.w       v23, [s48, #0]
    v.mov        v54, v23                        // hand off through the shared window (sec 7.3)
    v.ld.w       v23, [s45, #0]
    v.mov        v55, v23                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s41, x8dot_done_52
    s.movz       s24, #0
    s.add        s44, s3, s22
    s.addi       s45, s24, #0
    s.addi       s24, s44, #96
    s.addi       s44, s32, #256
x8dot_row_53:
    s.addi       s46, s26, #-96
    v.movi       v23, #0
    s.sub        s47, s46, s45
    s.add        s46, s24, s45
    v.splat      v28, s47
    s.shli       s47, s45, #4
    v.cmp.gt     p1, v28, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s46, v26]            // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.addi       s47, s45, #1
    s.movz       s48, #32
    v.st.b       [s46, #0], v23
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_53
x8dot_done_52:
    v.splat      v23, s41
    v.movi       v26, #0
    v.splat      v28, s41
    v.movi       v30, #0
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    s.movz       s44, #0
    s.movz       s45, #96
    v.cmp.ne     p1, v23, v26
    v.cmp.eq     p2, v28, v30
    v.extract    s46, v22, #0
    s.mov        s47, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v20, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_54
    s.movz       s45, #0
    s.add        s46, s3, s22
    s.addi       s47, s45, #0
    s.addi       s45, s46, #96
    s.addi       s46, s32, #256
x8dot_row_55:
    s.addi       s48, s26, #-96
    v.movi       v23, #0
    s.sub        s49, s48, s47
    s.add        s48, s45, s47
    v.splat      v26, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s48, v6]             // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s48, #0], v23
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_55
x8dot_done_54:
    v.splat      v6, s44
    v.movi       v23, #0
    v.splat      v26, s44
    v.movi       v28, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    s.movz       s46, #0
    s.movz       s47, #96
    v.cmp.ne     p1, v6, v23
    v.cmp.eq     p2, v26, v28
    v.extract    s48, v22, #1
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v20, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_56
    s.movz       s47, #0
    s.add        s48, s3, s22
    s.addi       s49, s47, #0
    s.addi       s47, s48, #96
    s.addi       s48, s32, #256
x8dot_row_57:
    s.addi       s50, s26, #-96
    v.movi       v6, #0
    s.sub        s51, s50, s49
    s.add        s50, s47, s49
    v.splat      v23, s51
    s.shli       s51, s49, #4
    v.cmp.gt     p1, v23, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s50, v11]             // index is in elements (ISA sec 9.1)
    s.add        s50, s48, s51
    s.addi       s51, s49, #1
    s.movz       s52, #32
    v.st.b       [s50, #0], v6
    fence.acq_rel.device
    s.mov        s49, s51
    s.cmp.lt     s50, s49, s52
    br.nz        s50, x8dot_row_57
x8dot_done_56:
    v.splat      v6, s46
    v.movi       v11, #0
    v.splat      v23, s46
    v.movi       v26, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    s.movz       s48, #0
    s.movz       s49, #96
    v.cmp.ne     p1, v6, v11
    v.cmp.eq     p2, v23, v26
    v.extract    s50, v22, #2
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v20, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_58
    s.movz       s49, #0
    s.add        s50, s3, s22
    s.addi       s51, s49, #0
    s.addi       s49, s50, #96
    s.addi       s50, s32, #256
x8dot_row_59:
    s.addi       s52, s26, #-96
    v.movi       v6, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v11, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v11, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s52, v13]             // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v6
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_59
x8dot_done_58:
    v.splat      v6, s48
    v.movi       v11, #0
    v.splat      v13, s48
    v.movi       v23, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    s.movz       s50, #0
    s.movz       s51, #96
    v.cmp.ne     p1, v6, v11
    v.cmp.eq     p2, v13, v23
    v.extract    s52, v22, #3
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v20, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_60
    s.movz       s51, #0
    s.add        s52, s3, s22
    s.addi       s53, s51, #0
    s.addi       s51, s52, #96
    s.addi       s52, s32, #256
x8dot_row_61:
    s.addi       s54, s26, #-96
    v.movi       v6, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v11, s55
    s.shli       s55, s53, #4
    v.cmp.gt     p1, v11, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s54, v14]             // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.addi       s55, s53, #1
    s.movz       s56, #32
    v.st.b       [s54, #0], v6
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s54, s53, s56
    br.nz        s54, x8dot_row_61
x8dot_done_60:
    v.splat      v6, s50
    v.movi       v11, #0
    v.splat      v13, s50
    v.movi       v14, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s51, #0
    s.movz       s52, #0
    s.movz       s53, #96
    v.cmp.ne     p1, v6, v11
    v.cmp.eq     p2, v13, v14
    v.extract    s54, v22, #4
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v20, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s52, x8dot_done_62
    s.movz       s53, #0
    s.add        s54, s3, s22
    s.addi       s55, s53, #0
    s.addi       s53, s54, #96
    s.addi       s54, s32, #256
x8dot_row_63:
    s.addi       s56, s26, #-96
    v.movi       v6, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v11, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v11, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s56, v15]             // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    s.movz       s58, #32
    v.st.b       [s56, #0], v6
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s58
    br.nz        s56, x8dot_row_63
x8dot_done_62:
    v.splat      v6, s52
    v.movi       v11, #0
    v.splat      v13, s52
    v.movi       v14, #0
    mb.arm       s52, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    s.movz       s54, #0
    s.movz       s55, #96
    v.cmp.ne     p1, v6, v11
    v.cmp.eq     p2, v13, v14
    v.extract    s56, v22, #5
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s57, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v20, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s54, x8dot_done_64
    s.movz       s55, #0
    s.add        s56, s3, s22
    s.addi       s57, s55, #0
    s.addi       s55, s56, #96
    s.addi       s56, s32, #256
x8dot_row_65:
    s.addi       s58, s26, #-96
    v.movi       v6, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v11, s59
    s.shli       s59, s57, #4
    v.cmp.gt     p1, v11, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s58, v16]             // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    s.addi       s59, s57, #1
    s.movz       s60, #32
    v.st.b       [s58, #0], v6
    fence.acq_rel.device
    s.mov        s57, s59
    s.cmp.lt     s58, s57, s60
    br.nz        s58, x8dot_row_65
x8dot_done_64:
    v.splat      v6, s54
    v.movi       v11, #0
    v.splat      v13, s54
    v.movi       v14, #0
    mb.arm       s54, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s55, #0
    s.movz       s56, #0
    s.movz       s57, #96
    v.cmp.ne     p1, v6, v11
    v.cmp.eq     p2, v13, v14
    v.extract    s58, v22, #6
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s60, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s59, s54            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s58                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v20, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s55
    mb.wait      s55
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s56, x8dot_done_66
    s.movz       s57, #0
    s.add        s58, s3, s22
    s.addi       s59, s57, #0
    s.addi       s57, s58, #96
    s.addi       s58, s32, #256
x8dot_row_67:
    s.addi       s60, s26, #-96
    v.movi       v6, #0
    s.sub        s20, s60, s59
    s.add        s23, s57, s59
    v.splat      v11, s20
    s.shli       s20, s59, #4
    v.cmp.gt     p1, v11, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s23, v24]             // index is in elements (ISA sec 9.1)
    s.add        s23, s58, s20
    s.addi       s20, s59, #1
    s.movz       s24, #32
    v.st.b       [s23, #0], v6
    fence.acq_rel.device
    s.mov        s59, s20
    s.cmp.lt     s20, s59, s24
    br.nz        s20, x8dot_row_67
x8dot_done_66:
    v.splat      v6, s56
    v.movi       v11, #0
    v.splat      v13, s56
    v.movi       v14, #0
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s23, #0
    s.movz       s24, #0
    s.movz       s25, #96
    v.cmp.ne     p1, v6, v11
    v.cmp.eq     p2, v13, v14
    v.extract    s26, v22, #7
    s.mov        s27, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s24                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s27, s20            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s23, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s25                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s23, s20          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s20
    mb.arm       s23, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s24, #0
    m.mma.async.k32.e4m3 a15, v48, v56, s23
    mb.wait      s23
    s.addi       s25, s32, #3072
    a.vread      v6, a8, s24
    s.movz       s24, #1
    v.st.w       [s25, #0], v6
    s.addi       s26, s25, #64
    a.vread      v6, a8, s24
    s.movz       s24, #2
    s.addi       s27, s25, #128
    s.movz       s28, #3
    s.addi       s29, s25, #192
    s.movz       s30, #4
    v.st.w       [s26, #0], v6
    a.vread      v6, a8, s24
    s.addi       s24, s25, #256
    s.movz       s26, #5
    v.st.w       [s27, #0], v6
    a.vread      v6, a8, s28
    s.addi       s27, s25, #320
    s.movz       s28, #6
    v.st.w       [s29, #0], v6
    a.vread      v6, a8, s30
    s.addi       s29, s25, #384
    s.movz       s30, #7
    v.st.w       [s24, #0], v6
    a.vread      v6, a8, s26
    s.addi       s24, s25, #448
    s.movz       s26, #8
    v.st.w       [s27, #0], v6
    a.vread      v6, a8, s28
    s.addi       s27, s25, #512
    s.movz       s28, #9
    v.st.w       [s29, #0], v6
    a.vread      v6, a8, s30
    s.addi       s29, s25, #576
    s.movz       s30, #10
    v.st.w       [s24, #0], v6
    a.vread      v6, a8, s26
    s.addi       s24, s25, #640
    s.movz       s26, #11
    v.st.w       [s27, #0], v6
    a.vread      v6, a8, s28
    s.addi       s27, s25, #704
    s.movz       s28, #12
    v.st.w       [s29, #0], v6
    a.vread      v6, a8, s30
    s.addi       s29, s25, #768
    s.movz       s30, #13
    v.st.w       [s24, #0], v6
    a.vread      v6, a8, s26
    s.addi       s24, s25, #832
    s.movz       s26, #14
    v.st.w       [s27, #0], v6
    a.vread      v6, a8, s28
    s.addi       s27, s25, #896
    s.movz       s28, #15
    s.addi       s31, s25, #960
    v.st.w       [s29, #0], v6
    a.vread      v6, a8, s30
    s.movz       s25, #0
    s.addi       s29, s32, #4096
    v.st.w       [s24, #0], v6
    a.vread      v6, a8, s26
    s.movz       s24, #1
    s.addi       s26, s29, #64
    v.st.w       [s27, #0], v6
    a.vread      v6, a8, s28
    s.movz       s27, #2
    s.addi       s28, s29, #128
    v.st.w       [s31, #0], v6
    fence.acq_rel.device
    a.vread      v6, a9, s25
    s.movz       s25, #3
    s.addi       s30, s29, #192
    v.st.w       [s29, #0], v6
    a.vread      v6, a9, s24
    s.movz       s24, #4
    v.st.w       [s26, #0], v6
    a.vread      v6, a9, s27
    s.addi       s26, s29, #256
    s.movz       s27, #5
    v.st.w       [s28, #0], v6
    a.vread      v6, a9, s25
    s.addi       s25, s29, #320
    s.movz       s28, #6
    v.st.w       [s30, #0], v6
    a.vread      v6, a9, s24
    s.addi       s24, s29, #384
    s.movz       s30, #7
    v.st.w       [s26, #0], v6
    a.vread      v6, a9, s27
    s.addi       s26, s29, #448
    s.movz       s27, #8
    v.st.w       [s25, #0], v6
    a.vread      v6, a9, s28
    s.addi       s25, s29, #512
    s.movz       s28, #9
    v.st.w       [s24, #0], v6
    a.vread      v6, a9, s30
    s.addi       s24, s29, #576
    s.movz       s30, #10
    v.st.w       [s26, #0], v6
    a.vread      v6, a9, s27
    s.addi       s26, s29, #640
    s.movz       s27, #11
    v.st.w       [s25, #0], v6
    a.vread      v6, a9, s28
    s.addi       s25, s29, #704
    s.movz       s28, #12
    v.st.w       [s24, #0], v6
    a.vread      v6, a9, s30
    s.addi       s24, s29, #768
    s.movz       s30, #13
    v.st.w       [s26, #0], v6
    a.vread      v6, a9, s27
    s.addi       s26, s29, #832
    s.movz       s27, #14
    v.st.w       [s25, #0], v6
    a.vread      v6, a9, s28
    s.addi       s25, s29, #896
    s.movz       s28, #15
    s.addi       s31, s29, #960
    v.st.w       [s24, #0], v6
    a.vread      v6, a9, s30
    s.movz       s24, #0
    s.addi       s29, s32, #5120
    v.st.w       [s26, #0], v6
    a.vread      v6, a9, s27
    s.movz       s26, #1
    s.addi       s27, s29, #64
    v.st.w       [s25, #0], v6
    a.vread      v6, a9, s28
    s.movz       s25, #2
    s.addi       s28, s29, #128
    v.st.w       [s31, #0], v6
    fence.acq_rel.device
    a.vread      v6, a10, s24
    s.movz       s24, #3
    s.addi       s30, s29, #192
    v.st.w       [s29, #0], v6
    a.vread      v6, a10, s26
    s.movz       s26, #4
    v.st.w       [s27, #0], v6
    a.vread      v6, a10, s25
    s.addi       s25, s29, #256
    s.movz       s27, #5
    v.st.w       [s28, #0], v6
    a.vread      v6, a10, s24
    s.addi       s24, s29, #320
    s.movz       s28, #6
    v.st.w       [s30, #0], v6
    a.vread      v6, a10, s26
    s.addi       s26, s29, #384
    s.movz       s30, #7
    v.st.w       [s25, #0], v6
    a.vread      v6, a10, s27
    s.addi       s25, s29, #448
    s.movz       s27, #8
    v.st.w       [s24, #0], v6
    a.vread      v6, a10, s28
    s.addi       s24, s29, #512
    s.movz       s28, #9
    v.st.w       [s26, #0], v6
    a.vread      v6, a10, s30
    s.addi       s26, s29, #576
    s.movz       s30, #10
    v.st.w       [s25, #0], v6
    a.vread      v6, a10, s27
    s.addi       s25, s29, #640
    s.movz       s27, #11
    v.st.w       [s24, #0], v6
    a.vread      v6, a10, s28
    s.addi       s24, s29, #704
    s.movz       s28, #12
    v.st.w       [s26, #0], v6
    a.vread      v6, a10, s30
    s.addi       s26, s29, #768
    s.movz       s30, #13
    v.st.w       [s25, #0], v6
    a.vread      v6, a10, s27
    s.addi       s25, s29, #832
    s.movz       s27, #14
    v.st.w       [s24, #0], v6
    a.vread      v6, a10, s28
    s.addi       s24, s29, #896
    s.movz       s28, #15
    s.addi       s31, s29, #960
    v.st.w       [s26, #0], v6
    a.vread      v6, a10, s30
    s.movz       s26, #0
    s.addi       s29, s32, #6144
    v.st.w       [s25, #0], v6
    a.vread      v6, a10, s27
    s.movz       s25, #1
    s.addi       s27, s29, #64
    v.st.w       [s24, #0], v6
    a.vread      v6, a10, s28
    s.movz       s24, #2
    s.addi       s28, s29, #128
    v.st.w       [s31, #0], v6
    fence.acq_rel.device
    a.vread      v6, a11, s26
    s.movz       s26, #3
    s.addi       s30, s29, #192
    v.st.w       [s29, #0], v6
    a.vread      v6, a11, s25
    s.movz       s25, #4
    v.st.w       [s27, #0], v6
    a.vread      v6, a11, s24
    s.addi       s24, s29, #256
    s.movz       s27, #5
    v.st.w       [s28, #0], v6
    a.vread      v6, a11, s26
    s.addi       s26, s29, #320
    s.movz       s28, #6
    v.st.w       [s30, #0], v6
    a.vread      v6, a11, s25
    s.addi       s25, s29, #384
    s.movz       s30, #7
    v.st.w       [s24, #0], v6
    a.vread      v6, a11, s27
    s.addi       s24, s29, #448
    s.movz       s27, #8
    v.st.w       [s26, #0], v6
    a.vread      v6, a11, s28
    s.addi       s26, s29, #512
    s.movz       s28, #9
    v.st.w       [s25, #0], v6
    a.vread      v6, a11, s30
    s.addi       s25, s29, #576
    s.movz       s30, #10
    v.st.w       [s24, #0], v6
    a.vread      v6, a11, s27
    s.addi       s24, s29, #640
    s.movz       s27, #11
    v.st.w       [s26, #0], v6
    a.vread      v6, a11, s28
    s.addi       s26, s29, #704
    s.movz       s28, #12
    v.st.w       [s25, #0], v6
    a.vread      v6, a11, s30
    s.addi       s25, s29, #768
    s.movz       s30, #13
    v.st.w       [s24, #0], v6
    a.vread      v6, a11, s27
    s.addi       s24, s29, #832
    s.movz       s27, #14
    v.st.w       [s26, #0], v6
    a.vread      v6, a11, s28
    s.addi       s26, s29, #896
    s.movz       s28, #15
    s.addi       s31, s29, #960
    v.st.w       [s25, #0], v6
    a.vread      v6, a11, s30
    s.movz       s25, #0
    s.addi       s29, s32, #7168
    v.st.w       [s24, #0], v6
    a.vread      v6, a11, s27
    s.movz       s24, #1
    s.addi       s27, s29, #64
    v.st.w       [s26, #0], v6
    a.vread      v6, a11, s28
    s.movz       s26, #2
    s.addi       s28, s29, #128
    v.st.w       [s31, #0], v6
    fence.acq_rel.device
    a.vread      v6, a12, s25
    s.movz       s25, #3
    s.addi       s30, s29, #192
    v.st.w       [s29, #0], v6
    a.vread      v6, a12, s24
    s.movz       s24, #4
    v.st.w       [s27, #0], v6
    a.vread      v6, a12, s26
    s.addi       s26, s29, #256
    s.movz       s27, #5
    v.st.w       [s28, #0], v6
    a.vread      v6, a12, s25
    s.addi       s25, s29, #320
    s.movz       s28, #6
    v.st.w       [s30, #0], v6
    a.vread      v6, a12, s24
    s.addi       s24, s29, #384
    s.movz       s30, #7
    v.st.w       [s26, #0], v6
    a.vread      v6, a12, s27
    s.addi       s26, s29, #448
    s.movz       s27, #8
    v.st.w       [s25, #0], v6
    a.vread      v6, a12, s28
    s.addi       s25, s29, #512
    s.movz       s28, #9
    v.st.w       [s24, #0], v6
    a.vread      v6, a12, s30
    s.addi       s24, s29, #576
    s.movz       s30, #10
    v.st.w       [s26, #0], v6
    a.vread      v6, a12, s27
    s.addi       s26, s29, #640
    s.movz       s27, #11
    v.st.w       [s25, #0], v6
    a.vread      v6, a12, s28
    s.addi       s25, s29, #704
    s.movz       s28, #12
    v.st.w       [s24, #0], v6
    a.vread      v6, a12, s30
    s.addi       s24, s29, #768
    s.movz       s30, #13
    v.st.w       [s26, #0], v6
    a.vread      v6, a12, s27
    s.addi       s26, s29, #832
    s.movz       s27, #14
    v.st.w       [s25, #0], v6
    a.vread      v6, a12, s28
    s.addi       s25, s29, #896
    s.movz       s28, #15
    s.addi       s31, s29, #960
    v.st.w       [s24, #0], v6
    a.vread      v6, a12, s30
    s.movz       s24, #0
    s.addi       s29, s32, #8192
    v.st.w       [s26, #0], v6
    a.vread      v6, a12, s27
    s.movz       s26, #1
    s.addi       s27, s29, #64
    v.st.w       [s25, #0], v6
    a.vread      v6, a12, s28
    s.movz       s25, #2
    s.addi       s28, s29, #128
    v.st.w       [s31, #0], v6
    fence.acq_rel.device
    a.vread      v6, a13, s24
    s.movz       s24, #3
    s.addi       s30, s29, #192
    v.st.w       [s29, #0], v6
    a.vread      v6, a13, s26
    s.movz       s26, #4
    v.st.w       [s27, #0], v6
    a.vread      v6, a13, s25
    s.addi       s25, s29, #256
    s.movz       s27, #5
    v.st.w       [s28, #0], v6
    a.vread      v6, a13, s24
    s.addi       s24, s29, #320
    s.movz       s28, #6
    v.st.w       [s30, #0], v6
    a.vread      v6, a13, s26
    s.addi       s26, s29, #384
    s.movz       s30, #7
    v.st.w       [s25, #0], v6
    a.vread      v6, a13, s27
    s.addi       s25, s29, #448
    s.movz       s27, #8
    v.st.w       [s24, #0], v6
    a.vread      v6, a13, s28
    s.addi       s24, s29, #512
    s.movz       s28, #9
    v.st.w       [s26, #0], v6
    a.vread      v6, a13, s30
    s.addi       s26, s29, #576
    s.movz       s30, #10
    v.st.w       [s25, #0], v6
    a.vread      v6, a13, s27
    s.addi       s25, s29, #640
    s.movz       s27, #11
    v.st.w       [s24, #0], v6
    a.vread      v6, a13, s28
    s.addi       s24, s29, #704
    s.movz       s28, #12
    v.st.w       [s26, #0], v6
    a.vread      v6, a13, s30
    s.addi       s26, s29, #768
    s.movz       s30, #13
    v.st.w       [s25, #0], v6
    a.vread      v6, a13, s27
    s.addi       s25, s29, #832
    s.movz       s27, #14
    v.st.w       [s24, #0], v6
    a.vread      v6, a13, s28
    s.addi       s24, s29, #896
    s.movz       s28, #15
    s.addi       s31, s29, #960
    v.st.w       [s26, #0], v6
    a.vread      v6, a13, s30
    s.movz       s26, #0
    s.addi       s29, s32, #9216
    v.st.w       [s25, #0], v6
    a.vread      v6, a13, s27
    s.movz       s25, #1
    s.addi       s27, s29, #64
    v.st.w       [s24, #0], v6
    a.vread      v6, a13, s28
    s.movz       s24, #2
    s.addi       s28, s29, #128
    v.st.w       [s31, #0], v6
    fence.acq_rel.device
    a.vread      v6, a14, s26
    s.movz       s26, #3
    s.addi       s30, s29, #192
    v.st.w       [s29, #0], v6
    a.vread      v6, a14, s25
    s.movz       s25, #4
    v.st.w       [s27, #0], v6
    a.vread      v6, a14, s24
    s.addi       s24, s29, #256
    s.movz       s27, #5
    v.st.w       [s28, #0], v6
    a.vread      v6, a14, s26
    s.addi       s26, s29, #320
    s.movz       s28, #6
    v.st.w       [s30, #0], v6
    a.vread      v6, a14, s25
    s.addi       s25, s29, #384
    s.movz       s30, #7
    v.st.w       [s24, #0], v6
    a.vread      v6, a14, s27
    s.addi       s24, s29, #448
    s.movz       s27, #8
    v.st.w       [s26, #0], v6
    a.vread      v6, a14, s28
    s.addi       s26, s29, #512
    s.movz       s28, #9
    v.st.w       [s25, #0], v6
    a.vread      v6, a14, s30
    s.addi       s25, s29, #576
    s.movz       s30, #10
    v.st.w       [s24, #0], v6
    a.vread      v6, a14, s27
    s.addi       s24, s29, #640
    s.movz       s27, #11
    v.st.w       [s26, #0], v6
    a.vread      v6, a14, s28
    s.addi       s26, s29, #704
    s.movz       s28, #12
    v.st.w       [s25, #0], v6
    a.vread      v6, a14, s30
    s.addi       s25, s29, #768
    s.movz       s30, #13
    v.st.w       [s24, #0], v6
    a.vread      v6, a14, s27
    s.addi       s24, s29, #832
    s.movz       s27, #14
    v.st.w       [s26, #0], v6
    a.vread      v6, a14, s28
    s.addi       s26, s29, #896
    s.movz       s28, #15
    s.addi       s31, s29, #960
    v.st.w       [s25, #0], v6
    a.vread      v6, a14, s30
    s.movz       s25, #0
    s.addi       s29, s32, #10240
    v.st.w       [s24, #0], v6
    a.vread      v6, a14, s27
    s.movz       s24, #1
    s.addi       s27, s29, #64
    v.st.w       [s26, #0], v6
    a.vread      v6, a14, s28
    s.movz       s26, #2
    s.addi       s28, s29, #128
    v.st.w       [s31, #0], v6
    fence.acq_rel.device
    a.vread      v6, a15, s25
    s.movz       s25, #3
    s.addi       s30, s29, #192
    v.st.w       [s29, #0], v6
    a.vread      v6, a15, s24
    s.movz       s24, #4
    v.st.w       [s27, #0], v6
    a.vread      v6, a15, s26
    s.addi       s26, s29, #256
    s.movz       s27, #5
    v.st.w       [s28, #0], v6
    a.vread      v6, a15, s25
    s.addi       s25, s29, #320
    s.movz       s28, #6
    v.st.w       [s30, #0], v6
    a.vread      v6, a15, s24
    s.addi       s24, s29, #384
    s.movz       s30, #7
    v.st.w       [s26, #0], v6
    a.vread      v6, a15, s27
    s.addi       s26, s29, #448
    s.movz       s27, #8
    v.st.w       [s25, #0], v6
    a.vread      v6, a15, s28
    s.addi       s25, s29, #512
    s.movz       s28, #9
    v.st.w       [s24, #0], v6
    a.vread      v6, a15, s30
    s.addi       s24, s29, #576
    s.movz       s30, #10
    v.st.w       [s26, #0], v6
    a.vread      v6, a15, s27
    s.addi       s26, s29, #640
    s.movz       s27, #11
    v.st.w       [s25, #0], v6
    a.vread      v6, a15, s28
    s.addi       s25, s29, #704
    s.movz       s28, #12
    v.st.w       [s24, #0], v6
    a.vread      v6, a15, s30
    s.addi       s24, s29, #768
    s.movz       s30, #13
    v.st.w       [s26, #0], v6
    a.vread      v6, a15, s27
    s.addi       s26, s29, #832
    s.movz       s27, #14
    v.st.w       [s25, #0], v6
    a.vread      v6, a15, s28
    s.addi       s25, s29, #896
    s.movz       s28, #15
    s.addi       s31, s29, #960
    v.st.w       [s24, #0], v6
    a.vread      v6, a15, s30
    s.movz       s24, #0
    s.addi       s29, s32, #3072
    v.st.w       [s26, #0], v6
    a.vread      v6, a15, s27
    v.extract    s26, v0, #0
    v.splat      v11, s26
    s.addi       s26, s32, #11264
    s.movz       s27, #1
    v.st.w       [s25, #0], v6
    a.vread      v6, a15, s28
    s.addi       s25, s32, #3136
    v.extract    s28, v0, #1
    v.splat      v13, s28
    s.addi       s28, s26, #64
    v.st.w       [s31, #0], v6
    fence.acq_rel.device
    a.vread      v6, a0, s24
    s.movz       s24, #2
    s.addi       s30, s32, #3200
    v.ld.w       v14, [s29, #0]
    v.extract    s29, v0, #2
    v.splat      v15, s29
    s.addi       s29, s26, #128
    vf.mul       v16, v14, v11
    vf.mul       v11, v16, v12
    vf.add       v14, v6, v11
    v.st.w       [s26, #0], v14
    a.vread      v6, a0, s27
    s.movz       s27, #3
    v.ld.w       v11, [s25, #0]
    s.addi       s25, s32, #3264
    vf.mul       v14, v11, v13
    vf.mul       v11, v14, v12
    vf.add       v13, v6, v11
    v.st.w       [s28, #0], v13
    a.vread      v6, a0, s24
    v.extract    s24, v0, #3
    v.splat      v11, s24
    s.addi       s24, s26, #192
    s.movz       s28, #4
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #3328
    vf.mul       v14, v13, v15
    vf.mul       v13, v14, v12
    vf.add       v14, v6, v13
    v.st.w       [s29, #0], v14
    a.vread      v6, a0, s27
    v.extract    s27, v0, #4
    v.splat      v13, s27
    s.addi       s27, s26, #256
    s.movz       s29, #5
    v.ld.w       v14, [s25, #0]
    s.addi       s25, s32, #3392
    vf.mul       v15, v14, v11
    vf.mul       v11, v15, v12
    vf.add       v14, v6, v11
    v.st.w       [s24, #0], v14
    a.vread      v6, a0, s28
    v.extract    s24, v0, #5
    v.splat      v11, s24
    s.addi       s24, s26, #320
    s.movz       s28, #6
    v.ld.w       v14, [s30, #0]
    s.addi       s30, s32, #3456
    vf.mul       v15, v14, v13
    vf.mul       v13, v15, v12
    vf.add       v14, v6, v13
    v.st.w       [s27, #0], v14
    a.vread      v6, a0, s29
    v.extract    s27, v0, #6
    v.splat      v13, s27
    s.addi       s27, s26, #384
    s.movz       s29, #7
    v.ld.w       v14, [s25, #0]
    s.addi       s25, s32, #3520
    vf.mul       v15, v14, v11
    vf.mul       v11, v15, v12
    vf.add       v14, v6, v11
    v.st.w       [s24, #0], v14
    a.vread      v6, a0, s28
    v.extract    s24, v0, #7
    v.splat      v11, s24
    s.addi       s24, s26, #448
    s.movz       s28, #8
    v.ld.w       v14, [s30, #0]
    s.addi       s30, s32, #3584
    vf.mul       v15, v14, v13
    vf.mul       v13, v15, v12
    vf.add       v14, v6, v13
    v.st.w       [s27, #0], v14
    a.vread      v6, a0, s29
    v.extract    s27, v0, #8
    v.splat      v13, s27
    s.addi       s27, s26, #512
    s.movz       s29, #9
    v.ld.w       v14, [s25, #0]
    s.addi       s25, s32, #3648
    vf.mul       v15, v14, v11
    vf.mul       v11, v15, v12
    vf.add       v14, v6, v11
    v.st.w       [s24, #0], v14
    a.vread      v6, a0, s28
    v.extract    s24, v0, #9
    v.splat      v11, s24
    s.addi       s24, s26, #576
    s.movz       s28, #10
    v.ld.w       v14, [s30, #0]
    s.addi       s30, s32, #3712
    vf.mul       v15, v14, v13
    vf.mul       v13, v15, v12
    vf.add       v14, v6, v13
    v.st.w       [s27, #0], v14
    a.vread      v6, a0, s29
    v.extract    s27, v0, #10
    v.splat      v13, s27
    s.addi       s27, s26, #640
    s.movz       s29, #11
    v.ld.w       v14, [s25, #0]
    s.addi       s25, s32, #3776
    vf.mul       v15, v14, v11
    vf.mul       v11, v15, v12
    vf.add       v14, v6, v11
    v.st.w       [s24, #0], v14
    a.vread      v6, a0, s28
    v.extract    s24, v0, #11
    v.splat      v11, s24
    s.addi       s24, s26, #704
    s.movz       s28, #12
    v.ld.w       v14, [s30, #0]
    s.addi       s30, s32, #3840
    vf.mul       v15, v14, v13
    vf.mul       v13, v15, v12
    vf.add       v14, v6, v13
    v.st.w       [s27, #0], v14
    a.vread      v6, a0, s29
    v.extract    s27, v0, #12
    v.splat      v13, s27
    s.addi       s27, s26, #768
    s.movz       s29, #13
    v.ld.w       v14, [s25, #0]
    s.addi       s25, s32, #3904
    vf.mul       v15, v14, v11
    vf.mul       v11, v15, v12
    vf.add       v14, v6, v11
    v.st.w       [s24, #0], v14
    a.vread      v6, a0, s28
    v.extract    s24, v0, #13
    v.splat      v11, s24
    s.addi       s24, s26, #832
    s.movz       s28, #14
    v.ld.w       v14, [s30, #0]
    s.addi       s30, s32, #3968
    vf.mul       v15, v14, v13
    vf.mul       v13, v15, v12
    vf.add       v14, v6, v13
    v.st.w       [s27, #0], v14
    a.vread      v6, a0, s29
    v.extract    s27, v0, #14
    v.splat      v13, s27
    s.addi       s27, s26, #896
    s.movz       s29, #15
    s.addi       s31, s26, #960
    v.ld.w       v14, [s25, #0]
    s.addi       s25, s32, #4032
    vf.mul       v15, v14, v11
    vf.mul       v11, v15, v12
    vf.add       v14, v6, v11
    v.st.w       [s24, #0], v14
    a.vread      v6, a0, s28
    v.extract    s24, v0, #15
    v.splat      v11, s24
    s.movz       s24, #0
    s.addi       s26, s32, #4096
    v.ld.w       v14, [s30, #0]
    v.extract    s28, v0, #0
    v.splat      v15, s28
    s.addi       s28, s32, #12288
    vf.mul       v16, v14, v13
    vf.mul       v13, v16, v12
    vf.add       v14, v6, v13
    v.st.w       [s27, #0], v14
    a.vread      v6, a0, s29
    s.movz       s27, #1
    s.addi       s29, s32, #4160
    v.ld.w       v13, [s25, #0]
    v.extract    s25, v0, #1
    v.splat      v14, s25
    s.addi       s25, s28, #64
    vf.mul       v16, v13, v11
    vf.mul       v11, v16, v12
    vf.add       v12, v6, v11
    v.st.w       [s31, #0], v12
    fence.acq_rel.device
    a.vread      v6, a1, s24
    s.movz       s24, #2
    s.addi       s30, s32, #4224
    v.ld.w       v11, [s26, #0]
    v.extract    s26, v0, #2
    v.splat      v12, s26
    s.addi       s26, s28, #128
    vf.mul       v13, v11, v15
    vf.mul       v11, v13, v17
    vf.add       v13, v6, v11
    v.st.w       [s28, #0], v13
    a.vread      v6, a1, s27
    s.movz       s27, #3
    v.ld.w       v11, [s29, #0]
    s.addi       s29, s32, #4288
    vf.mul       v13, v11, v14
    vf.mul       v11, v13, v17
    vf.add       v13, v6, v11
    v.st.w       [s25, #0], v13
    a.vread      v6, a1, s24
    v.extract    s24, v0, #3
    v.splat      v11, s24
    s.addi       s24, s28, #192
    s.movz       s25, #4
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #4352
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v6, v12
    v.st.w       [s26, #0], v13
    a.vread      v6, a1, s27
    v.extract    s26, v0, #4
    v.splat      v12, s26
    s.addi       s26, s28, #256
    s.movz       s27, #5
    v.ld.w       v13, [s29, #0]
    s.addi       s29, s32, #4416
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v17
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a1, s25
    v.extract    s24, v0, #5
    v.splat      v11, s24
    s.addi       s24, s28, #320
    s.movz       s25, #6
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #4480
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v6, v12
    v.st.w       [s26, #0], v13
    a.vread      v6, a1, s27
    v.extract    s26, v0, #6
    v.splat      v12, s26
    s.addi       s26, s28, #384
    s.movz       s27, #7
    v.ld.w       v13, [s29, #0]
    s.addi       s29, s32, #4544
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v17
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a1, s25
    v.extract    s24, v0, #7
    v.splat      v11, s24
    s.addi       s24, s28, #448
    s.movz       s25, #8
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #4608
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v6, v12
    v.st.w       [s26, #0], v13
    a.vread      v6, a1, s27
    v.extract    s26, v0, #8
    v.splat      v12, s26
    s.addi       s26, s28, #512
    s.movz       s27, #9
    v.ld.w       v13, [s29, #0]
    s.addi       s29, s32, #4672
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v17
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a1, s25
    v.extract    s24, v0, #9
    v.splat      v11, s24
    s.addi       s24, s28, #576
    s.movz       s25, #10
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #4736
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v6, v12
    v.st.w       [s26, #0], v13
    a.vread      v6, a1, s27
    v.extract    s26, v0, #10
    v.splat      v12, s26
    s.addi       s26, s28, #640
    s.movz       s27, #11
    v.ld.w       v13, [s29, #0]
    s.addi       s29, s32, #4800
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v17
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a1, s25
    v.extract    s24, v0, #11
    v.splat      v11, s24
    s.addi       s24, s28, #704
    s.movz       s25, #12
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #4864
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v6, v12
    v.st.w       [s26, #0], v13
    a.vread      v6, a1, s27
    v.extract    s26, v0, #12
    v.splat      v12, s26
    s.addi       s26, s28, #768
    s.movz       s27, #13
    v.ld.w       v13, [s29, #0]
    s.addi       s29, s32, #4928
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v17
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a1, s25
    v.extract    s24, v0, #13
    v.splat      v11, s24
    s.addi       s24, s28, #832
    s.movz       s25, #14
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #4992
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v6, v12
    v.st.w       [s26, #0], v13
    a.vread      v6, a1, s27
    v.extract    s26, v0, #14
    v.splat      v12, s26
    s.addi       s26, s28, #896
    s.movz       s27, #15
    s.addi       s31, s28, #960
    v.ld.w       v13, [s29, #0]
    s.addi       s28, s32, #5056
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v17
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a1, s25
    v.extract    s24, v0, #15
    v.splat      v11, s24
    s.movz       s24, #0
    s.addi       s25, s32, #5120
    v.ld.w       v13, [s30, #0]
    v.extract    s29, v0, #0
    v.splat      v14, s29
    s.addi       s29, s32, #13312
    vf.mul       v15, v13, v12
    vf.mul       v12, v15, v17
    vf.add       v13, v6, v12
    v.st.w       [s26, #0], v13
    a.vread      v6, a1, s27
    s.movz       s26, #1
    s.addi       s27, s32, #5184
    v.ld.w       v12, [s28, #0]
    v.extract    s28, v0, #1
    v.splat      v13, s28
    s.addi       s28, s29, #64
    vf.mul       v15, v12, v11
    vf.mul       v11, v15, v17
    vf.add       v12, v6, v11
    v.st.w       [s31, #0], v12
    fence.acq_rel.device
    a.vread      v6, a2, s24
    s.movz       s24, #2
    s.addi       s30, s32, #5248
    v.ld.w       v11, [s25, #0]
    v.extract    s25, v0, #2
    v.splat      v12, s25
    s.addi       s25, s29, #128
    vf.mul       v15, v11, v14
    vf.mul       v11, v15, v21
    vf.add       v14, v6, v11
    v.st.w       [s29, #0], v14
    a.vread      v6, a2, s26
    s.movz       s26, #3
    v.ld.w       v11, [s27, #0]
    s.addi       s27, s32, #5312
    vf.mul       v14, v11, v13
    vf.mul       v11, v14, v21
    vf.add       v13, v6, v11
    v.st.w       [s28, #0], v13
    a.vread      v6, a2, s24
    v.extract    s24, v0, #3
    v.splat      v11, s24
    s.addi       s24, s29, #192
    s.movz       s28, #4
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #5376
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v21
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a2, s26
    v.extract    s25, v0, #4
    v.splat      v12, s25
    s.addi       s25, s29, #256
    s.movz       s26, #5
    v.ld.w       v13, [s27, #0]
    s.addi       s27, s32, #5440
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v21
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a2, s28
    v.extract    s24, v0, #5
    v.splat      v11, s24
    s.addi       s24, s29, #320
    s.movz       s28, #6
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #5504
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v21
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a2, s26
    v.extract    s25, v0, #6
    v.splat      v12, s25
    s.addi       s25, s29, #384
    s.movz       s26, #7
    v.ld.w       v13, [s27, #0]
    s.addi       s27, s32, #5568
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v21
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a2, s28
    v.extract    s24, v0, #7
    v.splat      v11, s24
    s.addi       s24, s29, #448
    s.movz       s28, #8
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #5632
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v21
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a2, s26
    v.extract    s25, v0, #8
    v.splat      v12, s25
    s.addi       s25, s29, #512
    s.movz       s26, #9
    v.ld.w       v13, [s27, #0]
    s.addi       s27, s32, #5696
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v21
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a2, s28
    v.extract    s24, v0, #9
    v.splat      v11, s24
    s.addi       s24, s29, #576
    s.movz       s28, #10
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #5760
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v21
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a2, s26
    v.extract    s25, v0, #10
    v.splat      v12, s25
    s.addi       s25, s29, #640
    s.movz       s26, #11
    v.ld.w       v13, [s27, #0]
    s.addi       s27, s32, #5824
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v21
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a2, s28
    v.extract    s24, v0, #11
    v.splat      v11, s24
    s.addi       s24, s29, #704
    s.movz       s28, #12
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #5888
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v21
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a2, s26
    v.extract    s25, v0, #12
    v.splat      v12, s25
    s.addi       s25, s29, #768
    s.movz       s26, #13
    v.ld.w       v13, [s27, #0]
    s.addi       s27, s32, #5952
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v21
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a2, s28
    v.extract    s24, v0, #13
    v.splat      v11, s24
    s.addi       s24, s29, #832
    s.movz       s28, #14
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #6016
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v21
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a2, s26
    v.extract    s25, v0, #14
    v.splat      v12, s25
    s.addi       s25, s29, #896
    s.movz       s26, #15
    s.addi       s31, s29, #960
    v.ld.w       v13, [s27, #0]
    s.addi       s27, s32, #6080
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v21
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a2, s28
    v.extract    s24, v0, #15
    v.splat      v11, s24
    s.movz       s24, #0
    s.addi       s28, s32, #6144
    v.ld.w       v13, [s30, #0]
    v.extract    s29, v0, #0
    v.splat      v14, s29
    s.addi       s29, s32, #14336
    vf.mul       v15, v13, v12
    vf.mul       v12, v15, v21
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a2, s26
    s.movz       s25, #1
    s.addi       s26, s32, #6208
    v.ld.w       v12, [s27, #0]
    v.extract    s27, v0, #1
    v.splat      v13, s27
    s.addi       s27, s29, #64
    vf.mul       v15, v12, v11
    vf.mul       v11, v15, v21
    vf.add       v12, v6, v11
    v.st.w       [s31, #0], v12
    fence.acq_rel.device
    a.vread      v6, a3, s24
    s.movz       s24, #2
    s.addi       s30, s32, #6272
    v.ld.w       v11, [s28, #0]
    v.extract    s28, v0, #2
    v.splat      v12, s28
    s.addi       s28, s29, #128
    vf.mul       v15, v11, v14
    vf.mul       v11, v15, v25
    vf.add       v14, v6, v11
    v.st.w       [s29, #0], v14
    a.vread      v6, a3, s25
    s.movz       s25, #3
    v.ld.w       v11, [s26, #0]
    s.addi       s26, s32, #6336
    vf.mul       v14, v11, v13
    vf.mul       v11, v14, v25
    vf.add       v13, v6, v11
    v.st.w       [s27, #0], v13
    a.vread      v6, a3, s24
    v.extract    s24, v0, #3
    v.splat      v11, s24
    s.addi       s24, s29, #192
    s.movz       s27, #4
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #6400
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v25
    vf.add       v13, v6, v12
    v.st.w       [s28, #0], v13
    a.vread      v6, a3, s25
    v.extract    s25, v0, #4
    v.splat      v12, s25
    s.addi       s25, s29, #256
    s.movz       s28, #5
    v.ld.w       v13, [s26, #0]
    s.addi       s26, s32, #6464
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v25
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a3, s27
    v.extract    s24, v0, #5
    v.splat      v11, s24
    s.addi       s24, s29, #320
    s.movz       s27, #6
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #6528
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v25
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a3, s28
    v.extract    s25, v0, #6
    v.splat      v12, s25
    s.addi       s25, s29, #384
    s.movz       s28, #7
    v.ld.w       v13, [s26, #0]
    s.addi       s26, s32, #6592
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v25
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a3, s27
    v.extract    s24, v0, #7
    v.splat      v11, s24
    s.addi       s24, s29, #448
    s.movz       s27, #8
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #6656
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v25
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a3, s28
    v.extract    s25, v0, #8
    v.splat      v12, s25
    s.addi       s25, s29, #512
    s.movz       s28, #9
    v.ld.w       v13, [s26, #0]
    s.addi       s26, s32, #6720
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v25
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a3, s27
    v.extract    s24, v0, #9
    v.splat      v11, s24
    s.addi       s24, s29, #576
    s.movz       s27, #10
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #6784
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v25
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a3, s28
    v.extract    s25, v0, #10
    v.splat      v12, s25
    s.addi       s25, s29, #640
    s.movz       s28, #11
    v.ld.w       v13, [s26, #0]
    s.addi       s26, s32, #6848
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v25
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a3, s27
    v.extract    s24, v0, #11
    v.splat      v11, s24
    s.addi       s24, s29, #704
    s.movz       s27, #12
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #6912
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v25
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a3, s28
    v.extract    s25, v0, #12
    v.splat      v12, s25
    s.addi       s25, s29, #768
    s.movz       s28, #13
    v.ld.w       v13, [s26, #0]
    s.addi       s26, s32, #6976
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v25
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a3, s27
    v.extract    s24, v0, #13
    v.splat      v11, s24
    s.addi       s24, s29, #832
    s.movz       s27, #14
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #7040
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v25
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a3, s28
    v.extract    s25, v0, #14
    v.splat      v12, s25
    s.addi       s25, s29, #896
    s.movz       s28, #15
    s.addi       s31, s29, #960
    v.ld.w       v13, [s26, #0]
    s.addi       s26, s32, #7104
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v25
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a3, s27
    v.extract    s24, v0, #15
    v.splat      v11, s24
    s.movz       s24, #0
    s.addi       s27, s32, #7168
    v.ld.w       v13, [s30, #0]
    v.extract    s29, v0, #0
    v.splat      v14, s29
    s.addi       s29, s32, #15360
    vf.mul       v15, v13, v12
    vf.mul       v12, v15, v25
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a3, s28
    s.movz       s25, #1
    s.addi       s28, s32, #7232
    v.ld.w       v12, [s26, #0]
    v.extract    s26, v0, #1
    v.splat      v13, s26
    s.addi       s26, s29, #64
    vf.mul       v15, v12, v11
    vf.mul       v11, v15, v25
    vf.add       v12, v6, v11
    v.st.w       [s31, #0], v12
    fence.acq_rel.device
    a.vread      v6, a4, s24
    s.movz       s24, #2
    s.addi       s30, s32, #7296
    v.ld.w       v11, [s27, #0]
    v.extract    s27, v0, #2
    v.splat      v12, s27
    s.addi       s27, s29, #128
    vf.mul       v15, v11, v14
    vf.mul       v11, v15, v18
    vf.add       v14, v6, v11
    v.st.w       [s29, #0], v14
    a.vread      v6, a4, s25
    s.movz       s25, #3
    v.ld.w       v11, [s28, #0]
    s.addi       s28, s32, #7360
    vf.mul       v14, v11, v13
    vf.mul       v11, v14, v18
    vf.add       v13, v6, v11
    v.st.w       [s26, #0], v13
    a.vread      v6, a4, s24
    v.extract    s24, v0, #3
    v.splat      v11, s24
    s.addi       s24, s29, #192
    s.movz       s26, #4
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #7424
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v6, v12
    v.st.w       [s27, #0], v13
    a.vread      v6, a4, s25
    v.extract    s25, v0, #4
    v.splat      v12, s25
    s.addi       s25, s29, #256
    s.movz       s27, #5
    v.ld.w       v13, [s28, #0]
    s.addi       s28, s32, #7488
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v18
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a4, s26
    v.extract    s24, v0, #5
    v.splat      v11, s24
    s.addi       s24, s29, #320
    s.movz       s26, #6
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #7552
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a4, s27
    v.extract    s25, v0, #6
    v.splat      v12, s25
    s.addi       s25, s29, #384
    s.movz       s27, #7
    v.ld.w       v13, [s28, #0]
    s.addi       s28, s32, #7616
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v18
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a4, s26
    v.extract    s24, v0, #7
    v.splat      v11, s24
    s.addi       s24, s29, #448
    s.movz       s26, #8
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #7680
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a4, s27
    v.extract    s25, v0, #8
    v.splat      v12, s25
    s.addi       s25, s29, #512
    s.movz       s27, #9
    v.ld.w       v13, [s28, #0]
    s.addi       s28, s32, #7744
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v18
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a4, s26
    v.extract    s24, v0, #9
    v.splat      v11, s24
    s.addi       s24, s29, #576
    s.movz       s26, #10
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #7808
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a4, s27
    v.extract    s25, v0, #10
    v.splat      v12, s25
    s.addi       s25, s29, #640
    s.movz       s27, #11
    v.ld.w       v13, [s28, #0]
    s.addi       s28, s32, #7872
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v18
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a4, s26
    v.extract    s24, v0, #11
    v.splat      v11, s24
    s.addi       s24, s29, #704
    s.movz       s26, #12
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #7936
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a4, s27
    v.extract    s25, v0, #12
    v.splat      v12, s25
    s.addi       s25, s29, #768
    s.movz       s27, #13
    v.ld.w       v13, [s28, #0]
    s.addi       s28, s32, #8000
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v18
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a4, s26
    v.extract    s24, v0, #13
    v.splat      v11, s24
    s.addi       s24, s29, #832
    s.movz       s26, #14
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #8064
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a4, s27
    v.extract    s25, v0, #14
    v.splat      v12, s25
    s.addi       s25, s29, #896
    s.movz       s27, #15
    s.addi       s31, s29, #960
    v.ld.w       v13, [s28, #0]
    s.addi       s28, s32, #8128
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v18
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a4, s26
    v.extract    s24, v0, #15
    v.splat      v11, s24
    s.movz       s24, #0
    s.addi       s26, s32, #8192
    v.ld.w       v13, [s30, #0]
    v.extract    s29, v0, #0
    v.splat      v14, s29
    s.addi       s29, s32, #16384
    vf.mul       v15, v13, v12
    vf.mul       v12, v15, v18
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a4, s27
    s.movz       s25, #1
    s.addi       s27, s32, #8256
    v.ld.w       v12, [s28, #0]
    v.extract    s28, v0, #1
    v.splat      v13, s28
    s.addi       s28, s29, #64
    vf.mul       v15, v12, v11
    vf.mul       v11, v15, v18
    vf.add       v12, v6, v11
    v.st.w       [s31, #0], v12
    fence.acq_rel.device
    a.vread      v6, a5, s24
    s.movz       s24, #2
    s.addi       s30, s32, #8320
    v.ld.w       v11, [s26, #0]
    v.extract    s26, v0, #2
    v.splat      v12, s26
    s.addi       s26, s29, #128
    vf.mul       v15, v11, v14
    vf.mul       v11, v15, v19
    vf.add       v14, v6, v11
    v.st.w       [s29, #0], v14
    a.vread      v6, a5, s25
    s.movz       s25, #3
    v.ld.w       v11, [s27, #0]
    s.addi       s27, s32, #8384
    vf.mul       v14, v11, v13
    vf.mul       v11, v14, v19
    vf.add       v13, v6, v11
    v.st.w       [s28, #0], v13
    a.vread      v6, a5, s24
    v.extract    s24, v0, #3
    v.splat      v11, s24
    s.addi       s24, s29, #192
    s.movz       s28, #4
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #8448
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v19
    vf.add       v13, v6, v12
    v.st.w       [s26, #0], v13
    a.vread      v6, a5, s25
    v.extract    s25, v0, #4
    v.splat      v12, s25
    s.addi       s25, s29, #256
    s.movz       s26, #5
    v.ld.w       v13, [s27, #0]
    s.addi       s27, s32, #8512
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v19
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a5, s28
    v.extract    s24, v0, #5
    v.splat      v11, s24
    s.addi       s24, s29, #320
    s.movz       s28, #6
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #8576
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v19
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a5, s26
    v.extract    s25, v0, #6
    v.splat      v12, s25
    s.addi       s25, s29, #384
    s.movz       s26, #7
    v.ld.w       v13, [s27, #0]
    s.addi       s27, s32, #8640
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v19
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a5, s28
    v.extract    s24, v0, #7
    v.splat      v11, s24
    s.addi       s24, s29, #448
    s.movz       s28, #8
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #8704
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v19
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a5, s26
    v.extract    s25, v0, #8
    v.splat      v12, s25
    s.addi       s25, s29, #512
    s.movz       s26, #9
    v.ld.w       v13, [s27, #0]
    s.addi       s27, s32, #8768
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v19
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a5, s28
    v.extract    s24, v0, #9
    v.splat      v11, s24
    s.addi       s24, s29, #576
    s.movz       s28, #10
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #8832
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v19
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a5, s26
    v.extract    s25, v0, #10
    v.splat      v12, s25
    s.addi       s25, s29, #640
    s.movz       s26, #11
    v.ld.w       v13, [s27, #0]
    s.addi       s27, s32, #8896
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v19
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a5, s28
    v.extract    s24, v0, #11
    v.splat      v11, s24
    s.addi       s24, s29, #704
    s.movz       s28, #12
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #8960
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v19
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a5, s26
    v.extract    s25, v0, #12
    v.splat      v12, s25
    s.addi       s25, s29, #768
    s.movz       s26, #13
    v.ld.w       v13, [s27, #0]
    s.addi       s27, s32, #9024
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v19
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a5, s28
    v.extract    s24, v0, #13
    v.splat      v11, s24
    s.addi       s24, s29, #832
    s.movz       s28, #14
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #9088
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v19
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a5, s26
    v.extract    s25, v0, #14
    v.splat      v12, s25
    s.addi       s25, s29, #896
    s.movz       s26, #15
    s.addi       s31, s29, #960
    v.ld.w       v13, [s27, #0]
    s.addi       s27, s32, #9152
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v19
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a5, s28
    v.extract    s24, v0, #15
    v.splat      v11, s24
    s.movz       s24, #0
    s.addi       s28, s32, #9216
    v.ld.w       v13, [s30, #0]
    v.extract    s29, v0, #0
    v.splat      v14, s29
    s.addi       s29, s32, #17408
    vf.mul       v15, v13, v12
    vf.mul       v12, v15, v19
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a5, s26
    s.movz       s25, #1
    s.addi       s26, s32, #9280
    v.ld.w       v12, [s27, #0]
    v.extract    s27, v0, #1
    v.splat      v13, s27
    s.addi       s27, s29, #64
    vf.mul       v15, v12, v11
    vf.mul       v11, v15, v19
    vf.add       v12, v6, v11
    v.st.w       [s31, #0], v12
    fence.acq_rel.device
    a.vread      v6, a6, s24
    s.movz       s24, #2
    s.addi       s30, s32, #9344
    v.ld.w       v11, [s28, #0]
    v.extract    s28, v0, #2
    v.splat      v12, s28
    s.addi       s28, s29, #128
    vf.mul       v15, v11, v14
    vf.mul       v11, v15, v27
    vf.add       v14, v6, v11
    v.st.w       [s29, #0], v14
    a.vread      v6, a6, s25
    s.movz       s25, #3
    v.ld.w       v11, [s26, #0]
    s.addi       s26, s32, #9408
    vf.mul       v14, v11, v13
    vf.mul       v11, v14, v27
    vf.add       v13, v6, v11
    v.st.w       [s27, #0], v13
    a.vread      v6, a6, s24
    v.extract    s24, v0, #3
    v.splat      v11, s24
    s.addi       s24, s29, #192
    s.movz       s27, #4
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #9472
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v27
    vf.add       v13, v6, v12
    v.st.w       [s28, #0], v13
    a.vread      v6, a6, s25
    v.extract    s25, v0, #4
    v.splat      v12, s25
    s.addi       s25, s29, #256
    s.movz       s28, #5
    v.ld.w       v13, [s26, #0]
    s.addi       s26, s32, #9536
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v27
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a6, s27
    v.extract    s24, v0, #5
    v.splat      v11, s24
    s.addi       s24, s29, #320
    s.movz       s27, #6
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #9600
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v27
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a6, s28
    v.extract    s25, v0, #6
    v.splat      v12, s25
    s.addi       s25, s29, #384
    s.movz       s28, #7
    v.ld.w       v13, [s26, #0]
    s.addi       s26, s32, #9664
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v27
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a6, s27
    v.extract    s24, v0, #7
    v.splat      v11, s24
    s.addi       s24, s29, #448
    s.movz       s27, #8
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #9728
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v27
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a6, s28
    v.extract    s25, v0, #8
    v.splat      v12, s25
    s.addi       s25, s29, #512
    s.movz       s28, #9
    v.ld.w       v13, [s26, #0]
    s.addi       s26, s32, #9792
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v27
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a6, s27
    v.extract    s24, v0, #9
    v.splat      v11, s24
    s.addi       s24, s29, #576
    s.movz       s27, #10
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #9856
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v27
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a6, s28
    v.extract    s25, v0, #10
    v.splat      v12, s25
    s.addi       s25, s29, #640
    s.movz       s28, #11
    v.ld.w       v13, [s26, #0]
    s.addi       s26, s32, #9920
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v27
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a6, s27
    v.extract    s24, v0, #11
    v.splat      v11, s24
    s.addi       s24, s29, #704
    s.movz       s27, #12
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #9984
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v27
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a6, s28
    v.extract    s25, v0, #12
    v.splat      v12, s25
    s.addi       s25, s29, #768
    s.movz       s28, #13
    v.ld.w       v13, [s26, #0]
    s.addi       s26, s32, #10048
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v27
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a6, s27
    v.extract    s24, v0, #13
    v.splat      v11, s24
    s.addi       s24, s29, #832
    s.movz       s27, #14
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #10112
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v27
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a6, s28
    v.extract    s25, v0, #14
    v.splat      v12, s25
    s.addi       s25, s29, #896
    s.movz       s28, #15
    s.addi       s31, s29, #960
    v.ld.w       v13, [s26, #0]
    s.addi       s26, s32, #10176
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v27
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a6, s27
    v.extract    s24, v0, #15
    v.splat      v11, s24
    s.movz       s24, #0
    s.addi       s27, s32, #10240
    v.ld.w       v13, [s30, #0]
    v.extract    s29, v0, #0
    v.splat      v14, s29
    s.addi       s29, s32, #18432
    vf.mul       v15, v13, v12
    vf.mul       v12, v15, v27
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a6, s28
    s.movz       s25, #1
    s.addi       s28, s32, #10304
    v.ld.w       v12, [s26, #0]
    v.extract    s26, v0, #1
    v.splat      v13, s26
    s.addi       s26, s29, #64
    vf.mul       v15, v12, v11
    vf.mul       v11, v15, v27
    vf.add       v12, v6, v11
    v.st.w       [s31, #0], v12
    fence.acq_rel.device
    a.vread      v6, a7, s24
    s.movz       s24, #2
    s.addi       s30, s32, #10368
    v.ld.w       v11, [s27, #0]
    v.extract    s27, v0, #2
    v.splat      v12, s27
    s.addi       s27, s29, #128
    vf.mul       v15, v11, v14
    vf.mul       v11, v15, v29
    vf.add       v14, v6, v11
    v.st.w       [s29, #0], v14
    a.vread      v6, a7, s25
    s.movz       s25, #3
    v.ld.w       v11, [s28, #0]
    s.addi       s28, s32, #10432
    vf.mul       v14, v11, v13
    vf.mul       v11, v14, v29
    vf.add       v13, v6, v11
    v.st.w       [s26, #0], v13
    a.vread      v6, a7, s24
    v.extract    s24, v0, #3
    v.splat      v11, s24
    s.addi       s24, s29, #192
    s.movz       s26, #4
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #10496
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v29
    vf.add       v13, v6, v12
    v.st.w       [s27, #0], v13
    a.vread      v6, a7, s25
    v.extract    s25, v0, #4
    v.splat      v12, s25
    s.addi       s25, s29, #256
    s.movz       s27, #5
    v.ld.w       v13, [s28, #0]
    s.addi       s28, s32, #10560
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v29
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a7, s26
    v.extract    s24, v0, #5
    v.splat      v11, s24
    s.addi       s24, s29, #320
    s.movz       s26, #6
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #10624
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v29
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a7, s27
    v.extract    s25, v0, #6
    v.splat      v12, s25
    s.addi       s25, s29, #384
    s.movz       s27, #7
    v.ld.w       v13, [s28, #0]
    s.addi       s28, s32, #10688
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v29
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a7, s26
    v.extract    s24, v0, #7
    v.splat      v11, s24
    s.addi       s24, s29, #448
    s.movz       s26, #8
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #10752
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v29
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a7, s27
    v.extract    s25, v0, #8
    v.splat      v12, s25
    s.addi       s25, s29, #512
    s.movz       s27, #9
    v.ld.w       v13, [s28, #0]
    s.addi       s28, s32, #10816
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v29
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a7, s26
    v.extract    s24, v0, #9
    v.splat      v11, s24
    s.addi       s24, s29, #576
    s.movz       s26, #10
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #10880
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v29
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a7, s27
    v.extract    s25, v0, #10
    v.splat      v12, s25
    s.addi       s25, s29, #640
    s.movz       s27, #11
    v.ld.w       v13, [s28, #0]
    s.addi       s28, s32, #10944
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v29
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a7, s26
    v.extract    s24, v0, #11
    v.splat      v11, s24
    s.addi       s24, s29, #704
    s.movz       s26, #12
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #11008
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v29
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a7, s27
    v.extract    s25, v0, #12
    v.splat      v12, s25
    s.addi       s25, s29, #768
    s.movz       s27, #13
    v.ld.w       v13, [s28, #0]
    s.addi       s28, s32, #11072
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v29
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a7, s26
    v.extract    s24, v0, #13
    v.splat      v11, s24
    s.addi       s24, s29, #832
    s.movz       s26, #14
    v.ld.w       v13, [s30, #0]
    s.addi       s30, s32, #11136
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v29
    vf.add       v13, v6, v12
    v.st.w       [s25, #0], v13
    a.vread      v6, a7, s27
    v.extract    s25, v0, #14
    v.splat      v12, s25
    s.addi       s25, s29, #896
    s.movz       s27, #15
    s.addi       s31, s29, #960
    v.ld.w       v13, [s28, #0]
    s.addi       s28, s32, #11200
    vf.mul       v14, v13, v11
    vf.mul       v11, v14, v29
    vf.add       v13, v6, v11
    v.st.w       [s24, #0], v13
    a.vread      v6, a7, s26
    v.extract    s24, v0, #15
    v.splat      v0, s24
    s.addi       s24, s21, #128
    s.addi       s26, s22, #128
    s.addi       s29, s24, #0
    s.addi       s24, s26, #0
    v.ld.w       v11, [s30, #0]
    s.addi       s26, s32, #11264
    vf.mul       v13, v11, v12
    vf.mul       v11, v13, v29
    vf.add       v12, v6, v11
    v.st.w       [s25, #0], v12
    a.vread      v6, a7, s27
    s.movz       s25, #0
    s.addi       s27, s32, #11328
    v.ld.w       v11, [s28, #0]
    s.movz       s28, #1
    vf.mul       v12, v11, v0
    vf.mul       v0, v12, v29
    vf.add       v11, v6, v0
    v.st.w       [s31, #0], v11
    fence.acq_rel.device
    s.mov        s21, s29
    s.mov        s22, s24
    s.addi       s24, s32, #11392
    s.movz       s29, #2
    s.addi       s30, s32, #11456
    s.movz       s31, #3
    s.addi       s33, s32, #11520
    v.ld.w       v0, [s26, #0]
    s.movz       s26, #4
    a.vwrite     a0, s25, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s25, s32, #11584
    s.movz       s27, #5
    a.vwrite     a0, s28, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #11648
    s.movz       s28, #6
    a.vwrite     a0, s29, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s29, s32, #11712
    s.movz       s30, #7
    a.vwrite     a0, s31, v0
    v.ld.w       v0, [s33, #0]
    s.addi       s31, s32, #11776
    s.movz       s33, #8
    a.vwrite     a0, s26, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #11840
    s.movz       s26, #9
    a.vwrite     a0, s27, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #11904
    s.movz       s27, #10
    a.vwrite     a0, s28, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s28, s32, #11968
    s.movz       s29, #11
    a.vwrite     a0, s30, v0
    v.ld.w       v0, [s31, #0]
    s.addi       s30, s32, #12032
    s.movz       s31, #12
    a.vwrite     a0, s33, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #12096
    s.movz       s33, #13
    a.vwrite     a0, s26, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #12160
    s.movz       s26, #14
    a.vwrite     a0, s27, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s27, s32, #12224
    s.movz       s28, #15
    a.vwrite     a0, s29, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s29, s32, #12288
    s.movz       s30, #0
    a.vwrite     a0, s31, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #12352
    s.movz       s31, #1
    a.vwrite     a0, s33, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #12416
    s.movz       s33, #2
    a.vwrite     a0, s26, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s26, s32, #12480
    s.movz       s27, #3
    a.vwrite     a0, s28, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s28, s32, #12544
    s.movz       s29, #4
    a.vwrite     a1, s30, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #12608
    s.movz       s30, #5
    a.vwrite     a1, s31, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #12672
    s.movz       s31, #6
    a.vwrite     a1, s33, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #12736
    s.movz       s33, #7
    a.vwrite     a1, s27, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s27, s32, #12800
    s.movz       s28, #8
    a.vwrite     a1, s29, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #12864
    s.movz       s29, #9
    a.vwrite     a1, s30, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #12928
    s.movz       s30, #10
    a.vwrite     a1, s31, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #12992
    s.movz       s31, #11
    a.vwrite     a1, s33, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #13056
    s.movz       s33, #12
    a.vwrite     a1, s28, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #13120
    s.movz       s28, #13
    a.vwrite     a1, s29, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #13184
    s.movz       s29, #14
    a.vwrite     a1, s30, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #13248
    s.movz       s30, #15
    a.vwrite     a1, s31, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #13312
    s.movz       s31, #0
    a.vwrite     a1, s33, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #13376
    s.movz       s33, #1
    a.vwrite     a1, s28, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #13440
    s.movz       s28, #2
    a.vwrite     a1, s29, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #13504
    s.movz       s29, #3
    a.vwrite     a1, s30, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #13568
    s.movz       s30, #4
    a.vwrite     a2, s31, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #13632
    s.movz       s31, #5
    a.vwrite     a2, s33, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #13696
    s.movz       s33, #6
    a.vwrite     a2, s28, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #13760
    s.movz       s28, #7
    a.vwrite     a2, s29, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #13824
    s.movz       s29, #8
    a.vwrite     a2, s30, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #13888
    s.movz       s30, #9
    a.vwrite     a2, s31, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #13952
    s.movz       s31, #10
    a.vwrite     a2, s33, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #14016
    s.movz       s33, #11
    a.vwrite     a2, s28, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #14080
    s.movz       s28, #12
    a.vwrite     a2, s29, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #14144
    s.movz       s29, #13
    a.vwrite     a2, s30, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #14208
    s.movz       s30, #14
    a.vwrite     a2, s31, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #14272
    s.movz       s31, #15
    a.vwrite     a2, s33, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #14336
    s.movz       s33, #0
    a.vwrite     a2, s28, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #14400
    s.movz       s28, #1
    a.vwrite     a2, s29, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #14464
    s.movz       s29, #2
    a.vwrite     a2, s30, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #14528
    s.movz       s30, #3
    a.vwrite     a2, s31, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #14592
    s.movz       s31, #4
    a.vwrite     a3, s33, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #14656
    s.movz       s33, #5
    a.vwrite     a3, s28, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #14720
    s.movz       s28, #6
    a.vwrite     a3, s29, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #14784
    s.movz       s29, #7
    a.vwrite     a3, s30, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #14848
    s.movz       s30, #8
    a.vwrite     a3, s31, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #14912
    s.movz       s31, #9
    a.vwrite     a3, s33, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #14976
    s.movz       s33, #10
    a.vwrite     a3, s28, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #15040
    s.movz       s28, #11
    a.vwrite     a3, s29, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #15104
    s.movz       s29, #12
    a.vwrite     a3, s30, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #15168
    s.movz       s30, #13
    a.vwrite     a3, s31, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #15232
    s.movz       s31, #14
    a.vwrite     a3, s33, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #15296
    s.movz       s33, #15
    a.vwrite     a3, s28, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #15360
    s.movz       s28, #0
    a.vwrite     a3, s29, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #15424
    s.movz       s29, #1
    a.vwrite     a3, s30, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #15488
    s.movz       s30, #2
    a.vwrite     a3, s31, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #15552
    s.movz       s31, #3
    a.vwrite     a3, s33, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #15616
    s.movz       s33, #4
    a.vwrite     a4, s28, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #15680
    s.movz       s28, #5
    a.vwrite     a4, s29, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #15744
    s.movz       s29, #6
    a.vwrite     a4, s30, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #15808
    s.movz       s30, #7
    a.vwrite     a4, s31, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #15872
    s.movz       s31, #8
    a.vwrite     a4, s33, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #15936
    s.movz       s33, #9
    a.vwrite     a4, s28, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #16000
    s.movz       s28, #10
    a.vwrite     a4, s29, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #16064
    s.movz       s29, #11
    a.vwrite     a4, s30, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #16128
    s.movz       s30, #12
    a.vwrite     a4, s31, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #16192
    s.movz       s31, #13
    a.vwrite     a4, s33, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #16256
    s.movz       s33, #14
    a.vwrite     a4, s28, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #16320
    s.movz       s28, #15
    a.vwrite     a4, s29, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #16384
    s.movz       s29, #0
    a.vwrite     a4, s30, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #16448
    s.movz       s30, #1
    a.vwrite     a4, s31, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #16512
    s.movz       s31, #2
    a.vwrite     a4, s33, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #16576
    s.movz       s33, #3
    a.vwrite     a4, s28, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #16640
    s.movz       s28, #4
    a.vwrite     a5, s29, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #16704
    s.movz       s29, #5
    a.vwrite     a5, s30, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #16768
    s.movz       s30, #6
    a.vwrite     a5, s31, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #16832
    s.movz       s31, #7
    a.vwrite     a5, s33, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #16896
    s.movz       s33, #8
    a.vwrite     a5, s28, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #16960
    s.movz       s28, #9
    a.vwrite     a5, s29, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #17024
    s.movz       s29, #10
    a.vwrite     a5, s30, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #17088
    s.movz       s30, #11
    a.vwrite     a5, s31, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #17152
    s.movz       s31, #12
    a.vwrite     a5, s33, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #17216
    s.movz       s33, #13
    a.vwrite     a5, s28, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #17280
    s.movz       s28, #14
    a.vwrite     a5, s29, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #17344
    s.movz       s29, #15
    a.vwrite     a5, s30, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #17408
    s.movz       s30, #0
    a.vwrite     a5, s31, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #17472
    s.movz       s31, #1
    a.vwrite     a5, s33, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #17536
    s.movz       s33, #2
    a.vwrite     a5, s28, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #17600
    s.movz       s28, #3
    a.vwrite     a5, s29, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #17664
    s.movz       s29, #4
    a.vwrite     a6, s30, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #17728
    s.movz       s30, #5
    a.vwrite     a6, s31, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #17792
    s.movz       s31, #6
    a.vwrite     a6, s33, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #17856
    s.movz       s33, #7
    a.vwrite     a6, s28, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #17920
    s.movz       s28, #8
    a.vwrite     a6, s29, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #17984
    s.movz       s29, #9
    a.vwrite     a6, s30, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #18048
    s.movz       s30, #10
    a.vwrite     a6, s31, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #18112
    s.movz       s31, #11
    a.vwrite     a6, s33, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #18176
    s.movz       s33, #12
    a.vwrite     a6, s28, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #18240
    s.movz       s28, #13
    a.vwrite     a6, s29, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #18304
    s.movz       s29, #14
    a.vwrite     a6, s30, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #18368
    s.movz       s30, #15
    a.vwrite     a6, s31, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #18432
    s.movz       s31, #0
    a.vwrite     a6, s33, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #18496
    s.movz       s33, #1
    a.vwrite     a6, s28, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #18560
    s.movz       s28, #2
    a.vwrite     a6, s29, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #18624
    s.movz       s29, #3
    a.vwrite     a6, s30, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #18688
    s.movz       s30, #4
    a.vwrite     a7, s31, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #18752
    s.movz       s31, #5
    a.vwrite     a7, s33, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #18816
    s.movz       s33, #6
    a.vwrite     a7, s28, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #18880
    s.movz       s28, #7
    a.vwrite     a7, s29, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #18944
    s.movz       s29, #8
    s.add        s34, s19, s18
    a.vwrite     a7, s30, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #19008
    s.movz       s30, #9
    a.vwrite     a7, s31, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #19072
    s.movz       s31, #10
    a.vwrite     a7, s33, v0
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s32, #19136
    s.movz       s33, #11
    a.vwrite     a7, s28, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s32, #19200
    s.movz       s28, #12
    a.vwrite     a7, s29, v0
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s32, #19264
    s.movz       s29, #13
    a.vwrite     a7, s30, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s32, #19328
    s.movz       s30, #14
    s.addi       s35, s32, #19392
    a.vwrite     a7, s31, v0
    v.ld.w       v0, [s26, #0]
    s.movz       s26, #15
    s.movz       s31, #1
    a.vwrite     a7, s33, v0
    v.ld.w       v0, [s27, #0]
    a.vwrite     a7, s28, v0
    v.ld.w       v0, [s25, #0]
    a.vwrite     a7, s29, v0
    v.ld.w       v0, [s24, #0]
    a.vwrite     a7, s30, v0
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s26, v0
    s.mov        s19, s34
    br.nz        s31, for_2
endfor_3:
    s.movz       s1, #0
    s.muli       s2, s14, #2                     // a runtime tile origin, x2
    s.movz       s3, #0
    s.add        s5, s1, s14                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    s.muli       s6, s8, #512                    // a runtime tile origin, x512
    s.add        s7, s3, s8                      // the tile origin
    s.movz       s3, #7
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s5
    s.movz       s5, #256
    a.vread      v2, a0, s1
    v.splat      v3, s7
    v.splat      v4, s3
    v.add        v5, v0, v1
    v.splat      v1, s5
    s.add        s1, s4, s2                      // the tile origin
    vf.cvt.f32.bf16 v6, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s2, s1, s6                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v6
    a.vread      v1, a0, s1
    v.splat      v2, s3
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #512                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s6, s7, #2
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a0, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #1024                   // row 2
    p.and        p3, p1, p2
    s.addi       s3, s14, #16
    s.movz       s6, #3
    @p3 v.st.h       [s1, #0], v3
    s.addi       s1, s14, #32
    a.vread      v1, a0, s6
    s.addi       s6, s14, #48
    vf.cvt.f32.bf16 v2, v1
    s.addi       s9, s14, #64
    s.addi       s10, s2, #1536                  // row 3
    s.addi       s11, s14, #80
    s.addi       s12, s7, #3
    s.addi       s13, s14, #96
    v.splat      v1, s12
    s.addi       s12, s14, #112
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.movz       s14, #4
    s.addi       s15, s7, #4
    @p3 v.st.h       [s10, #0], v2
    a.vread      v1, a0, s14
    v.splat      v2, s15
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s10, s2, #2048                  // row 4
    p.and        p3, p1, p2
    s.movz       s14, #5
    s.addi       s15, s7, #5
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s14
    v.splat      v2, s15
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s10, s2, #2560                  // row 5
    p.and        p3, p1, p2
    s.movz       s14, #6
    s.addi       s15, s7, #6
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s14
    v.splat      v2, s15
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s10, s2, #3072                  // row 6
    p.and        p3, p1, p2
    s.movz       s14, #7
    s.addi       s15, s7, #7
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s14
    v.splat      v2, s15
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s10, s2, #3584                  // row 7
    p.and        p3, p1, p2
    s.movz       s14, #8
    s.addi       s15, s7, #8
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s14
    v.splat      v2, s15
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s10, s2, #4096                  // row 8
    p.and        p3, p1, p2
    s.movz       s14, #9
    s.addi       s15, s7, #9
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s14
    v.splat      v2, s15
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s10, s2, #4608                  // row 9
    p.and        p3, p1, p2
    s.movz       s14, #10
    s.addi       s15, s7, #10
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s14
    v.splat      v2, s15
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s10, s2, #5120                  // row 10
    p.and        p3, p1, p2
    s.movz       s14, #11
    s.addi       s15, s7, #11
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s14
    v.splat      v2, s15
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s10, s2, #5632                  // row 11
    p.and        p3, p1, p2
    s.movz       s14, #12
    s.addi       s15, s7, #12
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s14
    v.splat      v2, s15
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s10, s2, #6144                  // row 12
    p.and        p3, p1, p2
    s.movz       s14, #13
    s.addi       s15, s7, #13
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s14
    v.splat      v2, s15
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s10, s2, #6656                  // row 13
    p.and        p3, p1, p2
    s.movz       s14, #14
    s.addi       s15, s7, #14
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s14
    v.splat      v2, s15
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s10, s2, #7168                  // row 14
    p.and        p3, p1, p2
    s.movz       s14, #15
    s.addi       s15, s7, #15
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s14
    v.splat      v2, s15
    s.movz       s10, #0
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s14, s3, #2                     // a runtime tile origin, x2
    s.add        s15, s10, s3                    // the tile origin
    s.addi       s3, s2, #7680                   // row 15
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.muli       s10, s8, #512                   // a runtime tile origin, x512
    v.splat      v1, s15
    @p3 v.st.h       [s3, #0], v3
    a.vread      v2, a1, s2
    v.splat      v3, s7
    v.add        v5, v0, v1
    v.splat      v1, s5
    s.add        s2, s4, s14                     // the tile origin
    vf.cvt.f32.bf16 v6, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s3, s2, s10                     // the tile origin
    p.and        p3, p1, p2
    s.movz       s2, #1
    s.addi       s10, s7, #1
    @p3 v.st.h       [s3, #0], v6
    a.vread      v1, a1, s2
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #512                    // row 1
    p.and        p3, p1, p2
    s.movz       s10, #2
    s.addi       s14, s7, #2
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #1024                   // row 2
    p.and        p3, p1, p2
    s.movz       s10, #3
    s.addi       s14, s7, #3
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #1536                   // row 3
    p.and        p3, p1, p2
    s.movz       s10, #4
    s.addi       s14, s7, #4
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #2048                   // row 4
    p.and        p3, p1, p2
    s.movz       s10, #5
    s.addi       s14, s7, #5
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #2560                   // row 5
    p.and        p3, p1, p2
    s.movz       s10, #6
    s.addi       s14, s7, #6
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #3072                   // row 6
    p.and        p3, p1, p2
    s.movz       s10, #7
    s.addi       s14, s7, #7
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #3584                   // row 7
    p.and        p3, p1, p2
    s.movz       s10, #8
    s.addi       s14, s7, #8
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #4096                   // row 8
    p.and        p3, p1, p2
    s.movz       s10, #9
    s.addi       s14, s7, #9
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #4608                   // row 9
    p.and        p3, p1, p2
    s.movz       s10, #10
    s.addi       s14, s7, #10
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #5120                   // row 10
    p.and        p3, p1, p2
    s.movz       s10, #11
    s.addi       s14, s7, #11
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #5632                   // row 11
    p.and        p3, p1, p2
    s.movz       s10, #12
    s.addi       s14, s7, #12
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #6144                   // row 12
    p.and        p3, p1, p2
    s.movz       s10, #13
    s.addi       s14, s7, #13
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #6656                   // row 13
    p.and        p3, p1, p2
    s.movz       s10, #14
    s.addi       s14, s7, #14
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s2, s3, #7168                   // row 14
    p.and        p3, p1, p2
    s.movz       s10, #15
    s.addi       s14, s7, #15
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a1, s10
    v.splat      v2, s14
    s.movz       s2, #0
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s10, s1, #2                     // a runtime tile origin, x2
    s.add        s14, s2, s1                     // the tile origin
    s.addi       s1, s3, #7680                   // row 15
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.muli       s3, s8, #512                    // a runtime tile origin, x512
    v.splat      v1, s14
    @p3 v.st.h       [s1, #0], v3
    a.vread      v2, a2, s2
    v.splat      v3, s7
    v.add        v5, v0, v1
    v.splat      v1, s5
    s.add        s1, s4, s10                     // the tile origin
    vf.cvt.f32.bf16 v6, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s2, s1, s3                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v6
    a.vread      v1, a2, s1
    v.splat      v2, s3
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #512                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s10, s7, #2
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #1024                   // row 2
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s10, s7, #3
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #1536                   // row 3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.addi       s10, s7, #4
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #2048                   // row 4
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.addi       s10, s7, #5
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #2560                   // row 5
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.addi       s10, s7, #6
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #3072                   // row 6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.addi       s10, s7, #7
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #3584                   // row 7
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.addi       s10, s7, #8
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #4096                   // row 8
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.addi       s10, s7, #9
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #4608                   // row 9
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.addi       s10, s7, #10
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #5120                   // row 10
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s10, s7, #11
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #5632                   // row 11
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.addi       s10, s7, #12
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #6144                   // row 12
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.addi       s10, s7, #13
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #6656                   // row 13
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.addi       s10, s7, #14
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #7168                   // row 14
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.addi       s10, s7, #15
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a2, s3
    v.splat      v2, s10
    s.movz       s1, #0
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s3, s6, #2                      // a runtime tile origin, x2
    s.add        s10, s1, s6                     // the tile origin
    s.addi       s1, s2, #7680                   // row 15
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.muli       s6, s8, #512                    // a runtime tile origin, x512
    v.splat      v1, s10
    @p3 v.st.h       [s1, #0], v3
    a.vread      v2, a3, s2
    v.splat      v3, s7
    v.add        v5, v0, v1
    v.splat      v1, s5
    s.add        s1, s4, s3                      // the tile origin
    vf.cvt.f32.bf16 v6, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s2, s1, s6                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v6
    a.vread      v1, a3, s1
    v.splat      v2, s3
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #512                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s6, s7, #2
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #1024                   // row 2
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s6, s7, #3
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #1536                   // row 3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.addi       s6, s7, #4
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #2048                   // row 4
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.addi       s6, s7, #5
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #2560                   // row 5
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.addi       s6, s7, #6
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #3072                   // row 6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.addi       s6, s7, #7
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #3584                   // row 7
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.addi       s6, s7, #8
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #4096                   // row 8
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.addi       s6, s7, #9
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #4608                   // row 9
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.addi       s6, s7, #10
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #5120                   // row 10
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s6, s7, #11
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #5632                   // row 11
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.addi       s6, s7, #12
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #6144                   // row 12
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.addi       s6, s7, #13
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #6656                   // row 13
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.addi       s6, s7, #14
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #7168                   // row 14
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.addi       s6, s7, #15
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a3, s3
    v.splat      v2, s6
    s.movz       s1, #0
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s3, s9, #2                      // a runtime tile origin, x2
    s.add        s6, s1, s9                      // the tile origin
    s.addi       s1, s2, #7680                   // row 15
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.muli       s9, s8, #512                    // a runtime tile origin, x512
    v.splat      v1, s6
    @p3 v.st.h       [s1, #0], v3
    a.vread      v2, a4, s2
    v.splat      v3, s7
    v.add        v5, v0, v1
    v.splat      v1, s5
    s.add        s1, s4, s3                      // the tile origin
    vf.cvt.f32.bf16 v6, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s2, s1, s9                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v6
    a.vread      v1, a4, s1
    v.splat      v2, s3
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #512                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s6, s7, #2
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #1024                   // row 2
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s6, s7, #3
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #1536                   // row 3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.addi       s6, s7, #4
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #2048                   // row 4
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.addi       s6, s7, #5
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #2560                   // row 5
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.addi       s6, s7, #6
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #3072                   // row 6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.addi       s6, s7, #7
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #3584                   // row 7
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.addi       s6, s7, #8
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #4096                   // row 8
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.addi       s6, s7, #9
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #4608                   // row 9
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.addi       s6, s7, #10
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #5120                   // row 10
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s6, s7, #11
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #5632                   // row 11
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.addi       s6, s7, #12
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #6144                   // row 12
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.addi       s6, s7, #13
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #6656                   // row 13
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.addi       s6, s7, #14
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #7168                   // row 14
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.addi       s6, s7, #15
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a4, s3
    v.splat      v2, s6
    s.movz       s1, #0
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s3, s11, #2                     // a runtime tile origin, x2
    s.add        s6, s1, s11                     // the tile origin
    s.addi       s1, s2, #7680                   // row 15
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.muli       s9, s8, #512                    // a runtime tile origin, x512
    v.splat      v1, s6
    @p3 v.st.h       [s1, #0], v3
    a.vread      v2, a5, s2
    v.splat      v3, s7
    v.add        v5, v0, v1
    v.splat      v1, s5
    s.add        s1, s4, s3                      // the tile origin
    vf.cvt.f32.bf16 v6, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s2, s1, s9                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v6
    a.vread      v1, a5, s1
    v.splat      v2, s3
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #512                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s6, s7, #2
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #1024                   // row 2
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s6, s7, #3
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #1536                   // row 3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.addi       s6, s7, #4
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #2048                   // row 4
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.addi       s6, s7, #5
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #2560                   // row 5
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.addi       s6, s7, #6
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #3072                   // row 6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.addi       s6, s7, #7
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #3584                   // row 7
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.addi       s6, s7, #8
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #4096                   // row 8
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.addi       s6, s7, #9
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #4608                   // row 9
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.addi       s6, s7, #10
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #5120                   // row 10
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s6, s7, #11
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #5632                   // row 11
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.addi       s6, s7, #12
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #6144                   // row 12
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.addi       s6, s7, #13
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #6656                   // row 13
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.addi       s6, s7, #14
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #7168                   // row 14
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.addi       s6, s7, #15
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a5, s3
    v.splat      v2, s6
    s.movz       s1, #0
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s3, s13, #2                     // a runtime tile origin, x2
    s.add        s6, s1, s13                     // the tile origin
    s.addi       s1, s2, #7680                   // row 15
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.muli       s9, s8, #512                    // a runtime tile origin, x512
    v.splat      v1, s6
    @p3 v.st.h       [s1, #0], v3
    a.vread      v2, a6, s2
    v.splat      v3, s7
    v.add        v5, v0, v1
    v.splat      v1, s5
    s.add        s1, s4, s3                      // the tile origin
    vf.cvt.f32.bf16 v6, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s2, s1, s9                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v6
    a.vread      v1, a6, s1
    v.splat      v2, s3
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #512                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s6, s7, #2
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #1024                   // row 2
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s6, s7, #3
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #1536                   // row 3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.addi       s6, s7, #4
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #2048                   // row 4
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.addi       s6, s7, #5
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #2560                   // row 5
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.addi       s6, s7, #6
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #3072                   // row 6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.addi       s6, s7, #7
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #3584                   // row 7
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.addi       s6, s7, #8
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #4096                   // row 8
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.addi       s6, s7, #9
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #4608                   // row 9
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.addi       s6, s7, #10
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #5120                   // row 10
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s6, s7, #11
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #5632                   // row 11
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.addi       s6, s7, #12
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #6144                   // row 12
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.addi       s6, s7, #13
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #6656                   // row 13
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.addi       s6, s7, #14
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s1, s2, #7168                   // row 14
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.addi       s6, s7, #15
    @p3 v.st.h       [s1, #0], v3
    a.vread      v1, a6, s3
    v.splat      v2, s6
    s.movz       s1, #0
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s3, s12, #2                     // a runtime tile origin, x2
    s.add        s6, s1, s12                     // the tile origin
    s.addi       s1, s2, #7680                   // row 15
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.muli       s9, s8, #512                    // a runtime tile origin, x512
    v.splat      v1, s6
    @p3 v.st.h       [s1, #0], v3
    a.vread      v2, a7, s2
    v.splat      v3, s7
    v.add        v5, v0, v1
    v.splat      v0, s5
    s.add        s1, s4, s3                      // the tile origin
    vf.cvt.f32.bf16 v1, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s2, s1, s9                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v0, a7, s1
    v.splat      v1, s3
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #512                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s4, s7, #2
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #1024                   // row 2
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s4, s7, #3
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #1536                   // row 3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.addi       s4, s7, #4
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #2048                   // row 4
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.addi       s4, s7, #5
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #2560                   // row 5
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.addi       s4, s7, #6
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #3072                   // row 6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.addi       s4, s7, #7
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #3584                   // row 7
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.addi       s4, s7, #8
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #4096                   // row 8
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.addi       s4, s7, #9
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #4608                   // row 9
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.addi       s4, s7, #10
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #5120                   // row 10
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s4, s7, #11
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #5632                   // row 11
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.addi       s4, s7, #12
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #6144                   // row 12
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.addi       s4, s7, #13
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #6656                   // row 13
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.addi       s4, s7, #14
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #7168                   // row 14
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.addi       s4, s7, #15
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s2, #7680                   // row 15
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    exit
    exit
