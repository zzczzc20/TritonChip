# AOT ID: ['42_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/kq/ckqzkf7gn2eulxyxgoubvxppbkwklr2p4ndgnrkuez24wc6vuqfr.py
# Topologically Sorted Source Nodes: [xf, pow_1, mean], Original ATen: [aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   mean => mean
#   pow_1 => pow_1
#   xf => convert_element_type
# Graph fragment:
#   %arg0_1 : Tensor "bf16[2, 1, 4, 128][512, 512, 128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %convert_element_type : Tensor "f32[2, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[2, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[2, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   return %buf2
triton_red_fused__to_copy_mean_pow_0 = async_compile.triton('triton_red_fused__to_copy_mean_pow_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 8, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_mean_pow_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 64, 'r0_': 2048}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_mean_pow_0(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 8
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 128*x0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/bi/cbijt27frmftddy5wyxxpcxyn7ajuqgjbivnqe6ayzoimfd53lji.py
# Topologically Sorted Source Nodes: [xf, pow_1, mean, add, rsqrt, mul, xn, to_1, q, getitem_9, neg, getitem_10, rot], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add => add
#   getitem_10 => slice_18
#   getitem_9 => slice_17
#   mean => mean
#   mul => mul
#   neg => neg
#   pow_1 => pow_1
#   q => permute
#   rot => cat
#   rsqrt => rsqrt
#   to_1 => convert_element_type_1
#   xf => convert_element_type
#   xn => mul_1
# Graph fragment:
#   %arg1_1 : Tensor "f32[128][1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "bf16[2, 1, 4, 128][512, 512, 128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf2 : Tensor "f32[2, 1, 4, 1][4, 8, 1, 8]tnca:0" = PlaceHolder[target=buf2]
#   %convert_element_type : Tensor "f32[2, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[2, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[2, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add : Tensor "f32[2, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[2, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[2, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[2, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg1_1, %mul), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[2, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.bfloat16), kwargs = {})
#   %permute : Tensor "bf16[2, 4, 1, 128][512, 128, 512, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_1, [0, 2, 1, 3]), kwargs = {})
#   %slice_17 : Tensor "bf16[2, 4, 1, 64][512, 128, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "bf16[2, 4, 1, 64][256, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_17,), kwargs = {})
#   %slice_18 : Tensor "bf16[2, 4, 1, 64][512, 128, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute, 3, 0, 64), kwargs = {})
#   %cat : Tensor "bf16[2, 4, 1, 128][512, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_18], -1), kwargs = {})
#   return %neg,%buf4
triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_1 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 6688}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_1(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    tmp0 = tl.load(in_ptr0 + (64 + x0), xmask, eviction_policy='evict_last')
    tmp1 = tl.load(in_ptr1 + (64 + x0 + 128*x1), xmask).to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x1), xmask, eviction_policy='evict_last')
    tmp13 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    tmp14 = tl.load(in_ptr1 + (x0 + 128*x1), xmask).to(tl.float32)
    tmp2 = tmp1.to(tl.float32)
    tmp4 = tl.full([1], 128.0, tl.float32)
    tmp5 = (tmp3 / tmp4)
    tmp6 = tl.full([1], 1e-06, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = libdevice.rsqrt(tmp7)
    tmp9 = tmp2 * tmp8
    tmp10 = tmp0 * tmp9
    tmp11 = tmp10.to(tl.float32)
    tmp12 = -tmp11
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tmp15 * tmp8
    tmp17 = tmp13 * tmp16
    tmp18 = tmp17.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 128*x1), tmp12, xmask)
    tl.store(out_ptr1 + (x0 + 128*x1), tmp18, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/3p/c3phb3tjlxx3fyrfkvz4azmjoef2vbqyqwrqu7yqeookdlfbqzde.py
# Topologically Sorted Source Nodes: [getitem, to_2, freqs, f, getitem_2, f_1, getitem_6], Original ATen: [aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin]
# Source node to ATen node mapping:
#   f => cos
#   f_1 => sin
#   freqs => mul_2
#   getitem => unsqueeze
#   getitem_2 => select_1, slice_1
#   getitem_6 => select_13, slice_9
#   to_2 => convert_element_type_2
# Graph fragment:
#   %arg2_1 : Tensor "i64[3, 2, 1][2, 1, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg3_1 : Tensor "f32[64][1]tnca:0" = PlaceHolder[target=arg3_1]
#   %unsqueeze : Tensor "i64[3, 2, 1, 1][2, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg2_1, 3), kwargs = {})
#   %convert_element_type_2 : Tensor "f32[3, 2, 1, 1][2, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %mul_2 : Tensor "f32[3, 2, 1, 64][128, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_2, %arg3_1), kwargs = {})
#   %cos : Tensor "f32[3, 2, 1, 64][128, 64, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul_2,), kwargs = {})
#   %select_1 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_1 : Tensor "f32[2, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_1, 2, 1, 60, 3), kwargs = {})
#   %select_int : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_1, 2, 1, 60, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 2, 1, 64][128, 64, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default, 0, 0), kwargs = {})
#   %sin : Tensor "f32[3, 2, 1, 64][128, 64, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul_2,), kwargs = {})
#   %select_13 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_9 : Tensor "f32[2, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_13, 2, 1, 60, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_9, 2, 1, 60, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 2, 1, 64][128, 64, 64, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default_1, 0, 0), kwargs = {})
#   return %select_scatter_default,%select_scatter_default_1
triton_poi_fused__to_copy_cos_mul_select_sin_slice_unsqueeze_2 = async_compile.triton('triton_poi_fused__to_copy_cos_mul_select_sin_slice_unsqueeze_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_cos_mul_select_sin_slice_unsqueeze_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 6480}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_cos_mul_select_sin_slice_unsqueeze_2(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 384
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex // 128
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 2)
    x3 = xindex // 64
    x4 = xindex
    tmp22 = tl.load(in_ptr0 + (x1), xmask, eviction_policy='evict_last')
    tmp24 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last')
    tmp28 = tl.load(in_ptr0 + (x3), xmask, eviction_policy='evict_last')
    tmp0 = (x2).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 1, tl.int64)
    tmp6 = tmp4 >= tmp5
    tmp7 = tl.full([1], 60, tl.int64)
    tmp8 = tmp4 < tmp7
    tmp9 = ((((-1) + x0) % 3)).to(tl.int64)
    tmp10 = (tmp9).to(tl.int64)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 == tmp11
    tmp13 = tmp6 & tmp8
    tmp14 = tmp13 & tmp12
    tmp15 = tl.load(in_ptr0 + (2 + x1), tmp14 & xmask, eviction_policy='evict_last', other=0.0)
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp14 & xmask, eviction_policy='evict_last', other=0.0)
    tmp18 = tmp16 * tmp17
    tmp19 = tl_math.cos(tmp18)
    tmp20 = tl.full(tmp19.shape, 0.0, tmp19.dtype)
    tmp21 = tl.where(tmp14, tmp19, tmp20)
    tmp23 = tmp22.to(tl.float32)
    tmp25 = tmp23 * tmp24
    tmp26 = tl_math.cos(tmp25)
    tmp27 = tl.where(tmp14, tmp21, tmp26)
    tmp29 = tmp28.to(tl.float32)
    tmp30 = tmp29 * tmp24
    tmp31 = tl_math.cos(tmp30)
    tmp32 = tl.where(tmp2, tmp27, tmp31)
    tmp33 = tl_math.sin(tmp18)
    tmp34 = tl.full(tmp33.shape, 0.0, tmp33.dtype)
    tmp35 = tl.where(tmp14, tmp33, tmp34)
    tmp36 = tl_math.sin(tmp25)
    tmp37 = tl.where(tmp14, tmp35, tmp36)
    tmp38 = tl_math.sin(tmp30)
    tmp39 = tl.where(tmp2, tmp37, tmp38)
    tl.store(out_ptr0 + (x4), tmp32, xmask)
    tl.store(out_ptr1 + (x4), tmp39, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/ki/ckirhave2ezr3bhm76spgrrsga3pby2wwldwn6uanveqsjx3pl24.py
# Topologically Sorted Source Nodes: [xf, pow_1, mean, add, rsqrt, mul, xn, to_1, q, setitem_1, cat, to_4, cos_1, mul_3, setitem_3, cat_1, to_5, sin_1, mul_4, qe, matmul, transpose_1, mul_5], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.select, aten.slice, aten.cat, aten.unsqueeze, aten.view, aten.bmm]
# Source node to ATen node mapping:
#   add => add
#   cat => clone, expand, select_11, unsqueeze_1, view
#   cat_1 => clone_2, expand_1, select_23, unsqueeze_3, view_1
#   cos_1 => unsqueeze_2
#   matmul => bmm, view_2, view_3, view_4
#   mean => mean
#   mul => mul
#   mul_3 => mul_3
#   mul_4 => mul_4
#   mul_5 => mul_5
#   pow_1 => pow_1
#   q => permute
#   qe => add_1
#   rsqrt => rsqrt
#   setitem_1 => select_8, slice_7
#   setitem_3 => select_20, slice_15
#   sin_1 => unsqueeze_4
#   to_1 => convert_element_type_1
#   to_4 => convert_element_type_3
#   to_5 => convert_element_type_4
#   transpose_1 => permute_1
#   xf => convert_element_type
#   xn => mul_1
# Graph fragment:
#   %arg1_1 : Tensor "f32[128][1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "bf16[2, 1, 4, 128][512, 512, 128, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf2 : Tensor "f32[2, 1, 4, 1][4, 8, 1, 8]tnca:0" = PlaceHolder[target=buf2]
#   %select_scatter_default : Tensor "f32[3, 2, 1, 64][128, 64, 384, 1]tnca:0" = PlaceHolder[target=select_scatter_default]
#   %cat : Tensor "bf16[2, 4, 1, 128][512, 128, 128, 1]tnca:0" = PlaceHolder[target=cat]
#   %select_scatter_default_1 : Tensor "f32[3, 2, 1, 64][128, 64, 384, 1]tnca:0" = PlaceHolder[target=select_scatter_default_1]
#   %arg4_1 : Tensor "bf16[2, 4, 40, 128][20480, 5120, 128, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %bmm : Tensor "bf16[8, 1, 40][40, 40, 1]tnca:0" = PlaceHolder[target=bmm]
#   %convert_element_type : Tensor "f32[2, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[2, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[2, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add : Tensor "f32[2, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[2, 1, 4, 1][4, 4, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[2, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[2, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg1_1, %mul), kwargs = {})
#   %convert_element_type_1 : Tensor "bf16[2, 1, 4, 128][512, 512, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.bfloat16), kwargs = {})
#   %permute : Tensor "bf16[2, 4, 1, 128][512, 128, 512, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_1, [0, 2, 1, 3]), kwargs = {})
#   %select_8 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_7 : Tensor "f32[2, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 60, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_7, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_2 : Tensor "f32[3, 2, 1, 64][128, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 0, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[2, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand : Tensor "f32[2, 1, 2, 64][64, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [2, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[2, 1, 2, 64][128, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[2, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [2, 1, 128]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[2, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_2 : Tensor "bf16[2, 1, 1, 128][128, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %mul_3 : Tensor "bf16[2, 4, 1, 128][512, 128, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute, %unsqueeze_2), kwargs = {})
#   %select_20 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_15 : Tensor "f32[2, 1, 20][64, 64, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 60, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_15, 2, 2, 60, 3), kwargs = {})
#   %select_scatter_default_3 : Tensor "f32[3, 2, 1, 64][128, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[2, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 0), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[2, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_1 : Tensor "f32[2, 1, 2, 64][64, 64, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [2, 1, 2, 64]), kwargs = {})
#   %clone_2 : Tensor "f32[2, 1, 2, 64][128, 128, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[2, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [2, 1, 128]), kwargs = {})
#   %convert_element_type_4 : Tensor "bf16[2, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_4 : Tensor "bf16[2, 1, 1, 128][128, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_4, 1), kwargs = {})
#   %mul_4 : Tensor "bf16[2, 4, 1, 128][512, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_4), kwargs = {})
#   %add_1 : Tensor "bf16[2, 4, 1, 128][512, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_3, %mul_4), kwargs = {})
#   %view_2 : Tensor "bf16[8, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [8, 1, 128]), kwargs = {})
#   %permute_1 : Tensor "bf16[2, 4, 128, 40][20480, 5120, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg4_1, [0, 1, 3, 2]), kwargs = {})
#   %view_3 : Tensor "bf16[8, 128, 40][5120, 1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_3, [8, 128, 40]), kwargs = {})
#   %bmm : Tensor "bf16[8, 1, 40][40, 40, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_2, %view_3), kwargs = {})
#   %view_4 : Tensor "bf16[2, 4, 1, 40][160, 40, 40, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [2, 4, 1, 40]), kwargs = {})
#   %mul_5 : Tensor "bf16[2, 4, 1, 40][160, 40, 40, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_4, 0.08838834764831845), kwargs = {})
#   return %bmm,%mul_5
triton_red_fused__to_copy_add_bmm_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_3 = async_compile.triton('triton_red_fused__to_copy_add_bmm_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 512, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*fp32', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*fp32', 'in_ptr6': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_bmm_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_3', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1280, 'r0_': 89600}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_bmm_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_3(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 320
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 40
    tmp3 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    x3 = xindex
    _tmp43 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_2), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.load(in_ptr1 + (r0_2 + 128*x1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp27 = tl.load(in_ptr3 + (64*(x1 // 4) + ((r0_2 % 64))), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp32 = tl.load(in_ptr4 + (r0_2 + 128*x1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp34 = tl.load(in_ptr5 + (64*(x1 // 4) + ((r0_2 % 64))), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp40 = tl.load(in_ptr6 + (r0_2 + 128*x3), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp2 = tmp1.to(tl.float32)
        tmp4 = tl.full([1], 128.0, tl.float32)
        tmp5 = (tmp3 / tmp4)
        tmp6 = tl.full([1], 1e-06, tl.float32)
        tmp7 = tmp5 + tmp6
        tmp8 = libdevice.rsqrt(tmp7)
        tmp9 = tmp2 * tmp8
        tmp10 = tmp0 * tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 0, tl.int32)
        tmp13 = tmp12 == tmp12
        tmp14 = ((r0_2 % 64)).to(tl.int64)
        tmp15 = (tmp14).to(tl.int64)
        tmp16 = tl.full([1], 2, tl.int64)
        tmp17 = tmp15 >= tmp16
        tmp18 = tl.full([1], 60, tl.int64)
        tmp19 = tmp15 < tmp18
        tmp20 = ((((-2) + ((r0_2 % 64))) % 3)).to(tl.int64)
        tmp21 = (tmp20).to(tl.int64)
        tmp22 = tl.full([1], 0, tl.int64)
        tmp23 = tmp21 == tmp22
        tmp24 = tmp17 & tmp19
        tmp25 = tmp24 & tmp23
        tmp26 = tl.load(in_ptr3 + (258 + 3*(triton_helpers.div_floor_integer((-2) + ((r0_2 % 64)),  3)) + 64*(x1 // 4)), r0_mask & tmp25, eviction_policy='evict_last', other=0.0)
        tmp28 = tl.where(tmp25, tmp26, tmp27)
        tmp29 = tl.where(tmp13, tmp28, tmp27)
        tmp30 = tmp29.to(tl.float32)
        tmp31 = tmp11 * tmp30
        tmp33 = tl.load(in_ptr5 + (258 + 3*(triton_helpers.div_floor_integer((-2) + ((r0_2 % 64)),  3)) + 64*(x1 // 4)), r0_mask & tmp25, eviction_policy='evict_last', other=0.0)
        tmp35 = tl.where(tmp25, tmp33, tmp34)
        tmp36 = tl.where(tmp13, tmp35, tmp34)
        tmp37 = tmp36.to(tl.float32)
        tmp38 = tmp32 * tmp37
        tmp39 = tmp31 + tmp38
        tmp41 = tmp39 * tmp40
        tmp42 = tl.broadcast_to(tmp41, [R0_BLOCK])
        tmp44 = _tmp43 + tmp42
        _tmp43 = tl.where(r0_mask, tmp44, _tmp43)
    tmp43 = triton_helpers.promote_to_tensor(tl.sum(_tmp43, 0))
    tmp45 = tl.full([1], 0.08838834764831845, tl.float32)
    tmp46 = tmp43 * tmp45
    tl.store(in_out_ptr0 + (x3), tmp46, None)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1 = args
        args.clear()
        assert_size_stride(arg0_1, (2, 1, 4, 128), (512, 512, 128, 1), 'input')
        buf2 = empty_strided((2, 1, 4, 1), (4, 8, 1, 8), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [xf, pow_1, mean], Original ATen: [aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mean_pow_0.run(arg0_1, buf2, 8, 128, stream=raw_stream0)
        assert_size_stride(arg1_1, (128, ), (1, ), 'input')
        buf5 = empty_strided((2, 4, 1, 128), (512, 128, 128, 1), device='tnca', dtype=torch.bfloat16)
        buf3 = reinterpret_tensor(buf5, (2, 4, 1, 64), (512, 128, 128, 1), 0)  # alias
        buf4 = reinterpret_tensor(buf5, (2, 4, 1, 64), (512, 128, 128, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [xf, pow_1, mean, add, rsqrt, mul, xn, to_1, q, getitem_9, neg, getitem_10, rot], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_1.run(arg1_1, arg0_1, buf2, buf3, buf4, 512, stream=raw_stream0)
        assert_size_stride_grouped((arg2_1, arg3_1), ((3, 2, 1), (64, )), ((2, 1, 1), (1, )), 'input')
        buf0 = empty_strided((3, 2, 1, 64), (128, 64, 384, 1), device='tnca', dtype=torch.float32)
        buf1 = empty_strided((3, 2, 1, 64), (128, 64, 384, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [getitem, to_2, freqs, f, getitem_2, f_1, getitem_6], Original ATen: [aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_cos_mul_select_sin_slice_unsqueeze_2.run(arg2_1, arg3_1, buf0, buf1, 384, stream=raw_stream0)
        del arg2_1
        del arg3_1
        del buf3
        del buf4
        assert_size_stride(arg4_1, (2, 4, 40, 128), (20480, 5120, 128, 1), 'input')
        buf6 = empty_strided((8, 1, 40), (40, 40, 1), device='tnca', dtype=torch.bfloat16)
        buf7 = reinterpret_tensor(buf6, (2, 4, 1, 40), (160, 40, 40, 1), 0); del buf6  # reuse
        # Topologically Sorted Source Nodes: [xf, pow_1, mean, add, rsqrt, mul, xn, to_1, q, setitem_1, cat, to_4, cos_1, mul_3, setitem_3, cat_1, to_5, sin_1, mul_4, qe, matmul, transpose_1, mul_5], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.select, aten.slice, aten.cat, aten.unsqueeze, aten.view, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_bmm_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_3.run(buf7, arg1_1, arg0_1, buf2, buf0, buf5, buf1, arg4_1, 320, 128, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg4_1
        return (buf7, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((2, 1, 4, 128), (512, 512, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg2_1 = rand_strided((3, 2, 1), (2, 1, 1), device='tnca:0', dtype=torch.int64)
    arg3_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg4_1 = rand_strided((2, 4, 40, 128), (20480, 5120, 128, 1), device='tnca:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
