    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #14
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    s.rdspecial  s2, arg_base
    v.lshr       v1, v4, v0
    s.ld.d       s3, [s2, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.sub        v0, v2, v1
    v.movi       v4, #0
    @p1 v.sel        v5, v0, v1
    v.sub        v0, v4, v3
    v.cmp.lt     p1, v3, v4
    @p1 v.sel        v1, v0, v3
    v.movi       v0, #7
    v.movi       v6, #0
    v.lshr       v7, v1, v0
    v.movi       v0, #0
    v.sub        v1, v4, v7
    v.movi       v8, #127
    @p1 v.sel        v9, v1, v7
    v.movi       v1, #128
    v.sub        v7, v0, v9
    v.cmp.lt     p1, v9, v0
    @p1 v.sel        v10, v7, v9
    s.ld.d       s4, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.and        v7, v10, v8
    v.movi       v8, #16384
    v.sub        v9, v0, v7
    s.ld.d       s5, [s2, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    @p1 v.sel        v10, v9, v7
    v.sub        v7, v2, v8
    s.ld.d       s6, [s2, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    v.sub        v9, v4, v1
    v.sub        v11, v0, v1
    s.ld.d       s7, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v8, v2
    s.ld.d       s8, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v2, v6, v3
    v.sub        v12, v6, v1
    @p1 v.sel        v13, v2, v3
    s.ld.d       s9, [s2, #48]                   // out_ptr0: device_ptr64 at arg_base+48
    v.movi       v2, #127
    v.cmp.lt     p3, v1, v4
    s.ld.d       s10, [s2, #56]                  // out_ptr1: device_ptr64 at arg_base+56
    v.movi       v3, #0
    v.and        v4, v13, v2
    v.movi       v2, #2048
    v.sub        v13, v6, v4
    v.add        v14, v10, v2
    @p1 v.sel        v2, v13, v4
    v.cmp.lt     p1, v5, v3
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    v.ld.gather.w v4, [s8, v5]                   // index is in elements (ISA sec 9.1)
    s.add        s1, s7, s2                      // &in_ptr0[...]
    v.movi       v10, #2
    @p2 v.sel        v13, v7, v8
    v.sub        v7, v3, v5
    v.movi       v8, #1
    @p1 v.sel        v13, v7, v5
    v.cmp.lt     p2, v1, v0
    v.lshr       v0, v13, v8
    v.sub        v7, v3, v10
    v.sub        v8, v3, v0
    @p3 v.sel        v13, v9, v1
    v.ld.gather.w v9, [s3, v5]                   // index is in elements (ISA sec 9.1)
    @p1 v.sel        v13, v8, v0
    v.movi       v0, #4096
    v.mul        v8, v13, v1
    v.add        v13, v2, v0
    v.add        v0, v14, v8
    v.mul        v8, v5, v1
    v.cmp.lt     p1, v1, v6
    v.add        v6, v13, v8
    v.add        v13, v2, v8
    v.ld.gather.h v2, [s4, v6]                   // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v10, v3
    @p2 v.sel        v3, v11, v1
    .li       s3, #897988541
    v.splat      v3, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1077936128
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v8, v9, v3
    v.ld.gather.w v3, [s5, v13]                  // index is in elements (ISA sec 9.1)
    .li       s3, #3204448256
    v.splat      v9, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v11, v2
    v.rsqrt.approx v2, v8                        // ISA 8.8: <= 2**-22 relative
    @p1 v.sel        v13, v12, v1
    s.add        s3, s9, s2                      // &out_ptr0[...]
    @p3 v.sel        v1, v7, v10
    v.ld.gather.h v1, [s4, v0]                   // index is in elements (ISA sec 9.1)
    vf.sub       v0, v11, v3
    v.ld.gather.w v3, [s6, v5]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v5, v1
    v.ld.w       v1, [s1, #0]
    vf.mul       v7, v0, v3
    s.add        s1, s10, s2                     // &out_ptr1[...]
    vf.mul       v0, v2, v2
    vf.mul       v3, v2, v9
    vf.fms       v9, v8, v0, v6
    vf.mul       v0, v1, v4
    vf.mul       v1, v3, v9                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v3, v1, v2
    vf.mul       v1, v5, v3
    vf.mul       v2, v1, v7
    vf.add       v1, v0, v2
    v.st.w       [s3, #0], v1
    v.st.w       [s1, #0], v1
__rctx_next:
    exit
