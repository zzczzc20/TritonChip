    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s2, arg_base
    v.add        v3, v1, v0
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v0, #63
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.movi       v4, #2560
    @p1 v.sel        v5, v1, v3
    s.shli       s4, s1, #1                      // element offset -> bytes (x2)
    v.cmp.lt     p2, v3, v4
    v.and        v1, v5, v0
    v.movi       v0, #64
    s.ld.d       s1, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v3, v2, v1
    s.add        s5, s3, s4                      // &in_ptr0[...]
    v.sub        v4, v2, v0
    @p1 v.sel        v5, v3, v1
    v.cmp.lt     p1, v0, v2
    @p1 v.sel        v1, v4, v0
    @p2 v.ld.h       v0, [s5, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v1, [s1, v5]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v0
    vf.cvt.bf16.f32 v0, v1
    s.ld.d       s1, [s2, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    vf.add       v1, v2, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s2, s1, s4                      // &out_ptr0[...]
    @p2 v.st.h       [s2, #0], v0
__rctx_next:
    exit
