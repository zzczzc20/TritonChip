    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #16
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #4
    s.movz       s6, #2
    s.xor        s8, s5, s3
    s.movz       s9, #1
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s9
    s.movz       s8, #0
    s.cmp.lt     s13, s12, s3
    s.movz       s3, #0
    s.cmp.lt     s14, s4, s11
    s.sub        s11, s8, s13
    s.sub        s8, s3, s14
    s.xor        s3, s12, s11
    s.muli       s13, s5, #16
    s.movz       s5, #0
    s.movz       s14, #1
    s.xor        s15, s4, s8
    s.sub        s16, s3, s11
    s.rdspecial  s3, arg_base
    s.xor        s11, s1, s7
    s.movz       s17, #0
    s.sub        s18, s15, s8
    s.addi       s15, s5, #0
    s.cmp.eq     s5, s16, s14
    s.ld.d       s14, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s19, s11, s7
    s.sub        s7, s2, s13
    s.ld.d       s2, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.addi       s7, s17, #0
    s.ld.d       s11, [s3, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s15, s18
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s15, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s18, s3
    s.shli       s13, s7, #1
    s.andi       s17, s5, #1
    s.movz       s5, #0
    s.or         s19, s13, s17
    s.movz       s13, #1
    s.cmp.geu    s17, s19, s16
    s.shl        s20, s13, s3
    s.sub        s13, s5, s17
    s.subi       s5, s3, #1
    s.and        s17, s16, s13
    s.and        s21, s20, s13
    s.sub        s13, s19, s17
    s.or         s17, s15, s21
    s.mov        s7, s13
    s.mov        s15, s17
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s13, s3, s5
    br.nz        s13, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s13, s4, s3
    s.movz       s3, #0
    s.sub        s15, s5, s13
    s.movz       s5, #0
    s.xor        s13, s4, s15
    s.movz       s4, #0
    s.sub        s16, s13, s15
    s.cmp.lt     s13, s12, s3
    s.lshri      s3, s16, #4
    s.movz       s17, #0
    s.muli       s18, s3, #16
    s.movz       s3, #0
    s.sub        s19, s4, s13
    s.movz       s4, #0
    s.cmp.lt     s13, s1, s17
    s.sub        s17, s16, s18
    s.xor        s16, s12, s19
    s.xor        s12, s17, s15
    s.xor        s17, s7, s8
    s.sub        s7, s12, s15
    s.sub        s12, s4, s13
    s.cmp.lt     s4, s7, s5
    s.sub        s5, s16, s19
    s.sub        s13, s3, s4
    s.movz       s3, #0
    s.xor        s4, s7, s13
    s.movz       s7, #1
    s.sub        s15, s17, s8
    s.xor        s8, s1, s12
    s.sub        s16, s4, s13
    s.movz       s4, #0
    s.addi       s17, s3, #0
    s.cmp.eq     s3, s5, s7
    s.add        s7, s10, s15
    s.sub        s10, s8, s12
    s.addi       s8, s4, #0
    s.mov        s17, s16
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s17, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s16, s3
    s.shli       s10, s8, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s15, s10, s12
    s.movz       s10, #1
    s.cmp.geu    s12, s15, s5
    s.shl        s18, s10, s3
    s.sub        s10, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s10
    s.and        s20, s18, s10
    s.sub        s10, s15, s12
    s.or         s12, s17, s20
    s.mov        s8, s10
    s.mov        s17, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s10, s3, s4
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.xor        s3, s13, s19
    s.mul        s4, s7, s1
    s.xor        s5, s17, s3
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s8, s5, s3
    s.movz       s3, #0
    s.mul        s5, s8, s1
    v.splat      v1, s4
    v.movi       v2, #17
    v.add        v3, v1, v0
    v.movi       v1, #0
    v.splat      v4, s7
    v.splat      v5, s3
    v.splat      v6, s8
    v.splat      v7, s3
    v.splat      v8, s5
    v.sub        v9, v1, v3
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v2, v1
    v.cmp.ge     p3, v4, v5
    v.sub        v4, v1, v2
    v.cmp.ge     p3, v6, v7
    v.add        v5, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v3
    @p2 v.sel        v3, v4, v2
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s7, #31
idiv_5:
    v.splat      v6, s7
    v.shl        v7, v4, v0
    v.lshr       v8, v5, v6
    v.cmp.lt     p2, v4, v1
    v.and        v9, v8, v0
    v.shl        v8, v0, v6
    v.or         v6, v7, v9
    s.subi       s8, s7, #1
    v.cmp.geu    p3, v6, v3
    p.or         p4, p2, p3
    v.sub        v7, v6, v3
    @p4 v.sel        v9, v8, v1
    @p4 v.sel        v8, v7, v6
    v.or         v6, v2, v9
    v.mov        v4, v8
    v.mov        v2, v6
    s.mov        s7, s8
    s.movz       s8, #0
    s.cmp.ge     s10, s7, s8
    br.nz        s10, idiv_5
    v.sub        v0, v1, v4
    @p1 v.sel        v1, v0, v4
    s.andi       s7, s5, #255
    v.splat      v0, s7
    v.iota       v2                              // arange(0, VLEN)
    v.add        v3, v0, v2
    s.rdspecial  s8, pid.y
    s.rdspecial  s10, pid.z
    s.rdspecial  s12, npid.y
    s.mul        s13, s10, s12
    s.add        s10, s8, s13
    s.movz       s8, #15
    s.min.s      s12, s10, s8
    s.movz       s13, #289
    s.mul        s15, s12, s13
    s.rdspecial  s13, arg_base
    s.ld.d       s16, [s13, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s13, role_id
    s.movz       s17, #7168
    s.mul        s18, s13, s17
    s.add        s13, s16, s18                   // this context's own scratch
    s.addi       s16, s13, #0
    v.splat      v0, s3
    v.extract    s17, v1, #0
    v.splat      v2, s17
    s.movz       s17, #17
    v.splat      v3, s17
    v.mul        v4, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.add        v5, v4, v2
    s.movz       s18, #0
    s.add        s19, s18, s15                   // the tile origin
    v.splat      v4, s19
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s16, #0], v5
    s.addi       s15, s16, #64
    v.extract    s18, v1, #1
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #128
    v.extract    s18, v1, #2
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #192
    v.extract    s18, v1, #3
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #256
    v.extract    s18, v1, #4
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #320
    v.extract    s18, v1, #5
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #384
    v.extract    s18, v1, #6
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #448
    v.extract    s18, v1, #7
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #512
    v.extract    s18, v1, #8
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #576
    v.extract    s18, v1, #9
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #640
    v.extract    s18, v1, #10
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #704
    v.extract    s18, v1, #11
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #768
    v.extract    s18, v1, #12
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #832
    v.extract    s18, v1, #13
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #896
    v.extract    s18, v1, #14
    v.splat      v5, s18
    v.mul        v6, v5, v3
    v.add        v5, v6, v2
    v.add        v6, v5, v4
    v.add        v5, v0, v6
    v.st.w       [s15, #0], v5
    s.addi       s15, s16, #960
    v.extract    s16, v1, #15
    v.splat      v1, s16
    v.mul        v5, v1, v3
    v.add        v1, v5, v2
    v.add        v5, v1, v4
    v.add        v1, v0, v5
    v.st.w       [s15, #0], v1
    fence.acq_rel.device
    s.movz       s15, #4352
    s.mul        s16, s12, s15
    s.addi       s12, s3, #0
    s.addi       s18, s13, #1024
    s.addi       s19, s13, #0
    v.ld.w       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s19, s18, #64
    s.addi       s20, s13, #64
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #128
    s.addi       s20, s13, #128
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #192
    s.addi       s20, s13, #192
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #256
    s.addi       s20, s13, #256
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #320
    s.addi       s20, s13, #320
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #384
    s.addi       s20, s13, #384
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #448
    s.addi       s20, s13, #448
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #512
    s.addi       s20, s13, #512
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #576
    s.addi       s20, s13, #576
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #640
    s.addi       s20, s13, #640
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #704
    s.addi       s20, s13, #704
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #768
    s.addi       s20, s13, #768
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #832
    s.addi       s20, s13, #832
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #896
    s.addi       s20, s13, #896
    v.ld.w       v0, [s20, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s18, #960
    s.addi       s18, s13, #960
    v.ld.w       v0, [s18, #0]
    v.st.w       [s19, #0], v0
    fence.acq_rel.device
    s.addi       s18, s13, #2048
    s.movz       s19, #0
    s.add        s20, s19, s7                    // the tile origin
    s.add        s7, s20, s16                    // the tile origin
    v.splat      v0, s7
    v.add        v1, v2, v0
    v.st.w       [s18, #0], v1
    s.addi       s16, s18, #64
    s.addi       s19, s7, #256
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #128
    s.addi       s19, s7, #512
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #192
    s.addi       s19, s7, #768
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #256
    s.addi       s19, s7, #1024
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #320
    s.addi       s19, s7, #1280
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #384
    s.addi       s19, s7, #1536
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #448
    s.addi       s19, s7, #1792
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #512
    s.addi       s19, s7, #2048
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #576
    s.addi       s19, s7, #2304
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #640
    s.addi       s19, s7, #2560
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #704
    s.addi       s19, s7, #2816
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #768
    s.addi       s19, s7, #3072
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #832
    s.addi       s19, s7, #3328
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #896
    s.addi       s19, s7, #3584
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s18, #960
    s.addi       s18, s7, #3840
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.st.w       [s16, #0], v1
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_6:
    s.cmp.ge     s7, s12, s17
    br.nz        s7, endfor_7
    s.addi       s7, s13, #1024
    s.sub        s16, s17, s12
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s18, #0
    s.add        s19, s7, s16                    // the tile origin
    s.addi       s7, s13, #1088
    v.splat      v1, s19
    s.movz       s19, #1
    v.cmp.lt     p1, v2, v1
    s.addi       s20, s13, #1152
    s.movz       s21, #2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    s.addi       s22, s13, #1216
    a.vwrite     a1, s18, v1
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #3
    s.addi       s18, s13, #1280
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s19, v1
    v.ld.w       v0, [s20, #0]
    s.movz       s19, #4
    s.addi       s20, s13, #1344
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s21, v1
    v.ld.w       v0, [s22, #0]
    s.movz       s21, #5
    s.addi       s22, s13, #1408
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v1
    v.ld.w       v0, [s18, #0]
    s.movz       s7, #6
    s.addi       s18, s13, #1472
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s19, v1
    v.ld.w       v0, [s20, #0]
    s.movz       s19, #7
    s.addi       s20, s13, #1536
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s21, v1
    v.ld.w       v0, [s22, #0]
    s.movz       s21, #8
    s.addi       s22, s13, #1600
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v1
    v.ld.w       v0, [s18, #0]
    s.movz       s7, #9
    s.addi       s18, s13, #1664
    v.splat      v1, s3
    s.movz       s23, #10
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s19, v4
    v.ld.w       v0, [s20, #0]
    s.addi       s19, s13, #1728
    s.movz       s20, #11
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s21, v4
    v.ld.w       v0, [s22, #0]
    s.addi       s21, s13, #1792
    s.movz       s22, #12
    v.splat      v4, s9
    s.addi       s24, s13, #1856
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v5
    v.ld.w       v0, [s18, #0]
    s.movz       s7, #13
    s.addi       s18, s13, #1920
    v.splat      v5, s6
    s.movz       s25, #14
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s23, v6
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s13, #1984
    s.movz       s23, #15
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s20, v6
    v.ld.w       v0, [s21, #0]
    s.addi       s20, s13, #2048
    s.movz       s21, #0
    s.add        s26, s21, s16                   // the tile origin
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s16, #0
    v.splat      v6, s26
    s.addi       s21, s13, #2112
    v.cmp.lt     p2, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s22, v1
    v.ld.w       v0, [s24, #0]
    s.movz       s22, #1
    s.addi       s24, s13, #2176
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v1
    v.ld.w       v0, [s18, #0]
    s.movz       s7, #2
    s.addi       s18, s13, #2240
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s14, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s25, v1
    v.ld.w       v0, [s19, #0]
    s.movz       s19, #3
    s.movz       s25, #3
    v.splat      v1, s19
    s.addi       s19, s13, #2304
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v6
    s.movz       s26, #4
    v.splat      v0, s26
    s.movz       s26, #4
    a.vwrite     a1, s23, v7
    v.ld.w       v4, [s20, #0]
    s.addi       s20, s13, #2368
    s.movz       s23, #5
    v.splat      v7, s23
    s.movz       s23, #5
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v6
    a.vwrite     a2, s16, v8
    v.ld.w       v4, [s21, #0]
    s.addi       s16, s13, #2432
    s.movz       s21, #6
    v.splat      v5, s21
    s.movz       s21, #6
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v6
    a.vwrite     a2, s22, v8
    v.ld.w       v1, [s24, #0]
    s.addi       s22, s13, #2496
    s.movz       s24, #7
    v.splat      v4, s24
    s.movz       s24, #7
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s2, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v6
    a.vwrite     a2, s7, v8
    v.ld.w       v0, [s18, #0]
    s.addi       s7, s13, #2560
    s.movz       s18, #8
    v.splat      v1, s18
    s.movz       s18, #8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v6
    a.vwrite     a2, s25, v8
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s13, #2624
    s.movz       s25, #9
    v.splat      v7, s25
    s.movz       s25, #9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v6
    a.vwrite     a2, s26, v8
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s13, #2688
    s.movz       s26, #10
    v.splat      v5, s26
    s.movz       s26, #10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v6
    a.vwrite     a2, s23, v8
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s13, #2752
    s.movz       s23, #11
    v.splat      v4, s23
    s.movz       s23, #11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v6
    a.vwrite     a2, s21, v8
    v.ld.w       v0, [s22, #0]
    s.addi       s21, s13, #2816
    s.movz       s22, #12
    v.splat      v1, s22
    s.movz       s22, #12
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v6
    a.vwrite     a2, s24, v8
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s13, #2880
    s.movz       s24, #13
    v.splat      v7, s24
    s.movz       s24, #13
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v6
    a.vwrite     a2, s18, v8
    v.ld.w       v0, [s19, #0]
    s.addi       s18, s13, #2944
    s.movz       s19, #14
    v.splat      v5, s8
    v.splat      v8, s19
    s.movz       s19, #14
    s.addi       s27, s13, #3008
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v9, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v6
    a.vwrite     a2, s25, v9
    v.ld.w       v0, [s20, #0]
    s.movz       s20, #15
    s.movz       s25, #0
    v.movi       v4, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v6
    a.vwrite     a2, s26, v9
    v.ld.w       v0, [s16, #0]
    s.movz       s16, #0
    s.movz       s26, #1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v6
    a.vwrite     a2, s23, v1
    v.ld.w       v0, [s21, #0]
    s.movz       s21, #2
    s.movz       s23, #3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v6
    a.vwrite     a2, s22, v1
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #4
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s22, #0
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v6
    a.vwrite     a2, s24, v1
    v.ld.w       v0, [s18, #0]
    s.movz       s18, #5
    s.movz       s24, #6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v1
    v.ld.w       v0, [s27, #0]
    s.movz       s19, #7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    s.movz       s27, #8
    a.vwrite     a2, s20, v1
    a.vread      v0, a1, s25
    a.vread      v1, a2, s16
    v.extract    s16, v0, #0
    v.splat      v5, s16
    v.extract    s16, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s16
    a.vread      v5, a2, s26
    v.extract    s16, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s16
    a.vread      v5, a2, s21
    v.extract    s16, v0, #3
    vf.fma       v6, v1, v5, v7
    v.splat      v1, s16
    a.vread      v5, a2, s23
    v.extract    s16, v0, #4
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    v.extract    s7, v0, #5
    vf.fma       v6, v1, v5, v7
    v.splat      v1, s7
    a.vread      v5, a2, s18
    v.extract    s7, v0, #6
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s24
    v.extract    s7, v0, #7
    vf.fma       v6, v1, v5, v7
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #8
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s27
    s.movz       s7, #9
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #9
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #10
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #11
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #12
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #13
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #14
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #15
    v.splat      v0, s16
    a.vread      v1, a2, s7
    s.movz       s7, #1
    vf.fma       v5, v0, v1, v6
    s.movz       s16, #0
    s.movz       s18, #1
    s.movz       s19, #2
    a.vwrite     a3, s22, v5
    a.vread      v0, a1, s7
    a.vread      v1, a2, s16
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s18
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s19
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #1
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #2
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #2
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #3
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #4
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #5
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #6
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #7
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #8
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #9
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #9
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #10
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #10
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #11
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #11
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #12
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #12
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #13
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #13
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #14
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v5, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v7, v1, v5, v6
    v.splat      v1, s7
    a.vread      v5, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v5, v7
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v5, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v5, a2, s7
    s.movz       s7, #14
    vf.fma       v6, v1, v5, v7
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #10
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #12
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #14
    vf.fma       v7, v1, v5, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v5, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v5, v7
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.movz       s16, #15
    vf.fma       v5, v0, v1, v6
    s.movz       s18, #0
    s.movz       s19, #1
    s.movz       s20, #2
    a.vwrite     a3, s7, v5
    a.vread      v0, a1, s16
    a.vread      v1, a2, s18
    v.extract    s7, v0, #0
    v.splat      v5, s7
    v.extract    s7, v0, #1
    vf.fma       v6, v5, v1, v4
    v.splat      v1, s7
    a.vread      v4, a2, s19
    v.extract    s7, v0, #2
    vf.fma       v5, v1, v4, v6
    v.splat      v1, s7
    a.vread      v4, a2, s20
    s.movz       s7, #3
    vf.fma       v6, v1, v4, v5
    v.extract    s16, v0, #3
    v.splat      v1, s16
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v5, v1, v4, v6
    v.extract    s16, v0, #4
    v.splat      v1, s16
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v6, v1, v4, v5
    v.extract    s16, v0, #5
    v.splat      v1, s16
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v5, v1, v4, v6
    v.extract    s16, v0, #6
    v.splat      v1, s16
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v6, v1, v4, v5
    v.extract    s16, v0, #7
    v.splat      v1, s16
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v5, v1, v4, v6
    v.extract    s16, v0, #8
    v.splat      v1, s16
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v6, v1, v4, v5
    s.movz       s16, #9
    v.extract    s18, v0, #9
    v.splat      v1, s18
    a.vread      v4, a2, s16
    s.movz       s16, #10
    vf.fma       v5, v1, v4, v6
    v.extract    s18, v0, #10
    v.splat      v1, s18
    a.vread      v4, a2, s16
    s.movz       s16, #11
    vf.fma       v6, v1, v4, v5
    v.extract    s18, v0, #11
    v.splat      v1, s18
    a.vread      v4, a2, s16
    s.movz       s16, #12
    vf.fma       v5, v1, v4, v6
    v.extract    s18, v0, #12
    v.splat      v1, s18
    a.vread      v4, a2, s16
    s.movz       s16, #13
    vf.fma       v6, v1, v4, v5
    v.extract    s18, v0, #13
    v.splat      v1, s18
    a.vread      v4, a2, s16
    s.movz       s16, #14
    vf.fma       v5, v1, v4, v6
    v.extract    s18, v0, #14
    v.splat      v1, s18
    a.vread      v4, a2, s16
    s.movz       s16, #15
    vf.fma       v6, v1, v4, v5
    v.extract    s18, v0, #15
    v.splat      v0, s18
    a.vread      v1, a2, s16
    s.addi       s16, s13, #1024
    vf.fma       v4, v0, v1, v6
    v.splat      v0, s1
    s.addi       s18, s13, #3072
    s.addi       s19, s13, #1088
    a.vwrite     a3, s7, v4
    v.ld.w       v1, [s16, #0]
    s.addi       s7, s18, #64
    s.addi       s16, s13, #1152
    s.addi       s20, s18, #128
    s.addi       s21, s13, #1216
    s.addi       s22, s18, #192
    s.addi       s23, s13, #1280
    s.addi       s24, s18, #256
    s.addi       s25, s13, #1344
    s.addi       s26, s18, #320
    v.add        v4, v1, v0
    s.addi       s27, s13, #1408
    v.st.w       [s18, #0], v4
    s.addi       s28, s18, #384
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s13, #1472
    v.add        v4, v1, v0
    v.st.w       [s7, #0], v4
    s.addi       s7, s18, #448
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s13, #1536
    v.add        v4, v1, v0
    v.st.w       [s20, #0], v4
    s.addi       s20, s18, #512
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s13, #1600
    v.add        v4, v1, v0
    v.st.w       [s22, #0], v4
    s.addi       s22, s18, #576
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s13, #1664
    v.add        v4, v1, v0
    v.st.w       [s24, #0], v4
    s.addi       s24, s18, #640
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s13, #1728
    v.add        v4, v1, v0
    v.st.w       [s26, #0], v4
    s.addi       s26, s18, #704
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s13, #1792
    v.add        v4, v1, v0
    v.st.w       [s28, #0], v4
    s.addi       s28, s18, #768
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s13, #1856
    v.add        v4, v1, v0
    v.st.w       [s7, #0], v4
    s.addi       s7, s18, #832
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s13, #1920
    v.add        v4, v1, v0
    v.st.w       [s20, #0], v4
    s.addi       s20, s18, #896
    s.addi       s29, s18, #960
    v.ld.w       v1, [s21, #0]
    s.addi       s18, s13, #1984
    v.add        v4, v1, v0
    v.st.w       [s22, #0], v4
    s.addi       s21, s13, #2048
    v.ld.w       v1, [s23, #0]
    s.movz       s22, #4096
    v.splat      v4, s22
    s.addi       s22, s13, #4096
    v.add        v5, v1, v0
    v.st.w       [s24, #0], v5
    s.addi       s23, s13, #2112
    v.ld.w       v1, [s25, #0]
    s.addi       s24, s22, #64
    v.add        v5, v1, v0
    v.st.w       [s26, #0], v5
    s.addi       s25, s13, #2176
    v.ld.w       v1, [s27, #0]
    s.addi       s26, s22, #128
    v.add        v5, v1, v0
    v.st.w       [s28, #0], v5
    s.addi       s27, s13, #2240
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s22, #192
    v.add        v5, v1, v0
    v.st.w       [s7, #0], v5
    s.addi       s7, s13, #2304
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s22, #256
    v.add        v5, v1, v0
    v.st.w       [s20, #0], v5
    s.addi       s20, s13, #2368
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s22, #320
    v.add        v5, v1, v0
    v.st.w       [s29, #0], v5
    fence.acq_rel.device
    s.addi       s28, s13, #2432
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s22, #384
    v.add        v1, v0, v4
    v.st.w       [s22, #0], v1
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s13, #2496
    v.add        v1, v0, v4
    v.st.w       [s24, #0], v1
    s.addi       s24, s22, #448
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s13, #2560
    v.add        v1, v0, v4
    v.st.w       [s26, #0], v1
    s.addi       s26, s22, #512
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s13, #2624
    v.add        v1, v0, v4
    v.st.w       [s19, #0], v1
    s.addi       s19, s22, #576
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s13, #2688
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s22, #640
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s13, #2752
    v.add        v1, v0, v4
    v.st.w       [s18, #0], v1
    s.addi       s18, s22, #704
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s13, #2816
    v.add        v1, v0, v4
    v.st.w       [s21, #0], v1
    s.addi       s21, s22, #768
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s13, #2880
    v.add        v1, v0, v4
    v.st.w       [s24, #0], v1
    s.addi       s24, s22, #832
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s13, #2944
    v.add        v1, v0, v4
    v.st.w       [s26, #0], v1
    s.addi       s26, s22, #896
    s.addi       s29, s22, #960
    v.ld.w       v0, [s27, #0]
    s.addi       s22, s13, #3008
    v.add        v1, v0, v4
    v.st.w       [s19, #0], v1
    s.addi       s19, s13, #3072
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s13, #5120
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s13, #3136
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s7, #64
    v.add        v1, v0, v4
    v.st.w       [s18, #0], v1
    s.addi       s18, s13, #3200
    v.ld.w       v0, [s28, #0]
    s.addi       s27, s7, #128
    v.add        v1, v0, v4
    v.st.w       [s21, #0], v1
    s.addi       s21, s13, #3264
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s7, #192
    v.add        v1, v0, v4
    v.st.w       [s24, #0], v1
    s.addi       s24, s13, #3328
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s7, #256
    v.add        v1, v0, v4
    v.st.w       [s26, #0], v1
    s.addi       s26, s13, #3392
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s7, #320
    v.add        v1, v0, v4
    v.st.w       [s29, #0], v1
    fence.acq_rel.device
    s.addi       s28, s13, #3456
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s7, #384
    v.st.w       [s7, #0], v0
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s13, #3520
    v.st.w       [s20, #0], v0
    s.addi       s20, s7, #448
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s13, #3584
    v.st.w       [s27, #0], v0
    s.addi       s27, s7, #512
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s13, #3648
    v.st.w       [s23, #0], v0
    s.addi       s23, s7, #576
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s13, #3712
    v.st.w       [s25, #0], v0
    s.addi       s25, s7, #640
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s13, #3776
    v.st.w       [s22, #0], v0
    s.addi       s22, s7, #704
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s13, #3840
    v.st.w       [s19, #0], v0
    s.addi       s19, s7, #768
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s13, #3904
    v.st.w       [s20, #0], v0
    s.addi       s20, s7, #832
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s13, #3968
    v.st.w       [s27, #0], v0
    s.addi       s27, s7, #896
    s.addi       s29, s7, #960
    v.ld.w       v0, [s21, #0]
    s.addi       s7, s13, #4032
    v.st.w       [s23, #0], v0
    s.addi       s21, s13, #4096
    v.ld.w       v0, [s24, #0]
    s.addi       s23, s13, #6144
    v.st.w       [s25, #0], v0
    s.addi       s24, s13, #4160
    v.ld.w       v0, [s26, #0]
    s.addi       s25, s23, #64
    v.st.w       [s22, #0], v0
    s.addi       s22, s13, #4224
    v.ld.w       v0, [s28, #0]
    s.addi       s26, s23, #128
    v.st.w       [s19, #0], v0
    s.addi       s19, s13, #4288
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s23, #192
    v.st.w       [s20, #0], v0
    s.addi       s20, s13, #4352
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #256
    v.st.w       [s27, #0], v0
    s.addi       s27, s13, #4416
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s23, #320
    v.st.w       [s29, #0], v0
    fence.acq_rel.device
    s.addi       s28, s13, #4480
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s23, #384
    v.st.w       [s23, #0], v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s13, #4544
    v.st.w       [s25, #0], v0
    s.addi       s25, s23, #448
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s13, #4608
    v.st.w       [s26, #0], v0
    s.addi       s26, s23, #512
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s13, #4672
    v.st.w       [s16, #0], v0
    s.addi       s16, s23, #576
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s13, #4736
    v.st.w       [s18, #0], v0
    s.addi       s18, s23, #640
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s13, #4800
    v.st.w       [s7, #0], v0
    s.addi       s7, s23, #704
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s13, #4864
    v.st.w       [s21, #0], v0
    s.addi       s21, s23, #768
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s13, #4928
    v.st.w       [s25, #0], v0
    s.addi       s25, s23, #832
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s13, #4992
    v.st.w       [s26, #0], v0
    s.addi       s26, s23, #896
    s.addi       s29, s23, #960
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s13, #5056
    v.st.w       [s16, #0], v0
    s.movz       s16, #0
    v.ld.w       v0, [s20, #0]
    s.movz       s20, #0
    v.st.w       [s18, #0], v0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s18, #0
    v.ld.w       v0, [s27, #0]
    s.movz       s23, #1
    v.st.w       [s7, #0], v0
    s.movz       s7, #1
    v.ld.w       v0, [s28, #0]
    s.movz       s27, #1
    v.st.w       [s21, #0], v0
    s.movz       s21, #2
    v.ld.w       v0, [s24, #0]
    s.movz       s24, #2
    v.st.w       [s25, #0], v0
    s.movz       s25, #2
    v.ld.w       v0, [s22, #0]
    s.movz       s22, #3
    v.st.w       [s26, #0], v0
    s.movz       s26, #3
    v.ld.w       v0, [s19, #0]
    s.movz       s19, #3
    v.st.w       [s29, #0], v0
    fence.acq_rel.device
    a.vread      v0, a0, s16
    a.vread      v1, a3, s20
    s.movz       s16, #4
    vf.add       v4, v0, v1
    s.movz       s20, #4
    s.movz       s28, #4
    a.vwrite     a4, s18, v4
    a.vread      v0, a0, s23
    a.vread      v1, a3, s7
    s.movz       s7, #5
    vf.add       v4, v0, v1
    s.movz       s18, #5
    s.movz       s23, #5
    a.vwrite     a4, s27, v4
    a.vread      v0, a0, s21
    a.vread      v1, a3, s24
    s.movz       s21, #6
    vf.add       v4, v0, v1
    s.movz       s24, #6
    s.movz       s27, #6
    a.vwrite     a4, s25, v4
    a.vread      v0, a0, s22
    a.vread      v1, a3, s26
    s.movz       s22, #7
    vf.add       v4, v0, v1
    s.movz       s25, #7
    s.movz       s26, #7
    a.vwrite     a4, s19, v4
    a.vread      v0, a0, s16
    a.vread      v1, a3, s20
    s.movz       s16, #8
    vf.add       v4, v0, v1
    s.movz       s19, #8
    s.movz       s20, #8
    a.vwrite     a4, s28, v4
    a.vread      v0, a0, s7
    a.vread      v1, a3, s18
    s.movz       s7, #9
    vf.add       v4, v0, v1
    s.movz       s18, #9
    s.movz       s28, #9
    a.vwrite     a4, s23, v4
    a.vread      v0, a0, s21
    a.vread      v1, a3, s24
    s.movz       s21, #10
    vf.add       v4, v0, v1
    s.movz       s23, #10
    s.movz       s24, #10
    a.vwrite     a4, s27, v4
    a.vread      v0, a0, s22
    a.vread      v1, a3, s25
    s.movz       s22, #11
    vf.add       v4, v0, v1
    s.movz       s25, #11
    s.movz       s27, #11
    a.vwrite     a4, s26, v4
    a.vread      v0, a0, s16
    a.vread      v1, a3, s19
    s.movz       s16, #12
    vf.add       v4, v0, v1
    s.movz       s19, #12
    s.movz       s26, #12
    a.vwrite     a4, s20, v4
    a.vread      v0, a0, s7
    a.vread      v1, a3, s18
    s.movz       s7, #13
    vf.add       v4, v0, v1
    s.movz       s18, #13
    s.movz       s20, #13
    a.vwrite     a4, s28, v4
    a.vread      v0, a0, s21
    a.vread      v1, a3, s23
    s.movz       s21, #14
    vf.add       v4, v0, v1
    s.movz       s23, #14
    s.movz       s28, #14
    a.vwrite     a4, s24, v4
    a.vread      v0, a0, s22
    a.vread      v1, a3, s25
    s.movz       s22, #15
    vf.add       v4, v0, v1
    s.movz       s24, #15
    s.movz       s25, #15
    a.vwrite     a4, s27, v4
    a.vread      v0, a0, s16
    a.vread      v1, a3, s19
    s.addi       s16, s13, #5120
    vf.add       v4, v0, v1
    s.addi       s19, s13, #1024
    s.addi       s27, s13, #5184
    a.vwrite     a4, s26, v4
    a.vread      v0, a0, s7
    a.vread      v1, a3, s18
    s.addi       s7, s13, #1088
    vf.add       v4, v0, v1
    s.addi       s18, s13, #5248
    s.addi       s26, s13, #1152
    a.vwrite     a4, s20, v4
    a.vread      v0, a0, s21
    a.vread      v1, a3, s23
    s.addi       s20, s13, #5312
    vf.add       v4, v0, v1
    s.addi       s21, s13, #1216
    s.addi       s23, s13, #5376
    a.vwrite     a4, s28, v4
    a.vread      v0, a0, s22
    a.vread      v1, a3, s24
    s.addi       s22, s13, #1280
    vf.add       v4, v0, v1
    s.addi       s24, s13, #5440
    s.addi       s28, s13, #1344
    a.vwrite     a4, s25, v4
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s13, #5504
    s.addi       s25, s13, #1408
    v.st.w       [s19, #0], v0
    s.addi       s19, s13, #5568
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s13, #1472
    v.st.w       [s7, #0], v0
    s.addi       s7, s13, #5632
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s13, #1536
    v.st.w       [s26, #0], v0
    s.addi       s26, s13, #5696
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s13, #1600
    v.st.w       [s21, #0], v0
    s.addi       s21, s13, #5760
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s13, #1664
    v.st.w       [s22, #0], v0
    s.addi       s22, s13, #5824
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s13, #1728
    v.st.w       [s28, #0], v0
    s.addi       s28, s13, #5888
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s13, #1792
    v.st.w       [s25, #0], v0
    s.addi       s25, s13, #5952
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s13, #1856
    v.st.w       [s27, #0], v0
    s.addi       s27, s13, #6016
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s13, #1920
    v.st.w       [s18, #0], v0
    s.addi       s18, s13, #6080
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s13, #1984
    v.st.w       [s20, #0], v0
    s.addi       s20, s13, #6144
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s13, #2048
    v.st.w       [s23, #0], v0
    s.addi       s23, s13, #6208
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s13, #2112
    v.st.w       [s24, #0], v0
    s.addi       s24, s13, #6272
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s13, #2176
    v.st.w       [s16, #0], v0
    s.addi       s16, s13, #6336
    v.ld.w       v0, [s25, #0]
    s.addi       s25, s13, #2240
    v.st.w       [s19, #0], v0
    s.addi       s19, s13, #6400
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s13, #2304
    v.st.w       [s7, #0], v0
    s.addi       s7, s13, #6464
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s13, #2368
    v.st.w       [s26, #0], v0
    fence.acq_rel.device
    s.addi       s26, s13, #6528
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s13, #2432
    v.st.w       [s21, #0], v0
    s.addi       s21, s13, #6592
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s13, #2496
    v.st.w       [s22, #0], v0
    s.addi       s22, s13, #6656
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s13, #2560
    v.st.w       [s28, #0], v0
    s.addi       s28, s13, #6720
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s13, #2624
    v.st.w       [s25, #0], v0
    s.addi       s25, s13, #6784
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s13, #2688
    v.st.w       [s27, #0], v0
    s.addi       s27, s13, #6848
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s13, #2752
    v.st.w       [s18, #0], v0
    s.addi       s18, s13, #6912
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s13, #2816
    v.st.w       [s20, #0], v0
    s.addi       s20, s13, #6976
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s13, #2880
    v.st.w       [s23, #0], v0
    s.addi       s23, s13, #7040
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s13, #2944
    v.st.w       [s24, #0], v0
    s.addi       s24, s13, #7104
    s.addi       s29, s13, #3008
    v.ld.w       v0, [s28, #0]
    s.movz       s28, #0
    v.st.w       [s16, #0], v0
    s.movz       s16, #0
    v.ld.w       v0, [s25, #0]
    s.movz       s25, #1
    v.st.w       [s19, #0], v0
    s.movz       s19, #1
    v.ld.w       v0, [s27, #0]
    s.movz       s27, #2
    v.st.w       [s7, #0], v0
    s.movz       s7, #2
    v.ld.w       v0, [s18, #0]
    s.movz       s18, #3
    v.st.w       [s26, #0], v0
    s.movz       s26, #3
    v.ld.w       v0, [s20, #0]
    s.movz       s20, #4
    v.st.w       [s21, #0], v0
    s.movz       s21, #4
    v.ld.w       v0, [s23, #0]
    s.movz       s23, #5
    v.st.w       [s22, #0], v0
    s.movz       s22, #5
    v.ld.w       v0, [s24, #0]
    s.movz       s24, #6
    v.st.w       [s29, #0], v0
    fence.acq_rel.device
    a.vread      v0, a4, s28
    s.movz       s28, #6
    a.vwrite     a0, s16, v0
    a.vread      v0, a4, s25
    s.movz       s16, #7
    a.vwrite     a0, s19, v0
    a.vread      v0, a4, s27
    s.movz       s19, #7
    a.vwrite     a0, s7, v0
    a.vread      v0, a4, s18
    s.movz       s7, #8
    a.vwrite     a0, s26, v0
    a.vread      v0, a4, s20
    s.movz       s18, #8
    a.vwrite     a0, s21, v0
    a.vread      v0, a4, s23
    s.movz       s20, #9
    a.vwrite     a0, s22, v0
    a.vread      v0, a4, s24
    s.movz       s21, #9
    a.vwrite     a0, s28, v0
    a.vread      v0, a4, s16
    s.movz       s16, #10
    a.vwrite     a0, s19, v0
    a.vread      v0, a4, s7
    s.movz       s7, #10
    a.vwrite     a0, s18, v0
    a.vread      v0, a4, s20
    s.movz       s18, #11
    a.vwrite     a0, s21, v0
    a.vread      v0, a4, s16
    s.movz       s16, #11
    a.vwrite     a0, s7, v0
    a.vread      v0, a4, s18
    s.movz       s7, #12
    a.vwrite     a0, s16, v0
    s.movz       s16, #12
    a.vread      v0, a4, s7
    s.movz       s7, #13
    a.vwrite     a0, s16, v0
    s.movz       s16, #13
    a.vread      v0, a4, s7
    s.movz       s7, #14
    a.vwrite     a0, s16, v0
    s.movz       s16, #14
    a.vread      v0, a4, s7
    s.movz       s7, #15
    a.vwrite     a0, s16, v0
    s.movz       s16, #15
    a.vread      v0, a4, s7
    s.add        s7, s12, s1
    s.movz       s18, #1
    a.vwrite     a0, s16, v0
    s.mov        s12, s7
    br.nz        s18, for_6
endfor_7:
    s.movz       s2, #0
    s.mul        s3, s10, s15
    s.muli       s6, s5, #4                      // a runtime tile origin, x4
    s.movz       s7, #0
    s.add        s8, s2, s5                      // the tile origin
    s.muli       s2, s4, #1024                   // a runtime tile origin, x1024
    s.add        s5, s7, s4                      // the tile origin
    v.splat      v0, s8
    s.movz       s4, #256
    s.muli       s7, s3, #4                      // a runtime tile origin, x4
    v.splat      v1, s5
    v.add        v4, v2, v0
    v.splat      v0, s4
    s.addi       s3, s5, #1
    s.add        s4, s11, s6                     // the tile origin
    v.splat      v2, s10
    v.splat      v5, s1
    v.cmp.lt     p1, v1, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s3
    s.addi       s1, s5, #2
    s.add        s3, s4, s2                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    p.and        p3, p1, p2
    v.cmp.lt     p1, v2, v5
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s1
    s.addi       s1, s5, #3
    s.add        s4, s3, s7                      // the tile origin
    a.vread      v1, a0, s2
    p.and        p5, p3, p1
    s.movz       s2, #1
    p.and        p3, p4, p2
    v.splat      v2, s1
    s.addi       s1, s5, #4
    @p5 v.st.w       [s4, #0], v1
    v.cmp.lt     p4, v0, v3
    a.vread      v0, a0, s2
    s.addi       s2, s4, #1024                   // row 1
    p.and        p5, p3, p1
    s.movz       s3, #2
    p.and        p3, p4, p2
    v.splat      v1, s1
    s.addi       s1, s5, #5
    s.addi       s6, s4, #2048                   // row 2
    @p5 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s3
    p.and        p5, p3, p1
    s.movz       s2, #3
    p.and        p3, p4, p2
    v.splat      v2, s1
    s.addi       s1, s5, #6
    s.addi       s3, s4, #3072                   // row 3
    p.and        p4, p3, p1
    @p5 v.st.w       [s6, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s2
    s.movz       s2, #4
    p.and        p5, p3, p2
    v.splat      v1, s1
    s.addi       s1, s5, #7
    s.addi       s6, s4, #4096                   // row 4
    p.and        p3, p5, p1
    s.movz       s7, #5
    @p4 v.st.w       [s3, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s2
    p.and        p5, p4, p2
    v.splat      v2, s1
    s.addi       s1, s5, #8
    s.addi       s2, s4, #5120                   // row 5
    p.and        p4, p5, p1
    s.movz       s3, #6
    v.splat      v4, s1
    @p3 v.st.w       [s6, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s7
    p.and        p5, p3, p2
    s.addi       s1, s5, #9
    s.addi       s6, s4, #6144                   // row 6
    p.and        p3, p5, p1
    s.movz       s7, #7
    v.splat      v1, s1
    s.addi       s1, s5, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s3
    p.and        p5, p4, p2
    s.addi       s2, s4, #7168                   // row 7
    p.and        p4, p5, p1
    s.movz       s3, #8
    v.splat      v2, s1
    s.addi       s1, s5, #11
    s.addi       s8, s4, #8192                   // row 8
    @p3 v.st.w       [s6, #0], v0
    v.cmp.lt     p3, v4, v3
    a.vread      v0, a0, s7
    p.and        p5, p3, p2
    s.movz       s6, #9
    p.and        p3, p5, p1
    v.splat      v4, s1
    s.addi       s1, s5, #12
    s.addi       s7, s4, #9216                   // row 9
    s.movz       s9, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v1, v3
    a.vread      v0, a0, s3
    p.and        p5, p4, p2
    v.splat      v1, s1
    p.and        p4, p5, p1
    s.addi       s1, s5, #13
    s.addi       s2, s4, #10240                  // row 10
    s.movz       s3, #11
    v.splat      v5, s1
    @p3 v.st.w       [s8, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s6
    p.and        p5, p3, p2
    s.addi       s1, s5, #14
    p.and        p3, p5, p1
    s.addi       s6, s4, #11264                  // row 11
    s.movz       s8, #12
    v.splat      v2, s1
    s.addi       s1, s4, #12288                  // row 12
    @p4 v.st.w       [s7, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    s.addi       s7, s5, #15
    p.and        p4, p5, p1
    s.movz       s5, #13
    v.splat      v4, s7
    s.addi       s7, s4, #13312                  // row 13
    s.movz       s9, #14
    @p3 v.st.w       [s2, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s3
    p.and        p5, p3, p2
    s.addi       s2, s4, #14336                  // row 14
    p.and        p3, p5, p1
    s.movz       s3, #15
    s.addi       s10, s4, #15360                 // row 15
    @p4 v.st.w       [s6, #0], v0
    v.cmp.lt     p4, v5, v3
    a.vread      v0, a0, s8
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s5
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s7, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    p.and        p2, p5, p1
    @p3 v.st.w       [s2, #0], v0
    a.vread      v0, a0, s3
    @p2 v.st.w       [s10, #0], v0
__rctx_next:
    exit
