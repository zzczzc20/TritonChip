    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // arg_B: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #512
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.st.d       [s6, #0], s3
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    s.st.d       [s6, #16], s1
    s.movz       s3, #256
    s.st.d       [s6, #48], s3
    s.movz       s7, #2
    s.st.d       [s6, #56], s7
    .li       s8, #68719476752
    s.st.d       [s6, #88], s8
    .li       s9, #8589934592
    s.st.d       [s6, #104], s9
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s6, arg_base
    s.ld.d       s10, [s6, #32]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s6, role_id
    s.movz       s11, #512
    s.mul        s12, s6, s11
    s.add        s6, s10, s12                    // this context's own scratch
    s.addi       s10, s6, #256                   // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.st.d       [s10, #0], s4
    s.st.d       [s10, #8], s1
    s.st.d       [s10, #16], s1
    s.st.d       [s10, #48], s3
    s.st.d       [s10, #56], s7
    s.st.d       [s10, #88], s8
    s.st.d       [s10, #104], s9
    fence.release.device
    td.load      d1, [s10]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #24
    s.movz       s3, #0
    s.cmp.lt     s4, s1, s3
    s.sub        s1, s3, s4
    .li       s4, #1431655766
    s.movz       s6, #4
    s.movz       s7, #1
    s.rdspecial  s8, role_id
    s.rdspecial  s9, npid.x
__rctx_program:
    s.cmp.lt     s10, s8, s3
    s.addi       s11, s3, #0
    s.sub        s12, s3, s10
    s.addi       s10, s3, #0
    s.xor        s13, s8, s12
    s.xor        s14, s12, s1
    s.sub        s15, s13, s12
    s.mul        s16, s15, s4
    s.mov        s11, s15
    s.lshri      s17, s16, #32
    s.sub        s16, s15, s17
    s.lshri      s18, s16, #1
    s.add        s16, s17, s18
    s.lshri      s17, s16, #4
    s.xor        s16, s17, s14
    s.sub        s17, s16, s14
    s.sub        s14, s6, s17
    s.min.s      s16, s14, s7
    s.cmp.lt     s14, s16, s3
    s.sub        s18, s3, s14
    s.xor        s14, s16, s18
    s.sub        s16, s14, s18
    s.cmp.eq     s14, s16, s7
    br.nz        s14, sdiv_done_1
    s.movz       s19, #0
    s.movz       s20, #31
    s.mov        s11, s19
    s.addi       s21, s20, #0
sdiv_2:
    s.lshr       s20, s15, s21
    s.shli       s22, s10, #1
    s.andi       s23, s20, #1
    s.shl        s20, s7, s21
    s.or         s24, s22, s23
    s.cmp.geu    s22, s24, s16
    s.sub        s23, s19, s22
    s.and        s22, s16, s23
    s.and        s25, s20, s23
    s.sub        s10, s24, s22
    s.or         s11, s11, s25
    s.subi       s21, s21, #1
    s.cmp.ge     s20, s21, s19
    br.nz        s20, sdiv_2
sdiv_done_1:
    s.sub        s11, s13, s12
    s.xor        s13, s10, s12
    s.mul        s10, s11, s4
    s.sub        s15, s13, s12
    s.addi       s13, s3, #0
    s.add        s19, s17, s15
    s.addi       s15, s3, #0
    s.lshri      s17, s10, #32
    s.sub        s10, s11, s17
    s.lshri      s20, s10, #1
    s.add        s10, s17, s20
    s.lshri      s17, s10, #4
    s.muli       s10, s17, #24
    s.sub        s17, s11, s10
    s.xor        s10, s17, s12
    s.sub        s11, s10, s12
    s.cmp.lt     s10, s11, s3
    s.sub        s12, s3, s10
    s.xor        s10, s11, s12
    s.sub        s11, s10, s12
    s.mov        s13, s11
    br.nz        s14, sdiv_done_3
    s.movz       s10, #0
    s.movz       s14, #31
    s.mov        s13, s10
    s.addi       s17, s14, #0
    s.movz       s14, #1
sdiv_4:
    s.lshr       s20, s11, s17
    s.shli       s21, s15, #1
    s.andi       s22, s20, #1
    s.shl        s20, s14, s17
    s.or         s23, s21, s22
    s.cmp.geu    s21, s23, s16
    s.sub        s22, s10, s21
    s.and        s21, s16, s22
    s.and        s24, s20, s22
    s.sub        s15, s23, s21
    s.or         s13, s13, s24
    s.subi       s17, s17, #1
    s.cmp.ge     s20, s17, s10
    br.nz        s20, sdiv_4
sdiv_done_3:
    s.xor        s10, s12, s18
    s.movz       s11, #16
    s.xor        s12, s13, s10
    .li       s13, #1431655766
    s.sub        s14, s12, s10
    s.mul        s10, s19, s11
    s.mul        s12, s14, s11
    s.movz       s14, #0
    s.movz       s15, #8
    s.addi       s16, s14, #0
    s.andi       s17, s10, #63
    s.mul        s18, s12, s13
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.lshri      s13, s18, #32
    s.sub        s18, s12, s13
    s.lshri      s19, s18, #1
    s.add        s18, s13, s19
    s.lshri      s13, s18, #8
    s.muli       s18, s13, #384
    s.sub        s13, s12, s18
for_5:
    s.cmp.ge     s18, s16, s15
    br.nz        s18, endfor_6
    s.mul        s18, s16, s11
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s19, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s20, s17                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s21, s18                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s20, s19
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s20, s13                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s21, s18                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s20, s19
    mb.wait      s19
gemm_pipe:
    mb.arm       s18, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s20, #1
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v56, v48, s18
    s.add        s16, s16, s7
    s.cmp.ge     s20, s16, s15
    br.nz        s20, gemm_pipe_drain0
    s.mul        s20, s16, s11
    w.def        w2, #40, #8                     // v40..v47
    mb.arm       s21, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s22, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s22, s17                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s23, s20                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w2, d0, s22, s21
    w.def        w3, #32, #8                     // v32..v39
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s22, s13                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s23, s20                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w3, d1, s22, s21
    mb.wait      s21
    mb.wait      s18
    mb.arm       s20, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v40, v32, s20
    s.add        s16, s16, s7
    s.cmp.ge     s22, s16, s15
    br.nz        s22, gemm_pipe_drain1
    s.mul        s22, s16, s11
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s23, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s24, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s25, s17                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s22                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s25, s23
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s25, s13                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s22                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s25, s23
    mb.wait      s23
    mb.wait      s20
    br.nz        s24, gemm_pipe
gemm_pipe_drain0:
    s.movz       s11, #1
    mb.wait      s18
    br.nz        s11, endfor_6
gemm_pipe_drain1:
    mb.wait      s20
endfor_6:
    s.add        s11, s14, s12                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s11
    s.add        s11, s14, s10                   // the tile origin
    s.movz       s13, #64
    s.movz       s15, #384
    s.muli       s16, s12, #2                    // a runtime tile origin, x2
    v.splat      v2, s11
    v.splat      v3, s13
    v.add        v4, v0, v1
    v.splat      v0, s15
    v.cmp.lt     p1, v2, v3
    s.add        s12, s2, s16                    // the tile origin
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    a.vread      v0, a0, s14
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s12, #0]
    s.addi       s13, s11, #1
    s.muli       s14, s10, #768                  // a runtime tile origin, x768
    v.splat      v2, s13
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.add        s10, s5, s16                    // the tile origin
    s.movz       s13, #1
    v.cmp.lt     p1, v2, v3
    s.add        s15, s10, s14                   // the tile origin
    p.and        p4, p1, p2
    s.addi       s10, s11, #2
    s.addi       s14, s15, #768                  // row 1
    v.splat      v2, s10
    s.movz       s10, #2
    s.addi       s16, s11, #3
    vf.cvt.f16.f32 v4, v1
    v.splat      v1, s16
    s.addi       s16, s15, #1536                 // row 2
    s.movz       s17, #3
    s.addi       s22, s11, #4
    vf.add       v5, v0, v4
    v.splat      v0, s22
    s.addi       s22, s15, #2304                 // row 3
    s.movz       s24, #4
    vf.cvt.f32.f16 v4, v5
    @p3 v.st.h       [s15, #0], v4
    a.vread      v4, a0, s13
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.addi       s13, s11, #5
    v.splat      v2, s13
    s.addi       s13, s15, #3072                 // row 4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p4 v.st.h       [s14, #0], v4
    a.vread      v4, a0, s10
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s10, #5
    s.addi       s14, s11, #6
    v.splat      v1, s14
    s.addi       s14, s15, #3840                 // row 5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p3 v.st.h       [s16, #0], v4
    a.vread      v4, a0, s17
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s16, #6
    s.addi       s17, s11, #7
    v.splat      v0, s17
    s.addi       s17, s15, #4608                 // row 6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p4 v.st.h       [s22, #0], v4
    a.vread      v4, a0, s24
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s22, #7
    s.addi       s24, s11, #8
    v.splat      v2, s24
    s.addi       s24, s15, #5376                 // row 7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p3 v.st.h       [s13, #0], v4
    a.vread      v4, a0, s10
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.movz       s10, #8
    s.addi       s13, s11, #9
    v.splat      v1, s13
    s.addi       s13, s15, #6144                 // row 8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p4 v.st.h       [s14, #0], v4
    a.vread      v4, a0, s16
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.movz       s14, #9
    s.addi       s16, s11, #10
    v.splat      v0, s16
    s.addi       s16, s15, #6912                 // row 9
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p3 v.st.h       [s17, #0], v4
    a.vread      v4, a0, s22
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.movz       s17, #10
    s.addi       s22, s11, #11
    v.splat      v2, s22
    s.addi       s22, s15, #7680                 // row 10
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p4 v.st.h       [s24, #0], v4
    a.vread      v4, a0, s10
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s10, #11
    s.addi       s24, s11, #12
    v.splat      v1, s24
    s.addi       s24, s15, #8448                 // row 11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p3 v.st.h       [s13, #0], v4
    a.vread      v4, a0, s14
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s13, #12
    s.addi       s14, s11, #13
    v.splat      v0, s14
    s.addi       s14, s15, #9216                 // row 12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p4 v.st.h       [s16, #0], v4
    a.vread      v4, a0, s17
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s16, #13
    s.addi       s17, s11, #14
    v.splat      v2, s17
    s.addi       s17, s15, #9984                 // row 13
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p3 v.st.h       [s22, #0], v4
    a.vread      v4, a0, s10
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.movz       s10, #14
    s.addi       s22, s11, #15
    s.addi       s11, s15, #10752                // row 14
    v.splat      v1, s22
    s.movz       s22, #15
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    s.addi       s25, s15, #11520                // row 15
    @p4 v.st.h       [s24, #0], v4
    a.vread      v4, a0, s13
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s12, #0]
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    @p3 v.st.h       [s14, #0], v4
    a.vread      v0, a0, s16
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s12, #0]
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    @p4 v.st.h       [s17, #0], v0
    a.vread      v0, a0, s10
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a0, s22
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s25, #0], v0
__rctx_next:
    s.addi       s10, s8, #2                     // the next program of this context: + 2
    s.cmp.lt     s11, s10, s9
    s.mov        s8, s10
    br.nz        s11, __rctx_program
    exit
