    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #512
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s2
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #128
    s.st.d       [s6, #48], s1
    s.movz       s1, #4
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s6, #512
    s.mul        s7, s1, s6
    s.add        s1, s2, s7                      // this context's own scratch
    s.addi       s2, s1, #256                    // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s2, #0], s3
    .li       s1, #2147483647
    s.st.d       [s2, #8], s1
    .li       s1, #2147483647
    s.st.d       [s2, #16], s1
    s.movz       s1, #64
    s.st.d       [s2, #48], s1
    s.movz       s1, #4
    s.st.d       [s2, #56], s1
    .li       s1, #68719476752
    s.st.d       [s2, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s2, #104], s1
    fence.release.device
    td.load      d1, [s2]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #1
    s.movz       s2, #0
    s.movz       s3, #0
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s10, #1
    s.sub        s11, s1, s4
    s.min.s      s12, s11, s1
    s.cmp.lt     s11, s4, s3
    s.sub        s3, s2, s11
    s.cmp.lt     s2, s12, s7
    s.sub        s7, s6, s2
    s.xor        s2, s4, s3
    s.sub        s6, s2, s3
    s.xor        s2, s12, s7
    s.sub        s11, s2, s7
    s.addi       s2, s8, #0
    s.addi       s7, s9, #0
    s.cmp.eq     s8, s11, s10
    s.mov        s2, s6
    br.nz        s8, sdiv_done_1
    s.movz       s8, #0
    s.movz       s9, #31
    s.mov        s2, s8
    s.addi       s8, s9, #0
sdiv_2:
    s.lshr       s9, s6, s8
    s.shli       s10, s7, #1
    s.andi       s13, s9, #1
    s.movz       s9, #0
    s.or         s14, s10, s13
    s.movz       s10, #1
    s.cmp.geu    s13, s14, s11
    s.shl        s15, s10, s8
    s.sub        s10, s9, s13
    s.subi       s9, s8, #1
    s.and        s13, s11, s10
    s.and        s16, s15, s10
    s.sub        s10, s14, s13
    s.or         s13, s2, s16
    s.mov        s7, s10
    s.mov        s2, s13
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s8, s9
    br.nz        s10, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s6, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s12, s2
    s.movz       s2, #0
    s.cmp.lt     s11, s6, s8
    s.sub        s8, s9, s10
    s.sub        s9, s2, s11
    s.xor        s2, s12, s8
    s.xor        s10, s7, s3
    s.xor        s7, s6, s9
    s.sub        s11, s2, s8
    s.movz       s2, #0
    s.movz       s12, #1
    s.sub        s13, s10, s3
    s.sub        s3, s7, s9
    s.movz       s7, #0
    s.addi       s10, s2, #0
    s.cmp.eq     s2, s11, s12
    s.add        s12, s4, s13
    s.addi       s4, s7, #0
    s.mov        s10, s3
    br.nz        s2, sdiv_done_3
    s.movz       s2, #0
    s.movz       s7, #31
    s.mov        s10, s2
    s.addi       s2, s7, #0
sdiv_4:
    s.lshr       s7, s3, s2
    s.shli       s13, s4, #1
    s.andi       s14, s7, #1
    s.movz       s7, #0
    s.or         s15, s13, s14
    s.movz       s13, #1
    s.cmp.geu    s14, s15, s11
    s.shl        s16, s13, s2
    s.sub        s13, s7, s14
    s.subi       s7, s2, #1
    s.and        s14, s11, s13
    s.and        s17, s16, s13
    s.sub        s13, s15, s14
    s.or         s14, s10, s17
    s.mov        s4, s13
    s.mov        s10, s14
    s.mov        s2, s7
    s.movz       s7, #0
    s.cmp.ge     s13, s2, s7
    br.nz        s13, sdiv_4
sdiv_done_3:
    s.xor        s2, s9, s8
    s.movz       s3, #16
    s.xor        s4, s10, s2
    s.mul        s7, s12, s3
    s.sub        s8, s4, s2
    v.splat      v0, s12
    s.mul        s2, s8, s3
    v.splat      v1, s6
    s.andi       s4, s7, #15
    v.splat      v2, s8
    v.splat      v3, s6
    s.andi       s8, s2, #15
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s7
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s2
    v.splat      v1, s4
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s8
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s9, #2
    s.addi       s10, s6, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s6, s10, s9
    br.nz        s6, endfor_6
    s.mul        s6, s10, s3
    w.def        w0, #48, #16                    // v48..v63
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.movi       v0, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s12, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s6                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w0, d0, s13, s11
    mb.wait      s11
    w.def        w1, #32, #16                    // v32..v47
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s6                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s8                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w1, d1, s14, s13
    mb.wait      s13
    v.extract    s6, v48, #0
    v.extract    s14, v48, #1
    v.splat      v1, s6
    v.splat      v2, s14
    v.extract    s6, v48, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v48, #3
    v.extract    s14, v48, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s14
    v.extract    s6, v48, #5
    v.extract    s14, v48, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s14
    v.extract    s6, v48, #7
    v.extract    s14, v48, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s14
    v.extract    s6, v48, #9
    v.extract    s14, v48, #10
    v.extract    s15, v48, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v48, #12
    v.extract    s16, v48, #13
    v.extract    s17, v48, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s14
    v.extract    s14, v48, #15
    v.splat      v6, s15
    s.movz       s15, #1
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s14
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s12, v1
    v.extract    s6, v49, #0
    v.extract    s12, v49, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v49, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v49, #3
    v.extract    s12, v49, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v49, #5
    v.extract    s12, v49, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v49, #7
    v.extract    s12, v49, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v49, #9
    v.extract    s12, v49, #10
    v.extract    s14, v49, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v49, #12
    v.extract    s16, v49, #13
    v.extract    s17, v49, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v49, #15
    v.splat      v6, s14
    s.movz       s14, #2
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s15, v1
    v.extract    s6, v50, #0
    v.extract    s12, v50, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v50, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v50, #3
    v.extract    s12, v50, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v50, #5
    v.extract    s12, v50, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v50, #7
    v.extract    s12, v50, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v50, #9
    v.extract    s12, v50, #10
    v.extract    s15, v50, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v50, #12
    v.extract    s16, v50, #13
    v.extract    s17, v50, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v50, #15
    v.splat      v6, s15
    s.movz       s15, #3
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s6, v51, #0
    v.extract    s12, v51, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v51, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v51, #3
    v.extract    s12, v51, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v51, #5
    v.extract    s12, v51, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v51, #7
    v.extract    s12, v51, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v51, #9
    v.extract    s12, v51, #10
    v.extract    s14, v51, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v51, #12
    v.extract    s16, v51, #13
    v.extract    s17, v51, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v51, #15
    v.splat      v6, s14
    s.movz       s14, #4
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s15, v1
    v.extract    s6, v52, #0
    v.extract    s12, v52, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v52, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v52, #3
    v.extract    s12, v52, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v52, #5
    v.extract    s12, v52, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v52, #7
    v.extract    s12, v52, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v52, #9
    v.extract    s12, v52, #10
    v.extract    s15, v52, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v52, #12
    v.extract    s16, v52, #13
    v.extract    s17, v52, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v52, #15
    v.splat      v6, s15
    s.movz       s15, #5
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s6, v53, #0
    v.extract    s12, v53, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v53, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v53, #3
    v.extract    s12, v53, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v53, #5
    v.extract    s12, v53, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v53, #7
    v.extract    s12, v53, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v53, #9
    v.extract    s12, v53, #10
    v.extract    s14, v53, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v53, #12
    v.extract    s16, v53, #13
    v.extract    s17, v53, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v53, #15
    v.splat      v6, s14
    s.movz       s14, #6
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s15, v1
    v.extract    s6, v54, #0
    v.extract    s12, v54, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v54, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v54, #3
    v.extract    s12, v54, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v54, #5
    v.extract    s12, v54, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v54, #7
    v.extract    s12, v54, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v54, #9
    v.extract    s12, v54, #10
    v.extract    s15, v54, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v54, #12
    v.extract    s16, v54, #13
    v.extract    s17, v54, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v54, #15
    v.splat      v6, s15
    s.movz       s15, #7
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s6, v55, #0
    v.extract    s12, v55, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v55, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v55, #3
    v.extract    s12, v55, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v55, #5
    v.extract    s12, v55, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v55, #7
    v.extract    s12, v55, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v55, #9
    v.extract    s12, v55, #10
    v.extract    s14, v55, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v55, #12
    v.extract    s16, v55, #13
    v.extract    s17, v55, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v55, #15
    v.splat      v6, s14
    s.movz       s14, #8
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s15, v1
    v.extract    s6, v56, #0
    v.extract    s12, v56, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v56, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v56, #3
    v.extract    s12, v56, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v56, #5
    v.extract    s12, v56, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v56, #7
    v.extract    s12, v56, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v56, #9
    v.extract    s12, v56, #10
    v.extract    s15, v56, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v56, #12
    v.extract    s16, v56, #13
    v.extract    s17, v56, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v56, #15
    v.splat      v6, s15
    s.movz       s15, #9
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s6, v57, #0
    v.extract    s12, v57, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v57, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v57, #3
    v.extract    s12, v57, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v57, #5
    v.extract    s12, v57, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v57, #7
    v.extract    s12, v57, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v57, #9
    v.extract    s12, v57, #10
    v.extract    s14, v57, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v57, #12
    v.extract    s16, v57, #13
    v.extract    s17, v57, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v57, #15
    v.splat      v6, s14
    s.movz       s14, #10
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s15, v1
    v.extract    s6, v58, #0
    v.extract    s12, v58, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v58, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v58, #3
    v.extract    s12, v58, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v58, #5
    v.extract    s12, v58, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v58, #7
    v.extract    s12, v58, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v58, #9
    v.extract    s12, v58, #10
    v.extract    s15, v58, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v58, #12
    v.extract    s16, v58, #13
    v.extract    s17, v58, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v58, #15
    v.splat      v6, s15
    s.movz       s15, #11
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s6, v59, #0
    v.extract    s12, v59, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v59, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v59, #3
    v.extract    s12, v59, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v59, #5
    v.extract    s12, v59, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v59, #7
    v.extract    s12, v59, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v59, #9
    v.extract    s12, v59, #10
    v.extract    s14, v59, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v59, #12
    v.extract    s16, v59, #13
    v.extract    s17, v59, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v59, #15
    v.splat      v6, s14
    s.movz       s14, #12
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s15, v1
    v.extract    s6, v60, #0
    v.extract    s12, v60, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v60, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v60, #3
    v.extract    s12, v60, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v60, #5
    v.extract    s12, v60, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v60, #7
    v.extract    s12, v60, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v60, #9
    v.extract    s12, v60, #10
    v.extract    s15, v60, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v60, #12
    v.extract    s16, v60, #13
    v.extract    s17, v60, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v60, #15
    v.splat      v6, s15
    s.movz       s15, #13
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s6, v61, #0
    v.extract    s12, v61, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v61, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v61, #3
    v.extract    s12, v61, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v61, #5
    v.extract    s12, v61, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v61, #7
    v.extract    s12, v61, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v61, #9
    v.extract    s12, v61, #10
    v.extract    s14, v61, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v61, #12
    v.extract    s16, v61, #13
    v.extract    s17, v61, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v61, #15
    v.splat      v6, s14
    s.movz       s14, #14
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s15, v1
    v.extract    s6, v62, #0
    v.extract    s12, v62, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v62, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v62, #3
    v.extract    s12, v62, #4
    v.splat      v4, s6
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v62, #5
    v.extract    s12, v62, #6
    v.splat      v3, s6
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s12
    v.extract    s6, v62, #7
    v.extract    s12, v62, #8
    v.splat      v5, s6
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s12
    v.extract    s6, v62, #9
    v.extract    s12, v62, #10
    v.extract    s15, v62, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s6
    v.extract    s6, v62, #12
    v.extract    s16, v62, #13
    v.extract    s17, v62, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s12
    v.extract    s12, v62, #15
    v.splat      v6, s15
    s.movz       s15, #15
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s6
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s16
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s17
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s12
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a1, s14, v1
    v.extract    s6, v63, #0
    v.extract    s12, v63, #1
    v.splat      v1, s6
    v.splat      v2, s12
    v.extract    s6, v63, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v0, s6
    v.extract    s6, v63, #3
    v.extract    s12, v63, #4
    v.splat      v1, s6
    vf.fma       v4, v2, v33, v3
    v.splat      v2, s12
    v.extract    s6, v63, #5
    v.extract    s12, v63, #6
    v.splat      v3, s6
    vf.fma       v5, v0, v34, v4
    v.splat      v0, s12
    v.extract    s6, v63, #7
    v.extract    s12, v63, #8
    v.splat      v4, s6
    vf.fma       v6, v1, v35, v5
    v.splat      v1, s12
    v.extract    s6, v63, #9
    v.extract    s12, v63, #10
    v.splat      v5, s6
    vf.fma       v7, v2, v36, v6
    v.splat      v2, s12
    v.extract    s6, v63, #11
    v.extract    s12, v63, #12
    v.extract    s14, v63, #13
    vf.fma       v6, v3, v37, v7
    v.splat      v3, s6
    v.extract    s6, v63, #14
    v.extract    s16, v63, #15
    v.splat      v7, s12
    vf.fma       v8, v0, v38, v6
    v.splat      v0, s14
    s.movz       s12, #0
    s.movz       s14, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s17, #0
    vf.fma       v6, v4, v39, v8
    v.splat      v4, s6
    s.movz       s6, #1
    s.movz       s18, #1
    vf.fma       v8, v1, v40, v6
    v.splat      v1, s16
    s.movz       s16, #1
    vf.fma       v6, v5, v41, v8
    vf.fma       v5, v2, v42, v6
    vf.fma       v2, v3, v43, v5
    vf.fma       v3, v7, v44, v2
    vf.fma       v2, v0, v45, v3
    vf.fma       v0, v4, v46, v2
    vf.fma       v2, v1, v47, v0
    a.vwrite     a1, s15, v2
    a.vread      v0, a0, s12
    a.vread      v1, a1, s14
    s.movz       s12, #2
    s.movz       s14, #2
    vf.add       v2, v0, v1
    s.movz       s15, #2
    a.vwrite     a2, s17, v2
    a.vread      v0, a0, s6
    a.vread      v1, a1, s18
    s.movz       s6, #3
    s.movz       s17, #3
    vf.add       v2, v0, v1
    s.movz       s18, #3
    a.vwrite     a2, s16, v2
    a.vread      v0, a0, s12
    a.vread      v1, a1, s14
    s.movz       s12, #4
    s.movz       s14, #4
    vf.add       v2, v0, v1
    s.movz       s16, #4
    a.vwrite     a2, s15, v2
    a.vread      v0, a0, s6
    a.vread      v1, a1, s17
    s.movz       s6, #5
    s.movz       s15, #5
    vf.add       v2, v0, v1
    s.movz       s17, #5
    a.vwrite     a2, s18, v2
    a.vread      v0, a0, s12
    a.vread      v1, a1, s14
    s.movz       s12, #6
    s.movz       s14, #6
    vf.add       v2, v0, v1
    s.movz       s18, #6
    a.vwrite     a2, s16, v2
    a.vread      v0, a0, s6
    a.vread      v1, a1, s15
    s.movz       s6, #7
    s.movz       s15, #7
    vf.add       v2, v0, v1
    s.movz       s16, #7
    a.vwrite     a2, s17, v2
    a.vread      v0, a0, s12
    a.vread      v1, a1, s14
    s.movz       s12, #8
    s.movz       s14, #8
    vf.add       v2, v0, v1
    s.movz       s17, #8
    a.vwrite     a2, s18, v2
    a.vread      v0, a0, s6
    a.vread      v1, a1, s15
    s.movz       s6, #9
    s.movz       s15, #9
    vf.add       v2, v0, v1
    s.movz       s18, #9
    a.vwrite     a2, s16, v2
    a.vread      v0, a0, s12
    a.vread      v1, a1, s14
    s.movz       s12, #10
    s.movz       s14, #10
    vf.add       v2, v0, v1
    s.movz       s16, #10
    a.vwrite     a2, s17, v2
    a.vread      v0, a0, s6
    a.vread      v1, a1, s15
    s.movz       s6, #11
    s.movz       s15, #11
    vf.add       v2, v0, v1
    s.movz       s17, #11
    a.vwrite     a2, s18, v2
    a.vread      v0, a0, s12
    a.vread      v1, a1, s14
    s.movz       s12, #12
    s.movz       s14, #12
    vf.add       v2, v0, v1
    s.movz       s18, #12
    a.vwrite     a2, s16, v2
    a.vread      v0, a0, s6
    a.vread      v1, a1, s15
    s.movz       s6, #13
    s.movz       s15, #13
    vf.add       v2, v0, v1
    s.movz       s16, #13
    a.vwrite     a2, s17, v2
    a.vread      v0, a0, s12
    a.vread      v1, a1, s14
    s.movz       s12, #14
    s.movz       s14, #14
    vf.add       v2, v0, v1
    s.movz       s17, #14
    a.vwrite     a2, s18, v2
    a.vread      v0, a0, s6
    a.vread      v1, a1, s15
    s.movz       s6, #15
    s.movz       s15, #15
    vf.add       v2, v0, v1
    s.movz       s18, #15
    a.vwrite     a2, s16, v2
    a.vread      v0, a0, s12
    a.vread      v1, a1, s14
    s.movz       s12, #0
    s.movz       s14, #0
    vf.add       v2, v0, v1
    s.movz       s16, #1
    a.vwrite     a2, s17, v2
    a.vread      v0, a0, s6
    a.vread      v1, a1, s15
    s.movz       s6, #1
    s.movz       s15, #2
    vf.add       v2, v0, v1
    s.movz       s17, #2
    a.vwrite     a2, s18, v2
    a.vread      v0, a2, s12
    s.movz       s12, #3
    s.movz       s18, #3
    a.vwrite     a0, s14, v0
    a.vread      v0, a2, s16
    s.movz       s14, #4
    s.movz       s16, #4
    a.vwrite     a0, s6, v0
    a.vread      v0, a2, s15
    s.movz       s6, #5
    s.movz       s15, #5
    a.vwrite     a0, s17, v0
    a.vread      v0, a2, s12
    s.movz       s12, #6
    s.movz       s17, #6
    a.vwrite     a0, s18, v0
    a.vread      v0, a2, s14
    s.movz       s14, #7
    s.movz       s18, #7
    a.vwrite     a0, s16, v0
    a.vread      v0, a2, s6
    s.movz       s6, #8
    s.movz       s16, #8
    a.vwrite     a0, s15, v0
    a.vread      v0, a2, s12
    s.movz       s12, #9
    s.movz       s15, #9
    a.vwrite     a0, s17, v0
    a.vread      v0, a2, s14
    s.movz       s14, #10
    s.movz       s17, #10
    a.vwrite     a0, s18, v0
    a.vread      v0, a2, s6
    s.movz       s6, #11
    s.movz       s18, #11
    a.vwrite     a0, s16, v0
    a.vread      v0, a2, s12
    s.movz       s12, #12
    s.movz       s16, #12
    a.vwrite     a0, s15, v0
    a.vread      v0, a2, s14
    s.movz       s14, #13
    s.movz       s15, #13
    a.vwrite     a0, s17, v0
    a.vread      v0, a2, s6
    s.movz       s6, #14
    s.movz       s17, #14
    a.vwrite     a0, s18, v0
    a.vread      v0, a2, s12
    s.movz       s12, #15
    s.movz       s18, #15
    a.vwrite     a0, s16, v0
    a.vread      v0, a2, s14
    s.add        s14, s10, s1
    s.movz       s16, #1
    a.vwrite     a0, s15, v0
    a.vread      v0, a2, s6
    a.vwrite     a0, s17, v0
    a.vread      v0, a2, s12
    a.vwrite     a0, s18, v0
    s.mov        s10, s14
    br.nz        s16, for_5
endfor_6:
    s.movz       s1, #0
    s.movz       s4, #0
    s.add        s6, s1, s2                      // the tile origin
    s.muli       s1, s2, #4                      // a runtime tile origin, x4
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    s.add        s2, s4, s7                      // the tile origin
    s.muli       s4, s7, #64                     // a runtime tile origin, x64
    v.splat      v2, s2
    v.splat      v3, s3
    v.add        v4, v0, v1
    v.splat      v0, s3
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    s.addi       s6, s2, #1
    s.add        s7, s5, s1                      // the tile origin
    a.vread      v1, a0, s3
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s6
    s.add        s1, s7, s4                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s3, #1
    s.addi       s4, s2, #2
    @p3 v.st.w       [s1, #0], v1
    a.vread      v1, a0, s3
    v.cmp.lt     p1, v0, v3
    v.splat      v0, s4
    s.addi       s3, s1, #64                     // row 1
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.addi       s5, s2, #3
    v.cmp.lt     p1, v0, v3
    v.splat      v0, s5
    s.addi       s5, s1, #128                    // row 2
    p.and        p4, p1, p2
    s.movz       s6, #3
    s.addi       s7, s2, #4
    s.addi       s8, s1, #192                    // row 3
    v.splat      v2, s7
    s.movz       s7, #4
    s.addi       s9, s2, #5
    @p3 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    v.splat      v0, s9
    s.addi       s3, s1, #256                    // row 4
    s.movz       s4, #5
    s.addi       s9, s2, #6
    v.splat      v4, s9
    s.addi       s9, s1, #320                    // row 5
    @p4 v.st.w       [s5, #0], v1
    a.vread      v1, a0, s6
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s5, #6
    s.addi       s6, s2, #7
    v.splat      v2, s6
    s.addi       s6, s1, #384                    // row 6
    @p3 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s7, #7
    s.addi       s8, s2, #8
    v.splat      v0, s8
    s.addi       s8, s1, #448                    // row 7
    @p4 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.movz       s3, #8
    s.addi       s4, s2, #9
    v.splat      v4, s4
    s.addi       s4, s1, #512                    // row 8
    @p3 v.st.w       [s9, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.movz       s5, #9
    s.addi       s9, s2, #10
    v.splat      v2, s9
    s.addi       s9, s1, #576                    // row 9
    @p4 v.st.w       [s6, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.movz       s6, #10
    s.addi       s7, s2, #11
    v.splat      v0, s7
    s.addi       s7, s1, #640                    // row 10
    @p3 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s3
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s8, s2, #12
    v.splat      v4, s8
    s.addi       s8, s1, #704                    // row 11
    @p4 v.st.w       [s4, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s4, #12
    s.addi       s5, s2, #13
    v.splat      v2, s5
    s.addi       s5, s1, #768                    // row 12
    @p3 v.st.w       [s9, #0], v1
    a.vread      v1, a0, s6
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s6, #13
    s.addi       s9, s2, #14
    s.addi       s10, s2, #15
    v.splat      v0, s9
    s.addi       s2, s1, #832                    // row 13
    v.splat      v5, s10
    s.movz       s9, #14
    @p4 v.st.w       [s7, #0], v1
    a.vread      v1, a0, s3
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.addi       s3, s1, #896                    // row 14
    s.movz       s7, #15
    s.addi       s10, s1, #960                   // row 15
    @p3 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p4 v.st.w       [s5, #0], v1
    a.vread      v1, a0, s6
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    @p3 v.st.w       [s2, #0], v1
    a.vread      v0, a0, s9
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    @p4 v.st.w       [s3, #0], v0
    a.vread      v0, a0, s7
    @p3 v.st.w       [s10, #0], v0
__rctx_next:
    exit
