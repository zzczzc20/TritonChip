    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s1, s2, #1920
    s.rdspecial  s2, arg_base
    s.ld.d       s6, [s2, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s2, s6, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s7, #0
    s.st.d       [s2, #0], s1
    s.movz       s7, #64
    s.st.d       [s2, #8], s7
    s.movz       s7, #2
    s.st.d       [s2, #48], s7
    s.movz       s7, #16
    s.st.d       [s2, #88], s7
    .li       s7, #4294967296
    s.st.d       [s2, #104], s7
    td.load      d0, [s2]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s2, s3, #1920
    s.addi       s3, s6, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 1)
    s.movz       s6, #0
    s.st.d       [s3, #0], s2
    s.movz       s6, #64
    s.st.d       [s3, #8], s6
    s.movz       s6, #2
    s.st.d       [s3, #48], s6
    s.movz       s6, #16
    s.st.d       [s3, #88], s6
    .li       s6, #4294967296
    s.st.d       [s3, #104], s6
    td.load      d1, [s3]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s3, #0
    s.movz       s6, #64
    s.movz       s7, #16
    s.addi       s8, s3, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s9, s8, s6
    br.nz        s9, endfor_2
    v.splat      v1, s8
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s8
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s9, #64
    s.movz       s10, #64
    s.muli       s11, s8, #2
    s.muli       s12, s8, #2
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s9
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s10
    v.cmp.ge     p1, v6, v1
    v.cmp.lt     p2, v6, v3
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    s.add        s9, s1, s11
    p.and        p5, p1, p2
    s.add        s10, s2, s12
    p.and        p1, p3, p4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v1, [s9, #0]
    v.splat      v3, s8
    v.movi       v4, #64
    v.movi       v5, #0
    v.add        v6, v3, v0
    s.add        s9, s8, s7
    s.movz       s11, #1
    v.cmp.lt     p2, v6, v4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s10, #0]
    vf.cvt.f16.f32 v4, v1
    vf.cvt.f16.f32 v1, v3
    vf.add       v3, v4, v1
    vf.mul       v1, v3, v3
    vf.add       v3, v2, v1
    @p2 v.sel        v1, v3, v2
    v.mov        v5, v1
    v.mov        v2, v5
    s.mov        s8, s9
    br.nz        s11, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    s.addi       s8, s3, #0
    vf.add       v3, v1, v2
for_3:
    s.cmp.ge     s3, s8, s6
    br.nz        s3, endfor_4
    .li       s3, #1115684864
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1065353216
    v.splat      v2, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #925353388
    v.splat      v4, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v1                          // ISA 8.8: <= 2**-22 relative
    v.splat      v6, s8
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v8, s8
    v.iota       v9                              // arange(0, VLEN)
    s.movz       s3, #64
    s.movz       s9, #64
    s.muli       s10, s8, #2
    s.muli       s11, s8, #2
    v.add        v10, v6, v7
    v.movi       v6, #0
    v.add        v7, v8, v9
    v.splat      v8, s3
    v.cmp.ge     p1, v10, v6
    v.movi       v6, #0
    v.cmp.lt     p2, v10, v8
    v.splat      v8, s9
    v.cmp.ge     p3, v7, v6
    s.add        s3, s1, s10
    v.cmp.lt     p4, v7, v8
    p.and        p5, p1, p2
    s.add        s9, s2, s11
    p.and        p1, p3, p4
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v6, [s3, #0]
    v.splat      v7, s8
    .li       s3, #1077936128
    v.splat      v8, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #64
    v.add        v10, v7, v0
    vf.fms       v7, v1, v5, v2
    .li       s3, #3204448256
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s3, s8, #1                      // element offset -> bytes (x2)
    v.cmp.lt     p2, v10, v9
    s.add        s10, s4, s3                     // &in_ptr2[...]
    vf.fms       v2, v5, v7, v5
    s.add        s11, s5, s3                     // &out_ptr1[...]
    s.add        s3, s8, s7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s9, #0]
    vf.neg       v9, v2                          // Newton step: r0*(2 - x*r0)
    vf.cvt.f16.f32 v2, v6
    s.movz       s9, #1
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v6, v9, v5
    vf.mul       v5, v3, v6                      // a/y as a refined reciprocal (ISA has no divide)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v6, [s10, #0]
    vf.add       v9, v5, v4
    vf.cvt.f16.f32 v4, v7
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    vf.add       v7, v2, v4
    vf.cvt.f16.f32 v2, v6
    vf.mul       v4, v5, v5
    vf.mul       v6, v5, v1
    vf.fms       v1, v9, v4, v8
    vf.mul       v4, v6, v1                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v1, v4, v5
    v.extract    s10, v1, #0
    v.splat      v1, s10
    vf.mul       v4, v7, v1
    vf.mul       v1, v4, v2
    vf.cvt.f32.f16 v2, v1
    @p2 v.st.h       [s11, #0], v2
    s.mov        s8, s3
    br.nz        s9, for_3
endfor_4:
    exit
    exit
