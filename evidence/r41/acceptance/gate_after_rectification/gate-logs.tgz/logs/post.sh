#!/bin/bash
# After the head RTL lanes (which build sim/build/tb_core.vvp), rerun make compiler strictly.
set -u
source ~/tc_env/env.sh
G=~/r41fix_gate; R=$G/head; L=$G/logs/head
P=~/tc_env/torchenv/bin/python; LLVM=~/tc_env/root/usr/lib/llvm-20
export R1_STRICT=1 PYTHONPATH=$R/python:$R/compiler/python:$R
while kill -0 $1 2>/dev/null; do sleep 30; done
stamp() { date -u +%FT%TZ; }
lane() { local n=$1; shift
  echo "# $(stamp) start $n: $*" > $L/$n.log
  ( cd $R && nice -n 10 "$@" ) >> $L/$n.log 2>&1; local rc=$?
  echo "# $(stamp) end $n exit $rc" >> $L/$n.log; echo "$n $rc" >> $L/exit_codes.txt; }
lane compiler-after-core make compiler PYTHON=$P LLVM_PREFIX=$LLVM
lane compiler-ir $P compiler/test/IR/run_ir_tests.py
echo "post finished $(stamp)" >> $L/run.txt
