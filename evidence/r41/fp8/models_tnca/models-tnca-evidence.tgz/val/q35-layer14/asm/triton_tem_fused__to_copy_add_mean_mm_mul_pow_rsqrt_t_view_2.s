    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #3072
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #2048                   // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s3
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #5120
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #2
    s.movz       s3, #0
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s1, s8
    s.sub        s8, s7, s9
    s.xor        s7, s1, s8
    s.sub        s9, s7, s8
    s.movz       s7, #6
    s.movz       s9, #1
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #1
    s.cmp.lt     s17, s4, s6
    s.sub        s6, s3, s17
    s.xor        s3, s4, s6
    s.sub        s17, s3, s6
    s.lshri      s3, s17, #1
    s.muli       s18, s3, #2
    s.sub        s19, s17, s18
    s.xor        s17, s6, s8
    s.xor        s6, s3, s17
    s.sub        s3, s6, s17
    s.sub        s6, s7, s3
    s.min.s      s7, s6, s9
    s.cmp.lt     s6, s4, s11
    s.sub        s8, s10, s6
    s.cmp.lt     s6, s7, s13
    s.sub        s10, s12, s6
    s.xor        s6, s4, s8
    s.sub        s11, s6, s8
    s.xor        s6, s7, s10
    s.sub        s12, s6, s10
    s.addi       s6, s14, #0
    s.addi       s10, s15, #0
    s.cmp.eq     s13, s12, s16
    s.mov        s6, s11
    br.nz        s13, sdiv_done_1
    s.movz       s13, #0
    s.movz       s14, #31
    s.mov        s6, s13
    s.addi       s13, s14, #0
sdiv_2:
    s.lshr       s14, s11, s13
    s.shli       s15, s10, #1
    s.andi       s16, s14, #1
    s.movz       s14, #0
    s.or         s17, s15, s16
    s.movz       s15, #1
    s.cmp.geu    s16, s17, s12
    s.shl        s18, s15, s13
    s.sub        s15, s14, s16
    s.subi       s14, s13, #1
    s.and        s16, s12, s15
    s.and        s19, s18, s15
    s.sub        s15, s17, s16
    s.or         s16, s6, s19
    s.mov        s10, s15
    s.mov        s6, s16
    s.mov        s13, s14
    s.movz       s14, #0
    s.cmp.ge     s15, s13, s14
    br.nz        s15, sdiv_2
sdiv_done_1:
    s.movz       s6, #0
    s.movz       s11, #0
    s.cmp.lt     s12, s4, s6
    s.movz       s6, #0
    s.sub        s13, s11, s12
    s.movz       s11, #0
    s.xor        s12, s4, s13
    s.movz       s4, #0
    s.sub        s14, s12, s13
    s.cmp.lt     s12, s7, s6
    s.lshri      s6, s14, #1
    s.movz       s15, #0
    s.muli       s16, s6, #2
    s.sub        s6, s4, s12
    s.movz       s4, #0
    s.cmp.lt     s12, s1, s15
    s.xor        s15, s7, s6
    s.sub        s7, s14, s16
    s.movz       s14, #0
    s.xor        s16, s7, s13
    s.xor        s7, s10, s8
    s.sub        s10, s16, s13
    s.sub        s13, s14, s12
    s.cmp.lt     s12, s10, s11
    s.sub        s11, s15, s6
    s.sub        s14, s4, s12
    s.movz       s4, #0
    s.xor        s12, s10, s14
    s.movz       s10, #1
    s.sub        s15, s7, s8
    s.xor        s7, s1, s13
    s.sub        s1, s12, s14
    s.movz       s8, #0
    s.addi       s12, s4, #0
    s.cmp.eq     s4, s11, s10
    s.add        s10, s3, s15
    s.sub        s3, s7, s13
    s.addi       s3, s8, #0
    s.mov        s12, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s7, #31
    s.mov        s12, s4
    s.addi       s4, s7, #0
sdiv_4:
    s.lshr       s7, s1, s4
    s.shli       s8, s3, #1
    s.andi       s13, s7, #1
    s.movz       s7, #0
    s.or         s15, s8, s13
    s.movz       s8, #1
    s.cmp.geu    s13, s15, s11
    s.shl        s16, s8, s4
    s.sub        s8, s7, s13
    s.subi       s7, s4, #1
    s.and        s13, s11, s8
    s.and        s17, s16, s8
    s.sub        s8, s15, s13
    s.or         s13, s12, s17
    s.mov        s3, s8
    s.mov        s12, s13
    s.mov        s4, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s4, s7
    br.nz        s8, sdiv_4
sdiv_done_3:
    s.xor        s1, s14, s6
    s.movz       s3, #16
    s.xor        s4, s12, s1
    s.mul        s6, s10, s3
    s.sub        s7, s4, s1
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s1, s7, s3
    s.movz       s4, #0
    v.splat      v1, s6
    v.movi       v2, #85
    v.add        v3, v1, v0
    v.movi       v1, #0
    v.splat      v4, s10
    v.splat      v5, s4
    v.splat      v6, s7
    v.splat      v7, s4
    v.splat      v8, s1
    v.sub        v9, v1, v3
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v2, v1
    v.cmp.ge     p3, v4, v5
    v.sub        v4, v1, v2
    v.cmp.ge     p3, v6, v7
    v.add        v5, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v3
    @p2 v.sel        v3, v4, v2
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s7, #31
idiv_5:
    v.splat      v6, s7
    v.shl        v7, v4, v0
    v.lshr       v8, v5, v6
    v.cmp.lt     p2, v4, v1
    v.and        v9, v8, v0
    v.shl        v8, v0, v6
    v.or         v6, v7, v9
    s.subi       s8, s7, #1
    v.cmp.geu    p3, v6, v3
    p.or         p4, p2, p3
    v.sub        v7, v6, v3
    @p4 v.sel        v9, v8, v1
    @p4 v.sel        v8, v7, v6
    v.or         v6, v2, v9
    v.mov        v4, v8
    v.mov        v2, v6
    s.mov        s7, s8
    s.movz       s8, #0
    s.cmp.ge     s10, s7, s8
    br.nz        s10, idiv_5
    s.andi       s7, s1, #31
    v.sub        v0, v1, v4
    v.splat      v1, s7
    v.iota       v2                              // arange(0, VLEN)
    @p1 v.sel        v3, v0, v4
    v.add        v0, v1, v2
    s.movz       s8, #160
    s.addi       s10, s4, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_6:
    s.cmp.ge     s11, s10, s8
    br.nz        s11, endfor_7
    s.mul        s11, s10, s3
    s.rdspecial  s12, arg_base
    s.ld.d       s13, [s12, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s12, role_id
    s.movz       s14, #3072
    s.mul        s15, s12, s14
    s.add        s12, s13, s15                   // this context's own scratch
    s.addi       s13, s12, #0
    v.splat      v0, s4
    s.movz       s14, #0
    s.add        s15, s14, s11                   // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s15
    v.add        v4, v1, v2
    v.extract    s14, v3, #0
    v.splat      v1, s14
    s.movz       s14, #2560
    v.splat      v2, s14
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s13, #0], v5
    s.addi       s14, s13, #64
    v.extract    s15, v3, #1
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #128
    v.extract    s15, v3, #2
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #192
    v.extract    s15, v3, #3
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #256
    v.extract    s15, v3, #4
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #320
    v.extract    s15, v3, #5
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #384
    v.extract    s15, v3, #6
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #448
    v.extract    s15, v3, #7
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #512
    v.extract    s15, v3, #8
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #576
    v.extract    s15, v3, #9
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #640
    v.extract    s15, v3, #10
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #704
    v.extract    s15, v3, #11
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #768
    v.extract    s15, v3, #12
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #832
    v.extract    s15, v3, #13
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #896
    v.extract    s15, v3, #14
    v.splat      v1, s15
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v5, v0, v1
    v.st.w       [s14, #0], v5
    s.addi       s14, s13, #960
    v.extract    s13, v3, #15
    v.splat      v1, s13
    v.mul        v5, v1, v2
    v.add        v1, v4, v5
    v.add        v2, v0, v1
    v.st.w       [s14, #0], v2
    fence.acq_rel.device
    s.addi       s13, s12, #1024
    s.addi       s14, s12, #0
    v.ld.w       v0, [s14, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s13, #0], v1
    s.addi       s14, s13, #64
    s.addi       s15, s12, #64
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #128
    s.addi       s15, s12, #128
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #192
    s.addi       s15, s12, #192
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #256
    s.addi       s15, s12, #256
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #320
    s.addi       s15, s12, #320
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #384
    s.addi       s15, s12, #384
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #448
    s.addi       s15, s12, #448
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #512
    s.addi       s15, s12, #512
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #576
    s.addi       s15, s12, #576
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #640
    s.addi       s15, s12, #640
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #704
    s.addi       s15, s12, #704
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #768
    s.addi       s15, s12, #768
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #832
    s.addi       s15, s12, #832
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #896
    s.addi       s15, s12, #896
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s13, #960
    s.addi       s13, s12, #960
    v.ld.w       v0, [s13, #0]
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    fence.acq_rel.device
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s13, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s11                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s14, s13
    mb.wait      s13
    s.addi       s11, s12, #2304                 // 512 bytes of repack scratch
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s14, s12, #1024
    v.ld.w       v0, [s14, #0]
    v.st.h       [s11, #0], v0
    s.addi       s14, s12, #1088
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #32                   // row 1
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1152
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #64                   // row 2
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1216
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #96                   // row 3
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1280
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #128                  // row 4
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1344
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #160                  // row 5
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1408
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #192                  // row 6
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1472
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #224                  // row 7
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1536
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #256                  // row 8
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1600
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #288                  // row 9
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1664
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #320                  // row 10
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1728
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #352                  // row 11
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1792
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #384                  // row 12
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1856
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #416                  // row 13
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1920
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #448                  // row 14
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #1984
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s11, #480                  // row 15
    v.st.h       [s14, #0], v0
    s.addi       s14, s12, #2816                 // TensorMap 1: a repacked tile
    s.movz       s12, #0
    s.st.d       [s14, #0], s11
    s.movz       s11, #16
    s.st.d       [s14, #8], s11
    s.movz       s11, #16
    s.st.d       [s14, #16], s11
    s.movz       s11, #32
    s.st.d       [s14, #48], s11
    s.movz       s11, #2
    s.st.d       [s14, #56], s11
    .li       s11, #68719476752
    s.st.d       [s14, #88], s11
    .li       s11, #1108101562368
    s.st.d       [s14, #104], s11
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s11, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s12, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s14, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s11                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s14, s12
    mb.wait      s12
    mb.arm       s11, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v48, v56, s11
    mb.wait      s11
    s.add        s14, s10, s9
    s.mov        s10, s14
    s.movz       s14, #1
    br.nz        s14, for_6
endfor_7:
    s.movz       s2, #0
    s.muli       s3, s1, #2                      // a runtime tile origin, x2
    s.movz       s4, #0
    s.add        s7, s2, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    s.muli       s2, s6, #64                     // a runtime tile origin, x64
    s.add        s8, s4, s6                      // the tile origin
    s.movz       s4, #85
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    s.movz       s6, #32
    a.vread      v2, a0, s1
    v.splat      v3, s8
    v.splat      v4, s4
    v.add        v5, v0, v1
    v.splat      v0, s6
    s.add        s1, s5, s3                      // the tile origin
    vf.cvt.f32.bf16 v1, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s3, s1, s2                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s2, s8, #1
    @p3 v.st.h       [s3, #0], v1
    a.vread      v0, a0, s1
    v.splat      v1, s2
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #64                     // row 1
    p.and        p3, p1, p2
    s.movz       s2, #2
    s.addi       s4, s8, #2
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #128                    // row 2
    p.and        p3, p1, p2
    s.movz       s2, #3
    s.addi       s4, s8, #3
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #192                    // row 3
    p.and        p3, p1, p2
    s.movz       s2, #4
    s.addi       s4, s8, #4
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #256                    // row 4
    p.and        p3, p1, p2
    s.movz       s2, #5
    s.addi       s4, s8, #5
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #320                    // row 5
    p.and        p3, p1, p2
    s.movz       s2, #6
    s.addi       s4, s8, #6
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #384                    // row 6
    p.and        p3, p1, p2
    s.movz       s2, #7
    s.addi       s4, s8, #7
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #448                    // row 7
    p.and        p3, p1, p2
    s.movz       s2, #8
    s.addi       s4, s8, #8
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #512                    // row 8
    p.and        p3, p1, p2
    s.movz       s2, #9
    s.addi       s4, s8, #9
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #576                    // row 9
    p.and        p3, p1, p2
    s.movz       s2, #10
    s.addi       s4, s8, #10
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #640                    // row 10
    p.and        p3, p1, p2
    s.movz       s2, #11
    s.addi       s4, s8, #11
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #704                    // row 11
    p.and        p3, p1, p2
    s.movz       s2, #12
    s.addi       s4, s8, #12
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #768                    // row 12
    p.and        p3, p1, p2
    s.movz       s2, #13
    s.addi       s4, s8, #13
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #832                    // row 13
    p.and        p3, p1, p2
    s.movz       s2, #14
    s.addi       s4, s8, #14
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #896                    // row 14
    p.and        p3, p1, p2
    s.movz       s2, #15
    s.addi       s4, s8, #15
    @p3 v.st.h       [s1, #0], v2
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.bf16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #960                    // row 15
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
__rctx_next:
    exit
