# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-stage1/runs/harness-smoke-v5/primitives/inductor-cache/va/cvazm63vd5mjtt4ug55xjvocqhdydpecuohaf6bjnxhlbizugkvq.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => convert_element_type, mul
# Graph fragment:
#   %arg0_1 : Tensor "bf16[1, 8, 5, 256][10240, 1280, 256, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %convert_element_type : Tensor "f32[1, 8, 5, 256][10240, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[1, 8, 5, 256][10240, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type, 0.25), kwargs = {})
#   return %expand_2
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_0 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 102400}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_0(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 10240
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.full([1], 0.25, tl.float32)
    tmp3 = tmp1 * tmp2
    tl.store(out_ptr0 + (x0), tmp3, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-stage1/runs/harness-smoke-v5/primitives/inductor-cache/4h/c4houiqy2mlwyoik6joebwk53peqribjnvciqviey6reo2fvnzrl.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => clone, convert_element_type_1, expand, mul_1, permute, unsqueeze_2, view
# Graph fragment:
#   %arg1_1 : Tensor "bf16[1, 2, 5, 256][2560, 1280, 256, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %convert_element_type_1 : Tensor "f32[1, 2, 5, 256][2560, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg1_1, torch.float32), kwargs = {})
#   %unsqueeze_2 : Tensor "f32[1, 2, 1, 5, 256][2560, 1280, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 2), kwargs = {})
#   %expand : Tensor "f32[1, 2, 4, 5, 256][2560, 1280, 0, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_2, [1, 2, 4, 5, 256]), kwargs = {})
#   %clone : Tensor "f32[1, 2, 4, 5, 256][10240, 5120, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 8, 5, 256][10240, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 8, 5, 256]), kwargs = {})
#   %permute : Tensor "f32[1, 8, 256, 5][10240, 1280, 1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view, [0, 1, 3, 2]), kwargs = {})
#   %mul_1 : Tensor "f32[1, 8, 256, 5][10240, 1280, 1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute, 0.25), kwargs = {})
#   return %expand_3
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 81920}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 10240
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 5)
    x1 = ((xindex // 5) % 256)
    x2 = xindex // 1280
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x1 + 256*x0 + 1280*(x2 // 4)), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.full([1], 0.25, tl.float32)
    tmp3 = tmp1 * tmp2
    tl.store(out_ptr0 + (x3), tmp3, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-stage1/runs/harness-smoke-v5/primitives/inductor-cache/sy/csygeq7qx2zceczyvem7oy3pmwjhy5ur65k7ir66rtb2bmctrcxw.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => bmm, clone, convert_element_type, convert_element_type_1, expand, mul, mul_1, permute, unsqueeze_2, view, view_2, view_3
# Graph fragment:
#   %expand_2 : Tensor "f32[1, 8, 5, 256][10240, 1280, 256, 1]tnca:0" = PlaceHolder[target=expand_2]
#   %expand_3 : Tensor "f32[1, 8, 256, 5][10240, 1280, 5, 1]tnca:0" = PlaceHolder[target=expand_3]
#   %convert_element_type : Tensor "f32[1, 8, 5, 256][10240, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[1, 8, 5, 256][10240, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type, 0.25), kwargs = {})
#   %view_2 : Tensor "f32[8, 5, 256][1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [8, 5, 256]), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[1, 2, 5, 256][2560, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg1_1, torch.float32), kwargs = {})
#   %unsqueeze_2 : Tensor "f32[1, 2, 1, 5, 256][2560, 1280, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 2), kwargs = {})
#   %expand : Tensor "f32[1, 2, 4, 5, 256][2560, 1280, 0, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_2, [1, 2, 4, 5, 256]), kwargs = {})
#   %clone : Tensor "f32[1, 2, 4, 5, 256][10240, 5120, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 8, 5, 256][10240, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 8, 5, 256]), kwargs = {})
#   %permute : Tensor "f32[1, 8, 256, 5][10240, 1280, 1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view, [0, 1, 3, 2]), kwargs = {})
#   %mul_1 : Tensor "f32[1, 8, 256, 5][10240, 1280, 1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute, 0.25), kwargs = {})
#   %view_3 : Tensor "f32[8, 256, 5][1280, 1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_3, [8, 256, 5]), kwargs = {})
#   %bmm : Tensor "f32[8, 5, 5][25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_2, %view_3), kwargs = {})
#   return %bmm
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_2 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_2', 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_2(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 5
    N = 5
    K = 256
    BATCH = 8

    stride_aq = 1280
    stride_am = 256
    stride_ak = 1

    stride_bq = 1280
    stride_bk = 5
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 5*idx_m + 25*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-stage1/runs/harness-smoke-v5/primitives/inductor-cache/es/cesmfqjeusjzug6fw3psacwnulb2hp44vryoyitpogks36qe5433.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => add, any_1, eq, full_default, full_default_1, full_default_2, iota, iota_1, le, logical_and, logical_not, sub, unsqueeze, unsqueeze_1, view_4, where
# Graph fragment:
#   %bmm : Tensor "f32[8, 5, 5][25, 5, 1]tnca:0" = PlaceHolder[target=bmm]
#   %view_4 : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 8, 5, 5]), kwargs = {})
#   %iota : Tensor "i64[5][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (5,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze : Tensor "i64[1, 5][5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota, -2), kwargs = {})
#   %iota_1 : Tensor "i64[5][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (5,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze_1 : Tensor "i64[5, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota_1, -1), kwargs = {})
#   %sub : Tensor "i64[5, 5][5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%unsqueeze, %unsqueeze_1), kwargs = {})
#   %le : Tensor "b8[5, 5][5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.le.Scalar](args = (%sub, 0), kwargs = {})
#   %full_default : Tensor "b8[5, 5][5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([5, 5], True), kwargs = {dtype: torch.bool, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %logical_and : Tensor "b8[5, 5][5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_and.default](args = (%le, %full_default), kwargs = {})
#   %full_default_2 : Tensor "f32[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], 0.0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %full_default_1 : Tensor "f32[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %where : Tensor "f32[5, 5][5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_and, %full_default_2, %full_default_1), kwargs = {})
#   %add : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%view_4, %where), kwargs = {})
#   %eq : Tensor "b8[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%add, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq,), kwargs = {})
#   %any_1 : Tensor "b8[1, 8, 5, 1][40, 5, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   return %any_1
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_3 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 64}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*i1', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 80}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_3(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 40
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 5)
    tmp0 = tl.load(in_ptr0 + (5*x2), xmask, eviction_policy='evict_last')
    tmp15 = tl.load(in_ptr0 + (1 + 5*x2), xmask, eviction_policy='evict_last')
    tmp27 = tl.load(in_ptr0 + (2 + 5*x2), xmask, eviction_policy='evict_last')
    tmp39 = tl.load(in_ptr0 + (3 + 5*x2), xmask, eviction_policy='evict_last')
    tmp51 = tl.load(in_ptr0 + (4 + 5*x2), xmask, eviction_policy='evict_last')
    tmp1 = ((-1)*x0).to(tl.int64)
    tmp2 = (tmp1).to(tl.int64)
    tmp3 = tl.full([1], 0, tl.int64)
    tmp4 = tmp2 <= tmp3
    tmp5 = tl.full([1], True, tl.int1)
    tmp6 = tmp4 & tmp5
    tmp7 = tl.full([1], 0.0, tl.float32)
    tmp8 = tl.full([1], float("-inf"), tl.float32)
    tmp9 = tl.where(tmp6, tmp7, tmp8)
    tmp10 = tmp0 + tmp9
    tmp11 = tmp10 == tmp8
    tmp12 = tmp11 == 0
    tmp13 = tmp12.to(tl.int64)
    tmp14 = (tmp13 != 0)
    tmp16 = (1 + ((-1)*x0)).to(tl.int64)
    tmp17 = (tmp16).to(tl.int64)
    tmp18 = tmp17 <= tmp3
    tmp19 = tmp18 & tmp5
    tmp20 = tl.where(tmp19, tmp7, tmp8)
    tmp21 = tmp15 + tmp20
    tmp22 = tmp21 == tmp8
    tmp23 = tmp22 == 0
    tmp24 = tmp23.to(tl.int64)
    tmp25 = (tmp24 != 0)
    tmp26 = tmp14 | tmp25
    tmp28 = (2 + ((-1)*x0)).to(tl.int64)
    tmp29 = (tmp28).to(tl.int64)
    tmp30 = tmp29 <= tmp3
    tmp31 = tmp30 & tmp5
    tmp32 = tl.where(tmp31, tmp7, tmp8)
    tmp33 = tmp27 + tmp32
    tmp34 = tmp33 == tmp8
    tmp35 = tmp34 == 0
    tmp36 = tmp35.to(tl.int64)
    tmp37 = (tmp36 != 0)
    tmp38 = tmp26 | tmp37
    tmp40 = (3 + ((-1)*x0)).to(tl.int64)
    tmp41 = (tmp40).to(tl.int64)
    tmp42 = tmp41 <= tmp3
    tmp43 = tmp42 & tmp5
    tmp44 = tl.where(tmp43, tmp7, tmp8)
    tmp45 = tmp39 + tmp44
    tmp46 = tmp45 == tmp8
    tmp47 = tmp46 == 0
    tmp48 = tmp47.to(tl.int64)
    tmp49 = (tmp48 != 0)
    tmp50 = tmp38 | tmp49
    tmp52 = (4 + ((-1)*x0)).to(tl.int64)
    tmp53 = (tmp52).to(tl.int64)
    tmp54 = tmp53 <= tmp3
    tmp55 = tmp54 & tmp5
    tmp56 = tl.where(tmp55, tmp7, tmp8)
    tmp57 = tmp51 + tmp56
    tmp58 = tmp57 == tmp8
    tmp59 = tmp58 == 0
    tmp60 = tmp59.to(tl.int64)
    tmp61 = (tmp60 != 0)
    tmp62 = tmp50 | tmp61
    tl.store(out_ptr0 + (x2), tmp62, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-stage1/runs/harness-smoke-v5/primitives/inductor-cache/pv/cpv6ozo4dkbyzkott2fz6kjp7mk45lzsavy4qher5bomgscn7r2x.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => add, amax, exp, full_default, full_default_1, full_default_2, iota, iota_1, le, logical_and, sub, sub_1, unsqueeze, unsqueeze_1, view_4, where
# Graph fragment:
#   %bmm : Tensor "f32[8, 5, 5][25, 5, 1]tnca:0" = PlaceHolder[target=bmm]
#   %sub_1 : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0" = PlaceHolder[target=sub_1]
#   %view_4 : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 8, 5, 5]), kwargs = {})
#   %iota : Tensor "i64[5][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (5,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze : Tensor "i64[1, 5][5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota, -2), kwargs = {})
#   %iota_1 : Tensor "i64[5][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (5,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze_1 : Tensor "i64[5, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota_1, -1), kwargs = {})
#   %sub : Tensor "i64[5, 5][5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%unsqueeze, %unsqueeze_1), kwargs = {})
#   %le : Tensor "b8[5, 5][5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.le.Scalar](args = (%sub, 0), kwargs = {})
#   %full_default : Tensor "b8[5, 5][5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([5, 5], True), kwargs = {dtype: torch.bool, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %logical_and : Tensor "b8[5, 5][5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_and.default](args = (%le, %full_default), kwargs = {})
#   %full_default_2 : Tensor "f32[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], 0.0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %full_default_1 : Tensor "f32[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %where : Tensor "f32[5, 5][5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_and, %full_default_2, %full_default_1), kwargs = {})
#   %add : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%view_4, %where), kwargs = {})
#   %amax : Tensor "f32[1, 8, 5, 1][40, 5, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%add, [-1], True), kwargs = {})
#   %sub_1 : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%add, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub_1,), kwargs = {})
#   return %sub_1,%exp
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_4 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_4', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 2400}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_4(in_out_ptr0, in_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 200
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x3 = xindex
    x0 = (xindex % 5)
    x1 = ((xindex // 5) % 5)
    x4 = xindex // 5
    tmp0 = tl.load(in_ptr0 + (x3), xmask)
    tmp11 = tl.load(in_ptr0 + (5*x4), xmask, eviction_policy='evict_last')
    tmp18 = tl.load(in_ptr0 + (1 + 5*x4), xmask, eviction_policy='evict_last')
    tmp26 = tl.load(in_ptr0 + (2 + 5*x4), xmask, eviction_policy='evict_last')
    tmp34 = tl.load(in_ptr0 + (3 + 5*x4), xmask, eviction_policy='evict_last')
    tmp42 = tl.load(in_ptr0 + (4 + 5*x4), xmask, eviction_policy='evict_last')
    tmp1 = (x0 + ((-1)*x1)).to(tl.int64)
    tmp2 = (tmp1).to(tl.int64)
    tmp3 = tl.full([1], 0, tl.int64)
    tmp4 = tmp2 <= tmp3
    tmp5 = tl.full([1], True, tl.int1)
    tmp6 = tmp4 & tmp5
    tmp7 = tl.full([1], 0.0, tl.float32)
    tmp8 = tl.full([1], float("-inf"), tl.float32)
    tmp9 = tl.where(tmp6, tmp7, tmp8)
    tmp10 = tmp0 + tmp9
    tmp12 = ((-1)*x1).to(tl.int64)
    tmp13 = (tmp12).to(tl.int64)
    tmp14 = tmp13 <= tmp3
    tmp15 = tmp14 & tmp5
    tmp16 = tl.where(tmp15, tmp7, tmp8)
    tmp17 = tmp11 + tmp16
    tmp19 = (1 + ((-1)*x1)).to(tl.int64)
    tmp20 = (tmp19).to(tl.int64)
    tmp21 = tmp20 <= tmp3
    tmp22 = tmp21 & tmp5
    tmp23 = tl.where(tmp22, tmp7, tmp8)
    tmp24 = tmp18 + tmp23
    tmp25 = tl.maximum(tmp17, tmp24, tl.PropagateNan.ALL)
    tmp27 = (2 + ((-1)*x1)).to(tl.int64)
    tmp28 = (tmp27).to(tl.int64)
    tmp29 = tmp28 <= tmp3
    tmp30 = tmp29 & tmp5
    tmp31 = tl.where(tmp30, tmp7, tmp8)
    tmp32 = tmp26 + tmp31
    tmp33 = tl.maximum(tmp25, tmp32, tl.PropagateNan.ALL)
    tmp35 = (3 + ((-1)*x1)).to(tl.int64)
    tmp36 = (tmp35).to(tl.int64)
    tmp37 = tmp36 <= tmp3
    tmp38 = tmp37 & tmp5
    tmp39 = tl.where(tmp38, tmp7, tmp8)
    tmp40 = tmp34 + tmp39
    tmp41 = tl.maximum(tmp33, tmp40, tl.PropagateNan.ALL)
    tmp43 = (4 + ((-1)*x1)).to(tl.int64)
    tmp44 = (tmp43).to(tl.int64)
    tmp45 = tmp44 <= tmp3
    tmp46 = tmp45 & tmp5
    tmp47 = tl.where(tmp46, tmp7, tmp8)
    tmp48 = tmp42 + tmp47
    tmp49 = tl.maximum(tmp41, tmp48, tl.PropagateNan.ALL)
    tmp50 = tmp10 - tmp49
    tmp51 = libdevice.exp(tmp50)
    tl.store(in_out_ptr0 + (x3), tmp51, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-stage1/runs/harness-smoke-v5/primitives/inductor-cache/wu/cwuwox2funumrkykashqzt4qghrfx7zcbluqglwp57lolquaasuf.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => div, full_default_3, logical_not_1, sum_1, where_1
# Graph fragment:
#   %any_1 : Tensor "b8[1, 8, 5, 1][40, 5, 1, 40]tnca:0" = PlaceHolder[target=any_1]
#   %exp : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0" = PlaceHolder[target=exp]
#   %logical_not_1 : Tensor "b8[1, 8, 5, 1][40, 5, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_3 : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 8, 5, 5], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %sum_1 : Tensor "f32[1, 8, 5, 1][40, 5, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   %div : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_1 : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_3, %div), kwargs = {})
#   return %expand_4
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_5 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 2440}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_5(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 200
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = xindex // 5
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x1), xmask, eviction_policy='evict_last').to(tl.int1)
    tmp2 = tl.load(in_ptr1 + (x2), xmask)
    tmp3 = tl.load(in_ptr1 + (5*x1), xmask, eviction_policy='evict_last')
    tmp4 = tl.load(in_ptr1 + (1 + 5*x1), xmask, eviction_policy='evict_last')
    tmp6 = tl.load(in_ptr1 + (2 + 5*x1), xmask, eviction_policy='evict_last')
    tmp8 = tl.load(in_ptr1 + (3 + 5*x1), xmask, eviction_policy='evict_last')
    tmp10 = tl.load(in_ptr1 + (4 + 5*x1), xmask, eviction_policy='evict_last')
    tmp1 = tmp0 == 0
    tmp5 = tmp3 + tmp4
    tmp7 = tmp5 + tmp6
    tmp9 = tmp7 + tmp8
    tmp11 = tmp9 + tmp10
    tmp12 = (tmp2 / tmp11)
    tmp13 = tl.full([1], 0.0, tl.float32)
    tmp14 = tl.where(tmp1, tmp13, tmp12)
    tl.store(out_ptr0 + (x2), tmp14, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-stage1/runs/harness-smoke-v5/primitives/inductor-cache/vo/cvojs4qutftuam62vlga4tf42zvryyiv554rtg7x4hhqowxr5mcj.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => clone_1, convert_element_type_2, expand_1, unsqueeze_3
# Graph fragment:
#   %arg2_1 : Tensor "bf16[1, 2, 5, 256][2560, 1280, 256, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %convert_element_type_2 : Tensor "f32[1, 2, 5, 256][2560, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg2_1, torch.float32), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[1, 2, 1, 5, 256][2560, 1280, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 2), kwargs = {})
#   %expand_1 : Tensor "f32[1, 2, 4, 5, 256][2560, 1280, 0, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [1, 2, 4, 5, 256]), kwargs = {})
#   %clone_1 : Tensor "f32[1, 2, 4, 5, 256][10240, 5120, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_1
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 87040}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 10240
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 1280)
    x2 = xindex // 5120
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 1280*x2), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp1, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-stage1/runs/harness-smoke-v5/primitives/inductor-cache/ma/cmagyje66xwcvfwh52wkpdhbler7wvgbei5x4o6cryrivpd4nna2.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => bmm_1, clone_1, convert_element_type_2, div, expand_1, full_default_3, logical_not_1, sum_1, unsqueeze_3, view_1, view_5, view_6, where_1
# Graph fragment:
#   %expand_4 : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0" = PlaceHolder[target=expand_4]
#   %clone_1 : Tensor "f32[1, 2, 4, 5, 256][10240, 5120, 1280, 256, 1]tnca:0" = PlaceHolder[target=clone_1]
#   %logical_not_1 : Tensor "b8[1, 8, 5, 1][40, 5, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_3 : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 8, 5, 5], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %sum_1 : Tensor "f32[1, 8, 5, 1][40, 5, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   %div : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_1 : Tensor "f32[1, 8, 5, 5][200, 25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_3, %div), kwargs = {})
#   %view_5 : Tensor "f32[8, 5, 5][25, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_4, [8, 5, 5]), kwargs = {})
#   %convert_element_type_2 : Tensor "f32[1, 2, 5, 256][2560, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg2_1, torch.float32), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[1, 2, 1, 5, 256][2560, 1280, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 2), kwargs = {})
#   %expand_1 : Tensor "f32[1, 2, 4, 5, 256][2560, 1280, 0, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [1, 2, 4, 5, 256]), kwargs = {})
#   %clone_1 : Tensor "f32[1, 2, 4, 5, 256][10240, 5120, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 8, 5, 256][10240, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_1, [1, 8, 5, 256]), kwargs = {})
#   %view_6 : Tensor "f32[8, 5, 256][1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_5, [8, 5, 256]), kwargs = {})
#   %bmm_1 : Tensor "f32[8, 5, 256][1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_5, %view_6), kwargs = {})
#   return %bmm_1
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_7 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_7', 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': False, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_7(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = False
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 5
    N = 256
    K = 5
    BATCH = 8

    stride_aq = 25
    stride_am = 5
    stride_ak = 1

    stride_bq = 1280
    stride_bk = 256
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 256*idx_m + 1280*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-stage1/runs/harness-smoke-v5/primitives/inductor-cache/by/cbys52ij272nqbjivogjcayktjlqmweaycevs6bo7drt4u2tlgis.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => clone_2, convert_element_type_3, permute_1, view_7
# Graph fragment:
#   %bmm_1 : Tensor "f32[8, 5, 256][1280, 256, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %view_7 : Tensor "f32[1, 8, 5, 256][10240, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 8, 5, 256]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 8, 5, 256][10240, 1280, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_7, torch.bfloat16), kwargs = {})
#   %permute_1 : Tensor "bf16[5, 1, 8, 256][256, 10240, 1280, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_3, [2, 0, 1, 3]), kwargs = {})
#   %clone_2 : Tensor "bf16[5, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute_1,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_2
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_8 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 81920}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_8(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 10240
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 256)
    x1 = ((xindex // 256) % 8)
    x2 = xindex // 2048
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 256*x2 + 1280*x1), xmask)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp1, xmask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1 = args
        args.clear()
        assert_size_stride(arg0_1, (1, 8, 5, 256), (10240, 1280, 256, 1), 'input')
        buf0 = empty_strided((1, 8, 5, 256), (10240, 1280, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_0.run(arg0_1, buf0, 10240, stream=raw_stream0)
        del arg0_1
        assert_size_stride(arg1_1, (1, 2, 5, 256), (2560, 1280, 256, 1), 'input')
        buf1 = empty_strided((1, 8, 256, 5), (10240, 1280, 5, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1.run(arg1_1, buf1, 10240, stream=raw_stream0)
        del arg1_1
        buf2 = empty_strided((8, 5, 5), (25, 5, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_2.run(buf0, buf1, buf2, 1, 8, 1, stream=raw_stream0)
        del buf0
        buf3 = empty_strided((1, 8, 5, 1), (40, 5, 1, 40), device='tnca', dtype=torch.bool)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_3.run(buf2, buf3, 40, stream=raw_stream0)
        buf4 = empty_strided((1, 8, 5, 5), (200, 25, 5, 1), device='tnca', dtype=torch.float32)
        buf5 = buf4; del buf4  # reuse
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_4.run(buf5, buf2, 200, stream=raw_stream0)
        buf6 = reinterpret_tensor(buf2, (1, 8, 5, 5), (200, 25, 5, 1), 0); del buf2  # reuse
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_5.run(buf3, buf5, buf6, 200, stream=raw_stream0)
        del buf3
        del buf5
        assert_size_stride(arg2_1, (1, 2, 5, 256), (2560, 1280, 256, 1), 'input')
        buf7 = reinterpret_tensor(buf1, (1, 2, 4, 5, 256), (10240, 5120, 1280, 256, 1), 0); del buf1  # reuse
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6.run(arg2_1, buf7, 10240, stream=raw_stream0)
        del arg2_1
        buf8 = empty_strided((8, 5, 256), (1280, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_7.run(buf6, buf7, buf8, 16, 8, 1, stream=raw_stream0)
        del buf6
        del buf7
        buf9 = empty_strided((5, 1, 8, 256), (2048, 1, 256, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_8.run(buf8, buf9, 10240, stream=raw_stream0)
        return (reinterpret_tensor(buf9, (1, 8, 5, 256), (2048, 256, 2048, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 8, 5, 256), (10240, 1280, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((1, 2, 5, 256), (2560, 1280, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg2_1 = rand_strided((1, 2, 5, 256), (2560, 1280, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
