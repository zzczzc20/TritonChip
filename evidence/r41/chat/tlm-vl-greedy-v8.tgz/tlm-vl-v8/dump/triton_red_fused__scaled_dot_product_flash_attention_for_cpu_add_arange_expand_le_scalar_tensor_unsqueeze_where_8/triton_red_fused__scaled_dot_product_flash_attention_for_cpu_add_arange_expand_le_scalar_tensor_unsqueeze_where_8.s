    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr3: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #256
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s8, #0], s2
    s.movz       s1, #16
    s.st.d       [s8, #8], s1
    s.movz       s1, #64
    s.st.d       [s8, #16], s1
    s.movz       s1, #256
    s.st.d       [s8, #48], s1
    s.movz       s1, #4
    s.st.d       [s8, #56], s1
    .li       s1, #68719476737
    s.st.d       [s8, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s8, #64
    s.movz       s9, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.ld.d       s10, [s3, #0]                   // one element, not a vector
    v.movi       v1, #0
    v.movi       v2, #0
    v.insert     v1, s10, #0
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #0
    v.insert     v1, s10, #1
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #1
    v.insert     v1, s10, #2
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #2
    v.insert     v1, s10, #3
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #3
    v.insert     v1, s10, #4
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #4
    v.insert     v1, s10, #5
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #5
    v.insert     v1, s10, #6
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #6
    v.insert     v1, s10, #7
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #7
    v.insert     v1, s10, #8
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #8
    v.insert     v1, s10, #9
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #9
    v.insert     v1, s10, #10
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #10
    v.insert     v1, s10, #11
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #11
    v.insert     v1, s10, #12
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #12
    v.insert     v1, s10, #13
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #13
    v.insert     v1, s10, #14
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #14
    v.insert     v1, s10, #15
    s.lshri      s11, s10, #32
    v.insert     v2, s11, #15
    s.addi       s10, s1, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.cmp.ne     p1, v3, v4
    p.mov        p2, p1
    .li       s11, #4286578688
    v.splat      v3, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v4, #0
    v.mov        v4, v3
for_1:
    s.cmp.ge     s11, s10, s8
    br.nz        s11, endfor_2
    v.splat      v5, s10
    v.splat      v6, s10
    v.iota       v7                              // arange(0, VLEN)
    v.add        v8, v5, v0
    s.movz       s11, #64
    s.movz       s12, #16
    s.muli       s13, s4, #256
    v.add        v5, v6, v7
    v.movi       v6, #0
    v.splat      v7, s11
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s12
    v.extract    s11, v8, #0
    s.muli       s12, s10, #4
    s.shli       s14, s11, #32
    v.cmp.ge     p1, v5, v6
    v.cmp.lt     p3, v5, v7
    v.cmp.ge     p4, v9, v10
    v.cmp.lt     p5, v9, v11
    v.extract    s11, v8, #1
    s.add        s15, s2, s13
    p.and        p6, p1, p3
    p.and        p1, p4, p5
    s.ashri      s13, s14, #32
    v.movi       v5, #0
    v.movi       v6, #0
    s.shli       s14, s11, #32
    s.add        s11, s15, s12
    p.and        p3, p6, p1
    s.lshri      s12, s13, #32
    v.extract    s15, v8, #2
    s.ashri      s16, s14, #32
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v7, [s11, #0]
    v.insert     v5, s13, #0
    v.insert     v6, s12, #0
    s.shli       s11, s15, #32
    s.lshri      s12, s16, #32
    v.extract    s13, v8, #3
    s.ashri      s14, s11, #32
    v.insert     v5, s16, #1
    v.insert     v6, s12, #1
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    s.ashri      s13, s11, #32
    v.insert     v5, s14, #2
    v.insert     v6, s12, #2
    v.movi       v9, #64
    s.lshri      s11, s13, #32
    v.insert     v5, s13, #3
    v.cmp.lt     p1, v8, v9
    v.extract    s12, v8, #4
    v.extract    s13, v8, #5
    s.shli       s14, s12, #32
    v.insert     v6, s11, #3
    s.ashri      s11, s14, #32
    s.shli       s12, s13, #32
    s.lshri      s13, s11, #32
    v.extract    s14, v8, #6
    s.ashri      s15, s12, #32
    v.insert     v5, s11, #4
    v.insert     v6, s13, #4
    s.shli       s11, s14, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v8, #7
    s.ashri      s14, s11, #32
    v.insert     v5, s15, #5
    v.insert     v6, s12, #5
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v8, #8
    s.ashri      s15, s11, #32
    v.insert     v5, s14, #6
    v.insert     v6, s12, #6
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v8, #9
    s.ashri      s14, s11, #32
    v.insert     v5, s15, #7
    v.insert     v6, s12, #7
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v8, #10
    s.ashri      s15, s11, #32
    v.insert     v5, s14, #8
    v.insert     v6, s12, #8
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v8, #11
    s.ashri      s14, s11, #32
    v.insert     v5, s15, #9
    v.insert     v6, s12, #9
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v8, #12
    s.ashri      s15, s11, #32
    v.insert     v5, s14, #10
    v.insert     v6, s12, #10
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v8, #13
    s.ashri      s14, s11, #32
    v.insert     v5, s15, #11
    v.insert     v6, s12, #11
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v8, #14
    s.ashri      s15, s11, #32
    v.insert     v5, s14, #12
    v.insert     v6, s12, #12
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v8, #15
    s.ashri      s14, s11, #32
    v.insert     v5, s15, #13
    v.insert     v6, s12, #13
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    s.ashri      s13, s11, #32
    v.insert     v5, s14, #14
    v.insert     v6, s12, #14
    s.lshri      s11, s13, #32
    v.insert     v5, s13, #15
    v.insert     v6, s11, #15
    v.extract    s11, v2, #0
    v.extract    s12, v5, #0
    v.extract    s13, v6, #0
    v.extract    s14, v1, #0
    s.shli       s15, s13, #32
    s.shli       s13, s11, #32
    v.extract    s11, v6, #1
    v.extract    s16, v2, #1
    s.or         s17, s12, s15
    s.or         s12, s14, s13
    v.movi       v8, #0
    v.extract    s13, v5, #1
    s.shli       s14, s11, #32
    v.extract    s11, v1, #1
    s.shli       s15, s16, #32
    s.cmp.le     s16, s17, s12
    v.extract    s12, v6, #2
    v.extract    s17, v2, #2
    s.or         s18, s13, s14
    s.or         s13, s11, s15
    v.insert     v8, s16, #0
    v.extract    s11, v5, #2
    s.shli       s14, s12, #32
    v.extract    s12, v1, #2
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s13
    v.extract    s13, v6, #3
    v.extract    s17, v2, #3
    s.or         s18, s11, s14
    s.or         s11, s12, s15
    v.insert     v8, s16, #1
    v.extract    s12, v5, #3
    s.shli       s14, s13, #32
    v.extract    s13, v1, #3
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s11
    v.extract    s11, v6, #4
    v.extract    s17, v2, #4
    s.or         s18, s12, s14
    s.or         s12, s13, s15
    v.insert     v8, s16, #2
    v.extract    s13, v5, #4
    s.shli       s14, s11, #32
    v.extract    s11, v1, #4
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s12
    v.extract    s12, v6, #5
    v.extract    s17, v2, #5
    s.or         s18, s13, s14
    s.or         s13, s11, s15
    v.insert     v8, s16, #3
    v.extract    s11, v5, #5
    s.shli       s14, s12, #32
    v.extract    s12, v1, #5
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s13
    v.extract    s13, v6, #6
    v.extract    s17, v2, #6
    s.or         s18, s11, s14
    s.or         s11, s12, s15
    v.insert     v8, s16, #4
    v.extract    s12, v5, #6
    s.shli       s14, s13, #32
    v.extract    s13, v1, #6
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s11
    v.extract    s11, v6, #7
    v.extract    s17, v2, #7
    s.or         s18, s12, s14
    s.or         s12, s13, s15
    v.insert     v8, s16, #5
    v.extract    s13, v5, #7
    s.shli       s14, s11, #32
    v.extract    s11, v1, #7
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s12
    v.extract    s12, v6, #8
    v.extract    s17, v2, #8
    s.or         s18, s13, s14
    s.or         s13, s11, s15
    v.insert     v8, s16, #6
    v.extract    s11, v5, #8
    s.shli       s14, s12, #32
    v.extract    s12, v1, #8
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s13
    v.extract    s13, v6, #9
    v.extract    s17, v2, #9
    s.or         s18, s11, s14
    s.or         s11, s12, s15
    v.insert     v8, s16, #7
    v.extract    s12, v5, #9
    s.shli       s14, s13, #32
    v.extract    s13, v1, #9
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s11
    v.extract    s11, v6, #10
    v.extract    s17, v2, #10
    s.or         s18, s12, s14
    s.or         s12, s13, s15
    v.insert     v8, s16, #8
    v.extract    s13, v5, #10
    s.shli       s14, s11, #32
    v.extract    s11, v1, #10
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s12
    v.extract    s12, v6, #11
    v.extract    s17, v2, #11
    s.or         s18, s13, s14
    s.or         s13, s11, s15
    v.insert     v8, s16, #9
    v.extract    s11, v5, #11
    s.shli       s14, s12, #32
    v.extract    s12, v1, #11
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s13
    v.extract    s13, v6, #12
    v.extract    s17, v2, #12
    s.or         s18, s11, s14
    s.or         s11, s12, s15
    v.insert     v8, s16, #10
    v.extract    s12, v5, #12
    s.shli       s14, s13, #32
    v.extract    s13, v1, #12
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s11
    v.extract    s11, v6, #13
    v.extract    s17, v2, #13
    s.or         s18, s12, s14
    s.or         s12, s13, s15
    v.insert     v8, s16, #11
    v.extract    s13, v5, #13
    s.shli       s14, s11, #32
    v.extract    s11, v1, #13
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s12
    v.extract    s12, v6, #14
    v.extract    s17, v2, #14
    s.or         s18, s13, s14
    s.or         s13, s11, s15
    v.insert     v8, s16, #12
    v.extract    s11, v5, #14
    s.shli       s14, s12, #32
    v.extract    s12, v1, #14
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s13
    v.extract    s13, v6, #15
    v.extract    s17, v2, #15
    s.or         s18, s11, s14
    s.or         s11, s12, s15
    v.insert     v8, s16, #13
    v.extract    s12, v5, #15
    s.shli       s14, s13, #32
    v.extract    s13, v1, #15
    s.shli       s15, s17, #32
    s.cmp.le     s16, s18, s11
    s.or         s11, s12, s14
    s.or         s12, s13, s15
    v.insert     v8, s16, #14
    s.cmp.le     s13, s11, s12
    v.movi       v5, #0
    v.insert     v8, s13, #15
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.ne     p3, v8, v5
    @p3 v.sel        v5, v6, v3
    v.movi       v6, #0
    v.movi       v8, #0
    vf.add       v10, v7, v5
    v.movi       v5, #1
    v.movi       v7, #0
    v.movi       v11, #1
    v.movi       v12, #0
    vf.cmp.eq    p3, v10, v3
    @p3 v.sel        v13, v9, v6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.eq     p3, v13, v8
    @p3 v.sel        v8, v5, v7
    @p3 v.sel        v5, v11, v12
    v.movi       v7, #0
    v.extract    s11, v8, #0
    v.movi       v8, #0
    s.lshri      s12, s11, #32
    v.extract    s13, v5, #1
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s11, #0
    v.insert     v8, s12, #0
    s.lshri      s11, s13, #32
    v.extract    s12, v5, #2
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s13, #1
    v.insert     v8, s11, #1
    s.lshri      s11, s12, #32
    v.extract    s13, v5, #3
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s12, #2
    v.insert     v8, s11, #2
    s.lshri      s11, s13, #32
    v.extract    s12, v5, #4
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s13, #3
    v.insert     v8, s11, #3
    s.lshri      s11, s12, #32
    v.extract    s13, v5, #5
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s12, #4
    v.insert     v8, s11, #4
    s.lshri      s11, s13, #32
    v.extract    s12, v5, #6
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s13, #5
    v.insert     v8, s11, #5
    s.lshri      s11, s12, #32
    v.extract    s13, v5, #7
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s12, #6
    v.insert     v8, s11, #6
    s.lshri      s11, s13, #32
    v.extract    s12, v5, #8
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s13, #7
    v.insert     v8, s11, #7
    s.lshri      s11, s12, #32
    v.extract    s13, v5, #9
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s12, #8
    v.insert     v8, s11, #8
    s.lshri      s11, s13, #32
    v.extract    s12, v5, #10
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s13, #9
    v.insert     v8, s11, #9
    s.lshri      s11, s12, #32
    v.extract    s13, v5, #11
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s12, #10
    v.insert     v8, s11, #10
    s.lshri      s11, s13, #32
    v.extract    s12, v5, #12
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s13, #11
    v.insert     v8, s11, #11
    s.lshri      s11, s12, #32
    v.extract    s13, v5, #13
    @p3 v.sel        v5, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s12, #12
    v.insert     v8, s11, #12
    s.lshri      s11, s13, #32
    v.extract    s12, v5, #14
    @p3 v.sel        v5, v6, v9
    v.insert     v7, s13, #13
    v.insert     v8, s11, #13
    s.lshri      s11, s12, #32
    v.extract    s13, v5, #15
    v.insert     v7, s12, #14
    v.insert     v8, s11, #14
    s.lshri      s11, s13, #32
    v.insert     v7, s13, #15
    v.insert     v8, s11, #15
    s.movz       s11, #0
    v.extract    s12, v7, #0
    v.extract    s13, v8, #0
    v.extract    s14, v8, #1
    s.shli       s15, s13, #32
    v.movi       v5, #0
    s.or         s13, s12, s15
    v.extract    s12, v7, #1
    s.shli       s15, s14, #32
    s.cmp.ne     s14, s13, s11
    v.extract    s11, v8, #2
    s.or         s13, s12, s15
    s.movz       s12, #0
    v.insert     v5, s14, #0
    v.extract    s14, v7, #2
    s.shli       s15, s11, #32
    s.cmp.ne     s11, s13, s12
    v.extract    s12, v8, #3
    s.or         s13, s14, s15
    s.movz       s14, #0
    v.insert     v5, s11, #1
    v.extract    s11, v7, #3
    s.shli       s15, s12, #32
    s.cmp.ne     s12, s13, s14
    v.extract    s13, v8, #4
    s.or         s14, s11, s15
    s.movz       s11, #0
    v.insert     v5, s12, #2
    v.extract    s12, v7, #4
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s14, s11
    v.extract    s11, v8, #5
    s.or         s14, s12, s15
    s.movz       s12, #0
    v.insert     v5, s13, #3
    v.extract    s13, v7, #5
    s.shli       s15, s11, #32
    s.cmp.ne     s11, s14, s12
    v.extract    s12, v8, #6
    s.or         s14, s13, s15
    s.movz       s13, #0
    v.insert     v5, s11, #4
    v.extract    s11, v7, #6
    s.shli       s15, s12, #32
    s.cmp.ne     s12, s14, s13
    v.extract    s13, v8, #7
    s.or         s14, s11, s15
    s.movz       s11, #0
    v.insert     v5, s12, #5
    v.extract    s12, v7, #7
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s14, s11
    v.extract    s11, v8, #8
    s.or         s14, s12, s15
    s.movz       s12, #0
    v.insert     v5, s13, #6
    v.extract    s13, v7, #8
    s.shli       s15, s11, #32
    s.cmp.ne     s11, s14, s12
    v.extract    s12, v8, #9
    s.or         s14, s13, s15
    s.movz       s13, #0
    v.insert     v5, s11, #7
    v.extract    s11, v7, #9
    s.shli       s15, s12, #32
    s.cmp.ne     s12, s14, s13
    v.extract    s13, v8, #10
    s.or         s14, s11, s15
    s.movz       s11, #0
    v.insert     v5, s12, #8
    v.extract    s12, v7, #10
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s14, s11
    v.extract    s11, v8, #11
    s.or         s14, s12, s15
    s.movz       s12, #0
    v.insert     v5, s13, #9
    v.extract    s13, v7, #11
    s.shli       s15, s11, #32
    s.cmp.ne     s11, s14, s12
    v.extract    s12, v8, #12
    s.or         s14, s13, s15
    s.movz       s13, #0
    v.insert     v5, s11, #10
    v.extract    s11, v7, #12
    s.shli       s15, s12, #32
    s.cmp.ne     s12, s14, s13
    v.extract    s13, v8, #13
    s.or         s14, s11, s15
    s.movz       s11, #0
    v.insert     v5, s12, #11
    v.extract    s12, v7, #13
    s.shli       s15, s13, #32
    s.cmp.ne     s13, s14, s11
    v.extract    s11, v8, #14
    s.or         s14, s12, s15
    s.movz       s12, #0
    v.insert     v5, s13, #12
    v.extract    s13, v7, #14
    s.shli       s15, s11, #32
    s.cmp.ne     s11, s14, s12
    v.extract    s12, v8, #15
    s.or         s14, s13, s15
    s.movz       s13, #0
    v.insert     v5, s11, #13
    v.extract    s11, v7, #15
    s.shli       s15, s12, #32
    s.cmp.ne     s12, s14, s13
    s.or         s13, s11, s15
    s.movz       s11, #0
    v.insert     v5, s12, #14
    s.cmp.ne     s12, s13, s11
    v.movi       v6, #0
    v.insert     v5, s12, #15
    vf.max       v7, v4, v10
    p.not        p3, p1
    v.cmp.ne     p4, v5, v6
    p.or         p5, p2, p4
    p.and        p4, p3, p2
    p.and        p3, p1, p5
    @p1 v.sel        v5, v7, v4
    v.movi       v6, #0
    p.or         p1, p3, p4
    s.add        s11, s10, s9
    p.mov        p3, p1
    v.mov        v6, v5
    s.movz       s12, #1
    p.mov        p2, p3
    v.mov        v4, v6
    s.mov        s10, s11
    br.nz        s12, for_1
endfor_2:
    v.movi       v1, #1
    v.movi       v2, #0
    s.movz       s10, #1
    s.shli       s11, s4, #0                     // element offset -> bytes (x1)
    @p2 v.sel        v5, v1, v2
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s10
    v.reduce.or  s10, v5
    s.add        s12, s5, s11                    // &out_ptr0[...]
    v.splat      v5, s10
    v.cmp.lt     p1, v1, v2
    v.movi       v1, #0
    @p1 v.st.b       [s12, #0], v5
    v.movi       v2, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cmp.uo    p1, v4, v4
    v.movi       v7, #0
    @p1 v.sel        v8, v5, v6
    vf.reduce.max.b v5, v4
    .li       s5, #2143289344
    v.splat      v4, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.reduce.or.b v6, v8
    v.movi       v8, #0
    s.ld.d       s5, [s3, #0]                    // one element, not a vector
    v.cmp.ne     p1, v6, v7
    @p1 v.sel        v6, v4, v5
    vf.add       v4, v6, v8
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #0
    v.insert     v2, s3, #0
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #1
    v.insert     v2, s3, #1
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #2
    v.insert     v2, s3, #2
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #3
    v.insert     v2, s3, #3
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #4
    v.insert     v2, s3, #4
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #5
    v.insert     v2, s3, #5
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #6
    v.insert     v2, s3, #6
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #7
    v.insert     v2, s3, #7
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #8
    v.insert     v2, s3, #8
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #9
    v.insert     v2, s3, #9
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #10
    v.insert     v2, s3, #10
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #11
    v.insert     v2, s3, #11
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #12
    v.insert     v2, s3, #12
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #13
    v.insert     v2, s3, #13
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #14
    v.insert     v2, s3, #14
    v.movi       v5, #0
    v.movi       v6, #0
    s.lshri      s3, s5, #32
    v.insert     v1, s5, #15
    v.insert     v2, s3, #15
    s.addi       s3, s1, #0
    v.mov        v6, v5
for_3:
    s.cmp.ge     s1, s3, s8
    br.nz        s1, endfor_4
    v.splat      v7, s3
    v.splat      v9, s3
    v.iota       v10                             // arange(0, VLEN)
    v.add        v11, v7, v0
    s.movz       s1, #64
    s.movz       s5, #16
    s.muli       s10, s4, #256
    v.add        v7, v9, v10
    v.movi       v9, #0
    v.splat      v10, s1
    v.splat      v12, s4
    v.movi       v13, #0
    v.splat      v14, s5
    v.extract    s1, v11, #0
    s.muli       s5, s3, #4
    s.shli       s11, s1, #32
    v.cmp.ge     p1, v7, v9
    v.cmp.lt     p2, v7, v10
    v.cmp.ge     p3, v12, v13
    v.cmp.lt     p4, v12, v14
    v.extract    s1, v11, #1
    s.add        s12, s2, s10
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.ashri      s10, s11, #32
    v.movi       v7, #0
    v.movi       v9, #0
    s.shli       s11, s1, #32
    s.add        s1, s12, s5
    p.and        p2, p5, p1
    s.lshri      s5, s10, #32
    v.extract    s12, v11, #2
    s.ashri      s13, s11, #32
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s1, #0]
    v.insert     v7, s10, #0
    v.insert     v9, s5, #0
    s.shli       s1, s12, #32
    s.lshri      s5, s13, #32
    v.extract    s10, v11, #3
    s.ashri      s11, s1, #32
    v.insert     v7, s13, #1
    v.insert     v9, s5, #1
    s.shli       s1, s10, #32
    s.lshri      s5, s11, #32
    s.ashri      s10, s1, #32
    v.insert     v7, s11, #2
    v.insert     v9, s5, #2
    v.movi       v12, #64
    s.lshri      s1, s10, #32
    v.insert     v7, s10, #3
    v.cmp.lt     p1, v11, v12
    v.extract    s5, v11, #4
    v.extract    s10, v11, #5
    s.shli       s11, s5, #32
    v.insert     v9, s1, #3
    s.ashri      s1, s11, #32
    s.shli       s5, s10, #32
    s.lshri      s10, s1, #32
    v.extract    s11, v11, #6
    s.ashri      s12, s5, #32
    v.insert     v7, s1, #4
    v.insert     v9, s10, #4
    s.shli       s1, s11, #32
    s.lshri      s5, s12, #32
    v.extract    s10, v11, #7
    s.ashri      s11, s1, #32
    v.insert     v7, s12, #5
    v.insert     v9, s5, #5
    s.shli       s1, s10, #32
    s.lshri      s5, s11, #32
    v.extract    s10, v11, #8
    s.ashri      s12, s1, #32
    v.insert     v7, s11, #6
    v.insert     v9, s5, #6
    s.shli       s1, s10, #32
    s.lshri      s5, s12, #32
    v.extract    s10, v11, #9
    s.ashri      s11, s1, #32
    v.insert     v7, s12, #7
    v.insert     v9, s5, #7
    s.shli       s1, s10, #32
    s.lshri      s5, s11, #32
    v.extract    s10, v11, #10
    s.ashri      s12, s1, #32
    v.insert     v7, s11, #8
    v.insert     v9, s5, #8
    s.shli       s1, s10, #32
    s.lshri      s5, s12, #32
    v.extract    s10, v11, #11
    s.ashri      s11, s1, #32
    v.insert     v7, s12, #9
    v.insert     v9, s5, #9
    s.shli       s1, s10, #32
    s.lshri      s5, s11, #32
    v.extract    s10, v11, #12
    s.ashri      s12, s1, #32
    v.insert     v7, s11, #10
    v.insert     v9, s5, #10
    s.shli       s1, s10, #32
    s.lshri      s5, s12, #32
    v.extract    s10, v11, #13
    s.ashri      s11, s1, #32
    v.insert     v7, s12, #11
    v.insert     v9, s5, #11
    s.shli       s1, s10, #32
    s.lshri      s5, s11, #32
    v.extract    s10, v11, #14
    s.ashri      s12, s1, #32
    v.insert     v7, s11, #12
    v.insert     v9, s5, #12
    s.shli       s1, s10, #32
    s.lshri      s5, s12, #32
    v.extract    s10, v11, #15
    s.ashri      s11, s1, #32
    v.insert     v7, s12, #13
    v.insert     v9, s5, #13
    s.shli       s1, s10, #32
    s.lshri      s5, s11, #32
    s.ashri      s10, s1, #32
    v.insert     v7, s11, #14
    v.insert     v9, s5, #14
    s.lshri      s1, s10, #32
    v.insert     v7, s10, #15
    v.insert     v9, s1, #15
    v.extract    s1, v2, #0
    v.extract    s5, v7, #0
    v.extract    s10, v9, #0
    v.extract    s11, v1, #0
    s.shli       s12, s10, #32
    s.shli       s10, s1, #32
    v.extract    s1, v9, #1
    v.extract    s13, v2, #1
    s.or         s14, s5, s12
    s.or         s5, s11, s10
    v.movi       v12, #0
    v.extract    s10, v7, #1
    s.shli       s11, s1, #32
    v.extract    s1, v1, #1
    s.shli       s12, s13, #32
    s.cmp.le     s13, s14, s5
    v.extract    s5, v9, #2
    v.extract    s14, v2, #2
    s.or         s15, s10, s11
    s.or         s10, s1, s12
    v.insert     v12, s13, #0
    v.extract    s1, v7, #2
    s.shli       s11, s5, #32
    v.extract    s5, v1, #2
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s10
    v.extract    s10, v9, #3
    v.extract    s14, v2, #3
    s.or         s15, s1, s11
    s.or         s1, s5, s12
    v.insert     v12, s13, #1
    v.extract    s5, v7, #3
    s.shli       s11, s10, #32
    v.extract    s10, v1, #3
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s1
    v.extract    s1, v9, #4
    v.extract    s14, v2, #4
    s.or         s15, s5, s11
    s.or         s5, s10, s12
    v.insert     v12, s13, #2
    v.extract    s10, v7, #4
    s.shli       s11, s1, #32
    v.extract    s1, v1, #4
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s5
    v.extract    s5, v9, #5
    v.extract    s14, v2, #5
    s.or         s15, s10, s11
    s.or         s10, s1, s12
    v.insert     v12, s13, #3
    v.extract    s1, v7, #5
    s.shli       s11, s5, #32
    v.extract    s5, v1, #5
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s10
    v.extract    s10, v9, #6
    v.extract    s14, v2, #6
    s.or         s15, s1, s11
    s.or         s1, s5, s12
    v.insert     v12, s13, #4
    v.extract    s5, v7, #6
    s.shli       s11, s10, #32
    v.extract    s10, v1, #6
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s1
    v.extract    s1, v9, #7
    v.extract    s14, v2, #7
    s.or         s15, s5, s11
    s.or         s5, s10, s12
    v.insert     v12, s13, #5
    v.extract    s10, v7, #7
    s.shli       s11, s1, #32
    v.extract    s1, v1, #7
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s5
    v.extract    s5, v9, #8
    v.extract    s14, v2, #8
    s.or         s15, s10, s11
    s.or         s10, s1, s12
    v.insert     v12, s13, #6
    v.extract    s1, v7, #8
    s.shli       s11, s5, #32
    v.extract    s5, v1, #8
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s10
    v.extract    s10, v9, #9
    v.extract    s14, v2, #9
    s.or         s15, s1, s11
    s.or         s1, s5, s12
    v.insert     v12, s13, #7
    v.extract    s5, v7, #9
    s.shli       s11, s10, #32
    v.extract    s10, v1, #9
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s1
    v.extract    s1, v9, #10
    v.extract    s14, v2, #10
    s.or         s15, s5, s11
    s.or         s5, s10, s12
    v.insert     v12, s13, #8
    v.extract    s10, v7, #10
    s.shli       s11, s1, #32
    v.extract    s1, v1, #10
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s5
    v.extract    s5, v9, #11
    v.extract    s14, v2, #11
    s.or         s15, s10, s11
    s.or         s10, s1, s12
    v.insert     v12, s13, #9
    v.extract    s1, v7, #11
    s.shli       s11, s5, #32
    v.extract    s5, v1, #11
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s10
    v.extract    s10, v9, #12
    v.extract    s14, v2, #12
    s.or         s15, s1, s11
    s.or         s1, s5, s12
    v.insert     v12, s13, #10
    v.extract    s5, v7, #12
    s.shli       s11, s10, #32
    v.extract    s10, v1, #12
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s1
    v.extract    s1, v9, #13
    v.extract    s14, v2, #13
    s.or         s15, s5, s11
    s.or         s5, s10, s12
    v.insert     v12, s13, #11
    v.extract    s10, v7, #13
    s.shli       s11, s1, #32
    v.extract    s1, v1, #13
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s5
    v.extract    s5, v9, #14
    v.extract    s14, v2, #14
    s.or         s15, s10, s11
    s.or         s10, s1, s12
    v.insert     v12, s13, #12
    v.extract    s1, v7, #14
    s.shli       s11, s5, #32
    v.extract    s5, v1, #14
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s10
    v.extract    s10, v9, #15
    v.extract    s14, v2, #15
    s.or         s15, s1, s11
    s.or         s1, s5, s12
    v.insert     v12, s13, #13
    v.extract    s5, v7, #15
    s.shli       s11, s10, #32
    v.extract    s10, v1, #15
    s.shli       s12, s14, #32
    s.cmp.le     s13, s15, s1
    s.or         s1, s5, s11
    s.or         s5, s10, s12
    v.insert     v12, s13, #14
    s.cmp.le     s10, s1, s5
    v.movi       v7, #0
    v.insert     v12, s10, #15
    v.extract    s1, v4, #0
    .li       s5, #1069066811
    v.splat      v9, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p2, v12, v7
    @p2 v.sel        v7, v5, v3
    v.splat      v12, s1
    .li       s1, #1060205080
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v14, v10, v7
    s.mul        s1, s4, s8
    v.movi       v7, #0
    s.add        s5, s3, s9
    s.movz       s10, #1
    vf.sub       v10, v14, v12
    s.add        s11, s3, s1
    v.splat      v12, s1
    s.shli       s1, s11, #2                     // element offset -> bytes (x4)
    vf.mul       v14, v10, v9
    s.add        s11, s6, s1                     // &out_ptr2[...]
    v.add        v15, v11, v12
    v.exp2.approx v11, v14                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v12, v10, v9, v14               // the exact rounding error of x*log2(e)
    vf.mul       v9, v12, v13
    vf.fma       v10, v11, v9, v11               // 2**t * 2**d
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v9, v10, v11
    vf.add       v10, v6, v9
    @p1 v.st.w       [s11, #0], v9
    @p1 v.sel        v9, v10, v6
    v.mov        v7, v9
    v.mov        v6, v7
    s.mov        s3, s5
    br.nz        s10, for_3
endfor_4:
    vf.reduce.add.b v0, v6
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v1, v0, v8
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s1
    s.add        s1, s7, s2                      // &out_ptr3[...]
    v.cmp.lt     p1, v0, v2
    @p1 v.st.w       [s1, #0], v1
__rctx_next:
    exit
