    s.rdspecial  s1, pid.x
    s.movz       s2, #0
    s.movz       s3, #0
    s.cmp.lt     s4, s1, s2
    s.movz       s2, #2
    s.sub        s5, s3, s4
    s.movz       s3, #0
    s.movz       s4, #0
    s.cmp.lt     s6, s2, s3
    s.rdspecial  s3, arg_base
    s.xor        s7, s1, s5
    s.sub        s8, s4, s6
    s.ld.d       s4, [s3, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.sub        s6, s7, s5
    s.ld.d       s7, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.xor        s9, s2, s8
    s.ld.d       s10, [s3, #16]                  // arg_SA: device_ptr64 at arg_base+16
    s.sub        s11, s9, s8
    s.ld.d       s9, [s3, #24]                   // arg_SB: device_ptr64 at arg_base+24
    s.lshri      s11, s6, #1
    s.ld.d       s12, [s3, #32]                  // out_ptr1: device_ptr64 at arg_base+32
    s.movz       s3, #0
    s.xor        s13, s5, s8
    s.movz       s5, #0
    s.cmp.lt     s8, s1, s3
    s.sub        s3, s5, s8
    s.xor        s5, s11, s13
    s.xor        s8, s1, s3
    s.sub        s1, s5, s13
    s.sub        s5, s8, s3
    s.movz       s8, #0
    s.muli       s13, s11, #2
    s.cmp.lt     s11, s2, s8
    s.sub        s8, s6, s13
    s.lshri      s6, s5, #1
    s.movz       s8, #16
    s.muli       s13, s6, #2
    s.mul        s6, s1, s8
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s1, s5, s13
    s.movz       s5, #0
    s.xor        s13, s1, s3
    v.splat      v1, s6
    s.sub        s1, s13, s3
    s.movz       s3, #128
    s.sub        s13, s5, s11
    s.mul        s5, s1, s3
    v.add        v2, v1, v0
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s1, s2, s13
    v.movi       v1, #16
    v.iota       v3                              // arange(0, VLEN)
    s.sub        s11, s1, s13
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #32
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #48
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #64
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #80
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #96
    v.add        v14, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #112
    v.add        v15, v4, v5
    v.add        v4, v6, v7
    v.add        v5, v8, v9
    v.add        v6, v10, v11
    v.add        v7, v12, v13
    v.add        v8, v0, v1
    v.splat      v0, s5
    v.movi       v1, #7
    v.splat      v9, s5
    v.movi       v10, #0
    v.splat      v11, s5
    v.splat      v12, s5
    v.splat      v13, s5
    v.splat      v16, s5
    v.cmp.lt     p1, v2, v10
    v.cmp.lt     p2, v1, v10
    v.add        v17, v0, v3
    v.splat      v0, s5
    v.add        v3, v9, v14
    v.splat      v9, s5
    v.add        v14, v11, v15
    v.sub        v11, v10, v2
    v.add        v15, v12, v4
    v.sub        v4, v10, v1
    v.add        v12, v13, v5
    v.add        v5, v16, v6
    v.add        v6, v0, v7
    v.add        v0, v9, v8
    v.movi       v7, #1
    @p1 v.sel        v8, v11, v2
    @p2 v.sel        v2, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v9, s1
    v.shl        v11, v4, v7
    v.lshr       v13, v8, v9
    v.cmp.lt     p2, v4, v10
    v.and        v16, v13, v7
    v.shl        v13, v7, v9
    v.or         v9, v11, v16
    s.subi       s11, s1, #1
    v.cmp.geu    p3, v9, v2
    p.or         p4, p2, p3
    v.sub        v11, v9, v2
    @p4 v.sel        v16, v13, v10
    @p4 v.sel        v13, v11, v9
    v.or         v9, v1, v16
    v.mov        v4, v13
    v.mov        v1, v9
    s.mov        s1, s11
    s.movz       s11, #0
    s.cmp.ge     s13, s1, s11
    br.nz        s13, idiv_1
    v.movi       v1, #136
    v.movi       v2, #0
    v.sub        v7, v10, v4
    v.sub        v8, v2, v17
    v.sub        v9, v2, v1
    v.cmp.lt     p2, v17, v2
    @p1 v.sel        v10, v7, v4
    v.cmp.lt     p1, v1, v2
    v.movi       v4, #1
    @p2 v.sel        v7, v8, v17
    @p1 v.sel        v8, v9, v1
    v.movi       v1, #0
    v.movi       v9, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v11, s1
    v.shl        v13, v9, v4
    v.lshr       v16, v7, v11
    v.cmp.lt     p1, v9, v2
    v.and        v17, v16, v4
    v.shl        v16, v4, v11
    v.or         v11, v13, v17
    s.subi       s11, s1, #1
    v.cmp.geu    p3, v11, v8
    p.or         p4, p1, p3
    v.sub        v13, v11, v8
    @p4 v.sel        v17, v16, v2
    @p4 v.sel        v16, v13, v11
    v.or         v11, v1, v17
    v.mov        v9, v16
    v.mov        v1, v11
    s.mov        s1, s11
    s.movz       s11, #0
    s.cmp.ge     s13, s1, s11
    br.nz        s13, idiv_2
    v.movi       v1, #136
    v.movi       v4, #0
    v.sub        v7, v2, v9
    v.sub        v2, v4, v3
    v.sub        v8, v4, v1
    v.cmp.lt     p1, v3, v4
    @p2 v.sel        v11, v7, v9
    v.cmp.lt     p2, v1, v4
    v.movi       v7, #1
    @p1 v.sel        v9, v2, v3
    @p2 v.sel        v2, v8, v1
    v.movi       v1, #0
    v.movi       v3, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v8, s1
    v.shl        v13, v3, v7
    v.lshr       v16, v9, v8
    v.cmp.lt     p2, v3, v4
    v.and        v17, v16, v7
    v.shl        v16, v7, v8
    v.or         v8, v13, v17
    s.subi       s11, s1, #1
    v.cmp.geu    p3, v8, v2
    p.or         p4, p2, p3
    v.sub        v13, v8, v2
    @p4 v.sel        v17, v16, v4
    @p4 v.sel        v16, v13, v8
    v.or         v8, v1, v17
    v.mov        v3, v16
    v.mov        v1, v8
    s.mov        s1, s11
    s.movz       s11, #0
    s.cmp.ge     s13, s1, s11
    br.nz        s13, idiv_3
    v.movi       v1, #136
    v.movi       v2, #0
    v.sub        v7, v4, v3
    v.sub        v4, v2, v14
    v.sub        v8, v2, v1
    v.cmp.lt     p2, v14, v2
    @p1 v.sel        v9, v7, v3
    v.cmp.lt     p1, v1, v2
    v.movi       v3, #1
    @p2 v.sel        v7, v4, v14
    @p1 v.sel        v4, v8, v1
    v.movi       v1, #0
    v.movi       v8, #0
    s.movz       s1, #31
idiv_4:
    v.splat      v13, s1
    v.shl        v14, v8, v3
    v.lshr       v16, v7, v13
    v.cmp.lt     p1, v8, v2
    v.and        v17, v16, v3
    v.shl        v16, v3, v13
    v.or         v13, v14, v17
    s.subi       s11, s1, #1
    v.cmp.geu    p3, v13, v4
    p.or         p4, p1, p3
    v.sub        v14, v13, v4
    @p4 v.sel        v17, v16, v2
    @p4 v.sel        v16, v14, v13
    v.or         v13, v1, v17
    v.mov        v8, v16
    v.mov        v1, v13
    s.mov        s1, s11
    s.movz       s11, #0
    s.cmp.ge     s13, s1, s11
    br.nz        s13, idiv_4
    v.movi       v1, #136
    v.movi       v3, #0
    v.sub        v4, v2, v8
    v.sub        v2, v3, v15
    v.sub        v7, v3, v1
    v.cmp.lt     p1, v15, v3
    @p2 v.sel        v13, v4, v8
    v.cmp.lt     p2, v1, v3
    v.movi       v4, #1
    @p1 v.sel        v8, v2, v15
    @p2 v.sel        v2, v7, v1
    v.movi       v1, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_5:
    v.splat      v14, s1
    v.shl        v15, v7, v4
    v.lshr       v16, v8, v14
    v.cmp.lt     p2, v7, v3
    v.and        v17, v16, v4
    v.shl        v16, v4, v14
    v.or         v14, v15, v17
    s.subi       s11, s1, #1
    v.cmp.geu    p3, v14, v2
    p.or         p4, p2, p3
    v.sub        v15, v14, v2
    @p4 v.sel        v17, v16, v3
    @p4 v.sel        v16, v15, v14
    v.or         v14, v1, v17
    v.mov        v7, v16
    v.mov        v1, v14
    s.mov        s1, s11
    s.movz       s11, #0
    s.cmp.ge     s13, s1, s11
    br.nz        s13, idiv_5
    v.movi       v1, #136
    v.movi       v2, #0
    v.sub        v4, v3, v7
    v.sub        v3, v2, v12
    v.sub        v8, v2, v1
    v.cmp.lt     p2, v12, v2
    @p1 v.sel        v14, v4, v7
    v.cmp.lt     p1, v1, v2
    v.movi       v4, #1
    @p2 v.sel        v7, v3, v12
    @p1 v.sel        v3, v8, v1
    v.movi       v1, #0
    v.movi       v8, #0
    s.movz       s1, #31
idiv_6:
    v.splat      v12, s1
    v.shl        v15, v8, v4
    v.lshr       v16, v7, v12
    v.cmp.lt     p1, v8, v2
    v.and        v17, v16, v4
    v.shl        v16, v4, v12
    v.or         v12, v15, v17
    s.subi       s11, s1, #1
    v.cmp.geu    p3, v12, v3
    p.or         p4, p1, p3
    v.sub        v15, v12, v3
    @p4 v.sel        v17, v16, v2
    @p4 v.sel        v16, v15, v12
    v.or         v12, v1, v17
    v.mov        v8, v16
    v.mov        v1, v12
    s.mov        s1, s11
    s.movz       s11, #0
    s.cmp.ge     s13, s1, s11
    br.nz        s13, idiv_6
    v.movi       v1, #136
    v.movi       v3, #0
    v.sub        v4, v2, v8
    v.sub        v2, v3, v5
    v.sub        v7, v3, v1
    v.cmp.lt     p1, v5, v3
    @p2 v.sel        v12, v4, v8
    v.cmp.lt     p2, v1, v3
    v.movi       v4, #1
    @p1 v.sel        v8, v2, v5
    @p2 v.sel        v2, v7, v1
    v.movi       v1, #0
    v.movi       v5, #0
    s.movz       s1, #31
idiv_7:
    v.splat      v7, s1
    v.shl        v15, v5, v4
    v.lshr       v16, v8, v7
    v.cmp.lt     p2, v5, v3
    v.and        v17, v16, v4
    v.shl        v16, v4, v7
    v.or         v7, v15, v17
    s.subi       s11, s1, #1
    v.cmp.geu    p3, v7, v2
    p.or         p4, p2, p3
    v.sub        v15, v7, v2
    @p4 v.sel        v17, v16, v3
    @p4 v.sel        v16, v15, v7
    v.or         v7, v1, v17
    v.mov        v5, v16
    v.mov        v1, v7
    s.mov        s1, s11
    s.movz       s11, #0
    s.cmp.ge     s13, s1, s11
    br.nz        s13, idiv_7
    v.movi       v1, #136
    v.movi       v2, #0
    v.sub        v4, v3, v5
    v.sub        v3, v2, v6
    v.sub        v7, v2, v1
    v.cmp.lt     p2, v6, v2
    @p1 v.sel        v8, v4, v5
    v.cmp.lt     p1, v1, v2
    v.movi       v4, #1
    @p2 v.sel        v5, v3, v6
    @p1 v.sel        v3, v7, v1
    v.movi       v1, #0
    v.movi       v6, #0
    s.movz       s1, #31
idiv_8:
    v.splat      v7, s1
    v.shl        v15, v6, v4
    v.lshr       v16, v5, v7
    v.cmp.lt     p1, v6, v2
    v.and        v17, v16, v4
    v.shl        v16, v4, v7
    v.or         v7, v15, v17
    s.subi       s11, s1, #1
    v.cmp.geu    p3, v7, v3
    p.or         p4, p1, p3
    v.sub        v15, v7, v3
    @p4 v.sel        v17, v16, v2
    @p4 v.sel        v16, v15, v7
    v.or         v7, v1, v17
    v.mov        v6, v16
    v.mov        v1, v7
    s.mov        s1, s11
    s.movz       s11, #0
    s.cmp.ge     s13, s1, s11
    br.nz        s13, idiv_8
    v.movi       v1, #136
    v.movi       v3, #0
    v.sub        v4, v2, v6
    v.sub        v2, v3, v0
    v.sub        v5, v3, v1
    v.cmp.lt     p1, v0, v3
    @p2 v.sel        v7, v4, v6
    v.cmp.lt     p2, v1, v3
    v.movi       v4, #1
    @p1 v.sel        v6, v2, v0
    @p2 v.sel        v0, v5, v1
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s1, #31
idiv_9:
    v.splat      v5, s1
    v.shl        v15, v2, v4
    v.lshr       v16, v6, v5
    v.cmp.lt     p2, v2, v3
    v.and        v17, v16, v4
    v.shl        v16, v4, v5
    v.or         v5, v15, v17
    s.subi       s11, s1, #1
    v.cmp.geu    p3, v5, v0
    p.or         p4, p2, p3
    v.sub        v15, v5, v0
    @p4 v.sel        v17, v16, v3
    @p4 v.sel        v16, v15, v5
    v.or         v5, v1, v17
    v.mov        v2, v16
    v.mov        v1, v5
    s.mov        s1, s11
    s.movz       s11, #0
    s.cmp.ge     s13, s1, s11
    br.nz        s13, idiv_9
    v.sub        v0, v3, v2
    s.movz       s1, #0
    s.movz       s11, #0
    s.movz       s13, #0
    @p1 v.sel        v1, v0, v2
    s.movz       s14, #1
    s.addi       s15, s1, #0
    s.addi       s16, s11, #0
    s.addi       s11, s13, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_10:
    s.cmp.ge     s13, s15, s2
    br.nz        s13, endfor_11
    s.mul        s13, s15, s3
    s.movz       s17, #200
    s.sub        s18, s17, s13
    s.movz       s13, #7
    s.mul        s17, s15, s13
    v.splat      v0, s17
    s.shli       s19, s17, #2                    // element offset -> bytes (x4)
    s.add        s17, s10, s19                   // &arg_SA[...]
    v.ld.gather.w v0, [s17, v10]                 // index is in elements (ISA sec 9.1)
    s.movz       s17, #136
    s.mul        s19, s15, s17
    v.splat      v2, s19
    v.splat      v2, s19
    v.splat      v2, s19
    v.splat      v2, s19
    v.splat      v2, s19
    v.splat      v2, s19
    v.splat      v2, s19
    v.splat      v2, s19
    s.shli       s17, s19, #2                    // element offset -> bytes (x4)
    s.add        s19, s9, s17                    // &arg_SB[...]
    v.ld.gather.w v2, [s19, v11]                 // index is in elements (ISA sec 9.1)
    s.add        s19, s9, s17                    // &arg_SB[...]
    v.ld.gather.w v3, [s19, v9]                  // index is in elements (ISA sec 9.1)
    s.add        s19, s9, s17                    // &arg_SB[...]
    v.ld.gather.w v4, [s19, v13]                 // index is in elements (ISA sec 9.1)
    s.add        s19, s9, s17                    // &arg_SB[...]
    v.ld.gather.w v5, [s19, v14]                 // index is in elements (ISA sec 9.1)
    s.add        s19, s9, s17                    // &arg_SB[...]
    v.ld.gather.w v6, [s19, v12]                 // index is in elements (ISA sec 9.1)
    s.add        s19, s9, s17                    // &arg_SB[...]
    v.ld.gather.w v15, [s19, v8]                 // index is in elements (ISA sec 9.1)
    s.add        s19, s9, s17                    // &arg_SB[...]
    v.ld.gather.w v16, [s19, v7]                 // index is in elements (ISA sec 9.1)
    s.add        s19, s9, s17                    // &arg_SB[...]
    v.ld.gather.w v17, [s19, v1]                 // index is in elements (ISA sec 9.1)
    s.movz       s17, #8
    s.addi       s19, s1, #0
    s.movz       s20, #0
    s.addi       s21, s20, #0
    s.movz       s20, #0
    s.addi       s22, s20, #0
    v.movi       v18, #0
    s.rdspecial  s20, arg_base
    s.ld.d       s23, [s20, #40]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s20, s23, #0
    v.st.w       [s20, #0], v18
    s.addi       s24, s20, #64
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #128
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #192
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #256
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #320
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #384
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #448
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #512
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #576
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #640
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #704
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #768
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #832
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #896
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #960
    v.st.w       [s24, #0], v18
    fence.acq_rel.device
    v.movi       v18, #0
    s.addi       s20, s23, #1024
    v.st.w       [s20, #0], v18
    s.addi       s24, s20, #64
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #128
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #192
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #256
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #320
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #384
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #448
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #512
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #576
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #640
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #704
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #768
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #832
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #896
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #960
    v.st.w       [s24, #0], v18
    fence.acq_rel.device
    v.movi       v18, #0
    s.addi       s20, s23, #2048
    v.st.w       [s20, #0], v18
    s.addi       s24, s20, #64
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #128
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #192
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #256
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #320
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #384
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #448
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #512
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #576
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #640
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #704
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #768
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #832
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #896
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #960
    v.st.w       [s24, #0], v18
    fence.acq_rel.device
    v.movi       v18, #0
    s.addi       s20, s23, #3072
    v.st.w       [s20, #0], v18
    s.addi       s24, s20, #64
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #128
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #192
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #256
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #320
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #384
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #448
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #512
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #576
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #640
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #704
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #768
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #832
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #896
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #960
    v.st.w       [s24, #0], v18
    fence.acq_rel.device
    v.movi       v18, #0
    s.addi       s20, s23, #4096
    v.st.w       [s20, #0], v18
    s.addi       s24, s20, #64
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #128
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #192
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #256
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #320
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #384
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #448
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #512
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #576
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #640
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #704
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #768
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #832
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #896
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #960
    v.st.w       [s24, #0], v18
    fence.acq_rel.device
    v.movi       v18, #0
    s.addi       s20, s23, #5120
    v.st.w       [s20, #0], v18
    s.addi       s24, s20, #64
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #128
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #192
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #256
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #320
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #384
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #448
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #512
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #576
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #640
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #704
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #768
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #832
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #896
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #960
    v.st.w       [s24, #0], v18
    fence.acq_rel.device
    v.movi       v18, #0
    s.addi       s20, s23, #6144
    v.st.w       [s20, #0], v18
    s.addi       s24, s20, #64
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #128
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #192
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #256
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #320
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #384
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #448
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #512
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #576
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #640
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #704
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #768
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #832
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #896
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #960
    v.st.w       [s24, #0], v18
    fence.acq_rel.device
    v.movi       v18, #0
    s.addi       s20, s23, #7168
    v.st.w       [s20, #0], v18
    s.addi       s24, s20, #64
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #128
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #192
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #256
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #320
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #384
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #448
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #512
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #576
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #640
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #704
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #768
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #832
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #896
    v.st.w       [s24, #0], v18
    s.addi       s24, s20, #960
    v.st.w       [s24, #0], v18
    fence.acq_rel.device
for_12:
    s.cmp.ge     s20, s19, s17
    br.nz        s20, endfor_13
    s.mul        s20, s19, s8
    s.sub        s24, s18, s20
    s.movz       s20, #200
    v.splat      v18, s20
    v.mul        v19, v11, v18
    s.movz       s20, #200
    v.splat      v18, s20
    v.mul        v20, v9, v18
    s.movz       s20, #200
    v.splat      v18, s20
    v.mul        v21, v13, v18
    s.movz       s20, #200
    v.splat      v18, s20
    v.mul        v22, v14, v18
    s.movz       s20, #200
    v.splat      v18, s20
    v.mul        v23, v12, v18
    s.movz       s20, #200
    v.splat      v18, s20
    v.mul        v24, v8, v18
    s.movz       s20, #200
    v.splat      v18, s20
    v.mul        v25, v7, v18
    s.movz       s20, #200
    v.splat      v18, s20
    v.mul        v26, v1, v18
    // E4M3 x E5M2: both operands as FP16 fragments, exactly (ISA sec 9C.1)
    s.addi       s20, s23, #8192                 // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.movz       s25, #200
    v.splat      v18, s25
    v.mul        v27, v10, v18
    v.extract    s25, v27, #0
    s.add        s26, s16, s21
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.iota       v18                             // arange(0, VLEN)
    s.movz       s27, #0
    s.add        s28, s27, s24                   // the tile origin
    v.splat      v28, s28
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 0: f8E4M3FN -> f16
    v.st.h       [s20, #0], v28
    v.extract    s25, v27, #1
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 1: f8E4M3FN -> f16
    s.addi       s25, s20, #32                   // row 1
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #2
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 2: f8E4M3FN -> f16
    s.addi       s25, s20, #64                   // row 2
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #3
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 3: f8E4M3FN -> f16
    s.addi       s25, s20, #96                   // row 3
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #4
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 4: f8E4M3FN -> f16
    s.addi       s25, s20, #128                  // row 4
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #5
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 5: f8E4M3FN -> f16
    s.addi       s25, s20, #160                  // row 5
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #6
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 6: f8E4M3FN -> f16
    s.addi       s25, s20, #192                  // row 6
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #7
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 7: f8E4M3FN -> f16
    s.addi       s25, s20, #224                  // row 7
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #8
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 8: f8E4M3FN -> f16
    s.addi       s25, s20, #256                  // row 8
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #9
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 9: f8E4M3FN -> f16
    s.addi       s25, s20, #288                  // row 9
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #10
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 10: f8E4M3FN -> f16
    s.addi       s25, s20, #320                  // row 10
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #11
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 11: f8E4M3FN -> f16
    s.addi       s25, s20, #352                  // row 11
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #12
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 12: f8E4M3FN -> f16
    s.addi       s25, s20, #384                  // row 12
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #13
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 13: f8E4M3FN -> f16
    s.addi       s25, s20, #416                  // row 13
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #14
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 14: f8E4M3FN -> f16
    s.addi       s25, s20, #448                  // row 14
    v.st.h       [s25, #0], v28
    v.extract    s25, v27, #15
    s.add        s27, s25, s26
    s.add        s25, s4, s27
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s25, #0]
    vf.cvt.e4m3.f16 v28, v18                     // row 15: f8E4M3FN -> f16
    s.addi       s25, s20, #480                  // row 15
    v.st.h       [s25, #0], v28
    s.addi       s25, s23, #8704                 // TensorMap 0: a repacked tile
    s.movz       s27, #0
    s.st.d       [s25, #0], s20
    s.movz       s20, #16
    s.st.d       [s25, #8], s20
    s.movz       s20, #16
    s.st.d       [s25, #16], s20
    s.movz       s20, #32
    s.st.d       [s25, #48], s20
    s.movz       s20, #2
    s.st.d       [s25, #56], s20
    .li       s20, #68719476752
    s.st.d       [s25, #88], s20
    .li       s20, #8589934592
    s.st.d       [s25, #104], s20
    td.load      d0, [s25]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s20, #0
    w.def        w0, #48, #8                     // v48..v55
    mb.arm       s25, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s27, s20                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s20                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s27, s25
    mb.wait      s25
    s.addi       s20, s23, #8960                 // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.add        s27, s11, s22
    s.add        s28, s7, s27
    v.splat      v18, s1
    s.movz       s29, #0
    s.add        s30, s29, s24                   // the tile origin
    v.splat      v28, s30
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s28, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 0: f8E5M2 -> f16
    v.st.h       [s20, #0], v29
    s.addi       s24, s27, #1
    s.add        s28, s7, s24
    v.splat      v18, s14
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s28, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 1: f8E5M2 -> f16
    s.addi       s24, s20, #32                   // row 1
    v.st.h       [s24, #0], v29
    s.addi       s24, s27, #2
    s.add        s28, s7, s24
    v.splat      v18, s2
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s28, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 2: f8E5M2 -> f16
    s.addi       s24, s20, #64                   // row 2
    v.st.h       [s24, #0], v29
    s.addi       s24, s27, #3
    s.add        s28, s7, s24
    s.movz       s24, #3
    v.splat      v18, s24
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s28, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 3: f8E5M2 -> f16
    s.addi       s28, s20, #96                   // row 3
    v.st.h       [s28, #0], v29
    s.addi       s28, s27, #4
    s.add        s29, s7, s28
    s.movz       s28, #4
    v.splat      v18, s28
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s29, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 4: f8E5M2 -> f16
    s.addi       s29, s20, #128                  // row 4
    v.st.h       [s29, #0], v29
    s.addi       s29, s27, #5
    s.add        s30, s7, s29
    s.movz       s29, #5
    v.splat      v18, s29
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s30, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 5: f8E5M2 -> f16
    s.addi       s30, s20, #160                  // row 5
    v.st.h       [s30, #0], v29
    s.addi       s30, s27, #6
    s.add        s31, s7, s30
    s.movz       s30, #6
    v.splat      v18, s30
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s31, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 6: f8E5M2 -> f16
    s.addi       s31, s20, #192                  // row 6
    v.st.h       [s31, #0], v29
    s.addi       s31, s27, #7
    s.add        s32, s7, s31
    v.splat      v18, s13
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s32, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 7: f8E5M2 -> f16
    s.addi       s31, s20, #224                  // row 7
    v.st.h       [s31, #0], v29
    s.addi       s31, s27, #8
    s.add        s32, s7, s31
    v.splat      v18, s17
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s32, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 8: f8E5M2 -> f16
    s.addi       s31, s20, #256                  // row 8
    v.st.h       [s31, #0], v29
    s.addi       s31, s27, #9
    s.add        s32, s7, s31
    s.movz       s31, #9
    v.splat      v18, s31
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s32, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 9: f8E5M2 -> f16
    s.addi       s32, s20, #288                  // row 9
    v.st.h       [s32, #0], v29
    s.addi       s32, s27, #10
    s.add        s33, s7, s32
    s.movz       s32, #10
    v.splat      v18, s32
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s33, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 10: f8E5M2 -> f16
    s.addi       s33, s20, #320                  // row 10
    v.st.h       [s33, #0], v29
    s.addi       s33, s27, #11
    s.add        s34, s7, s33
    s.movz       s33, #11
    v.splat      v18, s33
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s34, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 11: f8E5M2 -> f16
    s.addi       s34, s20, #352                  // row 11
    v.st.h       [s34, #0], v29
    s.addi       s34, s27, #12
    s.add        s35, s7, s34
    s.movz       s34, #12
    v.splat      v18, s34
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s35, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 12: f8E5M2 -> f16
    s.addi       s35, s20, #384                  // row 12
    v.st.h       [s35, #0], v29
    s.addi       s35, s27, #13
    s.add        s36, s7, s35
    s.movz       s35, #13
    v.splat      v18, s35
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s36, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 13: f8E5M2 -> f16
    s.addi       s36, s20, #416                  // row 13
    v.st.h       [s36, #0], v29
    s.addi       s36, s27, #14
    s.add        s37, s7, s36
    s.movz       s36, #14
    v.splat      v18, s36
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s37, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v29, v18                     // row 14: f8E5M2 -> f16
    s.addi       s37, s20, #448                  // row 14
    v.st.h       [s37, #0], v29
    s.addi       s37, s27, #15
    s.add        s38, s7, s37
    s.movz       s37, #15
    v.splat      v18, s37
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s38, v19]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 15: f8E5M2 -> f16
    s.addi       s38, s20, #480                  // row 15
    v.st.h       [s38, #0], v19
    s.addi       s38, s23, #9472                 // TensorMap 1: a repacked tile
    s.movz       s39, #0
    s.st.d       [s38, #0], s20
    s.movz       s20, #16
    s.st.d       [s38, #8], s20
    s.movz       s20, #16
    s.st.d       [s38, #16], s20
    s.movz       s20, #32
    s.st.d       [s38, #48], s20
    s.movz       s20, #2
    s.st.d       [s38, #56], s20
    .li       s20, #68719476752
    s.st.d       [s38, #88], s20
    .li       s20, #8589934592
    s.st.d       [s38, #104], s20
    td.load      d1, [s38]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s20, #0
    w.def        w1, #56, #8                     // v56..v63
    mb.arm       s38, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s39, s20                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s20                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s39, s38
    mb.wait      s38
    s.addi       s20, s23, #0
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #0
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #64
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #1
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #128
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #2
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #192
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #3
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #256
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #4
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #320
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #5
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #384
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #6
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #448
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #7
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #512
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #8
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #576
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #9
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #640
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #10
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #704
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #11
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #768
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #12
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #832
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #13
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #896
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #14
    a.vwrite     a8, s20, v18
    s.addi       s20, s23, #960
    v.ld.w       v18, [s20, #0]
    s.movz       s20, #15
    a.vwrite     a8, s20, v18
    mb.arm       s20, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.f16 a8, v48, v56, s20
    mb.wait      s20
    // E4M3 x E5M2: both operands as FP16 fragments, exactly (ISA sec 9C.1)
    s.addi       s39, s23, #9728                 // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.extract    s40, v27, #0
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 0: f8E4M3FN -> f16
    v.st.h       [s39, #0], v19
    v.extract    s40, v27, #1
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 1: f8E4M3FN -> f16
    s.addi       s40, s39, #32                   // row 1
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #2
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 2: f8E4M3FN -> f16
    s.addi       s40, s39, #64                   // row 2
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #3
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 3: f8E4M3FN -> f16
    s.addi       s40, s39, #96                   // row 3
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #4
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 4: f8E4M3FN -> f16
    s.addi       s40, s39, #128                  // row 4
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #5
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 5: f8E4M3FN -> f16
    s.addi       s40, s39, #160                  // row 5
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #6
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 6: f8E4M3FN -> f16
    s.addi       s40, s39, #192                  // row 6
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #7
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 7: f8E4M3FN -> f16
    s.addi       s40, s39, #224                  // row 7
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #8
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 8: f8E4M3FN -> f16
    s.addi       s40, s39, #256                  // row 8
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #9
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 9: f8E4M3FN -> f16
    s.addi       s40, s39, #288                  // row 9
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #10
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 10: f8E4M3FN -> f16
    s.addi       s40, s39, #320                  // row 10
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #11
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 11: f8E4M3FN -> f16
    s.addi       s40, s39, #352                  // row 11
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #12
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 12: f8E4M3FN -> f16
    s.addi       s40, s39, #384                  // row 12
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #13
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 13: f8E4M3FN -> f16
    s.addi       s40, s39, #416                  // row 13
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #14
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 14: f8E4M3FN -> f16
    s.addi       s40, s39, #448                  // row 14
    v.st.h       [s40, #0], v19
    v.extract    s40, v27, #15
    s.add        s41, s40, s26
    s.add        s40, s4, s41
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s40, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 15: f8E4M3FN -> f16
    s.addi       s40, s39, #480                  // row 15
    v.st.h       [s40, #0], v19
    s.addi       s40, s23, #10240                // TensorMap 2: a repacked tile
    s.movz       s41, #0
    s.st.d       [s40, #0], s39
    s.movz       s39, #16
    s.st.d       [s40, #8], s39
    s.movz       s39, #16
    s.st.d       [s40, #16], s39
    s.movz       s39, #32
    s.st.d       [s40, #48], s39
    s.movz       s39, #2
    s.st.d       [s40, #56], s39
    .li       s39, #68719476752
    s.st.d       [s40, #88], s39
    .li       s39, #8589934592
    s.st.d       [s40, #104], s39
    td.load      d2, [s40]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s39, #0
    w.def        w2, #48, #8                     // v48..v55
    mb.arm       s40, b3, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w2, d2, s41, s40
    mb.wait      s40
    s.addi       s39, s23, #10496                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.add        s41, s7, s27
    v.splat      v18, s1
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s41, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 0: f8E5M2 -> f16
    v.st.h       [s39, #0], v19
    s.addi       s41, s27, #1
    s.add        s42, s7, s41
    v.splat      v18, s14
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 1: f8E5M2 -> f16
    s.addi       s41, s39, #32                   // row 1
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #2
    s.add        s42, s7, s41
    v.splat      v18, s2
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 2: f8E5M2 -> f16
    s.addi       s41, s39, #64                   // row 2
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #3
    s.add        s42, s7, s41
    v.splat      v18, s24
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 3: f8E5M2 -> f16
    s.addi       s41, s39, #96                   // row 3
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #4
    s.add        s42, s7, s41
    v.splat      v18, s28
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 4: f8E5M2 -> f16
    s.addi       s41, s39, #128                  // row 4
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #5
    s.add        s42, s7, s41
    v.splat      v18, s29
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 5: f8E5M2 -> f16
    s.addi       s41, s39, #160                  // row 5
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #6
    s.add        s42, s7, s41
    v.splat      v18, s30
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 6: f8E5M2 -> f16
    s.addi       s41, s39, #192                  // row 6
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #7
    s.add        s42, s7, s41
    v.splat      v18, s13
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 7: f8E5M2 -> f16
    s.addi       s41, s39, #224                  // row 7
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #8
    s.add        s42, s7, s41
    v.splat      v18, s17
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 8: f8E5M2 -> f16
    s.addi       s41, s39, #256                  // row 8
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #9
    s.add        s42, s7, s41
    v.splat      v18, s31
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 9: f8E5M2 -> f16
    s.addi       s41, s39, #288                  // row 9
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #10
    s.add        s42, s7, s41
    v.splat      v18, s32
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 10: f8E5M2 -> f16
    s.addi       s41, s39, #320                  // row 10
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #11
    s.add        s42, s7, s41
    v.splat      v18, s33
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 11: f8E5M2 -> f16
    s.addi       s41, s39, #352                  // row 11
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #12
    s.add        s42, s7, s41
    v.splat      v18, s34
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 12: f8E5M2 -> f16
    s.addi       s41, s39, #384                  // row 12
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #13
    s.add        s42, s7, s41
    v.splat      v18, s35
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 13: f8E5M2 -> f16
    s.addi       s41, s39, #416                  // row 13
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #14
    s.add        s42, s7, s41
    v.splat      v18, s36
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 14: f8E5M2 -> f16
    s.addi       s41, s39, #448                  // row 14
    v.st.h       [s41, #0], v19
    s.addi       s41, s27, #15
    s.add        s42, s7, s41
    v.splat      v18, s37
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s42, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 15: f8E5M2 -> f16
    s.addi       s41, s39, #480                  // row 15
    v.st.h       [s41, #0], v19
    s.addi       s41, s23, #11008                // TensorMap 3: a repacked tile
    s.movz       s42, #0
    s.st.d       [s41, #0], s39
    s.movz       s39, #16
    s.st.d       [s41, #8], s39
    s.movz       s39, #16
    s.st.d       [s41, #16], s39
    s.movz       s39, #32
    s.st.d       [s41, #48], s39
    s.movz       s39, #2
    s.st.d       [s41, #56], s39
    .li       s39, #68719476752
    s.st.d       [s41, #88], s39
    .li       s39, #8589934592
    s.st.d       [s41, #104], s39
    td.load      d3, [s41]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s39, #0
    w.def        w3, #56, #8                     // v56..v63
    mb.arm       s41, b4, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w3, d3, s42, s41
    mb.wait      s41
    s.addi       s39, s23, #1024
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #0
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1088
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #1
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1152
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #2
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1216
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #3
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1280
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #4
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1344
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #5
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1408
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #6
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1472
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #7
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1536
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #8
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1600
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #9
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1664
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #10
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1728
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #11
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1792
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #12
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1856
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #13
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1920
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #14
    a.vwrite     a9, s39, v18
    s.addi       s39, s23, #1984
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #15
    a.vwrite     a9, s39, v18
    mb.arm       s39, b5, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.f16 a9, v48, v56, s39
    mb.wait      s39
    // E4M3 x E5M2: both operands as FP16 fragments, exactly (ISA sec 9C.1)
    s.addi       s42, s23, #11264                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.extract    s43, v27, #0
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 0: f8E4M3FN -> f16
    v.st.h       [s42, #0], v19
    v.extract    s43, v27, #1
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 1: f8E4M3FN -> f16
    s.addi       s43, s42, #32                   // row 1
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #2
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 2: f8E4M3FN -> f16
    s.addi       s43, s42, #64                   // row 2
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #3
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 3: f8E4M3FN -> f16
    s.addi       s43, s42, #96                   // row 3
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #4
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 4: f8E4M3FN -> f16
    s.addi       s43, s42, #128                  // row 4
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #5
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 5: f8E4M3FN -> f16
    s.addi       s43, s42, #160                  // row 5
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #6
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 6: f8E4M3FN -> f16
    s.addi       s43, s42, #192                  // row 6
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #7
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 7: f8E4M3FN -> f16
    s.addi       s43, s42, #224                  // row 7
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #8
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 8: f8E4M3FN -> f16
    s.addi       s43, s42, #256                  // row 8
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #9
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 9: f8E4M3FN -> f16
    s.addi       s43, s42, #288                  // row 9
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #10
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 10: f8E4M3FN -> f16
    s.addi       s43, s42, #320                  // row 10
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #11
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 11: f8E4M3FN -> f16
    s.addi       s43, s42, #352                  // row 11
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #12
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 12: f8E4M3FN -> f16
    s.addi       s43, s42, #384                  // row 12
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #13
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 13: f8E4M3FN -> f16
    s.addi       s43, s42, #416                  // row 13
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #14
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 14: f8E4M3FN -> f16
    s.addi       s43, s42, #448                  // row 14
    v.st.h       [s43, #0], v19
    v.extract    s43, v27, #15
    s.add        s44, s43, s26
    s.add        s43, s4, s44
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s43, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 15: f8E4M3FN -> f16
    s.addi       s43, s42, #480                  // row 15
    v.st.h       [s43, #0], v19
    s.addi       s43, s23, #11776                // TensorMap 4: a repacked tile
    s.movz       s44, #0
    s.st.d       [s43, #0], s42
    s.movz       s42, #16
    s.st.d       [s43, #8], s42
    s.movz       s42, #16
    s.st.d       [s43, #16], s42
    s.movz       s42, #32
    s.st.d       [s43, #48], s42
    s.movz       s42, #2
    s.st.d       [s43, #56], s42
    .li       s42, #68719476752
    s.st.d       [s43, #88], s42
    .li       s42, #8589934592
    s.st.d       [s43, #104], s42
    td.load      d4, [s43]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s42, #0
    w.def        w4, #48, #8                     // v48..v55
    mb.arm       s43, b6, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w4, d4, s44, s43
    mb.wait      s43
    s.addi       s42, s23, #12032                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.add        s44, s7, s27
    v.splat      v18, s1
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s44, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 0: f8E5M2 -> f16
    v.st.h       [s42, #0], v19
    s.addi       s44, s27, #1
    s.add        s45, s7, s44
    v.splat      v18, s14
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 1: f8E5M2 -> f16
    s.addi       s44, s42, #32                   // row 1
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #2
    s.add        s45, s7, s44
    v.splat      v18, s2
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 2: f8E5M2 -> f16
    s.addi       s44, s42, #64                   // row 2
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #3
    s.add        s45, s7, s44
    v.splat      v18, s24
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 3: f8E5M2 -> f16
    s.addi       s44, s42, #96                   // row 3
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #4
    s.add        s45, s7, s44
    v.splat      v18, s28
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 4: f8E5M2 -> f16
    s.addi       s44, s42, #128                  // row 4
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #5
    s.add        s45, s7, s44
    v.splat      v18, s29
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 5: f8E5M2 -> f16
    s.addi       s44, s42, #160                  // row 5
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #6
    s.add        s45, s7, s44
    v.splat      v18, s30
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 6: f8E5M2 -> f16
    s.addi       s44, s42, #192                  // row 6
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #7
    s.add        s45, s7, s44
    v.splat      v18, s13
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 7: f8E5M2 -> f16
    s.addi       s44, s42, #224                  // row 7
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #8
    s.add        s45, s7, s44
    v.splat      v18, s17
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 8: f8E5M2 -> f16
    s.addi       s44, s42, #256                  // row 8
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #9
    s.add        s45, s7, s44
    v.splat      v18, s31
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 9: f8E5M2 -> f16
    s.addi       s44, s42, #288                  // row 9
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #10
    s.add        s45, s7, s44
    v.splat      v18, s32
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 10: f8E5M2 -> f16
    s.addi       s44, s42, #320                  // row 10
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #11
    s.add        s45, s7, s44
    v.splat      v18, s33
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 11: f8E5M2 -> f16
    s.addi       s44, s42, #352                  // row 11
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #12
    s.add        s45, s7, s44
    v.splat      v18, s34
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 12: f8E5M2 -> f16
    s.addi       s44, s42, #384                  // row 12
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #13
    s.add        s45, s7, s44
    v.splat      v18, s35
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 13: f8E5M2 -> f16
    s.addi       s44, s42, #416                  // row 13
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #14
    s.add        s45, s7, s44
    v.splat      v18, s36
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 14: f8E5M2 -> f16
    s.addi       s44, s42, #448                  // row 14
    v.st.h       [s44, #0], v19
    s.addi       s44, s27, #15
    s.add        s45, s7, s44
    v.splat      v18, s37
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s45, v21]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 15: f8E5M2 -> f16
    s.addi       s44, s42, #480                  // row 15
    v.st.h       [s44, #0], v19
    s.addi       s44, s23, #12544                // TensorMap 5: a repacked tile
    s.movz       s45, #0
    s.st.d       [s44, #0], s42
    s.movz       s42, #16
    s.st.d       [s44, #8], s42
    s.movz       s42, #16
    s.st.d       [s44, #16], s42
    s.movz       s42, #32
    s.st.d       [s44, #48], s42
    s.movz       s42, #2
    s.st.d       [s44, #56], s42
    .li       s42, #68719476752
    s.st.d       [s44, #88], s42
    .li       s42, #8589934592
    s.st.d       [s44, #104], s42
    td.load      d5, [s44]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s42, #0
    w.def        w5, #56, #8                     // v56..v63
    mb.arm       s44, b7, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w5, d5, s45, s44
    mb.wait      s44
    s.addi       s42, s23, #2048
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #0
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2112
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #1
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2176
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #2
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2240
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #3
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2304
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #4
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2368
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #5
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2432
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #6
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2496
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #7
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2560
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #8
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2624
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #9
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2688
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #10
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2752
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #11
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2816
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #12
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2880
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #13
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #2944
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #14
    a.vwrite     a10, s42, v18
    s.addi       s42, s23, #3008
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #15
    a.vwrite     a10, s42, v18
    mb.arm       s42, b8, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.f16 a10, v48, v56, s42
    mb.wait      s42
    // E4M3 x E5M2: both operands as FP16 fragments, exactly (ISA sec 9C.1)
    s.addi       s45, s23, #12800                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.extract    s46, v27, #0
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 0: f8E4M3FN -> f16
    v.st.h       [s45, #0], v19
    v.extract    s46, v27, #1
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 1: f8E4M3FN -> f16
    s.addi       s46, s45, #32                   // row 1
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #2
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 2: f8E4M3FN -> f16
    s.addi       s46, s45, #64                   // row 2
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #3
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 3: f8E4M3FN -> f16
    s.addi       s46, s45, #96                   // row 3
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #4
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 4: f8E4M3FN -> f16
    s.addi       s46, s45, #128                  // row 4
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #5
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 5: f8E4M3FN -> f16
    s.addi       s46, s45, #160                  // row 5
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #6
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 6: f8E4M3FN -> f16
    s.addi       s46, s45, #192                  // row 6
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #7
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 7: f8E4M3FN -> f16
    s.addi       s46, s45, #224                  // row 7
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #8
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 8: f8E4M3FN -> f16
    s.addi       s46, s45, #256                  // row 8
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #9
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 9: f8E4M3FN -> f16
    s.addi       s46, s45, #288                  // row 9
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #10
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 10: f8E4M3FN -> f16
    s.addi       s46, s45, #320                  // row 10
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #11
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 11: f8E4M3FN -> f16
    s.addi       s46, s45, #352                  // row 11
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #12
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 12: f8E4M3FN -> f16
    s.addi       s46, s45, #384                  // row 12
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #13
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 13: f8E4M3FN -> f16
    s.addi       s46, s45, #416                  // row 13
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #14
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 14: f8E4M3FN -> f16
    s.addi       s46, s45, #448                  // row 14
    v.st.h       [s46, #0], v19
    v.extract    s46, v27, #15
    s.add        s47, s46, s26
    s.add        s46, s4, s47
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s46, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 15: f8E4M3FN -> f16
    s.addi       s46, s45, #480                  // row 15
    v.st.h       [s46, #0], v19
    s.addi       s46, s23, #13312                // TensorMap 6: a repacked tile
    s.movz       s47, #0
    s.st.d       [s46, #0], s45
    s.movz       s45, #16
    s.st.d       [s46, #8], s45
    s.movz       s45, #16
    s.st.d       [s46, #16], s45
    s.movz       s45, #32
    s.st.d       [s46, #48], s45
    s.movz       s45, #2
    s.st.d       [s46, #56], s45
    .li       s45, #68719476752
    s.st.d       [s46, #88], s45
    .li       s45, #8589934592
    s.st.d       [s46, #104], s45
    td.load      d6, [s46]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s45, #0
    w.def        w6, #48, #8                     // v48..v55
    mb.arm       s46, b9, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s47, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s45                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w6, d6, s47, s46
    mb.wait      s46
    s.addi       s45, s23, #13568                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.add        s47, s7, s27
    v.splat      v18, s1
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s47, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 0: f8E5M2 -> f16
    v.st.h       [s45, #0], v19
    s.addi       s47, s27, #1
    s.add        s48, s7, s47
    v.splat      v18, s14
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 1: f8E5M2 -> f16
    s.addi       s47, s45, #32                   // row 1
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #2
    s.add        s48, s7, s47
    v.splat      v18, s2
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 2: f8E5M2 -> f16
    s.addi       s47, s45, #64                   // row 2
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #3
    s.add        s48, s7, s47
    v.splat      v18, s24
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 3: f8E5M2 -> f16
    s.addi       s47, s45, #96                   // row 3
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #4
    s.add        s48, s7, s47
    v.splat      v18, s28
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 4: f8E5M2 -> f16
    s.addi       s47, s45, #128                  // row 4
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #5
    s.add        s48, s7, s47
    v.splat      v18, s29
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 5: f8E5M2 -> f16
    s.addi       s47, s45, #160                  // row 5
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #6
    s.add        s48, s7, s47
    v.splat      v18, s30
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 6: f8E5M2 -> f16
    s.addi       s47, s45, #192                  // row 6
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #7
    s.add        s48, s7, s47
    v.splat      v18, s13
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 7: f8E5M2 -> f16
    s.addi       s47, s45, #224                  // row 7
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #8
    s.add        s48, s7, s47
    v.splat      v18, s17
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 8: f8E5M2 -> f16
    s.addi       s47, s45, #256                  // row 8
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #9
    s.add        s48, s7, s47
    v.splat      v18, s31
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 9: f8E5M2 -> f16
    s.addi       s47, s45, #288                  // row 9
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #10
    s.add        s48, s7, s47
    v.splat      v18, s32
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 10: f8E5M2 -> f16
    s.addi       s47, s45, #320                  // row 10
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #11
    s.add        s48, s7, s47
    v.splat      v18, s33
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 11: f8E5M2 -> f16
    s.addi       s47, s45, #352                  // row 11
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #12
    s.add        s48, s7, s47
    v.splat      v18, s34
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 12: f8E5M2 -> f16
    s.addi       s47, s45, #384                  // row 12
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #13
    s.add        s48, s7, s47
    v.splat      v18, s35
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 13: f8E5M2 -> f16
    s.addi       s47, s45, #416                  // row 13
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #14
    s.add        s48, s7, s47
    v.splat      v18, s36
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 14: f8E5M2 -> f16
    s.addi       s47, s45, #448                  // row 14
    v.st.h       [s47, #0], v19
    s.addi       s47, s27, #15
    s.add        s48, s7, s47
    v.splat      v18, s37
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s48, v22]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 15: f8E5M2 -> f16
    s.addi       s47, s45, #480                  // row 15
    v.st.h       [s47, #0], v19
    s.addi       s47, s23, #14080                // TensorMap 7: a repacked tile
    s.movz       s48, #0
    s.st.d       [s47, #0], s45
    s.movz       s45, #16
    s.st.d       [s47, #8], s45
    s.movz       s45, #16
    s.st.d       [s47, #16], s45
    s.movz       s45, #32
    s.st.d       [s47, #48], s45
    s.movz       s45, #2
    s.st.d       [s47, #56], s45
    .li       s45, #68719476752
    s.st.d       [s47, #88], s45
    .li       s45, #8589934592
    s.st.d       [s47, #104], s45
    td.load      d7, [s47]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s45, #0
    w.def        w7, #56, #8                     // v56..v63
    mb.arm       s47, b10, #0, #1                // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s48, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w7, d7, s48, s47
    mb.wait      s47
    s.addi       s45, s23, #3072
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #0
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3136
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #1
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3200
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #2
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3264
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #3
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3328
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #4
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3392
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #5
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3456
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #6
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3520
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #7
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3584
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #8
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3648
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #9
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3712
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #10
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3776
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #11
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3840
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #12
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3904
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #13
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #3968
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #14
    a.vwrite     a11, s45, v18
    s.addi       s45, s23, #4032
    v.ld.w       v18, [s45, #0]
    s.movz       s45, #15
    a.vwrite     a11, s45, v18
    mb.arm       s45, b11, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.f16 a11, v48, v56, s45
    mb.wait      s45
    // E4M3 x E5M2: both operands as FP16 fragments, exactly (ISA sec 9C.1)
    s.addi       s48, s23, #14336                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.extract    s49, v27, #0
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 0: f8E4M3FN -> f16
    v.st.h       [s48, #0], v19
    v.extract    s49, v27, #1
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 1: f8E4M3FN -> f16
    s.addi       s49, s48, #32                   // row 1
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #2
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 2: f8E4M3FN -> f16
    s.addi       s49, s48, #64                   // row 2
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #3
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 3: f8E4M3FN -> f16
    s.addi       s49, s48, #96                   // row 3
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #4
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 4: f8E4M3FN -> f16
    s.addi       s49, s48, #128                  // row 4
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #5
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 5: f8E4M3FN -> f16
    s.addi       s49, s48, #160                  // row 5
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #6
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 6: f8E4M3FN -> f16
    s.addi       s49, s48, #192                  // row 6
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #7
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 7: f8E4M3FN -> f16
    s.addi       s49, s48, #224                  // row 7
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #8
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 8: f8E4M3FN -> f16
    s.addi       s49, s48, #256                  // row 8
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #9
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 9: f8E4M3FN -> f16
    s.addi       s49, s48, #288                  // row 9
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #10
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 10: f8E4M3FN -> f16
    s.addi       s49, s48, #320                  // row 10
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #11
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 11: f8E4M3FN -> f16
    s.addi       s49, s48, #352                  // row 11
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #12
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 12: f8E4M3FN -> f16
    s.addi       s49, s48, #384                  // row 12
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #13
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 13: f8E4M3FN -> f16
    s.addi       s49, s48, #416                  // row 13
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #14
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 14: f8E4M3FN -> f16
    s.addi       s49, s48, #448                  // row 14
    v.st.h       [s49, #0], v19
    v.extract    s49, v27, #15
    s.add        s50, s49, s26
    s.add        s49, s4, s50
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s49, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 15: f8E4M3FN -> f16
    s.addi       s49, s48, #480                  // row 15
    v.st.h       [s49, #0], v19
    s.addi       s49, s23, #14848                // TensorMap 8: a repacked tile
    s.movz       s50, #0
    s.st.d       [s49, #0], s48
    s.movz       s48, #16
    s.st.d       [s49, #8], s48
    s.movz       s48, #16
    s.st.d       [s49, #16], s48
    s.movz       s48, #32
    s.st.d       [s49, #48], s48
    s.movz       s48, #2
    s.st.d       [s49, #56], s48
    .li       s48, #68719476752
    s.st.d       [s49, #88], s48
    .li       s48, #8589934592
    s.st.d       [s49, #104], s48
    td.load      d8, [s49]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s48, #0
    w.def        w8, #48, #8                     // v48..v55
    mb.arm       s49, b12, #0, #1                // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s48                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w8, d8, s50, s49
    mb.wait      s49
    s.addi       s48, s23, #15104                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.add        s50, s7, s27
    v.splat      v18, s1
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s50, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 0: f8E5M2 -> f16
    v.st.h       [s48, #0], v19
    s.addi       s50, s27, #1
    s.add        s51, s7, s50
    v.splat      v18, s14
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 1: f8E5M2 -> f16
    s.addi       s50, s48, #32                   // row 1
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #2
    s.add        s51, s7, s50
    v.splat      v18, s2
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 2: f8E5M2 -> f16
    s.addi       s50, s48, #64                   // row 2
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #3
    s.add        s51, s7, s50
    v.splat      v18, s24
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 3: f8E5M2 -> f16
    s.addi       s50, s48, #96                   // row 3
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #4
    s.add        s51, s7, s50
    v.splat      v18, s28
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 4: f8E5M2 -> f16
    s.addi       s50, s48, #128                  // row 4
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #5
    s.add        s51, s7, s50
    v.splat      v18, s29
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 5: f8E5M2 -> f16
    s.addi       s50, s48, #160                  // row 5
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #6
    s.add        s51, s7, s50
    v.splat      v18, s30
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 6: f8E5M2 -> f16
    s.addi       s50, s48, #192                  // row 6
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #7
    s.add        s51, s7, s50
    v.splat      v18, s13
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 7: f8E5M2 -> f16
    s.addi       s50, s48, #224                  // row 7
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #8
    s.add        s51, s7, s50
    v.splat      v18, s17
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 8: f8E5M2 -> f16
    s.addi       s50, s48, #256                  // row 8
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #9
    s.add        s51, s7, s50
    v.splat      v18, s31
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 9: f8E5M2 -> f16
    s.addi       s50, s48, #288                  // row 9
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #10
    s.add        s51, s7, s50
    v.splat      v18, s32
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 10: f8E5M2 -> f16
    s.addi       s50, s48, #320                  // row 10
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #11
    s.add        s51, s7, s50
    v.splat      v18, s33
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 11: f8E5M2 -> f16
    s.addi       s50, s48, #352                  // row 11
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #12
    s.add        s51, s7, s50
    v.splat      v18, s34
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 12: f8E5M2 -> f16
    s.addi       s50, s48, #384                  // row 12
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #13
    s.add        s51, s7, s50
    v.splat      v18, s35
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 13: f8E5M2 -> f16
    s.addi       s50, s48, #416                  // row 13
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #14
    s.add        s51, s7, s50
    v.splat      v18, s36
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 14: f8E5M2 -> f16
    s.addi       s50, s48, #448                  // row 14
    v.st.h       [s50, #0], v19
    s.addi       s50, s27, #15
    s.add        s51, s7, s50
    v.splat      v18, s37
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s51, v23]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 15: f8E5M2 -> f16
    s.addi       s50, s48, #480                  // row 15
    v.st.h       [s50, #0], v19
    s.addi       s50, s23, #15616                // TensorMap 9: a repacked tile
    s.movz       s51, #0
    s.st.d       [s50, #0], s48
    s.movz       s48, #16
    s.st.d       [s50, #8], s48
    s.movz       s48, #16
    s.st.d       [s50, #16], s48
    s.movz       s48, #32
    s.st.d       [s50, #48], s48
    s.movz       s48, #2
    s.st.d       [s50, #56], s48
    .li       s48, #68719476752
    s.st.d       [s50, #88], s48
    .li       s48, #8589934592
    s.st.d       [s50, #104], s48
    td.load      d9, [s50]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s48, #0
    w.def        w9, #56, #8                     // v56..v63
    mb.arm       s50, b13, #0, #1                // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s51, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w9, d9, s51, s50
    mb.wait      s50
    s.addi       s48, s23, #4096
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #0
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4160
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #1
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4224
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #2
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4288
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #3
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4352
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #4
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4416
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #5
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4480
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #6
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4544
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #7
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4608
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #8
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4672
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #9
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4736
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #10
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4800
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #11
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4864
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #12
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4928
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #13
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #4992
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #14
    a.vwrite     a12, s48, v18
    s.addi       s48, s23, #5056
    v.ld.w       v18, [s48, #0]
    s.movz       s48, #15
    a.vwrite     a12, s48, v18
    mb.arm       s48, b14, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.f16 a12, v48, v56, s48
    mb.wait      s48
    // E4M3 x E5M2: both operands as FP16 fragments, exactly (ISA sec 9C.1)
    s.addi       s51, s23, #15872                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.extract    s52, v27, #0
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 0: f8E4M3FN -> f16
    v.st.h       [s51, #0], v19
    v.extract    s52, v27, #1
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 1: f8E4M3FN -> f16
    s.addi       s52, s51, #32                   // row 1
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #2
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 2: f8E4M3FN -> f16
    s.addi       s52, s51, #64                   // row 2
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #3
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 3: f8E4M3FN -> f16
    s.addi       s52, s51, #96                   // row 3
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #4
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 4: f8E4M3FN -> f16
    s.addi       s52, s51, #128                  // row 4
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #5
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 5: f8E4M3FN -> f16
    s.addi       s52, s51, #160                  // row 5
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #6
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 6: f8E4M3FN -> f16
    s.addi       s52, s51, #192                  // row 6
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #7
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 7: f8E4M3FN -> f16
    s.addi       s52, s51, #224                  // row 7
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #8
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 8: f8E4M3FN -> f16
    s.addi       s52, s51, #256                  // row 8
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #9
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 9: f8E4M3FN -> f16
    s.addi       s52, s51, #288                  // row 9
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #10
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 10: f8E4M3FN -> f16
    s.addi       s52, s51, #320                  // row 10
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #11
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 11: f8E4M3FN -> f16
    s.addi       s52, s51, #352                  // row 11
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #12
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 12: f8E4M3FN -> f16
    s.addi       s52, s51, #384                  // row 12
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #13
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 13: f8E4M3FN -> f16
    s.addi       s52, s51, #416                  // row 13
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #14
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 14: f8E4M3FN -> f16
    s.addi       s52, s51, #448                  // row 14
    v.st.h       [s52, #0], v19
    v.extract    s52, v27, #15
    s.add        s53, s52, s26
    s.add        s52, s4, s53
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s52, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 15: f8E4M3FN -> f16
    s.addi       s52, s51, #480                  // row 15
    v.st.h       [s52, #0], v19
    s.addi       s52, s23, #16384                // TensorMap 10: a repacked tile
    s.movz       s53, #0
    s.st.d       [s52, #0], s51
    s.movz       s51, #16
    s.st.d       [s52, #8], s51
    s.movz       s51, #16
    s.st.d       [s52, #16], s51
    s.movz       s51, #32
    s.st.d       [s52, #48], s51
    s.movz       s51, #2
    s.st.d       [s52, #56], s51
    .li       s51, #68719476752
    s.st.d       [s52, #88], s51
    .li       s51, #8589934592
    s.st.d       [s52, #104], s51
    td.load      d10, [s52]                      // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s51, #0
    w.def        w10, #48, #8                    // v48..v55
    mb.arm       s52, b15, #0, #1                // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s51                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w10, d10, s53, s52
    mb.wait      s52
    s.addi       s51, s23, #16640                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.add        s53, s7, s27
    v.splat      v18, s1
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s53, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 0: f8E5M2 -> f16
    v.st.h       [s51, #0], v19
    s.addi       s53, s27, #1
    s.add        s54, s7, s53
    v.splat      v18, s14
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 1: f8E5M2 -> f16
    s.addi       s53, s51, #32                   // row 1
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #2
    s.add        s54, s7, s53
    v.splat      v18, s2
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 2: f8E5M2 -> f16
    s.addi       s53, s51, #64                   // row 2
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #3
    s.add        s54, s7, s53
    v.splat      v18, s24
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 3: f8E5M2 -> f16
    s.addi       s53, s51, #96                   // row 3
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #4
    s.add        s54, s7, s53
    v.splat      v18, s28
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 4: f8E5M2 -> f16
    s.addi       s53, s51, #128                  // row 4
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #5
    s.add        s54, s7, s53
    v.splat      v18, s29
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 5: f8E5M2 -> f16
    s.addi       s53, s51, #160                  // row 5
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #6
    s.add        s54, s7, s53
    v.splat      v18, s30
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 6: f8E5M2 -> f16
    s.addi       s53, s51, #192                  // row 6
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #7
    s.add        s54, s7, s53
    v.splat      v18, s13
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 7: f8E5M2 -> f16
    s.addi       s53, s51, #224                  // row 7
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #8
    s.add        s54, s7, s53
    v.splat      v18, s17
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 8: f8E5M2 -> f16
    s.addi       s53, s51, #256                  // row 8
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #9
    s.add        s54, s7, s53
    v.splat      v18, s31
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 9: f8E5M2 -> f16
    s.addi       s53, s51, #288                  // row 9
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #10
    s.add        s54, s7, s53
    v.splat      v18, s32
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 10: f8E5M2 -> f16
    s.addi       s53, s51, #320                  // row 10
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #11
    s.add        s54, s7, s53
    v.splat      v18, s33
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 11: f8E5M2 -> f16
    s.addi       s53, s51, #352                  // row 11
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #12
    s.add        s54, s7, s53
    v.splat      v18, s34
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 12: f8E5M2 -> f16
    s.addi       s53, s51, #384                  // row 12
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #13
    s.add        s54, s7, s53
    v.splat      v18, s35
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 13: f8E5M2 -> f16
    s.addi       s53, s51, #416                  // row 13
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #14
    s.add        s54, s7, s53
    v.splat      v18, s36
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 14: f8E5M2 -> f16
    s.addi       s53, s51, #448                  // row 14
    v.st.h       [s53, #0], v19
    s.addi       s53, s27, #15
    s.add        s54, s7, s53
    v.splat      v18, s37
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s54, v24]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 15: f8E5M2 -> f16
    s.addi       s53, s51, #480                  // row 15
    v.st.h       [s53, #0], v19
    s.addi       s53, s23, #17152                // TensorMap 11: a repacked tile
    s.movz       s54, #0
    s.st.d       [s53, #0], s51
    s.movz       s51, #16
    s.st.d       [s53, #8], s51
    s.movz       s51, #16
    s.st.d       [s53, #16], s51
    s.movz       s51, #32
    s.st.d       [s53, #48], s51
    s.movz       s51, #2
    s.st.d       [s53, #56], s51
    .li       s51, #68719476752
    s.st.d       [s53, #88], s51
    .li       s51, #8589934592
    s.st.d       [s53, #104], s51
    td.load      d11, [s53]                      // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s51, #0
    w.def        w11, #56, #8                    // v56..v63
    mb.arm       s53, b16, #0, #1                // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s54, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w11, d11, s54, s53
    mb.wait      s53
    s.addi       s51, s23, #5120
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #0
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5184
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #1
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5248
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #2
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5312
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #3
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5376
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #4
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5440
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #5
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5504
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #6
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5568
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #7
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5632
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #8
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5696
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #9
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5760
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #10
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5824
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #11
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5888
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #12
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #5952
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #13
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #6016
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #14
    a.vwrite     a13, s51, v18
    s.addi       s51, s23, #6080
    v.ld.w       v18, [s51, #0]
    s.movz       s51, #15
    a.vwrite     a13, s51, v18
    mb.arm       s51, b17, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.f16 a13, v48, v56, s51
    mb.wait      s51
    // E4M3 x E5M2: both operands as FP16 fragments, exactly (ISA sec 9C.1)
    s.addi       s54, s23, #17408                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.extract    s55, v27, #0
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 0: f8E4M3FN -> f16
    v.st.h       [s54, #0], v19
    v.extract    s55, v27, #1
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 1: f8E4M3FN -> f16
    s.addi       s55, s54, #32                   // row 1
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #2
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 2: f8E4M3FN -> f16
    s.addi       s55, s54, #64                   // row 2
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #3
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 3: f8E4M3FN -> f16
    s.addi       s55, s54, #96                   // row 3
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #4
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 4: f8E4M3FN -> f16
    s.addi       s55, s54, #128                  // row 4
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #5
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 5: f8E4M3FN -> f16
    s.addi       s55, s54, #160                  // row 5
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #6
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 6: f8E4M3FN -> f16
    s.addi       s55, s54, #192                  // row 6
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #7
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 7: f8E4M3FN -> f16
    s.addi       s55, s54, #224                  // row 7
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #8
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 8: f8E4M3FN -> f16
    s.addi       s55, s54, #256                  // row 8
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #9
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 9: f8E4M3FN -> f16
    s.addi       s55, s54, #288                  // row 9
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #10
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 10: f8E4M3FN -> f16
    s.addi       s55, s54, #320                  // row 10
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #11
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 11: f8E4M3FN -> f16
    s.addi       s55, s54, #352                  // row 11
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #12
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 12: f8E4M3FN -> f16
    s.addi       s55, s54, #384                  // row 12
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #13
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 13: f8E4M3FN -> f16
    s.addi       s55, s54, #416                  // row 13
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #14
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 14: f8E4M3FN -> f16
    s.addi       s55, s54, #448                  // row 14
    v.st.h       [s55, #0], v19
    v.extract    s55, v27, #15
    s.add        s56, s55, s26
    s.add        s55, s4, s56
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s55, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 15: f8E4M3FN -> f16
    s.addi       s55, s54, #480                  // row 15
    v.st.h       [s55, #0], v19
    s.addi       s55, s23, #17920                // TensorMap 12: a repacked tile
    s.movz       s56, #0
    s.st.d       [s55, #0], s54
    s.movz       s54, #16
    s.st.d       [s55, #8], s54
    s.movz       s54, #16
    s.st.d       [s55, #16], s54
    s.movz       s54, #32
    s.st.d       [s55, #48], s54
    s.movz       s54, #2
    s.st.d       [s55, #56], s54
    .li       s54, #68719476752
    s.st.d       [s55, #88], s54
    .li       s54, #8589934592
    s.st.d       [s55, #104], s54
    td.load      d12, [s55]                      // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s54, #0
    w.def        w12, #48, #8                    // v48..v55
    mb.arm       s55, b18, #0, #1                // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s54                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w12, d12, s56, s55
    mb.wait      s55
    s.addi       s54, s23, #18176                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.add        s56, s7, s27
    v.splat      v18, s1
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s56, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 0: f8E5M2 -> f16
    v.st.h       [s54, #0], v19
    s.addi       s56, s27, #1
    s.add        s57, s7, s56
    v.splat      v18, s14
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 1: f8E5M2 -> f16
    s.addi       s56, s54, #32                   // row 1
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #2
    s.add        s57, s7, s56
    v.splat      v18, s2
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 2: f8E5M2 -> f16
    s.addi       s56, s54, #64                   // row 2
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #3
    s.add        s57, s7, s56
    v.splat      v18, s24
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 3: f8E5M2 -> f16
    s.addi       s56, s54, #96                   // row 3
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #4
    s.add        s57, s7, s56
    v.splat      v18, s28
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 4: f8E5M2 -> f16
    s.addi       s56, s54, #128                  // row 4
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #5
    s.add        s57, s7, s56
    v.splat      v18, s29
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 5: f8E5M2 -> f16
    s.addi       s56, s54, #160                  // row 5
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #6
    s.add        s57, s7, s56
    v.splat      v18, s30
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 6: f8E5M2 -> f16
    s.addi       s56, s54, #192                  // row 6
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #7
    s.add        s57, s7, s56
    v.splat      v18, s13
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 7: f8E5M2 -> f16
    s.addi       s56, s54, #224                  // row 7
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #8
    s.add        s57, s7, s56
    v.splat      v18, s17
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 8: f8E5M2 -> f16
    s.addi       s56, s54, #256                  // row 8
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #9
    s.add        s57, s7, s56
    v.splat      v18, s31
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 9: f8E5M2 -> f16
    s.addi       s56, s54, #288                  // row 9
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #10
    s.add        s57, s7, s56
    v.splat      v18, s32
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 10: f8E5M2 -> f16
    s.addi       s56, s54, #320                  // row 10
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #11
    s.add        s57, s7, s56
    v.splat      v18, s33
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 11: f8E5M2 -> f16
    s.addi       s56, s54, #352                  // row 11
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #12
    s.add        s57, s7, s56
    v.splat      v18, s34
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 12: f8E5M2 -> f16
    s.addi       s56, s54, #384                  // row 12
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #13
    s.add        s57, s7, s56
    v.splat      v18, s35
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 13: f8E5M2 -> f16
    s.addi       s56, s54, #416                  // row 13
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #14
    s.add        s57, s7, s56
    v.splat      v18, s36
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 14: f8E5M2 -> f16
    s.addi       s56, s54, #448                  // row 14
    v.st.h       [s56, #0], v19
    s.addi       s56, s27, #15
    s.add        s57, s7, s56
    v.splat      v18, s37
    v.cmp.lt     p2, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.b v18, [s57, v25]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 15: f8E5M2 -> f16
    s.addi       s56, s54, #480                  // row 15
    v.st.h       [s56, #0], v19
    s.addi       s56, s23, #18688                // TensorMap 13: a repacked tile
    s.movz       s57, #0
    s.st.d       [s56, #0], s54
    s.movz       s54, #16
    s.st.d       [s56, #8], s54
    s.movz       s54, #16
    s.st.d       [s56, #16], s54
    s.movz       s54, #32
    s.st.d       [s56, #48], s54
    s.movz       s54, #2
    s.st.d       [s56, #56], s54
    .li       s54, #68719476752
    s.st.d       [s56, #88], s54
    .li       s54, #8589934592
    s.st.d       [s56, #104], s54
    td.load      d13, [s56]                      // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s54, #0
    w.def        w13, #56, #8                    // v56..v63
    mb.arm       s56, b19, #0, #1                // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s57, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w13, d13, s57, s56
    mb.wait      s56
    s.addi       s54, s23, #6144
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #0
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6208
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #1
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6272
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #2
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6336
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #3
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6400
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #4
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6464
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #5
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6528
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #6
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6592
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #7
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6656
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #8
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6720
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #9
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6784
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #10
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6848
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #11
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6912
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #12
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #6976
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #13
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #7040
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #14
    a.vwrite     a14, s54, v18
    s.addi       s54, s23, #7104
    v.ld.w       v18, [s54, #0]
    s.movz       s54, #15
    a.vwrite     a14, s54, v18
    mb.arm       s54, b20, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.f16 a14, v48, v56, s54
    mb.wait      s54
    // E4M3 x E5M2: both operands as FP16 fragments, exactly (ISA sec 9C.1)
    s.addi       s57, s23, #18944                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.extract    s58, v27, #0
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 0: f8E4M3FN -> f16
    v.st.h       [s57, #0], v19
    v.extract    s58, v27, #1
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 1: f8E4M3FN -> f16
    s.addi       s58, s57, #32                   // row 1
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #2
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 2: f8E4M3FN -> f16
    s.addi       s58, s57, #64                   // row 2
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #3
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 3: f8E4M3FN -> f16
    s.addi       s58, s57, #96                   // row 3
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #4
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 4: f8E4M3FN -> f16
    s.addi       s58, s57, #128                  // row 4
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #5
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 5: f8E4M3FN -> f16
    s.addi       s58, s57, #160                  // row 5
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #6
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 6: f8E4M3FN -> f16
    s.addi       s58, s57, #192                  // row 6
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #7
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 7: f8E4M3FN -> f16
    s.addi       s58, s57, #224                  // row 7
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #8
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 8: f8E4M3FN -> f16
    s.addi       s58, s57, #256                  // row 8
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #9
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 9: f8E4M3FN -> f16
    s.addi       s58, s57, #288                  // row 9
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #10
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 10: f8E4M3FN -> f16
    s.addi       s58, s57, #320                  // row 10
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #11
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 11: f8E4M3FN -> f16
    s.addi       s58, s57, #352                  // row 11
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #12
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 12: f8E4M3FN -> f16
    s.addi       s58, s57, #384                  // row 12
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #13
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 13: f8E4M3FN -> f16
    s.addi       s58, s57, #416                  // row 13
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #14
    s.add        s59, s58, s26
    s.add        s58, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s58, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 14: f8E4M3FN -> f16
    s.addi       s58, s57, #448                  // row 14
    v.st.h       [s58, #0], v19
    v.extract    s58, v27, #15
    s.add        s59, s58, s26
    s.add        s26, s4, s59
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v18, [s26, #0]
    vf.cvt.e4m3.f16 v19, v18                     // row 15: f8E4M3FN -> f16
    s.addi       s26, s57, #480                  // row 15
    v.st.h       [s26, #0], v19
    s.addi       s26, s23, #19456                // TensorMap 14: a repacked tile
    s.movz       s58, #0
    s.st.d       [s26, #0], s57
    s.movz       s57, #16
    s.st.d       [s26, #8], s57
    s.movz       s57, #16
    s.st.d       [s26, #16], s57
    s.movz       s57, #32
    s.st.d       [s26, #48], s57
    s.movz       s57, #2
    s.st.d       [s26, #56], s57
    .li       s57, #68719476752
    s.st.d       [s26, #88], s57
    .li       s57, #8589934592
    s.st.d       [s26, #104], s57
    td.load      d14, [s26]                      // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s26, #0
    w.def        w14, #48, #8                    // v48..v55
    mb.arm       s57, b21, #0, #1                // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s58, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s26                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w14, d14, s58, s57
    mb.wait      s57
    s.addi       s26, s23, #19712                // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.add        s58, s7, s27
    v.splat      v18, s1
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s58, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 0: f8E5M2 -> f16
    v.st.h       [s26, #0], v19
    s.addi       s58, s27, #1
    s.add        s59, s7, s58
    v.splat      v18, s14
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s59, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 1: f8E5M2 -> f16
    s.addi       s58, s26, #32                   // row 1
    v.st.h       [s58, #0], v19
    s.addi       s58, s27, #2
    s.add        s59, s7, s58
    v.splat      v18, s2
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s59, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 2: f8E5M2 -> f16
    s.addi       s58, s26, #64                   // row 2
    v.st.h       [s58, #0], v19
    s.addi       s58, s27, #3
    s.add        s59, s7, s58
    v.splat      v18, s24
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s59, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 3: f8E5M2 -> f16
    s.addi       s24, s26, #96                   // row 3
    v.st.h       [s24, #0], v19
    s.addi       s24, s27, #4
    s.add        s58, s7, s24
    v.splat      v18, s28
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s58, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 4: f8E5M2 -> f16
    s.addi       s24, s26, #128                  // row 4
    v.st.h       [s24, #0], v19
    s.addi       s24, s27, #5
    s.add        s28, s7, s24
    v.splat      v18, s29
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s28, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 5: f8E5M2 -> f16
    s.addi       s24, s26, #160                  // row 5
    v.st.h       [s24, #0], v19
    s.addi       s24, s27, #6
    s.add        s28, s7, s24
    v.splat      v18, s30
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s28, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 6: f8E5M2 -> f16
    s.addi       s24, s26, #192                  // row 6
    v.st.h       [s24, #0], v19
    s.addi       s24, s27, #7
    s.add        s28, s7, s24
    v.splat      v18, s13
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s28, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 7: f8E5M2 -> f16
    s.addi       s24, s26, #224                  // row 7
    v.st.h       [s24, #0], v19
    s.addi       s24, s27, #8
    s.add        s28, s7, s24
    v.splat      v18, s17
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s28, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 8: f8E5M2 -> f16
    s.addi       s24, s26, #256                  // row 8
    v.st.h       [s24, #0], v19
    s.addi       s24, s27, #9
    s.add        s28, s7, s24
    v.splat      v18, s31
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s28, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 9: f8E5M2 -> f16
    s.addi       s24, s26, #288                  // row 9
    v.st.h       [s24, #0], v19
    s.addi       s24, s27, #10
    s.add        s28, s7, s24
    v.splat      v18, s32
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s28, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 10: f8E5M2 -> f16
    s.addi       s24, s26, #320                  // row 10
    v.st.h       [s24, #0], v19
    s.addi       s24, s27, #11
    s.add        s28, s7, s24
    v.splat      v18, s33
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s28, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 11: f8E5M2 -> f16
    s.addi       s24, s26, #352                  // row 11
    v.st.h       [s24, #0], v19
    s.addi       s24, s27, #12
    s.add        s28, s7, s24
    v.splat      v18, s34
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s28, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 12: f8E5M2 -> f16
    s.addi       s24, s26, #384                  // row 12
    v.st.h       [s24, #0], v19
    s.addi       s24, s27, #13
    s.add        s28, s7, s24
    v.splat      v18, s35
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s28, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 13: f8E5M2 -> f16
    s.addi       s24, s26, #416                  // row 13
    v.st.h       [s24, #0], v19
    s.addi       s24, s27, #14
    s.add        s28, s7, s24
    v.splat      v18, s36
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s28, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 14: f8E5M2 -> f16
    s.addi       s24, s26, #448                  // row 14
    v.st.h       [s24, #0], v19
    s.addi       s24, s27, #15
    s.add        s27, s7, s24
    v.splat      v18, s37
    v.cmp.lt     p1, v18, v28
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v18, [s27, v26]            // index is in elements (ISA sec 9.1)
    vf.cvt.e5m2.f16 v19, v18                     // row 15: f8E5M2 -> f16
    s.addi       s24, s26, #480                  // row 15
    v.st.h       [s24, #0], v19
    s.addi       s24, s23, #20224                // TensorMap 15: a repacked tile
    s.movz       s27, #0
    s.st.d       [s24, #0], s26
    s.movz       s26, #16
    s.st.d       [s24, #8], s26
    s.movz       s26, #16
    s.st.d       [s24, #16], s26
    s.movz       s26, #32
    s.st.d       [s24, #48], s26
    s.movz       s26, #2
    s.st.d       [s24, #56], s26
    .li       s26, #68719476752
    s.st.d       [s24, #88], s26
    .li       s26, #8589934592
    s.st.d       [s24, #104], s26
    td.load      d15, [s24]                      // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s24, #0
    w.def        w15, #56, #8                    // v56..v63
    mb.arm       s26, b22, #0, #1                // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s27, s24                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s24                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w15, d15, s27, s26
    mb.wait      s26
    s.addi       s24, s23, #7168
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #0
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #7232
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #1
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #7296
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #2
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #7360
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #3
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #7424
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #4
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #7488
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #5
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #7552
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #6
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #7616
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #7
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #7680
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #8
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #7744
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #9
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #7808
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #10
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #7872
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #11
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #7936
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #12
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #8000
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #13
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #8064
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #14
    a.vwrite     a15, s24, v18
    s.addi       s24, s23, #8128
    v.ld.w       v18, [s24, #0]
    s.movz       s24, #15
    a.vwrite     a15, s24, v18
    mb.arm       s24, b23, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.f16 a15, v48, v56, s24
    mb.wait      s24
    s.addi       s27, s23, #20480
    s.movz       s28, #0
    a.vread      v18, a8, s28
    v.st.w       [s27, #0], v18
    s.addi       s28, s27, #64
    s.movz       s29, #1
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #128
    s.movz       s29, #2
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #192
    s.movz       s29, #3
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #256
    s.movz       s29, #4
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #320
    s.movz       s29, #5
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #384
    s.movz       s29, #6
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #448
    s.movz       s29, #7
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #512
    s.movz       s29, #8
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #576
    s.movz       s29, #9
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #640
    s.movz       s29, #10
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #704
    s.movz       s29, #11
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #768
    s.movz       s29, #12
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #832
    s.movz       s29, #13
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #896
    s.movz       s29, #14
    a.vread      v18, a8, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #960
    s.movz       s27, #15
    a.vread      v18, a8, s27
    v.st.w       [s28, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #21504
    s.movz       s28, #0
    a.vread      v18, a9, s28
    v.st.w       [s27, #0], v18
    s.addi       s28, s27, #64
    s.movz       s29, #1
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #128
    s.movz       s29, #2
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #192
    s.movz       s29, #3
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #256
    s.movz       s29, #4
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #320
    s.movz       s29, #5
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #384
    s.movz       s29, #6
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #448
    s.movz       s29, #7
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #512
    s.movz       s29, #8
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #576
    s.movz       s29, #9
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #640
    s.movz       s29, #10
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #704
    s.movz       s29, #11
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #768
    s.movz       s29, #12
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #832
    s.movz       s29, #13
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #896
    s.movz       s29, #14
    a.vread      v18, a9, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #960
    s.movz       s27, #15
    a.vread      v18, a9, s27
    v.st.w       [s28, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #22528
    s.movz       s28, #0
    a.vread      v18, a10, s28
    v.st.w       [s27, #0], v18
    s.addi       s28, s27, #64
    s.movz       s29, #1
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #128
    s.movz       s29, #2
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #192
    s.movz       s29, #3
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #256
    s.movz       s29, #4
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #320
    s.movz       s29, #5
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #384
    s.movz       s29, #6
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #448
    s.movz       s29, #7
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #512
    s.movz       s29, #8
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #576
    s.movz       s29, #9
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #640
    s.movz       s29, #10
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #704
    s.movz       s29, #11
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #768
    s.movz       s29, #12
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #832
    s.movz       s29, #13
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #896
    s.movz       s29, #14
    a.vread      v18, a10, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #960
    s.movz       s27, #15
    a.vread      v18, a10, s27
    v.st.w       [s28, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #23552
    s.movz       s28, #0
    a.vread      v18, a11, s28
    v.st.w       [s27, #0], v18
    s.addi       s28, s27, #64
    s.movz       s29, #1
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #128
    s.movz       s29, #2
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #192
    s.movz       s29, #3
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #256
    s.movz       s29, #4
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #320
    s.movz       s29, #5
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #384
    s.movz       s29, #6
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #448
    s.movz       s29, #7
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #512
    s.movz       s29, #8
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #576
    s.movz       s29, #9
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #640
    s.movz       s29, #10
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #704
    s.movz       s29, #11
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #768
    s.movz       s29, #12
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #832
    s.movz       s29, #13
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #896
    s.movz       s29, #14
    a.vread      v18, a11, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #960
    s.movz       s27, #15
    a.vread      v18, a11, s27
    v.st.w       [s28, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #24576
    s.movz       s28, #0
    a.vread      v18, a12, s28
    v.st.w       [s27, #0], v18
    s.addi       s28, s27, #64
    s.movz       s29, #1
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #128
    s.movz       s29, #2
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #192
    s.movz       s29, #3
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #256
    s.movz       s29, #4
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #320
    s.movz       s29, #5
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #384
    s.movz       s29, #6
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #448
    s.movz       s29, #7
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #512
    s.movz       s29, #8
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #576
    s.movz       s29, #9
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #640
    s.movz       s29, #10
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #704
    s.movz       s29, #11
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #768
    s.movz       s29, #12
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #832
    s.movz       s29, #13
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #896
    s.movz       s29, #14
    a.vread      v18, a12, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #960
    s.movz       s27, #15
    a.vread      v18, a12, s27
    v.st.w       [s28, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #25600
    s.movz       s28, #0
    a.vread      v18, a13, s28
    v.st.w       [s27, #0], v18
    s.addi       s28, s27, #64
    s.movz       s29, #1
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #128
    s.movz       s29, #2
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #192
    s.movz       s29, #3
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #256
    s.movz       s29, #4
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #320
    s.movz       s29, #5
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #384
    s.movz       s29, #6
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #448
    s.movz       s29, #7
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #512
    s.movz       s29, #8
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #576
    s.movz       s29, #9
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #640
    s.movz       s29, #10
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #704
    s.movz       s29, #11
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #768
    s.movz       s29, #12
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #832
    s.movz       s29, #13
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #896
    s.movz       s29, #14
    a.vread      v18, a13, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #960
    s.movz       s27, #15
    a.vread      v18, a13, s27
    v.st.w       [s28, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #26624
    s.movz       s28, #0
    a.vread      v18, a14, s28
    v.st.w       [s27, #0], v18
    s.addi       s28, s27, #64
    s.movz       s29, #1
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #128
    s.movz       s29, #2
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #192
    s.movz       s29, #3
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #256
    s.movz       s29, #4
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #320
    s.movz       s29, #5
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #384
    s.movz       s29, #6
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #448
    s.movz       s29, #7
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #512
    s.movz       s29, #8
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #576
    s.movz       s29, #9
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #640
    s.movz       s29, #10
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #704
    s.movz       s29, #11
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #768
    s.movz       s29, #12
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #832
    s.movz       s29, #13
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #896
    s.movz       s29, #14
    a.vread      v18, a14, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #960
    s.movz       s27, #15
    a.vread      v18, a14, s27
    v.st.w       [s28, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #27648
    s.movz       s28, #0
    a.vread      v18, a15, s28
    v.st.w       [s27, #0], v18
    s.addi       s28, s27, #64
    s.movz       s29, #1
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #128
    s.movz       s29, #2
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #192
    s.movz       s29, #3
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #256
    s.movz       s29, #4
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #320
    s.movz       s29, #5
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #384
    s.movz       s29, #6
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #448
    s.movz       s29, #7
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #512
    s.movz       s29, #8
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #576
    s.movz       s29, #9
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #640
    s.movz       s29, #10
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #704
    s.movz       s29, #11
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #768
    s.movz       s29, #12
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #832
    s.movz       s29, #13
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #896
    s.movz       s29, #14
    a.vread      v18, a15, s29
    v.st.w       [s28, #0], v18
    s.addi       s28, s27, #960
    s.movz       s27, #15
    a.vread      v18, a15, s27
    v.st.w       [s28, #0], v18
    fence.acq_rel.device
    s.addi       s27, s21, #16
    s.addi       s28, s27, #0
    s.addi       s27, s22, #16
    s.addi       s29, s27, #0
    s.mov        s21, s28
    s.mov        s22, s29
    s.addi       s27, s23, #0
    s.addi       s28, s23, #20480
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #64
    s.addi       s28, s23, #20544
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #128
    s.addi       s28, s23, #20608
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #192
    s.addi       s28, s23, #20672
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #256
    s.addi       s28, s23, #20736
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #320
    s.addi       s28, s23, #20800
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #384
    s.addi       s28, s23, #20864
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #448
    s.addi       s28, s23, #20928
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #512
    s.addi       s28, s23, #20992
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #576
    s.addi       s28, s23, #21056
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #640
    s.addi       s28, s23, #21120
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #704
    s.addi       s28, s23, #21184
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #768
    s.addi       s28, s23, #21248
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #832
    s.addi       s28, s23, #21312
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #896
    s.addi       s28, s23, #21376
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #960
    s.addi       s28, s23, #21440
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #1024
    s.addi       s28, s23, #21504
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1088
    s.addi       s28, s23, #21568
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1152
    s.addi       s28, s23, #21632
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1216
    s.addi       s28, s23, #21696
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1280
    s.addi       s28, s23, #21760
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1344
    s.addi       s28, s23, #21824
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1408
    s.addi       s28, s23, #21888
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1472
    s.addi       s28, s23, #21952
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1536
    s.addi       s28, s23, #22016
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1600
    s.addi       s28, s23, #22080
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1664
    s.addi       s28, s23, #22144
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1728
    s.addi       s28, s23, #22208
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1792
    s.addi       s28, s23, #22272
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1856
    s.addi       s28, s23, #22336
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1920
    s.addi       s28, s23, #22400
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #1984
    s.addi       s28, s23, #22464
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #2048
    s.addi       s28, s23, #22528
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2112
    s.addi       s28, s23, #22592
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2176
    s.addi       s28, s23, #22656
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2240
    s.addi       s28, s23, #22720
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2304
    s.addi       s28, s23, #22784
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2368
    s.addi       s28, s23, #22848
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2432
    s.addi       s28, s23, #22912
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2496
    s.addi       s28, s23, #22976
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2560
    s.addi       s28, s23, #23040
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2624
    s.addi       s28, s23, #23104
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2688
    s.addi       s28, s23, #23168
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2752
    s.addi       s28, s23, #23232
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2816
    s.addi       s28, s23, #23296
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2880
    s.addi       s28, s23, #23360
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #2944
    s.addi       s28, s23, #23424
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3008
    s.addi       s28, s23, #23488
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #3072
    s.addi       s28, s23, #23552
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3136
    s.addi       s28, s23, #23616
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3200
    s.addi       s28, s23, #23680
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3264
    s.addi       s28, s23, #23744
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3328
    s.addi       s28, s23, #23808
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3392
    s.addi       s28, s23, #23872
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3456
    s.addi       s28, s23, #23936
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3520
    s.addi       s28, s23, #24000
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3584
    s.addi       s28, s23, #24064
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3648
    s.addi       s28, s23, #24128
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3712
    s.addi       s28, s23, #24192
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3776
    s.addi       s28, s23, #24256
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3840
    s.addi       s28, s23, #24320
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3904
    s.addi       s28, s23, #24384
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #3968
    s.addi       s28, s23, #24448
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4032
    s.addi       s28, s23, #24512
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #4096
    s.addi       s28, s23, #24576
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4160
    s.addi       s28, s23, #24640
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4224
    s.addi       s28, s23, #24704
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4288
    s.addi       s28, s23, #24768
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4352
    s.addi       s28, s23, #24832
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4416
    s.addi       s28, s23, #24896
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4480
    s.addi       s28, s23, #24960
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4544
    s.addi       s28, s23, #25024
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4608
    s.addi       s28, s23, #25088
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4672
    s.addi       s28, s23, #25152
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4736
    s.addi       s28, s23, #25216
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4800
    s.addi       s28, s23, #25280
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4864
    s.addi       s28, s23, #25344
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4928
    s.addi       s28, s23, #25408
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #4992
    s.addi       s28, s23, #25472
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5056
    s.addi       s28, s23, #25536
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #5120
    s.addi       s28, s23, #25600
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5184
    s.addi       s28, s23, #25664
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5248
    s.addi       s28, s23, #25728
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5312
    s.addi       s28, s23, #25792
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5376
    s.addi       s28, s23, #25856
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5440
    s.addi       s28, s23, #25920
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5504
    s.addi       s28, s23, #25984
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5568
    s.addi       s28, s23, #26048
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5632
    s.addi       s28, s23, #26112
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5696
    s.addi       s28, s23, #26176
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5760
    s.addi       s28, s23, #26240
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5824
    s.addi       s28, s23, #26304
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5888
    s.addi       s28, s23, #26368
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #5952
    s.addi       s28, s23, #26432
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6016
    s.addi       s28, s23, #26496
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6080
    s.addi       s28, s23, #26560
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #6144
    s.addi       s28, s23, #26624
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6208
    s.addi       s28, s23, #26688
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6272
    s.addi       s28, s23, #26752
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6336
    s.addi       s28, s23, #26816
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6400
    s.addi       s28, s23, #26880
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6464
    s.addi       s28, s23, #26944
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6528
    s.addi       s28, s23, #27008
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6592
    s.addi       s28, s23, #27072
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6656
    s.addi       s28, s23, #27136
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6720
    s.addi       s28, s23, #27200
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6784
    s.addi       s28, s23, #27264
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6848
    s.addi       s28, s23, #27328
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6912
    s.addi       s28, s23, #27392
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #6976
    s.addi       s28, s23, #27456
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7040
    s.addi       s28, s23, #27520
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7104
    s.addi       s28, s23, #27584
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    fence.acq_rel.device
    s.addi       s27, s23, #7168
    s.addi       s28, s23, #27648
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7232
    s.addi       s28, s23, #27712
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7296
    s.addi       s28, s23, #27776
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7360
    s.addi       s28, s23, #27840
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7424
    s.addi       s28, s23, #27904
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7488
    s.addi       s28, s23, #27968
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7552
    s.addi       s28, s23, #28032
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7616
    s.addi       s28, s23, #28096
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7680
    s.addi       s28, s23, #28160
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7744
    s.addi       s28, s23, #28224
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7808
    s.addi       s28, s23, #28288
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7872
    s.addi       s28, s23, #28352
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #7936
    s.addi       s28, s23, #28416
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #8000
    s.addi       s28, s23, #28480
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #8064
    s.addi       s28, s23, #28544
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    s.addi       s27, s23, #8128
    s.addi       s28, s23, #28608
    v.ld.w       v18, [s28, #0]
    v.st.w       [s27, #0], v18
    fence.acq_rel.device
    s.add        s27, s19, s14
    s.mov        s19, s27
    s.movz       s27, #1
    br.nz        s27, for_12
endfor_13:
    s.movz       s13, #0
    s.addi       s17, s23, #0
    a.vread      v18, a0, s13
    v.ld.w       v19, [s17, #0]
    v.extract    s13, v0, #0
    v.splat      v20, s13
    s.addi       s13, s23, #28672
    s.movz       s17, #1
    s.addi       s18, s23, #64
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s13, #0], v20
    a.vread      v18, a0, s17
    v.extract    s17, v0, #1
    v.splat      v19, s17
    s.addi       s17, s13, #64
    v.ld.w       v20, [s18, #0]
    s.movz       s18, #2
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s17, #0], v20
    s.addi       s17, s23, #128
    a.vread      v18, a0, s18
    v.extract    s18, v0, #2
    v.splat      v19, s18
    s.addi       s18, s13, #128
    v.ld.w       v20, [s17, #0]
    s.movz       s17, #3
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s18, #0], v20
    s.addi       s18, s23, #192
    a.vread      v18, a0, s17
    v.extract    s17, v0, #3
    v.splat      v19, s17
    s.addi       s17, s13, #192
    v.ld.w       v20, [s18, #0]
    s.movz       s18, #4
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s17, #0], v20
    s.addi       s17, s23, #256
    a.vread      v18, a0, s18
    v.extract    s18, v0, #4
    v.splat      v19, s18
    s.addi       s18, s13, #256
    v.ld.w       v20, [s17, #0]
    s.movz       s17, #5
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s18, #0], v20
    s.addi       s18, s23, #320
    a.vread      v18, a0, s17
    v.extract    s17, v0, #5
    v.splat      v19, s17
    s.addi       s17, s13, #320
    v.ld.w       v20, [s18, #0]
    s.movz       s18, #6
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s17, #0], v20
    s.addi       s17, s23, #384
    a.vread      v18, a0, s18
    v.extract    s18, v0, #6
    v.splat      v19, s18
    s.addi       s18, s13, #384
    v.ld.w       v20, [s17, #0]
    s.movz       s17, #7
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s18, #0], v20
    s.addi       s18, s23, #448
    a.vread      v18, a0, s17
    v.extract    s17, v0, #7
    v.splat      v19, s17
    s.addi       s17, s13, #448
    v.ld.w       v20, [s18, #0]
    s.movz       s18, #8
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s17, #0], v20
    s.addi       s17, s23, #512
    a.vread      v18, a0, s18
    v.extract    s18, v0, #8
    v.splat      v19, s18
    s.addi       s18, s13, #512
    v.ld.w       v20, [s17, #0]
    s.movz       s17, #9
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s18, #0], v20
    s.addi       s18, s23, #576
    a.vread      v18, a0, s17
    v.extract    s17, v0, #9
    v.splat      v19, s17
    s.addi       s17, s13, #576
    v.ld.w       v20, [s18, #0]
    s.movz       s18, #10
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s17, #0], v20
    s.addi       s17, s23, #640
    a.vread      v18, a0, s18
    v.extract    s18, v0, #10
    v.splat      v19, s18
    s.addi       s18, s13, #640
    v.ld.w       v20, [s17, #0]
    s.movz       s17, #11
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s18, #0], v20
    s.addi       s18, s23, #704
    a.vread      v18, a0, s17
    v.extract    s17, v0, #11
    v.splat      v19, s17
    s.addi       s17, s13, #704
    v.ld.w       v20, [s18, #0]
    s.movz       s18, #12
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s17, #0], v20
    s.addi       s17, s23, #768
    a.vread      v18, a0, s18
    v.extract    s18, v0, #12
    v.splat      v19, s18
    s.addi       s18, s13, #768
    v.ld.w       v20, [s17, #0]
    s.movz       s17, #13
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s18, #0], v20
    s.addi       s18, s23, #832
    a.vread      v18, a0, s17
    v.extract    s17, v0, #13
    v.splat      v19, s17
    s.addi       s17, s13, #832
    v.ld.w       v20, [s18, #0]
    s.movz       s18, #14
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s17, #0], v20
    s.addi       s17, s23, #896
    a.vread      v18, a0, s18
    v.extract    s18, v0, #14
    v.splat      v19, s18
    s.addi       s18, s13, #896
    s.addi       s19, s13, #960
    v.ld.w       v20, [s17, #0]
    s.movz       s13, #15
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v20, v18, v19
    v.st.w       [s18, #0], v20
    s.addi       s17, s23, #960
    a.vread      v18, a0, s13
    v.extract    s13, v0, #15
    v.splat      v19, s13
    s.movz       s13, #0
    v.ld.w       v20, [s17, #0]
    s.addi       s17, s23, #1024
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v2
    vf.add       v2, v18, v19
    v.st.w       [s19, #0], v2
    fence.acq_rel.device
    a.vread      v2, a1, s13
    v.extract    s13, v0, #0
    v.splat      v18, s13
    s.addi       s13, s23, #29696
    s.movz       s18, #1
    v.ld.w       v19, [s17, #0]
    s.addi       s17, s23, #1088
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s13, #0], v19
    a.vread      v2, a1, s18
    v.extract    s18, v0, #1
    v.splat      v18, s18
    s.addi       s18, s13, #64
    v.ld.w       v19, [s17, #0]
    s.movz       s17, #2
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s18, #0], v19
    s.addi       s18, s23, #1152
    a.vread      v2, a1, s17
    v.extract    s17, v0, #2
    v.splat      v18, s17
    s.addi       s17, s13, #128
    v.ld.w       v19, [s18, #0]
    s.movz       s18, #3
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s17, #0], v19
    s.addi       s17, s23, #1216
    a.vread      v2, a1, s18
    v.extract    s18, v0, #3
    v.splat      v18, s18
    s.addi       s18, s13, #192
    v.ld.w       v19, [s17, #0]
    s.movz       s17, #4
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s18, #0], v19
    s.addi       s18, s23, #1280
    a.vread      v2, a1, s17
    v.extract    s17, v0, #4
    v.splat      v18, s17
    s.addi       s17, s13, #256
    v.ld.w       v19, [s18, #0]
    s.movz       s18, #5
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s17, #0], v19
    s.addi       s17, s23, #1344
    a.vread      v2, a1, s18
    v.extract    s18, v0, #5
    v.splat      v18, s18
    s.addi       s18, s13, #320
    v.ld.w       v19, [s17, #0]
    s.movz       s17, #6
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s18, #0], v19
    s.addi       s18, s23, #1408
    a.vread      v2, a1, s17
    v.extract    s17, v0, #6
    v.splat      v18, s17
    s.addi       s17, s13, #384
    v.ld.w       v19, [s18, #0]
    s.movz       s18, #7
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s17, #0], v19
    s.addi       s17, s23, #1472
    a.vread      v2, a1, s18
    v.extract    s18, v0, #7
    v.splat      v18, s18
    s.addi       s18, s13, #448
    v.ld.w       v19, [s17, #0]
    s.movz       s17, #8
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s18, #0], v19
    s.addi       s18, s23, #1536
    a.vread      v2, a1, s17
    v.extract    s17, v0, #8
    v.splat      v18, s17
    s.addi       s17, s13, #512
    v.ld.w       v19, [s18, #0]
    s.movz       s18, #9
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s17, #0], v19
    s.addi       s17, s23, #1600
    a.vread      v2, a1, s18
    v.extract    s18, v0, #9
    v.splat      v18, s18
    s.addi       s18, s13, #576
    v.ld.w       v19, [s17, #0]
    s.movz       s17, #10
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s18, #0], v19
    s.addi       s18, s23, #1664
    a.vread      v2, a1, s17
    v.extract    s17, v0, #10
    v.splat      v18, s17
    s.addi       s17, s13, #640
    v.ld.w       v19, [s18, #0]
    s.movz       s18, #11
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s17, #0], v19
    s.addi       s17, s23, #1728
    a.vread      v2, a1, s18
    v.extract    s18, v0, #11
    v.splat      v18, s18
    s.addi       s18, s13, #704
    v.ld.w       v19, [s17, #0]
    s.movz       s17, #12
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s18, #0], v19
    s.addi       s18, s23, #1792
    a.vread      v2, a1, s17
    v.extract    s17, v0, #12
    v.splat      v18, s17
    s.addi       s17, s13, #768
    v.ld.w       v19, [s18, #0]
    s.movz       s18, #13
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s17, #0], v19
    s.addi       s17, s23, #1856
    a.vread      v2, a1, s18
    v.extract    s18, v0, #13
    v.splat      v18, s18
    s.addi       s18, s13, #832
    v.ld.w       v19, [s17, #0]
    s.movz       s17, #14
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s18, #0], v19
    s.addi       s18, s23, #1920
    a.vread      v2, a1, s17
    v.extract    s17, v0, #14
    v.splat      v18, s17
    s.addi       s17, s13, #896
    s.addi       s19, s13, #960
    v.ld.w       v19, [s18, #0]
    s.movz       s13, #15
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v19, v2, v18
    v.st.w       [s17, #0], v19
    s.addi       s17, s23, #1984
    a.vread      v2, a1, s13
    v.extract    s13, v0, #15
    v.splat      v18, s13
    s.movz       s13, #0
    v.ld.w       v19, [s17, #0]
    s.addi       s17, s23, #2048
    vf.mul       v20, v19, v18
    vf.mul       v18, v20, v3
    vf.add       v3, v2, v18
    v.st.w       [s19, #0], v3
    fence.acq_rel.device
    a.vread      v2, a2, s13
    v.extract    s13, v0, #0
    v.splat      v3, s13
    s.addi       s13, s23, #30720
    s.movz       s18, #1
    v.ld.w       v18, [s17, #0]
    s.addi       s17, s23, #2112
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s13, #0], v18
    a.vread      v2, a2, s18
    v.extract    s18, v0, #1
    v.splat      v3, s18
    s.addi       s18, s13, #64
    v.ld.w       v18, [s17, #0]
    s.movz       s17, #2
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s18, #0], v18
    s.addi       s18, s23, #2176
    a.vread      v2, a2, s17
    v.extract    s17, v0, #2
    v.splat      v3, s17
    s.addi       s17, s13, #128
    v.ld.w       v18, [s18, #0]
    s.movz       s18, #3
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s17, #0], v18
    s.addi       s17, s23, #2240
    a.vread      v2, a2, s18
    v.extract    s18, v0, #3
    v.splat      v3, s18
    s.addi       s18, s13, #192
    v.ld.w       v18, [s17, #0]
    s.movz       s17, #4
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s18, #0], v18
    s.addi       s18, s23, #2304
    a.vread      v2, a2, s17
    v.extract    s17, v0, #4
    v.splat      v3, s17
    s.addi       s17, s13, #256
    v.ld.w       v18, [s18, #0]
    s.movz       s18, #5
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s17, #0], v18
    s.addi       s17, s23, #2368
    a.vread      v2, a2, s18
    v.extract    s18, v0, #5
    v.splat      v3, s18
    s.addi       s18, s13, #320
    v.ld.w       v18, [s17, #0]
    s.movz       s17, #6
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s18, #0], v18
    s.addi       s18, s23, #2432
    a.vread      v2, a2, s17
    v.extract    s17, v0, #6
    v.splat      v3, s17
    s.addi       s17, s13, #384
    v.ld.w       v18, [s18, #0]
    s.movz       s18, #7
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s17, #0], v18
    s.addi       s17, s23, #2496
    a.vread      v2, a2, s18
    v.extract    s18, v0, #7
    v.splat      v3, s18
    s.addi       s18, s13, #448
    v.ld.w       v18, [s17, #0]
    s.movz       s17, #8
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s18, #0], v18
    s.addi       s18, s23, #2560
    a.vread      v2, a2, s17
    v.extract    s17, v0, #8
    v.splat      v3, s17
    s.addi       s17, s13, #512
    v.ld.w       v18, [s18, #0]
    s.movz       s18, #9
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s17, #0], v18
    s.addi       s17, s23, #2624
    a.vread      v2, a2, s18
    v.extract    s18, v0, #9
    v.splat      v3, s18
    s.addi       s18, s13, #576
    v.ld.w       v18, [s17, #0]
    s.movz       s17, #10
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s18, #0], v18
    s.addi       s18, s23, #2688
    a.vread      v2, a2, s17
    v.extract    s17, v0, #10
    v.splat      v3, s17
    s.addi       s17, s13, #640
    v.ld.w       v18, [s18, #0]
    s.movz       s18, #11
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s17, #0], v18
    s.addi       s17, s23, #2752
    a.vread      v2, a2, s18
    v.extract    s18, v0, #11
    v.splat      v3, s18
    s.addi       s18, s13, #704
    v.ld.w       v18, [s17, #0]
    s.movz       s17, #12
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s18, #0], v18
    s.addi       s18, s23, #2816
    a.vread      v2, a2, s17
    v.extract    s17, v0, #12
    v.splat      v3, s17
    s.addi       s17, s13, #768
    v.ld.w       v18, [s18, #0]
    s.movz       s18, #13
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s17, #0], v18
    s.addi       s17, s23, #2880
    a.vread      v2, a2, s18
    v.extract    s18, v0, #13
    v.splat      v3, s18
    s.addi       s18, s13, #832
    v.ld.w       v18, [s17, #0]
    s.movz       s17, #14
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s18, #0], v18
    s.addi       s18, s23, #2944
    a.vread      v2, a2, s17
    v.extract    s17, v0, #14
    v.splat      v3, s17
    s.addi       s17, s13, #896
    s.addi       s19, s13, #960
    v.ld.w       v18, [s18, #0]
    s.movz       s13, #15
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v18, v2, v3
    v.st.w       [s17, #0], v18
    s.addi       s17, s23, #3008
    a.vread      v2, a2, s13
    v.extract    s13, v0, #15
    v.splat      v3, s13
    s.movz       s13, #0
    v.ld.w       v18, [s17, #0]
    s.addi       s17, s23, #3072
    vf.mul       v19, v18, v3
    vf.mul       v3, v19, v4
    vf.add       v4, v2, v3
    v.st.w       [s19, #0], v4
    fence.acq_rel.device
    a.vread      v2, a3, s13
    v.extract    s13, v0, #0
    v.splat      v3, s13
    s.addi       s13, s23, #31744
    s.movz       s18, #1
    v.ld.w       v4, [s17, #0]
    s.addi       s17, s23, #3136
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    a.vread      v2, a3, s18
    v.extract    s18, v0, #1
    v.splat      v3, s18
    s.addi       s18, s13, #64
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #2
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s18, #0], v4
    s.addi       s18, s23, #3200
    a.vread      v2, a3, s17
    v.extract    s17, v0, #2
    v.splat      v3, s17
    s.addi       s17, s13, #128
    v.ld.w       v4, [s18, #0]
    s.movz       s18, #3
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #3264
    a.vread      v2, a3, s18
    v.extract    s18, v0, #3
    v.splat      v3, s18
    s.addi       s18, s13, #192
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #4
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s18, #0], v4
    s.addi       s18, s23, #3328
    a.vread      v2, a3, s17
    v.extract    s17, v0, #4
    v.splat      v3, s17
    s.addi       s17, s13, #256
    v.ld.w       v4, [s18, #0]
    s.movz       s18, #5
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #3392
    a.vread      v2, a3, s18
    v.extract    s18, v0, #5
    v.splat      v3, s18
    s.addi       s18, s13, #320
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #6
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s18, #0], v4
    s.addi       s18, s23, #3456
    a.vread      v2, a3, s17
    v.extract    s17, v0, #6
    v.splat      v3, s17
    s.addi       s17, s13, #384
    v.ld.w       v4, [s18, #0]
    s.movz       s18, #7
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #3520
    a.vread      v2, a3, s18
    v.extract    s18, v0, #7
    v.splat      v3, s18
    s.addi       s18, s13, #448
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #8
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s18, #0], v4
    s.addi       s18, s23, #3584
    a.vread      v2, a3, s17
    v.extract    s17, v0, #8
    v.splat      v3, s17
    s.addi       s17, s13, #512
    v.ld.w       v4, [s18, #0]
    s.movz       s18, #9
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #3648
    a.vread      v2, a3, s18
    v.extract    s18, v0, #9
    v.splat      v3, s18
    s.addi       s18, s13, #576
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #10
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s18, #0], v4
    s.addi       s18, s23, #3712
    a.vread      v2, a3, s17
    v.extract    s17, v0, #10
    v.splat      v3, s17
    s.addi       s17, s13, #640
    v.ld.w       v4, [s18, #0]
    s.movz       s18, #11
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #3776
    a.vread      v2, a3, s18
    v.extract    s18, v0, #11
    v.splat      v3, s18
    s.addi       s18, s13, #704
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #12
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s18, #0], v4
    s.addi       s18, s23, #3840
    a.vread      v2, a3, s17
    v.extract    s17, v0, #12
    v.splat      v3, s17
    s.addi       s17, s13, #768
    v.ld.w       v4, [s18, #0]
    s.movz       s18, #13
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #3904
    a.vread      v2, a3, s18
    v.extract    s18, v0, #13
    v.splat      v3, s18
    s.addi       s18, s13, #832
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #14
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s18, #0], v4
    s.addi       s18, s23, #3968
    a.vread      v2, a3, s17
    v.extract    s17, v0, #14
    v.splat      v3, s17
    s.addi       s17, s13, #896
    s.addi       s19, s13, #960
    v.ld.w       v4, [s18, #0]
    s.movz       s13, #15
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #4032
    a.vread      v2, a3, s13
    v.extract    s13, v0, #15
    v.splat      v3, s13
    s.movz       s13, #0
    v.ld.w       v4, [s17, #0]
    s.addi       s17, s23, #4096
    vf.mul       v18, v4, v3
    vf.mul       v3, v18, v5
    vf.add       v4, v2, v3
    v.st.w       [s19, #0], v4
    fence.acq_rel.device
    a.vread      v2, a4, s13
    v.extract    s13, v0, #0
    v.splat      v3, s13
    s.movz       s13, #32768
    s.movz       s18, #1
    s.add        s19, s23, s13
    v.ld.w       v4, [s17, #0]
    s.addi       s13, s23, #4160
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s19, #0], v4
    a.vread      v2, a4, s18
    v.extract    s17, v0, #1
    v.splat      v3, s17
    s.addi       s17, s19, #64
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #2
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #4224
    a.vread      v2, a4, s13
    v.extract    s13, v0, #2
    v.splat      v3, s13
    s.addi       s13, s19, #128
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #3
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #4288
    a.vread      v2, a4, s17
    v.extract    s17, v0, #3
    v.splat      v3, s17
    s.addi       s17, s19, #192
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #4
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #4352
    a.vread      v2, a4, s13
    v.extract    s13, v0, #4
    v.splat      v3, s13
    s.addi       s13, s19, #256
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #5
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #4416
    a.vread      v2, a4, s17
    v.extract    s17, v0, #5
    v.splat      v3, s17
    s.addi       s17, s19, #320
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #6
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #4480
    a.vread      v2, a4, s13
    v.extract    s13, v0, #6
    v.splat      v3, s13
    s.addi       s13, s19, #384
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #7
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #4544
    a.vread      v2, a4, s17
    v.extract    s17, v0, #7
    v.splat      v3, s17
    s.addi       s17, s19, #448
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #8
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #4608
    a.vread      v2, a4, s13
    v.extract    s13, v0, #8
    v.splat      v3, s13
    s.addi       s13, s19, #512
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #9
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #4672
    a.vread      v2, a4, s17
    v.extract    s17, v0, #9
    v.splat      v3, s17
    s.addi       s17, s19, #576
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #10
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #4736
    a.vread      v2, a4, s13
    v.extract    s13, v0, #10
    v.splat      v3, s13
    s.addi       s13, s19, #640
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #11
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #4800
    a.vread      v2, a4, s17
    v.extract    s17, v0, #11
    v.splat      v3, s17
    s.addi       s17, s19, #704
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #12
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #4864
    a.vread      v2, a4, s13
    v.extract    s13, v0, #12
    v.splat      v3, s13
    s.addi       s13, s19, #768
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #13
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #4928
    a.vread      v2, a4, s17
    v.extract    s17, v0, #13
    v.splat      v3, s17
    s.addi       s17, s19, #832
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #14
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #4992
    a.vread      v2, a4, s13
    v.extract    s13, v0, #14
    v.splat      v3, s13
    s.addi       s13, s19, #896
    s.addi       s18, s19, #960
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #15
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #5056
    a.vread      v2, a4, s17
    v.extract    s17, v0, #15
    v.splat      v3, s17
    s.movz       s17, #0
    v.ld.w       v4, [s13, #0]
    s.addi       s13, s23, #5120
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v6
    vf.add       v4, v2, v3
    v.st.w       [s18, #0], v4
    fence.acq_rel.device
    a.vread      v2, a5, s17
    v.extract    s17, v0, #0
    v.splat      v3, s17
    s.movz       s17, #33792
    s.movz       s18, #1
    s.add        s19, s23, s17
    v.ld.w       v4, [s13, #0]
    s.addi       s13, s23, #5184
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s19, #0], v4
    a.vread      v2, a5, s18
    v.extract    s17, v0, #1
    v.splat      v3, s17
    s.addi       s17, s19, #64
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #2
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #5248
    a.vread      v2, a5, s13
    v.extract    s13, v0, #2
    v.splat      v3, s13
    s.addi       s13, s19, #128
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #3
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #5312
    a.vread      v2, a5, s17
    v.extract    s17, v0, #3
    v.splat      v3, s17
    s.addi       s17, s19, #192
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #4
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #5376
    a.vread      v2, a5, s13
    v.extract    s13, v0, #4
    v.splat      v3, s13
    s.addi       s13, s19, #256
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #5
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #5440
    a.vread      v2, a5, s17
    v.extract    s17, v0, #5
    v.splat      v3, s17
    s.addi       s17, s19, #320
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #6
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #5504
    a.vread      v2, a5, s13
    v.extract    s13, v0, #6
    v.splat      v3, s13
    s.addi       s13, s19, #384
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #7
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #5568
    a.vread      v2, a5, s17
    v.extract    s17, v0, #7
    v.splat      v3, s17
    s.addi       s17, s19, #448
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #8
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #5632
    a.vread      v2, a5, s13
    v.extract    s13, v0, #8
    v.splat      v3, s13
    s.addi       s13, s19, #512
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #9
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #5696
    a.vread      v2, a5, s17
    v.extract    s17, v0, #9
    v.splat      v3, s17
    s.addi       s17, s19, #576
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #10
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #5760
    a.vread      v2, a5, s13
    v.extract    s13, v0, #10
    v.splat      v3, s13
    s.addi       s13, s19, #640
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #11
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #5824
    a.vread      v2, a5, s17
    v.extract    s17, v0, #11
    v.splat      v3, s17
    s.addi       s17, s19, #704
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #12
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #5888
    a.vread      v2, a5, s13
    v.extract    s13, v0, #12
    v.splat      v3, s13
    s.addi       s13, s19, #768
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #13
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #5952
    a.vread      v2, a5, s17
    v.extract    s17, v0, #13
    v.splat      v3, s17
    s.addi       s17, s19, #832
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #14
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #6016
    a.vread      v2, a5, s13
    v.extract    s13, v0, #14
    v.splat      v3, s13
    s.addi       s13, s19, #896
    s.addi       s18, s19, #960
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #15
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #6080
    a.vread      v2, a5, s17
    v.extract    s17, v0, #15
    v.splat      v3, s17
    s.movz       s17, #0
    v.ld.w       v4, [s13, #0]
    s.addi       s13, s23, #6144
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v15
    vf.add       v4, v2, v3
    v.st.w       [s18, #0], v4
    fence.acq_rel.device
    a.vread      v2, a6, s17
    v.extract    s17, v0, #0
    v.splat      v3, s17
    s.movz       s17, #34816
    s.movz       s18, #1
    s.add        s19, s23, s17
    v.ld.w       v4, [s13, #0]
    s.addi       s13, s23, #6208
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s19, #0], v4
    a.vread      v2, a6, s18
    v.extract    s17, v0, #1
    v.splat      v3, s17
    s.addi       s17, s19, #64
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #2
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #6272
    a.vread      v2, a6, s13
    v.extract    s13, v0, #2
    v.splat      v3, s13
    s.addi       s13, s19, #128
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #3
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #6336
    a.vread      v2, a6, s17
    v.extract    s17, v0, #3
    v.splat      v3, s17
    s.addi       s17, s19, #192
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #4
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #6400
    a.vread      v2, a6, s13
    v.extract    s13, v0, #4
    v.splat      v3, s13
    s.addi       s13, s19, #256
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #5
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #6464
    a.vread      v2, a6, s17
    v.extract    s17, v0, #5
    v.splat      v3, s17
    s.addi       s17, s19, #320
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #6
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #6528
    a.vread      v2, a6, s13
    v.extract    s13, v0, #6
    v.splat      v3, s13
    s.addi       s13, s19, #384
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #7
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #6592
    a.vread      v2, a6, s17
    v.extract    s17, v0, #7
    v.splat      v3, s17
    s.addi       s17, s19, #448
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #8
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #6656
    a.vread      v2, a6, s13
    v.extract    s13, v0, #8
    v.splat      v3, s13
    s.addi       s13, s19, #512
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #9
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #6720
    a.vread      v2, a6, s17
    v.extract    s17, v0, #9
    v.splat      v3, s17
    s.addi       s17, s19, #576
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #10
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #6784
    a.vread      v2, a6, s13
    v.extract    s13, v0, #10
    v.splat      v3, s13
    s.addi       s13, s19, #640
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #11
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #6848
    a.vread      v2, a6, s17
    v.extract    s17, v0, #11
    v.splat      v3, s17
    s.addi       s17, s19, #704
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #12
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #6912
    a.vread      v2, a6, s13
    v.extract    s13, v0, #12
    v.splat      v3, s13
    s.addi       s13, s19, #768
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #13
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #6976
    a.vread      v2, a6, s17
    v.extract    s17, v0, #13
    v.splat      v3, s17
    s.addi       s17, s19, #832
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #14
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #7040
    a.vread      v2, a6, s13
    v.extract    s13, v0, #14
    v.splat      v3, s13
    s.addi       s13, s19, #896
    s.addi       s18, s19, #960
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #15
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #7104
    a.vread      v2, a6, s17
    v.extract    s17, v0, #15
    v.splat      v3, s17
    s.movz       s17, #0
    v.ld.w       v4, [s13, #0]
    s.addi       s13, s23, #7168
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v16
    vf.add       v4, v2, v3
    v.st.w       [s18, #0], v4
    fence.acq_rel.device
    a.vread      v2, a7, s17
    v.extract    s17, v0, #0
    v.splat      v3, s17
    s.movz       s17, #35840
    s.movz       s18, #1
    s.add        s19, s23, s17
    v.ld.w       v4, [s13, #0]
    s.addi       s13, s23, #7232
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s19, #0], v4
    a.vread      v2, a7, s18
    v.extract    s17, v0, #1
    v.splat      v3, s17
    s.addi       s17, s19, #64
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #2
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #7296
    a.vread      v2, a7, s13
    v.extract    s13, v0, #2
    v.splat      v3, s13
    s.addi       s13, s19, #128
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #3
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #7360
    a.vread      v2, a7, s17
    v.extract    s17, v0, #3
    v.splat      v3, s17
    s.addi       s17, s19, #192
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #4
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #7424
    a.vread      v2, a7, s13
    v.extract    s13, v0, #4
    v.splat      v3, s13
    s.addi       s13, s19, #256
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #5
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #7488
    a.vread      v2, a7, s17
    v.extract    s17, v0, #5
    v.splat      v3, s17
    s.addi       s17, s19, #320
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #6
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #7552
    a.vread      v2, a7, s13
    v.extract    s13, v0, #6
    v.splat      v3, s13
    s.addi       s13, s19, #384
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #7
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #7616
    a.vread      v2, a7, s17
    v.extract    s17, v0, #7
    v.splat      v3, s17
    s.addi       s17, s19, #448
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #8
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #7680
    a.vread      v2, a7, s13
    v.extract    s13, v0, #8
    v.splat      v3, s13
    s.addi       s13, s19, #512
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #9
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #7744
    a.vread      v2, a7, s17
    v.extract    s17, v0, #9
    v.splat      v3, s17
    s.addi       s17, s19, #576
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #10
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #7808
    a.vread      v2, a7, s13
    v.extract    s13, v0, #10
    v.splat      v3, s13
    s.addi       s13, s19, #640
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #11
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #7872
    a.vread      v2, a7, s17
    v.extract    s17, v0, #11
    v.splat      v3, s17
    s.addi       s17, s19, #704
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #12
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #7936
    a.vread      v2, a7, s13
    v.extract    s13, v0, #12
    v.splat      v3, s13
    s.addi       s13, s19, #768
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #13
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #8000
    a.vread      v2, a7, s17
    v.extract    s17, v0, #13
    v.splat      v3, s17
    s.addi       s17, s19, #832
    v.ld.w       v4, [s13, #0]
    s.movz       s13, #14
    vf.mul       v5, v4, v3
    vf.mul       v3, v5, v17
    vf.add       v4, v2, v3
    v.st.w       [s17, #0], v4
    s.addi       s17, s23, #8064
    a.vread      v2, a7, s13
    v.extract    s13, v0, #14
    v.splat      v3, s13
    s.addi       s13, s19, #896
    s.addi       s18, s19, #960
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #15
    vf.mul       v5, v4, v3
    s.add        s19, s16, s21
    vf.mul       v3, v5, v17
    s.addi       s21, s19, #0
    vf.add       v4, v2, v3
    s.add        s19, s11, s22
    v.st.w       [s13, #0], v4
    s.addi       s13, s23, #8128
    a.vread      v2, a7, s17
    v.extract    s17, v0, #15
    v.splat      v0, s17
    s.addi       s17, s19, #0
    s.addi       s19, s23, #28672
    v.ld.w       v3, [s13, #0]
    s.movz       s13, #0
    vf.mul       v4, v3, v0
    vf.mul       v0, v4, v17
    vf.add       v3, v2, v0
    v.st.w       [s18, #0], v3
    fence.acq_rel.device
    s.mov        s16, s21
    s.mov        s11, s17
    s.addi       s17, s23, #28736
    s.movz       s18, #1
    s.addi       s21, s23, #28800
    s.movz       s22, #2
    s.addi       s27, s23, #28864
    v.ld.w       v0, [s19, #0]
    s.movz       s19, #3
    a.vwrite     a0, s13, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s13, s23, #28928
    s.movz       s17, #4
    a.vwrite     a0, s18, v0
    v.ld.w       v0, [s21, #0]
    s.addi       s18, s23, #28992
    s.movz       s21, #5
    a.vwrite     a0, s22, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s22, s23, #29056
    s.movz       s27, #6
    a.vwrite     a0, s19, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #29120
    s.movz       s19, #7
    a.vwrite     a0, s17, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s17, s23, #29184
    s.movz       s18, #8
    a.vwrite     a0, s21, v0
    v.ld.w       v0, [s22, #0]
    s.addi       s21, s23, #29248
    s.movz       s22, #9
    a.vwrite     a0, s27, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #29312
    s.movz       s27, #10
    a.vwrite     a0, s19, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #29376
    s.movz       s19, #11
    a.vwrite     a0, s18, v0
    v.ld.w       v0, [s21, #0]
    s.addi       s18, s23, #29440
    s.movz       s21, #12
    a.vwrite     a0, s22, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #29504
    s.movz       s22, #13
    a.vwrite     a0, s27, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #29568
    s.movz       s27, #14
    a.vwrite     a0, s19, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #29632
    s.movz       s19, #15
    a.vwrite     a0, s21, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #29696
    s.movz       s21, #0
    a.vwrite     a0, s22, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #29760
    s.movz       s22, #1
    a.vwrite     a0, s27, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #29824
    s.movz       s27, #2
    a.vwrite     a0, s19, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #29888
    s.movz       s19, #3
    a.vwrite     a1, s21, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #29952
    s.movz       s21, #4
    a.vwrite     a1, s22, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #30016
    s.movz       s22, #5
    a.vwrite     a1, s27, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #30080
    s.movz       s27, #6
    a.vwrite     a1, s19, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #30144
    s.movz       s19, #7
    a.vwrite     a1, s21, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #30208
    s.movz       s21, #8
    a.vwrite     a1, s22, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #30272
    s.movz       s22, #9
    a.vwrite     a1, s27, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #30336
    s.movz       s27, #10
    a.vwrite     a1, s19, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #30400
    s.movz       s19, #11
    a.vwrite     a1, s21, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #30464
    s.movz       s21, #12
    a.vwrite     a1, s22, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #30528
    s.movz       s22, #13
    a.vwrite     a1, s27, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #30592
    s.movz       s27, #14
    a.vwrite     a1, s19, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #30656
    s.movz       s19, #15
    a.vwrite     a1, s21, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #30720
    s.movz       s21, #0
    a.vwrite     a1, s22, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #30784
    s.movz       s22, #1
    a.vwrite     a1, s27, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #30848
    s.movz       s27, #2
    a.vwrite     a1, s19, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #30912
    s.movz       s19, #3
    a.vwrite     a2, s21, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #30976
    s.movz       s21, #4
    a.vwrite     a2, s22, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #31040
    s.movz       s22, #5
    a.vwrite     a2, s27, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #31104
    s.movz       s27, #6
    a.vwrite     a2, s19, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #31168
    s.movz       s19, #7
    a.vwrite     a2, s21, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #31232
    s.movz       s21, #8
    a.vwrite     a2, s22, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #31296
    s.movz       s22, #9
    a.vwrite     a2, s27, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #31360
    s.movz       s27, #10
    a.vwrite     a2, s19, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #31424
    s.movz       s19, #11
    a.vwrite     a2, s21, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #31488
    s.movz       s21, #12
    a.vwrite     a2, s22, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #31552
    s.movz       s22, #13
    a.vwrite     a2, s27, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #31616
    s.movz       s27, #14
    a.vwrite     a2, s19, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #31680
    s.movz       s19, #15
    a.vwrite     a2, s21, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #31744
    s.movz       s21, #0
    a.vwrite     a2, s22, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #31808
    s.movz       s22, #1
    a.vwrite     a2, s27, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #31872
    s.movz       s27, #2
    a.vwrite     a2, s19, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #31936
    s.movz       s19, #3
    a.vwrite     a3, s21, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #32000
    s.movz       s21, #4
    a.vwrite     a3, s22, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #32064
    s.movz       s22, #5
    a.vwrite     a3, s27, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #32128
    s.movz       s27, #6
    a.vwrite     a3, s19, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #32192
    s.movz       s19, #7
    a.vwrite     a3, s21, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #32256
    s.movz       s21, #8
    a.vwrite     a3, s22, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #32320
    s.movz       s22, #9
    a.vwrite     a3, s27, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #32384
    s.movz       s27, #10
    a.vwrite     a3, s19, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #32448
    s.movz       s19, #11
    a.vwrite     a3, s21, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #32512
    s.movz       s21, #12
    a.vwrite     a3, s22, v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s23, #32576
    s.movz       s22, #13
    a.vwrite     a3, s27, v0
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s23, #32640
    s.movz       s27, #14
    a.vwrite     a3, s19, v0
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s23, #32704
    s.movz       s19, #32768
    s.add        s28, s23, s19
    a.vwrite     a3, s21, v0
    v.ld.w       v0, [s13, #0]
    s.movz       s13, #15
    s.movz       s19, #32832
    a.vwrite     a3, s22, v0
    v.ld.w       v0, [s17, #0]
    s.movz       s17, #0
    s.add        s21, s23, s19
    s.movz       s19, #1
    a.vwrite     a3, s27, v0
    v.ld.w       v0, [s18, #0]
    s.movz       s18, #32896
    s.movz       s22, #2
    s.add        s27, s23, s18
    a.vwrite     a3, s13, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #32960
    s.movz       s18, #3
    s.add        s28, s23, s13
    a.vwrite     a4, s17, v0
    v.ld.w       v0, [s21, #0]
    s.movz       s13, #33024
    s.movz       s17, #4
    s.add        s21, s23, s13
    a.vwrite     a4, s19, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #33088
    s.movz       s19, #5
    s.add        s27, s23, s13
    a.vwrite     a4, s22, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #33152
    s.movz       s22, #6
    s.add        s28, s23, s13
    a.vwrite     a4, s18, v0
    v.ld.w       v0, [s21, #0]
    s.movz       s13, #33216
    s.movz       s18, #7
    s.add        s21, s23, s13
    a.vwrite     a4, s17, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #33280
    s.movz       s17, #8
    s.add        s27, s23, s13
    a.vwrite     a4, s19, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #33344
    s.movz       s19, #9
    s.add        s28, s23, s13
    a.vwrite     a4, s22, v0
    v.ld.w       v0, [s21, #0]
    s.movz       s13, #33408
    s.movz       s21, #10
    s.add        s22, s23, s13
    a.vwrite     a4, s18, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #33472
    s.movz       s18, #11
    s.add        s27, s23, s13
    a.vwrite     a4, s17, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #33536
    s.movz       s17, #12
    s.add        s28, s23, s13
    a.vwrite     a4, s19, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #33600
    s.movz       s19, #13
    s.add        s22, s23, s13
    a.vwrite     a4, s21, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #33664
    s.movz       s21, #14
    s.add        s27, s23, s13
    a.vwrite     a4, s18, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #33728
    s.movz       s18, #15
    s.add        s28, s23, s13
    a.vwrite     a4, s17, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #33792
    s.movz       s17, #0
    s.add        s22, s23, s13
    a.vwrite     a4, s19, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #33856
    s.movz       s19, #1
    s.add        s27, s23, s13
    a.vwrite     a4, s21, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #33920
    s.movz       s21, #2
    s.add        s28, s23, s13
    a.vwrite     a4, s18, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #33984
    s.movz       s18, #3
    s.add        s22, s23, s13
    a.vwrite     a5, s17, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #34048
    s.movz       s17, #4
    s.add        s27, s23, s13
    a.vwrite     a5, s19, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #34112
    s.movz       s19, #5
    s.add        s28, s23, s13
    a.vwrite     a5, s21, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #34176
    s.movz       s21, #6
    s.add        s22, s23, s13
    a.vwrite     a5, s18, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #34240
    s.movz       s18, #7
    s.add        s27, s23, s13
    a.vwrite     a5, s17, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #34304
    s.movz       s17, #8
    s.add        s28, s23, s13
    a.vwrite     a5, s19, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #34368
    s.movz       s19, #9
    s.add        s22, s23, s13
    a.vwrite     a5, s21, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #34432
    s.movz       s21, #10
    s.add        s27, s23, s13
    a.vwrite     a5, s18, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #34496
    s.movz       s18, #11
    s.add        s28, s23, s13
    a.vwrite     a5, s17, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #34560
    s.movz       s17, #12
    s.add        s22, s23, s13
    a.vwrite     a5, s19, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #34624
    s.movz       s19, #13
    s.add        s27, s23, s13
    a.vwrite     a5, s21, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #34688
    s.movz       s21, #14
    s.add        s28, s23, s13
    a.vwrite     a5, s18, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #34752
    s.movz       s18, #15
    s.add        s22, s23, s13
    a.vwrite     a5, s17, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #34816
    s.movz       s17, #0
    s.add        s27, s23, s13
    a.vwrite     a5, s19, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #34880
    s.movz       s19, #1
    s.add        s28, s23, s13
    a.vwrite     a5, s21, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #34944
    s.movz       s21, #2
    s.add        s22, s23, s13
    a.vwrite     a5, s18, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #35008
    s.movz       s18, #3
    s.add        s27, s23, s13
    a.vwrite     a6, s17, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #35072
    s.movz       s17, #4
    s.add        s28, s23, s13
    a.vwrite     a6, s19, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #35136
    s.movz       s19, #5
    s.add        s22, s23, s13
    a.vwrite     a6, s21, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #35200
    s.movz       s21, #6
    s.add        s27, s23, s13
    a.vwrite     a6, s18, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #35264
    s.movz       s18, #7
    s.add        s28, s23, s13
    a.vwrite     a6, s17, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #35328
    s.movz       s17, #8
    s.add        s22, s23, s13
    a.vwrite     a6, s19, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #35392
    s.movz       s19, #9
    s.add        s27, s23, s13
    a.vwrite     a6, s21, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #35456
    s.movz       s21, #10
    s.add        s28, s23, s13
    a.vwrite     a6, s18, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #35520
    s.movz       s18, #11
    s.add        s22, s23, s13
    a.vwrite     a6, s17, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #35584
    s.movz       s17, #12
    s.add        s27, s23, s13
    a.vwrite     a6, s19, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #35648
    s.movz       s19, #13
    s.add        s28, s23, s13
    a.vwrite     a6, s21, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #35712
    s.movz       s21, #14
    s.add        s22, s23, s13
    a.vwrite     a6, s18, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #35776
    s.movz       s18, #15
    s.add        s27, s23, s13
    a.vwrite     a6, s17, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #35840
    s.movz       s17, #0
    s.add        s28, s23, s13
    a.vwrite     a6, s19, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #35904
    s.movz       s19, #1
    s.add        s22, s23, s13
    a.vwrite     a6, s21, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #35968
    s.movz       s21, #2
    s.add        s27, s23, s13
    a.vwrite     a6, s18, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #36032
    s.movz       s18, #3
    s.add        s28, s23, s13
    a.vwrite     a7, s17, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #36096
    s.movz       s17, #4
    s.add        s22, s23, s13
    a.vwrite     a7, s19, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #36160
    s.movz       s19, #5
    s.add        s27, s23, s13
    a.vwrite     a7, s21, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #36224
    s.movz       s21, #6
    s.add        s28, s23, s13
    a.vwrite     a7, s18, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #36288
    s.movz       s18, #7
    s.add        s22, s23, s13
    a.vwrite     a7, s17, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #36352
    s.movz       s17, #8
    s.add        s27, s23, s13
    a.vwrite     a7, s19, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #36416
    s.movz       s19, #9
    s.add        s28, s23, s13
    a.vwrite     a7, s21, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #36480
    s.movz       s21, #10
    s.add        s22, s23, s13
    a.vwrite     a7, s18, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #36544
    s.movz       s18, #11
    s.add        s27, s23, s13
    a.vwrite     a7, s17, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #36608
    s.movz       s17, #12
    s.add        s28, s23, s13
    a.vwrite     a7, s19, v0
    v.ld.w       v0, [s22, #0]
    s.movz       s13, #36672
    s.movz       s19, #13
    s.add        s22, s23, s13
    a.vwrite     a7, s21, v0
    v.ld.w       v0, [s27, #0]
    s.movz       s13, #36736
    s.movz       s21, #14
    s.add        s27, s23, s13
    a.vwrite     a7, s18, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s13, #36800
    s.movz       s18, #15
    s.add        s28, s23, s13
    a.vwrite     a7, s17, v0
    v.ld.w       v0, [s22, #0]
    s.add        s13, s15, s14
    s.movz       s17, #1
    a.vwrite     a7, s19, v0
    v.ld.w       v0, [s27, #0]
    a.vwrite     a7, s21, v0
    v.ld.w       v0, [s28, #0]
    a.vwrite     a7, s18, v0
    s.mov        s15, s13
    br.nz        s17, for_10
endfor_11:
    s.muli       s1, s5, #2                      // a runtime tile origin, x2
    s.movz       s2, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    s.muli       s4, s6, #272                    // a runtime tile origin, x272
    s.add        s7, s2, s6                      // the tile origin
    a.vread      v0, a0, s3
    s.add        s2, s12, s1                     // the tile origin
    vf.cvt.f32.bf16 v1, v0
    s.add        s1, s2, s4                      // the tile origin
    s.addi       s2, s5, #16
    v.splat      v0, s7
    s.addi       s3, s5, #32
    s.movz       s4, #7
    s.addi       s8, s5, #48
    v.splat      v2, s4
    s.addi       s4, s5, #64
    v.cmp.lt     p1, v0, v2
    s.addi       s9, s5, #80
    s.movz       s10, #0
    s.addi       s11, s5, #96
    s.add        s13, s10, s5                    // the tile origin
    s.addi       s10, s5, #112
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v3, s13
    s.movz       s5, #136
    v.add        v4, v0, v3
    v.splat      v3, s5
    s.movz       s13, #1
    v.cmp.lt     p2, v4, v3
    p.and        p3, p1, p2
    s.addi       s14, s7, #1
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s13
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #272                   // row 1
    p.and        p3, p1, p2
    s.movz       s14, #2
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #2
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #544                   // row 2
    p.and        p3, p1, p2
    s.movz       s14, #3
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #3
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #816                   // row 3
    p.and        p3, p1, p2
    s.movz       s14, #4
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #4
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #1088                  // row 4
    p.and        p3, p1, p2
    s.movz       s14, #5
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #5
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #1360                  // row 5
    p.and        p3, p1, p2
    s.movz       s14, #6
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #6
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #1632                  // row 6
    p.and        p3, p1, p2
    s.movz       s14, #7
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #7
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #1904                  // row 7
    p.and        p3, p1, p2
    s.movz       s14, #8
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #8
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #2176                  // row 8
    p.and        p3, p1, p2
    s.movz       s14, #9
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #9
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #2448                  // row 9
    p.and        p3, p1, p2
    s.movz       s14, #10
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #10
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #2720                  // row 10
    p.and        p3, p1, p2
    s.movz       s14, #11
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #11
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #2992                  // row 11
    p.and        p3, p1, p2
    s.movz       s14, #12
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #12
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #3264                  // row 12
    p.and        p3, p1, p2
    s.movz       s14, #13
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #13
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #3536                  // row 13
    p.and        p3, p1, p2
    s.movz       s14, #14
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #14
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s13, s1, #3808                  // row 14
    p.and        p3, p1, p2
    s.movz       s14, #15
    @p3 v.st.h       [s13, #0], v4
    s.addi       s13, s7, #15
    a.vread      v1, a0, s14
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    s.movz       s13, #0
    v.cmp.lt     p1, v3, v2
    s.muli       s14, s2, #2                     // a runtime tile origin, x2
    s.addi       s15, s1, #4080                  // row 15
    s.add        s1, s13, s2                     // the tile origin
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    v.splat      v1, s1
    s.muli       s1, s6, #272                    // a runtime tile origin, x272
    @p3 v.st.h       [s15, #0], v4
    a.vread      v3, a1, s2
    v.splat      v4, s7
    v.add        v5, v0, v1
    s.add        s2, s12, s14                    // the tile origin
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v4, v2
    v.splat      v3, s5
    s.add        s13, s2, s1                     // the tile origin
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s2, s7, #1
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a1, s1
    v.splat      v3, s2
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #272                   // row 1
    p.and        p3, p1, p2
    s.movz       s2, #2
    s.addi       s14, s7, #2
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #544                   // row 2
    p.and        p3, p1, p2
    s.movz       s2, #3
    s.addi       s14, s7, #3
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #816                   // row 3
    p.and        p3, p1, p2
    s.movz       s2, #4
    s.addi       s14, s7, #4
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #1088                  // row 4
    p.and        p3, p1, p2
    s.movz       s2, #5
    s.addi       s14, s7, #5
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #1360                  // row 5
    p.and        p3, p1, p2
    s.movz       s2, #6
    s.addi       s14, s7, #6
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #1632                  // row 6
    p.and        p3, p1, p2
    s.movz       s2, #7
    s.addi       s14, s7, #7
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #1904                  // row 7
    p.and        p3, p1, p2
    s.movz       s2, #8
    s.addi       s14, s7, #8
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #2176                  // row 8
    p.and        p3, p1, p2
    s.movz       s2, #9
    s.addi       s14, s7, #9
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #2448                  // row 9
    p.and        p3, p1, p2
    s.movz       s2, #10
    s.addi       s14, s7, #10
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #2720                  // row 10
    p.and        p3, p1, p2
    s.movz       s2, #11
    s.addi       s14, s7, #11
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #2992                  // row 11
    p.and        p3, p1, p2
    s.movz       s2, #12
    s.addi       s14, s7, #12
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #3264                  // row 12
    p.and        p3, p1, p2
    s.movz       s2, #13
    s.addi       s14, s7, #13
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #3536                  // row 13
    p.and        p3, p1, p2
    s.movz       s2, #14
    s.addi       s14, s7, #14
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s13, #3808                  // row 14
    p.and        p3, p1, p2
    s.movz       s2, #15
    s.addi       s14, s7, #15
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a1, s2
    v.splat      v3, s14
    vf.cvt.f32.bf16 v4, v1
    s.movz       s1, #0
    v.cmp.lt     p1, v3, v2
    s.muli       s2, s3, #2                      // a runtime tile origin, x2
    s.addi       s14, s13, #4080                 // row 15
    s.add        s13, s1, s3                     // the tile origin
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    s.muli       s3, s6, #272                    // a runtime tile origin, x272
    v.splat      v1, s13
    @p3 v.st.h       [s14, #0], v4
    a.vread      v3, a2, s1
    v.splat      v4, s7
    v.add        v5, v0, v1
    s.add        s1, s12, s2                     // the tile origin
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v4, v2
    v.splat      v3, s5
    s.add        s2, s1, s3                      // the tile origin
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a2, s1
    v.splat      v3, s3
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #272                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s13, s7, #2
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #544                    // row 2
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s13, s7, #3
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #816                    // row 3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.addi       s13, s7, #4
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1088                   // row 4
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.addi       s13, s7, #5
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1360                   // row 5
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.addi       s13, s7, #6
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1632                   // row 6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.addi       s13, s7, #7
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1904                   // row 7
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.addi       s13, s7, #8
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2176                   // row 8
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.addi       s13, s7, #9
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2448                   // row 9
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.addi       s13, s7, #10
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2720                   // row 10
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s13, s7, #11
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2992                   // row 11
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.addi       s13, s7, #12
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3264                   // row 12
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.addi       s13, s7, #13
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3536                   // row 13
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.addi       s13, s7, #14
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3808                   // row 14
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.addi       s13, s7, #15
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a2, s3
    v.splat      v3, s13
    vf.cvt.f32.bf16 v4, v1
    s.movz       s1, #0
    v.cmp.lt     p1, v3, v2
    s.muli       s3, s8, #2                      // a runtime tile origin, x2
    s.addi       s13, s2, #4080                  // row 15
    s.add        s2, s1, s8                      // the tile origin
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    s.muli       s8, s6, #272                    // a runtime tile origin, x272
    v.splat      v1, s2
    @p3 v.st.h       [s13, #0], v4
    a.vread      v3, a3, s1
    v.splat      v4, s7
    v.add        v5, v0, v1
    s.add        s1, s12, s3                     // the tile origin
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v4, v2
    v.splat      v3, s5
    s.add        s2, s1, s8                      // the tile origin
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a3, s1
    v.splat      v3, s3
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #272                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s8, s7, #2
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #544                    // row 2
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s8, s7, #3
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #816                    // row 3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.addi       s8, s7, #4
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1088                   // row 4
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.addi       s8, s7, #5
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1360                   // row 5
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.addi       s8, s7, #6
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1632                   // row 6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.addi       s8, s7, #7
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1904                   // row 7
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.addi       s8, s7, #8
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2176                   // row 8
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.addi       s8, s7, #9
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2448                   // row 9
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.addi       s8, s7, #10
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2720                   // row 10
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s8, s7, #11
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2992                   // row 11
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.addi       s8, s7, #12
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3264                   // row 12
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.addi       s8, s7, #13
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3536                   // row 13
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.addi       s8, s7, #14
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3808                   // row 14
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.addi       s8, s7, #15
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a3, s3
    v.splat      v3, s8
    vf.cvt.f32.bf16 v4, v1
    s.movz       s1, #0
    v.cmp.lt     p1, v3, v2
    s.muli       s3, s4, #2                      // a runtime tile origin, x2
    s.addi       s8, s2, #4080                   // row 15
    s.add        s2, s1, s4                      // the tile origin
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    s.muli       s4, s6, #272                    // a runtime tile origin, x272
    v.splat      v1, s2
    @p3 v.st.h       [s8, #0], v4
    a.vread      v3, a4, s1
    v.splat      v4, s7
    v.add        v5, v0, v1
    s.add        s1, s12, s3                     // the tile origin
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v4, v2
    v.splat      v3, s5
    s.add        s2, s1, s4                      // the tile origin
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a4, s1
    v.splat      v3, s3
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #272                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s4, s7, #2
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #544                    // row 2
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s4, s7, #3
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #816                    // row 3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.addi       s4, s7, #4
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1088                   // row 4
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.addi       s4, s7, #5
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1360                   // row 5
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.addi       s4, s7, #6
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1632                   // row 6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.addi       s4, s7, #7
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1904                   // row 7
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.addi       s4, s7, #8
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2176                   // row 8
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.addi       s4, s7, #9
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2448                   // row 9
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.addi       s4, s7, #10
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2720                   // row 10
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s4, s7, #11
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2992                   // row 11
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.addi       s4, s7, #12
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3264                   // row 12
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.addi       s4, s7, #13
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3536                   // row 13
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.addi       s4, s7, #14
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3808                   // row 14
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.addi       s4, s7, #15
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    s.movz       s1, #0
    v.cmp.lt     p1, v3, v2
    s.muli       s3, s9, #2                      // a runtime tile origin, x2
    s.addi       s4, s2, #4080                   // row 15
    s.add        s2, s1, s9                      // the tile origin
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    s.muli       s8, s6, #272                    // a runtime tile origin, x272
    v.splat      v1, s2
    @p3 v.st.h       [s4, #0], v4
    a.vread      v3, a5, s1
    v.splat      v4, s7
    v.add        v5, v0, v1
    s.add        s1, s12, s3                     // the tile origin
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v4, v2
    v.splat      v3, s5
    s.add        s2, s1, s8                      // the tile origin
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a5, s1
    v.splat      v3, s3
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #272                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s4, s7, #2
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #544                    // row 2
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s4, s7, #3
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #816                    // row 3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.addi       s4, s7, #4
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1088                   // row 4
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.addi       s4, s7, #5
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1360                   // row 5
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.addi       s4, s7, #6
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1632                   // row 6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.addi       s4, s7, #7
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1904                   // row 7
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.addi       s4, s7, #8
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2176                   // row 8
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.addi       s4, s7, #9
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2448                   // row 9
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.addi       s4, s7, #10
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2720                   // row 10
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s4, s7, #11
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2992                   // row 11
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.addi       s4, s7, #12
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3264                   // row 12
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.addi       s4, s7, #13
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3536                   // row 13
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.addi       s4, s7, #14
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3808                   // row 14
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.addi       s4, s7, #15
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    s.movz       s1, #0
    v.cmp.lt     p1, v3, v2
    s.muli       s3, s11, #2                     // a runtime tile origin, x2
    s.addi       s4, s2, #4080                   // row 15
    s.add        s2, s1, s11                     // the tile origin
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    s.muli       s8, s6, #272                    // a runtime tile origin, x272
    v.splat      v1, s2
    @p3 v.st.h       [s4, #0], v4
    a.vread      v3, a6, s1
    v.splat      v4, s7
    v.add        v5, v0, v1
    s.add        s1, s12, s3                     // the tile origin
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v4, v2
    v.splat      v3, s5
    s.add        s2, s1, s8                      // the tile origin
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a6, s1
    v.splat      v3, s3
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #272                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s4, s7, #2
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #544                    // row 2
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s4, s7, #3
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #816                    // row 3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.addi       s4, s7, #4
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1088                   // row 4
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.addi       s4, s7, #5
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1360                   // row 5
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.addi       s4, s7, #6
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1632                   // row 6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.addi       s4, s7, #7
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #1904                   // row 7
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.addi       s4, s7, #8
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2176                   // row 8
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.addi       s4, s7, #9
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2448                   // row 9
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.addi       s4, s7, #10
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2720                   // row 10
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s4, s7, #11
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #2992                   // row 11
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.addi       s4, s7, #12
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3264                   // row 12
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.addi       s4, s7, #13
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3536                   // row 13
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.addi       s4, s7, #14
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.addi       s1, s2, #3808                   // row 14
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.addi       s4, s7, #15
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s3
    v.splat      v3, s4
    vf.cvt.f32.bf16 v4, v1
    s.movz       s1, #0
    v.cmp.lt     p1, v3, v2
    s.muli       s3, s10, #2                     // a runtime tile origin, x2
    s.addi       s4, s2, #4080                   // row 15
    s.add        s2, s1, s10                     // the tile origin
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    s.muli       s8, s6, #272                    // a runtime tile origin, x272
    v.splat      v1, s2
    @p3 v.st.h       [s4, #0], v4
    a.vread      v3, a7, s1
    v.splat      v4, s7
    v.add        v5, v0, v1
    v.splat      v0, s5
    s.add        s1, s12, s3                     // the tile origin
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v4, v2
    v.cmp.lt     p2, v5, v0
    s.add        s2, s1, s8                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    s.addi       s3, s7, #1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v0, a7, s1
    v.splat      v1, s3
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #272                    // row 1
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.addi       s4, s7, #2
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #544                    // row 2
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.addi       s4, s7, #3
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #816                    // row 3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.addi       s4, s7, #4
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #1088                   // row 4
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.addi       s4, s7, #5
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #1360                   // row 5
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.addi       s4, s7, #6
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #1632                   // row 6
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.addi       s4, s7, #7
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #1904                   // row 7
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.addi       s4, s7, #8
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #2176                   // row 8
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.addi       s4, s7, #9
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #2448                   // row 9
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.addi       s4, s7, #10
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #2720                   // row 10
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.addi       s4, s7, #11
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #2992                   // row 11
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.addi       s4, s7, #12
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #3264                   // row 12
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.addi       s4, s7, #13
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #3536                   // row 13
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.addi       s4, s7, #14
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #3808                   // row 14
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.addi       s4, s7, #15
    @p3 v.st.h       [s1, #0], v3
    a.vread      v0, a7, s3
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v0
    v.cmp.lt     p1, v1, v2
    s.addi       s1, s2, #4080                   // row 15
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    exit
    exit
