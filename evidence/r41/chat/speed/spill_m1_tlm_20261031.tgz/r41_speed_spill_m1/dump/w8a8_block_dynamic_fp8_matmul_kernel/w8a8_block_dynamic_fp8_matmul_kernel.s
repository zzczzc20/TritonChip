    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #32]                   // N: i32 at arg_base+32
    s.movz       s4, #0
    s.movz       s5, #128
    s.rdspecial  s6, pid.x
    s.cmp.lt     s7, s5, s4
    s.movz       s8, #8
    s.sub        s9, s4, s7
    s.rdspecial  s7, pid.y
    s.movz       s10, #1
    s.xor        s11, s5, s9
    s.addi       s12, s4, #0
    s.add        s13, s3, s2
    s.ld.d       s14, [s1, #0]                   // A: device_ptr64 at arg_base+0
    s.cmp.lt     s15, s13, s4
    s.sub        s16, s11, s9
    s.sub        s11, s4, s15
    s.addi       s15, s4, #0
    s.xor        s16, s13, s11
    s.xor        s13, s11, s9
    s.sub        s9, s16, s11
    s.lshri      s11, s9, #7
    s.xor        s16, s11, s13
    s.muli       s17, s11, #128
    s.sub        s11, s16, s13
    s.ld.d       s13, [s1, #8]                   // B: device_ptr64 at arg_base+8
    s.mul        s16, s6, s11
    s.mul        s6, s11, s8
    s.sub        s11, s9, s17
    s.add        s9, s16, s7
    s.cmp.lt     s7, s6, s4
    s.cmp.lt     s11, s9, s4
    s.sub        s16, s4, s7
    s.sub        s7, s4, s11
    s.xor        s11, s6, s16
    s.xor        s17, s9, s7
    s.sub        s18, s11, s16
    s.sub        s11, s17, s7
    s.cmp.eq     s17, s18, s10
    s.ld.d       s19, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.ld.d       s20, [s1, #24]                  // Bs: device_ptr64 at arg_base+24
    s.ld.sw      s21, [s1, #40]                  // K: i32 at arg_base+40
    s.ld.sw      s22, [s1, #56]                  // stride_bn: i32 at arg_base+56
    s.ld.sw      s23, [s1, #64]                  // stride_cm: i32 at arg_base+64
    s.ld.sw      s24, [s1, #72]                  // stride_bs_n: i32 at arg_base+72
    s.mov        s12, s11
    br.nz        s17, sdiv_done_1
    s.movz       s1, #0
    s.movz       s17, #31
    s.mov        s12, s1
    s.addi       s1, s17, #0
sdiv_2:
    s.lshr       s17, s11, s1
    s.shli       s25, s15, #1
    s.andi       s26, s17, #1
    s.shl        s17, s10, s1
    s.or         s27, s25, s26
    s.subi       s25, s1, #1
    s.cmp.geu    s26, s27, s18
    s.sub        s28, s4, s26
    s.and        s26, s18, s28
    s.and        s29, s17, s28
    s.sub        s17, s27, s26
    s.or         s26, s12, s29
    s.mov        s15, s17
    s.mov        s12, s26
    s.mov        s1, s25
    s.cmp.ge     s17, s1, s4
    br.nz        s17, sdiv_2
sdiv_done_1:
    s.xor        s1, s7, s16
    s.movz       s4, #0
    s.xor        s7, s12, s1
    s.cmp.lt     s11, s6, s4
    s.sub        s12, s7, s1
    s.cmp.lt     s1, s9, s4
    s.sub        s7, s4, s11
    s.mul        s11, s12, s8
    s.sub        s12, s4, s1
    s.xor        s1, s6, s7
    s.xor        s6, s9, s12
    s.sub        s9, s1, s7
    s.sub        s1, s10, s11
    s.sub        s7, s6, s12
    s.addi       s6, s4, #0
    s.cmp.eq     s15, s9, s10
    s.min.s      s16, s1, s8
    s.addi       s1, s4, #0
    s.mov        s6, s7
    br.nz        s15, sdiv_done_3
    s.movz       s8, #0
    s.movz       s15, #31
    s.mov        s6, s8
    s.addi       s8, s15, #0
sdiv_4:
    s.lshr       s15, s7, s8
    s.shli       s17, s1, #1
    s.andi       s18, s15, #1
    s.movz       s15, #1
    s.or         s25, s17, s18
    s.shl        s17, s15, s8
    s.cmp.geu    s15, s25, s9
    s.subi       s18, s8, #1
    s.sub        s26, s4, s15
    s.and        s15, s9, s26
    s.and        s27, s17, s26
    s.sub        s17, s25, s15
    s.or         s15, s6, s27
    s.mov        s1, s17
    s.mov        s6, s15
    s.mov        s8, s18
    s.cmp.ge     s15, s8, s4
    br.nz        s15, sdiv_4
sdiv_done_3:
    s.xor        s6, s1, s12
    s.cmp.lt     s1, s16, s4
    s.sub        s7, s6, s12
    s.sub        s6, s4, s1
    s.cmp.lt     s1, s7, s4
    s.xor        s8, s16, s6
    s.sub        s9, s4, s1
    s.sub        s1, s8, s6
    s.xor        s6, s7, s9
    s.movz       s8, #1
    s.sub        s12, s6, s9
    s.addi       s6, s4, #0
    s.cmp.eq     s15, s1, s8
    s.addi       s17, s4, #0
    s.mov        s6, s12
    br.nz        s15, sdiv_done_5
    s.movz       s4, #0
    s.movz       s15, #31
    s.mov        s6, s4
    s.addi       s4, s15, #0
sdiv_6:
    s.lshr       s15, s12, s4
    s.shli       s18, s17, #1
    s.andi       s25, s15, #1
    s.movz       s15, #0
    s.or         s26, s18, s25
    s.shl        s18, s8, s4
    s.cmp.geu    s25, s26, s1
    s.subi       s27, s4, #1
    s.sub        s28, s15, s25
    s.and        s25, s1, s28
    s.and        s29, s18, s28
    s.sub        s18, s26, s25
    s.or         s25, s6, s29
    s.mov        s17, s18
    s.mov        s6, s25
    s.mov        s4, s27
    s.cmp.ge     s18, s4, s15
    br.nz        s18, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.xor        s4, s17, s9
    s.cmp.lt     s6, s16, s1
    s.cmp.lt     s12, s7, s1
    s.sub        s15, s1, s6
    s.sub        s6, s1, s12
    s.xor        s12, s16, s15
    s.xor        s16, s7, s6
    s.sub        s7, s12, s15
    s.sub        s12, s4, s9
    s.sub        s4, s16, s6
    s.addi       s9, s1, #0
    s.cmp.eq     s16, s7, s8
    s.add        s8, s11, s12
    s.addi       s11, s1, #0
    s.mov        s9, s4
    br.nz        s16, sdiv_done_7
    s.movz       s12, #0
    s.movz       s16, #31
    s.mov        s9, s12
    s.addi       s12, s16, #0
sdiv_8:
    s.lshr       s16, s4, s12
    s.shli       s17, s11, #1
    s.andi       s18, s16, #1
    s.movz       s16, #1
    s.or         s25, s17, s18
    s.shl        s17, s16, s12
    s.cmp.geu    s16, s25, s7
    s.subi       s18, s12, #1
    s.sub        s26, s1, s16
    s.and        s16, s7, s26
    s.and        s27, s17, s26
    s.sub        s17, s25, s16
    s.or         s16, s9, s27
    s.mov        s11, s17
    s.mov        s9, s16
    s.mov        s12, s18
    s.cmp.ge     s16, s12, s1
    br.nz        s16, sdiv_8
sdiv_done_7:
    s.xor        s1, s6, s15
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s4, s9, s1
    v.movi       v1, #16
    s.sub        s6, s4, s1
    v.movi       v2, #32
    s.mul        s1, s6, s5
    v.movi       v3, #48
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #64
    v.movi       v6, #80
    v.splat      v7, s1
    v.movi       v8, #96
    v.iota       v9                              // arange(0, VLEN)
    v.movi       v10, #112
    v.add        v11, v7, v0
    v.splat      v12, s3
    v.movi       v13, #0
    v.add        v14, v0, v1
    v.add        v1, v0, v2
    v.add        v2, v0, v3
    v.add        v0, v4, v5
    v.add        v3, v4, v6
    v.add        v5, v4, v8
    v.add        v4, v9, v10
    v.sub        v6, v13, v11
    v.sub        v8, v13, v12
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v12, v13
    v.add        v9, v7, v14
    v.add        v10, v7, v1
    v.add        v1, v7, v2
    v.add        v2, v7, v0
    v.add        v0, v7, v3
    v.add        v3, v7, v5
    v.add        v5, v7, v4
    v.movi       v4, #1
    @p1 v.sel        v7, v6, v11
    @p2 v.sel        v6, v8, v12
    v.movi       v8, #0
    v.movi       v11, #0
    s.movz       s4, #31
idiv_9:
    v.splat      v14, s4
    v.shl        v15, v11, v4
    v.cmp.lt     p2, v11, v13
    v.lshr       v16, v7, v14
    v.shl        v17, v4, v14
    s.subi       s6, s4, #1
    v.and        v14, v16, v4
    s.movz       s7, #0
    v.or         v16, v15, v14
    v.cmp.geu    p3, v16, v6
    p.or         p4, p2, p3
    v.sub        v14, v16, v6
    @p4 v.sel        v15, v17, v13
    @p4 v.sel        v17, v14, v16
    v.or         v14, v8, v15
    v.mov        v11, v17
    v.mov        v8, v14
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_9
    v.movi       v4, #0
    v.sub        v6, v13, v11
    v.movi       v7, #1
    v.sub        v8, v4, v9
    v.sub        v13, v4, v12
    v.cmp.lt     p2, v9, v4
    v.cmp.lt     p3, v12, v4
    @p1 v.sel        v14, v6, v11
    @p2 v.sel        v6, v8, v9
    @p3 v.sel        v8, v13, v12
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s4, #31
idiv_10:
    v.splat      v13, s4
    v.shl        v15, v11, v7
    v.cmp.lt     p1, v11, v4
    v.lshr       v16, v6, v13
    v.shl        v17, v7, v13
    s.subi       s6, s4, #1
    v.and        v13, v16, v7
    v.or         v16, v15, v13
    v.cmp.geu    p3, v16, v8
    p.or         p4, p1, p3
    v.sub        v13, v16, v8
    @p4 v.sel        v15, v17, v4
    @p4 v.sel        v17, v13, v16
    v.or         v13, v9, v15
    v.mov        v11, v17
    v.mov        v9, v13
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_10
    v.movi       v6, #0
    v.sub        v7, v4, v11
    v.movi       v4, #1
    v.sub        v8, v6, v10
    v.sub        v9, v6, v12
    v.cmp.lt     p1, v10, v6
    v.cmp.lt     p3, v12, v6
    @p2 v.sel        v13, v7, v11
    @p1 v.sel        v7, v8, v10
    @p3 v.sel        v8, v9, v12
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s4, #31
idiv_11:
    v.splat      v11, s4
    v.shl        v15, v10, v4
    v.cmp.lt     p2, v10, v6
    v.lshr       v16, v7, v11
    v.shl        v17, v4, v11
    s.subi       s6, s4, #1
    v.and        v11, v16, v4
    s.movz       s7, #0
    v.or         v16, v15, v11
    v.cmp.geu    p3, v16, v8
    p.or         p4, p2, p3
    v.sub        v11, v16, v8
    @p4 v.sel        v15, v17, v6
    @p4 v.sel        v17, v11, v16
    v.or         v11, v9, v15
    v.mov        v10, v17
    v.mov        v9, v11
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_11
    v.movi       v4, #0
    v.sub        v7, v6, v10
    v.movi       v6, #1
    v.sub        v8, v4, v1
    v.sub        v9, v4, v12
    v.cmp.lt     p2, v1, v4
    v.cmp.lt     p3, v12, v4
    @p1 v.sel        v11, v7, v10
    @p2 v.sel        v7, v8, v1
    @p3 v.sel        v1, v9, v12
    v.movi       v8, #0
    v.movi       v9, #0
    s.movz       s4, #31
idiv_12:
    v.splat      v10, s4
    v.shl        v15, v9, v6
    v.cmp.lt     p1, v9, v4
    v.lshr       v16, v7, v10
    v.shl        v17, v6, v10
    s.subi       s6, s4, #1
    v.and        v10, v16, v6
    v.or         v16, v15, v10
    v.cmp.geu    p3, v16, v1
    p.or         p4, p1, p3
    v.sub        v10, v16, v1
    @p4 v.sel        v15, v17, v4
    @p4 v.sel        v17, v10, v16
    v.or         v10, v8, v15
    v.mov        v9, v17
    v.mov        v8, v10
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_12
    v.movi       v1, #0
    v.sub        v6, v4, v9
    v.movi       v4, #1
    v.sub        v7, v1, v2
    v.sub        v8, v1, v12
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p3, v12, v1
    @p2 v.sel        v10, v6, v9
    @p1 v.sel        v6, v7, v2
    @p3 v.sel        v2, v8, v12
    v.movi       v7, #0
    v.movi       v8, #0
    s.movz       s4, #31
idiv_13:
    v.splat      v9, s4
    v.shl        v15, v8, v4
    v.cmp.lt     p2, v8, v1
    v.lshr       v16, v6, v9
    v.shl        v17, v4, v9
    s.subi       s6, s4, #1
    v.and        v9, v16, v4
    s.movz       s7, #0
    v.or         v16, v15, v9
    v.cmp.geu    p3, v16, v2
    p.or         p4, p2, p3
    v.sub        v9, v16, v2
    @p4 v.sel        v15, v17, v1
    @p4 v.sel        v17, v9, v16
    v.or         v9, v7, v15
    v.mov        v8, v17
    v.mov        v7, v9
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_13
    v.movi       v2, #0
    v.sub        v4, v1, v8
    v.movi       v1, #1
    v.sub        v6, v2, v0
    v.sub        v7, v2, v12
    v.cmp.lt     p2, v0, v2
    v.cmp.lt     p3, v12, v2
    @p1 v.sel        v9, v4, v8
    @p2 v.sel        v4, v6, v0
    @p3 v.sel        v0, v7, v12
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s4, #31
idiv_14:
    v.splat      v8, s4
    v.shl        v15, v7, v1
    v.cmp.lt     p1, v7, v2
    v.lshr       v16, v4, v8
    v.shl        v17, v1, v8
    s.subi       s6, s4, #1
    v.and        v8, v16, v1
    v.or         v16, v15, v8
    v.cmp.geu    p3, v16, v0
    p.or         p4, p1, p3
    v.sub        v8, v16, v0
    @p4 v.sel        v15, v17, v2
    @p4 v.sel        v17, v8, v16
    v.or         v8, v6, v15
    v.mov        v7, v17
    v.mov        v6, v8
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_14
    v.movi       v0, #0
    v.sub        v1, v2, v7
    v.movi       v2, #1
    v.sub        v4, v0, v3
    v.sub        v6, v0, v12
    v.cmp.lt     p1, v3, v0
    v.cmp.lt     p3, v12, v0
    @p2 v.sel        v8, v1, v7
    @p1 v.sel        v1, v4, v3
    @p3 v.sel        v3, v6, v12
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s4, #31
idiv_15:
    v.splat      v7, s4
    v.shl        v15, v6, v2
    v.cmp.lt     p2, v6, v0
    v.lshr       v16, v1, v7
    v.shl        v17, v2, v7
    s.subi       s6, s4, #1
    v.and        v7, v16, v2
    s.movz       s7, #0
    v.or         v16, v15, v7
    v.cmp.geu    p3, v16, v3
    p.or         p4, p2, p3
    v.sub        v7, v16, v3
    @p4 v.sel        v15, v17, v0
    @p4 v.sel        v17, v7, v16
    v.or         v7, v4, v15
    v.mov        v6, v17
    v.mov        v4, v7
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_15
    v.movi       v1, #0
    v.sub        v2, v0, v6
    v.movi       v0, #1
    v.sub        v3, v1, v5
    v.sub        v4, v1, v12
    v.cmp.lt     p2, v5, v1
    v.cmp.lt     p3, v12, v1
    @p1 v.sel        v7, v2, v6
    @p2 v.sel        v2, v3, v5
    @p3 v.sel        v3, v4, v12
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s4, #31
idiv_16:
    v.splat      v6, s4
    v.shl        v12, v5, v0
    v.cmp.lt     p1, v5, v1
    v.lshr       v15, v2, v6
    v.shl        v16, v0, v6
    s.subi       s6, s4, #1
    v.and        v6, v15, v0
    v.or         v15, v12, v6
    v.cmp.geu    p3, v15, v3
    p.or         p4, p1, p3
    v.sub        v6, v15, v3
    @p4 v.sel        v12, v16, v1
    @p4 v.sel        v16, v6, v15
    v.or         v6, v4, v12
    v.mov        v5, v16
    v.mov        v4, v6
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_16
    v.sub        v0, v1, v5
    v.movi       v1, #0
    v.movi       v2, #0
    @p2 v.sel        v3, v0, v5
    v.movi       v0, #0
    v.movi       v4, #0
    v.sub        v5, v1, v14
    v.sub        v6, v2, v13
    v.sub        v12, v0, v11
    v.cmp.lt     p1, v14, v1
    v.cmp.lt     p2, v13, v2
    v.cmp.lt     p3, v11, v0
    @p1 v.sel        v15, v5, v14
    v.movi       v5, #7
    @p2 v.sel        v16, v6, v13
    v.movi       v6, #7
    @p3 v.sel        v17, v12, v11
    v.movi       v12, #7
    v.lshr       v18, v15, v5
    v.lshr       v5, v16, v6
    v.lshr       v6, v17, v12
    v.movi       v12, #128
    v.sub        v15, v1, v18
    v.movi       v16, #128
    v.sub        v17, v2, v5
    v.movi       v19, #128
    v.sub        v20, v0, v6
    v.movi       v21, #128
    v.sub        v22, v1, v12
    @p1 v.sel        v23, v15, v18
    v.sub        v15, v2, v16
    @p2 v.sel        v18, v17, v5
    v.sub        v5, v0, v19
    @p3 v.sel        v17, v20, v6
    v.cmp.lt     p1, v12, v1
    v.cmp.lt     p2, v16, v2
    v.cmp.lt     p3, v19, v0
    s.movz       s4, #16
    s.movz       s6, #32
    s.movz       s7, #48
    s.movz       s9, #64
    v.sub        v0, v4, v10
    s.movz       s11, #80
    s.movz       s12, #96
    v.sub        v1, v4, v21
    s.movz       s15, #112
    v.movi       v2, #7
    v.movi       v6, #1
    v.movi       v6, #0
    @p1 v.sel        v20, v22, v12
    v.cmp.lt     p1, v10, v4
    v.sub        v12, v6, v9
    @p1 v.sel        v20, v0, v10
    v.movi       v0, #7
    v.movi       v22, #1
    v.lshr       v22, v20, v2
    v.movi       v2, #0
    @p2 v.sel        v20, v15, v16
    v.cmp.lt     p2, v9, v6
    v.sub        v15, v2, v8
    @p2 v.sel        v16, v12, v9
    v.movi       v12, #7
    v.movi       v20, #1
    v.lshr       v20, v16, v0
    v.movi       v0, #0
    @p3 v.sel        v16, v5, v19
    v.cmp.lt     p3, v8, v2
    v.sub        v5, v0, v7
    @p3 v.sel        v16, v15, v8
    v.movi       v15, #7
    v.movi       v19, #1
    v.lshr       v19, v16, v12
    v.sub        v12, v4, v22
    v.movi       v16, #1
    v.movi       v16, #1
    @p1 v.sel        v16, v12, v22
    v.cmp.lt     p1, v7, v0
    @p1 v.sel        v12, v5, v7
    v.movi       v5, #128
    v.movi       v22, #1
    v.lshr       v22, v12, v15
    v.sub        v12, v6, v20
    @p2 v.sel        v15, v12, v20
    v.movi       v12, #128
    v.cmp.lt     p2, v21, v4
    v.movi       v4, #0
    @p2 v.sel        v20, v1, v21
    v.movi       v1, #7
    v.sub        v20, v4, v3
    v.cmp.lt     p2, v3, v4
    v.movi       v21, #1
    @p2 v.sel        v21, v20, v3
    v.lshr       v20, v21, v1
    v.sub        v1, v2, v19
    @p3 v.sel        v21, v1, v19
    v.movi       v1, #128
    v.cmp.lt     p3, v5, v6
    v.sub        v19, v6, v5
    @p3 v.sel        v6, v19, v5
    s.add        s16, s21, s2
    s.movz       s2, #0
    v.sub        v5, v0, v22
    s.cmp.lt     s17, s16, s2
    v.movi       v6, #128
    s.sub        s18, s2, s17
    @p1 v.sel        v19, v5, v22
    v.sub        v5, v4, v20
    v.cmp.lt     p1, v12, v2
    s.xor        s17, s16, s18
    s.cmp.lt     s16, s5, s2
    v.sub        v22, v2, v12
    s.sub        s25, s17, s18
    s.sub        s17, s2, s16
    @p2 v.sel        v2, v5, v20
    v.sub        v5, v0, v1
    v.cmp.lt     p2, v1, v0
    v.sub        v0, v4, v6
    v.cmp.lt     p3, v6, v4
    v.splat      v4, s24
    @p1 v.sel        v20, v22, v12
    s.lshri      s16, s25, #7
    s.xor        s24, s18, s17
    s.muli       s18, s16, #128
    v.movi       v12, #0
    s.xor        s26, s5, s17
    s.xor        s27, s16, s24
    @p2 v.sel        v20, v5, v1
    s.rdspecial  s16, arg_base
    @p3 v.sel        v1, v0, v6
    s.ld.d       s28, [s16, #80]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.mul        v0, v23, v4
    v.mul        v1, v18, v4
    v.mul        v5, v17, v4
    v.mul        v6, v16, v4
    v.mul        v16, v15, v4
    v.mul        v15, v21, v4
    v.mul        v17, v19, v4
    v.mul        v18, v2, v4
    v.movi       v2, #0
    s.sub        s16, s26, s17
    s.addi       s16, s28, #0
    s.addi       s17, s28, #1024
    s.addi       s26, s16, #64
    s.addi       s29, s16, #128
    s.addi       s30, s16, #192
    s.addi       s31, s16, #256
    s.sub        s32, s25, s18
    s.addi       s18, s16, #320
    s.addi       s25, s16, #384
    s.sub        s32, s27, s24
    s.addi       s24, s16, #448
    s.addi       s27, s20, #0
    v.st.w       [s16, #0], v12
    v.st.w       [s26, #0], v12
    s.addi       s20, s16, #512
    v.st.w       [s29, #0], v12
    s.addi       s26, s16, #576
    v.st.w       [s30, #0], v12
    s.addi       s29, s16, #640
    v.st.w       [s31, #0], v12
    s.addi       s30, s16, #704
    v.st.w       [s18, #0], v12
    s.addi       s18, s16, #768
    v.st.w       [s25, #0], v12
    s.addi       s25, s16, #832
    v.st.w       [s24, #0], v12
    s.addi       s24, s16, #896
    s.addi       s31, s16, #960
    v.st.w       [s20, #0], v12
    s.addi       s16, s17, #64
    v.st.w       [s26, #0], v12
    s.addi       s20, s17, #128
    v.st.w       [s29, #0], v12
    s.addi       s26, s17, #192
    v.st.w       [s30, #0], v12
    s.addi       s29, s2, #0
    v.st.w       [s18, #0], v12
    s.addi       s18, s2, #0
    v.st.w       [s25, #0], v12
    s.addi       s25, s17, #256
    v.st.w       [s24, #0], v12
    s.addi       s24, s2, #0
    v.movi       v4, #0
    v.st.w       [s31, #0], v12
    s.addi       s30, s28, #2048
    fence.acq_rel.device
    v.st.w       [s17, #0], v2
    v.st.w       [s16, #0], v2
    s.addi       s16, s17, #320
    v.st.w       [s20, #0], v2
    s.addi       s20, s17, #384
    v.st.w       [s26, #0], v2
    s.addi       s26, s17, #448
    v.st.w       [s25, #0], v2
    s.addi       s25, s17, #512
    v.st.w       [s16, #0], v2
    s.addi       s16, s17, #576
    v.st.w       [s20, #0], v2
    s.addi       s20, s17, #640
    v.st.w       [s26, #0], v2
    s.addi       s26, s17, #704
    v.st.w       [s25, #0], v2
    s.addi       s25, s17, #768
    v.st.w       [s16, #0], v2
    s.addi       s16, s28, #3072
    v.movi       v12, #0
    v.st.w       [s20, #0], v2
    s.addi       s20, s17, #832
    v.st.w       [s26, #0], v2
    s.addi       s26, s17, #896
    s.addi       s31, s17, #960
    v.st.w       [s25, #0], v2
    s.addi       s17, s30, #64
    v.st.w       [s20, #0], v2
    s.addi       s20, s30, #128
    v.st.w       [s26, #0], v2
    s.addi       s25, s30, #192
    v.st.w       [s31, #0], v2
    s.addi       s26, s30, #256
    fence.acq_rel.device
    v.st.w       [s30, #0], v4
    v.st.w       [s17, #0], v4
    s.addi       s17, s30, #320
    v.st.w       [s20, #0], v4
    s.addi       s20, s30, #384
    v.st.w       [s25, #0], v4
    s.addi       s25, s30, #448
    v.st.w       [s26, #0], v4
    s.addi       s26, s30, #512
    v.st.w       [s17, #0], v4
    s.addi       s17, s30, #576
    v.st.w       [s20, #0], v4
    s.addi       s20, s30, #640
    v.st.w       [s25, #0], v4
    s.addi       s25, s30, #704
    v.st.w       [s26, #0], v4
    s.addi       s26, s30, #768
    v.st.w       [s17, #0], v4
    s.addi       s17, s28, #4096
    v.movi       v2, #0
    v.st.w       [s20, #0], v4
    s.addi       s20, s30, #832
    v.st.w       [s25, #0], v4
    s.addi       s25, s30, #896
    s.addi       s31, s30, #960
    v.st.w       [s26, #0], v4
    s.addi       s26, s16, #64
    v.st.w       [s20, #0], v4
    s.addi       s20, s16, #128
    v.st.w       [s25, #0], v4
    s.addi       s25, s16, #192
    v.st.w       [s31, #0], v4
    s.addi       s30, s16, #256
    fence.acq_rel.device
    v.st.w       [s16, #0], v12
    v.st.w       [s26, #0], v12
    s.addi       s26, s16, #320
    v.st.w       [s20, #0], v12
    s.addi       s20, s16, #384
    v.st.w       [s25, #0], v12
    s.addi       s25, s16, #448
    v.st.w       [s30, #0], v12
    s.addi       s30, s16, #512
    v.st.w       [s26, #0], v12
    s.addi       s26, s16, #576
    v.st.w       [s20, #0], v12
    s.addi       s20, s16, #640
    v.st.w       [s25, #0], v12
    s.addi       s25, s16, #704
    v.st.w       [s30, #0], v12
    s.addi       s30, s16, #768
    v.st.w       [s26, #0], v12
    s.addi       s26, s28, #5120
    v.movi       v4, #0
    v.st.w       [s20, #0], v12
    s.addi       s20, s16, #832
    v.st.w       [s25, #0], v12
    s.addi       s25, s16, #896
    s.addi       s31, s16, #960
    v.st.w       [s30, #0], v12
    s.addi       s16, s17, #64
    v.st.w       [s20, #0], v12
    s.addi       s20, s17, #128
    v.st.w       [s25, #0], v12
    s.addi       s25, s17, #192
    v.st.w       [s31, #0], v12
    s.addi       s30, s17, #256
    fence.acq_rel.device
    v.st.w       [s17, #0], v2
    v.st.w       [s16, #0], v2
    s.addi       s16, s17, #320
    v.st.w       [s20, #0], v2
    s.addi       s20, s17, #384
    v.st.w       [s25, #0], v2
    s.addi       s25, s17, #448
    v.st.w       [s30, #0], v2
    s.addi       s30, s17, #512
    v.st.w       [s16, #0], v2
    s.addi       s16, s17, #576
    v.st.w       [s20, #0], v2
    s.addi       s20, s17, #640
    v.st.w       [s25, #0], v2
    s.addi       s25, s17, #704
    v.st.w       [s30, #0], v2
    s.addi       s30, s17, #768
    v.st.w       [s16, #0], v2
    s.addi       s16, s28, #6144
    v.movi       v12, #0
    v.st.w       [s20, #0], v2
    s.addi       s20, s17, #832
    v.st.w       [s25, #0], v2
    s.addi       s25, s17, #896
    s.addi       s31, s17, #960
    v.st.w       [s30, #0], v2
    s.addi       s17, s26, #64
    v.st.w       [s20, #0], v2
    s.addi       s20, s26, #128
    v.st.w       [s25, #0], v2
    s.addi       s25, s26, #192
    v.st.w       [s31, #0], v2
    s.addi       s30, s26, #256
    fence.acq_rel.device
    v.st.w       [s26, #0], v4
    v.st.w       [s17, #0], v4
    s.addi       s17, s26, #320
    v.st.w       [s20, #0], v4
    s.addi       s20, s26, #384
    v.st.w       [s25, #0], v4
    s.addi       s25, s26, #448
    v.st.w       [s30, #0], v4
    s.addi       s30, s26, #512
    v.st.w       [s17, #0], v4
    s.addi       s17, s26, #576
    v.st.w       [s20, #0], v4
    s.addi       s20, s26, #640
    v.st.w       [s25, #0], v4
    s.addi       s25, s26, #704
    v.st.w       [s30, #0], v4
    s.addi       s30, s26, #768
    v.st.w       [s17, #0], v4
    s.addi       s17, s28, #7168
    v.movi       v2, #0
    v.st.w       [s20, #0], v4
    s.addi       s20, s26, #832
    v.st.w       [s25, #0], v4
    s.addi       s25, s26, #896
    s.addi       s31, s26, #960
    v.st.w       [s30, #0], v4
    s.addi       s26, s16, #64
    v.st.w       [s20, #0], v4
    s.addi       s20, s16, #128
    v.st.w       [s25, #0], v4
    s.addi       s25, s16, #192
    v.st.w       [s31, #0], v4
    s.addi       s30, s16, #256
    fence.acq_rel.device
    v.st.w       [s16, #0], v12
    v.st.w       [s26, #0], v12
    s.addi       s26, s16, #320
    v.st.w       [s20, #0], v12
    s.addi       s20, s16, #384
    v.st.w       [s25, #0], v12
    s.addi       s25, s16, #448
    v.st.w       [s30, #0], v12
    s.addi       s30, s16, #512
    v.st.w       [s26, #0], v12
    s.addi       s26, s16, #576
    v.st.w       [s20, #0], v12
    s.addi       s20, s16, #640
    v.st.w       [s25, #0], v12
    s.addi       s25, s16, #704
    v.st.w       [s30, #0], v12
    s.addi       s30, s16, #768
    v.st.w       [s26, #0], v12
    s.addi       s26, s16, #832
    v.st.w       [s20, #0], v12
    s.addi       s20, s16, #896
    s.addi       s31, s16, #960
    v.st.w       [s25, #0], v12
    s.addi       s16, s17, #64
    v.st.w       [s30, #0], v12
    s.addi       s25, s17, #128
    v.st.w       [s26, #0], v12
    s.addi       s26, s17, #192
    v.st.w       [s20, #0], v12
    s.addi       s20, s17, #256
    v.st.w       [s31, #0], v12
    s.addi       s30, s17, #320
    fence.acq_rel.device
    v.st.w       [s17, #0], v2
    v.st.w       [s16, #0], v2
    s.addi       s16, s17, #384
    v.st.w       [s25, #0], v2
    s.addi       s25, s17, #448
    v.st.w       [s26, #0], v2
    s.addi       s26, s17, #512
    v.st.w       [s20, #0], v2
    s.addi       s20, s17, #576
    v.st.w       [s30, #0], v2
    s.addi       s30, s17, #640
    v.st.w       [s16, #0], v2
    s.addi       s16, s17, #704
    v.st.w       [s25, #0], v2
    s.addi       s25, s17, #768
    v.st.w       [s26, #0], v2
    s.addi       s26, s17, #832
    v.st.w       [s20, #0], v2
    s.addi       s20, s17, #896
    s.addi       s31, s17, #960
    v.st.w       [s30, #0], v2
    v.st.w       [s16, #0], v2
    v.st.w       [s25, #0], v2
    v.st.w       [s26, #0], v2
    v.st.w       [s20, #0], v2
    v.st.w       [s31, #0], v2
    fence.acq_rel.device
for_25:
    s.cmp.ge     s16, s29, s32
    br.nz        s16, endfor_26
    s.mul        s16, s29, s5
    s.movz       s17, #0
    s.muli       s20, s18, #2
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s25, s28, #8192
    s.sub        s26, s21, s16
    s.addi       s16, s25, #64
    s.add        s30, s17, s26                   // the tile origin
    s.add        s17, s14, s20
    v.splat      v4, s30
    s.addi       s30, s25, #128
    s.addi       s31, s25, #192
    v.cmp.lt     p1, v2, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    s.addi       s33, s25, #256
    s.addi       s34, s25, #320
    s.addi       s35, s25, #384
    s.addi       s36, s25, #448
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s25, #0], v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s16, #0], v12
    s.addi       s16, s25, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s30, #0], v12
    s.addi       s30, s25, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.addi       s31, s25, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s33, s25, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s34, #0], v12
    s.add        s34, s14, s20
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s35, s25, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    s.addi       s36, s25, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s16, #0], v12
    s.addi       s16, s25, #896
    s.addi       s37, s25, #960
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s30, #0], v12
    s.movz       s25, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.add        s30, s25, s4                    // the tile origin
    s.add        s31, s25, s26                   // the tile origin
    v.splat      v4, s30
    s.addi       s25, s20, #32
    v.splat      v12, s31
    v.add        v19, v2, v4
    s.add        s30, s14, s25
    s.addi       s25, s28, #9216
    v.cmp.lt     p2, v19, v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    s.addi       s17, s25, #64
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s31, s25, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s34, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s33, s25, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s34, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    s.addi       s35, s25, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s34, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s16, #0], v12
    s.addi       s16, s25, #320
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s34, #0]
    s.addi       s34, s25, #384
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s37, #0], v12
    fence.acq_rel.device
    s.addi       s36, s25, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s25, #0], v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s17, #0], v12
    s.addi       s17, s25, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.addi       s31, s20, #32
    s.add        s37, s14, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s31, s25, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s33, s25, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s16, #0], v12
    s.addi       s16, s25, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s34, #0], v12
    s.addi       s34, s25, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    s.addi       s35, s25, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s17, #0], v12
    s.addi       s17, s25, #896
    s.addi       s36, s25, #960
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s30, #0]
    s.movz       s25, #0
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.add        s30, s25, s6                    // the tile origin
    s.add        s31, s25, s26                   // the tile origin
    v.splat      v4, s30
    s.addi       s25, s20, #64
    v.splat      v12, s31
    v.add        v19, v2, v4
    s.add        s30, s14, s25
    s.addi       s25, s28, #10240
    v.cmp.lt     p1, v19, v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s31, s25, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s16, #0], v12
    s.addi       s16, s25, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s34, #0], v12
    s.addi       s33, s25, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s34, s25, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s17, #0], v12
    s.addi       s17, s25, #320
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    s.addi       s35, s25, #384
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    fence.acq_rel.device
    s.addi       s36, s25, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s25, #0], v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.addi       s31, s25, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s16, #0], v12
    s.addi       s16, s20, #64
    s.add        s37, s14, s16
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s16, s25, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s34, #0], v12
    s.addi       s33, s25, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s17, #0], v12
    s.addi       s17, s25, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s34, s25, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    s.addi       s35, s25, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s30, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.addi       s31, s25, #896
    s.addi       s36, s25, #960
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s30, #0]
    s.movz       s25, #0
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s16, #0], v12
    s.add        s16, s25, s7                    // the tile origin
    s.add        s30, s25, s26                   // the tile origin
    v.splat      v4, s16
    s.addi       s16, s20, #96
    v.splat      v12, s30
    v.add        v19, v2, v4
    s.add        s25, s14, s16
    s.addi       s16, s28, #11264
    v.cmp.lt     p2, v19, v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s30, s16, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s17, #0], v12
    s.addi       s17, s16, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s34, #0], v12
    s.addi       s33, s16, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s34, s16, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.addi       s31, s16, #320
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s37, #0]
    s.addi       s35, s16, #384
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    fence.acq_rel.device
    s.addi       s36, s16, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s25, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s16, #0], v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s25, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s30, #0], v12
    s.addi       s30, s16, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s25, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s17, #0], v12
    s.addi       s17, s20, #96
    s.add        s37, s14, s17
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s25, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s17, s16, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s25, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s34, #0], v12
    s.addi       s33, s16, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s25, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.addi       s31, s16, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s25, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s34, s16, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s25, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    s.addi       s35, s16, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s25, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s30, #0], v12
    s.addi       s30, s16, #896
    s.addi       s36, s16, #960
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s25, #0]
    s.movz       s16, #0
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s17, #0], v12
    s.add        s17, s16, s9                    // the tile origin
    s.add        s25, s16, s26                   // the tile origin
    v.splat      v4, s17
    s.addi       s16, s20, #128
    v.splat      v12, s25
    v.add        v19, v2, v4
    s.add        s17, s14, s16
    s.addi       s16, s28, #12288
    v.cmp.lt     p1, v19, v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s25, s16, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.addi       s31, s16, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s34, #0], v12
    s.addi       s33, s16, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s34, s16, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s30, #0], v12
    s.addi       s30, s16, #320
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    s.addi       s35, s16, #384
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    fence.acq_rel.device
    s.addi       s36, s16, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s16, #0], v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s25, #0], v12
    s.addi       s25, s16, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.addi       s31, s20, #128
    s.add        s37, s14, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s31, s16, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s34, #0], v12
    s.addi       s33, s16, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s30, #0], v12
    s.addi       s30, s16, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s34, s16, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    s.addi       s35, s16, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s25, #0], v12
    s.addi       s25, s16, #896
    s.addi       s36, s16, #960
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    s.movz       s16, #0
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.add        s17, s16, s11                   // the tile origin
    s.add        s31, s16, s26                   // the tile origin
    v.splat      v4, s17
    s.addi       s16, s20, #160
    v.splat      v12, s31
    v.add        v19, v2, v4
    s.add        s17, s14, s16
    s.addi       s16, s28, #13312
    v.cmp.lt     p2, v19, v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s31, s16, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s30, #0], v12
    s.addi       s30, s16, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s34, #0], v12
    s.addi       s33, s16, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s34, s16, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s25, #0], v12
    s.addi       s25, s16, #320
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s37, #0]
    s.addi       s35, s16, #384
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    fence.acq_rel.device
    s.addi       s36, s16, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s16, #0], v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.addi       s31, s16, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s30, #0], v12
    s.addi       s30, s20, #160
    s.add        s37, s14, s30
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s30, s16, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s34, #0], v12
    s.addi       s33, s16, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s25, #0], v12
    s.addi       s25, s16, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s34, s16, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    s.addi       s35, s16, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.addi       s31, s16, #896
    s.addi       s36, s16, #960
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s17, #0]
    s.movz       s16, #0
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s30, #0], v12
    s.add        s17, s16, s12                   // the tile origin
    s.add        s30, s16, s26                   // the tile origin
    v.splat      v4, s17
    s.addi       s16, s20, #192
    v.splat      v12, s30
    v.add        v19, v2, v4
    s.add        s17, s14, s16
    s.addi       s16, s28, #14336
    v.cmp.lt     p1, v19, v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s30, s16, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s25, #0], v12
    s.addi       s25, s16, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s34, #0], v12
    s.addi       s33, s16, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s34, s16, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.addi       s31, s16, #320
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s37, #0]
    s.addi       s35, s16, #384
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    fence.acq_rel.device
    s.addi       s36, s16, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s16, #0], v12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s30, #0], v12
    s.addi       s30, s16, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s25, #0], v12
    s.addi       s25, s20, #192
    s.add        s37, s14, s25
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s33, #0], v12
    s.addi       s25, s16, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s34, #0], v12
    s.addi       s33, s16, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s31, #0], v12
    s.addi       s31, s16, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s35, #0], v12
    s.addi       s34, s16, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s36, #0], v12
    s.addi       s35, s16, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s30, #0], v12
    s.addi       s30, s16, #896
    s.addi       s36, s16, #960
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s17, #0]
    s.movz       s16, #0
    vf.cvt.bf16.f32 v12, v4
    v.st.w       [s25, #0], v12
    s.add        s17, s16, s15                   // the tile origin
    s.add        s25, s16, s26                   // the tile origin
    v.splat      v4, s17
    s.addi       s16, s20, #224
    v.splat      v12, s25
    v.add        v19, v2, v4
    s.add        s17, s14, s16
    s.addi       s16, s28, #15360
    v.cmp.lt     p2, v19, v12
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s37, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s33, #0], v4
    s.addi       s25, s16, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s37, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s31, #0], v4
    s.addi       s31, s16, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s37, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s34, #0], v4
    s.addi       s33, s16, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s37, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s35, #0], v4
    s.addi       s34, s16, #256
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s37, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s30, #0], v4
    s.addi       s30, s16, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s37, #0]
    s.addi       s35, s16, #384
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s36, #0], v4
    fence.acq_rel.device
    s.addi       s36, s16, #448
    s.addi       s37, s20, #224
    s.add        s20, s14, s37
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s17, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s16, #0], v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s17, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s25, #0], v4
    s.addi       s25, s16, #512
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s17, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s31, #0], v4
    s.addi       s31, s16, #576
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s17, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s33, #0], v4
    s.addi       s33, s16, #640
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s17, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s34, #0], v4
    s.addi       s34, s16, #704
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s17, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s30, #0], v4
    s.addi       s30, s16, #768
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s17, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s35, #0], v4
    s.addi       s35, s16, #832
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s17, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s36, #0], v4
    s.addi       s36, s16, #896
    s.addi       s37, s16, #960
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s17, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s25, #0], v4
    s.addi       s16, s28, #8192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s17, #0]
    s.addi       s17, s28, #9216
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s31, #0], v4
    s.addi       s25, s28, #10240
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s20, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s33, #0], v4
    s.addi       s31, s28, #11264
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s20, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s34, #0], v4
    s.addi       s33, s28, #12288
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s20, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s30, #0], v4
    s.addi       s30, s28, #8256
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s20, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s35, #0], v4
    s.addi       s34, s28, #9280
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s20, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s36, #0], v4
    s.addi       s35, s28, #10304
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s20, #0]
    s.addi       s20, s28, #11328
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s37, #0], v4
    fence.acq_rel.device
    s.addi       s36, s28, #12352
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s28, #13312
    v.ld.w       v4, [s17, #0]
    vf.abs       v12, v2
    s.addi       s17, s28, #13376
    v.ld.w       v2, [s30, #0]
    vf.abs       v19, v4
    s.addi       s30, s28, #14336
    vf.max.ieee  v4, v12, v19
    v.ld.w       v12, [s34, #0]
    vf.abs       v19, v2
    s.addi       s34, s28, #14400
    v.ld.w       v2, [s25, #0]
    vf.abs       v20, v12
    s.addi       s25, s28, #15360
    vf.max.ieee  v12, v19, v20
    v.ld.w       v19, [s35, #0]
    vf.abs       v20, v2
    vf.max.ieee  v2, v4, v20
    s.addi       s35, s28, #15424
    v.ld.w       v4, [s31, #0]
    vf.abs       v20, v19
    vf.max.ieee  v19, v12, v20
    v.ld.w       v12, [s20, #0]
    vf.abs       v20, v4
    vf.max.ieee  v4, v2, v20
    v.ld.w       v2, [s33, #0]
    s.addi       s20, s28, #8320
    vf.abs       v20, v12
    vf.max.ieee  v12, v19, v20
    v.ld.w       v19, [s36, #0]
    vf.abs       v20, v2
    vf.max.ieee  v2, v4, v20
    s.addi       s31, s28, #9344
    v.ld.w       v4, [s20, #0]
    vf.abs       v20, v19
    vf.max.ieee  v19, v12, v20
    v.ld.w       v12, [s16, #0]
    vf.abs       v20, v4
    v.ld.w       v4, [s31, #0]
    vf.abs       v21, v12
    vf.max.ieee  v12, v2, v21
    s.addi       s16, s28, #10368
    v.ld.w       v2, [s17, #0]
    vf.abs       v21, v4
    vf.max.ieee  v4, v20, v21
    v.ld.w       v20, [s30, #0]
    vf.abs       v21, v2
    vf.max.ieee  v2, v19, v21
    v.ld.w       v19, [s16, #0]
    vf.abs       v21, v20
    vf.max.ieee  v20, v12, v21
    s.addi       s16, s28, #11392
    v.ld.w       v12, [s34, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v4, v21
    v.ld.w       v4, [s25, #0]
    vf.abs       v21, v12
    vf.max.ieee  v12, v2, v21
    v.ld.w       v2, [s16, #0]
    vf.abs       v21, v4
    vf.max.ieee  v4, v20, v21
    vf.reduce.max.b v20, v4
    s.addi       s16, s28, #8384
    s.addi       s17, s28, #9408
    s.addi       s20, s28, #10432
    s.addi       s25, s28, #11456
    s.addi       s30, s28, #12416
    s.addi       s31, s28, #13440
    v.ld.w       v4, [s16, #0]
    s.addi       s16, s28, #14464
    vf.abs       v21, v2
    s.addi       s33, s28, #15488
    vf.max.ieee  v2, v19, v21
    v.ld.w       v19, [s17, #0]
    vf.abs       v21, v4
    v.ld.w       v4, [s20, #0]
    vf.abs       v22, v19
    vf.max.ieee  v19, v21, v22
    v.ld.w       v21, [s30, #0]
    vf.abs       v22, v4
    vf.max.ieee  v4, v19, v22
    v.ld.w       v19, [s31, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v2, v22
    v.ld.w       v2, [s16, #0]
    vf.abs       v22, v19
    vf.max.ieee  v19, v21, v22
    v.ld.w       v21, [s35, #0]
    vf.abs       v22, v2
    vf.max.ieee  v2, v19, v22
    v.ld.w       v19, [s25, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v12, v22
    vf.reduce.max.b v12, v21
    s.addi       s16, s28, #8448
    s.addi       s17, s28, #9472
    s.addi       s20, s28, #10496
    s.addi       s25, s28, #11520
    s.addi       s30, s28, #12480
    s.addi       s31, s28, #13504
    v.ld.w       v21, [s16, #0]
    s.addi       s16, s28, #14528
    vf.abs       v22, v19
    s.addi       s34, s28, #15552
    vf.max.ieee  v19, v4, v22
    v.ld.w       v4, [s17, #0]
    vf.abs       v22, v21
    v.ld.w       v21, [s20, #0]
    vf.abs       v23, v4
    vf.max.ieee  v4, v22, v23
    v.ld.w       v22, [s30, #0]
    vf.abs       v23, v21
    vf.max.ieee  v21, v4, v23
    v.ld.w       v4, [s31, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v19, v23
    v.ld.w       v19, [s16, #0]
    vf.abs       v23, v4
    vf.max.ieee  v4, v22, v23
    v.ld.w       v22, [s33, #0]
    vf.abs       v23, v19
    vf.max.ieee  v19, v4, v23
    v.ld.w       v4, [s25, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v2, v23
    vf.reduce.max.b v2, v22
    s.addi       s16, s28, #8512
    s.addi       s17, s28, #9536
    s.addi       s20, s28, #10560
    s.addi       s25, s28, #11584
    s.addi       s30, s28, #12544
    s.addi       s31, s28, #13568
    v.ld.w       v22, [s16, #0]
    s.addi       s16, s28, #14592
    vf.abs       v23, v4
    s.addi       s33, s28, #15616
    vf.max.ieee  v4, v21, v23
    v.ld.w       v21, [s17, #0]
    vf.abs       v23, v22
    v.ld.w       v22, [s20, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    v.ld.w       v23, [s30, #0]
    vf.abs       v24, v22
    vf.max.ieee  v22, v21, v24
    v.ld.w       v21, [s31, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v4, v24
    v.ld.w       v4, [s16, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    v.ld.w       v23, [s34, #0]
    vf.abs       v24, v4
    vf.max.ieee  v4, v21, v24
    v.ld.w       v21, [s25, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v19, v24
    vf.reduce.max.b v19, v23
    s.addi       s16, s28, #8576
    s.addi       s17, s28, #9600
    s.addi       s20, s28, #10624
    s.addi       s25, s28, #11648
    s.addi       s30, s28, #12608
    s.addi       s31, s28, #13632
    v.ld.w       v23, [s16, #0]
    s.addi       s16, s28, #14656
    vf.abs       v24, v21
    s.addi       s34, s28, #15680
    vf.max.ieee  v21, v22, v24
    v.ld.w       v22, [s17, #0]
    vf.abs       v24, v23
    v.ld.w       v23, [s20, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    v.ld.w       v24, [s30, #0]
    vf.abs       v25, v23
    vf.max.ieee  v23, v22, v25
    v.ld.w       v22, [s31, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v21, v25
    v.ld.w       v21, [s16, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    v.ld.w       v24, [s33, #0]
    vf.abs       v25, v21
    vf.max.ieee  v21, v22, v25
    v.ld.w       v22, [s25, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v4, v25
    vf.reduce.max.b v4, v24
    s.addi       s16, s28, #8640
    s.addi       s17, s28, #9664
    s.addi       s20, s28, #10688
    s.addi       s25, s28, #11712
    s.addi       s30, s28, #12672
    s.addi       s31, s28, #13696
    v.ld.w       v24, [s16, #0]
    s.addi       s16, s28, #14720
    vf.abs       v25, v22
    s.addi       s33, s28, #15744
    vf.max.ieee  v22, v23, v25
    v.ld.w       v23, [s17, #0]
    vf.abs       v25, v24
    v.ld.w       v24, [s20, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    v.ld.w       v25, [s30, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v23, v26
    v.ld.w       v23, [s31, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v22, v26
    v.ld.w       v22, [s16, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    v.ld.w       v25, [s34, #0]
    vf.abs       v26, v22
    vf.max.ieee  v22, v23, v26
    v.ld.w       v23, [s25, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v21, v26
    vf.reduce.max.b v21, v25
    s.addi       s16, s28, #8704
    s.addi       s17, s28, #9728
    s.addi       s20, s28, #10752
    s.addi       s25, s28, #11776
    s.addi       s30, s28, #12736
    s.addi       s31, s28, #13760
    v.ld.w       v25, [s16, #0]
    s.addi       s16, s28, #14784
    vf.abs       v26, v23
    s.addi       s34, s28, #15808
    vf.max.ieee  v23, v24, v26
    v.ld.w       v24, [s17, #0]
    vf.abs       v26, v25
    v.ld.w       v25, [s20, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    v.ld.w       v26, [s30, #0]
    vf.abs       v27, v25
    vf.max.ieee  v25, v24, v27
    v.ld.w       v24, [s31, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v23, v27
    v.ld.w       v23, [s16, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    v.ld.w       v26, [s33, #0]
    vf.abs       v27, v23
    vf.max.ieee  v23, v24, v27
    v.ld.w       v24, [s25, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v22, v27
    vf.reduce.max.b v22, v26
    s.addi       s16, s28, #8768
    s.addi       s17, s28, #9792
    s.addi       s20, s28, #10816
    s.addi       s25, s28, #11840
    s.addi       s30, s28, #12800
    s.addi       s31, s28, #13824
    v.ld.w       v26, [s16, #0]
    s.addi       s16, s28, #14848
    vf.abs       v27, v24
    s.addi       s33, s28, #15872
    vf.max.ieee  v24, v25, v27
    v.ld.w       v25, [s17, #0]
    vf.abs       v27, v26
    v.ld.w       v26, [s20, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    v.ld.w       v27, [s30, #0]
    vf.abs       v28, v26
    vf.max.ieee  v26, v25, v28
    v.ld.w       v25, [s31, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v24, v28
    v.ld.w       v24, [s16, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    v.ld.w       v27, [s34, #0]
    vf.abs       v28, v24
    vf.max.ieee  v24, v25, v28
    v.ld.w       v25, [s25, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v23, v28
    vf.reduce.max.b v23, v27
    s.addi       s16, s28, #8832
    s.addi       s17, s28, #9856
    s.addi       s20, s28, #10880
    s.addi       s25, s28, #11904
    s.addi       s30, s28, #12864
    s.addi       s31, s28, #13888
    v.ld.w       v27, [s16, #0]
    s.addi       s16, s28, #14912
    vf.abs       v28, v25
    s.addi       s34, s28, #15936
    vf.max.ieee  v25, v26, v28
    v.ld.w       v26, [s17, #0]
    vf.abs       v28, v27
    v.ld.w       v27, [s20, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    v.ld.w       v28, [s30, #0]
    vf.abs       v29, v27
    vf.max.ieee  v27, v26, v29
    v.ld.w       v26, [s31, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v25, v29
    v.ld.w       v25, [s16, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    v.ld.w       v28, [s33, #0]
    vf.abs       v29, v25
    vf.max.ieee  v25, v26, v29
    v.ld.w       v26, [s25, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v24, v29
    vf.reduce.max.b v24, v28
    s.addi       s16, s28, #8896
    s.addi       s17, s28, #9920
    s.addi       s20, s28, #10944
    s.addi       s25, s28, #11968
    s.addi       s30, s28, #12928
    s.addi       s31, s28, #13952
    v.ld.w       v28, [s16, #0]
    s.addi       s16, s28, #14976
    vf.abs       v29, v26
    s.addi       s33, s28, #16000
    vf.max.ieee  v26, v27, v29
    v.ld.w       v27, [s17, #0]
    vf.abs       v29, v28
    v.ld.w       v28, [s20, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    v.ld.w       v29, [s30, #0]
    vf.abs       v30, v28
    vf.max.ieee  v28, v27, v30
    v.ld.w       v27, [s31, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v26, v30
    v.ld.w       v26, [s16, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    v.ld.w       v29, [s34, #0]
    vf.abs       v30, v26
    vf.max.ieee  v26, v27, v30
    v.ld.w       v27, [s25, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v25, v30
    vf.reduce.max.b v25, v29
    s.addi       s16, s28, #8960
    s.addi       s17, s28, #9984
    s.addi       s20, s28, #11008
    s.addi       s25, s28, #12032
    s.addi       s30, s28, #12992
    s.addi       s31, s28, #14016
    v.ld.w       v29, [s16, #0]
    s.addi       s16, s28, #15040
    vf.abs       v30, v27
    s.addi       s34, s28, #16064
    vf.max.ieee  v27, v28, v30
    v.ld.w       v28, [s17, #0]
    vf.abs       v30, v29
    v.ld.w       v29, [s20, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    v.ld.w       v30, [s30, #0]
    vf.abs       v31, v29
    vf.max.ieee  v29, v28, v31
    v.ld.w       v28, [s31, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v27, v31
    v.ld.w       v27, [s16, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    v.ld.w       v30, [s33, #0]
    vf.abs       v31, v27
    vf.max.ieee  v27, v28, v31
    v.ld.w       v28, [s25, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v26, v31
    vf.reduce.max.b v26, v30
    s.addi       s16, s28, #9024
    s.addi       s17, s28, #10048
    s.addi       s20, s28, #11072
    s.addi       s25, s28, #12096
    s.addi       s30, s28, #13056
    s.addi       s31, s28, #14080
    v.ld.w       v30, [s16, #0]
    s.addi       s16, s28, #15104
    s.addi       s33, s28, #16128
    vf.abs       v31, v28
    vf.max.ieee  v28, v29, v31
    v.ld.w       v29, [s17, #0]
    vf.abs       v31, v30
    v.ld.w       v30, [s20, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    v.ld.w       v31, [s30, #0]
    vf.abs       v32, v30
    vf.max.ieee  v30, v29, v32
    v.ld.w       v29, [s31, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v28, v32
    v.ld.w       v28, [s16, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    v.ld.w       v31, [s34, #0]
    vf.abs       v32, v28
    vf.max.ieee  v28, v29, v32
    v.ld.w       v29, [s25, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v27, v32
    vf.reduce.max.b v27, v31
    s.addi       s16, s28, #9088
    s.addi       s17, s28, #10112
    s.addi       s20, s28, #11136
    s.addi       s25, s28, #12160
    s.addi       s30, s28, #13120
    s.addi       s31, s28, #14144
    v.ld.w       v31, [s16, #0]
    s.addi       s16, s28, #15168
    s.addi       s34, s28, #16192
    vf.abs       v32, v29
    vf.max.ieee  v29, v30, v32
    v.ld.w       v30, [s17, #0]
    vf.abs       v32, v31
    v.ld.w       v31, [s20, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v32, v33
    v.ld.w       v32, [s30, #0]
    vf.abs       v33, v31
    vf.max.ieee  v31, v30, v33
    v.ld.w       v30, [s31, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v29, v33
    v.ld.w       v29, [s33, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v32, v33
    v.ld.w       v32, [s25, #0]
    vf.abs       v33, v29
    vf.max.ieee  v29, v28, v33
    vf.reduce.max.b v28, v29
    s.addi       s17, s28, #9152
    s.addi       s20, s28, #10176
    s.addi       s25, s28, #11200
    s.addi       s30, s28, #13184
    s.addi       s31, s28, #14208
    s.addi       s33, s28, #15232
    v.ld.w       v29, [s17, #0]
    s.addi       s17, s28, #16256
    vf.abs       v33, v32
    vf.max.ieee  v32, v31, v33
    v.ld.w       v31, [s20, #0]
    vf.abs       v33, v29
    v.ld.w       v29, [s30, #0]
    vf.abs       v34, v31
    vf.max.ieee  v31, v33, v34
    v.ld.w       v33, [s31, #0]
    vf.abs       v34, v29
    vf.max.ieee  v29, v32, v34
    v.ld.w       v32, [s16, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v29, v34
    v.ld.w       v29, [s25, #0]
    vf.abs       v34, v32
    vf.max.ieee  v32, v30, v34
    s.addi       s16, s28, #12224
    v.ld.w       v30, [s34, #0]
    vf.abs       v34, v29
    vf.max.ieee  v29, v31, v34
    v.ld.w       v31, [s16, #0]
    vf.abs       v34, v30
    vf.max.ieee  v30, v32, v34
    vf.reduce.max.b v32, v30
    s.addi       s16, s28, #13248
    v.movi       v30, #0
    s.addi       s20, s28, #14272
    s.addi       s25, s28, #15296
    s.addi       s30, s28, #16320
    // one value per row into one vector (ISA 0x09)
    v.extract    s31, v20, #0
    v.ld.w       v20, [s16, #0]
    v.extract    s16, v12, #0
    v.extract    s34, v2, #0
    v.extract    s35, v19, #0
    vf.abs       v2, v31
    vf.max.ieee  v12, v29, v2
    v.ld.w       v2, [s33, #0]
    vf.abs       v19, v20
    vf.max.ieee  v20, v12, v19
    v.ld.w       v12, [s17, #0]
    vf.abs       v19, v2
    v.extract    s17, v4, #0
    vf.max.ieee  v2, v33, v19
    v.extract    s33, v21, #0
    v.ld.w       v4, [s20, #0]
    vf.abs       v19, v12
    v.extract    s20, v22, #0
    vf.max.ieee  v12, v2, v19
    vf.reduce.max.b v2, v12
    .li       s36, #1138753536
    v.splat      v12, s36                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s36, v23, #0
    .li       s37, #1065353216
    v.splat      v19, s37                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v21, v12                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v22, [s25, #0]
    vf.abs       v23, v4
    v.extract    s25, v24, #0
    vf.max.ieee  v4, v20, v23
    v.ld.w       v20, [s30, #0]
    v.insert     v30, s31, #0
    vf.abs       v23, v22
    v.extract    s30, v25, #0
    v.insert     v30, s16, #1
    v.extract    s16, v26, #0
    v.extract    s31, v27, #0
    v.insert     v30, s34, #2
    vf.max.ieee  v22, v4, v23
    vf.fms       v4, v12, v21, v19
    v.insert     v30, s35, #3
    v.extract    s34, v28, #0
    v.extract    s35, v32, #0
    v.insert     v30, s17, #4
    vf.fms       v23, v21, v4, v21
    v.extract    s17, v2, #0
    v.insert     v30, s33, #5
    vf.abs       v2, v20
    v.insert     v30, s20, #6
    vf.neg       v4, v23                         // Newton step: r0*(2 - x*r0)
    v.insert     v30, s36, #7
    vf.max.ieee  v20, v22, v2
    v.insert     v30, s25, #8
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v2, v4, v21
    v.insert     v30, s30, #9
    vf.reduce.max.b v4, v20
    v.iota       v20                             // arange(0, VLEN)
    v.insert     v30, s16, #10
    s.movz       s16, #0
    s.add        s20, s2, s26
    v.insert     v30, s31, #11
    v.extract    s25, v14, #0
    s.cmp.ge     s26, s20, s16
    v.splat      v21, s25
    v.insert     v30, s34, #12
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    v.movi       v22, #0
    v.add        v23, v21, v20
    v.insert     v30, s35, #13
    v.extract    s30, v4, #0
    v.sub        v4, v14, v23
    v.insert     v30, s17, #14
    s.cmp.ge     s17, s25, s16
    v.reduce.or  s31, v4
    v.insert     v30, s30, #15
    v.extract    s30, v13, #0
    s.cmp.eq     s33, s31, s16
    v.splat      v4, s30
    s.and        s31, s33, s17
    v.ld.gather.w v21, [s27, v0]                 // index is in elements (ISA sec 9.1)
    v.add        v23, v4, v20
    s.and        s17, s31, s26
    v.movi       v4, #0
    v.sub        v24, v13, v23
    vf.mul       v23, v30, v2                    // a/y: faithful quotient
    s.cmp.ge     s31, s30, s16
    v.reduce.or  s33, v24
    v.splat      v24, s22
    s.cmp.eq     s34, s33, s16
    vf.fms       v25, v23, v12, v30
    s.and        s33, s34, s31
    v.splat      v12, s22
    .li       s31, #730643660
    v.splat      v26, s31                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v27, v14, v24
    vf.fms       v28, v25, v2, v23
    s.and        s31, s33, s26
    v.mul        v2, v13, v24
    v.ld.gather.w v25, [s27, v1]                 // index is in elements (ISA sec 9.1)
    v.mul        v29, v11, v24
    vf.neg       v30, v28                        // a/y: one correction to the IEEE quotient
    v.mul        v28, v10, v24
    v.mul        v31, v9, v24
    v.mul        v24, v8, v12
    v.mul        v32, v7, v12
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v33, v30, v23
    v.extract    s33, v11, #0
    v.mul        v23, v3, v12
    v.splat      v12, s33
    v.extract    s34, v10, #0
    s.cmp.ge     s35, s33, s16
    v.add        v30, v12, v20
    v.splat      v12, s34
    v.sub        v34, v11, v30
    v.add        v30, v12, v20
    v.ld.gather.w v12, [s27, v5]                 // index is in elements (ISA sec 9.1)
    v.reduce.or  s36, v34
    v.sub        v34, v10, v30
    s.cmp.eq     s37, s36, s16
    s.and        s36, s37, s35
    s.and        s35, s36, s26
    v.ld.gather.w v30, [s27, v6]                 // index is in elements (ISA sec 9.1)
    v.reduce.or  s36, v34
    v.ld.gather.w v34, [s27, v16]                // index is in elements (ISA sec 9.1)
    s.cmp.eq     s37, s36, s16
    v.ld.gather.w v35, [s27, v15]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v36, [s27, v17]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v37, [s27, v18]                // index is in elements (ISA sec 9.1)
    v.insert     v22, s17, #0
    v.extract    s17, v9, #0
    v.insert     v4, s25, #0
    v.splat      v38, s17
    v.extract    s25, v8, #0
    v.insert     v22, s31, #1
    v.add        v39, v38, v20
    v.splat      v38, s25
    v.extract    s31, v7, #0
    v.sub        v40, v9, v39
    v.add        v39, v38, v20
    v.splat      v38, s31
    v.insert     v4, s30, #1
    v.extract    s30, v3, #0
    v.sub        v41, v8, v39
    v.add        v39, v38, v20
    v.insert     v22, s35, #2
    s.cmp.ge     s35, s34, s16
    v.splat      v38, s30
    s.and        s36, s37, s35
    v.reduce.or  s35, v40
    s.and        s37, s36, s26
    s.cmp.eq     s36, s35, s16
    s.cmp.ge     s35, s17, s16
    v.sub        v40, v7, v39
    s.and        s16, s36, s35
    v.reduce.or  s35, v41
    v.insert     v4, s33, #2
    s.movz       s33, #0
    v.add        v39, v38, v20
    v.insert     v22, s37, #3
    s.cmp.eq     s36, s35, s33
    s.cmp.ge     s35, s25, s33
    s.and        s37, s16, s26
    v.sub        v20, v3, v39
    s.and        s16, s36, s35
    v.reduce.or  s35, v40
    v.insert     v4, s34, #3
    v.insert     v22, s37, #4
    s.cmp.eq     s34, s35, s33
    s.cmp.ge     s35, s31, s33
    s.and        s36, s16, s26
    v.reduce.or  s16, v20
    s.and        s37, s34, s35
    v.insert     v4, s17, #4
    v.insert     v22, s36, #5
    s.cmp.eq     s17, s16, s33
    s.cmp.ge     s16, s30, s33
    s.and        s33, s37, s26
    s.and        s34, s17, s16
    v.insert     v4, s25, #5
    v.insert     v22, s33, #6
    s.and        s16, s34, s26
    v.insert     v4, s31, #6
    v.insert     v22, s16, #7
    s.add        s16, s13, s24
    s.addi       s17, s28, #16384                // TensorMap 0: W's rows for a transposed FP8 B
    .li       s25, #2147483647
    s.movz       s26, #1
    .li       s31, #137438953488
    .li       s33, #7705171329024
    s.addi       s34, s28, #16640
    s.addi       s35, s28, #17152                // TensorMap 1: the gathered fallback B tile
    s.movz       s36, #32
    v.insert     v4, s30, #7
    s.movz       s30, #16
    s.st.d       [s17, #0], s16
    .li       s16, #68719476768
    s.st.d       [s17, #8], s25
    v.extract    s25, v22, #0
    s.st.d       [s17, #16], s20
    s.st.d       [s17, #48], s22
    s.st.d       [s17, #56], s26
    s.st.d       [s17, #88], s31
    s.st.d       [s17, #104], s33
    fence.release.device
    td.load      d0, [s17]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.st.d       [s35, #0], s34
    s.st.d       [s35, #8], s36
    s.st.d       [s35, #16], s30
    s.st.d       [s35, #48], s30
    s.st.d       [s35, #56], s26
    s.st.d       [s35, #88], s16
    s.st.d       [s35, #104], s33
    fence.release.device
    td.load      d1, [s35]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a0
    m.zero       a1
    m.zero       a2
    m.zero       a3
    m.zero       a4
    m.zero       a5
    m.zero       a6
    m.zero       a7
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s25, x8dot_done_27
    s.movz       s16, #0
    s.add        s17, s13, s24
    s.addi       s26, s16, #0
x8dot_row_28:
    s.addi       s16, s20, #0
    v.movi       v20, #0
    s.sub        s30, s16, s26
    s.add        s16, s17, s26
    v.splat      v38, s30
    s.shli       s30, s26, #4
    s.addi       s31, s26, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s16, v27]            // index is in elements (ISA sec 9.1)
    s.add        s16, s34, s30
    v.st.b       [s16, #0], v20
    fence.acq_rel.device
    s.mov        s26, s31
    s.cmp.lt     s16, s26, s36
    br.nz        s16, x8dot_row_28
x8dot_done_27:
    v.extract    s16, v33, #0
    v.splat      v20, s25
    v.splat      v38, s16
    v.movi       v39, #0
    mb.arm       s16, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v40, v38, v26
    s.movz       s17, #0
    v.extract    s25, v4, #0
    s.addi       s26, s28, #8192
    v.cmp.ne     p1, v20, v39
    v.rcp.approx v38, v40                        // ISA 8.8: <= 2**-22 relative
    v.cmp.eq     p2, v20, v39
    s.mov        s30, s17                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s17                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s30, s16            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s30, s25                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s17                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s30, s16          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v20, [s26, #0]
    v.extract    s17, v33, #1
    v.movi       v39, #24
    v.splat      v41, s17
    v.movi       v42, #128
    s.addi       s17, s28, #17408                // 512 bytes of repack scratch
    vf.max.ieee  v43, v41, v26
    s.addi       s25, s17, #0
    s.addi       s26, s28, #8256
    v.extract    s30, v33, #2
    s.addi       s31, s17, #32
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    v.splat      v44, s30
    s.addi       s30, s28, #8320
    vf.max.ieee  v45, v44, v26
    v.rcp.approx v44, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v46, v40, v38, v19
    vf.fms       v47, v38, v46, v38
    vf.neg       v46, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v46, v46
    @p1 v.sel        v47, v46, v38
    vf.fms       v38, v43, v41, v19
    vf.fms       v46, v41, v38, v41
    vf.neg       v38, v46                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v46, v38, v41
    vf.mul       v38, v20, v47                   // a/y: faithful quotient
    vf.fms       v41, v38, v40, v20
    vf.fms       v20, v45, v44, v19
    vf.fms       v40, v41, v47, v38
    vf.fms       v41, v44, v20, v44
    vf.neg       v20, v40                        // a/y: one correction to the IEEE quotient
    vf.neg       v40, v41                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v41, v20, v38
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v20, v40, v44
    v.lshr       v38, v41, v39
    vf.cvt.f32.e4m3 v40, v41
    v.and        v41, v38, v42
    s.addi       s33, s17, #64
    v.or         v38, v40, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s25, #0], v38
    v.extract    s25, v33, #3
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s25
    s.addi       s25, s28, #8384
    vf.max.ieee  v41, v40, v26
    v.rcp.approx v40, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v38, v46                   // a/y: faithful quotient
    vf.fms       v47, v44, v43, v38
    vf.fms       v38, v47, v46, v44
    vf.neg       v43, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v41, v40, v19
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v46, v43, v44
    v.lshr       v43, v46, v39
    vf.cvt.f32.e4m3 v44, v46
    vf.fms       v46, v40, v38, v40
    v.and        v38, v43, v42
    s.addi       s26, s17, #96
    v.or         v43, v44, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v46                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s31, #0], v43
    v.extract    s31, v33, #4
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v43, v38, v40
    v.ld.w       v38, [s30, #0]
    v.splat      v40, s31
    s.addi       s30, s28, #8448
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s31, s17, #128
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s33, #0], v20
    v.extract    s33, v33, #5
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s33
    s.addi       s25, s28, #8512
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v41, v38
    vf.fms       v38, v47, v43, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s33, s17, #160
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s26, #0], v41
    v.extract    s26, v33, #6
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s30, #0]
    v.splat      v40, s26
    s.addi       s26, s28, #8576
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s30, s17, #192
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s31, #0], v20
    v.extract    s31, v33, #7
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s31
    s.addi       s25, s28, #8640
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s31, s17, #224
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s33, #0], v41
    v.extract    s33, v33, #8
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s33
    s.addi       s26, s28, #8704
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v46
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s33, s17, #256
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s30, #0], v20
    v.extract    s30, v33, #9
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s30
    s.addi       s25, s28, #8768
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v44, v41, v46
    v.lshr       v41, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s30, s17, #288
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s31, #0], v41
    v.extract    s31, v33, #10
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s31
    s.addi       s26, s28, #8832
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s31, s17, #320
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s33, #0], v20
    v.extract    s33, v33, #11
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s33
    s.addi       s25, s28, #8896
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s33, s17, #352
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s30, #0], v41
    v.extract    s30, v33, #12
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s30
    s.addi       s26, s28, #8960
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s30, s17, #384
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s31, #0], v20
    v.extract    s31, v33, #13
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s31
    s.addi       s25, s28, #9024
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s31, s17, #416
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s33, #0], v41
    v.extract    s33, v33, #14
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s33
    s.addi       s26, s28, #9088
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v46
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s33, s17, #448
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s30, #0], v20
    v.extract    s30, v33, #15
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s30
    s.addi       s25, s28, #9152
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v44, v41, v46
    v.lshr       v41, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s30, s17, #480
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s31, #0], v41
    v.extract    s31, v33, #0
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s31
    s.addi       s26, s28, #9216
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s31, s17, #16
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s33, #0], v20
    v.extract    s33, v33, #1
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s33
    s.addi       s25, s28, #9280
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s33, s17, #48
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s30, #0], v41
    v.extract    s30, v33, #2
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s30
    s.addi       s26, s28, #9344
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s30, s17, #80
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s31, #0], v20
    v.extract    s31, v33, #3
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s31
    s.addi       s25, s28, #9408
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s31, s17, #112
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s33, #0], v41
    v.extract    s33, v33, #4
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s33
    s.addi       s26, s28, #9472
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v46
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s33, s17, #144
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s30, #0], v20
    v.extract    s30, v33, #5
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s30
    s.addi       s25, s28, #9536
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v44, v41, v46
    v.lshr       v41, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s30, s17, #176
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s31, #0], v41
    v.extract    s31, v33, #6
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s31
    s.addi       s26, s28, #9600
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s31, s17, #208
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s33, #0], v20
    v.extract    s33, v33, #7
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s33
    s.addi       s25, s28, #9664
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s33, s17, #240
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s30, #0], v41
    v.extract    s30, v33, #8
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s30
    s.addi       s26, s28, #9728
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s30, s17, #272
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s31, #0], v20
    v.extract    s31, v33, #9
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s31
    s.addi       s25, s28, #9792
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s31, s17, #304
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s33, #0], v41
    v.extract    s33, v33, #10
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s33
    s.addi       s26, s28, #9856
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v46
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s33, s17, #336
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s30, #0], v20
    v.extract    s30, v33, #11
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s30
    s.addi       s25, s28, #9920
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v44, v41, v46
    v.lshr       v41, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s30, s17, #368
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s31, #0], v41
    v.extract    s31, v33, #12
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s31
    s.addi       s26, s28, #9984
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s31, s17, #400
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s33, #0], v20
    v.extract    s33, v33, #13
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s33
    s.addi       s25, s28, #10048
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s33, s17, #432
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s30, #0], v41
    v.extract    s30, v33, #14
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s30
    s.addi       s26, s28, #10112
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s30, s17, #464
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s31, #0], v20
    v.extract    s31, v33, #15
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s25, #0]
    v.splat      v40, s31
    s.addi       s25, s28, #10176
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s31, s17, #496
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s33, #0], v41
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s26, #0]
    s.addi       s26, s17, #64
    s.addi       s33, s17, #128
    vf.mul       v40, v38, v20                   // a/y: faithful quotient
    vf.fms       v45, v40, v43, v38
    vf.fms       v38, v45, v20, v40
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v38, v20, v40
    v.lshr       v20, v38, v39
    vf.cvt.f32.e4m3 v40, v38
    v.and        v38, v20, v42
    v.or         v20, v40, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s30, #0], v20
    s.addi       s30, s17, #192
    v.ld.w       v20, [s25, #0]
    s.addi       s25, s17, #256
    vf.mul       v38, v20, v41                   // a/y: faithful quotient
    vf.fms       v40, v38, v44, v20
    vf.fms       v20, v40, v41, v38
    vf.neg       v40, v20                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v20, v40, v38
    v.lshr       v38, v20, v39
    vf.cvt.f32.e4m3 v40, v20
    v.and        v20, v38, v42
    v.or         v38, v40, v20                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v38
    fence.acq_rel.device
    w.def        w1, #56, #8                     // v56..v63
    s.addi       s31, s17, #320
    v.ld.w       v20, [s17, #0]
    v.mov        v56, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s26, #0]
    s.addi       s26, s17, #384
    s.addi       s34, s17, #448
    v.mov        v57, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s33, #0]
    v.extract    s17, v22, #1
    v.mov        v58, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s30, #0]
    v.mov        v59, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s25, #0]
    v.mov        v60, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s31, #0]
    v.mov        v61, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s26, #0]
    v.mov        v62, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s34, #0]
    v.mov        v63, v20                        // hand off through the shared window (sec 7.3)
    mb.wait      s16
    mb.arm       s25, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v56, v48, s25
    mb.wait      s25
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s17, x8dot_done_29
    s.movz       s26, #0
    s.add        s30, s13, s24
    s.addi       s31, s26, #0
    s.addi       s26, s28, #16640
x8dot_row_30:
    s.addi       s33, s20, #0
    v.movi       v20, #0
    s.sub        s34, s33, s31
    s.add        s33, s30, s31
    v.splat      v38, s34
    s.shli       s34, s31, #4
    s.addi       s35, s31, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s33, v2]             // index is in elements (ISA sec 9.1)
    s.add        s33, s26, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v20
    fence.acq_rel.device
    s.mov        s31, s35
    s.cmp.lt     s33, s31, s34
    br.nz        s33, x8dot_row_30
x8dot_done_29:
    v.splat      v20, s17
    v.movi       v38, #0
    mb.arm       s17, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s26, #0
    v.extract    s30, v4, #1
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s33, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s33, s17            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s33, s17          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s17
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v22, #2
    m.mma.dp.async.k32.e4m3 a1, v56, v48, s30
    mb.wait      s30
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s31, x8dot_done_31
    s.addi       s33, s26, #0
    s.add        s34, s13, s24
    s.addi       s35, s28, #16640
x8dot_row_32:
    s.addi       s36, s20, #0
    v.movi       v20, #0
    s.sub        s37, s36, s33
    s.add        s36, s34, s33
    v.splat      v38, s37
    s.shli       s37, s33, #4
    s.addi       s38, s33, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s36, v29]            // index is in elements (ISA sec 9.1)
    s.add        s36, s35, s37
    s.movz       s37, #32
    v.st.b       [s36, #0], v20
    fence.acq_rel.device
    s.mov        s33, s38
    s.cmp.lt     s36, s33, s37
    br.nz        s36, x8dot_row_32
x8dot_done_31:
    v.splat      v20, s31
    v.movi       v38, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s33, v4, #2
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s34, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s34, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s34, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v22, #3
    m.mma.dp.async.k32.e4m3 a2, v56, v48, s33
    mb.wait      s33
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s34, x8dot_done_33
    s.addi       s35, s26, #0
    s.add        s26, s13, s24
    s.addi       s36, s28, #16640
x8dot_row_34:
    s.addi       s37, s20, #0
    v.movi       v20, #0
    s.sub        s38, s37, s35
    s.add        s37, s26, s35
    v.splat      v38, s38
    s.shli       s38, s35, #4
    s.addi       s39, s35, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s37, v28]            // index is in elements (ISA sec 9.1)
    s.add        s37, s36, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v20
    fence.acq_rel.device
    s.mov        s35, s39
    s.cmp.lt     s37, s35, s38
    br.nz        s37, x8dot_row_34
x8dot_done_33:
    v.splat      v20, s34
    v.movi       v38, #0
    mb.arm       s26, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.extract    s35, v4, #3
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s36, s26            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s36, s26          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s26
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v22, #4
    m.mma.dp.async.k32.e4m3 a3, v56, v48, s35
    mb.wait      s35
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s36, x8dot_done_35
    s.addi       s37, s34, #0
    s.add        s38, s13, s24
    s.addi       s39, s28, #16640
x8dot_row_36:
    s.addi       s40, s20, #0
    v.movi       v20, #0
    s.sub        s41, s40, s37
    s.add        s40, s38, s37
    v.splat      v38, s41
    s.shli       s41, s37, #4
    s.addi       s42, s37, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s40, v31]            // index is in elements (ISA sec 9.1)
    s.add        s40, s39, s41
    s.movz       s41, #32
    v.st.b       [s40, #0], v20
    fence.acq_rel.device
    s.mov        s37, s42
    s.cmp.lt     s40, s37, s41
    br.nz        s40, x8dot_row_36
x8dot_done_35:
    v.splat      v20, s36
    v.movi       v38, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s37, v4, #4
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v22, #5
    m.mma.dp.async.k32.e4m3 a4, v56, v48, s37
    mb.wait      s37
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s38, x8dot_done_37
    s.addi       s39, s34, #0
    s.add        s34, s13, s24
    s.addi       s40, s28, #16640
x8dot_row_38:
    s.addi       s41, s20, #0
    v.movi       v20, #0
    s.sub        s42, s41, s39
    s.add        s41, s34, s39
    v.splat      v38, s42
    s.shli       s42, s39, #4
    s.addi       s43, s39, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s41, v24]            // index is in elements (ISA sec 9.1)
    s.add        s41, s40, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v20
    fence.acq_rel.device
    s.mov        s39, s43
    s.cmp.lt     s41, s39, s42
    br.nz        s41, x8dot_row_38
x8dot_done_37:
    v.splat      v20, s38
    v.movi       v38, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s39, v4, #5
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s40, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s40, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v22, #6
    m.mma.dp.async.k32.e4m3 a5, v56, v48, s39
    mb.wait      s39
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s40, x8dot_done_39
    s.addi       s41, s38, #0
    s.add        s42, s13, s24
    s.addi       s43, s28, #16640
x8dot_row_40:
    s.addi       s44, s20, #0
    v.movi       v20, #0
    s.sub        s45, s44, s41
    s.add        s44, s42, s41
    v.splat      v38, s45
    s.shli       s45, s41, #4
    s.addi       s46, s41, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s44, v32]            // index is in elements (ISA sec 9.1)
    s.add        s44, s43, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v20
    fence.acq_rel.device
    s.mov        s41, s46
    s.cmp.lt     s44, s41, s45
    br.nz        s44, x8dot_row_40
x8dot_done_39:
    v.splat      v20, s40
    v.movi       v38, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s41, v4, #6
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s42, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s42, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v22, #7
    m.mma.dp.async.k32.e4m3 a6, v56, v48, s41
    mb.wait      s41
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s42, x8dot_done_41
    s.addi       s43, s38, #0
    s.add        s38, s13, s24
    s.addi       s44, s28, #16640
x8dot_row_42:
    s.addi       s45, s20, #0
    v.movi       v20, #0
    s.sub        s46, s45, s43
    s.add        s45, s38, s43
    v.splat      v38, s46
    s.shli       s46, s43, #4
    s.addi       s47, s43, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s45, v23]            // index is in elements (ISA sec 9.1)
    s.add        s45, s44, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v20
    fence.acq_rel.device
    s.mov        s43, s47
    s.cmp.lt     s45, s43, s46
    br.nz        s45, x8dot_row_42
x8dot_done_41:
    v.splat      v20, s42
    v.movi       v38, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.extract    s43, v4, #7
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s44, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s44, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v22, #0
    m.mma.dp.async.k32.e4m3 a7, v56, v48, s43
    mb.wait      s43
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s44, x8dot_done_43
    s.add        s45, s13, s24
    s.addi       s46, s42, #0
    s.addi       s47, s45, #32
    s.addi       s45, s28, #16640
x8dot_row_44:
    s.addi       s48, s20, #-32
    v.movi       v20, #0
    s.sub        s49, s48, s46
    s.add        s48, s47, s46
    v.splat      v38, s49
    s.shli       s49, s46, #4
    s.addi       s50, s46, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s48, v27]            // index is in elements (ISA sec 9.1)
    s.add        s48, s45, s49
    s.movz       s49, #32
    v.st.b       [s48, #0], v20
    fence.acq_rel.device
    s.mov        s46, s50
    s.cmp.lt     s48, s46, s49
    br.nz        s48, x8dot_row_44
x8dot_done_43:
    v.extract    s45, v33, #0
    v.splat      v20, s44
    v.splat      v38, s45
    v.movi       v40, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v41, v38, v26
    v.extract    s45, v4, #0
    s.movz       s46, #32
    s.addi       s47, s28, #10240
    v.cmp.ne     p1, v20, v40
    v.rcp.approx v38, v41                        // ISA 8.8: <= 2**-22 relative
    v.cmp.eq     p2, v20, v40
    s.mov        s48, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s48, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s48, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s48, s44          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v20, [s47, #0]
    v.extract    s42, v33, #1
    s.addi       s45, s28, #17920                // 512 bytes of repack scratch
    v.splat      v40, s42
    s.addi       s42, s45, #0
    s.addi       s46, s28, #10304
    vf.max.ieee  v43, v40, v26
    v.extract    s47, v33, #2
    s.addi       s48, s45, #32
    v.splat      v40, s47
    s.addi       s47, s28, #10368
    v.rcp.approx v44, v43                        // ISA 8.8: <= 2**-22 relative
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v46, v41, v38, v19
    vf.fms       v47, v38, v46, v38
    vf.neg       v46, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v46, v46
    @p1 v.sel        v47, v46, v38
    vf.fms       v38, v43, v44, v19
    vf.fms       v46, v44, v38, v44
    vf.neg       v38, v46                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v46, v38, v44
    vf.mul       v38, v20, v47                   // a/y: faithful quotient
    vf.fms       v44, v38, v41, v20
    vf.fms       v20, v45, v40, v19
    vf.fms       v41, v44, v47, v38
    vf.fms       v44, v40, v20, v40
    vf.neg       v20, v41                        // a/y: one correction to the IEEE quotient
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v38
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v20, v41, v40
    v.lshr       v38, v44, v39
    vf.cvt.f32.e4m3 v40, v44
    v.and        v41, v38, v42
    s.addi       s49, s45, #64
    v.or         v38, v40, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v38
    v.extract    s42, v33, #3
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s42
    s.addi       s42, s28, #10432
    vf.max.ieee  v41, v40, v26
    v.rcp.approx v40, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v38, v46                   // a/y: faithful quotient
    vf.fms       v47, v44, v43, v38
    vf.fms       v38, v47, v46, v44
    vf.neg       v43, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v41, v40, v19
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v46, v43, v44
    v.lshr       v43, v46, v39
    vf.cvt.f32.e4m3 v44, v46
    vf.fms       v46, v40, v38, v40
    v.and        v38, v43, v42
    s.addi       s46, s45, #96
    v.or         v43, v44, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v46                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v43
    v.extract    s48, v33, #4
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v43, v38, v40
    v.ld.w       v38, [s47, #0]
    v.splat      v40, s48
    s.addi       s47, s28, #10496
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s48, s45, #128
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s49, #0], v20
    v.extract    s49, v33, #5
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s49
    s.addi       s42, s28, #10560
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v41, v38
    vf.fms       v38, v47, v43, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s49, s45, #160
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v41
    v.extract    s46, v33, #6
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s47, #0]
    v.splat      v40, s46
    s.addi       s46, s28, #10624
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s47, s45, #192
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v20
    v.extract    s48, v33, #7
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s48
    s.addi       s42, s28, #10688
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s48, s45, #224
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s49, #0], v41
    v.extract    s49, v33, #8
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s49
    s.addi       s46, s28, #10752
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v46
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s49, s45, #256
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v20
    v.extract    s47, v33, #9
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s47
    s.addi       s42, s28, #10816
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v44, v41, v46
    v.lshr       v41, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s47, s45, #288
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v41
    v.extract    s48, v33, #10
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s48
    s.addi       s46, s28, #10880
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s48, s45, #320
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s49, #0], v20
    v.extract    s49, v33, #11
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s49
    s.addi       s42, s28, #10944
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s49, s45, #352
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v41
    v.extract    s47, v33, #12
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s47
    s.addi       s46, s28, #11008
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s47, s45, #384
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v20
    v.extract    s48, v33, #13
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s48
    s.addi       s42, s28, #11072
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s48, s45, #416
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s49, #0], v41
    v.extract    s49, v33, #14
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s49
    s.addi       s46, s28, #11136
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v46
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s49, s45, #448
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v20
    v.extract    s47, v33, #15
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s47
    s.addi       s42, s28, #11200
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v44, v41, v46
    v.lshr       v41, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s47, s45, #480
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v41
    v.extract    s48, v33, #0
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s48
    s.addi       s46, s28, #11264
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s48, s45, #16
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s49, #0], v20
    v.extract    s49, v33, #1
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s49
    s.addi       s42, s28, #11328
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s49, s45, #48
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v41
    v.extract    s47, v33, #2
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s47
    s.addi       s46, s28, #11392
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s47, s45, #80
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v20
    v.extract    s48, v33, #3
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s48
    s.addi       s42, s28, #11456
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s48, s45, #112
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s49, #0], v41
    v.extract    s49, v33, #4
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s49
    s.addi       s46, s28, #11520
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v46
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s49, s45, #144
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v20
    v.extract    s47, v33, #5
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s47
    s.addi       s42, s28, #11584
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v44, v41, v46
    v.lshr       v41, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s47, s45, #176
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v41
    v.extract    s48, v33, #6
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s48
    s.addi       s46, s28, #11648
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s48, s45, #208
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s49, #0], v20
    v.extract    s49, v33, #7
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s49
    s.addi       s42, s28, #11712
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s49, s45, #240
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v41
    v.extract    s47, v33, #8
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s47
    s.addi       s46, s28, #11776
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s47, s45, #272
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v20
    v.extract    s48, v33, #9
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s48
    s.addi       s42, s28, #11840
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s48, s45, #304
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s49, #0], v41
    v.extract    s49, v33, #10
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s49
    s.addi       s46, s28, #11904
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v46
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s49, s45, #336
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v20
    v.extract    s47, v33, #11
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s47
    s.addi       s42, s28, #11968
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v44, v41, v46
    v.lshr       v41, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s47, s45, #368
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v41
    v.extract    s48, v33, #12
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s48
    s.addi       s46, s28, #12032
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s48, s45, #400
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s49, #0], v20
    v.extract    s49, v33, #13
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s49
    s.addi       s42, s28, #12096
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s49, s45, #432
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v41
    v.extract    s47, v33, #14
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    v.splat      v40, s47
    s.addi       s46, s28, #12160
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s47, s45, #464
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v20
    v.extract    s48, v33, #15
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s42, #0]
    v.splat      v40, s48
    s.addi       s42, s28, #12224
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s48, s45, #496
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s49, #0], v41
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s46, #0]
    s.addi       s46, s45, #64
    s.addi       s49, s45, #128
    vf.mul       v40, v38, v20                   // a/y: faithful quotient
    vf.fms       v45, v40, v43, v38
    vf.fms       v38, v45, v20, v40
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v38, v20, v40
    v.lshr       v20, v38, v39
    vf.cvt.f32.e4m3 v40, v38
    v.and        v38, v20, v42
    v.or         v20, v40, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v20
    s.addi       s47, s45, #192
    v.ld.w       v20, [s42, #0]
    s.addi       s42, s45, #256
    vf.mul       v38, v20, v41                   // a/y: faithful quotient
    vf.fms       v40, v38, v44, v20
    vf.fms       v20, v40, v41, v38
    vf.neg       v40, v20                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v20, v40, v38
    v.lshr       v38, v20, v39
    vf.cvt.f32.e4m3 v40, v20
    v.and        v20, v38, v42
    v.or         v38, v40, v20                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s48, #0], v38
    fence.acq_rel.device
    w.def        w1, #56, #8                     // v56..v63
    s.addi       s48, s45, #320
    v.ld.w       v20, [s45, #0]
    v.mov        v56, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s46, #0]
    s.addi       s46, s45, #384
    s.addi       s50, s45, #448
    v.mov        v57, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s49, #0]
    v.extract    s45, v22, #1
    v.mov        v58, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s47, #0]
    v.mov        v59, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s42, #0]
    v.mov        v60, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s48, #0]
    v.mov        v61, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s46, #0]
    v.mov        v62, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s50, #0]
    v.mov        v63, v20                        // hand off through the shared window (sec 7.3)
    mb.wait      s44
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v56, v48, s42
    mb.wait      s42
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s45, x8dot_done_45
    s.movz       s46, #0
    s.add        s47, s13, s24
    s.addi       s48, s46, #0
    s.addi       s46, s47, #32
    s.addi       s47, s28, #16640
x8dot_row_46:
    s.addi       s49, s20, #-32
    v.movi       v20, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v38, s50
    s.shli       s50, s48, #4
    s.addi       s51, s48, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s49, v2]             // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v20
    fence.acq_rel.device
    s.mov        s48, s51
    s.cmp.lt     s49, s48, s50
    br.nz        s49, x8dot_row_46
x8dot_done_45:
    v.splat      v20, s45
    v.movi       v38, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.extract    s47, v4, #1
    s.movz       s48, #32
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s49, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s49, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s49, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v22, #2
    m.mma.dp.async.k32.e4m3 a1, v56, v48, s47
    mb.wait      s47
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s49, x8dot_done_47
    s.add        s50, s13, s24
    s.addi       s51, s46, #0
    s.addi       s52, s50, #32
    s.addi       s50, s28, #16640
x8dot_row_48:
    s.addi       s53, s20, #-32
    v.movi       v20, #0
    s.sub        s54, s53, s51
    s.add        s53, s52, s51
    v.splat      v38, s54
    s.shli       s54, s51, #4
    s.addi       s55, s51, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s53, v29]            // index is in elements (ISA sec 9.1)
    s.add        s53, s50, s54
    v.st.b       [s53, #0], v20
    fence.acq_rel.device
    s.mov        s51, s55
    s.cmp.lt     s53, s51, s48
    br.nz        s53, x8dot_row_48
x8dot_done_47:
    v.splat      v20, s49
    v.movi       v38, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s50, v4, #2
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s51, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s51, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v22, #3
    m.mma.dp.async.k32.e4m3 a2, v56, v48, s48
    mb.wait      s48
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s50, x8dot_done_49
    s.add        s51, s13, s24
    s.addi       s52, s46, #0
    s.addi       s46, s51, #32
    s.addi       s51, s28, #16640
x8dot_row_50:
    s.addi       s53, s20, #-32
    v.movi       v20, #0
    s.sub        s54, s53, s52
    s.add        s53, s46, s52
    v.splat      v38, s54
    s.shli       s54, s52, #4
    s.addi       s55, s52, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s53, v28]            // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v20
    fence.acq_rel.device
    s.mov        s52, s55
    s.cmp.lt     s53, s52, s54
    br.nz        s53, x8dot_row_50
x8dot_done_49:
    v.splat      v20, s50
    v.movi       v38, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.extract    s51, v4, #3
    s.movz       s52, #32
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s53, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s53, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s53, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v22, #4
    m.mma.dp.async.k32.e4m3 a3, v56, v48, s51
    mb.wait      s51
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s53, x8dot_done_51
    s.add        s54, s13, s24
    s.addi       s55, s50, #0
    s.addi       s56, s54, #32
    s.addi       s54, s28, #16640
x8dot_row_52:
    s.addi       s57, s20, #-32
    v.movi       v20, #0
    s.sub        s58, s57, s55
    s.add        s57, s56, s55
    v.splat      v38, s58
    s.shli       s58, s55, #4
    s.addi       s59, s55, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s57, v31]            // index is in elements (ISA sec 9.1)
    s.add        s57, s54, s58
    v.st.b       [s57, #0], v20
    fence.acq_rel.device
    s.mov        s55, s59
    s.cmp.lt     s57, s55, s52
    br.nz        s57, x8dot_row_52
x8dot_done_51:
    v.splat      v20, s53
    v.movi       v38, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s54, v4, #4
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s55, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s55, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s55, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v22, #5
    m.mma.dp.async.k32.e4m3 a4, v56, v48, s52
    mb.wait      s52
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s54, x8dot_done_53
    s.add        s55, s13, s24
    s.addi       s56, s50, #0
    s.addi       s50, s55, #32
    s.addi       s55, s28, #16640
x8dot_row_54:
    s.addi       s57, s20, #-32
    v.movi       v20, #0
    s.sub        s58, s57, s56
    s.add        s57, s50, s56
    v.splat      v38, s58
    s.shli       s58, s56, #4
    s.addi       s59, s56, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s57, v24]            // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v20
    fence.acq_rel.device
    s.mov        s56, s59
    s.cmp.lt     s57, s56, s58
    br.nz        s57, x8dot_row_54
x8dot_done_53:
    v.splat      v20, s54
    v.movi       v38, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    v.extract    s55, v4, #5
    s.movz       s56, #32
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s57, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s57, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s57, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s57, v22, #6
    m.mma.dp.async.k32.e4m3 a5, v56, v48, s55
    mb.wait      s55
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s57, x8dot_done_55
    s.add        s58, s13, s24
    s.addi       s59, s54, #0
    s.addi       s60, s58, #32
    s.addi       s58, s28, #16640
x8dot_row_56:
    s.addi       s16, s20, #-32
    v.movi       v20, #0
    s.sub        s17, s16, s59
    s.add        s16, s60, s59
    v.splat      v38, s17
    s.shli       s17, s59, #4
    s.addi       s25, s59, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s16, v32]            // index is in elements (ISA sec 9.1)
    s.add        s16, s58, s17
    v.st.b       [s16, #0], v20
    fence.acq_rel.device
    s.mov        s59, s25
    s.cmp.lt     s16, s59, s56
    br.nz        s16, x8dot_row_56
x8dot_done_55:
    v.splat      v20, s57
    v.movi       v38, #0
    mb.arm       s16, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s17, v4, #6
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s25, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s25, s16            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s25, s17                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s25, s16          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s16
    mb.arm       s17, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s25, v22, #7
    m.mma.dp.async.k32.e4m3 a6, v56, v48, s17
    mb.wait      s17
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s25, x8dot_done_57
    s.add        s26, s13, s24
    s.addi       s30, s54, #0
    s.addi       s31, s26, #32
    s.addi       s26, s28, #16640
x8dot_row_58:
    s.addi       s33, s20, #-32
    v.movi       v20, #0
    s.sub        s34, s33, s30
    s.add        s33, s31, s30
    v.splat      v38, s34
    s.shli       s34, s30, #4
    s.addi       s35, s30, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s33, v23]            // index is in elements (ISA sec 9.1)
    s.add        s33, s26, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v20
    fence.acq_rel.device
    s.mov        s30, s35
    s.cmp.lt     s33, s30, s34
    br.nz        s33, x8dot_row_58
x8dot_done_57:
    v.splat      v20, s25
    v.movi       v38, #0
    mb.arm       s25, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s26, #0
    v.extract    s30, v4, #7
    s.movz       s31, #32
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s33, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s33, s25            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s33, s25          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s25
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v22, #0
    m.mma.dp.async.k32.e4m3 a7, v56, v48, s30
    mb.wait      s30
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s33, x8dot_done_59
    s.add        s34, s13, s24
    s.addi       s35, s26, #0
    s.addi       s36, s34, #64
    s.addi       s34, s28, #16640
x8dot_row_60:
    s.addi       s37, s20, #-64
    v.movi       v20, #0
    s.sub        s38, s37, s35
    s.add        s37, s36, s35
    v.splat      v38, s38
    s.shli       s38, s35, #4
    s.addi       s39, s35, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s37, v27]            // index is in elements (ISA sec 9.1)
    s.add        s37, s34, s38
    v.st.b       [s37, #0], v20
    fence.acq_rel.device
    s.mov        s35, s39
    s.cmp.lt     s37, s35, s31
    br.nz        s37, x8dot_row_60
x8dot_done_59:
    v.extract    s31, v33, #0
    v.splat      v20, s33
    v.splat      v38, s31
    v.movi       v40, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v41, v38, v26
    v.extract    s33, v4, #0
    s.movz       s34, #64
    s.addi       s35, s28, #12288
    v.cmp.ne     p1, v20, v40
    v.rcp.approx v38, v41                        // ISA 8.8: <= 2**-22 relative
    v.cmp.eq     p2, v20, v40
    s.mov        s36, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s36, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s36, s31          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v20, [s35, #0]
    v.extract    s26, v33, #1
    s.addi       s33, s28, #18432                // 512 bytes of repack scratch
    v.splat      v40, s26
    s.addi       s26, s33, #0
    s.addi       s34, s28, #12352
    vf.max.ieee  v43, v40, v26
    v.extract    s35, v33, #2
    s.addi       s36, s33, #32
    v.splat      v40, s35
    s.addi       s35, s28, #12416
    v.rcp.approx v44, v43                        // ISA 8.8: <= 2**-22 relative
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v46, v41, v38, v19
    vf.fms       v47, v38, v46, v38
    vf.neg       v46, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v46, v46
    @p1 v.sel        v47, v46, v38
    vf.fms       v38, v43, v44, v19
    vf.fms       v46, v44, v38, v44
    vf.neg       v38, v46                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v46, v38, v44
    vf.mul       v38, v20, v47                   // a/y: faithful quotient
    vf.fms       v44, v38, v41, v20
    vf.fms       v20, v45, v40, v19
    vf.fms       v41, v44, v47, v38
    vf.fms       v44, v40, v20, v40
    vf.neg       v20, v41                        // a/y: one correction to the IEEE quotient
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v38
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v20, v41, v40
    v.lshr       v38, v44, v39
    vf.cvt.f32.e4m3 v40, v44
    v.and        v41, v38, v42
    s.addi       s37, s33, #64
    v.or         v38, v40, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s26, #0], v38
    v.extract    s26, v33, #3
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s26
    s.addi       s26, s28, #12480
    vf.max.ieee  v41, v40, v26
    v.rcp.approx v40, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v38, v46                   // a/y: faithful quotient
    vf.fms       v47, v44, v43, v38
    vf.fms       v38, v47, v46, v44
    vf.neg       v43, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v41, v40, v19
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v46, v43, v44
    v.lshr       v43, v46, v39
    vf.cvt.f32.e4m3 v44, v46
    vf.fms       v46, v40, v38, v40
    v.and        v38, v43, v42
    s.addi       s34, s33, #96
    v.or         v43, v44, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v46                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v43
    v.extract    s36, v33, #4
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v43, v38, v40
    v.ld.w       v38, [s35, #0]
    v.splat      v40, s36
    s.addi       s35, s28, #12544
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s36, s33, #128
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s37, #0], v20
    v.extract    s37, v33, #5
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s37
    s.addi       s26, s28, #12608
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v41, v38
    vf.fms       v38, v47, v43, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s37, s33, #160
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s34, #0], v41
    v.extract    s34, v33, #6
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s35, #0]
    v.splat      v40, s34
    s.addi       s34, s28, #12672
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s35, s33, #192
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v20
    v.extract    s36, v33, #7
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s36
    s.addi       s26, s28, #12736
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s36, s33, #224
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s37, #0], v41
    v.extract    s37, v33, #8
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s37
    s.addi       s34, s28, #12800
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v46
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s37, s33, #256
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v20
    v.extract    s35, v33, #9
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s35
    s.addi       s26, s28, #12864
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v44, v41, v46
    v.lshr       v41, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s35, s33, #288
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v41
    v.extract    s36, v33, #10
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s36
    s.addi       s34, s28, #12928
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s36, s33, #320
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s37, #0], v20
    v.extract    s37, v33, #11
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s37
    s.addi       s26, s28, #12992
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s37, s33, #352
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v41
    v.extract    s35, v33, #12
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s35
    s.addi       s34, s28, #13056
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s35, s33, #384
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v20
    v.extract    s36, v33, #13
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s36
    s.addi       s26, s28, #13120
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s36, s33, #416
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s37, #0], v41
    v.extract    s37, v33, #14
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s37
    s.addi       s34, s28, #13184
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v46
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s37, s33, #448
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v20
    v.extract    s35, v33, #15
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s35
    s.addi       s26, s28, #13248
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v44, v41, v46
    v.lshr       v41, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s35, s33, #480
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v41
    v.extract    s36, v33, #0
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s36
    s.addi       s34, s28, #13312
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s36, s33, #16
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s37, #0], v20
    v.extract    s37, v33, #1
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s37
    s.addi       s26, s28, #13376
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s37, s33, #48
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v41
    v.extract    s35, v33, #2
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s35
    s.addi       s34, s28, #13440
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s35, s33, #80
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v20
    v.extract    s36, v33, #3
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s36
    s.addi       s26, s28, #13504
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s36, s33, #112
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s37, #0], v41
    v.extract    s37, v33, #4
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s37
    s.addi       s34, s28, #13568
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v46
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s37, s33, #144
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v20
    v.extract    s35, v33, #5
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s35
    s.addi       s26, s28, #13632
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v44, v41, v46
    v.lshr       v41, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s35, s33, #176
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v41
    v.extract    s36, v33, #6
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s36
    s.addi       s34, s28, #13696
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s36, s33, #208
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s37, #0], v20
    v.extract    s37, v33, #7
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s37
    s.addi       s26, s28, #13760
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s37, s33, #240
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v41
    v.extract    s35, v33, #8
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s35
    s.addi       s34, s28, #13824
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s35, s33, #272
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v20
    v.extract    s36, v33, #9
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s36
    s.addi       s26, s28, #13888
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s36, s33, #304
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s37, #0], v41
    v.extract    s37, v33, #10
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s37
    s.addi       s34, s28, #13952
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v46
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s37, s33, #336
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v20
    v.extract    s35, v33, #11
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s35
    s.addi       s26, s28, #14016
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v44, v41, v46
    v.lshr       v41, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s35, s33, #368
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v41
    v.extract    s36, v33, #12
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s36
    s.addi       s34, s28, #14080
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v45, v20, v46
    v.lshr       v20, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s36, s33, #400
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s37, #0], v20
    v.extract    s37, v33, #13
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s37
    s.addi       s26, s28, #14144
    vf.max.ieee  v45, v40, v26
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v45, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v46
    v.lshr       v41, v43, v39
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s37, s33, #432
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v41
    v.extract    s35, v33, #14
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    v.splat      v40, s35
    s.addi       s34, s28, #14208
    vf.max.ieee  v43, v40, v26
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v20                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v38
    vf.fms       v38, v47, v20, v46
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v43, v40, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v46
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v40, v38, v40
    v.and        v38, v20, v42
    s.addi       s35, s33, #464
    v.or         v20, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v20
    v.extract    s36, v33, #15
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v20, v38, v40
    v.ld.w       v38, [s26, #0]
    v.splat      v40, s36
    s.addi       s26, s28, #14272
    vf.max.ieee  v44, v40, v26
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v38, v41                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v38
    vf.fms       v38, v47, v41, v46
    vf.neg       v41, v38                        // a/y: one correction to the IEEE quotient
    vf.fms       v38, v44, v40, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v46
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v40, v38, v40
    v.and        v38, v41, v42
    s.addi       s36, s33, #496
    v.or         v41, v46, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v38, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s37, #0], v41
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v41, v38, v40
    v.ld.w       v38, [s34, #0]
    s.addi       s34, s33, #64
    s.addi       s37, s33, #128
    vf.mul       v40, v38, v20                   // a/y: faithful quotient
    vf.fms       v45, v40, v43, v38
    vf.fms       v38, v45, v20, v40
    vf.neg       v20, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v38, v20, v40
    v.lshr       v20, v38, v39
    vf.cvt.f32.e4m3 v40, v38
    v.and        v38, v20, v42
    v.or         v20, v40, v38                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v20
    s.addi       s35, s33, #192
    v.ld.w       v20, [s26, #0]
    s.addi       s26, s33, #256
    vf.mul       v38, v20, v41                   // a/y: faithful quotient
    vf.fms       v40, v38, v44, v20
    vf.fms       v20, v40, v41, v38
    vf.neg       v40, v20                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v20, v40, v38
    v.lshr       v38, v20, v39
    vf.cvt.f32.e4m3 v40, v20
    v.and        v20, v38, v42
    v.or         v38, v40, v20                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v38
    fence.acq_rel.device
    w.def        w1, #56, #8                     // v56..v63
    s.addi       s36, s33, #320
    v.ld.w       v20, [s33, #0]
    v.mov        v56, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s34, #0]
    s.addi       s34, s33, #384
    s.addi       s38, s33, #448
    v.mov        v57, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s37, #0]
    v.extract    s33, v22, #1
    v.mov        v58, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s35, #0]
    v.mov        v59, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s26, #0]
    v.mov        v60, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s36, #0]
    v.mov        v61, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s34, #0]
    v.mov        v62, v20                        // hand off through the shared window (sec 7.3)
    v.ld.w       v20, [s38, #0]
    v.mov        v63, v20                        // hand off through the shared window (sec 7.3)
    mb.wait      s31
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v56, v48, s26
    mb.wait      s26
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s33, x8dot_done_61
    s.movz       s34, #0
    s.add        s35, s13, s24
    s.addi       s36, s34, #0
    s.addi       s34, s35, #64
    s.addi       s35, s28, #16640
x8dot_row_62:
    s.addi       s37, s20, #-64
    v.movi       v20, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v38, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s37, v2]             // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v20
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_62
x8dot_done_61:
    v.splat      v20, s33
    v.movi       v38, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.extract    s35, v4, #1
    s.movz       s36, #64
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s37, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s37, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v22, #2
    m.mma.dp.async.k32.e4m3 a1, v56, v48, s35
    mb.wait      s35
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s37, x8dot_done_63
    s.add        s38, s13, s24
    s.addi       s39, s34, #0
    s.addi       s40, s38, #64
    s.addi       s38, s28, #16640
x8dot_row_64:
    s.addi       s41, s20, #-64
    v.movi       v20, #0
    s.sub        s42, s41, s39
    s.add        s41, s40, s39
    v.splat      v38, s42
    s.shli       s42, s39, #4
    s.addi       s43, s39, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s41, v29]            // index is in elements (ISA sec 9.1)
    s.add        s41, s38, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v20
    fence.acq_rel.device
    s.mov        s39, s43
    s.cmp.lt     s41, s39, s42
    br.nz        s41, x8dot_row_64
x8dot_done_63:
    v.splat      v20, s37
    v.movi       v38, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s38, v4, #2
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s39, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v22, #3
    m.mma.dp.async.k32.e4m3 a2, v56, v48, s36
    mb.wait      s36
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s38, x8dot_done_65
    s.add        s39, s13, s24
    s.addi       s40, s34, #0
    s.addi       s34, s39, #64
    s.addi       s39, s28, #16640
x8dot_row_66:
    s.addi       s41, s20, #-64
    v.movi       v20, #0
    s.sub        s42, s41, s40
    s.add        s41, s34, s40
    v.splat      v38, s42
    s.shli       s42, s40, #4
    s.addi       s43, s40, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s41, v28]            // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v20
    fence.acq_rel.device
    s.mov        s40, s43
    s.cmp.lt     s41, s40, s42
    br.nz        s41, x8dot_row_66
x8dot_done_65:
    v.splat      v20, s38
    v.movi       v38, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s39, v4, #3
    s.movz       s40, #64
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s41, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s41, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v22, #4
    m.mma.dp.async.k32.e4m3 a3, v56, v48, s39
    mb.wait      s39
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s41, x8dot_done_67
    s.add        s42, s13, s24
    s.addi       s43, s38, #0
    s.addi       s44, s42, #64
    s.addi       s42, s28, #16640
x8dot_row_68:
    s.addi       s45, s20, #-64
    v.movi       v20, #0
    s.sub        s46, s45, s43
    s.add        s45, s44, s43
    v.splat      v38, s46
    s.shli       s46, s43, #4
    s.addi       s47, s43, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s45, v31]            // index is in elements (ISA sec 9.1)
    s.add        s45, s42, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v20
    fence.acq_rel.device
    s.mov        s43, s47
    s.cmp.lt     s45, s43, s46
    br.nz        s45, x8dot_row_68
x8dot_done_67:
    v.splat      v20, s41
    v.movi       v38, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s42, v4, #4
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v22, #5
    m.mma.dp.async.k32.e4m3 a4, v56, v48, s40
    mb.wait      s40
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s42, x8dot_done_69
    s.add        s43, s13, s24
    s.addi       s44, s38, #0
    s.addi       s38, s43, #64
    s.addi       s43, s28, #16640
x8dot_row_70:
    s.addi       s45, s20, #-64
    v.movi       v20, #0
    s.sub        s46, s45, s44
    s.add        s45, s38, s44
    v.splat      v38, s46
    s.shli       s46, s44, #4
    s.addi       s47, s44, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s45, v24]            // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v20
    fence.acq_rel.device
    s.mov        s44, s47
    s.cmp.lt     s45, s44, s46
    br.nz        s45, x8dot_row_70
x8dot_done_69:
    v.splat      v20, s42
    v.movi       v38, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.extract    s43, v4, #5
    s.movz       s44, #64
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s45, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s45, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v22, #6
    m.mma.dp.async.k32.e4m3 a5, v56, v48, s43
    mb.wait      s43
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s45, x8dot_done_71
    s.add        s46, s13, s24
    s.addi       s47, s42, #0
    s.addi       s48, s46, #64
    s.addi       s46, s28, #16640
x8dot_row_72:
    s.addi       s49, s20, #-64
    v.movi       v20, #0
    s.sub        s50, s49, s47
    s.add        s49, s48, s47
    v.splat      v38, s50
    s.shli       s50, s47, #4
    s.addi       s51, s47, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s49, v32]            // index is in elements (ISA sec 9.1)
    s.add        s49, s46, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v20
    fence.acq_rel.device
    s.mov        s47, s51
    s.cmp.lt     s49, s47, s50
    br.nz        s49, x8dot_row_72
x8dot_done_71:
    v.splat      v20, s45
    v.movi       v38, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s46, v4, #6
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s47, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s47, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s47, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v22, #7
    m.mma.dp.async.k32.e4m3 a6, v56, v48, s44
    mb.wait      s44
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s46, x8dot_done_73
    s.add        s47, s13, s24
    s.addi       s48, s42, #0
    s.addi       s42, s47, #64
    s.addi       s47, s28, #16640
x8dot_row_74:
    s.addi       s49, s20, #-64
    v.movi       v20, #0
    s.sub        s50, s49, s48
    s.add        s49, s42, s48
    v.splat      v38, s50
    s.shli       s50, s48, #4
    s.addi       s51, s48, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s49, v23]            // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v20
    fence.acq_rel.device
    s.mov        s48, s51
    s.cmp.lt     s49, s48, s50
    br.nz        s49, x8dot_row_74
x8dot_done_73:
    v.splat      v20, s46
    v.movi       v38, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.extract    s47, v4, #7
    s.movz       s48, #64
    v.cmp.ne     p1, v20, v38
    v.cmp.eq     p2, v20, v38
    s.mov        s49, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s49, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s49, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v22, #0
    m.mma.dp.async.k32.e4m3 a7, v56, v48, s47
    mb.wait      s47
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s48, x8dot_done_75
    s.add        s49, s13, s24
    s.addi       s50, s46, #0
    s.addi       s51, s49, #96
    s.addi       s49, s28, #16640
x8dot_row_76:
    s.addi       s52, s20, #-96
    v.movi       v20, #0
    s.sub        s53, s52, s50
    s.add        s52, s51, s50
    v.splat      v38, s53
    s.shli       s53, s50, #4
    s.addi       s54, s50, #1
    v.cmp.gt     p1, v38, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s52, v27]            // index is in elements (ISA sec 9.1)
    s.add        s52, s49, s53
    s.movz       s53, #32
    v.st.b       [s52, #0], v20
    fence.acq_rel.device
    s.mov        s50, s54
    s.cmp.lt     s52, s50, s53
    br.nz        s52, x8dot_row_76
x8dot_done_75:
    v.extract    s49, v33, #0
    v.splat      v20, s48
    v.splat      v27, s49
    v.movi       v38, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v40, v27, v26
    v.extract    s49, v4, #0
    s.movz       s50, #96
    s.addi       s51, s28, #14336
    v.cmp.ne     p1, v20, v38
    v.rcp.approx v27, v40                        // ISA 8.8: <= 2**-22 relative
    v.cmp.eq     p2, v20, v38
    s.mov        s52, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s52, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s52, s48          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v20, [s51, #0]
    v.extract    s46, v33, #1
    s.addi       s49, s28, #18944                // 512 bytes of repack scratch
    v.splat      v38, s46
    s.addi       s46, s49, #0
    s.addi       s50, s28, #14400
    vf.max.ieee  v41, v38, v26
    v.extract    s51, v33, #2
    s.addi       s52, s49, #32
    v.splat      v38, s51
    s.addi       s51, s28, #14464
    v.rcp.approx v43, v41                        // ISA 8.8: <= 2**-22 relative
    vf.max.ieee  v44, v38, v26
    v.rcp.approx v38, v44                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v45, v40, v27, v19
    vf.fms       v46, v27, v45, v27
    vf.neg       v45, v46                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v45, v45
    @p1 v.sel        v46, v45, v27
    vf.fms       v27, v41, v43, v19
    vf.fms       v45, v43, v27, v43
    vf.neg       v27, v45                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v45, v27, v43
    vf.mul       v27, v20, v46                   // a/y: faithful quotient
    vf.fms       v43, v27, v40, v20
    vf.fms       v20, v44, v38, v19
    vf.fms       v40, v43, v46, v27
    vf.fms       v43, v38, v20, v38
    vf.neg       v20, v40                        // a/y: one correction to the IEEE quotient
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v27
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v20, v40, v38
    v.lshr       v27, v43, v39
    vf.cvt.f32.e4m3 v38, v43
    v.and        v40, v27, v42
    s.addi       s53, s49, #64
    v.or         v27, v38, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v27
    v.extract    s46, v33, #3
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s46
    s.addi       s46, s28, #14528
    vf.max.ieee  v40, v38, v26
    v.rcp.approx v38, v40                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v43, v27, v45                   // a/y: faithful quotient
    vf.fms       v46, v43, v41, v27
    vf.fms       v27, v46, v45, v43
    vf.neg       v41, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v40, v38, v19
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v43
    v.lshr       v41, v45, v39
    vf.cvt.f32.e4m3 v43, v45
    vf.fms       v45, v38, v27, v38
    v.and        v27, v41, v42
    s.addi       s50, s49, #96
    v.or         v41, v43, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v41
    v.extract    s52, v33, #4
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v41, v27, v38
    v.ld.w       v27, [s51, #0]
    v.splat      v38, s52
    s.addi       s51, s28, #14592
    vf.max.ieee  v43, v38, v26
    v.rcp.approx v38, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v44, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v43, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v45
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v45, v44
    vf.fms       v44, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s52, s49, #128
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s53, #0], v20
    v.extract    s53, v33, #5
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s53
    s.addi       s46, s28, #14656
    vf.max.ieee  v44, v38, v26
    v.rcp.approx v38, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v41                   // a/y: faithful quotient
    vf.fms       v46, v45, v40, v27
    vf.fms       v27, v46, v41, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v44, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v41, v40, v45
    v.lshr       v40, v41, v39
    vf.cvt.f32.e4m3 v45, v41
    vf.fms       v41, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s53, s49, #160
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v41                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s50, #0], v40
    v.extract    s50, v33, #6
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s51, #0]
    v.splat      v38, s50
    s.addi       s50, s28, #14720
    vf.max.ieee  v41, v38, v26
    v.rcp.approx v38, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v43, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v41, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v45
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s51, s49, #192
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v20
    v.extract    s52, v33, #7
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s52
    s.addi       s46, s28, #14784
    vf.max.ieee  v43, v38, v26
    v.rcp.approx v38, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v40                   // a/y: faithful quotient
    vf.fms       v46, v45, v44, v27
    vf.fms       v27, v46, v40, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v43, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v45
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v45, v44
    vf.fms       v44, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s52, s49, #224
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s53, #0], v40
    v.extract    s53, v33, #8
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s53
    s.addi       s50, s28, #14848
    vf.max.ieee  v44, v38, v26
    v.rcp.approx v38, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v41, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v44, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v41, v20, v45
    v.lshr       v20, v41, v39
    vf.cvt.f32.e4m3 v45, v41
    vf.fms       v41, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s53, s49, #256
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v41                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v20
    v.extract    s51, v33, #9
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s51
    s.addi       s46, s28, #14912
    vf.max.ieee  v41, v38, v26
    v.rcp.approx v38, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v40                   // a/y: faithful quotient
    vf.fms       v46, v45, v43, v27
    vf.fms       v27, v46, v40, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v41, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v45
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s51, s49, #288
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v40
    v.extract    s52, v33, #10
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s52
    s.addi       s50, s28, #14976
    vf.max.ieee  v43, v38, v26
    v.rcp.approx v38, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v44, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v43, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v45
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v45, v44
    vf.fms       v44, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s52, s49, #320
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s53, #0], v20
    v.extract    s53, v33, #11
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s53
    s.addi       s46, s28, #15040
    vf.max.ieee  v44, v38, v26
    v.rcp.approx v38, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v40                   // a/y: faithful quotient
    vf.fms       v46, v45, v41, v27
    vf.fms       v27, v46, v40, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v44, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v41, v40, v45
    v.lshr       v40, v41, v39
    vf.cvt.f32.e4m3 v45, v41
    vf.fms       v41, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s53, s49, #352
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v41                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v40
    v.extract    s51, v33, #12
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s51
    s.addi       s50, s28, #15104
    vf.max.ieee  v41, v38, v26
    v.rcp.approx v38, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v43, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v41, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v45
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s51, s49, #384
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v20
    v.extract    s52, v33, #13
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s52
    s.addi       s46, s28, #15168
    vf.max.ieee  v43, v38, v26
    v.rcp.approx v38, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v40                   // a/y: faithful quotient
    vf.fms       v46, v45, v44, v27
    vf.fms       v27, v46, v40, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v43, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v45
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v45, v44
    vf.fms       v44, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s52, s49, #416
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s53, #0], v40
    v.extract    s53, v33, #14
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s53
    s.addi       s50, s28, #15232
    vf.max.ieee  v44, v38, v26
    v.rcp.approx v38, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v41, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v44, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v41, v20, v45
    v.lshr       v20, v41, v39
    vf.cvt.f32.e4m3 v45, v41
    vf.fms       v41, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s53, s49, #448
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v41                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v20
    v.extract    s51, v33, #15
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s51
    s.addi       s46, s28, #15296
    vf.max.ieee  v41, v38, v26
    v.rcp.approx v38, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v40                   // a/y: faithful quotient
    vf.fms       v46, v45, v43, v27
    vf.fms       v27, v46, v40, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v41, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v45
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s51, s49, #480
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v40
    v.extract    s52, v33, #0
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s52
    s.addi       s50, s28, #15360
    vf.max.ieee  v43, v38, v26
    v.rcp.approx v38, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v44, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v43, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v45
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v45, v44
    vf.fms       v44, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s52, s49, #16
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s53, #0], v20
    v.extract    s53, v33, #1
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s53
    s.addi       s46, s28, #15424
    vf.max.ieee  v44, v38, v26
    v.rcp.approx v38, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v40                   // a/y: faithful quotient
    vf.fms       v46, v45, v41, v27
    vf.fms       v27, v46, v40, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v44, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v41, v40, v45
    v.lshr       v40, v41, v39
    vf.cvt.f32.e4m3 v45, v41
    vf.fms       v41, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s53, s49, #48
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v41                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v40
    v.extract    s51, v33, #2
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s51
    s.addi       s50, s28, #15488
    vf.max.ieee  v41, v38, v26
    v.rcp.approx v38, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v43, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v41, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v45
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s51, s49, #80
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v20
    v.extract    s52, v33, #3
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s52
    s.addi       s46, s28, #15552
    vf.max.ieee  v43, v38, v26
    v.rcp.approx v38, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v40                   // a/y: faithful quotient
    vf.fms       v46, v45, v44, v27
    vf.fms       v27, v46, v40, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v43, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v45
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v45, v44
    vf.fms       v44, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s52, s49, #112
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s53, #0], v40
    v.extract    s53, v33, #4
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s53
    s.addi       s50, s28, #15616
    vf.max.ieee  v44, v38, v26
    v.rcp.approx v38, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v41, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v44, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v41, v20, v45
    v.lshr       v20, v41, v39
    vf.cvt.f32.e4m3 v45, v41
    vf.fms       v41, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s53, s49, #144
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v41                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v20
    v.extract    s51, v33, #5
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s51
    s.addi       s46, s28, #15680
    vf.max.ieee  v41, v38, v26
    v.rcp.approx v38, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v40                   // a/y: faithful quotient
    vf.fms       v46, v45, v43, v27
    vf.fms       v27, v46, v40, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v41, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v45
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s51, s49, #176
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v40
    v.extract    s52, v33, #6
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s52
    s.addi       s50, s28, #15744
    vf.max.ieee  v43, v38, v26
    v.rcp.approx v38, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v44, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v43, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v45
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v45, v44
    vf.fms       v44, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s52, s49, #208
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s53, #0], v20
    v.extract    s53, v33, #7
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s53
    s.addi       s46, s28, #15808
    vf.max.ieee  v44, v38, v26
    v.rcp.approx v38, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v40                   // a/y: faithful quotient
    vf.fms       v46, v45, v41, v27
    vf.fms       v27, v46, v40, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v44, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v41, v40, v45
    v.lshr       v40, v41, v39
    vf.cvt.f32.e4m3 v45, v41
    vf.fms       v41, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s53, s49, #240
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v41                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v40
    v.extract    s51, v33, #8
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s51
    s.addi       s50, s28, #15872
    vf.max.ieee  v41, v38, v26
    v.rcp.approx v38, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v43, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v41, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v45
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s51, s49, #272
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v20
    v.extract    s52, v33, #9
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s52
    s.addi       s46, s28, #15936
    vf.max.ieee  v43, v38, v26
    v.rcp.approx v38, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v40                   // a/y: faithful quotient
    vf.fms       v46, v45, v44, v27
    vf.fms       v27, v46, v40, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v43, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v45
    v.lshr       v40, v44, v39
    vf.cvt.f32.e4m3 v45, v44
    vf.fms       v44, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s52, s49, #304
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s53, #0], v40
    v.extract    s53, v33, #10
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s53
    s.addi       s50, s28, #16000
    vf.max.ieee  v44, v38, v26
    v.rcp.approx v38, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v41, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v44, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v41, v20, v45
    v.lshr       v20, v41, v39
    vf.cvt.f32.e4m3 v45, v41
    vf.fms       v41, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s53, s49, #336
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v41                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v20
    v.extract    s51, v33, #11
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s51
    s.addi       s46, s28, #16064
    vf.max.ieee  v41, v38, v26
    v.rcp.approx v38, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v40                   // a/y: faithful quotient
    vf.fms       v46, v45, v43, v27
    vf.fms       v27, v46, v40, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v41, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v45
    v.lshr       v40, v43, v39
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s51, s49, #368
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v40
    v.extract    s52, v33, #12
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s52
    s.addi       s50, s28, #16128
    vf.max.ieee  v43, v38, v26
    v.rcp.approx v38, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v44, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v43, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v44, v20, v45
    v.lshr       v20, v44, v39
    vf.cvt.f32.e4m3 v45, v44
    vf.fms       v44, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s52, s49, #400
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s53, #0], v20
    v.extract    s53, v33, #13
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s53
    s.addi       s46, s28, #16192
    vf.max.ieee  v44, v38, v26
    v.rcp.approx v38, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v40                   // a/y: faithful quotient
    vf.fms       v46, v45, v41, v27
    vf.fms       v27, v46, v40, v45
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v44, v38, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v41, v40, v45
    v.lshr       v40, v41, v39
    vf.cvt.f32.e4m3 v45, v41
    vf.fms       v41, v38, v27, v38
    v.and        v27, v40, v42
    s.addi       s53, s49, #432
    v.or         v40, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v41                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v40
    v.extract    s51, v33, #14
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v40, v27, v38
    v.ld.w       v27, [s50, #0]
    v.splat      v38, s51
    s.addi       s50, s28, #16256
    vf.max.ieee  v41, v38, v26
    v.rcp.approx v38, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v27, v20                   // a/y: faithful quotient
    vf.fms       v46, v45, v43, v27
    vf.fms       v27, v46, v20, v45
    vf.neg       v20, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v41, v38, v19
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v43, v20, v45
    v.lshr       v20, v43, v39
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v38, v27, v38
    v.and        v27, v20, v42
    s.addi       s51, s49, #464
    v.or         v20, v45, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v20
    v.extract    s52, v33, #15
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v20, v27, v38
    v.ld.w       v27, [s46, #0]
    v.splat      v38, s52
    s.addi       s46, s28, #16320
    vf.max.ieee  v43, v38, v26
    v.rcp.approx v26, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v38, v27, v40                   // a/y: faithful quotient
    vf.fms       v45, v38, v44, v27
    vf.fms       v27, v45, v40, v38
    vf.neg       v40, v27                        // a/y: one correction to the IEEE quotient
    vf.fms       v27, v43, v26, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v19, v40, v38
    v.lshr       v38, v19, v39
    vf.cvt.f32.e4m3 v40, v19
    vf.fms       v19, v26, v27, v26
    v.and        v27, v38, v42
    s.addi       s52, s49, #496
    v.or         v38, v40, v27                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v27, v19                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s53, #0], v38
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v19, v27, v26
    v.ld.w       v26, [s50, #0]
    s.addi       s50, s49, #64
    s.addi       s53, s49, #128
    vf.mul       v27, v26, v20                   // a/y: faithful quotient
    vf.fms       v38, v27, v41, v26
    vf.fms       v26, v38, v20, v27
    vf.neg       v20, v26                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v26, v20, v27
    v.lshr       v20, v26, v39
    vf.cvt.f32.e4m3 v27, v26
    v.and        v26, v20, v42
    v.or         v20, v27, v26                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v20
    s.addi       s51, s49, #192
    v.ld.w       v20, [s46, #0]
    s.addi       s46, s49, #256
    vf.mul       v26, v20, v19                   // a/y: faithful quotient
    vf.fms       v27, v26, v43, v20
    vf.fms       v20, v27, v19, v26
    vf.neg       v19, v20                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v20, v19, v26
    v.lshr       v19, v20, v39
    vf.cvt.f32.e4m3 v26, v20
    v.and        v20, v19, v42
    v.or         v19, v26, v20                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v19
    fence.acq_rel.device
    w.def        w1, #56, #8                     // v56..v63
    s.addi       s52, s49, #320
    v.ld.w       v19, [s49, #0]
    v.mov        v56, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s50, #0]
    s.addi       s50, s49, #384
    s.addi       s54, s49, #448
    v.mov        v57, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s53, #0]
    v.extract    s49, v22, #1
    v.mov        v58, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s51, #0]
    v.mov        v59, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s46, #0]
    v.mov        v60, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s52, #0]
    v.mov        v61, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s50, #0]
    v.mov        v62, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s54, #0]
    v.mov        v63, v19                        // hand off through the shared window (sec 7.3)
    mb.wait      s48
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a0, v56, v48, s46
    mb.wait      s46
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s49, x8dot_done_77
    s.movz       s50, #0
    s.add        s51, s13, s24
    s.addi       s52, s50, #0
    s.addi       s50, s51, #96
    s.addi       s51, s28, #16640
x8dot_row_78:
    s.addi       s53, s20, #-96
    v.movi       v19, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v20, s54
    s.shli       s54, s52, #4
    s.addi       s55, s52, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s53, v2]             // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v19
    fence.acq_rel.device
    s.mov        s52, s55
    s.cmp.lt     s53, s52, s54
    br.nz        s53, x8dot_row_78
x8dot_done_77:
    v.splat      v2, s49
    v.movi       v19, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.extract    s51, v4, #1
    s.movz       s52, #96
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s53, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s53, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s53, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v22, #2
    m.mma.dp.async.k32.e4m3 a1, v56, v48, s51
    mb.wait      s51
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s53, x8dot_done_79
    s.add        s54, s13, s24
    s.addi       s55, s50, #0
    s.addi       s56, s54, #96
    s.addi       s54, s28, #16640
x8dot_row_80:
    s.addi       s57, s20, #-96
    v.movi       v2, #0
    s.sub        s58, s57, s55
    s.add        s57, s56, s55
    v.splat      v19, s58
    s.shli       s58, s55, #4
    s.addi       s59, s55, #1
    v.cmp.gt     p1, v19, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s57, v29]             // index is in elements (ISA sec 9.1)
    s.add        s57, s54, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v2
    fence.acq_rel.device
    s.mov        s55, s59
    s.cmp.lt     s57, s55, s58
    br.nz        s57, x8dot_row_80
x8dot_done_79:
    v.splat      v2, s53
    v.movi       v19, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s54, v4, #2
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s55, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s55, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s55, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v22, #3
    m.mma.dp.async.k32.e4m3 a2, v56, v48, s52
    mb.wait      s52
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s54, x8dot_done_81
    s.add        s55, s13, s24
    s.addi       s56, s50, #0
    s.addi       s50, s55, #96
    s.addi       s55, s28, #16640
x8dot_row_82:
    s.addi       s57, s20, #-96
    v.movi       v2, #0
    s.sub        s58, s57, s56
    s.add        s57, s50, s56
    v.splat      v19, s58
    s.shli       s58, s56, #4
    s.addi       s59, s56, #1
    v.cmp.gt     p1, v19, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s57, v28]             // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v2
    fence.acq_rel.device
    s.mov        s56, s59
    s.cmp.lt     s57, s56, s58
    br.nz        s57, x8dot_row_82
x8dot_done_81:
    v.splat      v2, s54
    v.movi       v19, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    v.extract    s55, v4, #3
    s.movz       s56, #96
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s57, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s57, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s57, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s57, v22, #4
    m.mma.dp.async.k32.e4m3 a3, v56, v48, s55
    mb.wait      s55
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s57, x8dot_done_83
    s.add        s58, s13, s24
    s.addi       s59, s54, #0
    s.addi       s60, s58, #96
    s.addi       s58, s28, #16640
x8dot_row_84:
    s.addi       s16, s20, #-96
    v.movi       v2, #0
    s.sub        s17, s16, s59
    s.add        s16, s60, s59
    v.splat      v19, s17
    s.shli       s17, s59, #4
    s.addi       s25, s59, #1
    v.cmp.gt     p1, v19, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s16, v31]             // index is in elements (ISA sec 9.1)
    s.add        s16, s58, s17
    s.movz       s17, #32
    v.st.b       [s16, #0], v2
    fence.acq_rel.device
    s.mov        s59, s25
    s.cmp.lt     s16, s59, s17
    br.nz        s16, x8dot_row_84
x8dot_done_83:
    v.splat      v2, s57
    v.movi       v19, #0
    mb.arm       s16, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s17, v4, #4
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s25, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s25, s16            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s25, s17                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s25, s16          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s16
    mb.arm       s17, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s25, v22, #5
    m.mma.dp.async.k32.e4m3 a4, v56, v48, s17
    mb.wait      s17
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s25, x8dot_done_85
    s.add        s26, s13, s24
    s.addi       s30, s54, #0
    s.addi       s31, s26, #96
    s.addi       s26, s28, #16640
x8dot_row_86:
    s.addi       s33, s20, #-96
    v.movi       v2, #0
    s.sub        s34, s33, s30
    s.add        s33, s31, s30
    v.splat      v19, s34
    s.shli       s34, s30, #4
    s.addi       s35, s30, #1
    v.cmp.gt     p1, v19, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s33, v24]             // index is in elements (ISA sec 9.1)
    s.add        s33, s26, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v2
    fence.acq_rel.device
    s.mov        s30, s35
    s.cmp.lt     s33, s30, s34
    br.nz        s33, x8dot_row_86
x8dot_done_85:
    v.splat      v2, s25
    v.movi       v19, #0
    mb.arm       s25, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s26, #0
    v.extract    s30, v4, #5
    s.movz       s31, #96
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s33, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s33, s25            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s33, s25          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s25
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v22, #6
    m.mma.dp.async.k32.e4m3 a5, v56, v48, s30
    mb.wait      s30
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s33, x8dot_done_87
    s.add        s34, s13, s24
    s.addi       s35, s26, #0
    s.addi       s36, s34, #96
    s.addi       s34, s28, #16640
x8dot_row_88:
    s.addi       s37, s20, #-96
    v.movi       v2, #0
    s.sub        s38, s37, s35
    s.add        s37, s36, s35
    v.splat      v19, s38
    s.shli       s38, s35, #4
    s.addi       s39, s35, #1
    v.cmp.gt     p1, v19, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s37, v32]             // index is in elements (ISA sec 9.1)
    s.add        s37, s34, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v2
    fence.acq_rel.device
    s.mov        s35, s39
    s.cmp.lt     s37, s35, s38
    br.nz        s37, x8dot_row_88
x8dot_done_87:
    v.splat      v2, s33
    v.movi       v19, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s34, v4, #6
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s35, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s35, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s35, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v22, #7
    m.mma.dp.async.k32.e4m3 a6, v56, v48, s31
    mb.wait      s31
    w.def        w0, #48, #8                     // v48..v55
    br.nz        s34, x8dot_done_89
    s.add        s35, s13, s24
    s.addi       s36, s26, #0
    s.addi       s26, s35, #96
    s.addi       s35, s28, #16640
x8dot_row_90:
    s.addi       s37, s20, #-96
    v.movi       v2, #0
    s.sub        s38, s37, s36
    s.add        s37, s26, s36
    v.splat      v19, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v19, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s37, v23]             // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v2
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_90
x8dot_done_89:
    v.splat      v2, s34
    v.movi       v19, #0
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s26, #0
    v.extract    s34, v4, #7
    s.movz       s35, #96
    v.cmp.ne     p1, v2, v19
    v.cmp.eq     p2, v2, v19
    s.mov        s36, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s36, s20            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s36, s20          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s20
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s35, s28, #19456
    s.movz       s36, #1
    m.mma.dp.async.k32.e4m3 a7, v56, v48, s34
    mb.wait      s34
    a.vread      v2, a0, s26
    s.addi       s26, s35, #64
    s.movz       s37, #2
    v.st.w       [s35, #0], v2
    a.vread      v2, a0, s36
    s.addi       s36, s35, #128
    s.movz       s38, #3
    s.addi       s39, s35, #192
    s.movz       s40, #4
    v.st.w       [s26, #0], v2
    a.vread      v2, a0, s37
    s.addi       s26, s35, #256
    s.movz       s37, #5
    v.st.w       [s36, #0], v2
    a.vread      v2, a0, s38
    s.addi       s36, s35, #320
    s.movz       s38, #6
    v.st.w       [s39, #0], v2
    a.vread      v2, a0, s40
    s.addi       s39, s35, #384
    s.movz       s40, #7
    v.st.w       [s26, #0], v2
    a.vread      v2, a0, s37
    s.addi       s26, s35, #448
    s.movz       s37, #8
    v.st.w       [s36, #0], v2
    a.vread      v2, a0, s38
    s.addi       s36, s35, #512
    s.movz       s38, #9
    v.st.w       [s39, #0], v2
    a.vread      v2, a0, s40
    s.addi       s39, s35, #576
    s.movz       s40, #10
    v.st.w       [s26, #0], v2
    a.vread      v2, a0, s37
    s.addi       s26, s35, #640
    s.movz       s37, #11
    v.st.w       [s36, #0], v2
    a.vread      v2, a0, s38
    s.addi       s36, s35, #704
    s.movz       s38, #12
    v.st.w       [s39, #0], v2
    a.vread      v2, a0, s40
    s.addi       s39, s35, #768
    s.movz       s40, #13
    v.st.w       [s26, #0], v2
    a.vread      v2, a0, s37
    s.addi       s26, s35, #832
    s.movz       s37, #14
    v.st.w       [s36, #0], v2
    a.vread      v2, a0, s38
    s.addi       s36, s35, #896
    s.movz       s38, #15
    s.addi       s41, s35, #960
    v.st.w       [s39, #0], v2
    a.vread      v2, a0, s40
    s.movz       s35, #0
    s.addi       s39, s28, #20480
    v.st.w       [s26, #0], v2
    a.vread      v2, a0, s37
    s.movz       s26, #1
    s.addi       s37, s39, #64
    v.st.w       [s36, #0], v2
    a.vread      v2, a0, s38
    s.movz       s36, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v2
    fence.acq_rel.device
    a.vread      v2, a1, s35
    s.movz       s35, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v2
    a.vread      v2, a1, s26
    s.movz       s26, #4
    v.st.w       [s37, #0], v2
    a.vread      v2, a1, s36
    s.addi       s36, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v2
    a.vread      v2, a1, s35
    s.addi       s35, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v2
    a.vread      v2, a1, s26
    s.addi       s26, s39, #384
    s.movz       s40, #7
    v.st.w       [s36, #0], v2
    a.vread      v2, a1, s37
    s.addi       s36, s39, #448
    s.movz       s37, #8
    v.st.w       [s35, #0], v2
    a.vread      v2, a1, s38
    s.addi       s35, s39, #512
    s.movz       s38, #9
    v.st.w       [s26, #0], v2
    a.vread      v2, a1, s40
    s.addi       s26, s39, #576
    s.movz       s40, #10
    v.st.w       [s36, #0], v2
    a.vread      v2, a1, s37
    s.addi       s36, s39, #640
    s.movz       s37, #11
    v.st.w       [s35, #0], v2
    a.vread      v2, a1, s38
    s.addi       s35, s39, #704
    s.movz       s38, #12
    v.st.w       [s26, #0], v2
    a.vread      v2, a1, s40
    s.addi       s26, s39, #768
    s.movz       s40, #13
    v.st.w       [s36, #0], v2
    a.vread      v2, a1, s37
    s.addi       s36, s39, #832
    s.movz       s37, #14
    v.st.w       [s35, #0], v2
    a.vread      v2, a1, s38
    s.addi       s35, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s26, #0], v2
    a.vread      v2, a1, s40
    s.movz       s26, #0
    s.addi       s39, s28, #21504
    v.st.w       [s36, #0], v2
    a.vread      v2, a1, s37
    s.movz       s36, #1
    s.addi       s37, s39, #64
    v.st.w       [s35, #0], v2
    a.vread      v2, a1, s38
    s.movz       s35, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v2
    fence.acq_rel.device
    a.vread      v2, a2, s26
    s.movz       s26, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v2
    a.vread      v2, a2, s36
    s.movz       s36, #4
    v.st.w       [s37, #0], v2
    a.vread      v2, a2, s35
    s.addi       s35, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v2
    a.vread      v2, a2, s26
    s.addi       s26, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v2
    a.vread      v2, a2, s36
    s.addi       s36, s39, #384
    s.movz       s40, #7
    v.st.w       [s35, #0], v2
    a.vread      v2, a2, s37
    s.addi       s35, s39, #448
    s.movz       s37, #8
    v.st.w       [s26, #0], v2
    a.vread      v2, a2, s38
    s.addi       s26, s39, #512
    s.movz       s38, #9
    v.st.w       [s36, #0], v2
    a.vread      v2, a2, s40
    s.addi       s36, s39, #576
    s.movz       s40, #10
    v.st.w       [s35, #0], v2
    a.vread      v2, a2, s37
    s.addi       s35, s39, #640
    s.movz       s37, #11
    v.st.w       [s26, #0], v2
    a.vread      v2, a2, s38
    s.addi       s26, s39, #704
    s.movz       s38, #12
    v.st.w       [s36, #0], v2
    a.vread      v2, a2, s40
    s.addi       s36, s39, #768
    s.movz       s40, #13
    v.st.w       [s35, #0], v2
    a.vread      v2, a2, s37
    s.addi       s35, s39, #832
    s.movz       s37, #14
    v.st.w       [s26, #0], v2
    a.vread      v2, a2, s38
    s.addi       s26, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s36, #0], v2
    a.vread      v2, a2, s40
    s.movz       s36, #0
    s.addi       s39, s28, #22528
    v.st.w       [s35, #0], v2
    a.vread      v2, a2, s37
    s.movz       s35, #1
    s.addi       s37, s39, #64
    v.st.w       [s26, #0], v2
    a.vread      v2, a2, s38
    s.movz       s26, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v2
    fence.acq_rel.device
    a.vread      v2, a3, s36
    s.movz       s36, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v2
    a.vread      v2, a3, s35
    s.movz       s35, #4
    v.st.w       [s37, #0], v2
    a.vread      v2, a3, s26
    s.addi       s26, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v2
    a.vread      v2, a3, s36
    s.addi       s36, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v2
    a.vread      v2, a3, s35
    s.addi       s35, s39, #384
    s.movz       s40, #7
    v.st.w       [s26, #0], v2
    a.vread      v2, a3, s37
    s.addi       s26, s39, #448
    s.movz       s37, #8
    v.st.w       [s36, #0], v2
    a.vread      v2, a3, s38
    s.addi       s36, s39, #512
    s.movz       s38, #9
    v.st.w       [s35, #0], v2
    a.vread      v2, a3, s40
    s.addi       s35, s39, #576
    s.movz       s40, #10
    v.st.w       [s26, #0], v2
    a.vread      v2, a3, s37
    s.addi       s26, s39, #640
    s.movz       s37, #11
    v.st.w       [s36, #0], v2
    a.vread      v2, a3, s38
    s.addi       s36, s39, #704
    s.movz       s38, #12
    v.st.w       [s35, #0], v2
    a.vread      v2, a3, s40
    s.addi       s35, s39, #768
    s.movz       s40, #13
    v.st.w       [s26, #0], v2
    a.vread      v2, a3, s37
    s.addi       s26, s39, #832
    s.movz       s37, #14
    v.st.w       [s36, #0], v2
    a.vread      v2, a3, s38
    s.addi       s36, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s35, #0], v2
    a.vread      v2, a3, s40
    s.movz       s35, #0
    s.addi       s39, s28, #23552
    v.st.w       [s26, #0], v2
    a.vread      v2, a3, s37
    s.movz       s26, #1
    s.addi       s37, s39, #64
    v.st.w       [s36, #0], v2
    a.vread      v2, a3, s38
    s.movz       s36, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v2
    fence.acq_rel.device
    a.vread      v2, a4, s35
    s.movz       s35, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v2
    a.vread      v2, a4, s26
    s.movz       s26, #4
    v.st.w       [s37, #0], v2
    a.vread      v2, a4, s36
    s.addi       s36, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v2
    a.vread      v2, a4, s35
    s.addi       s35, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v2
    a.vread      v2, a4, s26
    s.addi       s26, s39, #384
    s.movz       s40, #7
    v.st.w       [s36, #0], v2
    a.vread      v2, a4, s37
    s.addi       s36, s39, #448
    s.movz       s37, #8
    v.st.w       [s35, #0], v2
    a.vread      v2, a4, s38
    s.addi       s35, s39, #512
    s.movz       s38, #9
    v.st.w       [s26, #0], v2
    a.vread      v2, a4, s40
    s.addi       s26, s39, #576
    s.movz       s40, #10
    v.st.w       [s36, #0], v2
    a.vread      v2, a4, s37
    s.addi       s36, s39, #640
    s.movz       s37, #11
    v.st.w       [s35, #0], v2
    a.vread      v2, a4, s38
    s.addi       s35, s39, #704
    s.movz       s38, #12
    v.st.w       [s26, #0], v2
    a.vread      v2, a4, s40
    s.addi       s26, s39, #768
    s.movz       s40, #13
    v.st.w       [s36, #0], v2
    a.vread      v2, a4, s37
    s.addi       s36, s39, #832
    s.movz       s37, #14
    v.st.w       [s35, #0], v2
    a.vread      v2, a4, s38
    s.addi       s35, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s26, #0], v2
    a.vread      v2, a4, s40
    s.movz       s26, #0
    s.addi       s39, s28, #24576
    v.st.w       [s36, #0], v2
    a.vread      v2, a4, s37
    s.movz       s36, #1
    s.addi       s37, s39, #64
    v.st.w       [s35, #0], v2
    a.vread      v2, a4, s38
    s.movz       s35, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v2
    fence.acq_rel.device
    a.vread      v2, a5, s26
    s.movz       s26, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v2
    a.vread      v2, a5, s36
    s.movz       s36, #4
    v.st.w       [s37, #0], v2
    a.vread      v2, a5, s35
    s.addi       s35, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v2
    a.vread      v2, a5, s26
    s.addi       s26, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v2
    a.vread      v2, a5, s36
    s.addi       s36, s39, #384
    s.movz       s40, #7
    v.st.w       [s35, #0], v2
    a.vread      v2, a5, s37
    s.addi       s35, s39, #448
    s.movz       s37, #8
    v.st.w       [s26, #0], v2
    a.vread      v2, a5, s38
    s.addi       s26, s39, #512
    s.movz       s38, #9
    v.st.w       [s36, #0], v2
    a.vread      v2, a5, s40
    s.addi       s36, s39, #576
    s.movz       s40, #10
    v.st.w       [s35, #0], v2
    a.vread      v2, a5, s37
    s.addi       s35, s39, #640
    s.movz       s37, #11
    v.st.w       [s26, #0], v2
    a.vread      v2, a5, s38
    s.addi       s26, s39, #704
    s.movz       s38, #12
    v.st.w       [s36, #0], v2
    a.vread      v2, a5, s40
    s.addi       s36, s39, #768
    s.movz       s40, #13
    v.st.w       [s35, #0], v2
    a.vread      v2, a5, s37
    s.addi       s35, s39, #832
    s.movz       s37, #14
    v.st.w       [s26, #0], v2
    a.vread      v2, a5, s38
    s.addi       s26, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s36, #0], v2
    a.vread      v2, a5, s40
    s.movz       s36, #0
    s.addi       s39, s28, #25600
    v.st.w       [s35, #0], v2
    a.vread      v2, a5, s37
    s.movz       s35, #1
    s.addi       s37, s39, #64
    v.st.w       [s26, #0], v2
    a.vread      v2, a5, s38
    s.movz       s26, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v2
    fence.acq_rel.device
    a.vread      v2, a6, s36
    s.movz       s36, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v2
    a.vread      v2, a6, s35
    s.movz       s35, #4
    v.st.w       [s37, #0], v2
    a.vread      v2, a6, s26
    s.addi       s26, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v2
    a.vread      v2, a6, s36
    s.addi       s36, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v2
    a.vread      v2, a6, s35
    s.addi       s35, s39, #384
    s.movz       s40, #7
    v.st.w       [s26, #0], v2
    a.vread      v2, a6, s37
    s.addi       s26, s39, #448
    s.movz       s37, #8
    v.st.w       [s36, #0], v2
    a.vread      v2, a6, s38
    s.addi       s36, s39, #512
    s.movz       s38, #9
    v.st.w       [s35, #0], v2
    a.vread      v2, a6, s40
    s.addi       s35, s39, #576
    s.movz       s40, #10
    v.st.w       [s26, #0], v2
    a.vread      v2, a6, s37
    s.addi       s26, s39, #640
    s.movz       s37, #11
    v.st.w       [s36, #0], v2
    a.vread      v2, a6, s38
    s.addi       s36, s39, #704
    s.movz       s38, #12
    v.st.w       [s35, #0], v2
    a.vread      v2, a6, s40
    s.addi       s35, s39, #768
    s.movz       s40, #13
    v.st.w       [s26, #0], v2
    a.vread      v2, a6, s37
    s.addi       s26, s39, #832
    s.movz       s37, #14
    v.st.w       [s36, #0], v2
    a.vread      v2, a6, s38
    s.addi       s36, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s35, #0], v2
    a.vread      v2, a6, s40
    s.movz       s35, #0
    s.addi       s39, s28, #26624
    v.st.w       [s26, #0], v2
    a.vread      v2, a6, s37
    s.movz       s26, #1
    s.addi       s37, s39, #64
    v.st.w       [s36, #0], v2
    a.vread      v2, a6, s38
    s.movz       s36, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v2
    fence.acq_rel.device
    a.vread      v2, a7, s35
    s.movz       s35, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v2
    a.vread      v2, a7, s26
    s.movz       s26, #4
    v.st.w       [s37, #0], v2
    a.vread      v2, a7, s36
    s.addi       s36, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v2
    a.vread      v2, a7, s35
    s.addi       s35, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v2
    a.vread      v2, a7, s26
    s.addi       s26, s39, #384
    s.movz       s40, #7
    v.st.w       [s36, #0], v2
    a.vread      v2, a7, s37
    s.addi       s36, s39, #448
    s.movz       s37, #8
    v.st.w       [s35, #0], v2
    a.vread      v2, a7, s38
    s.addi       s35, s39, #512
    s.movz       s38, #9
    v.st.w       [s26, #0], v2
    a.vread      v2, a7, s40
    s.addi       s26, s39, #576
    s.movz       s40, #10
    v.st.w       [s36, #0], v2
    a.vread      v2, a7, s37
    s.addi       s36, s39, #640
    s.movz       s37, #11
    v.st.w       [s35, #0], v2
    a.vread      v2, a7, s38
    s.addi       s35, s39, #704
    s.movz       s38, #12
    v.st.w       [s26, #0], v2
    a.vread      v2, a7, s40
    s.addi       s26, s39, #768
    s.movz       s40, #13
    v.st.w       [s36, #0], v2
    a.vread      v2, a7, s37
    s.addi       s36, s39, #832
    s.movz       s37, #14
    v.st.w       [s35, #0], v2
    a.vread      v2, a7, s38
    s.addi       s35, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s26, #0], v2
    a.vread      v2, a7, s40
    s.addi       s26, s28, #19456
    s.addi       s39, s28, #0
    v.st.w       [s36, #0], v2
    a.vread      v2, a7, s37
    v.extract    s36, v33, #0
    s.addi       s37, s28, #27648
    v.splat      v4, s36
    s.addi       s36, s28, #19520
    v.st.w       [s35, #0], v2
    a.vread      v2, a7, s38
    s.addi       s35, s28, #64
    v.extract    s38, v33, #1
    v.splat      v19, s38
    s.addi       s38, s37, #64
    v.st.w       [s41, #0], v2
    fence.acq_rel.device
    s.addi       s40, s28, #19584
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #128
    v.ld.w       v20, [s39, #0]
    vf.mul       v22, v2, v4
    v.extract    s39, v33, #2
    v.splat      v2, s39
    s.addi       s39, s37, #128
    vf.mul       v4, v22, v21
    vf.add       v22, v20, v4
    v.st.w       [s37, #0], v22
    v.ld.w       v4, [s36, #0]
    s.addi       s36, s28, #19648
    v.ld.w       v20, [s35, #0]
    vf.mul       v22, v4, v19
    s.addi       s35, s28, #192
    vf.mul       v4, v22, v21
    vf.add       v19, v20, v4
    v.st.w       [s38, #0], v19
    v.extract    s38, v33, #3
    v.splat      v4, s38
    s.addi       s38, s37, #192
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #19712
    v.ld.w       v20, [s26, #0]
    vf.mul       v22, v19, v2
    s.addi       s26, s28, #256
    vf.mul       v2, v22, v21
    vf.add       v19, v20, v2
    v.st.w       [s39, #0], v19
    v.extract    s39, v33, #4
    v.splat      v2, s39
    s.addi       s39, s37, #256
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s28, #19776
    v.ld.w       v20, [s35, #0]
    vf.mul       v22, v19, v4
    s.addi       s35, s28, #320
    vf.mul       v4, v22, v21
    vf.add       v19, v20, v4
    v.st.w       [s38, #0], v19
    v.extract    s38, v33, #5
    v.splat      v4, s38
    s.addi       s38, s37, #320
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #19840
    v.ld.w       v20, [s26, #0]
    vf.mul       v22, v19, v2
    s.addi       s26, s28, #384
    vf.mul       v2, v22, v21
    vf.add       v19, v20, v2
    v.st.w       [s39, #0], v19
    v.extract    s39, v33, #6
    v.splat      v2, s39
    s.addi       s39, s37, #384
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s28, #19904
    v.ld.w       v20, [s35, #0]
    vf.mul       v22, v19, v4
    s.addi       s35, s28, #448
    vf.mul       v4, v22, v21
    vf.add       v19, v20, v4
    v.st.w       [s38, #0], v19
    v.extract    s38, v33, #7
    v.splat      v4, s38
    s.addi       s38, s37, #448
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #19968
    v.ld.w       v20, [s26, #0]
    vf.mul       v22, v19, v2
    s.addi       s26, s28, #512
    vf.mul       v2, v22, v21
    vf.add       v19, v20, v2
    v.st.w       [s39, #0], v19
    v.extract    s39, v33, #8
    v.splat      v2, s39
    s.addi       s39, s37, #512
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s28, #20032
    v.ld.w       v20, [s35, #0]
    vf.mul       v22, v19, v4
    s.addi       s35, s28, #576
    vf.mul       v4, v22, v21
    vf.add       v19, v20, v4
    v.st.w       [s38, #0], v19
    v.extract    s38, v33, #9
    v.splat      v4, s38
    s.addi       s38, s37, #576
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #20096
    v.ld.w       v20, [s26, #0]
    vf.mul       v22, v19, v2
    s.addi       s26, s28, #640
    vf.mul       v2, v22, v21
    vf.add       v19, v20, v2
    v.st.w       [s39, #0], v19
    v.extract    s39, v33, #10
    v.splat      v2, s39
    s.addi       s39, s37, #640
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s28, #20160
    v.ld.w       v20, [s35, #0]
    vf.mul       v22, v19, v4
    s.addi       s35, s28, #704
    vf.mul       v4, v22, v21
    vf.add       v19, v20, v4
    v.st.w       [s38, #0], v19
    v.extract    s38, v33, #11
    v.splat      v4, s38
    s.addi       s38, s37, #704
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #20224
    v.ld.w       v20, [s26, #0]
    vf.mul       v22, v19, v2
    s.addi       s26, s28, #768
    vf.mul       v2, v22, v21
    vf.add       v19, v20, v2
    v.st.w       [s39, #0], v19
    v.extract    s39, v33, #12
    v.splat      v2, s39
    s.addi       s39, s37, #768
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s28, #20288
    v.ld.w       v20, [s35, #0]
    vf.mul       v22, v19, v4
    s.addi       s35, s28, #832
    vf.mul       v4, v22, v21
    vf.add       v19, v20, v4
    v.st.w       [s38, #0], v19
    v.extract    s38, v33, #13
    v.splat      v4, s38
    s.addi       s38, s37, #832
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #20352
    v.ld.w       v20, [s26, #0]
    vf.mul       v22, v19, v2
    s.addi       s26, s28, #896
    vf.mul       v2, v22, v21
    vf.add       v19, v20, v2
    v.st.w       [s39, #0], v19
    v.extract    s39, v33, #14
    v.splat      v2, s39
    s.addi       s39, s37, #896
    s.addi       s41, s37, #960
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s28, #20416
    v.ld.w       v20, [s35, #0]
    vf.mul       v22, v19, v4
    s.addi       s35, s28, #960
    vf.mul       v4, v22, v21
    vf.add       v19, v20, v4
    v.st.w       [s38, #0], v19
    v.extract    s37, v33, #15
    v.splat      v4, s37
    s.addi       s37, s28, #20480
    v.ld.w       v19, [s40, #0]
    s.addi       s38, s28, #1024
    v.ld.w       v20, [s26, #0]
    vf.mul       v22, v19, v2
    v.extract    s26, v33, #0
    v.splat      v2, s26
    s.addi       s26, s28, #28672
    vf.mul       v19, v22, v21
    vf.add       v22, v20, v19
    v.st.w       [s39, #0], v22
    s.addi       s39, s28, #20544
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s28, #1088
    v.ld.w       v20, [s35, #0]
    vf.mul       v22, v19, v4
    v.extract    s35, v33, #1
    v.splat      v4, s35
    s.addi       s35, s26, #64
    vf.mul       v19, v22, v21
    vf.add       v21, v20, v19
    v.st.w       [s41, #0], v21
    fence.acq_rel.device
    s.addi       s40, s28, #20608
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s28, #1152
    v.ld.w       v20, [s38, #0]
    vf.mul       v21, v19, v2
    v.extract    s38, v33, #2
    v.splat      v2, s38
    s.addi       s38, s26, #128
    vf.mul       v19, v21, v25
    vf.add       v21, v20, v19
    v.st.w       [s26, #0], v21
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s28, #20672
    v.ld.w       v20, [s36, #0]
    vf.mul       v21, v19, v4
    s.addi       s36, s28, #1216
    vf.mul       v4, v21, v25
    vf.add       v19, v20, v4
    v.st.w       [s35, #0], v19
    v.extract    s35, v33, #3
    v.splat      v4, s35
    s.addi       s35, s26, #192
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #20736
    v.ld.w       v20, [s37, #0]
    vf.mul       v21, v19, v2
    s.addi       s37, s28, #1280
    vf.mul       v2, v21, v25
    vf.add       v19, v20, v2
    v.st.w       [s38, #0], v19
    v.extract    s38, v33, #4
    v.splat      v2, s38
    s.addi       s38, s26, #256
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s28, #20800
    v.ld.w       v20, [s36, #0]
    vf.mul       v21, v19, v4
    s.addi       s36, s28, #1344
    vf.mul       v4, v21, v25
    vf.add       v19, v20, v4
    v.st.w       [s35, #0], v19
    v.extract    s35, v33, #5
    v.splat      v4, s35
    s.addi       s35, s26, #320
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #20864
    v.ld.w       v20, [s37, #0]
    vf.mul       v21, v19, v2
    s.addi       s37, s28, #1408
    vf.mul       v2, v21, v25
    vf.add       v19, v20, v2
    v.st.w       [s38, #0], v19
    v.extract    s38, v33, #6
    v.splat      v2, s38
    s.addi       s38, s26, #384
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s28, #20928
    v.ld.w       v20, [s36, #0]
    vf.mul       v21, v19, v4
    s.addi       s36, s28, #1472
    vf.mul       v4, v21, v25
    vf.add       v19, v20, v4
    v.st.w       [s35, #0], v19
    v.extract    s35, v33, #7
    v.splat      v4, s35
    s.addi       s35, s26, #448
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #20992
    v.ld.w       v20, [s37, #0]
    vf.mul       v21, v19, v2
    s.addi       s37, s28, #1536
    vf.mul       v2, v21, v25
    vf.add       v19, v20, v2
    v.st.w       [s38, #0], v19
    v.extract    s38, v33, #8
    v.splat      v2, s38
    s.addi       s38, s26, #512
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s28, #21056
    v.ld.w       v20, [s36, #0]
    vf.mul       v21, v19, v4
    s.addi       s36, s28, #1600
    vf.mul       v4, v21, v25
    vf.add       v19, v20, v4
    v.st.w       [s35, #0], v19
    v.extract    s35, v33, #9
    v.splat      v4, s35
    s.addi       s35, s26, #576
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #21120
    v.ld.w       v20, [s37, #0]
    vf.mul       v21, v19, v2
    s.addi       s37, s28, #1664
    vf.mul       v2, v21, v25
    vf.add       v19, v20, v2
    v.st.w       [s38, #0], v19
    v.extract    s38, v33, #10
    v.splat      v2, s38
    s.addi       s38, s26, #640
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s28, #21184
    v.ld.w       v20, [s36, #0]
    vf.mul       v21, v19, v4
    s.addi       s36, s28, #1728
    vf.mul       v4, v21, v25
    vf.add       v19, v20, v4
    v.st.w       [s35, #0], v19
    v.extract    s35, v33, #11
    v.splat      v4, s35
    s.addi       s35, s26, #704
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #21248
    v.ld.w       v20, [s37, #0]
    vf.mul       v21, v19, v2
    s.addi       s37, s28, #1792
    vf.mul       v2, v21, v25
    vf.add       v19, v20, v2
    v.st.w       [s38, #0], v19
    v.extract    s38, v33, #12
    v.splat      v2, s38
    s.addi       s38, s26, #768
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s28, #21312
    v.ld.w       v20, [s36, #0]
    vf.mul       v21, v19, v4
    s.addi       s36, s28, #1856
    vf.mul       v4, v21, v25
    vf.add       v19, v20, v4
    v.st.w       [s35, #0], v19
    v.extract    s35, v33, #13
    v.splat      v4, s35
    s.addi       s35, s26, #832
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #21376
    v.ld.w       v20, [s37, #0]
    vf.mul       v21, v19, v2
    s.addi       s37, s28, #1920
    vf.mul       v2, v21, v25
    vf.add       v19, v20, v2
    v.st.w       [s38, #0], v19
    v.extract    s38, v33, #14
    v.splat      v2, s38
    s.addi       s38, s26, #896
    s.addi       s41, s26, #960
    v.ld.w       v19, [s39, #0]
    s.addi       s26, s28, #21440
    v.ld.w       v20, [s36, #0]
    vf.mul       v21, v19, v4
    s.addi       s36, s28, #1984
    vf.mul       v4, v21, v25
    vf.add       v19, v20, v4
    v.st.w       [s35, #0], v19
    v.extract    s35, v33, #15
    v.splat      v4, s35
    s.addi       s35, s28, #21504
    v.ld.w       v19, [s40, #0]
    s.addi       s39, s28, #2048
    v.ld.w       v20, [s37, #0]
    vf.mul       v21, v19, v2
    v.extract    s37, v33, #0
    v.splat      v2, s37
    s.addi       s37, s28, #29696
    vf.mul       v19, v21, v25
    vf.add       v21, v20, v19
    v.st.w       [s38, #0], v21
    s.addi       s38, s28, #21568
    v.ld.w       v19, [s26, #0]
    s.addi       s26, s28, #2112
    v.ld.w       v20, [s36, #0]
    vf.mul       v21, v19, v4
    v.extract    s36, v33, #1
    v.splat      v4, s36
    s.addi       s36, s37, #64
    vf.mul       v19, v21, v25
    vf.add       v21, v20, v19
    v.st.w       [s41, #0], v21
    fence.acq_rel.device
    s.addi       s40, s28, #21632
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s28, #2176
    v.ld.w       v20, [s39, #0]
    vf.mul       v21, v19, v2
    v.extract    s39, v33, #2
    v.splat      v2, s39
    s.addi       s39, s37, #128
    vf.mul       v19, v21, v12
    vf.add       v21, v20, v19
    v.st.w       [s37, #0], v21
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s28, #21696
    v.ld.w       v20, [s26, #0]
    vf.mul       v21, v19, v4
    s.addi       s26, s28, #2240
    vf.mul       v4, v21, v12
    vf.add       v19, v20, v4
    v.st.w       [s36, #0], v19
    v.extract    s36, v33, #3
    v.splat      v4, s36
    s.addi       s36, s37, #192
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #21760
    v.ld.w       v20, [s35, #0]
    vf.mul       v21, v19, v2
    s.addi       s35, s28, #2304
    vf.mul       v2, v21, v12
    vf.add       v19, v20, v2
    v.st.w       [s39, #0], v19
    v.extract    s39, v33, #4
    v.splat      v2, s39
    s.addi       s39, s37, #256
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s28, #21824
    v.ld.w       v20, [s26, #0]
    vf.mul       v21, v19, v4
    s.addi       s26, s28, #2368
    vf.mul       v4, v21, v12
    vf.add       v19, v20, v4
    v.st.w       [s36, #0], v19
    v.extract    s36, v33, #5
    v.splat      v4, s36
    s.addi       s36, s37, #320
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #21888
    v.ld.w       v20, [s35, #0]
    vf.mul       v21, v19, v2
    s.addi       s35, s28, #2432
    vf.mul       v2, v21, v12
    vf.add       v19, v20, v2
    v.st.w       [s39, #0], v19
    v.extract    s39, v33, #6
    v.splat      v2, s39
    s.addi       s39, s37, #384
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s28, #21952
    v.ld.w       v20, [s26, #0]
    vf.mul       v21, v19, v4
    s.addi       s26, s28, #2496
    vf.mul       v4, v21, v12
    vf.add       v19, v20, v4
    v.st.w       [s36, #0], v19
    v.extract    s36, v33, #7
    v.splat      v4, s36
    s.addi       s36, s37, #448
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #22016
    v.ld.w       v20, [s35, #0]
    vf.mul       v21, v19, v2
    s.addi       s35, s28, #2560
    vf.mul       v2, v21, v12
    vf.add       v19, v20, v2
    v.st.w       [s39, #0], v19
    v.extract    s39, v33, #8
    v.splat      v2, s39
    s.addi       s39, s37, #512
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s28, #22080
    v.ld.w       v20, [s26, #0]
    vf.mul       v21, v19, v4
    s.addi       s26, s28, #2624
    vf.mul       v4, v21, v12
    vf.add       v19, v20, v4
    v.st.w       [s36, #0], v19
    v.extract    s36, v33, #9
    v.splat      v4, s36
    s.addi       s36, s37, #576
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #22144
    v.ld.w       v20, [s35, #0]
    vf.mul       v21, v19, v2
    s.addi       s35, s28, #2688
    vf.mul       v2, v21, v12
    vf.add       v19, v20, v2
    v.st.w       [s39, #0], v19
    v.extract    s39, v33, #10
    v.splat      v2, s39
    s.addi       s39, s37, #640
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s28, #22208
    v.ld.w       v20, [s26, #0]
    vf.mul       v21, v19, v4
    s.addi       s26, s28, #2752
    vf.mul       v4, v21, v12
    vf.add       v19, v20, v4
    v.st.w       [s36, #0], v19
    v.extract    s36, v33, #11
    v.splat      v4, s36
    s.addi       s36, s37, #704
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #22272
    v.ld.w       v20, [s35, #0]
    vf.mul       v21, v19, v2
    s.addi       s35, s28, #2816
    vf.mul       v2, v21, v12
    vf.add       v19, v20, v2
    v.st.w       [s39, #0], v19
    v.extract    s39, v33, #12
    v.splat      v2, s39
    s.addi       s39, s37, #768
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s28, #22336
    v.ld.w       v20, [s26, #0]
    vf.mul       v21, v19, v4
    s.addi       s26, s28, #2880
    vf.mul       v4, v21, v12
    vf.add       v19, v20, v4
    v.st.w       [s36, #0], v19
    v.extract    s36, v33, #13
    v.splat      v4, s36
    s.addi       s36, s37, #832
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s28, #22400
    v.ld.w       v20, [s35, #0]
    vf.mul       v21, v19, v2
    s.addi       s35, s28, #2944
    vf.mul       v2, v21, v12
    vf.add       v19, v20, v2
    v.st.w       [s39, #0], v19
    v.extract    s39, v33, #14
    v.splat      v2, s39
    s.addi       s39, s37, #896
    s.addi       s41, s37, #960
    v.ld.w       v19, [s38, #0]
    s.addi       s37, s28, #22464
    v.ld.w       v20, [s26, #0]
    vf.mul       v21, v19, v4
    s.addi       s26, s28, #3008
    vf.mul       v4, v21, v12
    vf.add       v19, v20, v4
    v.st.w       [s36, #0], v19
    v.extract    s36, v33, #15
    v.splat      v4, s36
    s.addi       s36, s28, #22528
    v.ld.w       v19, [s40, #0]
    s.addi       s38, s28, #3072
    v.ld.w       v20, [s35, #0]
    vf.mul       v21, v19, v2
    v.extract    s35, v33, #0
    v.splat      v2, s35
    s.addi       s35, s28, #30720
    vf.mul       v19, v21, v12
    vf.add       v21, v20, v19
    v.st.w       [s39, #0], v21
    s.addi       s39, s28, #22592
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s28, #3136
    v.ld.w       v20, [s26, #0]
    vf.mul       v21, v19, v4
    v.extract    s26, v33, #1
    v.splat      v4, s26
    s.addi       s26, s35, #64
    vf.mul       v19, v21, v12
    vf.add       v12, v20, v19
    v.st.w       [s41, #0], v12
    fence.acq_rel.device
    s.addi       s40, s28, #22656
    v.ld.w       v12, [s36, #0]
    s.addi       s36, s28, #3200
    v.ld.w       v19, [s38, #0]
    vf.mul       v20, v12, v2
    v.extract    s38, v33, #2
    v.splat      v2, s38
    s.addi       s38, s35, #128
    vf.mul       v12, v20, v30
    vf.add       v20, v19, v12
    v.st.w       [s35, #0], v20
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #22720
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #3264
    vf.mul       v4, v20, v30
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #3
    v.splat      v4, s26
    s.addi       s26, s35, #192
    v.ld.w       v12, [s40, #0]
    s.addi       s40, s28, #22784
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s36, s28, #3328
    vf.mul       v2, v20, v30
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #4
    v.splat      v2, s38
    s.addi       s38, s35, #256
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #22848
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #3392
    vf.mul       v4, v20, v30
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #5
    v.splat      v4, s26
    s.addi       s26, s35, #320
    v.ld.w       v12, [s40, #0]
    s.addi       s40, s28, #22912
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s36, s28, #3456
    vf.mul       v2, v20, v30
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #6
    v.splat      v2, s38
    s.addi       s38, s35, #384
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #22976
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #3520
    vf.mul       v4, v20, v30
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #7
    v.splat      v4, s26
    s.addi       s26, s35, #448
    v.ld.w       v12, [s40, #0]
    s.addi       s40, s28, #23040
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s36, s28, #3584
    vf.mul       v2, v20, v30
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #8
    v.splat      v2, s38
    s.addi       s38, s35, #512
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #23104
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #3648
    vf.mul       v4, v20, v30
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #9
    v.splat      v4, s26
    s.addi       s26, s35, #576
    v.ld.w       v12, [s40, #0]
    s.addi       s40, s28, #23168
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s36, s28, #3712
    vf.mul       v2, v20, v30
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #10
    v.splat      v2, s38
    s.addi       s38, s35, #640
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #23232
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #3776
    vf.mul       v4, v20, v30
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #11
    v.splat      v4, s26
    s.addi       s26, s35, #704
    v.ld.w       v12, [s40, #0]
    s.addi       s40, s28, #23296
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s36, s28, #3840
    vf.mul       v2, v20, v30
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #12
    v.splat      v2, s38
    s.addi       s38, s35, #768
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #23360
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #3904
    vf.mul       v4, v20, v30
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #13
    v.splat      v4, s26
    s.addi       s26, s35, #832
    v.ld.w       v12, [s40, #0]
    s.addi       s40, s28, #23424
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s36, s28, #3968
    vf.mul       v2, v20, v30
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #14
    v.splat      v2, s38
    s.addi       s38, s35, #896
    s.addi       s41, s35, #960
    v.ld.w       v12, [s39, #0]
    s.addi       s35, s28, #23488
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #4032
    vf.mul       v4, v20, v30
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #15
    v.splat      v4, s26
    s.addi       s26, s28, #23552
    v.ld.w       v12, [s40, #0]
    s.addi       s39, s28, #4096
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    v.extract    s36, v33, #0
    v.splat      v2, s36
    s.addi       s36, s28, #31744
    vf.mul       v12, v20, v30
    vf.add       v20, v19, v12
    v.st.w       [s38, #0], v20
    s.addi       s38, s28, #23616
    v.ld.w       v12, [s35, #0]
    s.addi       s35, s28, #4160
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    v.extract    s37, v33, #1
    v.splat      v4, s37
    s.addi       s37, s36, #64
    vf.mul       v12, v20, v30
    vf.add       v20, v19, v12
    v.st.w       [s41, #0], v20
    fence.acq_rel.device
    s.addi       s40, s28, #23680
    v.ld.w       v12, [s26, #0]
    s.addi       s26, s28, #4224
    v.ld.w       v19, [s39, #0]
    vf.mul       v20, v12, v2
    v.extract    s39, v33, #2
    v.splat      v2, s39
    s.addi       s39, s36, #128
    vf.mul       v12, v20, v34
    vf.add       v20, v19, v12
    v.st.w       [s36, #0], v20
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #23744
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v4
    s.addi       s35, s28, #4288
    vf.mul       v4, v20, v34
    vf.add       v12, v19, v4
    v.st.w       [s37, #0], v12
    v.extract    s37, v33, #3
    v.splat      v4, s37
    s.addi       s37, s36, #192
    v.ld.w       v12, [s40, #0]
    s.addi       s40, s28, #23808
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v2
    s.addi       s26, s28, #4352
    vf.mul       v2, v20, v34
    vf.add       v12, v19, v2
    v.st.w       [s39, #0], v12
    v.extract    s39, v33, #4
    v.splat      v2, s39
    s.addi       s39, s36, #256
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #23872
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v4
    s.addi       s35, s28, #4416
    vf.mul       v4, v20, v34
    vf.add       v12, v19, v4
    v.st.w       [s37, #0], v12
    v.extract    s37, v33, #5
    v.splat      v4, s37
    s.addi       s37, s36, #320
    v.ld.w       v12, [s40, #0]
    s.addi       s40, s28, #23936
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v2
    s.addi       s26, s28, #4480
    vf.mul       v2, v20, v34
    vf.add       v12, v19, v2
    v.st.w       [s39, #0], v12
    v.extract    s39, v33, #6
    v.splat      v2, s39
    s.addi       s39, s36, #384
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #24000
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v4
    s.addi       s35, s28, #4544
    vf.mul       v4, v20, v34
    vf.add       v12, v19, v4
    v.st.w       [s37, #0], v12
    v.extract    s37, v33, #7
    v.splat      v4, s37
    s.addi       s37, s36, #448
    v.ld.w       v12, [s40, #0]
    s.addi       s40, s28, #24064
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v2
    s.addi       s26, s28, #4608
    vf.mul       v2, v20, v34
    vf.add       v12, v19, v2
    v.st.w       [s39, #0], v12
    v.extract    s39, v33, #8
    v.splat      v2, s39
    s.addi       s39, s36, #512
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #24128
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v4
    s.addi       s35, s28, #4672
    vf.mul       v4, v20, v34
    vf.add       v12, v19, v4
    v.st.w       [s37, #0], v12
    v.extract    s37, v33, #9
    v.splat      v4, s37
    s.addi       s37, s36, #576
    v.ld.w       v12, [s40, #0]
    s.addi       s40, s28, #24192
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v2
    s.addi       s26, s28, #4736
    vf.mul       v2, v20, v34
    vf.add       v12, v19, v2
    v.st.w       [s39, #0], v12
    v.extract    s39, v33, #10
    v.splat      v2, s39
    s.addi       s39, s36, #640
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #24256
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v4
    s.addi       s35, s28, #4800
    vf.mul       v4, v20, v34
    vf.add       v12, v19, v4
    v.st.w       [s37, #0], v12
    v.extract    s37, v33, #11
    v.splat      v4, s37
    s.addi       s37, s36, #704
    v.ld.w       v12, [s40, #0]
    s.addi       s40, s28, #24320
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v2
    s.addi       s26, s28, #4864
    vf.mul       v2, v20, v34
    vf.add       v12, v19, v2
    v.st.w       [s39, #0], v12
    v.extract    s39, v33, #12
    v.splat      v2, s39
    s.addi       s39, s36, #768
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #24384
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v4
    s.addi       s35, s28, #4928
    vf.mul       v4, v20, v34
    vf.add       v12, v19, v4
    v.st.w       [s37, #0], v12
    v.extract    s37, v33, #13
    v.splat      v4, s37
    s.addi       s37, s36, #832
    v.ld.w       v12, [s40, #0]
    s.addi       s40, s28, #24448
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v2
    s.addi       s26, s28, #4992
    vf.mul       v2, v20, v34
    vf.add       v12, v19, v2
    v.st.w       [s39, #0], v12
    v.extract    s39, v33, #14
    v.splat      v2, s39
    s.addi       s39, s36, #896
    s.addi       s41, s36, #960
    v.ld.w       v12, [s38, #0]
    s.addi       s36, s28, #24512
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v4
    s.addi       s35, s28, #5056
    vf.mul       v4, v20, v34
    vf.add       v12, v19, v4
    v.st.w       [s37, #0], v12
    v.extract    s37, v33, #15
    v.splat      v4, s37
    s.addi       s37, s28, #24576
    v.ld.w       v12, [s40, #0]
    s.addi       s38, s28, #5120
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v2
    v.extract    s26, v33, #0
    v.splat      v2, s26
    s.movz       s26, #32768
    vf.mul       v12, v20, v34
    s.add        s40, s28, s26
    vf.add       v20, v19, v12
    v.st.w       [s39, #0], v20
    s.addi       s26, s28, #24640
    v.ld.w       v12, [s36, #0]
    s.addi       s36, s28, #5184
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v4
    v.extract    s35, v33, #1
    v.splat      v4, s35
    s.addi       s35, s40, #64
    vf.mul       v12, v20, v34
    vf.add       v20, v19, v12
    v.st.w       [s41, #0], v20
    fence.acq_rel.device
    s.addi       s39, s28, #24704
    v.ld.w       v12, [s37, #0]
    s.addi       s37, s28, #5248
    v.ld.w       v19, [s38, #0]
    vf.mul       v20, v12, v2
    v.extract    s38, v33, #2
    v.splat      v2, s38
    s.addi       s38, s40, #128
    vf.mul       v12, v20, v35
    vf.add       v20, v19, v12
    v.st.w       [s40, #0], v20
    v.ld.w       v12, [s26, #0]
    s.addi       s26, s28, #24768
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v4
    s.addi       s36, s28, #5312
    vf.mul       v4, v20, v35
    vf.add       v12, v19, v4
    v.st.w       [s35, #0], v12
    v.extract    s35, v33, #3
    v.splat      v4, s35
    s.addi       s35, s40, #192
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #24832
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v2
    s.addi       s37, s28, #5376
    vf.mul       v2, v20, v35
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #4
    v.splat      v2, s38
    s.addi       s38, s40, #256
    v.ld.w       v12, [s26, #0]
    s.addi       s26, s28, #24896
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v4
    s.addi       s36, s28, #5440
    vf.mul       v4, v20, v35
    vf.add       v12, v19, v4
    v.st.w       [s35, #0], v12
    v.extract    s35, v33, #5
    v.splat      v4, s35
    s.addi       s35, s40, #320
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #24960
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v2
    s.addi       s37, s28, #5504
    vf.mul       v2, v20, v35
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #6
    v.splat      v2, s38
    s.addi       s38, s40, #384
    v.ld.w       v12, [s26, #0]
    s.addi       s26, s28, #25024
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v4
    s.addi       s36, s28, #5568
    vf.mul       v4, v20, v35
    vf.add       v12, v19, v4
    v.st.w       [s35, #0], v12
    v.extract    s35, v33, #7
    v.splat      v4, s35
    s.addi       s35, s40, #448
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #25088
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v2
    s.addi       s37, s28, #5632
    vf.mul       v2, v20, v35
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #8
    v.splat      v2, s38
    s.addi       s38, s40, #512
    v.ld.w       v12, [s26, #0]
    s.addi       s26, s28, #25152
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v4
    s.addi       s36, s28, #5696
    vf.mul       v4, v20, v35
    vf.add       v12, v19, v4
    v.st.w       [s35, #0], v12
    v.extract    s35, v33, #9
    v.splat      v4, s35
    s.addi       s35, s40, #576
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #25216
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v2
    s.addi       s37, s28, #5760
    vf.mul       v2, v20, v35
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #10
    v.splat      v2, s38
    s.addi       s38, s40, #640
    v.ld.w       v12, [s26, #0]
    s.addi       s26, s28, #25280
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v4
    s.addi       s36, s28, #5824
    vf.mul       v4, v20, v35
    vf.add       v12, v19, v4
    v.st.w       [s35, #0], v12
    v.extract    s35, v33, #11
    v.splat      v4, s35
    s.addi       s35, s40, #704
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #25344
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v2
    s.addi       s37, s28, #5888
    vf.mul       v2, v20, v35
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #12
    v.splat      v2, s38
    s.addi       s38, s40, #768
    v.ld.w       v12, [s26, #0]
    s.addi       s26, s28, #25408
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v4
    s.addi       s36, s28, #5952
    vf.mul       v4, v20, v35
    vf.add       v12, v19, v4
    v.st.w       [s35, #0], v12
    v.extract    s35, v33, #13
    v.splat      v4, s35
    s.addi       s35, s40, #832
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #25472
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v2
    s.addi       s37, s28, #6016
    vf.mul       v2, v20, v35
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #14
    v.splat      v2, s38
    s.addi       s38, s40, #896
    s.addi       s41, s40, #960
    v.ld.w       v12, [s26, #0]
    s.addi       s26, s28, #25536
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v4
    s.addi       s36, s28, #6080
    vf.mul       v4, v20, v35
    vf.add       v12, v19, v4
    v.st.w       [s35, #0], v12
    v.extract    s35, v33, #15
    v.splat      v4, s35
    s.addi       s35, s28, #25600
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #6144
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v2
    v.extract    s37, v33, #0
    v.splat      v2, s37
    s.movz       s37, #33792
    vf.mul       v12, v20, v35
    s.add        s40, s28, s37
    vf.add       v20, v19, v12
    v.st.w       [s38, #0], v20
    s.addi       s37, s28, #25664
    v.ld.w       v12, [s26, #0]
    s.addi       s26, s28, #6208
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v4
    v.extract    s36, v33, #1
    v.splat      v4, s36
    s.addi       s36, s40, #64
    vf.mul       v12, v20, v35
    vf.add       v20, v19, v12
    v.st.w       [s41, #0], v20
    fence.acq_rel.device
    s.addi       s38, s28, #25728
    v.ld.w       v12, [s35, #0]
    s.addi       s35, s28, #6272
    v.ld.w       v19, [s39, #0]
    vf.mul       v20, v12, v2
    v.extract    s39, v33, #2
    v.splat      v2, s39
    s.addi       s39, s40, #128
    vf.mul       v12, v20, v36
    vf.add       v20, v19, v12
    v.st.w       [s40, #0], v20
    v.ld.w       v12, [s37, #0]
    s.addi       s37, s28, #25792
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v4
    s.addi       s26, s28, #6336
    vf.mul       v4, v20, v36
    vf.add       v12, v19, v4
    v.st.w       [s36, #0], v12
    v.extract    s36, v33, #3
    v.splat      v4, s36
    s.addi       s36, s40, #192
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #25856
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v2
    s.addi       s35, s28, #6400
    vf.mul       v2, v20, v36
    vf.add       v12, v19, v2
    v.st.w       [s39, #0], v12
    v.extract    s39, v33, #4
    v.splat      v2, s39
    s.addi       s39, s40, #256
    v.ld.w       v12, [s37, #0]
    s.addi       s37, s28, #25920
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v4
    s.addi       s26, s28, #6464
    vf.mul       v4, v20, v36
    vf.add       v12, v19, v4
    v.st.w       [s36, #0], v12
    v.extract    s36, v33, #5
    v.splat      v4, s36
    s.addi       s36, s40, #320
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #25984
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v2
    s.addi       s35, s28, #6528
    vf.mul       v2, v20, v36
    vf.add       v12, v19, v2
    v.st.w       [s39, #0], v12
    v.extract    s39, v33, #6
    v.splat      v2, s39
    s.addi       s39, s40, #384
    v.ld.w       v12, [s37, #0]
    s.addi       s37, s28, #26048
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v4
    s.addi       s26, s28, #6592
    vf.mul       v4, v20, v36
    vf.add       v12, v19, v4
    v.st.w       [s36, #0], v12
    v.extract    s36, v33, #7
    v.splat      v4, s36
    s.addi       s36, s40, #448
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #26112
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v2
    s.addi       s35, s28, #6656
    vf.mul       v2, v20, v36
    vf.add       v12, v19, v2
    v.st.w       [s39, #0], v12
    v.extract    s39, v33, #8
    v.splat      v2, s39
    s.addi       s39, s40, #512
    v.ld.w       v12, [s37, #0]
    s.addi       s37, s28, #26176
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v4
    s.addi       s26, s28, #6720
    vf.mul       v4, v20, v36
    vf.add       v12, v19, v4
    v.st.w       [s36, #0], v12
    v.extract    s36, v33, #9
    v.splat      v4, s36
    s.addi       s36, s40, #576
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #26240
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v2
    s.addi       s35, s28, #6784
    vf.mul       v2, v20, v36
    vf.add       v12, v19, v2
    v.st.w       [s39, #0], v12
    v.extract    s39, v33, #10
    v.splat      v2, s39
    s.addi       s39, s40, #640
    v.ld.w       v12, [s37, #0]
    s.addi       s37, s28, #26304
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v4
    s.addi       s26, s28, #6848
    vf.mul       v4, v20, v36
    vf.add       v12, v19, v4
    v.st.w       [s36, #0], v12
    v.extract    s36, v33, #11
    v.splat      v4, s36
    s.addi       s36, s40, #704
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #26368
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v2
    s.addi       s35, s28, #6912
    vf.mul       v2, v20, v36
    vf.add       v12, v19, v2
    v.st.w       [s39, #0], v12
    v.extract    s39, v33, #12
    v.splat      v2, s39
    s.addi       s39, s40, #768
    v.ld.w       v12, [s37, #0]
    s.addi       s37, s28, #26432
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v4
    s.addi       s26, s28, #6976
    vf.mul       v4, v20, v36
    vf.add       v12, v19, v4
    v.st.w       [s36, #0], v12
    v.extract    s36, v33, #13
    v.splat      v4, s36
    s.addi       s36, s40, #832
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #26496
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v2
    s.addi       s35, s28, #7040
    vf.mul       v2, v20, v36
    vf.add       v12, v19, v2
    v.st.w       [s39, #0], v12
    v.extract    s39, v33, #14
    v.splat      v2, s39
    s.addi       s39, s40, #896
    s.addi       s41, s40, #960
    v.ld.w       v12, [s37, #0]
    s.addi       s37, s28, #26560
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v4
    s.addi       s26, s28, #7104
    vf.mul       v4, v20, v36
    vf.add       v12, v19, v4
    v.st.w       [s36, #0], v12
    v.extract    s36, v33, #15
    v.splat      v4, s36
    s.addi       s36, s28, #26624
    v.ld.w       v12, [s38, #0]
    s.addi       s38, s28, #7168
    v.ld.w       v19, [s35, #0]
    vf.mul       v20, v12, v2
    v.extract    s35, v33, #0
    v.splat      v2, s35
    s.movz       s35, #34816
    vf.mul       v12, v20, v36
    s.add        s40, s28, s35
    vf.add       v20, v19, v12
    v.st.w       [s39, #0], v20
    s.addi       s35, s28, #26688
    v.ld.w       v12, [s37, #0]
    s.addi       s37, s28, #7232
    v.ld.w       v19, [s26, #0]
    vf.mul       v20, v12, v4
    v.extract    s26, v33, #1
    v.splat      v4, s26
    s.addi       s26, s40, #64
    vf.mul       v12, v20, v36
    vf.add       v20, v19, v12
    v.st.w       [s41, #0], v20
    fence.acq_rel.device
    s.addi       s39, s28, #26752
    v.ld.w       v12, [s36, #0]
    s.addi       s36, s28, #7296
    v.ld.w       v19, [s38, #0]
    vf.mul       v20, v12, v2
    v.extract    s38, v33, #2
    v.splat      v2, s38
    s.addi       s38, s40, #128
    vf.mul       v12, v20, v37
    vf.add       v20, v19, v12
    v.st.w       [s40, #0], v20
    v.ld.w       v12, [s35, #0]
    s.addi       s35, s28, #26816
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #7360
    vf.mul       v4, v20, v37
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #3
    v.splat      v4, s26
    s.addi       s26, s40, #192
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #26880
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s36, s28, #7424
    vf.mul       v2, v20, v37
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #4
    v.splat      v2, s38
    s.addi       s38, s40, #256
    v.ld.w       v12, [s35, #0]
    s.addi       s35, s28, #26944
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #7488
    vf.mul       v4, v20, v37
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #5
    v.splat      v4, s26
    s.addi       s26, s40, #320
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #27008
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s36, s28, #7552
    vf.mul       v2, v20, v37
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #6
    v.splat      v2, s38
    s.addi       s38, s40, #384
    v.ld.w       v12, [s35, #0]
    s.addi       s35, s28, #27072
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #7616
    vf.mul       v4, v20, v37
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #7
    v.splat      v4, s26
    s.addi       s26, s40, #448
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #27136
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s36, s28, #7680
    vf.mul       v2, v20, v37
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #8
    v.splat      v2, s38
    s.addi       s38, s40, #512
    v.ld.w       v12, [s35, #0]
    s.addi       s35, s28, #27200
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #7744
    vf.mul       v4, v20, v37
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #9
    v.splat      v4, s26
    s.addi       s26, s40, #576
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #27264
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s36, s28, #7808
    vf.mul       v2, v20, v37
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #10
    v.splat      v2, s38
    s.addi       s38, s40, #640
    v.ld.w       v12, [s35, #0]
    s.addi       s35, s28, #27328
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #7872
    vf.mul       v4, v20, v37
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #11
    v.splat      v4, s26
    s.addi       s26, s40, #704
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #27392
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s36, s28, #7936
    vf.mul       v2, v20, v37
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #12
    v.splat      v2, s38
    s.addi       s38, s40, #768
    v.ld.w       v12, [s35, #0]
    s.addi       s35, s28, #27456
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #8000
    vf.mul       v4, v20, v37
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #13
    v.splat      v4, s26
    s.addi       s26, s40, #832
    v.ld.w       v12, [s39, #0]
    s.addi       s39, s28, #27520
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s36, s28, #8064
    s.addi       s41, s27, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    s.addi       s41, s27, #4                    // &ptr_carry_19[1] (a constant offset, x4)
    s.addi       s41, s27, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    vf.mul       v2, v20, v37
    s.addi       s41, s27, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    s.addi       s41, s27, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    s.addi       s41, s27, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    vf.add       v12, v19, v2
    s.addi       s41, s27, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    v.st.w       [s38, #0], v12
    v.extract    s38, v33, #14
    v.splat      v2, s38
    s.addi       s38, s40, #896
    s.addi       s41, s40, #960
    v.ld.w       v12, [s35, #0]
    s.addi       s35, s28, #27584
    v.ld.w       v19, [s37, #0]
    vf.mul       v20, v12, v4
    s.addi       s37, s28, #8128
    vf.mul       v4, v20, v37
    vf.add       v12, v19, v4
    v.st.w       [s26, #0], v12
    v.extract    s26, v33, #15
    v.splat      v4, s26
    s.addi       s26, s18, #128
    s.addi       s40, s26, #0
    v.ld.w       v12, [s39, #0]
    s.addi       s26, s24, #128
    s.addi       s39, s26, #0
    v.ld.w       v19, [s36, #0]
    vf.mul       v20, v12, v2
    s.addi       s26, s27, #4                    // &ptr_carry_17[1] (a constant offset, x4)
    s.addi       s36, s26, #0
    vf.mul       v2, v20, v37
    vf.add       v12, v19, v2
    v.st.w       [s38, #0], v12
    s.addi       s26, s28, #27648
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s28, #0
    v.ld.w       v12, [s37, #0]
    vf.mul       v19, v2, v4
    s.addi       s37, s28, #27712
    vf.mul       v2, v19, v37
    vf.add       v4, v12, v2
    v.st.w       [s41, #0], v4
    fence.acq_rel.device
    s.mov        s18, s40
    s.mov        s24, s39
    s.mov        s27, s36
    s.addi       s36, s28, #64
    s.addi       s38, s28, #27776
    s.addi       s39, s28, #128
    s.addi       s40, s28, #27840
    s.addi       s41, s28, #192
    s.addi       s42, s28, #27904
    s.addi       s43, s28, #256
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #27968
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #320
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #28032
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #384
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #28096
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #448
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #28160
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #512
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #28224
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #576
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #28288
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #640
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #28352
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #704
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #28416
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #768
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #28480
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #832
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #28544
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #896
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #28608
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #960
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #28672
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #1024
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #28736
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #1088
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #28800
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #1152
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #28864
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #1216
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #28928
    v.st.w       [s35, #0], v2
    fence.acq_rel.device
    s.addi       s35, s28, #1280
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #28992
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #1344
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #29056
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #1408
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #29120
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #1472
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #29184
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #1536
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #29248
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #1600
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #29312
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #1664
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #29376
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #1728
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #29440
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #1792
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #29504
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #1856
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #29568
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #1920
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #29632
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #1984
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #29696
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #2048
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #29760
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #2112
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #29824
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #2176
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #29888
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #2240
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #29952
    v.st.w       [s36, #0], v2
    fence.acq_rel.device
    s.addi       s36, s28, #2304
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #30016
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #2368
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #30080
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #2432
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #30144
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #2496
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #30208
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #2560
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #30272
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #2624
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #30336
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #2688
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #30400
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #2752
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #30464
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #2816
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #30528
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #2880
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #30592
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #2944
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #30656
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #3008
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #30720
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #3072
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #30784
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #3136
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #30848
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #3200
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #30912
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #3264
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #30976
    v.st.w       [s39, #0], v2
    fence.acq_rel.device
    s.addi       s39, s28, #3328
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #31040
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #3392
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #31104
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #3456
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #31168
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #3520
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #31232
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #3584
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #31296
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #3648
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #31360
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #3712
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #31424
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #3776
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #31488
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #3840
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #31552
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #3904
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #31616
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #3968
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #31680
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #4032
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #31744
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #4096
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #31808
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #4160
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #31872
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #4224
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #31936
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #4288
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #32000
    v.st.w       [s41, #0], v2
    fence.acq_rel.device
    s.addi       s41, s28, #4352
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #32064
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #4416
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #32128
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #4480
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #32192
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #4544
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #32256
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #4608
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #32320
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #4672
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #32384
    v.st.w       [s43, #0], v2
    s.addi       s43, s28, #4736
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #32448
    v.st.w       [s35, #0], v2
    s.addi       s35, s28, #4800
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s28, #32512
    v.st.w       [s36, #0], v2
    s.addi       s36, s28, #4864
    v.ld.w       v2, [s38, #0]
    s.addi       s38, s28, #32576
    v.st.w       [s39, #0], v2
    s.addi       s39, s28, #4928
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s28, #32640
    v.st.w       [s41, #0], v2
    s.addi       s41, s28, #4992
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s28, #32704
    v.st.w       [s43, #0], v2
    s.movz       s43, #32768
    s.add        s44, s28, s43
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s28, #5056
    v.st.w       [s35, #0], v2
    s.movz       s35, #32832
    s.add        s43, s28, s35
    v.ld.w       v2, [s37, #0]
    s.addi       s35, s28, #5120
    v.st.w       [s36, #0], v2
    s.movz       s36, #32896
    s.add        s37, s28, s36
    v.ld.w       v2, [s38, #0]
    s.addi       s36, s28, #5184
    v.st.w       [s39, #0], v2
    s.movz       s38, #32960
    s.add        s39, s28, s38
    v.ld.w       v2, [s40, #0]
    s.addi       s38, s28, #5248
    v.st.w       [s41, #0], v2
    s.movz       s40, #33024
    s.add        s41, s28, s40
    v.ld.w       v2, [s42, #0]
    s.addi       s40, s28, #5312
    v.st.w       [s26, #0], v2
    fence.acq_rel.device
    s.movz       s26, #33088
    s.add        s42, s28, s26
    v.ld.w       v2, [s44, #0]
    s.addi       s26, s28, #5376
    v.st.w       [s35, #0], v2
    s.movz       s35, #33152
    s.add        s44, s28, s35
    v.ld.w       v2, [s43, #0]
    s.addi       s35, s28, #5440
    v.st.w       [s36, #0], v2
    s.movz       s36, #33216
    s.add        s43, s28, s36
    v.ld.w       v2, [s37, #0]
    s.addi       s36, s28, #5504
    v.st.w       [s38, #0], v2
    s.movz       s37, #33280
    s.add        s38, s28, s37
    v.ld.w       v2, [s39, #0]
    s.addi       s37, s28, #5568
    v.st.w       [s40, #0], v2
    s.movz       s39, #33344
    s.add        s40, s28, s39
    v.ld.w       v2, [s41, #0]
    s.addi       s39, s28, #5632
    v.st.w       [s26, #0], v2
    s.movz       s26, #33408
    s.add        s41, s28, s26
    v.ld.w       v2, [s42, #0]
    s.addi       s26, s28, #5696
    v.st.w       [s35, #0], v2
    s.movz       s35, #33472
    s.add        s42, s28, s35
    v.ld.w       v2, [s44, #0]
    s.addi       s35, s28, #5760
    v.st.w       [s36, #0], v2
    s.movz       s36, #33536
    s.add        s44, s28, s36
    v.ld.w       v2, [s43, #0]
    s.addi       s36, s28, #5824
    v.st.w       [s37, #0], v2
    s.movz       s37, #33600
    s.add        s43, s28, s37
    v.ld.w       v2, [s38, #0]
    s.addi       s37, s28, #5888
    v.st.w       [s39, #0], v2
    s.movz       s38, #33664
    s.add        s39, s28, s38
    v.ld.w       v2, [s40, #0]
    s.addi       s38, s28, #5952
    v.st.w       [s26, #0], v2
    s.movz       s26, #33728
    s.add        s40, s28, s26
    v.ld.w       v2, [s41, #0]
    s.addi       s26, s28, #6016
    v.st.w       [s35, #0], v2
    s.movz       s35, #33792
    s.add        s41, s28, s35
    v.ld.w       v2, [s42, #0]
    s.addi       s35, s28, #6080
    v.st.w       [s36, #0], v2
    s.movz       s36, #33856
    s.add        s42, s28, s36
    v.ld.w       v2, [s44, #0]
    s.addi       s36, s28, #6144
    v.st.w       [s37, #0], v2
    s.movz       s37, #33920
    s.add        s44, s28, s37
    v.ld.w       v2, [s43, #0]
    s.addi       s37, s28, #6208
    v.st.w       [s38, #0], v2
    s.movz       s38, #33984
    s.add        s43, s28, s38
    v.ld.w       v2, [s39, #0]
    s.addi       s38, s28, #6272
    v.st.w       [s26, #0], v2
    s.movz       s26, #34048
    s.add        s39, s28, s26
    v.ld.w       v2, [s40, #0]
    s.addi       s26, s28, #6336
    v.st.w       [s35, #0], v2
    fence.acq_rel.device
    s.movz       s35, #34112
    s.add        s40, s28, s35
    v.ld.w       v2, [s41, #0]
    s.addi       s35, s28, #6400
    v.st.w       [s36, #0], v2
    s.movz       s36, #34176
    s.add        s41, s28, s36
    v.ld.w       v2, [s42, #0]
    s.addi       s36, s28, #6464
    v.st.w       [s37, #0], v2
    s.movz       s37, #34240
    s.add        s42, s28, s37
    v.ld.w       v2, [s44, #0]
    s.addi       s37, s28, #6528
    v.st.w       [s38, #0], v2
    s.movz       s38, #34304
    s.add        s44, s28, s38
    v.ld.w       v2, [s43, #0]
    s.addi       s38, s28, #6592
    v.st.w       [s26, #0], v2
    s.movz       s26, #34368
    s.add        s43, s28, s26
    v.ld.w       v2, [s39, #0]
    s.addi       s26, s28, #6656
    v.st.w       [s35, #0], v2
    s.movz       s35, #34432
    s.add        s39, s28, s35
    v.ld.w       v2, [s40, #0]
    s.addi       s35, s28, #6720
    v.st.w       [s36, #0], v2
    s.movz       s36, #34496
    s.add        s40, s28, s36
    v.ld.w       v2, [s41, #0]
    s.addi       s36, s28, #6784
    v.st.w       [s37, #0], v2
    s.movz       s37, #34560
    s.add        s41, s28, s37
    v.ld.w       v2, [s42, #0]
    s.addi       s37, s28, #6848
    v.st.w       [s38, #0], v2
    s.movz       s38, #34624
    s.add        s42, s28, s38
    v.ld.w       v2, [s44, #0]
    s.addi       s38, s28, #6912
    v.st.w       [s26, #0], v2
    s.movz       s26, #34688
    s.add        s44, s28, s26
    v.ld.w       v2, [s43, #0]
    s.addi       s26, s28, #6976
    v.st.w       [s35, #0], v2
    s.movz       s35, #34752
    s.add        s43, s28, s35
    v.ld.w       v2, [s39, #0]
    s.addi       s35, s28, #7040
    v.st.w       [s36, #0], v2
    s.movz       s36, #34816
    s.add        s39, s28, s36
    v.ld.w       v2, [s40, #0]
    s.addi       s36, s28, #7104
    v.st.w       [s37, #0], v2
    s.movz       s37, #34880
    s.add        s40, s28, s37
    v.ld.w       v2, [s41, #0]
    s.addi       s37, s28, #7168
    v.st.w       [s38, #0], v2
    s.movz       s38, #34944
    s.add        s41, s28, s38
    v.ld.w       v2, [s42, #0]
    s.addi       s38, s28, #7232
    v.st.w       [s26, #0], v2
    s.movz       s26, #35008
    s.add        s42, s28, s26
    v.ld.w       v2, [s44, #0]
    s.addi       s26, s28, #7296
    v.st.w       [s35, #0], v2
    s.movz       s35, #35072
    s.add        s44, s28, s35
    v.ld.w       v2, [s43, #0]
    s.addi       s35, s28, #7360
    v.st.w       [s36, #0], v2
    fence.acq_rel.device
    s.movz       s36, #35136
    s.add        s43, s28, s36
    v.ld.w       v2, [s39, #0]
    s.addi       s36, s28, #7424
    v.st.w       [s37, #0], v2
    s.movz       s37, #35200
    s.add        s39, s28, s37
    v.ld.w       v2, [s40, #0]
    s.addi       s37, s28, #7488
    v.st.w       [s38, #0], v2
    s.movz       s38, #35264
    s.add        s40, s28, s38
    v.ld.w       v2, [s41, #0]
    s.addi       s38, s28, #7552
    v.st.w       [s26, #0], v2
    s.movz       s26, #35328
    s.add        s41, s28, s26
    v.ld.w       v2, [s42, #0]
    s.addi       s26, s28, #7616
    v.st.w       [s35, #0], v2
    s.movz       s35, #35392
    s.add        s42, s28, s35
    v.ld.w       v2, [s44, #0]
    s.addi       s35, s28, #7680
    v.st.w       [s36, #0], v2
    s.movz       s36, #35456
    s.add        s44, s28, s36
    v.ld.w       v2, [s43, #0]
    s.addi       s36, s28, #7744
    v.st.w       [s37, #0], v2
    s.movz       s37, #35520
    s.add        s43, s28, s37
    v.ld.w       v2, [s39, #0]
    s.addi       s37, s28, #7808
    v.st.w       [s38, #0], v2
    s.movz       s38, #35584
    s.add        s39, s28, s38
    v.ld.w       v2, [s40, #0]
    s.addi       s38, s28, #7872
    v.st.w       [s26, #0], v2
    s.movz       s26, #35648
    s.add        s40, s28, s26
    v.ld.w       v2, [s41, #0]
    s.addi       s26, s28, #7936
    v.st.w       [s35, #0], v2
    s.movz       s35, #35712
    s.add        s41, s28, s35
    v.ld.w       v2, [s42, #0]
    s.addi       s35, s28, #8000
    v.st.w       [s36, #0], v2
    s.movz       s36, #35776
    s.add        s42, s28, s36
    v.ld.w       v2, [s44, #0]
    s.addi       s36, s28, #8064
    v.st.w       [s37, #0], v2
    s.addi       s37, s28, #8128
    v.ld.w       v2, [s43, #0]
    s.add        s43, s29, s10
    v.st.w       [s38, #0], v2
    s.movz       s38, #1
    v.ld.w       v2, [s39, #0]
    v.st.w       [s26, #0], v2
    v.ld.w       v2, [s40, #0]
    v.st.w       [s35, #0], v2
    v.ld.w       v2, [s41, #0]
    v.st.w       [s36, #0], v2
    v.ld.w       v2, [s42, #0]
    v.st.w       [s37, #0], v2
    fence.acq_rel.device
    s.mov        s29, s43
    br.nz        s38, for_25
endfor_26:
    s.addi       s2, s28, #0
    s.mul        s5, s8, s4
    v.ld.w       v0, [s2, #0]
    s.movz       s2, #0
    s.muli       s4, s1, #2
    s.add        s6, s2, s1                      // the tile origin
    s.mul        s7, s5, s23
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s6
    s.add        s6, s2, s5                      // the tile origin
    s.add        s8, s2, s3                      // the tile origin
    s.muli       s2, s7, #2
    v.splat      v3, s6
    v.splat      v4, s10
    v.add        v5, v1, v2
    v.splat      v2, s8
    s.add        s7, s2, s4
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v2
    s.add        s8, s19, s7
    vf.cvt.f32.bf16 v2, v0
    p.and        p3, p1, p2
    s.addi       s7, s28, #64
    s.muli       s9, s23, #2
    s.addi       s10, s6, #1
    @p3 v.st.h       [s8, #0], v2
    v.splat      v0, s10
    s.addi       s8, s28, #128
    s.muli       s10, s9, #1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.addi       s11, s1, #16
    s.addi       s12, s1, #32
    s.add        s13, s10, s2
    s.addi       s10, s1, #48
    s.add        s14, s13, s4
    s.addi       s13, s1, #64
    s.add        s15, s19, s14
    s.addi       s14, s1, #80
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s1, #96
    s.addi       s18, s1, #112
    v.iota       v2                              // arange(0, VLEN)
    s.muli       s1, s9, #2
    v.splat      v3, s5
    v.add        v5, v3, v2
    s.addi       s5, s6, #2
    s.add        s21, s1, s2
    v.splat      v2, s5
    s.add        s1, s21, s4
    s.addi       s5, s28, #192
    v.cmp.lt     p1, v2, v4
    s.add        s21, s19, s1
    p.and        p4, p1, p2
    s.muli       s1, s9, #3
    vf.cvt.f32.bf16 v2, v0
    s.addi       s22, s6, #3
    s.addi       s23, s28, #256
    v.splat      v0, s22
    s.add        s22, s1, s2
    @p3 v.st.h       [s15, #0], v2
    s.add        s1, s22, s4
    v.cmp.lt     p1, v0, v4
    s.add        s15, s19, s1
    p.and        p3, p1, p2
    s.muli       s1, s9, #4
    s.addi       s22, s6, #4
    s.addi       s24, s28, #320
    v.splat      v0, s22
    s.muli       s22, s9, #5
    s.add        s26, s1, s2
    s.add        s1, s26, s4
    v.ld.w       v2, [s8, #0]
    s.add        s8, s19, s1
    s.addi       s1, s6, #5
    s.add        s26, s22, s2
    v.splat      v3, s1
    s.add        s1, s26, s4
    s.addi       s22, s28, #384
    s.add        s26, s19, s1
    vf.cvt.f32.bf16 v5, v2
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.muli       s1, s9, #6
    s.add        s21, s1, s2
    s.add        s1, s21, s4
    s.add        s21, s19, s1
    v.ld.w       v0, [s5, #0]
    s.addi       s1, s6, #6
    v.splat      v2, s1
    s.addi       s1, s28, #448
    vf.cvt.f32.bf16 v5, v0
    @p3 v.st.h       [s15, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.muli       s5, s9, #7
    s.add        s15, s5, s2
    s.add        s5, s15, s4
    s.add        s15, s19, s5
    v.ld.w       v0, [s23, #0]
    s.addi       s5, s6, #7
    v.splat      v3, s5
    s.addi       s5, s28, #512
    vf.cvt.f32.bf16 v5, v0
    @p4 v.st.h       [s8, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.muli       s8, s9, #8
    s.add        s23, s8, s2
    s.add        s8, s23, s4
    s.add        s23, s19, s8
    v.ld.w       v0, [s24, #0]
    s.addi       s8, s6, #8
    v.splat      v2, s8
    s.addi       s8, s28, #576
    vf.cvt.f32.bf16 v5, v0
    @p3 v.st.h       [s26, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.muli       s24, s9, #9
    s.add        s26, s24, s2
    s.add        s24, s26, s4
    s.add        s26, s19, s24
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s6, #9
    v.splat      v3, s22
    s.addi       s22, s28, #640
    vf.cvt.f32.bf16 v5, v0
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.muli       s21, s9, #10
    s.add        s24, s21, s2
    s.add        s21, s24, s4
    s.add        s24, s19, s21
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s6, #10
    v.splat      v2, s1
    s.addi       s1, s28, #704
    vf.cvt.f32.bf16 v5, v0
    @p3 v.st.h       [s15, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.muli       s15, s9, #11
    s.add        s21, s15, s2
    s.add        s15, s21, s4
    s.add        s21, s19, s15
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s6, #11
    v.splat      v3, s5
    s.addi       s5, s28, #768
    vf.cvt.f32.bf16 v5, v0
    @p4 v.st.h       [s23, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.muli       s15, s9, #12
    s.add        s23, s15, s2
    s.add        s15, s23, s4
    s.add        s23, s19, s15
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s6, #12
    v.splat      v2, s8
    s.addi       s8, s28, #832
    vf.cvt.f32.bf16 v5, v0
    @p3 v.st.h       [s26, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.muli       s15, s9, #13
    s.add        s26, s15, s2
    s.add        s15, s26, s4
    s.add        s26, s19, s15
    v.ld.w       v0, [s22, #0]
    s.addi       s15, s6, #13
    v.splat      v3, s15
    s.addi       s15, s28, #896
    vf.cvt.f32.bf16 v5, v0
    @p4 v.st.h       [s24, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.muli       s22, s9, #14
    s.add        s24, s22, s2
    s.add        s22, s24, s4
    s.add        s24, s19, s22
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s6, #14
    v.splat      v2, s1
    s.addi       s1, s28, #960
    vf.cvt.f32.bf16 v5, v0
    @p3 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.muli       s21, s9, #15
    s.add        s22, s21, s2
    s.add        s21, s22, s4
    s.addi       s4, s6, #15
    s.add        s22, s19, s21
    v.splat      v0, s4
    v.ld.w       v3, [s5, #0]
    s.addi       s4, s28, #1024
    vf.cvt.f32.bf16 v5, v3
    s.movz       s5, #0
    v.splat      v3, s6
    @p4 v.st.h       [s23, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s21, s5, s11                    // the tile origin
    s.muli       s23, s11, #2
    v.splat      v2, s21
    s.add        s11, s5, s3                     // the tile origin
    v.add        v5, v1, v2
    s.add        s5, s2, s23
    s.add        s21, s19, s5
    v.ld.w       v2, [s8, #0]
    v.splat      v6, s11
    vf.cvt.f32.bf16 v7, v2
    s.addi       s5, s28, #1088
    s.muli       s8, s9, #1
    @p3 v.st.h       [s26, #0], v7
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    v.cmp.lt     p1, v3, v4
    s.addi       s11, s6, #1
    s.add        s26, s8, s2
    s.add        s8, s26, s23
    s.add        s26, s19, s8
    v.ld.w       v0, [s15, #0]
    v.splat      v2, s11
    vf.cvt.f32.bf16 v3, v0
    s.addi       s8, s28, #1152
    s.muli       s11, s9, #2
    @p4 v.st.h       [s24, #0], v3
    v.cmp.lt     p2, v5, v6
    p.and        p4, p1, p2
    s.addi       s15, s6, #2
    s.add        s24, s11, s2
    s.add        s11, s24, s23
    s.add        s24, s19, s11
    v.ld.w       v0, [s1, #0]
    v.splat      v3, s15
    vf.cvt.f32.bf16 v5, v0
    s.addi       s1, s28, #1216
    s.muli       s11, s9, #3
    @p3 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s15, s6, #3
    s.add        s22, s11, s2
    s.add        s11, s22, s23
    s.add        s22, s19, s11
    v.ld.w       v0, [s4, #0]
    v.splat      v2, s15
    vf.cvt.f32.bf16 v5, v0
    s.addi       s4, s28, #1280
    s.muli       s11, s9, #4
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    s.addi       s15, s6, #4
    s.add        s21, s11, s2
    v.splat      v0, s15
    s.add        s11, s21, s23
    s.addi       s15, s28, #1344
    s.add        s21, s19, s11
    v.ld.w       v3, [s5, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s5, s9, #5
    @p3 v.st.h       [s26, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s11, s6, #5
    s.add        s26, s5, s2
    v.splat      v2, s11
    s.add        s5, s26, s23
    s.addi       s11, s28, #1408
    s.add        s26, s19, s5
    v.ld.w       v3, [s8, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s5, s9, #6
    @p4 v.st.h       [s24, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s8, s6, #6
    s.add        s24, s5, s2
    v.splat      v0, s8
    s.add        s5, s24, s23
    s.addi       s8, s28, #1472
    s.add        s24, s19, s5
    v.ld.w       v3, [s1, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #7
    @p3 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s5, s6, #7
    s.add        s22, s1, s2
    v.splat      v2, s5
    s.add        s1, s22, s23
    s.addi       s5, s28, #1536
    s.add        s22, s19, s1
    v.ld.w       v3, [s4, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #8
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s4, s6, #8
    s.add        s21, s1, s2
    v.splat      v0, s4
    s.add        s1, s21, s23
    s.addi       s4, s28, #1600
    s.add        s21, s19, s1
    v.ld.w       v3, [s15, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #9
    @p3 v.st.h       [s26, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s15, s6, #9
    s.add        s26, s1, s2
    v.splat      v2, s15
    s.add        s1, s26, s23
    s.addi       s15, s28, #1664
    s.add        s26, s19, s1
    v.ld.w       v3, [s11, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #10
    @p4 v.st.h       [s24, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s11, s6, #10
    s.add        s24, s1, s2
    v.splat      v0, s11
    s.add        s1, s24, s23
    s.addi       s11, s28, #1728
    s.add        s24, s19, s1
    v.ld.w       v3, [s8, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #11
    @p3 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s8, s6, #11
    s.add        s22, s1, s2
    v.splat      v2, s8
    s.add        s1, s22, s23
    s.addi       s8, s28, #1792
    s.add        s22, s19, s1
    v.ld.w       v3, [s5, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #12
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s5, s6, #12
    s.add        s21, s1, s2
    v.splat      v0, s5
    s.add        s1, s21, s23
    s.addi       s5, s28, #1856
    s.add        s21, s19, s1
    v.ld.w       v3, [s4, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #13
    @p3 v.st.h       [s26, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s4, s6, #13
    s.add        s26, s1, s2
    v.splat      v2, s4
    s.add        s1, s26, s23
    s.addi       s4, s28, #1920
    s.add        s26, s19, s1
    v.ld.w       v3, [s15, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #14
    @p4 v.st.h       [s24, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.addi       s15, s6, #14
    s.add        s24, s1, s2
    v.splat      v0, s15
    s.add        s1, s24, s23
    s.addi       s15, s28, #1984
    s.add        s24, s19, s1
    v.ld.w       v3, [s11, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #15
    @p3 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s11, s6, #15
    s.add        s22, s1, s2
    v.splat      v2, s11
    s.add        s1, s22, s23
    s.addi       s11, s28, #2048
    s.add        s22, s19, s1
    v.ld.w       v3, [s8, #0]
    vf.cvt.f32.bf16 v5, v3
    s.movz       s1, #0
    s.muli       s8, s12, #2
    s.add        s23, s1, s12                    // the tile origin
    v.splat      v3, s6
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    v.splat      v0, s23
    s.add        s12, s1, s3                     // the tile origin
    s.add        s1, s2, s8
    v.add        v5, v1, v0
    s.add        s21, s19, s1
    v.ld.w       v0, [s5, #0]
    v.splat      v6, s12
    vf.cvt.f32.bf16 v7, v0
    s.addi       s1, s28, #2112
    s.muli       s5, s9, #1
    @p3 v.st.h       [s26, #0], v7
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    v.cmp.lt     p1, v3, v4
    s.addi       s12, s6, #1
    s.add        s23, s5, s2
    s.add        s5, s23, s8
    s.add        s23, s19, s5
    v.ld.w       v0, [s4, #0]
    v.splat      v2, s12
    vf.cvt.f32.bf16 v3, v0
    s.addi       s4, s28, #2176
    s.muli       s5, s9, #2
    @p4 v.st.h       [s24, #0], v3
    v.cmp.lt     p2, v5, v6
    p.and        p4, p1, p2
    s.addi       s12, s6, #2
    s.add        s24, s5, s2
    s.add        s5, s24, s8
    s.add        s24, s19, s5
    v.ld.w       v0, [s15, #0]
    v.splat      v3, s12
    vf.cvt.f32.bf16 v5, v0
    s.addi       s5, s28, #2240
    s.muli       s12, s9, #3
    @p3 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s15, s6, #3
    s.add        s22, s12, s2
    s.add        s12, s22, s8
    s.add        s22, s19, s12
    v.ld.w       v0, [s11, #0]
    v.splat      v2, s15
    vf.cvt.f32.bf16 v5, v0
    s.addi       s11, s28, #2304
    s.muli       s12, s9, #4
    s.addi       s15, s6, #4
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    s.add        s21, s12, s2
    v.splat      v0, s15
    s.add        s12, s21, s8
    s.addi       s15, s28, #2368
    s.add        s21, s19, s12
    v.ld.w       v3, [s1, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #5
    s.addi       s12, s6, #5
    v.splat      v3, s12
    @p3 v.st.h       [s23, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.add        s12, s1, s2
    s.addi       s1, s28, #2432
    s.add        s23, s12, s8
    s.add        s12, s19, s23
    v.ld.w       v2, [s4, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s4, s9, #6
    s.addi       s23, s6, #6
    v.splat      v2, s23
    @p4 v.st.h       [s24, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.add        s23, s4, s2
    s.addi       s4, s28, #2496
    s.add        s24, s23, s8
    s.add        s23, s19, s24
    v.ld.w       v0, [s5, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s5, s9, #7
    s.addi       s24, s6, #7
    v.splat      v0, s24
    @p3 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.add        s22, s5, s2
    s.addi       s5, s28, #2560
    s.add        s24, s22, s8
    s.add        s22, s19, s24
    v.ld.w       v3, [s11, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s11, s9, #8
    s.addi       s24, s6, #8
    v.splat      v3, s24
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s21, s11, s2
    s.addi       s11, s28, #2624
    s.add        s24, s21, s8
    s.add        s21, s19, s24
    v.ld.w       v2, [s15, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s15, s9, #9
    s.addi       s24, s6, #9
    v.splat      v2, s24
    @p3 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.add        s12, s15, s2
    s.addi       s15, s28, #2688
    s.add        s24, s12, s8
    s.add        s12, s19, s24
    v.ld.w       v0, [s1, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s1, s9, #10
    s.addi       s24, s6, #10
    v.splat      v0, s24
    @p4 v.st.h       [s23, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    s.add        s23, s1, s2
    s.addi       s1, s28, #2752
    s.add        s24, s23, s8
    s.add        s23, s19, s24
    v.ld.w       v3, [s4, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s4, s9, #11
    s.addi       s24, s6, #11
    v.splat      v3, s24
    @p3 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.add        s22, s4, s2
    s.addi       s4, s28, #2816
    s.add        s24, s22, s8
    s.add        s22, s19, s24
    v.ld.w       v2, [s5, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s5, s9, #12
    s.addi       s24, s6, #12
    v.splat      v2, s24
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.add        s21, s5, s2
    s.addi       s5, s28, #2880
    s.add        s24, s21, s8
    s.add        s21, s19, s24
    v.ld.w       v0, [s11, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s11, s9, #13
    s.addi       s24, s6, #13
    v.splat      v0, s24
    @p3 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.add        s12, s11, s2
    s.addi       s11, s28, #2944
    s.add        s24, s12, s8
    s.add        s12, s19, s24
    v.ld.w       v3, [s15, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s15, s9, #14
    s.addi       s24, s6, #14
    v.splat      v3, s24
    @p4 v.st.h       [s23, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s23, s15, s2
    s.addi       s15, s28, #3008
    s.add        s24, s23, s8
    s.add        s23, s19, s24
    v.ld.w       v2, [s1, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s1, s9, #15
    s.addi       s24, s6, #15
    v.splat      v2, s24
    @p3 v.st.h       [s22, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.add        s22, s1, s2
    s.addi       s1, s28, #3072
    s.add        s24, s22, s8
    s.add        s8, s19, s24
    v.ld.w       v0, [s4, #0]
    vf.cvt.f32.bf16 v5, v0
    s.movz       s4, #0
    s.muli       s22, s10, #2
    s.add        s24, s4, s10                    // the tile origin
    v.splat      v0, s6
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    v.splat      v3, s24
    s.add        s10, s4, s3                     // the tile origin
    s.add        s4, s2, s22
    v.add        v5, v1, v3
    s.add        s21, s19, s4
    v.ld.w       v3, [s5, #0]
    v.splat      v6, s10
    vf.cvt.f32.bf16 v7, v3
    s.addi       s4, s28, #3136
    s.muli       s5, s9, #1
    @p3 v.st.h       [s12, #0], v7
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    v.cmp.lt     p1, v0, v4
    s.addi       s10, s6, #1
    s.add        s12, s5, s2
    s.add        s5, s12, s22
    s.add        s12, s19, s5
    v.ld.w       v0, [s11, #0]
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v0
    s.addi       s5, s28, #3200
    s.muli       s10, s9, #2
    @p4 v.st.h       [s23, #0], v3
    v.cmp.lt     p2, v5, v6
    p.and        p4, p1, p2
    s.addi       s11, s6, #2
    s.add        s23, s10, s2
    s.add        s10, s23, s22
    s.add        s23, s19, s10
    v.ld.w       v0, [s15, #0]
    v.splat      v3, s11
    vf.cvt.f32.bf16 v5, v0
    s.addi       s10, s28, #3264
    s.muli       s11, s9, #3
    @p3 v.st.h       [s8, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s8, s6, #3
    s.add        s15, s11, s2
    s.add        s11, s15, s22
    s.add        s15, s19, s11
    v.ld.w       v0, [s1, #0]
    v.splat      v2, s8
    vf.cvt.f32.bf16 v5, v0
    s.addi       s1, s28, #3328
    s.muli       s8, s9, #4
    s.addi       s11, s6, #4
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    s.add        s21, s8, s2
    v.splat      v0, s11
    s.add        s8, s21, s22
    s.addi       s11, s28, #3392
    s.add        s21, s19, s8
    v.ld.w       v3, [s4, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s4, s9, #5
    s.addi       s8, s6, #5
    v.splat      v3, s8
    @p3 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.add        s8, s4, s2
    s.addi       s4, s28, #3456
    s.add        s12, s8, s22
    s.add        s8, s19, s12
    v.ld.w       v2, [s5, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s5, s9, #6
    s.addi       s12, s6, #6
    v.splat      v2, s12
    @p4 v.st.h       [s23, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.add        s12, s5, s2
    s.addi       s5, s28, #3520
    s.add        s23, s12, s22
    s.add        s12, s19, s23
    v.ld.w       v0, [s10, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s10, s9, #7
    s.addi       s23, s6, #7
    v.splat      v0, s23
    @p3 v.st.h       [s15, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.add        s15, s10, s2
    s.addi       s10, s28, #3584
    s.add        s23, s15, s22
    s.add        s15, s19, s23
    v.ld.w       v3, [s1, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #8
    s.addi       s23, s6, #8
    v.splat      v3, s23
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s21, s1, s2
    s.addi       s1, s28, #3648
    s.add        s23, s21, s22
    s.add        s21, s19, s23
    v.ld.w       v2, [s11, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s11, s9, #9
    s.addi       s23, s6, #9
    v.splat      v2, s23
    @p3 v.st.h       [s8, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.add        s8, s11, s2
    s.addi       s11, s28, #3712
    s.add        s23, s8, s22
    s.add        s8, s19, s23
    v.ld.w       v0, [s4, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s4, s9, #10
    s.addi       s23, s6, #10
    v.splat      v0, s23
    @p4 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    s.add        s12, s4, s2
    s.addi       s4, s28, #3776
    s.add        s23, s12, s22
    s.add        s12, s19, s23
    v.ld.w       v3, [s5, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s5, s9, #11
    s.addi       s23, s6, #11
    v.splat      v3, s23
    @p3 v.st.h       [s15, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.add        s15, s5, s2
    s.addi       s5, s28, #3840
    s.add        s23, s15, s22
    s.add        s15, s19, s23
    v.ld.w       v2, [s10, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s10, s9, #12
    s.addi       s23, s6, #12
    v.splat      v2, s23
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.add        s21, s10, s2
    s.addi       s10, s28, #3904
    s.add        s23, s21, s22
    s.add        s21, s19, s23
    v.ld.w       v0, [s1, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s1, s9, #13
    s.addi       s23, s6, #13
    v.splat      v0, s23
    @p3 v.st.h       [s8, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.add        s8, s1, s2
    s.addi       s1, s28, #3968
    s.add        s23, s8, s22
    s.add        s8, s19, s23
    v.ld.w       v3, [s11, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s11, s9, #14
    s.addi       s23, s6, #14
    v.splat      v3, s23
    @p4 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s12, s11, s2
    s.addi       s11, s28, #4032
    s.add        s23, s12, s22
    s.add        s12, s19, s23
    v.ld.w       v2, [s4, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s4, s9, #15
    s.addi       s23, s6, #15
    v.splat      v2, s23
    @p3 v.st.h       [s15, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.add        s15, s4, s2
    s.addi       s4, s28, #4096
    s.add        s23, s15, s22
    s.add        s15, s19, s23
    v.ld.w       v0, [s5, #0]
    vf.cvt.f32.bf16 v5, v0
    s.movz       s5, #0
    s.muli       s22, s13, #2
    s.add        s23, s5, s13                    // the tile origin
    v.splat      v0, s6
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    v.splat      v3, s23
    s.add        s13, s5, s3                     // the tile origin
    s.add        s5, s2, s22
    v.add        v5, v1, v3
    s.add        s21, s19, s5
    v.ld.w       v3, [s10, #0]
    v.splat      v6, s13
    vf.cvt.f32.bf16 v7, v3
    s.addi       s5, s28, #4160
    s.muli       s10, s9, #1
    @p3 v.st.h       [s8, #0], v7
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    v.cmp.lt     p1, v0, v4
    s.addi       s8, s6, #1
    s.add        s13, s10, s2
    s.add        s10, s13, s22
    s.add        s13, s19, s10
    v.ld.w       v0, [s1, #0]
    v.splat      v2, s8
    vf.cvt.f32.bf16 v3, v0
    s.addi       s1, s28, #4224
    s.muli       s8, s9, #2
    @p4 v.st.h       [s12, #0], v3
    v.cmp.lt     p2, v5, v6
    p.and        p4, p1, p2
    s.addi       s10, s6, #2
    s.add        s12, s8, s2
    s.add        s8, s12, s22
    s.add        s12, s19, s8
    v.ld.w       v0, [s11, #0]
    v.splat      v3, s10
    vf.cvt.f32.bf16 v5, v0
    s.addi       s8, s28, #4288
    s.muli       s10, s9, #3
    @p3 v.st.h       [s15, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s11, s6, #3
    s.add        s15, s10, s2
    s.add        s10, s15, s22
    s.add        s15, s19, s10
    v.ld.w       v0, [s4, #0]
    v.splat      v2, s11
    vf.cvt.f32.bf16 v5, v0
    s.addi       s4, s28, #4352
    s.muli       s10, s9, #4
    s.addi       s11, s6, #4
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    s.add        s21, s10, s2
    v.splat      v0, s11
    s.add        s10, s21, s22
    s.addi       s11, s28, #4416
    s.add        s21, s19, s10
    v.ld.w       v3, [s5, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s5, s9, #5
    s.addi       s10, s6, #5
    v.splat      v3, s10
    @p3 v.st.h       [s13, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.add        s10, s5, s2
    s.addi       s5, s28, #4480
    s.add        s13, s10, s22
    s.add        s10, s19, s13
    v.ld.w       v2, [s1, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s1, s9, #6
    s.addi       s13, s6, #6
    v.splat      v2, s13
    @p4 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.add        s12, s1, s2
    s.addi       s1, s28, #4544
    s.add        s13, s12, s22
    s.add        s12, s19, s13
    v.ld.w       v0, [s8, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s8, s9, #7
    s.addi       s13, s6, #7
    v.splat      v0, s13
    @p3 v.st.h       [s15, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.add        s13, s8, s2
    s.addi       s8, s28, #4608
    s.add        s15, s13, s22
    s.add        s13, s19, s15
    v.ld.w       v3, [s4, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s4, s9, #8
    s.addi       s15, s6, #8
    v.splat      v3, s15
    @p4 v.st.h       [s21, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s15, s4, s2
    s.addi       s4, s28, #4672
    s.add        s21, s15, s22
    s.add        s15, s19, s21
    v.ld.w       v2, [s11, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s11, s9, #9
    s.addi       s21, s6, #9
    v.splat      v2, s21
    @p3 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.add        s10, s11, s2
    s.addi       s11, s28, #4736
    s.add        s21, s10, s22
    s.add        s10, s19, s21
    v.ld.w       v0, [s5, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s5, s9, #10
    s.addi       s21, s6, #10
    v.splat      v0, s21
    @p4 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    s.add        s12, s5, s2
    s.addi       s5, s28, #4800
    s.add        s21, s12, s22
    s.add        s12, s19, s21
    v.ld.w       v3, [s1, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #11
    s.addi       s21, s6, #11
    v.splat      v3, s21
    @p3 v.st.h       [s13, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.add        s13, s1, s2
    s.addi       s1, s28, #4864
    s.add        s21, s13, s22
    s.add        s13, s19, s21
    v.ld.w       v2, [s8, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s8, s9, #12
    s.addi       s21, s6, #12
    v.splat      v2, s21
    @p4 v.st.h       [s15, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.add        s15, s8, s2
    s.addi       s8, s28, #4928
    s.add        s21, s15, s22
    s.add        s15, s19, s21
    v.ld.w       v0, [s4, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s4, s9, #13
    s.addi       s21, s6, #13
    v.splat      v0, s21
    @p3 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.add        s10, s4, s2
    s.addi       s4, s28, #4992
    s.add        s21, s10, s22
    s.add        s10, s19, s21
    v.ld.w       v3, [s11, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s11, s9, #14
    s.addi       s21, s6, #14
    v.splat      v3, s21
    @p4 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s12, s11, s2
    s.addi       s11, s28, #5056
    s.add        s21, s12, s22
    s.add        s12, s19, s21
    v.ld.w       v2, [s5, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s5, s9, #15
    s.addi       s21, s6, #15
    v.splat      v2, s21
    @p3 v.st.h       [s13, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.add        s13, s5, s2
    s.addi       s5, s28, #5120
    s.add        s21, s13, s22
    s.add        s13, s19, s21
    v.ld.w       v0, [s1, #0]
    vf.cvt.f32.bf16 v5, v0
    s.movz       s1, #0
    s.muli       s21, s14, #2
    s.add        s22, s1, s14                    // the tile origin
    v.splat      v0, s6
    @p4 v.st.h       [s15, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    v.splat      v3, s22
    s.add        s14, s1, s3                     // the tile origin
    s.add        s1, s2, s21
    v.add        v5, v1, v3
    s.add        s15, s19, s1
    v.ld.w       v3, [s8, #0]
    v.splat      v6, s14
    vf.cvt.f32.bf16 v7, v3
    s.addi       s1, s28, #5184
    s.muli       s8, s9, #1
    @p3 v.st.h       [s10, #0], v7
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    v.cmp.lt     p1, v0, v4
    s.addi       s10, s6, #1
    s.add        s14, s8, s2
    s.add        s8, s14, s21
    s.add        s14, s19, s8
    v.ld.w       v0, [s4, #0]
    v.splat      v2, s10
    vf.cvt.f32.bf16 v3, v0
    s.addi       s4, s28, #5248
    s.muli       s8, s9, #2
    @p4 v.st.h       [s12, #0], v3
    v.cmp.lt     p2, v5, v6
    p.and        p4, p1, p2
    s.addi       s10, s6, #2
    s.add        s12, s8, s2
    s.add        s8, s12, s21
    s.add        s12, s19, s8
    v.ld.w       v0, [s11, #0]
    v.splat      v3, s10
    vf.cvt.f32.bf16 v5, v0
    s.addi       s8, s28, #5312
    s.muli       s10, s9, #3
    @p3 v.st.h       [s13, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s11, s6, #3
    s.add        s13, s10, s2
    s.add        s10, s13, s21
    s.add        s13, s19, s10
    v.ld.w       v0, [s5, #0]
    v.splat      v2, s11
    vf.cvt.f32.bf16 v5, v0
    s.addi       s5, s28, #5376
    s.muli       s10, s9, #4
    s.addi       s11, s6, #4
    @p4 v.st.h       [s15, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    s.add        s15, s10, s2
    v.splat      v0, s11
    s.add        s10, s15, s21
    s.addi       s11, s28, #5440
    s.add        s15, s19, s10
    v.ld.w       v3, [s1, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #5
    s.addi       s10, s6, #5
    v.splat      v3, s10
    @p3 v.st.h       [s14, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.add        s10, s1, s2
    s.addi       s1, s28, #5504
    s.add        s14, s10, s21
    s.add        s10, s19, s14
    v.ld.w       v2, [s4, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s4, s9, #6
    s.addi       s14, s6, #6
    v.splat      v2, s14
    @p4 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.add        s12, s4, s2
    s.addi       s4, s28, #5568
    s.add        s14, s12, s21
    s.add        s12, s19, s14
    v.ld.w       v0, [s8, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s8, s9, #7
    s.addi       s14, s6, #7
    v.splat      v0, s14
    @p3 v.st.h       [s13, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.add        s13, s8, s2
    s.addi       s8, s28, #5632
    s.add        s14, s13, s21
    s.add        s13, s19, s14
    v.ld.w       v3, [s5, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s5, s9, #8
    s.addi       s14, s6, #8
    v.splat      v3, s14
    @p4 v.st.h       [s15, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s14, s5, s2
    s.addi       s5, s28, #5696
    s.add        s15, s14, s21
    s.add        s14, s19, s15
    v.ld.w       v2, [s11, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s11, s9, #9
    s.addi       s15, s6, #9
    v.splat      v2, s15
    @p3 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.add        s10, s11, s2
    s.addi       s11, s28, #5760
    s.add        s15, s10, s21
    s.add        s10, s19, s15
    v.ld.w       v0, [s1, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s1, s9, #10
    s.addi       s15, s6, #10
    v.splat      v0, s15
    @p4 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    s.add        s12, s1, s2
    s.addi       s1, s28, #5824
    s.add        s15, s12, s21
    s.add        s12, s19, s15
    v.ld.w       v3, [s4, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s4, s9, #11
    s.addi       s15, s6, #11
    v.splat      v3, s15
    @p3 v.st.h       [s13, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.add        s13, s4, s2
    s.addi       s4, s28, #5888
    s.add        s15, s13, s21
    s.add        s13, s19, s15
    v.ld.w       v2, [s8, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s8, s9, #12
    s.addi       s15, s6, #12
    v.splat      v2, s15
    @p4 v.st.h       [s14, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.add        s14, s8, s2
    s.addi       s8, s28, #5952
    s.add        s15, s14, s21
    s.add        s14, s19, s15
    v.ld.w       v0, [s5, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s5, s9, #13
    s.addi       s15, s6, #13
    v.splat      v0, s15
    @p3 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.add        s10, s5, s2
    s.addi       s5, s28, #6016
    s.add        s15, s10, s21
    s.add        s10, s19, s15
    v.ld.w       v3, [s11, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s11, s9, #14
    s.addi       s15, s6, #14
    v.splat      v3, s15
    @p4 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s12, s11, s2
    s.addi       s11, s28, #6080
    s.add        s15, s12, s21
    s.add        s12, s19, s15
    v.ld.w       v2, [s1, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s1, s9, #15
    s.addi       s15, s6, #15
    v.splat      v2, s15
    @p3 v.st.h       [s13, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.add        s13, s1, s2
    s.addi       s1, s28, #6144
    s.add        s15, s13, s21
    s.add        s13, s19, s15
    v.ld.w       v0, [s4, #0]
    vf.cvt.f32.bf16 v5, v0
    s.movz       s4, #0
    s.muli       s15, s7, #2
    s.add        s21, s4, s7                     // the tile origin
    v.splat      v0, s6
    @p4 v.st.h       [s14, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    v.splat      v3, s21
    s.add        s7, s4, s3                      // the tile origin
    s.add        s4, s2, s15
    v.add        v5, v1, v3
    s.add        s14, s19, s4
    v.ld.w       v3, [s8, #0]
    v.splat      v6, s7
    vf.cvt.f32.bf16 v7, v3
    s.addi       s4, s28, #6208
    s.muli       s7, s9, #1
    @p3 v.st.h       [s10, #0], v7
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    v.cmp.lt     p1, v0, v4
    s.addi       s8, s6, #1
    s.add        s10, s7, s2
    s.add        s7, s10, s15
    s.add        s10, s19, s7
    v.ld.w       v0, [s5, #0]
    v.splat      v2, s8
    vf.cvt.f32.bf16 v3, v0
    s.addi       s5, s28, #6272
    s.muli       s7, s9, #2
    @p4 v.st.h       [s12, #0], v3
    v.cmp.lt     p2, v5, v6
    p.and        p4, p1, p2
    s.addi       s8, s6, #2
    s.add        s12, s7, s2
    s.add        s7, s12, s15
    s.add        s12, s19, s7
    v.ld.w       v0, [s11, #0]
    v.splat      v3, s8
    vf.cvt.f32.bf16 v5, v0
    s.addi       s7, s28, #6336
    s.muli       s8, s9, #3
    @p3 v.st.h       [s13, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s11, s6, #3
    s.add        s13, s8, s2
    s.add        s8, s13, s15
    s.add        s13, s19, s8
    v.ld.w       v0, [s1, #0]
    v.splat      v2, s11
    vf.cvt.f32.bf16 v5, v0
    s.addi       s1, s28, #6400
    s.muli       s8, s9, #4
    s.addi       s11, s6, #4
    @p4 v.st.h       [s14, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    s.add        s14, s8, s2
    v.splat      v0, s11
    s.add        s8, s14, s15
    s.addi       s11, s28, #6464
    s.add        s14, s19, s8
    v.ld.w       v3, [s4, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s4, s9, #5
    s.addi       s8, s6, #5
    v.splat      v3, s8
    @p3 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.add        s8, s4, s2
    s.addi       s4, s28, #6528
    s.add        s10, s8, s15
    s.add        s8, s19, s10
    v.ld.w       v2, [s5, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s5, s9, #6
    s.addi       s10, s6, #6
    v.splat      v2, s10
    @p4 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.add        s10, s5, s2
    s.addi       s5, s28, #6592
    s.add        s12, s10, s15
    s.add        s10, s19, s12
    v.ld.w       v0, [s7, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s7, s9, #7
    s.addi       s12, s6, #7
    v.splat      v0, s12
    @p3 v.st.h       [s13, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.add        s12, s7, s2
    s.addi       s7, s28, #6656
    s.add        s13, s12, s15
    s.add        s12, s19, s13
    v.ld.w       v3, [s1, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s1, s9, #8
    s.addi       s13, s6, #8
    v.splat      v3, s13
    @p4 v.st.h       [s14, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s13, s1, s2
    s.addi       s1, s28, #6720
    s.add        s14, s13, s15
    s.add        s13, s19, s14
    v.ld.w       v2, [s11, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s11, s9, #9
    s.addi       s14, s6, #9
    v.splat      v2, s14
    @p3 v.st.h       [s8, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.add        s8, s11, s2
    s.addi       s11, s28, #6784
    s.add        s14, s8, s15
    s.add        s8, s19, s14
    v.ld.w       v0, [s4, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s4, s9, #10
    s.addi       s14, s6, #10
    v.splat      v0, s14
    @p4 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    s.add        s10, s4, s2
    s.addi       s4, s28, #6848
    s.add        s14, s10, s15
    s.add        s10, s19, s14
    v.ld.w       v3, [s5, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s5, s9, #11
    s.addi       s14, s6, #11
    v.splat      v3, s14
    @p3 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.add        s12, s5, s2
    s.addi       s5, s28, #6912
    s.add        s14, s12, s15
    s.add        s12, s19, s14
    v.ld.w       v2, [s7, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s7, s9, #12
    s.addi       s14, s6, #12
    v.splat      v2, s14
    @p4 v.st.h       [s13, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.add        s13, s7, s2
    s.addi       s7, s28, #6976
    s.add        s14, s13, s15
    s.add        s13, s19, s14
    v.ld.w       v0, [s1, #0]
    vf.cvt.f32.bf16 v5, v0
    s.muli       s1, s9, #13
    s.addi       s14, s6, #13
    v.splat      v0, s14
    @p3 v.st.h       [s8, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    s.add        s8, s1, s2
    s.addi       s1, s28, #7040
    s.add        s14, s8, s15
    s.add        s8, s19, s14
    v.ld.w       v3, [s11, #0]
    vf.cvt.f32.bf16 v5, v3
    s.muli       s11, s9, #14
    s.addi       s14, s6, #14
    v.splat      v3, s14
    @p4 v.st.h       [s10, #0], v5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s10, s11, s2
    s.addi       s11, s28, #7104
    s.add        s14, s10, s15
    s.add        s10, s19, s14
    v.ld.w       v2, [s4, #0]
    vf.cvt.f32.bf16 v5, v2
    s.muli       s4, s9, #15
    s.addi       s14, s6, #15
    v.splat      v2, s14
    @p3 v.st.h       [s12, #0], v5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.add        s12, s4, s2
    s.addi       s4, s28, #7168
    s.add        s14, s12, s15
    s.add        s12, s19, s14
    v.ld.w       v0, [s5, #0]
    vf.cvt.f32.bf16 v5, v0
    s.movz       s5, #0
    s.muli       s14, s18, #2
    s.add        s15, s5, s18                    // the tile origin
    v.splat      v0, s6
    @p4 v.st.h       [s13, #0], v5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    v.splat      v3, s15
    s.add        s13, s5, s3                     // the tile origin
    s.add        s3, s2, s14
    v.add        v5, v1, v3
    s.add        s5, s19, s3
    v.ld.w       v1, [s7, #0]
    v.splat      v3, s13
    vf.cvt.f32.bf16 v6, v1
    s.addi       s3, s28, #7232
    s.muli       s7, s9, #1
    @p3 v.st.h       [s8, #0], v6
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    v.cmp.lt     p1, v0, v4
    s.addi       s8, s6, #1
    s.add        s13, s7, s2
    s.add        s7, s13, s14
    s.add        s13, s19, s7
    v.ld.w       v0, [s1, #0]
    v.splat      v1, s8
    vf.cvt.f32.bf16 v2, v0
    s.addi       s1, s28, #7296
    s.muli       s7, s9, #2
    @p4 v.st.h       [s10, #0], v2
    v.cmp.lt     p2, v5, v3
    p.and        p4, p1, p2
    s.addi       s8, s6, #2
    s.add        s10, s7, s2
    s.add        s7, s10, s14
    s.add        s10, s19, s7
    v.ld.w       v0, [s11, #0]
    v.splat      v2, s8
    vf.cvt.f32.bf16 v3, v0
    s.addi       s7, s28, #7360
    s.muli       s8, s9, #3
    @p3 v.st.h       [s12, #0], v3
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s11, s6, #3
    s.add        s12, s8, s2
    s.add        s8, s12, s14
    s.add        s12, s19, s8
    v.ld.w       v0, [s4, #0]
    v.splat      v1, s11
    vf.cvt.f32.bf16 v3, v0
    s.addi       s4, s28, #7424
    s.muli       s8, s9, #4
    s.addi       s11, s6, #4
    @p4 v.st.h       [s5, #0], v3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s5, s8, s2
    v.splat      v0, s11
    s.add        s8, s5, s14
    s.addi       s5, s28, #7488
    s.add        s11, s19, s8
    v.ld.w       v2, [s3, #0]
    vf.cvt.f32.bf16 v3, v2
    s.muli       s3, s9, #5
    s.addi       s8, s6, #5
    v.splat      v2, s8
    @p3 v.st.h       [s13, #0], v3
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.add        s8, s3, s2
    s.addi       s3, s28, #7552
    s.add        s13, s8, s14
    s.add        s8, s19, s13
    v.ld.w       v1, [s1, #0]
    vf.cvt.f32.bf16 v3, v1
    s.muli       s1, s9, #6
    s.addi       s13, s6, #6
    v.splat      v1, s13
    @p4 v.st.h       [s10, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.add        s10, s1, s2
    s.addi       s1, s28, #7616
    s.add        s13, s10, s14
    s.add        s10, s19, s13
    v.ld.w       v0, [s7, #0]
    vf.cvt.f32.bf16 v3, v0
    s.muli       s7, s9, #7
    s.addi       s13, s6, #7
    v.splat      v0, s13
    @p3 v.st.h       [s12, #0], v3
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.add        s12, s7, s2
    s.addi       s7, s28, #7680
    s.add        s13, s12, s14
    s.add        s12, s19, s13
    v.ld.w       v2, [s4, #0]
    vf.cvt.f32.bf16 v3, v2
    s.muli       s4, s9, #8
    s.addi       s13, s6, #8
    v.splat      v2, s13
    @p4 v.st.h       [s11, #0], v3
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    s.add        s11, s4, s2
    s.addi       s4, s28, #7744
    s.add        s13, s11, s14
    s.add        s11, s19, s13
    v.ld.w       v1, [s5, #0]
    vf.cvt.f32.bf16 v3, v1
    s.muli       s5, s9, #9
    s.addi       s13, s6, #9
    v.splat      v1, s13
    @p3 v.st.h       [s8, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.add        s8, s5, s2
    s.addi       s5, s28, #7808
    s.add        s13, s8, s14
    s.add        s8, s19, s13
    v.ld.w       v0, [s3, #0]
    vf.cvt.f32.bf16 v3, v0
    s.muli       s3, s9, #10
    s.addi       s13, s6, #10
    v.splat      v0, s13
    @p4 v.st.h       [s10, #0], v3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    s.add        s10, s3, s2
    s.addi       s3, s28, #7872
    s.add        s13, s10, s14
    s.add        s10, s19, s13
    v.ld.w       v2, [s1, #0]
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s9, #11
    s.addi       s13, s6, #11
    v.splat      v2, s13
    @p3 v.st.h       [s12, #0], v3
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.add        s12, s1, s2
    s.addi       s1, s28, #7936
    s.add        s13, s12, s14
    s.add        s12, s19, s13
    v.ld.w       v1, [s7, #0]
    vf.cvt.f32.bf16 v3, v1
    s.muli       s7, s9, #12
    s.addi       s13, s6, #12
    v.splat      v1, s13
    @p4 v.st.h       [s11, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    s.add        s11, s7, s2
    s.addi       s7, s28, #8000
    s.add        s13, s11, s14
    s.add        s11, s19, s13
    v.ld.w       v0, [s4, #0]
    vf.cvt.f32.bf16 v3, v0
    s.muli       s4, s9, #13
    s.addi       s13, s6, #13
    v.splat      v0, s13
    @p3 v.st.h       [s8, #0], v3
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.add        s8, s4, s2
    s.addi       s4, s28, #8064
    s.add        s13, s8, s14
    s.add        s8, s19, s13
    v.ld.w       v2, [s5, #0]
    vf.cvt.f32.bf16 v3, v2
    s.muli       s5, s9, #14
    s.addi       s13, s6, #14
    v.splat      v2, s13
    @p4 v.st.h       [s10, #0], v3
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    s.add        s10, s5, s2
    s.addi       s5, s28, #8128
    s.add        s13, s10, s14
    s.add        s10, s19, s13
    v.ld.w       v1, [s3, #0]
    vf.cvt.f32.bf16 v3, v1
    s.muli       s3, s9, #15
    s.addi       s9, s6, #15
    v.splat      v1, s9
    @p3 v.st.h       [s12, #0], v3
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    s.add        s6, s3, s2
    s.add        s2, s6, s14
    s.add        s3, s19, s2
    v.ld.w       v0, [s1, #0]
    vf.cvt.f32.bf16 v3, v0
    @p4 v.st.h       [s11, #0], v3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    v.ld.w       v0, [s7, #0]
    vf.cvt.f32.bf16 v2, v0
    @p3 v.st.h       [s8, #0], v2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    v.ld.w       v0, [s4, #0]
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s10, #0], v1
    v.ld.w       v0, [s5, #0]
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s3, #0], v1
    exit
    exit
