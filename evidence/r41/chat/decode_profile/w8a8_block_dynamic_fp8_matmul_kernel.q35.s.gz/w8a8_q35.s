    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #32]                   // N: i32 at arg_base+32
    s.movz       s4, #0
    s.movz       s5, #0
    s.movz       s6, #128
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s6, s7
    s.rdspecial  s7, pid.x
    s.sub        s10, s8, s9
    s.movz       s8, #8
    s.rdspecial  s9, pid.y
    s.add        s11, s3, s2
    s.movz       s12, #0
    s.cmp.lt     s13, s11, s4
    s.movz       s4, #0
    s.sub        s14, s5, s13
    s.movz       s5, #0
    s.xor        s13, s11, s14
    s.xor        s11, s14, s10
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.lshri      s14, s15, #7
    s.xor        s16, s6, s10
    s.xor        s17, s14, s11
    s.muli       s18, s14, #128
    s.sub        s14, s17, s11
    s.ld.d       s11, [s1, #0]                   // A: device_ptr64 at arg_base+0
    s.mul        s17, s7, s14
    s.mul        s7, s14, s8
    s.movz       s14, #0
    s.sub        s19, s16, s10
    s.sub        s10, s15, s18
    s.add        s10, s17, s9
    s.cmp.lt     s9, s7, s12
    s.cmp.lt     s12, s10, s4
    s.sub        s4, s5, s9
    s.sub        s5, s13, s12
    s.xor        s9, s7, s4
    s.xor        s12, s10, s5
    s.sub        s13, s9, s4
    s.sub        s9, s12, s5
    s.ld.d       s12, [s1, #8]                   // B: device_ptr64 at arg_base+8
    s.movz       s15, #0
    s.ld.d       s16, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.addi       s17, s14, #0
    s.ld.d       s14, [s1, #24]                  // Bs: device_ptr64 at arg_base+24
    s.movz       s18, #1
    s.addi       s19, s15, #0
    s.ld.sw      s15, [s1, #40]                  // K: i32 at arg_base+40
    s.cmp.eq     s20, s13, s18
    s.ld.sw      s18, [s1, #56]                  // stride_bn: i32 at arg_base+56
    s.ld.sw      s21, [s1, #64]                  // stride_cm: i32 at arg_base+64
    s.ld.sw      s22, [s1, #72]                  // stride_bs_n: i32 at arg_base+72
    s.mov        s17, s9
    br.nz        s20, sdiv_done_1
    s.movz       s1, #0
    s.movz       s20, #31
    s.mov        s17, s1
    s.addi       s1, s20, #0
sdiv_2:
    s.lshr       s20, s9, s1
    s.shli       s23, s19, #1
    s.andi       s24, s20, #1
    s.movz       s20, #0
    s.or         s25, s23, s24
    s.movz       s23, #1
    s.cmp.geu    s24, s25, s13
    s.shl        s26, s23, s1
    s.sub        s23, s20, s24
    s.subi       s20, s1, #1
    s.and        s24, s13, s23
    s.and        s27, s26, s23
    s.sub        s23, s25, s24
    s.or         s24, s17, s27
    s.mov        s19, s23
    s.mov        s17, s24
    s.mov        s1, s20
    s.movz       s20, #0
    s.cmp.ge     s23, s1, s20
    br.nz        s23, sdiv_2
sdiv_done_1:
    s.xor        s1, s5, s4
    s.movz       s4, #0
    s.xor        s5, s17, s1
    s.movz       s9, #0
    s.movz       s13, #0
    s.cmp.lt     s17, s7, s4
    s.sub        s4, s5, s1
    s.movz       s1, #0
    s.cmp.lt     s5, s10, s9
    s.sub        s9, s13, s17
    s.mul        s13, s4, s8
    s.sub        s4, s1, s5
    s.xor        s1, s7, s9
    s.movz       s5, #1
    s.xor        s7, s10, s4
    s.sub        s10, s1, s9
    s.movz       s1, #0
    s.movz       s9, #1
    s.sub        s17, s5, s13
    s.sub        s19, s7, s4
    s.movz       s7, #0
    s.addi       s20, s1, #0
    s.cmp.eq     s1, s10, s9
    s.min.s      s9, s17, s8
    s.addi       s8, s7, #0
    s.mov        s20, s19
    br.nz        s1, sdiv_done_3
    s.movz       s1, #0
    s.movz       s7, #31
    s.mov        s20, s1
    s.addi       s1, s7, #0
sdiv_4:
    s.lshr       s7, s19, s1
    s.shli       s17, s8, #1
    s.andi       s23, s7, #1
    s.movz       s7, #0
    s.or         s24, s17, s23
    s.movz       s17, #1
    s.cmp.geu    s23, s24, s10
    s.shl        s25, s17, s1
    s.sub        s17, s7, s23
    s.subi       s7, s1, #1
    s.and        s23, s10, s17
    s.and        s26, s25, s17
    s.sub        s17, s24, s23
    s.or         s23, s20, s26
    s.mov        s8, s17
    s.mov        s20, s23
    s.mov        s1, s7
    s.movz       s7, #0
    s.cmp.ge     s17, s1, s7
    br.nz        s17, sdiv_4
sdiv_done_3:
    s.xor        s1, s8, s4
    s.movz       s7, #0
    s.sub        s8, s1, s4
    s.movz       s1, #0
    s.movz       s4, #0
    s.cmp.lt     s10, s9, s7
    s.movz       s7, #0
    s.cmp.lt     s17, s8, s1
    s.sub        s1, s4, s10
    s.sub        s4, s7, s17
    s.xor        s7, s9, s1
    s.xor        s10, s8, s4
    s.sub        s17, s7, s1
    s.movz       s1, #0
    s.movz       s7, #1
    s.sub        s19, s10, s4
    s.movz       s10, #0
    s.addi       s20, s1, #0
    s.cmp.eq     s1, s17, s7
    s.addi       s7, s10, #0
    s.mov        s20, s19
    br.nz        s1, sdiv_done_5
    s.movz       s1, #0
    s.movz       s10, #31
    s.mov        s20, s1
    s.addi       s1, s10, #0
sdiv_6:
    s.lshr       s10, s19, s1
    s.shli       s23, s7, #1
    s.andi       s24, s10, #1
    s.movz       s10, #0
    s.or         s25, s23, s24
    s.movz       s23, #1
    s.cmp.geu    s24, s25, s17
    s.shl        s26, s23, s1
    s.sub        s23, s10, s24
    s.subi       s10, s1, #1
    s.and        s24, s17, s23
    s.and        s27, s26, s23
    s.sub        s23, s25, s24
    s.or         s24, s20, s27
    s.mov        s7, s23
    s.mov        s20, s24
    s.mov        s1, s10
    s.movz       s10, #0
    s.cmp.ge     s23, s1, s10
    br.nz        s23, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.movz       s10, #0
    s.movz       s17, #0
    s.cmp.lt     s19, s9, s1
    s.movz       s1, #0
    s.cmp.lt     s20, s8, s10
    s.sub        s10, s17, s19
    s.sub        s17, s1, s20
    s.xor        s1, s9, s10
    s.xor        s9, s7, s4
    s.xor        s7, s8, s17
    s.sub        s8, s1, s10
    s.movz       s1, #0
    s.movz       s19, #1
    s.sub        s20, s9, s4
    s.sub        s4, s7, s17
    s.movz       s7, #0
    s.addi       s9, s1, #0
    s.cmp.eq     s1, s8, s19
    s.add        s19, s13, s20
    s.addi       s13, s7, #0
    s.mov        s9, s4
    br.nz        s1, sdiv_done_7
    s.movz       s1, #0
    s.movz       s7, #31
    s.mov        s9, s1
    s.addi       s1, s7, #0
sdiv_8:
    s.lshr       s7, s4, s1
    s.shli       s20, s13, #1
    s.andi       s23, s7, #1
    s.movz       s7, #0
    s.or         s24, s20, s23
    s.movz       s20, #1
    s.cmp.geu    s23, s24, s8
    s.shl        s25, s20, s1
    s.sub        s20, s7, s23
    s.subi       s7, s1, #1
    s.and        s23, s8, s20
    s.and        s26, s25, s20
    s.sub        s20, s24, s23
    s.or         s23, s9, s26
    s.mov        s13, s20
    s.mov        s9, s23
    s.mov        s1, s7
    s.movz       s7, #0
    s.cmp.ge     s20, s1, s7
    br.nz        s20, sdiv_8
sdiv_done_7:
    s.xor        s1, s17, s10
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s4, s9, s1
    v.iota       v1                              // arange(0, VLEN)
    s.sub        s7, s4, s1
    v.movi       v2, #16
    s.mul        s1, s7, s6
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #32
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #48
    v.splat      v7, s1
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #64
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #80
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #96
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #112
    v.add        v16, v7, v0
    v.splat      v0, s3
    v.movi       v7, #0
    v.add        v17, v1, v2
    v.add        v1, v3, v4
    v.add        v2, v5, v6
    v.add        v3, v8, v9
    v.add        v4, v10, v11
    v.add        v5, v12, v13
    v.add        v6, v14, v15
    v.splat      v8, s1
    v.splat      v9, s1
    v.splat      v10, s1
    v.splat      v11, s1
    v.splat      v12, s1
    v.splat      v13, s1
    v.splat      v14, s1
    v.sub        v15, v7, v16
    v.sub        v18, v7, v0
    v.cmp.lt     p1, v16, v7
    v.cmp.lt     p2, v0, v7
    v.add        v19, v8, v17
    v.add        v8, v9, v1
    v.add        v1, v10, v2
    v.add        v2, v11, v3
    v.add        v3, v12, v4
    v.add        v4, v13, v5
    v.add        v5, v14, v6
    v.splat      v6, s3
    v.splat      v9, s3
    v.splat      v10, s3
    v.splat      v11, s3
    v.splat      v12, s3
    v.splat      v13, s3
    v.splat      v14, s3
    v.movi       v17, #1
    @p1 v.sel        v20, v15, v16
    @p2 v.sel        v15, v18, v0
    v.movi       v0, #0
    v.movi       v16, #0
    s.movz       s4, #31
idiv_9:
    v.splat      v18, s4
    v.shl        v21, v16, v17
    v.cmp.lt     p2, v16, v7
    v.lshr       v22, v20, v18
    v.shl        v23, v17, v18
    s.subi       s7, s4, #1
    v.and        v18, v22, v17
    s.movz       s8, #0
    v.or         v22, v21, v18
    v.cmp.geu    p3, v22, v15
    p.or         p4, p2, p3
    v.sub        v18, v22, v15
    @p4 v.sel        v21, v23, v7
    @p4 v.sel        v23, v18, v22
    v.or         v18, v0, v21
    v.mov        v16, v23
    v.mov        v0, v18
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_9
    v.movi       v0, #0
    v.sub        v15, v7, v16
    v.movi       v7, #1
    v.sub        v17, v0, v19
    v.sub        v18, v0, v6
    v.cmp.lt     p2, v19, v0
    v.cmp.lt     p3, v6, v0
    @p1 v.sel        v20, v15, v16
    @p2 v.sel        v15, v17, v19
    @p3 v.sel        v16, v18, v6
    v.movi       v6, #0
    v.movi       v17, #0
    s.movz       s4, #31
idiv_10:
    v.splat      v18, s4
    v.shl        v19, v17, v7
    v.cmp.lt     p1, v17, v0
    v.lshr       v21, v15, v18
    v.shl        v22, v7, v18
    s.subi       s7, s4, #1
    v.and        v18, v21, v7
    s.movz       s8, #0
    v.or         v21, v19, v18
    v.cmp.geu    p3, v21, v16
    p.or         p4, p1, p3
    v.sub        v18, v21, v16
    @p4 v.sel        v19, v22, v0
    @p4 v.sel        v22, v18, v21
    v.or         v18, v6, v19
    v.mov        v17, v22
    v.mov        v6, v18
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_10
    v.movi       v6, #0
    v.sub        v7, v0, v17
    v.movi       v0, #1
    v.sub        v15, v6, v8
    v.sub        v16, v6, v9
    v.cmp.lt     p1, v8, v6
    v.cmp.lt     p3, v9, v6
    @p2 v.sel        v18, v7, v17
    @p1 v.sel        v7, v15, v8
    @p3 v.sel        v8, v16, v9
    v.movi       v9, #0
    v.movi       v15, #0
    s.movz       s4, #31
idiv_11:
    v.splat      v16, s4
    v.shl        v17, v15, v0
    v.cmp.lt     p2, v15, v6
    v.lshr       v19, v7, v16
    v.shl        v21, v0, v16
    s.subi       s7, s4, #1
    v.and        v16, v19, v0
    s.movz       s8, #0
    v.or         v19, v17, v16
    v.cmp.geu    p3, v19, v8
    p.or         p4, p2, p3
    v.sub        v16, v19, v8
    @p4 v.sel        v17, v21, v6
    @p4 v.sel        v21, v16, v19
    v.or         v16, v9, v17
    v.mov        v15, v21
    v.mov        v9, v16
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_11
    v.movi       v0, #0
    v.sub        v7, v6, v15
    v.movi       v6, #1
    v.sub        v8, v0, v1
    v.sub        v9, v0, v10
    v.cmp.lt     p2, v1, v0
    v.cmp.lt     p3, v10, v0
    @p1 v.sel        v16, v7, v15
    @p2 v.sel        v7, v8, v1
    @p3 v.sel        v1, v9, v10
    v.movi       v8, #0
    v.movi       v9, #0
    s.movz       s4, #31
idiv_12:
    v.splat      v10, s4
    v.shl        v15, v9, v6
    v.cmp.lt     p1, v9, v0
    v.lshr       v17, v7, v10
    v.shl        v19, v6, v10
    s.subi       s7, s4, #1
    v.and        v10, v17, v6
    s.movz       s8, #0
    v.or         v17, v15, v10
    v.cmp.geu    p3, v17, v1
    p.or         p4, p1, p3
    v.sub        v10, v17, v1
    @p4 v.sel        v15, v19, v0
    @p4 v.sel        v19, v10, v17
    v.or         v10, v8, v15
    v.mov        v9, v19
    v.mov        v8, v10
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_12
    v.movi       v1, #0
    v.sub        v6, v0, v9
    v.movi       v0, #1
    v.sub        v7, v1, v2
    v.sub        v8, v1, v11
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p3, v11, v1
    @p2 v.sel        v10, v6, v9
    @p1 v.sel        v6, v7, v2
    @p3 v.sel        v2, v8, v11
    v.movi       v7, #0
    v.movi       v8, #0
    s.movz       s4, #31
idiv_13:
    v.splat      v9, s4
    v.shl        v11, v8, v0
    v.cmp.lt     p2, v8, v1
    v.lshr       v15, v6, v9
    v.shl        v17, v0, v9
    s.subi       s7, s4, #1
    v.and        v9, v15, v0
    s.movz       s8, #0
    v.or         v15, v11, v9
    v.cmp.geu    p3, v15, v2
    p.or         p4, p2, p3
    v.sub        v9, v15, v2
    @p4 v.sel        v11, v17, v1
    @p4 v.sel        v17, v9, v15
    v.or         v9, v7, v11
    v.mov        v8, v17
    v.mov        v7, v9
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_13
    v.movi       v0, #0
    v.sub        v2, v1, v8
    v.movi       v1, #1
    v.sub        v6, v0, v3
    v.sub        v7, v0, v12
    v.cmp.lt     p2, v3, v0
    v.cmp.lt     p3, v12, v0
    @p1 v.sel        v9, v2, v8
    @p2 v.sel        v2, v6, v3
    @p3 v.sel        v3, v7, v12
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s4, #31
idiv_14:
    v.splat      v8, s4
    v.shl        v11, v7, v1
    v.cmp.lt     p1, v7, v0
    v.lshr       v12, v2, v8
    v.shl        v15, v1, v8
    s.subi       s7, s4, #1
    v.and        v8, v12, v1
    s.movz       s8, #0
    v.or         v12, v11, v8
    v.cmp.geu    p3, v12, v3
    p.or         p4, p1, p3
    v.sub        v8, v12, v3
    @p4 v.sel        v11, v15, v0
    @p4 v.sel        v15, v8, v12
    v.or         v8, v6, v11
    v.mov        v7, v15
    v.mov        v6, v8
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_14
    v.movi       v1, #0
    v.sub        v2, v0, v7
    v.movi       v0, #1
    v.sub        v3, v1, v4
    v.sub        v6, v1, v13
    v.cmp.lt     p1, v4, v1
    v.cmp.lt     p3, v13, v1
    @p2 v.sel        v8, v2, v7
    @p1 v.sel        v2, v3, v4
    @p3 v.sel        v3, v6, v13
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s4, #31
idiv_15:
    v.splat      v7, s4
    v.shl        v11, v6, v0
    v.cmp.lt     p2, v6, v1
    v.lshr       v12, v2, v7
    v.shl        v13, v0, v7
    s.subi       s7, s4, #1
    v.and        v7, v12, v0
    s.movz       s8, #0
    v.or         v12, v11, v7
    v.cmp.geu    p3, v12, v3
    p.or         p4, p2, p3
    v.sub        v7, v12, v3
    @p4 v.sel        v11, v13, v1
    @p4 v.sel        v13, v7, v12
    v.or         v7, v4, v11
    v.mov        v6, v13
    v.mov        v4, v7
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_15
    v.movi       v0, #0
    v.sub        v2, v1, v6
    v.movi       v1, #1
    v.sub        v3, v0, v5
    v.sub        v4, v0, v14
    v.cmp.lt     p2, v5, v0
    v.cmp.lt     p3, v14, v0
    @p1 v.sel        v7, v2, v6
    @p2 v.sel        v2, v3, v5
    @p3 v.sel        v3, v4, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s4, #31
idiv_16:
    v.splat      v6, s4
    v.shl        v11, v5, v1
    v.cmp.lt     p1, v5, v0
    v.lshr       v12, v2, v6
    v.shl        v13, v1, v6
    s.subi       s7, s4, #1
    v.and        v6, v12, v1
    s.movz       s8, #0
    v.or         v12, v11, v6
    v.cmp.geu    p3, v12, v3
    p.or         p4, p1, p3
    v.sub        v6, v12, v3
    @p4 v.sel        v11, v13, v0
    @p4 v.sel        v13, v6, v12
    v.or         v6, v4, v11
    v.mov        v5, v13
    v.mov        v4, v6
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_16
    v.sub        v1, v0, v5
    v.movi       v0, #0
    v.movi       v2, #0
    @p2 v.sel        v3, v1, v5
    v.movi       v1, #0
    v.movi       v4, #0
    v.sub        v5, v0, v20
    v.sub        v6, v2, v18
    v.sub        v11, v1, v16
    v.cmp.lt     p1, v20, v0
    v.cmp.lt     p2, v18, v2
    v.cmp.lt     p3, v16, v1
    @p1 v.sel        v12, v5, v20
    v.movi       v5, #7
    @p2 v.sel        v13, v6, v18
    v.movi       v6, #7
    @p3 v.sel        v14, v11, v16
    v.movi       v11, #7
    v.lshr       v15, v12, v5
    v.lshr       v5, v13, v6
    v.lshr       v6, v14, v11
    v.movi       v11, #128
    v.sub        v12, v0, v15
    v.movi       v13, #128
    v.sub        v14, v2, v5
    v.movi       v17, #128
    v.sub        v19, v1, v6
    v.movi       v21, #128
    v.sub        v22, v0, v11
    @p1 v.sel        v23, v12, v15
    v.sub        v12, v2, v13
    @p2 v.sel        v15, v14, v5
    v.sub        v5, v1, v17
    @p3 v.sel        v14, v19, v6
    v.cmp.lt     p1, v11, v0
    v.cmp.lt     p2, v13, v2
    v.cmp.lt     p3, v17, v1
    s.movz       s4, #16
    s.movz       s7, #32
    s.movz       s8, #48
    s.movz       s9, #64
    v.sub        v0, v4, v10
    s.movz       s10, #80
    s.movz       s13, #96
    v.sub        v1, v4, v21
    s.movz       s17, #112
    v.movi       v2, #7
    v.movi       v6, #1
    v.movi       v6, #0
    v.movi       v19, #128
    @p1 v.sel        v24, v22, v11
    v.sub        v11, v6, v9
    v.cmp.lt     p1, v10, v4
    @p1 v.sel        v22, v0, v10
    v.movi       v0, #7
    v.sub        v24, v6, v19
    v.lshr       v25, v22, v2
    v.movi       v2, #1
    v.movi       v2, #0
    v.sub        v22, v4, v25
    v.movi       v26, #128
    @p2 v.sel        v27, v12, v13
    v.sub        v12, v2, v8
    v.cmp.lt     p2, v9, v6
    @p2 v.sel        v13, v11, v9
    v.movi       v11, #7
    @p1 v.sel        v27, v22, v25
    v.cmp.lt     p1, v8, v2
    @p1 v.sel        v22, v12, v8
    v.lshr       v12, v13, v0
    v.sub        v0, v2, v26
    v.lshr       v13, v22, v11
    v.sub        v11, v6, v12
    v.movi       v22, #1
    v.movi       v22, #0
    v.sub        v25, v2, v13
    @p2 v.sel        v28, v11, v12
    v.cmp.lt     p2, v7, v22
    v.movi       v11, #128
    @p1 v.sel        v12, v25, v13
    v.cmp.lt     p1, v21, v4
    @p3 v.sel        v4, v5, v17
    v.sub        v4, v22, v7
    v.movi       v5, #7
    v.sub        v13, v22, v11
    @p2 v.sel        v17, v4, v7
    v.cmp.lt     p3, v19, v6
    v.movi       v4, #1
    v.movi       v4, #0
    v.lshr       v6, v17, v5
    v.movi       v5, #128
    @p1 v.sel        v17, v1, v21
    v.sub        v1, v4, v3
    v.cmp.lt     p1, v3, v4
    v.movi       v17, #7
    @p1 v.sel        v21, v1, v3
    v.sub        v1, v22, v6
    v.movi       v25, #1
    v.lshr       v25, v21, v17
    @p2 v.sel        v17, v1, v6
    v.sub        v1, v4, v5
    v.sub        v6, v4, v25
    v.cmp.lt     p2, v26, v2
    v.splat      v2, s22
    @p1 v.sel        v21, v6, v25
    v.splat      v6, s22
    v.cmp.lt     p1, v11, v22
    v.splat      v22, s22
    @p3 v.sel        v25, v24, v19
    v.splat      v19, s22
    v.splat      v24, s22
    v.cmp.lt     p3, v5, v4
    v.splat      v4, s22
    v.movi       v25, #1
    s.add        s20, s15, s2
    @p2 v.sel        v25, v0, v26
    s.movz       s2, #0
    s.movz       s23, #0
    s.cmp.lt     s24, s20, s2
    s.movz       s2, #0
    s.sub        s25, s23, s24
    s.movz       s23, #0
    s.cmp.lt     s24, s6, s2
    v.splat      v0, s22
    v.splat      v25, s22
    v.movi       v26, #1
    s.xor        s2, s20, s25
    s.sub        s20, s23, s24
    s.sub        s22, s2, s25
    s.xor        s2, s6, s20
    s.lshri      s23, s22, #7
    @p1 v.sel        v26, v13, v11
    s.muli       s24, s23, #128
    s.xor        s26, s25, s20
    s.movz       s25, #0
    s.xor        s27, s23, s26
    v.movi       v11, #1
    s.movz       s23, #0
    s.movz       s28, #0
    @p3 v.sel        v11, v1, v5
    v.mul        v1, v23, v2
    v.mul        v2, v15, v6
    v.mul        v5, v14, v22
    v.mul        v6, v27, v19
    v.mul        v11, v28, v24
    v.mul        v13, v12, v4
    v.mul        v4, v17, v0
    v.mul        v0, v21, v25
    s.sub        s29, s2, s20
    s.sub        s2, s22, s24
    s.sub        s2, s27, s26
    s.addi       s20, s25, #0
    s.addi       s22, s23, #0
    s.addi       s23, s28, #0
    s.addi       s24, s14, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_25:
    s.cmp.ge     s14, s20, s2
    br.nz        s14, endfor_26
    s.mul        s14, s20, s6
    s.movz       s26, #0
    s.muli       s27, s22, #2
    v.iota       v12                             // arange(0, VLEN)
    s.rdspecial  s28, arg_base
    s.sub        s29, s15, s14
    s.ld.d       s14, [s28, #80]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s28, s26, s29                   // the tile origin
    s.add        s26, s11, s27
    v.splat      v14, s28
    s.add        s28, s11, s27
    s.add        s30, s11, s27
    v.cmp.lt     p1, v12, v14
    s.add        s31, s11, s27
    s.add        s32, s11, s27
    s.add        s33, s11, s27
    s.add        s34, s11, s27
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s26, #0]
    s.addi       s26, s14, #0
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s28, #0]
    s.addi       s28, s26, #64
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s26, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s30, #0]
    s.addi       s30, s26, #192
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s26, #256
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s31, #0]
    s.addi       s31, s26, #320
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s26, #384
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.add        s32, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s26, #448
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.add        s33, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s26, #512
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.add        s34, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s26, #576
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.add        s32, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s26, #640
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.add        s33, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s26, #704
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.add        s34, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s26, #768
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.add        s32, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s26, #832
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.add        s33, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s26, #896
    s.addi       s35, s26, #960
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.add        s26, s11, s27
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.movz       s30, #0
    s.add        s34, s30, s4                    // the tile origin
    v.splat      v14, s34
    s.movz       s30, #0
    s.add        s34, s30, s29                   // the tile origin
    v.add        v15, v12, v14
    v.splat      v14, s34
    s.addi       s30, s27, #32
    s.add        s34, s11, s30
    v.cmp.lt     p2, v15, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s30, s27, #32
    s.add        s32, s11, s30
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s14, #1024
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s30, s27, #32
    s.add        s33, s11, s30
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s30, s28, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s26, #0]
    s.addi       s26, s27, #32
    s.add        s31, s11, s26
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s35, #0], v15
    fence.acq_rel.device
    s.addi       s26, s28, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s34, s27, #32
    s.add        s35, s11, s34
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s32, s28, #192
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #32
    s.add        s34, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s28, #256
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #32
    s.add        s33, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s31, #0]
    s.addi       s26, s28, #320
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s32, #0], v15
    s.addi       s31, s27, #32
    s.add        s32, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s31, s28, #384
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #32
    s.add        s35, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s30, s28, #448
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #32
    s.add        s34, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s26, s28, #512
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #32
    s.add        s33, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s31, s28, #576
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #32
    s.add        s32, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s30, s28, #640
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #32
    s.add        s35, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s26, s28, #704
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #32
    s.add        s34, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s31, s28, #768
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #32
    s.add        s33, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s30, s28, #832
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #32
    s.add        s32, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s26, s28, #896
    s.addi       s35, s28, #960
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.movz       s28, #0
    s.add        s31, s28, s7                    // the tile origin
    v.splat      v14, s31
    s.movz       s28, #0
    s.add        s31, s28, s29                   // the tile origin
    v.add        v15, v12, v14
    v.splat      v14, s31
    s.addi       s28, s27, #64
    s.add        s31, s11, s28
    v.cmp.lt     p1, v15, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s28, s27, #64
    s.add        s34, s11, s28
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s28, s14, #2048
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s27, #64
    s.add        s33, s11, s30
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s28, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s30, s27, #64
    s.add        s32, s11, s30
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s35, #0], v15
    fence.acq_rel.device
    s.addi       s30, s28, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s31, #0]
    s.addi       s31, s27, #64
    s.add        s35, s11, s31
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s31, s28, #192
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #64
    s.add        s34, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s26, s28, #256
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #64
    s.add        s33, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s30, s28, #320
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #64
    s.add        s32, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s31, s28, #384
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #64
    s.add        s35, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s26, s28, #448
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #64
    s.add        s34, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s30, s28, #512
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #64
    s.add        s33, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s31, s28, #576
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #64
    s.add        s32, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s26, s28, #640
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #64
    s.add        s35, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s30, s28, #704
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #64
    s.add        s34, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s31, s28, #768
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s27, #64
    s.add        s33, s11, s26
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s26, s28, #832
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #64
    s.add        s32, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s30, s28, #896
    s.addi       s35, s28, #960
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.movz       s28, #0
    s.add        s31, s28, s8                    // the tile origin
    v.splat      v14, s31
    s.movz       s28, #0
    s.add        s31, s28, s29                   // the tile origin
    v.add        v15, v12, v14
    v.splat      v14, s31
    s.addi       s28, s27, #96
    s.add        s31, s11, s28
    v.cmp.lt     p2, v15, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s28, s27, #96
    s.add        s34, s11, s28
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    s.addi       s26, s14, #3072
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s28, s27, #96
    s.add        s33, s11, s28
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s28, s26, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s30, s27, #96
    s.add        s32, s11, s30
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s35, #0], v15
    fence.acq_rel.device
    s.addi       s30, s26, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s31, #0]
    s.addi       s31, s27, #96
    s.add        s35, s11, s31
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s31, s26, #192
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #96
    s.add        s34, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s28, s26, #256
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #96
    s.add        s33, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s30, s26, #320
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #96
    s.add        s32, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s31, s26, #384
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #96
    s.add        s35, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s28, s26, #448
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #96
    s.add        s34, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s26, #512
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #96
    s.add        s33, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s31, s26, #576
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #96
    s.add        s32, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s28, s26, #640
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #96
    s.add        s35, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s30, s26, #704
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #96
    s.add        s34, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s31, s26, #768
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #96
    s.add        s33, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s28, s26, #832
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #96
    s.add        s32, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s30, s26, #896
    s.addi       s35, s26, #960
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.movz       s26, #0
    s.add        s31, s26, s9                    // the tile origin
    v.splat      v14, s31
    s.movz       s26, #0
    s.add        s31, s26, s29                   // the tile origin
    v.add        v15, v12, v14
    v.splat      v14, s31
    s.addi       s26, s27, #128
    s.add        s31, s11, s26
    v.cmp.lt     p1, v15, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s26, s27, #128
    s.add        s34, s11, s26
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s26, s14, #4096
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s28, s27, #128
    s.add        s33, s11, s28
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s28, s26, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s30, s27, #128
    s.add        s32, s11, s30
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s35, #0], v15
    fence.acq_rel.device
    s.addi       s30, s26, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s31, #0]
    s.addi       s31, s27, #128
    s.add        s35, s11, s31
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s31, s26, #192
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #128
    s.add        s34, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s28, s26, #256
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #128
    s.add        s33, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s30, s26, #320
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #128
    s.add        s32, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s31, s26, #384
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #128
    s.add        s35, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s28, s26, #448
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #128
    s.add        s34, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s30, s26, #512
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #128
    s.add        s33, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s31, s26, #576
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #128
    s.add        s32, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s28, s26, #640
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #128
    s.add        s35, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s30, s26, #704
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #128
    s.add        s34, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s31, s26, #768
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #128
    s.add        s33, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s28, s26, #832
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #128
    s.add        s32, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s30, s26, #896
    s.addi       s35, s26, #960
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.movz       s26, #0
    s.add        s31, s26, s10                   // the tile origin
    v.splat      v14, s31
    s.movz       s26, #0
    s.add        s31, s26, s29                   // the tile origin
    v.add        v15, v12, v14
    v.splat      v14, s31
    s.addi       s26, s27, #160
    s.add        s31, s11, s26
    v.cmp.lt     p2, v15, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s26, s27, #160
    s.add        s34, s11, s26
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s26, s14, #5120
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s28, s27, #160
    s.add        s33, s11, s28
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s28, s26, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s30, s27, #160
    s.add        s32, s11, s30
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s35, #0], v15
    fence.acq_rel.device
    s.addi       s30, s26, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s31, #0]
    s.addi       s31, s27, #160
    s.add        s35, s11, s31
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s31, s26, #192
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #160
    s.add        s34, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s28, s26, #256
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #160
    s.add        s33, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s30, s26, #320
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #160
    s.add        s32, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s31, s26, #384
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #160
    s.add        s35, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s28, s26, #448
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #160
    s.add        s34, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s26, #512
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #160
    s.add        s33, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s31, s26, #576
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #160
    s.add        s32, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s28, s26, #640
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #160
    s.add        s35, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s30, s26, #704
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #160
    s.add        s34, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s31, s26, #768
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #160
    s.add        s33, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s28, s26, #832
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #160
    s.add        s32, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s30, s26, #896
    s.addi       s35, s26, #960
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.movz       s26, #0
    s.add        s31, s26, s13                   // the tile origin
    v.splat      v14, s31
    s.movz       s26, #0
    s.add        s31, s26, s29                   // the tile origin
    v.add        v15, v12, v14
    v.splat      v14, s31
    s.addi       s26, s27, #192
    s.add        s31, s11, s26
    v.cmp.lt     p1, v15, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s26, s27, #192
    s.add        s34, s11, s26
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s26, s14, #6144
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s28, s27, #192
    s.add        s33, s11, s28
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s28, s26, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s30, s27, #192
    s.add        s32, s11, s30
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s35, #0], v15
    fence.acq_rel.device
    s.addi       s30, s26, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s31, #0]
    s.addi       s31, s27, #192
    s.add        s35, s11, s31
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s26, #0], v15
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s31, s26, #192
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #192
    s.add        s34, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s28, s26, #256
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #192
    s.add        s33, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s30, s26, #320
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #192
    s.add        s32, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s31, s26, #384
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #192
    s.add        s35, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s28, s26, #448
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #192
    s.add        s34, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s30, s26, #512
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #192
    s.add        s33, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s31, s26, #576
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #192
    s.add        s32, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s28, s26, #640
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #192
    s.add        s35, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s30, s26, #704
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.addi       s31, s27, #192
    s.add        s34, s11, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s31, s26, #768
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s28, #0], v15
    s.addi       s28, s27, #192
    s.add        s33, s11, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s28, s26, #832
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s30, #0], v15
    s.addi       s30, s27, #192
    s.add        s32, s11, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s30, s26, #896
    s.addi       s35, s26, #960
    vf.cvt.bf16.f32 v15, v14
    v.st.w       [s31, #0], v15
    s.movz       s26, #0
    s.add        s31, s26, s17                   // the tile origin
    v.splat      v14, s31
    s.movz       s26, #0
    s.add        s31, s26, s29                   // the tile origin
    v.add        v15, v12, v14
    v.splat      v12, s31
    s.addi       s26, s27, #224
    s.add        s31, s11, s26
    v.cmp.lt     p2, v15, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s34, #0]
    s.addi       s26, s27, #224
    s.add        s34, s11, s26
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s28, #0], v14
    s.addi       s26, s14, #7168
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    s.addi       s28, s27, #224
    s.add        s33, s11, s28
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s30, #0], v14
    s.addi       s28, s26, #64
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s32, #0]
    s.addi       s30, s27, #224
    s.add        s32, s11, s30
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s35, #0], v14
    fence.acq_rel.device
    s.addi       s30, s26, #128
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s31, #0]
    s.addi       s31, s27, #224
    s.add        s35, s11, s31
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s26, #0], v14
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s34, #0]
    s.addi       s31, s26, #192
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s28, #0], v14
    s.addi       s28, s27, #224
    s.add        s34, s11, s28
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s33, #0]
    s.addi       s28, s26, #256
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s30, #0], v14
    s.addi       s30, s27, #224
    s.add        s33, s11, s30
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s32, #0]
    s.addi       s30, s26, #320
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s31, #0], v14
    s.addi       s31, s27, #224
    s.add        s32, s11, s31
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s35, #0]
    s.addi       s31, s26, #384
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s28, #0], v14
    s.addi       s28, s27, #224
    s.add        s35, s11, s28
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s34, #0]
    s.addi       s28, s26, #448
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s30, #0], v14
    s.addi       s30, s27, #224
    s.add        s34, s11, s30
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s33, #0]
    s.addi       s30, s26, #512
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s31, #0], v14
    s.addi       s31, s27, #224
    s.add        s33, s11, s31
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s32, #0]
    s.addi       s31, s26, #576
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s28, #0], v14
    s.addi       s28, s27, #224
    s.add        s32, s11, s28
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s35, #0]
    s.addi       s28, s26, #640
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s30, #0], v14
    s.addi       s30, s27, #224
    s.add        s35, s11, s30
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s34, #0]
    s.addi       s30, s26, #704
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s31, #0], v14
    s.addi       s31, s27, #224
    s.add        s34, s11, s31
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s33, #0]
    s.addi       s31, s26, #768
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s28, #0], v14
    s.addi       s28, s27, #224
    s.addi       s33, s27, #224
    s.add        s27, s11, s28
    s.add        s28, s11, s33
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s32, #0]
    s.addi       s32, s26, #832
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s30, #0], v14
    s.addi       s30, s26, #896
    s.addi       s33, s26, #960
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s35, #0]
    s.addi       s26, s14, #0
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s31, #0], v14
    s.addi       s31, s14, #1024
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s34, #0]
    s.addi       s34, s14, #64
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s32, #0], v14
    s.addi       s32, s14, #1088
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s27, #0]
    s.addi       s27, s14, #2048
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s30, #0], v14
    s.addi       s30, s14, #2112
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v12, [s28, #0]
    s.addi       s28, s14, #3072
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s33, #0], v14
    fence.acq_rel.device
    s.addi       s33, s14, #3136
    v.ld.w       v12, [s26, #0]
    s.addi       s26, s14, #4096
    v.ld.w       v14, [s31, #0]
    s.addi       s31, s14, #4160
    vf.abs       v15, v12
    v.ld.w       v12, [s34, #0]
    vf.abs       v17, v14
    s.addi       s34, s14, #5120
    vf.max.ieee  v14, v15, v17
    v.ld.w       v15, [s32, #0]
    vf.abs       v17, v12
    s.addi       s32, s14, #5184
    v.ld.w       v12, [s27, #0]
    vf.abs       v19, v15
    s.addi       s27, s14, #6144
    vf.max.ieee  v15, v17, v19
    v.ld.w       v17, [s30, #0]
    vf.abs       v19, v12
    s.addi       s30, s14, #6208
    vf.max.ieee  v12, v14, v19
    v.ld.w       v14, [s28, #0]
    vf.abs       v19, v17
    s.addi       s28, s14, #7168
    vf.max.ieee  v17, v15, v19
    v.ld.w       v15, [s33, #0]
    vf.abs       v19, v14
    s.addi       s33, s14, #7232
    vf.max.ieee  v14, v12, v19
    v.ld.w       v12, [s26, #0]
    s.addi       s26, s14, #128
    vf.abs       v19, v15
    vf.max.ieee  v15, v17, v19
    v.ld.w       v17, [s31, #0]
    vf.abs       v19, v12
    vf.max.ieee  v12, v14, v19
    s.addi       s31, s14, #1152
    v.ld.w       v14, [s26, #0]
    vf.abs       v19, v17
    vf.max.ieee  v17, v15, v19
    v.ld.w       v15, [s34, #0]
    vf.abs       v19, v14
    v.ld.w       v14, [s31, #0]
    vf.abs       v21, v15
    vf.max.ieee  v15, v12, v21
    s.addi       s26, s14, #2176
    v.ld.w       v12, [s32, #0]
    vf.abs       v21, v14
    vf.max.ieee  v14, v19, v21
    v.ld.w       v19, [s27, #0]
    vf.abs       v21, v12
    vf.max.ieee  v12, v17, v21
    v.ld.w       v17, [s26, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v15, v21
    s.addi       s26, s14, #3200
    v.ld.w       v15, [s30, #0]
    vf.abs       v21, v17
    vf.max.ieee  v17, v14, v21
    v.ld.w       v14, [s28, #0]
    vf.abs       v21, v15
    vf.max.ieee  v15, v12, v21
    v.ld.w       v12, [s26, #0]
    vf.abs       v21, v14
    vf.max.ieee  v14, v19, v21
    vf.reduce.max.b v19, v14
    s.addi       s26, s14, #192
    s.addi       s27, s14, #1216
    s.addi       s28, s14, #2240
    s.addi       s30, s14, #3264
    s.addi       s31, s14, #4224
    s.addi       s32, s14, #5248
    v.ld.w       v14, [s26, #0]
    s.addi       s26, s14, #6272
    vf.abs       v21, v12
    s.addi       s34, s14, #7296
    vf.max.ieee  v12, v17, v21
    v.ld.w       v17, [s27, #0]
    vf.abs       v21, v14
    v.ld.w       v14, [s28, #0]
    vf.abs       v22, v17
    vf.max.ieee  v17, v21, v22
    v.ld.w       v21, [s31, #0]
    vf.abs       v22, v14
    vf.max.ieee  v14, v17, v22
    v.ld.w       v17, [s32, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v12, v22
    v.ld.w       v12, [s26, #0]
    vf.abs       v22, v17
    vf.max.ieee  v17, v21, v22
    v.ld.w       v21, [s33, #0]
    vf.abs       v22, v12
    vf.max.ieee  v12, v17, v22
    v.ld.w       v17, [s30, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v15, v22
    vf.reduce.max.b v15, v21
    s.addi       s26, s14, #256
    s.addi       s27, s14, #1280
    s.addi       s28, s14, #2304
    s.addi       s30, s14, #3328
    s.addi       s31, s14, #4288
    s.addi       s32, s14, #5312
    v.ld.w       v21, [s26, #0]
    s.addi       s26, s14, #6336
    vf.abs       v22, v17
    s.addi       s33, s14, #7360
    vf.max.ieee  v17, v14, v22
    v.ld.w       v14, [s27, #0]
    vf.abs       v22, v21
    v.ld.w       v21, [s28, #0]
    vf.abs       v23, v14
    vf.max.ieee  v14, v22, v23
    v.ld.w       v22, [s31, #0]
    vf.abs       v23, v21
    vf.max.ieee  v21, v14, v23
    v.ld.w       v14, [s32, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v17, v23
    v.ld.w       v17, [s26, #0]
    vf.abs       v23, v14
    vf.max.ieee  v14, v22, v23
    v.ld.w       v22, [s34, #0]
    vf.abs       v23, v17
    vf.max.ieee  v17, v14, v23
    v.ld.w       v14, [s30, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v12, v23
    vf.reduce.max.b v12, v22
    s.addi       s26, s14, #320
    s.addi       s27, s14, #1344
    s.addi       s28, s14, #2368
    s.addi       s30, s14, #3392
    s.addi       s31, s14, #4352
    s.addi       s32, s14, #5376
    v.ld.w       v22, [s26, #0]
    s.addi       s26, s14, #6400
    vf.abs       v23, v14
    s.addi       s34, s14, #7424
    vf.max.ieee  v14, v21, v23
    v.ld.w       v21, [s27, #0]
    vf.abs       v23, v22
    v.ld.w       v22, [s28, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    v.ld.w       v23, [s31, #0]
    vf.abs       v24, v22
    vf.max.ieee  v22, v21, v24
    v.ld.w       v21, [s32, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v14, v24
    v.ld.w       v14, [s26, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    v.ld.w       v23, [s33, #0]
    vf.abs       v24, v14
    vf.max.ieee  v14, v21, v24
    v.ld.w       v21, [s30, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v17, v24
    vf.reduce.max.b v17, v23
    s.addi       s26, s14, #384
    s.addi       s27, s14, #1408
    s.addi       s28, s14, #2432
    s.addi       s30, s14, #3456
    s.addi       s31, s14, #4416
    s.addi       s32, s14, #5440
    v.ld.w       v23, [s26, #0]
    s.addi       s26, s14, #6464
    vf.abs       v24, v21
    s.addi       s33, s14, #7488
    vf.max.ieee  v21, v22, v24
    v.ld.w       v22, [s27, #0]
    vf.abs       v24, v23
    v.ld.w       v23, [s28, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    v.ld.w       v24, [s31, #0]
    vf.abs       v25, v23
    vf.max.ieee  v23, v22, v25
    v.ld.w       v22, [s32, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v21, v25
    v.ld.w       v21, [s26, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    v.ld.w       v24, [s34, #0]
    vf.abs       v25, v21
    vf.max.ieee  v21, v22, v25
    v.ld.w       v22, [s30, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v14, v25
    vf.reduce.max.b v14, v24
    s.addi       s26, s14, #448
    s.addi       s27, s14, #1472
    s.addi       s28, s14, #2496
    s.addi       s30, s14, #3520
    s.addi       s31, s14, #4480
    s.addi       s32, s14, #5504
    v.ld.w       v24, [s26, #0]
    s.addi       s26, s14, #6528
    vf.abs       v25, v22
    s.addi       s34, s14, #7552
    vf.max.ieee  v22, v23, v25
    v.ld.w       v23, [s27, #0]
    vf.abs       v25, v24
    v.ld.w       v24, [s28, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    v.ld.w       v25, [s31, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v23, v26
    v.ld.w       v23, [s32, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v22, v26
    v.ld.w       v22, [s26, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    v.ld.w       v25, [s33, #0]
    vf.abs       v26, v22
    vf.max.ieee  v22, v23, v26
    v.ld.w       v23, [s30, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v21, v26
    vf.reduce.max.b v21, v25
    s.addi       s26, s14, #512
    s.addi       s27, s14, #1536
    s.addi       s28, s14, #2560
    s.addi       s30, s14, #3584
    s.addi       s31, s14, #4544
    s.addi       s32, s14, #5568
    v.ld.w       v25, [s26, #0]
    s.addi       s26, s14, #6592
    vf.abs       v26, v23
    s.addi       s33, s14, #7616
    vf.max.ieee  v23, v24, v26
    v.ld.w       v24, [s27, #0]
    vf.abs       v26, v25
    v.ld.w       v25, [s28, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    v.ld.w       v26, [s31, #0]
    vf.abs       v27, v25
    vf.max.ieee  v25, v24, v27
    v.ld.w       v24, [s32, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v23, v27
    v.ld.w       v23, [s26, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    v.ld.w       v26, [s34, #0]
    vf.abs       v27, v23
    vf.max.ieee  v23, v24, v27
    v.ld.w       v24, [s30, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v22, v27
    vf.reduce.max.b v22, v26
    s.addi       s26, s14, #576
    s.addi       s27, s14, #1600
    s.addi       s28, s14, #2624
    s.addi       s30, s14, #3648
    s.addi       s31, s14, #4608
    s.addi       s32, s14, #5632
    v.ld.w       v26, [s26, #0]
    s.addi       s26, s14, #6656
    vf.abs       v27, v24
    s.addi       s34, s14, #7680
    vf.max.ieee  v24, v25, v27
    v.ld.w       v25, [s27, #0]
    vf.abs       v27, v26
    v.ld.w       v26, [s28, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    v.ld.w       v27, [s31, #0]
    vf.abs       v28, v26
    vf.max.ieee  v26, v25, v28
    v.ld.w       v25, [s32, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v24, v28
    v.ld.w       v24, [s26, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    v.ld.w       v27, [s33, #0]
    vf.abs       v28, v24
    vf.max.ieee  v24, v25, v28
    v.ld.w       v25, [s30, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v23, v28
    vf.reduce.max.b v23, v27
    s.addi       s26, s14, #640
    s.addi       s27, s14, #1664
    s.addi       s28, s14, #2688
    s.addi       s30, s14, #3712
    s.addi       s31, s14, #4672
    s.addi       s32, s14, #5696
    v.ld.w       v27, [s26, #0]
    s.addi       s26, s14, #6720
    vf.abs       v28, v25
    s.addi       s33, s14, #7744
    vf.max.ieee  v25, v26, v28
    v.ld.w       v26, [s27, #0]
    vf.abs       v28, v27
    v.ld.w       v27, [s28, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    v.ld.w       v28, [s31, #0]
    vf.abs       v29, v27
    vf.max.ieee  v27, v26, v29
    v.ld.w       v26, [s32, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v25, v29
    v.ld.w       v25, [s26, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    v.ld.w       v28, [s34, #0]
    vf.abs       v29, v25
    vf.max.ieee  v25, v26, v29
    v.ld.w       v26, [s30, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v24, v29
    vf.reduce.max.b v24, v28
    s.addi       s26, s14, #704
    s.addi       s27, s14, #1728
    s.addi       s28, s14, #2752
    s.addi       s30, s14, #3776
    s.addi       s31, s14, #4736
    s.addi       s32, s14, #5760
    v.ld.w       v28, [s26, #0]
    s.addi       s26, s14, #6784
    vf.abs       v29, v26
    s.addi       s34, s14, #7808
    vf.max.ieee  v26, v27, v29
    v.ld.w       v27, [s27, #0]
    vf.abs       v29, v28
    v.ld.w       v28, [s28, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    v.ld.w       v29, [s31, #0]
    vf.abs       v30, v28
    vf.max.ieee  v28, v27, v30
    v.ld.w       v27, [s32, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v26, v30
    v.ld.w       v26, [s26, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    v.ld.w       v29, [s33, #0]
    vf.abs       v30, v26
    vf.max.ieee  v26, v27, v30
    v.ld.w       v27, [s30, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v25, v30
    vf.reduce.max.b v25, v29
    s.addi       s26, s14, #768
    s.addi       s27, s14, #1792
    s.addi       s28, s14, #2816
    s.addi       s30, s14, #3840
    s.addi       s31, s14, #4800
    s.addi       s32, s14, #5824
    v.ld.w       v29, [s26, #0]
    s.addi       s26, s14, #6848
    vf.abs       v30, v27
    s.addi       s33, s14, #7872
    vf.max.ieee  v27, v28, v30
    v.ld.w       v28, [s27, #0]
    vf.abs       v30, v29
    v.ld.w       v29, [s28, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    v.ld.w       v30, [s31, #0]
    vf.abs       v31, v29
    vf.max.ieee  v29, v28, v31
    v.ld.w       v28, [s32, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v27, v31
    v.ld.w       v27, [s26, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    v.ld.w       v30, [s34, #0]
    vf.abs       v31, v27
    vf.max.ieee  v27, v28, v31
    v.ld.w       v28, [s30, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v26, v31
    vf.reduce.max.b v26, v30
    s.addi       s26, s14, #832
    s.addi       s27, s14, #1856
    s.addi       s28, s14, #2880
    s.addi       s30, s14, #3904
    s.addi       s31, s14, #4864
    s.addi       s32, s14, #5888
    v.ld.w       v30, [s26, #0]
    s.addi       s26, s14, #6912
    s.addi       s34, s14, #7936
    vf.abs       v31, v28
    vf.max.ieee  v28, v29, v31
    v.ld.w       v29, [s27, #0]
    vf.abs       v31, v30
    v.ld.w       v30, [s28, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    v.ld.w       v31, [s31, #0]
    vf.abs       v32, v30
    vf.max.ieee  v30, v29, v32
    v.ld.w       v29, [s32, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v28, v32
    v.ld.w       v28, [s26, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    v.ld.w       v31, [s33, #0]
    vf.abs       v32, v28
    vf.max.ieee  v28, v29, v32
    v.ld.w       v29, [s30, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v27, v32
    vf.reduce.max.b v27, v31
    s.addi       s26, s14, #896
    s.addi       s27, s14, #1920
    s.addi       s28, s14, #2944
    s.addi       s30, s14, #3968
    s.addi       s31, s14, #4928
    s.addi       s32, s14, #5952
    v.ld.w       v31, [s26, #0]
    s.addi       s26, s14, #6976
    s.addi       s33, s14, #8000
    vf.abs       v32, v29
    vf.max.ieee  v29, v30, v32
    v.ld.w       v30, [s27, #0]
    vf.abs       v32, v31
    v.ld.w       v31, [s28, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v32, v33
    v.ld.w       v32, [s31, #0]
    vf.abs       v33, v31
    vf.max.ieee  v31, v30, v33
    v.ld.w       v30, [s32, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v29, v33
    v.ld.w       v29, [s34, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v32, v33
    v.ld.w       v32, [s30, #0]
    vf.abs       v33, v29
    vf.max.ieee  v29, v28, v33
    vf.reduce.max.b v28, v29
    s.addi       s27, s14, #960
    s.addi       s28, s14, #1984
    s.addi       s30, s14, #3008
    s.addi       s31, s14, #4992
    s.addi       s32, s14, #6016
    s.addi       s34, s14, #7040
    v.ld.w       v29, [s27, #0]
    s.addi       s27, s14, #8064
    vf.abs       v33, v32
    vf.max.ieee  v32, v31, v33
    v.ld.w       v31, [s28, #0]
    vf.abs       v33, v29
    v.ld.w       v29, [s31, #0]
    vf.abs       v34, v31
    vf.max.ieee  v31, v33, v34
    v.ld.w       v33, [s32, #0]
    vf.abs       v34, v29
    vf.max.ieee  v29, v32, v34
    v.ld.w       v32, [s26, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v29, v34
    v.ld.w       v29, [s30, #0]
    vf.abs       v34, v32
    vf.max.ieee  v32, v30, v34
    s.addi       s26, s14, #4032
    v.ld.w       v30, [s33, #0]
    vf.abs       v34, v29
    vf.max.ieee  v29, v31, v34
    v.ld.w       v31, [s26, #0]
    vf.abs       v34, v30
    vf.max.ieee  v30, v32, v34
    vf.reduce.max.b v32, v30
    s.addi       s26, s14, #5056
    v.movi       v30, #0
    s.addi       s28, s14, #6080
    s.addi       s30, s14, #7104
    s.addi       s31, s14, #8128
    // one value per row into one vector (ISA 0x09)
    v.extract    s32, v19, #0
    v.ld.w       v19, [s26, #0]
    v.extract    s26, v15, #0
    v.extract    s33, v12, #0
    vf.abs       v12, v31
    vf.max.ieee  v15, v29, v12
    v.ld.w       v12, [s34, #0]
    v.extract    s34, v17, #0
    vf.abs       v17, v19
    vf.max.ieee  v19, v15, v17
    v.ld.w       v15, [s27, #0]
    vf.abs       v17, v12
    v.extract    s27, v14, #0
    vf.max.ieee  v12, v33, v17
    v.ld.w       v14, [s28, #0]
    v.extract    s28, v21, #0
    vf.abs       v17, v15
    vf.max.ieee  v15, v12, v17
    vf.reduce.max.b v12, v15
    .li       s35, #1138753536
    v.splat      v15, s35                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s35, #1065353216
    v.splat      v17, s35                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v21, v15                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v29, [s30, #0]
    v.extract    s30, v22, #0
    vf.abs       v22, v14
    vf.max.ieee  v14, v19, v22
    v.ld.w       v19, [s31, #0]
    v.insert     v30, s32, #0
    v.extract    s31, v23, #0
    v.extract    s32, v24, #0
    v.insert     v30, s26, #1
    vf.abs       v22, v29
    v.extract    s26, v25, #0
    v.insert     v30, s33, #2
    v.extract    s33, v26, #0
    vf.fms       v23, v15, v21, v17
    v.insert     v30, s34, #3
    vf.max.ieee  v24, v14, v22
    v.extract    s34, v27, #0
    v.insert     v30, s27, #4
    v.extract    s27, v28, #0
    vf.fms       v14, v21, v23, v21
    v.insert     v30, s28, #5
    v.extract    s28, v32, #0
    vf.abs       v22, v19
    v.insert     v30, s30, #6
    vf.neg       v19, v14                        // Newton step: r0*(2 - x*r0)
    v.extract    s30, v12, #0
    v.insert     v30, s31, #7
    vf.max.ieee  v12, v24, v22
    v.insert     v30, s32, #8
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v14, v19, v21
    v.insert     v30, s26, #9
    vf.reduce.max.b v19, v12
    .li       s26, #730643660
    v.splat      v12, s26                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.insert     v30, s33, #10
    v.extract    s26, v19, #0
    v.splat      v19, s18
    v.insert     v30, s34, #11
    s.add        s31, s25, s29
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    v.movi       v21, #0
    v.insert     v30, s27, #12
    v.iota       v22                             // arange(0, VLEN)
    v.movi       v23, #0
    v.insert     v30, s28, #13
    s.movz       s27, #0
    v.splat      v24, s18
    v.insert     v30, s30, #14
    v.extract    s28, v20, #0
    s.cmp.ge     s29, s31, s27
    v.insert     v30, s26, #15
    v.splat      v25, s28
    s.movz       s26, #0
    vf.mul       v26, v30, v14                   // a/y: faithful quotient
    v.add        v27, v25, v22
    s.movz       s27, #0
    v.ld.gather.w v25, [s24, v1]                 // index is in elements (ISA sec 9.1)
    v.sub        v28, v20, v27
    vf.fms       v27, v26, v15, v30
    s.cmp.ge     s30, s28, s27
    v.reduce.or  s27, v28
    v.splat      v15, s18
    s.cmp.eq     s32, s27, s26
    vf.fms       v28, v27, v14, v26
    v.extract    s26, v18, #0
    s.and        s27, s32, s30
    v.splat      v14, s18
    s.and        s30, s27, s29
    vf.neg       v27, v28                        // a/y: one correction to the IEEE quotient
    v.splat      v28, s26
    v.splat      v29, s18
    v.splat      v30, s18
    v.splat      v31, s18
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v32, v27, v26
    v.add        v26, v28, v22
    s.movz       s27, #0
    v.ld.gather.w v27, [s24, v2]                 // index is in elements (ISA sec 9.1)
    v.sub        v28, v18, v26
    v.splat      v26, s18
    v.mul        v33, v20, v19
    v.reduce.or  s32, v28
    s.movz       s33, #0
    s.cmp.eq     s34, s32, s27
    v.mul        v19, v18, v24
    s.cmp.ge     s27, s26, s33
    v.mul        v24, v16, v15
    s.and        s32, s34, s27
    v.mul        v15, v10, v14
    v.extract    s27, v16, #0
    s.and        s33, s32, s29
    v.mul        v14, v9, v29
    v.splat      v28, s27
    v.mul        v29, v8, v30
    v.mul        v30, v7, v31
    v.add        v31, v28, v22
    s.movz       s32, #0
    v.ld.gather.w v28, [s24, v5]                 // index is in elements (ISA sec 9.1)
    v.sub        v34, v16, v31
    v.mul        v31, v3, v26
    s.movz       s34, #0
    s.cmp.ge     s35, s27, s34
    v.ld.gather.w v26, [s24, v6]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s24, v11]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v36, [s24, v13]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v37, [s24, v4]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v38, [s24, v0]                 // index is in elements (ISA sec 9.1)
    v.insert     v21, s30, #0
    v.extract    s30, v10, #0
    v.insert     v23, s28, #0
    v.splat      v39, s30
    v.extract    s28, v9, #0
    v.insert     v21, s33, #1
    v.add        v40, v39, v22
    v.splat      v39, s28
    v.extract    s33, v8, #0
    v.sub        v41, v10, v40
    v.add        v40, v39, v22
    v.splat      v39, s33
    v.insert     v23, s26, #1
    v.reduce.or  s26, v34
    v.sub        v34, v9, v40
    s.cmp.eq     s34, s26, s32
    v.extract    s26, v7, #0
    v.add        v40, v39, v22
    v.splat      v39, s26
    s.and        s32, s34, s35
    v.reduce.or  s34, v41
    s.and        s35, s32, s29
    v.sub        v41, v8, v40
    v.add        v40, v39, v22
    v.insert     v21, s35, #2
    s.movz       s32, #0
    v.insert     v23, s27, #2
    s.movz       s27, #0
    s.cmp.eq     s35, s34, s32
    v.extract    s32, v3, #0
    s.cmp.ge     s34, s30, s27
    v.splat      v39, s32
    s.and        s27, s35, s34
    v.reduce.or  s34, v34
    s.and        s35, s27, s29
    v.sub        v34, v7, v40
    v.add        v40, v39, v22
    v.insert     v21, s35, #3
    s.movz       s27, #0
    v.insert     v23, s30, #3
    s.movz       s30, #0
    s.cmp.eq     s35, s34, s27
    s.cmp.ge     s27, s28, s30
    v.reduce.or  s30, v41
    s.and        s34, s35, s27
    s.movz       s27, #0
    s.and        s35, s34, s29
    s.cmp.eq     s34, s30, s27
    s.movz       s27, #0
    v.sub        v22, v3, v40
    s.cmp.ge     s30, s33, s27
    v.insert     v21, s35, #4
    v.reduce.or  s27, v34
    s.and        s35, s34, s30
    s.movz       s30, #0
    v.insert     v23, s28, #4
    s.movz       s28, #0
    s.cmp.eq     s34, s27, s30
    s.cmp.ge     s27, s26, s28
    s.and        s28, s35, s29
    v.reduce.or  s30, v22
    s.and        s35, s34, s27
    s.movz       s27, #0
    v.insert     v21, s28, #5
    s.movz       s28, #0
    v.insert     v23, s33, #5
    s.cmp.eq     s33, s30, s27
    s.cmp.ge     s27, s32, s28
    s.and        s28, s35, s29
    s.and        s30, s33, s27
    v.insert     v21, s28, #6
    v.insert     v23, s26, #6
    v.extract    s26, v32, #0
    s.and        s27, s30, s29
    v.splat      v22, s26
    s.add        s26, s12, s23
    s.addi       s28, s14, #8192                 // TensorMap 0: W's rows for a transposed FP8 B
    vf.max.ieee  v34, v22, v12
    .li       s29, #2147483647
    s.movz       s30, #1
    .li       s33, #137438953488
    .li       s34, #7705171329024
    v.insert     v21, s27, #7
    v.rcp.approx v22, v34                        // ISA 8.8: <= 2**-22 relative
    s.addi       s27, s14, #8448
    v.insert     v23, s32, #7
    s.addi       s32, s14, #8960                 // TensorMap 1: the gathered fallback B tile
    s.st.d       [s28, #0], s26
    s.movz       s26, #32
    s.movz       s35, #0
    s.movz       s35, #0
    s.st.d       [s28, #8], s29
    s.movz       s29, #16
    s.st.d       [s28, #16], s31
    vf.fms       v39, v34, v22, v17
    vf.fms       v40, v22, v39, v22
    s.st.d       [s28, #48], s18
    vf.neg       v39, v40                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v39, v39
    @p1 v.sel        v40, v39, v22
    s.st.d       [s28, #56], s30
    s.movz       s30, #16
    s.st.d       [s28, #88], s33
    s.movz       s33, #1
    v.movi       v22, #24
    s.st.d       [s28, #104], s34
    .li       s34, #68719476768
    td.load      d0, [s28]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s28, #7705171329024
    v.movi       v39, #128
    s.st.d       [s32, #0], s27
    s.addi       s27, s14, #0
    s.st.d       [s32, #8], s26
    v.extract    s26, v32, #1
    v.splat      v41, s26
    s.addi       s26, s14, #9216                 // 512 bytes of repack scratch
    s.st.d       [s32, #16], s29
    vf.max.ieee  v42, v41, v12
    s.addi       s29, s26, #0
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    s.st.d       [s32, #48], s30
    s.addi       s30, s14, #64
    s.st.d       [s32, #56], s33
    s.st.d       [s32, #88], s34
    vf.fms       v43, v42, v41, v17
    vf.fms       v44, v41, v43, v41
    s.st.d       [s32, #104], s28
    td.load      d1, [s32]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v44, [s27, #0]
    v.extract    s27, v32, #2
    s.addi       s28, s26, #32
    v.splat      v45, s27
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v46, v43, v41
    vf.max.ieee  v41, v45, v12
    s.addi       s27, s14, #128
    v.rcp.approx v43, v41                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v44, v40                   // a/y: faithful quotient
    vf.fms       v47, v45, v34, v44
    vf.fms       v34, v47, v40, v45
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v45
    vf.fms       v40, v41, v43, v17
    v.lshr       v44, v34, v22
    vf.cvt.f32.e4m3 v45, v34
    v.and        v34, v44, v39
    vf.fms       v44, v43, v40, v43
    s.addi       s32, s26, #64
    v.or         v40, v45, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s33, s14, #192
    v.st.b       [s29, #0], v40
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.extract    s29, v32, #3
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v43
    v.ld.w       v34, [s30, #0]
    v.splat      v43, s29
    vf.max.ieee  v44, v43, v12
    v.rcp.approx v43, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v34, v46                   // a/y: faithful quotient
    vf.fms       v47, v45, v42, v34
    vf.fms       v34, v47, v46, v45
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v43, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v45
    v.lshr       v42, v46, v22
    vf.cvt.f32.e4m3 v45, v46
    vf.fms       v46, v43, v34, v43
    v.and        v34, v42, v39
    s.addi       s29, s26, #96
    v.or         v42, v45, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v46                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #256
    v.st.b       [s28, #0], v42
    v.extract    s28, v32, #4
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v43
    v.ld.w       v34, [s27, #0]
    v.splat      v43, s28
    vf.max.ieee  v45, v43, v12
    v.rcp.approx v43, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v41, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v43, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v41, v40, v46
    v.lshr       v40, v41, v22
    vf.cvt.f32.e4m3 v46, v41
    vf.fms       v41, v43, v34, v43
    v.and        v34, v40, v39
    s.addi       s27, s26, #128
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v41                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #320
    v.st.b       [s32, #0], v40
    v.extract    s32, v32, #5
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v43
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s32
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s32, s26, #160
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #384
    v.st.b       [s29, #0], v42
    v.extract    s29, v32, #6
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s30, #0]
    v.splat      v41, s29
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s29, s26, #192
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #448
    v.st.b       [s27, #0], v40
    v.extract    s27, v32, #7
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s27
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s27, s26, #224
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #512
    v.st.b       [s32, #0], v42
    v.extract    s32, v32, #8
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s32
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s32, s26, #256
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #576
    v.st.b       [s29, #0], v40
    v.extract    s29, v32, #9
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s30, #0]
    v.splat      v41, s29
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s29, s26, #288
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #640
    v.st.b       [s27, #0], v42
    v.extract    s27, v32, #10
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s27
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s27, s26, #320
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #704
    v.st.b       [s32, #0], v40
    v.extract    s32, v32, #11
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s32
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s32, s26, #352
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #768
    v.st.b       [s29, #0], v42
    v.extract    s29, v32, #12
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s30, #0]
    v.splat      v41, s29
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s29, s26, #384
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #832
    v.st.b       [s27, #0], v40
    v.extract    s27, v32, #13
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s27
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s27, s26, #416
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #896
    v.st.b       [s32, #0], v42
    v.extract    s32, v32, #14
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s32
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s32, s26, #448
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #960
    v.st.b       [s29, #0], v40
    v.extract    s29, v32, #15
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s30, #0]
    v.splat      v41, s29
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s29, s26, #480
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #1024
    v.st.b       [s27, #0], v42
    v.extract    s27, v32, #0
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s27
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s27, s26, #16
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #1088
    v.st.b       [s32, #0], v40
    v.extract    s32, v32, #1
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s32
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s32, s26, #48
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #1152
    v.st.b       [s29, #0], v42
    v.extract    s29, v32, #2
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s30, #0]
    v.splat      v41, s29
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s29, s26, #80
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #1216
    v.st.b       [s27, #0], v40
    v.extract    s27, v32, #3
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s27
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s27, s26, #112
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #1280
    v.st.b       [s32, #0], v42
    v.extract    s32, v32, #4
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s32
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s32, s26, #144
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #1344
    v.st.b       [s29, #0], v40
    v.extract    s29, v32, #5
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s30, #0]
    v.splat      v41, s29
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s29, s26, #176
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #1408
    v.st.b       [s27, #0], v42
    v.extract    s27, v32, #6
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s27
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s27, s26, #208
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #1472
    v.st.b       [s32, #0], v40
    v.extract    s32, v32, #7
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s32
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s32, s26, #240
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #1536
    v.st.b       [s29, #0], v42
    v.extract    s29, v32, #8
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s30, #0]
    v.splat      v41, s29
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s29, s26, #272
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #1600
    v.st.b       [s27, #0], v40
    v.extract    s27, v32, #9
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s27
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s27, s26, #304
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #1664
    v.st.b       [s32, #0], v42
    v.extract    s32, v32, #10
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s32
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s32, s26, #336
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #1728
    v.st.b       [s29, #0], v40
    v.extract    s29, v32, #11
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s30, #0]
    v.splat      v41, s29
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s29, s26, #368
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #1792
    v.st.b       [s27, #0], v42
    v.extract    s27, v32, #12
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s27
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s27, s26, #400
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s14, #1856
    v.st.b       [s32, #0], v40
    v.extract    s32, v32, #13
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s32
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s32, s26, #432
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s14, #1920
    v.st.b       [s29, #0], v42
    v.extract    s29, v32, #14
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s30, #0]
    v.splat      v41, s29
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s29, s26, #464
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s30, s14, #1984
    v.st.b       [s27, #0], v40
    v.extract    s27, v32, #15
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s27
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s27, s26, #496
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s32, #0], v42
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s33, #0]
    s.addi       s28, s26, #64
    s.addi       s32, s26, #128
    s.addi       s33, s26, #192
    vf.mul       v41, v34, v40                   // a/y: faithful quotient
    s.addi       s34, s26, #256
    vf.fms       v43, v41, v44, v34
    vf.fms       v34, v43, v40, v41
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.lshr       v40, v34, v22
    vf.cvt.f32.e4m3 v41, v34
    v.and        v34, v40, v39
    v.or         v40, v41, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v40
    s.addi       s29, s26, #320
    v.ld.w       v34, [s30, #0]
    s.addi       s30, s26, #384
    vf.mul       v40, v34, v42                   // a/y: faithful quotient
    vf.fms       v41, v40, v45, v34
    vf.fms       v34, v41, v42, v40
    vf.neg       v41, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v34, v41, v40
    v.lshr       v40, v34, v22
    vf.cvt.f32.e4m3 v41, v34
    v.and        v34, v40, v39
    v.or         v40, v41, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s27, #0], v40
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s27, s26, #448
    v.ld.w       v34, [s26, #0]
    v.extract    s26, v21, #0
    v.mov        v48, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s28, #0]
    v.mov        v49, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s32, #0]
    v.mov        v50, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s33, #0]
    v.mov        v51, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s34, #0]
    v.mov        v52, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s29, #0]
    v.mov        v53, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s30, #0]
    v.mov        v54, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s27, #0]
    v.mov        v55, v34                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s26, x8dot_done_27
    s.movz       s27, #0
    s.add        s28, s12, s23
    s.addi       s29, s27, #0
    s.addi       s27, s14, #8448
x8dot_row_28:
    s.addi       s30, s31, #0
    v.movi       v34, #0
    s.sub        s32, s30, s29
    s.add        s30, s28, s29
    v.splat      v40, s32
    s.shli       s32, s29, #4
    s.addi       s33, s29, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s30, v33]            // index is in elements (ISA sec 9.1)
    s.add        s30, s27, s32
    s.movz       s32, #32
    v.st.b       [s30, #0], v34
    fence.acq_rel.device
    s.mov        s29, s33
    s.cmp.lt     s30, s29, s32
    br.nz        s30, x8dot_row_28
x8dot_done_27:
    v.splat      v34, s26
    v.movi       v40, #0
    v.splat      v41, s26
    v.movi       v42, #0
    mb.arm       s26, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s27, #0
    s.movz       s28, #0
    v.extract    s29, v23, #0
    s.movz       s30, #0
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s32, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s32, s26            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s27, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s27, s26          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s26
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s28, v21, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s27
    mb.wait      s27
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s28, x8dot_done_29
    s.movz       s29, #0
    s.add        s30, s12, s23
    s.addi       s32, s29, #0
    s.addi       s29, s14, #8448
x8dot_row_30:
    s.addi       s33, s31, #0
    v.movi       v34, #0
    s.sub        s34, s33, s32
    s.add        s33, s30, s32
    v.splat      v40, s34
    s.shli       s34, s32, #4
    s.addi       s35, s32, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s33, v19]            // index is in elements (ISA sec 9.1)
    s.add        s33, s29, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v34
    fence.acq_rel.device
    s.mov        s32, s35
    s.cmp.lt     s33, s32, s34
    br.nz        s33, x8dot_row_30
x8dot_done_29:
    v.splat      v34, s28
    v.movi       v40, #0
    v.splat      v41, s28
    v.movi       v42, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    s.movz       s30, #0
    v.extract    s32, v23, #1
    s.movz       s33, #0
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s30, v21, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_31
    s.movz       s32, #0
    s.add        s33, s12, s23
    s.addi       s34, s32, #0
    s.addi       s32, s14, #8448
x8dot_row_32:
    s.addi       s35, s31, #0
    v.movi       v34, #0
    s.sub        s36, s35, s34
    s.add        s35, s33, s34
    v.splat      v40, s36
    s.shli       s36, s34, #4
    s.addi       s37, s34, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s35, v24]            // index is in elements (ISA sec 9.1)
    s.add        s35, s32, s36
    s.movz       s36, #32
    v.st.b       [s35, #0], v34
    fence.acq_rel.device
    s.mov        s34, s37
    s.cmp.lt     s35, s34, s36
    br.nz        s35, x8dot_row_32
x8dot_done_31:
    v.splat      v34, s30
    v.movi       v40, #0
    v.splat      v41, s30
    v.movi       v42, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    s.movz       s33, #0
    v.extract    s34, v23, #2
    s.movz       s35, #0
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v21, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_33
    s.movz       s34, #0
    s.add        s35, s12, s23
    s.addi       s36, s34, #0
    s.addi       s34, s14, #8448
x8dot_row_34:
    s.addi       s37, s31, #0
    v.movi       v34, #0
    s.sub        s38, s37, s36
    s.add        s37, s35, s36
    v.splat      v40, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s37, v15]            // index is in elements (ISA sec 9.1)
    s.add        s37, s34, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v34
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_34
x8dot_done_33:
    v.splat      v34, s33
    v.movi       v40, #0
    v.splat      v41, s33
    v.movi       v42, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    s.movz       s35, #0
    v.extract    s36, v23, #3
    s.movz       s37, #0
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v21, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_35
    s.movz       s36, #0
    s.add        s37, s12, s23
    s.addi       s38, s36, #0
    s.addi       s36, s14, #8448
x8dot_row_36:
    s.addi       s39, s31, #0
    v.movi       v34, #0
    s.sub        s40, s39, s38
    s.add        s39, s37, s38
    v.splat      v40, s40
    s.shli       s40, s38, #4
    s.addi       s41, s38, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s39, v14]            // index is in elements (ISA sec 9.1)
    s.add        s39, s36, s40
    s.movz       s40, #32
    v.st.b       [s39, #0], v34
    fence.acq_rel.device
    s.mov        s38, s41
    s.cmp.lt     s39, s38, s40
    br.nz        s39, x8dot_row_36
x8dot_done_35:
    v.splat      v34, s35
    v.movi       v40, #0
    v.splat      v41, s35
    v.movi       v42, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    s.movz       s37, #0
    v.extract    s38, v23, #4
    s.movz       s39, #0
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v21, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_37
    s.movz       s38, #0
    s.add        s39, s12, s23
    s.addi       s40, s38, #0
    s.addi       s38, s14, #8448
x8dot_row_38:
    s.addi       s41, s31, #0
    v.movi       v34, #0
    s.sub        s42, s41, s40
    s.add        s41, s39, s40
    v.splat      v40, s42
    s.shli       s42, s40, #4
    s.addi       s43, s40, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s41, v29]            // index is in elements (ISA sec 9.1)
    s.add        s41, s38, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v34
    fence.acq_rel.device
    s.mov        s40, s43
    s.cmp.lt     s41, s40, s42
    br.nz        s41, x8dot_row_38
x8dot_done_37:
    v.splat      v34, s37
    v.movi       v40, #0
    v.splat      v41, s37
    v.movi       v42, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    s.movz       s39, #0
    v.extract    s40, v23, #5
    s.movz       s41, #0
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v21, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_39
    s.movz       s40, #0
    s.add        s41, s12, s23
    s.addi       s42, s40, #0
    s.addi       s40, s14, #8448
x8dot_row_40:
    s.addi       s43, s31, #0
    v.movi       v34, #0
    s.sub        s44, s43, s42
    s.add        s43, s41, s42
    v.splat      v40, s44
    s.shli       s44, s42, #4
    s.addi       s45, s42, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s43, v30]            // index is in elements (ISA sec 9.1)
    s.add        s43, s40, s44
    s.movz       s44, #32
    v.st.b       [s43, #0], v34
    fence.acq_rel.device
    s.mov        s42, s45
    s.cmp.lt     s43, s42, s44
    br.nz        s43, x8dot_row_40
x8dot_done_39:
    v.splat      v34, s39
    v.movi       v40, #0
    v.splat      v41, s39
    v.movi       v42, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    s.movz       s41, #0
    v.extract    s42, v23, #6
    s.movz       s43, #0
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s44, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v21, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s41, x8dot_done_41
    s.movz       s42, #0
    s.add        s43, s12, s23
    s.addi       s44, s42, #0
    s.addi       s42, s14, #8448
x8dot_row_42:
    s.addi       s45, s31, #0
    v.movi       v34, #0
    s.sub        s46, s45, s44
    s.add        s45, s43, s44
    v.splat      v40, s46
    s.shli       s46, s44, #4
    s.addi       s47, s44, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s45, v31]            // index is in elements (ISA sec 9.1)
    s.add        s45, s42, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v34
    fence.acq_rel.device
    s.mov        s44, s47
    s.cmp.lt     s45, s44, s46
    br.nz        s45, x8dot_row_42
x8dot_done_41:
    v.extract    s42, v32, #0
    v.splat      v34, s41
    v.splat      v40, s42
    v.movi       v41, #0
    v.splat      v42, s41
    vf.max.ieee  v43, v40, v12
    v.movi       v40, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    s.movz       s43, #0
    v.rcp.approx v44, v43                        // ISA 8.8: <= 2**-22 relative
    v.extract    s44, v23, #7
    s.movz       s45, #0
    v.cmp.ne     p1, v34, v41
    v.cmp.eq     p2, v42, v40
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s46, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s43, s14, #2048
    v.extract    s44, v32, #1
    m.mma.async.k32.e4m3 a15, v48, v56, s42
    mb.wait      s42
    v.ld.w       v34, [s43, #0]
    v.splat      v40, s44
    s.addi       s43, s14, #9728                 // 512 bytes of repack scratch
    s.addi       s44, s14, #2112
    vf.max.ieee  v41, v40, v12
    s.addi       s45, s43, #0
    v.extract    s46, v32, #2
    s.addi       s47, s43, #32
    v.splat      v40, s46
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s14, #2176
    vf.max.ieee  v45, v40, v12
    vf.fms       v40, v43, v44, v17
    v.rcp.approx v46, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v47, v44, v40, v44
    vf.neg       v40, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v47, v40, v44
    vf.mul       v40, v34, v47                   // a/y: faithful quotient
    vf.fms       v44, v40, v43, v34
    vf.fms       v34, v41, v42, v17
    vf.fms       v43, v44, v47, v40
    vf.fms       v44, v42, v34, v42
    vf.fms       v34, v45, v46, v17
    vf.neg       v47, v43                        // a/y: one correction to the IEEE quotient
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.fms       v44, v46, v34, v46
    vf.cmp.o     p1, v47, v47
    @p1 v.sel        v34, v47, v40
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v40, v43, v42
    v.lshr       v42, v34, v22
    vf.cvt.f32.e4m3 v43, v34
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.and        v44, v42, v39
    s.addi       s48, s43, #64
    v.or         v42, v43, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.st.b       [s45, #0], v42
    v.extract    s45, v32, #3
    v.ld.w       v34, [s44, #0]
    v.splat      v42, s45
    s.addi       s44, s14, #2240
    vf.max.ieee  v44, v42, v12
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v41, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v42, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v41, v40, v46
    v.lshr       v40, v41, v22
    vf.cvt.f32.e4m3 v46, v41
    vf.fms       v41, v42, v34, v42
    v.and        v34, v40, v39
    s.addi       s45, s43, #96
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v41                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v40
    v.extract    s47, v32, #4
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v42
    v.ld.w       v34, [s46, #0]
    v.splat      v41, s47
    s.addi       s46, s14, #2304
    vf.max.ieee  v42, v41, v12
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v43, v46
    vf.neg       v43, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v42, v41, v17
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v45, v43, v46
    v.lshr       v43, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v43, v39
    s.addi       s47, s43, #128
    v.or         v43, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v43
    v.extract    s48, v32, #5
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s48
    s.addi       s44, s14, #2368
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s48, s43, #160
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s45, #0], v40
    v.extract    s45, v32, #6
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s46, #0]
    v.splat      v41, s45
    s.addi       s45, s14, #2432
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v42, v34
    vf.fms       v34, v47, v43, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s46, s43, #192
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v42
    v.extract    s47, v32, #7
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s47
    s.addi       s44, s14, #2496
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s47, s43, #224
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v40
    v.extract    s48, v32, #8
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    v.splat      v41, s48
    s.addi       s45, s14, #2560
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s48, s43, #256
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v42
    v.extract    s46, v32, #9
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s46
    s.addi       s44, s14, #2624
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s46, s43, #288
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v40
    v.extract    s47, v32, #10
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    v.splat      v41, s47
    s.addi       s45, s14, #2688
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s47, s43, #320
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v42
    v.extract    s48, v32, #11
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s48
    s.addi       s44, s14, #2752
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s48, s43, #352
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v40
    v.extract    s46, v32, #12
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    v.splat      v41, s46
    s.addi       s45, s14, #2816
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s46, s43, #384
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v42
    v.extract    s47, v32, #13
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s47
    s.addi       s44, s14, #2880
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s47, s43, #416
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v40
    v.extract    s48, v32, #14
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    v.splat      v41, s48
    s.addi       s45, s14, #2944
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s48, s43, #448
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v42
    v.extract    s46, v32, #15
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s46
    s.addi       s44, s14, #3008
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s46, s43, #480
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v40
    v.extract    s47, v32, #0
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    v.splat      v41, s47
    s.addi       s45, s14, #3072
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s47, s43, #16
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v42
    v.extract    s48, v32, #1
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s48
    s.addi       s44, s14, #3136
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s48, s43, #48
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v40
    v.extract    s46, v32, #2
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    v.splat      v41, s46
    s.addi       s45, s14, #3200
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s46, s43, #80
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v42
    v.extract    s47, v32, #3
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s47
    s.addi       s44, s14, #3264
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s47, s43, #112
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v40
    v.extract    s48, v32, #4
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    v.splat      v41, s48
    s.addi       s45, s14, #3328
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s48, s43, #144
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v42
    v.extract    s46, v32, #5
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s46
    s.addi       s44, s14, #3392
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s46, s43, #176
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v40
    v.extract    s47, v32, #6
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    v.splat      v41, s47
    s.addi       s45, s14, #3456
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s47, s43, #208
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v42
    v.extract    s48, v32, #7
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s48
    s.addi       s44, s14, #3520
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s48, s43, #240
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v40
    v.extract    s46, v32, #8
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    v.splat      v41, s46
    s.addi       s45, s14, #3584
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s46, s43, #272
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v42
    v.extract    s47, v32, #9
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s47
    s.addi       s44, s14, #3648
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s47, s43, #304
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v40
    v.extract    s48, v32, #10
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    v.splat      v41, s48
    s.addi       s45, s14, #3712
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s48, s43, #336
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v42
    v.extract    s46, v32, #11
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s46
    s.addi       s44, s14, #3776
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s46, s43, #368
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v40
    v.extract    s47, v32, #12
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    v.splat      v41, s47
    s.addi       s45, s14, #3840
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s47, s43, #400
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v42
    v.extract    s48, v32, #13
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s48
    s.addi       s44, s14, #3904
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s48, s43, #432
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v40
    v.extract    s46, v32, #14
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    v.splat      v41, s46
    s.addi       s45, s14, #3968
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s46, s43, #464
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v42
    v.extract    s47, v32, #15
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s44, #0]
    v.splat      v41, s47
    s.addi       s44, s14, #4032
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s47, s43, #496
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v40
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s45, #0]
    s.addi       s45, s43, #64
    s.addi       s48, s43, #128
    vf.mul       v41, v34, v42                   // a/y: faithful quotient
    vf.fms       v45, v41, v44, v34
    vf.fms       v34, v45, v42, v41
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v34, v42, v41
    v.lshr       v41, v34, v22
    vf.cvt.f32.e4m3 v42, v34
    v.and        v34, v41, v39
    v.or         v41, v42, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v41
    s.addi       s46, s43, #192
    v.ld.w       v34, [s44, #0]
    s.addi       s44, s43, #256
    vf.mul       v41, v34, v40                   // a/y: faithful quotient
    vf.fms       v42, v41, v43, v34
    vf.fms       v34, v42, v40, v41
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.lshr       v40, v34, v22
    vf.cvt.f32.e4m3 v41, v34
    v.and        v34, v40, v39
    v.or         v40, v41, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v40
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s47, s43, #320
    v.ld.w       v34, [s43, #0]
    v.mov        v48, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s45, #0]
    s.addi       s45, s43, #384
    s.addi       s49, s43, #448
    v.mov        v49, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s48, #0]
    v.extract    s43, v21, #0
    v.mov        v50, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s46, #0]
    v.mov        v51, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s44, #0]
    v.mov        v52, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s47, #0]
    v.mov        v53, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s45, #0]
    v.mov        v54, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s49, #0]
    v.mov        v55, v34                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s43, x8dot_done_43
    s.movz       s44, #0
    s.add        s45, s12, s23
    s.addi       s46, s44, #0
    s.addi       s44, s45, #32
    s.addi       s45, s14, #8448
x8dot_row_44:
    s.addi       s47, s31, #-32
    v.movi       v34, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v40, s48
    s.shli       s48, s46, #4
    s.addi       s49, s46, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s47, v33]            // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.movz       s48, #32
    v.st.b       [s47, #0], v34
    fence.acq_rel.device
    s.mov        s46, s49
    s.cmp.lt     s47, s46, s48
    br.nz        s47, x8dot_row_44
x8dot_done_43:
    v.splat      v34, s43
    v.movi       v40, #0
    v.splat      v41, s43
    v.movi       v42, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    s.movz       s45, #0
    v.extract    s46, v23, #0
    s.movz       s47, #32
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s48, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v21, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s45, x8dot_done_45
    s.movz       s46, #0
    s.add        s47, s12, s23
    s.addi       s48, s46, #0
    s.addi       s46, s47, #32
    s.addi       s47, s14, #8448
x8dot_row_46:
    s.addi       s49, s31, #-32
    v.movi       v34, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v40, s50
    s.shli       s50, s48, #4
    s.addi       s51, s48, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s49, v19]            // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v34
    fence.acq_rel.device
    s.mov        s48, s51
    s.cmp.lt     s49, s48, s50
    br.nz        s49, x8dot_row_46
x8dot_done_45:
    v.splat      v34, s45
    v.movi       v40, #0
    v.splat      v41, s45
    v.movi       v42, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    s.movz       s47, #0
    v.extract    s48, v23, #1
    s.movz       s49, #32
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s50, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v21, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s47, x8dot_done_47
    s.movz       s48, #0
    s.add        s49, s12, s23
    s.addi       s50, s48, #0
    s.addi       s48, s49, #32
    s.addi       s49, s14, #8448
x8dot_row_48:
    s.addi       s51, s31, #-32
    v.movi       v34, #0
    s.sub        s52, s51, s50
    s.add        s51, s48, s50
    v.splat      v40, s52
    s.shli       s52, s50, #4
    s.addi       s53, s50, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s51, v24]            // index is in elements (ISA sec 9.1)
    s.add        s51, s49, s52
    s.movz       s52, #32
    v.st.b       [s51, #0], v34
    fence.acq_rel.device
    s.mov        s50, s53
    s.cmp.lt     s51, s50, s52
    br.nz        s51, x8dot_row_48
x8dot_done_47:
    v.splat      v34, s47
    v.movi       v40, #0
    v.splat      v41, s47
    v.movi       v42, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    s.movz       s49, #0
    v.extract    s50, v23, #2
    s.movz       s51, #32
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s52, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s48, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s48, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v21, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s49, x8dot_done_49
    s.movz       s50, #0
    s.add        s51, s12, s23
    s.addi       s52, s50, #0
    s.addi       s50, s51, #32
    s.addi       s51, s14, #8448
x8dot_row_50:
    s.addi       s53, s31, #-32
    v.movi       v34, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v40, s54
    s.shli       s54, s52, #4
    s.addi       s55, s52, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s53, v15]            // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v34
    fence.acq_rel.device
    s.mov        s52, s55
    s.cmp.lt     s53, s52, s54
    br.nz        s53, x8dot_row_50
x8dot_done_49:
    v.splat      v34, s49
    v.movi       v40, #0
    v.splat      v41, s49
    v.movi       v42, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    s.movz       s51, #0
    v.extract    s52, v23, #3
    s.movz       s53, #32
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s54, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v21, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s51, x8dot_done_51
    s.movz       s52, #0
    s.add        s53, s12, s23
    s.addi       s54, s52, #0
    s.addi       s52, s53, #32
    s.addi       s53, s14, #8448
x8dot_row_52:
    s.addi       s55, s31, #-32
    v.movi       v34, #0
    s.sub        s56, s55, s54
    s.add        s55, s52, s54
    v.splat      v40, s56
    s.shli       s56, s54, #4
    s.addi       s57, s54, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s55, v14]            // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    s.movz       s56, #32
    v.st.b       [s55, #0], v34
    fence.acq_rel.device
    s.mov        s54, s57
    s.cmp.lt     s55, s54, s56
    br.nz        s55, x8dot_row_52
x8dot_done_51:
    v.splat      v34, s51
    v.movi       v40, #0
    v.splat      v41, s51
    v.movi       v42, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    s.movz       s53, #0
    v.extract    s54, v23, #4
    s.movz       s55, #32
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s56, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v21, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_53
    s.movz       s54, #0
    s.add        s55, s12, s23
    s.addi       s56, s54, #0
    s.addi       s54, s55, #32
    s.addi       s55, s14, #8448
x8dot_row_54:
    s.addi       s57, s31, #-32
    v.movi       v34, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v40, s58
    s.shli       s58, s56, #4
    s.addi       s59, s56, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s57, v29]            // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v34
    fence.acq_rel.device
    s.mov        s56, s59
    s.cmp.lt     s57, s56, s58
    br.nz        s57, x8dot_row_54
x8dot_done_53:
    v.splat      v34, s53
    v.movi       v40, #0
    v.splat      v41, s53
    v.movi       v42, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    s.movz       s55, #0
    v.extract    s56, v23, #5
    s.movz       s57, #32
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s58, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v21, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s55, x8dot_done_55
    s.movz       s56, #0
    s.add        s57, s12, s23
    s.addi       s58, s56, #0
    s.addi       s56, s57, #32
    s.addi       s57, s14, #8448
x8dot_row_56:
    s.addi       s59, s31, #-32
    v.movi       v34, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v40, s60
    s.shli       s60, s58, #4
    s.addi       s26, s58, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s59, v30]            // index is in elements (ISA sec 9.1)
    s.add        s27, s57, s60
    s.movz       s28, #32
    v.st.b       [s27, #0], v34
    fence.acq_rel.device
    s.mov        s58, s26
    s.cmp.lt     s26, s58, s28
    br.nz        s26, x8dot_row_56
x8dot_done_55:
    v.splat      v34, s55
    v.movi       v40, #0
    v.splat      v41, s55
    v.movi       v42, #0
    mb.arm       s26, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s27, #0
    s.movz       s28, #0
    v.extract    s29, v23, #6
    s.movz       s30, #32
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s32, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s32, s26            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s27, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s27, s26          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s26
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s28, v21, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s27
    mb.wait      s27
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s28, x8dot_done_57
    s.movz       s29, #0
    s.add        s30, s12, s23
    s.addi       s32, s29, #0
    s.addi       s29, s30, #32
    s.addi       s30, s14, #8448
x8dot_row_58:
    s.addi       s33, s31, #-32
    v.movi       v34, #0
    s.sub        s34, s33, s32
    s.add        s33, s29, s32
    v.splat      v40, s34
    s.shli       s34, s32, #4
    s.addi       s35, s32, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s33, v31]            // index is in elements (ISA sec 9.1)
    s.add        s33, s30, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v34
    fence.acq_rel.device
    s.mov        s32, s35
    s.cmp.lt     s33, s32, s34
    br.nz        s33, x8dot_row_58
x8dot_done_57:
    v.extract    s29, v32, #0
    v.splat      v34, s28
    v.splat      v40, s29
    v.movi       v41, #0
    v.splat      v42, s28
    vf.max.ieee  v43, v40, v12
    v.movi       v40, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    s.movz       s30, #0
    v.rcp.approx v44, v43                        // ISA 8.8: <= 2**-22 relative
    v.extract    s32, v23, #7
    s.movz       s33, #32
    v.cmp.ne     p1, v34, v41
    v.cmp.eq     p2, v42, v40
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s30, s14, #4096
    v.extract    s32, v32, #1
    m.mma.async.k32.e4m3 a15, v48, v56, s29
    mb.wait      s29
    v.ld.w       v34, [s30, #0]
    v.splat      v40, s32
    s.addi       s30, s14, #10240                // 512 bytes of repack scratch
    s.addi       s32, s14, #4160
    vf.max.ieee  v41, v40, v12
    s.addi       s33, s30, #0
    v.extract    s34, v32, #2
    s.addi       s35, s30, #32
    v.splat      v40, s34
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s34, s14, #4224
    vf.max.ieee  v45, v40, v12
    vf.fms       v40, v43, v44, v17
    v.rcp.approx v46, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v47, v44, v40, v44
    vf.neg       v40, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v47, v40, v44
    vf.mul       v40, v34, v47                   // a/y: faithful quotient
    vf.fms       v44, v40, v43, v34
    vf.fms       v34, v41, v42, v17
    vf.fms       v43, v44, v47, v40
    vf.fms       v44, v42, v34, v42
    vf.fms       v34, v45, v46, v17
    vf.neg       v47, v43                        // a/y: one correction to the IEEE quotient
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.fms       v44, v46, v34, v46
    vf.cmp.o     p1, v47, v47
    @p1 v.sel        v34, v47, v40
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v40, v43, v42
    v.lshr       v42, v34, v22
    vf.cvt.f32.e4m3 v43, v34
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.and        v44, v42, v39
    s.addi       s36, s30, #64
    v.or         v42, v43, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.st.b       [s33, #0], v42
    v.extract    s33, v32, #3
    v.ld.w       v34, [s32, #0]
    v.splat      v42, s33
    s.addi       s32, s14, #4288
    vf.max.ieee  v44, v42, v12
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v41, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v42, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v41, v40, v46
    v.lshr       v40, v41, v22
    vf.cvt.f32.e4m3 v46, v41
    vf.fms       v41, v42, v34, v42
    v.and        v34, v40, v39
    s.addi       s33, s30, #96
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v41                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v40
    v.extract    s35, v32, #4
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v42
    v.ld.w       v34, [s34, #0]
    v.splat      v41, s35
    s.addi       s34, s14, #4352
    vf.max.ieee  v42, v41, v12
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v43, v46
    vf.neg       v43, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v42, v41, v17
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v45, v43, v46
    v.lshr       v43, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v43, v39
    s.addi       s35, s30, #128
    v.or         v43, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v43
    v.extract    s36, v32, #5
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s36
    s.addi       s32, s14, #4416
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s36, s30, #160
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s33, #0], v40
    v.extract    s33, v32, #6
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s34, #0]
    v.splat      v41, s33
    s.addi       s33, s14, #4480
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v42, v34
    vf.fms       v34, v47, v43, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s34, s30, #192
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v42
    v.extract    s35, v32, #7
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s35
    s.addi       s32, s14, #4544
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s35, s30, #224
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v40
    v.extract    s36, v32, #8
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s36
    s.addi       s33, s14, #4608
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s36, s30, #256
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s34, #0], v42
    v.extract    s34, v32, #9
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s34
    s.addi       s32, s14, #4672
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s34, s30, #288
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v40
    v.extract    s35, v32, #10
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s35
    s.addi       s33, s14, #4736
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s35, s30, #320
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v42
    v.extract    s36, v32, #11
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s36
    s.addi       s32, s14, #4800
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s36, s30, #352
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s34, #0], v40
    v.extract    s34, v32, #12
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s34
    s.addi       s33, s14, #4864
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s34, s30, #384
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v42
    v.extract    s35, v32, #13
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s35
    s.addi       s32, s14, #4928
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s35, s30, #416
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v40
    v.extract    s36, v32, #14
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s36
    s.addi       s33, s14, #4992
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s36, s30, #448
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s34, #0], v42
    v.extract    s34, v32, #15
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s34
    s.addi       s32, s14, #5056
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s34, s30, #480
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v40
    v.extract    s35, v32, #0
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s35
    s.addi       s33, s14, #5120
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s35, s30, #16
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v42
    v.extract    s36, v32, #1
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s36
    s.addi       s32, s14, #5184
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s36, s30, #48
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s34, #0], v40
    v.extract    s34, v32, #2
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s34
    s.addi       s33, s14, #5248
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s34, s30, #80
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v42
    v.extract    s35, v32, #3
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s35
    s.addi       s32, s14, #5312
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s35, s30, #112
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v40
    v.extract    s36, v32, #4
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s36
    s.addi       s33, s14, #5376
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s36, s30, #144
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s34, #0], v42
    v.extract    s34, v32, #5
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s34
    s.addi       s32, s14, #5440
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s34, s30, #176
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v40
    v.extract    s35, v32, #6
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s35
    s.addi       s33, s14, #5504
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s35, s30, #208
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v42
    v.extract    s36, v32, #7
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s36
    s.addi       s32, s14, #5568
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s36, s30, #240
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s34, #0], v40
    v.extract    s34, v32, #8
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s34
    s.addi       s33, s14, #5632
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s34, s30, #272
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v42
    v.extract    s35, v32, #9
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s35
    s.addi       s32, s14, #5696
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s35, s30, #304
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v40
    v.extract    s36, v32, #10
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s36
    s.addi       s33, s14, #5760
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s36, s30, #336
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s34, #0], v42
    v.extract    s34, v32, #11
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s34
    s.addi       s32, s14, #5824
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s34, s30, #368
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v40
    v.extract    s35, v32, #12
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s35
    s.addi       s33, s14, #5888
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s35, s30, #400
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v42
    v.extract    s36, v32, #13
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s36
    s.addi       s32, s14, #5952
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s36, s30, #432
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s34, #0], v40
    v.extract    s34, v32, #14
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s34
    s.addi       s33, s14, #6016
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s34, s30, #464
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s35, #0], v42
    v.extract    s35, v32, #15
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s35
    s.addi       s32, s14, #6080
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s35, s30, #496
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s36, #0], v40
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    s.addi       s33, s30, #64
    s.addi       s36, s30, #128
    vf.mul       v41, v34, v42                   // a/y: faithful quotient
    vf.fms       v45, v41, v44, v34
    vf.fms       v34, v45, v42, v41
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v34, v42, v41
    v.lshr       v41, v34, v22
    vf.cvt.f32.e4m3 v42, v34
    v.and        v34, v41, v39
    v.or         v41, v42, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s34, #0], v41
    s.addi       s34, s30, #192
    v.ld.w       v34, [s32, #0]
    s.addi       s32, s30, #256
    vf.mul       v41, v34, v40                   // a/y: faithful quotient
    vf.fms       v42, v41, v43, v34
    vf.fms       v34, v42, v40, v41
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.lshr       v40, v34, v22
    vf.cvt.f32.e4m3 v41, v34
    v.and        v34, v40, v39
    v.or         v40, v41, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v40
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s35, s30, #320
    v.ld.w       v34, [s30, #0]
    v.mov        v48, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s33, #0]
    s.addi       s33, s30, #384
    s.addi       s37, s30, #448
    v.mov        v49, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s36, #0]
    v.extract    s30, v21, #0
    v.mov        v50, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s34, #0]
    v.mov        v51, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s32, #0]
    v.mov        v52, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s35, #0]
    v.mov        v53, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s33, #0]
    v.mov        v54, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s37, #0]
    v.mov        v55, v34                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_59
    s.movz       s32, #0
    s.add        s33, s12, s23
    s.addi       s34, s32, #0
    s.addi       s32, s33, #64
    s.addi       s33, s14, #8448
x8dot_row_60:
    s.addi       s35, s31, #-64
    v.movi       v34, #0
    s.sub        s36, s35, s34
    s.add        s35, s32, s34
    v.splat      v40, s36
    s.shli       s36, s34, #4
    s.addi       s37, s34, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s35, v33]            // index is in elements (ISA sec 9.1)
    s.add        s35, s33, s36
    s.movz       s36, #32
    v.st.b       [s35, #0], v34
    fence.acq_rel.device
    s.mov        s34, s37
    s.cmp.lt     s35, s34, s36
    br.nz        s35, x8dot_row_60
x8dot_done_59:
    v.splat      v34, s30
    v.movi       v40, #0
    v.splat      v41, s30
    v.movi       v42, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    s.movz       s33, #0
    v.extract    s34, v23, #0
    s.movz       s35, #64
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v21, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_61
    s.movz       s34, #0
    s.add        s35, s12, s23
    s.addi       s36, s34, #0
    s.addi       s34, s35, #64
    s.addi       s35, s14, #8448
x8dot_row_62:
    s.addi       s37, s31, #-64
    v.movi       v34, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v40, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s37, v19]            // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v34
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_62
x8dot_done_61:
    v.splat      v34, s33
    v.movi       v40, #0
    v.splat      v41, s33
    v.movi       v42, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    s.movz       s35, #0
    v.extract    s36, v23, #1
    s.movz       s37, #64
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v21, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_63
    s.movz       s36, #0
    s.add        s37, s12, s23
    s.addi       s38, s36, #0
    s.addi       s36, s37, #64
    s.addi       s37, s14, #8448
x8dot_row_64:
    s.addi       s39, s31, #-64
    v.movi       v34, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v40, s40
    s.shli       s40, s38, #4
    s.addi       s41, s38, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s39, v24]            // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.movz       s40, #32
    v.st.b       [s39, #0], v34
    fence.acq_rel.device
    s.mov        s38, s41
    s.cmp.lt     s39, s38, s40
    br.nz        s39, x8dot_row_64
x8dot_done_63:
    v.splat      v34, s35
    v.movi       v40, #0
    v.splat      v41, s35
    v.movi       v42, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    s.movz       s37, #0
    v.extract    s38, v23, #2
    s.movz       s39, #64
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v21, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_65
    s.movz       s38, #0
    s.add        s39, s12, s23
    s.addi       s40, s38, #0
    s.addi       s38, s39, #64
    s.addi       s39, s14, #8448
x8dot_row_66:
    s.addi       s41, s31, #-64
    v.movi       v34, #0
    s.sub        s42, s41, s40
    s.add        s41, s38, s40
    v.splat      v40, s42
    s.shli       s42, s40, #4
    s.addi       s43, s40, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s41, v15]            // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v34
    fence.acq_rel.device
    s.mov        s40, s43
    s.cmp.lt     s41, s40, s42
    br.nz        s41, x8dot_row_66
x8dot_done_65:
    v.splat      v34, s37
    v.movi       v40, #0
    v.splat      v41, s37
    v.movi       v42, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    s.movz       s39, #0
    v.extract    s40, v23, #3
    s.movz       s41, #64
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v21, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_67
    s.movz       s40, #0
    s.add        s41, s12, s23
    s.addi       s42, s40, #0
    s.addi       s40, s41, #64
    s.addi       s41, s14, #8448
x8dot_row_68:
    s.addi       s43, s31, #-64
    v.movi       v34, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v40, s44
    s.shli       s44, s42, #4
    s.addi       s45, s42, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s43, v14]            // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.movz       s44, #32
    v.st.b       [s43, #0], v34
    fence.acq_rel.device
    s.mov        s42, s45
    s.cmp.lt     s43, s42, s44
    br.nz        s43, x8dot_row_68
x8dot_done_67:
    v.splat      v34, s39
    v.movi       v40, #0
    v.splat      v41, s39
    v.movi       v42, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    s.movz       s41, #0
    v.extract    s42, v23, #4
    s.movz       s43, #64
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s44, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v21, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s41, x8dot_done_69
    s.movz       s42, #0
    s.add        s43, s12, s23
    s.addi       s44, s42, #0
    s.addi       s42, s43, #64
    s.addi       s43, s14, #8448
x8dot_row_70:
    s.addi       s45, s31, #-64
    v.movi       v34, #0
    s.sub        s46, s45, s44
    s.add        s45, s42, s44
    v.splat      v40, s46
    s.shli       s46, s44, #4
    s.addi       s47, s44, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s45, v29]            // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v34
    fence.acq_rel.device
    s.mov        s44, s47
    s.cmp.lt     s45, s44, s46
    br.nz        s45, x8dot_row_70
x8dot_done_69:
    v.splat      v34, s41
    v.movi       v40, #0
    v.splat      v41, s41
    v.movi       v42, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    s.movz       s43, #0
    v.extract    s44, v23, #5
    s.movz       s45, #64
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s46, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v21, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s43, x8dot_done_71
    s.movz       s44, #0
    s.add        s45, s12, s23
    s.addi       s46, s44, #0
    s.addi       s44, s45, #64
    s.addi       s45, s14, #8448
x8dot_row_72:
    s.addi       s47, s31, #-64
    v.movi       v34, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v40, s48
    s.shli       s48, s46, #4
    s.addi       s49, s46, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s47, v30]            // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.movz       s48, #32
    v.st.b       [s47, #0], v34
    fence.acq_rel.device
    s.mov        s46, s49
    s.cmp.lt     s47, s46, s48
    br.nz        s47, x8dot_row_72
x8dot_done_71:
    v.splat      v34, s43
    v.movi       v40, #0
    v.splat      v41, s43
    v.movi       v42, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    s.movz       s45, #0
    v.extract    s46, v23, #6
    s.movz       s47, #64
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v41, v42
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s48, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v21, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s45, x8dot_done_73
    s.movz       s46, #0
    s.add        s47, s12, s23
    s.addi       s48, s46, #0
    s.addi       s46, s47, #64
    s.addi       s47, s14, #8448
x8dot_row_74:
    s.addi       s49, s31, #-64
    v.movi       v34, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v40, s50
    s.shli       s50, s48, #4
    s.addi       s51, s48, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s49, v31]            // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v34
    fence.acq_rel.device
    s.mov        s48, s51
    s.cmp.lt     s49, s48, s50
    br.nz        s49, x8dot_row_74
x8dot_done_73:
    v.extract    s46, v32, #0
    v.splat      v34, s45
    v.splat      v40, s46
    v.movi       v41, #0
    v.splat      v42, s45
    vf.max.ieee  v43, v40, v12
    v.movi       v40, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    s.movz       s47, #0
    v.rcp.approx v44, v43                        // ISA 8.8: <= 2**-22 relative
    v.extract    s48, v23, #7
    s.movz       s49, #64
    v.cmp.ne     p1, v34, v41
    v.cmp.eq     p2, v42, v40
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s50, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s47, s14, #6144
    v.extract    s48, v32, #1
    m.mma.async.k32.e4m3 a15, v48, v56, s46
    mb.wait      s46
    v.ld.w       v34, [s47, #0]
    v.splat      v40, s48
    s.addi       s47, s14, #10752                // 512 bytes of repack scratch
    s.addi       s48, s14, #6208
    vf.max.ieee  v41, v40, v12
    s.addi       s49, s47, #0
    v.extract    s50, v32, #2
    s.addi       s51, s47, #32
    v.splat      v40, s50
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s50, s14, #6272
    vf.max.ieee  v45, v40, v12
    vf.fms       v40, v43, v44, v17
    v.rcp.approx v46, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v47, v44, v40, v44
    vf.neg       v40, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v47, v40, v44
    vf.mul       v40, v34, v47                   // a/y: faithful quotient
    vf.fms       v44, v40, v43, v34
    vf.fms       v34, v41, v42, v17
    vf.fms       v43, v44, v47, v40
    vf.fms       v44, v42, v34, v42
    vf.fms       v34, v45, v46, v17
    vf.neg       v47, v43                        // a/y: one correction to the IEEE quotient
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.fms       v44, v46, v34, v46
    vf.cmp.o     p1, v47, v47
    @p1 v.sel        v34, v47, v40
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v40, v43, v42
    v.lshr       v42, v34, v22
    vf.cvt.f32.e4m3 v43, v34
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.and        v44, v42, v39
    s.addi       s52, s47, #64
    v.or         v42, v43, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.st.b       [s49, #0], v42
    v.extract    s49, v32, #3
    v.ld.w       v34, [s48, #0]
    v.splat      v42, s49
    s.addi       s48, s14, #6336
    vf.max.ieee  v44, v42, v12
    v.rcp.approx v42, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v41, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v42, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v41, v40, v46
    v.lshr       v40, v41, v22
    vf.cvt.f32.e4m3 v46, v41
    vf.fms       v41, v42, v34, v42
    v.and        v34, v40, v39
    s.addi       s49, s47, #96
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v41                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v40
    v.extract    s51, v32, #4
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v42
    v.ld.w       v34, [s50, #0]
    v.splat      v41, s51
    s.addi       s50, s14, #6400
    vf.max.ieee  v42, v41, v12
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v43, v46
    vf.neg       v43, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v42, v41, v17
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v45, v43, v46
    v.lshr       v43, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v43, v39
    s.addi       s51, s47, #128
    v.or         v43, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v43
    v.extract    s52, v32, #5
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s52
    s.addi       s48, s14, #6464
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s52, s47, #160
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s49, #0], v40
    v.extract    s49, v32, #6
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s50, #0]
    v.splat      v41, s49
    s.addi       s49, s14, #6528
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v42, v34
    vf.fms       v34, v47, v43, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s50, s47, #192
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v42
    v.extract    s51, v32, #7
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s51
    s.addi       s48, s14, #6592
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s51, s47, #224
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v40
    v.extract    s52, v32, #8
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s49, #0]
    v.splat      v41, s52
    s.addi       s49, s14, #6656
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s52, s47, #256
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s50, #0], v42
    v.extract    s50, v32, #9
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s50
    s.addi       s48, s14, #6720
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s50, s47, #288
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v40
    v.extract    s51, v32, #10
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s49, #0]
    v.splat      v41, s51
    s.addi       s49, s14, #6784
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s51, s47, #320
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v42
    v.extract    s52, v32, #11
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s52
    s.addi       s48, s14, #6848
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s52, s47, #352
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s50, #0], v40
    v.extract    s50, v32, #12
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s49, #0]
    v.splat      v41, s50
    s.addi       s49, s14, #6912
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s50, s47, #384
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v42
    v.extract    s51, v32, #13
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s51
    s.addi       s48, s14, #6976
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s51, s47, #416
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v40
    v.extract    s52, v32, #14
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s49, #0]
    v.splat      v41, s52
    s.addi       s49, s14, #7040
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s52, s47, #448
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s50, #0], v42
    v.extract    s50, v32, #15
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s50
    s.addi       s48, s14, #7104
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s50, s47, #480
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v40
    v.extract    s51, v32, #0
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s49, #0]
    v.splat      v41, s51
    s.addi       s49, s14, #7168
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s51, s47, #16
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v42
    v.extract    s52, v32, #1
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s52
    s.addi       s48, s14, #7232
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s52, s47, #48
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s50, #0], v40
    v.extract    s50, v32, #2
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s49, #0]
    v.splat      v41, s50
    s.addi       s49, s14, #7296
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s50, s47, #80
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v42
    v.extract    s51, v32, #3
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s51
    s.addi       s48, s14, #7360
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s51, s47, #112
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v40
    v.extract    s52, v32, #4
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s49, #0]
    v.splat      v41, s52
    s.addi       s49, s14, #7424
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s52, s47, #144
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s50, #0], v42
    v.extract    s50, v32, #5
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s50
    s.addi       s48, s14, #7488
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s50, s47, #176
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v40
    v.extract    s51, v32, #6
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s49, #0]
    v.splat      v41, s51
    s.addi       s49, s14, #7552
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s51, s47, #208
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v42
    v.extract    s52, v32, #7
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s52
    s.addi       s48, s14, #7616
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s52, s47, #240
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s50, #0], v40
    v.extract    s50, v32, #8
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s49, #0]
    v.splat      v41, s50
    s.addi       s49, s14, #7680
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s50, s47, #272
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v42
    v.extract    s51, v32, #9
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s51
    s.addi       s48, s14, #7744
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s51, s47, #304
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v40
    v.extract    s52, v32, #10
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s49, #0]
    v.splat      v41, s52
    s.addi       s49, s14, #7808
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s52, s47, #336
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s50, #0], v42
    v.extract    s50, v32, #11
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s50
    s.addi       s48, s14, #7872
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s50, s47, #368
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v40
    v.extract    s51, v32, #12
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s49, #0]
    v.splat      v41, s51
    s.addi       s49, s14, #7936
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v22
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s51, s47, #400
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v42
    v.extract    s52, v32, #13
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s52
    s.addi       s48, s14, #8000
    vf.max.ieee  v45, v41, v12
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v22
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s52, s47, #432
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s50, #0], v40
    v.extract    s50, v32, #14
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s49, #0]
    v.splat      v41, s50
    s.addi       s49, s14, #8064
    vf.max.ieee  v44, v41, v12
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v17
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v22
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s50, s47, #464
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s51, #0], v42
    v.extract    s51, v32, #15
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s48, #0]
    v.splat      v41, s51
    s.addi       s48, s14, #8128
    vf.max.ieee  v43, v41, v12
    v.rcp.approx v12, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v41, v34, v40                   // a/y: faithful quotient
    vf.fms       v46, v41, v45, v34
    vf.fms       v34, v46, v40, v41
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v12, v17
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v17, v40, v41
    v.lshr       v40, v17, v22
    vf.cvt.f32.e4m3 v41, v17
    vf.fms       v17, v12, v34, v12
    v.and        v34, v40, v39
    s.addi       s51, s47, #496
    v.or         v40, v41, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v17                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s52, #0], v40
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v17, v34, v12
    v.ld.w       v12, [s49, #0]
    s.addi       s49, s47, #64
    s.addi       s52, s47, #128
    vf.mul       v34, v12, v42                   // a/y: faithful quotient
    vf.fms       v40, v34, v44, v12
    vf.fms       v12, v40, v42, v34
    vf.neg       v40, v12                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v12, v40, v34
    v.lshr       v34, v12, v22
    vf.cvt.f32.e4m3 v40, v12
    v.and        v12, v34, v39
    v.or         v34, v40, v12                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s50, #0], v34
    s.addi       s50, s47, #192
    v.ld.w       v12, [s48, #0]
    s.addi       s48, s47, #256
    vf.mul       v34, v12, v17                   // a/y: faithful quotient
    vf.fms       v40, v34, v43, v12
    vf.fms       v12, v40, v17, v34
    vf.neg       v17, v12                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v17, v17
    @p1 v.sel        v12, v17, v34
    v.lshr       v17, v12, v22
    vf.cvt.f32.e4m3 v22, v12
    v.and        v12, v17, v39
    v.or         v17, v22, v12                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v17
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s51, s47, #320
    v.ld.w       v12, [s47, #0]
    v.mov        v48, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s49, #0]
    s.addi       s49, s47, #384
    s.addi       s53, s47, #448
    v.mov        v49, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s52, #0]
    v.extract    s47, v21, #0
    v.mov        v50, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s50, #0]
    v.mov        v51, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s48, #0]
    v.mov        v52, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s51, #0]
    v.mov        v53, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s49, #0]
    v.mov        v54, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s53, #0]
    v.mov        v55, v12                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s47, x8dot_done_75
    s.movz       s48, #0
    s.add        s49, s12, s23
    s.addi       s50, s48, #0
    s.addi       s48, s49, #96
    s.addi       s49, s14, #8448
x8dot_row_76:
    s.addi       s51, s31, #-96
    v.movi       v12, #0
    s.sub        s52, s51, s50
    s.add        s51, s48, s50
    v.splat      v17, s52
    s.shli       s52, s50, #4
    s.addi       s53, s50, #1
    v.cmp.gt     p1, v17, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s51, v33]            // index is in elements (ISA sec 9.1)
    s.add        s51, s49, s52
    s.movz       s52, #32
    v.st.b       [s51, #0], v12
    fence.acq_rel.device
    s.mov        s50, s53
    s.cmp.lt     s51, s50, s52
    br.nz        s51, x8dot_row_76
x8dot_done_75:
    v.splat      v12, s47
    v.movi       v17, #0
    v.splat      v22, s47
    v.movi       v33, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    s.movz       s49, #0
    v.extract    s50, v23, #0
    s.movz       s51, #96
    v.cmp.ne     p1, v12, v17
    v.cmp.eq     p2, v22, v33
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s52, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s48, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s48, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v21, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s49, x8dot_done_77
    s.movz       s50, #0
    s.add        s51, s12, s23
    s.addi       s52, s50, #0
    s.addi       s50, s51, #96
    s.addi       s51, s14, #8448
x8dot_row_78:
    s.addi       s53, s31, #-96
    v.movi       v12, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v17, s54
    s.shli       s54, s52, #4
    s.addi       s55, s52, #1
    v.cmp.gt     p1, v17, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s53, v19]            // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v12
    fence.acq_rel.device
    s.mov        s52, s55
    s.cmp.lt     s53, s52, s54
    br.nz        s53, x8dot_row_78
x8dot_done_77:
    v.splat      v12, s49
    v.movi       v17, #0
    v.splat      v19, s49
    v.movi       v22, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    s.movz       s51, #0
    v.extract    s52, v23, #1
    s.movz       s53, #96
    v.cmp.ne     p1, v12, v17
    v.cmp.eq     p2, v19, v22
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s54, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v21, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s51, x8dot_done_79
    s.movz       s52, #0
    s.add        s53, s12, s23
    s.addi       s54, s52, #0
    s.addi       s52, s53, #96
    s.addi       s53, s14, #8448
x8dot_row_80:
    s.addi       s55, s31, #-96
    v.movi       v12, #0
    s.sub        s56, s55, s54
    s.add        s55, s52, s54
    v.splat      v17, s56
    s.shli       s56, s54, #4
    s.addi       s57, s54, #1
    v.cmp.gt     p1, v17, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s55, v24]            // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    s.movz       s56, #32
    v.st.b       [s55, #0], v12
    fence.acq_rel.device
    s.mov        s54, s57
    s.cmp.lt     s55, s54, s56
    br.nz        s55, x8dot_row_80
x8dot_done_79:
    v.splat      v12, s51
    v.movi       v17, #0
    v.splat      v19, s51
    v.movi       v22, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    s.movz       s53, #0
    v.extract    s54, v23, #2
    s.movz       s55, #96
    v.cmp.ne     p1, v12, v17
    v.cmp.eq     p2, v19, v22
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s56, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v21, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_81
    s.movz       s54, #0
    s.add        s55, s12, s23
    s.addi       s56, s54, #0
    s.addi       s54, s55, #96
    s.addi       s55, s14, #8448
x8dot_row_82:
    s.addi       s57, s31, #-96
    v.movi       v12, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v17, s58
    s.shli       s58, s56, #4
    s.addi       s59, s56, #1
    v.cmp.gt     p1, v17, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s57, v15]            // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v12
    fence.acq_rel.device
    s.mov        s56, s59
    s.cmp.lt     s57, s56, s58
    br.nz        s57, x8dot_row_82
x8dot_done_81:
    v.splat      v12, s53
    v.movi       v15, #0
    v.splat      v17, s53
    v.movi       v19, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    s.movz       s55, #0
    v.extract    s56, v23, #3
    s.movz       s57, #96
    v.cmp.ne     p1, v12, v15
    v.cmp.eq     p2, v17, v19
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s58, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v21, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s55, x8dot_done_83
    s.movz       s56, #0
    s.add        s57, s12, s23
    s.addi       s58, s56, #0
    s.addi       s56, s57, #96
    s.addi       s57, s14, #8448
x8dot_row_84:
    s.addi       s59, s31, #-96
    v.movi       v12, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v15, s60
    s.shli       s60, s58, #4
    s.addi       s26, s58, #1
    v.cmp.gt     p1, v15, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s59, v14]            // index is in elements (ISA sec 9.1)
    s.add        s27, s57, s60
    s.movz       s28, #32
    v.st.b       [s27, #0], v12
    fence.acq_rel.device
    s.mov        s58, s26
    s.cmp.lt     s26, s58, s28
    br.nz        s26, x8dot_row_84
x8dot_done_83:
    v.splat      v12, s55
    v.movi       v14, #0
    v.splat      v15, s55
    v.movi       v17, #0
    mb.arm       s26, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s27, #0
    s.movz       s28, #0
    v.extract    s29, v23, #4
    s.movz       s30, #96
    v.cmp.ne     p1, v12, v14
    v.cmp.eq     p2, v15, v17
    s.mov        s32, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s32, s26            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s27, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s27, s26          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s26
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s28, v21, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s27
    mb.wait      s27
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s28, x8dot_done_85
    s.movz       s29, #0
    s.add        s30, s12, s23
    s.addi       s32, s29, #0
    s.addi       s29, s30, #96
    s.addi       s30, s14, #8448
x8dot_row_86:
    s.addi       s33, s31, #-96
    v.movi       v12, #0
    s.sub        s34, s33, s32
    s.add        s33, s29, s32
    v.splat      v14, s34
    s.shli       s34, s32, #4
    s.addi       s35, s32, #1
    v.cmp.gt     p1, v14, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s33, v29]            // index is in elements (ISA sec 9.1)
    s.add        s33, s30, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v12
    fence.acq_rel.device
    s.mov        s32, s35
    s.cmp.lt     s33, s32, s34
    br.nz        s33, x8dot_row_86
x8dot_done_85:
    v.splat      v12, s28
    v.movi       v14, #0
    v.splat      v15, s28
    v.movi       v17, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    s.movz       s30, #0
    v.extract    s32, v23, #5
    s.movz       s33, #96
    v.cmp.ne     p1, v12, v14
    v.cmp.eq     p2, v15, v17
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s30, v21, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_87
    s.movz       s32, #0
    s.add        s33, s12, s23
    s.addi       s34, s32, #0
    s.addi       s32, s33, #96
    s.addi       s33, s14, #8448
x8dot_row_88:
    s.addi       s35, s31, #-96
    v.movi       v12, #0
    s.sub        s36, s35, s34
    s.add        s35, s32, s34
    v.splat      v14, s36
    s.shli       s36, s34, #4
    s.addi       s37, s34, #1
    v.cmp.gt     p1, v14, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s35, v30]            // index is in elements (ISA sec 9.1)
    s.add        s35, s33, s36
    s.movz       s36, #32
    v.st.b       [s35, #0], v12
    fence.acq_rel.device
    s.mov        s34, s37
    s.cmp.lt     s35, s34, s36
    br.nz        s35, x8dot_row_88
x8dot_done_87:
    v.splat      v12, s30
    v.movi       v14, #0
    v.splat      v15, s30
    v.movi       v17, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    s.movz       s33, #0
    v.extract    s34, v23, #6
    s.movz       s35, #96
    v.cmp.ne     p1, v12, v14
    v.cmp.eq     p2, v15, v17
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v21, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_89
    s.movz       s34, #0
    s.add        s35, s12, s23
    s.addi       s36, s34, #0
    s.addi       s34, s35, #96
    s.addi       s35, s14, #8448
x8dot_row_90:
    s.addi       s37, s31, #-96
    v.movi       v12, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v14, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v14, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s37, v31]            // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v12
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_90
x8dot_done_89:
    v.splat      v12, s33
    v.movi       v14, #0
    v.splat      v15, s33
    v.movi       v17, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    s.movz       s34, #0
    v.extract    s35, v23, #7
    s.movz       s36, #96
    v.cmp.ne     p1, v12, v14
    v.cmp.eq     p2, v15, v17
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s34, #0
    s.addi       s35, s14, #11264
    m.mma.async.k32.e4m3 a15, v48, v56, s33
    mb.wait      s33
    a.vread      v12, a8, s34
    s.movz       s34, #1
    s.addi       s36, s35, #64
    v.st.w       [s35, #0], v12
    a.vread      v12, a8, s34
    s.movz       s34, #2
    s.addi       s37, s35, #128
    s.movz       s38, #3
    s.addi       s39, s35, #192
    s.movz       s40, #4
    v.st.w       [s36, #0], v12
    a.vread      v12, a8, s34
    s.addi       s34, s35, #256
    s.movz       s36, #5
    v.st.w       [s37, #0], v12
    a.vread      v12, a8, s38
    s.addi       s37, s35, #320
    s.movz       s38, #6
    v.st.w       [s39, #0], v12
    a.vread      v12, a8, s40
    s.addi       s39, s35, #384
    s.movz       s40, #7
    v.st.w       [s34, #0], v12
    a.vread      v12, a8, s36
    s.addi       s34, s35, #448
    s.movz       s36, #8
    v.st.w       [s37, #0], v12
    a.vread      v12, a8, s38
    s.addi       s37, s35, #512
    s.movz       s38, #9
    v.st.w       [s39, #0], v12
    a.vread      v12, a8, s40
    s.addi       s39, s35, #576
    s.movz       s40, #10
    v.st.w       [s34, #0], v12
    a.vread      v12, a8, s36
    s.addi       s34, s35, #640
    s.movz       s36, #11
    v.st.w       [s37, #0], v12
    a.vread      v12, a8, s38
    s.addi       s37, s35, #704
    s.movz       s38, #12
    v.st.w       [s39, #0], v12
    a.vread      v12, a8, s40
    s.addi       s39, s35, #768
    s.movz       s40, #13
    v.st.w       [s34, #0], v12
    a.vread      v12, a8, s36
    s.addi       s34, s35, #832
    s.movz       s36, #14
    v.st.w       [s37, #0], v12
    a.vread      v12, a8, s38
    s.addi       s37, s35, #896
    s.movz       s38, #15
    s.addi       s41, s35, #960
    v.st.w       [s39, #0], v12
    a.vread      v12, a8, s40
    s.movz       s35, #0
    s.addi       s39, s14, #12288
    v.st.w       [s34, #0], v12
    a.vread      v12, a8, s36
    s.movz       s34, #1
    s.addi       s36, s39, #64
    v.st.w       [s37, #0], v12
    a.vread      v12, a8, s38
    s.movz       s37, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v12
    fence.acq_rel.device
    a.vread      v12, a9, s35
    s.movz       s35, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v12
    a.vread      v12, a9, s34
    s.movz       s34, #4
    v.st.w       [s36, #0], v12
    a.vread      v12, a9, s37
    s.addi       s36, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v12
    a.vread      v12, a9, s35
    s.addi       s35, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v12
    a.vread      v12, a9, s34
    s.addi       s34, s39, #384
    s.movz       s40, #7
    v.st.w       [s36, #0], v12
    a.vread      v12, a9, s37
    s.addi       s36, s39, #448
    s.movz       s37, #8
    v.st.w       [s35, #0], v12
    a.vread      v12, a9, s38
    s.addi       s35, s39, #512
    s.movz       s38, #9
    v.st.w       [s34, #0], v12
    a.vread      v12, a9, s40
    s.addi       s34, s39, #576
    s.movz       s40, #10
    v.st.w       [s36, #0], v12
    a.vread      v12, a9, s37
    s.addi       s36, s39, #640
    s.movz       s37, #11
    v.st.w       [s35, #0], v12
    a.vread      v12, a9, s38
    s.addi       s35, s39, #704
    s.movz       s38, #12
    v.st.w       [s34, #0], v12
    a.vread      v12, a9, s40
    s.addi       s34, s39, #768
    s.movz       s40, #13
    v.st.w       [s36, #0], v12
    a.vread      v12, a9, s37
    s.addi       s36, s39, #832
    s.movz       s37, #14
    v.st.w       [s35, #0], v12
    a.vread      v12, a9, s38
    s.addi       s35, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s34, #0], v12
    a.vread      v12, a9, s40
    s.movz       s34, #0
    s.addi       s39, s14, #13312
    v.st.w       [s36, #0], v12
    a.vread      v12, a9, s37
    s.movz       s36, #1
    s.addi       s37, s39, #64
    v.st.w       [s35, #0], v12
    a.vread      v12, a9, s38
    s.movz       s35, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v12
    fence.acq_rel.device
    a.vread      v12, a10, s34
    s.movz       s34, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v12
    a.vread      v12, a10, s36
    s.movz       s36, #4
    v.st.w       [s37, #0], v12
    a.vread      v12, a10, s35
    s.addi       s35, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v12
    a.vread      v12, a10, s34
    s.addi       s34, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v12
    a.vread      v12, a10, s36
    s.addi       s36, s39, #384
    s.movz       s40, #7
    v.st.w       [s35, #0], v12
    a.vread      v12, a10, s37
    s.addi       s35, s39, #448
    s.movz       s37, #8
    v.st.w       [s34, #0], v12
    a.vread      v12, a10, s38
    s.addi       s34, s39, #512
    s.movz       s38, #9
    v.st.w       [s36, #0], v12
    a.vread      v12, a10, s40
    s.addi       s36, s39, #576
    s.movz       s40, #10
    v.st.w       [s35, #0], v12
    a.vread      v12, a10, s37
    s.addi       s35, s39, #640
    s.movz       s37, #11
    v.st.w       [s34, #0], v12
    a.vread      v12, a10, s38
    s.addi       s34, s39, #704
    s.movz       s38, #12
    v.st.w       [s36, #0], v12
    a.vread      v12, a10, s40
    s.addi       s36, s39, #768
    s.movz       s40, #13
    v.st.w       [s35, #0], v12
    a.vread      v12, a10, s37
    s.addi       s35, s39, #832
    s.movz       s37, #14
    v.st.w       [s34, #0], v12
    a.vread      v12, a10, s38
    s.addi       s34, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s36, #0], v12
    a.vread      v12, a10, s40
    s.movz       s36, #0
    s.addi       s39, s14, #14336
    v.st.w       [s35, #0], v12
    a.vread      v12, a10, s37
    s.movz       s35, #1
    s.addi       s37, s39, #64
    v.st.w       [s34, #0], v12
    a.vread      v12, a10, s38
    s.movz       s34, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v12
    fence.acq_rel.device
    a.vread      v12, a11, s36
    s.movz       s36, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v12
    a.vread      v12, a11, s35
    s.movz       s35, #4
    v.st.w       [s37, #0], v12
    a.vread      v12, a11, s34
    s.addi       s34, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v12
    a.vread      v12, a11, s36
    s.addi       s36, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v12
    a.vread      v12, a11, s35
    s.addi       s35, s39, #384
    s.movz       s40, #7
    v.st.w       [s34, #0], v12
    a.vread      v12, a11, s37
    s.addi       s34, s39, #448
    s.movz       s37, #8
    v.st.w       [s36, #0], v12
    a.vread      v12, a11, s38
    s.addi       s36, s39, #512
    s.movz       s38, #9
    v.st.w       [s35, #0], v12
    a.vread      v12, a11, s40
    s.addi       s35, s39, #576
    s.movz       s40, #10
    v.st.w       [s34, #0], v12
    a.vread      v12, a11, s37
    s.addi       s34, s39, #640
    s.movz       s37, #11
    v.st.w       [s36, #0], v12
    a.vread      v12, a11, s38
    s.addi       s36, s39, #704
    s.movz       s38, #12
    v.st.w       [s35, #0], v12
    a.vread      v12, a11, s40
    s.addi       s35, s39, #768
    s.movz       s40, #13
    v.st.w       [s34, #0], v12
    a.vread      v12, a11, s37
    s.addi       s34, s39, #832
    s.movz       s37, #14
    v.st.w       [s36, #0], v12
    a.vread      v12, a11, s38
    s.addi       s36, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s35, #0], v12
    a.vread      v12, a11, s40
    s.movz       s35, #0
    s.addi       s39, s14, #15360
    v.st.w       [s34, #0], v12
    a.vread      v12, a11, s37
    s.movz       s34, #1
    s.addi       s37, s39, #64
    v.st.w       [s36, #0], v12
    a.vread      v12, a11, s38
    s.movz       s36, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v12
    fence.acq_rel.device
    a.vread      v12, a12, s35
    s.movz       s35, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v12
    a.vread      v12, a12, s34
    s.movz       s34, #4
    v.st.w       [s37, #0], v12
    a.vread      v12, a12, s36
    s.addi       s36, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v12
    a.vread      v12, a12, s35
    s.addi       s35, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v12
    a.vread      v12, a12, s34
    s.addi       s34, s39, #384
    s.movz       s40, #7
    v.st.w       [s36, #0], v12
    a.vread      v12, a12, s37
    s.addi       s36, s39, #448
    s.movz       s37, #8
    v.st.w       [s35, #0], v12
    a.vread      v12, a12, s38
    s.addi       s35, s39, #512
    s.movz       s38, #9
    v.st.w       [s34, #0], v12
    a.vread      v12, a12, s40
    s.addi       s34, s39, #576
    s.movz       s40, #10
    v.st.w       [s36, #0], v12
    a.vread      v12, a12, s37
    s.addi       s36, s39, #640
    s.movz       s37, #11
    v.st.w       [s35, #0], v12
    a.vread      v12, a12, s38
    s.addi       s35, s39, #704
    s.movz       s38, #12
    v.st.w       [s34, #0], v12
    a.vread      v12, a12, s40
    s.addi       s34, s39, #768
    s.movz       s40, #13
    v.st.w       [s36, #0], v12
    a.vread      v12, a12, s37
    s.addi       s36, s39, #832
    s.movz       s37, #14
    v.st.w       [s35, #0], v12
    a.vread      v12, a12, s38
    s.addi       s35, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s34, #0], v12
    a.vread      v12, a12, s40
    s.movz       s34, #0
    s.addi       s39, s14, #16384
    v.st.w       [s36, #0], v12
    a.vread      v12, a12, s37
    s.movz       s36, #1
    s.addi       s37, s39, #64
    v.st.w       [s35, #0], v12
    a.vread      v12, a12, s38
    s.movz       s35, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v12
    fence.acq_rel.device
    a.vread      v12, a13, s34
    s.movz       s34, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v12
    a.vread      v12, a13, s36
    s.movz       s36, #4
    v.st.w       [s37, #0], v12
    a.vread      v12, a13, s35
    s.addi       s35, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v12
    a.vread      v12, a13, s34
    s.addi       s34, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v12
    a.vread      v12, a13, s36
    s.addi       s36, s39, #384
    s.movz       s40, #7
    v.st.w       [s35, #0], v12
    a.vread      v12, a13, s37
    s.addi       s35, s39, #448
    s.movz       s37, #8
    v.st.w       [s34, #0], v12
    a.vread      v12, a13, s38
    s.addi       s34, s39, #512
    s.movz       s38, #9
    v.st.w       [s36, #0], v12
    a.vread      v12, a13, s40
    s.addi       s36, s39, #576
    s.movz       s40, #10
    v.st.w       [s35, #0], v12
    a.vread      v12, a13, s37
    s.addi       s35, s39, #640
    s.movz       s37, #11
    v.st.w       [s34, #0], v12
    a.vread      v12, a13, s38
    s.addi       s34, s39, #704
    s.movz       s38, #12
    v.st.w       [s36, #0], v12
    a.vread      v12, a13, s40
    s.addi       s36, s39, #768
    s.movz       s40, #13
    v.st.w       [s35, #0], v12
    a.vread      v12, a13, s37
    s.addi       s35, s39, #832
    s.movz       s37, #14
    v.st.w       [s34, #0], v12
    a.vread      v12, a13, s38
    s.addi       s34, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s36, #0], v12
    a.vread      v12, a13, s40
    s.movz       s36, #0
    s.addi       s39, s14, #17408
    v.st.w       [s35, #0], v12
    a.vread      v12, a13, s37
    s.movz       s35, #1
    s.addi       s37, s39, #64
    v.st.w       [s34, #0], v12
    a.vread      v12, a13, s38
    s.movz       s34, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v12
    fence.acq_rel.device
    a.vread      v12, a14, s36
    s.movz       s36, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v12
    a.vread      v12, a14, s35
    s.movz       s35, #4
    v.st.w       [s37, #0], v12
    a.vread      v12, a14, s34
    s.addi       s34, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v12
    a.vread      v12, a14, s36
    s.addi       s36, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v12
    a.vread      v12, a14, s35
    s.addi       s35, s39, #384
    s.movz       s40, #7
    v.st.w       [s34, #0], v12
    a.vread      v12, a14, s37
    s.addi       s34, s39, #448
    s.movz       s37, #8
    v.st.w       [s36, #0], v12
    a.vread      v12, a14, s38
    s.addi       s36, s39, #512
    s.movz       s38, #9
    v.st.w       [s35, #0], v12
    a.vread      v12, a14, s40
    s.addi       s35, s39, #576
    s.movz       s40, #10
    v.st.w       [s34, #0], v12
    a.vread      v12, a14, s37
    s.addi       s34, s39, #640
    s.movz       s37, #11
    v.st.w       [s36, #0], v12
    a.vread      v12, a14, s38
    s.addi       s36, s39, #704
    s.movz       s38, #12
    v.st.w       [s35, #0], v12
    a.vread      v12, a14, s40
    s.addi       s35, s39, #768
    s.movz       s40, #13
    v.st.w       [s34, #0], v12
    a.vread      v12, a14, s37
    s.addi       s34, s39, #832
    s.movz       s37, #14
    v.st.w       [s36, #0], v12
    a.vread      v12, a14, s38
    s.addi       s36, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s35, #0], v12
    a.vread      v12, a14, s40
    s.movz       s35, #0
    s.addi       s39, s14, #18432
    v.st.w       [s34, #0], v12
    a.vread      v12, a14, s37
    s.movz       s34, #1
    s.addi       s37, s39, #64
    v.st.w       [s36, #0], v12
    a.vread      v12, a14, s38
    s.movz       s36, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v12
    fence.acq_rel.device
    a.vread      v12, a15, s35
    s.movz       s35, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v12
    a.vread      v12, a15, s34
    s.movz       s34, #4
    v.st.w       [s37, #0], v12
    a.vread      v12, a15, s36
    s.addi       s36, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v12
    a.vread      v12, a15, s35
    s.addi       s35, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v12
    a.vread      v12, a15, s34
    s.addi       s34, s39, #384
    s.movz       s40, #7
    v.st.w       [s36, #0], v12
    a.vread      v12, a15, s37
    s.addi       s36, s39, #448
    s.movz       s37, #8
    v.st.w       [s35, #0], v12
    a.vread      v12, a15, s38
    s.addi       s35, s39, #512
    s.movz       s38, #9
    v.st.w       [s34, #0], v12
    a.vread      v12, a15, s40
    s.addi       s34, s39, #576
    s.movz       s40, #10
    v.st.w       [s36, #0], v12
    a.vread      v12, a15, s37
    s.addi       s36, s39, #640
    s.movz       s37, #11
    v.st.w       [s35, #0], v12
    a.vread      v12, a15, s38
    s.addi       s35, s39, #704
    s.movz       s38, #12
    v.st.w       [s34, #0], v12
    a.vread      v12, a15, s40
    s.addi       s34, s39, #768
    s.movz       s40, #13
    v.st.w       [s36, #0], v12
    a.vread      v12, a15, s37
    s.addi       s36, s39, #832
    s.movz       s37, #14
    v.st.w       [s35, #0], v12
    a.vread      v12, a15, s38
    s.addi       s35, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s34, #0], v12
    a.vread      v12, a15, s40
    s.movz       s34, #0
    s.addi       s39, s14, #11264
    v.st.w       [s36, #0], v12
    a.vread      v12, a15, s37
    v.extract    s36, v32, #0
    s.addi       s37, s14, #19456
    v.splat      v14, s36
    s.movz       s36, #1
    v.st.w       [s35, #0], v12
    a.vread      v12, a15, s38
    s.addi       s35, s14, #11328
    v.extract    s38, v32, #1
    v.splat      v15, s38
    s.addi       s38, s37, #64
    v.st.w       [s41, #0], v12
    fence.acq_rel.device
    a.vread      v12, a0, s34
    s.movz       s34, #2
    s.addi       s40, s14, #11392
    v.ld.w       v17, [s39, #0]
    v.extract    s39, v32, #2
    v.splat      v19, s39
    s.addi       s39, s37, #128
    vf.mul       v21, v17, v14
    vf.mul       v14, v21, v25
    vf.add       v17, v12, v14
    v.st.w       [s37, #0], v17
    a.vread      v12, a0, s36
    s.movz       s36, #3
    v.ld.w       v14, [s35, #0]
    s.addi       s35, s14, #11456
    vf.mul       v17, v14, v15
    vf.mul       v14, v17, v25
    vf.add       v15, v12, v14
    v.st.w       [s38, #0], v15
    a.vread      v12, a0, s34
    v.extract    s34, v32, #3
    s.addi       s38, s37, #192
    v.splat      v14, s34
    s.movz       s34, #4
    v.ld.w       v15, [s40, #0]
    s.addi       s40, s14, #11520
    vf.mul       v17, v15, v19
    vf.mul       v15, v17, v25
    vf.add       v17, v12, v15
    v.st.w       [s39, #0], v17
    a.vread      v12, a0, s36
    v.extract    s36, v32, #4
    s.addi       s39, s37, #256
    v.splat      v15, s36
    s.movz       s36, #5
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #11584
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v25
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a0, s34
    v.extract    s34, v32, #5
    s.addi       s38, s37, #320
    v.splat      v14, s34
    s.movz       s34, #6
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #11648
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v25
    vf.add       v17, v12, v15
    v.st.w       [s39, #0], v17
    a.vread      v12, a0, s36
    v.extract    s36, v32, #6
    s.addi       s39, s37, #384
    v.splat      v15, s36
    s.movz       s36, #7
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #11712
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v25
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a0, s34
    v.extract    s34, v32, #7
    s.addi       s38, s37, #448
    v.splat      v14, s34
    s.movz       s34, #8
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #11776
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v25
    vf.add       v17, v12, v15
    v.st.w       [s39, #0], v17
    a.vread      v12, a0, s36
    v.extract    s36, v32, #8
    s.addi       s39, s37, #512
    v.splat      v15, s36
    s.movz       s36, #9
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #11840
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v25
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a0, s34
    v.extract    s34, v32, #9
    s.addi       s38, s37, #576
    v.splat      v14, s34
    s.movz       s34, #10
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #11904
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v25
    vf.add       v17, v12, v15
    v.st.w       [s39, #0], v17
    a.vread      v12, a0, s36
    v.extract    s36, v32, #10
    s.addi       s39, s37, #640
    v.splat      v15, s36
    s.movz       s36, #11
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #11968
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v25
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a0, s34
    v.extract    s34, v32, #11
    s.addi       s38, s37, #704
    v.splat      v14, s34
    s.movz       s34, #12
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #12032
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v25
    vf.add       v17, v12, v15
    v.st.w       [s39, #0], v17
    a.vread      v12, a0, s36
    v.extract    s36, v32, #12
    s.addi       s39, s37, #768
    v.splat      v15, s36
    s.movz       s36, #13
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #12096
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v25
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a0, s34
    v.extract    s34, v32, #13
    s.addi       s38, s37, #832
    v.splat      v14, s34
    s.movz       s34, #14
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #12160
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v25
    vf.add       v17, v12, v15
    v.st.w       [s39, #0], v17
    a.vread      v12, a0, s36
    v.extract    s36, v32, #14
    s.addi       s39, s37, #896
    v.splat      v15, s36
    s.movz       s36, #15
    s.addi       s41, s37, #960
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #12224
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v25
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a0, s34
    v.extract    s34, v32, #15
    s.movz       s37, #0
    v.splat      v14, s34
    s.addi       s34, s14, #12288
    v.ld.w       v17, [s40, #0]
    v.extract    s38, v32, #0
    v.splat      v19, s38
    s.addi       s38, s14, #20480
    vf.mul       v21, v17, v15
    vf.mul       v15, v21, v25
    vf.add       v17, v12, v15
    v.st.w       [s39, #0], v17
    a.vread      v12, a0, s36
    s.movz       s36, #1
    s.addi       s39, s14, #12352
    v.ld.w       v15, [s35, #0]
    v.extract    s35, v32, #1
    v.splat      v17, s35
    s.addi       s35, s38, #64
    vf.mul       v21, v15, v14
    vf.mul       v14, v21, v25
    vf.add       v15, v12, v14
    v.st.w       [s41, #0], v15
    fence.acq_rel.device
    a.vread      v12, a1, s37
    s.movz       s37, #2
    s.addi       s40, s14, #12416
    v.ld.w       v14, [s34, #0]
    v.extract    s34, v32, #2
    v.splat      v15, s34
    s.addi       s34, s38, #128
    vf.mul       v21, v14, v19
    vf.mul       v14, v21, v27
    vf.add       v19, v12, v14
    v.st.w       [s38, #0], v19
    a.vread      v12, a1, s36
    s.movz       s36, #3
    v.ld.w       v14, [s39, #0]
    s.addi       s39, s14, #12480
    vf.mul       v19, v14, v17
    vf.mul       v14, v19, v27
    vf.add       v17, v12, v14
    v.st.w       [s35, #0], v17
    a.vread      v12, a1, s37
    v.extract    s35, v32, #3
    s.addi       s37, s38, #192
    v.splat      v14, s35
    s.movz       s35, #4
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #12544
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v27
    vf.add       v17, v12, v15
    v.st.w       [s34, #0], v17
    a.vread      v12, a1, s36
    v.extract    s34, v32, #4
    s.addi       s36, s38, #256
    v.splat      v15, s34
    s.movz       s34, #5
    v.ld.w       v17, [s39, #0]
    s.addi       s39, s14, #12608
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v27
    vf.add       v17, v12, v14
    v.st.w       [s37, #0], v17
    a.vread      v12, a1, s35
    v.extract    s35, v32, #5
    s.addi       s37, s38, #320
    v.splat      v14, s35
    s.movz       s35, #6
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #12672
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v27
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a1, s34
    v.extract    s34, v32, #6
    s.addi       s36, s38, #384
    v.splat      v15, s34
    s.movz       s34, #7
    v.ld.w       v17, [s39, #0]
    s.addi       s39, s14, #12736
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v27
    vf.add       v17, v12, v14
    v.st.w       [s37, #0], v17
    a.vread      v12, a1, s35
    v.extract    s35, v32, #7
    s.addi       s37, s38, #448
    v.splat      v14, s35
    s.movz       s35, #8
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #12800
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v27
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a1, s34
    v.extract    s34, v32, #8
    s.addi       s36, s38, #512
    v.splat      v15, s34
    s.movz       s34, #9
    v.ld.w       v17, [s39, #0]
    s.addi       s39, s14, #12864
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v27
    vf.add       v17, v12, v14
    v.st.w       [s37, #0], v17
    a.vread      v12, a1, s35
    v.extract    s35, v32, #9
    s.addi       s37, s38, #576
    v.splat      v14, s35
    s.movz       s35, #10
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #12928
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v27
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a1, s34
    v.extract    s34, v32, #10
    s.addi       s36, s38, #640
    v.splat      v15, s34
    s.movz       s34, #11
    v.ld.w       v17, [s39, #0]
    s.addi       s39, s14, #12992
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v27
    vf.add       v17, v12, v14
    v.st.w       [s37, #0], v17
    a.vread      v12, a1, s35
    v.extract    s35, v32, #11
    s.addi       s37, s38, #704
    v.splat      v14, s35
    s.movz       s35, #12
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #13056
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v27
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a1, s34
    v.extract    s34, v32, #12
    s.addi       s36, s38, #768
    v.splat      v15, s34
    s.movz       s34, #13
    v.ld.w       v17, [s39, #0]
    s.addi       s39, s14, #13120
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v27
    vf.add       v17, v12, v14
    v.st.w       [s37, #0], v17
    a.vread      v12, a1, s35
    v.extract    s35, v32, #13
    s.addi       s37, s38, #832
    v.splat      v14, s35
    s.movz       s35, #14
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #13184
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v27
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a1, s34
    v.extract    s34, v32, #14
    s.addi       s36, s38, #896
    v.splat      v15, s34
    s.movz       s34, #15
    s.addi       s41, s38, #960
    v.ld.w       v17, [s39, #0]
    s.addi       s38, s14, #13248
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v27
    vf.add       v17, v12, v14
    v.st.w       [s37, #0], v17
    a.vread      v12, a1, s35
    v.extract    s35, v32, #15
    s.movz       s37, #0
    v.splat      v14, s35
    s.addi       s35, s14, #13312
    v.ld.w       v17, [s40, #0]
    v.extract    s39, v32, #0
    v.splat      v19, s39
    s.addi       s39, s14, #21504
    vf.mul       v21, v17, v15
    vf.mul       v15, v21, v27
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a1, s34
    s.movz       s34, #1
    s.addi       s36, s14, #13376
    v.ld.w       v15, [s38, #0]
    v.extract    s38, v32, #1
    v.splat      v17, s38
    s.addi       s38, s39, #64
    vf.mul       v21, v15, v14
    vf.mul       v14, v21, v27
    vf.add       v15, v12, v14
    v.st.w       [s41, #0], v15
    fence.acq_rel.device
    a.vread      v12, a2, s37
    s.movz       s37, #2
    s.addi       s40, s14, #13440
    v.ld.w       v14, [s35, #0]
    v.extract    s35, v32, #2
    v.splat      v15, s35
    s.addi       s35, s39, #128
    vf.mul       v21, v14, v19
    vf.mul       v14, v21, v28
    vf.add       v19, v12, v14
    v.st.w       [s39, #0], v19
    a.vread      v12, a2, s34
    s.movz       s34, #3
    v.ld.w       v14, [s36, #0]
    s.addi       s36, s14, #13504
    vf.mul       v19, v14, v17
    vf.mul       v14, v19, v28
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a2, s37
    v.extract    s37, v32, #3
    s.addi       s38, s39, #192
    v.splat      v14, s37
    s.movz       s37, #4
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #13568
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v28
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a2, s34
    v.extract    s34, v32, #4
    s.addi       s35, s39, #256
    v.splat      v15, s34
    s.movz       s34, #5
    v.ld.w       v17, [s36, #0]
    s.addi       s36, s14, #13632
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v28
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a2, s37
    v.extract    s37, v32, #5
    s.addi       s38, s39, #320
    v.splat      v14, s37
    s.movz       s37, #6
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #13696
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v28
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a2, s34
    v.extract    s34, v32, #6
    s.addi       s35, s39, #384
    v.splat      v15, s34
    s.movz       s34, #7
    v.ld.w       v17, [s36, #0]
    s.addi       s36, s14, #13760
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v28
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a2, s37
    v.extract    s37, v32, #7
    s.addi       s38, s39, #448
    v.splat      v14, s37
    s.movz       s37, #8
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #13824
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v28
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a2, s34
    v.extract    s34, v32, #8
    s.addi       s35, s39, #512
    v.splat      v15, s34
    s.movz       s34, #9
    v.ld.w       v17, [s36, #0]
    s.addi       s36, s14, #13888
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v28
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a2, s37
    v.extract    s37, v32, #9
    s.addi       s38, s39, #576
    v.splat      v14, s37
    s.movz       s37, #10
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #13952
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v28
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a2, s34
    v.extract    s34, v32, #10
    s.addi       s35, s39, #640
    v.splat      v15, s34
    s.movz       s34, #11
    v.ld.w       v17, [s36, #0]
    s.addi       s36, s14, #14016
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v28
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a2, s37
    v.extract    s37, v32, #11
    s.addi       s38, s39, #704
    v.splat      v14, s37
    s.movz       s37, #12
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #14080
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v28
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a2, s34
    v.extract    s34, v32, #12
    s.addi       s35, s39, #768
    v.splat      v15, s34
    s.movz       s34, #13
    v.ld.w       v17, [s36, #0]
    s.addi       s36, s14, #14144
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v28
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a2, s37
    v.extract    s37, v32, #13
    s.addi       s38, s39, #832
    v.splat      v14, s37
    s.movz       s37, #14
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #14208
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v28
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a2, s34
    v.extract    s34, v32, #14
    s.addi       s35, s39, #896
    v.splat      v15, s34
    s.movz       s34, #15
    s.addi       s41, s39, #960
    v.ld.w       v17, [s36, #0]
    s.addi       s36, s14, #14272
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v28
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a2, s37
    v.extract    s37, v32, #15
    s.movz       s38, #0
    v.splat      v14, s37
    s.addi       s37, s14, #14336
    v.ld.w       v17, [s40, #0]
    v.extract    s39, v32, #0
    v.splat      v19, s39
    s.addi       s39, s14, #22528
    vf.mul       v21, v17, v15
    vf.mul       v15, v21, v28
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a2, s34
    s.movz       s34, #1
    s.addi       s35, s14, #14400
    v.ld.w       v15, [s36, #0]
    v.extract    s36, v32, #1
    v.splat      v17, s36
    s.addi       s36, s39, #64
    vf.mul       v21, v15, v14
    vf.mul       v14, v21, v28
    vf.add       v15, v12, v14
    v.st.w       [s41, #0], v15
    fence.acq_rel.device
    a.vread      v12, a3, s38
    s.movz       s38, #2
    s.addi       s40, s14, #14464
    v.ld.w       v14, [s37, #0]
    v.extract    s37, v32, #2
    v.splat      v15, s37
    s.addi       s37, s39, #128
    vf.mul       v21, v14, v19
    vf.mul       v14, v21, v26
    vf.add       v19, v12, v14
    v.st.w       [s39, #0], v19
    a.vread      v12, a3, s34
    s.movz       s34, #3
    v.ld.w       v14, [s35, #0]
    s.addi       s35, s14, #14528
    vf.mul       v19, v14, v17
    vf.mul       v14, v19, v26
    vf.add       v17, v12, v14
    v.st.w       [s36, #0], v17
    a.vread      v12, a3, s38
    v.extract    s36, v32, #3
    s.addi       s38, s39, #192
    v.splat      v14, s36
    s.movz       s36, #4
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #14592
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v26
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a3, s34
    v.extract    s34, v32, #4
    s.addi       s37, s39, #256
    v.splat      v15, s34
    s.movz       s34, #5
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #14656
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v26
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a3, s36
    v.extract    s36, v32, #5
    s.addi       s38, s39, #320
    v.splat      v14, s36
    s.movz       s36, #6
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #14720
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v26
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a3, s34
    v.extract    s34, v32, #6
    s.addi       s37, s39, #384
    v.splat      v15, s34
    s.movz       s34, #7
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #14784
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v26
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a3, s36
    v.extract    s36, v32, #7
    s.addi       s38, s39, #448
    v.splat      v14, s36
    s.movz       s36, #8
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #14848
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v26
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a3, s34
    v.extract    s34, v32, #8
    s.addi       s37, s39, #512
    v.splat      v15, s34
    s.movz       s34, #9
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #14912
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v26
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a3, s36
    v.extract    s36, v32, #9
    s.addi       s38, s39, #576
    v.splat      v14, s36
    s.movz       s36, #10
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #14976
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v26
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a3, s34
    v.extract    s34, v32, #10
    s.addi       s37, s39, #640
    v.splat      v15, s34
    s.movz       s34, #11
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #15040
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v26
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a3, s36
    v.extract    s36, v32, #11
    s.addi       s38, s39, #704
    v.splat      v14, s36
    s.movz       s36, #12
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #15104
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v26
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a3, s34
    v.extract    s34, v32, #12
    s.addi       s37, s39, #768
    v.splat      v15, s34
    s.movz       s34, #13
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #15168
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v26
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a3, s36
    v.extract    s36, v32, #13
    s.addi       s38, s39, #832
    v.splat      v14, s36
    s.movz       s36, #14
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #15232
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v26
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a3, s34
    v.extract    s34, v32, #14
    s.addi       s37, s39, #896
    v.splat      v15, s34
    s.movz       s34, #15
    s.addi       s41, s39, #960
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #15296
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v26
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a3, s36
    v.extract    s36, v32, #15
    s.movz       s38, #0
    v.splat      v14, s36
    s.addi       s36, s14, #15360
    v.ld.w       v17, [s40, #0]
    v.extract    s39, v32, #0
    v.splat      v19, s39
    s.addi       s39, s14, #23552
    vf.mul       v21, v17, v15
    vf.mul       v15, v21, v26
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a3, s34
    s.movz       s34, #1
    s.addi       s37, s14, #15424
    v.ld.w       v15, [s35, #0]
    v.extract    s35, v32, #1
    v.splat      v17, s35
    s.addi       s35, s39, #64
    vf.mul       v21, v15, v14
    vf.mul       v14, v21, v26
    vf.add       v15, v12, v14
    v.st.w       [s41, #0], v15
    fence.acq_rel.device
    a.vread      v12, a4, s38
    s.movz       s38, #2
    s.addi       s40, s14, #15488
    v.ld.w       v14, [s36, #0]
    v.extract    s36, v32, #2
    v.splat      v15, s36
    s.addi       s36, s39, #128
    vf.mul       v21, v14, v19
    vf.mul       v14, v21, v35
    vf.add       v19, v12, v14
    v.st.w       [s39, #0], v19
    a.vread      v12, a4, s34
    s.movz       s34, #3
    v.ld.w       v14, [s37, #0]
    s.addi       s37, s14, #15552
    vf.mul       v19, v14, v17
    vf.mul       v14, v19, v35
    vf.add       v17, v12, v14
    v.st.w       [s35, #0], v17
    a.vread      v12, a4, s38
    v.extract    s35, v32, #3
    s.addi       s38, s39, #192
    v.splat      v14, s35
    s.movz       s35, #4
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #15616
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v35
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a4, s34
    v.extract    s34, v32, #4
    s.addi       s36, s39, #256
    v.splat      v15, s34
    s.movz       s34, #5
    v.ld.w       v17, [s37, #0]
    s.addi       s37, s14, #15680
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v35
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a4, s35
    v.extract    s35, v32, #5
    s.addi       s38, s39, #320
    v.splat      v14, s35
    s.movz       s35, #6
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #15744
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v35
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a4, s34
    v.extract    s34, v32, #6
    s.addi       s36, s39, #384
    v.splat      v15, s34
    s.movz       s34, #7
    v.ld.w       v17, [s37, #0]
    s.addi       s37, s14, #15808
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v35
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a4, s35
    v.extract    s35, v32, #7
    s.addi       s38, s39, #448
    v.splat      v14, s35
    s.movz       s35, #8
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #15872
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v35
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a4, s34
    v.extract    s34, v32, #8
    s.addi       s36, s39, #512
    v.splat      v15, s34
    s.movz       s34, #9
    v.ld.w       v17, [s37, #0]
    s.addi       s37, s14, #15936
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v35
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a4, s35
    v.extract    s35, v32, #9
    s.addi       s38, s39, #576
    v.splat      v14, s35
    s.movz       s35, #10
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #16000
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v35
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a4, s34
    v.extract    s34, v32, #10
    s.addi       s36, s39, #640
    v.splat      v15, s34
    s.movz       s34, #11
    v.ld.w       v17, [s37, #0]
    s.addi       s37, s14, #16064
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v35
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a4, s35
    v.extract    s35, v32, #11
    s.addi       s38, s39, #704
    v.splat      v14, s35
    s.movz       s35, #12
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #16128
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v35
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a4, s34
    v.extract    s34, v32, #12
    s.addi       s36, s39, #768
    v.splat      v15, s34
    s.movz       s34, #13
    v.ld.w       v17, [s37, #0]
    s.addi       s37, s14, #16192
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v35
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a4, s35
    v.extract    s35, v32, #13
    s.addi       s38, s39, #832
    v.splat      v14, s35
    s.movz       s35, #14
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #16256
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v35
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a4, s34
    v.extract    s34, v32, #14
    s.addi       s36, s39, #896
    v.splat      v15, s34
    s.movz       s34, #15
    s.addi       s41, s39, #960
    v.ld.w       v17, [s37, #0]
    s.addi       s37, s14, #16320
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v35
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a4, s35
    v.extract    s35, v32, #15
    s.movz       s38, #0
    v.splat      v14, s35
    s.addi       s35, s14, #16384
    v.ld.w       v17, [s40, #0]
    v.extract    s39, v32, #0
    v.splat      v19, s39
    s.addi       s39, s14, #24576
    vf.mul       v21, v17, v15
    vf.mul       v15, v21, v35
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a4, s34
    s.movz       s34, #1
    s.addi       s36, s14, #16448
    v.ld.w       v15, [s37, #0]
    v.extract    s37, v32, #1
    v.splat      v17, s37
    s.addi       s37, s39, #64
    vf.mul       v21, v15, v14
    vf.mul       v14, v21, v35
    vf.add       v15, v12, v14
    v.st.w       [s41, #0], v15
    fence.acq_rel.device
    a.vread      v12, a5, s38
    s.movz       s38, #2
    s.addi       s40, s14, #16512
    v.ld.w       v14, [s35, #0]
    v.extract    s35, v32, #2
    v.splat      v15, s35
    s.addi       s35, s39, #128
    vf.mul       v21, v14, v19
    vf.mul       v14, v21, v36
    vf.add       v19, v12, v14
    v.st.w       [s39, #0], v19
    a.vread      v12, a5, s34
    s.movz       s34, #3
    v.ld.w       v14, [s36, #0]
    s.addi       s36, s14, #16576
    vf.mul       v19, v14, v17
    vf.mul       v14, v19, v36
    vf.add       v17, v12, v14
    v.st.w       [s37, #0], v17
    a.vread      v12, a5, s38
    v.extract    s37, v32, #3
    s.addi       s38, s39, #192
    v.splat      v14, s37
    s.movz       s37, #4
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #16640
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v36
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a5, s34
    v.extract    s34, v32, #4
    s.addi       s35, s39, #256
    v.splat      v15, s34
    s.movz       s34, #5
    v.ld.w       v17, [s36, #0]
    s.addi       s36, s14, #16704
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v36
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a5, s37
    v.extract    s37, v32, #5
    s.addi       s38, s39, #320
    v.splat      v14, s37
    s.movz       s37, #6
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #16768
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v36
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a5, s34
    v.extract    s34, v32, #6
    s.addi       s35, s39, #384
    v.splat      v15, s34
    s.movz       s34, #7
    v.ld.w       v17, [s36, #0]
    s.addi       s36, s14, #16832
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v36
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a5, s37
    v.extract    s37, v32, #7
    s.addi       s38, s39, #448
    v.splat      v14, s37
    s.movz       s37, #8
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #16896
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v36
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a5, s34
    v.extract    s34, v32, #8
    s.addi       s35, s39, #512
    v.splat      v15, s34
    s.movz       s34, #9
    v.ld.w       v17, [s36, #0]
    s.addi       s36, s14, #16960
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v36
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a5, s37
    v.extract    s37, v32, #9
    s.addi       s38, s39, #576
    v.splat      v14, s37
    s.movz       s37, #10
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #17024
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v36
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a5, s34
    v.extract    s34, v32, #10
    s.addi       s35, s39, #640
    v.splat      v15, s34
    s.movz       s34, #11
    v.ld.w       v17, [s36, #0]
    s.addi       s36, s14, #17088
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v36
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a5, s37
    v.extract    s37, v32, #11
    s.addi       s38, s39, #704
    v.splat      v14, s37
    s.movz       s37, #12
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #17152
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v36
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a5, s34
    v.extract    s34, v32, #12
    s.addi       s35, s39, #768
    v.splat      v15, s34
    s.movz       s34, #13
    v.ld.w       v17, [s36, #0]
    s.addi       s36, s14, #17216
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v36
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a5, s37
    v.extract    s37, v32, #13
    s.addi       s38, s39, #832
    v.splat      v14, s37
    s.movz       s37, #14
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #17280
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v36
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a5, s34
    v.extract    s34, v32, #14
    s.addi       s35, s39, #896
    v.splat      v15, s34
    s.movz       s34, #15
    s.addi       s41, s39, #960
    v.ld.w       v17, [s36, #0]
    s.addi       s36, s14, #17344
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v36
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a5, s37
    v.extract    s37, v32, #15
    s.movz       s38, #0
    v.splat      v14, s37
    s.addi       s37, s14, #17408
    v.ld.w       v17, [s40, #0]
    v.extract    s39, v32, #0
    v.splat      v19, s39
    s.addi       s39, s14, #25600
    vf.mul       v21, v17, v15
    vf.mul       v15, v21, v36
    vf.add       v17, v12, v15
    v.st.w       [s35, #0], v17
    a.vread      v12, a5, s34
    s.movz       s34, #1
    s.addi       s35, s14, #17472
    v.ld.w       v15, [s36, #0]
    v.extract    s36, v32, #1
    v.splat      v17, s36
    s.addi       s36, s39, #64
    vf.mul       v21, v15, v14
    vf.mul       v14, v21, v36
    vf.add       v15, v12, v14
    v.st.w       [s41, #0], v15
    fence.acq_rel.device
    a.vread      v12, a6, s38
    s.movz       s38, #2
    s.addi       s40, s14, #17536
    v.ld.w       v14, [s37, #0]
    v.extract    s37, v32, #2
    v.splat      v15, s37
    s.addi       s37, s39, #128
    vf.mul       v21, v14, v19
    vf.mul       v14, v21, v37
    vf.add       v19, v12, v14
    v.st.w       [s39, #0], v19
    a.vread      v12, a6, s34
    s.movz       s34, #3
    v.ld.w       v14, [s35, #0]
    s.addi       s35, s14, #17600
    vf.mul       v19, v14, v17
    vf.mul       v14, v19, v37
    vf.add       v17, v12, v14
    v.st.w       [s36, #0], v17
    a.vread      v12, a6, s38
    v.extract    s36, v32, #3
    s.addi       s38, s39, #192
    v.splat      v14, s36
    s.movz       s36, #4
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #17664
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v37
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a6, s34
    v.extract    s34, v32, #4
    s.addi       s37, s39, #256
    v.splat      v15, s34
    s.movz       s34, #5
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #17728
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v37
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a6, s36
    v.extract    s36, v32, #5
    s.addi       s38, s39, #320
    v.splat      v14, s36
    s.movz       s36, #6
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #17792
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v37
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a6, s34
    v.extract    s34, v32, #6
    s.addi       s37, s39, #384
    v.splat      v15, s34
    s.movz       s34, #7
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #17856
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v37
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a6, s36
    v.extract    s36, v32, #7
    s.addi       s38, s39, #448
    v.splat      v14, s36
    s.movz       s36, #8
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #17920
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v37
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a6, s34
    v.extract    s34, v32, #8
    s.addi       s37, s39, #512
    v.splat      v15, s34
    s.movz       s34, #9
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #17984
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v37
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a6, s36
    v.extract    s36, v32, #9
    s.addi       s38, s39, #576
    v.splat      v14, s36
    s.movz       s36, #10
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #18048
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v37
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a6, s34
    v.extract    s34, v32, #10
    s.addi       s37, s39, #640
    v.splat      v15, s34
    s.movz       s34, #11
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #18112
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v37
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a6, s36
    v.extract    s36, v32, #11
    s.addi       s38, s39, #704
    v.splat      v14, s36
    s.movz       s36, #12
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #18176
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v37
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a6, s34
    v.extract    s34, v32, #12
    s.addi       s37, s39, #768
    v.splat      v15, s34
    s.movz       s34, #13
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #18240
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v37
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a6, s36
    v.extract    s36, v32, #13
    s.addi       s38, s39, #832
    v.splat      v14, s36
    s.movz       s36, #14
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #18304
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v37
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a6, s34
    v.extract    s34, v32, #14
    s.addi       s37, s39, #896
    v.splat      v15, s34
    s.movz       s34, #15
    s.addi       s41, s39, #960
    v.ld.w       v17, [s35, #0]
    s.addi       s35, s14, #18368
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v37
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a6, s36
    v.extract    s36, v32, #15
    s.movz       s38, #0
    v.splat      v14, s36
    s.addi       s36, s14, #18432
    v.ld.w       v17, [s40, #0]
    v.extract    s39, v32, #0
    v.splat      v19, s39
    s.addi       s39, s14, #26624
    vf.mul       v21, v17, v15
    vf.mul       v15, v21, v37
    vf.add       v17, v12, v15
    v.st.w       [s37, #0], v17
    a.vread      v12, a6, s34
    s.movz       s34, #1
    s.addi       s37, s14, #18496
    v.ld.w       v15, [s35, #0]
    v.extract    s35, v32, #1
    v.splat      v17, s35
    s.addi       s35, s39, #64
    vf.mul       v21, v15, v14
    vf.mul       v14, v21, v37
    vf.add       v15, v12, v14
    v.st.w       [s41, #0], v15
    fence.acq_rel.device
    a.vread      v12, a7, s38
    s.movz       s38, #2
    s.addi       s40, s14, #18560
    v.ld.w       v14, [s36, #0]
    v.extract    s36, v32, #2
    v.splat      v15, s36
    s.addi       s36, s39, #128
    vf.mul       v21, v14, v19
    vf.mul       v14, v21, v38
    vf.add       v19, v12, v14
    v.st.w       [s39, #0], v19
    a.vread      v12, a7, s34
    s.movz       s34, #3
    v.ld.w       v14, [s37, #0]
    s.addi       s37, s14, #18624
    vf.mul       v19, v14, v17
    vf.mul       v14, v19, v38
    vf.add       v17, v12, v14
    v.st.w       [s35, #0], v17
    a.vread      v12, a7, s38
    v.extract    s35, v32, #3
    s.addi       s38, s39, #192
    v.splat      v14, s35
    s.movz       s35, #4
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #18688
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v38
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a7, s34
    v.extract    s34, v32, #4
    s.addi       s36, s39, #256
    v.splat      v15, s34
    s.movz       s34, #5
    v.ld.w       v17, [s37, #0]
    s.addi       s37, s14, #18752
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v38
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a7, s35
    v.extract    s35, v32, #5
    s.addi       s38, s39, #320
    v.splat      v14, s35
    s.movz       s35, #6
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #18816
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v38
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a7, s34
    v.extract    s34, v32, #6
    s.addi       s36, s39, #384
    v.splat      v15, s34
    s.movz       s34, #7
    v.ld.w       v17, [s37, #0]
    s.addi       s37, s14, #18880
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v38
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a7, s35
    v.extract    s35, v32, #7
    s.addi       s38, s39, #448
    v.splat      v14, s35
    s.movz       s35, #8
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #18944
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v38
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a7, s34
    v.extract    s34, v32, #8
    s.addi       s36, s39, #512
    v.splat      v15, s34
    s.movz       s34, #9
    v.ld.w       v17, [s37, #0]
    s.addi       s37, s14, #19008
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v38
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a7, s35
    v.extract    s35, v32, #9
    s.addi       s38, s39, #576
    v.splat      v14, s35
    s.movz       s35, #10
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #19072
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v38
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a7, s34
    v.extract    s34, v32, #10
    s.addi       s36, s39, #640
    v.splat      v15, s34
    s.movz       s34, #11
    v.ld.w       v17, [s37, #0]
    s.addi       s37, s14, #19136
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v38
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a7, s35
    v.extract    s35, v32, #11
    s.addi       s38, s39, #704
    v.splat      v14, s35
    s.movz       s35, #12
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #19200
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v38
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a7, s34
    v.extract    s34, v32, #12
    s.addi       s36, s39, #768
    v.splat      v15, s34
    s.movz       s34, #13
    v.ld.w       v17, [s37, #0]
    s.addi       s37, s14, #19264
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v38
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a7, s35
    v.extract    s35, v32, #13
    s.addi       s38, s39, #832
    v.splat      v14, s35
    s.movz       s35, #14
    s.addi       s41, s24, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s14, #19328
    s.addi       s41, s24, #4                    // &ptr_carry_19[1] (a constant offset, x4)
    s.addi       s41, s24, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    s.addi       s41, s24, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    vf.mul       v19, v17, v15
    s.addi       s41, s24, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    vf.mul       v15, v19, v38
    s.addi       s41, s24, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    vf.add       v17, v12, v15
    s.addi       s41, s24, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    v.st.w       [s36, #0], v17
    a.vread      v12, a7, s34
    v.extract    s34, v32, #14
    s.addi       s36, s39, #896
    v.splat      v15, s34
    s.movz       s34, #15
    s.addi       s41, s39, #960
    v.ld.w       v17, [s37, #0]
    s.addi       s37, s14, #19392
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v38
    vf.add       v17, v12, v14
    v.st.w       [s38, #0], v17
    a.vread      v12, a7, s35
    v.extract    s35, v32, #15
    s.addi       s38, s22, #128
    v.splat      v14, s35
    s.addi       s35, s23, #128
    s.addi       s39, s38, #0
    s.addi       s38, s35, #0
    v.ld.w       v17, [s40, #0]
    s.addi       s35, s24, #4                    // &ptr_carry_17[1] (a constant offset, x4)
    s.addi       s40, s35, #0
    vf.mul       v19, v17, v15
    vf.mul       v15, v19, v38
    vf.add       v17, v12, v15
    v.st.w       [s36, #0], v17
    a.vread      v12, a7, s34
    s.addi       s34, s14, #19456
    s.movz       s35, #0
    v.ld.w       v15, [s37, #0]
    s.addi       s36, s14, #19520
    vf.mul       v17, v15, v14
    vf.mul       v14, v17, v38
    vf.add       v15, v12, v14
    v.st.w       [s41, #0], v15
    fence.acq_rel.device
    s.mov        s22, s39
    s.mov        s23, s38
    s.mov        s24, s40
    s.movz       s37, #1
    s.addi       s38, s14, #19584
    s.movz       s39, #2
    s.addi       s40, s14, #19648
    s.movz       s41, #3
    s.addi       s42, s14, #19712
    s.movz       s43, #4
    v.ld.w       v12, [s34, #0]
    s.addi       s34, s14, #19776
    a.vwrite     a0, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #5
    s.addi       s36, s14, #19840
    a.vwrite     a0, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #6
    s.addi       s38, s14, #19904
    a.vwrite     a0, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #7
    s.addi       s40, s14, #19968
    a.vwrite     a0, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #8
    s.addi       s42, s14, #20032
    a.vwrite     a0, s43, v12
    v.ld.w       v12, [s34, #0]
    s.movz       s34, #9
    s.addi       s43, s14, #20096
    a.vwrite     a0, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #10
    s.addi       s36, s14, #20160
    a.vwrite     a0, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #11
    s.addi       s38, s14, #20224
    a.vwrite     a0, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #12
    s.addi       s40, s14, #20288
    a.vwrite     a0, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #13
    s.addi       s42, s14, #20352
    a.vwrite     a0, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #14
    s.addi       s43, s14, #20416
    a.vwrite     a0, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #15
    s.addi       s36, s14, #20480
    a.vwrite     a0, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #0
    s.addi       s38, s14, #20544
    a.vwrite     a0, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #1
    s.addi       s40, s14, #20608
    a.vwrite     a0, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #2
    s.addi       s42, s14, #20672
    a.vwrite     a0, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #3
    s.addi       s43, s14, #20736
    a.vwrite     a0, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #4
    s.addi       s36, s14, #20800
    a.vwrite     a1, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #5
    s.addi       s38, s14, #20864
    a.vwrite     a1, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #6
    s.addi       s40, s14, #20928
    a.vwrite     a1, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #7
    s.addi       s42, s14, #20992
    a.vwrite     a1, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #8
    s.addi       s43, s14, #21056
    a.vwrite     a1, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #9
    s.addi       s36, s14, #21120
    a.vwrite     a1, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #10
    s.addi       s38, s14, #21184
    a.vwrite     a1, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #11
    s.addi       s40, s14, #21248
    a.vwrite     a1, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #12
    s.addi       s42, s14, #21312
    a.vwrite     a1, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #13
    s.addi       s43, s14, #21376
    a.vwrite     a1, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #14
    s.addi       s36, s14, #21440
    a.vwrite     a1, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #15
    s.addi       s38, s14, #21504
    a.vwrite     a1, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #0
    s.addi       s40, s14, #21568
    a.vwrite     a1, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #1
    s.addi       s42, s14, #21632
    a.vwrite     a1, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #2
    s.addi       s43, s14, #21696
    a.vwrite     a1, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #3
    s.addi       s36, s14, #21760
    a.vwrite     a1, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #4
    s.addi       s38, s14, #21824
    a.vwrite     a2, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #5
    s.addi       s40, s14, #21888
    a.vwrite     a2, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #6
    s.addi       s42, s14, #21952
    a.vwrite     a2, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #7
    s.addi       s43, s14, #22016
    a.vwrite     a2, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #8
    s.addi       s36, s14, #22080
    a.vwrite     a2, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #9
    s.addi       s38, s14, #22144
    a.vwrite     a2, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #10
    s.addi       s40, s14, #22208
    a.vwrite     a2, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #11
    s.addi       s42, s14, #22272
    a.vwrite     a2, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #12
    s.addi       s43, s14, #22336
    a.vwrite     a2, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #13
    s.addi       s36, s14, #22400
    a.vwrite     a2, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #14
    s.addi       s38, s14, #22464
    a.vwrite     a2, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #15
    s.addi       s40, s14, #22528
    a.vwrite     a2, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #0
    s.addi       s42, s14, #22592
    a.vwrite     a2, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #1
    s.addi       s43, s14, #22656
    a.vwrite     a2, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #2
    s.addi       s36, s14, #22720
    a.vwrite     a2, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #3
    s.addi       s38, s14, #22784
    a.vwrite     a2, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #4
    s.addi       s40, s14, #22848
    a.vwrite     a3, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #5
    s.addi       s42, s14, #22912
    a.vwrite     a3, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #6
    s.addi       s43, s14, #22976
    a.vwrite     a3, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #7
    s.addi       s36, s14, #23040
    a.vwrite     a3, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #8
    s.addi       s38, s14, #23104
    a.vwrite     a3, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #9
    s.addi       s40, s14, #23168
    a.vwrite     a3, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #10
    s.addi       s42, s14, #23232
    a.vwrite     a3, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #11
    s.addi       s43, s14, #23296
    a.vwrite     a3, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #12
    s.addi       s36, s14, #23360
    a.vwrite     a3, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #13
    s.addi       s38, s14, #23424
    a.vwrite     a3, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #14
    s.addi       s40, s14, #23488
    a.vwrite     a3, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #15
    s.addi       s42, s14, #23552
    a.vwrite     a3, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #0
    s.addi       s43, s14, #23616
    a.vwrite     a3, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #1
    s.addi       s36, s14, #23680
    a.vwrite     a3, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #2
    s.addi       s38, s14, #23744
    a.vwrite     a3, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #3
    s.addi       s40, s14, #23808
    a.vwrite     a3, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #4
    s.addi       s42, s14, #23872
    a.vwrite     a4, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #5
    s.addi       s43, s14, #23936
    a.vwrite     a4, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #6
    s.addi       s36, s14, #24000
    a.vwrite     a4, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #7
    s.addi       s38, s14, #24064
    a.vwrite     a4, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #8
    s.addi       s40, s14, #24128
    a.vwrite     a4, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #9
    s.addi       s42, s14, #24192
    a.vwrite     a4, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #10
    s.addi       s43, s14, #24256
    a.vwrite     a4, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #11
    s.addi       s36, s14, #24320
    a.vwrite     a4, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #12
    s.addi       s38, s14, #24384
    a.vwrite     a4, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #13
    s.addi       s40, s14, #24448
    a.vwrite     a4, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #14
    s.addi       s42, s14, #24512
    a.vwrite     a4, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #15
    s.addi       s43, s14, #24576
    a.vwrite     a4, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #0
    s.addi       s36, s14, #24640
    a.vwrite     a4, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #1
    s.addi       s38, s14, #24704
    a.vwrite     a4, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #2
    s.addi       s40, s14, #24768
    a.vwrite     a4, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #3
    s.addi       s42, s14, #24832
    a.vwrite     a4, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #4
    s.addi       s43, s14, #24896
    a.vwrite     a5, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #5
    s.addi       s36, s14, #24960
    a.vwrite     a5, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #6
    s.addi       s38, s14, #25024
    a.vwrite     a5, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #7
    s.addi       s40, s14, #25088
    a.vwrite     a5, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #8
    s.addi       s42, s14, #25152
    a.vwrite     a5, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #9
    s.addi       s43, s14, #25216
    a.vwrite     a5, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #10
    s.addi       s36, s14, #25280
    a.vwrite     a5, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #11
    s.addi       s38, s14, #25344
    a.vwrite     a5, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #12
    s.addi       s40, s14, #25408
    a.vwrite     a5, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #13
    s.addi       s42, s14, #25472
    a.vwrite     a5, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #14
    s.addi       s43, s14, #25536
    a.vwrite     a5, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #15
    s.addi       s36, s14, #25600
    a.vwrite     a5, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #0
    s.addi       s38, s14, #25664
    a.vwrite     a5, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #1
    s.addi       s40, s14, #25728
    a.vwrite     a5, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #2
    s.addi       s42, s14, #25792
    a.vwrite     a5, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #3
    s.addi       s43, s14, #25856
    a.vwrite     a5, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #4
    s.addi       s36, s14, #25920
    a.vwrite     a6, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #5
    s.addi       s38, s14, #25984
    a.vwrite     a6, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #6
    s.addi       s40, s14, #26048
    a.vwrite     a6, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #7
    s.addi       s42, s14, #26112
    a.vwrite     a6, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #8
    s.addi       s43, s14, #26176
    a.vwrite     a6, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #9
    s.addi       s36, s14, #26240
    a.vwrite     a6, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #10
    s.addi       s38, s14, #26304
    a.vwrite     a6, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #11
    s.addi       s40, s14, #26368
    a.vwrite     a6, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #12
    s.addi       s42, s14, #26432
    a.vwrite     a6, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #13
    s.addi       s43, s14, #26496
    a.vwrite     a6, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #14
    s.addi       s36, s14, #26560
    a.vwrite     a6, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #15
    s.addi       s38, s14, #26624
    a.vwrite     a6, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #0
    s.addi       s40, s14, #26688
    a.vwrite     a6, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #1
    s.addi       s42, s14, #26752
    a.vwrite     a6, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #2
    s.addi       s43, s14, #26816
    a.vwrite     a6, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #3
    s.addi       s36, s14, #26880
    a.vwrite     a6, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #4
    s.addi       s38, s14, #26944
    a.vwrite     a7, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #5
    s.addi       s40, s14, #27008
    a.vwrite     a7, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #6
    s.addi       s42, s14, #27072
    a.vwrite     a7, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #7
    s.addi       s43, s14, #27136
    a.vwrite     a7, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #8
    s.addi       s36, s14, #27200
    a.vwrite     a7, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s37, #9
    s.addi       s38, s14, #27264
    a.vwrite     a7, s39, v12
    v.ld.w       v12, [s40, #0]
    s.movz       s39, #10
    s.addi       s40, s14, #27328
    a.vwrite     a7, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #11
    s.addi       s42, s14, #27392
    a.vwrite     a7, s34, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s34, #12
    s.addi       s43, s14, #27456
    a.vwrite     a7, s35, v12
    v.ld.w       v12, [s36, #0]
    s.movz       s35, #13
    s.addi       s36, s14, #27520
    s.addi       s44, s14, #27584
    a.vwrite     a7, s37, v12
    v.ld.w       v12, [s38, #0]
    s.movz       s14, #14
    s.movz       s37, #15
    a.vwrite     a7, s39, v12
    v.ld.w       v12, [s40, #0]
    s.add        s38, s20, s5
    s.movz       s39, #1
    a.vwrite     a7, s41, v12
    v.ld.w       v12, [s42, #0]
    a.vwrite     a7, s34, v12
    v.ld.w       v12, [s43, #0]
    a.vwrite     a7, s35, v12
    v.ld.w       v12, [s36, #0]
    a.vwrite     a7, s14, v12
    v.ld.w       v12, [s44, #0]
    a.vwrite     a7, s37, v12
    s.mov        s20, s38
    br.nz        s39, for_25
endfor_26:
    s.mul        s2, s19, s4
    s.movz       s4, #0
    s.movz       s6, #0
    s.add        s7, s4, s1                      // the tile origin
    s.movz       s4, #0
    s.mul        s8, s2, s21
    s.movz       s9, #0
    s.muli       s10, s1, #2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    s.muli       s7, s8, #2
    a.vread      v2, a0, s6
    s.muli       s6, s21, #2
    s.add        s8, s4, s2                      // the tile origin
    s.add        s4, s9, s3                      // the tile origin
    v.splat      v3, s8
    v.splat      v4, s5
    v.add        v5, v0, v1
    v.splat      v1, s4
    vf.cvt.f32.bf16 v6, v2
    s.add        s4, s7, s10
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.muli       s5, s6, #1
    s.add        s9, s16, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    @p3 v.st.h       [s9, #0], v6
    a.vread      v1, a0, s4
    s.addi       s4, s8, #1
    s.add        s9, s5, s7
    v.splat      v2, s4
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s9, s10
    v.cmp.lt     p1, v2, v4
    s.add        s5, s16, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.addi       s9, s1, #16
    s.addi       s11, s1, #32
    s.addi       s12, s1, #48
    @p3 v.st.h       [s5, #0], v3
    s.addi       s5, s1, #64
    s.addi       s13, s1, #80
    s.addi       s14, s1, #96
    s.addi       s15, s1, #112
    v.iota       v1                              // arange(0, VLEN)
    a.vread      v2, a0, s4
    v.splat      v3, s2
    vf.cvt.f32.bf16 v5, v2
    v.add        v2, v3, v1
    s.muli       s1, s6, #2
    s.addi       s2, s8, #2
    s.muli       s4, s6, #3
    v.splat      v1, s2
    s.movz       s2, #3
    s.add        s17, s1, s7
    v.cmp.lt     p1, v1, v4
    s.add        s1, s17, s10
    p.and        p3, p1, p2
    s.add        s17, s16, s1
    s.addi       s1, s8, #3
    @p3 v.st.h       [s17, #0], v5
    a.vread      v1, a0, s2
    s.add        s2, s4, s7
    v.splat      v2, s1
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s2, s10
    v.cmp.lt     p1, v2, v4
    s.muli       s2, s6, #4
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    s.movz       s1, #4
    s.addi       s17, s8, #4
    s.add        s18, s2, s7
    v.splat      v1, s17
    @p3 v.st.h       [s4, #0], v3
    a.vread      v2, a0, s1
    s.add        s1, s18, s10
    v.cmp.lt     p1, v1, v4
    vf.cvt.f32.bf16 v1, v2
    s.muli       s2, s6, #5
    s.add        s4, s16, s1
    p.and        p3, p1, p2
    s.movz       s1, #5
    s.addi       s17, s8, #5
    s.add        s18, s2, s7
    v.splat      v2, s17
    s.add        s2, s18, s10
    s.muli       s17, s6, #6
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v2, v4
    s.add        s1, s16, s2
    vf.cvt.f32.bf16 v2, v1
    p.and        p3, p1, p2
    s.movz       s2, #6
    s.addi       s4, s8, #6
    s.add        s18, s17, s7
    v.splat      v1, s4
    s.add        s4, s18, s10
    s.muli       s17, s6, #7
    v.cmp.lt     p1, v1, v4
    s.add        s18, s16, s4
    @p3 v.st.h       [s1, #0], v2
    a.vread      v1, a0, s2
    p.and        p3, p1, p2
    s.movz       s1, #7
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #7
    s.add        s4, s17, s7
    v.splat      v1, s2
    s.add        s2, s4, s10
    s.muli       s4, s6, #8
    v.cmp.lt     p1, v1, v4
    s.add        s17, s16, s2
    p.and        p4, p1, p2
    s.movz       s2, #8
    @p3 v.st.h       [s18, #0], v2
    a.vread      v1, a0, s1
    s.addi       s1, s8, #8
    s.add        s18, s4, s7
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s1
    s.add        s1, s18, s10
    s.muli       s4, s6, #9
    v.cmp.lt     p1, v1, v4
    s.add        s18, s16, s1
    p.and        p3, p1, p2
    s.movz       s1, #9
    s.addi       s19, s8, #9
    s.add        s20, s4, s7
    @p4 v.st.h       [s17, #0], v2
    a.vread      v1, a0, s2
    v.splat      v2, s19
    s.add        s2, s20, s10
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s4, s6, #10
    s.add        s17, s16, s2
    p.and        p4, p1, p2
    s.movz       s2, #10
    s.addi       s19, s8, #10
    s.add        s20, s4, s7
    v.splat      v1, s19
    s.add        s4, s20, s10
    @p3 v.st.h       [s18, #0], v3
    a.vread      v2, a0, s1
    v.cmp.lt     p1, v1, v4
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v1, v2
    s.add        s18, s16, s4
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.addi       s19, s8, #11
    s.add        s20, s1, s7
    v.splat      v2, s19
    s.add        s1, s20, s10
    s.muli       s19, s6, #12
    s.add        s20, s16, s1
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.movz       s1, #12
    s.addi       s2, s8, #12
    s.add        s17, s19, s7
    v.splat      v1, s2
    s.add        s2, s17, s10
    s.muli       s17, s6, #13
    s.add        s19, s16, s2
    s.movz       s2, #13
    s.addi       s21, s8, #13
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a0, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s4, s17, s7
    v.splat      v2, s21
    s.add        s17, s4, s10
    s.muli       s4, s6, #14
    s.add        s18, s16, s17
    s.movz       s17, #14
    s.addi       s21, s8, #14
    s.add        s22, s4, s7
    @p4 v.st.h       [s20, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s21
    s.add        s1, s22, s10
    s.muli       s4, s6, #15
    s.add        s20, s16, s1
    s.movz       s1, #15
    s.addi       s21, s8, #15
    v.splat      v3, s8
    s.add        s22, s4, s7
    v.splat      v5, s21
    @p3 v.st.h       [s19, #0], v2
    a.vread      v2, a0, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s2, #0
    s.add        s4, s22, s10
    s.add        s10, s2, s9                     // the tile origin
    s.add        s2, s16, s4
    s.movz       s4, #0
    s.movz       s19, #0
    s.muli       s21, s9, #2
    v.splat      v2, s10
    s.add        s9, s19, s3                     // the tile origin
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v1
    v.add        v1, v0, v2
    v.splat      v2, s9
    s.add        s9, s7, s21
    v.cmp.lt     p1, v3, v4
    s.muli       s10, s6, #1
    s.add        s17, s16, s9
    s.movz       s9, #1
    s.addi       s18, s8, #1
    s.muli       s19, s6, #2
    @p3 v.st.h       [s20, #0], v5
    a.vread      v3, a0, s1
    v.cmp.lt     p2, v1, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s10, s7
    v.splat      v2, s18
    s.add        s10, s1, s21
    s.movz       s1, #2
    s.add        s18, s16, s10
    s.addi       s10, s8, #2
    s.add        s20, s19, s7
    v.splat      v3, s10
    s.add        s10, s20, s21
    @p4 v.st.h       [s2, #0], v1
    a.vread      v1, a1, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s2, s6, #3
    s.add        s4, s16, s10
    s.movz       s10, #3
    s.addi       s19, s8, #3
    s.muli       s20, s6, #4
    s.add        s22, s2, s7
    v.splat      v1, s19
    s.add        s2, s22, s21
    s.movz       s19, #4
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s9
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s9, s16, s2
    s.addi       s2, s8, #4
    s.add        s17, s20, s7
    v.splat      v2, s2
    s.add        s2, s17, s21
    s.muli       s17, s6, #5
    s.add        s20, s16, s2
    s.movz       s2, #5
    @p4 v.st.h       [s18, #0], v3
    a.vread      v3, a1, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s1, s8, #5
    s.add        s18, s17, s7
    v.splat      v3, s1
    s.add        s1, s18, s21
    s.muli       s17, s6, #6
    s.add        s18, s16, s1
    s.movz       s1, #6
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a1, s10
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s4, s8, #6
    s.add        s10, s17, s7
    v.splat      v1, s4
    s.add        s4, s10, s21
    s.muli       s10, s6, #7
    s.add        s17, s16, s4
    s.movz       s4, #7
    @p4 v.st.h       [s9, #0], v2
    a.vread      v2, a1, s19
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s9, s8, #7
    s.add        s19, s10, s7
    v.splat      v2, s9
    s.add        s9, s19, s21
    s.muli       s10, s6, #8
    s.add        s19, s16, s9
    s.movz       s9, #8
    @p3 v.st.h       [s20, #0], v3
    a.vread      v3, a1, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s2, s8, #8
    s.add        s20, s10, s7
    v.splat      v3, s2
    s.add        s2, s20, s21
    s.muli       s10, s6, #9
    s.add        s20, s16, s2
    s.movz       s2, #9
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s1, s8, #9
    s.add        s18, s10, s7
    v.splat      v1, s1
    s.add        s1, s18, s21
    s.muli       s10, s6, #10
    s.add        s18, s16, s1
    s.movz       s1, #10
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s4, s8, #10
    s.add        s17, s10, s7
    v.splat      v2, s4
    s.add        s4, s17, s21
    s.muli       s10, s6, #11
    s.add        s17, s16, s4
    s.movz       s4, #11
    @p4 v.st.h       [s19, #0], v3
    a.vread      v3, a1, s9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s9, s8, #11
    s.add        s19, s10, s7
    v.splat      v3, s9
    s.add        s9, s19, s21
    s.muli       s10, s6, #12
    s.add        s19, s16, s9
    s.movz       s9, #12
    @p3 v.st.h       [s20, #0], v1
    a.vread      v1, a1, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #12
    s.add        s20, s10, s7
    v.splat      v1, s2
    s.add        s2, s20, s21
    s.muli       s10, s6, #13
    s.add        s20, s16, s2
    s.movz       s2, #13
    @p4 v.st.h       [s18, #0], v2
    a.vread      v2, a1, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s1, s8, #13
    s.add        s18, s10, s7
    v.splat      v2, s1
    s.add        s1, s18, s21
    s.muli       s10, s6, #14
    s.add        s18, s16, s1
    s.movz       s1, #14
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s4, s8, #14
    s.add        s17, s10, s7
    v.splat      v3, s4
    s.add        s4, s17, s21
    s.muli       s10, s6, #15
    s.add        s17, s16, s4
    s.movz       s4, #15
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a1, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s9, s8, #15
    s.add        s19, s10, s7
    v.splat      v1, s9
    s.movz       s9, #0
    s.add        s10, s19, s21
    s.add        s19, s9, s11                    // the tile origin
    s.add        s9, s16, s10
    s.movz       s10, #0
    s.muli       s21, s11, #2
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a1, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.movz       s2, #0
    v.splat      v2, s19
    s.add        s11, s2, s3                     // the tile origin
    v.splat      v5, s8
    v.add        v6, v0, v2
    v.splat      v2, s11
    s.add        s2, s7, s21
    s.muli       s11, s6, #1
    s.add        s19, s16, s2
    @p4 v.st.h       [s18, #0], v3
    a.vread      v3, a1, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v5, v4
    s.movz       s1, #1
    s.addi       s2, s8, #1
    s.add        s18, s11, s7
    v.splat      v3, s2
    s.add        s2, s18, s21
    s.muli       s11, s6, #2
    s.add        s18, s16, s2
    s.movz       s2, #2
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a1, s4
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s4, s8, #2
    s.add        s17, s11, s7
    v.splat      v1, s4
    s.add        s4, s17, s21
    s.muli       s11, s6, #3
    s.add        s17, s16, s4
    s.movz       s4, #3
    @p4 v.st.h       [s9, #0], v2
    a.vread      v2, a2, s10
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s9, s8, #3
    s.add        s10, s11, s7
    v.splat      v2, s9
    s.add        s9, s10, s21
    s.muli       s10, s6, #4
    s.add        s11, s16, s9
    s.movz       s9, #4
    s.addi       s20, s8, #4
    @p3 v.st.h       [s19, #0], v3
    a.vread      v3, a2, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s10, s7
    v.splat      v3, s20
    s.add        s10, s1, s21
    s.muli       s1, s6, #5
    s.add        s19, s16, s10
    s.movz       s10, #5
    s.addi       s20, s8, #5
    s.add        s22, s1, s7
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s20
    s.add        s1, s22, s21
    s.muli       s2, s6, #6
    s.add        s18, s16, s1
    s.movz       s1, #6
    s.addi       s20, s8, #6
    s.add        s22, s2, s7
    v.splat      v5, s20
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s2, s22, s21
    s.muli       s4, s6, #7
    s.add        s17, s16, s2
    s.movz       s2, #7
    s.addi       s20, s8, #7
    s.add        s22, s4, s7
    v.splat      v2, s20
    s.add        s4, s22, s21
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a2, s9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s9, s6, #8
    s.add        s11, s16, s4
    s.movz       s4, #8
    s.addi       s20, s8, #8
    s.add        s22, s9, s7
    v.splat      v3, s20
    s.add        s9, s22, s21
    @p3 v.st.h       [s19, #0], v1
    a.vread      v1, a2, s10
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s10, s6, #9
    s.add        s19, s16, s9
    s.movz       s9, #9
    s.addi       s20, s8, #9
    s.add        s22, s10, s7
    v.splat      v1, s20
    s.add        s10, s22, s21
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a2, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s1, s6, #10
    s.add        s18, s16, s10
    s.movz       s10, #10
    s.addi       s20, s8, #10
    s.add        s22, s1, s7
    v.splat      v5, s20
    s.add        s1, s22, s21
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s2, s6, #11
    s.add        s17, s16, s1
    s.movz       s1, #11
    s.addi       s20, s8, #11
    s.add        s22, s2, s7
    v.splat      v2, s20
    s.add        s2, s22, s21
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a2, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s6, #12
    s.add        s11, s16, s2
    s.movz       s2, #12
    s.addi       s20, s8, #12
    s.add        s22, s4, s7
    v.splat      v3, s20
    s.add        s4, s22, s21
    @p3 v.st.h       [s19, #0], v1
    a.vread      v1, a2, s9
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s9, s6, #13
    s.add        s19, s16, s4
    s.movz       s4, #13
    s.addi       s20, s8, #13
    s.add        s22, s9, s7
    v.splat      v1, s20
    s.add        s9, s22, s21
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a2, s10
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s10, s6, #14
    s.add        s18, s16, s9
    s.movz       s9, #14
    s.addi       s20, s8, #14
    s.add        s22, s10, s7
    v.splat      v5, s20
    s.add        s10, s22, s21
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s6, #15
    s.add        s17, s16, s10
    s.movz       s10, #15
    s.addi       s20, s8, #15
    s.add        s22, s1, s7
    v.splat      v2, s20
    s.add        s1, s22, s21
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a2, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.movz       s2, #0
    s.add        s11, s16, s1
    s.add        s1, s2, s12                     // the tile origin
    s.movz       s2, #0
    s.muli       s20, s12, #2
    v.splat      v3, s1
    v.splat      v6, s8
    @p3 v.st.h       [s19, #0], v1
    a.vread      v1, a2, s4
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s1, #0
    v.add        v1, v0, v3
    s.add        s4, s1, s3                      // the tile origin
    s.add        s1, s7, s20
    v.splat      v3, s4
    s.muli       s4, s6, #1
    s.add        s12, s16, s1
    s.movz       s1, #1
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a2, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    v.cmp.lt     p1, v6, v4
    s.addi       s9, s8, #1
    s.add        s18, s4, s7
    v.splat      v5, s9
    s.add        s4, s18, s20
    s.muli       s9, s6, #2
    s.add        s18, s16, s4
    s.movz       s4, #2
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s10
    v.cmp.lt     p2, v1, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s10, s8, #2
    s.add        s17, s9, s7
    v.splat      v2, s10
    s.add        s9, s17, s20
    s.muli       s10, s6, #3
    s.add        s17, s16, s9
    s.movz       s9, #3
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a3, s2
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s2, s8, #3
    s.add        s11, s10, s7
    v.splat      v1, s2
    s.add        s2, s11, s20
    s.muli       s10, s6, #4
    s.add        s11, s16, s2
    s.movz       s2, #4
    s.addi       s19, s8, #4
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a3, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.add        s1, s10, s7
    v.splat      v3, s19
    s.add        s10, s1, s20
    s.muli       s1, s6, #5
    s.add        s12, s16, s10
    s.movz       s10, #5
    s.addi       s19, s8, #5
    s.add        s21, s1, s7
    @p4 v.st.h       [s18, #0], v2
    a.vread      v2, a3, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s19
    s.add        s1, s21, s20
    s.muli       s4, s6, #6
    s.add        s18, s16, s1
    s.movz       s1, #6
    s.addi       s19, s8, #6
    s.add        s21, s4, s7
    v.splat      v5, s19
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s9
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s21, s20
    s.muli       s9, s6, #7
    s.add        s17, s16, s4
    s.movz       s4, #7
    s.addi       s19, s8, #7
    s.add        s21, s9, s7
    v.splat      v1, s19
    s.add        s9, s21, s20
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a3, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s2, s6, #8
    s.add        s11, s16, s9
    s.movz       s9, #8
    s.addi       s19, s8, #8
    s.add        s21, s2, s7
    v.splat      v3, s19
    s.add        s2, s21, s20
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a3, s10
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s10, s6, #9
    s.add        s12, s16, s2
    s.movz       s2, #9
    s.addi       s19, s8, #9
    s.add        s21, s10, s7
    v.splat      v2, s19
    s.add        s10, s21, s20
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a3, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s1, s6, #10
    s.add        s18, s16, s10
    s.movz       s10, #10
    s.addi       s19, s8, #10
    s.add        s21, s1, s7
    v.splat      v5, s19
    s.add        s1, s21, s20
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s4, s6, #11
    s.add        s17, s16, s1
    s.movz       s1, #11
    s.addi       s19, s8, #11
    s.add        s21, s4, s7
    v.splat      v1, s19
    s.add        s4, s21, s20
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a3, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s9, s6, #12
    s.add        s11, s16, s4
    s.movz       s4, #12
    s.addi       s19, s8, #12
    s.add        s21, s9, s7
    v.splat      v3, s19
    s.add        s9, s21, s20
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a3, s2
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s2, s6, #13
    s.add        s12, s16, s9
    s.movz       s9, #13
    s.addi       s19, s8, #13
    s.add        s21, s2, s7
    v.splat      v2, s19
    s.add        s2, s21, s20
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a3, s10
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s10, s6, #14
    s.add        s18, s16, s2
    s.movz       s2, #14
    s.addi       s19, s8, #14
    s.add        s21, s10, s7
    v.splat      v5, s19
    s.add        s10, s21, s20
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s1, s6, #15
    s.add        s17, s16, s10
    s.movz       s10, #15
    s.addi       s19, s8, #15
    s.add        s21, s1, s7
    v.splat      v1, s19
    s.add        s1, s21, s20
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a3, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.movz       s4, #0
    s.add        s11, s16, s1
    s.add        s1, s4, s5                      // the tile origin
    s.movz       s4, #0
    s.muli       s19, s5, #2
    v.splat      v3, s1
    v.splat      v6, s8
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a3, s9
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s1, #0
    v.add        v2, v0, v3
    s.add        s5, s1, s3                      // the tile origin
    s.add        s1, s7, s19
    v.splat      v3, s5
    s.muli       s5, s6, #1
    s.add        s9, s16, s1
    s.movz       s1, #1
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a3, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    v.cmp.lt     p1, v6, v4
    s.addi       s2, s8, #1
    s.add        s12, s5, s7
    v.splat      v5, s2
    s.add        s2, s12, s19
    s.muli       s5, s6, #2
    s.add        s12, s16, s2
    s.movz       s2, #2
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s10
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s10, s8, #2
    s.add        s17, s5, s7
    v.splat      v1, s10
    s.add        s5, s17, s19
    s.muli       s10, s6, #3
    s.add        s17, s16, s5
    s.movz       s5, #3
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a4, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s4, s8, #3
    s.add        s11, s10, s7
    v.splat      v2, s4
    s.add        s4, s11, s19
    s.muli       s10, s6, #4
    s.add        s11, s16, s4
    s.movz       s4, #4
    s.addi       s18, s8, #4
    @p3 v.st.h       [s9, #0], v3
    a.vread      v3, a4, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s10, s7
    v.splat      v3, s18
    s.add        s9, s1, s19
    s.muli       s1, s6, #5
    s.add        s10, s16, s9
    s.movz       s9, #5
    s.addi       s18, s8, #5
    s.add        s20, s1, s7
    @p4 v.st.h       [s12, #0], v1
    a.vread      v1, a4, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s18
    s.add        s1, s20, s19
    s.muli       s2, s6, #6
    s.add        s12, s16, s1
    s.movz       s1, #6
    s.addi       s18, s8, #6
    s.add        s20, s2, s7
    v.splat      v5, s18
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s2, s20, s19
    s.muli       s5, s6, #7
    s.add        s17, s16, s2
    s.movz       s2, #7
    s.addi       s18, s8, #7
    s.add        s20, s5, s7
    v.splat      v2, s18
    s.add        s5, s20, s19
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a4, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s6, #8
    s.add        s11, s16, s5
    s.movz       s5, #8
    s.addi       s18, s8, #8
    s.add        s20, s4, s7
    v.splat      v3, s18
    s.add        s4, s20, s19
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a4, s9
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s9, s6, #9
    s.add        s10, s16, s4
    s.movz       s4, #9
    s.addi       s18, s8, #9
    s.add        s20, s9, s7
    v.splat      v1, s18
    s.add        s9, s20, s19
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a4, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s1, s6, #10
    s.add        s12, s16, s9
    s.movz       s9, #10
    s.addi       s18, s8, #10
    s.add        s20, s1, s7
    v.splat      v5, s18
    s.add        s1, s20, s19
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s2, s6, #11
    s.add        s17, s16, s1
    s.movz       s1, #11
    s.addi       s18, s8, #11
    s.add        s20, s2, s7
    v.splat      v2, s18
    s.add        s2, s20, s19
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a4, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s5, s6, #12
    s.add        s11, s16, s2
    s.movz       s2, #12
    s.addi       s18, s8, #12
    s.add        s20, s5, s7
    v.splat      v3, s18
    s.add        s5, s20, s19
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a4, s4
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s4, s6, #13
    s.add        s10, s16, s5
    s.movz       s5, #13
    s.addi       s18, s8, #13
    s.add        s20, s4, s7
    v.splat      v1, s18
    s.add        s4, s20, s19
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a4, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s9, s6, #14
    s.add        s12, s16, s4
    s.movz       s4, #14
    s.addi       s18, s8, #14
    s.add        s20, s9, s7
    v.splat      v5, s18
    s.add        s9, s20, s19
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s6, #15
    s.add        s17, s16, s9
    s.movz       s9, #15
    s.addi       s18, s8, #15
    s.add        s20, s1, s7
    v.splat      v2, s18
    s.add        s1, s20, s19
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a4, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.movz       s2, #0
    s.add        s11, s16, s1
    s.add        s1, s2, s13                     // the tile origin
    s.movz       s2, #0
    s.muli       s18, s13, #2
    v.splat      v3, s1
    v.splat      v6, s8
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a4, s5
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s1, #0
    v.add        v1, v0, v3
    s.add        s5, s1, s3                      // the tile origin
    s.add        s1, s7, s18
    v.splat      v3, s5
    s.muli       s5, s6, #1
    s.add        s10, s16, s1
    s.movz       s1, #1
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a4, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    v.cmp.lt     p1, v6, v4
    s.addi       s4, s8, #1
    s.add        s12, s5, s7
    v.splat      v5, s4
    s.add        s4, s12, s18
    s.muli       s5, s6, #2
    s.add        s12, s16, s4
    s.movz       s4, #2
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s9
    v.cmp.lt     p2, v1, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s9, s8, #2
    s.add        s13, s5, s7
    v.splat      v2, s9
    s.add        s5, s13, s18
    s.muli       s9, s6, #3
    s.add        s13, s16, s5
    s.movz       s5, #3
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a5, s2
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s2, s8, #3
    s.add        s11, s9, s7
    v.splat      v1, s2
    s.add        s2, s11, s18
    s.muli       s9, s6, #4
    s.add        s11, s16, s2
    s.movz       s2, #4
    s.addi       s17, s8, #4
    @p3 v.st.h       [s10, #0], v3
    a.vread      v3, a5, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.add        s1, s9, s7
    v.splat      v3, s17
    s.add        s9, s1, s18
    s.muli       s1, s6, #5
    s.add        s10, s16, s9
    s.movz       s9, #5
    s.addi       s17, s8, #5
    s.add        s19, s1, s7
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a5, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s17
    s.add        s1, s19, s18
    s.muli       s4, s6, #6
    s.add        s12, s16, s1
    s.movz       s1, #6
    s.addi       s17, s8, #6
    s.add        s19, s4, s7
    v.splat      v5, s17
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s19, s18
    s.muli       s5, s6, #7
    s.add        s13, s16, s4
    s.movz       s4, #7
    s.addi       s17, s8, #7
    s.add        s19, s5, s7
    v.splat      v1, s17
    s.add        s5, s19, s18
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a5, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s2, s6, #8
    s.add        s11, s16, s5
    s.movz       s5, #8
    s.addi       s17, s8, #8
    s.add        s19, s2, s7
    v.splat      v3, s17
    s.add        s2, s19, s18
    @p3 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s9
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s9, s6, #9
    s.add        s10, s16, s2
    s.movz       s2, #9
    s.addi       s17, s8, #9
    s.add        s19, s9, s7
    v.splat      v2, s17
    s.add        s9, s19, s18
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a5, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s1, s6, #10
    s.add        s12, s16, s9
    s.movz       s9, #10
    s.addi       s17, s8, #10
    s.add        s19, s1, s7
    v.splat      v5, s17
    s.add        s1, s19, s18
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s4, s6, #11
    s.add        s13, s16, s1
    s.movz       s1, #11
    s.addi       s17, s8, #11
    s.add        s19, s4, s7
    v.splat      v1, s17
    s.add        s4, s19, s18
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a5, s5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s5, s6, #12
    s.add        s11, s16, s4
    s.movz       s4, #12
    s.addi       s17, s8, #12
    s.add        s19, s5, s7
    v.splat      v3, s17
    s.add        s5, s19, s18
    @p3 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s2
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s2, s6, #13
    s.add        s10, s16, s5
    s.movz       s5, #13
    s.addi       s17, s8, #13
    s.add        s19, s2, s7
    v.splat      v2, s17
    s.add        s2, s19, s18
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a5, s9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s9, s6, #14
    s.add        s12, s16, s2
    s.movz       s2, #14
    s.addi       s17, s8, #14
    s.add        s19, s9, s7
    v.splat      v5, s17
    s.add        s9, s19, s18
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s1, s6, #15
    s.add        s13, s16, s9
    s.movz       s9, #15
    s.addi       s17, s8, #15
    s.add        s19, s1, s7
    v.splat      v1, s17
    s.add        s1, s19, s18
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a5, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.movz       s4, #0
    s.add        s11, s16, s1
    s.add        s1, s4, s14                     // the tile origin
    s.movz       s4, #0
    s.muli       s17, s14, #2
    v.splat      v3, s1
    v.splat      v6, s8
    @p3 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s5
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s1, #0
    v.add        v2, v0, v3
    s.add        s5, s1, s3                      // the tile origin
    s.add        s1, s7, s17
    v.splat      v3, s5
    s.muli       s5, s6, #1
    s.add        s10, s16, s1
    s.movz       s1, #1
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a5, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    v.cmp.lt     p1, v6, v4
    s.addi       s2, s8, #1
    s.add        s12, s5, s7
    v.splat      v5, s2
    s.add        s2, s12, s17
    s.muli       s5, s6, #2
    s.add        s12, s16, s2
    s.movz       s2, #2
    @p3 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s9
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s9, s8, #2
    s.add        s13, s5, s7
    v.splat      v1, s9
    s.add        s5, s13, s17
    s.muli       s9, s6, #3
    s.add        s13, s16, s5
    s.movz       s5, #3
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a6, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s4, s8, #3
    s.add        s11, s9, s7
    v.splat      v2, s4
    s.add        s4, s11, s17
    s.muli       s9, s6, #4
    s.add        s11, s16, s4
    s.movz       s4, #4
    s.addi       s14, s8, #4
    @p3 v.st.h       [s10, #0], v3
    a.vread      v3, a6, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s9, s7
    v.splat      v3, s14
    s.add        s9, s1, s17
    s.muli       s1, s6, #5
    s.add        s10, s16, s9
    s.movz       s9, #5
    s.addi       s14, s8, #5
    s.add        s18, s1, s7
    @p4 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s14
    s.add        s1, s18, s17
    s.muli       s2, s6, #6
    s.add        s12, s16, s1
    s.movz       s1, #6
    s.addi       s14, s8, #6
    s.add        s18, s2, s7
    v.splat      v5, s14
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s2, s18, s17
    s.muli       s5, s6, #7
    s.add        s13, s16, s2
    s.movz       s2, #7
    s.addi       s14, s8, #7
    s.add        s18, s5, s7
    v.splat      v2, s14
    s.add        s5, s18, s17
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a6, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s6, #8
    s.add        s11, s16, s5
    s.movz       s5, #8
    s.addi       s14, s8, #8
    s.add        s18, s4, s7
    v.splat      v3, s14
    s.add        s4, s18, s17
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a6, s9
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s9, s6, #9
    s.add        s10, s16, s4
    s.movz       s4, #9
    s.addi       s14, s8, #9
    s.add        s18, s9, s7
    v.splat      v1, s14
    s.add        s9, s18, s17
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a6, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s1, s6, #10
    s.add        s12, s16, s9
    s.movz       s9, #10
    s.addi       s14, s8, #10
    s.add        s18, s1, s7
    v.splat      v5, s14
    s.add        s1, s18, s17
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s2, s6, #11
    s.add        s13, s16, s1
    s.movz       s1, #11
    s.addi       s14, s8, #11
    s.add        s18, s2, s7
    v.splat      v2, s14
    s.add        s2, s18, s17
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a6, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s5, s6, #12
    s.add        s11, s16, s2
    s.movz       s2, #12
    s.addi       s14, s8, #12
    s.add        s18, s5, s7
    v.splat      v3, s14
    s.add        s5, s18, s17
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a6, s4
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s4, s6, #13
    s.add        s10, s16, s5
    s.movz       s5, #13
    s.addi       s14, s8, #13
    s.add        s18, s4, s7
    v.splat      v1, s14
    s.add        s4, s18, s17
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a6, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s9, s6, #14
    s.add        s12, s16, s4
    s.movz       s4, #14
    s.addi       s14, s8, #14
    s.add        s18, s9, s7
    v.splat      v5, s14
    s.add        s9, s18, s17
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s6, #15
    s.add        s13, s16, s9
    s.movz       s9, #15
    s.addi       s14, s8, #15
    s.add        s18, s1, s7
    v.splat      v2, s14
    s.add        s1, s18, s17
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a6, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.movz       s2, #0
    s.add        s11, s16, s1
    s.add        s1, s2, s15                     // the tile origin
    s.movz       s2, #0
    s.muli       s14, s15, #2
    v.splat      v3, s1
    v.splat      v6, s8
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a6, s5
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s1, #0
    v.add        v1, v0, v3
    s.add        s5, s1, s3                      // the tile origin
    s.add        s1, s7, s14
    v.splat      v0, s5
    s.muli       s3, s6, #1
    s.add        s5, s16, s1
    s.movz       s1, #1
    @p4 v.st.h       [s12, #0], v5
    a.vread      v3, a6, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    v.cmp.lt     p1, v6, v4
    s.addi       s4, s8, #1
    s.add        s10, s3, s7
    v.splat      v3, s4
    s.add        s3, s10, s14
    s.muli       s4, s6, #2
    s.add        s10, s16, s3
    s.movz       s3, #2
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s9
    v.cmp.lt     p2, v1, v0
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v2
    s.addi       s9, s8, #2
    s.add        s12, s4, s7
    v.splat      v1, s9
    s.add        s4, s12, s14
    s.muli       s9, s6, #3
    s.add        s12, s16, s4
    s.movz       s4, #3
    @p4 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s2
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.addi       s2, s8, #3
    s.add        s11, s9, s7
    v.splat      v0, s2
    s.add        s2, s11, s14
    s.muli       s9, s6, #4
    s.add        s11, s16, s2
    s.movz       s2, #4
    s.addi       s13, s8, #4
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a7, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s1, s9, s7
    v.splat      v2, s13
    s.add        s5, s1, s14
    s.muli       s1, s6, #5
    s.add        s9, s16, s5
    s.movz       s5, #5
    s.addi       s13, s8, #5
    s.add        s15, s1, s7
    @p4 v.st.h       [s10, #0], v1
    a.vread      v1, a7, s3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    v.splat      v1, s13
    s.add        s1, s15, s14
    s.muli       s3, s6, #6
    s.add        s10, s16, s1
    s.movz       s1, #6
    s.addi       s13, s8, #6
    s.add        s15, s3, s7
    v.splat      v3, s13
    @p3 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s4
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.add        s3, s15, s14
    s.muli       s4, s6, #7
    s.add        s12, s16, s3
    s.movz       s3, #7
    s.addi       s13, s8, #7
    s.add        s15, s4, s7
    v.splat      v0, s13
    s.add        s4, s15, s14
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a7, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s2, s6, #8
    s.add        s11, s16, s4
    s.movz       s4, #8
    s.addi       s13, s8, #8
    s.add        s15, s2, s7
    v.splat      v2, s13
    s.add        s2, s15, s14
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a7, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s5, s6, #9
    s.add        s9, s16, s2
    s.movz       s2, #9
    s.addi       s13, s8, #9
    s.add        s15, s5, s7
    v.splat      v1, s13
    s.add        s5, s15, s14
    @p4 v.st.h       [s10, #0], v3
    a.vread      v3, a7, s1
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v3
    s.muli       s1, s6, #10
    s.add        s10, s16, s5
    s.movz       s5, #10
    s.addi       s13, s8, #10
    s.add        s15, s1, s7
    v.splat      v3, s13
    s.add        s1, s15, s14
    @p3 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s3, s6, #11
    s.add        s12, s16, s1
    s.movz       s1, #11
    s.addi       s13, s8, #11
    s.add        s15, s3, s7
    v.splat      v0, s13
    s.add        s3, s15, s14
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a7, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s4, s6, #12
    s.add        s11, s16, s3
    s.movz       s3, #12
    s.addi       s13, s8, #12
    s.add        s15, s4, s7
    v.splat      v2, s13
    s.add        s4, s15, s14
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a7, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s2, s6, #13
    s.add        s9, s16, s4
    s.movz       s4, #13
    s.addi       s13, s8, #13
    s.add        s15, s2, s7
    v.splat      v1, s13
    s.add        s2, s15, s14
    @p4 v.st.h       [s10, #0], v3
    a.vread      v3, a7, s5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v3
    s.muli       s5, s6, #14
    s.add        s10, s16, s2
    s.movz       s2, #14
    s.addi       s13, s8, #14
    s.add        s15, s5, s7
    v.splat      v3, s13
    s.add        s5, s15, s14
    @p3 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s1, s6, #15
    s.add        s6, s16, s5
    s.movz       s5, #15
    s.addi       s12, s8, #15
    s.add        s8, s1, s7
    v.splat      v0, s12
    s.add        s1, s8, s14
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a7, s3
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s3, s16, s1
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a7, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    @p4 v.st.h       [s10, #0], v2
    a.vread      v1, a7, s2
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a7, s5
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s3, #0], v1
    exit
    exit
