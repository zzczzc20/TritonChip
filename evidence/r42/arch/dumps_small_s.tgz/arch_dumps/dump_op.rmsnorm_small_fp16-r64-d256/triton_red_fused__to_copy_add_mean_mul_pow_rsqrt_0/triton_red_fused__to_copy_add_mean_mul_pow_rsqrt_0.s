    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #256
    s.movz       s5, #64
    s.movz       s6, #1
    s.rdspecial  s6, role_id
    s.rdspecial  s7, npid.x
    s.ld.d       s8, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s9, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
__rctx_program:
    s.mul        s1, s6, s4
    s.addi       s10, s2, #0
    v.movi       v0, #0
    v.movi       v1, #0
    v.movi       v2, #0
    s.add        s11, s10, s1
    v.movi       v3, #0
    v.movi       v4, #0
    s.shli       s12, s11, #1                    // element offset -> bytes (x2)
    v.mov        v1, v0
    v.mov        v2, v0
    v.mov        v3, v0
    v.mov        v4, v0
    s.add        s11, s3, s12                    // &in_ptr0[...]
for_1:
    v.ld.h       v0, [s11, #0]
    v.ld.h       v5, [s11, #32]
    vf.cvt.f16.f32 v6, v0
    vf.mul       v0, v6, v6
    vf.add       v1, v1, v0
    v.ld.h       v0, [s11, #64]
    vf.cvt.f16.f32 v6, v5
    vf.mul       v5, v6, v6
    vf.add       v2, v2, v5
    v.ld.h       v5, [s11, #96]
    vf.cvt.f16.f32 v6, v0
    vf.mul       v0, v6, v6
    vf.add       v3, v3, v0
    vf.cvt.f16.f32 v0, v5
    vf.mul       v5, v0, v0
    vf.add       v4, v4, v5
    s.addi       s11, s11, #128                  // the next iteration's address
    s.add        s10, s10, s5
    s.cmp.lt     s12, s10, s4
    br.nz        s12, for_1
endfor_2:
    .li       s10, #1132462080
    v.splat      v0, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s10, #1065353216
    v.splat      v5, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.add.b v6, v1
    v.rcp.approx v1, v0                          // ISA 8.8: <= 2**-22 relative
    vf.reduce.add.b v7, v2
    vf.reduce.add.b v2, v3
    vf.reduce.add.b v3, v4
    vf.add       v4, v6, v7
    v.movi       v6, #0
    vf.add       v7, v2, v3
    .li       s10, #925353388
    v.splat      v2, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s10, #1077936128
    v.splat      v3, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.addi       s10, s2, #0
    s.movz       s11, #1
    vf.add       v8, v4, v7
    .li       s11, #3204448256
    v.splat      v4, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s11, s10, s1
    s.add        s12, s10, s1
    s.shli       s1, s11, #1                     // element offset -> bytes (x2)
    vf.add       v7, v8, v6
    s.shli       s11, s10, #1                    // element offset -> bytes (x2)
    s.shli       s13, s12, #1                    // element offset -> bytes (x2)
    s.add        s12, s3, s1                     // &in_ptr0[...]
    s.add        s1, s8, s11                     // &in_ptr1[...]
    s.add        s11, s9, s13                    // &out_ptr1[...]
    vf.fms       v6, v0, v1, v5
    vf.fms       v0, v1, v6, v1
    vf.neg       v5, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v0, v5, v1
    vf.mul       v1, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v0, v1, v2
    v.rsqrt.approx v1, v0                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v2, v1, v1
    vf.mul       v5, v1, v4
    vf.fms       v4, v0, v2, v3
    vf.mul       v0, v5, v4                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v2, v0, v1
    v.extract    s13, v2, #0
    v.splat      v0, s13
for_3:
    v.ld.h       v1, [s12, #0]
    v.ld.h       v2, [s12, #32]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    v.ld.h       v3, [s12, #64]
    vf.cvt.f16.f32 v4, v2
    vf.mul       v2, v4, v0
    v.ld.h       v4, [s12, #96]
    vf.cvt.f16.f32 v5, v3
    vf.mul       v3, v5, v0
    v.ld.h       v5, [s1, #0]
    vf.cvt.f16.f32 v6, v4
    vf.mul       v4, v6, v0
    v.ld.h       v6, [s1, #32]
    vf.cvt.f16.f32 v7, v5
    vf.mul       v5, v1, v7
    vf.cvt.f32.f16 v1, v5
    v.ld.h       v5, [s1, #64]
    vf.cvt.f16.f32 v7, v6
    vf.mul       v6, v2, v7
    vf.cvt.f32.f16 v2, v6
    v.ld.h       v6, [s1, #96]
    vf.cvt.f16.f32 v7, v5
    vf.mul       v5, v3, v7
    vf.cvt.f32.f16 v3, v5
    vf.cvt.f16.f32 v5, v6
    v.st.h       [s11, #0], v1
    vf.mul       v1, v4, v5
    vf.cvt.f32.f16 v4, v1
    v.st.h       [s11, #32], v2
    v.st.h       [s11, #64], v3
    v.st.h       [s11, #96], v4
    s.addi       s12, s12, #128                  // the next iteration's address
    s.addi       s1, s1, #128                    // the next iteration's address
    s.addi       s11, s11, #128                  // the next iteration's address
    s.add        s10, s10, s5
    s.cmp.lt     s13, s10, s4
    br.nz        s13, for_3
endfor_4:
__rctx_next:
    s.addi       s1, s6, #4                      // the next program of this context: + 4
    s.cmp.lt     s10, s1, s7
    s.mov        s6, s1
    br.nz        s10, __rctx_program
    exit
