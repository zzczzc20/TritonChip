# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /tmp/torchinductor_zzhouch/gr/cgrp7hpjcpcgnviizvmxl2rp62vcc2s3y4feqxsf6hdoxu22oqb7.py
# Topologically Sorted Source Nodes: [x, rms_norm], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   rms_norm => add, convert_element_type, convert_element_type_1, mean, mul, mul_1, pow_1, rsqrt
#   x => embedding
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 16][16, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[256, 64][64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf0 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0" = PlaceHolder[target=buf0]
#   %arg4_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg4_1]
#   %embedding : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [2], True), kwargs = {})
#   %add : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 9.999999747378752e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg4_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.float16), kwargs = {})
#   return %buf0,%convert_element_type_1
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 128, 'r0_': 4224}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.device_assert((0 <= tmp0) & (tmp0 < 256), "index out of bounds: 0 <= tmp0 < 256")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 64*tmp0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp17 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 256), "index out of bounds: 0 <= tmp0 < 256")
        tmp9 = tl.load(in_ptr1 + (r0_1 + 64*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tl.full([1], 64.0, tl.float32)
        tmp12 = (tmp6 / tmp11)
        tmp13 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp14 = tmp12 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp10 * tmp15
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 * tmp18
        tmp20 = tmp19.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 64*x0), tmp20, r0_mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/to/ctogw6lpcpukhlbyn2csvrkmciknlt7owk45p2aqujipj3y7nsmr.py
# Topologically Sorted Source Nodes: [x, rms_norm, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear => mm, permute, view
#   rms_norm => add, convert_element_type, convert_element_type_1, mean, mul, mul_1, pow_1, rsqrt
#   x => embedding
# Graph fragment:
#   %convert_element_type_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_1]
#   %arg5_1 : Tensor "f16[64, 64][64, 1]tnca:0" = PlaceHolder[target=arg5_1]
#   %embedding : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [2], True), kwargs = {})
#   %add : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 9.999999747378752e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg4_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.float16), kwargs = {})
#   %view : Tensor "f16[16, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [16, 64]), kwargs = {})
#   %permute : Tensor "f16[64, 64][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg5_1, [1, 0]), kwargs = {})
#   %mm : Tensor "f16[16, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view, %permute), kwargs = {})
#   return %mm
triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1 = async_compile.triton('triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1', 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 16
    N = 64
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 64
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 64*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/yh/cyhn5torzy5nc77rxjb6iwldjzufrcy6ubxcroqmnwg6k4khhpa6.py
# Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_1 => mm_1, permute_2, view_3
# Graph fragment:
#   %convert_element_type_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_1]
#   %arg6_1 : Tensor "f16[32, 64][64, 1]tnca:0" = PlaceHolder[target=arg6_1]
#   %view_3 : Tensor "f16[16, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [16, 64]), kwargs = {})
#   %permute_2 : Tensor "f16[64, 32][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg6_1, [1, 0]), kwargs = {})
#   %mm_1 : Tensor "f16[16, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_3, %permute_2), kwargs = {})
#   return %mm_1
triton_tem_fused_mm_t_view_2 = async_compile.triton('triton_tem_fused_mm_t_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_2', 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_2(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 16
    N = 32
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 64
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 32*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 32*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/at/cat52lby5l4pjpnmcnhpqcsp65g7ia6m6c76kxl6ajs7umzxad5i.py
# Topologically Sorted Source Nodes: [linear, view, q, chunk, neg], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk => split
#   linear => view_1
#   neg => neg
#   q => permute_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=mm]
#   %view_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 16, 64]), kwargs = {})
#   %view_2 : Tensor "f16[1, 16, 4, 16][1024, 64, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 16, 4, 16]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_1, 8, -1), kwargs = {})
#   %neg : Tensor "f16[1, 4, 16, 8][512, 8, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   return %neg
triton_poi_fused__unsafe_view_neg_split_transpose_view_3 = async_compile.triton('triton_poi_fused__unsafe_view_neg_split_transpose_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_neg_split_transpose_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3072}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_neg_split_transpose_view_3(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8)
    x1 = ((xindex // 8) % 16)
    x2 = xindex // 128
    x3 = xindex // 8
    tmp0 = tl.load(in_ptr0 + (8 + x0 + 16*x2 + 64*x1), xmask).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 16*x3), tmp1, xmask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/4v/c4vus5aw5fmp7ivbcez5lxd2eqfrff6lmuxw4osjjslanvucnyj6.py
# Topologically Sorted Source Nodes: [linear, view, q, chunk, neg, cat], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat => cat
#   chunk => split
#   linear => view_1
#   neg => neg
#   q => permute_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=mm]
#   %view_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 16, 64]), kwargs = {})
#   %view_2 : Tensor "f16[1, 16, 4, 16][1024, 64, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 16, 4, 16]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_1, 8, -1), kwargs = {})
#   %neg : Tensor "f16[1, 4, 16, 8][512, 8, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   %cat : Tensor "f16[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %getitem], -1), kwargs = {})
#   return %buf5
triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4 = async_compile.triton('triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3072}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8)
    x1 = ((xindex // 8) % 16)
    x2 = xindex // 128
    x3 = xindex // 8
    tmp0 = tl.load(in_ptr0 + (x0 + 16*x2 + 64*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 16*x3), tmp0, xmask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/4m/c4mn5a7fho2puexhhoo6ethvji7p6q6wf3rxkte62kmr2plqbq7t.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk_1 => split_1
#   k => permute_3
#   linear_1 => view_4
#   neg_1 => neg_1
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[16, 32][32, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %view_4 : Tensor "f16[1, 16, 32][512, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 16, 32]), kwargs = {})
#   %view_5 : Tensor "f16[1, 16, 2, 16][512, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 16, 2, 16]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 2, 16, 16][512, 16, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_3, 8, -1), kwargs = {})
#   %neg_1 : Tensor "f16[1, 2, 16, 8][256, 8, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_3,), kwargs = {})
#   return %neg_1
triton_poi_fused__unsafe_view_neg_split_transpose_view_5 = async_compile.triton('triton_poi_fused__unsafe_view_neg_split_transpose_view_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_neg_split_transpose_view_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1536}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_neg_split_transpose_view_5(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8)
    x1 = ((xindex // 8) % 16)
    x2 = xindex // 128
    x3 = xindex // 8
    tmp0 = tl.load(in_ptr0 + (8 + x0 + 16*x2 + 32*x1), xmask).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 16*x3), tmp1, xmask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/6d/c6dmyw47wcoclyqyx2hixqoe75mhtawbtktpbndrkmmydqpfsu4s.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1, cat_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat_1 => cat_1
#   chunk_1 => split_1
#   k => permute_3
#   linear_1 => view_4
#   neg_1 => neg_1
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[16, 32][32, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %view_4 : Tensor "f16[1, 16, 32][512, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 16, 32]), kwargs = {})
#   %view_5 : Tensor "f16[1, 16, 2, 16][512, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 16, 2, 16]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 2, 16, 16][512, 16, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_3, 8, -1), kwargs = {})
#   %neg_1 : Tensor "f16[1, 2, 16, 8][256, 8, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_3,), kwargs = {})
#   %cat_1 : Tensor "f16[1, 2, 16, 16][512, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %getitem_2], -1), kwargs = {})
#   return %buf8
triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6 = async_compile.triton('triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1536}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8)
    x1 = ((xindex // 8) % 16)
    x2 = xindex // 128
    x3 = xindex // 8
    tmp0 = tl.load(in_ptr0 + (x0 + 16*x2 + 32*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 16*x3), tmp0, xmask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/fo/cfo5tnhwairycjhwnjlzymwqmqqirbuznmazrij7mtbozbyzonmy.py
# Topologically Sorted Source Nodes: [linear, view, q, linear_1, view_1, k, mul, mul_1, q_1, o, mul_2, mul_3, k_1, getitem_4, expand, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   expand => expand
#   getitem_4 => unsqueeze
#   k => permute_3
#   k_1 => add_2
#   k_2 => clone, view_9
#   linear => view_1
#   linear_1 => view_4
#   mul => mul_2
#   mul_1 => mul_3
#   mul_2 => mul_4
#   mul_3 => mul_5
#   o => convert_element_type_8, convert_element_type_9, mul_6, mul_7, permute_6
#   q => permute_1
#   q_1 => add_1
#   view => view_2
#   view_1 => view_5
# Graph fragment:
#   %mm : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=mm]
#   %arg2_1 : Tensor "f16[16, 16][16, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %cat : Tensor "f16[1, 4, 16, 16][1024, 256, 16, 1]tnca:0" = PlaceHolder[target=cat]
#   %arg3_1 : Tensor "f16[16, 16][16, 1]tnca:0" = PlaceHolder[target=arg3_1]
#   %mm_1 : Tensor "f16[16, 32][32, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %cat_1 : Tensor "f16[1, 2, 16, 16][512, 256, 16, 1]tnca:0" = PlaceHolder[target=cat_1]
#   %view_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 16, 64]), kwargs = {})
#   %view_2 : Tensor "f16[1, 16, 4, 16][1024, 64, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 16, 4, 16]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %view_4 : Tensor "f16[1, 16, 32][512, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 16, 32]), kwargs = {})
#   %view_5 : Tensor "f16[1, 16, 2, 16][512, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 16, 2, 16]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 2, 16, 16][512, 16, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %mul_2 : Tensor "f16[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_1, %arg2_1), kwargs = {})
#   %mul_3 : Tensor "f16[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %arg3_1), kwargs = {})
#   %add_1 : Tensor "f16[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_2, %mul_3), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_1, torch.float32), kwargs = {})
#   %mul_6 : Tensor "f32[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_8, 0.5), kwargs = {})
#   %mul_4 : Tensor "f16[1, 2, 16, 16][512, 16, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, %arg2_1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 2, 16, 16][512, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %arg3_1), kwargs = {})
#   %add_2 : Tensor "f16[1, 2, 16, 16][512, 16, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %unsqueeze : Tensor "f16[1, 2, 1, 16, 16][512, 16, 512, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%add_2, 2), kwargs = {})
#   %expand : Tensor "f16[1, 2, 2, 16, 16][512, 16, 0, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze, [1, 2, 2, 16, 16]), kwargs = {})
#   %clone : Tensor "f16[1, 2, 2, 16, 16][1024, 512, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view_9 : Tensor "f16[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 4, 16, 16]), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_9, torch.float32), kwargs = {})
#   %permute_6 : Tensor "f32[1, 4, 16, 16][1024, 256, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_9, [0, 1, 3, 2]), kwargs = {})
#   %mul_7 : Tensor "f32[1, 4, 16, 16][1024, 256, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_6, 0.5), kwargs = {})
#   return %expand_2,%expand_3
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'y': 64, 'x': 16}, tile_hint=TileHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'in_ptr5': '*fp16', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'y': 8192, 'x': 15360}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, out_ptr1, ynumel, xnumel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 64
    xnumel = 16
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :]
    xmask = xindex < xnumel
    x2 = xindex
    y0 = (yindex % 16)
    y1 = yindex // 16
    y3 = yindex
    tmp0 = tl.load(in_ptr0 + (x2 + 16*y1 + 64*y0), xmask & ymask).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (x2 + 16*y0), xmask & ymask, eviction_policy='evict_last').to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x2 + 16*y3), xmask & ymask).to(tl.float32)
    tmp4 = tl.load(in_ptr3 + (x2 + 16*y0), xmask & ymask, eviction_policy='evict_last').to(tl.float32)
    tmp10 = tl.load(in_ptr4 + (x2 + 16*(y1 // 2) + 32*y0), xmask & ymask).to(tl.float32)
    tmp12 = tl.load(in_ptr5 + (x2 + 16*y0 + 256*(y1 // 2)), xmask & ymask).to(tl.float32)
    tmp2 = tmp0 * tmp1
    tmp5 = tmp3 * tmp4
    tmp6 = tmp2 + tmp5
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tl.full([1, 1], 0.5, tl.float32)
    tmp9 = tmp7 * tmp8
    tmp11 = tmp10 * tmp1
    tmp13 = tmp12 * tmp4
    tmp14 = tmp11 + tmp13
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tmp15 * tmp8
    tl.store(out_ptr0 + (x2 + 16*y3), tmp9, xmask & ymask)
    tl.store(out_ptr1 + (y0 + 16*x2 + 256*y1), tmp16, xmask & ymask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/sb/csbnrpb3uvw7lbuxqurdijjeldzcofqjnfyeangpzdn6q5lm6dez.py
# Topologically Sorted Source Nodes: [linear, view, q, linear_1, view_1, k, mul, mul_1, q_1, o, mul_2, mul_3, k_1, getitem_4, expand, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   expand => expand
#   getitem_4 => unsqueeze
#   k => permute_3
#   k_1 => add_2
#   k_2 => clone, view_9
#   linear => view_1
#   linear_1 => view_4
#   mul => mul_2
#   mul_1 => mul_3
#   mul_2 => mul_4
#   mul_3 => mul_5
#   o => bmm, convert_element_type_8, convert_element_type_9, mul_6, mul_7, permute_6, view_11, view_12
#   q => permute_1
#   q_1 => add_1
#   view => view_2
#   view_1 => view_5
# Graph fragment:
#   %expand_2 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0" = PlaceHolder[target=expand_2]
#   %expand_3 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0" = PlaceHolder[target=expand_3]
#   %view_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 16, 64]), kwargs = {})
#   %view_2 : Tensor "f16[1, 16, 4, 16][1024, 64, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 16, 4, 16]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %view_4 : Tensor "f16[1, 16, 32][512, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 16, 32]), kwargs = {})
#   %view_5 : Tensor "f16[1, 16, 2, 16][512, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 16, 2, 16]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 2, 16, 16][512, 16, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %mul_2 : Tensor "f16[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_1, %arg2_1), kwargs = {})
#   %mul_3 : Tensor "f16[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %arg3_1), kwargs = {})
#   %add_1 : Tensor "f16[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_2, %mul_3), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_1, torch.float32), kwargs = {})
#   %mul_6 : Tensor "f32[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_8, 0.5), kwargs = {})
#   %view_11 : Tensor "f32[4, 16, 16][16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [4, 16, 16]), kwargs = {})
#   %mul_4 : Tensor "f16[1, 2, 16, 16][512, 16, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, %arg2_1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 2, 16, 16][512, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %arg3_1), kwargs = {})
#   %add_2 : Tensor "f16[1, 2, 16, 16][512, 16, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %unsqueeze : Tensor "f16[1, 2, 1, 16, 16][512, 16, 512, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%add_2, 2), kwargs = {})
#   %expand : Tensor "f16[1, 2, 2, 16, 16][512, 16, 0, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze, [1, 2, 2, 16, 16]), kwargs = {})
#   %clone : Tensor "f16[1, 2, 2, 16, 16][1024, 512, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view_9 : Tensor "f16[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 4, 16, 16]), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_9, torch.float32), kwargs = {})
#   %permute_6 : Tensor "f32[1, 4, 16, 16][1024, 256, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_9, [0, 1, 3, 2]), kwargs = {})
#   %mul_7 : Tensor "f32[1, 4, 16, 16][1024, 256, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_6, 0.5), kwargs = {})
#   %view_12 : Tensor "f32[4, 16, 16][256, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_3, [4, 16, 16]), kwargs = {})
#   %bmm : Tensor "f32[4, 16, 16][256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_11, %view_12), kwargs = {})
#   return %bmm
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8', 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 16
    N = 16
    K = 16
    BATCH = 4

    stride_aq = 256
    stride_am = 16
    stride_ak = 1

    stride_bq = 256
    stride_bk = 16
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 16*idx_m + 256*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/pe/cpelpxeoinp73uk677vujuk3pngbeljyw4t2ufenf7k25qdaswll.py
# Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   o => add_3, amax, any_1, div, eq, exp, full_default, full_default_1, full_default_2, full_default_3, iota, iota_1, le, logical_and, logical_not, logical_not_1, sub, sub_1, sum_1, unsqueeze_2, unsqueeze_3, view_13, where, where_1
# Graph fragment:
#   %bmm : Tensor "f32[4, 16, 16][256, 16, 1]tnca:0" = PlaceHolder[target=bmm]
#   %amax : Tensor "f32[1, 4, 16, 1][64, 16, 1, 64]tnca:0" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0" = PlaceHolder[target=exp]
#   %any_1 : Tensor "b8[1, 4, 16, 1][64, 16, 1, 64]tnca:0" = PlaceHolder[target=any_1]
#   %sum_1 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 64]tnca:0" = PlaceHolder[target=sum_1]
#   %view_13 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 4, 16, 16]), kwargs = {})
#   %iota : Tensor "i64[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (16,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze_2 : Tensor "i64[1, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota, -2), kwargs = {})
#   %iota_1 : Tensor "i64[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (16,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze_3 : Tensor "i64[16, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota_1, -1), kwargs = {})
#   %sub : Tensor "i64[16, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%unsqueeze_2, %unsqueeze_3), kwargs = {})
#   %le : Tensor "b8[16, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.le.Scalar](args = (%sub, 0), kwargs = {})
#   %full_default : Tensor "b8[16, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([16, 16], True), kwargs = {dtype: torch.bool, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %logical_and : Tensor "b8[16, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_and.default](args = (%le, %full_default), kwargs = {})
#   %full_default_2 : Tensor "f32[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], 0.0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %full_default_1 : Tensor "f32[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %where : Tensor "f32[16, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_and, %full_default_2, %full_default_1), kwargs = {})
#   %add_3 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%view_13, %where), kwargs = {})
#   %eq : Tensor "b8[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%add_3, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq,), kwargs = {})
#   %any_1 : Tensor "b8[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   %logical_not_1 : Tensor "b8[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_3 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 4, 16, 16], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %amax : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%add_3, [-1], True), kwargs = {})
#   %sub_1 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%add_3, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub_1,), kwargs = {})
#   %sum_1 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   %div : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_1 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_3, %div), kwargs = {})
#   return %any_1,%amax,%exp,%sum_1,%expand_4
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 16},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 2, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 12288}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9(in_out_ptr0, in_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 64
    XBLOCK: tl.constexpr = 1
    r0_numel = 16
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x3 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[64, 16], strides=[16, 1], block_shape=[XBLOCK, R0_BLOCK])
    x0 = (xindex % 16)
    _tmp16 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp20 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp1 = (r0_2 + ((-1)*x0)).to(tl.int64)
        tmp2 = (tmp1).to(tl.int64)
        tmp3 = tl.full([1], 0, tl.int64)
        tmp4 = tmp2 <= tmp3
        tmp5 = tl.full([1], True, tl.int1)
        tmp6 = tmp4 & tmp5
        tmp7 = tl.full([1], 0.0, tl.float32)
        tmp8 = tl.full([1], float("-inf"), tl.float32)
        tmp9 = tl.where(tmp6, tmp7, tmp8)
        tmp10 = tmp0 + tmp9
        tmp11 = tmp10 == tmp8
        tmp12 = tmp11 == 0
        tmp13 = tmp12.to(tl.int64)
        tmp14 = (tmp13 != 0)
        tmp15 = tl.broadcast_to(tmp14, [R0_BLOCK])
        tmp17 = _tmp16 | tmp15
        _tmp16 = tl.where(r0_mask, tmp17, _tmp16)
        tmp19 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp21 = tl.maximum(_tmp20, tmp19, tl.PropagateNan.ALL)
        _tmp20 = tl.where(r0_mask, tmp21, _tmp20)
    tmp18 = _tmp16.to(tl.int8)
    tmp16 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp18, 0))
    tmp20 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp20, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[64, 16], strides=[16, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp36 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp22 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp23 = (r0_2 + ((-1)*x0)).to(tl.int64)
        tmp24 = (tmp23).to(tl.int64)
        tmp25 = tl.full([1], 0, tl.int64)
        tmp26 = tmp24 <= tmp25
        tmp27 = tl.full([1], True, tl.int1)
        tmp28 = tmp26 & tmp27
        tmp29 = tl.full([1], 0.0, tl.float32)
        tmp30 = tl.full([1], float("-inf"), tl.float32)
        tmp31 = tl.where(tmp28, tmp29, tmp30)
        tmp32 = tmp22 + tmp31
        tmp33 = tmp32 - tmp20
        tmp34 = libdevice.exp(tmp33)
        tmp35 = tl.broadcast_to(tmp34, [R0_BLOCK])
        tmp37 = _tmp36 + tmp35
        _tmp36 = tl.where(r0_mask, tmp37, _tmp36)
        tl.store(in_out_ptr0 + (r0_2 + 16*x3), tmp34, r0_mask)
    tmp36 = triton_helpers.promote_to_tensor(tl.sum(_tmp36, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[64, 16], strides=[16, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tl.debug_barrier()
        tmp39 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp38 = tmp16 == 0
        tmp40 = (tmp39 / tmp36)
        tmp41 = tl.full([1], 0.0, tl.float32)
        tmp42 = tl.where(tmp38, tmp41, tmp40)
        tl.store(in_out_ptr0 + (r0_2 + 16*x3), tmp42, r0_mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/ps/cpsbhotwpkescgagwylwyzv4ee74yoahfaijfae3bafcvqyorhdw.py
# Topologically Sorted Source Nodes: [linear_2, view_2, v, getitem_5, expand_1, v_1, o], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   expand_1 => expand_1
#   getitem_5 => unsqueeze_1
#   linear_2 => view_7
#   o => convert_element_type_10
#   v => permute_5
#   v_1 => clone_1, view_10
#   view_2 => view_8
# Graph fragment:
#   %mm_2 : Tensor "f16[16, 32][32, 1]tnca:0" = PlaceHolder[target=mm_2]
#   %view_7 : Tensor "f16[1, 16, 32][512, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 16, 32]), kwargs = {})
#   %view_8 : Tensor "f16[1, 16, 2, 16][512, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_7, [1, 16, 2, 16]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 2, 16, 16][512, 16, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze_1 : Tensor "f16[1, 2, 1, 16, 16][512, 16, 512, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute_5, 2), kwargs = {})
#   %expand_1 : Tensor "f16[1, 2, 2, 16, 16][512, 16, 0, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 2, 2, 16, 16]), kwargs = {})
#   %clone_1 : Tensor "f16[1, 2, 2, 16, 16][1024, 512, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_10 : Tensor "f16[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_1, [1, 4, 16, 16]), kwargs = {})
#   %convert_element_type_10 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   return %expand_5
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 9216}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 16)
    x1 = ((xindex // 16) % 16)
    x2 = xindex // 256
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 16*(x2 // 2) + 32*x1), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp1, xmask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/pf/cpfx2tivbbv3bt6bd6qw2agil7u2mdlxw2utgcde46pznlacjjwm.py
# Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   o => clone_2, convert_element_type_12, permute_7, view_16
# Graph fragment:
#   %bmm_1 : Tensor "f32[4, 16, 16][256, 16, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %view_16 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 4, 16, 16]), kwargs = {})
#   %convert_element_type_12 : Tensor "f16[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_16, torch.float16), kwargs = {})
#   %permute_7 : Tensor "f16[16, 1, 4, 16][16, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_12, [2, 0, 1, 3]), kwargs = {})
#   %clone_2 : Tensor "f16[16, 1, 4, 16][64, 64, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute_7,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_2
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_11 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 8192}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_11(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 16)
    x1 = ((xindex // 16) % 4)
    x2 = xindex // 64
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 16*x2 + 256*x1), xmask)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp1, xmask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/fg/cfg22bbn6yp53zgqmrjlz26nhwlgcvsx5oegn6qrf4tm4fzyaijk.py
# Topologically Sorted Source Nodes: [x, h, x_1, y], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   x => embedding
#   x_1 => add_4
#   y => add_5, convert_element_type_15, convert_element_type_16, mean_1, mul_8, mul_9, pow_2, rsqrt_1
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 16][16, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[256, 64][64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %buf23 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0" = PlaceHolder[target=buf23]
#   %arg9_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg9_1]
#   %embedding : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 16, 64]), kwargs = {})
#   %add_4 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %convert_element_type_15 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_4, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_15, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [2], True), kwargs = {})
#   %add_5 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_1, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_5,), kwargs = {})
#   %mul_8 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_15, %rsqrt_1), kwargs = {})
#   %mul_9 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_8, %arg9_1), kwargs = {})
#   %convert_element_type_16 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_9, torch.float16), kwargs = {})
#   return %buf23,%convert_element_type_16
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_12 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 128, 'r0_': 6272}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_12(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 256), "index out of bounds: 0 <= tmp0 < 256")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 64*tmp0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp12 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp21 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 256), "index out of bounds: 0 <= tmp0 < 256")
        tmp11 = tl.load(in_ptr1 + (r0_1 + 64*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp13 = tmp11 + tmp12
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tl.full([1], 64.0, tl.float32)
        tmp16 = (tmp8 / tmp15)
        tmp17 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp14 * tmp19
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp20 * tmp22
        tmp24 = tmp23.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 64*x0), tmp24, r0_mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/qt/cqtkivvbocrxnbfdmmqwizyh5yqsr3fnw5wn3v2jm3gbanqq6a44.py
# Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_4 => mm_4, permute_11, view_20
# Graph fragment:
#   %convert_element_type_16 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_16]
#   %arg10_1 : Tensor "f16[128, 64][64, 1]tnca:0" = PlaceHolder[target=arg10_1]
#   %view_20 : Tensor "f16[16, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_16, [16, 64]), kwargs = {})
#   %permute_11 : Tensor "f16[64, 128][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg10_1, [1, 0]), kwargs = {})
#   %mm_4 : Tensor "f16[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_20, %permute_11), kwargs = {})
#   return %mm_4
triton_tem_fused_mm_t_view_13 = async_compile.triton('triton_tem_fused_mm_t_view_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_13', 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_13(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 16
    N = 128
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 64
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 128*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/4d/c4dk55rarjcifmjpcw434nuc7cbawrftqln4ehgw7yshonj564zr.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_21
#   linear_5 => mm_5, permute_12, view_22, view_23
#   mul_4 => mul_10
#   silu => add_6, convert_element_type_19, convert_element_type_20, div_1, exp_1, neg_2
# Graph fragment:
#   %convert_element_type_16 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_16]
#   %arg11_1 : Tensor "f16[128, 64][64, 1]tnca:0" = PlaceHolder[target=arg11_1]
#   %mm_4 : Tensor "f16[16, 128][128, 1]tnca:0" = PlaceHolder[target=mm_4]
#   %mm_5 : Tensor "f16[16, 128][128, 1]tnca:0" = PlaceHolder[target=mm_5]
#   %view_21 : Tensor "f16[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 16, 128]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_21, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_19,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_6 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_19, %add_6), kwargs = {})
#   %convert_element_type_20 : Tensor "f16[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.float16), kwargs = {})
#   %view_22 : Tensor "f16[16, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_16, [16, 64]), kwargs = {})
#   %permute_12 : Tensor "f16[64, 128][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg11_1, [1, 0]), kwargs = {})
#   %mm_5 : Tensor "f16[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_22, %permute_12), kwargs = {})
#   %view_23 : Tensor "f16[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 16, 128]), kwargs = {})
#   %mul_10 : Tensor "f16[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %view_23), kwargs = {})
#   return %mm_5,%mul_10
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_14 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_14', 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_14(arg_A, arg_B, in_ptr2, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 16
    N = 128
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 64
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 128*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m
    tmp0 = acc.to(tl.float16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.load(in_ptr2 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = -tmp3
    tmp5 = libdevice.exp(tmp4)
    tmp6 = tl.full([1], 1.0, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = (tmp3 / tmp7)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tmp9 * tmp1
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp10, mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/ss/cssg6mgwgx5smeixqkjja2kivrk4mtk6772plnpyismjoncuqnrd.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4, linear_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_4 => view_21
#   linear_5 => view_23
#   linear_6 => mm_6, permute_13, view_24
#   mul_4 => mul_10
#   silu => add_6, convert_element_type_19, convert_element_type_20, div_1, exp_1, neg_2
# Graph fragment:
#   %mul_10 : Tensor "f16[1, 16, 128][2048, 128, 1]tnca:0" = PlaceHolder[target=mul_10]
#   %arg12_1 : Tensor "f16[64, 128][128, 1]tnca:0" = PlaceHolder[target=arg12_1]
#   %view_21 : Tensor "f16[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 16, 128]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_21, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_19,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_6 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_19, %add_6), kwargs = {})
#   %convert_element_type_20 : Tensor "f16[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.float16), kwargs = {})
#   %view_23 : Tensor "f16[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 16, 128]), kwargs = {})
#   %mul_10 : Tensor "f16[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %view_23), kwargs = {})
#   %view_24 : Tensor "f16[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_10, [16, 128]), kwargs = {})
#   %permute_13 : Tensor "f16[128, 64][1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg12_1, [1, 0]), kwargs = {})
#   %mm_6 : Tensor "f16[16, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_24, %permute_13), kwargs = {})
#   return %mm_6
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15', 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 16
    N = 64
    K = 128
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 128
    stride_ak = 1
    stride_bk = 1
    stride_bn = 128

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 128*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 64*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 128*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/r4/cr4nbwlegt2jxy54u7etyxnglprpy4k2ppdlxdqpb62us63p4if7.py
# Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, rms_norm_2], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   linear_6 => view_25
#   rms_norm_2 => add_8, convert_element_type_25, convert_element_type_26, mean_2, mul_11, mul_12, pow_3, rsqrt_2
#   x => embedding
#   x_1 => add_4
#   x_2 => add_7
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 16][16, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[256, 64][64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %mm_6 : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=mm_6]
#   %buf29 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0" = PlaceHolder[target=buf29]
#   %arg13_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg13_1]
#   %embedding : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 16, 64]), kwargs = {})
#   %add_4 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %view_25 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 16, 64]), kwargs = {})
#   %add_7 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4, %view_25), kwargs = {})
#   %convert_element_type_25 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_7, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_25, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [2], True), kwargs = {})
#   %add_8 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_2, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8,), kwargs = {})
#   %mul_11 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_25, %rsqrt_2), kwargs = {})
#   %mul_12 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_11, %arg13_1), kwargs = {})
#   %convert_element_type_26 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_12, torch.float16), kwargs = {})
#   return %buf29,%convert_element_type_26
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_16 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_16', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 128, 'r0_': 8320}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_16(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 256), "index out of bounds: 0 <= tmp0 < 256")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 64*tmp0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp14 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp16 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp25 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 256), "index out of bounds: 0 <= tmp0 < 256")
        tmp13 = tl.load(in_ptr1 + (r0_1 + 64*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp15 = tmp13 + tmp14
        tmp17 = tmp15 + tmp16
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tl.full([1], 64.0, tl.float32)
        tmp20 = (tmp10 / tmp19)
        tmp21 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp26 = tmp25.to(tl.float32)
        tmp27 = tmp24 * tmp26
        tmp28 = tmp27.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 64*x0), tmp28, r0_mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/fi/cfiut7sbua5zespvnsfhkw74cwfseze5yjr4tht7moqn3gb2amno.py
# Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, h_1, x_3, y_1], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   h_1 => view_45
#   linear_6 => view_25
#   x => embedding
#   x_1 => add_4
#   x_2 => add_7
#   x_3 => add_12
#   y_1 => add_13, convert_element_type_40, convert_element_type_41, mean_3, mul_19, mul_20, pow_4, rsqrt_3
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 16][16, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[256, 64][64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %mm_6 : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=mm_6]
#   %mm_10 : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=mm_10]
#   %add_12 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0" = PlaceHolder[target=add_12]
#   %buf53 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0" = PlaceHolder[target=buf53]
#   %arg18_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg18_1]
#   %embedding : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 16, 64]), kwargs = {})
#   %add_4 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %view_25 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 16, 64]), kwargs = {})
#   %add_7 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4, %view_25), kwargs = {})
#   %view_45 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_10, [1, 16, 64]), kwargs = {})
#   %add_12 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_7, %view_45), kwargs = {})
#   %convert_element_type_40 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_12, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_40, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [2], True), kwargs = {})
#   %add_13 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_3, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_13,), kwargs = {})
#   %mul_19 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_40, %rsqrt_3), kwargs = {})
#   %mul_20 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_19, %arg18_1), kwargs = {})
#   %convert_element_type_41 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_20, torch.float16), kwargs = {})
#   return %add_12,%buf53,%convert_element_type_41
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 128, 'r0_': 14464}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr3, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 256), "index out of bounds: 0 <= tmp0 < 256")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 64*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (r0_1 + 64*x0), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_out_ptr0, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.debug_barrier()
        tmp14 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 64.0, tl.float32)
        tmp17 = (tmp12 / tmp16)
        tmp18 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp21 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 64*x0), tmp25, r0_mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/65/c65ikc4727is4y57fg57zevtcqfww2xyqh2nb7en4xz2zp7rejsv.py
# Topologically Sorted Source Nodes: [linear_13, x_4, getitem_12, rms_norm_4], Original ATen: [aten._unsafe_view, aten.add, aten.slice, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   getitem_12 => slice_1
#   linear_13 => view_51
#   rms_norm_4 => add_16, convert_element_type_50, convert_element_type_51, mean_4, mul_22, mul_23, pow_5, rsqrt_4
#   x_4 => add_15
# Graph fragment:
#   %add_12 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0" = PlaceHolder[target=add_12]
#   %mm_13 : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=mm_13]
#   %buf59 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf59]
#   %arg22_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg22_1]
#   %view_51 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 16, 64]), kwargs = {})
#   %add_15 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_12, %view_51), kwargs = {})
#   %slice_1 : Tensor "f16[1, 1, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%add_15, 1, -1, 9223372036854775807), kwargs = {})
#   %convert_element_type_50 : Tensor "f32[1, 1, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_1, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_50, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [2], True), kwargs = {})
#   %add_16 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_4, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_16,), kwargs = {})
#   %mul_22 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_50, %rsqrt_4), kwargs = {})
#   %mul_23 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_22, %arg22_1), kwargs = {})
#   %convert_element_type_51 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_23, torch.float16), kwargs = {})
#   return %buf59,%convert_element_type_51
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_slice_18 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_slice_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_slice_18', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 640}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_slice_18(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0 + (960), shape=[64], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1 + (960), shape=[64], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr0 + (960), shape=[64], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr1 + (960), shape=[64], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 64.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp17 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp21, r0_mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/xz/cxzele6e5a6zu2du2qdd32jy6kuradefr3apyl55ghcmdgvmbexo.py
# Topologically Sorted Source Nodes: [linear_13, x_4, getitem_12, rms_norm_4, linear_14], Original ATen: [aten._unsafe_view, aten.add, aten.slice, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   getitem_12 => slice_1
#   linear_13 => view_51
#   linear_14 => mm_14, permute_28, view_52
#   rms_norm_4 => add_16, convert_element_type_50, convert_element_type_51, mean_4, mul_22, mul_23, pow_5, rsqrt_4
#   x_4 => add_15
# Graph fragment:
#   %convert_element_type_51 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_51]
#   %arg23_1 : Tensor "f16[256, 64][64, 1]tnca:0" = PlaceHolder[target=arg23_1]
#   %view_51 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 16, 64]), kwargs = {})
#   %add_15 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_12, %view_51), kwargs = {})
#   %slice_1 : Tensor "f16[1, 1, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%add_15, 1, -1, 9223372036854775807), kwargs = {})
#   %convert_element_type_50 : Tensor "f32[1, 1, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_1, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_50, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [2], True), kwargs = {})
#   %add_16 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_4, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_16,), kwargs = {})
#   %mul_22 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_50, %rsqrt_4), kwargs = {})
#   %mul_23 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_22, %arg22_1), kwargs = {})
#   %convert_element_type_51 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_23, torch.float16), kwargs = {})
#   %view_52 : Tensor "f16[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_51, [1, 64]), kwargs = {})
#   %permute_28 : Tensor "f16[64, 256][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg23_1, [1, 0]), kwargs = {})
#   %mm_14 : Tensor "f16[1, 256][256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_52, %permute_28), kwargs = {})
#   return %mm_14
triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_19 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_19', 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_19(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 256
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 256*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 256*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1 = args
        args.clear()
        assert_size_stride_grouped((arg1_1, arg0_1, arg4_1), ((1, 16), (256, 64), (64, )), ((16, 1), (64, 1), (1, )), 'input')
        buf1 = empty_strided((1, 16, 64), (1024, 64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [x, rms_norm], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg0_1, arg4_1, buf1, 16, 64, stream=raw_stream0)
        del arg4_1
        assert_size_stride(arg5_1, (64, 64), (64, 1), 'input')
        buf2 = empty_strided((16, 64), (64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [x, rms_norm, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf1, arg5_1, buf2, 4, 1, 1, stream=raw_stream0)
        del arg5_1
        assert_size_stride(arg6_1, (32, 64), (64, 1), 'input')
        buf3 = empty_strided((16, 32), (32, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf1, arg6_1, buf3, 2, 1, 1, stream=raw_stream0)
        del arg6_1
        buf6 = empty_strided((1, 4, 16, 16), (1024, 256, 16, 1), device='tnca', dtype=torch.float16)
        buf4 = reinterpret_tensor(buf6, (1, 4, 16, 8), (1024, 256, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear, view, q, chunk, neg], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf2, buf4, 512, stream=raw_stream0)
        buf5 = reinterpret_tensor(buf6, (1, 4, 16, 8), (1024, 256, 16, 1), 8)  # alias
        # Topologically Sorted Source Nodes: [linear, view, q, chunk, neg, cat], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf2, buf5, 512, stream=raw_stream0)
        buf9 = empty_strided((1, 2, 16, 16), (512, 256, 16, 1), device='tnca', dtype=torch.float16)
        buf7 = reinterpret_tensor(buf9, (1, 2, 16, 8), (512, 256, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf3, buf7, 256, stream=raw_stream0)
        del buf4
        del buf5
        buf8 = reinterpret_tensor(buf9, (1, 2, 16, 8), (512, 256, 16, 1), 8)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1, cat_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf3, buf8, 256, stream=raw_stream0)
        assert_size_stride_grouped((arg2_1, arg3_1), ((16, 16), (16, 16)), ((16, 1), (16, 1)), 'input')
        buf10 = empty_strided((1, 4, 16, 16), (1024, 256, 16, 1), device='tnca', dtype=torch.float32)
        buf11 = empty_strided((1, 4, 16, 16), (1024, 256, 16, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear, view, q, linear_1, view_1, k, mul, mul_1, q_1, o, mul_2, mul_3, k_1, getitem_4, expand, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7.run(buf2, arg2_1, buf6, arg3_1, buf3, buf9, buf10, buf11, 64, 16, stream=raw_stream0)
        del buf2
        del buf3
        del buf6
        del buf7
        del buf8
        buf12 = empty_strided((4, 16, 16), (256, 16, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear, view, q, linear_1, view_1, k, mul, mul_1, q_1, o, mul_2, mul_3, k_1, getitem_4, expand, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8.run(buf10, buf11, buf12, 1, 4, 1, stream=raw_stream0)
        buf15 = buf11; del buf11  # reuse
        buf18 = buf15; del buf15  # reuse
        # Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9.run(buf18, buf12, 64, 16, stream=raw_stream0)
        assert_size_stride(arg7_1, (32, 64), (64, 1), 'input')
        buf17 = reinterpret_tensor(buf9, (16, 32), (32, 1), 0); del buf9  # reuse
        # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf1, arg7_1, buf17, 2, 1, 1, stream=raw_stream0)
        del arg7_1
        buf19 = reinterpret_tensor(buf12, (1, 4, 16, 16), (1024, 256, 16, 1), 0); del buf12  # reuse
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, getitem_5, expand_1, v_1, o], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf17, buf19, 1024, stream=raw_stream0)
        buf20 = reinterpret_tensor(buf10, (4, 16, 16), (256, 16, 1), 0); del buf10  # reuse
        # Topologically Sorted Source Nodes: [o, linear_2, view_2, v, getitem_5, expand_1, v_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8.run(buf18, buf19, buf20, 1, 4, 1, stream=raw_stream0)
        del buf18
        del buf19
        buf21 = reinterpret_tensor(buf1, (16, 1, 4, 16), (64, 1, 16, 1), 0); del buf1  # reuse
        # Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_11.run(buf20, buf21, 1024, stream=raw_stream0)
        del buf20
        assert_size_stride(arg8_1, (64, 64), (64, 1), 'input')
        buf22 = empty_strided((16, 64), (64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [o, transpose_3, o_1, h], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf21, arg8_1, buf22, 4, 1, 1, stream=raw_stream0)
        del arg8_1
        assert_size_stride(arg9_1, (64, ), (1, ), 'input')
        buf24 = reinterpret_tensor(buf21, (1, 16, 64), (1024, 64, 1), 0); del buf21  # reuse
        # Topologically Sorted Source Nodes: [x, h, x_1, y], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_12.run(arg1_1, arg0_1, buf22, arg9_1, buf24, 16, 64, stream=raw_stream0)
        del arg9_1
        assert_size_stride(arg10_1, (128, 64), (64, 1), 'input')
        buf25 = empty_strided((16, 128), (128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_13.run(buf24, arg10_1, buf25, 8, 1, 1, stream=raw_stream0)
        del arg10_1
        assert_size_stride(arg11_1, (128, 64), (64, 1), 'input')
        buf27 = empty_strided((1, 16, 128), (2048, 128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_14.run(buf24, arg11_1, buf25, buf27, 8, 1, 1, stream=raw_stream0)
        del arg11_1
        del buf25
        assert_size_stride(arg12_1, (64, 128), (128, 1), 'input')
        buf28 = reinterpret_tensor(buf24, (16, 64), (64, 1), 0); del buf24  # reuse
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4, linear_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf27, arg12_1, buf28, 4, 1, 1, stream=raw_stream0)
        del arg12_1
        del buf27
        assert_size_stride(arg13_1, (64, ), (1, ), 'input')
        buf30 = empty_strided((1, 16, 64), (1024, 64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, rms_norm_2], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_16.run(arg1_1, arg0_1, buf22, buf28, arg13_1, buf30, 16, 64, stream=raw_stream0)
        del arg13_1
        assert_size_stride(arg14_1, (64, 64), (64, 1), 'input')
        buf31 = empty_strided((16, 64), (64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf30, arg14_1, buf31, 4, 1, 1, stream=raw_stream0)
        del arg14_1
        assert_size_stride(arg15_1, (32, 64), (64, 1), 'input')
        buf32 = buf17; del buf17  # reuse
        # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf30, arg15_1, buf32, 2, 1, 1, stream=raw_stream0)
        del arg15_1
        buf35 = empty_strided((1, 4, 16, 16), (1024, 256, 16, 1), device='tnca', dtype=torch.float16)
        buf33 = reinterpret_tensor(buf35, (1, 4, 16, 8), (1024, 256, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, chunk_2, neg_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf31, buf33, 512, stream=raw_stream0)
        buf34 = reinterpret_tensor(buf35, (1, 4, 16, 8), (1024, 256, 16, 1), 8)  # alias
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, chunk_2, neg_2, cat_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf31, buf34, 512, stream=raw_stream0)
        buf38 = empty_strided((1, 2, 16, 16), (512, 256, 16, 1), device='tnca', dtype=torch.float16)
        buf36 = reinterpret_tensor(buf38, (1, 2, 16, 8), (512, 256, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_3, chunk_3, neg_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf32, buf36, 256, stream=raw_stream0)
        del buf33
        del buf34
        buf37 = reinterpret_tensor(buf38, (1, 2, 16, 8), (512, 256, 16, 1), 8)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_3, chunk_3, neg_3, cat_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf32, buf37, 256, stream=raw_stream0)
        buf39 = empty_strided((1, 4, 16, 16), (1024, 256, 16, 1), device='tnca', dtype=torch.float32)
        buf40 = empty_strided((1, 4, 16, 16), (1024, 256, 16, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, linear_8, view_4, k_3, mul_5, mul_6, q_3, o_2, mul_7, mul_8, k_4, getitem_10, expand_2, k_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7.run(buf31, arg2_1, buf35, arg3_1, buf32, buf38, buf39, buf40, 64, 16, stream=raw_stream0)
        del arg2_1
        del arg3_1
        del buf31
        del buf32
        del buf35
        del buf36
        del buf37
        buf41 = empty_strided((4, 16, 16), (256, 16, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, linear_8, view_4, k_3, mul_5, mul_6, q_3, o_2, mul_7, mul_8, k_4, getitem_10, expand_2, k_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8.run(buf39, buf40, buf41, 1, 4, 1, stream=raw_stream0)
        del buf39
        buf44 = buf40; del buf40  # reuse
        buf47 = buf44; del buf44  # reuse
        # Topologically Sorted Source Nodes: [o_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9.run(buf47, buf41, 64, 16, stream=raw_stream0)
        assert_size_stride(arg16_1, (32, 64), (64, 1), 'input')
        buf46 = reinterpret_tensor(buf38, (16, 32), (32, 1), 0); del buf38  # reuse
        # Topologically Sorted Source Nodes: [linear_9], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf30, arg16_1, buf46, 2, 1, 1, stream=raw_stream0)
        del arg16_1
        buf48 = reinterpret_tensor(buf41, (1, 4, 16, 16), (1024, 256, 16, 1), 0); del buf41  # reuse
        # Topologically Sorted Source Nodes: [linear_9, view_5, v_2, getitem_11, expand_3, v_3, o_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf46, buf48, 1024, stream=raw_stream0)
        del buf46
        buf49 = empty_strided((4, 16, 16), (256, 16, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [o_2, linear_9, view_5, v_2, getitem_11, expand_3, v_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8.run(buf47, buf48, buf49, 1, 4, 1, stream=raw_stream0)
        del buf47
        del buf48
        buf50 = reinterpret_tensor(buf30, (16, 1, 4, 16), (64, 1, 16, 1), 0); del buf30  # reuse
        # Topologically Sorted Source Nodes: [o_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_11.run(buf49, buf50, 1024, stream=raw_stream0)
        del buf49
        assert_size_stride(arg17_1, (64, 64), (64, 1), 'input')
        buf51 = empty_strided((16, 64), (64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [o_2, transpose_7, o_3, h_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf50, arg17_1, buf51, 4, 1, 1, stream=raw_stream0)
        del arg17_1
        assert_size_stride(arg18_1, (64, ), (1, ), 'input')
        buf52 = reinterpret_tensor(buf22, (1, 16, 64), (1024, 64, 1), 0); del buf22  # reuse
        buf54 = reinterpret_tensor(buf50, (1, 16, 64), (1024, 64, 1), 0); del buf50  # reuse
        # Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, h_1, x_3, y_1], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17.run(buf52, arg1_1, arg0_1, buf28, buf51, arg18_1, buf54, 16, 64, stream=raw_stream0)
        del arg0_1
        del arg18_1
        del arg1_1
        del buf28
        del buf51
        assert_size_stride(arg19_1, (128, 64), (64, 1), 'input')
        buf55 = empty_strided((16, 128), (128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [y_1, linear_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_13.run(buf54, arg19_1, buf55, 8, 1, 1, stream=raw_stream0)
        del arg19_1
        assert_size_stride(arg20_1, (128, 64), (64, 1), 'input')
        buf57 = empty_strided((1, 16, 128), (2048, 128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_9], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_14.run(buf54, arg20_1, buf55, buf57, 8, 1, 1, stream=raw_stream0)
        del arg20_1
        del buf55
        assert_size_stride(arg21_1, (64, 128), (128, 1), 'input')
        buf58 = reinterpret_tensor(buf54, (16, 64), (64, 1), 0); del buf54  # reuse
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_9, linear_13], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf57, arg21_1, buf58, 4, 1, 1, stream=raw_stream0)
        del arg21_1
        del buf57
        assert_size_stride(arg22_1, (64, ), (1, ), 'input')
        buf60 = empty_strided((1, 1, 64), (64, 64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_13, x_4, getitem_12, rms_norm_4], Original ATen: [aten._unsafe_view, aten.add, aten.slice, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_slice_18.run(buf52, buf58, arg22_1, buf60, 1, 64, stream=raw_stream0)
        del arg22_1
        del buf52
        del buf58
        assert_size_stride(arg23_1, (256, 64), (64, 1), 'input')
        buf61 = empty_strided((1, 256), (256, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_13, x_4, getitem_12, rms_norm_4, linear_14], Original ATen: [aten._unsafe_view, aten.add, aten.slice, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_19.run(buf60, arg23_1, buf61, 16, 1, 1, stream=raw_stream0)
        del arg23_1
        return (reinterpret_tensor(buf61, (1, 1, 256), (256, 256, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((256, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg1_1 = rand_strided((1, 16), (16, 1), device='tnca:0', dtype=torch.int64)
    arg2_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float16)
    arg3_1 = rand_strided((16, 16), (16, 1), device='tnca:0', dtype=torch.float16)
    arg4_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg5_1 = rand_strided((64, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg6_1 = rand_strided((32, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg7_1 = rand_strided((32, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg8_1 = rand_strided((64, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg9_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg10_1 = rand_strided((128, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg11_1 = rand_strided((128, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg12_1 = rand_strided((64, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg13_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg14_1 = rand_strided((64, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg15_1 = rand_strided((32, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg16_1 = rand_strided((32, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg17_1 = rand_strided((64, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg18_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg19_1 = rand_strided((128, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg20_1 = rand_strided((128, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg21_1 = rand_strided((64, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg22_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg23_1 = rand_strided((256, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
