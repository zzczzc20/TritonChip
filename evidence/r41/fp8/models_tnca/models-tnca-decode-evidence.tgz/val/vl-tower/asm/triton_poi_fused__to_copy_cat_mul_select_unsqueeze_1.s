    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #4
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #2
    v.lshr       v5, v4, v0
    s.rdspecial  s1, arg_base
    v.sub        v0, v2, v5
    v.movi       v4, #1
    @p1 v.sel        v6, v0, v5
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.mul        v0, v6, v1
    v.movi       v1, #1
    v.add        v5, v0, v4
    v.movi       v4, #1
    s.addi       s3, s2, #4
    s.addi       s4, s2, #4
    v.shl        v7, v0, v1
    v.shl        v0, v5, v4
    v.ld.gather.w v1, [s3, v7]                   // index is in elements (ISA sec 9.1)
    v.movi       v4, #31
    v.movi       v5, #0
    v.movi       v8, #15
    v.sub        v9, v5, v3
    v.cmp.lt     p1, v3, v5
    @p1 v.sel        v10, v9, v3
    v.movi       v3, #16
    v.and        v9, v10, v8
    v.sub        v8, v2, v3
    v.ld.gather.w v10, [s4, v0]                  // index is in elements (ISA sec 9.1)
    v.sub        v11, v5, v9
    v.sub        v12, v5, v3
    @p1 v.sel        v13, v11, v9
    v.cmp.lt     p1, v3, v2
    v.cmp.lt     p2, v3, v5
    @p1 v.sel        v2, v8, v3
    @p2 v.sel        v2, v12, v3
    v.ld.gather.w v2, [s2, v7]                   // index is in elements (ISA sec 9.1)
    v.ld.gather.w v3, [s2, v0]                   // index is in elements (ISA sec 9.1)
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.ashr       v0, v1, v4
    v.ld.gather.w v4, [s2, v13]                  // index is in elements (ISA sec 9.1)
    s.ld.d       s2, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    v.xor        v5, v2, v0
    s.ld.d       s3, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    v.sub        v2, v5, v0
    s.ld.d       s4, [s1, #32]                   // out_ptr2: device_ptr64 at arg_base+32
    v.movi       v5, #0
    s.ld.d       s5, [s1, #40]                   // out_ptr3: device_ptr64 at arg_base+40
    v.movi       v7, #1
    v.movi       v8, #0
    v.cmp.eq     p1, v2, v5
    @p1 v.sel        v5, v7, v8
    v.xor        v7, v1, v0
    v.and        v8, v0, v5
    v.movi       v0, #32
    v.add        v5, v7, v8
    v.movi       v7, #1
    v.clz        v8, v5
    v.movi       v9, #-1
    v.sub        v11, v0, v8
    v.lshr       v0, v9, v8
    v.sub        v9, v11, v7
    v.movi       v7, #1
    v.lshr       v12, v2, v9
    v.and        v9, v2, v0
    v.movi       v0, #0
    v.shl        v14, v5, v8
    v.lshr       v8, v12, v7
    v.movi       v7, #1
    v.movi       v12, #0
    v.cmp.ne     p1, v9, v0
    v.or         v0, v14, v8
    @p1 v.sel        v8, v7, v12
    v.movi       v7, #127
    v.or         v9, v0, v8
    v.add        v0, v11, v7
    vf.cvt.u32.f32 v7, v9                        // top 32 bits + sticky: one rounding
    v.movi       v8, #23
    vf.cvt.u32.f32 v9, v2                        // |x| < 2**32: one rounding
    v.shl        v2, v0, v8
    v.movi       v0, #0
    vf.mul       v8, v7, v2                      // * 2**n, exact
    v.cmp.eq     p1, v5, v0
    v.movi       v0, #0
    v.movi       v2, #23
    @p1 v.sel        v5, v9, v8
    v.cmp.lt     p1, v1, v0
    vf.neg       v0, v5
    v.movi       v1, #127
    v.movi       v7, #-1
    v.movi       v8, #7
    @p1 v.sel        v9, v0, v5
    v.movi       v0, #5
    vf.mul       v5, v9, v4
    v.movi       v9, #1
    .li       s1, #1313084713
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-64530479
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v14, v5
    v.movi       v15, #2
    .li       s1, #-1560706194
    v.splat      v16, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1313084713
    v.splat      v17, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.lshr       v18, v14, v2
    .li       s1, #-181084736
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v19, v18, v1
    .li       s1, #-64530479
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.max.s      v18, v19, v7
    v.movi       v7, #3
    v.add        v20, v18, v8
    .li       s1, #-64530479
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.lshr       v18, v20, v0
    .li       s1, #-614296167
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.eq     p1, v18, v9
    @p1 v.sel        v9, v12, v11
    v.cmp.eq     p2, v18, v15
    @p1 v.sel        v11, v17, v16
    @p2 v.sel        v12, v2, v9
    v.cmp.eq     p3, v18, v7
    v.movi       v2, #4
    v.movi       v7, #0
    .li       s1, #-1560706194
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v15, #31
    @p2 v.sel        v16, v8, v11
    .li       s1, #-181084736
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p3 v.sel        v11, v0, v12
    .li       s1, #1011060801
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.eq     p4, v18, v2
    @p1 v.sel        v2, v9, v7
    .li       s1, #1313084713
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v9, v20, v15
    @p3 v.sel        v12, v8, v16
    .li       s1, #-614296167
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v15, v0, v11
    @p2 v.sel        v0, v7, v2
    .li       s1, #-64530479
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #8388607
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-181084736
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v16, v8, v12
    @p3 v.sel        v8, v2, v0
    .li       s1, #-181084736
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v2, v14, v7
    @p1 v.sel        v7, v11, v1
    .li       s1, #8388608
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-614296167
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v12, v0, v8
    v.or         v0, v2, v1
    @p2 v.sel        v1, v11, v7
    .li       s1, #1011060801
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-28220501
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p3 v.sel        v8, v2, v1
    v.movi       v1, #31
    @p4 v.sel        v2, v7, v8
    v.movi       v7, #1
    v.movi       v8, #1
    v.sub        v11, v1, v9
    v.lshr       v1, v15, v7
    v.lshr       v7, v2, v8
    v.movi       v2, #1
    v.shl        v8, v16, v9
    v.lshr       v17, v1, v11
    v.shl        v1, v15, v9
    v.lshr       v15, v7, v11
    v.lshr       v7, v16, v2
    v.or         v2, v8, v17
    v.or         v8, v1, v15
    v.shl        v1, v12, v9
    v.lshr       v9, v7, v11
    v.mulh.u     v7, v0, v8
    v.mul        v11, v0, v2
    v.or         v12, v1, v9
    v.add        v1, v11, v7
    v.movi       v9, #1
    v.movi       v11, #0
    v.mul        v15, v0, v12
    v.mulh.u     v12, v0, v2
    v.cmp.ltu    p1, v1, v7
    @p1 v.sel        v2, v9, v11
    v.add        v7, v15, v12
    v.movi       v9, #2
    v.add        v11, v7, v2
    v.movi       v2, #30
    v.shl        v7, v11, v9
    v.lshr       v9, v1, v2
    v.mul        v2, v0, v8
    v.movi       v0, #2
    v.movi       v8, #30
    v.or         v12, v7, v9
    v.movi       v7, #31
    v.shl        v9, v1, v0
    v.lshr       v0, v2, v8
    v.ashr       v1, v12, v7
    v.or         v2, v9, v0
    v.xor        v0, v12, v1
    v.movi       v7, #0
    v.xor        v8, v2, v1
    v.cmp.ne     p1, v0, v7
    @p1 v.sel        v2, v0, v8
    v.movi       v0, #0
    v.clz        v7, v2
    @p1 v.sel        v9, v8, v0
    v.movi       v0, #1
    v.movi       v8, #31
    v.lshr       v12, v9, v0
    v.sub        v0, v8, v7
    v.shl        v8, v2, v7
    v.lshr       v15, v12, v0
    v.movi       v0, #0
    v.movi       v12, #32
    v.or         v16, v8, v15
    @p1 v.sel        v8, v0, v12
    v.movi       v0, #8
    v.add        v12, v7, v8
    v.lshr       v8, v16, v0
    v.movi       v0, #103
    vf.cvt.u32.f32 v15, v8
    v.movi       v8, #255
    v.shl        v17, v9, v7
    v.and        v7, v16, v8
    v.movi       v8, #16
    v.movi       v9, #16
    v.shl        v16, v7, v8
    v.lshr       v7, v17, v9
    .li       s1, #536870912
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v9, v0, v12
    v.or         v0, v16, v7
    v.add        v7, v11, v8
    v.movi       v8, #23
    vf.cvt.u32.f32 v11, v0
    v.movi       v0, #30
    v.shl        v16, v9, v8
    v.lshr       v8, v7, v0
    vf.mul       v0, v15, v16
    .li       s1, #-2147483648
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #0
    v.and        v15, v1, v7
    v.movi       v1, #0
    v.xor        v7, v0, v15
    v.cmp.eq     p1, v2, v9
    @p1 v.sel        v0, v1, v7
    .li       s1, #1070141403
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v7, #-1
    vf.mul       v9, v0, v2
    v.cmp.lt     p2, v19, v7
    .li       s1, #1056964608
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #79
    @p2 v.sel        v17, v14, v9
    v.sub        v14, v16, v12
    vf.mul       v12, v17, v17
    v.movi       v16, #23
    .li       s1, #1065353216
    v.splat      v18, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.shl        v20, v14, v16
    vf.mul       v14, v12, v7
    vf.mul       v16, v11, v20
    vf.fms       v11, v0, v2, v9                 // exact error of f_hi*pi/2
    .li       s1, #3007036718
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.sub       v20, v18, v14
    v.xor        v21, v16, v15
    vf.fma       v15, v0, v9, v11
    .li       s1, #909535061
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.sub       v11, v18, v20
    .li       s1, #3109029817
    v.splat      v16, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v22, v1, v21
    vf.fms       v21, v17, v17, v12              // exact error of r*r
    vf.fma       v23, v0, v12, v16
    vf.sub       v24, v11, v14
    vf.fma       v11, v22, v2, v15
    .li       s1, #1007192196
    v.splat      v15, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v22, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #936178630
    v.splat      v25, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3132491283
    v.splat      v26, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v27, v14
    vf.fma       v14, v23, v12, v15
    vf.fma       v23, v22, v21, v24
    vf.neg       v21, v17
    vf.fma       v24, v25, v12, v26
    @p2 v.sel        v28, v1, v11
    .li       s1, #3190467243
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1026206373
    v.splat      v29, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v30, v17, v12
    vf.fma       v31, v27, v28, v28
    vf.fma       v27, v14, v12, v11
    vf.fma       v14, v21, v28, v23
    vf.mul       v21, v12, v12
    vf.fma       v23, v24, v12, v29
    v.movi       v12, #0
    vf.fma       v24, v30, v27, v31
    @p2 v.sel        v27, v12, v8
    v.movi       v8, #31
    v.movi       v12, #0
    v.ashr       v28, v10, v8
    vf.fma       v8, v21, v23, v14
    v.xor        v14, v3, v28
    v.movi       v3, #2
    v.sub        v21, v14, v28
    v.movi       v14, #1
    v.movi       v23, #1
    vf.add       v30, v17, v24
    v.movi       v17, #1
    v.movi       v24, #0
    v.cmp.eq     p1, v21, v12
    @p1 v.sel        v12, v17, v24
    v.xor        v17, v10, v28
    v.and        v24, v28, v12
    v.movi       v12, #32
    v.add        v28, v17, v24
    v.movi       v17, #1
    v.clz        v24, v28
    v.movi       v31, #1
    v.sub        v32, v12, v24
    v.shl        v12, v28, v24
    v.sub        v33, v32, v17
    vf.add       v17, v20, v8
    v.lshr       v8, v21, v33
    vf.cvt.u32.f32 v20, v21                      // |x| < 2**32: one rounding
    v.lshr       v33, v8, v31
    v.and        v8, v27, v3
    v.or         v3, v12, v33
    v.movi       v12, #30
    .li       s1, #-2147483648
    v.splat      v31, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v33, v27, v14
    v.and        v14, v27, v23
    v.movi       v23, #-1
    v.shl        v27, v8, v12
    v.movi       v8, #2
    v.and        v12, v5, v31
    v.movi       v5, #0
    v.lshr       v31, v23, v24
    v.and        v23, v33, v8
    v.movi       v8, #30
    v.cmp.ne     p1, v14, v5
    v.and        v5, v21, v31
    v.xor        v14, v27, v12
    @p1 v.sel        v12, v17, v30
    v.shl        v21, v23, v8
    @p1 v.sel        v8, v30, v17
    v.movi       v17, #128
    v.movi       v23, #0
    .li       s1, #2143289344
    v.splat      v24, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.xor        v27, v12, v14
    v.xor        v12, v8, v21
    v.cmp.eq     p1, v19, v17
    v.movi       v8, #1
    v.movi       v14, #0
    v.cmp.ne     p2, v5, v23
    @p2 v.sel        v5, v8, v14
    v.movi       v8, #127
    v.or         v14, v3, v5
    v.add        v3, v32, v8
    vf.cvt.u32.f32 v5, v14                       // top 32 bits + sticky: one rounding
    v.movi       v8, #23
    @p1 v.sel        v14, v24, v27
    v.shl        v17, v3, v8
    v.movi       v3, #0
    vf.mul       v8, v5, v17                     // * 2**n, exact
    v.cmp.eq     p2, v28, v3
    v.movi       v3, #0
    @p1 v.sel        v5, v24, v12
    @p2 v.sel        v12, v20, v8
    v.cmp.lt     p1, v10, v3
    vf.neg       v3, v12
    v.movi       v8, #23
    v.movi       v10, #127
    v.movi       v17, #-1
    @p1 v.sel        v19, v3, v12
    v.movi       v3, #7
    vf.mul       v12, v19, v4
    v.movi       v4, #5
    v.movi       v19, #1
    .li       s1, #1313084713
    v.splat      v20, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v21, v12
    .li       s1, #-64530479
    v.splat      v23, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v27, #2
    .li       s1, #-1560706194
    v.splat      v28, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.lshr       v30, v21, v8
    .li       s1, #1313084713
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v31, v30, v10
    .li       s1, #-64530479
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.max.s      v30, v31, v17
    .li       s1, #-181084736
    v.splat      v17, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v32, v30, v3
    v.movi       v3, #3
    v.lshr       v30, v32, v4
    .li       s1, #-64530479
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.eq     p1, v30, v19
    @p1 v.sel        v19, v23, v20
    v.cmp.eq     p2, v30, v27
    @p1 v.sel        v20, v8, v28
    @p2 v.sel        v8, v17, v19
    .li       s1, #-614296167
    v.splat      v17, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.eq     p3, v30, v3
    v.movi       v3, #4
    v.movi       v19, #0
    .li       s1, #-1560706194
    v.splat      v23, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v27, #31
    @p2 v.sel        v28, v4, v20
    .li       s1, #-181084736
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p3 v.sel        v20, v17, v8
    .li       s1, #1011060801
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.eq     p4, v30, v3
    @p1 v.sel        v3, v23, v19
    .li       s1, #1313084713
    v.splat      v17, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v19, v32, v27
    @p3 v.sel        v23, v4, v28
    .li       s1, #-614296167
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v27, v8, v20
    @p2 v.sel        v8, v17, v3
    .li       s1, #-64530479
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #8388607
    v.splat      v17, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-181084736
    v.splat      v20, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v28, v4, v23
    @p3 v.sel        v4, v3, v8
    .li       s1, #-181084736
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v8, v21, v17
    @p1 v.sel        v17, v20, v10
    .li       s1, #8388608
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-614296167
    v.splat      v20, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v23, v3, v4
    v.or         v3, v8, v10
    @p2 v.sel        v4, v20, v17
    .li       s1, #1011060801
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-28220501
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p3 v.sel        v17, v8, v4
    v.movi       v4, #31
    @p4 v.sel        v8, v10, v17
    v.movi       v10, #1
    v.movi       v17, #1
    v.sub        v20, v4, v19
    v.lshr       v4, v27, v10
    v.lshr       v10, v8, v17
    v.movi       v8, #1
    v.shl        v17, v28, v19
    v.lshr       v30, v4, v20
    v.shl        v4, v27, v19
    v.lshr       v27, v10, v20
    v.lshr       v10, v28, v8
    v.or         v8, v17, v30
    v.or         v17, v4, v27
    v.shl        v4, v23, v19
    v.lshr       v19, v10, v20
    v.mulh.u     v10, v3, v17
    v.mul        v20, v3, v8
    v.or         v23, v4, v19
    v.add        v4, v20, v10
    v.movi       v19, #1
    v.movi       v20, #0
    v.mul        v27, v3, v23
    v.mulh.u     v23, v3, v8
    v.cmp.ltu    p1, v4, v10
    @p1 v.sel        v8, v19, v20
    v.add        v10, v27, v23
    v.movi       v19, #2
    v.add        v20, v10, v8
    v.movi       v8, #30
    v.shl        v10, v20, v19
    v.lshr       v19, v4, v8
    v.mul        v8, v3, v17
    v.movi       v3, #2
    v.movi       v17, #30
    v.or         v23, v10, v19
    v.movi       v10, #31
    v.shl        v19, v4, v3
    v.lshr       v3, v8, v17
    v.ashr       v4, v23, v10
    v.or         v8, v19, v3
    v.xor        v3, v23, v4
    v.movi       v10, #0
    v.xor        v17, v8, v4
    v.cmp.ne     p1, v3, v10
    @p1 v.sel        v8, v3, v17
    v.movi       v3, #0
    v.clz        v10, v8
    @p1 v.sel        v19, v17, v3
    v.movi       v3, #1
    v.movi       v17, #31
    v.lshr       v23, v19, v3
    v.sub        v3, v17, v10
    v.shl        v17, v8, v10
    v.lshr       v27, v23, v3
    v.movi       v3, #0
    v.movi       v23, #32
    v.or         v28, v17, v27
    @p1 v.sel        v17, v3, v23
    v.movi       v3, #8
    v.add        v23, v10, v17
    v.lshr       v17, v28, v3
    v.movi       v3, #103
    vf.cvt.u32.f32 v27, v17
    v.movi       v17, #255
    v.shl        v30, v19, v10
    v.and        v10, v28, v17
    v.movi       v17, #16
    v.movi       v19, #16
    v.shl        v28, v10, v17
    v.lshr       v10, v30, v19
    .li       s1, #536870912
    v.splat      v17, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v19, v3, v23
    v.or         v3, v28, v10
    v.add        v10, v20, v17
    v.movi       v17, #23
    vf.cvt.u32.f32 v20, v3
    v.movi       v3, #30
    v.shl        v28, v19, v17
    v.lshr       v17, v10, v3
    vf.mul       v3, v27, v28
    .li       s1, #-2147483648
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v19, #0
    v.and        v27, v4, v10
    v.cmp.eq     p1, v8, v19
    v.xor        v4, v3, v27
    v.movi       v3, #-1
    @p1 v.sel        v8, v1, v4
    v.cmp.lt     p2, v31, v3
    vf.mul       v3, v8, v2
    v.movi       v4, #79
    v.movi       v10, #23
    v.sub        v19, v4, v23
    @p2 v.sel        v4, v21, v3
    v.shl        v21, v19, v10
    vf.mul       v10, v4, v4
    vf.mul       v19, v20, v21
    vf.fms       v20, v8, v2, v3                 // exact error of f_hi*pi/2
    vf.neg       v3, v4
    vf.mul       v21, v10, v7
    v.xor        v7, v19, v27
    vf.fma       v19, v8, v9, v20
    @p1 v.sel        v8, v1, v7
    vf.sub       v7, v18, v21
    vf.fms       v9, v4, v4, v10                 // exact error of r*r
    vf.fma       v20, v0, v10, v16
    vf.fma       v0, v8, v2, v19
    vf.sub       v2, v18, v7
    vf.neg       v8, v21
    vf.fma       v16, v20, v10, v15
    vf.fma       v15, v25, v10, v26
    vf.sub       v18, v2, v21
    @p2 v.sel        v2, v1, v0
    vf.mul       v0, v4, v10
    vf.fma       v1, v8, v2, v2
    vf.fma       v8, v22, v9, v18
    vf.fma       v9, v16, v10, v11
    vf.mul       v11, v10, v10
    vf.fma       v16, v15, v10, v29
    vf.fma       v10, v3, v2, v8
    v.movi       v2, #0
    vf.fma       v3, v0, v9, v1
    @p2 v.sel        v0, v2, v17
    vf.fma       v1, v11, v16, v10
    v.movi       v2, #2
    v.movi       v8, #1
    v.movi       v9, #1
    vf.add       v10, v4, v3
    vf.add       v3, v7, v1
    v.and        v1, v0, v2
    v.movi       v2, #30
    .li       s1, #-2147483648
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v7, v0, v8
    v.movi       v8, #2
    v.and        v11, v0, v9
    v.movi       v0, #0
    v.shl        v9, v1, v2
    v.and        v1, v12, v4
    v.and        v2, v7, v8
    v.movi       v4, #30
    v.cmp.ne     p1, v11, v0
    v.xor        v0, v9, v1
    @p1 v.sel        v1, v3, v10
    v.shl        v7, v2, v4
    @p1 v.sel        v2, v10, v3
    v.movi       v3, #32
    v.movi       v4, #128
    v.xor        v8, v1, v0
    v.xor        v0, v2, v7
    v.mul        v1, v6, v3
    v.cmp.eq     p1, v31, v4
    @p1 v.sel        v2, v24, v8
    @p1 v.sel        v3, v24, v0
    v.add        v0, v13, v1
    v.st.scatter.w [s2, v0], v5
    v.st.scatter.w [s3, v0], v14
    v.st.scatter.w [s4, v0], v3
    v.st.scatter.w [s5, v0], v2
__rctx_next:
    exit
