    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #13
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v1, v4
    @p1 v.sel        v7, v5, v4
    v.movi       v5, #1
    v.cmp.lt     p2, v4, v1
    v.lshr       v8, v7, v3
    @p2 v.sel        v3, v6, v4
    v.movi       v4, #8191
    v.sub        v6, v2, v8
    s.rdspecial  s2, arg_base
    v.and        v7, v3, v4
    @p1 v.sel        v3, v6, v8
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v4, #8192
    v.sub        v6, v0, v3
    v.cmp.lt     p1, v3, v0
    v.sub        v8, v1, v7
    @p1 v.sel        v9, v6, v3
    v.movi       v3, #2
    @p2 v.sel        v6, v8, v7
    v.lshr       v7, v9, v5
    s.shli       s4, s1, #2                      // element offset -> bytes (x4)
    v.sub        v5, v1, v4
    v.sub        v8, v0, v7
    s.ld.d       s1, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.sub        v9, v2, v4
    @p1 v.sel        v10, v8, v7
    v.sub        v7, v0, v3
    v.cmp.lt     p1, v4, v1
    v.mul        v1, v10, v4
    v.cmp.lt     p2, v4, v2
    v.cmp.lt     p3, v3, v0
    v.add        v0, v6, v1
    @p1 v.sel        v1, v5, v4
    @p2 v.sel        v1, v9, v4
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.add        s2, s1, s4                      // &out_ptr0[...]
    @p3 v.sel        v0, v7, v3
    vf.cvt.bf16.f32 v0, v1
    v.st.w       [s2, #0], v0
__rctx_next:
    exit
