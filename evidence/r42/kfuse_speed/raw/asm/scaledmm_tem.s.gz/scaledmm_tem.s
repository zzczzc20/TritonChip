    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // arg_SA: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // arg_SB: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.rdspecial  s1, pid.x
    s.movz       s7, #3
    s.movz       s8, #0
    s.cmp.lt     s9, s1, s8
    s.sub        s10, s8, s9
    s.cmp.lt     s9, s7, s8
    s.sub        s11, s8, s9
    s.xor        s8, s1, s10
    s.sub        s1, s8, s10
    s.xor        s8, s7, s11
    s.sub        s9, s8, s11
    .li       s8, #1431655766
    s.mul        s9, s1, s8
    s.lshri      s8, s9, #32
    s.sub        s9, s1, s8
    s.lshri      s12, s9, #1
    s.add        s9, s8, s12
    s.lshri      s8, s9, #1
    s.muli       s9, s8, #3
    s.sub        s12, s1, s9
    s.xor        s1, s10, s11
    s.xor        s9, s8, s1
    s.sub        s8, s9, s1
    s.xor        s1, s12, s10
    s.sub        s9, s1, s10
    s.movz       s1, #16
    s.mul        s10, s8, s1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s10
    v.add        v2, v1, v0
    s.movz       s8, #128
    s.mul        s11, s9, s8
    v.movi       v1, #16
    v.add        v3, v0, v1
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v4, #32
    v.add        v5, v1, v4
    v.movi       v4, #48
    v.add        v6, v1, v4
    v.movi       v4, #64
    v.add        v7, v1, v4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v4, #80
    v.add        v8, v1, v4
    v.movi       v4, #96
    v.add        v9, v1, v4
    v.movi       v4, #112
    v.add        v10, v1, v4
    v.splat      v1, s11
    v.add        v4, v1, v0
    v.add        v0, v1, v3
    v.add        v3, v1, v5
    v.add        v5, v1, v6
    v.add        v6, v1, v7
    v.add        v7, v1, v8
    v.add        v8, v1, v9
    v.add        v9, v1, v10
    v.movi       v1, #16
    v.movi       v10, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v2, v10
    v.cmp.lt     p2, v1, v10
    v.sub        v11, v10, v2
    @p1 v.sel        v12, v11, v2
    v.sub        v2, v10, v1
    @p2 v.sel        v11, v2, v1
    v.movi       v1, #15
    v.and        v2, v12, v1
    v.sub        v1, v10, v2
    @p1 v.sel        v10, v1, v2
    v.movi       v1, #384
    v.movi       v2, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v4, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v12, v2, v4
    @p1 v.sel        v13, v12, v4
    v.sub        v4, v2, v1
    @p2 v.sel        v12, v4, v1
    .li       s9, #1431655766
    v.splat      v1, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mulh.u     v4, v13, v1
    v.sub        v1, v13, v4
    v.lshr       v12, v1, v11
    v.add        v1, v4, v12
    v.movi       v4, #8
    v.lshr       v11, v1, v4
    v.movi       v1, #384
    v.mul        v4, v11, v1
    v.sub        v11, v13, v4
    v.sub        v4, v2, v11
    @p1 v.sel        v2, v4, v11
    v.movi       v4, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v0, v4
    v.cmp.lt     p2, v1, v4
    v.sub        v12, v4, v0
    @p1 v.sel        v13, v12, v0
    v.sub        v0, v4, v1
    @p2 v.sel        v12, v0, v1
    .li       s9, #1431655766
    v.splat      v0, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mulh.u     v1, v13, v0
    v.sub        v0, v13, v1
    v.lshr       v12, v0, v11
    v.add        v0, v1, v12
    v.movi       v1, #8
    v.lshr       v11, v0, v1
    v.movi       v0, #384
    v.mul        v1, v11, v0
    v.sub        v11, v13, v1
    v.sub        v1, v4, v11
    @p1 v.sel        v4, v1, v11
    v.movi       v1, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v0, v1
    v.sub        v12, v1, v3
    @p1 v.sel        v13, v12, v3
    v.sub        v3, v1, v0
    @p2 v.sel        v12, v3, v0
    .li       s9, #1431655766
    v.splat      v0, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mulh.u     v3, v13, v0
    v.sub        v0, v13, v3
    v.lshr       v12, v0, v11
    v.add        v0, v3, v12
    v.movi       v3, #8
    v.lshr       v11, v0, v3
    v.movi       v0, #384
    v.mul        v3, v11, v0
    v.sub        v11, v13, v3
    v.sub        v3, v1, v11
    @p1 v.sel        v1, v3, v11
    v.movi       v3, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v5, v3
    v.cmp.lt     p2, v0, v3
    v.sub        v12, v3, v5
    @p1 v.sel        v13, v12, v5
    v.sub        v5, v3, v0
    @p2 v.sel        v12, v5, v0
    .li       s9, #1431655766
    v.splat      v0, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mulh.u     v5, v13, v0
    v.sub        v0, v13, v5
    v.lshr       v12, v0, v11
    v.add        v0, v5, v12
    v.movi       v5, #8
    v.lshr       v11, v0, v5
    v.movi       v0, #384
    v.mul        v5, v11, v0
    v.sub        v11, v13, v5
    v.sub        v5, v3, v11
    @p1 v.sel        v3, v5, v11
    v.movi       v5, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v6, v5
    v.cmp.lt     p2, v0, v5
    v.sub        v12, v5, v6
    @p1 v.sel        v13, v12, v6
    v.sub        v6, v5, v0
    @p2 v.sel        v12, v6, v0
    .li       s9, #1431655766
    v.splat      v0, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mulh.u     v6, v13, v0
    v.sub        v0, v13, v6
    v.lshr       v12, v0, v11
    v.add        v0, v6, v12
    v.movi       v6, #8
    v.lshr       v11, v0, v6
    v.movi       v0, #384
    v.mul        v6, v11, v0
    v.sub        v11, v13, v6
    v.sub        v6, v5, v11
    @p1 v.sel        v5, v6, v11
    v.movi       v6, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v0, v6
    v.sub        v12, v6, v7
    @p1 v.sel        v13, v12, v7
    v.sub        v7, v6, v0
    @p2 v.sel        v12, v7, v0
    .li       s9, #1431655766
    v.splat      v0, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mulh.u     v7, v13, v0
    v.sub        v0, v13, v7
    v.lshr       v12, v0, v11
    v.add        v0, v7, v12
    v.movi       v7, #8
    v.lshr       v11, v0, v7
    v.movi       v0, #384
    v.mul        v7, v11, v0
    v.sub        v11, v13, v7
    v.sub        v7, v6, v11
    @p1 v.sel        v6, v7, v11
    v.movi       v7, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v8, v7
    v.cmp.lt     p2, v0, v7
    v.sub        v12, v7, v8
    @p1 v.sel        v13, v12, v8
    v.sub        v8, v7, v0
    @p2 v.sel        v12, v8, v0
    .li       s9, #1431655766
    v.splat      v0, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mulh.u     v8, v13, v0
    v.sub        v0, v13, v8
    v.lshr       v12, v0, v11
    v.add        v0, v8, v12
    v.movi       v8, #8
    v.lshr       v11, v0, v8
    v.movi       v0, #384
    v.mul        v8, v11, v0
    v.sub        v11, v13, v8
    v.sub        v8, v7, v11
    @p1 v.sel        v7, v8, v11
    v.movi       v8, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v9, v8
    v.cmp.lt     p2, v0, v8
    v.sub        v12, v8, v9
    @p1 v.sel        v13, v12, v9
    v.sub        v9, v8, v0
    @p2 v.sel        v12, v9, v0
    .li       s9, #1431655766
    v.splat      v0, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mulh.u     v9, v13, v0
    v.sub        v0, v13, v9
    v.lshr       v12, v0, v11
    v.add        v0, v9, v12
    v.movi       v9, #8
    v.lshr       v11, v0, v9
    v.movi       v0, #384
    v.mul        v9, v11, v0
    v.sub        v0, v13, v9
    v.sub        v9, v8, v0
    @p1 v.sel        v8, v9, v0
    s.movz       s9, #32
    s.movz       s12, #48
    s.movz       s13, #64
    s.movz       s14, #80
    s.movz       s15, #96
    s.movz       s16, #112
    s.movz       s17, #8
    v.movi       v0, #8
    v.mul        v9, v10, v0
    v.movi       v0, #128
    v.movi       v11, #0
    v.movi       v12, #1
    v.cmp.lt     p1, v2, v11
    v.cmp.lt     p2, v0, v11
    v.sub        v12, v11, v2
    @p1 v.sel        v13, v12, v2
    v.sub        v12, v11, v0
    @p2 v.sel        v14, v12, v0
    v.movi       v0, #7
    v.lshr       v12, v13, v0
    v.sub        v0, v11, v12
    @p1 v.sel        v11, v0, v12
    v.movi       v0, #128
    v.movi       v12, #0
    v.movi       v13, #1
    v.cmp.lt     p1, v4, v12
    v.cmp.lt     p2, v0, v12
    v.sub        v13, v12, v4
    @p1 v.sel        v14, v13, v4
    v.sub        v13, v12, v0
    @p2 v.sel        v15, v13, v0
    v.movi       v0, #7
    v.lshr       v13, v14, v0
    v.sub        v0, v12, v13
    @p1 v.sel        v12, v0, v13
    v.movi       v0, #128
    v.movi       v13, #0
    v.movi       v14, #1
    v.cmp.lt     p1, v1, v13
    v.cmp.lt     p2, v0, v13
    v.sub        v14, v13, v1
    @p1 v.sel        v15, v14, v1
    v.sub        v14, v13, v0
    @p2 v.sel        v16, v14, v0
    v.movi       v0, #7
    v.lshr       v14, v15, v0
    v.sub        v0, v13, v14
    @p1 v.sel        v13, v0, v14
    v.movi       v0, #128
    v.movi       v14, #0
    v.movi       v15, #1
    v.cmp.lt     p1, v3, v14
    v.cmp.lt     p2, v0, v14
    v.sub        v15, v14, v3
    @p1 v.sel        v16, v15, v3
    v.sub        v15, v14, v0
    @p2 v.sel        v17, v15, v0
    v.movi       v0, #7
    v.lshr       v15, v16, v0
    v.sub        v0, v14, v15
    @p1 v.sel        v14, v0, v15
    v.movi       v0, #128
    v.movi       v15, #0
    v.movi       v16, #1
    v.cmp.lt     p1, v5, v15
    v.cmp.lt     p2, v0, v15
    v.sub        v16, v15, v5
    @p1 v.sel        v17, v16, v5
    v.sub        v16, v15, v0
    @p2 v.sel        v18, v16, v0
    v.movi       v0, #7
    v.lshr       v16, v17, v0
    v.sub        v0, v15, v16
    @p1 v.sel        v15, v0, v16
    v.movi       v0, #128
    v.movi       v16, #0
    v.movi       v17, #1
    v.cmp.lt     p1, v6, v16
    v.cmp.lt     p2, v0, v16
    v.sub        v17, v16, v6
    @p1 v.sel        v18, v17, v6
    v.sub        v17, v16, v0
    @p2 v.sel        v19, v17, v0
    v.movi       v0, #7
    v.lshr       v17, v18, v0
    v.sub        v0, v16, v17
    @p1 v.sel        v16, v0, v17
    v.movi       v0, #128
    v.movi       v17, #0
    v.movi       v18, #1
    v.cmp.lt     p1, v7, v17
    v.cmp.lt     p2, v0, v17
    v.sub        v18, v17, v7
    @p1 v.sel        v19, v18, v7
    v.sub        v18, v17, v0
    @p2 v.sel        v20, v18, v0
    v.movi       v0, #7
    v.lshr       v18, v19, v0
    v.sub        v0, v17, v18
    @p1 v.sel        v17, v0, v18
    v.movi       v0, #128
    v.movi       v18, #0
    v.movi       v19, #1
    v.cmp.lt     p1, v8, v18
    v.cmp.lt     p2, v0, v18
    v.sub        v19, v18, v8
    @p1 v.sel        v20, v19, v8
    v.sub        v19, v18, v0
    @p2 v.sel        v21, v19, v0
    v.movi       v0, #7
    v.lshr       v19, v20, v0
    v.sub        v0, v18, v19
    @p1 v.sel        v18, v0, v19
    s.movz       s18, #0
    s.movz       s19, #1
    s.addi       s20, s18, #0
    s.addi       s21, s18, #0
    s.addi       s22, s18, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_1:
    s.cmp.ge     s23, s20, s17
    br.nz        s23, endfor_2
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s23, arg_base
    s.mul        s24, s20, s8
    s.ld.d       s25, [s23, #40]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s23, #1024
    s.mul        s26, s20, s7
    v.splat      v0, s23
    s.sub        s27, s23, s24
    v.splat      v19, s23
    v.splat      v20, s23
    s.add        s23, s18, s27
    s.shli       s24, s20, #2                    // element offset -> bytes (x4)
    s.shli       s28, s26, #2                    // element offset -> bytes (x4)
    v.mul        v21, v2, v0
    v.mul        v22, v4, v0
    v.mul        v23, v1, v0
    v.mul        v0, v3, v19
    v.mul        v24, v5, v19
    v.mul        v25, v6, v19
    v.mul        v19, v7, v20
    v.mul        v26, v8, v20
    v.movi       v20, #0
    s.add        s29, s4, s24                    // &arg_SA[...]
    s.add        s24, s5, s28                    // &arg_SB[...]
    s.addi       s28, s25, #0
    s.addi       s30, s25, #64
    s.addi       s31, s25, #128
    s.addi       s32, s25, #192
    s.addi       s33, s25, #256
    s.addi       s34, s25, #320
    s.addi       s35, s25, #384
    s.addi       s36, s25, #448
    v.ld.gather.w v27, [s29, v9]                 // index is in elements (ISA sec 9.1)
    v.splat      v28, s20
    v.extract    s29, v2, #0
    v.iota       v28                             // arange(0, VLEN)
    s.movz       s37, #0
    v.movi       v29, #0
    s.cmp.ge     s38, s23, s37
    v.splat      v30, s26
    v.splat      v30, s29
    v.add        v31, v30, v28
    v.sub        v30, v2, v31
    v.ld.gather.w v31, [s24, v11]                // index is in elements (ISA sec 9.1)
    v.reduce.or  s26, v30
    v.ld.gather.w v30, [s24, v12]                // index is in elements (ISA sec 9.1)
    s.cmp.eq     s39, s26, s37
    v.ld.gather.w v32, [s24, v13]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v33, [s24, v14]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v34, [s24, v15]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s24, v16]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v36, [s24, v17]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v37, [s24, v18]                // index is in elements (ISA sec 9.1)
    v.extract    s24, v4, #0
    v.splat      v38, s24
    v.add        v39, v38, v28
    v.sub        v38, v4, v39
    v.st.w       [s28, #0], v21
    v.extract    s26, v1, #0
    v.splat      v21, s26
    v.add        v39, v21, v28
    v.sub        v21, v1, v39
    v.st.w       [s30, #0], v22
    s.cmp.ge     s28, s29, s37
    s.and        s30, s39, s28
    v.reduce.or  s28, v38
    s.and        s39, s30, s38
    s.cmp.eq     s30, s28, s37
    v.st.w       [s31, #0], v23
    s.cmp.ge     s28, s24, s37
    s.and        s31, s30, s28
    v.reduce.or  s28, v21
    s.and        s30, s31, s38
    s.cmp.eq     s31, s28, s37
    v.st.w       [s32, #0], v0
    v.extract    s28, v3, #0
    v.splat      v0, s28
    v.st.w       [s33, #0], v24
    v.add        v21, v0, v28
    s.cmp.ge     s32, s26, s37
    v.sub        v0, v3, v21
    s.and        s33, s31, s32
    s.and        s31, s33, s38
    v.st.w       [s34, #0], v25
    v.reduce.or  s32, v0
    s.cmp.eq     s33, s32, s37
    v.st.w       [s35, #0], v19
    s.cmp.ge     s32, s28, s37
    s.and        s34, s33, s32
    v.st.w       [s36, #0], v26
    fence.acq_rel.device
    v.extract    s32, v5, #0
    v.extract    s33, v6, #0
    v.splat      v0, s32
    v.splat      v19, s33
    v.insert     v20, s39, #0
    v.add        v21, v0, v28
    v.add        v0, v19, v28
    v.insert     v29, s29, #0
    v.extract    s29, v7, #0
    v.sub        v19, v5, v21
    v.insert     v20, s30, #1
    v.splat      v21, s29
    v.reduce.or  s30, v19
    v.sub        v19, v6, v0
    v.insert     v29, s24, #1
    v.extract    s24, v8, #0
    v.add        v0, v21, v28
    v.insert     v20, s31, #2
    v.splat      v21, s24
    s.cmp.eq     s31, s30, s37
    s.cmp.ge     s30, s32, s37
    s.and        s35, s34, s38
    v.reduce.or  s34, v19
    s.movz       s36, #0
    v.sub        v19, v7, v0
    s.and        s37, s31, s30
    v.insert     v29, s26, #2
    v.add        v0, v21, v28
    v.insert     v20, s35, #3
    s.cmp.eq     s26, s34, s36
    s.cmp.ge     s30, s33, s36
    s.and        s31, s37, s38
    v.reduce.or  s34, v19
    v.sub        v19, v8, v0
    s.and        s35, s26, s30
    v.insert     v29, s28, #3
    v.insert     v20, s31, #4
    s.cmp.eq     s26, s34, s36
    s.cmp.ge     s28, s29, s36
    s.and        s30, s35, s38
    v.reduce.or  s31, v19
    s.and        s34, s26, s28
    v.insert     v29, s32, #4
    v.insert     v20, s30, #5
    s.cmp.eq     s26, s31, s36
    s.cmp.ge     s28, s24, s36
    s.and        s30, s34, s38
    s.and        s31, s26, s28
    v.insert     v29, s33, #5
    v.insert     v20, s30, #6
    s.and        s26, s31, s38
    v.insert     v29, s29, #6
    v.insert     v20, s26, #7
    s.add        s26, s3, s22
    s.addi       s28, s25, #512                  // TensorMap 0: W's rows for a transposed FP8 B
    .li       s29, #2147483647
    s.movz       s30, #1024
    s.movz       s31, #1
    .li       s32, #137438953488
    .li       s33, #7705171329024
    s.addi       s34, s25, #768
    s.addi       s35, s25, #1792                 // TensorMap 1: the gathered fallback B tile
    s.movz       s36, #32
    s.movz       s37, #16
    .li       s38, #68719476768
    v.insert     v29, s24, #7
    s.addi       s24, s25, #1280
    s.st.d       [s28, #0], s26
    s.addi       s26, s25, #2048                 // TensorMap 2: the gathered fallback B tile
    s.st.d       [s28, #8], s29
    v.extract    s29, v20, #0
    s.st.d       [s28, #16], s23
    s.st.d       [s28, #48], s30
    s.movz       s30, #0
    s.st.d       [s28, #56], s31
    s.st.d       [s28, #88], s32
    s.st.d       [s28, #104], s33
    fence.release.device
    td.load      d0, [s28]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.st.d       [s35, #0], s34
    s.st.d       [s35, #8], s36
    s.st.d       [s35, #16], s37
    s.st.d       [s35, #48], s37
    s.st.d       [s35, #56], s31
    s.st.d       [s35, #88], s38
    s.st.d       [s35, #104], s33
    fence.release.device
    td.load      d1, [s35]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.st.d       [s26, #0], s24
    s.st.d       [s26, #8], s36
    s.st.d       [s26, #16], s37
    s.st.d       [s26, #48], s37
    s.st.d       [s26, #56], s31
    s.st.d       [s26, #88], s38
    s.st.d       [s26, #104], s33
    fence.release.device
    td.load      d2, [s26]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s29, x8dot_done_3
    s.addi       s24, s25, #0
    s.addi       s26, s30, #0
    v.ld.w       v0, [s24, #0]
    s.add        s24, s3, s22
x8dot_row_4:
    s.addi       s28, s23, #0
    v.movi       v19, #0
    s.sub        s31, s28, s26
    s.add        s28, s24, s26
    v.splat      v21, s31
    s.shli       s31, s26, #4
    s.addi       s32, s26, #1
    v.cmp.gt     p1, v21, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s28, v0]             // index is in elements (ISA sec 9.1)
    s.add        s28, s34, s31
    v.st.b       [s28, #0], v19
    fence.acq_rel.device
    s.mov        s26, s32
    s.cmp.lt     s28, s26, s36
    br.nz        s28, x8dot_row_4
x8dot_done_3:
    v.splat      v0, s29
    v.movi       v19, #0
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s26, v29, #0
    v.extract    s28, v20, #1
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s31, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s31, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s31, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s31, s24          // predicated off still completes once (ISA sec 9A.3)
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s28, x8dot_done_5
    s.movz       s26, #0
    s.addi       s29, s25, #64
    s.addi       s30, s26, #0
    v.ld.w       v0, [s29, #0]
    s.add        s26, s3, s22
    s.addi       s29, s25, #1280
x8dot_row_6:
    s.addi       s31, s23, #0
    v.movi       v19, #0
    s.sub        s32, s31, s30
    s.add        s31, s26, s30
    v.splat      v21, s32
    s.shli       s32, s30, #4
    s.addi       s33, s30, #1
    v.cmp.gt     p1, v21, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s31, v0]             // index is in elements (ISA sec 9.1)
    s.add        s31, s29, s32
    s.movz       s32, #32
    v.st.b       [s31, #0], v19
    fence.acq_rel.device
    s.mov        s30, s33
    s.cmp.lt     s31, s30, s32
    br.nz        s31, x8dot_row_6
x8dot_done_5:
    s.movz       s26, #1024
    s.movz       s29, #0
    v.splat      v0, s26
    s.add        s26, s29, s27                   // the tile origin
    v.splat      v19, s28
    v.mul        v21, v10, v0
    v.movi       v0, #0
    v.iota       v22                             // arange(0, VLEN)
    v.extract    s28, v21, #0
    v.splat      v23, s26
    s.add        s26, s28, s21
    mb.arm       s28, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s30, v29, #1
    s.add        s31, s2, s26
    v.cmp.ne     p1, v19, v0
    v.cmp.eq     p2, v19, v0
    v.cmp.lt     p3, v22, v23
    s.mov        s32, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s32, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s28          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s31, #0]
    v.extract    s26, v21, #1
    s.addi       s29, s25, #2304                 // 512 bytes of repack scratch
    s.add        s30, s26, s21
    s.addi       s26, s29, #0
    s.add        s31, s2, s30
    v.extract    s30, v21, #2
    s.addi       s32, s29, #32
    s.add        s33, s30, s21
    v.extract    s30, v21, #3
    s.add        s34, s2, s33
    s.add        s33, s30, s21
    v.st.b       [s26, #0], v0
    s.addi       s26, s29, #64
    s.add        s30, s2, s33
    v.extract    s33, v21, #4
    s.addi       s35, s29, #96
    s.add        s36, s33, s21
    s.add        s33, s2, s36
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s31, #0]
    v.extract    s31, v21, #5
    s.add        s36, s31, s21
    s.add        s31, s2, s36
    v.st.b       [s32, #0], v0
    s.addi       s32, s29, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s34, #0]
    v.extract    s34, v21, #6
    s.add        s36, s34, s21
    s.add        s34, s2, s36
    v.st.b       [s26, #0], v0
    s.addi       s26, s29, #160
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s30, #0]
    v.extract    s30, v21, #7
    s.add        s36, s30, s21
    s.add        s30, s2, s36
    v.st.b       [s35, #0], v0
    s.addi       s35, s29, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s33, #0]
    v.extract    s33, v21, #8
    s.add        s36, s33, s21
    s.add        s33, s2, s36
    v.st.b       [s32, #0], v0
    s.addi       s32, s29, #224
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s31, #0]
    v.extract    s31, v21, #9
    s.add        s36, s31, s21
    s.add        s31, s2, s36
    v.st.b       [s26, #0], v0
    s.addi       s26, s29, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s34, #0]
    v.extract    s34, v21, #10
    s.add        s36, s34, s21
    s.add        s34, s2, s36
    v.st.b       [s35, #0], v0
    s.addi       s35, s29, #288
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s30, #0]
    v.extract    s30, v21, #11
    s.add        s36, s30, s21
    s.add        s30, s2, s36
    v.st.b       [s32, #0], v0
    s.addi       s32, s29, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s33, #0]
    v.extract    s33, v21, #12
    s.add        s36, s33, s21
    s.add        s33, s2, s36
    v.st.b       [s26, #0], v0
    s.addi       s26, s29, #352
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s31, #0]
    v.extract    s31, v21, #13
    s.add        s36, s31, s21
    s.add        s31, s2, s36
    v.st.b       [s35, #0], v0
    s.addi       s35, s29, #384
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s34, #0]
    v.extract    s34, v21, #14
    s.add        s36, s34, s21
    s.add        s34, s2, s36
    v.st.b       [s32, #0], v0
    s.addi       s32, s29, #416
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s30, #0]
    v.extract    s30, v21, #15
    s.add        s36, s30, s21
    s.add        s30, s2, s36
    v.st.b       [s26, #0], v0
    s.addi       s26, s29, #448
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s33, #0]
    s.movz       s33, #0
    v.st.b       [s35, #0], v0
    s.add        s35, s33, s1                    // the tile origin
    s.add        s36, s33, s27                   // the tile origin
    v.splat      v0, s35
    v.extract    s33, v21, #0
    v.splat      v19, s36
    s.add        s35, s33, s21
    v.add        v23, v22, v0
    s.addi       s33, s35, #16
    s.addi       s35, s29, #480
    s.add        s36, s2, s33
    v.cmp.lt     p1, v23, v19
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s31, #0]
    v.extract    s31, v21, #1
    s.add        s33, s31, s21
    s.addi       s31, s33, #16
    s.add        s33, s2, s31
    v.st.b       [s32, #0], v0
    s.addi       s31, s29, #16
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s34, #0]
    v.extract    s32, v21, #2
    s.add        s34, s32, s21
    s.addi       s32, s34, #16
    s.add        s34, s2, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s29, #48
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s30, #0]
    v.extract    s30, v21, #3
    s.add        s32, s30, s21
    s.addi       s30, s32, #16
    s.add        s32, s2, s30
    v.st.b       [s35, #0], v0
    s.addi       s30, s29, #80
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s36, #0]
    v.extract    s35, v21, #4
    s.add        s36, s35, s21
    s.addi       s35, s36, #16
    s.add        s36, s2, s35
    v.st.b       [s31, #0], v0
    s.addi       s31, s29, #112
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s33, #0]
    v.extract    s33, v21, #5
    s.add        s35, s33, s21
    s.addi       s33, s35, #16
    s.add        s35, s2, s33
    v.st.b       [s26, #0], v0
    s.addi       s26, s29, #144
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s34, #0]
    v.extract    s33, v21, #6
    s.add        s34, s33, s21
    s.addi       s33, s34, #16
    s.add        s34, s2, s33
    v.st.b       [s30, #0], v0
    s.addi       s30, s29, #176
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s32, #0]
    v.extract    s32, v21, #7
    s.add        s33, s32, s21
    s.addi       s32, s33, #16
    s.add        s33, s2, s32
    v.st.b       [s31, #0], v0
    s.addi       s31, s29, #208
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s36, #0]
    v.extract    s32, v21, #8
    s.add        s36, s32, s21
    s.addi       s32, s36, #16
    s.add        s36, s2, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s29, #240
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s35, #0]
    v.extract    s32, v21, #9
    s.add        s35, s32, s21
    s.addi       s32, s35, #16
    s.add        s35, s2, s32
    v.st.b       [s30, #0], v0
    s.addi       s30, s29, #272
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s34, #0]
    v.extract    s32, v21, #10
    s.add        s34, s32, s21
    s.addi       s32, s34, #16
    s.add        s34, s2, s32
    v.st.b       [s31, #0], v0
    s.addi       s31, s29, #304
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s33, #0]
    v.extract    s32, v21, #11
    s.add        s33, s32, s21
    s.addi       s32, s33, #16
    s.add        s33, s2, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s29, #336
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s36, #0]
    v.extract    s32, v21, #12
    s.add        s36, s32, s21
    s.addi       s32, s36, #16
    s.add        s36, s2, s32
    v.st.b       [s30, #0], v0
    s.addi       s30, s29, #368
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s35, #0]
    v.extract    s32, v21, #13
    s.add        s35, s32, s21
    s.addi       s32, s35, #16
    s.add        s35, s2, s32
    v.st.b       [s31, #0], v0
    s.addi       s31, s29, #400
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s34, #0]
    v.extract    s32, v21, #14
    s.add        s34, s32, s21
    s.addi       s32, s34, #16
    s.add        s34, s2, s32
    v.st.b       [s26, #0], v0
    s.addi       s26, s29, #432
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s33, #0]
    v.extract    s32, v21, #15
    s.add        s33, s32, s21
    s.addi       s32, s33, #16
    s.add        s33, s2, s32
    v.st.b       [s30, #0], v0
    s.addi       s30, s29, #464
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s36, #0]
    s.addi       s32, s29, #496
    v.st.b       [s31, #0], v0
    s.addi       s31, s29, #64
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s35, #0]
    s.addi       s35, s29, #128
    v.st.b       [s26, #0], v0
    s.addi       s26, s29, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s34, #0]
    s.addi       s34, s29, #256
    v.st.b       [s30, #0], v0
    s.addi       s30, s29, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s33, #0]
    s.addi       s33, s29, #384
    v.st.b       [s32, #0], v0
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s32, s29, #448
    v.ld.w       v0, [s29, #0]
    v.extract    s29, v20, #2
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s31, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s35, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s26, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s34, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s30, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s33, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s32, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.wait      s24
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s26
    mb.wait      s26
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s29, x8dot_done_7
    s.movz       s30, #0
    s.addi       s31, s25, #128
    s.addi       s32, s30, #0
    v.ld.w       v0, [s31, #0]
    s.add        s30, s3, s22
    s.addi       s31, s25, #768
x8dot_row_8:
    s.addi       s33, s23, #0
    v.movi       v19, #0
    s.sub        s34, s33, s32
    s.add        s33, s30, s32
    v.splat      v23, s34
    s.shli       s34, s32, #4
    s.addi       s35, s32, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s33, v0]             // index is in elements (ISA sec 9.1)
    s.add        s33, s31, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v19
    fence.acq_rel.device
    s.mov        s32, s35
    s.cmp.lt     s33, s32, s34
    br.nz        s33, x8dot_row_8
x8dot_done_7:
    v.splat      v0, s29
    v.movi       v19, #0
    mb.arm       s29, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    v.extract    s31, v29, #2
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s32, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s32, s29            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s32, s29          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s31, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s32, v20, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s31
    mb.wait      s31
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s32, x8dot_done_9
    s.addi       s33, s25, #192
    s.addi       s34, s30, #0
    v.ld.w       v0, [s33, #0]
    s.add        s33, s3, s22
    s.addi       s35, s25, #1280
x8dot_row_10:
    s.addi       s36, s23, #0
    v.movi       v19, #0
    s.sub        s37, s36, s34
    s.add        s36, s33, s34
    v.splat      v23, s37
    s.shli       s37, s34, #4
    s.addi       s38, s34, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s36, v0]             // index is in elements (ISA sec 9.1)
    s.add        s36, s35, s37
    s.movz       s37, #32
    v.st.b       [s36, #0], v19
    fence.acq_rel.device
    s.mov        s34, s38
    s.cmp.lt     s36, s34, s37
    br.nz        s36, x8dot_row_10
x8dot_done_9:
    v.splat      v0, s32
    v.movi       v19, #0
    mb.arm       s32, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s33, v29, #3
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s34, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s34, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s29
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v20, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s33
    mb.wait      s33
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s34, x8dot_done_11
    s.addi       s35, s25, #256
    s.addi       s36, s30, #0
    v.ld.w       v0, [s35, #0]
    s.add        s30, s3, s22
    s.addi       s35, s25, #768
x8dot_row_12:
    s.addi       s37, s23, #0
    v.movi       v19, #0
    s.sub        s38, s37, s36
    s.add        s37, s30, s36
    v.splat      v23, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s37, v0]             // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v19
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_12
x8dot_done_11:
    v.splat      v0, s34
    v.movi       v19, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.extract    s35, v29, #4
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s36, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s36, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s35, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v20, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s35
    mb.wait      s35
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s36, x8dot_done_13
    s.addi       s37, s25, #320
    s.addi       s38, s34, #0
    v.ld.w       v0, [s37, #0]
    s.add        s37, s3, s22
    s.addi       s39, s25, #1280
x8dot_row_14:
    s.addi       s40, s23, #0
    v.movi       v19, #0
    s.sub        s41, s40, s38
    s.add        s40, s37, s38
    v.splat      v23, s41
    s.shli       s41, s38, #4
    s.addi       s42, s38, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s40, v0]             // index is in elements (ISA sec 9.1)
    s.add        s40, s39, s41
    s.movz       s41, #32
    v.st.b       [s40, #0], v19
    fence.acq_rel.device
    s.mov        s38, s42
    s.cmp.lt     s40, s38, s41
    br.nz        s40, x8dot_row_14
x8dot_done_13:
    v.splat      v0, s36
    v.movi       v19, #0
    mb.arm       s36, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s37, v29, #5
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v20, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s37
    mb.wait      s37
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s38, x8dot_done_15
    s.addi       s39, s25, #384
    s.addi       s40, s34, #0
    v.ld.w       v0, [s39, #0]
    s.add        s34, s3, s22
    s.addi       s39, s25, #768
x8dot_row_16:
    s.addi       s41, s23, #0
    v.movi       v19, #0
    s.sub        s42, s41, s40
    s.add        s41, s34, s40
    v.splat      v23, s42
    s.shli       s42, s40, #4
    s.addi       s43, s40, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s41, v0]             // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v19
    fence.acq_rel.device
    s.mov        s40, s43
    s.cmp.lt     s41, s40, s42
    br.nz        s41, x8dot_row_16
x8dot_done_15:
    v.splat      v0, s38
    v.movi       v19, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s39, v29, #6
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s40, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s40, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s39, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v20, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s39
    mb.wait      s39
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s40, x8dot_done_17
    s.addi       s41, s25, #448
    s.addi       s42, s38, #0
    v.ld.w       v0, [s41, #0]
    s.add        s41, s3, s22
    s.addi       s43, s25, #1280
x8dot_row_18:
    s.addi       s44, s23, #0
    v.movi       v19, #0
    s.sub        s45, s44, s42
    s.add        s44, s41, s42
    v.splat      v23, s45
    s.shli       s45, s42, #4
    s.addi       s46, s42, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s44, v0]             // index is in elements (ISA sec 9.1)
    s.add        s44, s43, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v19
    fence.acq_rel.device
    s.mov        s42, s46
    s.cmp.lt     s44, s42, s45
    br.nz        s44, x8dot_row_18
x8dot_done_17:
    v.splat      v0, s40
    v.movi       v19, #0
    mb.arm       s40, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s41, v29, #7
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s42, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v20, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s41
    mb.wait      s41
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s42, x8dot_done_19
    s.addi       s43, s25, #0
    s.add        s44, s3, s22
    s.addi       s45, s38, #0
    v.ld.w       v0, [s43, #0]
    s.addi       s38, s44, #32
    s.addi       s43, s25, #768
x8dot_row_20:
    s.addi       s44, s23, #-32
    v.movi       v19, #0
    s.sub        s46, s44, s45
    s.add        s44, s38, s45
    v.splat      v23, s46
    s.shli       s46, s45, #4
    s.addi       s47, s45, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s44, v0]             // index is in elements (ISA sec 9.1)
    s.add        s44, s43, s46
    s.movz       s46, #32
    v.st.b       [s44, #0], v19
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s44, s45, s46
    br.nz        s44, x8dot_row_20
x8dot_done_19:
    v.splat      v0, s42
    v.movi       v19, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.extract    s43, v29, #0
    s.movz       s44, #32
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s45, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s45, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s43, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v20, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s43
    mb.wait      s43
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s45, x8dot_done_21
    s.addi       s46, s25, #64
    s.add        s47, s3, s22
    s.addi       s48, s42, #0
    v.ld.w       v0, [s46, #0]
    s.addi       s46, s47, #32
    s.addi       s47, s25, #1280
x8dot_row_22:
    s.addi       s49, s23, #-32
    v.movi       v19, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v23, s50
    s.shli       s50, s48, #4
    s.addi       s51, s48, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s49, v0]             // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    v.st.b       [s49, #0], v19
    fence.acq_rel.device
    s.mov        s48, s51
    s.cmp.lt     s49, s48, s44
    br.nz        s49, x8dot_row_22
x8dot_done_21:
    s.add        s46, s42, s9                    // the tile origin
    v.extract    s47, v21, #0
    v.splat      v0, s46
    s.add        s46, s47, s21
    s.add        s47, s42, s27                   // the tile origin
    v.splat      v19, s45
    v.movi       v23, #0
    s.addi       s45, s46, #32
    v.add        v24, v22, v0
    v.splat      v0, s47
    mb.arm       s46, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s47, v29, #1
    s.add        s48, s2, s45
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    v.cmp.lt     p3, v24, v0
    s.mov        s49, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s49, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s46          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s48, #0]
    v.extract    s42, v21, #1
    s.addi       s44, s25, #2816                 // 512 bytes of repack scratch
    s.add        s45, s42, s21
    s.addi       s42, s44, #0
    s.addi       s47, s45, #32
    v.extract    s45, v21, #2
    s.add        s48, s2, s47
    s.add        s47, s45, s21
    s.addi       s45, s44, #32
    s.addi       s49, s47, #32
    v.extract    s47, v21, #3
    v.st.b       [s42, #0], v0
    s.add        s42, s2, s49
    s.add        s49, s47, s21
    s.addi       s47, s44, #64
    s.addi       s50, s49, #32
    v.extract    s49, v21, #4
    s.add        s51, s2, s50
    s.add        s50, s49, s21
    s.addi       s49, s44, #96
    s.addi       s52, s50, #32
    s.add        s50, s2, s52
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s48, #0]
    v.extract    s48, v21, #5
    s.add        s52, s48, s21
    s.addi       s48, s52, #32
    s.add        s52, s2, s48
    v.st.b       [s45, #0], v0
    s.addi       s45, s44, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s42, #0]
    v.extract    s42, v21, #6
    s.add        s48, s42, s21
    s.addi       s42, s48, #32
    s.add        s48, s2, s42
    v.st.b       [s47, #0], v0
    s.addi       s42, s44, #160
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s51, #0]
    v.extract    s47, v21, #7
    s.add        s51, s47, s21
    s.addi       s47, s51, #32
    s.add        s51, s2, s47
    v.st.b       [s49, #0], v0
    s.addi       s47, s44, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s50, #0]
    v.extract    s49, v21, #8
    s.add        s50, s49, s21
    s.addi       s49, s50, #32
    s.add        s50, s2, s49
    v.st.b       [s45, #0], v0
    s.addi       s45, s44, #224
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s52, #0]
    v.extract    s49, v21, #9
    s.add        s52, s49, s21
    s.addi       s49, s52, #32
    s.add        s52, s2, s49
    v.st.b       [s42, #0], v0
    s.addi       s42, s44, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s48, #0]
    v.extract    s48, v21, #10
    s.add        s49, s48, s21
    s.addi       s48, s49, #32
    s.add        s49, s2, s48
    v.st.b       [s47, #0], v0
    s.addi       s47, s44, #288
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s51, #0]
    v.extract    s48, v21, #11
    s.add        s51, s48, s21
    s.addi       s48, s51, #32
    s.add        s51, s2, s48
    v.st.b       [s45, #0], v0
    s.addi       s45, s44, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s50, #0]
    v.extract    s48, v21, #12
    s.add        s50, s48, s21
    s.addi       s48, s50, #32
    s.add        s50, s2, s48
    v.st.b       [s42, #0], v0
    s.addi       s42, s44, #352
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s52, #0]
    v.extract    s48, v21, #13
    s.add        s52, s48, s21
    s.addi       s48, s52, #32
    s.add        s52, s2, s48
    v.st.b       [s47, #0], v0
    s.addi       s47, s44, #384
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s49, #0]
    v.extract    s48, v21, #14
    s.add        s49, s48, s21
    s.addi       s48, s49, #32
    s.add        s49, s2, s48
    v.st.b       [s45, #0], v0
    s.addi       s45, s44, #416
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s51, #0]
    v.extract    s48, v21, #15
    s.add        s51, s48, s21
    s.addi       s48, s51, #32
    s.add        s51, s2, s48
    v.st.b       [s42, #0], v0
    s.addi       s42, s44, #448
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s50, #0]
    s.movz       s48, #0
    v.st.b       [s47, #0], v0
    s.add        s47, s48, s12                   // the tile origin
    s.add        s50, s48, s27                   // the tile origin
    v.splat      v0, s47
    v.extract    s47, v21, #0
    v.splat      v19, s50
    s.add        s48, s47, s21
    v.add        v23, v22, v0
    s.addi       s47, s48, #48
    s.addi       s48, s44, #480
    s.add        s50, s2, s47
    v.cmp.lt     p1, v23, v19
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s52, #0]
    v.extract    s47, v21, #1
    s.add        s52, s47, s21
    s.addi       s47, s52, #48
    s.add        s52, s2, s47
    v.st.b       [s45, #0], v0
    s.addi       s45, s44, #16
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s49, #0]
    v.extract    s47, v21, #2
    s.add        s49, s47, s21
    s.addi       s47, s49, #48
    s.add        s49, s2, s47
    v.st.b       [s42, #0], v0
    s.addi       s42, s44, #48
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s51, #0]
    v.extract    s47, v21, #3
    s.add        s51, s47, s21
    s.addi       s47, s51, #48
    s.add        s51, s2, s47
    v.st.b       [s48, #0], v0
    s.addi       s47, s44, #80
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s50, #0]
    v.extract    s48, v21, #4
    s.add        s50, s48, s21
    s.addi       s48, s50, #48
    s.add        s50, s2, s48
    v.st.b       [s45, #0], v0
    s.addi       s45, s44, #112
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s52, #0]
    v.extract    s48, v21, #5
    s.add        s52, s48, s21
    s.addi       s48, s52, #48
    s.add        s52, s2, s48
    v.st.b       [s42, #0], v0
    s.addi       s42, s44, #144
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s49, #0]
    v.extract    s48, v21, #6
    s.add        s49, s48, s21
    s.addi       s48, s49, #48
    s.add        s49, s2, s48
    v.st.b       [s47, #0], v0
    s.addi       s47, s44, #176
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s51, #0]
    v.extract    s48, v21, #7
    s.add        s51, s48, s21
    s.addi       s48, s51, #48
    s.add        s51, s2, s48
    v.st.b       [s45, #0], v0
    s.addi       s45, s44, #208
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s50, #0]
    v.extract    s48, v21, #8
    s.add        s50, s48, s21
    s.addi       s48, s50, #48
    s.add        s50, s2, s48
    v.st.b       [s42, #0], v0
    s.addi       s42, s44, #240
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s52, #0]
    v.extract    s48, v21, #9
    s.add        s52, s48, s21
    s.addi       s48, s52, #48
    s.add        s52, s2, s48
    v.st.b       [s47, #0], v0
    s.addi       s47, s44, #272
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s49, #0]
    v.extract    s48, v21, #10
    s.add        s49, s48, s21
    s.addi       s48, s49, #48
    s.add        s49, s2, s48
    v.st.b       [s45, #0], v0
    s.addi       s45, s44, #304
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s51, #0]
    v.extract    s48, v21, #11
    s.add        s51, s48, s21
    s.addi       s48, s51, #48
    s.add        s51, s2, s48
    v.st.b       [s42, #0], v0
    s.addi       s42, s44, #336
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s50, #0]
    v.extract    s48, v21, #12
    s.add        s50, s48, s21
    s.addi       s48, s50, #48
    s.add        s50, s2, s48
    v.st.b       [s47, #0], v0
    s.addi       s47, s44, #368
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s52, #0]
    v.extract    s48, v21, #13
    s.add        s52, s48, s21
    s.addi       s48, s52, #48
    s.add        s52, s2, s48
    v.st.b       [s45, #0], v0
    s.addi       s45, s44, #400
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s49, #0]
    v.extract    s48, v21, #14
    s.add        s49, s48, s21
    s.addi       s48, s49, #48
    s.add        s49, s2, s48
    v.st.b       [s42, #0], v0
    s.addi       s42, s44, #432
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s51, #0]
    v.extract    s48, v21, #15
    s.add        s51, s48, s21
    s.addi       s48, s51, #48
    s.add        s51, s2, s48
    v.st.b       [s47, #0], v0
    s.addi       s47, s44, #464
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s50, #0]
    s.addi       s48, s44, #496
    v.st.b       [s45, #0], v0
    s.addi       s45, s44, #64
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s52, #0]
    s.addi       s50, s44, #128
    v.st.b       [s42, #0], v0
    s.addi       s42, s44, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s49, #0]
    s.addi       s49, s44, #256
    v.st.b       [s47, #0], v0
    s.addi       s47, s44, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s51, #0]
    s.addi       s51, s44, #384
    v.st.b       [s48, #0], v0
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s48, s44, #448
    v.ld.w       v0, [s44, #0]
    v.extract    s44, v20, #2
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s45, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s50, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s42, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s49, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s47, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s51, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s48, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.wait      s38
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s42
    mb.wait      s42
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s44, x8dot_done_23
    s.movz       s45, #0
    s.addi       s47, s25, #128
    s.add        s48, s3, s22
    s.addi       s49, s45, #0
    v.ld.w       v0, [s47, #0]
    s.addi       s45, s48, #32
    s.addi       s47, s25, #768
x8dot_row_24:
    s.addi       s48, s23, #-32
    v.movi       v19, #0
    s.sub        s50, s48, s49
    s.add        s48, s45, s49
    v.splat      v23, s50
    s.shli       s50, s49, #4
    s.addi       s51, s49, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s48, v0]             // index is in elements (ISA sec 9.1)
    s.add        s48, s47, s50
    s.movz       s50, #32
    v.st.b       [s48, #0], v19
    fence.acq_rel.device
    s.mov        s49, s51
    s.cmp.lt     s48, s49, s50
    br.nz        s48, x8dot_row_24
x8dot_done_23:
    v.splat      v0, s44
    v.movi       v19, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    v.extract    s47, v29, #2
    s.movz       s48, #32
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s49, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s49, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s47, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v20, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s47
    mb.wait      s47
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s49, x8dot_done_25
    s.addi       s50, s25, #192
    s.add        s51, s3, s22
    s.addi       s52, s45, #0
    v.ld.w       v0, [s50, #0]
    s.addi       s50, s51, #32
    s.addi       s51, s25, #1280
x8dot_row_26:
    s.addi       s53, s23, #-32
    v.movi       v19, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v23, s54
    s.shli       s54, s52, #4
    s.addi       s55, s52, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s53, v0]             // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    v.st.b       [s53, #0], v19
    fence.acq_rel.device
    s.mov        s52, s55
    s.cmp.lt     s53, s52, s48
    br.nz        s53, x8dot_row_26
x8dot_done_25:
    v.splat      v0, s49
    v.movi       v19, #0
    mb.arm       s49, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s50, v29, #3
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s51, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s51, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v20, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s48
    mb.wait      s48
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s50, x8dot_done_27
    s.addi       s51, s25, #256
    s.add        s52, s3, s22
    s.addi       s53, s45, #0
    v.ld.w       v0, [s51, #0]
    s.addi       s45, s52, #32
    s.addi       s51, s25, #768
x8dot_row_28:
    s.addi       s52, s23, #-32
    v.movi       v19, #0
    s.sub        s54, s52, s53
    s.add        s52, s45, s53
    v.splat      v23, s54
    s.shli       s54, s53, #4
    s.addi       s55, s53, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s52, v0]             // index is in elements (ISA sec 9.1)
    s.add        s52, s51, s54
    s.movz       s54, #32
    v.st.b       [s52, #0], v19
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s52, s53, s54
    br.nz        s52, x8dot_row_28
x8dot_done_27:
    v.splat      v0, s50
    v.movi       v19, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.extract    s51, v29, #4
    s.movz       s52, #32
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s53, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s53, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s53, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s51, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v20, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s51
    mb.wait      s51
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s53, x8dot_done_29
    s.addi       s54, s25, #320
    s.add        s55, s3, s22
    s.addi       s56, s50, #0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s55, #32
    s.addi       s55, s25, #1280
x8dot_row_30:
    s.addi       s57, s23, #-32
    v.movi       v19, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v23, s58
    s.shli       s58, s56, #4
    s.addi       s59, s56, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s57, v0]             // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    v.st.b       [s57, #0], v19
    fence.acq_rel.device
    s.mov        s56, s59
    s.cmp.lt     s57, s56, s52
    br.nz        s57, x8dot_row_30
x8dot_done_29:
    v.splat      v0, s53
    v.movi       v19, #0
    mb.arm       s53, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s54, v29, #5
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s55, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s55, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v20, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s52
    mb.wait      s52
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s54, x8dot_done_31
    s.addi       s55, s25, #384
    s.add        s56, s3, s22
    s.addi       s57, s50, #0
    v.ld.w       v0, [s55, #0]
    s.addi       s50, s56, #32
    s.addi       s55, s25, #768
x8dot_row_32:
    s.addi       s56, s23, #-32
    v.movi       v19, #0
    s.sub        s58, s56, s57
    s.add        s56, s50, s57
    v.splat      v23, s58
    s.shli       s58, s57, #4
    s.addi       s59, s57, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s56, v0]             // index is in elements (ISA sec 9.1)
    s.add        s56, s55, s58
    s.movz       s58, #32
    v.st.b       [s56, #0], v19
    fence.acq_rel.device
    s.mov        s57, s59
    s.cmp.lt     s56, s57, s58
    br.nz        s56, x8dot_row_32
x8dot_done_31:
    v.splat      v0, s54
    v.movi       v19, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    v.extract    s55, v29, #6
    s.movz       s56, #32
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s57, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s57, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s57, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s55, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s57, v20, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s55
    mb.wait      s55
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s57, x8dot_done_33
    s.addi       s58, s25, #448
    s.add        s59, s3, s22
    s.addi       s60, s54, #0
    v.ld.w       v0, [s58, #0]
    s.addi       s58, s59, #32
    s.addi       s59, s25, #1280
x8dot_row_34:
    s.addi       s24, s23, #-32
    v.movi       v19, #0
    s.sub        s26, s24, s60
    s.add        s24, s58, s60
    v.splat      v23, s26
    s.shli       s26, s60, #4
    s.addi       s28, s60, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s24, v0]             // index is in elements (ISA sec 9.1)
    s.add        s24, s59, s26
    v.st.b       [s24, #0], v19
    fence.acq_rel.device
    s.mov        s60, s28
    s.cmp.lt     s24, s60, s56
    br.nz        s24, x8dot_row_34
x8dot_done_33:
    v.splat      v0, s57
    v.movi       v19, #0
    mb.arm       s24, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s26, v29, #7
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s28, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s28, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s28, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s28, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s28, v20, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s26
    mb.wait      s26
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s28, x8dot_done_35
    s.addi       s29, s25, #0
    s.add        s30, s3, s22
    s.addi       s31, s54, #0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s30, #64
    s.addi       s30, s25, #768
x8dot_row_36:
    s.addi       s32, s23, #-64
    v.movi       v19, #0
    s.sub        s33, s32, s31
    s.add        s32, s29, s31
    v.splat      v23, s33
    s.shli       s33, s31, #4
    s.addi       s34, s31, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s32, v0]             // index is in elements (ISA sec 9.1)
    s.add        s32, s30, s33
    s.movz       s33, #32
    v.st.b       [s32, #0], v19
    fence.acq_rel.device
    s.mov        s31, s34
    s.cmp.lt     s32, s31, s33
    br.nz        s32, x8dot_row_36
x8dot_done_35:
    v.splat      v0, s28
    v.movi       v19, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    v.extract    s30, v29, #0
    s.movz       s31, #64
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s32, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s32, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s32, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    mb.arm       s30, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s32, v20, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s30
    mb.wait      s30
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s32, x8dot_done_37
    s.addi       s33, s25, #64
    s.add        s34, s3, s22
    s.addi       s35, s29, #0
    v.ld.w       v0, [s33, #0]
    s.addi       s33, s34, #64
    s.addi       s34, s25, #1280
x8dot_row_38:
    s.addi       s36, s23, #-64
    v.movi       v19, #0
    s.sub        s37, s36, s35
    s.add        s36, s33, s35
    v.splat      v23, s37
    s.shli       s37, s35, #4
    s.addi       s38, s35, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s36, v0]             // index is in elements (ISA sec 9.1)
    s.add        s36, s34, s37
    s.movz       s37, #32
    v.st.b       [s36, #0], v19
    fence.acq_rel.device
    s.mov        s35, s38
    s.cmp.lt     s36, s35, s37
    br.nz        s36, x8dot_row_38
x8dot_done_37:
    s.add        s33, s29, s13                   // the tile origin
    v.extract    s34, v21, #0
    v.splat      v0, s33
    s.add        s33, s34, s21
    s.add        s34, s29, s27                   // the tile origin
    v.splat      v19, s32
    v.movi       v23, #0
    s.addi       s32, s33, #64
    v.add        v24, v22, v0
    v.splat      v0, s34
    mb.arm       s33, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s34, v29, #1
    s.add        s35, s2, s32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    v.cmp.lt     p3, v24, v0
    s.mov        s36, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s36, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s33          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s35, #0]
    v.extract    s29, v21, #1
    s.addi       s31, s25, #3328                 // 512 bytes of repack scratch
    s.add        s32, s29, s21
    s.addi       s29, s31, #0
    s.addi       s34, s32, #64
    v.extract    s32, v21, #2
    s.add        s35, s2, s34
    s.add        s34, s32, s21
    s.addi       s32, s31, #32
    s.addi       s36, s34, #64
    v.extract    s34, v21, #3
    v.st.b       [s29, #0], v0
    s.add        s29, s2, s36
    s.add        s36, s34, s21
    s.addi       s34, s31, #64
    s.addi       s37, s36, #64
    v.extract    s36, v21, #4
    s.add        s38, s2, s37
    s.add        s37, s36, s21
    s.addi       s36, s31, #96
    s.addi       s39, s37, #64
    s.add        s37, s2, s39
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s35, #0]
    v.extract    s35, v21, #5
    s.add        s39, s35, s21
    s.addi       s35, s39, #64
    s.add        s39, s2, s35
    v.st.b       [s32, #0], v0
    s.addi       s32, s31, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s29, #0]
    v.extract    s29, v21, #6
    s.add        s35, s29, s21
    s.addi       s29, s35, #64
    s.add        s35, s2, s29
    v.st.b       [s34, #0], v0
    s.addi       s29, s31, #160
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s38, #0]
    v.extract    s34, v21, #7
    s.add        s38, s34, s21
    s.addi       s34, s38, #64
    s.add        s38, s2, s34
    v.st.b       [s36, #0], v0
    s.addi       s34, s31, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s37, #0]
    v.extract    s36, v21, #8
    s.add        s37, s36, s21
    s.addi       s36, s37, #64
    s.add        s37, s2, s36
    v.st.b       [s32, #0], v0
    s.addi       s32, s31, #224
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s39, #0]
    v.extract    s36, v21, #9
    s.add        s39, s36, s21
    s.addi       s36, s39, #64
    s.add        s39, s2, s36
    v.st.b       [s29, #0], v0
    s.addi       s29, s31, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s35, #0]
    v.extract    s35, v21, #10
    s.add        s36, s35, s21
    s.addi       s35, s36, #64
    s.add        s36, s2, s35
    v.st.b       [s34, #0], v0
    s.addi       s34, s31, #288
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s38, #0]
    v.extract    s35, v21, #11
    s.add        s38, s35, s21
    s.addi       s35, s38, #64
    s.add        s38, s2, s35
    v.st.b       [s32, #0], v0
    s.addi       s32, s31, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s37, #0]
    v.extract    s35, v21, #12
    s.add        s37, s35, s21
    s.addi       s35, s37, #64
    s.add        s37, s2, s35
    v.st.b       [s29, #0], v0
    s.addi       s29, s31, #352
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s39, #0]
    v.extract    s35, v21, #13
    s.add        s39, s35, s21
    s.addi       s35, s39, #64
    s.add        s39, s2, s35
    v.st.b       [s34, #0], v0
    s.addi       s34, s31, #384
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s36, #0]
    v.extract    s35, v21, #14
    s.add        s36, s35, s21
    s.addi       s35, s36, #64
    s.add        s36, s2, s35
    v.st.b       [s32, #0], v0
    s.addi       s32, s31, #416
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s38, #0]
    v.extract    s35, v21, #15
    s.add        s38, s35, s21
    s.addi       s35, s38, #64
    s.add        s38, s2, s35
    v.st.b       [s29, #0], v0
    s.addi       s29, s31, #448
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s37, #0]
    s.movz       s35, #0
    v.st.b       [s34, #0], v0
    s.add        s34, s35, s14                   // the tile origin
    s.add        s37, s35, s27                   // the tile origin
    v.splat      v0, s34
    v.extract    s34, v21, #0
    v.splat      v19, s37
    s.add        s35, s34, s21
    v.add        v23, v22, v0
    s.addi       s34, s35, #80
    s.addi       s35, s31, #480
    s.add        s37, s2, s34
    v.cmp.lt     p1, v23, v19
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s39, #0]
    v.extract    s34, v21, #1
    s.add        s39, s34, s21
    s.addi       s34, s39, #80
    s.add        s39, s2, s34
    v.st.b       [s32, #0], v0
    s.addi       s32, s31, #16
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s36, #0]
    v.extract    s34, v21, #2
    s.add        s36, s34, s21
    s.addi       s34, s36, #80
    s.add        s36, s2, s34
    v.st.b       [s29, #0], v0
    s.addi       s29, s31, #48
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s38, #0]
    v.extract    s34, v21, #3
    s.add        s38, s34, s21
    s.addi       s34, s38, #80
    s.add        s38, s2, s34
    v.st.b       [s35, #0], v0
    s.addi       s34, s31, #80
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s37, #0]
    v.extract    s35, v21, #4
    s.add        s37, s35, s21
    s.addi       s35, s37, #80
    s.add        s37, s2, s35
    v.st.b       [s32, #0], v0
    s.addi       s32, s31, #112
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    v.extract    s35, v21, #5
    s.add        s39, s35, s21
    s.addi       s35, s39, #80
    s.add        s39, s2, s35
    v.st.b       [s29, #0], v0
    s.addi       s29, s31, #144
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s36, #0]
    v.extract    s35, v21, #6
    s.add        s36, s35, s21
    s.addi       s35, s36, #80
    s.add        s36, s2, s35
    v.st.b       [s34, #0], v0
    s.addi       s34, s31, #176
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    v.extract    s35, v21, #7
    s.add        s38, s35, s21
    s.addi       s35, s38, #80
    s.add        s38, s2, s35
    v.st.b       [s32, #0], v0
    s.addi       s32, s31, #208
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s37, #0]
    v.extract    s35, v21, #8
    s.add        s37, s35, s21
    s.addi       s35, s37, #80
    s.add        s37, s2, s35
    v.st.b       [s29, #0], v0
    s.addi       s29, s31, #240
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    v.extract    s35, v21, #9
    s.add        s39, s35, s21
    s.addi       s35, s39, #80
    s.add        s39, s2, s35
    v.st.b       [s34, #0], v0
    s.addi       s34, s31, #272
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s36, #0]
    v.extract    s35, v21, #10
    s.add        s36, s35, s21
    s.addi       s35, s36, #80
    s.add        s36, s2, s35
    v.st.b       [s32, #0], v0
    s.addi       s32, s31, #304
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    v.extract    s35, v21, #11
    s.add        s38, s35, s21
    s.addi       s35, s38, #80
    s.add        s38, s2, s35
    v.st.b       [s29, #0], v0
    s.addi       s29, s31, #336
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s37, #0]
    v.extract    s35, v21, #12
    s.add        s37, s35, s21
    s.addi       s35, s37, #80
    s.add        s37, s2, s35
    v.st.b       [s34, #0], v0
    s.addi       s34, s31, #368
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    v.extract    s35, v21, #13
    s.add        s39, s35, s21
    s.addi       s35, s39, #80
    s.add        s39, s2, s35
    v.st.b       [s32, #0], v0
    s.addi       s32, s31, #400
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s36, #0]
    v.extract    s35, v21, #14
    s.add        s36, s35, s21
    s.addi       s35, s36, #80
    s.add        s36, s2, s35
    v.st.b       [s29, #0], v0
    s.addi       s29, s31, #432
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    v.extract    s35, v21, #15
    s.add        s38, s35, s21
    s.addi       s35, s38, #80
    s.add        s38, s2, s35
    v.st.b       [s34, #0], v0
    s.addi       s34, s31, #464
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s37, #0]
    s.addi       s35, s31, #496
    v.st.b       [s32, #0], v0
    s.addi       s32, s31, #64
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s39, #0]
    s.addi       s37, s31, #128
    v.st.b       [s29, #0], v0
    s.addi       s29, s31, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s36, #0]
    s.addi       s36, s31, #256
    v.st.b       [s34, #0], v0
    s.addi       s34, s31, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s38, #0]
    s.addi       s38, s31, #384
    v.st.b       [s35, #0], v0
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s35, s31, #448
    v.ld.w       v0, [s31, #0]
    v.extract    s31, v20, #2
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s32, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s37, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s29, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s36, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s34, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s38, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s35, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.wait      s28
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s29
    mb.wait      s29
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s31, x8dot_done_39
    s.movz       s32, #0
    s.addi       s34, s25, #128
    s.add        s35, s3, s22
    s.addi       s36, s32, #0
    v.ld.w       v0, [s34, #0]
    s.addi       s32, s35, #64
    s.addi       s34, s25, #768
x8dot_row_40:
    s.addi       s35, s23, #-64
    v.movi       v19, #0
    s.sub        s37, s35, s36
    s.add        s35, s32, s36
    v.splat      v23, s37
    s.shli       s37, s36, #4
    s.addi       s38, s36, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s35, v0]             // index is in elements (ISA sec 9.1)
    s.add        s35, s34, s37
    s.movz       s37, #32
    v.st.b       [s35, #0], v19
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s35, s36, s37
    br.nz        s35, x8dot_row_40
x8dot_done_39:
    v.splat      v0, s31
    v.movi       v19, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    v.extract    s34, v29, #2
    s.movz       s35, #64
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s36, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s36, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s34, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v20, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s34
    mb.wait      s34
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s36, x8dot_done_41
    s.addi       s37, s25, #192
    s.add        s38, s3, s22
    s.addi       s39, s32, #0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s38, #64
    s.addi       s38, s25, #1280
x8dot_row_42:
    s.addi       s40, s23, #-64
    v.movi       v19, #0
    s.sub        s41, s40, s39
    s.add        s40, s37, s39
    v.splat      v23, s41
    s.shli       s41, s39, #4
    s.addi       s42, s39, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s40, v0]             // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    s.movz       s41, #32
    v.st.b       [s40, #0], v19
    fence.acq_rel.device
    s.mov        s39, s42
    s.cmp.lt     s40, s39, s41
    br.nz        s40, x8dot_row_42
x8dot_done_41:
    v.splat      v0, s36
    v.movi       v19, #0
    mb.arm       s36, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s37, v29, #3
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s38, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v20, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s35
    mb.wait      s35
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s37, x8dot_done_43
    s.addi       s38, s25, #256
    s.add        s39, s3, s22
    s.addi       s40, s32, #0
    v.ld.w       v0, [s38, #0]
    s.addi       s32, s39, #64
    s.addi       s38, s25, #768
x8dot_row_44:
    s.addi       s39, s23, #-64
    v.movi       v19, #0
    s.sub        s41, s39, s40
    s.add        s39, s32, s40
    v.splat      v23, s41
    s.shli       s41, s40, #4
    s.addi       s42, s40, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s39, v0]             // index is in elements (ISA sec 9.1)
    s.add        s39, s38, s41
    s.movz       s41, #32
    v.st.b       [s39, #0], v19
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s39, s40, s41
    br.nz        s39, x8dot_row_44
x8dot_done_43:
    v.splat      v0, s37
    v.movi       v19, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.extract    s38, v29, #4
    s.movz       s39, #64
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s40, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s40, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s38, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v20, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s38
    mb.wait      s38
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s40, x8dot_done_45
    s.addi       s41, s25, #320
    s.add        s42, s3, s22
    s.addi       s43, s37, #0
    v.ld.w       v0, [s41, #0]
    s.addi       s41, s42, #64
    s.addi       s42, s25, #1280
x8dot_row_46:
    s.addi       s44, s23, #-64
    v.movi       v19, #0
    s.sub        s45, s44, s43
    s.add        s44, s41, s43
    v.splat      v23, s45
    s.shli       s45, s43, #4
    s.addi       s46, s43, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s44, v0]             // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v19
    fence.acq_rel.device
    s.mov        s43, s46
    s.cmp.lt     s44, s43, s45
    br.nz        s44, x8dot_row_46
x8dot_done_45:
    v.splat      v0, s40
    v.movi       v19, #0
    mb.arm       s40, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s41, v29, #5
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s42, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v20, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s39
    mb.wait      s39
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s41, x8dot_done_47
    s.addi       s42, s25, #384
    s.add        s43, s3, s22
    s.addi       s44, s37, #0
    v.ld.w       v0, [s42, #0]
    s.addi       s37, s43, #64
    s.addi       s42, s25, #768
x8dot_row_48:
    s.addi       s43, s23, #-64
    v.movi       v19, #0
    s.sub        s45, s43, s44
    s.add        s43, s37, s44
    v.splat      v23, s45
    s.shli       s45, s44, #4
    s.addi       s46, s44, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s43, v0]             // index is in elements (ISA sec 9.1)
    s.add        s43, s42, s45
    s.movz       s45, #32
    v.st.b       [s43, #0], v19
    fence.acq_rel.device
    s.mov        s44, s46
    s.cmp.lt     s43, s44, s45
    br.nz        s43, x8dot_row_48
x8dot_done_47:
    v.splat      v0, s41
    v.movi       v19, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    v.extract    s42, v29, #6
    s.movz       s43, #64
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s44, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s44, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s44, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s42, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v20, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s42
    mb.wait      s42
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s44, x8dot_done_49
    s.addi       s45, s25, #448
    s.add        s46, s3, s22
    s.addi       s47, s41, #0
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s46, #64
    s.addi       s46, s25, #1280
x8dot_row_50:
    s.addi       s48, s23, #-64
    v.movi       v19, #0
    s.sub        s49, s48, s47
    s.add        s48, s45, s47
    v.splat      v23, s49
    s.shli       s49, s47, #4
    s.addi       s51, s47, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s48, v0]             // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.movz       s49, #32
    v.st.b       [s48, #0], v19
    fence.acq_rel.device
    s.mov        s47, s51
    s.cmp.lt     s48, s47, s49
    br.nz        s48, x8dot_row_50
x8dot_done_49:
    v.splat      v0, s44
    v.movi       v19, #0
    mb.arm       s44, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s45, v29, #7
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s46, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s46, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v20, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s43
    mb.wait      s43
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s45, x8dot_done_51
    s.addi       s46, s25, #0
    s.add        s47, s3, s22
    s.addi       s48, s41, #0
    v.ld.w       v0, [s46, #0]
    s.addi       s41, s47, #96
    s.addi       s46, s25, #768
x8dot_row_52:
    s.addi       s47, s23, #-96
    v.movi       v19, #0
    s.sub        s49, s47, s48
    s.add        s47, s41, s48
    v.splat      v23, s49
    s.shli       s49, s48, #4
    s.addi       s51, s48, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s47, v0]             // index is in elements (ISA sec 9.1)
    s.add        s47, s46, s49
    s.movz       s49, #32
    v.st.b       [s47, #0], v19
    fence.acq_rel.device
    s.mov        s48, s51
    s.cmp.lt     s47, s48, s49
    br.nz        s47, x8dot_row_52
x8dot_done_51:
    v.splat      v0, s45
    v.movi       v19, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    v.extract    s46, v29, #0
    s.movz       s47, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s48, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s48, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s48, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s48, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s46, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v20, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s46
    mb.wait      s46
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s48, x8dot_done_53
    s.addi       s49, s25, #64
    s.add        s51, s3, s22
    s.addi       s52, s45, #0
    v.ld.w       v0, [s49, #0]
    s.addi       s49, s51, #96
    s.addi       s51, s25, #1280
x8dot_row_54:
    s.addi       s53, s23, #-96
    v.movi       v19, #0
    s.sub        s54, s53, s52
    s.add        s53, s49, s52
    v.splat      v23, s54
    s.shli       s54, s52, #4
    s.addi       s55, s52, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s53, v0]             // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v19
    fence.acq_rel.device
    s.mov        s52, s55
    s.cmp.lt     s53, s52, s54
    br.nz        s53, x8dot_row_54
x8dot_done_53:
    s.add        s49, s45, s15                   // the tile origin
    v.extract    s51, v21, #0
    v.splat      v0, s49
    s.add        s49, s51, s21
    s.add        s51, s45, s27                   // the tile origin
    v.splat      v19, s48
    v.movi       v23, #0
    s.addi       s48, s49, #96
    v.add        v24, v22, v0
    v.splat      v0, s51
    mb.arm       s49, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s51, v29, #1
    s.add        s52, s2, s48
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    v.cmp.lt     p3, v24, v0
    s.mov        s53, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s53, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s49          // predicated off still completes once (ISA sec 9A.3)
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s52, #0]
    v.extract    s45, v21, #1
    s.addi       s47, s25, #3840                 // 512 bytes of repack scratch
    s.add        s48, s45, s21
    s.addi       s45, s47, #0
    s.addi       s51, s48, #96
    v.extract    s48, v21, #2
    s.add        s52, s2, s51
    s.add        s51, s48, s21
    s.addi       s48, s47, #32
    s.addi       s53, s51, #96
    v.extract    s51, v21, #3
    v.st.b       [s45, #0], v0
    s.add        s45, s2, s53
    s.add        s53, s51, s21
    s.addi       s51, s47, #64
    s.addi       s54, s53, #96
    v.extract    s53, v21, #4
    s.add        s55, s2, s54
    s.add        s54, s53, s21
    s.addi       s53, s47, #96
    s.addi       s56, s54, #96
    s.add        s54, s2, s56
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s52, #0]
    v.extract    s52, v21, #5
    s.add        s56, s52, s21
    s.addi       s52, s56, #96
    s.add        s56, s2, s52
    v.st.b       [s48, #0], v0
    s.addi       s48, s47, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s45, #0]
    v.extract    s45, v21, #6
    s.add        s52, s45, s21
    s.addi       s45, s52, #96
    s.add        s52, s2, s45
    v.st.b       [s51, #0], v0
    s.addi       s45, s47, #160
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s55, #0]
    v.extract    s51, v21, #7
    s.add        s55, s51, s21
    s.addi       s51, s55, #96
    s.add        s55, s2, s51
    v.st.b       [s53, #0], v0
    s.addi       s51, s47, #192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s54, #0]
    v.extract    s53, v21, #8
    s.add        s54, s53, s21
    s.addi       s53, s54, #96
    s.add        s54, s2, s53
    v.st.b       [s48, #0], v0
    s.addi       s48, s47, #224
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s56, #0]
    v.extract    s53, v21, #9
    s.add        s56, s53, s21
    s.addi       s53, s56, #96
    s.add        s56, s2, s53
    v.st.b       [s45, #0], v0
    s.addi       s45, s47, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s52, #0]
    v.extract    s52, v21, #10
    s.add        s53, s52, s21
    s.addi       s52, s53, #96
    s.add        s53, s2, s52
    v.st.b       [s51, #0], v0
    s.addi       s51, s47, #288
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s55, #0]
    v.extract    s52, v21, #11
    s.add        s55, s52, s21
    s.addi       s52, s55, #96
    s.add        s55, s2, s52
    v.st.b       [s48, #0], v0
    s.addi       s48, s47, #320
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s54, #0]
    v.extract    s52, v21, #12
    s.add        s54, s52, s21
    s.addi       s52, s54, #96
    s.add        s54, s2, s52
    v.st.b       [s45, #0], v0
    s.addi       s45, s47, #352
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s56, #0]
    v.extract    s52, v21, #13
    s.add        s56, s52, s21
    s.addi       s52, s56, #96
    s.add        s56, s2, s52
    v.st.b       [s51, #0], v0
    s.addi       s51, s47, #384
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s53, #0]
    v.extract    s52, v21, #14
    s.add        s53, s52, s21
    s.addi       s52, s53, #96
    s.add        s53, s2, s52
    v.st.b       [s48, #0], v0
    s.addi       s48, s47, #416
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s55, #0]
    v.extract    s52, v21, #15
    s.add        s55, s52, s21
    s.addi       s52, s55, #96
    s.add        s55, s2, s52
    v.st.b       [s45, #0], v0
    s.addi       s45, s47, #448
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s54, #0]
    s.movz       s52, #0
    s.add        s54, s52, s27                   // the tile origin
    s.add        s27, s52, s16                   // the tile origin
    v.splat      v19, s54
    v.extract    s52, v21, #0
    v.splat      v23, s27
    s.add        s27, s52, s21
    s.addi       s52, s47, #480
    s.addi       s54, s27, #112
    v.add        v24, v22, v23
    v.st.b       [s51, #0], v0
    s.add        s27, s2, s54
    v.cmp.lt     p1, v24, v19
    v.extract    s51, v21, #1
    s.add        s54, s51, s21
    s.addi       s51, s54, #112
    s.add        s54, s2, s51
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s56, #0]
    s.addi       s51, s47, #16
    v.st.b       [s48, #0], v0
    v.extract    s48, v21, #2
    s.add        s56, s48, s21
    s.addi       s48, s56, #112
    s.add        s56, s2, s48
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s53, #0]
    s.addi       s48, s47, #48
    v.st.b       [s45, #0], v0
    v.extract    s45, v21, #3
    s.add        s53, s45, s21
    s.addi       s45, s53, #112
    s.add        s53, s2, s45
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v0, [s55, #0]
    s.addi       s45, s47, #80
    v.st.b       [s52, #0], v0
    v.extract    s52, v21, #4
    s.add        s55, s52, s21
    s.addi       s52, s55, #112
    s.add        s55, s2, s52
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s27, #0]
    s.addi       s27, s47, #112
    v.st.b       [s51, #0], v0
    v.extract    s51, v21, #5
    s.add        s52, s51, s21
    s.addi       s51, s52, #112
    s.add        s52, s2, s51
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s54, #0]
    s.addi       s51, s47, #144
    v.st.b       [s48, #0], v0
    v.extract    s48, v21, #6
    s.add        s54, s48, s21
    s.addi       s48, s54, #112
    s.add        s54, s2, s48
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s56, #0]
    s.addi       s48, s47, #176
    v.st.b       [s45, #0], v0
    v.extract    s45, v21, #7
    s.add        s56, s45, s21
    s.addi       s45, s56, #112
    s.add        s56, s2, s45
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s53, #0]
    s.addi       s45, s47, #208
    v.st.b       [s27, #0], v0
    v.extract    s27, v21, #8
    s.add        s53, s27, s21
    s.addi       s27, s53, #112
    s.add        s53, s2, s27
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s55, #0]
    s.addi       s27, s47, #240
    v.st.b       [s51, #0], v0
    v.extract    s51, v21, #9
    s.add        s55, s51, s21
    s.addi       s51, s55, #112
    s.add        s55, s2, s51
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s52, #0]
    s.addi       s51, s47, #272
    v.st.b       [s48, #0], v0
    v.extract    s48, v21, #10
    s.add        s52, s48, s21
    s.addi       s48, s52, #112
    s.add        s52, s2, s48
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s54, #0]
    s.addi       s48, s47, #304
    v.st.b       [s45, #0], v0
    v.extract    s45, v21, #11
    s.add        s54, s45, s21
    s.addi       s45, s54, #112
    s.add        s54, s2, s45
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s56, #0]
    s.addi       s45, s47, #336
    v.st.b       [s27, #0], v0
    v.extract    s27, v21, #12
    s.add        s56, s27, s21
    s.addi       s27, s56, #112
    s.add        s56, s2, s27
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s53, #0]
    s.addi       s27, s47, #368
    v.st.b       [s51, #0], v0
    v.extract    s51, v21, #13
    s.add        s53, s51, s21
    s.addi       s51, s53, #112
    s.add        s53, s2, s51
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s55, #0]
    s.addi       s51, s47, #400
    v.st.b       [s48, #0], v0
    v.extract    s48, v21, #14
    s.add        s55, s48, s21
    s.addi       s48, s55, #112
    s.add        s55, s2, s48
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s52, #0]
    s.addi       s48, s47, #432
    v.st.b       [s45, #0], v0
    v.extract    s45, v21, #15
    s.add        s52, s45, s21
    s.addi       s45, s52, #112
    s.add        s52, s2, s45
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s54, #0]
    s.addi       s45, s47, #464
    v.st.b       [s27, #0], v0
    s.addi       s27, s47, #496
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s56, #0]
    s.addi       s54, s47, #64
    v.st.b       [s51, #0], v0
    s.addi       s51, s47, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s53, #0]
    s.addi       s53, s47, #192
    v.st.b       [s48, #0], v0
    s.addi       s48, s47, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s55, #0]
    s.addi       s55, s47, #320
    v.st.b       [s45, #0], v0
    s.addi       s45, s47, #384
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v0, [s52, #0]
    s.addi       s52, s47, #448
    v.st.b       [s27, #0], v0
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.extract    s27, v20, #2
    v.ld.w       v0, [s47, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s54, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s51, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s53, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s48, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s55, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s45, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s52, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.wait      s41
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s45
    mb.wait      s45
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s27, x8dot_done_55
    s.movz       s47, #0
    s.addi       s48, s25, #128
    s.add        s51, s3, s22
    s.addi       s52, s47, #0
    v.ld.w       v0, [s48, #0]
    s.addi       s47, s51, #96
    s.addi       s48, s25, #768
x8dot_row_56:
    s.addi       s51, s23, #-96
    v.movi       v19, #0
    s.sub        s53, s51, s52
    s.add        s51, s47, s52
    v.splat      v21, s53
    s.shli       s53, s52, #4
    s.addi       s54, s52, #1
    v.cmp.gt     p1, v21, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s51, v0]             // index is in elements (ISA sec 9.1)
    s.add        s51, s48, s53
    s.movz       s53, #32
    v.st.b       [s51, #0], v19
    fence.acq_rel.device
    s.mov        s52, s54
    s.cmp.lt     s51, s52, s53
    br.nz        s51, x8dot_row_56
x8dot_done_55:
    v.splat      v0, s27
    v.movi       v19, #0
    mb.arm       s27, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    v.extract    s48, v29, #2
    s.movz       s51, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s52, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s52, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s52, s27          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s48, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v20, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s48
    mb.wait      s48
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s52, x8dot_done_57
    s.addi       s53, s25, #192
    s.add        s54, s3, s22
    s.addi       s55, s47, #0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s54, #96
    s.addi       s54, s25, #1280
x8dot_row_58:
    s.addi       s56, s23, #-96
    v.movi       v19, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v21, s57
    s.shli       s57, s55, #4
    s.addi       s58, s55, #1
    v.cmp.gt     p1, v21, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s56, v0]             // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.movz       s57, #32
    v.st.b       [s56, #0], v19
    fence.acq_rel.device
    s.mov        s55, s58
    s.cmp.lt     s56, s55, s57
    br.nz        s56, x8dot_row_58
x8dot_done_57:
    v.splat      v0, s52
    v.movi       v19, #0
    mb.arm       s52, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s53, v29, #3
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s54, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s54, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v20, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s51
    mb.wait      s51
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s53, x8dot_done_59
    s.addi       s54, s25, #256
    s.add        s55, s3, s22
    s.addi       s56, s47, #0
    v.ld.w       v0, [s54, #0]
    s.addi       s47, s55, #96
    s.addi       s54, s25, #768
x8dot_row_60:
    s.addi       s55, s23, #-96
    v.movi       v19, #0
    s.sub        s57, s55, s56
    s.add        s55, s47, s56
    v.splat      v21, s57
    s.shli       s57, s56, #4
    s.addi       s58, s56, #1
    v.cmp.gt     p1, v21, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s55, v0]             // index is in elements (ISA sec 9.1)
    s.add        s55, s54, s57
    s.movz       s57, #32
    v.st.b       [s55, #0], v19
    fence.acq_rel.device
    s.mov        s56, s58
    s.cmp.lt     s55, s56, s57
    br.nz        s55, x8dot_row_60
x8dot_done_59:
    v.splat      v0, s53
    v.movi       v19, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    v.extract    s54, v29, #4
    s.movz       s55, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s56, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s56, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s56, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s54, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v20, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s54
    mb.wait      s54
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s56, x8dot_done_61
    s.addi       s57, s25, #320
    s.add        s58, s3, s22
    s.addi       s59, s53, #0
    v.ld.w       v0, [s57, #0]
    s.addi       s57, s58, #96
    s.addi       s58, s25, #1280
x8dot_row_62:
    s.addi       s60, s23, #-96
    v.movi       v19, #0
    s.sub        s24, s60, s59
    s.add        s26, s57, s59
    v.splat      v21, s24
    s.shli       s24, s59, #4
    s.addi       s27, s59, #1
    v.cmp.gt     p1, v21, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s26, v0]             // index is in elements (ISA sec 9.1)
    s.add        s26, s58, s24
    s.movz       s24, #32
    v.st.b       [s26, #0], v19
    fence.acq_rel.device
    s.mov        s59, s27
    s.cmp.lt     s26, s59, s24
    br.nz        s26, x8dot_row_62
x8dot_done_61:
    v.splat      v0, s56
    v.movi       v19, #0
    mb.arm       s24, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s26, v29, #5
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s27, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s27, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s27, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s27, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s27, v20, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s26
    mb.wait      s26
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s27, x8dot_done_63
    s.addi       s28, s25, #384
    s.add        s29, s3, s22
    s.addi       s30, s53, #0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s29, #96
    s.addi       s29, s25, #768
x8dot_row_64:
    s.addi       s31, s23, #-96
    v.movi       v19, #0
    s.sub        s32, s31, s30
    s.add        s31, s28, s30
    v.splat      v21, s32
    s.shli       s32, s30, #4
    s.addi       s33, s30, #1
    v.cmp.gt     p1, v21, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s31, v0]             // index is in elements (ISA sec 9.1)
    s.add        s31, s29, s32
    s.movz       s32, #32
    v.st.b       [s31, #0], v19
    fence.acq_rel.device
    s.mov        s30, s33
    s.cmp.lt     s31, s30, s32
    br.nz        s31, x8dot_row_64
x8dot_done_63:
    v.splat      v0, s27
    v.movi       v19, #0
    mb.arm       s27, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s28, #0
    v.extract    s29, v29, #6
    s.movz       s30, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s31, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s31, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s31, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s31, s27          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    mb.arm       s29, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v20, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s29
    mb.wait      s29
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s31, x8dot_done_65
    s.addi       s32, s25, #448
    s.add        s33, s3, s22
    s.addi       s34, s28, #0
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s33, #96
    s.addi       s33, s25, #1280
x8dot_row_66:
    s.addi       s35, s23, #-96
    v.movi       v19, #0
    s.sub        s36, s35, s34
    s.add        s35, s32, s34
    v.splat      v20, s36
    s.shli       s36, s34, #4
    s.addi       s37, s34, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s35, v0]             // index is in elements (ISA sec 9.1)
    s.add        s35, s33, s36
    s.movz       s36, #32
    v.st.b       [s35, #0], v19
    fence.acq_rel.device
    s.mov        s34, s37
    s.cmp.lt     s35, s34, s36
    br.nz        s35, x8dot_row_66
x8dot_done_65:
    v.splat      v0, s31
    v.movi       v19, #0
    mb.arm       s23, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s31, v29, #7
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s32, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s32, s23            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s23          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s31, s25, #4352
    s.movz       s32, #1
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s30
    mb.wait      s30
    mb.wait      s23
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s34, s31, #64
    s.movz       s35, #2
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s33
    mb.wait      s33
    a.vread      v0, a8, s28
    s.addi       s28, s31, #128
    s.movz       s36, #3
    v.st.w       [s31, #0], v0
    a.vread      v0, a8, s32
    s.addi       s32, s31, #192
    s.movz       s37, #4
    s.addi       s38, s31, #256
    s.movz       s39, #5
    s.addi       s40, s31, #320
    s.movz       s41, #6
    s.addi       s42, s31, #384
    s.movz       s43, #7
    s.addi       s44, s31, #448
    s.movz       s45, #8
    s.addi       s46, s31, #512
    s.movz       s48, #9
    s.addi       s49, s31, #576
    s.movz       s50, #10
    v.st.w       [s34, #0], v0
    a.vread      v0, a8, s35
    s.addi       s34, s31, #640
    s.movz       s35, #11
    v.st.w       [s28, #0], v0
    a.vread      v0, a8, s36
    s.addi       s28, s31, #704
    s.movz       s36, #12
    v.st.w       [s32, #0], v0
    a.vread      v0, a8, s37
    s.addi       s32, s31, #768
    s.movz       s37, #13
    v.st.w       [s38, #0], v0
    a.vread      v0, a8, s39
    s.addi       s38, s31, #832
    s.movz       s39, #14
    v.st.w       [s40, #0], v0
    a.vread      v0, a8, s41
    s.addi       s40, s31, #896
    s.movz       s41, #15
    s.addi       s51, s31, #960
    v.st.w       [s42, #0], v0
    a.vread      v0, a8, s43
    s.movz       s31, #0
    s.addi       s42, s25, #5376
    v.st.w       [s44, #0], v0
    a.vread      v0, a8, s45
    s.movz       s43, #1
    s.addi       s44, s42, #64
    v.st.w       [s46, #0], v0
    a.vread      v0, a8, s48
    s.movz       s45, #2
    s.addi       s46, s42, #128
    v.st.w       [s49, #0], v0
    a.vread      v0, a8, s50
    s.movz       s48, #3
    s.addi       s49, s42, #192
    v.st.w       [s34, #0], v0
    a.vread      v0, a8, s35
    s.movz       s34, #4
    s.addi       s35, s42, #256
    v.st.w       [s28, #0], v0
    a.vread      v0, a8, s36
    s.movz       s28, #5
    s.addi       s36, s42, #320
    v.st.w       [s32, #0], v0
    a.vread      v0, a8, s37
    s.movz       s32, #6
    s.addi       s37, s42, #384
    v.st.w       [s38, #0], v0
    a.vread      v0, a8, s39
    s.movz       s38, #7
    s.addi       s39, s42, #448
    v.st.w       [s40, #0], v0
    a.vread      v0, a8, s41
    s.movz       s40, #8
    s.addi       s41, s42, #512
    v.st.w       [s51, #0], v0
    fence.acq_rel.device
    a.vread      v0, a9, s31
    s.movz       s31, #9
    s.addi       s50, s42, #576
    v.st.w       [s42, #0], v0
    a.vread      v0, a9, s43
    s.movz       s43, #10
    v.st.w       [s44, #0], v0
    a.vread      v0, a9, s45
    s.addi       s44, s42, #640
    s.movz       s45, #11
    v.st.w       [s46, #0], v0
    a.vread      v0, a9, s48
    s.addi       s46, s42, #704
    s.movz       s48, #12
    v.st.w       [s49, #0], v0
    a.vread      v0, a9, s34
    s.addi       s34, s42, #768
    s.movz       s49, #13
    v.st.w       [s35, #0], v0
    a.vread      v0, a9, s28
    s.addi       s28, s42, #832
    s.movz       s35, #14
    v.st.w       [s36, #0], v0
    a.vread      v0, a9, s32
    s.addi       s32, s42, #896
    s.movz       s36, #15
    s.addi       s51, s42, #960
    v.st.w       [s37, #0], v0
    a.vread      v0, a9, s38
    s.movz       s37, #0
    s.addi       s38, s25, #6400
    v.st.w       [s39, #0], v0
    a.vread      v0, a9, s40
    s.movz       s39, #1
    s.addi       s40, s38, #64
    v.st.w       [s41, #0], v0
    a.vread      v0, a9, s31
    s.movz       s31, #2
    s.addi       s41, s38, #128
    v.st.w       [s50, #0], v0
    a.vread      v0, a9, s43
    s.movz       s42, #3
    s.addi       s43, s38, #192
    v.st.w       [s44, #0], v0
    a.vread      v0, a9, s45
    s.movz       s44, #4
    s.addi       s45, s38, #256
    v.st.w       [s46, #0], v0
    a.vread      v0, a9, s48
    s.movz       s46, #5
    s.addi       s48, s38, #320
    v.st.w       [s34, #0], v0
    a.vread      v0, a9, s49
    s.movz       s34, #6
    s.addi       s49, s38, #384
    v.st.w       [s28, #0], v0
    a.vread      v0, a9, s35
    s.movz       s28, #7
    s.addi       s35, s38, #448
    v.st.w       [s32, #0], v0
    a.vread      v0, a9, s36
    s.movz       s32, #8
    s.addi       s36, s38, #512
    v.st.w       [s51, #0], v0
    fence.acq_rel.device
    a.vread      v0, a10, s37
    s.movz       s37, #9
    s.addi       s50, s38, #576
    v.st.w       [s38, #0], v0
    a.vread      v0, a10, s39
    s.movz       s39, #10
    v.st.w       [s40, #0], v0
    a.vread      v0, a10, s31
    s.addi       s31, s38, #640
    s.movz       s40, #11
    v.st.w       [s41, #0], v0
    a.vread      v0, a10, s42
    s.addi       s41, s38, #704
    s.movz       s42, #12
    v.st.w       [s43, #0], v0
    a.vread      v0, a10, s44
    s.addi       s43, s38, #768
    s.movz       s44, #13
    v.st.w       [s45, #0], v0
    a.vread      v0, a10, s46
    s.addi       s45, s38, #832
    s.movz       s46, #14
    v.st.w       [s48, #0], v0
    a.vread      v0, a10, s34
    s.addi       s34, s38, #896
    s.movz       s48, #15
    s.addi       s51, s38, #960
    v.st.w       [s49, #0], v0
    a.vread      v0, a10, s28
    s.movz       s28, #0
    s.addi       s38, s25, #7424
    v.st.w       [s35, #0], v0
    a.vread      v0, a10, s32
    s.movz       s32, #1
    s.addi       s35, s38, #64
    v.st.w       [s36, #0], v0
    a.vread      v0, a10, s37
    s.movz       s36, #2
    s.addi       s37, s38, #128
    v.st.w       [s50, #0], v0
    a.vread      v0, a10, s39
    s.movz       s39, #3
    s.addi       s49, s38, #192
    v.st.w       [s31, #0], v0
    a.vread      v0, a10, s40
    s.movz       s31, #4
    s.addi       s40, s38, #256
    v.st.w       [s41, #0], v0
    a.vread      v0, a10, s42
    s.movz       s41, #5
    s.addi       s42, s38, #320
    v.st.w       [s43, #0], v0
    a.vread      v0, a10, s44
    s.movz       s43, #6
    s.addi       s44, s38, #384
    v.st.w       [s45, #0], v0
    a.vread      v0, a10, s46
    s.movz       s45, #7
    s.addi       s46, s38, #448
    v.st.w       [s34, #0], v0
    a.vread      v0, a10, s48
    s.movz       s34, #8
    s.addi       s48, s38, #512
    v.st.w       [s51, #0], v0
    fence.acq_rel.device
    a.vread      v0, a11, s28
    s.movz       s28, #9
    s.addi       s50, s38, #576
    v.st.w       [s38, #0], v0
    a.vread      v0, a11, s32
    s.movz       s32, #10
    v.st.w       [s35, #0], v0
    a.vread      v0, a11, s36
    s.addi       s35, s38, #640
    s.movz       s36, #11
    v.st.w       [s37, #0], v0
    a.vread      v0, a11, s39
    s.addi       s37, s38, #704
    s.movz       s39, #12
    v.st.w       [s49, #0], v0
    a.vread      v0, a11, s31
    s.addi       s31, s38, #768
    s.movz       s49, #13
    v.st.w       [s40, #0], v0
    a.vread      v0, a11, s41
    s.addi       s40, s38, #832
    s.movz       s41, #14
    v.st.w       [s42, #0], v0
    a.vread      v0, a11, s43
    s.addi       s42, s38, #896
    s.movz       s43, #15
    s.addi       s51, s38, #960
    v.st.w       [s44, #0], v0
    a.vread      v0, a11, s45
    s.movz       s38, #0
    s.addi       s44, s25, #8448
    v.st.w       [s46, #0], v0
    a.vread      v0, a11, s34
    s.movz       s34, #1
    s.addi       s45, s44, #64
    v.st.w       [s48, #0], v0
    a.vread      v0, a11, s28
    s.movz       s28, #2
    s.addi       s46, s44, #128
    v.st.w       [s50, #0], v0
    a.vread      v0, a11, s32
    s.movz       s32, #3
    s.addi       s48, s44, #192
    v.st.w       [s35, #0], v0
    a.vread      v0, a11, s36
    s.movz       s35, #4
    s.addi       s36, s44, #256
    v.st.w       [s37, #0], v0
    a.vread      v0, a11, s39
    s.movz       s37, #5
    s.addi       s39, s44, #320
    v.st.w       [s31, #0], v0
    a.vread      v0, a11, s49
    s.movz       s31, #6
    s.addi       s49, s44, #384
    v.st.w       [s40, #0], v0
    a.vread      v0, a11, s41
    s.movz       s40, #7
    s.addi       s41, s44, #448
    v.st.w       [s42, #0], v0
    a.vread      v0, a11, s43
    s.movz       s42, #8
    s.addi       s43, s44, #512
    v.st.w       [s51, #0], v0
    fence.acq_rel.device
    a.vread      v0, a12, s38
    s.movz       s38, #9
    s.addi       s50, s44, #576
    v.st.w       [s44, #0], v0
    a.vread      v0, a12, s34
    s.movz       s34, #10
    v.st.w       [s45, #0], v0
    a.vread      v0, a12, s28
    s.addi       s28, s44, #640
    s.movz       s45, #11
    v.st.w       [s46, #0], v0
    a.vread      v0, a12, s32
    s.addi       s32, s44, #704
    s.movz       s46, #12
    v.st.w       [s48, #0], v0
    a.vread      v0, a12, s35
    s.addi       s35, s44, #768
    s.movz       s48, #13
    v.st.w       [s36, #0], v0
    a.vread      v0, a12, s37
    s.addi       s36, s44, #832
    s.movz       s37, #14
    v.st.w       [s39, #0], v0
    a.vread      v0, a12, s31
    s.addi       s31, s44, #896
    s.movz       s39, #15
    s.addi       s51, s44, #960
    v.st.w       [s49, #0], v0
    a.vread      v0, a12, s40
    s.movz       s40, #0
    s.addi       s44, s25, #9472
    v.st.w       [s41, #0], v0
    a.vread      v0, a12, s42
    s.movz       s41, #1
    s.addi       s42, s44, #64
    v.st.w       [s43, #0], v0
    a.vread      v0, a12, s38
    s.movz       s38, #2
    s.addi       s43, s44, #128
    v.st.w       [s50, #0], v0
    a.vread      v0, a12, s34
    s.movz       s34, #3
    s.addi       s49, s44, #192
    v.st.w       [s28, #0], v0
    a.vread      v0, a12, s45
    s.movz       s28, #4
    s.addi       s45, s44, #256
    v.st.w       [s32, #0], v0
    a.vread      v0, a12, s46
    s.movz       s32, #5
    s.addi       s46, s44, #320
    v.st.w       [s35, #0], v0
    a.vread      v0, a12, s48
    s.movz       s35, #6
    s.addi       s48, s44, #384
    v.st.w       [s36, #0], v0
    a.vread      v0, a12, s37
    s.movz       s36, #7
    s.addi       s37, s44, #448
    v.st.w       [s31, #0], v0
    a.vread      v0, a12, s39
    s.movz       s31, #8
    s.addi       s39, s44, #512
    v.st.w       [s51, #0], v0
    fence.acq_rel.device
    a.vread      v0, a13, s40
    s.movz       s40, #9
    s.addi       s50, s44, #576
    v.st.w       [s44, #0], v0
    a.vread      v0, a13, s41
    s.movz       s41, #10
    v.st.w       [s42, #0], v0
    a.vread      v0, a13, s38
    s.addi       s38, s44, #640
    s.movz       s42, #11
    v.st.w       [s43, #0], v0
    a.vread      v0, a13, s34
    s.addi       s34, s44, #704
    s.movz       s43, #12
    v.st.w       [s49, #0], v0
    a.vread      v0, a13, s28
    s.addi       s28, s44, #768
    s.movz       s49, #13
    v.st.w       [s45, #0], v0
    a.vread      v0, a13, s32
    s.addi       s32, s44, #832
    s.movz       s45, #14
    v.st.w       [s46, #0], v0
    a.vread      v0, a13, s35
    s.addi       s35, s44, #896
    s.movz       s46, #15
    s.addi       s51, s44, #960
    v.st.w       [s48, #0], v0
    a.vread      v0, a13, s36
    s.movz       s36, #0
    s.addi       s44, s25, #10496
    v.st.w       [s37, #0], v0
    a.vread      v0, a13, s31
    s.movz       s31, #1
    s.addi       s37, s44, #64
    v.st.w       [s39, #0], v0
    a.vread      v0, a13, s40
    s.movz       s39, #2
    s.addi       s40, s44, #128
    v.st.w       [s50, #0], v0
    a.vread      v0, a13, s41
    s.movz       s41, #3
    s.addi       s48, s44, #192
    v.st.w       [s38, #0], v0
    a.vread      v0, a13, s42
    s.movz       s38, #4
    s.addi       s42, s44, #256
    v.st.w       [s34, #0], v0
    a.vread      v0, a13, s43
    s.movz       s34, #5
    s.addi       s43, s44, #320
    v.st.w       [s28, #0], v0
    a.vread      v0, a13, s49
    s.movz       s28, #6
    s.addi       s49, s44, #384
    v.st.w       [s32, #0], v0
    a.vread      v0, a13, s45
    s.movz       s32, #7
    s.addi       s45, s44, #448
    v.st.w       [s35, #0], v0
    a.vread      v0, a13, s46
    s.movz       s35, #8
    s.addi       s46, s44, #512
    v.st.w       [s51, #0], v0
    fence.acq_rel.device
    a.vread      v0, a14, s36
    s.movz       s36, #9
    s.addi       s50, s44, #576
    v.st.w       [s44, #0], v0
    a.vread      v0, a14, s31
    s.movz       s31, #10
    v.st.w       [s37, #0], v0
    a.vread      v0, a14, s39
    s.addi       s37, s44, #640
    s.movz       s39, #11
    v.st.w       [s40, #0], v0
    a.vread      v0, a14, s41
    s.addi       s40, s44, #704
    s.movz       s41, #12
    v.st.w       [s48, #0], v0
    a.vread      v0, a14, s38
    s.addi       s38, s44, #768
    s.movz       s48, #13
    v.st.w       [s42, #0], v0
    a.vread      v0, a14, s34
    s.addi       s34, s44, #832
    s.movz       s42, #14
    v.st.w       [s43, #0], v0
    a.vread      v0, a14, s28
    s.addi       s28, s44, #896
    s.movz       s43, #15
    s.addi       s51, s44, #960
    v.st.w       [s49, #0], v0
    a.vread      v0, a14, s32
    s.movz       s32, #0
    s.addi       s44, s25, #11520
    v.st.w       [s45, #0], v0
    a.vread      v0, a14, s35
    s.movz       s35, #1
    s.addi       s45, s44, #64
    v.st.w       [s46, #0], v0
    a.vread      v0, a14, s36
    s.movz       s36, #2
    s.addi       s46, s44, #128
    v.st.w       [s50, #0], v0
    a.vread      v0, a14, s31
    s.movz       s31, #3
    s.addi       s49, s44, #192
    v.st.w       [s37, #0], v0
    a.vread      v0, a14, s39
    s.movz       s37, #4
    s.addi       s39, s44, #256
    v.st.w       [s40, #0], v0
    a.vread      v0, a14, s41
    s.movz       s40, #5
    s.addi       s41, s44, #320
    v.st.w       [s38, #0], v0
    a.vread      v0, a14, s48
    s.movz       s38, #6
    s.addi       s48, s44, #384
    v.st.w       [s34, #0], v0
    a.vread      v0, a14, s42
    s.movz       s34, #7
    s.addi       s42, s44, #448
    v.st.w       [s28, #0], v0
    a.vread      v0, a14, s43
    s.movz       s28, #8
    s.addi       s43, s44, #512
    v.st.w       [s51, #0], v0
    fence.acq_rel.device
    a.vread      v0, a15, s32
    s.movz       s32, #9
    s.addi       s50, s44, #576
    v.st.w       [s44, #0], v0
    a.vread      v0, a15, s35
    s.movz       s35, #10
    v.st.w       [s45, #0], v0
    a.vread      v0, a15, s36
    s.addi       s36, s44, #640
    s.movz       s45, #11
    v.st.w       [s46, #0], v0
    a.vread      v0, a15, s31
    s.addi       s31, s44, #704
    s.movz       s46, #12
    v.st.w       [s49, #0], v0
    a.vread      v0, a15, s37
    s.addi       s37, s44, #768
    s.movz       s49, #13
    v.st.w       [s39, #0], v0
    a.vread      v0, a15, s40
    s.addi       s39, s44, #832
    s.movz       s40, #14
    v.st.w       [s41, #0], v0
    a.vread      v0, a15, s38
    s.addi       s38, s44, #896
    s.movz       s41, #15
    s.addi       s51, s44, #960
    v.st.w       [s48, #0], v0
    a.vread      v0, a15, s34
    s.movz       s34, #0
    s.addi       s44, s25, #4352
    v.st.w       [s42, #0], v0
    a.vread      v0, a15, s28
    v.extract    s28, v27, #0
    s.addi       s42, s25, #12544
    v.splat      v19, s28
    s.movz       s28, #1
    v.st.w       [s43, #0], v0
    a.vread      v0, a15, s32
    s.addi       s32, s25, #4416
    v.extract    s43, v27, #1
    v.splat      v20, s43
    s.addi       s43, s42, #64
    v.st.w       [s50, #0], v0
    a.vread      v0, a15, s35
    s.movz       s35, #2
    s.addi       s48, s25, #4480
    v.st.w       [s36, #0], v0
    a.vread      v0, a15, s45
    v.extract    s36, v27, #2
    s.addi       s45, s42, #128
    v.splat      v21, s36
    v.st.w       [s31, #0], v0
    a.vread      v0, a15, s46
    s.addi       s31, s42, #192
    v.st.w       [s37, #0], v0
    a.vread      v0, a15, s49
    s.movz       s36, #3
    s.addi       s37, s25, #4544
    v.st.w       [s39, #0], v0
    a.vread      v0, a15, s40
    v.extract    s39, v27, #3
    v.splat      v22, s39
    v.st.w       [s38, #0], v0
    a.vread      v0, a15, s41
    s.movz       s38, #4
    s.addi       s39, s42, #256
    v.st.w       [s51, #0], v0
    fence.acq_rel.device
    a.vread      v0, a0, s34
    s.addi       s34, s25, #4608
    v.extract    s40, v27, #4
    v.splat      v23, s40
    v.ld.w       v24, [s44, #0]
    vf.mul       v25, v24, v19
    s.addi       s40, s42, #320
    vf.mul       v19, v25, v31
    s.movz       s41, #5
    vf.add       v24, v0, v19
    v.st.w       [s42, #0], v24
    a.vread      v0, a0, s28
    s.addi       s28, s25, #4672
    v.extract    s44, v27, #5
    v.splat      v19, s44
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v20
    s.addi       s32, s42, #384
    vf.mul       v20, v25, v31
    s.movz       s44, #6
    vf.add       v24, v0, v20
    v.st.w       [s43, #0], v24
    a.vread      v0, a0, s35
    s.addi       s35, s25, #4736
    v.extract    s43, v27, #6
    v.splat      v20, s43
    v.ld.w       v24, [s48, #0]
    vf.mul       v25, v24, v21
    s.addi       s43, s42, #448
    vf.mul       v21, v25, v31
    s.movz       s46, #7
    vf.add       v24, v0, v21
    v.st.w       [s45, #0], v24
    a.vread      v0, a0, s36
    s.addi       s36, s25, #4800
    v.extract    s45, v27, #7
    v.splat      v21, s45
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    s.addi       s37, s42, #512
    vf.mul       v22, v25, v31
    s.movz       s45, #8
    vf.add       v24, v0, v22
    v.st.w       [s31, #0], v24
    a.vread      v0, a0, s38
    s.addi       s31, s25, #4864
    v.extract    s38, v27, #8
    v.splat      v22, s38
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v23
    s.addi       s34, s42, #576
    vf.mul       v23, v25, v31
    s.movz       s38, #9
    vf.add       v24, v0, v23
    v.st.w       [s39, #0], v24
    a.vread      v0, a0, s41
    s.addi       s39, s25, #4928
    v.extract    s41, v27, #9
    v.splat      v23, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v19
    s.addi       s28, s42, #640
    vf.mul       v19, v25, v31
    s.movz       s41, #10
    vf.add       v24, v0, v19
    v.st.w       [s40, #0], v24
    a.vread      v0, a0, s44
    s.addi       s40, s25, #4992
    v.extract    s44, v27, #10
    v.splat      v19, s44
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s42, #704
    vf.mul       v20, v25, v31
    s.movz       s44, #11
    vf.add       v24, v0, v20
    v.st.w       [s32, #0], v24
    a.vread      v0, a0, s46
    s.addi       s32, s25, #5056
    v.extract    s46, v27, #11
    v.splat      v20, s46
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v21
    s.addi       s36, s42, #768
    vf.mul       v21, v25, v31
    s.movz       s46, #12
    vf.add       v24, v0, v21
    v.st.w       [s43, #0], v24
    a.vread      v0, a0, s45
    s.addi       s43, s25, #5120
    v.extract    s45, v27, #12
    v.splat      v21, s45
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v22
    s.addi       s31, s42, #832
    vf.mul       v22, v25, v31
    s.movz       s45, #13
    vf.add       v24, v0, v22
    v.st.w       [s37, #0], v24
    a.vread      v0, a0, s38
    s.addi       s37, s25, #5184
    v.extract    s38, v27, #13
    v.splat      v22, s38
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v23
    s.addi       s38, s42, #896
    vf.mul       v23, v25, v31
    s.movz       s39, #14
    vf.add       v24, v0, v23
    v.st.w       [s34, #0], v24
    a.vread      v0, a0, s41
    s.addi       s34, s25, #5248
    v.extract    s41, v27, #14
    v.splat      v23, s41
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    s.addi       s40, s42, #960
    vf.mul       v19, v25, v31
    s.movz       s41, #15
    vf.add       v24, v0, v19
    v.st.w       [s28, #0], v24
    a.vread      v0, a0, s44
    s.addi       s28, s25, #5312
    v.extract    s42, v27, #15
    v.splat      v19, s42
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v31
    s.addi       s32, s25, #13568
    vf.add       v24, v0, v20
    s.movz       s42, #0
    v.st.w       [s35, #0], v24
    a.vread      v0, a0, s46
    s.addi       s35, s25, #5376
    v.extract    s44, v27, #0
    v.splat      v20, s44
    v.ld.w       v24, [s43, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v31
    s.addi       s43, s32, #64
    vf.add       v24, v0, v21
    s.movz       s44, #1
    v.st.w       [s36, #0], v24
    a.vread      v0, a0, s45
    s.addi       s36, s25, #5440
    v.extract    s45, v27, #1
    v.splat      v21, s45
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v31
    s.addi       s37, s32, #128
    vf.add       v24, v0, v22
    s.movz       s45, #2
    v.st.w       [s31, #0], v24
    a.vread      v0, a0, s39
    s.addi       s31, s25, #5504
    v.extract    s39, v27, #2
    v.splat      v22, s39
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v31
    s.addi       s34, s32, #192
    vf.add       v24, v0, v23
    s.movz       s39, #3
    v.st.w       [s38, #0], v24
    a.vread      v0, a0, s41
    s.addi       s38, s25, #5568
    v.extract    s41, v27, #3
    v.splat      v23, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v31
    s.addi       s28, s32, #256
    vf.add       v24, v0, v19
    s.movz       s41, #4
    v.st.w       [s40, #0], v24
    fence.acq_rel.device
    a.vread      v0, a1, s42
    s.addi       s40, s25, #5632
    v.extract    s42, v27, #4
    v.splat      v19, s42
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s32, #320
    vf.mul       v20, v25, v30
    s.movz       s42, #5
    vf.add       v24, v0, v20
    v.st.w       [s32, #0], v24
    a.vread      v0, a1, s44
    s.addi       s44, s25, #5696
    v.extract    s46, v27, #5
    v.splat      v20, s46
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v21
    s.addi       s36, s32, #384
    vf.mul       v21, v25, v30
    s.movz       s46, #6
    vf.add       v24, v0, v21
    v.st.w       [s43, #0], v24
    a.vread      v0, a1, s45
    s.addi       s43, s25, #5760
    v.extract    s45, v27, #6
    v.splat      v21, s45
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v22
    s.addi       s31, s32, #448
    vf.mul       v22, v25, v30
    s.movz       s45, #7
    vf.add       v24, v0, v22
    v.st.w       [s37, #0], v24
    a.vread      v0, a1, s39
    s.addi       s37, s25, #5824
    v.extract    s39, v27, #7
    v.splat      v22, s39
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v23
    s.addi       s38, s32, #512
    vf.mul       v23, v25, v30
    s.movz       s39, #8
    vf.add       v24, v0, v23
    v.st.w       [s34, #0], v24
    a.vread      v0, a1, s41
    s.addi       s34, s25, #5888
    v.extract    s41, v27, #8
    v.splat      v23, s41
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    s.addi       s40, s32, #576
    vf.mul       v19, v25, v30
    s.movz       s41, #9
    vf.add       v24, v0, v19
    v.st.w       [s28, #0], v24
    a.vread      v0, a1, s42
    s.addi       s28, s25, #5952
    v.extract    s42, v27, #9
    v.splat      v19, s42
    v.ld.w       v24, [s44, #0]
    vf.mul       v25, v24, v20
    s.addi       s42, s32, #640
    vf.mul       v20, v25, v30
    s.movz       s44, #10
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a1, s46
    s.addi       s35, s25, #6016
    v.extract    s46, v27, #10
    v.splat      v20, s46
    v.ld.w       v24, [s43, #0]
    vf.mul       v25, v24, v21
    s.addi       s43, s32, #704
    vf.mul       v21, v25, v30
    s.movz       s46, #11
    vf.add       v24, v0, v21
    v.st.w       [s36, #0], v24
    a.vread      v0, a1, s45
    s.addi       s36, s25, #6080
    v.extract    s45, v27, #11
    v.splat      v21, s45
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    s.addi       s37, s32, #768
    vf.mul       v22, v25, v30
    s.movz       s45, #12
    vf.add       v24, v0, v22
    v.st.w       [s31, #0], v24
    a.vread      v0, a1, s39
    s.addi       s31, s25, #6144
    v.extract    s39, v27, #12
    v.splat      v22, s39
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v23
    s.addi       s34, s32, #832
    vf.mul       v23, v25, v30
    s.movz       s39, #13
    vf.add       v24, v0, v23
    v.st.w       [s38, #0], v24
    a.vread      v0, a1, s41
    s.addi       s38, s25, #6208
    v.extract    s41, v27, #13
    v.splat      v23, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v19
    s.addi       s28, s32, #896
    vf.mul       v19, v25, v30
    s.movz       s41, #14
    vf.add       v24, v0, v19
    v.st.w       [s40, #0], v24
    a.vread      v0, a1, s44
    s.addi       s40, s25, #6272
    v.extract    s44, v27, #14
    v.splat      v19, s44
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s32, #960
    vf.mul       v20, v25, v30
    s.movz       s32, #15
    vf.add       v24, v0, v20
    v.st.w       [s42, #0], v24
    a.vread      v0, a1, s46
    s.addi       s42, s25, #6336
    v.extract    s44, v27, #15
    v.splat      v20, s44
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v30
    s.addi       s36, s25, #14592
    vf.add       v24, v0, v21
    s.movz       s44, #0
    v.st.w       [s43, #0], v24
    a.vread      v0, a1, s45
    s.addi       s43, s25, #6400
    v.extract    s45, v27, #0
    v.splat      v21, s45
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v30
    s.addi       s31, s36, #64
    vf.add       v24, v0, v22
    s.movz       s45, #1
    v.st.w       [s37, #0], v24
    a.vread      v0, a1, s39
    s.addi       s37, s25, #6464
    v.extract    s39, v27, #1
    v.splat      v22, s39
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v30
    s.addi       s38, s36, #128
    vf.add       v24, v0, v23
    s.movz       s39, #2
    v.st.w       [s34, #0], v24
    a.vread      v0, a1, s41
    s.addi       s34, s25, #6528
    v.extract    s41, v27, #2
    v.splat      v23, s41
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v30
    s.addi       s40, s36, #192
    vf.add       v24, v0, v19
    s.movz       s41, #3
    v.st.w       [s28, #0], v24
    a.vread      v0, a1, s32
    s.addi       s28, s25, #6592
    v.extract    s32, v27, #3
    v.splat      v19, s32
    v.ld.w       v24, [s42, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v30
    s.addi       s32, s36, #256
    vf.add       v24, v0, v20
    s.movz       s42, #4
    v.st.w       [s35, #0], v24
    fence.acq_rel.device
    a.vread      v0, a2, s44
    s.addi       s35, s25, #6656
    v.extract    s44, v27, #4
    v.splat      v20, s44
    v.ld.w       v24, [s43, #0]
    vf.mul       v25, v24, v21
    s.addi       s43, s36, #320
    vf.mul       v21, v25, v32
    s.movz       s44, #5
    vf.add       v24, v0, v21
    v.st.w       [s36, #0], v24
    a.vread      v0, a2, s45
    s.addi       s45, s25, #6720
    v.extract    s46, v27, #5
    v.splat      v21, s46
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    s.addi       s37, s36, #384
    vf.mul       v22, v25, v32
    s.movz       s46, #6
    vf.add       v24, v0, v22
    v.st.w       [s31, #0], v24
    a.vread      v0, a2, s39
    s.addi       s31, s25, #6784
    v.extract    s39, v27, #6
    v.splat      v22, s39
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v23
    s.addi       s34, s36, #448
    vf.mul       v23, v25, v32
    s.movz       s39, #7
    vf.add       v24, v0, v23
    v.st.w       [s38, #0], v24
    a.vread      v0, a2, s41
    s.addi       s38, s25, #6848
    v.extract    s41, v27, #7
    v.splat      v23, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v19
    s.addi       s28, s36, #512
    vf.mul       v19, v25, v32
    s.movz       s41, #8
    vf.add       v24, v0, v19
    v.st.w       [s40, #0], v24
    a.vread      v0, a2, s42
    s.addi       s40, s25, #6912
    v.extract    s42, v27, #8
    v.splat      v19, s42
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s36, #576
    vf.mul       v20, v25, v32
    s.movz       s42, #9
    vf.add       v24, v0, v20
    v.st.w       [s32, #0], v24
    a.vread      v0, a2, s44
    s.addi       s32, s25, #6976
    v.extract    s44, v27, #9
    v.splat      v20, s44
    v.ld.w       v24, [s45, #0]
    vf.mul       v25, v24, v21
    s.addi       s44, s36, #640
    vf.mul       v21, v25, v32
    s.movz       s45, #10
    vf.add       v24, v0, v21
    v.st.w       [s43, #0], v24
    a.vread      v0, a2, s46
    s.addi       s43, s25, #7040
    v.extract    s46, v27, #10
    v.splat      v21, s46
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v22
    s.addi       s31, s36, #704
    vf.mul       v22, v25, v32
    s.movz       s46, #11
    vf.add       v24, v0, v22
    v.st.w       [s37, #0], v24
    a.vread      v0, a2, s39
    s.addi       s37, s25, #7104
    v.extract    s39, v27, #11
    v.splat      v22, s39
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v23
    s.addi       s38, s36, #768
    vf.mul       v23, v25, v32
    s.movz       s39, #12
    vf.add       v24, v0, v23
    v.st.w       [s34, #0], v24
    a.vread      v0, a2, s41
    s.addi       s34, s25, #7168
    v.extract    s41, v27, #12
    v.splat      v23, s41
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    s.addi       s40, s36, #832
    vf.mul       v19, v25, v32
    s.movz       s41, #13
    vf.add       v24, v0, v19
    v.st.w       [s28, #0], v24
    a.vread      v0, a2, s42
    s.addi       s28, s25, #7232
    v.extract    s42, v27, #13
    v.splat      v19, s42
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v20
    s.addi       s32, s36, #896
    vf.mul       v20, v25, v32
    s.movz       s42, #14
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a2, s45
    s.addi       s35, s25, #7296
    v.extract    s45, v27, #14
    v.splat      v20, s45
    v.ld.w       v24, [s43, #0]
    vf.mul       v25, v24, v21
    s.addi       s43, s36, #960
    vf.mul       v21, v25, v32
    s.movz       s36, #15
    vf.add       v24, v0, v21
    v.st.w       [s44, #0], v24
    a.vread      v0, a2, s46
    s.addi       s44, s25, #7360
    v.extract    s45, v27, #15
    v.splat      v21, s45
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v32
    s.addi       s37, s25, #15616
    vf.add       v24, v0, v22
    s.movz       s45, #0
    v.st.w       [s31, #0], v24
    a.vread      v0, a2, s39
    s.addi       s31, s25, #7424
    v.extract    s39, v27, #0
    v.splat      v22, s39
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v32
    s.addi       s34, s37, #64
    vf.add       v24, v0, v23
    s.movz       s39, #1
    v.st.w       [s38, #0], v24
    a.vread      v0, a2, s41
    s.addi       s38, s25, #7488
    v.extract    s41, v27, #1
    v.splat      v23, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v32
    s.addi       s28, s37, #128
    vf.add       v24, v0, v19
    s.movz       s41, #2
    v.st.w       [s40, #0], v24
    a.vread      v0, a2, s42
    s.addi       s40, s25, #7552
    v.extract    s42, v27, #2
    v.splat      v19, s42
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v32
    s.addi       s35, s37, #192
    vf.add       v24, v0, v20
    s.movz       s42, #3
    v.st.w       [s32, #0], v24
    a.vread      v0, a2, s36
    s.addi       s32, s25, #7616
    v.extract    s36, v27, #3
    v.splat      v20, s36
    v.ld.w       v24, [s44, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v32
    s.addi       s36, s37, #256
    vf.add       v24, v0, v21
    s.movz       s44, #4
    v.st.w       [s43, #0], v24
    fence.acq_rel.device
    a.vread      v0, a3, s45
    s.addi       s43, s25, #7680
    v.extract    s45, v27, #4
    v.splat      v21, s45
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v22
    s.addi       s31, s37, #320
    vf.mul       v22, v25, v33
    s.movz       s45, #5
    vf.add       v24, v0, v22
    v.st.w       [s37, #0], v24
    a.vread      v0, a3, s39
    s.addi       s39, s25, #7744
    v.extract    s46, v27, #5
    v.splat      v22, s46
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v23
    s.addi       s38, s37, #384
    vf.mul       v23, v25, v33
    s.movz       s46, #6
    vf.add       v24, v0, v23
    v.st.w       [s34, #0], v24
    a.vread      v0, a3, s41
    s.addi       s34, s25, #7808
    v.extract    s41, v27, #6
    v.splat      v23, s41
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    s.addi       s40, s37, #448
    vf.mul       v19, v25, v33
    s.movz       s41, #7
    vf.add       v24, v0, v19
    v.st.w       [s28, #0], v24
    a.vread      v0, a3, s42
    s.addi       s28, s25, #7872
    v.extract    s42, v27, #7
    v.splat      v19, s42
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v20
    s.addi       s32, s37, #512
    vf.mul       v20, v25, v33
    s.movz       s42, #8
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a3, s44
    s.addi       s35, s25, #7936
    v.extract    s44, v27, #8
    v.splat      v20, s44
    v.ld.w       v24, [s43, #0]
    vf.mul       v25, v24, v21
    s.addi       s43, s37, #576
    vf.mul       v21, v25, v33
    s.movz       s44, #9
    vf.add       v24, v0, v21
    v.st.w       [s36, #0], v24
    a.vread      v0, a3, s45
    s.addi       s36, s25, #8000
    v.extract    s45, v27, #9
    v.splat      v21, s45
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v22
    s.addi       s39, s37, #640
    vf.mul       v22, v25, v33
    s.movz       s45, #10
    vf.add       v24, v0, v22
    v.st.w       [s31, #0], v24
    a.vread      v0, a3, s46
    s.addi       s31, s25, #8064
    v.extract    s46, v27, #10
    v.splat      v22, s46
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v23
    s.addi       s34, s37, #704
    vf.mul       v23, v25, v33
    s.movz       s46, #11
    vf.add       v24, v0, v23
    v.st.w       [s38, #0], v24
    a.vread      v0, a3, s41
    s.addi       s38, s25, #8128
    v.extract    s41, v27, #11
    v.splat      v23, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v19
    s.addi       s28, s37, #768
    vf.mul       v19, v25, v33
    s.movz       s41, #12
    vf.add       v24, v0, v19
    v.st.w       [s40, #0], v24
    a.vread      v0, a3, s42
    s.addi       s40, s25, #8192
    v.extract    s42, v27, #12
    v.splat      v19, s42
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s37, #832
    vf.mul       v20, v25, v33
    s.movz       s42, #13
    vf.add       v24, v0, v20
    v.st.w       [s32, #0], v24
    a.vread      v0, a3, s44
    s.addi       s32, s25, #8256
    v.extract    s44, v27, #13
    v.splat      v20, s44
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v21
    s.addi       s36, s37, #896
    vf.mul       v21, v25, v33
    s.movz       s44, #14
    vf.add       v24, v0, v21
    v.st.w       [s43, #0], v24
    a.vread      v0, a3, s45
    s.addi       s43, s25, #8320
    v.extract    s45, v27, #14
    v.splat      v21, s45
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v22
    s.addi       s31, s37, #960
    vf.mul       v22, v25, v33
    s.movz       s37, #15
    vf.add       v24, v0, v22
    v.st.w       [s39, #0], v24
    a.vread      v0, a3, s46
    s.addi       s39, s25, #8384
    v.extract    s45, v27, #15
    v.splat      v22, s45
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v33
    s.addi       s38, s25, #16640
    vf.add       v24, v0, v23
    s.movz       s45, #0
    v.st.w       [s34, #0], v24
    a.vread      v0, a3, s41
    s.addi       s34, s25, #8448
    v.extract    s41, v27, #0
    v.splat      v23, s41
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v33
    s.addi       s40, s38, #64
    vf.add       v24, v0, v19
    s.movz       s41, #1
    v.st.w       [s28, #0], v24
    a.vread      v0, a3, s42
    s.addi       s28, s25, #8512
    v.extract    s42, v27, #1
    v.splat      v19, s42
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v33
    s.addi       s32, s38, #128
    vf.add       v24, v0, v20
    s.movz       s42, #2
    v.st.w       [s35, #0], v24
    a.vread      v0, a3, s44
    s.addi       s35, s25, #8576
    v.extract    s44, v27, #2
    v.splat      v20, s44
    v.ld.w       v24, [s43, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v33
    s.addi       s43, s38, #192
    vf.add       v24, v0, v21
    s.movz       s44, #3
    v.st.w       [s36, #0], v24
    a.vread      v0, a3, s37
    s.addi       s36, s25, #8640
    v.extract    s37, v27, #3
    v.splat      v21, s37
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v33
    s.addi       s37, s38, #256
    vf.add       v24, v0, v22
    s.movz       s39, #4
    v.st.w       [s31, #0], v24
    fence.acq_rel.device
    a.vread      v0, a4, s45
    s.addi       s31, s25, #8704
    v.extract    s45, v27, #4
    v.splat      v22, s45
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v23
    s.addi       s34, s38, #320
    vf.mul       v23, v25, v34
    s.movz       s45, #5
    vf.add       v24, v0, v23
    v.st.w       [s38, #0], v24
    a.vread      v0, a4, s41
    s.addi       s41, s25, #8768
    v.extract    s46, v27, #5
    v.splat      v23, s46
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v19
    s.addi       s28, s38, #384
    vf.mul       v19, v25, v34
    s.movz       s46, #6
    vf.add       v24, v0, v19
    v.st.w       [s40, #0], v24
    a.vread      v0, a4, s42
    s.addi       s40, s25, #8832
    v.extract    s42, v27, #6
    v.splat      v19, s42
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s38, #448
    vf.mul       v20, v25, v34
    s.movz       s42, #7
    vf.add       v24, v0, v20
    v.st.w       [s32, #0], v24
    a.vread      v0, a4, s44
    s.addi       s32, s25, #8896
    v.extract    s44, v27, #7
    v.splat      v20, s44
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v21
    s.addi       s36, s38, #512
    vf.mul       v21, v25, v34
    s.movz       s44, #8
    vf.add       v24, v0, v21
    v.st.w       [s43, #0], v24
    a.vread      v0, a4, s39
    s.addi       s39, s25, #8960
    v.extract    s43, v27, #8
    v.splat      v21, s43
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v22
    s.addi       s31, s38, #576
    vf.mul       v22, v25, v34
    s.movz       s43, #9
    vf.add       v24, v0, v22
    v.st.w       [s37, #0], v24
    a.vread      v0, a4, s45
    s.addi       s37, s25, #9024
    v.extract    s45, v27, #9
    v.splat      v22, s45
    v.ld.w       v24, [s41, #0]
    vf.mul       v25, v24, v23
    s.addi       s41, s38, #640
    vf.mul       v23, v25, v34
    s.movz       s45, #10
    vf.add       v24, v0, v23
    v.st.w       [s34, #0], v24
    a.vread      v0, a4, s46
    s.addi       s34, s25, #9088
    v.extract    s46, v27, #10
    v.splat      v23, s46
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    s.addi       s40, s38, #704
    vf.mul       v19, v25, v34
    s.movz       s46, #11
    vf.add       v24, v0, v19
    v.st.w       [s28, #0], v24
    a.vread      v0, a4, s42
    s.addi       s28, s25, #9152
    v.extract    s42, v27, #11
    v.splat      v19, s42
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v20
    s.addi       s32, s38, #768
    vf.mul       v20, v25, v34
    s.movz       s42, #12
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a4, s44
    s.addi       s35, s25, #9216
    v.extract    s44, v27, #12
    v.splat      v20, s44
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v21
    s.addi       s39, s38, #832
    vf.mul       v21, v25, v34
    s.movz       s44, #13
    vf.add       v24, v0, v21
    v.st.w       [s36, #0], v24
    a.vread      v0, a4, s43
    s.addi       s36, s25, #9280
    v.extract    s43, v27, #13
    v.splat      v21, s43
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    s.addi       s37, s38, #896
    vf.mul       v22, v25, v34
    s.movz       s43, #14
    vf.add       v24, v0, v22
    v.st.w       [s31, #0], v24
    a.vread      v0, a4, s45
    s.addi       s31, s25, #9344
    v.extract    s45, v27, #14
    v.splat      v22, s45
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v23
    s.addi       s34, s38, #960
    vf.mul       v23, v25, v34
    s.movz       s38, #15
    vf.add       v24, v0, v23
    v.st.w       [s41, #0], v24
    a.vread      v0, a4, s46
    s.addi       s41, s25, #9408
    v.extract    s45, v27, #15
    v.splat      v23, s45
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v34
    s.addi       s28, s25, #17664
    vf.add       v24, v0, v19
    s.movz       s45, #0
    v.st.w       [s40, #0], v24
    a.vread      v0, a4, s42
    s.addi       s40, s25, #9472
    v.extract    s42, v27, #0
    v.splat      v19, s42
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v34
    s.addi       s35, s28, #64
    vf.add       v24, v0, v20
    s.movz       s42, #1
    v.st.w       [s32, #0], v24
    a.vread      v0, a4, s44
    s.addi       s32, s25, #9536
    v.extract    s44, v27, #1
    v.splat      v20, s44
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v34
    s.addi       s36, s28, #128
    vf.add       v24, v0, v21
    s.movz       s44, #2
    v.st.w       [s39, #0], v24
    a.vread      v0, a4, s43
    s.addi       s39, s25, #9600
    v.extract    s43, v27, #2
    v.splat      v21, s43
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v34
    s.addi       s31, s28, #192
    vf.add       v24, v0, v22
    s.movz       s43, #3
    v.st.w       [s37, #0], v24
    a.vread      v0, a4, s38
    s.addi       s37, s25, #9664
    v.extract    s38, v27, #3
    v.splat      v22, s38
    v.ld.w       v24, [s41, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v34
    s.addi       s38, s28, #256
    vf.add       v24, v0, v23
    s.movz       s41, #4
    v.st.w       [s34, #0], v24
    fence.acq_rel.device
    a.vread      v0, a5, s45
    s.addi       s34, s25, #9728
    v.extract    s45, v27, #4
    v.splat      v23, s45
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    s.addi       s40, s28, #320
    vf.mul       v19, v25, v35
    s.movz       s45, #5
    vf.add       v24, v0, v19
    v.st.w       [s28, #0], v24
    a.vread      v0, a5, s42
    s.addi       s42, s25, #9792
    v.extract    s46, v27, #5
    v.splat      v19, s46
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v20
    s.addi       s32, s28, #384
    vf.mul       v20, v25, v35
    s.movz       s46, #6
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a5, s44
    s.addi       s35, s25, #9856
    v.extract    s44, v27, #6
    v.splat      v20, s44
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v21
    s.addi       s39, s28, #448
    vf.mul       v21, v25, v35
    s.movz       s44, #7
    vf.add       v24, v0, v21
    v.st.w       [s36, #0], v24
    a.vread      v0, a5, s43
    s.addi       s36, s25, #9920
    v.extract    s43, v27, #7
    v.splat      v21, s43
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    s.addi       s37, s28, #512
    vf.mul       v22, v25, v35
    s.movz       s43, #8
    vf.add       v24, v0, v22
    v.st.w       [s31, #0], v24
    a.vread      v0, a5, s41
    s.addi       s31, s25, #9984
    v.extract    s41, v27, #8
    v.splat      v22, s41
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v23
    s.addi       s34, s28, #576
    vf.mul       v23, v25, v35
    s.movz       s41, #9
    vf.add       v24, v0, v23
    v.st.w       [s38, #0], v24
    a.vread      v0, a5, s45
    s.addi       s38, s25, #10048
    v.extract    s45, v27, #9
    v.splat      v23, s45
    v.ld.w       v24, [s42, #0]
    vf.mul       v25, v24, v19
    s.addi       s42, s28, #640
    vf.mul       v19, v25, v35
    s.movz       s45, #10
    vf.add       v24, v0, v19
    v.st.w       [s40, #0], v24
    a.vread      v0, a5, s46
    s.addi       s40, s25, #10112
    v.extract    s46, v27, #10
    v.splat      v19, s46
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s28, #704
    vf.mul       v20, v25, v35
    s.movz       s46, #11
    vf.add       v24, v0, v20
    v.st.w       [s32, #0], v24
    a.vread      v0, a5, s44
    s.addi       s32, s25, #10176
    v.extract    s44, v27, #11
    v.splat      v20, s44
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v21
    s.addi       s36, s28, #768
    vf.mul       v21, v25, v35
    s.movz       s44, #12
    vf.add       v24, v0, v21
    v.st.w       [s39, #0], v24
    a.vread      v0, a5, s43
    s.addi       s39, s25, #10240
    v.extract    s43, v27, #12
    v.splat      v21, s43
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v22
    s.addi       s31, s28, #832
    vf.mul       v22, v25, v35
    s.movz       s43, #13
    vf.add       v24, v0, v22
    v.st.w       [s37, #0], v24
    a.vread      v0, a5, s41
    s.addi       s37, s25, #10304
    v.extract    s41, v27, #13
    v.splat      v22, s41
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v23
    s.addi       s38, s28, #896
    vf.mul       v23, v25, v35
    s.movz       s41, #14
    vf.add       v24, v0, v23
    v.st.w       [s34, #0], v24
    a.vread      v0, a5, s45
    s.addi       s34, s25, #10368
    v.extract    s45, v27, #14
    v.splat      v23, s45
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    s.addi       s40, s28, #960
    vf.mul       v19, v25, v35
    s.movz       s28, #15
    vf.add       v24, v0, v19
    v.st.w       [s42, #0], v24
    a.vread      v0, a5, s46
    s.addi       s42, s25, #10432
    v.extract    s45, v27, #15
    v.splat      v19, s45
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v35
    s.addi       s32, s25, #18688
    vf.add       v24, v0, v20
    s.movz       s45, #0
    v.st.w       [s35, #0], v24
    a.vread      v0, a5, s44
    s.addi       s35, s25, #10496
    v.extract    s44, v27, #0
    v.splat      v20, s44
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v35
    s.addi       s39, s32, #64
    vf.add       v24, v0, v21
    s.movz       s44, #1
    v.st.w       [s36, #0], v24
    a.vread      v0, a5, s43
    s.addi       s36, s25, #10560
    v.extract    s43, v27, #1
    v.splat      v21, s43
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v35
    s.addi       s37, s32, #128
    vf.add       v24, v0, v22
    s.movz       s43, #2
    v.st.w       [s31, #0], v24
    a.vread      v0, a5, s41
    s.addi       s31, s25, #10624
    v.extract    s41, v27, #2
    v.splat      v22, s41
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v35
    s.addi       s34, s32, #192
    vf.add       v24, v0, v23
    s.movz       s41, #3
    v.st.w       [s38, #0], v24
    a.vread      v0, a5, s28
    s.addi       s28, s25, #10688
    v.extract    s38, v27, #3
    v.splat      v23, s38
    v.ld.w       v24, [s42, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v35
    s.addi       s38, s32, #256
    vf.add       v24, v0, v19
    s.movz       s42, #4
    v.st.w       [s40, #0], v24
    fence.acq_rel.device
    a.vread      v0, a6, s45
    s.addi       s40, s25, #10752
    v.extract    s45, v27, #4
    v.splat      v19, s45
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s32, #320
    vf.mul       v20, v25, v36
    s.movz       s45, #5
    vf.add       v24, v0, v20
    v.st.w       [s32, #0], v24
    a.vread      v0, a6, s44
    s.addi       s44, s25, #10816
    v.extract    s46, v27, #5
    v.splat      v20, s46
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v21
    s.addi       s36, s32, #384
    vf.mul       v21, v25, v36
    s.movz       s46, #6
    vf.add       v24, v0, v21
    v.st.w       [s39, #0], v24
    a.vread      v0, a6, s43
    s.addi       s39, s25, #10880
    v.extract    s43, v27, #6
    v.splat      v21, s43
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v22
    s.addi       s31, s32, #448
    vf.mul       v22, v25, v36
    s.movz       s43, #7
    vf.add       v24, v0, v22
    v.st.w       [s37, #0], v24
    a.vread      v0, a6, s41
    s.addi       s37, s25, #10944
    v.extract    s41, v27, #7
    v.splat      v22, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v23
    s.addi       s28, s32, #512
    vf.mul       v23, v25, v36
    s.movz       s41, #8
    vf.add       v24, v0, v23
    v.st.w       [s34, #0], v24
    a.vread      v0, a6, s42
    s.addi       s34, s25, #11008
    v.extract    s42, v27, #8
    v.splat      v23, s42
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    s.addi       s40, s32, #576
    vf.mul       v19, v25, v36
    s.movz       s42, #9
    vf.add       v24, v0, v19
    v.st.w       [s38, #0], v24
    a.vread      v0, a6, s45
    s.addi       s38, s25, #11072
    v.extract    s45, v27, #9
    v.splat      v19, s45
    v.ld.w       v24, [s44, #0]
    vf.mul       v25, v24, v20
    s.addi       s44, s32, #640
    vf.mul       v20, v25, v36
    s.movz       s45, #10
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a6, s46
    s.addi       s35, s25, #11136
    v.extract    s46, v27, #10
    v.splat      v20, s46
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v21
    s.addi       s39, s32, #704
    vf.mul       v21, v25, v36
    s.movz       s46, #11
    vf.add       v24, v0, v21
    v.st.w       [s36, #0], v24
    a.vread      v0, a6, s43
    s.addi       s36, s25, #11200
    v.extract    s43, v27, #11
    v.splat      v21, s43
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    s.addi       s37, s32, #768
    vf.mul       v22, v25, v36
    s.movz       s43, #12
    vf.add       v24, v0, v22
    v.st.w       [s31, #0], v24
    a.vread      v0, a6, s41
    s.addi       s31, s25, #11264
    v.extract    s41, v27, #12
    v.splat      v22, s41
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v23
    s.addi       s34, s32, #832
    vf.mul       v23, v25, v36
    s.movz       s41, #13
    vf.add       v24, v0, v23
    v.st.w       [s28, #0], v24
    a.vread      v0, a6, s42
    s.addi       s28, s25, #11328
    v.extract    s42, v27, #13
    v.splat      v23, s42
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v19
    s.addi       s38, s32, #896
    vf.mul       v19, v25, v36
    s.movz       s42, #14
    vf.add       v24, v0, v19
    v.st.w       [s40, #0], v24
    a.vread      v0, a6, s45
    s.addi       s40, s25, #11392
    v.extract    s45, v27, #14
    v.splat      v19, s45
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s32, #960
    vf.mul       v20, v25, v36
    s.movz       s32, #15
    vf.add       v24, v0, v20
    v.st.w       [s44, #0], v24
    a.vread      v0, a6, s46
    s.addi       s44, s25, #11456
    v.extract    s45, v27, #15
    v.splat      v20, s45
    v.ld.w       v24, [s36, #0]
    vf.mul       v25, v24, v21
    vf.mul       v21, v25, v36
    s.addi       s36, s25, #19712
    vf.add       v24, v0, v21
    s.movz       s45, #0
    v.st.w       [s39, #0], v24
    a.vread      v0, a6, s43
    s.addi       s39, s25, #11520
    v.extract    s43, v27, #0
    v.splat      v21, s43
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v36
    s.addi       s31, s36, #64
    vf.add       v24, v0, v22
    s.movz       s43, #1
    v.st.w       [s37, #0], v24
    a.vread      v0, a6, s41
    s.addi       s37, s25, #11584
    v.extract    s41, v27, #1
    v.splat      v22, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v23
    vf.mul       v23, v25, v36
    s.addi       s28, s36, #128
    vf.add       v24, v0, v23
    s.movz       s41, #2
    v.st.w       [s34, #0], v24
    a.vread      v0, a6, s42
    s.addi       s34, s25, #11648
    v.extract    s42, v27, #2
    v.splat      v23, s42
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    vf.mul       v19, v25, v36
    s.addi       s40, s36, #192
    vf.add       v24, v0, v19
    s.movz       s42, #3
    v.st.w       [s38, #0], v24
    a.vread      v0, a6, s32
    s.addi       s32, s25, #11712
    v.extract    s38, v27, #3
    v.splat      v19, s38
    v.ld.w       v24, [s44, #0]
    vf.mul       v25, v24, v20
    vf.mul       v20, v25, v36
    s.addi       s38, s36, #256
    vf.add       v24, v0, v20
    s.movz       s44, #4
    v.st.w       [s35, #0], v24
    fence.acq_rel.device
    a.vread      v0, a7, s45
    s.addi       s35, s25, #11776
    v.extract    s45, v27, #4
    v.splat      v20, s45
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v21
    s.addi       s39, s36, #320
    vf.mul       v21, v25, v37
    s.movz       s45, #5
    vf.add       v24, v0, v21
    v.st.w       [s36, #0], v24
    a.vread      v0, a7, s43
    s.addi       s43, s25, #11840
    v.extract    s46, v27, #5
    v.splat      v21, s46
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    s.addi       s37, s36, #384
    vf.mul       v22, v25, v37
    s.movz       s46, #6
    vf.add       v24, v0, v22
    v.st.w       [s31, #0], v24
    a.vread      v0, a7, s41
    s.addi       s31, s25, #11904
    v.extract    s41, v27, #6
    v.splat      v22, s41
    v.ld.w       v24, [s34, #0]
    vf.mul       v25, v24, v23
    s.addi       s34, s36, #448
    vf.mul       v23, v25, v37
    s.movz       s41, #7
    vf.add       v24, v0, v23
    v.st.w       [s28, #0], v24
    a.vread      v0, a7, s42
    s.addi       s28, s25, #11968
    v.extract    s42, v27, #7
    v.splat      v23, s42
    v.ld.w       v24, [s32, #0]
    vf.mul       v25, v24, v19
    s.addi       s32, s36, #512
    vf.mul       v19, v25, v37
    s.movz       s42, #8
    vf.add       v24, v0, v19
    v.st.w       [s40, #0], v24
    a.vread      v0, a7, s44
    s.addi       s40, s25, #12032
    v.extract    s44, v27, #8
    v.splat      v19, s44
    v.ld.w       v24, [s35, #0]
    vf.mul       v25, v24, v20
    s.addi       s35, s36, #576
    vf.mul       v20, v25, v37
    s.movz       s44, #9
    vf.add       v24, v0, v20
    v.st.w       [s38, #0], v24
    a.vread      v0, a7, s45
    s.addi       s38, s25, #12096
    v.extract    s45, v27, #9
    v.splat      v20, s45
    v.ld.w       v24, [s43, #0]
    vf.mul       v25, v24, v21
    s.addi       s43, s36, #640
    vf.mul       v21, v25, v37
    s.movz       s45, #10
    vf.add       v24, v0, v21
    v.st.w       [s39, #0], v24
    a.vread      v0, a7, s46
    s.addi       s39, s25, #12160
    v.extract    s46, v27, #10
    v.splat      v21, s46
    v.ld.w       v24, [s31, #0]
    vf.mul       v25, v24, v22
    s.addi       s31, s36, #704
    vf.mul       v22, v25, v37
    s.movz       s46, #11
    vf.add       v24, v0, v22
    v.st.w       [s37, #0], v24
    a.vread      v0, a7, s41
    s.addi       s37, s25, #12224
    v.extract    s41, v27, #11
    v.splat      v22, s41
    v.ld.w       v24, [s28, #0]
    vf.mul       v25, v24, v23
    s.addi       s28, s36, #768
    vf.mul       v23, v25, v37
    s.movz       s41, #12
    vf.add       v24, v0, v23
    v.st.w       [s34, #0], v24
    a.vread      v0, a7, s42
    s.addi       s34, s25, #12288
    v.extract    s42, v27, #12
    v.splat      v23, s42
    v.ld.w       v24, [s40, #0]
    vf.mul       v25, v24, v19
    s.addi       s40, s36, #832
    vf.mul       v19, v25, v37
    s.movz       s42, #13
    vf.add       v24, v0, v19
    v.st.w       [s32, #0], v24
    a.vread      v0, a7, s44
    s.addi       s32, s25, #12352
    v.extract    s44, v27, #13
    v.splat      v19, s44
    v.ld.w       v24, [s38, #0]
    vf.mul       v25, v24, v20
    s.addi       s38, s36, #896
    vf.mul       v20, v25, v37
    s.movz       s44, #14
    vf.add       v24, v0, v20
    v.st.w       [s35, #0], v24
    a.vread      v0, a7, s45
    s.addi       s35, s25, #12416
    v.extract    s45, v27, #14
    v.splat      v20, s45
    v.ld.w       v24, [s39, #0]
    vf.mul       v25, v24, v21
    s.addi       s39, s36, #960
    vf.mul       v21, v25, v37
    s.movz       s36, #15
    vf.add       v24, v0, v21
    v.st.w       [s43, #0], v24
    a.vread      v0, a7, s46
    s.addi       s43, s25, #12480
    v.extract    s45, v27, #15
    v.splat      v21, s45
    v.ld.w       v24, [s37, #0]
    vf.mul       v25, v24, v22
    vf.mul       v22, v25, v37
    s.addi       s37, s21, #128
    vf.add       v24, v0, v22
    s.addi       s45, s37, #0
    v.st.w       [s31, #0], v24
    a.vread      v0, a7, s41
    s.addi       s31, s22, #128
    s.movz       s37, #0
    s.addi       s41, s31, #0
    v.ld.w       v22, [s34, #0]
    s.addi       s31, s25, #12544
    vf.mul       v24, v22, v23
    s.movz       s34, #1
    vf.mul       v22, v24, v37
    s.addi       s46, s25, #12608
    vf.add       v23, v0, v22
    v.st.w       [s28, #0], v23
    a.vread      v0, a7, s42
    s.addi       s28, s25, #12672
    s.movz       s42, #2
    v.ld.w       v22, [s32, #0]
    s.addi       s32, s25, #12736
    s.movz       s48, #3
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v37
    s.movz       s49, #4
    vf.add       v22, v0, v19
    s.addi       s50, s25, #12800
    v.st.w       [s40, #0], v22
    a.vread      v0, a7, s44
    s.addi       s40, s25, #12864
    s.movz       s44, #5
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s25, #12928
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v37
    vf.add       v20, v0, v19
    v.st.w       [s38, #0], v20
    a.vread      v0, a7, s36
    s.movz       s36, #6
    s.addi       s38, s25, #12992
    v.ld.w       v19, [s43, #0]
    s.movz       s43, #7
    vf.mul       v20, v19, v21
    vf.mul       v19, v20, v37
    vf.add       v20, v0, v19
    v.st.w       [s39, #0], v20
    fence.acq_rel.device
    s.mov        s21, s45
    s.mov        s22, s41
    s.addi       s39, s25, #13056
    s.movz       s41, #8
    s.addi       s45, s25, #13120
    s.movz       s51, #9
    s.addi       s52, s25, #13184
    v.ld.w       v0, [s31, #0]
    s.movz       s31, #10
    a.vwrite     a0, s37, v0
    v.ld.w       v0, [s46, #0]
    s.addi       s46, s25, #13248
    a.vwrite     a0, s34, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s28, #11
    a.vwrite     a0, s42, v0
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s25, #13312
    a.vwrite     a0, s48, v0
    v.ld.w       v0, [s50, #0]
    s.movz       s50, #12
    a.vwrite     a0, s49, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s25, #13376
    a.vwrite     a0, s44, v0
    v.ld.w       v0, [s35, #0]
    s.movz       s35, #13
    a.vwrite     a0, s36, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s25, #13440
    a.vwrite     a0, s43, v0
    v.ld.w       v0, [s39, #0]
    s.movz       s39, #14
    a.vwrite     a0, s41, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s25, #13504
    a.vwrite     a0, s51, v0
    v.ld.w       v0, [s52, #0]
    s.movz       s52, #15
    a.vwrite     a0, s31, v0
    v.ld.w       v0, [s46, #0]
    s.addi       s46, s25, #13568
    a.vwrite     a0, s28, v0
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s25, #13632
    a.vwrite     a0, s50, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s25, #13696
    a.vwrite     a0, s35, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s25, #13760
    a.vwrite     a0, s39, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s25, #13824
    a.vwrite     a0, s52, v0
    v.ld.w       v0, [s46, #0]
    s.addi       s46, s25, #13888
    a.vwrite     a1, s37, v0
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s25, #13952
    s.addi       s37, s25, #14016
    a.vwrite     a1, s34, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s34, s25, #14080
    s.addi       s40, s25, #14144
    a.vwrite     a1, s42, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s25, #14208
    s.addi       s42, s25, #14272
    a.vwrite     a1, s48, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s45, s25, #14336
    s.addi       s48, s25, #14400
    a.vwrite     a1, s49, v0
    v.ld.w       v0, [s46, #0]
    s.addi       s46, s25, #14464
    s.addi       s49, s25, #14528
    a.vwrite     a1, s44, v0
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s25, #14592
    s.movz       s44, #0
    a.vwrite     a1, s36, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s36, s25, #14656
    s.movz       s37, #1
    a.vwrite     a1, s43, v0
    v.ld.w       v0, [s34, #0]
    s.addi       s34, s25, #14720
    s.movz       s43, #2
    a.vwrite     a1, s41, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s25, #14784
    s.movz       s41, #3
    a.vwrite     a1, s51, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s25, #14848
    s.movz       s51, #4
    a.vwrite     a1, s31, v0
    v.ld.w       v0, [s42, #0]
    s.addi       s31, s25, #14912
    s.movz       s42, #5
    a.vwrite     a1, s28, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s28, s25, #14976
    s.movz       s45, #6
    a.vwrite     a1, s50, v0
    v.ld.w       v0, [s48, #0]
    s.addi       s48, s25, #15040
    s.movz       s50, #7
    a.vwrite     a1, s35, v0
    v.ld.w       v0, [s46, #0]
    s.addi       s35, s25, #15104
    s.movz       s46, #8
    a.vwrite     a1, s39, v0
    v.ld.w       v0, [s49, #0]
    s.addi       s39, s25, #15168
    s.movz       s49, #9
    a.vwrite     a1, s52, v0
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s25, #15232
    s.movz       s52, #10
    a.vwrite     a2, s44, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s25, #15296
    a.vwrite     a2, s37, v0
    v.ld.w       v0, [s34, #0]
    s.movz       s34, #11
    a.vwrite     a2, s43, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s25, #15360
    a.vwrite     a2, s41, v0
    v.ld.w       v0, [s38, #0]
    s.movz       s38, #12
    a.vwrite     a2, s51, v0
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s25, #15424
    a.vwrite     a2, s42, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s28, #13
    a.vwrite     a2, s45, v0
    v.ld.w       v0, [s48, #0]
    s.addi       s48, s25, #15488
    a.vwrite     a2, s50, v0
    v.ld.w       v0, [s35, #0]
    s.movz       s35, #14
    a.vwrite     a2, s46, v0
    v.ld.w       v0, [s39, #0]
    s.addi       s39, s25, #15552
    a.vwrite     a2, s49, v0
    v.ld.w       v0, [s32, #0]
    s.movz       s32, #15
    a.vwrite     a2, s52, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s25, #15616
    a.vwrite     a2, s34, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s25, #15680
    a.vwrite     a2, s38, v0
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s25, #15744
    a.vwrite     a2, s28, v0
    v.ld.w       v0, [s48, #0]
    s.addi       s48, s25, #15808
    a.vwrite     a2, s35, v0
    v.ld.w       v0, [s39, #0]
    s.addi       s39, s25, #15872
    a.vwrite     a2, s32, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s25, #15936
    a.vwrite     a3, s44, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s25, #16000
    s.addi       s44, s25, #16064
    a.vwrite     a3, s37, v0
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s25, #16128
    s.addi       s37, s25, #16192
    a.vwrite     a3, s43, v0
    v.ld.w       v0, [s48, #0]
    s.addi       s43, s25, #16256
    s.addi       s48, s25, #16320
    a.vwrite     a3, s41, v0
    v.ld.w       v0, [s39, #0]
    s.addi       s39, s25, #16384
    s.addi       s41, s25, #16448
    a.vwrite     a3, s51, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s25, #16512
    s.addi       s51, s25, #16576
    a.vwrite     a3, s42, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s25, #16640
    s.movz       s42, #0
    a.vwrite     a3, s45, v0
    v.ld.w       v0, [s44, #0]
    s.addi       s44, s25, #16704
    s.movz       s45, #1
    a.vwrite     a3, s50, v0
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s25, #16768
    s.movz       s50, #2
    a.vwrite     a3, s46, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s25, #16832
    s.movz       s46, #3
    a.vwrite     a3, s49, v0
    v.ld.w       v0, [s43, #0]
    s.addi       s43, s25, #16896
    s.movz       s49, #4
    a.vwrite     a3, s52, v0
    v.ld.w       v0, [s48, #0]
    s.addi       s48, s25, #16960
    s.movz       s52, #5
    a.vwrite     a3, s34, v0
    v.ld.w       v0, [s39, #0]
    s.addi       s34, s25, #17024
    s.movz       s39, #6
    a.vwrite     a3, s38, v0
    v.ld.w       v0, [s41, #0]
    s.addi       s38, s25, #17088
    s.movz       s41, #7
    a.vwrite     a3, s28, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s28, s25, #17152
    s.movz       s36, #8
    a.vwrite     a3, s35, v0
    v.ld.w       v0, [s51, #0]
    s.addi       s35, s25, #17216
    s.movz       s51, #9
    a.vwrite     a3, s32, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s32, s25, #17280
    s.movz       s40, #10
    a.vwrite     a4, s42, v0
    v.ld.w       v0, [s44, #0]
    s.addi       s44, s25, #17344
    a.vwrite     a4, s45, v0
    v.ld.w       v0, [s31, #0]
    s.movz       s31, #11
    a.vwrite     a4, s50, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s25, #17408
    a.vwrite     a4, s46, v0
    v.ld.w       v0, [s43, #0]
    s.movz       s43, #12
    a.vwrite     a4, s49, v0
    v.ld.w       v0, [s48, #0]
    s.addi       s48, s25, #17472
    a.vwrite     a4, s52, v0
    v.ld.w       v0, [s34, #0]
    s.movz       s34, #13
    a.vwrite     a4, s39, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s25, #17536
    a.vwrite     a4, s41, v0
    v.ld.w       v0, [s28, #0]
    s.movz       s28, #14
    a.vwrite     a4, s36, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s35, s25, #17600
    a.vwrite     a4, s51, v0
    v.ld.w       v0, [s32, #0]
    s.movz       s32, #15
    a.vwrite     a4, s40, v0
    v.ld.w       v0, [s44, #0]
    s.addi       s44, s25, #17664
    a.vwrite     a4, s31, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s25, #17728
    a.vwrite     a4, s43, v0
    v.ld.w       v0, [s48, #0]
    s.addi       s48, s25, #17792
    a.vwrite     a4, s34, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s25, #17856
    a.vwrite     a4, s28, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s35, s25, #17920
    a.vwrite     a4, s32, v0
    v.ld.w       v0, [s44, #0]
    s.addi       s44, s25, #17984
    a.vwrite     a5, s42, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s25, #18048
    s.addi       s42, s25, #18112
    a.vwrite     a5, s45, v0
    v.ld.w       v0, [s48, #0]
    s.addi       s45, s25, #18176
    s.addi       s48, s25, #18240
    a.vwrite     a5, s50, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s25, #18304
    s.addi       s50, s25, #18368
    a.vwrite     a5, s46, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s35, s25, #18432
    s.addi       s46, s25, #18496
    a.vwrite     a5, s49, v0
    v.ld.w       v0, [s44, #0]
    s.addi       s44, s25, #18560
    s.addi       s49, s25, #18624
    a.vwrite     a5, s52, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s37, s25, #18688
    s.movz       s52, #0
    a.vwrite     a5, s39, v0
    v.ld.w       v0, [s42, #0]
    s.addi       s39, s25, #18752
    s.movz       s42, #1
    a.vwrite     a5, s41, v0
    v.ld.w       v0, [s45, #0]
    s.addi       s41, s25, #18816
    s.movz       s45, #2
    a.vwrite     a5, s36, v0
    v.ld.w       v0, [s48, #0]
    s.addi       s36, s25, #18880
    s.movz       s48, #3
    a.vwrite     a5, s51, v0
    v.ld.w       v0, [s38, #0]
    s.addi       s38, s25, #18944
    s.movz       s51, #4
    a.vwrite     a5, s40, v0
    v.ld.w       v0, [s50, #0]
    s.addi       s40, s25, #19008
    s.movz       s50, #5
    a.vwrite     a5, s31, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s31, s25, #19072
    s.movz       s35, #6
    a.vwrite     a5, s43, v0
    v.ld.w       v0, [s46, #0]
    s.addi       s43, s25, #19136
    s.movz       s46, #7
    a.vwrite     a5, s34, v0
    v.ld.w       v0, [s44, #0]
    s.addi       s34, s25, #19200
    s.movz       s44, #8
    a.vwrite     a5, s28, v0
    v.ld.w       v0, [s49, #0]
    s.addi       s28, s25, #19264
    s.movz       s49, #9
    a.vwrite     a5, s32, v0
    v.ld.w       v0, [s37, #0]
    s.addi       s32, s25, #19328
    s.movz       s37, #10
    a.vwrite     a6, s52, v0
    v.ld.w       v0, [s39, #0]
    s.addi       s39, s25, #19392
    a.vwrite     a6, s42, v0
    v.ld.w       v0, [s41, #0]
    s.movz       s41, #11
    a.vwrite     a6, s45, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s25, #19456
    a.vwrite     a6, s48, v0
    v.ld.w       v0, [s38, #0]
    s.movz       s38, #12
    a.vwrite     a6, s51, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s25, #19520
    a.vwrite     a6, s50, v0
    v.ld.w       v0, [s31, #0]
    s.movz       s31, #13
    a.vwrite     a6, s35, v0
    v.ld.w       v0, [s43, #0]
    s.addi       s43, s25, #19584
    a.vwrite     a6, s46, v0
    v.ld.w       v0, [s34, #0]
    s.movz       s34, #14
    a.vwrite     a6, s44, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s25, #19648
    a.vwrite     a6, s49, v0
    v.ld.w       v0, [s32, #0]
    s.movz       s32, #15
    a.vwrite     a6, s37, v0
    v.ld.w       v0, [s39, #0]
    s.addi       s39, s25, #19712
    a.vwrite     a6, s41, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s25, #19776
    a.vwrite     a6, s38, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s25, #19840
    a.vwrite     a6, s31, v0
    v.ld.w       v0, [s43, #0]
    s.addi       s43, s25, #19904
    a.vwrite     a6, s34, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s25, #19968
    a.vwrite     a6, s32, v0
    v.ld.w       v0, [s39, #0]
    s.addi       s39, s25, #20032
    s.add        s53, s20, s19
    a.vwrite     a7, s52, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s25, #20096
    s.addi       s52, s25, #20160
    a.vwrite     a7, s42, v0
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s25, #20224
    s.addi       s42, s25, #20288
    a.vwrite     a7, s45, v0
    v.ld.w       v0, [s43, #0]
    s.addi       s43, s25, #20352
    s.addi       s45, s25, #20416
    a.vwrite     a7, s48, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s25, #20480
    s.addi       s48, s25, #20544
    a.vwrite     a7, s51, v0
    v.ld.w       v0, [s39, #0]
    s.addi       s39, s25, #20608
    s.addi       s51, s25, #20672
    s.movz       s25, #1
    a.vwrite     a7, s50, v0
    v.ld.w       v0, [s36, #0]
    a.vwrite     a7, s35, v0
    v.ld.w       v0, [s52, #0]
    a.vwrite     a7, s46, v0
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s44, v0
    v.ld.w       v0, [s42, #0]
    a.vwrite     a7, s49, v0
    v.ld.w       v0, [s43, #0]
    a.vwrite     a7, s37, v0
    v.ld.w       v0, [s45, #0]
    a.vwrite     a7, s41, v0
    v.ld.w       v0, [s28, #0]
    a.vwrite     a7, s38, v0
    v.ld.w       v0, [s48, #0]
    a.vwrite     a7, s31, v0
    v.ld.w       v0, [s39, #0]
    a.vwrite     a7, s34, v0
    v.ld.w       v0, [s51, #0]
    a.vwrite     a7, s32, v0
    s.mov        s20, s53
    br.nz        s25, for_1
endfor_2:
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.muli       s3, s11, #2                     // a runtime tile origin, x2
    s.add        s4, s2, s11                     // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s4
    a.vread      v2, a0, s2
    s.add        s4, s2, s10                     // the tile origin
    s.movz       s2, #384
    s.muli       s5, s10, #768                   // a runtime tile origin, x768
    v.splat      v3, s4
    v.splat      v4, s1
    v.add        v5, v0, v1
    v.splat      v1, s2
    vf.cvt.f32.f16 v6, v2
    s.add        s1, s6, s3                      // the tile origin
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s3, s1, s5                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    @p3 v.st.h       [s3, #0], v6
    a.vread      v1, a0, s1
    s.addi       s1, s4, #1
    s.addi       s5, s3, #768                    // row 1
    v.splat      v2, s1
    vf.cvt.f32.f16 v3, v1
    s.movz       s1, #2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    s.addi       s7, s4, #2
    s.addi       s8, s3, #1536                   // row 2
    v.splat      v1, s7
    s.movz       s7, #3
    s.addi       s9, s11, #16
    @p3 v.st.h       [s5, #0], v3
    a.vread      v2, a0, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.addi       s1, s3, #2304                   // row 3
    s.addi       s5, s11, #32
    s.addi       s12, s4, #3
    s.addi       s13, s11, #48
    v.splat      v2, s12
    s.addi       s12, s11, #64
    s.addi       s14, s11, #80
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    @p3 v.st.h       [s8, #0], v1
    a.vread      v1, a0, s7
    s.addi       s7, s11, #96
    s.addi       s8, s11, #112
    vf.cvt.f32.f16 v2, v1
    s.movz       s11, #4
    s.addi       s15, s4, #4
    s.addi       s16, s3, #3072                  // row 4
    v.splat      v1, s15
    s.movz       s15, #5
    s.addi       s17, s4, #5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    v.splat      v1, s17
    @p4 v.st.h       [s1, #0], v2
    a.vread      v2, a0, s11
    v.cmp.lt     p1, v1, v4
    s.addi       s1, s3, #3840                   // row 5
    vf.cvt.f32.f16 v1, v2
    p.and        p4, p1, p2
    s.movz       s11, #6
    s.addi       s17, s4, #6
    s.addi       s18, s3, #4608                  // row 6
    v.splat      v2, s17
    s.movz       s17, #7
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a0, s15
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s15, s4, #7
    s.addi       s16, s3, #5376                  // row 7
    v.splat      v1, s15
    s.movz       s15, #8
    @p4 v.st.h       [s1, #0], v2
    a.vread      v2, a0, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.addi       s1, s4, #8
    s.addi       s11, s3, #6144                  // row 8
    v.splat      v2, s1
    s.movz       s1, #9
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s17, s4, #9
    s.addi       s18, s3, #6912                  // row 9
    v.splat      v1, s17
    s.movz       s17, #10
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a0, s15
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.addi       s15, s4, #10
    s.addi       s16, s3, #7680                  // row 10
    v.splat      v2, s15
    s.movz       s15, #11
    @p3 v.st.h       [s11, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s1, s4, #11
    s.addi       s11, s3, #8448                  // row 11
    v.splat      v1, s1
    s.movz       s1, #12
    @p4 v.st.h       [s18, #0], v2
    a.vread      v2, a0, s17
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.addi       s17, s4, #12
    s.addi       s18, s3, #9216                  // row 12
    v.splat      v2, s17
    s.movz       s17, #13
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a0, s15
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s15, s4, #13
    s.addi       s16, s3, #9984                  // row 13
    v.splat      v1, s15
    s.movz       s15, #14
    v.splat      v3, s4
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a0, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.addi       s1, s4, #14
    s.addi       s11, s3, #10752                 // row 14
    v.splat      v2, s1
    s.movz       s1, #15
    s.addi       s19, s3, #11520                 // row 15
    v.splat      v5, s2
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s3, s4, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s17, #0
    v.splat      v1, s3
    s.add        s3, s17, s9                     // the tile origin
    s.muli       s18, s9, #2                     // a runtime tile origin, x2
    v.splat      v6, s3
    s.muli       s3, s10, #768                   // a runtime tile origin, x768
    v.add        v7, v0, v6
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a0, s15
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.add        s9, s6, s18                     // the tile origin
    v.cmp.lt     p1, v3, v4
    s.add        s15, s9, s3                     // the tile origin
    s.movz       s3, #1
    s.addi       s9, s4, #1
    s.addi       s16, s15, #768                  // row 1
    v.splat      v2, s9
    s.movz       s9, #2
    @p3 v.st.h       [s11, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p2, v7, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v1
    s.addi       s1, s4, #2
    s.addi       s11, s15, #1536                 // row 2
    v.splat      v1, s1
    s.movz       s1, #3
    @p4 v.st.h       [s19, #0], v3
    a.vread      v3, a1, s17
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v3
    s.addi       s17, s4, #3
    s.addi       s18, s15, #2304                 // row 3
    v.splat      v3, s17
    s.movz       s17, #4
    @p3 v.st.h       [s15, #0], v2
    a.vread      v2, a1, s3
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.addi       s3, s4, #4
    v.splat      v2, s3
    s.addi       s3, s15, #3072                  // row 4
    @p4 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s9
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v1
    s.movz       s9, #5
    s.addi       s16, s4, #5
    v.splat      v1, s16
    s.addi       s16, s15, #3840                 // row 5
    @p3 v.st.h       [s11, #0], v3
    a.vread      v3, a1, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v3
    s.movz       s1, #6
    s.addi       s11, s4, #6
    v.splat      v3, s11
    s.addi       s11, s15, #4608                 // row 6
    @p4 v.st.h       [s18, #0], v2
    a.vread      v2, a1, s17
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.movz       s17, #7
    s.addi       s18, s4, #7
    v.splat      v2, s18
    s.addi       s18, s15, #5376                 // row 7
    @p3 v.st.h       [s3, #0], v1
    a.vread      v1, a1, s9
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v1
    s.movz       s3, #8
    s.addi       s9, s4, #8
    v.splat      v1, s9
    s.addi       s9, s15, #6144                  // row 8
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a1, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v3
    s.movz       s1, #9
    s.addi       s16, s4, #9
    v.splat      v3, s16
    s.addi       s16, s15, #6912                 // row 9
    @p3 v.st.h       [s11, #0], v2
    a.vread      v2, a1, s17
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.movz       s11, #10
    s.addi       s17, s4, #10
    v.splat      v2, s17
    s.addi       s17, s15, #7680                 // row 10
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s3
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v1
    s.movz       s3, #11
    s.addi       s18, s4, #11
    v.splat      v1, s18
    s.addi       s18, s15, #8448                 // row 11
    @p3 v.st.h       [s9, #0], v3
    a.vread      v3, a1, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v3
    s.movz       s1, #12
    s.addi       s9, s4, #12
    v.splat      v3, s9
    s.addi       s9, s15, #9216                  // row 12
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.movz       s11, #13
    s.addi       s16, s4, #13
    v.splat      v2, s16
    s.addi       s16, s15, #9984                 // row 13
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a1, s3
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v1
    s.movz       s3, #14
    s.addi       s17, s4, #14
    v.splat      v1, s4
    v.splat      v5, s17
    s.addi       s17, s15, #10752                // row 14
    s.addi       s19, s15, #11520                // row 15
    @p4 v.st.h       [s18, #0], v3
    a.vread      v3, a1, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v3
    s.movz       s1, #15
    s.addi       s15, s4, #15
    v.splat      v3, s2
    v.splat      v6, s15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s15, #0
    @p3 v.st.h       [s9, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.add        s9, s15, s5                     // the tile origin
    s.muli       s11, s5, #2                     // a runtime tile origin, x2
    v.splat      v2, s9
    s.muli       s5, s10, #768                   // a runtime tile origin, x768
    s.movz       s9, #1
    v.add        v7, v0, v2
    s.add        s18, s6, s11                    // the tile origin
    s.add        s11, s18, s5                    // the tile origin
    @p4 v.st.h       [s16, #0], v5
    a.vread      v2, a1, s3
    v.cmp.lt     p1, v6, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v2
    v.cmp.lt     p1, v1, v4
    s.addi       s3, s4, #1
    s.addi       s5, s11, #768                   // row 1
    v.splat      v1, s3
    s.movz       s3, #2
    s.addi       s16, s4, #2
    v.splat      v2, s16
    s.addi       s16, s11, #1536                 // row 2
    @p3 v.st.h       [s17, #0], v5
    a.vread      v5, a1, s1
    v.cmp.lt     p2, v7, v3
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.movz       s1, #3
    s.addi       s17, s4, #3
    v.splat      v5, s17
    s.addi       s17, s11, #2304                 // row 3
    @p4 v.st.h       [s19, #0], v3
    a.vread      v3, a2, s15
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.movz       s15, #4
    s.addi       s18, s4, #4
    v.splat      v3, s18
    s.addi       s18, s11, #3072                 // row 4
    @p3 v.st.h       [s11, #0], v1
    a.vread      v1, a2, s9
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.movz       s9, #5
    @p4 v.st.h       [s5, #0], v2
    a.vread      v1, a2, s3
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s3, s4, #5
    s.addi       s5, s11, #3840                  // row 5
    v.splat      v1, s3
    s.movz       s3, #6
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a2, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s1, s4, #6
    s.addi       s16, s11, #4608                 // row 6
    v.splat      v2, s1
    s.movz       s1, #7
    @p4 v.st.h       [s17, #0], v3
    a.vread      v3, a2, s15
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.addi       s15, s4, #7
    s.addi       s17, s11, #5376                 // row 7
    v.splat      v3, s15
    s.movz       s15, #8
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s9
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s9, s4, #8
    s.addi       s18, s11, #6144                 // row 8
    v.splat      v1, s9
    s.movz       s9, #9
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a2, s3
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s3, s4, #9
    s.addi       s5, s11, #6912                  // row 9
    v.splat      v2, s3
    s.movz       s3, #10
    @p3 v.st.h       [s16, #0], v3
    a.vread      v3, a2, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.addi       s1, s4, #10
    s.addi       s16, s11, #7680                 // row 10
    v.splat      v3, s1
    s.movz       s1, #11
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a2, s15
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s15, s4, #11
    s.addi       s17, s11, #8448                 // row 11
    v.splat      v1, s15
    s.movz       s15, #12
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a2, s9
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s9, s4, #12
    s.addi       s18, s11, #9216                 // row 12
    v.splat      v2, s9
    s.movz       s9, #13
    @p4 v.st.h       [s5, #0], v3
    a.vread      v3, a2, s3
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.addi       s3, s4, #13
    s.addi       s5, s11, #9984                  // row 13
    v.splat      v3, s3
    s.movz       s3, #14
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a2, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s1, s4, #14
    s.addi       s16, s11, #10752                // row 14
    v.splat      v1, s1
    s.movz       s1, #15
    s.addi       s19, s11, #11520                // row 15
    v.splat      v5, s4
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s15
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s11, s4, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s15, #0
    v.splat      v2, s11
    s.add        s11, s15, s13                   // the tile origin
    s.muli       s17, s13, #2                    // a runtime tile origin, x2
    v.splat      v6, s11
    s.muli       s11, s10, #768                  // a runtime tile origin, x768
    v.splat      v7, s2
    v.add        v8, v0, v6
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s9
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.add        s9, s6, s17                     // the tile origin
    s.movz       s13, #1
    s.add        s17, s9, s11                    // the tile origin
    s.addi       s9, s4, #1
    s.addi       s11, s17, #768                  // row 1
    v.splat      v3, s9
    s.movz       s9, #2
    @p4 v.st.h       [s5, #0], v1
    a.vread      v1, a2, s3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    v.cmp.lt     p1, v5, v4
    s.addi       s3, s4, #2
    s.addi       s5, s17, #1536                  // row 2
    v.splat      v1, s3
    s.movz       s3, #3
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a2, s1
    v.cmp.lt     p2, v8, v7
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.addi       s1, s4, #3
    s.addi       s16, s17, #2304                 // row 3
    v.splat      v2, s1
    s.movz       s1, #4
    @p4 v.st.h       [s19, #0], v5
    a.vread      v5, a3, s15
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.addi       s15, s4, #4
    s.addi       s18, s17, #3072                 // row 4
    v.splat      v5, s15
    s.movz       s15, #5
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a3, s13
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.addi       s13, s4, #5
    v.splat      v3, s13
    s.addi       s13, s17, #3840                 // row 5
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a3, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.movz       s9, #6
    s.addi       s11, s4, #6
    v.splat      v1, s11
    s.addi       s11, s17, #4608                 // row 6
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a3, s3
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.movz       s3, #7
    s.addi       s5, s4, #7
    v.splat      v2, s5
    s.addi       s5, s17, #5376                  // row 7
    @p4 v.st.h       [s16, #0], v5
    a.vread      v5, a3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.movz       s1, #8
    s.addi       s16, s4, #8
    v.splat      v5, s16
    s.addi       s16, s17, #6144                 // row 8
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a3, s15
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.movz       s15, #9
    s.addi       s18, s4, #9
    v.splat      v3, s18
    s.addi       s18, s17, #6912                 // row 9
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a3, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.movz       s9, #10
    s.addi       s13, s4, #10
    v.splat      v1, s13
    s.addi       s13, s17, #7680                 // row 10
    @p3 v.st.h       [s11, #0], v2
    a.vread      v2, a3, s3
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.movz       s3, #11
    s.addi       s11, s4, #11
    v.splat      v2, s11
    s.addi       s11, s17, #8448                 // row 11
    @p4 v.st.h       [s5, #0], v5
    a.vread      v5, a3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.movz       s1, #12
    s.addi       s5, s4, #12
    v.splat      v5, s5
    s.addi       s5, s17, #9216                  // row 12
    @p3 v.st.h       [s16, #0], v3
    a.vread      v3, a3, s15
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.movz       s15, #13
    s.addi       s16, s4, #13
    v.splat      v3, s16
    s.addi       s16, s17, #9984                 // row 13
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.movz       s9, #14
    s.addi       s18, s4, #14
    v.splat      v1, s18
    s.addi       s18, s17, #10752                // row 14
    s.addi       s19, s17, #11520                // row 15
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a3, s3
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.movz       s3, #15
    s.addi       s13, s4, #15
    v.splat      v2, s4
    v.splat      v6, s13
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s13, #0
    @p4 v.st.h       [s11, #0], v5
    a.vread      v5, a3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.add        s1, s13, s12                    // the tile origin
    s.muli       s11, s12, #2                    // a runtime tile origin, x2
    v.splat      v5, s1
    s.muli       s1, s10, #768                   // a runtime tile origin, x768
    v.splat      v7, s2
    v.add        v8, v0, v5
    s.add        s12, s6, s11                    // the tile origin
    s.movz       s11, #1
    s.add        s17, s12, s1                    // the tile origin
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a3, s15
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.addi       s1, s4, #1
    s.addi       s5, s17, #768                   // row 1
    v.splat      v3, s1
    s.movz       s1, #2
    s.addi       s12, s17, #1536                 // row 2
    @p4 v.st.h       [s16, #0], v1
    a.vread      v1, a3, s9
    v.cmp.lt     p1, v6, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s9, s4, #2
    s.movz       s15, #3
    v.splat      v1, s9
    s.addi       s9, s17, #2304                  // row 3
    @p3 v.st.h       [s18, #0], v5
    a.vread      v2, a3, s3
    v.cmp.lt     p2, v8, v7
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.addi       s3, s4, #3
    s.movz       s16, #4
    v.splat      v2, s3
    s.addi       s3, s17, #3072                  // row 4
    @p4 v.st.h       [s19, #0], v5
    a.vread      v5, a4, s13
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.addi       s13, s4, #4
    s.movz       s18, #5
    v.splat      v5, s13
    s.addi       s13, s4, #5
    v.splat      v6, s13
    s.addi       s13, s17, #3840                 // row 5
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a4, s11
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.movz       s11, #6
    @p4 v.st.h       [s5, #0], v1
    a.vread      v1, a4, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s1, s4, #6
    s.addi       s5, s17, #4608                  // row 6
    v.splat      v1, s1
    s.movz       s1, #7
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s15
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s12, s4, #7
    s.addi       s15, s17, #5376                 // row 7
    v.splat      v2, s12
    s.movz       s12, #8
    @p4 v.st.h       [s9, #0], v3
    a.vread      v3, a4, s16
    v.cmp.lt     p1, v6, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v3
    s.addi       s9, s4, #8
    s.addi       s16, s17, #6144                 // row 8
    v.splat      v3, s9
    s.movz       s9, #9
    @p3 v.st.h       [s3, #0], v5
    a.vread      v5, a4, s18
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v5
    s.addi       s3, s4, #9
    s.addi       s18, s17, #6912                 // row 9
    v.splat      v5, s3
    s.movz       s3, #10
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a4, s11
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s11, s4, #10
    s.addi       s13, s17, #7680                 // row 10
    v.splat      v1, s11
    s.movz       s11, #11
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a4, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s1, s4, #11
    s.addi       s5, s17, #8448                  // row 11
    v.splat      v2, s1
    s.movz       s1, #12
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a4, s12
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v3
    s.addi       s12, s4, #12
    s.addi       s15, s17, #9216                 // row 12
    v.splat      v3, s12
    s.movz       s12, #13
    @p3 v.st.h       [s16, #0], v5
    a.vread      v5, a4, s9
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v5
    s.addi       s9, s4, #13
    s.addi       s16, s17, #9984                 // row 13
    v.splat      v5, s9
    s.movz       s9, #14
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a4, s3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s3, s4, #14
    s.addi       s18, s17, #10752                // row 14
    v.splat      v1, s3
    s.movz       s3, #15
    s.addi       s19, s17, #11520                // row 15
    @p3 v.st.h       [s13, #0], v2
    a.vread      v2, a4, s11
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s11, s4, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s13, #0
    v.splat      v2, s11
    s.add        s11, s13, s14                   // the tile origin
    s.muli       s17, s14, #2                    // a runtime tile origin, x2
    v.splat      v6, s11
    s.muli       s11, s10, #768                  // a runtime tile origin, x768
    v.splat      v7, s4
    @p4 v.st.h       [s5, #0], v3
    a.vread      v3, a4, s1
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v3
    v.add        v3, v0, v6
    v.splat      v6, s2
    s.add        s1, s6, s17                     // the tile origin
    s.movz       s5, #1
    s.add        s14, s1, s11                    // the tile origin
    s.addi       s1, s14, #768                   // row 1
    @p3 v.st.h       [s15, #0], v5
    a.vread      v5, a4, s12
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v5
    s.addi       s11, s4, #1
    s.movz       s12, #2
    v.splat      v5, s11
    s.addi       s11, s14, #1536                 // row 2
    @p4 v.st.h       [s16, #0], v1
    a.vread      v1, a4, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    v.cmp.lt     p1, v7, v4
    s.addi       s9, s4, #2
    s.movz       s15, #3
    v.splat      v1, s9
    s.addi       s9, s14, #2304                  // row 3
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a4, s3
    v.cmp.lt     p2, v3, v6
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s3, s4, #3
    s.movz       s16, #4
    v.splat      v2, s3
    s.addi       s3, s14, #3072                  // row 4
    @p4 v.st.h       [s19, #0], v3
    a.vread      v3, a5, s13
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v3
    s.addi       s13, s4, #4
    s.movz       s17, #5
    v.splat      v3, s13
    s.addi       s13, s4, #5
    s.addi       s18, s14, #3840                 // row 5
    v.splat      v6, s13
    s.movz       s13, #6
    @p3 v.st.h       [s14, #0], v5
    a.vread      v5, a5, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v5
    s.addi       s5, s4, #6
    v.splat      v5, s5
    s.addi       s5, s14, #4608                  // row 6
    @p4 v.st.h       [s1, #0], v1
    a.vread      v1, a5, s12
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.movz       s1, #7
    s.addi       s12, s4, #7
    v.splat      v1, s12
    s.addi       s12, s14, #5376                 // row 7
    @p3 v.st.h       [s11, #0], v2
    a.vread      v2, a5, s15
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.movz       s11, #8
    s.addi       s15, s4, #8
    v.splat      v2, s15
    s.addi       s15, s14, #6144                 // row 8
    @p4 v.st.h       [s9, #0], v3
    a.vread      v3, a5, s16
    v.cmp.lt     p1, v6, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v6, v3
    s.movz       s9, #9
    s.addi       s16, s4, #9
    v.splat      v3, s16
    s.addi       s16, s14, #6912                 // row 9
    @p3 v.st.h       [s3, #0], v6
    a.vread      v6, a5, s17
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v6
    s.movz       s3, #10
    s.addi       s17, s4, #10
    v.splat      v6, s17
    s.addi       s17, s14, #7680                 // row 10
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a5, s13
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v5
    s.movz       s13, #11
    s.addi       s18, s4, #11
    v.splat      v5, s18
    s.addi       s18, s14, #8448                 // row 11
    @p3 v.st.h       [s5, #0], v1
    a.vread      v1, a5, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.movz       s1, #12
    s.addi       s5, s4, #12
    v.splat      v1, s5
    s.addi       s5, s14, #9216                  // row 12
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a5, s11
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.movz       s11, #13
    s.addi       s12, s4, #13
    v.splat      v2, s12
    s.addi       s12, s14, #9984                 // row 13
    @p3 v.st.h       [s15, #0], v3
    a.vread      v3, a5, s9
    v.cmp.lt     p1, v6, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v6, v3
    s.movz       s9, #14
    s.addi       s15, s4, #14
    v.splat      v3, s15
    s.addi       s15, s14, #10752                // row 14
    @p4 v.st.h       [s16, #0], v6
    a.vread      v6, a5, s3
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v6
    s.movz       s3, #15
    s.addi       s16, s4, #15
    s.addi       s19, s14, #11520                // row 15
    v.splat      v6, s16
    s.muli       s14, s7, #2                     // a runtime tile origin, x2
    @p3 v.st.h       [s17, #0], v5
    a.vread      v5, a5, s13
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v5
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s13, #0
    s.muli       s16, s10, #768                  // a runtime tile origin, x768
    s.add        s17, s13, s7                    // the tile origin
    v.splat      v5, s4
    v.splat      v7, s17
    s.add        s7, s6, s14                     // the tile origin
    s.add        s14, s7, s16                    // the tile origin
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a5, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    v.add        v1, v0, v7
    v.splat      v7, s2
    s.movz       s1, #1
    s.addi       s7, s14, #768                   // row 1
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a5, s11
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s5, s4, #1
    s.movz       s11, #2
    v.splat      v2, s5
    s.addi       s5, s14, #1536                  // row 2
    @p4 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s9
    v.cmp.lt     p1, v6, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v6, v3
    v.cmp.lt     p1, v5, v4
    s.addi       s9, s4, #2
    s.movz       s12, #3
    v.splat      v3, s9
    s.addi       s9, s14, #2304                  // row 3
    @p3 v.st.h       [s15, #0], v6
    a.vread      v5, a5, s3
    v.cmp.lt     p2, v1, v7
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v5
    s.addi       s3, s4, #3
    s.movz       s15, #4
    v.splat      v5, s3
    s.addi       s3, s14, #3072                  // row 4
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a6, s13
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s13, s4, #4
    s.movz       s16, #5
    v.splat      v1, s13
    s.addi       s13, s4, #5
    s.addi       s17, s14, #3840                 // row 5
    v.splat      v6, s13
    s.movz       s13, #6
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a6, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s1, s4, #6
    s.addi       s18, s14, #4608                 // row 6
    v.splat      v2, s1
    s.movz       s1, #7
    @p4 v.st.h       [s7, #0], v3
    a.vread      v3, a6, s11
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v3
    s.addi       s7, s4, #7
    s.addi       s11, s14, #5376                 // row 7
    v.splat      v3, s7
    s.movz       s7, #8
    @p3 v.st.h       [s5, #0], v5
    a.vread      v5, a6, s12
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v5
    s.addi       s5, s4, #8
    s.addi       s12, s14, #6144                 // row 8
    v.splat      v5, s5
    s.movz       s5, #9
    @p4 v.st.h       [s9, #0], v1
    a.vread      v1, a6, s15
    v.cmp.lt     p1, v6, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v6, v1
    s.addi       s9, s4, #9
    s.addi       s15, s14, #6912                 // row 9
    v.splat      v1, s9
    s.movz       s9, #10
    @p3 v.st.h       [s3, #0], v6
    a.vread      v6, a6, s16
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v6
    s.addi       s3, s4, #10
    s.addi       s16, s14, #7680                 // row 10
    v.splat      v6, s3
    s.movz       s3, #11
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a6, s13
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s13, s4, #11
    s.addi       s17, s14, #8448                 // row 11
    v.splat      v2, s13
    s.movz       s13, #12
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a6, s1
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v3
    s.addi       s1, s4, #12
    s.addi       s18, s14, #9216                 // row 12
    v.splat      v3, s1
    s.movz       s1, #13
    @p4 v.st.h       [s11, #0], v5
    a.vread      v5, a6, s7
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v5
    s.addi       s7, s4, #13
    s.addi       s11, s14, #9984                 // row 13
    v.splat      v5, s7
    s.movz       s7, #14
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s5
    v.cmp.lt     p1, v6, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v6, v1
    s.addi       s5, s4, #14
    s.addi       s12, s14, #10752                // row 14
    v.splat      v1, s5
    s.movz       s5, #15
    @p4 v.st.h       [s15, #0], v6
    a.vread      v6, a6, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v6
    s.addi       s9, s4, #15
    s.addi       s15, s14, #11520                // row 15
    v.splat      v6, s9
    s.muli       s9, s8, #2                      // a runtime tile origin, x2
    s.add        s14, s6, s9                     // the tile origin
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a6, s3
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    s.muli       s6, s10, #768                   // a runtime tile origin, x768
    s.add        s9, s3, s8                      // the tile origin
    v.splat      v2, s4
    v.splat      v7, s9
    s.add        s8, s14, s6                     // the tile origin
    @p4 v.st.h       [s17, #0], v3
    a.vread      v3, a6, s13
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v3
    v.add        v3, v0, v7
    v.splat      v0, s2
    s.movz       s2, #1
    s.addi       s6, s8, #768                    // row 1
    @p3 v.st.h       [s18, #0], v5
    a.vread      v5, a6, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v5
    s.addi       s1, s4, #1
    s.movz       s9, #2
    v.splat      v5, s1
    s.addi       s1, s8, #1536                   // row 2
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a6, s7
    v.cmp.lt     p1, v6, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v6, v1
    v.cmp.lt     p1, v2, v4
    s.addi       s7, s4, #2
    s.movz       s10, #3
    v.splat      v1, s7
    s.addi       s7, s8, #2304                   // row 3
    @p3 v.st.h       [s12, #0], v6
    a.vread      v2, a6, s5
    v.cmp.lt     p2, v3, v0
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v2
    s.addi       s5, s4, #3
    s.movz       s11, #4
    v.splat      v2, s5
    s.addi       s5, s8, #3072                   // row 4
    @p4 v.st.h       [s15, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v0
    s.addi       s3, s4, #4
    s.movz       s12, #5
    v.splat      v0, s3
    s.addi       s3, s4, #5
    s.addi       s13, s8, #3840                  // row 5
    v.splat      v5, s3
    s.movz       s3, #6
    @p3 v.st.h       [s8, #0], v3
    a.vread      v3, a7, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.addi       s2, s4, #6
    s.addi       s14, s8, #4608                  // row 6
    v.splat      v3, s2
    s.movz       s2, #7
    @p4 v.st.h       [s6, #0], v1
    a.vread      v1, a7, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s6, s4, #7
    s.addi       s9, s8, #5376                   // row 7
    v.splat      v1, s6
    s.movz       s6, #8
    @p3 v.st.h       [s1, #0], v2
    a.vread      v2, a7, s10
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v2
    s.addi       s1, s4, #8
    s.addi       s10, s8, #6144                  // row 8
    v.splat      v2, s1
    s.movz       s1, #9
    @p4 v.st.h       [s7, #0], v0
    a.vread      v0, a7, s11
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v0
    s.addi       s7, s4, #9
    s.addi       s11, s8, #6912                  // row 9
    v.splat      v0, s7
    s.movz       s7, #10
    @p3 v.st.h       [s5, #0], v5
    a.vread      v5, a7, s12
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.addi       s5, s4, #10
    s.addi       s12, s8, #7680                  // row 10
    v.splat      v5, s5
    s.movz       s5, #11
    @p4 v.st.h       [s13, #0], v3
    a.vread      v3, a7, s3
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.addi       s3, s4, #11
    s.addi       s13, s8, #8448                  // row 11
    v.splat      v3, s3
    s.movz       s3, #12
    @p3 v.st.h       [s14, #0], v1
    a.vread      v1, a7, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s2, s4, #12
    s.addi       s14, s8, #9216                  // row 12
    v.splat      v1, s2
    s.movz       s2, #13
    @p4 v.st.h       [s9, #0], v2
    a.vread      v2, a7, s6
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v2
    s.addi       s6, s4, #13
    s.addi       s9, s8, #9984                   // row 13
    v.splat      v2, s6
    s.movz       s6, #14
    @p3 v.st.h       [s10, #0], v0
    a.vread      v0, a7, s1
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v0
    s.addi       s1, s4, #14
    s.addi       s10, s8, #10752                 // row 14
    v.splat      v0, s1
    s.movz       s1, #15
    @p4 v.st.h       [s11, #0], v5
    a.vread      v5, a7, s7
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.addi       s7, s4, #15
    s.addi       s4, s8, #11520                  // row 15
    v.splat      v5, s7
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a7, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a7, s3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s14, #0], v2
    a.vread      v1, a7, s2
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s9, #0], v0
    a.vread      v0, a7, s6
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v0
    @p3 v.st.h       [s10, #0], v1
    a.vread      v0, a7, s1
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s4, #0], v1
    exit
    exit
