    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #0
    v.movi       v2, #0
    v.movi       v3, #6
    v.movi       v4, #63
    v.splat      v5, s2
    v.movi       v6, #64
    v.add        v7, v5, v0
    v.movi       v0, #17
    v.sub        v5, v1, v7
    v.cmp.lt     p1, v7, v1
    @p1 v.sel        v8, v5, v7
    v.sub        v5, v2, v7
    v.lshr       v9, v8, v3
    v.cmp.lt     p2, v7, v2
    @p2 v.sel        v3, v5, v7
    v.sub        v5, v1, v9
    v.and        v8, v3, v4
    @p1 v.sel        v3, v5, v9
    v.movi       v4, #0
    s.rdspecial  s1, arg_base
    v.movi       v5, #4352
    v.sub        v9, v2, v6
    v.sub        v10, v2, v8
    v.sub        v11, v1, v6
    v.sub        v12, v4, v3
    v.cmp.lt     p1, v6, v2
    v.sub        v2, v4, v0
    v.cmp.lt     p3, v6, v1
    v.cmp.lt     p4, v3, v4
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #1
    @p1 v.sel        v1, v9, v6
    v.cmp.lt     p1, v0, v4
    s.ld.d       s4, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    @p2 v.sel        v1, v10, v8
    v.cmp.lt     p2, v7, v5
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.movi       v5, #1
    @p3 v.sel        v5, v11, v6
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.movi       v5, #1
    @p4 v.sel        v6, v12, v3
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    @p1 v.sel        v8, v2, v0
    v.movi       v0, #0
    s.ld.d       s8, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    v.movi       v2, #0
    s.movz       s9, #31
    s.ld.d       s10, [s1, #48]                  // out_ptr0: device_ptr64 at arg_base+48
idiv_1:
    v.splat      v9, s9
    v.shl        v10, v2, v5
    v.lshr       v11, v6, v9
    v.cmp.lt     p1, v2, v4
    v.and        v12, v11, v5
    v.shl        v11, v5, v9
    v.or         v9, v10, v12
    s.subi       s1, s9, #1
    v.cmp.geu    p3, v9, v8
    p.or         p5, p1, p3
    v.sub        v10, v9, v8
    @p5 v.sel        v12, v11, v4
    @p5 v.sel        v11, v10, v9
    v.or         v9, v0, v12
    v.mov        v2, v11
    v.mov        v0, v9
    s.mov        s9, s1
    s.movz       s1, #0
    s.cmp.ge     s11, s9, s1
    br.nz        s11, idiv_1
    v.movi       v0, #1088
    v.movi       v5, #0
    v.sub        v6, v4, v2
    v.sub        v4, v5, v7
    v.sub        v8, v5, v0
    v.cmp.lt     p1, v7, v5
    v.cmp.lt     p3, v0, v5
    @p4 v.sel        v9, v6, v2
    v.movi       v2, #1
    @p1 v.sel        v6, v4, v7
    @p3 v.sel        v4, v8, v0
    v.movi       v8, #0
    v.movi       v10, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v11, s1
    v.shl        v12, v10, v2
    v.lshr       v13, v6, v11
    v.cmp.lt     p4, v10, v5
    v.and        v14, v13, v2
    v.shl        v13, v2, v11
    v.or         v11, v12, v14
    s.subi       s9, s1, #1
    v.cmp.geu    p5, v11, v4
    p.or         p6, p4, p5
    v.sub        v12, v11, v4
    @p6 v.sel        v14, v13, v5
    @p6 v.sel        v13, v12, v11
    v.or         v11, v8, v14
    v.mov        v10, v13
    v.mov        v8, v11
    s.mov        s1, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s1, s9
    br.nz        s11, idiv_2
    v.movi       v2, #0
    p.xor        p4, p1, p3
    v.sub        v4, v5, v8
    v.sub        v5, v2, v7
    v.sub        v6, v2, v0
    v.cmp.lt     p1, v7, v2
    v.cmp.lt     p3, v0, v2
    @p4 v.sel        v10, v4, v8
    v.movi       v4, #1
    @p1 v.sel        v8, v5, v7
    @p3 v.sel        v5, v6, v0
    v.movi       v0, #0
    v.movi       v6, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v7, s1
    v.shl        v11, v6, v4
    v.lshr       v12, v8, v7
    v.cmp.lt     p3, v6, v2
    v.and        v13, v12, v4
    v.shl        v12, v4, v7
    v.or         v7, v11, v13
    s.subi       s9, s1, #1
    v.cmp.geu    p4, v7, v5
    p.or         p5, p3, p4
    v.sub        v11, v7, v5
    @p5 v.sel        v13, v12, v2
    @p5 v.sel        v12, v11, v7
    v.or         v7, v0, v13
    v.mov        v6, v12
    v.mov        v0, v7
    s.mov        s1, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s1, s9
    br.nz        s11, idiv_3
    .li       s1, #1132462080
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v0                          // ISA 8.8: <= 2**-22 relative
    v.movi       v7, #4
    .li       s1, #897988541
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v11, v9, v7
    v.movi       v7, #256
    v.add        v12, v10, v11
    v.mul        v11, v10, v7
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v10, [s4, v12]             // index is in elements (ISA sec 9.1)
    v.movi       v12, #1024
    v.add        v13, v1, v11
    v.mul        v11, v9, v12
    .li       s1, #1077936128
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v14, v13, v11
    v.sub        v11, v2, v6
    s.shli       s1, s2, #1                      // element offset -> bytes (x2)
    @p1 v.sel        v2, v11, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v6, [s3, v14]              // index is in elements (ISA sec 9.1)
    s.add        s2, s7, s1                      // &in_ptr4[...]
    s.movz       s1, #256
    .li       s1, #1065353216
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.movz       s1, #1024
    s.movz       s1, #4
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v13, [s5, v1]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v14, v6
    v.mul        v6, v3, v7
    vf.fms       v3, v0, v5, v4
    v.add        v4, v1, v6
    vf.cvt.bf16.f32 v1, v13
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v6, [s6, v2]               // index is in elements (ISA sec 9.1)
    vf.fms       v7, v5, v3, v5
    vf.add       v3, v1, v11
    vf.neg       v1, v7                          // Newton step: r0*(2 - x*r0)
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v7, [s2, #0]
    vf.cvt.bf16.f32 v11, v6
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v6, v1, v5
    vf.mul       v1, v10, v6                     // a/y: faithful quotient
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v5, [s8, v2]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v7
    vf.fms       v7, v1, v0, v10
    vf.cvt.bf16.f32 v0, v5
    vf.fms       v5, v7, v6, v1
    vf.mul       v6, v2, v0
    vf.neg       v0, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v2, v0, v1
    vf.add       v0, v2, v8
    v.rsqrt.approx v1, v0                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v2, v1, v1
    vf.mul       v5, v1, v12
    vf.fms       v7, v0, v2, v9
    vf.mul       v0, v5, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v2, v0, v1
    vf.mul       v0, v14, v2
    vf.mul       v1, v0, v3
    vf.mul       v0, v1, v11
    vf.add       v1, v0, v6
    vf.cvt.f32.bf16 v0, v1
    @p2 v.st.scatter.h [s10, v4], v0
__rctx_next:
    exit
