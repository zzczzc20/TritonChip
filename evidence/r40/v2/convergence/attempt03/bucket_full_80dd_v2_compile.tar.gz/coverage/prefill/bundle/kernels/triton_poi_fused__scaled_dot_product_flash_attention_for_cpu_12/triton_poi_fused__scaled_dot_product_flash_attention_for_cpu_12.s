    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    s.shli       s1, s2, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #6
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.movi       v6, #0
    @p1 v.sel        v7, v5, v4
    v.sub        v5, v0, v4
    v.cmp.lt     p2, v4, v0
    v.lshr       v8, v7, v3
    v.sub        v3, v1, v4
    @p2 v.sel        v7, v5, v4
    v.sub        v5, v2, v8
    v.movi       v9, #10
    v.cmp.lt     p3, v4, v1
    @p1 v.sel        v10, v5, v8
    @p3 v.sel        v5, v3, v4
    v.movi       v3, #63
    v.sub        v4, v6, v10
    v.cmp.lt     p1, v10, v6
    v.movi       v8, #15
    @p1 v.sel        v11, v4, v10
    v.lshr       v4, v7, v9
    v.and        v7, v5, v3
    v.and        v3, v11, v8
    v.sub        v5, v0, v4
    v.movi       v8, #64
    v.sub        v9, v1, v7
    v.sub        v10, v6, v3
    @p2 v.sel        v11, v5, v4
    @p3 v.sel        v4, v9, v7
    @p1 v.sel        v5, v10, v3
    v.mul        v3, v11, v8
    s.movz       s6, #32768
    v.splat      v7, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #16
    v.add        v10, v4, v3
    v.mul        v3, v5, v7
    v.movi       v4, #1024
    v.sub        v5, v1, v8
    v.sub        v7, v2, v8
    v.cmp.lt     p1, v8, v1
    v.add        v1, v10, v3
    s.shli       s6, s1, #1                      // element offset -> bytes (x2)
    v.sub        v3, v6, v9
    v.ld.gather.w v10, [s3, v1]                  // index is in elements (ISA sec 9.1)
    v.sub        v1, v0, v4
    v.cmp.lt     p2, v8, v2
    v.cmp.lt     p3, v9, v6
    @p1 v.sel        v2, v5, v8
    s.add        s1, s5, s6                      // &out_ptr0[...]
    v.cmp.lt     p1, v4, v0
    @p2 v.sel        v0, v7, v8
    @p3 v.sel        v0, v3, v9
    @p1 v.sel        v0, v1, v4
    vf.cvt.f32.f16 v0, v10
    v.st.h       [s1, #0], v0
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s6, s1, s4
    s.mov        s2, s1
    br.nz        s6, __rctx_program
    exit
