    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #192
    v.movi       v2, #0
    v.movi       v3, #768
    s.rdspecial  s1, arg_base
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v0, #1
    v.sub        v4, v2, v6
    v.cmp.lt     p2, v6, v2
    v.cmp.lt     p3, v6, v3
    @p2 v.sel        v3, v4, v6
    @p1 v.sel        v4, v5, v1
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s3, #31
    s.ld.d       s4, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
idiv_1:
    v.splat      v8, s3
    v.shl        v9, v7, v0
    v.cmp.lt     p1, v7, v2
    v.lshr       v10, v3, v8
    v.shl        v11, v0, v8
    s.subi       s1, s3, #1
    v.and        v8, v10, v0
    s.movz       s7, #0
    v.or         v10, v9, v8
    v.cmp.geu    p4, v10, v4
    p.or         p5, p1, p4
    v.sub        v8, v10, v4
    @p5 v.sel        v9, v11, v2
    @p5 v.sel        v11, v8, v10
    v.or         v8, v5, v9
    v.mov        v7, v11
    v.mov        v5, v8
    s.mov        s3, s1
    s.cmp.ge     s1, s3, s7
    br.nz        s1, idiv_1
    v.movi       v0, #0
    v.sub        v3, v2, v7
    v.movi       v2, #1
    v.sub        v4, v0, v6
    v.sub        v5, v0, v1
    v.cmp.lt     p1, v6, v0
    v.cmp.lt     p4, v1, v0
    @p2 v.sel        v8, v3, v7
    @p1 v.sel        v3, v4, v6
    @p4 v.sel        v4, v5, v1
    v.movi       v1, #0
    v.movi       v5, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v6, s1
    v.shl        v7, v5, v2
    v.cmp.lt     p2, v5, v0
    v.lshr       v9, v3, v6
    v.shl        v10, v2, v6
    s.subi       s3, s1, #1
    v.and        v6, v9, v2
    s.movz       s7, #0
    v.or         v9, v7, v6
    v.cmp.geu    p5, v9, v4
    p.or         p6, p2, p5
    v.sub        v6, v9, v4
    @p6 v.sel        v7, v10, v0
    @p6 v.sel        v10, v6, v9
    v.or         v6, v1, v7
    v.mov        v5, v10
    v.mov        v1, v6
    s.mov        s1, s3
    s.cmp.ge     s3, s1, s7
    br.nz        s3, idiv_2
    .li       s1, #1132462080
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v3, v0, v1
    p.xor        p2, p1, p4
    v.rcp.approx v0, v2                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p2 v.sel        v5, v3, v1
    .li       s1, #897988541
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #64
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s4, v5]               // index is in elements (ISA sec 9.1)
    v.movi       v7, #256
    v.add        v9, v8, v3
    .li       s1, #1077936128
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v10, v5, v7
    .li       s1, #3204448256
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v11, v9, v10
    v.add        v12, v8, v10
    s.movz       s1, #64
    s.movz       s1, #256
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v8, [s2, v11]              // index is in elements (ISA sec 9.1)
    vf.fms       v10, v2, v0, v4
    vf.fms       v4, v0, v10, v0
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v10, [s5, v9]              // index is in elements (ISA sec 9.1)
    vf.neg       v9, v4                          // Newton step: r0*(2 - x*r0)
    vf.cvt.bf16.f32 v4, v8
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v8, v9, v0
    vf.mul       v0, v6, v8                      // a/y: faithful quotient
    vf.cvt.bf16.f32 v9, v10
    vf.fms       v10, v0, v2, v6
    vf.add       v2, v9, v7
    vf.fms       v6, v10, v8, v0
    vf.neg       v7, v6                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v6, v7, v0
    vf.add       v0, v6, v1
    v.rsqrt.approx v1, v0                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v6, v1, v1
    vf.mul       v7, v1, v5
    vf.fms       v5, v0, v6, v3
    vf.mul       v0, v7, v5                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v3, v0, v1
    vf.mul       v0, v4, v3
    vf.mul       v1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.scatter.h [s6, v12], v0
__rctx_next:
    exit
