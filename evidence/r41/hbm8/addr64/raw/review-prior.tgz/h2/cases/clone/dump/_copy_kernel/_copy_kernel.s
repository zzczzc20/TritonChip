    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // SRC: device_ptr64 at arg_base+0
    s.movz       s5, #9216
    s.movz       s6, #1
    s.addi       s7, s2, #0
    s.ld.d       s2, [s1, #8]                    // DST: device_ptr64 at arg_base+8
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    s.movz       s1, #1024
    s.movz       s8, #128
    s.mul        s9, s7, s1
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #32
    s.add        s1, s9, s4
    v.iota       v4                              // arange(0, VLEN)
    s.mul        s9, s1, s8
    v.movi       v5, #48
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #64
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #80
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #96
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #112
    v.iota       v14                             // arange(0, VLEN)
    v.add        v15, v0, v1
    v.add        v0, v2, v3
    v.add        v1, v4, v5
    v.add        v2, v6, v7
    v.add        v3, v8, v9
    v.add        v4, v10, v11
    v.add        v5, v12, v13
    v.splat      v6, s9
    v.splat      v7, s9
    v.splat      v8, s9
    v.splat      v9, s9
    v.splat      v10, s9
    v.splat      v11, s9
    v.splat      v12, s9
    v.splat      v13, s9
    v.add        v16, v6, v14
    v.add        v6, v7, v15
    v.add        v7, v8, v0
    v.add        v0, v9, v1
    v.add        v1, v10, v2
    v.add        v2, v11, v3
    v.add        v3, v12, v4
    v.add        v4, v13, v5
    s.movz       s1, #16
    v.movi       v5, #0
    v.movi       v8, #2
    s.movz       s8, #32
    v.sub        v9, v5, v16
    v.cmp.lt     p1, v16, v5
    v.sub        v10, v5, v8
    @p1 v.sel        v11, v9, v16
    s.movz       s10, #48
    v.movi       v9, #1
    s.movz       s11, #64
    v.movi       v12, #0
    v.lshr       v13, v11, v9
    v.movi       v9, #2
    s.movz       s12, #80
    v.sub        v11, v12, v6
    v.cmp.lt     p2, v6, v12
    v.sub        v14, v5, v13
    @p2 v.sel        v15, v11, v6
    s.movz       s13, #96
    v.movi       v11, #1
    @p1 v.sel        v17, v14, v13
    v.sub        v13, v12, v9
    v.lshr       v14, v15, v11
    s.movz       s14, #112
    v.movi       v11, #0
    v.sub        v15, v12, v14
    v.movi       v18, #2
    v.sub        v19, v11, v7
    v.cmp.lt     p1, v7, v11
    @p2 v.sel        v20, v15, v14
    @p1 v.sel        v14, v19, v7
    v.sub        v15, v11, v18
    v.cmp.lt     p2, v8, v5
    v.cmp.lt     p3, v9, v12
    s.add        s15, s1, s9
    v.movi       v5, #1
    s.add        s1, s8, s9
    s.add        s1, s10, s9
    v.movi       v12, #0
    v.lshr       v19, v14, v5
    v.movi       v5, #2
    s.add        s1, s11, s9
    v.sub        v14, v11, v19
    s.add        s1, s12, s9
    v.sub        v21, v12, v0
    @p1 v.sel        v22, v14, v19
    v.cmp.lt     p1, v0, v12
    s.add        s1, s13, s9
    @p1 v.sel        v14, v21, v0
    v.sub        v19, v12, v5
    s.add        s1, s14, s9
    v.movi       v21, #1
    v.movi       v23, #1
    v.movi       v23, #0
    v.lshr       v24, v14, v21
    v.movi       v14, #2
    @p2 v.sel        v21, v10, v8
    v.sub        v10, v23, v1
    v.cmp.lt     p2, v1, v23
    v.movi       v21, #1
    @p2 v.sel        v25, v10, v1
    v.sub        v10, v12, v24
    v.sub        v26, v23, v14
    v.lshr       v27, v25, v21
    @p1 v.sel        v21, v10, v24
    v.cmp.lt     p1, v18, v11
    v.movi       v10, #1
    v.movi       v10, #0
    v.sub        v11, v23, v27
    v.movi       v24, #2
    @p3 v.sel        v25, v13, v9
    v.sub        v13, v10, v2
    v.cmp.lt     p3, v2, v10
    v.movi       v25, #1
    @p3 v.sel        v28, v13, v2
    @p2 v.sel        v13, v11, v27
    v.sub        v11, v10, v24
    v.lshr       v27, v28, v25
    v.cmp.lt     p2, v5, v12
    v.movi       v12, #1
    v.movi       v12, #0
    v.sub        v25, v10, v27
    v.movi       v28, #2
    @p1 v.sel        v29, v15, v18
    v.sub        v15, v12, v3
    v.cmp.lt     p1, v3, v12
    v.movi       v29, #1
    @p1 v.sel        v30, v15, v3
    @p3 v.sel        v15, v25, v27
    v.sub        v25, v12, v28
    v.lshr       v27, v30, v29
    v.cmp.lt     p3, v14, v23
    v.movi       v23, #1
    v.movi       v23, #0
    v.sub        v29, v12, v27
    v.movi       v30, #2
    @p2 v.sel        v31, v19, v5
    v.sub        v19, v23, v4
    v.cmp.lt     p2, v4, v23
    v.movi       v31, #1
    @p2 v.sel        v32, v19, v4
    @p1 v.sel        v19, v29, v27
    v.sub        v27, v23, v30
    v.lshr       v29, v32, v31
    v.cmp.lt     p1, v24, v10
    v.movi       v10, #1
    v.movi       v10, #0
    v.sub        v31, v23, v29
    @p3 v.sel        v32, v26, v14
    v.sub        v26, v10, v16
    v.cmp.lt     p3, v16, v10
    v.movi       v32, #1
    @p3 v.sel        v33, v26, v16
    @p2 v.sel        v26, v31, v29
    v.sub        v29, v10, v8
    v.and        v31, v33, v32
    v.cmp.lt     p2, v28, v12
    v.movi       v12, #1
    v.movi       v12, #0
    v.sub        v32, v10, v31
    @p1 v.sel        v33, v11, v24
    v.sub        v11, v12, v6
    v.cmp.lt     p1, v6, v12
    v.movi       v33, #1
    @p1 v.sel        v34, v11, v6
    @p3 v.sel        v11, v32, v31
    v.sub        v31, v12, v9
    v.and        v32, v34, v33
    v.cmp.lt     p3, v30, v23
    v.movi       v23, #1
    v.movi       v23, #0
    v.sub        v33, v12, v32
    @p2 v.sel        v34, v25, v28
    v.movi       v25, #0
    v.sub        v34, v23, v7
    v.cmp.lt     p2, v7, v23
    v.movi       v35, #1
    @p2 v.sel        v36, v34, v7
    @p1 v.sel        v34, v33, v32
    v.sub        v32, v23, v18
    v.and        v33, v36, v35
    v.cmp.lt     p1, v8, v10
    v.movi       v10, #1
    v.sub        v10, v25, v0
    v.sub        v35, v23, v33
    v.sub        v36, v25, v5
    @p3 v.sel        v37, v27, v30
    v.movi       v27, #0
    v.cmp.lt     p3, v0, v25
    @p3 v.sel        v37, v10, v0
    v.movi       v10, #1
    @p2 v.sel        v38, v35, v33
    v.cmp.lt     p2, v9, v12
    v.and        v12, v37, v10
    v.movi       v10, #1
    v.sub        v10, v27, v1
    v.sub        v33, v25, v12
    v.sub        v35, v27, v14
    @p1 v.sel        v37, v29, v8
    v.movi       v29, #0
    v.cmp.lt     p1, v1, v27
    @p1 v.sel        v37, v10, v1
    v.movi       v10, #1
    @p3 v.sel        v39, v33, v12
    v.cmp.lt     p3, v18, v23
    v.and        v12, v37, v10
    v.movi       v10, #1
    v.sub        v10, v29, v2
    v.sub        v23, v27, v12
    v.sub        v33, v29, v24
    @p2 v.sel        v37, v31, v9
    v.movi       v31, #0
    v.cmp.lt     p2, v2, v29
    @p2 v.sel        v37, v10, v2
    v.movi       v10, #1
    @p1 v.sel        v40, v23, v12
    v.cmp.lt     p1, v5, v25
    v.and        v12, v37, v10
    v.movi       v10, #1
    v.sub        v10, v31, v3
    v.sub        v23, v29, v12
    v.sub        v25, v31, v28
    @p3 v.sel        v37, v32, v18
    v.movi       v32, #0
    v.cmp.lt     p3, v3, v31
    @p3 v.sel        v37, v10, v3
    v.movi       v10, #1
    @p2 v.sel        v41, v23, v12
    v.cmp.lt     p2, v14, v27
    v.and        v12, v37, v10
    v.movi       v10, #1
    v.sub        v10, v32, v4
    v.sub        v23, v31, v12
    v.sub        v27, v32, v30
    @p1 v.sel        v37, v36, v5
    v.cmp.lt     p1, v4, v32
    @p1 v.sel        v36, v10, v4
    v.movi       v10, #1
    @p3 v.sel        v37, v23, v12
    v.cmp.lt     p3, v24, v29
    v.and        v12, v36, v10
    v.movi       v10, #1
    v.mul        v10, v17, v8
    v.sub        v8, v32, v12
    v.mul        v17, v20, v9
    v.mul        v9, v22, v18
    @p1 v.sel        v18, v8, v12
    v.mul        v8, v21, v5
    v.mul        v5, v13, v14
    v.mul        v12, v15, v24
    v.cmp.lt     p1, v28, v31
    @p2 v.sel        v13, v35, v14
    v.mul        v13, v19, v28
    v.mul        v14, v26, v30
    .li       s1, #1207959552
    v.splat      v15, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v19, v10, v11                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p2, v30, v32
    v.movi       v20, #1
    .li       s1, #1207959552
    v.splat      v20, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1207959552
    v.splat      v21, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v22, v17, v34                   // per-lane offsets add up, in elements (ISA sec 9.1)
    @p3 v.sel        v23, v33, v24
    .li       s1, #1207959552
    v.splat      v23, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v24, v9, v38                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v26, v8, v39                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p3, v16, v15
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v29, [s3, v19]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v20
    v.movi       v19, #1
    .li       s1, #1207959552
    v.splat      v19, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1207959552
    v.splat      v31, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v32, v5, v40                    // per-lane offsets add up, in elements (ISA sec 9.1)
    @p1 v.sel        v33, v25, v28
    .li       s1, #1207959552
    v.splat      v25, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v28, v12, v41                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v33, v13, v37                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v21
    v.movi       v35, #1
    .li       s1, #1207959552
    v.splat      v35, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v36, v14, v18                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v42, v10, v11                   // per-lane offsets add up, in elements (ISA sec 9.1)
    @p2 v.sel        v10, v27, v30
    v.cmp.lt     p2, v0, v23
    v.add        v10, v17, v34                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v11, [s3, v22]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v1, v19
    s.movz       s1, #2
    v.add        v17, v9, v38                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v9, v8, v39                     // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v8, v5, v40                     // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v5, v12, v41                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v12, v13, v37                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v13, v14, v18                   // per-lane offsets add up, in elements (ISA sec 9.1)
    s.add        s1, s7, s6
    s.movz       s8, #1
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v14, [s3, v24]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v31
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v18, [s3, v26]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v25
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v22, [s3, v32]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v4, v35
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v24, [s3, v28]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v16, v15
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v15, [s3, v33]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v20
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v6, [s3, v36]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v7, v21
    @p1 v.st.scatter.b [s2, v42], v29
    v.cmp.lt     p1, v0, v23
    @p2 v.st.scatter.b [s2, v10], v11
    v.cmp.lt     p2, v1, v19
    @p3 v.st.scatter.b [s2, v17], v14
    v.cmp.lt     p3, v2, v31
    @p1 v.st.scatter.b [s2, v9], v18
    v.cmp.lt     p1, v3, v25
    @p2 v.st.scatter.b [s2, v8], v22
    v.cmp.lt     p2, v4, v35
    @p3 v.st.scatter.b [s2, v5], v24
    @p1 v.st.scatter.b [s2, v12], v15
    @p2 v.st.scatter.b [s2, v13], v6
    s.mov        s7, s1
    br.nz        s8, for_1
endfor_2:
__rctx_next:
    exit
