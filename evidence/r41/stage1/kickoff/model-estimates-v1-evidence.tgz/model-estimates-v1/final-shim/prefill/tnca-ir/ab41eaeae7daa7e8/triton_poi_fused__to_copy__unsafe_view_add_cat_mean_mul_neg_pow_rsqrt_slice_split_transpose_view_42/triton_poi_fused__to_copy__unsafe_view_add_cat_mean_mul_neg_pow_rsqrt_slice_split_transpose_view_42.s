    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.add        v3, v1, v0
    v.movi       v0, #5
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.movi       v4, #0
    @p1 v.sel        v5, v1, v3
    v.movi       v1, #31
    v.sub        v6, v4, v3
    v.lshr       v7, v5, v0
    v.cmp.lt     p2, v3, v4
    @p2 v.sel        v0, v6, v3
    v.sub        v5, v2, v7
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.and        v6, v0, v1
    @p1 v.sel        v0, v5, v7
    v.movi       v1, #32
    v.sub        v5, v4, v6
    v.movi       v7, #0
    v.movi       v8, #0
    @p2 v.sel        v9, v5, v6
    v.sub        v5, v7, v3
    v.cmp.lt     p1, v3, v7
    v.sub        v6, v8, v0
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    @p1 v.sel        v10, v5, v3
    v.cmp.lt     p2, v0, v8
    @p2 v.sel        v3, v6, v0
    v.movi       v5, #7
    v.movi       v6, #8
    v.movi       v11, #256
    v.and        v12, v3, v5
    v.sub        v3, v4, v1
    v.sub        v5, v2, v1
    v.sub        v13, v8, v12
    s.ld.d       s5, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    v.sub        v14, v8, v6
    @p2 v.sel        v15, v13, v12
    v.sub        v12, v7, v11
    v.cmp.lt     p2, v1, v4
    v.cmp.lt     p3, v1, v2
    @p2 v.sel        v2, v3, v1
    v.cmp.lt     p2, v6, v8
    @p3 v.sel        v2, v5, v1
    v.cmp.lt     p3, v11, v7
    @p2 v.sel        v2, v14, v6
    s.ld.d       s6, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    .li       s1, #1132462080
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #897988541
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v2                          // ISA 8.8: <= 2**-22 relative
    v.movi       v6, #512
    v.add        v8, v9, v1
    .li       s1, #1077936128
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v13, v0, v6
    .li       s1, #3204448256
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p3 v.sel        v14, v12, v11
    v.ld.gather.w v11, [s2, v0]                  // index is in elements (ISA sec 9.1)
    v.add        v0, v8, v13
    v.add        v12, v9, v13
    .li       s1, #1065353216
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.gather.h v14, [s3, v0]                  // index is in elements (ISA sec 9.1)
    vf.fms       v0, v2, v5, v3
    v.movi       v2, #8
    v.lshr       v3, v10, v2
    vf.fms       v2, v5, v0, v5
    v.movi       v0, #64
    v.sub        v10, v7, v3
    vf.neg       v7, v2                          // Newton step: r0*(2 - x*r0)
    v.ld.gather.h v2, [s4, v8]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v8, v14
    @p1 v.sel        v14, v10, v3
    v.movi       v3, #8192
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v10, v7, v5
    v.mul        v5, v14, v0
    v.mul        v0, v15, v3
    vf.mul       v3, v11, v10                    // a/y as a refined reciprocal (ISA has no divide)
    v.add        v7, v9, v5
    v.add        v5, v7, v0
    vf.add       v0, v3, v4
    v.ld.gather.h v3, [s3, v12]                  // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v4, v2
    v.rsqrt.approx v2, v0                        // ISA 8.8: <= 2**-22 relative
    vf.add       v7, v4, v13
    v.ld.gather.h v4, [s4, v9]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v9, v3
    vf.cvt.bf16.f32 v3, v4
    vf.mul       v4, v2, v2
    vf.mul       v10, v2, v6
    vf.add       v6, v3, v13
    vf.fms       v3, v0, v4, v1
    vf.mul       v0, v10, v3                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v1, v0, v2
    vf.mul       v0, v8, v1
    vf.mul       v2, v9, v1
    vf.mul       v1, v0, v7
    vf.mul       v0, v2, v6
    vf.neg       v2, v1
    vf.cvt.f32.bf16 v1, v0
    vf.cvt.f32.bf16 v0, v2
    v.st.scatter.h [s5, v5], v0
    v.st.scatter.h [s6, v5], v1
__rctx_next:
    exit
