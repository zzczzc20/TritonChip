    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // out_ptr0: device_ptr64 at arg_base+40
    s.rdspecial  s1, arg_base
    s.ld.d       s9, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s10, #512
    s.mul        s11, s1, s10
    s.add        s1, s9, s11                     // this context's own scratch
    s.addi       s9, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s9, #0], s2
    .li       s1, #2147483647
    s.st.d       [s9, #8], s1
    .li       s1, #2147483647
    s.st.d       [s9, #16], s1
    s.movz       s1, #16
    s.st.d       [s9, #48], s1
    s.movz       s1, #1
    s.st.d       [s9, #56], s1
    .li       s1, #68719476752
    s.st.d       [s9, #88], s1
    .li       s1, #7705171329024
    s.st.d       [s9, #104], s1
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #1
    s.movz       s2, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #1
    s.sub        s15, s1, s4
    s.min.s      s16, s15, s1
    s.cmp.lt     s1, s4, s9
    s.sub        s9, s2, s1
    s.cmp.lt     s1, s16, s11
    s.sub        s2, s10, s1
    s.xor        s1, s4, s9
    s.sub        s10, s1, s9
    s.xor        s1, s16, s2
    s.sub        s11, s1, s2
    s.addi       s1, s12, #0
    s.addi       s2, s13, #0
    s.cmp.eq     s12, s11, s14
    s.mov        s1, s10
    br.nz        s12, sdiv_done_1
    s.movz       s12, #0
    s.movz       s13, #31
    s.mov        s1, s12
    s.addi       s12, s13, #0
sdiv_2:
    s.lshr       s13, s10, s12
    s.shli       s14, s2, #1
    s.andi       s15, s13, #1
    s.movz       s13, #0
    s.or         s17, s14, s15
    s.movz       s14, #1
    s.cmp.geu    s15, s17, s11
    s.shl        s18, s14, s12
    s.sub        s14, s13, s15
    s.subi       s13, s12, #1
    s.and        s15, s11, s14
    s.and        s19, s18, s14
    s.sub        s14, s17, s15
    s.or         s15, s1, s19
    s.mov        s2, s14
    s.mov        s1, s15
    s.mov        s12, s13
    s.movz       s13, #0
    s.cmp.ge     s14, s12, s13
    br.nz        s14, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.cmp.lt     s13, s16, s1
    s.movz       s1, #0
    s.cmp.lt     s14, s10, s11
    s.sub        s11, s12, s13
    s.sub        s12, s1, s14
    s.xor        s1, s16, s11
    s.xor        s13, s2, s9
    s.xor        s2, s10, s12
    s.sub        s14, s1, s11
    s.movz       s1, #0
    s.movz       s15, #1
    s.sub        s16, s13, s9
    s.sub        s9, s2, s12
    s.movz       s2, #0
    s.addi       s13, s1, #0
    s.cmp.eq     s1, s14, s15
    s.add        s15, s4, s16
    s.addi       s4, s2, #0
    s.mov        s13, s9
    br.nz        s1, sdiv_done_3
    s.movz       s1, #0
    s.movz       s2, #31
    s.mov        s13, s1
    s.addi       s1, s2, #0
sdiv_4:
    s.lshr       s2, s9, s1
    s.shli       s16, s4, #1
    s.andi       s17, s2, #1
    s.movz       s2, #0
    s.or         s18, s16, s17
    s.movz       s16, #1
    s.cmp.geu    s17, s18, s14
    s.shl        s19, s16, s1
    s.sub        s16, s2, s17
    s.subi       s2, s1, #1
    s.and        s17, s14, s16
    s.and        s20, s19, s16
    s.sub        s16, s18, s17
    s.or         s17, s13, s20
    s.mov        s4, s16
    s.mov        s13, s17
    s.mov        s1, s2
    s.movz       s2, #0
    s.cmp.ge     s16, s1, s2
    br.nz        s16, sdiv_4
sdiv_done_3:
    s.xor        s1, s12, s11
    s.xor        s2, s13, s1
    s.sub        s4, s2, s1
    v.splat      v0, s15
    v.splat      v1, s10
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s4
    v.splat      v1, s10
    v.cmp.ge     p1, v0, v1
    s.movz       s1, #16
    s.mul        s2, s15, s1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    v.add        v2, v1, v0
    s.mul        s9, s4, s1
    v.splat      v1, s9
    v.add        v2, v1, v0
    s.andi       s4, s2, #15
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.add        v2, v0, v1
    s.andi       s10, s9, #15
    v.splat      v0, s10
    v.iota       v1                              // arange(0, VLEN)
    v.add        v2, v0, v1
    s.movz       s11, #0
    w.def        w0, #60, #4                     // v60..v63
    mb.arm       s12, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s11                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s13, s12
    mb.wait      s12
    s.rdspecial  s4, arg_base
    s.ld.d       s11, [s4, #48]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s4, role_id
    s.movz       s13, #512
    s.mul        s14, s4, s13
    s.add        s4, s11, s14                    // this context's own scratch
    s.addi       s11, s4, #256                   // 256 bytes of repack scratch
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.movz       s4, #0
    s.muli       s13, s10, #16                   // a runtime tile origin, x16
    s.add        s10, s4, s13                    // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    s.movz       s4, #16
    v.splat      v1, s4
    v.mul        v2, v0, v1
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s11, #0], v0
    s.addi       s4, s10, #1
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #16                    // row 1
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #2
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #32                    // row 2
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #3
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #48                    // row 3
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #4
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #64                    // row 4
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #5
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #80                    // row 5
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #6
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #96                    // row 6
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #7
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #112                   // row 7
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #8
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #128                   // row 8
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #9
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #144                   // row 9
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #10
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #160                   // row 10
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #11
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #176                   // row 11
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #12
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #192                   // row 12
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #13
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #208                   // row 13
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #14
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s4, s11, #224                   // row 14
    v.st.b       [s4, #0], v0
    s.addi       s4, s10, #15
    v.splat      v0, s4
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s3, s11, #240                   // row 15
    v.st.b       [s3, #0], v0
    w.def        w1, #56, #4                     // v56..v59
    fence.acq_rel.device
    v.ld.w       v0, [s11, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s3, s11, #64
    v.ld.w       v0, [s3, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s3, s11, #128
    v.ld.w       v0, [s3, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s3, s11, #192
    v.ld.w       v0, [s3, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    m.zero       a0
    mb.arm       s3, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.e4m3 a0, v60, v56, s3
    mb.wait      s3
    v.movi       v0, #0
    s.ld.w       s4, [s5, #0]                    // one element, not a vector
    v.splat      v1, s4
    s.ld.w       s4, [s6, #0]                    // one element, not a vector
    v.splat      v2, s4
    s.muli       s4, s9, #2                      // a runtime tile origin, x2
    s.add        s5, s7, s4                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s4, s9, #2                      // a runtime tile origin, x2
    s.add        s6, s8, s4                      // the tile origin
    s.muli       s4, s2, #32                     // a runtime tile origin, x32
    s.add        s7, s6, s4                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s4, #0
    a.vread      v3, a0, s4
    vf.add       v4, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v5, v4, v3
    s.movz       s4, #0
    s.add        s6, s4, s2                      // the tile origin
    v.splat      v3, s6
    v.splat      v4, s1
    v.cmp.lt     p1, v3, v4
    s.movz       s2, #0
    s.add        s4, s2, s9                      // the tile origin
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v6, s4
    v.add        v7, v3, v6
    v.splat      v3, s1
    v.cmp.lt     p2, v7, v3
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v6, v3
    vf.add       v3, v5, v6
    vf.cvt.f32.bf16 v5, v3
    v.splat      v3, s6
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s7, #0], v5
    s.movz       s1, #1
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #1
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #32                     // row 1
    s.addi       s2, s6, #1
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #2
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #2
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #64                     // row 2
    s.addi       s2, s6, #2
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #3
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #3
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #96                     // row 3
    s.addi       s2, s6, #3
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #4
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #4
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #128                    // row 4
    s.addi       s2, s6, #4
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #5
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #5
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #160                    // row 5
    s.addi       s2, s6, #5
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #6
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #6
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #192                    // row 6
    s.addi       s2, s6, #6
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #7
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #7
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #224                    // row 7
    s.addi       s2, s6, #7
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #8
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #8
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #256                    // row 8
    s.addi       s2, s6, #8
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #9
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #9
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #288                    // row 9
    s.addi       s2, s6, #9
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #10
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #10
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #320                    // row 10
    s.addi       s2, s6, #10
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #11
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #11
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #352                    // row 11
    s.addi       s2, s6, #11
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #12
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #12
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #384                    // row 12
    s.addi       s2, s6, #12
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #13
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #13
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #416                    // row 13
    s.addi       s2, s6, #13
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #14
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v3, v1, v2
    vf.mul       v6, v5, v3
    s.addi       s1, s6, #14
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s5, #0]
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v6, v5
    vf.cvt.f32.bf16 v5, v3
    s.addi       s1, s7, #448                    // row 14
    s.addi       s2, s6, #14
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v5
    s.movz       s1, #15
    a.vread      v3, a0, s1
    vf.add       v5, v3, v0
    vf.mul       v0, v1, v2
    vf.mul       v1, v5, v0
    s.addi       s1, s6, #15
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.bf16.f32 v2, v0
    vf.add       v0, v1, v2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s7, #480                    // row 15
    s.addi       s2, s6, #15
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
__rctx_next:
    exit
