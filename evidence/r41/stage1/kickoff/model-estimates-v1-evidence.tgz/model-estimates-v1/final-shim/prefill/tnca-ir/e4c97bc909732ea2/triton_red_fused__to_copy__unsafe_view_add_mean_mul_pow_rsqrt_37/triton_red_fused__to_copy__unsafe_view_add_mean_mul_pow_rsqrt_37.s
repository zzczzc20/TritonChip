    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #768
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s9, #0
    s.st.d       [s8, #0], s2
    s.movz       s9, #128
    s.st.d       [s8, #8], s9
    s.movz       s9, #2048
    s.st.d       [s8, #16], s9
    s.movz       s9, #4096
    s.st.d       [s8, #48], s9
    s.movz       s9, #2
    s.st.d       [s8, #56], s9
    .li       s9, #68719476737
    s.st.d       [s8, #88], s9
    .li       s9, #1108101562368
    s.st.d       [s8, #104], s9
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s8, s1, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s9, #0
    s.st.d       [s8, #0], s3
    s.movz       s9, #128
    s.st.d       [s8, #8], s9
    s.movz       s9, #2048
    s.st.d       [s8, #16], s9
    s.movz       s9, #4096
    s.st.d       [s8, #48], s9
    s.movz       s9, #2
    s.st.d       [s8, #56], s9
    .li       s9, #68719476737
    s.st.d       [s8, #88], s9
    .li       s9, #1108101562368
    s.st.d       [s8, #104], s9
    fence.release.device
    td.load      d1, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s8, s1, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s8, #0], s5
    s.movz       s1, #128
    s.st.d       [s8, #8], s1
    s.movz       s1, #2048
    s.st.d       [s8, #16], s1
    s.movz       s1, #4096
    s.st.d       [s8, #48], s1
    s.movz       s1, #2
    s.st.d       [s8, #56], s1
    .li       s1, #68719476737
    s.st.d       [s8, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d2, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s8, #2048
    s.movz       s9, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s10, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s11, s10, s8
    br.nz        s11, endfor_2
    v.splat      v1, s10
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s11, #2048
    s.movz       s12, #128
    s.movz       s13, #2048
    s.movz       s14, #128
    s.muli       s15, s4, #4096
    s.muli       s16, s4, #4096
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s11
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s12
    v.add        v10, v4, v5
    v.movi       v4, #0
    s.muli       s11, s10, #2
    s.muli       s12, s10, #2
    v.cmp.ge     p1, v6, v1
    v.splat      v1, s13
    v.cmp.lt     p2, v6, v3
    v.splat      v3, s4
    v.movi       v5, #0
    v.cmp.ge     p3, v7, v8
    v.splat      v6, s14
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s13, s2, s15
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v1
    p.and        p2, p3, p4
    v.cmp.ge     p3, v3, v5
    s.add        s14, s3, s16
    p.and        p4, p5, p1
    v.cmp.lt     p1, v3, v6
    p.and        p5, p3, p1
    s.add        s15, s13, s11
    p.and        p1, p6, p2
    s.add        s11, s14, s12
    p.and        p2, p4, p5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s15, #0]
    v.splat      v3, s10
    v.movi       v4, #2048
    v.add        v5, v3, v0
    s.muli       s12, s4, #4096
    v.cmp.lt     p1, v5, v4
    v.splat      v3, s10
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s13, #2048
    s.movz       s14, #128
    v.add        v5, v3, v4
    v.movi       v3, #0
    v.splat      v4, s13
    v.splat      v6, s4
    v.movi       v7, #0
    v.splat      v8, s14
    s.muli       s13, s10, #2
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v9, [s11, #0]
    v.cmp.ge     p2, v5, v3
    v.cmp.lt     p3, v5, v4
    v.cmp.ge     p4, v6, v7
    v.cmp.lt     p5, v6, v8
    s.add        s11, s5, s12
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.add        s12, s11, s13
    p.and        p3, p6, p2
    vf.cvt.bf16.f32 v3, v1
    v.movi       v1, #0
    s.add        s11, s10, s9
    s.movz       s13, #1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s12, #0]
    vf.cvt.bf16.f32 v5, v9
    vf.add       v6, v3, v5
    vf.cvt.bf16.f32 v3, v4
    vf.add       v4, v6, v3
    vf.mul       v3, v4, v4
    vf.add       v4, v2, v3
    @p1 v.sel        v3, v4, v2
    v.mov        v1, v3
    v.mov        v2, v1
    s.mov        s10, s11
    br.nz        s13, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    s.addi       s10, s1, #0
    vf.add       v3, v1, v2
for_3:
    s.cmp.ge     s1, s10, s8
    br.nz        s1, endfor_4
    v.splat      v1, s10
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s1, #2048
    s.movz       s11, #128
    s.movz       s12, #2048
    s.movz       s13, #128
    s.muli       s14, s4, #4096
    v.add        v6, v1, v2
    v.movi       v1, #0
    v.splat      v2, s1
    s.muli       s1, s4, #4096
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s11
    v.add        v10, v4, v5
    v.movi       v4, #0
    v.splat      v5, s12
    s.muli       s11, s10, #2
    s.muli       s12, s10, #2
    v.cmp.ge     p1, v6, v1
    v.splat      v1, s4
    v.cmp.lt     p2, v6, v2
    v.movi       v2, #0
    v.splat      v6, s13
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s13, s2, s14
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v5
    p.and        p2, p3, p4
    v.cmp.ge     p3, v1, v2
    s.add        s14, s3, s1
    p.and        p4, p5, p1
    v.cmp.lt     p1, v1, v6
    p.and        p5, p3, p1
    s.add        s1, s13, s11
    p.and        p1, p6, p2
    s.add        s11, s14, s12
    p.and        p2, p4, p5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s1, #0]
    v.splat      v2, s10
    v.movi       v4, #2048
    v.add        v5, v2, v0
    s.muli       s1, s4, #4096
    v.cmp.lt     p1, v5, v4
    v.splat      v2, s10
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s12, #2048
    s.movz       s13, #128
    v.add        v6, v2, v4
    v.movi       v2, #0
    v.splat      v4, s12
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s13
    s.muli       s12, s10, #2
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v10, [s11, #0]
    v.cmp.ge     p2, v6, v2
    v.cmp.lt     p3, v6, v4
    v.cmp.ge     p4, v7, v8
    v.cmp.lt     p5, v7, v9
    s.add        s11, s5, s1
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.add        s1, s11, s12
    p.and        p3, p6, p2
    s.shli       s11, s10, #1                    // element offset -> bytes (x2)
    vf.cvt.bf16.f32 v2, v1
    .li       s12, #1157627904
    v.splat      v1, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s12, #1065353216
    v.splat      v4, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s12, #897988541
    v.splat      v6, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v7, v1                          // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v8, [s1, #0]
    .li       s1, #1077936128
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s1, s6, s11                     // &in_ptr3[...]
    vf.cvt.bf16.f32 v12, v10
    s.mul        s11, s4, s8
    s.add        s12, s10, s9
    s.movz       s13, #1
    vf.add       v10, v2, v12
    .li       s14, #1065353216
    v.splat      v2, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s14, s10, s11
    s.shli       s15, s14, #1                    // element offset -> bytes (x2)
    vf.cvt.bf16.f32 v12, v8
    s.add        s14, s7, s15                    // &out_ptr1[...]
    vf.add       v8, v10, v12
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v10, [s1, #0]
    vf.fms       v12, v1, v7, v4
    v.splat      v1, s11
    v.add        v4, v5, v1
    vf.fms       v1, v7, v12, v7
    vf.cvt.bf16.f32 v4, v10
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.add       v1, v4, v2
    vf.cmp.o     p2, v5, v5
    @p2 v.sel        v2, v5, v7
    vf.mul       v4, v3, v2                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v2, v4, v6
    v.rsqrt.approx v4, v2                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v4, v4
    vf.mul       v6, v4, v11
    vf.fms       v7, v2, v5, v9
    vf.mul       v2, v6, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v5, v2, v4
    v.extract    s1, v5, #0
    v.splat      v2, s1
    vf.mul       v4, v8, v2
    vf.mul       v2, v4, v1
    vf.cvt.f32.bf16 v1, v2
    @p1 v.st.h       [s14, #0], v1
    s.mov        s10, s12
    br.nz        s13, for_3
endfor_4:
__rctx_next:
    exit
