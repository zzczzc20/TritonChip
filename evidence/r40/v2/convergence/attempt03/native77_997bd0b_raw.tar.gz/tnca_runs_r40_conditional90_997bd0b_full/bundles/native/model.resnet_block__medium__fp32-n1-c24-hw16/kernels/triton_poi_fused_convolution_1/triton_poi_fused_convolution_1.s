    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, pid.y
    s.movz       s3, #16
    s.rdspecial  s5, arg_base
    s.ld.d       s6, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.mul        s7, s2, s3
    s.mul        s2, s4, s3
    s.movz       s3, #0
    s.rdspecial  s4, role_id
    s.movz       s8, #1024
    s.add        s9, s3, s7                      // the tile origin
    s.movz       s3, #24
    s.mul        s10, s4, s8
    s.muli       s4, s2, #4                      // a runtime tile origin, x4
    v.splat      v0, s9
    s.ld.d       s8, [s5, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v1, s3
    v.movi       v2, #0
    s.muli       s3, s7, #36                     // a runtime tile origin, x36
    s.movz       s5, #0
    v.sub        v3, v2, v0
    v.sub        v4, v2, v1
    s.add        s7, s6, s4                      // the tile origin
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.iota       v5                              // arange(0, VLEN)
    s.add        s4, s8, s10                     // this context's own scratch
    s.ld.d       s6, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.addi       s1, s4, #0
    s.add        s8, s7, s3                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    v.splat      v5, s5
    v.movi       v6, #1
    @p1 v.sel        v7, v3, v0
    @p2 v.sel        v0, v4, v1
    v.movi       v3, #0
    v.movi       v4, #0
    s.movz       s3, #31
idiv_1:
    v.splat      v8, s3
    v.shl        v9, v4, v6
    v.cmp.lt     p2, v4, v2
    v.lshr       v10, v7, v8
    v.shl        v11, v6, v8
    s.subi       s5, s3, #1
    v.and        v8, v10, v6
    s.movz       s7, #0
    v.or         v10, v9, v8
    v.cmp.geu    p3, v10, v0
    p.or         p4, p2, p3
    v.sub        v8, v10, v0
    @p4 v.sel        v9, v11, v2
    @p4 v.sel        v11, v8, v10
    v.or         v8, v3, v9
    v.mov        v4, v11
    v.mov        v3, v8
    s.mov        s3, s5
    s.cmp.ge     s5, s3, s7
    br.nz        s5, idiv_1
    s.muli       s3, s2, #24                     // a runtime tile origin, x24
    s.movz       s5, #24
    s.movz       s7, #0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v3, s5
    s.add        s5, s7, s3                      // the tile origin
    v.sub        v6, v2, v4
    v.mul        v2, v0, v3
    v.splat      v0, s5
    v.splat      v3, s9
    v.movi       v7, #0
    @p1 v.sel        v8, v6, v4
    v.add        v4, v2, v0
    v.sub        v0, v7, v3
    v.sub        v2, v7, v1
    v.cmp.lt     p1, v3, v7
    v.cmp.lt     p2, v1, v7
    v.add        v6, v8, v4
    v.movi       v8, #1
    @p1 v.sel        v9, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s3, #31
idiv_2:
    v.splat      v10, s3
    v.shl        v11, v3, v8
    v.cmp.lt     p3, v3, v7
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s5, s3, #1
    v.and        v10, v12, v8
    s.movz       s7, #0
    v.or         v12, v11, v10
    v.cmp.geu    p4, v12, v0
    p.or         p5, p3, p4
    v.sub        v10, v12, v0
    @p5 v.sel        v11, v13, v7
    @p5 v.sel        v13, v10, v12
    v.or         v10, v2, v11
    v.mov        v3, v13
    v.mov        v2, v10
    s.mov        s3, s5
    s.cmp.ge     s5, s3, s7
    br.nz        s5, idiv_2
    v.sub        v0, v7, v2
    p.xor        p3, p1, p2
    s.movz       s3, #216
    @p3 v.sel        v3, v0, v2
    v.splat      v0, s3
    s.addi       s3, s9, #1
    v.movi       v2, #0
    v.mul        v7, v3, v0
    v.splat      v3, s3
    v.sub        v8, v2, v1
    v.add        v9, v6, v7
    v.sub        v6, v2, v3
    v.cmp.lt     p1, v3, v2
    v.add        v7, v5, v9
    v.cmp.lt     p2, v1, v2
    s.addi       s3, s1, #64
    v.st.w       [s1, #0], v7
    v.movi       v7, #1
    @p1 v.sel        v9, v6, v3
    @p2 v.sel        v3, v8, v1
    v.movi       v6, #0
    v.movi       v8, #0
    s.movz       s5, #31
idiv_3:
    v.splat      v10, s5
    v.shl        v11, v8, v7
    v.cmp.lt     p2, v8, v2
    v.lshr       v12, v9, v10
    v.shl        v13, v7, v10
    s.subi       s7, s5, #1
    v.and        v10, v12, v7
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v3
    p.or         p4, p2, p3
    v.sub        v10, v12, v3
    @p4 v.sel        v11, v13, v2
    @p4 v.sel        v13, v10, v12
    v.or         v10, v6, v11
    v.mov        v8, v13
    v.mov        v6, v10
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_3
    s.addi       s5, s9, #1
    v.sub        v3, v2, v8
    v.splat      v2, s5
    v.movi       v6, #0
    @p1 v.sel        v7, v3, v8
    v.movi       v3, #1
    v.sub        v8, v6, v2
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v7, v4
    @p1 v.sel        v7, v8, v2
    @p2 v.sel        v2, v9, v1
    v.movi       v8, #0
    v.movi       v9, #0
    s.movz       s5, #31
idiv_4:
    v.splat      v11, s5
    v.shl        v12, v9, v3
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v7, v11
    v.shl        v14, v3, v11
    s.subi       s7, s5, #1
    v.and        v11, v13, v3
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v2
    p.or         p5, p3, p4
    v.sub        v11, v13, v2
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v8, v12
    v.mov        v9, v14
    v.mov        v8, v11
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_4
    v.sub        v2, v6, v8
    p.xor        p3, p1, p2
    s.addi       s5, s9, #2
    @p3 v.sel        v3, v2, v8
    v.splat      v2, s5
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s5, s1, #128
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s3, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_5:
    v.splat      v10, s3
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s3, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_5
    s.addi       s3, s9, #2
    v.sub        v2, v6, v7
    v.splat      v3, s3
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s3, #31
idiv_6:
    v.splat      v11, s3
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s3, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_6
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s3, s9, #3
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s3
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s3, s1, #192
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s5, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s5, #31
idiv_7:
    v.splat      v10, s5
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s5, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_7
    s.addi       s5, s9, #3
    v.sub        v2, v6, v7
    v.splat      v3, s5
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s5, #31
idiv_8:
    v.splat      v11, s5
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s5, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_8
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s5, s9, #4
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s5
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s5, s1, #256
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s3, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_9:
    v.splat      v10, s3
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s3, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_9
    s.addi       s3, s9, #4
    v.sub        v2, v6, v7
    v.splat      v3, s3
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s3, #31
idiv_10:
    v.splat      v11, s3
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s3, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_10
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s3, s9, #5
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s3
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s3, s1, #320
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s5, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s5, #31
idiv_11:
    v.splat      v10, s5
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s5, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_11
    s.addi       s5, s9, #5
    v.sub        v2, v6, v7
    v.splat      v3, s5
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s5, #31
idiv_12:
    v.splat      v11, s5
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s5, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_12
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s5, s9, #6
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s5
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s5, s1, #384
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s3, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_13:
    v.splat      v10, s3
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s3, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_13
    s.addi       s3, s9, #6
    v.sub        v2, v6, v7
    v.splat      v3, s3
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s3, #31
idiv_14:
    v.splat      v11, s3
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s3, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_14
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s3, s9, #7
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s3
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s3, s1, #448
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s5, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s5, #31
idiv_15:
    v.splat      v10, s5
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s5, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_15
    s.addi       s5, s9, #7
    v.sub        v2, v6, v7
    v.splat      v3, s5
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s5, #31
idiv_16:
    v.splat      v11, s5
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s5, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_16
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s5, s9, #8
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s5
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s5, s1, #512
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s3, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_17:
    v.splat      v10, s3
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s3, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_17
    s.addi       s3, s9, #8
    v.sub        v2, v6, v7
    v.splat      v3, s3
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s3, #31
idiv_18:
    v.splat      v11, s3
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s3, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_18
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s3, s9, #9
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s3
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s3, s1, #576
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s5, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s5, #31
idiv_19:
    v.splat      v10, s5
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s5, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_19
    s.addi       s5, s9, #9
    v.sub        v2, v6, v7
    v.splat      v3, s5
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s5, #31
idiv_20:
    v.splat      v11, s5
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s5, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_20
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s5, s9, #10
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s5
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s5, s1, #640
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s3, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_21:
    v.splat      v10, s3
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s3, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_21
    s.addi       s3, s9, #10
    v.sub        v2, v6, v7
    v.splat      v3, s3
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s3, #31
idiv_22:
    v.splat      v11, s3
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s3, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_22
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s3, s9, #11
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s3
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s3, s1, #704
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s5, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s5, #31
idiv_23:
    v.splat      v10, s5
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s5, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_23
    s.addi       s5, s9, #11
    v.sub        v2, v6, v7
    v.splat      v3, s5
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s5, #31
idiv_24:
    v.splat      v11, s5
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s5, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_24
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s5, s9, #12
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s5
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s5, s1, #768
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s3, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_25:
    v.splat      v10, s3
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s3, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_25
    s.addi       s3, s9, #12
    v.sub        v2, v6, v7
    v.splat      v3, s3
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s3, #31
idiv_26:
    v.splat      v11, s3
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s3, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_26
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s3, s9, #13
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s3
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s3, s1, #832
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s5, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s5, #31
idiv_27:
    v.splat      v10, s5
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s5, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_27
    s.addi       s5, s9, #13
    v.sub        v2, v6, v7
    v.splat      v3, s5
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s5, #31
idiv_28:
    v.splat      v11, s5
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s5, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s5, s7
    s.cmp.ge     s7, s5, s10
    br.nz        s7, idiv_28
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s5, s9, #14
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s5
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s5, s1, #896
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s3, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_29:
    v.splat      v10, s3
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s7, s3, #1
    v.and        v10, v12, v8
    s.movz       s10, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_29
    s.addi       s3, s9, #14
    v.sub        v2, v6, v7
    v.splat      v3, s3
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v8, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s3, #31
idiv_30:
    v.splat      v11, s3
    v.shl        v12, v9, v2
    v.cmp.lt     p3, v9, v6
    v.lshr       v13, v8, v11
    v.shl        v14, v2, v11
    s.subi       s7, s3, #1
    v.and        v11, v13, v2
    s.movz       s10, #0
    v.or         v13, v12, v11
    v.cmp.geu    p4, v13, v3
    p.or         p5, p3, p4
    v.sub        v11, v13, v3
    @p5 v.sel        v12, v14, v6
    @p5 v.sel        v14, v11, v13
    v.or         v11, v7, v12
    v.mov        v9, v14
    v.mov        v7, v11
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s10
    br.nz        s7, idiv_30
    v.sub        v2, v6, v7
    p.xor        p3, p1, p2
    s.addi       s3, s9, #15
    @p3 v.sel        v3, v2, v7
    v.splat      v2, s3
    v.movi       v6, #0
    v.mul        v7, v3, v0
    s.addi       s3, s1, #960
    v.sub        v3, v6, v2
    v.add        v8, v10, v7
    v.sub        v7, v6, v1
    v.cmp.lt     p1, v2, v6
    v.add        v9, v5, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v8, #1
    v.st.w       [s5, #0], v9
    @p1 v.sel        v9, v3, v2
    @p2 v.sel        v2, v7, v1
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_31:
    v.splat      v10, s1
    v.shl        v11, v7, v8
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v9, v10
    v.shl        v13, v8, v10
    s.subi       s5, s1, #1
    v.and        v10, v12, v8
    s.movz       s7, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v10, v12, v2
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v10, v12
    v.or         v10, v3, v11
    v.mov        v7, v13
    v.mov        v3, v10
    s.mov        s1, s5
    s.cmp.ge     s5, s1, s7
    br.nz        s5, idiv_31
    s.addi       s1, s9, #15
    v.sub        v2, v6, v7
    v.splat      v3, s1
    v.movi       v6, #0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    v.sub        v7, v6, v3
    v.sub        v9, v6, v1
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v1, v6
    v.add        v10, v8, v4
    @p1 v.sel        v4, v7, v3
    @p2 v.sel        v3, v9, v1
    v.movi       v1, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_32:
    v.splat      v8, s1
    v.shl        v9, v7, v2
    v.cmp.lt     p3, v7, v6
    v.lshr       v11, v4, v8
    v.shl        v12, v2, v8
    s.subi       s5, s1, #1
    v.and        v8, v11, v2
    s.movz       s7, #0
    v.or         v11, v9, v8
    v.cmp.geu    p4, v11, v3
    p.or         p5, p3, p4
    v.sub        v8, v11, v3
    @p5 v.sel        v9, v12, v6
    @p5 v.sel        v12, v8, v11
    v.or         v8, v1, v9
    v.mov        v7, v12
    v.mov        v1, v8
    s.mov        s1, s5
    s.cmp.ge     s5, s1, s7
    br.nz        s5, idiv_32
    v.sub        v2, v6, v1
    p.xor        p3, p1, p2
    s.movz       s1, #0
    @p3 v.sel        v3, v2, v1
    s.add        s5, s1, s2                      // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.mul        v2, v3, v0
    v.splat      v0, s5
    s.movz       s1, #9
    s.movz       s2, #576
    v.add        v3, v10, v2
    v.add        v2, v1, v0
    v.splat      v0, s1
    v.splat      v1, s9
    v.splat      v4, s2
    v.add        v6, v5, v3
    v.cmp.lt     p1, v2, v0
    v.cmp.lt     p2, v1, v4
    p.and        p3, p1, p2
    s.addi       s1, s4, #0
    v.st.w       [s3, #0], v6
    fence.acq_rel.device
    s.addi       s2, s9, #1
    v.splat      v0, s9
    v.splat      v1, s2
    s.addi       s2, s8, #36                     // row 1
    v.cmp.lt     p2, v0, v4
    p.and        p4, p1, p2
    s.addi       s3, s4, #64
    s.addi       s5, s9, #1
    s.addi       s7, s9, #2
    v.splat      v0, s5
    v.splat      v2, s7
    s.addi       s5, s8, #72                     // row 2
    s.addi       s7, s4, #128
    s.addi       s10, s9, #2
    v.splat      v3, s10
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s8, #0]
    v.cmp.lt     p2, v1, v4
    p.and        p3, p1, p2
    s.addi       s10, s9, #3
    v.splat      v1, s10
    s.addi       s10, s8, #108                   // row 3
    v.ld.w       v6, [s1, #0]
    s.addi       s1, s4, #192
    @p4 v.st.scatter.w [s6, v6], v5
    v.cmp.lt     p2, v0, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s2, #0]
    v.cmp.lt     p2, v2, v4
    p.and        p3, p1, p2
    s.addi       s2, s9, #3
    v.splat      v2, s2
    s.addi       s2, s9, #4
    v.splat      v5, s2
    s.addi       s2, s8, #144                    // row 4
    v.ld.w       v6, [s3, #0]
    s.addi       s3, s4, #256
    @p4 v.st.scatter.w [s6, v6], v0
    v.cmp.lt     p2, v3, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    v.cmp.lt     p2, v1, v4
    p.and        p3, p1, p2
    s.addi       s5, s9, #4
    v.splat      v1, s5
    s.addi       s5, s9, #5
    v.splat      v3, s5
    s.addi       s5, s8, #180                    // row 5
    v.ld.w       v6, [s7, #0]
    s.addi       s7, s4, #320
    @p4 v.st.scatter.w [s6, v6], v0
    v.cmp.lt     p2, v2, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s10, #0]
    v.cmp.lt     p2, v5, v4
    p.and        p3, p1, p2
    s.addi       s10, s9, #5
    v.splat      v2, s10
    s.addi       s10, s9, #6
    v.splat      v5, s10
    s.addi       s10, s8, #216                   // row 6
    v.ld.w       v6, [s1, #0]
    s.addi       s1, s4, #384
    @p4 v.st.scatter.w [s6, v6], v0
    v.cmp.lt     p2, v1, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s2, #0]
    v.cmp.lt     p2, v3, v4
    p.and        p3, p1, p2
    s.addi       s2, s9, #6
    v.splat      v1, s2
    s.addi       s2, s9, #7
    v.splat      v3, s2
    s.addi       s2, s8, #252                    // row 7
    v.ld.w       v6, [s3, #0]
    s.addi       s3, s4, #448
    @p4 v.st.scatter.w [s6, v6], v0
    v.cmp.lt     p2, v2, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    v.cmp.lt     p2, v5, v4
    p.and        p3, p1, p2
    s.addi       s5, s9, #7
    v.splat      v2, s5
    s.addi       s5, s9, #8
    v.splat      v5, s5
    s.addi       s5, s8, #288                    // row 8
    v.ld.w       v6, [s7, #0]
    s.addi       s7, s4, #512
    @p4 v.st.scatter.w [s6, v6], v0
    v.cmp.lt     p2, v1, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s10, #0]
    v.cmp.lt     p2, v3, v4
    p.and        p3, p1, p2
    s.addi       s10, s9, #8
    v.splat      v1, s10
    s.addi       s10, s9, #9
    v.splat      v3, s10
    s.addi       s10, s8, #324                   // row 9
    v.ld.w       v6, [s1, #0]
    s.addi       s1, s4, #576
    @p4 v.st.scatter.w [s6, v6], v0
    v.cmp.lt     p2, v2, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s2, #0]
    v.cmp.lt     p2, v5, v4
    p.and        p3, p1, p2
    s.addi       s2, s9, #9
    v.splat      v2, s2
    s.addi       s2, s9, #10
    v.splat      v5, s2
    s.addi       s2, s8, #360                    // row 10
    v.ld.w       v6, [s3, #0]
    s.addi       s3, s4, #640
    @p4 v.st.scatter.w [s6, v6], v0
    v.cmp.lt     p2, v1, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    v.cmp.lt     p2, v3, v4
    p.and        p3, p1, p2
    s.addi       s5, s9, #10
    v.splat      v1, s5
    s.addi       s5, s9, #11
    v.splat      v3, s5
    s.addi       s5, s8, #396                    // row 11
    v.ld.w       v6, [s7, #0]
    s.addi       s7, s4, #704
    @p4 v.st.scatter.w [s6, v6], v0
    v.cmp.lt     p2, v2, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s10, #0]
    v.cmp.lt     p2, v5, v4
    p.and        p3, p1, p2
    s.addi       s10, s9, #11
    v.splat      v2, s10
    s.addi       s10, s9, #12
    v.splat      v5, s10
    s.addi       s10, s8, #432                   // row 12
    v.ld.w       v6, [s1, #0]
    s.addi       s1, s4, #768
    @p4 v.st.scatter.w [s6, v6], v0
    v.cmp.lt     p2, v1, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s2, #0]
    v.cmp.lt     p2, v3, v4
    p.and        p3, p1, p2
    s.addi       s2, s9, #12
    v.splat      v1, s2
    s.addi       s2, s9, #13
    v.splat      v3, s2
    s.addi       s2, s8, #468                    // row 13
    v.ld.w       v6, [s3, #0]
    s.addi       s3, s4, #832
    @p4 v.st.scatter.w [s6, v6], v0
    v.cmp.lt     p2, v2, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    v.cmp.lt     p2, v5, v4
    p.and        p3, p1, p2
    s.addi       s5, s9, #13
    v.splat      v2, s5
    s.addi       s5, s9, #14
    v.splat      v5, s5
    s.addi       s5, s8, #504                    // row 14
    s.addi       s11, s8, #540                   // row 15
    v.ld.w       v6, [s7, #0]
    s.addi       s7, s4, #896
    s.addi       s8, s4, #960
    @p4 v.st.scatter.w [s6, v6], v0
    v.cmp.lt     p2, v1, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s10, #0]
    v.cmp.lt     p2, v3, v4
    p.and        p3, p1, p2
    s.addi       s4, s9, #14
    v.splat      v1, s4
    s.addi       s4, s9, #15
    s.addi       s10, s9, #15
    v.splat      v3, s4
    v.splat      v6, s10
    v.ld.w       v7, [s1, #0]
    @p4 v.st.scatter.w [s6, v7], v0
    v.cmp.lt     p2, v2, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s2, #0]
    v.cmp.lt     p2, v5, v4
    p.and        p3, p1, p2
    v.ld.w       v2, [s3, #0]
    @p4 v.st.scatter.w [s6, v2], v0
    v.cmp.lt     p2, v1, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    v.cmp.lt     p2, v3, v4
    p.and        p3, p1, p2
    v.ld.w       v1, [s7, #0]
    @p4 v.st.scatter.w [s6, v1], v0
    v.cmp.lt     p2, v6, v4
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s11, #0]
    v.ld.w       v1, [s8, #0]
    @p4 v.st.scatter.w [s6, v1], v0
__rctx_next:
    exit
