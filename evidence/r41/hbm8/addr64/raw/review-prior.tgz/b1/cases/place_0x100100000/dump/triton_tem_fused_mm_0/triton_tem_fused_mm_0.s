    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #3072
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s2
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #96
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #3
    s.movz       s2, #0
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s1, s8
    s.sub        s8, s7, s9
    s.xor        s7, s1, s8
    s.sub        s9, s7, s8
    .li       s7, #1431655766
    s.movz       s9, #2
    s.movz       s10, #1
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #1
    s.cmp.lt     s18, s4, s6
    s.sub        s6, s2, s18
    s.xor        s2, s4, s6
    s.sub        s18, s2, s6
    s.mul        s2, s18, s7
    s.lshri      s7, s2, #32
    s.sub        s2, s18, s7
    s.lshri      s19, s2, #1
    s.add        s2, s7, s19
    s.lshri      s7, s2, #1
    s.muli       s2, s7, #3
    s.sub        s19, s18, s2
    s.xor        s2, s6, s8
    s.xor        s6, s7, s2
    s.sub        s7, s6, s2
    s.sub        s2, s9, s7
    s.min.s      s6, s2, s10
    s.cmp.lt     s2, s4, s12
    s.sub        s8, s11, s2
    s.cmp.lt     s2, s6, s14
    s.sub        s9, s13, s2
    s.xor        s2, s4, s8
    s.sub        s11, s2, s8
    s.xor        s2, s6, s9
    s.sub        s12, s2, s9
    s.addi       s2, s15, #0
    s.addi       s9, s16, #0
    s.cmp.eq     s13, s12, s17
    s.mov        s2, s11
    br.nz        s13, sdiv_done_1
    s.movz       s13, #0
    s.movz       s14, #31
    s.mov        s2, s13
    s.addi       s13, s14, #0
sdiv_2:
    s.lshr       s14, s11, s13
    s.shli       s15, s9, #1
    s.andi       s16, s14, #1
    s.movz       s14, #0
    s.or         s17, s15, s16
    s.movz       s15, #1
    s.cmp.geu    s16, s17, s12
    s.shl        s18, s15, s13
    s.sub        s15, s14, s16
    s.subi       s14, s13, #1
    s.and        s16, s12, s15
    s.and        s19, s18, s15
    s.sub        s15, s17, s16
    s.or         s16, s2, s19
    s.mov        s9, s15
    s.mov        s2, s16
    s.mov        s13, s14
    s.movz       s14, #0
    s.cmp.ge     s15, s13, s14
    br.nz        s15, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s11, #0
    s.cmp.lt     s12, s4, s2
    .li       s2, #1431655766
    s.sub        s13, s11, s12
    s.movz       s11, #0
    s.xor        s12, s4, s13
    s.movz       s4, #0
    s.sub        s14, s12, s13
    s.movz       s12, #0
    s.mul        s15, s14, s2
    s.cmp.lt     s2, s6, s11
    s.movz       s11, #0
    s.movz       s16, #0
    s.sub        s17, s12, s2
    s.lshri      s2, s15, #32
    s.movz       s12, #0
    s.cmp.lt     s15, s1, s11
    s.xor        s11, s6, s17
    s.xor        s6, s9, s8
    s.sub        s9, s12, s15
    s.sub        s12, s14, s2
    s.sub        s15, s11, s17
    s.lshri      s11, s12, #1
    s.sub        s12, s6, s8
    s.add        s6, s2, s11
    s.movz       s2, #0
    s.lshri      s8, s6, #1
    s.movz       s6, #1
    s.muli       s11, s8, #3
    s.addi       s8, s2, #0
    s.cmp.eq     s2, s15, s6
    s.add        s6, s7, s12
    s.xor        s7, s1, s9
    s.sub        s12, s14, s11
    s.movz       s11, #0
    s.xor        s14, s12, s13
    s.sub        s12, s7, s9
    s.sub        s7, s14, s13
    s.addi       s9, s11, #0
    s.cmp.lt     s11, s7, s4
    s.sub        s4, s16, s11
    s.xor        s11, s7, s4
    s.sub        s7, s11, s4
    s.mov        s8, s7
    br.nz        s2, sdiv_done_3
    s.movz       s2, #0
    s.movz       s11, #31
    s.mov        s8, s2
    s.addi       s2, s11, #0
sdiv_4:
    s.lshr       s11, s7, s2
    s.shli       s12, s9, #1
    s.andi       s13, s11, #1
    s.movz       s11, #0
    s.or         s14, s12, s13
    s.movz       s12, #1
    s.cmp.geu    s13, s14, s15
    s.shl        s16, s12, s2
    s.sub        s12, s11, s13
    s.subi       s11, s2, #1
    s.and        s13, s15, s12
    s.and        s18, s16, s12
    s.sub        s12, s14, s13
    s.or         s13, s8, s18
    s.mov        s9, s12
    s.mov        s8, s13
    s.mov        s2, s11
    s.movz       s11, #0
    s.cmp.ge     s12, s2, s11
    br.nz        s12, sdiv_4
sdiv_done_3:
    s.xor        s2, s4, s17
    s.movz       s4, #16
    s.xor        s7, s8, s2
    s.mul        s8, s6, s4
    s.sub        s9, s7, s2
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s9, s4
    v.movi       v1, #40
    v.movi       v2, #0
    s.movz       s7, #0
    s.andi       s11, s8, #31
    v.splat      v3, s2
    v.splat      v4, s6
    v.splat      v5, s7
    v.add        v6, v3, v0
    v.splat      v3, s9
    v.splat      v7, s7
    v.splat      v8, s8
    v.splat      v9, s11
    v.cmp.lt     p1, v6, v2
    v.cmp.lt     p2, v1, v2
    v.cmp.ge     p3, v4, v5
    v.iota       v4                              // arange(0, VLEN)
    v.sub        v5, v2, v6
    v.cmp.ge     p3, v3, v7
    v.sub        v3, v2, v1
    v.add        v7, v8, v0
    v.add        v0, v9, v4
    v.movi       v0, #1
    @p1 v.sel        v4, v5, v6
    @p2 v.sel        v5, v3, v1
    v.movi       v1, #0
    v.movi       v3, #0
    s.movz       s6, #31
idiv_5:
    v.splat      v6, s6
    v.shl        v7, v3, v0
    v.cmp.lt     p2, v3, v2
    v.lshr       v8, v4, v6
    v.shl        v9, v0, v6
    s.subi       s9, s6, #1
    v.and        v6, v8, v0
    s.movz       s12, #0
    v.or         v8, v7, v6
    v.cmp.geu    p3, v8, v5
    p.or         p4, p2, p3
    v.sub        v6, v8, v5
    @p4 v.sel        v7, v9, v2
    @p4 v.sel        v9, v6, v8
    v.or         v6, v1, v7
    v.mov        v3, v9
    v.mov        v1, v6
    s.mov        s6, s9
    s.cmp.ge     s9, s6, s12
    br.nz        s9, idiv_5
    v.sub        v0, v2, v3
    s.addi       s6, s7, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    @p1 v.sel        v1, v0, v3
for_6:
    s.cmp.ge     s9, s6, s1
    br.nz        s9, endfor_7
    s.mul        s9, s6, s4
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s12, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s9                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s13, s12
    mb.wait      s12
    s.rdspecial  s13, arg_base
    s.ld.d       s14, [s13, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s13, role_id
    s.movz       s15, #3072
    s.mul        s16, s13, s15
    s.add        s13, s14, s16                   // this context's own scratch
    s.addi       s14, s13, #256
    v.splat      v0, s7
    s.movz       s15, #0
    s.muli       s16, s9, #40                    // a runtime tile origin, x40
    s.add        s9, s15, s16                    // the tile origin
    v.splat      v2, s9
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s14, #0], v2
    s.addi       s15, s14, #64
    s.addi       s16, s9, #40
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #128
    s.addi       s16, s9, #80
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #192
    s.addi       s16, s9, #120
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #256
    s.addi       s16, s9, #160
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #320
    s.addi       s16, s9, #200
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #384
    s.addi       s16, s9, #240
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #448
    s.addi       s16, s9, #280
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #512
    s.addi       s16, s9, #320
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #576
    s.addi       s16, s9, #360
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #640
    s.addi       s16, s9, #400
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #704
    s.addi       s16, s9, #440
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #768
    s.addi       s16, s9, #480
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #832
    s.addi       s16, s9, #520
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #896
    s.addi       s16, s9, #560
    v.splat      v2, s16
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #960
    s.addi       s14, s9, #600
    v.splat      v2, s14
    v.add        v3, v1, v2
    v.add        v2, v0, v3
    v.st.w       [s15, #0], v2
    fence.acq_rel.device
    s.addi       s9, s13, #1280
    s.addi       s14, s13, #256
    v.ld.w       v0, [s14, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v2
    s.addi       s14, s9, #64
    s.addi       s15, s13, #320
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #128
    s.addi       s15, s13, #384
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #192
    s.addi       s15, s13, #448
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #256
    s.addi       s15, s13, #512
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #320
    s.addi       s15, s13, #576
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #384
    s.addi       s15, s13, #640
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #448
    s.addi       s15, s13, #704
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #512
    s.addi       s15, s13, #768
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #576
    s.addi       s15, s13, #832
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #640
    s.addi       s15, s13, #896
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #704
    s.addi       s15, s13, #960
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #768
    s.addi       s15, s13, #1024
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #832
    s.addi       s15, s13, #1088
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #896
    s.addi       s15, s13, #1152
    v.ld.w       v0, [s15, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s9, #960
    s.addi       s9, s13, #1216
    v.ld.w       v0, [s9, #0]
    v.ld.gather.h v2, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    fence.acq_rel.device
    s.addi       s9, s13, #2304                  // 512 bytes of repack scratch
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s14, s13, #1280
    v.ld.w       v0, [s14, #0]
    v.st.h       [s9, #0], v0
    s.addi       s14, s13, #1344
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #32                    // row 1
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #1408
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #64                    // row 2
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #1472
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #96                    // row 3
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #1536
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #128                   // row 4
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #1600
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #160                   // row 5
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #1664
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #192                   // row 6
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #1728
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #224                   // row 7
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #1792
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #256                   // row 8
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #1856
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #288                   // row 9
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #1920
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #320                   // row 10
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #1984
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #352                   // row 11
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #2048
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #384                   // row 12
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #2112
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #416                   // row 13
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #2176
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #448                   // row 14
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #2240
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #480                   // row 15
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #2816                 // TensorMap 1: a repacked tile
    s.movz       s13, #0
    s.st.d       [s14, #0], s9
    s.movz       s9, #16
    s.st.d       [s14, #8], s9
    s.movz       s9, #16
    s.st.d       [s14, #16], s9
    s.movz       s9, #32
    s.st.d       [s14, #48], s9
    s.movz       s9, #2
    s.st.d       [s14, #56], s9
    .li       s9, #68719476752
    s.st.d       [s14, #88], s9
    .li       s9, #1108101562368
    s.st.d       [s14, #104], s9
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s9, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s14, s9                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s9                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s9, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v56, v48, s9
    mb.wait      s9
    s.add        s14, s6, s10
    s.mov        s6, s14
    s.movz       s14, #1
    br.nz        s14, for_6
endfor_7:
    s.movz       s1, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    s.add        s4, s1, s2                      // the tile origin
    s.movz       s1, #0
    s.muli       s6, s2, #2                      // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s4
    a.vread      v2, a0, s3
    s.add        s2, s1, s8                      // the tile origin
    s.movz       s1, #32
    s.movz       s3, #40
    s.muli       s4, s8, #80                     // a runtime tile origin, x80
    v.splat      v3, s2
    v.splat      v4, s1
    v.add        v5, v0, v1
    v.splat      v0, s3
    vf.cvt.f32.bf16 v1, v2
    s.add        s1, s5, s6                      // the tile origin
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s3, s1, s4                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    @p3 v.st.h       [s3, #0], v1
    a.vread      v0, a0, s1
    s.addi       s1, s2, #1
    s.addi       s4, s3, #80                     // row 1
    v.splat      v1, s1
    vf.cvt.f32.bf16 v2, v0
    s.movz       s1, #2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s5, s2, #2
    s.addi       s6, s3, #160                    // row 2
    v.splat      v0, s5
    s.movz       s5, #3
    s.addi       s7, s2, #3
    @p3 v.st.h       [s4, #0], v2
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    v.splat      v1, s7
    s.addi       s1, s3, #240                    // row 3
    s.movz       s4, #4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    s.addi       s7, s2, #4
    s.addi       s8, s3, #320                    // row 4
    v.splat      v1, s7
    s.movz       s7, #5
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s5, s2, #5
    s.addi       s6, s3, #400                    // row 5
    v.splat      v0, s5
    s.movz       s5, #6
    @p4 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s2, #6
    s.addi       s4, s3, #480                    // row 6
    v.splat      v1, s1
    s.movz       s1, #7
    @p3 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s7
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s7, s2, #7
    s.addi       s8, s3, #560                    // row 7
    v.splat      v0, s7
    s.movz       s7, #8
    @p4 v.st.h       [s6, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.addi       s5, s2, #8
    s.addi       s6, s3, #640                    // row 8
    v.splat      v1, s5
    s.movz       s5, #9
    @p3 v.st.h       [s4, #0], v0
    a.vread      v0, a0, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s2, #9
    s.addi       s4, s3, #720                    // row 9
    v.splat      v0, s1
    s.movz       s1, #10
    @p4 v.st.h       [s8, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.addi       s7, s2, #10
    s.addi       s8, s3, #800                    // row 10
    v.splat      v1, s7
    s.movz       s7, #11
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s5, s2, #11
    s.addi       s6, s3, #880                    // row 11
    v.splat      v0, s5
    s.movz       s5, #12
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s2, #12
    s.addi       s4, s3, #960                    // row 12
    v.splat      v1, s1
    s.movz       s1, #13
    @p3 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s7
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s7, s2, #13
    s.addi       s8, s3, #1040                   // row 13
    v.splat      v0, s7
    s.movz       s7, #14
    @p4 v.st.h       [s6, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.addi       s5, s2, #14
    s.addi       s6, s3, #1120                   // row 14
    v.splat      v1, s5
    s.movz       s5, #15
    s.addi       s10, s2, #15
    s.addi       s2, s3, #1200                   // row 15
    v.splat      v2, s10
    @p3 v.st.h       [s4, #0], v0
    a.vread      v0, a0, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s8, #0], v1
    a.vread      v0, a0, s7
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s6, #0], v1
    a.vread      v0, a0, s5
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s2, #0], v1
__rctx_next:
    exit
