    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s4, #512
    s.movz       s5, #8192
    s.mul        s6, s1, s4
    s.movz       s1, #512
    s.movz       s4, #2048
    s.movz       s7, #4
    .li       s8, #68719476737
    .li       s9, #2207613190144
    s.movz       s10, #0
    s.ld.d       s10, [s2, #8]                   // in_ptr0: device_ptr64 at arg_base+8
    s.add        s11, s3, s6                     // this context's own scratch
    s.movz       s3, #0
    s.addi       s6, s11, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #512
    s.ld.d       s13, [s2, #0]                   // in_out_ptr0: device_ptr64 at arg_base+0
    s.st.d       [s6, #0], s10
    s.st.d       [s6, #8], s5
    s.movz       s2, #16
    s.st.d       [s6, #16], s1
    s.rdspecial  s1, role_id
    s.st.d       [s6, #48], s4
    s.rdspecial  s4, npid.x
    s.st.d       [s6, #56], s7
    s.st.d       [s6, #88], s8
    s.st.d       [s6, #104], s9
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
__rctx_program:
    v.splat      v0, s1
    v.movi       v1, #0
    v.movi       v2, #511
    v.movi       v3, #512
    v.sub        v4, v1, v0
    v.cmp.lt     p1, v0, v1
    v.movi       v5, #0
    @p1 v.sel        v6, v4, v0
    v.movi       v0, #0
    v.sub        v4, v1, v3
    v.and        v7, v6, v2
    .li       s5, #4286578688
    v.splat      v2, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v6, #0
    v.sub        v8, v1, v7
    v.cmp.lt     p2, v3, v1
    v.cmp.ne     p3, v5, v0
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #1
    @p2 v.sel        v1, v4, v3
    @p1 v.sel        v1, v8, v7
    s.addi       s5, s3, #0
    p.mov        p1, p3
    v.mov        v6, v2
for_1:
    s.cmp.ge     s6, s5, s12
    br.nz        s6, endfor_2
    v.movi       v3, #-1
    v.splat      v4, s5
    v.splat      v5, s5
    v.mul        v7, v1, v3
    v.add        v3, v4, v0
    v.iota       v4                              // arange(0, VLEN)
    v.extract    s6, v7, #0
    s.movz       s7, #512
    v.splat      v7, s6
    s.movz       s6, #8192
    s.muli       s8, s1, #2048
    v.add        v8, v3, v7
    v.add        v7, v5, v4
    v.movi       v4, #0
    v.splat      v5, s7
    v.splat      v9, s1
    v.movi       v10, #0
    v.splat      v11, s6
    v.extract    s6, v8, #0
    s.muli       s7, s5, #4
    s.shli       s9, s6, #32
    v.cmp.ge     p2, v7, v4
    v.cmp.lt     p3, v7, v5
    v.cmp.ge     p4, v9, v10
    v.cmp.lt     p5, v9, v11
    v.extract    s6, v8, #1
    s.add        s14, s10, s8
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.ashri      s8, s9, #32
    v.movi       v4, #0
    v.movi       v5, #0
    s.shli       s9, s6, #32
    s.add        s6, s14, s7
    p.and        p3, p6, p2
    s.lshri      s7, s8, #32
    v.extract    s14, v8, #2
    s.ashri      s15, s9, #32
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v7, [s6, #0]
    v.insert     v4, s8, #0
    v.insert     v5, s7, #0
    s.shli       s6, s14, #32
    s.lshri      s7, s15, #32
    s.ashri      s8, s6, #32
    v.insert     v4, s15, #1
    v.insert     v5, s7, #1
    v.movi       v9, #512
    s.lshri      s6, s8, #32
    v.insert     v4, s8, #2
    v.cmp.lt     p2, v3, v9
    v.extract    s7, v8, #3
    v.extract    s8, v8, #4
    s.shli       s9, s7, #32
    v.insert     v5, s6, #2
    s.ashri      s6, s9, #32
    s.shli       s7, s8, #32
    s.lshri      s8, s6, #32
    v.extract    s9, v8, #5
    s.ashri      s14, s7, #32
    v.insert     v4, s6, #3
    v.insert     v5, s8, #3
    s.shli       s6, s9, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v8, #6
    s.ashri      s9, s6, #32
    v.insert     v4, s14, #4
    v.insert     v5, s7, #4
    s.shli       s6, s8, #32
    s.lshri      s7, s9, #32
    s.ashri      s8, s6, #32
    v.insert     v4, s9, #5
    v.insert     v5, s7, #5
    .li       s6, #-1
    v.extract    s6, v8, #7
    s.lshri      s7, s8, #32
    s.shli       s9, s6, #32
    v.extract    s6, v8, #8
    s.ashri      s14, s9, #32
    v.insert     v4, s8, #6
    v.insert     v5, s7, #6
    s.shli       s7, s6, #32
    s.lshri      s6, s14, #32
    v.extract    s8, v8, #9
    s.ashri      s9, s7, #32
    v.insert     v4, s14, #7
    v.insert     v5, s6, #7
    s.shli       s6, s8, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v8, #10
    s.ashri      s14, s6, #32
    v.insert     v4, s9, #8
    v.insert     v5, s7, #8
    s.shli       s6, s8, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v8, #11
    s.ashri      s9, s6, #32
    v.insert     v4, s14, #9
    v.insert     v5, s7, #9
    s.shli       s6, s8, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v8, #12
    s.ashri      s14, s6, #32
    v.insert     v4, s9, #10
    v.insert     v5, s7, #10
    s.shli       s6, s8, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v8, #13
    s.ashri      s9, s6, #32
    v.insert     v4, s14, #11
    v.insert     v5, s7, #11
    s.shli       s6, s8, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v8, #14
    s.ashri      s14, s6, #32
    v.insert     v4, s9, #12
    v.insert     v5, s7, #12
    s.shli       s6, s8, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v8, #15
    s.ashri      s9, s6, #32
    v.insert     v4, s14, #13
    v.insert     v5, s7, #13
    s.shli       s6, s8, #32
    s.lshri      s7, s9, #32
    s.ashri      s8, s6, #32
    v.insert     v4, s9, #14
    v.insert     v5, s7, #14
    s.lshri      s6, s8, #32
    v.insert     v4, s8, #15
    v.insert     v5, s6, #15
    s.movz       s6, #0
    v.extract    s7, v4, #0
    v.extract    s8, v5, #0
    v.extract    s9, v5, #1
    s.shli       s14, s8, #32
    v.movi       v3, #0
    s.or         s8, s7, s14
    v.extract    s7, v4, #1
    s.shli       s14, s9, #32
    s.cmp.le     s9, s8, s6
    v.extract    s6, v5, #2
    s.or         s8, s7, s14
    s.movz       s7, #0
    v.insert     v3, s9, #0
    v.extract    s9, v4, #2
    s.shli       s14, s6, #32
    s.cmp.le     s6, s8, s7
    v.extract    s7, v5, #3
    s.or         s8, s9, s14
    s.movz       s9, #0
    v.insert     v3, s6, #1
    v.extract    s6, v4, #3
    s.shli       s14, s7, #32
    s.cmp.le     s7, s8, s9
    v.extract    s8, v5, #4
    s.or         s9, s6, s14
    s.movz       s6, #0
    v.insert     v3, s7, #2
    v.extract    s7, v4, #4
    s.shli       s14, s8, #32
    s.cmp.le     s8, s9, s6
    v.extract    s6, v5, #5
    s.or         s9, s7, s14
    s.movz       s7, #0
    v.insert     v3, s8, #3
    v.extract    s8, v4, #5
    s.shli       s14, s6, #32
    s.cmp.le     s6, s9, s7
    v.extract    s7, v5, #6
    s.or         s9, s8, s14
    s.movz       s8, #0
    v.insert     v3, s6, #4
    v.extract    s6, v4, #6
    s.shli       s14, s7, #32
    s.cmp.le     s7, s9, s8
    v.extract    s8, v5, #7
    s.or         s9, s6, s14
    s.movz       s6, #0
    v.insert     v3, s7, #5
    v.extract    s7, v4, #7
    s.shli       s14, s8, #32
    s.cmp.le     s8, s9, s6
    v.extract    s6, v5, #8
    s.or         s9, s7, s14
    s.movz       s7, #0
    v.insert     v3, s8, #6
    v.extract    s8, v4, #8
    s.shli       s14, s6, #32
    s.cmp.le     s6, s9, s7
    v.extract    s7, v5, #9
    s.or         s9, s8, s14
    s.movz       s8, #0
    v.insert     v3, s6, #7
    v.extract    s6, v4, #9
    s.shli       s14, s7, #32
    s.cmp.le     s7, s9, s8
    v.extract    s8, v5, #10
    s.or         s9, s6, s14
    s.movz       s6, #0
    v.insert     v3, s7, #8
    v.extract    s7, v4, #10
    s.shli       s14, s8, #32
    s.cmp.le     s8, s9, s6
    v.extract    s6, v5, #11
    s.or         s9, s7, s14
    s.movz       s7, #0
    v.insert     v3, s8, #9
    v.extract    s8, v4, #11
    s.shli       s14, s6, #32
    s.cmp.le     s6, s9, s7
    v.extract    s7, v5, #12
    s.or         s9, s8, s14
    s.movz       s8, #0
    v.insert     v3, s6, #10
    v.extract    s6, v4, #12
    s.shli       s14, s7, #32
    s.cmp.le     s7, s9, s8
    v.extract    s8, v5, #13
    s.or         s9, s6, s14
    s.movz       s6, #0
    v.insert     v3, s7, #11
    v.extract    s7, v4, #13
    s.shli       s14, s8, #32
    s.cmp.le     s8, s9, s6
    v.extract    s6, v5, #14
    s.or         s9, s7, s14
    s.movz       s7, #0
    v.insert     v3, s8, #12
    v.extract    s8, v4, #14
    s.shli       s14, s6, #32
    s.cmp.le     s6, s9, s7
    v.extract    s7, v5, #15
    s.or         s9, s8, s14
    s.movz       s8, #0
    v.insert     v3, s6, #13
    v.extract    s6, v4, #15
    s.shli       s14, s7, #32
    s.cmp.le     s7, s9, s8
    s.or         s8, s6, s14
    s.movz       s6, #0
    v.insert     v3, s7, #14
    s.cmp.le     s7, s8, s6
    v.movi       v4, #0
    v.insert     v3, s7, #15
    v.movi       v5, #0
    v.movi       v8, #1
    v.cmp.ne     p3, v3, v4
    @p3 v.sel        v3, v5, v2
    v.movi       v4, #0
    v.movi       v5, #0
    vf.add       v9, v7, v3
    v.movi       v3, #1
    v.movi       v7, #0
    v.movi       v10, #1
    v.movi       v11, #0
    vf.cmp.eq    p3, v9, v2
    @p3 v.sel        v12, v8, v4
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.eq     p3, v12, v5
    @p3 v.sel        v5, v3, v7
    @p3 v.sel        v3, v10, v11
    v.movi       v7, #0
    v.extract    s6, v5, #0
    v.movi       v5, #0
    s.lshri      s7, s6, #32
    v.extract    s8, v3, #1
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s6, #0
    v.insert     v5, s7, #0
    s.lshri      s6, s8, #32
    v.extract    s7, v3, #2
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s8, #1
    v.insert     v5, s6, #1
    s.lshri      s6, s7, #32
    v.extract    s8, v3, #3
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s7, #2
    v.insert     v5, s6, #2
    s.lshri      s6, s8, #32
    v.extract    s7, v3, #4
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s8, #3
    v.insert     v5, s6, #3
    s.lshri      s6, s7, #32
    v.extract    s8, v3, #5
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s7, #4
    v.insert     v5, s6, #4
    s.lshri      s6, s8, #32
    v.extract    s7, v3, #6
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s8, #5
    v.insert     v5, s6, #5
    s.lshri      s6, s7, #32
    v.extract    s8, v3, #7
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s7, #6
    v.insert     v5, s6, #6
    s.lshri      s6, s8, #32
    v.extract    s7, v3, #8
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s8, #7
    v.insert     v5, s6, #7
    s.lshri      s6, s7, #32
    v.extract    s8, v3, #9
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s7, #8
    v.insert     v5, s6, #8
    s.lshri      s6, s8, #32
    v.extract    s7, v3, #10
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s8, #9
    v.insert     v5, s6, #9
    s.lshri      s6, s7, #32
    v.extract    s8, v3, #11
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s7, #10
    v.insert     v5, s6, #10
    s.lshri      s6, s8, #32
    v.extract    s7, v3, #12
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s8, #11
    v.insert     v5, s6, #11
    s.lshri      s6, s7, #32
    v.extract    s8, v3, #13
    @p3 v.sel        v3, v4, v8
    v.movi       v4, #1
    v.movi       v8, #0
    v.insert     v7, s7, #12
    v.insert     v5, s6, #12
    s.lshri      s6, s8, #32
    v.extract    s7, v3, #14
    @p3 v.sel        v3, v4, v8
    v.insert     v7, s8, #13
    v.insert     v5, s6, #13
    s.lshri      s6, s7, #32
    v.extract    s8, v3, #15
    v.insert     v7, s7, #14
    v.insert     v5, s6, #14
    s.lshri      s6, s8, #32
    v.insert     v7, s8, #15
    v.insert     v5, s6, #15
    s.movz       s6, #0
    v.extract    s7, v7, #0
    v.extract    s8, v5, #0
    v.extract    s9, v5, #1
    s.shli       s14, s8, #32
    v.movi       v3, #0
    s.or         s8, s7, s14
    v.extract    s7, v7, #1
    s.shli       s14, s9, #32
    s.cmp.ne     s9, s8, s6
    v.extract    s6, v5, #2
    s.or         s8, s7, s14
    s.movz       s7, #0
    v.insert     v3, s9, #0
    v.extract    s9, v7, #2
    s.shli       s14, s6, #32
    s.cmp.ne     s6, s8, s7
    v.extract    s7, v5, #3
    s.or         s8, s9, s14
    s.movz       s9, #0
    v.insert     v3, s6, #1
    v.extract    s6, v7, #3
    s.shli       s14, s7, #32
    s.cmp.ne     s7, s8, s9
    v.extract    s8, v5, #4
    s.or         s9, s6, s14
    s.movz       s6, #0
    v.insert     v3, s7, #2
    v.extract    s7, v7, #4
    s.shli       s14, s8, #32
    s.cmp.ne     s8, s9, s6
    v.extract    s6, v5, #5
    s.or         s9, s7, s14
    s.movz       s7, #0
    v.insert     v3, s8, #3
    v.extract    s8, v7, #5
    s.shli       s14, s6, #32
    s.cmp.ne     s6, s9, s7
    v.extract    s7, v5, #6
    s.or         s9, s8, s14
    s.movz       s8, #0
    v.insert     v3, s6, #4
    v.extract    s6, v7, #6
    s.shli       s14, s7, #32
    s.cmp.ne     s7, s9, s8
    v.extract    s8, v5, #7
    s.or         s9, s6, s14
    s.movz       s6, #0
    v.insert     v3, s7, #5
    v.extract    s7, v7, #7
    s.shli       s14, s8, #32
    s.cmp.ne     s8, s9, s6
    v.extract    s6, v5, #8
    s.or         s9, s7, s14
    s.movz       s7, #0
    v.insert     v3, s8, #6
    v.extract    s8, v7, #8
    s.shli       s14, s6, #32
    s.cmp.ne     s6, s9, s7
    v.extract    s7, v5, #9
    s.or         s9, s8, s14
    s.movz       s8, #0
    v.insert     v3, s6, #7
    v.extract    s6, v7, #9
    s.shli       s14, s7, #32
    s.cmp.ne     s7, s9, s8
    v.extract    s8, v5, #10
    s.or         s9, s6, s14
    s.movz       s6, #0
    v.insert     v3, s7, #8
    v.extract    s7, v7, #10
    s.shli       s14, s8, #32
    s.cmp.ne     s8, s9, s6
    v.extract    s6, v5, #11
    s.or         s9, s7, s14
    s.movz       s7, #0
    v.insert     v3, s8, #9
    v.extract    s8, v7, #11
    s.shli       s14, s6, #32
    s.cmp.ne     s6, s9, s7
    v.extract    s7, v5, #12
    s.or         s9, s8, s14
    s.movz       s8, #0
    v.insert     v3, s6, #10
    v.extract    s6, v7, #12
    s.shli       s14, s7, #32
    s.cmp.ne     s7, s9, s8
    v.extract    s8, v5, #13
    s.or         s9, s6, s14
    s.movz       s6, #0
    v.insert     v3, s7, #11
    v.extract    s7, v7, #13
    s.shli       s14, s8, #32
    s.cmp.ne     s8, s9, s6
    v.extract    s6, v5, #14
    s.or         s9, s7, s14
    s.movz       s7, #0
    v.insert     v3, s8, #12
    v.extract    s8, v7, #14
    s.shli       s14, s6, #32
    s.cmp.ne     s6, s9, s7
    v.extract    s7, v5, #15
    s.or         s9, s8, s14
    s.movz       s8, #0
    v.insert     v3, s6, #13
    v.extract    s6, v7, #15
    s.shli       s14, s7, #32
    s.cmp.ne     s7, s9, s8
    s.or         s8, s6, s14
    s.movz       s6, #0
    v.insert     v3, s7, #14
    s.cmp.ne     s7, s8, s6
    v.movi       v4, #0
    v.insert     v3, s7, #15
    vf.max       v5, v6, v9
    p.not        p3, p2
    v.cmp.ne     p4, v3, v4
    p.or         p5, p1, p4
    p.and        p4, p3, p1
    p.and        p3, p2, p5
    @p2 v.sel        v3, v5, v6
    v.movi       v4, #0
    p.or         p2, p3, p4
    s.add        s6, s5, s2
    p.mov        p3, p2
    v.mov        v4, v3
    s.movz       s7, #1
    p.mov        p1, p3
    v.mov        v6, v4
    s.mov        s5, s6
    br.nz        s7, for_1
endfor_2:
    v.movi       v3, #1
    v.movi       v4, #0
    vf.cmp.uo    p2, v6, v6
    v.movi       v5, #1
    @p2 v.sel        v7, v3, v4
    v.movi       v3, #0
    v.movi       v4, #0
    v.reduce.or.b v8, v7
    vf.reduce.max.b v7, v6
    .li       s5, #2143289344
    v.splat      v6, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v9, v5, v3
    v.cmp.ne     p1, v8, v4
    @p1 v.sel        v3, v6, v7
    v.movi       v4, #0
    v.movi       v5, #0
    v.movi       v6, #0
    v.reduce.or  s5, v9
    vf.add       v7, v3, v4
    v.splat      v3, s5
    s.addi       s5, s3, #0
    v.mov        v6, v5
for_3:
    s.cmp.ge     s6, s5, s12
    br.nz        s6, endfor_4
    v.movi       v8, #-1
    v.splat      v9, s5
    v.splat      v10, s5
    v.mul        v11, v1, v8
    v.add        v8, v9, v0
    v.iota       v9                              // arange(0, VLEN)
    v.extract    s6, v11, #0
    s.movz       s7, #512
    v.splat      v11, s6
    s.movz       s6, #8192
    s.muli       s8, s1, #2048
    v.add        v12, v8, v11
    v.add        v11, v10, v9
    v.movi       v9, #0
    v.splat      v10, s7
    v.splat      v13, s1
    v.movi       v14, #0
    v.splat      v15, s6
    v.extract    s6, v12, #0
    s.muli       s7, s5, #4
    s.shli       s9, s6, #32
    v.cmp.ge     p1, v11, v9
    v.cmp.lt     p2, v11, v10
    v.cmp.ge     p3, v13, v14
    v.cmp.lt     p4, v13, v15
    v.extract    s6, v12, #1
    s.add        s14, s10, s8
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.ashri      s8, s9, #32
    v.movi       v9, #0
    v.movi       v10, #0
    s.shli       s9, s6, #32
    s.add        s6, s14, s7
    p.and        p2, p5, p1
    s.lshri      s7, s8, #32
    v.extract    s14, v12, #2
    s.ashri      s15, s9, #32
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v11, [s6, #0]
    v.insert     v9, s8, #0
    v.insert     v10, s7, #0
    s.shli       s6, s14, #32
    s.lshri      s7, s15, #32
    s.ashri      s8, s6, #32
    v.insert     v9, s15, #1
    v.insert     v10, s7, #1
    v.movi       v13, #512
    s.lshri      s6, s8, #32
    v.insert     v9, s8, #2
    v.cmp.lt     p1, v8, v13
    v.extract    s7, v12, #3
    v.extract    s8, v12, #4
    s.shli       s9, s7, #32
    v.insert     v10, s6, #2
    s.ashri      s6, s9, #32
    s.shli       s7, s8, #32
    s.lshri      s8, s6, #32
    v.extract    s9, v12, #5
    s.ashri      s14, s7, #32
    v.insert     v9, s6, #3
    v.insert     v10, s8, #3
    s.shli       s6, s9, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v12, #6
    s.ashri      s9, s6, #32
    v.insert     v9, s14, #4
    v.insert     v10, s7, #4
    s.shli       s6, s8, #32
    s.lshri      s7, s9, #32
    s.ashri      s8, s6, #32
    v.insert     v9, s9, #5
    v.insert     v10, s7, #5
    .li       s6, #-1
    v.extract    s6, v12, #7
    s.lshri      s7, s8, #32
    s.shli       s9, s6, #32
    v.extract    s6, v12, #8
    s.ashri      s14, s9, #32
    v.insert     v9, s8, #6
    v.insert     v10, s7, #6
    s.shli       s7, s6, #32
    s.lshri      s6, s14, #32
    v.extract    s8, v12, #9
    s.ashri      s9, s7, #32
    v.insert     v9, s14, #7
    v.insert     v10, s6, #7
    s.shli       s6, s8, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v12, #10
    s.ashri      s14, s6, #32
    v.insert     v9, s9, #8
    v.insert     v10, s7, #8
    s.shli       s6, s8, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v12, #11
    s.ashri      s9, s6, #32
    v.insert     v9, s14, #9
    v.insert     v10, s7, #9
    s.shli       s6, s8, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v12, #12
    s.ashri      s14, s6, #32
    v.insert     v9, s9, #10
    v.insert     v10, s7, #10
    s.shli       s6, s8, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v12, #13
    s.ashri      s9, s6, #32
    v.insert     v9, s14, #11
    v.insert     v10, s7, #11
    s.shli       s6, s8, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v12, #14
    s.ashri      s14, s6, #32
    v.insert     v9, s9, #12
    v.insert     v10, s7, #12
    s.shli       s6, s8, #32
    s.lshri      s7, s14, #32
    v.extract    s8, v12, #15
    s.ashri      s9, s6, #32
    v.insert     v9, s14, #13
    v.insert     v10, s7, #13
    s.shli       s6, s8, #32
    s.lshri      s7, s9, #32
    s.ashri      s8, s6, #32
    v.insert     v9, s9, #14
    v.insert     v10, s7, #14
    s.lshri      s6, s8, #32
    v.insert     v9, s8, #15
    v.insert     v10, s6, #15
    s.movz       s6, #0
    v.extract    s7, v9, #0
    v.extract    s8, v10, #0
    v.extract    s9, v10, #1
    s.shli       s14, s8, #32
    v.movi       v12, #0
    s.or         s8, s7, s14
    v.extract    s7, v9, #1
    s.shli       s14, s9, #32
    s.cmp.le     s9, s8, s6
    v.extract    s6, v10, #2
    s.or         s8, s7, s14
    s.movz       s7, #0
    v.insert     v12, s9, #0
    v.extract    s9, v9, #2
    s.shli       s14, s6, #32
    s.cmp.le     s6, s8, s7
    v.extract    s7, v10, #3
    s.or         s8, s9, s14
    s.movz       s9, #0
    v.insert     v12, s6, #1
    v.extract    s6, v9, #3
    s.shli       s14, s7, #32
    s.cmp.le     s7, s8, s9
    v.extract    s8, v10, #4
    s.or         s9, s6, s14
    s.movz       s6, #0
    v.insert     v12, s7, #2
    v.extract    s7, v9, #4
    s.shli       s14, s8, #32
    s.cmp.le     s8, s9, s6
    v.extract    s6, v10, #5
    s.or         s9, s7, s14
    s.movz       s7, #0
    v.insert     v12, s8, #3
    v.extract    s8, v9, #5
    s.shli       s14, s6, #32
    s.cmp.le     s6, s9, s7
    v.extract    s7, v10, #6
    s.or         s9, s8, s14
    s.movz       s8, #0
    v.insert     v12, s6, #4
    v.extract    s6, v9, #6
    s.shli       s14, s7, #32
    s.cmp.le     s7, s9, s8
    v.extract    s8, v10, #7
    s.or         s9, s6, s14
    s.movz       s6, #0
    v.insert     v12, s7, #5
    v.extract    s7, v9, #7
    s.shli       s14, s8, #32
    s.cmp.le     s8, s9, s6
    v.extract    s6, v10, #8
    s.or         s9, s7, s14
    s.movz       s7, #0
    v.insert     v12, s8, #6
    v.extract    s8, v9, #8
    s.shli       s14, s6, #32
    s.cmp.le     s6, s9, s7
    v.extract    s7, v10, #9
    s.or         s9, s8, s14
    s.movz       s8, #0
    v.insert     v12, s6, #7
    v.extract    s6, v9, #9
    s.shli       s14, s7, #32
    s.cmp.le     s7, s9, s8
    v.extract    s8, v10, #10
    s.or         s9, s6, s14
    s.movz       s6, #0
    v.insert     v12, s7, #8
    v.extract    s7, v9, #10
    s.shli       s14, s8, #32
    s.cmp.le     s8, s9, s6
    v.extract    s6, v10, #11
    s.or         s9, s7, s14
    s.movz       s7, #0
    v.insert     v12, s8, #9
    v.extract    s8, v9, #11
    s.shli       s14, s6, #32
    s.cmp.le     s6, s9, s7
    v.extract    s7, v10, #12
    s.or         s9, s8, s14
    s.movz       s8, #0
    v.insert     v12, s6, #10
    v.extract    s6, v9, #12
    s.shli       s14, s7, #32
    s.cmp.le     s7, s9, s8
    v.extract    s8, v10, #13
    s.or         s9, s6, s14
    s.movz       s6, #0
    v.insert     v12, s7, #11
    v.extract    s7, v9, #13
    s.shli       s14, s8, #32
    s.cmp.le     s8, s9, s6
    v.extract    s6, v10, #14
    s.or         s9, s7, s14
    s.movz       s7, #0
    v.insert     v12, s8, #12
    v.extract    s8, v9, #14
    s.shli       s14, s6, #32
    s.cmp.le     s6, s9, s7
    v.extract    s7, v10, #15
    s.or         s9, s8, s14
    s.movz       s8, #0
    v.insert     v12, s6, #13
    v.extract    s6, v9, #15
    s.shli       s14, s7, #32
    s.cmp.le     s7, s9, s8
    s.or         s8, s6, s14
    s.movz       s6, #0
    v.insert     v12, s7, #14
    s.cmp.le     s7, s8, s6
    v.movi       v9, #0
    v.insert     v12, s7, #15
    v.extract    s6, v7, #0
    .li       s7, #1069066811
    v.splat      v10, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p2, v12, v9
    @p2 v.sel        v9, v5, v2
    v.splat      v12, s6
    .li       s6, #1060205080
    v.splat      v13, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v14, v11, v9
    s.mul        s6, s1, s12
    v.movi       v9, #0
    s.add        s7, s5, s2
    s.movz       s8, #1
    vf.sub       v11, v14, v12
    s.add        s9, s5, s6
    v.splat      v12, s6
    s.shli       s6, s9, #2                      // element offset -> bytes (x4)
    vf.mul       v14, v11, v10
    s.add        s9, s13, s6                     // &in_out_ptr0[...]
    v.add        v15, v8, v12
    v.exp2.approx v8, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v12, v11, v10, v14              // the exact rounding error of x*log2(e)
    vf.mul       v10, v12, v13
    vf.fma       v11, v8, v10, v8                // 2**t * 2**d
    vf.cmp.o     p2, v11, v11
    @p2 v.sel        v10, v11, v8
    vf.add       v8, v6, v10
    @p1 v.st.w       [s9, #0], v10
    @p1 v.sel        v10, v8, v6
    v.mov        v9, v10
    v.mov        v6, v9
    s.mov        s5, s7
    br.nz        s8, for_3
endfor_4:
    vf.reduce.add.b v1, v6
    vf.add       v2, v1, v4
    s.addi       s5, s11, #256                   // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s6, #0
    s.st.d       [s5, #0], s13
    s.movz       s6, #8192
    s.st.d       [s5, #8], s6
    s.movz       s6, #512
    s.st.d       [s5, #16], s6
    s.movz       s6, #2048
    s.st.d       [s5, #48], s6
    s.movz       s6, #4
    s.st.d       [s5, #56], s6
    .li       s6, #68719476737
    s.st.d       [s5, #88], s6
    .li       s6, #2207613190144
    s.st.d       [s5, #104], s6
    fence.release.device
    td.load      d1, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s5, s3, #0
for_5:
    s.cmp.ge     s6, s5, s12
    br.nz        s6, endfor_6
    v.extract    s6, v2, #0
    v.splat      v1, s5
    v.splat      v4, s6
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s6, #512
    v.rcp.approx v7, v4                          // ISA 8.8: <= 2**-22 relative
    s.movz       s7, #8192
    s.muli       s8, s1, #2048
    v.add        v8, v1, v6
    v.movi       v1, #0
    v.splat      v6, s6
    v.splat      v9, s1
    v.movi       v10, #0
    s.muli       s6, s5, #4
    v.cmp.ge     p1, v8, v1
    v.splat      v1, s7
    v.cmp.lt     p2, v8, v6
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v1
    s.add        s7, s13, s8
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    .li       s8, #1065353216
    v.splat      v1, s8                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s8, s7, s6
    p.and        p2, p5, p1
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s8, #0]
    v.movi       v9, #1
    v.movi       v10, #0
    v.cmp.eq     p1, v3, v6
    s.mul        s6, s1, s12
    @p1 v.sel        v6, v9, v10
    v.splat      v9, s5
    vf.fms       v10, v4, v7, v1
    v.extract    s7, v6, #0
    v.movi       v1, #0
    v.splat      v4, s7
    v.add        v6, v9, v0
    vf.fms       v9, v7, v10, v7
    s.add        s7, s5, s6
    v.movi       v10, #512
    v.cmp.ne     p1, v4, v1
    s.shli       s8, s7, #2                      // element offset -> bytes (x4)
    vf.neg       v1, v9                          // Newton step: r0*(2 - x*r0)
    v.splat      v4, s6
    v.cmp.lt     p2, v6, v10
    s.add        s6, s13, s8                     // &in_out_ptr0[...]
    s.add        s7, s5, s2
    vf.cmp.o     p3, v1, v1
    @p3 v.sel        v9, v1, v7
    s.movz       s8, #1
    v.add        v1, v6, v4
    vf.mul       v1, v8, v9                      // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v4, v5, v1
    @p2 v.st.w       [s6, #0], v4
    s.mov        s5, s7
    br.nz        s8, for_5
endfor_6:
__rctx_next:
    s.addi       s5, s1, #2                      // the next program of this context: + 2
    s.cmp.lt     s6, s5, s4
    s.mov        s1, s5
    br.nz        s6, __rctx_program
    exit
