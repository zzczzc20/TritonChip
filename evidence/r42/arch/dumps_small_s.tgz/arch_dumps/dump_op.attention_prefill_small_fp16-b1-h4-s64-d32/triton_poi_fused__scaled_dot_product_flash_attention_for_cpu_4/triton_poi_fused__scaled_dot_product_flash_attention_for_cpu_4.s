    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (2 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
tiles_1:
    // tile 1 of the iteration: lanes t0 + 128
    s.addi       s9, s8, #128
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s10, s1, s8
    s.add        s11, s1, s9
    s.shli       s9, s10, #1
    s.shli       s12, s11, #1
    s.add        s13, s3, s9
    s.add        s9, s3, s12
    v.ld.h       v0, [s13, #0]
    s.shli       s12, s10, #2
    s.shli       s10, s11, #2
    s.add        s11, s7, s12
    s.add        s12, s7, s10
    v.ld.h       v1, [s13, #32]
    vf.cvt.f16.f32 v2, v0
    v.ld.h       v0, [s13, #64]
    vf.cvt.f16.f32 v3, v1
    v.ld.h       v1, [s13, #96]
    vf.cvt.f16.f32 v4, v0
    v.ld.h       v0, [s13, #128]
    vf.cvt.f16.f32 v5, v1
    v.ld.h       v1, [s13, #160]
    vf.cvt.f16.f32 v6, v0
    v.ld.h       v0, [s13, #192]
    vf.cvt.f16.f32 v7, v1
    v.ld.h       v1, [s13, #224]
    vf.cvt.f16.f32 v8, v0
    v.ld.h       v0, [s9, #0]
    vf.cvt.f16.f32 v9, v1
    v.ld.h       v1, [s9, #32]
    vf.cvt.f16.f32 v10, v0
    v.ld.h       v0, [s9, #64]
    vf.cvt.f16.f32 v11, v1
    v.ld.h       v1, [s9, #96]
    vf.cvt.f16.f32 v12, v0
    v.ld.h       v0, [s9, #128]
    vf.cvt.f16.f32 v13, v1
    v.ld.h       v1, [s9, #160]
    vf.cvt.f16.f32 v14, v0
    v.ld.h       v0, [s9, #192]
    vf.cvt.f16.f32 v15, v1
    v.ld.h       v1, [s9, #224]
    vf.cvt.f16.f32 v16, v0
    vf.cvt.f16.f32 v0, v1
    v.st.w       [s11, #0], v2
    v.st.w       [s11, #64], v3
    v.st.w       [s11, #128], v4
    v.st.w       [s11, #192], v5
    v.st.w       [s11, #256], v6
    v.st.w       [s11, #320], v7
    v.st.w       [s11, #384], v8
    v.st.w       [s11, #448], v9
    v.st.w       [s12, #0], v10
    v.st.w       [s12, #64], v11
    v.st.w       [s12, #128], v12
    v.st.w       [s12, #192], v13
    v.st.w       [s12, #256], v14
    v.st.w       [s12, #320], v15
    v.st.w       [s12, #384], v16
    v.st.w       [s12, #448], v0
    s.addi       s8, s8, #256
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
