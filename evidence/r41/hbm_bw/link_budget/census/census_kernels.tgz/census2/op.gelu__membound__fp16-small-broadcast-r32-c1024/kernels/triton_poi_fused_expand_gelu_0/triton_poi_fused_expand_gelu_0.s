    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.add        v2, v1, v0
    v.movi       v0, #1024
    v.movi       v1, #0
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p2, v0, v1
    v.sub        v3, v1, v2
    @p1 v.sel        v4, v3, v2
    v.sub        v2, v1, v0
    @p2 v.sel        v3, v2, v0
    v.movi       v0, #1023
    v.and        v2, v4, v0
    v.sub        v0, v1, v2
    @p1 v.sel        v1, v0, v2
    v.ld.gather.h v0, [s2, v1]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v1, v0
    .li       s2, #1056964608
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v2, v1, v0
    .li       s2, #1060439283
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v3, v1, v0
    vf.abs       v0, v3
    vf.mul       v1, v3, v3
    .li       s2, #3054550917
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #951369979
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v6, v4, v1, v5
    .li       s2, #3126118730
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v5, v6, v1, v4
    .li       s2, #1001013584
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v6, v5, v1, v4
    .li       s2, #3168535077
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v5, v6, v1, v4
    .li       s2, #1038554810
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v6, v5, v1, v4
    .li       s2, #3200291744
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v5, v6, v1, v4
    .li       s2, #1040414164
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v6, v5, v1, v4
    vf.fma       v1, v3, v6, v3                  // x + x*P(x*x)
    .li       s2, #1081802752
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.lt    p1, v0, v4
    @p1 v.sel        v5, v0, v4
    .li       s2, #1065353216
    v.splat      v6, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.sub       v7, v5, v6                      // t - 1, exact on [0.5, 4]
    .li       s2, #971895886
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3143235307
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v9, v5, v7, v8
    .li       s2, #1008707431
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v8, v9, v7, v5
    .li       s2, #3161341843
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v9, v8, v7, v5
    .li       s2, #1009556701
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v8, v9, v7, v5
    .li       s2, #998679498
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v9, v8, v7, v5
    .li       s2, #3173260768
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v8, v9, v7, v5
    .li       s2, #3210207623
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v9, v8, v7, v5
    .li       s2, #3223905464
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v8, v9, v7, v5
    .li       s2, #3219963872
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v9, v8, v7, v5
    .li       s2, #1069066811
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1262485504
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v8, v9, v5, v7
    .li       s2, #1262485504
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v10, v8, v5
    vf.sub       v5, v8, v7
    vf.neg       v7, v5
    .li       s2, #1060205056
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v11, v7, v8, v9                 // q - n*ln2_hi, exact
    vf.neg       v7, v5
    .li       s2, #901758606
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v8, v7, v5, v11
    .li       s2, #961512523
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #985056900
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v9, v5, v8, v7
    .li       s2, #1007192376
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v7, v9, v8, v5
    .li       s2, #1026206279
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v9, v7, v8, v5
    .li       s2, #1042983594
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v7, v9, v8, v5
    .li       s2, #1056964608
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v9, v7, v8, v5
    vf.mul       v5, v8, v8
    vf.fma       v7, v5, v9, v8
    vf.add       v5, v7, v6                      // e**f
    v.movi       v7, #127
    v.add        v8, v10, v7
    v.movi       v7, #23
    v.shl        v9, v8, v7
    vf.neg       v7, v5
    vf.fma       v5, v7, v9, v6                  // 1 - e**f * 2**n
    vf.cmp.lt    p1, v0, v4
    @p1 v.sel        v4, v5, v6
    .li       s2, #-2147483648
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v7, v3, v5
    v.or         v5, v4, v7
    vf.cmp.lt    p1, v0, v6
    @p1 v.sel        v0, v1, v5
    vf.cmp.uo    p1, v3, v3
    @p1 v.sel        v1, v3, v0
    .li       s2, #1065353216
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v3, v1, v0
    vf.mul       v0, v2, v3
    vf.cvt.f32.f16 v1, v0
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    s.add        s1, s3, s2                      // &out_ptr0[...]
    v.st.h       [s1, #0], v1
__rctx_next:
    exit
