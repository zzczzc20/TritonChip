    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr3: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // in_ptr4: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // in_ptr5: device_ptr64 at arg_base+48
    s.ld.d       s10, [s1, #56]                  // out_ptr1: device_ptr64 at arg_base+56
    s.rdspecial  s1, arg_base
    s.ld.d       s11, [s1, #80]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s12, #1280
    s.mul        s13, s1, s12
    s.add        s1, s11, s13                    // this context's own scratch
    s.addi       s11, s1, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s2
    s.movz       s12, #256
    s.st.d       [s11, #8], s12
    s.movz       s12, #1024
    s.st.d       [s11, #16], s12
    s.movz       s12, #2048
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d0, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #256                   // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s3
    s.movz       s12, #256
    s.st.d       [s11, #8], s12
    s.movz       s12, #1024
    s.st.d       [s11, #16], s12
    s.movz       s12, #2048
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d1, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #512                   // TensorMap 2: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s5
    s.movz       s12, #256
    s.st.d       [s11, #8], s12
    s.movz       s12, #1024
    s.st.d       [s11, #16], s12
    s.movz       s12, #2048
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d2, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #768                   // TensorMap 3: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s6
    s.movz       s12, #256
    s.st.d       [s11, #8], s12
    s.movz       s12, #1024
    s.st.d       [s11, #16], s12
    s.movz       s12, #2048
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d3, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #1024                  // TensorMap 4: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s11, #0], s7
    s.movz       s1, #256
    s.st.d       [s11, #8], s1
    s.movz       s1, #1024
    s.st.d       [s11, #16], s1
    s.movz       s1, #2048
    s.st.d       [s11, #48], s1
    s.movz       s1, #2
    s.st.d       [s11, #56], s1
    .li       s1, #68719476737
    s.st.d       [s11, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s11, #104], s1
    fence.release.device
    td.load      d4, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s11, #1024
    s.movz       s12, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s13, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s14, s13, s11
    br.nz        s14, endfor_2
    s.muli       s14, s4, #2048
    v.splat      v3, s13
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s15, #1024
    s.movz       s16, #256
    s.muli       s17, s4, #2048
    v.splat      v5, s13
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s18, #1024
    s.movz       s19, #256
    v.add        v7, v3, v4
    v.movi       v3, #0
    v.splat      v4, s15
    s.muli       s15, s13, #2
    v.splat      v8, s4
    v.movi       v9, #0
    v.splat      v10, s16
    s.muli       s16, s13, #2
    v.add        v11, v5, v6
    v.movi       v5, #0
    v.splat      v6, s18
    v.splat      v12, s4
    v.movi       v13, #0
    v.cmp.ge     p1, v7, v3
    v.splat      v3, s19
    v.cmp.lt     p2, v7, v4
    v.cmp.ge     p3, v8, v9
    v.cmp.lt     p4, v8, v10
    v.cmp.ge     p5, v11, v5
    s.add        s18, s2, s14
    p.and        p6, p1, p2
    v.cmp.lt     p1, v11, v6
    p.and        p2, p3, p4
    v.cmp.ge     p3, v12, v13
    s.add        s14, s3, s17
    p.and        p4, p5, p1
    v.cmp.lt     p1, v12, v3
    p.and        p5, p3, p1
    s.add        s17, s18, s15
    p.and        p1, p6, p2
    s.add        s15, s14, s16
    p.and        p2, p4, p5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s17, #0]
    v.splat      v4, s13
    v.movi       v5, #1024
    v.add        v6, v4, v0
    s.muli       s14, s4, #2048
    v.cmp.lt     p1, v6, v5
    v.splat      v4, s13
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s16, #1024
    s.movz       s17, #256
    s.muli       s18, s13, #2
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s16
    v.splat      v8, s4
    v.movi       v9, #0
    v.splat      v10, s17
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    v.cmp.ge     p5, v8, v9
    s.muli       s16, s4, #2048
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s15, #0]
    v.cmp.lt     p2, v8, v10
    s.add        s15, s5, s14
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    s.add        s14, s15, s18
    p.and        p2, p6, p3
    vf.cvt.bf16.f32 v5, v3
    v.splat      v3, s13
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s15, #1024
    s.movz       s17, #256
    s.muli       s18, s13, #2
    v.add        v8, v3, v7
    v.movi       v3, #0
    v.splat      v7, s15
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s17
    v.cmp.ge     p3, v8, v3
    v.cmp.lt     p4, v8, v7
    v.cmp.ge     p5, v9, v10
    s.muli       s15, s4, #2048
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v3, [s14, #0]
    v.cmp.lt     p2, v9, v11
    s.add        s14, s6, s16
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    vf.cvt.bf16.f32 v7, v4
    v.splat      v4, s13
    v.iota       v8                              // arange(0, VLEN)
    s.movz       s16, #1024
    s.movz       s17, #256
    s.muli       s19, s13, #2
    v.add        v9, v4, v8
    v.movi       v4, #0
    v.splat      v8, s16
    v.splat      v10, s4
    v.movi       v11, #0
    v.splat      v12, s17
    s.add        s16, s14, s18
    p.and        p2, p6, p3
    v.cmp.ge     p3, v9, v4
    v.cmp.lt     p4, v9, v8
    v.cmp.ge     p5, v10, v11
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s16, #0]
    v.cmp.lt     p2, v10, v12
    s.add        s14, s7, s15
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    vf.cvt.bf16.f32 v8, v3
    s.add        s15, s14, s19
    p.and        p2, p6, p3
    vf.add       v3, v5, v7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v5, [s15, #0]
    vf.cvt.bf16.f32 v7, v4
    s.mul        s14, s4, s11
    vf.add       v4, v3, v8
    v.movi       v3, #0
    s.add        s15, s13, s12
    vf.cvt.bf16.f32 v8, v5
    vf.add       v5, v4, v7
    s.add        s16, s13, s14
    v.splat      v4, s14
    s.shli       s14, s16, #1                    // element offset -> bytes (x2)
    vf.add       v7, v5, v8
    s.add        s16, s2, s14                    // &in_out_ptr0[...]
    s.movz       s14, #1
    v.add        v5, v6, v4
    vf.add       v4, v2, v7
    vf.cvt.f32.bf16 v5, v7
    @p1 v.sel        v6, v4, v2
    @p1 v.st.h       [s16, #0], v5
    v.mov        v3, v6
    v.mov        v2, v3
    s.mov        s13, s15
    br.nz        s14, for_1
endfor_2:
    .li       s3, #1149239296
    v.splat      v3, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1065353216
    v.splat      v4, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v3                          // ISA 8.8: <= 2**-22 relative
    vf.reduce.add.b v6, v2
    v.movi       v2, #0
    v.movi       v7, #0
    vf.add       v8, v6, v2
    s.addi       s3, s1, #0
    v.mov        v7, v1
    vf.fms       v1, v3, v5, v4
    vf.fms       v6, v5, v1, v5
    vf.neg       v1, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v6, v1, v5
    vf.mul       v1, v8, v6                      // a/y: faithful quotient
    vf.fms       v5, v1, v3, v8
    vf.fms       v8, v5, v6, v1
    vf.neg       v5, v8                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v6, v5, v1
for_3:
    s.cmp.ge     s5, s3, s11
    br.nz        s5, endfor_4
    s.muli       s5, s4, #2048
    v.splat      v1, s3
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s6, #1024
    s.movz       s7, #256
    s.muli       s13, s3, #2
    v.add        v8, v1, v5
    v.movi       v1, #0
    v.splat      v5, s6
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s7
    v.cmp.ge     p1, v8, v1
    v.cmp.lt     p2, v8, v5
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    s.add        s6, s2, s5
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s5, s6, s13
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s5, #0]
    v.extract    s5, v6, #0
    v.splat      v5, s5
    v.splat      v8, s3
    v.movi       v9, #1024
    v.add        v10, v8, v0
    vf.cvt.bf16.f32 v8, v1
    v.cmp.lt     p1, v10, v9
    v.movi       v1, #0
    s.add        s5, s3, s12
    vf.sub       v9, v8, v5
    s.movz       s6, #1
    vf.mul       v5, v9, v9
    vf.add       v8, v7, v5
    @p1 v.sel        v5, v8, v7
    v.mov        v1, v5
    v.mov        v7, v1
    s.mov        s3, s5
    br.nz        s6, for_3
endfor_4:
    vf.reduce.add.b v1, v7
    s.addi       s3, s1, #0
    vf.add       v5, v1, v2
for_5:
    s.cmp.ge     s1, s3, s11
    br.nz        s1, endfor_6
    v.rcp.approx v1, v3                          // ISA 8.8: <= 2**-22 relative
    s.muli       s1, s4, #2048
    v.splat      v2, s3
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s5, #1024
    s.movz       s6, #256
    s.muli       s7, s3, #2
    v.add        v8, v2, v7
    v.movi       v2, #0
    v.splat      v7, s5
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s6
    v.cmp.ge     p1, v8, v2
    v.cmp.lt     p2, v8, v7
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    s.add        s5, s2, s1
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s1, s5, s7
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s1, #0]
    v.splat      v7, s3
    s.shli       s1, s3, #1                      // element offset -> bytes (x2)
    v.add        v8, v7, v0
    vf.fms       v7, v3, v1, v4
    v.movi       v9, #1024
    .li       s5, #897988541
    v.splat      v10, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v11, v2
    vf.fms       v2, v1, v7, v1
    s.add        s5, s8, s1                      // &in_ptr4[...]
    v.cmp.lt     p1, v8, v9
    .li       s6, #1077936128
    v.splat      v7, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v9, v2                          // Newton step: r0*(2 - x*r0)
    .li       s6, #3204448256
    v.splat      v2, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s6, v6, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s5, #0]
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v1
    v.splat      v1, s6
    vf.mul       v9, v5, v13                     // a/y: faithful quotient
    s.add        s5, s9, s1                      // &in_ptr5[...]
    vf.sub       v14, v11, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s5, #0]
    vf.fms       v11, v9, v3, v5
    vf.cvt.bf16.f32 v15, v12
    s.mul        s1, s4, s11
    s.add        s5, s3, s12
    vf.fms       v12, v11, v13, v9
    vf.cvt.bf16.f32 v11, v1
    s.movz       s6, #1
    s.add        s7, s3, s1
    vf.neg       v1, v12                         // a/y: one correction to the IEEE quotient
    s.shli       s13, s7, #1                     // element offset -> bytes (x2)
    v.splat      v12, s1
    s.add        s1, s10, s13                    // &out_ptr1[...]
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v13, v1, v9
    v.add        v1, v8, v12
    vf.add       v1, v13, v10
    v.rsqrt.approx v8, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v9, v8, v8
    vf.mul       v10, v8, v2
    vf.fms       v2, v1, v9, v7
    vf.mul       v1, v10, v2                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v2, v1, v8
    v.extract    s7, v2, #0
    v.splat      v1, s7
    vf.mul       v2, v14, v1
    vf.mul       v1, v2, v15
    vf.add       v2, v1, v11
    vf.cvt.f32.bf16 v1, v2
    @p1 v.st.h       [s1, #0], v1
    s.mov        s3, s5
    br.nz        s6, for_5
endfor_6:
__rctx_next:
    exit
