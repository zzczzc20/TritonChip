    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #4
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.movi       v6, #0
    @p1 v.sel        v7, v4, v5
    v.cmp.lt     p1, v3, v1
    v.sub        v4, v0, v3
    v.sub        v5, v6, v7
    v.cmp.lt     p2, v3, v0
    v.cmp.lt     p3, v7, v6
    @p2 v.sel        v8, v4, v3
    v.movi       v4, #15
    @p3 v.sel        v9, v5, v7
    v.movi       v5, #63
    v.and        v10, v8, v4
    v.and        v4, v9, v5
    v.sub        v5, v0, v10
    v.sub        v8, v6, v4
    @p2 v.sel        v9, v5, v10
    v.movi       v5, #64
    @p3 v.sel        v10, v8, v4
    s.rdspecial  s1, arg_base
    v.sub        v4, v1, v3
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v8, v4, v3
    v.movi       v4, #2048
    v.movi       v11, #16
    v.cmp.lt     p2, v3, v4
    v.movi       v3, #1024
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v4, #10
    v.mul        v12, v10, v5
    v.lshr       v10, v8, v4
    v.movi       v4, #32
    v.cmp.lt     p3, v11, v0
    v.mul        v8, v7, v4
    v.sub        v7, v0, v11
    v.add        v0, v9, v8
    v.cmp.lt     p4, v11, v2
    v.sub        v8, v2, v11
    @p3 v.sel        v2, v7, v11
    v.sub        v2, v1, v10
    v.cmp.lt     p3, v5, v6
    @p1 v.sel        v7, v2, v10
    v.sub        v2, v6, v5
    v.mul        v6, v7, v4
    v.sub        v4, v1, v3
    v.add        v7, v9, v6
    v.cmp.lt     p1, v3, v1
    v.add        v1, v7, v12
    @p4 v.sel        v6, v8, v11
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v6, [s2, v1]               // index is in elements (ISA sec 9.1)
    @p3 v.sel        v1, v2, v5
    @p1 v.sel        v1, v4, v3
    @p2 v.st.scatter.h [s3, v0], v6
__rctx_next:
    exit
