    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #256
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.movz       s3, #16
    s.ld.d       s6, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.add        s7, s1, s5                      // this context's own scratch
    s.movz       s1, #128
    s.addi       s5, s7, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s7, #256
    s.movz       s8, #2
    .li       s9, #68719476737
    .li       s10, #1108101562368
    v.movi       v0, #0
    v.movi       v1, #0
    s.ld.d       s11, [s2, #8]                   // out_ptr0: device_ptr64 at arg_base+8
    s.movz       s2, #0
    v.splat      v2, s4
    s.st.d       [s5, #0], s6
    v.iota       v2                              // arange(0, VLEN)
    s.st.d       [s5, #8], s3
    s.movz       s2, #0
    s.st.d       [s5, #16], s1
    s.movz       s1, #128
    s.addi       s3, s2, #0
    s.st.d       [s5, #48], s7
    s.movz       s2, #16
    s.st.d       [s5, #56], s8
    s.st.d       [s5, #88], s9
    s.st.d       [s5, #104], s10
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.mov        v1, v0
for_1:
    s.cmp.ge     s5, s3, s1
    br.nz        s5, endfor_2
    s.movz       s5, #0
    s.movz       s7, #0
    s.cmp.lt     s8, s4, s5
    s.movz       s5, #2
    s.sub        s9, s7, s8
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s10, s5, s7
    s.xor        s7, s4, s9
    s.sub        s12, s8, s10
    s.sub        s8, s7, s9
    s.xor        s7, s9, s12
    s.lshri      s9, s8, #1
    v.splat      v0, s3
    s.xor        s10, s9, s7
    v.iota       v3                              // arange(0, VLEN)
    s.sub        s13, s10, s7
    s.movz       s7, #128
    s.muli       s10, s13, #256
    s.movz       s14, #16
    s.muli       s15, s3, #2
    v.add        v4, v0, v3
    v.movi       v0, #0
    v.splat      v3, s7
    v.splat      v5, s13
    v.movi       v6, #0
    v.cmp.ge     p1, v4, v0
    v.splat      v0, s14
    v.cmp.lt     p2, v4, v3
    v.cmp.ge     p3, v5, v6
    v.cmp.lt     p4, v5, v0
    s.add        s7, s6, s10
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s10, s7, s15
    p.and        p2, p5, p1
    v.splat      v0, s3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v3, [s10, #0]
    v.add        v4, v0, v2
    v.movi       v0, #128
    s.muli       s7, s9, #2
    v.cmp.lt     p1, v4, v0
    v.movi       v0, #0
    vf.cvt.bf16.f32 v4, v3
    s.xor        s9, s5, s12
    s.add        s5, s3, s2
    s.movz       s10, #1
    vf.mul       v3, v4, v4
    s.sub        s13, s9, s12
    s.sub        s9, s8, s7
    vf.add       v4, v1, v3
    @p1 v.sel        v3, v4, v1
    v.mov        v0, v3
    v.mov        v1, v0
    s.mov        s3, s5
    br.nz        s10, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.movz       s1, #1
    vf.add       v2, v0, v1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s11, s2                     // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
