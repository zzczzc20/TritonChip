    s.rdspecial  s1, role_id
    s.rdspecial  s2, npid.x
__rctx_program:
    s.rdspecial  s3, arg_base
    s.ld.d       s4, [s3, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s5, [s3, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s6, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s7, [s3, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s8, [s3, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s9, [s3, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s10, [s3, #48]                  // out_ptr0: device_ptr64 at arg_base+48
    s.ld.d       s11, [s3, #56]                  // out_ptr1: device_ptr64 at arg_base+56
    s.rdspecial  s3, pid.y
    s.shli       s12, s3, #4                     // x16 as a shift
    s.shli       s3, s1, #4                      // x16 as a shift
    s.rdspecial  s13, arg_base
    s.ld.d       s14, [s13, #80]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s13, role_id
    s.movz       s15, #15360
    s.mul        s16, s13, s15
    s.add        s13, s14, s16                   // this context's own scratch
    s.addi       s14, s13, #0
    s.movz       s15, #0
    s.add        s16, s15, s12                   // the tile origin
    v.splat      v0, s16
    s.movz       s15, #512
    v.splat      v1, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s14, #0], v2
    s.addi       s15, s14, #64
    s.addi       s17, s16, #1
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #128
    s.addi       s17, s16, #2
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #192
    s.addi       s17, s16, #3
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #256
    s.addi       s17, s16, #4
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #320
    s.addi       s17, s16, #5
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #384
    s.addi       s17, s16, #6
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #448
    s.addi       s17, s16, #7
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #512
    s.addi       s17, s16, #8
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #576
    s.addi       s17, s16, #9
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #640
    s.addi       s17, s16, #10
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #704
    s.addi       s17, s16, #11
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #768
    s.addi       s17, s16, #12
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #832
    s.addi       s17, s16, #13
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #896
    s.addi       s17, s16, #14
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #960
    s.addi       s14, s16, #15
    v.splat      v0, s14
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #511
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    fence.acq_rel.device
    s.addi       s14, s13, #1024
    v.splat      v0, s16
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s14, #0], v2
    s.addi       s15, s14, #64
    s.addi       s17, s16, #1
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #128
    s.addi       s17, s16, #2
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #192
    s.addi       s17, s16, #3
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #256
    s.addi       s17, s16, #4
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #320
    s.addi       s17, s16, #5
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #384
    s.addi       s17, s16, #6
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #448
    s.addi       s17, s16, #7
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #512
    s.addi       s17, s16, #8
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #576
    s.addi       s17, s16, #9
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #640
    s.addi       s17, s16, #10
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #704
    s.addi       s17, s16, #11
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #768
    s.addi       s17, s16, #12
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #832
    s.addi       s17, s16, #13
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #896
    s.addi       s17, s16, #14
    v.splat      v0, s17
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #960
    s.addi       s14, s16, #15
    v.splat      v0, s14
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #9
    v.lshr       v1, v4, v0
    v.sub        v0, v2, v1
    @p1 v.sel        v2, v0, v1
    v.st.w       [s15, #0], v2
    fence.acq_rel.device
    s.addi       s14, s13, #2048
    s.movz       s15, #0
    v.splat      v0, s15
    s.movz       s16, #0
    s.add        s17, s16, s3                    // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s17
    v.add        v3, v1, v2
    s.addi       s16, s13, #1024
    v.ld.w       v1, [s16, #0]
    s.movz       s16, #64
    v.splat      v2, s16
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s16, s13, #0
    v.ld.w       v4, [s16, #0]
    s.movz       s16, #1024
    v.splat      v5, s16
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s14, #0], v1
    s.addi       s16, s14, #64
    s.addi       s17, s13, #1088
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #64
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #128
    s.addi       s17, s13, #1152
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #128
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #192
    s.addi       s17, s13, #1216
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #192
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #256
    s.addi       s17, s13, #1280
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #256
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #320
    s.addi       s17, s13, #1344
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #320
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #384
    s.addi       s17, s13, #1408
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #384
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #448
    s.addi       s17, s13, #1472
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #448
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #512
    s.addi       s17, s13, #1536
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #512
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #576
    s.addi       s17, s13, #1600
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #576
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #640
    s.addi       s17, s13, #1664
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #640
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #704
    s.addi       s17, s13, #1728
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #704
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #768
    s.addi       s17, s13, #1792
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #768
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #832
    s.addi       s17, s13, #1856
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #832
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #896
    s.addi       s17, s13, #1920
    v.ld.w       v1, [s17, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s17, s13, #896
    v.ld.w       v4, [s17, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #960
    s.addi       s14, s13, #1984
    v.ld.w       v1, [s14, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s14, s13, #960
    v.ld.w       v4, [s14, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s16, #0], v1
    fence.acq_rel.device
    s.addi       s14, s13, #3072
    s.addi       s16, s13, #2048
    v.ld.w       v0, [s16, #0]
    v.cmpi.lt    p1, v3, #64
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s16, s14, #64
    s.addi       s17, s13, #2112
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #128
    s.addi       s17, s13, #2176
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #192
    s.addi       s17, s13, #2240
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #256
    s.addi       s17, s13, #2304
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #320
    s.addi       s17, s13, #2368
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #384
    s.addi       s17, s13, #2432
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #448
    s.addi       s17, s13, #2496
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #512
    s.addi       s17, s13, #2560
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #576
    s.addi       s17, s13, #2624
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #640
    s.addi       s17, s13, #2688
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #704
    s.addi       s17, s13, #2752
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #768
    s.addi       s17, s13, #2816
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #832
    s.addi       s17, s13, #2880
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #896
    s.addi       s17, s13, #2944
    v.ld.w       v0, [s17, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    s.addi       s16, s14, #960
    s.addi       s14, s13, #3008
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v1
    fence.acq_rel.device
    s.addi       s4, s13, #4096
    s.addi       s14, s13, #0
    v.ld.w       v0, [s14, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s4, #0], v0
    s.addi       s14, s4, #64
    s.addi       s16, s13, #64
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #128
    s.addi       s16, s13, #128
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #192
    s.addi       s16, s13, #192
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #256
    s.addi       s16, s13, #256
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #320
    s.addi       s16, s13, #320
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #384
    s.addi       s16, s13, #384
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #448
    s.addi       s16, s13, #448
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #512
    s.addi       s16, s13, #512
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #576
    s.addi       s16, s13, #576
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #640
    s.addi       s16, s13, #640
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #704
    s.addi       s16, s13, #704
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #768
    s.addi       s16, s13, #768
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #832
    s.addi       s16, s13, #832
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #896
    s.addi       s16, s13, #896
    v.ld.w       v0, [s16, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    s.addi       s14, s4, #960
    s.addi       s4, s13, #960
    v.ld.w       v0, [s4, #0]
    v.mul        v1, v0, v2
    v.add        v0, v3, v1
    v.st.w       [s14, #0], v0
    fence.acq_rel.device
    s.addi       s4, s13, #5120
    v.splat      v0, s15
    s.addi       s14, s13, #4096
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s4, #0], v4
    s.addi       s14, s4, #64
    s.addi       s16, s13, #4160
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #128
    s.addi       s16, s13, #4224
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #192
    s.addi       s16, s13, #4288
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #256
    s.addi       s16, s13, #4352
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #320
    s.addi       s16, s13, #4416
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #384
    s.addi       s16, s13, #4480
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #448
    s.addi       s16, s13, #4544
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #512
    s.addi       s16, s13, #4608
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #576
    s.addi       s16, s13, #4672
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #640
    s.addi       s16, s13, #4736
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #704
    s.addi       s16, s13, #4800
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #768
    s.addi       s16, s13, #4864
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #832
    s.addi       s16, s13, #4928
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #896
    s.addi       s16, s13, #4992
    v.ld.w       v1, [s16, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    s.addi       s14, s4, #960
    s.addi       s4, s13, #5056
    v.ld.w       v1, [s4, #0]
    v.add        v4, v0, v1
    v.st.w       [s14, #0], v4
    fence.acq_rel.device
    s.addi       s4, s13, #6144
    s.addi       s14, s13, #5120
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v1
    s.addi       s14, s4, #64
    s.addi       s16, s13, #5184
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #128
    s.addi       s16, s13, #5248
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #192
    s.addi       s16, s13, #5312
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #256
    s.addi       s16, s13, #5376
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #320
    s.addi       s16, s13, #5440
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #384
    s.addi       s16, s13, #5504
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #448
    s.addi       s16, s13, #5568
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #512
    s.addi       s16, s13, #5632
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #576
    s.addi       s16, s13, #5696
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #640
    s.addi       s16, s13, #5760
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #704
    s.addi       s16, s13, #5824
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #768
    s.addi       s16, s13, #5888
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #832
    s.addi       s16, s13, #5952
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #896
    s.addi       s16, s13, #6016
    v.ld.w       v0, [s16, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    s.addi       s14, s4, #960
    s.addi       s4, s13, #6080
    v.ld.w       v0, [s4, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v1
    fence.acq_rel.device
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    s.addi       s5, s13, #6144
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #1
    s.addi       s5, s13, #6208
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #2
    s.addi       s5, s13, #6272
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #3
    s.addi       s5, s13, #6336
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #4
    s.addi       s5, s13, #6400
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #5
    s.addi       s5, s13, #6464
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #6
    s.addi       s5, s13, #6528
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #7
    s.addi       s5, s13, #6592
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #8
    s.addi       s5, s13, #6656
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #9
    s.addi       s5, s13, #6720
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #10
    s.addi       s5, s13, #6784
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #11
    s.addi       s5, s13, #6848
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #12
    s.addi       s5, s13, #6912
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #13
    s.addi       s5, s13, #6976
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #14
    s.addi       s5, s13, #7040
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.movz       s4, #15
    s.addi       s5, s13, #7104
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a0, s4, v1
    s.muli       s4, s3, #2                      // a runtime tile origin, x2
    s.add        s5, s6, s4                      // the tile origin
    s.muli       s4, s12, #128                   // a runtime tile origin, x128
    s.add        s6, s5, s4                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s4, s13, #7168
    v.splat      v0, s15
    s.addi       s5, s13, #4096
    v.ld.w       v1, [s5, #0]
    v.add        v4, v0, v1
    v.st.w       [s4, #0], v4
    s.addi       s5, s4, #64
    s.addi       s14, s13, #4160
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #128
    s.addi       s14, s13, #4224
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #192
    s.addi       s14, s13, #4288
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #256
    s.addi       s14, s13, #4352
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #320
    s.addi       s14, s13, #4416
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #384
    s.addi       s14, s13, #4480
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #448
    s.addi       s14, s13, #4544
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #512
    s.addi       s14, s13, #4608
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #576
    s.addi       s14, s13, #4672
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #640
    s.addi       s14, s13, #4736
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #704
    s.addi       s14, s13, #4800
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #768
    s.addi       s14, s13, #4864
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #832
    s.addi       s14, s13, #4928
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #896
    s.addi       s14, s13, #4992
    v.ld.w       v1, [s14, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #960
    s.addi       s4, s13, #5056
    v.ld.w       v1, [s4, #0]
    v.add        v4, v0, v1
    v.st.w       [s5, #0], v4
    fence.acq_rel.device
    s.addi       s4, s13, #8192
    s.addi       s5, s13, #7168
    v.ld.w       v0, [s5, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v1
    s.addi       s5, s4, #64
    s.addi       s14, s13, #7232
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #128
    s.addi       s14, s13, #7296
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #192
    s.addi       s14, s13, #7360
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #256
    s.addi       s14, s13, #7424
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #320
    s.addi       s14, s13, #7488
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #384
    s.addi       s14, s13, #7552
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #448
    s.addi       s14, s13, #7616
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #512
    s.addi       s14, s13, #7680
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #576
    s.addi       s14, s13, #7744
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #640
    s.addi       s14, s13, #7808
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #704
    s.addi       s14, s13, #7872
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #768
    s.addi       s14, s13, #7936
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #832
    s.addi       s14, s13, #8000
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #896
    s.addi       s14, s13, #8064
    v.ld.w       v0, [s14, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #960
    s.addi       s4, s13, #8128
    v.ld.w       v0, [s4, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    fence.acq_rel.device
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    s.addi       s5, s13, #8192
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #1
    s.addi       s5, s13, #8256
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #2
    s.addi       s5, s13, #8320
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #3
    s.addi       s5, s13, #8384
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #4
    s.addi       s5, s13, #8448
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #5
    s.addi       s5, s13, #8512
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #6
    s.addi       s5, s13, #8576
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #7
    s.addi       s5, s13, #8640
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #8
    s.addi       s5, s13, #8704
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #9
    s.addi       s5, s13, #8768
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #10
    s.addi       s5, s13, #8832
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #11
    s.addi       s5, s13, #8896
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #12
    s.addi       s5, s13, #8960
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #13
    s.addi       s5, s13, #9024
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #14
    s.addi       s5, s13, #9088
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.movz       s4, #15
    s.addi       s5, s13, #9152
    v.ld.w       v0, [s5, #0]
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s4, v1
    s.addi       s4, s13, #9216
    s.addi       s5, s13, #1024
    v.ld.w       v0, [s5, #0]
    s.movz       s5, #4
    v.splat      v1, s5
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s4, #0], v4
    s.addi       s5, s4, #64
    s.addi       s7, s13, #1088
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #128
    s.addi       s7, s13, #1152
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #192
    s.addi       s7, s13, #1216
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #256
    s.addi       s7, s13, #1280
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #320
    s.addi       s7, s13, #1344
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #384
    s.addi       s7, s13, #1408
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #448
    s.addi       s7, s13, #1472
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #512
    s.addi       s7, s13, #1536
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #576
    s.addi       s7, s13, #1600
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #640
    s.addi       s7, s13, #1664
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #704
    s.addi       s7, s13, #1728
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #768
    s.addi       s7, s13, #1792
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #832
    s.addi       s7, s13, #1856
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #896
    s.addi       s7, s13, #1920
    v.ld.w       v0, [s7, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v5, v6, v0
    v.sub        v0, v4, v5
    @p2 v.sel        v4, v0, v5
    v.st.w       [s5, #0], v4
    s.addi       s5, s4, #960
    s.addi       s4, s13, #1984
    v.ld.w       v0, [s4, #0]
    v.movi       v4, #0
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    v.sub        v5, v4, v0
    @p2 v.sel        v6, v5, v0
    v.sub        v0, v4, v1
    @p3 v.sel        v5, v0, v1
    v.movi       v0, #2
    v.lshr       v1, v6, v0
    v.sub        v0, v4, v1
    @p2 v.sel        v4, v0, v1
    v.st.w       [s5, #0], v4
    fence.acq_rel.device
    s.addi       s4, s13, #10240
    v.splat      v0, s15
    s.addi       s5, s13, #9216
    v.ld.w       v1, [s5, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s5, s13, #0
    v.ld.w       v4, [s5, #0]
    s.movz       s5, #256
    v.splat      v5, s5
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s4, #0], v1
    s.addi       s5, s4, #64
    s.addi       s7, s13, #9280
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #64
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #128
    s.addi       s7, s13, #9344
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #128
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #192
    s.addi       s7, s13, #9408
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #192
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #256
    s.addi       s7, s13, #9472
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #256
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #320
    s.addi       s7, s13, #9536
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #320
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #384
    s.addi       s7, s13, #9600
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #384
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #448
    s.addi       s7, s13, #9664
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #448
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #512
    s.addi       s7, s13, #9728
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #512
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #576
    s.addi       s7, s13, #9792
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #576
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #640
    s.addi       s7, s13, #9856
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #640
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #704
    s.addi       s7, s13, #9920
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #704
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #768
    s.addi       s7, s13, #9984
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #768
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #832
    s.addi       s7, s13, #10048
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #832
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #896
    s.addi       s7, s13, #10112
    v.ld.w       v1, [s7, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s7, s13, #896
    v.ld.w       v4, [s7, #0]
    v.mul        v6, v4, v5
    v.add        v4, v1, v6
    v.add        v1, v0, v4
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #960
    s.addi       s4, s13, #10176
    v.ld.w       v1, [s4, #0]
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    s.addi       s4, s13, #960
    v.ld.w       v2, [s4, #0]
    v.mul        v3, v2, v5
    v.add        v2, v1, v3
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    fence.acq_rel.device
    s.addi       s4, s13, #11264
    s.addi       s5, s13, #10240
    v.ld.w       v0, [s5, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v1
    s.addi       s5, s4, #64
    s.addi       s7, s13, #10304
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #128
    s.addi       s7, s13, #10368
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #192
    s.addi       s7, s13, #10432
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #256
    s.addi       s7, s13, #10496
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #320
    s.addi       s7, s13, #10560
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #384
    s.addi       s7, s13, #10624
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #448
    s.addi       s7, s13, #10688
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #512
    s.addi       s7, s13, #10752
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #576
    s.addi       s7, s13, #10816
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #640
    s.addi       s7, s13, #10880
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #704
    s.addi       s7, s13, #10944
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #768
    s.addi       s7, s13, #11008
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #832
    s.addi       s7, s13, #11072
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #896
    s.addi       s7, s13, #11136
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #960
    s.addi       s4, s13, #11200
    v.ld.w       v0, [s4, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    fence.acq_rel.device
    s.addi       s4, s13, #12288
    v.splat      v0, s15
    s.addi       s5, s13, #4096
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s13, #9216
    v.ld.w       v2, [s5, #0]
    s.movz       s5, #32768
    v.splat      v3, s5
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s4, #0], v1
    s.addi       s5, s4, #64
    s.addi       s7, s13, #4160
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #9280
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #128
    s.addi       s7, s13, #4224
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #9344
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #192
    s.addi       s7, s13, #4288
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #9408
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #256
    s.addi       s7, s13, #4352
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #9472
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #320
    s.addi       s7, s13, #4416
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #9536
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #384
    s.addi       s7, s13, #4480
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #9600
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #448
    s.addi       s7, s13, #4544
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #9664
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #512
    s.addi       s7, s13, #4608
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #9728
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #576
    s.addi       s7, s13, #4672
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #9792
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #640
    s.addi       s7, s13, #4736
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #9856
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #704
    s.addi       s7, s13, #4800
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #9920
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #768
    s.addi       s7, s13, #4864
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #9984
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #832
    s.addi       s7, s13, #4928
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #10048
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #896
    s.addi       s7, s13, #4992
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s13, #10112
    v.ld.w       v2, [s7, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #960
    s.addi       s4, s13, #5056
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s13, #10176
    v.ld.w       v2, [s4, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s5, #0], v1
    fence.acq_rel.device
    s.addi       s4, s13, #13312
    s.addi       s5, s13, #12288
    v.ld.w       v0, [s5, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v1
    s.addi       s5, s4, #64
    s.addi       s7, s13, #12352
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #128
    s.addi       s7, s13, #12416
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #192
    s.addi       s7, s13, #12480
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #256
    s.addi       s7, s13, #12544
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #320
    s.addi       s7, s13, #12608
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #384
    s.addi       s7, s13, #12672
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #448
    s.addi       s7, s13, #12736
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #512
    s.addi       s7, s13, #12800
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #576
    s.addi       s7, s13, #12864
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #640
    s.addi       s7, s13, #12928
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #704
    s.addi       s7, s13, #12992
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #768
    s.addi       s7, s13, #13056
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #832
    s.addi       s7, s13, #13120
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #896
    s.addi       s7, s13, #13184
    v.ld.w       v0, [s7, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s5, s4, #960
    s.addi       s4, s13, #13248
    v.ld.w       v0, [s4, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    fence.acq_rel.device
    .li       s4, #1052050675
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #1052050675
    v.splat      v1, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    s.addi       s5, s13, #11264
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #0
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #13312
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #0
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #1
    s.addi       s5, s13, #11328
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #1
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #13376
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #1
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #2
    s.addi       s5, s13, #11392
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #2
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #13440
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #2
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #3
    s.addi       s5, s13, #11456
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #3
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #13504
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #3
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #4
    s.addi       s5, s13, #11520
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #4
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #13568
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #4
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #5
    s.addi       s5, s13, #11584
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #5
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #13632
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #5
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #6
    s.addi       s5, s13, #11648
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #6
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #13696
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #6
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #7
    s.addi       s5, s13, #11712
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #7
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #13760
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #7
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #8
    s.addi       s5, s13, #11776
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #8
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #13824
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #8
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #9
    s.addi       s5, s13, #11840
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #9
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #13888
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #9
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #10
    s.addi       s5, s13, #11904
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #10
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #13952
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #10
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #11
    s.addi       s5, s13, #11968
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #11
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #14016
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #11
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #12
    s.addi       s5, s13, #12032
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #12
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #14080
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #12
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #13
    s.addi       s5, s13, #12096
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #13
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #14144
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #13
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #14
    s.addi       s5, s13, #12160
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #14
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #14208
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #14
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.movz       s4, #15
    s.addi       s5, s13, #12224
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #15
    a.vread      v2, a0, s5
    vf.mul       v5, v4, v2
    s.addi       s5, s13, #14272
    v.ld.w       v2, [s5, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s5, #15
    a.vread      v2, a1, s5
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s4, v4
    s.muli       s4, s3, #4                      // a runtime tile origin, x4
    s.add        s5, s10, s4                     // the tile origin
    s.muli       s4, s12, #256                   // a runtime tile origin, x256
    s.add        s7, s5, s4                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s4, s13, #3072
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #0
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    @p1 v.ld.h       v1, [s6, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #0
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    @p1 v.st.w       [s7, #0], v2
    s.addi       s4, s13, #3136
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #1
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #128                    // row 1
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #1
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #256                    // row 1
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3200
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #2
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #256                    // row 2
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #2
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #512                    // row 2
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3264
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #3
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #384                    // row 3
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #3
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #768                    // row 3
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3328
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #4
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #512                    // row 4
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #4
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #1024                   // row 4
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3392
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #5
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #640                    // row 5
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #5
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #1280                   // row 5
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3456
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #6
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #768                    // row 6
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #6
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #1536                   // row 6
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3520
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #7
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #896                    // row 7
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #7
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #1792                   // row 7
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3584
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #8
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #1024                   // row 8
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #8
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #2048                   // row 8
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3648
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #9
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #1152                   // row 9
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #9
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #2304                   // row 9
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3712
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #10
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #1280                   // row 10
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #10
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #2560                   // row 10
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3776
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #11
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #1408                   // row 11
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #11
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #2816                   // row 11
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3840
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #12
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #1536                   // row 12
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #12
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #3072                   // row 12
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3904
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #13
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #1664                   // row 13
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #13
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #3328                   // row 13
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #3968
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #14
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #1792                   // row 14
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #14
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #3584                   // row 14
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #4032
    v.ld.w       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #15
    a.vread      v1, a0, s4
    vf.mul       v4, v2, v1
    s.addi       s4, s6, #1920                   // row 15
    @p1 v.ld.h       v1, [s4, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s4, #15
    a.vread      v1, a1, s4
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s4, s7, #3840                   // row 15
    @p1 v.st.w       [s4, #0], v2
    s.addi       s4, s13, #14336
    v.splat      v0, s15
    s.addi       s5, s13, #0
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #0
    s.muli       s6, s3, #512                    // a runtime tile origin, x512
    s.add        s3, s5, s6                      // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s5, #512
    v.splat      v4, s5
    v.mul        v5, v2, v4
    v.splat      v2, s3
    v.add        v4, v5, v2
    v.add        v2, v1, v4
    s.addi       s3, s13, #1024
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s4, #0], v2
    s.addi       s3, s4, #64
    s.addi       s5, s13, #64
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1088
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #128
    s.addi       s5, s13, #128
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1152
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #192
    s.addi       s5, s13, #192
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1216
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #256
    s.addi       s5, s13, #256
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1280
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #320
    s.addi       s5, s13, #320
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1344
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #384
    s.addi       s5, s13, #384
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1408
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #448
    s.addi       s5, s13, #448
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1472
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #512
    s.addi       s5, s13, #512
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1536
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #576
    s.addi       s5, s13, #576
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1600
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #640
    s.addi       s5, s13, #640
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1664
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #704
    s.addi       s5, s13, #704
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1728
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #768
    s.addi       s5, s13, #768
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1792
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #832
    s.addi       s5, s13, #832
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1856
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #896
    s.addi       s5, s13, #896
    v.ld.w       v1, [s5, #0]
    v.add        v2, v1, v4
    s.addi       s5, s13, #1920
    v.ld.w       v1, [s5, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    s.addi       s3, s4, #960
    s.addi       s4, s13, #960
    v.ld.w       v1, [s4, #0]
    v.add        v2, v1, v4
    s.addi       s4, s13, #1984
    v.ld.w       v1, [s4, #0]
    v.mul        v4, v1, v3
    v.add        v1, v2, v4
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    fence.acq_rel.device
    s.movz       s3, #0
    a.vread      v0, a2, s3
    s.addi       s3, s13, #14336
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #1
    a.vread      v0, a2, s3
    s.addi       s3, s13, #14400
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #2
    a.vread      v0, a2, s3
    s.addi       s3, s13, #14464
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #3
    a.vread      v0, a2, s3
    s.addi       s3, s13, #14528
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #4
    a.vread      v0, a2, s3
    s.addi       s3, s13, #14592
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #5
    a.vread      v0, a2, s3
    s.addi       s3, s13, #14656
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #6
    a.vread      v0, a2, s3
    s.addi       s3, s13, #14720
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #7
    a.vread      v0, a2, s3
    s.addi       s3, s13, #14784
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #8
    a.vread      v0, a2, s3
    s.addi       s3, s13, #14848
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #9
    a.vread      v0, a2, s3
    s.addi       s3, s13, #14912
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #10
    a.vread      v0, a2, s3
    s.addi       s3, s13, #14976
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #11
    a.vread      v0, a2, s3
    s.addi       s3, s13, #15040
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #12
    a.vread      v0, a2, s3
    s.addi       s3, s13, #15104
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #13
    a.vread      v0, a2, s3
    s.addi       s3, s13, #15168
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #14
    a.vread      v0, a2, s3
    s.addi       s3, s13, #15232
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
    s.movz       s3, #15
    a.vread      v0, a2, s3
    s.addi       s3, s13, #15296
    v.ld.w       v1, [s3, #0]
    @p1 v.st.scatter.w [s11, v1], v0
__rctx_next:
    s.addi       s3, s1, #2                      // the next program of this context: + 2
    s.cmp.lt     s4, s3, s2
    s.mov        s1, s3
    br.nz        s4, __rctx_program
    exit
