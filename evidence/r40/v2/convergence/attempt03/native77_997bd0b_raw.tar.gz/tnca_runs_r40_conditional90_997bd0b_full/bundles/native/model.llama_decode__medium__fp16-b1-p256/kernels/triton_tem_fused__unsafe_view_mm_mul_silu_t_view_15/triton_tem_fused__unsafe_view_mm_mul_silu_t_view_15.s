    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #1024
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #0                      // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s7, #0], s3
    .li       s1, #2147483647
    s.st.d       [s7, #8], s1
    .li       s1, #2147483647
    s.st.d       [s7, #16], s1
    s.movz       s1, #384
    s.st.d       [s7, #48], s1
    s.movz       s1, #2
    s.st.d       [s7, #56], s1
    .li       s1, #68719476752
    s.st.d       [s7, #88], s1
    .li       s1, #8589934592
    s.st.d       [s7, #104], s1
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #32
    s.movz       s3, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s1, s9
    s.sub        s9, s8, s10
    s.xor        s8, s1, s9
    s.sub        s10, s8, s9
    s.movz       s8, #1
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #1
    s.cmp.lt     s17, s4, s7
    s.sub        s7, s3, s17
    s.xor        s3, s4, s7
    s.sub        s17, s3, s7
    s.lshri      s3, s17, #5
    s.muli       s18, s3, #32
    s.sub        s19, s17, s18
    s.xor        s17, s7, s9
    s.xor        s7, s3, s17
    s.sub        s3, s7, s17
    s.sub        s7, s8, s3
    s.min.s      s9, s7, s8
    s.cmp.lt     s7, s4, s11
    s.sub        s11, s10, s7
    s.cmp.lt     s7, s9, s13
    s.sub        s10, s12, s7
    s.xor        s7, s4, s11
    s.sub        s12, s7, s11
    s.xor        s7, s9, s10
    s.sub        s13, s7, s10
    s.addi       s7, s14, #0
    s.addi       s10, s15, #0
    s.cmp.eq     s14, s13, s16
    s.mov        s7, s12
    br.nz        s14, sdiv_done_1
    s.movz       s14, #0
    s.movz       s15, #31
    s.mov        s7, s14
    s.addi       s14, s15, #0
sdiv_2:
    s.lshr       s15, s12, s14
    s.shli       s16, s10, #1
    s.andi       s17, s15, #1
    s.movz       s15, #0
    s.or         s18, s16, s17
    s.movz       s16, #1
    s.cmp.geu    s17, s18, s13
    s.shl        s19, s16, s14
    s.sub        s16, s15, s17
    s.subi       s15, s14, #1
    s.and        s17, s13, s16
    s.and        s20, s19, s16
    s.sub        s16, s18, s17
    s.or         s17, s7, s20
    s.mov        s10, s16
    s.mov        s7, s17
    s.mov        s14, s15
    s.movz       s15, #0
    s.cmp.ge     s16, s14, s15
    br.nz        s16, sdiv_2
sdiv_done_1:
    s.movz       s7, #0
    s.movz       s12, #0
    s.cmp.lt     s13, s4, s7
    s.movz       s7, #0
    s.sub        s14, s12, s13
    s.movz       s12, #0
    s.xor        s13, s4, s14
    s.movz       s4, #0
    s.sub        s15, s13, s14
    s.cmp.lt     s13, s9, s7
    s.lshri      s7, s15, #5
    s.movz       s16, #0
    s.muli       s17, s7, #32
    s.sub        s7, s4, s13
    s.movz       s4, #0
    s.cmp.lt     s13, s1, s16
    s.xor        s16, s9, s7
    s.sub        s9, s15, s17
    s.movz       s15, #0
    s.xor        s17, s9, s14
    s.xor        s9, s10, s11
    s.sub        s10, s17, s14
    s.sub        s14, s15, s13
    s.cmp.lt     s13, s10, s12
    s.sub        s12, s16, s7
    s.sub        s15, s4, s13
    s.movz       s4, #0
    s.xor        s13, s10, s15
    s.movz       s10, #1
    s.sub        s16, s9, s11
    s.xor        s9, s1, s14
    s.sub        s1, s13, s15
    s.movz       s11, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s12, s10
    s.add        s10, s3, s16
    s.sub        s3, s9, s14
    s.addi       s3, s11, #0
    s.mov        s13, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s9, #31
    s.mov        s13, s4
    s.addi       s4, s9, #0
sdiv_4:
    s.lshr       s9, s1, s4
    s.shli       s11, s3, #1
    s.andi       s14, s9, #1
    s.movz       s9, #0
    s.or         s16, s11, s14
    s.movz       s11, #1
    s.cmp.geu    s14, s16, s12
    s.shl        s17, s11, s4
    s.sub        s11, s9, s14
    s.subi       s9, s4, #1
    s.and        s14, s12, s11
    s.and        s18, s17, s11
    s.sub        s11, s16, s14
    s.or         s14, s13, s18
    s.mov        s3, s11
    s.mov        s13, s14
    s.mov        s4, s9
    s.movz       s9, #0
    s.cmp.ge     s11, s4, s9
    br.nz        s11, sdiv_4
sdiv_done_3:
    s.xor        s1, s15, s7
    s.movz       s3, #16
    s.xor        s4, s13, s1
    s.movz       s7, #0
    s.sub        s9, s4, s1
    v.splat      v0, s10
    s.mul        s1, s9, s3
    v.splat      v1, s7
    v.splat      v2, s9
    v.splat      v3, s7
    v.iota       v4                              // arange(0, VLEN)
    s.andi       s4, s1, #511
    v.splat      v5, s1
    v.splat      v6, s4
    v.cmp.ge     p1, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ge     p1, v2, v3
    v.add        v1, v5, v4
    v.add        v1, v6, v0
    s.movz       s9, #12
    s.addi       s11, s7, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s7, s11, s9
    br.nz        s7, endfor_6
    s.mul        s7, s11, s3
    s.muli       s12, s7, #2                     // a runtime tile origin, x2
    s.add        s13, s2, s12                    // the tile origin
    v.ld.h       v0, [s13, #0]
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s12, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s13, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s13, s12
    mb.wait      s12
    s.rdspecial  s7, arg_base
    s.ld.d       s13, [s7, #32]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s7, role_id
    s.movz       s14, #1024
    s.mul        s15, s7, s14
    s.add        s7, s13, s15                    // this context's own scratch
    s.addi       s13, s7, #256                   // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s13, #0], v0
    s.addi       s14, s13, #32                   // row 1
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #64                   // row 2
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #96                   // row 3
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #128                  // row 4
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #160                  // row 5
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #192                  // row 6
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #224                  // row 7
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #256                  // row 8
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #288                  // row 9
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #320                  // row 10
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #352                  // row 11
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #384                  // row 12
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #416                  // row 13
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #448                  // row 14
    v.st.h       [s14, #0], v0
    s.addi       s14, s13, #480                  // row 15
    v.st.h       [s14, #0], v0
    s.addi       s14, s7, #768                   // TensorMap 1: a repacked tile
    s.movz       s7, #0
    s.st.d       [s14, #0], s13
    s.movz       s7, #16
    s.st.d       [s14, #8], s7
    s.movz       s7, #16
    s.st.d       [s14, #16], s7
    s.movz       s7, #32
    s.st.d       [s14, #48], s7
    s.movz       s7, #2
    s.st.d       [s14, #56], s7
    .li       s7, #68719476752
    s.st.d       [s14, #88], s7
    .li       s7, #8589934592
    s.st.d       [s14, #104], s7
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s7, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s14, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s7, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v48, v56, s7
    mb.wait      s7
    s.add        s14, s11, s8
    s.mov        s11, s14
    s.movz       s14, #1
    br.nz        s14, for_5
endfor_6:
    s.mul        s2, s10, s3
    v.splat      v0, s2
    v.add        v1, v0, v4
    s.muli       s3, s1, #2                      // a runtime tile origin, x2
    s.add        s4, s5, s3                      // the tile origin
    s.muli       s3, s2, #1024                   // a runtime tile origin, x1024
    s.add        s5, s4, s3                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s3, #0
    s.movz       s4, #0
    s.add        s9, s4, s2                      // the tile origin
    v.splat      v0, s9
    v.splat      v1, s8
    v.cmp.lt     p1, v0, v1
    s.movz       s4, #0
    s.add        s8, s4, s1                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s8
    v.add        v3, v0, v2
    s.movz       s4, #512
    v.splat      v0, s4
    v.cmp.lt     p2, v3, v0
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #1
    s.addi       s4, s5, #1024                   // row 1
    s.addi       s8, s9, #1
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #2
    s.addi       s4, s5, #2048                   // row 2
    s.addi       s8, s9, #2
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #3
    s.addi       s4, s5, #3072                   // row 3
    s.addi       s8, s9, #3
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #4
    s.addi       s4, s5, #4096                   // row 4
    s.addi       s8, s9, #4
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #5
    s.addi       s4, s5, #5120                   // row 5
    s.addi       s8, s9, #5
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #6
    s.addi       s4, s5, #6144                   // row 6
    s.addi       s8, s9, #6
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #7
    s.addi       s4, s5, #7168                   // row 7
    s.addi       s8, s9, #7
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #8
    s.addi       s4, s5, #8192                   // row 8
    s.addi       s8, s9, #8
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #9
    s.addi       s4, s5, #9216                   // row 9
    s.addi       s8, s9, #9
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #10
    s.addi       s4, s5, #10240                  // row 10
    s.addi       s8, s9, #10
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #11
    s.addi       s4, s5, #11264                  // row 11
    s.addi       s8, s9, #11
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #12
    s.addi       s4, s5, #12288                  // row 12
    s.addi       s8, s9, #12
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #13
    s.addi       s4, s5, #13312                  // row 13
    s.addi       s8, s9, #13
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #14
    s.addi       s4, s5, #14336                  // row 14
    s.addi       s8, s9, #14
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    s.movz       s3, #15
    s.addi       s4, s5, #15360                  // row 15
    s.addi       s5, s9, #15
    v.splat      v0, s5
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s4, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s3, v2
    .li       s3, #1065353216
    v.splat      v0, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s3, s1, #2                      // a runtime tile origin, x2
    s.add        s1, s6, s3                      // the tile origin
    s.muli       s3, s2, #1024                   // a runtime tile origin, x1024
    s.add        s2, s1, s3                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v2, a1, s1
    s.movz       s1, #0
    a.vread      v3, a1, s1
    vf.neg       v4, v3
    .li       s1, #1069066811
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v5, v4, v3
    vf.fms       v6, v4, v3, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    .li       s1, #1060205080
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v7, v6, v5
    vf.fma       v6, v4, v7, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v7, v6, v4
    vf.add       v4, v7, v0
    v.rcp.approx v6, v4                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v8, v4, v6, v7
    vf.fms       v4, v6, v8, v6
    vf.neg       v8, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.mul       v6, v2, v4                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #0
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v4, v2
    vf.cvt.f16.f32 v2, v4
    vf.mul       v4, v6, v2
    vf.cvt.f32.f16 v2, v4
    v.splat      v4, s9
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v2
    s.movz       s1, #1
    a.vread      v2, a1, s1
    s.movz       s1, #1
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #1
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #1024                   // row 1
    s.addi       s3, s9, #1
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #2
    a.vread      v2, a1, s1
    s.movz       s1, #2
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #2
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #2048                   // row 2
    s.addi       s3, s9, #2
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #3
    a.vread      v2, a1, s1
    s.movz       s1, #3
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #3
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #3072                   // row 3
    s.addi       s3, s9, #3
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #4
    a.vread      v2, a1, s1
    s.movz       s1, #4
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #4
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #4096                   // row 4
    s.addi       s3, s9, #4
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #5
    a.vread      v2, a1, s1
    s.movz       s1, #5
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #5
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #5120                   // row 5
    s.addi       s3, s9, #5
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #6
    a.vread      v2, a1, s1
    s.movz       s1, #6
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #6
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #6144                   // row 6
    s.addi       s3, s9, #6
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #7
    a.vread      v2, a1, s1
    s.movz       s1, #7
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #7
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #7168                   // row 7
    s.addi       s3, s9, #7
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #8
    a.vread      v2, a1, s1
    s.movz       s1, #8
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #8
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #8192                   // row 8
    s.addi       s3, s9, #8
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #9
    a.vread      v2, a1, s1
    s.movz       s1, #9
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #9
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #9216                   // row 9
    s.addi       s3, s9, #9
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #10
    a.vread      v2, a1, s1
    s.movz       s1, #10
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #10
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #10240                  // row 10
    s.addi       s3, s9, #10
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #11
    a.vread      v2, a1, s1
    s.movz       s1, #11
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #11
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #11264                  // row 11
    s.addi       s3, s9, #11
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #12
    a.vread      v2, a1, s1
    s.movz       s1, #12
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #12
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #12288                  // row 12
    s.addi       s3, s9, #12
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #13
    a.vread      v2, a1, s1
    s.movz       s1, #13
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #13
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #13312                  // row 13
    s.addi       s3, s9, #13
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #14
    a.vread      v2, a1, s1
    s.movz       s1, #14
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #14
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s2, #14336                  // row 14
    s.addi       s3, s9, #14
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #15
    a.vread      v2, a1, s1
    s.movz       s1, #15
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v3, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v5, v3, v4, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v4, v5, v3
    vf.add       v3, v4, v0
    v.rcp.approx v0, v3                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v4, v3, v0, v7
    vf.fms       v3, v0, v4, v0
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v0
    vf.mul       v0, v2, v3                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #15
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v3, v2
    vf.cvt.f16.f32 v2, v3
    vf.mul       v3, v0, v2
    vf.cvt.f32.f16 v0, v3
    s.addi       s1, s2, #15360                  // row 15
    s.addi       s2, s9, #15
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
__rctx_next:
    exit
