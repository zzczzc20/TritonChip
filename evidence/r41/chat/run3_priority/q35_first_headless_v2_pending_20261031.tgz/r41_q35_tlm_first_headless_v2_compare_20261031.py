#!/usr/bin/env python3
"""Compare instrumented states; report whether instrumentation changed logits."""
import json, os, select, sys
from pathlib import Path
import torch
from safetensors.torch import load_file
h=Path.home()
for pid in [int(x) for x in sys.argv[1:]]:
 try:
  fd=os.pidfd_open(pid);poll=select.poll();poll.register(fd,select.POLLIN);poll.poll();os.close(fd)
 except ProcessLookupError:pass
cpu=h/'r41_q35_first_headless_v2_cpu_20261031_diag';tlm=h/'r41_q35_first_headless_v2_tlm_20261031_diag'
c=json.loads((cpu/'result.json').read_text());t=json.loads((tlm/'result.json').read_text())
for k in ('input_ids','model','revision','prompt','chat_sha256'):
 if c[k]!=t[k]:raise ValueError('mismatched '+k)
a=load_file(str(cpu/'states.safetensors'));b=load_file(str(tlm/'states.safetensors'))
if set(a)!=set(b):raise ValueError('mismatched capture keys')
def cmp(x,y):
 if x.shape!=y.shape or x.dtype!=y.dtype:raise ValueError('shape or dtype mismatch')
 dt={2:torch.int16,4:torch.int32,8:torch.int64}.get(x.element_size())
 if dt is None:raise TypeError(str(x.dtype))
 f=x.float();g=y.float();delta=(f-g).abs()
 return {'elements':x.numel(),'bit_mismatches':int((x.view(dt)!=y.view(dt)).sum()),'relative_l2':float((f-g).norm()/f.norm().clamp_min(1e-30)),'max_abs':float(delta.max())}
reference_cpu=load_file(str(h/'r41_q35_layers_cpu_20261031_diag/states.safetensors'))
out={'schema':'r41-q35-instrumented-layers-comparison/1','scope':'truncated two-layer headless diagnostic CPU vs DP TLM; hidden_01 is first layer, not board or acceptance','input_ids':c['input_ids'],'comparisons':{k:cmp(a[k],b[k]) for k in sorted(a)},'partial_cpu_vs_full_cpu':{k:cmp(reference_cpu[k],a[k]) for k in ('hidden_00','hidden_01')}}
path=h/'r41_q35_first_headless_v2_compare_20261031.json';path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
