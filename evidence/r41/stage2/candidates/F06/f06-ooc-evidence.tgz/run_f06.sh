#!/bin/bash
# F06 unit OOC: tnca_grid_dispatch inside a registered harness, base vs new, 10 ns.
set -u
D=$HOME/r41s2-io/f06
for side in base new; do
  out=$D/out/$side; mkdir -p $out
  OOC_SV=1 OOC_GENERICS="CORE_N=3" ~/r41s2_tools/vivado_slot.sh $D/run.log -- \
    vivado -mode batch -nojournal -nolog -source $D/flow/vivado_ooc_timing.tcl \
    -tclargs tnca_grid_dispatch_ooc 10 xcu280-fsvh2892-2L-e $out $D/$side/rtl tnca_grid_dispatch.v tnca_grid_dispatch_ooc.v > $out/vivado.log 2>&1
  echo "$(date -u +%FT%TZ) $side exit $?" >> $D/run.log
done
echo F06-DONE >> $D/run.log
