    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #0
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.sub        v4, v0, v3
    v.cmp.lt     p2, v3, v0
    @p2 v.sel        v5, v4, v3
    v.movi       v4, #4
    v.movi       v6, #0
    v.lshr       v7, v5, v4
    v.movi       v4, #0
    v.sub        v5, v0, v7
    v.sub        v8, v6, v3
    @p2 v.sel        v9, v5, v7
    v.cmp.lt     p2, v3, v6
    v.sub        v5, v4, v9
    v.cmp.lt     p3, v9, v4
    @p2 v.sel        v7, v8, v3
    v.movi       v8, #15
    @p3 v.sel        v10, v5, v9
    v.movi       v5, #15
    v.and        v9, v7, v8
    v.and        v7, v10, v5
    v.movi       v5, #16
    v.sub        v8, v6, v9
    v.sub        v10, v4, v7
    @p2 v.sel        v11, v8, v9
    @p3 v.sel        v8, v10, v7
    s.rdspecial  s2, arg_base
    @p1 v.sel        v7, v1, v3
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #1024
    v.movi       v9, #256
    v.cmp.lt     p2, v3, v1
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v1, #8
    v.movi       v3, #0
    v.lshr       v10, v7, v1
    v.movi       v1, #2
    v.cmp.lt     p3, v5, v6
    v.sub        v7, v6, v5
    v.cmp.lt     p4, v5, v0
    v.sub        v6, v0, v5
    @p3 v.sel        v0, v7, v5
    v.sub        v0, v2, v10
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    @p1 v.sel        v7, v0, v10
    v.movi       v0, #1
    v.cmp.lt     p1, v7, v3
    v.cmp.lt     p3, v5, v4
    v.sub        v10, v4, v5
    @p4 v.sel        v4, v6, v5
    v.sub        v4, v3, v7
    s.add        s1, s4, s2                      // &out_ptr0[...]
    @p1 v.sel        v6, v4, v7
    v.movi       v4, #32
    v.lshr       v7, v6, v0
    v.mul        v0, v8, v4
    v.sub        v4, v3, v7
    v.sub        v6, v2, v9
    @p1 v.sel        v8, v4, v7
    v.sub        v4, v3, v1
    v.mul        v7, v8, v5
    v.cmp.lt     p1, v9, v2
    v.add        v2, v11, v7
    v.cmp.lt     p4, v1, v3
    v.add        v3, v2, v0
    @p3 v.sel        v0, v10, v5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v0, [s3, v3]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v2, v6, v9
    @p4 v.sel        v2, v4, v1
    vf.cvt.f16.f32 v1, v0
    @p2 v.st.w       [s1, #0], v1
__rctx_next:
    exit
