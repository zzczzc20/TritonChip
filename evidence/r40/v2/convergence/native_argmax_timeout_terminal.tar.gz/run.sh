source ~/tc_env/env.sh
cd /home/zhongchun/r40_native_argmax_timeout_20261017
export OMP_NUM_THREADS=2 MAX_JOBS=2 TNCA_HOST_TIMEOUT=7200 CUDA_VISIBLE_DEVICES=
export PYTHONPATH="$PWD:$PWD/python:$PWD/compiler/python:$PWD/tools/asm"
/home/zhongchun/tc_env/torchenv/bin/python -u -m archbench.run --platform tnca --profile core-vrf-sync-v5 --backend fpga-multicore-sim --backend-args '{"core_count": 3, "memory_ports": 3, "memory_bytes": 8388608, "link_stages": 2, "noc_link_stages": 2, "dispatch_stages": 2, "home_stages": 2, "code_stages": 2, "board_top": true, "maintenance": true, "memory_controls": true, "hbm_dma": true}' --point op.argmax/medium/fp16-r32-v4096 --jobs 1 --seed 0 --warmup 0 --timed 1 --timeout 14400 --set TNCA_TORCH_DEVICE=native --set TNCA_TRANSFER_POLICY=resident --out /home/zhongchun/r40_native_argmax_timeout_20261017/result.jsonl > runner.log 2>&1
echo $? > runner.exit
