#!/bin/bash
set -euo pipefail
ROOT="$HOME/r41-accept-p2-pipeline-v5";BASE="$HOME/r41-accept-p2/pipeline-fixed-model-v2"
mkdir -p "$BASE"
source "$HOME/tc_env/env.sh"
export PYTHONPATH="$ROOT:$ROOT/python:$ROOT/compiler/python:$ROOT/tools/asm:$ROOT/tools/performance_harness/systemc"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MAX_JOBS=2
export TNCA_PROFILE=core-vrf-sync-v5-x8 TNCA_BACKEND=systemc-tlm-grid TNCA_ACTIVE_CORES=3
export TNCA_TLM_BINARY="$HOME/r41-accept-p1/model-build/tnca-chip" TNCA_TLM_MEMORY_BYTES=0x200000000
export TNCA_TLM_CONFIG="$ROOT/tools/performance_harness/systemc/configs/r40-three-core.cfg"
export TNCA_RCTX_SPMD=1 TNCA_RCTX_SPMD_SHARED=2 TNCA_SCHEDULE=0 TNCA_WINDOW_REUSE=0 TNCA_IEEE_DIV=1
export TORCH_EXTENSIONS_DIR="$HOME/r41-accept-p2/extensions"
cd "$ROOT"
make r2-stage-data PYTHON="$HOME/tc_env/torchenv/bin/python" > "$BASE/stage.log" 2>&1
for mode in baseline single paired; do
 export TNCA_TLM_OUT="$BASE/$mode-model"
 case "$mode" in
 baseline) export TNCA_SINGLE_ROLE_PIPELINE=0 TNCA_RCTX_ROLES=0 TNCA_RCTX_ROLE_PAIRS=0; args=();;
 single) export TNCA_SINGLE_ROLE_PIPELINE=1 TNCA_RCTX_ROLES=0 TNCA_RCTX_ROLE_PAIRS=0; args=(--require-single-role-pipeline);;
 paired) export TNCA_SINGLE_ROLE_PIPELINE=0 TNCA_RCTX_ROLES=2 TNCA_RCTX_ROLE_PAIRS=1; args=(--ring-stages 2);;
 esac
 "$HOME/tc_env/torchenv/bin/python" tools/performance_harness/fragment_case.py --out "$BASE/$mode" --columns 16 --shapes 16x16x32,16x16x48,16x16x64 --bitwise --require-resident "${args[@]}" > "$BASE/$mode.log" 2>&1
done
