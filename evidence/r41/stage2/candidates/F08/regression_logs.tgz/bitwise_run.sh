#!/bin/bash
# bitwise_run.sh TREE OUTDIR -- the Stage 1 bitwise K-order set on TREE's RTL (sim-file, core-vrf-sync-v5):
# final: {bfloat16 strided, float16} x {16, 32} columns; cancel: float16 x {16, 32}. Two at a time.
T=$1; O=$2; A=$HOME/r41s2-fma-aux
mkdir -p $O
cd $T
export TNCA_CACHE=$A/tnca-cache TNCA_HOST_TIMEOUT=7200 PYTHONPATH=python
~/tc_env/torchenv/bin/python $A/prep_bench.py core-vrf-sync-v5 > $O/prepare.log 2>&1 || { echo PREPARE-FAILED >> $O/status.txt; exit 1; }
run() {   # name args...
  n=$1; shift
  nice ~/tc_env/torchenv/bin/python tools/performance_harness/fragment_case.py --out $O/$n "$@" > $O/$n.log 2>&1
  echo "$n exit $?" >> $O/status.txt
}
run final-bfloat16-yes-16 --columns 16 --dtype bfloat16 --strided --bitwise &
run final-bfloat16-yes-32 --columns 32 --dtype bfloat16 --strided --bitwise &
wait
run final-float16-no-16 --columns 16 --dtype float16 --bitwise &
run final-float16-no-32 --columns 32 --dtype float16 --bitwise &
wait
run cancel-float16-no-16 --columns 16 --dtype float16 --bitwise --cancel &
run cancel-float16-no-32 --columns 32 --dtype float16 --bitwise --cancel &
wait
echo done >> $O/status.txt
