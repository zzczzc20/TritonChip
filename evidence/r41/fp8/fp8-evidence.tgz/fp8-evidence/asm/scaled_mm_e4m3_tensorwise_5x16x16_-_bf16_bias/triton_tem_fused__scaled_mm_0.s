    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #1
    s.movz       s2, #0
    s.sub        s3, s1, s4
    s.movz       s5, #0
    s.min.s      s6, s3, s1
    s.movz       s1, #0
    s.cmp.lt     s3, s6, s2
    s.movz       s2, #0
    s.cmp.lt     s7, s4, s5
    s.sub        s5, s1, s3
    s.sub        s1, s2, s7
    s.xor        s2, s6, s5
    s.movz       s3, #0
    s.movz       s7, #1
    s.xor        s8, s4, s1
    s.sub        s9, s2, s5
    s.rdspecial  s2, arg_base
    s.movz       s5, #0
    s.sub        s10, s8, s1
    s.addi       s8, s3, #0
    s.cmp.eq     s3, s9, s7
    s.ld.d       s7, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.addi       s11, s5, #0
    s.ld.d       s5, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s12, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s13, [s2, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s14, [s2, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s15, [s2, #40]                  // out_ptr0: device_ptr64 at arg_base+40
    s.mov        s8, s10
    br.nz        s3, sdiv_done_1
    s.movz       s2, #0
    s.movz       s3, #31
    s.mov        s8, s2
    s.addi       s2, s3, #0
sdiv_2:
    s.lshr       s3, s10, s2
    s.shli       s16, s11, #1
    s.andi       s17, s3, #1
    s.movz       s3, #0
    s.or         s18, s16, s17
    s.movz       s16, #1
    s.cmp.geu    s17, s18, s9
    s.shl        s19, s16, s2
    s.sub        s16, s3, s17
    s.subi       s3, s2, #1
    s.and        s17, s9, s16
    s.and        s20, s19, s16
    s.sub        s16, s18, s17
    s.or         s17, s8, s20
    s.mov        s11, s16
    s.mov        s8, s17
    s.mov        s2, s3
    s.movz       s3, #0
    s.cmp.ge     s16, s2, s3
    br.nz        s16, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s3, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s6, s2
    s.movz       s2, #0
    s.cmp.lt     s16, s3, s8
    s.sub        s8, s9, s10
    s.sub        s9, s2, s16
    s.xor        s2, s6, s8
    s.xor        s6, s11, s1
    s.xor        s10, s3, s9
    s.sub        s11, s2, s8
    s.movz       s2, #0
    s.movz       s16, #1
    s.sub        s17, s6, s1
    s.sub        s1, s10, s9
    s.movz       s6, #0
    s.addi       s10, s2, #0
    s.cmp.eq     s2, s11, s16
    s.add        s16, s4, s17
    s.addi       s4, s6, #0
    s.mov        s10, s1
    br.nz        s2, sdiv_done_3
    s.movz       s2, #0
    s.movz       s6, #31
    s.mov        s10, s2
    s.addi       s2, s6, #0
sdiv_4:
    s.lshr       s6, s1, s2
    s.shli       s17, s4, #1
    s.andi       s18, s6, #1
    s.movz       s6, #0
    s.or         s19, s17, s18
    s.movz       s17, #1
    s.cmp.geu    s18, s19, s11
    s.shl        s20, s17, s2
    s.sub        s17, s6, s18
    s.subi       s6, s2, #1
    s.and        s18, s11, s17
    s.and        s21, s20, s17
    s.sub        s17, s19, s18
    s.or         s18, s10, s21
    s.mov        s4, s17
    s.mov        s10, s18
    s.mov        s2, s6
    s.movz       s6, #0
    s.cmp.ge     s17, s2, s6
    br.nz        s17, sdiv_4
sdiv_done_3:
    s.movz       s1, #16
    s.xor        s2, s9, s8
    s.mul        s4, s16, s1
    s.xor        s6, s10, s2
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s8, s6, s2
    v.movi       v1, #5
    v.splat      v2, s4
    s.mul        s2, s8, s1
    v.movi       v3, #0
    v.add        v4, v2, v0
    v.splat      v2, s16
    v.splat      v5, s3
    v.splat      v6, s8
    v.splat      v7, s3
    v.splat      v8, s2
    v.sub        v9, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.cmp.ge     p3, v2, v5
    v.sub        v2, v3, v1
    v.cmp.ge     p3, v6, v7
    v.add        v5, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v4
    @p2 v.sel        v4, v2, v1
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s6, #31
idiv_5:
    v.splat      v6, s6
    v.shl        v7, v2, v0
    v.cmp.lt     p2, v2, v3
    v.lshr       v8, v5, v6
    v.shl        v9, v0, v6
    s.subi       s8, s6, #1
    v.and        v6, v8, v0
    s.movz       s9, #0
    v.or         v8, v7, v6
    v.cmp.geu    p3, v8, v4
    p.or         p4, p2, p3
    v.sub        v6, v8, v4
    @p4 v.sel        v7, v9, v3
    @p4 v.sel        v9, v6, v8
    v.or         v6, v1, v7
    v.mov        v2, v9
    v.mov        v1, v6
    s.mov        s6, s8
    s.cmp.ge     s8, s6, s9
    br.nz        s8, idiv_5
    v.sub        v0, v3, v2
    @p1 v.sel        v1, v0, v2
    s.andi       s6, s2, #15
    v.splat      v0, s6
    v.iota       v2                              // arange(0, VLEN)
    v.add        v3, v0, v2
    s.rdspecial  s8, arg_base
    s.ld.d       s9, [s8, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s8, role_id
    s.movz       s10, #1536
    s.mul        s11, s8, s10
    s.add        s8, s9, s11                     // this context's own scratch
    s.addi       s9, s8, #0
    v.splat      v0, s3
    v.iota       v2                              // arange(0, VLEN)
    v.extract    s3, v1, #0
    v.splat      v3, s3
    v.splat      v4, s1
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s9, #0], v5
    s.addi       s3, s9, #64
    v.extract    s10, v1, #1
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #128
    v.extract    s10, v1, #2
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #192
    v.extract    s10, v1, #3
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #256
    v.extract    s10, v1, #4
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #320
    v.extract    s10, v1, #5
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #384
    v.extract    s10, v1, #6
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #448
    v.extract    s10, v1, #7
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #512
    v.extract    s10, v1, #8
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #576
    v.extract    s10, v1, #9
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #640
    v.extract    s10, v1, #10
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #704
    v.extract    s10, v1, #11
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #768
    v.extract    s10, v1, #12
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #832
    v.extract    s10, v1, #13
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #896
    v.extract    s10, v1, #14
    v.splat      v3, s10
    v.mul        v5, v3, v4
    v.add        v3, v2, v5
    v.add        v5, v0, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s9, #960
    v.extract    s9, v1, #15
    v.splat      v1, s9
    v.mul        v3, v1, v4
    v.add        v1, v2, v3
    v.add        v3, v0, v1
    v.st.w       [s3, #0], v3
    fence.acq_rel.device
    s.addi       s3, s8, #1024                   // 256 bytes of repack scratch
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s9, s8, #0
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s3, #0], v1
    s.addi       s9, s8, #64
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #16                     // row 1
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #128
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #32                     // row 2
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #192
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #48                     // row 3
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #256
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #64                     // row 4
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #320
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #80                     // row 5
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #384
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #96                     // row 6
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #448
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #112                    // row 7
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #512
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #128                    // row 8
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #576
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #144                    // row 9
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #640
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #160                    // row 10
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #704
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #176                    // row 11
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #768
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #192                    // row 12
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #832
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #208                    // row 13
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #896
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s3, #224                    // row 14
    v.st.b       [s9, #0], v1
    s.addi       s9, s8, #960
    v.ld.w       v0, [s9, #0]
    v.ld.gather.b v1, [s7, v0]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #240                    // row 15
    v.st.b       [s7, #0], v1
    w.def        w0, #60, #4                     // v60..v63
    fence.acq_rel.device
    v.ld.w       v0, [s3, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s7, s3, #64
    v.ld.w       v0, [s7, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s7, s3, #128
    v.ld.w       v0, [s7, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s7, s3, #192
    v.ld.w       v0, [s7, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s3, s8, #1280                   // 256 bytes of repack scratch
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.movz       s7, #0
    s.muli       s8, s6, #16                     // a runtime tile origin, x16
    s.add        s6, s7, s8                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    s.movz       s7, #16
    v.splat      v1, s7
    v.mul        v3, v0, v1
    v.splat      v0, s6
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s3, #0], v0
    s.addi       s7, s6, #1
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #16                     // row 1
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #2
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #32                     // row 2
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #3
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #48                     // row 3
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #4
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #64                     // row 4
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #5
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #80                     // row 5
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #6
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #96                     // row 6
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #7
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #112                    // row 7
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #8
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #128                    // row 8
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #9
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #144                    // row 9
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #10
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #160                    // row 10
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #11
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #176                    // row 11
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #12
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #192                    // row 12
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #13
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #208                    // row 13
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #14
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s7, s3, #224                    // row 14
    v.st.b       [s7, #0], v0
    s.addi       s7, s6, #15
    v.splat      v0, s7
    v.add        v1, v3, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s5, s3, #240                    // row 15
    v.st.b       [s5, #0], v0
    w.def        w1, #56, #4                     // v56..v59
    fence.acq_rel.device
    v.ld.w       v0, [s3, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s5, s3, #64
    v.ld.w       v0, [s5, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s5, s3, #128
    v.ld.w       v0, [s5, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s5, s3, #192
    v.ld.w       v0, [s5, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    m.zero       a0
    mb.arm       s3, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.e4m3 a0, v60, v56, s3
    mb.wait      s3
    v.movi       v0, #0
    s.ld.w       s5, [s12, #0]                   // one element, not a vector
    v.splat      v1, s5
    s.ld.w       s5, [s13, #0]                   // one element, not a vector
    v.splat      v3, s5
    s.muli       s5, s2, #2                      // a runtime tile origin, x2
    s.add        s6, s14, s5                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s5, s2, #2                      // a runtime tile origin, x2
    s.add        s7, s15, s5                     // the tile origin
    s.muli       s5, s4, #32                     // a runtime tile origin, x32
    s.add        s8, s7, s5                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    a.vread      v4, a0, s5
    vf.add       v5, v4, v0
    vf.mul       v4, v1, v3
    vf.mul       v6, v5, v4
    s.movz       s5, #0
    s.add        s7, s5, s4                      // the tile origin
    v.splat      v4, s7
    s.movz       s4, #5
    v.splat      v5, s4
    v.cmp.lt     p1, v4, v5
    s.movz       s4, #0
    s.add        s5, s4, s2                      // the tile origin
    v.splat      v4, s5
    v.add        v7, v2, v4
    v.splat      v2, s1
    v.cmp.lt     p2, v7, v2
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s7
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s8, #0], v4
    s.movz       s1, #1
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #1
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #32                     // row 1
    s.addi       s2, s7, #1
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #2
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #2
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #64                     // row 2
    s.addi       s2, s7, #2
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #3
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #3
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #96                     // row 3
    s.addi       s2, s7, #3
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #4
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #4
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #128                    // row 4
    s.addi       s2, s7, #4
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #5
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #5
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #160                    // row 5
    s.addi       s2, s7, #5
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #6
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #6
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #192                    // row 6
    s.addi       s2, s7, #6
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #7
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #7
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #224                    // row 7
    s.addi       s2, s7, #7
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #8
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #8
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #256                    // row 8
    s.addi       s2, s7, #8
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #9
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #9
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #288                    // row 9
    s.addi       s2, s7, #9
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #10
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #10
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #320                    // row 10
    s.addi       s2, s7, #10
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #11
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #11
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #352                    // row 11
    s.addi       s2, s7, #11
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #12
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #12
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #384                    // row 12
    s.addi       s2, s7, #12
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #13
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #13
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #416                    // row 13
    s.addi       s2, s7, #13
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #14
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v2, v1, v3
    vf.mul       v6, v4, v2
    s.addi       s1, s7, #14
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v6, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #448                    // row 14
    s.addi       s2, s7, #14
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #15
    a.vread      v2, a0, s1
    vf.add       v4, v2, v0
    vf.mul       v0, v1, v3
    vf.mul       v1, v4, v0
    s.addi       s1, s7, #15
    v.splat      v0, s1
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s6, #0]
    vf.cvt.bf16.f32 v2, v0
    vf.add       v0, v1, v2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s8, #480                    // row 15
    s.addi       s2, s7, #15
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
__rctx_next:
    exit
