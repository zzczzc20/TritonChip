import sys,struct,hashlib
from pathlib import Path
r=Path.home()/"r41run2-auto/runtime_2eead82e";sys.path[:0]=[str(r/"python"),str(r/"compiler/python"),str(r/"tools/asm"),str(r/"tools/r41/run2_board")]
import auto
s="/sys/bus/pci/devices"; p=auto.probe(s)
if not auto.idle(p) or p["uuid"]!=auto.IMAGE_UUID or auto.clock_mhz(s)!=100:raise SystemExit("board busy or identity changed")
import triton
from tnca.runtime import Session
from tnca_asm import Assembler,build_image
profile="core-vrf-sync-v5-x8-g2c4-dp"
def desc(base,rows,cols):
 d=bytearray(256);struct.pack_into("<Q",d,0,base);struct.pack_into("<QQ",d,8,rows,cols);struct.pack_into("<qq",d,48,cols*2,2);struct.pack_into("<II",d,88,rows,cols);struct.pack_into("4B",d,108,2,0,0,0);struct.pack_into("<QQ",d,112,7319,7);return bytes(d)
with Session(profile=profile,backend="fpga-u280-multicore",xclbin=str(Path.home()/"r41run2-auto/run2.xclbin"),image_profile=profile,core_count=3,memory_ports=3,hbm_dma=True,hbm_bytes=8<<30,device_clock=False,host_timeout=3600,deadline_cycles=200000000000) as session:
 for rows,cols in ((4,16),(16,16)):
  n=rows*cols;src=session.allocate(n*2);dst=session.allocate(n*2);d0=session.allocate(256);d1=session.allocate(256)
  data=struct.pack("<"+"H"*n,*[(i*11+7)&65535 for i in range(n)])
  session.upload(src,data);session.upload(dst,bytes([0xa5])*(n*2));session.upload(d0,desc(src.addr,rows,cols));session.upload(d1,desc(dst.addr,rows,cols))
  text=f"""
  .li s1, #{d0.addr}
  td.load d0, [s1]
  .li s2, #{d1.addr}
  td.load d1, [s2]
  w.def w0, #0, #8
  mb.arm s3, b0, #0, #1
  .li s10, #0
  .li s11, #0
  t.ld.async.h w0, d0, s10, s3
  mb.wait s3
  mb.arm s4, b0, #0, #1
  t.st.async.h w0, d1, s10, s4
  mb.wait s4
  exit
  """
  words=build_image(Assembler().assemble(text));code=b"".join(w.to_bytes(8,"little") for w in words)
  assert session.dev.upload(0,code).ok
  reply=session.dev.launch(0,0); assert reply.ok,reply
  got=session.download(dst);bad=[i for i,(a,b) in enumerate(zip(data,got)) if a!=b]
  print(f"TENSOR_COPY rows={rows} cols={cols} mismatch_bytes={len(bad)} first={bad[:24]} expected_sha={hashlib.sha256(data).hexdigest()} actual_sha={hashlib.sha256(got).hexdigest()}",flush=True)
  for b in (src,dst,d0,d1):session.free(b)
