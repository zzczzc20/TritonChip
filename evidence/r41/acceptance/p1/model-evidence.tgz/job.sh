#!/bin/bash
set -euo pipefail
source "$HOME/tc_env/env.sh"
ROOT="$HOME/r41-accept-src"
OUT="$HOME/r41-accept-p1"
PY="$HOME/tc_env/torchenv/bin/python"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MAX_JOBS=2 CUDA_VISIBLE_DEVICES=
cmake -S "$ROOT/tools/performance_harness/systemc" -B "$OUT/model-build" -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="$HOME/tc_env/systemc-3.0.2/install" > "$OUT/model-config.log" 2>&1
cmake --build "$OUT/model-build" --parallel 4 > "$OUT/model-build.log" 2>&1
export TNCA_TLM_BINARY="$OUT/model-build/tnca-chip"
export TNCA_TLM_CONFIG="$ROOT/tools/performance_harness/systemc/configs/r40-three-core.cfg"
export TNCA_TORCH_DEVICE=native TNCA_BACKEND=systemc-tlm-grid TNCA_PROFILE=core-vrf-sync-v5-x8 TNCA_IEEE_DIV=1
export PYTHONPATH="$ROOT:$ROOT/python:$ROOT/compiler/python:$ROOT/tools/asm:$ROOT/tools/performance_harness/systemc"
export TNCA_DEADLINE=200000000 TNCA_HOST_TIMEOUT=1800 TNCA_TLM_MEMORY_BYTES=0x200000000
for columns in 16 32; do
    export TRITON_CACHE_DIR="$OUT/cache-$columns/triton" TORCHINDUCTOR_CACHE_DIR="$OUT/cache-$columns/inductor" TORCH_EXTENSIONS_DIR="$OUT/extensions"
    "$PY" "$ROOT/tools/performance_harness/fragment_case.py" --out "$OUT/fragment-$columns" --columns "$columns" --shapes 17x65x33,128x128x192 --dtype float16 --bitwise > "$OUT/fragment-$columns.log" 2>&1
done
