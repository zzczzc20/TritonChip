    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #6
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.movi       v6, #0
    @p1 v.sel        v7, v4, v5
    v.sub        v4, v1, v3
    v.cmp.lt     p1, v3, v1
    v.sub        v5, v0, v3
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v4, v3
    v.cmp.lt     p2, v3, v0
    v.cmp.lt     p3, v7, v6
    @p2 v.sel        v4, v5, v3
    v.movi       v3, #63
    @p3 v.sel        v5, v8, v7
    v.movi       v7, #15
    v.and        v8, v4, v3
    v.and        v3, v5, v7
    v.movi       v4, #64
    v.sub        v5, v0, v8
    v.sub        v7, v6, v3
    @p2 v.sel        v10, v5, v8
    @p3 v.sel        v5, v7, v3
    s.rdspecial  s2, arg_base
    v.movi       v3, #16
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v7, #1024
    v.sub        v8, v0, v4
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.cmp.lt     p2, v4, v0
    v.movi       v0, #10
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    v.lshr       v11, v9, v0
    s.movz       s1, #32768
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p3, v4, v2
    v.mul        v9, v5, v0
    v.sub        v0, v1, v11
    v.sub        v5, v2, v4
    @p1 v.sel        v2, v0, v11
    v.sub        v0, v6, v3
    v.mul        v11, v2, v4
    v.cmp.lt     p1, v3, v6
    v.add        v2, v10, v11
    v.sub        v6, v1, v7
    v.add        v10, v2, v9
    @p2 v.sel        v2, v8, v4
    v.ld.gather.w v2, [s3, v10]                  // index is in elements (ISA sec 9.1)
    s.add        s1, s4, s2                      // &out_ptr0[...]
    v.cmp.lt     p2, v7, v1
    @p3 v.sel        v1, v5, v4
    @p1 v.sel        v1, v0, v3
    @p2 v.sel        v0, v6, v7
    vf.cvt.f32.f16 v0, v2
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
