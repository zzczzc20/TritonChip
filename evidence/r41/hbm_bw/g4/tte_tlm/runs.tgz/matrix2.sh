#!/bin/bash
cd ~/r41-tte-runs
P="op.copy/membound/fp32-medium-contig-r1024-c1024 op.add/membound/fp32-medium-contig-r1024-c1024 op.relu/membound/fp32-medium-contig-r1024-c1024 op.clone/membound/fp32-medium-contig-r1024-c1024 op.add/membound/fp16-medium-contig-r2048-c1024 op.copy/membound/fp16-medium-contig-r2048-c1024 op.add/membound/fp32-medium-strided-r1024-c1024"
for a in "mx_pipe_line_m3 pipe_line.cfg 3" "mx_pipe_linewc_m3 pipe_linewc.cfg 3" "mx_pipe1_line_m3 pipe1_line.cfg 3"; do set -- $a; rm -rf $1; ./run.sh $1 $2 $3 $P; done
touch MATRIX2_DONE
