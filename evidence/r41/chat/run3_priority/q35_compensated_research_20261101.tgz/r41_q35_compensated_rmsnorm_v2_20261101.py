#!/usr/bin/env python3
"""Generic two-input gated RMS norm; exact-mean candidate vs default DP TLM."""
import json,os,sys,tempfile
from pathlib import Path
import torch
import triton
import triton.language as tl
from safetensors.torch import load_file

@triton.jit
def compensated(a,al,b,bl):
 s=a+b;t=s-a;error=(a-(s-t))+(b-t)
 return s,al+bl+error

@triton.jit
def gated_norm(X,Z,W,Y,CORRECT:tl.constexpr,BLOCK:tl.constexpr,EPS:tl.constexpr):
 row=tl.program_id(0);k=tl.arange(0,BLOCK)
 x=tl.load(X+row*BLOCK+k).to(tl.float32);z=tl.load(Z+row*BLOCK+k).to(tl.float32);w=tl.load(W+k).to(tl.float32)
 square=x*x
 if CORRECT:
  hi,lo=tl.reduce((square,tl.full((BLOCK,),0,tl.float32)),axis=0,combine_fn=compensated);mean=(hi+lo)/BLOCK
 else:mean=tl.sum(square,0)/BLOCK
 normalized=(x*tl.rsqrt(mean+EPS)).to(tl.bfloat16).to(tl.float32)
 weighted=(w*normalized).to(tl.bfloat16).to(tl.float32)
 activation=z/(1.0+tl.exp(-z));tl.store(Y+row*BLOCK+k,(weighted*activation).to(tl.bfloat16))

def main():
 from tnca import aot
 from tnca.runtime import Session
 import tlm_backend,chat
 tlm_backend.register();h=Path.home();raw=load_file(str(h/'r41_q35_gate_norm_tlm_20261031_diag/states.safetensors'));x=raw['core'].contiguous();z=raw['gate'].contiguous();want=raw['expected'].contiguous()
 if x.shape!=(864,128) or z.shape!=x.shape or x.dtype!=torch.bfloat16:raise ValueError('unexpected input')
 args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1']);app=chat.ChatApplication(args);norm=app.model.model.language_model.layers[0].linear_attn.norm;weight=norm.weight.detach().cpu().contiguous();eps=norm.variance_epsilon
 rows=[]
 for correct in (False,True):
  path=Path(tempfile.mkdtemp())/'rms.tnca';c=aot.compile_aot(gated_norm,signature={'X':'*bf16','Z':'*bf16','W':'*bf16','Y':'*bf16','CORRECT':'constexpr','BLOCK':'constexpr','EPS':'constexpr'},constexprs={'CORRECT':correct,'BLOCK':128,'EPS':eps},profile='core-vrf-sync-v5-x8-g2c4-dp',options={'index_opt':1},output=str(path))
  with Session(profile='core-vrf-sync-v5-x8-g2c4-dp',backend='systemc-tlm-grid',host_timeout=600,deadline_cycles=20000000) as sess:
   mod=sess.load(c.path);a,b,w,y=[sess.allocate(n) for n in (x.numel()*2,z.numel()*2,weight.numel()*2,want.numel()*2)];sess.upload(a,x.view(torch.uint8).numpy().tobytes());sess.upload(b,z.view(torch.uint8).numpy().tobytes());sess.upload(w,weight.view(torch.uint8).numpy().tobytes());before=sess.dev.counters_snapshot();ev=sess.submit(mod,{'X':a,'Z':b,'W':w,'Y':y},grid=(864,1,1));sess.wait(ev);after=sess.dev.counters_snapshot()
   if not ev.ok:raise RuntimeError(str(ev.error))
   got=torch.frombuffer(bytearray(sess.download(y)),dtype=torch.bfloat16).clone().reshape_as(want);diff=got.view(torch.int16)!=want.view(torch.int16);ins=sum(v-before.get(k,0) for k,v in after.items() if k.startswith('core_') and k.endswith('_instructions'))
   row={'compensated':correct,'elements':got.numel(),'bit_mismatches':int(diff.sum()),'max_abs':float((got.float()-want.float()).abs().max()),'first_mismatches':torch.nonzero(diff).tolist()[:10],'device_cycles':ev.device_cycles,'instructions':ins,'launches':1,'loads_during_launch':0};rows.append(row);print(json.dumps(row),flush=True)
 out=Path(os.environ['R41_NORM_OUT']);out.mkdir(parents=True,exist_ok=False);(out/'result.json').write_text(json.dumps({'scope':'DP TLM research on real captured inputs; not board','rows':rows},indent=2)+'\n')
if __name__=='__main__':main()
