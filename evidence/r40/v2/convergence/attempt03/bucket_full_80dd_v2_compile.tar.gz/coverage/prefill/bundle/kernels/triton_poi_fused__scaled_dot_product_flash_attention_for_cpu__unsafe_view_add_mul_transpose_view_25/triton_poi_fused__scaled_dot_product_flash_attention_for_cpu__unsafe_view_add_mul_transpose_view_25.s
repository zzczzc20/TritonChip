    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s6, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s7, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s8, [s1, #32]                   // out_ptr0: device_ptr64 at arg_base+32
__rctx_program:
    s.shli       s1, s2, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #6
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.movi       v6, #0
    @p1 v.sel        v7, v5, v4
    v.sub        v5, v0, v4
    v.cmp.lt     p2, v4, v0
    v.lshr       v8, v7, v3
    v.sub        v3, v1, v4
    @p2 v.sel        v7, v5, v4
    v.sub        v5, v2, v8
    v.movi       v9, #15
    v.cmp.lt     p3, v4, v1
    @p1 v.sel        v10, v5, v8
    @p3 v.sel        v5, v3, v4
    v.movi       v3, #63
    v.sub        v8, v6, v10
    v.cmp.lt     p1, v10, v6
    v.movi       v11, #511
    @p1 v.sel        v12, v8, v10
    v.lshr       v8, v7, v9
    v.movi       v7, #0
    v.and        v9, v5, v3
    v.and        v3, v12, v11
    v.sub        v5, v0, v8
    v.movi       v10, #64
    v.sub        v11, v7, v4
    @p2 v.sel        v12, v5, v8
    v.cmp.lt     p2, v4, v7
    v.sub        v5, v1, v9
    @p3 v.sel        v8, v5, v9
    v.sub        v5, v6, v3
    v.cmp.lt     p3, v10, v1
    @p2 v.sel        v9, v11, v4
    @p1 v.sel        v4, v5, v3
    v.movi       v3, #512
    s.movz       s9, #32768
    v.splat      v5, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v11, v1, v10
    v.cmp.lt     p1, v10, v2
    v.sub        v1, v2, v10
    @p3 v.sel        v2, v11, v10
    v.movi       v2, #32767
    v.mul        v11, v12, v10
    v.cmp.lt     p3, v3, v6
    v.and        v12, v9, v2
    v.movi       v2, #1024
    v.add        v9, v8, v11
    v.sub        v8, v7, v12
    v.mul        v11, v4, v2
    v.sub        v2, v6, v3
    @p2 v.sel        v4, v8, v12
    v.add        v6, v9, v11
    v.sub        v8, v0, v5
    v.ld.gather.h v9, [s5, v4]                   // index is in elements (ISA sec 9.1)
    v.sub        v11, v7, v5
    v.cmp.lt     p2, v5, v0
    @p1 v.sel        v0, v1, v10
    s.shli       s9, s1, #1                      // element offset -> bytes (x2)
    .li       s10, #1052050675
    v.splat      v0, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s10, s6, s9                     // &in_ptr2[...]
    v.cmp.lt     p1, v5, v7
    @p3 v.sel        v1, v2, v3
    s.shli       s9, s1, #2                      // element offset -> bytes (x4)
    @p2 v.sel        v1, v8, v5
    s.add        s1, s8, s9                      // &out_ptr0[...]
    @p1 v.sel        v1, v11, v5
    v.ld.gather.h v1, [s3, v6]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v2, v9
    v.ld.h       v3, [s10, #0]
    vf.cvt.f16.f32 v5, v1
    vf.mul       v1, v5, v2
    v.ld.gather.h v2, [s7, v4]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v4, v3
    vf.cvt.f16.f32 v3, v2
    vf.mul       v2, v4, v3
    vf.add       v3, v1, v2
    vf.mul       v1, v3, v0
    v.st.w       [s1, #0], v1
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s9, s1, s4
    s.mov        s2, s1
    br.nz        s9, __rctx_program
    exit
