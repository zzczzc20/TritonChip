#!/usr/bin/env python3
import json,sys
from pathlib import Path
import torch
import torch.nn.functional as F
from safetensors.torch import load_file
h=Path.home();tree=h/'r41_q35_multiturn_diag_20261031';sys.path[:0]=[str(tree/'tools/models'),str(tree),str(tree/'python'),str(tree/'compiler/python'),str(tree/'tools/asm')]
import chat
args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1']);app=chat.ChatApplication(args);norm=app.model.model.language_model.layers[0].linear_attn.norm
p=load_file(str(h/'r41_q35_gate_norm_tlm_20261031_diag/states.safetensors'));x=p['core'];z=p['gate'];y=p['expected'];xf=x.float();v=(xf.double().square().mean(-1,keepdim=True)).float();u=xf*torch.rsqrt(v+norm.variance_epsilon);w=norm.weight.detach().cpu()*u.to(x.dtype);out=(w*F.silu(z.float())).to(x.dtype)
errs=(out.view(torch.int16)!=y.view(torch.int16));r={'schema':'r41-q35-gate-exact-variance-cpu/1','scope':'CPU high-precision variance hypothetical, not TLM or board','variance_elements':v.numel(),'variance_mismatches':int((v.view(torch.int32)!=xf.square().mean(-1,keepdim=True).view(torch.int32)).sum()),'output_elements':out.numel(),'output_mismatches':int(errs.sum()),'max_abs':float((out.float()-y.float()).abs().max()),'mismatching_coordinates':torch.nonzero(errs).tolist()[:20]}
(h/'r41_q35_gate_sum_exact_20261101.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
