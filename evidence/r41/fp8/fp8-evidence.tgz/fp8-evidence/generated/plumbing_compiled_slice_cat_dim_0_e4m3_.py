# AOT ID: ['21_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/fp8w/runs3/tlm-full/inductor-cache/2r/c2rxkrove72u3zu5umh7pjishzrgl74vywmdlslltzf5q2e6dwsl.py
# Topologically Sorted Source Nodes: [getitem, getitem_1, cat], Original ATen: [aten.slice, aten.cat]
# Source node to ATen node mapping:
#   cat => cat
#   getitem => slice_1
#   getitem_1 => slice_2, slice_3
# Graph fragment:
#   %arg0_1 : Tensor "f8e4m3fn[48, 80][80, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %slice_1 : Tensor "f8e4m3fn[48, 8][80, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg0_1, 1, 0, 8), kwargs = {})
#   %slice_2 : Tensor "f8e4m3fn[17, 80][80, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg1_1, 0, 3, 20), kwargs = {})
#   %slice_3 : Tensor "f8e4m3fn[17, 8][80, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_2, 1, 5, 13), kwargs = {})
#   %cat : Tensor "f8e4m3fn[65, 8][8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%slice_1, %slice_3],), kwargs = {})
#   return %buf0
triton_poi_fused_cat_slice_0 = async_compile.triton('triton_poi_fused_cat_slice_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp8e4nv', 'out_ptr0': '*fp8e4nv', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_slice_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1152}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_slice_0(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 384
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8)
    x1 = xindex // 8
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 80*x1), xmask)
    tl.store(out_ptr0 + (x2), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/fp8w/runs3/tlm-full/inductor-cache/pa/cpachyext6am2dclm3morf7vrul7ecjhniecgvvsjtshsr3r6quo.py
# Topologically Sorted Source Nodes: [getitem, getitem_1, cat], Original ATen: [aten.slice, aten.cat]
# Source node to ATen node mapping:
#   cat => cat
#   getitem => slice_1
#   getitem_1 => slice_2, slice_3
# Graph fragment:
#   %arg1_1 : Tensor "f8e4m3fn[48, 80][80, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %slice_1 : Tensor "f8e4m3fn[48, 8][80, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg0_1, 1, 0, 8), kwargs = {})
#   %slice_2 : Tensor "f8e4m3fn[17, 80][80, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg1_1, 0, 3, 20), kwargs = {})
#   %slice_3 : Tensor "f8e4m3fn[17, 8][80, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_2, 1, 5, 13), kwargs = {})
#   %cat : Tensor "f8e4m3fn[65, 8][8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%slice_1, %slice_3],), kwargs = {})
#   return %buf1
triton_poi_fused_cat_slice_1 = async_compile.triton('triton_poi_fused_cat_slice_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp8e4nv', 'out_ptr0': '*fp8e4nv', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_slice_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 408}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_slice_1(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 136
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8)
    x1 = xindex // 8
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (245 + x0 + 80*x1), xmask)
    tl.store(out_ptr0 + (x2), tmp0, xmask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        assert_size_stride(arg0_1, (48, 80), (80, 1), 'input')
        buf2 = empty_strided((65, 8), (8, 1), device='tnca', dtype=torch.float8_e4m3fn)
        buf0 = reinterpret_tensor(buf2, (48, 8), (8, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem, getitem_1, cat], Original ATen: [aten.slice, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_slice_0.run(arg0_1, buf0, 384, stream=raw_stream0)
        del arg0_1
        assert_size_stride(arg1_1, (48, 80), (80, 1), 'input')
        buf1 = reinterpret_tensor(buf2, (17, 8), (8, 1), 384)  # alias
        # Topologically Sorted Source Nodes: [getitem, getitem_1, cat], Original ATen: [aten.slice, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_slice_1.run(arg1_1, buf1, 136, stream=raw_stream0)
        del arg1_1
        return (buf2, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((48, 80), (80, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    arg1_1 = rand_strided((48, 80), (80, 1), device='tnca:0', dtype=torch.float8_e4m3fn)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
