#!/bin/bash
cd ~ && rm -rf r41s2-int-logs && mkdir -p r41s2-int-logs
L="bash $HOME/r41s2-int-aux/lane.sh"; P=$HOME/tc_env/torchenv/bin/python; O=tools/performance_harness/systemc/rtl_oracle; A=$HOME/r41s2-int-aux; B=$HOME/r41s2-int-base
setsid nohup $L r41s2-int-a A "make core" "make core-slowmem" "make core-ooo" "make core-vrf" "make core4" "make top" "make r38-xpose-rtl" </dev/null >/dev/null 2>&1 &
setsid nohup $L r41s2-int-b B "make core-r39hw" "make core-r39sw" "make core-r39sw4" </dev/null >/dev/null 2>&1 &
setsid nohup $L r41s2-int-c C "make core-r39sw5" "make r41-core-boundary" </dev/null >/dev/null 2>&1 &
setsid nohup $L r41s2-int-d D "make lsu-reqreg" "make unit" "make fma-deep" "TMPDIR=$A bash $A/miter/run_miter.sh $B/rtl/gen rtl 30000000" "make lint" "$P $O/rtl_oracle.py --root . --out $A/oracle-int --per-op 400" "$P $O/rtl_oracle.py --root $B --out $A/oracle-base --per-op 400" "$P $O/matrix_oracle.py --root . --out $A/mx-int-1 --cases 12 --abuf 1" "$P $O/matrix_oracle.py --root $B --out $A/mx-base-1 --cases 12 --abuf 1" "$P $O/matrix_oracle.py --root . --out $A/mx-int-0 --cases 12 --abuf 0" "$P $O/matrix_oracle.py --root $B --out $A/mx-base-0 --cases 12 --abuf 0" </dev/null >/dev/null 2>&1 &
setsid nohup $L r41s2-int-e E "make r40-multicore-shell" "make r40-line-axi" "make r40-cache-maintenance" "make r40-grid-dispatch" "make r40-multicore-dma" "make r40-coherent-host" "$P tools/r40/multicore_mmio_tests.py --cores 3 --ports 3 --pipeline 2 --board-top" </dev/null >/dev/null 2>&1 &
setsid nohup $L r41s2-int-f F "make compiler-rtl" "make triton-e2e" "make r40-barrier-epoch" "make r40-pipeline-checks" "make r40-core-parameters" </dev/null >/dev/null 2>&1 &
sleep 3; cat r41s2-int-logs/*.lane
