"""Execute only the original frozen harness's CPU reference, without hardware stubs."""
import ast,copy,hashlib,json
from pathlib import Path
from types import SimpleNamespace
import torch
import torch.nn.functional as F
from archbench.models import LLAMA,LlamaPrefill,LlamaDecode
from archbench.ops import gen
from archbench.platforms.common import _to_fp32,ieee_fp32
root=Path.cwd()
source=root/'archbench/generate.py'
main=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='main')
cls=next(n for n in main.body if isinstance(n,ast.ClassDef) and n.name=='PrefillKV')
decoder=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='decoder')
reference=[n for n in main.body if isinstance(n,ast.With) and any(isinstance(x,ast.Name) and x.id=='ref_tokens' for x in ast.walk(n))]
assert len(reference)==1
scope=globals()
exec(compile(ast.Module(body=[cls,decoder],type_ignores=[]),str(source),'exec'),scope)
args=SimpleNamespace(seed=0,new=64)
c,bsz,s,_p=LLAMA['hbm']
g=gen(args.seed)
first=PrefillKV(c,g,'fp16',s).eval()
prompt=torch.randint(0,c.vocab,(bsz,s),generator=g)
weights=first.state_dict()
exec(compile(ast.Module(body=reference,type_ignores=[]),str(source),'exec'),scope)
actual=[t.tolist() for t in ref_tokens]
new=json.loads(Path('/tmp/r40_full_native_model_reference/report.json').read_text())
assert actual==new['reference_tokens'], 'new state wrappers changed the frozen CPU reference prefix'
report=dict(status='reference-only',gate_status='not-measured',performance='not-measured',
            source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
            comparison='original frozen generate.py IEEE fp32 reference block, exact 64-token prefix',
            tokens=actual,reference_top2_margins=margins,
            torch=torch.__version__,python_threads=torch.get_num_threads(),
            new_harness_sha256=new['identity']['harness_sha256'],weight_bytes=new['identity']['weight_bytes'])
Path('/tmp/r40_independent_model_reference.json').write_text(json.dumps(report,indent=2)+'\n')
print('FULL FROZEN CPU REFERENCES MATCH: original 64-token prefix, unchanged model and seed',flush=True)
