module original(input[63:0]cur_addr,input[5:0]cur_lsb,input pol_dbp,input[11:0]cur_own,input cur_we,cur_amo,output value);
    wire [63:0] tlw_mask = ((64'd1 << cur_lsb) - 64'd1) & ~64'd7;
    wire        cur_tlw  = pol_dbp && cur_own[11] && !cur_we && !cur_amo &&
                           (cur_lsb >= 6'd3) && ((cur_addr & tlw_mask) == tlw_mask);
assign value=cur_tlw;
endmodule
module candidate(input[63:0]cur_addr,input[5:0]cur_lsb,input pol_dbp,input[11:0]cur_own,input cur_we,cur_amo,output value);
    // A last-word address has every bit below the granule set, except
    // the three byte-offset bits. Test fixed bit positions directly rather
    // than build (1 << lsb) - 1 with a variable shifter and carry chain.
    wire [63:0] tlw_address = cur_addr;
    wire [59:0] tlw_missing;
    genvar tlw_bit;
    generate for(tlw_bit=3;tlw_bit<63;tlw_bit=tlw_bit+1)begin:g_tlw_predicate
        assign tlw_missing[tlw_bit-3] =
            (cur_lsb > tlw_bit) && !tlw_address[tlw_bit];
    end endgenerate
    wire        cur_tlw  = pol_dbp && cur_own[11] && !cur_we && !cur_amo &&
                           (cur_lsb >= 6'd3) && !(|tlw_missing);
assign value=cur_tlw;
endmodule
module miter(input[63:0]cur_addr,input[5:0]cur_lsb,input pol_dbp,input[11:0]cur_own,input cur_we,cur_amo,output mismatch);
wire before_value,after_value;
original before_dut(cur_addr,cur_lsb,pol_dbp,cur_own,cur_we,cur_amo,before_value);
candidate after_dut(cur_addr,cur_lsb,pol_dbp,cur_own,cur_we,cur_amo,after_value);
assign mismatch=before_value^after_value;
endmodule
