    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    .li       s5, #1124073472
    v.splat      v0, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s2
    v.rcp.approx v3, v0                          // ISA 8.8: <= 2**-22 relative
    v.movi       v4, #0
    v.add        v5, v2, v1
    v.movi       v1, #7
    .li       s5, #1065353216
    v.splat      v2, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v6, v4, v5
    s.add        s5, s3, s4                      // &in_ptr3[...]
    v.cmp.lt     p1, v5, v4
    v.ld.h       v7, [s5, #0]
    @p1 v.sel        v8, v6, v5
    v.movi       v6, #0
    v.movi       v9, #127
    v.lshr       v10, v8, v1
    v.sub        v1, v6, v5
    v.cmp.lt     p2, v5, v6
    v.sub        v8, v4, v10
    @p2 v.sel        v11, v1, v5
    s.shli       s3, s2, #2                      // element offset -> bytes (x4)
    @p1 v.sel        v1, v8, v10
    v.and        v5, v11, v9
    v.movi       v8, #128
    vf.cvt.bf16.f32 v9, v7
    s.ld.d       s2, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.sub        v7, v6, v5
    v.sub        v10, v6, v8
    v.sub        v11, v4, v8
    @p2 v.sel        v12, v7, v5
    vf.fms       v5, v0, v3, v2
    v.cmp.lt     p1, v8, v6
    v.cmp.lt     p2, v8, v4
    @p1 v.sel        v4, v10, v8
    @p2 v.sel        v4, v11, v8
    vf.fms       v4, v3, v5, v3
    v.ld.gather.w v5, [s2, v1]                   // index is in elements (ISA sec 9.1)
    vf.neg       v1, v4                          // Newton step: r0*(2 - x*r0)
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v4, v1, v3
    s.add        s6, s2, s3                      // &in_ptr1[...]
    vf.mul       v1, v5, v4                      // a/y: faithful quotient
    vf.fms       v3, v1, v0, v5
    v.ld.w       v0, [s6, #0]
    v.ld.gather.h v5, [s5, v12]                  // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v6, v5
    s.ld.d       s2, [s1, #32]                   // out_ptr0: device_ptr64 at arg_base+32
    vf.neg       v5, v9
    .li       s1, #1069066811
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1060205080
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v11, v3, v4, v1
    vf.mul       v3, v5, v7
    .li       s1, #897988541
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v12, v11                        // a/y: one correction to the IEEE quotient
    vf.fms       v11, v5, v7, v3                 // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    .li       s1, #1077936128
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s1, s2, s4                      // &out_ptr0[...]
    vf.cmp.o     p1, v12, v12
    vf.mul       v7, v11, v8
    @p1 v.sel        v8, v12, v1
    .li       s2, #3204448256
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v11, v8, v4
    v.rsqrt.approx v4, v11                       // ISA 8.8: <= 2**-22 relative
    vf.fma       v8, v5, v7, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v7, v8, v5
    vf.add       v5, v7, v10
    vf.mul       v7, v4, v4
    v.rcp.approx v8, v5                          // ISA 8.8: <= 2**-22 relative
    vf.mul       v10, v4, v1
    vf.fms       v1, v11, v7, v3
    vf.mul       v3, v10, v1                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    vf.mul       v3, v0, v1
    vf.mul       v0, v6, v3
    vf.fms       v1, v5, v8, v2
    vf.fms       v2, v8, v1, v8
    vf.neg       v1, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v2, v1, v8
    vf.mul       v1, v9, v2                      // a/y: faithful quotient
    vf.fms       v3, v1, v5, v9
    vf.fms       v4, v3, v2, v1
    vf.neg       v2, v4                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v3, v2, v1
    vf.mul       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
