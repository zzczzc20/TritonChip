#!/usr/bin/env python3
"""Explain gated RMSNorm BF16 output from captured CPU/TLM float intermediates."""
import json,sys
from pathlib import Path
import torch
from safetensors.torch import load_file
h=Path.home();tree=h/'r41_q35_multiturn_diag_20261031';sys.path[:0]=[str(tree/'tools/models'),str(tree),str(tree/'python'),str(tree/'compiler/python'),str(tree/'tools/asm')]
import chat
args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1']);app=chat.ChatApplication(args);weight=app.model.model.language_model.layers[0].linear_attn.norm.weight.detach().cpu()
v=load_file(str(h/'r41_q35_gate_parts_tlm_20261031_diag/states.safetensors'));cpu=v['cpu_normalized'];tlm=v['tlm_normalized'];cr=cpu.to(torch.bfloat16);tr=tlm.to(torch.bfloat16);cw=v['cpu_weighted'];tw=v['tlm_weighted'];cpu_pred=weight*cr;tlm_pred=weight*tr
compare=lambda x,y:dict(elements=x.numel(),mismatches=int((x.contiguous().view(torch.int16)!=y.contiguous().view(torch.int16)).sum()))
out={'schema':'r41-q35-gated-norm-rounding/1','scope':'CPU analysis of captured standalone DP TLM intermediate values, not board','weight_dtype':str(weight.dtype),'cpu_vs_tlm_normalized_bf16_cast':compare(cr,tr),'cpu_weight_reconstruction':compare(cw,cpu_pred),'tlm_weight_if_bf16_cast_honored':compare(tw,tlm_pred),'tlm_weight_vs_cpu_weight':compare(tw,cw)}
p=h/'r41_q35_gate_rounding_20261031.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
