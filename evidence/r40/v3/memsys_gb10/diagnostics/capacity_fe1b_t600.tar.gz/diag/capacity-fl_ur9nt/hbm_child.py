
import os, sys
import torch, triton
import tnca.torch_device as D
D.register()
from tnca import device as _device
which = sys.argv[1]
limit = _device.memory_limit(os.environ['TNCA_PROFILE'])
if which == 'samples':
    # One small tensor per step through the window, each with its own values,
    # all written before any is read: a lost high address bit aliases two.
    n_samples, step = 32, (limit - 0x40000) // 32
    held, samples = [], []
    for i in range(n_samples):
        pad = step - 4096
        if pad > 0:
            held.append(torch.empty(pad, dtype=torch.uint8, device='tnca'))
        h = torch.arange(64, dtype=torch.int64) * 1000003 + i * 7919 + (1 << 40)
        samples.append((h, h.to('tnca')))
    addrs = [d.untyped_storage().data_ptr() for _, d in samples]
    bad = [i for i, (h, d) in enumerate(samples) if not torch.equal(d.cpu(), h)]
    assert not bad, f'samples {bad} read back wrong'
    print(f'OK {n_samples} samples from {addrs[0]:#x} to {addrs[-1]:#x} (window end {limit:#x})')
elif which == 'capacity':
    pad = torch.empty(24 << 20, dtype=torch.uint8, device='tnca')
    n = 1 << 15
    a, b = torch.randn(n), torch.randn(n)
    da, db = a.to('tnca'), b.to('tnca')
    f = torch.compile(lambda x, y: (x * 2 + y).sum() + x.abs().max(), fullgraph=True)
    g = torch.compile(lambda x, y: x * 2 + y, fullgraph=True)
    out, red = g(da, db), f(da, db)
    assert torch.allclose(out.cpu(), a * 2 + b), 'pointwise wrong'
    want = (a * 2 + b).sum() + a.abs().max()
    assert abs(red.cpu().item() - want.item()) <= 1e-3 * max(1.0, abs(want.item())), 'reduction wrong'
    lo = min(t.untyped_storage().data_ptr() for t in (da, db, out))
    print(f'OK 3 x {n * 4 >> 10} KiB tensors from {lo:#x}, {lo >> 20} MiB into the device; '
          'pointwise and reduction right')
