    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #3                      // element offset -> bytes (x8)
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #1
    v.movi       v0, #0
    s.add        s6, s3, s2                      // &in_ptr0[...]
    v.movi       v1, #1
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s5
    s.movz       s2, #0
    v.shl        v4, v0, v1
    s.addi       s3, s6, #4
    v.movi       v0, #0
    v.movi       v1, #0
    v.cmp.lt     p1, v2, v3
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.movz       s7, #1024
    s.movz       s8, #16
    s.ld.d       s9, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.ld.d       s10, [s1, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.addi       s1, s2, #0
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s6, v4]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    v.mov        v1, v0
for_1:
    s.cmp.ge     s3, s1, s7
    br.nz        s3, endfor_2
    v.extract    s3, v5, #0
    v.extract    s6, v5, #0
    s.shli       s11, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v3, #0
    v.extract    s12, v3, #0
    s.or         s13, s6, s11
    s.movz       s6, #0
    s.or         s11, s12, s3
    s.movz       s3, #32000
    v.movi       v0, #0
    s.cmp.ge     s12, s13, s6
    v.movi       v4, #0
    s.cmp.lt     s6, s11, s3
    v.insert     v0, s12, #0
    v.movi       v6, #0
    v.insert     v4, s6, #0
    v.movi       v7, #0
    v.cmp.ne     p1, v0, v6
    v.cmp.ne     p2, v4, v7
    s.movz       s3, #1
    p.and        p3, p1, p2
    v.movi       v0, #0
    v.movi       v4, #1
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v7, s3
    @p3 v.sel        v8, v0, v4
    v.splat      v0, s1
    v.cmp.lt     p1, v6, v7
    s.movz       s3, #0
    @p1 v.reduce.or  s6, v8
    v.add        v4, v0, v2
    v.movi       v0, #1024
    s.cmp.eq     s11, s6, s3
    v.cmp.lt     p1, v4, v0
    br.nz        s11, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s3, v5, #0
    s.shli       s6, s3, #32
    v.extract    s3, v3, #0
    s.or         s11, s3, s6
    s.movz       s3, #1024
    v.extract    s6, v4, #0
    s.mul        s12, s11, s3
    s.shli       s3, s6, #32
    v.extract    s6, v4, #1
    s.ashri      s11, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #2
    v.movi       v0, #0
    v.movi       v6, #0
    s.lshri      s13, s12, #32
    v.movi       v7, #0
    v.movi       v8, #0
    s.lshri      s14, s11, #32
    s.ashri      s15, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #3
    v.insert     v0, s12, #0
    v.insert     v6, s13, #0
    v.insert     v7, s11, #0
    v.insert     v8, s14, #0
    s.lshri      s11, s15, #32
    s.ashri      s12, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #4
    v.insert     v7, s15, #1
    v.insert     v8, s11, #1
    s.lshri      s11, s12, #32
    s.ashri      s13, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #5
    v.insert     v7, s12, #2
    v.insert     v8, s11, #2
    s.lshri      s11, s13, #32
    s.ashri      s12, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #6
    v.insert     v7, s13, #3
    v.insert     v8, s11, #3
    s.lshri      s11, s12, #32
    s.ashri      s13, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #7
    v.insert     v7, s12, #4
    v.insert     v8, s11, #4
    s.lshri      s11, s13, #32
    s.ashri      s12, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #8
    v.insert     v7, s13, #5
    v.insert     v8, s11, #5
    s.lshri      s11, s12, #32
    s.ashri      s13, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #9
    v.insert     v7, s12, #6
    v.insert     v8, s11, #6
    s.lshri      s11, s13, #32
    s.ashri      s12, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #10
    v.insert     v7, s13, #7
    v.insert     v8, s11, #7
    s.lshri      s11, s12, #32
    s.ashri      s13, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #11
    v.insert     v7, s12, #8
    v.insert     v8, s11, #8
    s.lshri      s11, s13, #32
    s.ashri      s12, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #12
    v.insert     v7, s13, #9
    v.insert     v8, s11, #9
    s.lshri      s11, s12, #32
    s.ashri      s13, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #13
    v.insert     v7, s12, #10
    v.insert     v8, s11, #10
    s.lshri      s11, s13, #32
    s.ashri      s12, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #14
    v.insert     v7, s13, #11
    v.insert     v8, s11, #11
    s.lshri      s11, s12, #32
    s.ashri      s13, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v4, #15
    v.extract    s14, v6, #0
    v.insert     v7, s12, #12
    v.insert     v8, s11, #12
    s.lshri      s11, s13, #32
    s.ashri      s12, s3, #32
    s.shli       s3, s6, #32
    s.shli       s6, s14, #32
    v.extract    s14, v0, #0
    v.extract    s15, v6, #0
    v.insert     v7, s13, #13
    v.insert     v8, s11, #13
    s.lshri      s11, s12, #32
    s.ashri      s13, s3, #32
    s.or         s3, s14, s6
    s.shli       s6, s15, #32
    v.extract    s14, v0, #0
    v.extract    s15, v6, #0
    v.insert     v7, s12, #14
    v.insert     v8, s11, #14
    s.lshri      s11, s13, #32
    v.movi       v4, #0
    v.movi       v9, #0
    s.lshri      s12, s3, #32
    s.or         s16, s14, s6
    s.shli       s6, s15, #32
    v.extract    s14, v0, #0
    v.insert     v7, s13, #15
    v.extract    s13, v6, #0
    v.insert     v8, s11, #15
    v.insert     v4, s3, #0
    v.insert     v9, s12, #0
    s.lshri      s3, s16, #32
    s.or         s11, s14, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.extract    s13, v6, #0
    v.insert     v4, s16, #1
    v.insert     v9, s3, #1
    s.lshri      s3, s11, #32
    s.or         s14, s12, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.extract    s13, v6, #0
    v.insert     v4, s11, #2
    v.insert     v9, s3, #2
    s.lshri      s3, s14, #32
    s.or         s11, s12, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.extract    s13, v6, #0
    v.insert     v4, s14, #3
    v.insert     v9, s3, #3
    s.lshri      s3, s11, #32
    s.or         s14, s12, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.extract    s13, v6, #0
    v.insert     v4, s11, #4
    v.insert     v9, s3, #4
    s.lshri      s3, s14, #32
    s.or         s11, s12, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.extract    s13, v6, #0
    v.insert     v4, s14, #5
    v.insert     v9, s3, #5
    s.lshri      s3, s11, #32
    s.or         s14, s12, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.extract    s13, v6, #0
    v.insert     v4, s11, #6
    v.insert     v9, s3, #6
    s.lshri      s3, s14, #32
    s.or         s11, s12, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.extract    s13, v6, #0
    v.insert     v4, s14, #7
    v.insert     v9, s3, #7
    s.lshri      s3, s11, #32
    s.or         s14, s12, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.extract    s13, v6, #0
    v.insert     v4, s11, #8
    v.insert     v9, s3, #8
    s.lshri      s3, s14, #32
    s.or         s11, s12, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.extract    s13, v6, #0
    v.insert     v4, s14, #9
    v.insert     v9, s3, #9
    s.lshri      s3, s11, #32
    s.or         s14, s12, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.extract    s13, v6, #0
    v.insert     v4, s11, #10
    v.insert     v9, s3, #10
    s.lshri      s3, s14, #32
    s.or         s11, s12, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.extract    s13, v6, #0
    v.insert     v4, s14, #11
    v.insert     v9, s3, #11
    s.lshri      s3, s11, #32
    s.or         s14, s12, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.extract    s13, v6, #0
    v.insert     v4, s11, #12
    v.insert     v9, s3, #12
    s.lshri      s3, s14, #32
    s.or         s11, s12, s6
    s.shli       s6, s13, #32
    v.extract    s12, v0, #0
    v.insert     v4, s14, #13
    v.insert     v9, s3, #13
    s.lshri      s3, s11, #32
    s.or         s13, s12, s6
    v.insert     v4, s11, #14
    v.insert     v9, s3, #14
    s.lshri      s3, s13, #32
    v.insert     v4, s13, #15
    v.insert     v9, s3, #15
    v.extract    s3, v8, #0
    v.extract    s6, v9, #0
    s.shli       s11, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v7, #0
    v.extract    s12, v4, #0
    v.extract    s13, v8, #1
    v.extract    s14, v9, #1
    s.or         s15, s6, s11
    s.or         s6, s12, s3
    s.shli       s3, s13, #32
    s.shli       s11, s14, #32
    v.extract    s12, v7, #1
    v.extract    s13, v4, #1
    v.extract    s14, v8, #2
    v.movi       v0, #0
    s.add        s16, s15, s6
    v.extract    s6, v9, #2
    s.or         s15, s12, s3
    s.or         s3, s13, s11
    s.shli       s11, s14, #32
    s.shli       s12, s6, #32
    v.extract    s6, v7, #2
    v.extract    s13, v4, #2
    v.movi       v6, #0
    v.insert     v0, s16, #0
    s.lshri      s14, s16, #32
    s.add        s16, s15, s3
    v.extract    s3, v8, #3
    s.or         s15, s6, s11
    v.extract    s6, v9, #3
    s.or         s11, s13, s12
    s.shli       s12, s3, #32
    s.shli       s3, s6, #32
    v.extract    s6, v7, #3
    v.insert     v6, s14, #0
    v.extract    s13, v4, #3
    v.insert     v0, s16, #1
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v8, #4
    s.or         s15, s6, s12
    v.extract    s6, v9, #4
    s.or         s12, s13, s3
    s.shli       s3, s11, #32
    s.shli       s11, s6, #32
    v.extract    s6, v7, #4
    v.insert     v6, s14, #1
    v.extract    s13, v4, #4
    v.insert     v0, s16, #2
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v8, #5
    s.or         s15, s6, s3
    v.extract    s3, v9, #5
    s.or         s6, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s3, #32
    v.extract    s3, v7, #5
    v.insert     v6, s14, #2
    v.extract    s13, v4, #5
    v.insert     v0, s16, #3
    s.lshri      s14, s16, #32
    s.add        s16, s15, s6
    v.extract    s6, v8, #6
    s.or         s15, s3, s11
    v.extract    s3, v9, #6
    s.or         s11, s13, s12
    s.shli       s12, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v7, #6
    v.insert     v6, s14, #3
    v.extract    s13, v4, #6
    v.insert     v0, s16, #4
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v8, #7
    s.or         s15, s3, s12
    v.extract    s3, v9, #7
    s.or         s12, s13, s6
    s.shli       s6, s11, #32
    s.shli       s11, s3, #32
    v.extract    s3, v7, #7
    v.insert     v6, s14, #4
    v.extract    s13, v4, #7
    v.insert     v0, s16, #5
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v8, #8
    s.or         s15, s3, s6
    v.extract    s3, v9, #8
    s.or         s6, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s3, #32
    v.extract    s3, v7, #8
    v.insert     v6, s14, #5
    v.extract    s13, v4, #8
    v.insert     v0, s16, #6
    s.lshri      s14, s16, #32
    s.add        s16, s15, s6
    v.extract    s6, v8, #9
    s.or         s15, s3, s11
    v.extract    s3, v9, #9
    s.or         s11, s13, s12
    s.shli       s12, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v7, #9
    v.insert     v6, s14, #6
    v.extract    s13, v4, #9
    v.insert     v0, s16, #7
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v8, #10
    s.or         s15, s3, s12
    v.extract    s3, v9, #10
    s.or         s12, s13, s6
    s.shli       s6, s11, #32
    s.shli       s11, s3, #32
    v.extract    s3, v7, #10
    v.insert     v6, s14, #7
    v.extract    s13, v4, #10
    v.insert     v0, s16, #8
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v8, #11
    s.or         s15, s3, s6
    v.extract    s3, v9, #11
    s.or         s6, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s3, #32
    v.extract    s3, v7, #11
    v.insert     v6, s14, #8
    v.extract    s13, v4, #11
    v.insert     v0, s16, #9
    s.lshri      s14, s16, #32
    s.add        s16, s15, s6
    v.extract    s6, v8, #12
    s.or         s15, s3, s11
    v.extract    s3, v9, #12
    s.or         s11, s13, s12
    s.shli       s12, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v7, #12
    v.insert     v6, s14, #9
    v.extract    s13, v4, #12
    v.insert     v0, s16, #10
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    v.extract    s11, v8, #13
    s.or         s15, s3, s12
    v.extract    s3, v9, #13
    s.or         s12, s13, s6
    s.shli       s6, s11, #32
    s.shli       s11, s3, #32
    v.extract    s3, v7, #13
    v.insert     v6, s14, #10
    v.extract    s13, v4, #13
    v.insert     v0, s16, #11
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v8, #14
    s.or         s15, s3, s6
    v.extract    s3, v9, #14
    s.or         s6, s13, s11
    s.shli       s11, s12, #32
    s.shli       s12, s3, #32
    v.extract    s3, v7, #14
    v.insert     v6, s14, #11
    v.extract    s13, v4, #14
    v.insert     v0, s16, #12
    s.lshri      s14, s16, #32
    s.add        s16, s15, s6
    v.extract    s6, v8, #15
    s.or         s15, s3, s11
    v.extract    s3, v9, #15
    s.or         s11, s13, s12
    s.shli       s12, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v7, #15
    v.insert     v6, s14, #12
    v.extract    s13, v4, #15
    v.insert     v0, s16, #13
    s.lshri      s14, s16, #32
    s.add        s16, s15, s11
    s.or         s11, s3, s12
    s.or         s3, s13, s6
    v.insert     v6, s14, #13
    v.insert     v0, s16, #14
    s.lshri      s6, s16, #32
    s.add        s12, s11, s3
    v.insert     v6, s6, #14
    v.insert     v0, s12, #15
    s.lshri      s3, s12, #32
    v.movi       v4, #31
    v.insert     v6, s3, #15
    v.ashr       v7, v0, v4
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.ne     p2, v6, v7
    @p2 v.sel        v6, v4, v8
    s.movz       s3, #0
    v.reduce.or  s6, v6
    s.cmp.eq     s11, s6, s3
    br.nz        s11, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v4, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.movi       v0, #0
    s.add        s3, s1, s8
    s.movz       s6, #1
    vf.cvt.f16.f32 v6, v4
    vf.mul       v4, v6, v6
    vf.add       v6, v1, v4
    @p1 v.sel        v4, v6, v1
    v.mov        v0, v4
    v.mov        v1, v0
    s.mov        s1, s3
    br.nz        s6, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s1, s2, #0
    vf.add       v4, v0, v1
for_5:
    s.cmp.ge     s2, s1, s7
    br.nz        s2, endfor_6
    v.extract    s2, v5, #0
    v.extract    s3, v5, #0
    s.shli       s6, s2, #32
    s.shli       s2, s3, #32
    v.splat      v0, s1
    v.extract    s3, v3, #0
    v.extract    s11, v3, #0
    s.shli       s12, s1, #1                     // element offset -> bytes (x2)
    s.or         s13, s3, s6
    s.movz       s3, #0
    s.or         s6, s11, s2
    s.movz       s2, #32000
    v.add        v1, v0, v2
    v.movi       v0, #1024
    s.add        s11, s9, s12                    // &in_ptr2[...]
    v.movi       v6, #0
    s.cmp.ge     s12, s13, s3
    v.movi       v7, #0
    s.cmp.lt     s3, s6, s2
    v.cmp.lt     p1, v1, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s11, #0]
    v.insert     v6, s12, #0
    v.movi       v8, #0
    v.insert     v7, s3, #0
    v.movi       v9, #0
    v.cmp.ne     p2, v6, v8
    v.cmp.ne     p3, v7, v9
    s.movz       s2, #1
    p.and        p4, p2, p3
    v.movi       v6, #0
    v.movi       v7, #1
    v.iota       v8                              // arange(0, VLEN)
    v.splat      v9, s2
    @p4 v.sel        v10, v6, v7
    v.cmp.lt     p2, v8, v9
    s.movz       s2, #0
    @p2 v.reduce.or  s3, v10
    s.cmp.eq     s6, s3, s2
    vf.cvt.f16.f32 v6, v0
    br.nz        s6, assert_ok_7
    trap         #677351
assert_ok_7:
    v.extract    s2, v5, #0
    s.shli       s3, s2, #32
    v.extract    s2, v3, #0
    s.or         s6, s2, s3
    s.movz       s2, #1024
    v.extract    s3, v1, #0
    s.mul        s11, s6, s2
    s.shli       s2, s3, #32
    v.extract    s3, v1, #1
    s.ashri      s6, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #2
    v.movi       v0, #0
    v.movi       v7, #0
    s.lshri      s12, s11, #32
    v.movi       v8, #0
    v.movi       v9, #0
    s.lshri      s13, s6, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #3
    v.insert     v0, s11, #0
    v.insert     v7, s12, #0
    v.insert     v8, s6, #0
    v.insert     v9, s13, #0
    s.lshri      s6, s14, #32
    s.ashri      s11, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #4
    v.insert     v8, s14, #1
    v.insert     v9, s6, #1
    s.lshri      s6, s11, #32
    s.ashri      s12, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #5
    v.insert     v8, s11, #2
    v.insert     v9, s6, #2
    s.lshri      s6, s12, #32
    s.ashri      s11, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #6
    v.insert     v8, s12, #3
    v.insert     v9, s6, #3
    s.lshri      s6, s11, #32
    s.ashri      s12, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #7
    v.insert     v8, s11, #4
    v.insert     v9, s6, #4
    s.lshri      s6, s12, #32
    s.ashri      s11, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #8
    v.insert     v8, s12, #5
    v.insert     v9, s6, #5
    s.lshri      s6, s11, #32
    s.ashri      s12, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #9
    v.insert     v8, s11, #6
    v.insert     v9, s6, #6
    s.lshri      s6, s12, #32
    s.ashri      s11, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #10
    v.insert     v8, s12, #7
    v.insert     v9, s6, #7
    s.lshri      s6, s11, #32
    s.ashri      s12, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #11
    v.insert     v8, s11, #8
    v.insert     v9, s6, #8
    s.lshri      s6, s12, #32
    s.ashri      s11, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #12
    v.insert     v8, s12, #9
    v.insert     v9, s6, #9
    s.lshri      s6, s11, #32
    s.ashri      s12, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #13
    v.insert     v8, s11, #10
    v.insert     v9, s6, #10
    s.lshri      s6, s12, #32
    s.ashri      s11, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #14
    v.insert     v8, s12, #11
    v.insert     v9, s6, #11
    s.lshri      s6, s11, #32
    s.ashri      s12, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v1, #15
    v.extract    s13, v7, #0
    v.insert     v8, s11, #12
    v.insert     v9, s6, #12
    s.lshri      s6, s12, #32
    s.ashri      s11, s2, #32
    s.shli       s2, s3, #32
    s.shli       s3, s13, #32
    v.extract    s13, v0, #0
    v.extract    s14, v7, #0
    v.insert     v8, s12, #13
    v.insert     v9, s6, #13
    s.lshri      s6, s11, #32
    s.ashri      s12, s2, #32
    s.or         s2, s13, s3
    s.shli       s3, s14, #32
    v.extract    s13, v0, #0
    v.extract    s14, v7, #0
    v.insert     v8, s11, #14
    v.insert     v9, s6, #14
    s.lshri      s6, s12, #32
    v.movi       v10, #0
    v.movi       v11, #0
    s.lshri      s11, s2, #32
    s.or         s15, s13, s3
    s.shli       s3, s14, #32
    v.extract    s13, v0, #0
    v.insert     v8, s12, #15
    v.extract    s12, v7, #0
    v.insert     v9, s6, #15
    v.insert     v10, s2, #0
    v.insert     v11, s11, #0
    s.lshri      s2, s15, #32
    s.or         s6, s13, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.extract    s12, v7, #0
    v.insert     v10, s15, #1
    v.insert     v11, s2, #1
    s.lshri      s2, s6, #32
    s.or         s13, s11, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.extract    s12, v7, #0
    v.insert     v10, s6, #2
    v.insert     v11, s2, #2
    s.lshri      s2, s13, #32
    s.or         s6, s11, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.extract    s12, v7, #0
    v.insert     v10, s13, #3
    v.insert     v11, s2, #3
    s.lshri      s2, s6, #32
    s.or         s13, s11, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.extract    s12, v7, #0
    v.insert     v10, s6, #4
    v.insert     v11, s2, #4
    s.lshri      s2, s13, #32
    s.or         s6, s11, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.extract    s12, v7, #0
    v.insert     v10, s13, #5
    v.insert     v11, s2, #5
    s.lshri      s2, s6, #32
    s.or         s13, s11, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.extract    s12, v7, #0
    v.insert     v10, s6, #6
    v.insert     v11, s2, #6
    s.lshri      s2, s13, #32
    s.or         s6, s11, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.extract    s12, v7, #0
    v.insert     v10, s13, #7
    v.insert     v11, s2, #7
    s.lshri      s2, s6, #32
    s.or         s13, s11, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.extract    s12, v7, #0
    v.insert     v10, s6, #8
    v.insert     v11, s2, #8
    s.lshri      s2, s13, #32
    s.or         s6, s11, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.extract    s12, v7, #0
    v.insert     v10, s13, #9
    v.insert     v11, s2, #9
    s.lshri      s2, s6, #32
    s.or         s13, s11, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.extract    s12, v7, #0
    v.insert     v10, s6, #10
    v.insert     v11, s2, #10
    s.lshri      s2, s13, #32
    s.or         s6, s11, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.extract    s12, v7, #0
    v.insert     v10, s13, #11
    v.insert     v11, s2, #11
    s.lshri      s2, s6, #32
    s.or         s13, s11, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.extract    s12, v7, #0
    v.insert     v10, s6, #12
    v.insert     v11, s2, #12
    s.lshri      s2, s13, #32
    s.or         s6, s11, s3
    s.shli       s3, s12, #32
    v.extract    s11, v0, #0
    v.insert     v10, s13, #13
    v.insert     v11, s2, #13
    s.lshri      s2, s6, #32
    s.or         s12, s11, s3
    v.insert     v10, s6, #14
    v.insert     v11, s2, #14
    s.lshri      s2, s12, #32
    v.insert     v10, s12, #15
    v.insert     v11, s2, #15
    v.extract    s2, v9, #0
    v.extract    s3, v11, #0
    s.shli       s6, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v8, #0
    v.extract    s11, v10, #0
    v.extract    s12, v9, #1
    v.extract    s13, v11, #1
    s.or         s14, s3, s6
    s.or         s3, s11, s2
    s.shli       s2, s12, #32
    s.shli       s6, s13, #32
    v.extract    s11, v8, #1
    v.extract    s12, v10, #1
    v.extract    s13, v9, #2
    v.movi       v0, #0
    s.add        s15, s14, s3
    v.extract    s3, v11, #2
    s.or         s14, s11, s2
    s.or         s2, s12, s6
    s.shli       s6, s13, #32
    s.shli       s11, s3, #32
    v.extract    s3, v8, #2
    v.extract    s12, v10, #2
    v.movi       v7, #0
    v.insert     v0, s15, #0
    s.lshri      s13, s15, #32
    s.add        s15, s14, s2
    v.extract    s2, v9, #3
    s.or         s14, s3, s6
    v.extract    s3, v11, #3
    s.or         s6, s12, s11
    s.shli       s11, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v8, #3
    v.insert     v7, s13, #0
    v.extract    s12, v10, #3
    v.insert     v0, s15, #1
    s.lshri      s13, s15, #32
    s.add        s15, s14, s6
    v.extract    s6, v9, #4
    s.or         s14, s3, s11
    v.extract    s3, v11, #4
    s.or         s11, s12, s2
    s.shli       s2, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v8, #4
    v.insert     v7, s13, #1
    v.extract    s12, v10, #4
    v.insert     v0, s15, #2
    s.lshri      s13, s15, #32
    s.add        s15, s14, s11
    v.extract    s11, v9, #5
    s.or         s14, s3, s2
    v.extract    s2, v11, #5
    s.or         s3, s12, s6
    s.shli       s6, s11, #32
    s.shli       s11, s2, #32
    v.extract    s2, v8, #5
    v.insert     v7, s13, #2
    v.extract    s12, v10, #5
    v.insert     v0, s15, #3
    s.lshri      s13, s15, #32
    s.add        s15, s14, s3
    v.extract    s3, v9, #6
    s.or         s14, s2, s6
    v.extract    s2, v11, #6
    s.or         s6, s12, s11
    s.shli       s11, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v8, #6
    v.insert     v7, s13, #3
    v.extract    s12, v10, #6
    v.insert     v0, s15, #4
    s.lshri      s13, s15, #32
    s.add        s15, s14, s6
    v.extract    s6, v9, #7
    s.or         s14, s2, s11
    v.extract    s2, v11, #7
    s.or         s11, s12, s3
    s.shli       s3, s6, #32
    s.shli       s6, s2, #32
    v.extract    s2, v8, #7
    v.insert     v7, s13, #4
    v.extract    s12, v10, #7
    v.insert     v0, s15, #5
    s.lshri      s13, s15, #32
    s.add        s15, s14, s11
    v.extract    s11, v9, #8
    s.or         s14, s2, s3
    v.extract    s2, v11, #8
    s.or         s3, s12, s6
    s.shli       s6, s11, #32
    s.shli       s11, s2, #32
    v.extract    s2, v8, #8
    v.insert     v7, s13, #5
    v.extract    s12, v10, #8
    v.insert     v0, s15, #6
    s.lshri      s13, s15, #32
    s.add        s15, s14, s3
    v.extract    s3, v9, #9
    s.or         s14, s2, s6
    v.extract    s2, v11, #9
    s.or         s6, s12, s11
    s.shli       s11, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v8, #9
    v.insert     v7, s13, #6
    v.extract    s12, v10, #9
    v.insert     v0, s15, #7
    s.lshri      s13, s15, #32
    s.add        s15, s14, s6
    v.extract    s6, v9, #10
    s.or         s14, s2, s11
    v.extract    s2, v11, #10
    s.or         s11, s12, s3
    s.shli       s3, s6, #32
    s.shli       s6, s2, #32
    v.extract    s2, v8, #10
    v.insert     v7, s13, #7
    v.extract    s12, v10, #10
    v.insert     v0, s15, #8
    s.lshri      s13, s15, #32
    s.add        s15, s14, s11
    v.extract    s11, v9, #11
    s.or         s14, s2, s3
    v.extract    s2, v11, #11
    s.or         s3, s12, s6
    s.shli       s6, s11, #32
    s.shli       s11, s2, #32
    v.extract    s2, v8, #11
    v.insert     v7, s13, #8
    v.extract    s12, v10, #11
    v.insert     v0, s15, #9
    s.lshri      s13, s15, #32
    s.add        s15, s14, s3
    v.extract    s3, v9, #12
    s.or         s14, s2, s6
    v.extract    s2, v11, #12
    s.or         s6, s12, s11
    s.shli       s11, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v8, #12
    v.insert     v7, s13, #9
    v.extract    s12, v10, #12
    v.insert     v0, s15, #10
    s.lshri      s13, s15, #32
    s.add        s15, s14, s6
    v.extract    s6, v9, #13
    s.or         s14, s2, s11
    v.extract    s2, v11, #13
    s.or         s11, s12, s3
    s.shli       s3, s6, #32
    s.shli       s6, s2, #32
    v.extract    s2, v8, #13
    v.insert     v7, s13, #10
    v.extract    s12, v10, #13
    v.insert     v0, s15, #11
    s.lshri      s13, s15, #32
    s.add        s15, s14, s11
    v.extract    s11, v9, #14
    s.or         s14, s2, s3
    v.extract    s2, v11, #14
    s.or         s3, s12, s6
    s.shli       s6, s11, #32
    s.shli       s11, s2, #32
    v.extract    s2, v8, #14
    v.insert     v7, s13, #11
    v.extract    s12, v10, #14
    v.insert     v0, s15, #12
    s.lshri      s13, s15, #32
    s.add        s15, s14, s3
    v.extract    s3, v9, #15
    s.or         s14, s2, s6
    v.extract    s2, v11, #15
    s.or         s6, s12, s11
    s.shli       s11, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v8, #15
    v.insert     v7, s13, #12
    v.extract    s12, v10, #15
    v.insert     v0, s15, #13
    s.lshri      s13, s15, #32
    s.add        s15, s14, s6
    s.or         s6, s2, s11
    s.or         s2, s12, s3
    v.insert     v7, s13, #13
    v.insert     v0, s15, #14
    s.lshri      s3, s15, #32
    s.add        s11, s6, s2
    v.insert     v7, s3, #14
    v.insert     v0, s11, #15
    s.lshri      s2, s11, #32
    v.movi       v8, #31
    v.insert     v7, s2, #15
    v.ashr       v9, v0, v8
    v.movi       v8, #1
    v.movi       v10, #0
    v.cmp.ne     p2, v7, v9
    @p2 v.sel        v7, v8, v10
    s.movz       s2, #0
    v.reduce.or  s3, v7
    s.cmp.eq     s6, s3, s2
    br.nz        s6, narrow_ok_8
    trap         #677220
narrow_ok_8:
    .li       s2, #1149239296
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v9, v7                          // ISA 8.8: <= 2**-22 relative
    .li       s2, #925353388
    v.splat      v10, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1077936128
    v.splat      v11, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v12, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v13, [s5, v0]              // index is in elements (ISA sec 9.1)
    s.mul        s2, s4, s7
    s.add        s3, s1, s8
    s.movz       s6, #1
    vf.cvt.f16.f32 v0, v13
    s.add        s11, s1, s2
    v.splat      v13, s2
    s.shli       s2, s11, #1                     // element offset -> bytes (x2)
    v.add        v14, v1, v13
    s.add        s11, s10, s2                    // &out_ptr1[...]
    vf.fms       v1, v7, v9, v8
    vf.fms       v7, v9, v1, v9
    vf.neg       v1, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v7, v1, v9
    vf.mul       v1, v4, v7                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v7, v1, v10
    v.rsqrt.approx v1, v7                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v1, v1
    vf.mul       v9, v1, v12
    vf.fms       v10, v7, v8, v11
    vf.mul       v7, v9, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v7, v7
    @p2 v.sel        v8, v7, v1
    v.extract    s2, v8, #0
    v.splat      v1, s2
    vf.mul       v7, v0, v1
    vf.mul       v0, v7, v6
    vf.cvt.f32.f16 v1, v0
    @p1 v.st.h       [s11, #0], v1
    s.mov        s1, s3
    br.nz        s6, for_5
endfor_6:
__rctx_next:
    exit
