import concurrent.futures,hashlib,json,os,sys
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(Path.home()/'tnca_srcR40convergence_8abf527/tools/r1'))
import r1lib as R
manifest=root/'input/experiment.json';identity=json.loads(manifest.read_text())
def verify():
 for name,digest in identity['input_sha256'].items():
  if hashlib.sha256((root/'input'/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('input changed: '+name)
verify()
report=dict(schema='tnca-joint-ooc-run/1',status='running',pid=os.getpid(),per_variant_timeout_seconds=1800,
 experiment_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 supervisor_sha256=hashlib.sha256(Path(R.__file__).read_bytes()).hexdigest(),results=[],gate_status='not-measured')
path=root/'run.json';path.write_text(json.dumps(report,indent=2)+'\n')
def run(name,mode):
 work=root/name;work.mkdir(exist_ok=False)
 print('START '+name+' mode='+str(mode),flush=True)
 result=R.run_step(['bash',str(root/'run_variant.sh'),str(root),name,str(mode)],kind='build',case_dir=str(work),cwd=str(work),name='vivado',cap_seconds=1800)
 print(name+' '+result['status'],flush=True)
 return dict(variant=name,mode=mode,step=dict(result))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
 futures=[executor.submit(run,name,mode) for name,mode in identity['variants'].items()]
 for future in concurrent.futures.as_completed(futures):
  report['results'].append(future.result());path.write_text(json.dumps(report,indent=2)+'\n')
verify()
passed=all(r['step']['status']==R.PASS for r in report['results'])
report['status']='complete-diagnostic' if passed else 'incomplete-or-fail';path.write_text(json.dumps(report,indent=2)+'\n')
(root/'experiment.exit').write_text(str(int(not passed))+'\n')
