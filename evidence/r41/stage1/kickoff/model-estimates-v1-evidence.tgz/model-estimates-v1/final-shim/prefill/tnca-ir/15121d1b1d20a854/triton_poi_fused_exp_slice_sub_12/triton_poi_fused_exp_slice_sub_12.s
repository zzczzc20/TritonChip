    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #6
    v.add        v4, v1, v0
    s.rdspecial  s2, arg_base
    v.movi       v0, #64
    v.sub        v1, v2, v4
    v.cmp.lt     p1, v4, v2
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v5, v1, v4
    v.movi       v1, #63
    v.movi       v6, #2048
    v.lshr       v7, v5, v3
    s.shli       s4, s1, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p2, v4, v6
    v.sub        v3, v2, v7
    .li       s1, #1069066811
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1060205080
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v6, v3, v7
    s.add        s1, s3, s4                      // &in_ptr0[...]
    s.ld.d       s5, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.mul        v3, v6, v0
    v.sub        v6, v2, v0
    v.cmp.lt     p1, v0, v2
    v.add        v2, v3, v1
    @p1 v.sel        v1, v6, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v0, [s3, v2]               // index is in elements (ISA sec 9.1)
    s.add        s3, s5, s4                      // &out_ptr0[...]
    @p2 v.ld.w       v1, [s1, #0]
    vf.sub       v2, v0, v1
    vf.mul       v0, v1, v4
    s.ld.d       s1, [s2, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    vf.mul       v3, v2, v4
    v.exp2.approx v6, v0                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v1, v4, v0                  // the exact rounding error of x*log2(e)
    v.exp2.approx v0, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v1, v2, v4, v3                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v7, v5
    s.ld.d       s5, [s2, #24]                   // out_ptr2: device_ptr64 at arg_base+24
    s.add        s2, s1, s4                      // &out_ptr1[...]
    vf.mul       v3, v1, v5
    s.add        s1, s5, s4                      // &out_ptr2[...]
    vf.fma       v1, v6, v2, v6                  // 2**t * 2**d
    vf.fma       v2, v0, v3, v0                  // 2**t * 2**d
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v3, v1, v6
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v0
    @p2 v.st.w       [s3, #0], v1
    @p2 v.st.w       [s2, #0], v3
    @p2 v.st.w       [s1, #0], v3
__rctx_next:
    exit
