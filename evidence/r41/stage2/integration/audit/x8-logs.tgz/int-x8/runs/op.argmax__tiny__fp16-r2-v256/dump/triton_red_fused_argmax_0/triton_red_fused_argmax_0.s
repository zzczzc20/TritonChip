    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    .li       s3, #4286578688
    v.splat      v0, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    .li       s3, #2147483647
    v.splat      v2, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #256
    s.movz       s6, #16
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.splat      v4, s4
    v.iota       v4                              // arange(0, VLEN)
    s.addi       s1, s2, #0
    v.mov        v1, v0
    v.mov        v3, v2
for_1:
    s.cmp.ge     s2, s1, s5
    br.nz        s2, endfor_2
    s.mul        s2, s4, s5
    v.splat      v0, s1
    v.movi       v2, #256
    v.add        v5, v0, v4
    v.movi       v0, #-1
    s.add        s8, s1, s2
    v.cmp.lt     p1, v5, v2
    s.shli       s9, s8, #1                      // element offset -> bytes (x2)
    v.movi       v2, #0
    s.add        s8, s3, s9                      // &in_ptr0[...]
    vf.cmp.ne    p2, v1, v1
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s8, #0]
    v.cmp.ne     p3, v0, v2
    v.cmp.lt     p4, v3, v5
    v.movi       v0, #0
    v.movi       v2, #0
    v.splat      v7, s2
    vf.cvt.f16.f32 v8, v6
    s.add        s2, s1, s6
    s.movz       s8, #1
    v.add        v6, v5, v7
    vf.cmp.ne    p5, v8, v8
    p.xor        p6, p5, p3
    p.and        p3, p2, p5
    vf.cmp.eq    p5, v1, v8
    p.and        p7, p2, p6
    p.or         p2, p5, p3
    vf.cmp.gt    p3, v1, v8
    p.or         p5, p3, p7
    p.and        p3, p2, p4
    p.or         p2, p5, p3
    @p2 v.sel        v6, v1, v8
    @p2 v.sel        v7, v3, v5
    @p1 v.sel        v5, v6, v1
    @p1 v.sel        v6, v7, v3
    v.mov        v0, v5
    v.mov        v2, v6
    v.mov        v1, v0
    v.mov        v3, v2
    s.mov        s1, s2
    br.nz        s8, for_1
endfor_2:
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v0, s1
    v.splat      v2, s2
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v4, s1
    v.splat      v5, s2
    v.extract    s1, v1, #2
    v.splat      v6, s1
    v.extract    s1, v3, #2
    v.splat      v7, s1
    v.extract    s1, v1, #3
    v.splat      v8, s1
    v.extract    s1, v3, #3
    v.splat      v9, s1
    v.extract    s1, v1, #4
    v.splat      v10, s1
    v.extract    s1, v3, #4
    v.splat      v11, s1
    v.extract    s1, v1, #5
    v.splat      v12, s1
    v.extract    s1, v3, #5
    v.splat      v13, s1
    v.extract    s1, v1, #6
    v.splat      v14, s1
    v.extract    s1, v3, #6
    v.splat      v15, s1
    v.extract    s1, v1, #7
    v.splat      v16, s1
    v.extract    s1, v3, #7
    v.splat      v17, s1
    v.extract    s1, v1, #8
    vf.cmp.gt    p1, v0, v2
    v.splat      v18, s1
    vf.cmp.eq    p2, v0, v2
    v.extract    s1, v3, #8
    v.splat      v19, s1
    v.extract    s1, v1, #9
    vf.cmp.ne    p3, v0, v0
    v.splat      v20, s1
    vf.cmp.ne    p4, v2, v2
    v.extract    s1, v3, #9
    v.splat      v21, s1
    v.extract    s1, v1, #10
    .li       s2, #-1
    v.splat      v22, s1
    v.splat      v23, s2
    v.extract    s1, v3, #10
    v.splat      v24, s1
    v.extract    s1, v1, #11
    v.movi       v25, #0
    v.splat      v26, s1
    v.cmp.ne     p5, v23, v25
    v.extract    s1, v3, #11
    v.splat      v23, s1
    v.extract    s1, v1, #12
    p.xor        p6, p4, p5
    v.splat      v25, s1
    p.and        p5, p3, p6
    v.extract    s1, v3, #12
    v.splat      v27, s1
    v.extract    s1, v1, #13
    p.or         p6, p1, p5
    v.splat      v28, s1
    p.and        p1, p3, p4
    v.extract    s1, v3, #13
    v.splat      v29, s1
    v.extract    s1, v1, #14
    p.or         p3, p2, p1
    v.splat      v30, s1
    v.cmp.lt     p1, v4, v5
    v.extract    s1, v3, #14
    v.splat      v31, s1
    v.extract    s1, v1, #15
    p.and        p2, p3, p1
    v.splat      v1, s1
    p.or         p1, p6, p2
    v.splat      v32, s2
    @p1 v.sel        v33, v0, v2
    v.movi       v0, #0
    vf.cmp.ne    p2, v33, v33
    vf.cmp.ne    p3, v6, v6
    v.cmp.ne     p4, v32, v0
    p.xor        p5, p3, p4
    p.and        p4, p2, p3
    @p1 v.sel        v0, v4, v5
    vf.cmp.eq    p1, v33, v6
    p.and        p3, p2, p5
    p.or         p2, p1, p4
    vf.cmp.gt    p1, v33, v6
    v.cmp.lt     p4, v0, v7
    p.or         p5, p1, p3
    p.and        p1, p2, p4
    v.splat      v2, s2
    p.or         p2, p5, p1
    v.movi       v4, #0
    @p2 v.sel        v5, v33, v6
    vf.cmp.ne    p1, v8, v8
    vf.cmp.ne    p3, v5, v5
    v.cmp.ne     p4, v2, v4
    p.xor        p5, p1, p4
    p.and        p4, p3, p1
    @p2 v.sel        v2, v0, v7
    vf.cmp.eq    p1, v5, v8
    p.and        p2, p3, p5
    vf.cmp.gt    p3, v5, v8
    p.or         p5, p3, p2
    v.extract    s1, v3, #15
    p.or         p2, p1, p4
    v.splat      v0, s1
    v.cmp.lt     p1, v2, v9
    p.and        p3, p2, p1
    v.splat      v3, s2
    p.or         p1, p5, p3
    v.movi       v4, #0
    @p1 v.sel        v6, v5, v8
    vf.cmp.ne    p2, v10, v10
    vf.cmp.ne    p3, v6, v6
    v.cmp.ne     p4, v3, v4
    p.xor        p5, p2, p4
    p.and        p4, p3, p2
    @p1 v.sel        v3, v2, v9
    vf.cmp.eq    p1, v6, v10
    p.and        p2, p3, p5
    p.or         p3, p1, p4
    vf.cmp.gt    p1, v6, v10
    v.cmp.lt     p4, v3, v11
    p.or         p5, p1, p2
    p.and        p1, p3, p4
    v.splat      v2, s2
    p.or         p2, p5, p1
    v.movi       v4, #0
    @p2 v.sel        v5, v6, v10
    vf.cmp.ne    p1, v12, v12
    vf.cmp.ne    p3, v5, v5
    v.cmp.ne     p4, v2, v4
    p.xor        p5, p1, p4
    p.and        p4, p3, p1
    @p2 v.sel        v2, v3, v11
    vf.cmp.eq    p1, v5, v12
    p.and        p2, p3, p5
    p.or         p3, p1, p4
    vf.cmp.gt    p1, v5, v12
    v.cmp.lt     p4, v2, v13
    p.or         p5, p1, p2
    p.and        p1, p3, p4
    v.splat      v3, s2
    p.or         p2, p5, p1
    v.movi       v4, #0
    @p2 v.sel        v6, v5, v12
    vf.cmp.ne    p1, v14, v14
    vf.cmp.ne    p3, v6, v6
    v.cmp.ne     p4, v3, v4
    p.xor        p5, p1, p4
    p.and        p4, p3, p1
    @p2 v.sel        v3, v2, v13
    vf.cmp.eq    p1, v6, v14
    p.and        p2, p3, p5
    p.or         p3, p1, p4
    vf.cmp.gt    p1, v6, v14
    v.cmp.lt     p4, v3, v15
    p.or         p5, p1, p2
    p.and        p1, p3, p4
    v.splat      v2, s2
    p.or         p2, p5, p1
    v.movi       v4, #0
    @p2 v.sel        v5, v6, v14
    vf.cmp.ne    p1, v16, v16
    vf.cmp.ne    p3, v5, v5
    v.cmp.ne     p4, v2, v4
    p.xor        p5, p1, p4
    p.and        p4, p3, p1
    @p2 v.sel        v2, v3, v15
    vf.cmp.eq    p1, v5, v16
    p.and        p2, p3, p5
    p.or         p3, p1, p4
    vf.cmp.gt    p1, v5, v16
    v.cmp.lt     p4, v2, v17
    p.or         p5, p1, p2
    p.and        p1, p3, p4
    v.splat      v3, s2
    p.or         p2, p5, p1
    v.movi       v4, #0
    @p2 v.sel        v6, v5, v16
    vf.cmp.ne    p1, v18, v18
    vf.cmp.ne    p3, v6, v6
    v.cmp.ne     p4, v3, v4
    p.xor        p5, p1, p4
    p.and        p4, p3, p1
    @p2 v.sel        v3, v2, v17
    vf.cmp.eq    p1, v6, v18
    p.and        p2, p3, p5
    p.or         p3, p1, p4
    vf.cmp.gt    p1, v6, v18
    v.cmp.lt     p4, v3, v19
    p.or         p5, p1, p2
    p.and        p1, p3, p4
    v.splat      v2, s2
    p.or         p2, p5, p1
    v.movi       v4, #0
    @p2 v.sel        v5, v6, v18
    vf.cmp.ne    p1, v20, v20
    vf.cmp.ne    p3, v5, v5
    v.cmp.ne     p4, v2, v4
    p.xor        p5, p1, p4
    p.and        p4, p3, p1
    @p2 v.sel        v2, v3, v19
    vf.cmp.eq    p1, v5, v20
    p.and        p2, p3, p5
    p.or         p3, p1, p4
    vf.cmp.gt    p1, v5, v20
    v.cmp.lt     p4, v2, v21
    p.or         p5, p1, p2
    p.and        p1, p3, p4
    v.splat      v3, s2
    p.or         p2, p5, p1
    v.movi       v4, #0
    @p2 v.sel        v6, v5, v20
    vf.cmp.ne    p1, v22, v22
    vf.cmp.ne    p3, v6, v6
    v.cmp.ne     p4, v3, v4
    p.xor        p5, p1, p4
    p.and        p4, p3, p1
    @p2 v.sel        v3, v2, v21
    vf.cmp.eq    p1, v6, v22
    p.and        p2, p3, p5
    p.or         p3, p1, p4
    vf.cmp.gt    p1, v6, v22
    v.cmp.lt     p4, v3, v24
    p.or         p5, p1, p2
    p.and        p1, p3, p4
    v.splat      v2, s2
    p.or         p2, p5, p1
    v.movi       v4, #0
    @p2 v.sel        v5, v6, v22
    vf.cmp.ne    p1, v26, v26
    vf.cmp.ne    p3, v5, v5
    v.cmp.ne     p4, v2, v4
    p.xor        p5, p1, p4
    p.and        p4, p3, p1
    @p2 v.sel        v2, v3, v24
    vf.cmp.eq    p1, v5, v26
    p.and        p2, p3, p5
    p.or         p3, p1, p4
    vf.cmp.gt    p1, v5, v26
    v.cmp.lt     p4, v2, v23
    p.or         p5, p1, p2
    p.and        p1, p3, p4
    v.splat      v3, s2
    p.or         p2, p5, p1
    v.movi       v4, #0
    @p2 v.sel        v6, v5, v26
    vf.cmp.ne    p1, v25, v25
    vf.cmp.ne    p3, v6, v6
    v.cmp.ne     p4, v3, v4
    p.xor        p5, p1, p4
    p.and        p4, p3, p1
    @p2 v.sel        v3, v2, v23
    vf.cmp.eq    p1, v6, v25
    p.and        p2, p3, p5
    p.or         p3, p1, p4
    vf.cmp.gt    p1, v6, v25
    v.cmp.lt     p4, v3, v27
    p.or         p5, p1, p2
    p.and        p1, p3, p4
    v.splat      v2, s2
    p.or         p2, p5, p1
    v.movi       v4, #0
    @p2 v.sel        v5, v6, v25
    vf.cmp.ne    p1, v28, v28
    vf.cmp.ne    p3, v5, v5
    v.cmp.ne     p4, v2, v4
    p.xor        p5, p1, p4
    p.and        p4, p3, p1
    @p2 v.sel        v2, v3, v27
    vf.cmp.eq    p1, v5, v28
    p.and        p2, p3, p5
    p.or         p3, p1, p4
    vf.cmp.gt    p1, v5, v28
    v.cmp.lt     p4, v2, v29
    p.or         p5, p1, p2
    p.and        p1, p3, p4
    v.splat      v3, s2
    p.or         p2, p5, p1
    v.movi       v4, #0
    @p2 v.sel        v6, v5, v28
    vf.cmp.ne    p1, v30, v30
    vf.cmp.ne    p3, v6, v6
    v.cmp.ne     p4, v3, v4
    p.xor        p5, p1, p4
    p.and        p4, p3, p1
    @p2 v.sel        v3, v2, v29
    vf.cmp.eq    p1, v6, v30
    p.and        p2, p3, p5
    p.or         p3, p1, p4
    vf.cmp.gt    p1, v6, v30
    v.cmp.lt     p4, v3, v31
    p.or         p5, p1, p2
    p.and        p1, p3, p4
    v.splat      v2, s2
    p.or         p2, p5, p1
    v.movi       v4, #0
    @p2 v.sel        v5, v6, v30
    vf.cmp.ne    p1, v1, v1
    vf.cmp.ne    p3, v5, v5
    v.cmp.ne     p4, v2, v4
    p.xor        p5, p1, p4
    p.and        p4, p3, p1
    @p2 v.sel        v2, v3, v31
    vf.cmp.eq    p1, v5, v1
    p.and        p2, p3, p5
    p.or         p3, p1, p4
    vf.cmp.gt    p1, v5, v1
    v.cmp.lt     p4, v2, v0
    p.or         p5, p1, p2
    p.and        p1, p3, p4
    s.shli       s1, s4, #3                      // element offset -> bytes (x8)
    p.or         p2, p5, p1
    s.movz       s2, #1
    @p2 v.sel        v3, v2, v0
    v.movi       v0, #0
    v.extract    s3, v3, #0
    s.shli       s4, s3, #32
    v.movi       v2, #0
    s.ashri      s3, s4, #32
    s.add        s4, s7, s1                      // &out_ptr0[...]
    s.lshri      s1, s3, #32
    v.movi       v3, #0
    v.movi       v4, #1
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v7, s2
    v.insert     v0, s3, #0
    v.insert     v2, s1, #0
    v.shl        v8, v3, v4
    s.addi       s1, s4, #4
    v.cmp.lt     p1, v6, v7
    @p2 v.sel        v3, v5, v1
    @p1 v.st.scatter.w [s4, v8], v0
    @p1 v.st.scatter.w [s1, v8], v2
__rctx_next:
    exit
