    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    v.movi       v0, #0
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #0
    s.movz       s3, #16
    v.iota       v2                              // arange(0, VLEN)
    s.mul        s5, s4, s3
    v.movi       v3, #512
    v.movi       v4, #0
    v.movi       v5, #0
    v.movi       v6, #255
    v.splat      v7, s5
    v.movi       v8, #8
    s.ld.d       s3, [s2, #0]                    // one element, not a vector
    v.add        v9, v7, v2
    v.movi       v2, #256
    v.movi       v7, #1
    v.cmp.lt     p1, v9, v3
    v.sub        v3, v4, v9
    v.sub        v7, v5, v9
    v.cmp.lt     p2, v9, v4
    v.cmp.lt     p3, v9, v5
    @p2 v.sel        v10, v3, v9
    @p3 v.sel        v3, v7, v9
    s.lshri      s2, s3, #32
    s.ld.d       s4, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.lshri      s6, s3, #32
    s.lshri      s7, s3, #32
    s.lshri      s8, s3, #32
    v.and        v7, v10, v6
    v.lshr       v6, v3, v8
    v.sub        v3, v4, v2
    v.sub        v8, v4, v7
    v.sub        v9, v5, v2
    v.sub        v10, v5, v6
    v.cmp.lt     p4, v2, v4
    s.ld.d       s9, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    v.insert     v0, s3, #0
    v.insert     v1, s2, #0
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #1
    v.insert     v1, s6, #1
    s.lshri      s2, s3, #32
    v.insert     v0, s3, #2
    v.insert     v1, s7, #2
    s.lshri      s6, s3, #32
    v.insert     v0, s3, #3
    v.insert     v1, s8, #3
    s.lshri      s7, s3, #32
    v.insert     v0, s3, #4
    v.insert     v1, s1, #4
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #5
    v.insert     v1, s2, #5
    @p4 v.sel        v4, v3, v2
    v.insert     v0, s3, #6
    v.insert     v1, s6, #6
    s.lshri      s2, s3, #32
    v.insert     v0, s3, #7
    v.insert     v1, s7, #7
    s.lshri      s6, s3, #32
    v.insert     v0, s3, #8
    v.insert     v1, s1, #8
    v.cmp.lt     p4, v2, v5
    v.insert     v0, s3, #9
    v.insert     v1, s2, #9
    @p2 v.sel        v3, v8, v7
    v.insert     v0, s3, #10
    v.insert     v1, s6, #10
    v.movi       v4, #1
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #11
    v.insert     v1, s1, #11
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #12
    v.insert     v1, s1, #12
    @p4 v.sel        v4, v9, v2
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #13
    v.insert     v1, s1, #13
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #14
    @p3 v.sel        v2, v10, v6
    v.insert     v1, s1, #14
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #15
    v.insert     v1, s1, #15
    s.movz       s1, #144
    v.extract    s2, v0, #0
    v.extract    s3, v1, #0
    v.extract    s6, v1, #1
    s.shli       s7, s3, #32
    v.extract    s3, v0, #1
    s.or         s8, s2, s7
    s.shli       s2, s6, #32
    s.shli       s6, s5, #1                      // element offset -> bytes (x2)
    s.add        s5, s8, s1
    v.extract    s1, v1, #2
    v.movi       v4, #0
    v.movi       v5, #0
    s.or         s7, s3, s2
    s.movz       s2, #144
    s.add        s3, s4, s6                      // &in_ptr1[...]
    s.lshri      s4, s5, #32
    v.extract    s6, v0, #2
    s.shli       s8, s1, #32
    s.add        s1, s7, s2
    v.extract    s2, v1, #3
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s3, #0]
    v.insert     v4, s5, #0
    v.insert     v5, s4, #0
    s.or         s3, s6, s8
    s.movz       s4, #144
    s.lshri      s5, s1, #32
    v.extract    s6, v0, #3
    s.shli       s7, s2, #32
    s.add        s2, s3, s4
    v.extract    s3, v1, #4
    v.insert     v4, s1, #1
    v.insert     v5, s5, #1
    s.or         s1, s6, s7
    s.movz       s4, #144
    s.lshri      s5, s2, #32
    v.extract    s6, v0, #4
    s.shli       s7, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v1, #5
    v.insert     v4, s2, #2
    v.insert     v5, s5, #2
    s.or         s2, s6, s7
    s.movz       s4, #144
    s.lshri      s5, s3, #32
    v.extract    s6, v0, #5
    s.shli       s7, s1, #32
    s.add        s1, s2, s4
    v.extract    s2, v1, #6
    v.insert     v4, s3, #3
    v.insert     v5, s5, #3
    s.or         s3, s6, s7
    s.movz       s4, #144
    s.lshri      s5, s1, #32
    v.extract    s6, v0, #6
    s.shli       s7, s2, #32
    s.add        s2, s3, s4
    v.extract    s3, v1, #7
    v.insert     v4, s1, #4
    v.insert     v5, s5, #4
    s.or         s1, s6, s7
    s.movz       s4, #144
    s.lshri      s5, s2, #32
    v.extract    s6, v0, #7
    s.shli       s7, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v1, #8
    v.insert     v4, s2, #5
    v.insert     v5, s5, #5
    s.or         s2, s6, s7
    s.movz       s4, #144
    s.lshri      s5, s3, #32
    v.extract    s6, v0, #8
    s.shli       s7, s1, #32
    s.add        s1, s2, s4
    v.extract    s2, v1, #9
    v.insert     v4, s3, #6
    v.insert     v5, s5, #6
    s.or         s3, s6, s7
    s.movz       s4, #144
    s.lshri      s5, s1, #32
    v.extract    s6, v0, #9
    s.shli       s7, s2, #32
    s.add        s2, s3, s4
    v.extract    s3, v1, #10
    v.insert     v4, s1, #7
    v.insert     v5, s5, #7
    s.or         s1, s6, s7
    s.movz       s4, #144
    s.lshri      s5, s2, #32
    v.extract    s6, v0, #10
    s.shli       s7, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v1, #11
    v.insert     v4, s2, #8
    v.insert     v5, s5, #8
    s.or         s2, s6, s7
    s.movz       s4, #144
    s.lshri      s5, s3, #32
    v.extract    s6, v0, #11
    s.shli       s7, s1, #32
    s.add        s1, s2, s4
    v.extract    s2, v1, #12
    v.insert     v4, s3, #9
    v.insert     v5, s5, #9
    s.or         s3, s6, s7
    s.movz       s4, #144
    s.lshri      s5, s1, #32
    v.extract    s6, v0, #12
    s.shli       s7, s2, #32
    s.add        s2, s3, s4
    v.extract    s3, v1, #13
    v.insert     v4, s1, #10
    v.insert     v5, s5, #10
    s.or         s1, s6, s7
    s.movz       s4, #144
    s.lshri      s5, s2, #32
    v.extract    s6, v0, #13
    s.shli       s7, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v1, #14
    v.insert     v4, s2, #11
    v.insert     v5, s5, #11
    s.or         s2, s6, s7
    s.movz       s4, #144
    s.lshri      s5, s3, #32
    v.extract    s6, v0, #14
    s.shli       s7, s1, #32
    s.add        s1, s2, s4
    v.extract    s2, v1, #15
    v.insert     v4, s3, #12
    v.insert     v5, s5, #12
    s.or         s3, s6, s7
    s.movz       s4, #144
    s.lshri      s5, s1, #32
    v.extract    s6, v0, #15
    s.shli       s7, s2, #32
    v.extract    s2, v1, #0
    s.add        s8, s3, s4
    v.insert     v4, s1, #13
    v.insert     v5, s5, #13
    s.or         s1, s6, s7
    s.movz       s3, #144
    v.extract    s4, v0, #0
    s.shli       s5, s2, #32
    s.lshri      s2, s8, #32
    v.extract    s6, v1, #1
    s.add        s7, s1, s3
    s.or         s1, s4, s5
    s.movz       s3, #0
    v.insert     v4, s8, #14
    v.insert     v5, s2, #14
    v.movi       v7, #0
    v.extract    s2, v0, #1
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    s.cmp.lt     s6, s1, s3
    v.extract    s1, v1, #2
    s.or         s3, s2, s4
    s.movz       s2, #0
    v.insert     v4, s7, #15
    v.insert     v5, s5, #15
    v.insert     v7, s6, #0
    v.extract    s4, v0, #2
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s3, s2
    v.extract    s2, v1, #3
    s.or         s3, s4, s5
    s.movz       s4, #0
    v.insert     v7, s1, #1
    v.extract    s1, v0, #3
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s3, s4
    v.extract    s3, v1, #4
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v7, s2, #2
    v.extract    s2, v0, #4
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s1
    v.extract    s1, v1, #5
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v7, s3, #3
    v.extract    s3, v0, #5
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s2
    v.extract    s2, v1, #6
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v7, s1, #4
    v.extract    s1, v0, #6
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s3
    v.extract    s3, v1, #7
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v7, s2, #5
    v.extract    s2, v0, #7
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s1
    v.extract    s1, v1, #8
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v7, s3, #6
    v.extract    s3, v0, #8
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s2
    v.extract    s2, v1, #9
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v7, s1, #7
    v.extract    s1, v0, #9
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s3
    v.extract    s3, v1, #10
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v7, s2, #8
    v.extract    s2, v0, #10
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s1
    v.extract    s1, v1, #11
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v7, s3, #9
    v.extract    s3, v0, #11
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s2
    v.extract    s2, v1, #12
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v7, s1, #10
    v.extract    s1, v0, #12
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s3
    v.extract    s3, v1, #13
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v7, s2, #11
    v.extract    s2, v0, #13
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s1
    v.extract    s1, v1, #14
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v7, s3, #12
    v.extract    s3, v0, #14
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s2
    v.extract    s2, v1, #15
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v7, s1, #13
    v.extract    s1, v0, #15
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s3
    s.or         s3, s1, s5
    s.movz       s1, #0
    v.insert     v7, s2, #14
    s.cmp.lt     s2, s3, s1
    v.movi       v8, #0
    v.insert     v7, s2, #15
    v.movi       v9, #1
    v.movi       v10, #0
    v.extract    s1, v5, #0
    v.extract    s2, v1, #0
    v.cmp.ne     p2, v7, v8
    v.extract    s3, v4, #0
    s.shli       s4, s1, #32
    v.extract    s1, v0, #0
    s.shli       s5, s2, #32
    @p2 v.sel        v7, v9, v10
    v.extract    s2, v5, #1
    v.extract    s6, v1, #1
    s.or         s7, s3, s4
    s.or         s3, s1, s5
    v.extract    s1, v4, #1
    s.shli       s4, s2, #32
    v.extract    s2, v0, #1
    s.shli       s5, s6, #32
    v.extract    s6, v7, #0
    s.sub        s8, s7, s3
    v.extract    s7, v5, #2
    s.or         s10, s1, s4
    v.extract    s1, v1, #2
    s.or         s4, s2, s5
    s.mul        s2, s6, s8
    v.extract    s5, v4, #2
    s.shli       s6, s7, #32
    v.extract    s7, v0, #2
    s.shli       s8, s1, #32
    s.sub        s1, s10, s4
    s.or         s10, s5, s6
    v.extract    s5, v7, #1
    s.or         s6, s7, s8
    s.mul        s7, s5, s1
    v.extract    s1, v7, #2
    s.sub        s5, s10, s6
    s.add        s8, s3, s2
    v.movi       v8, #0
    v.extract    s2, v4, #3
    v.movi       v9, #0
    v.extract    s3, v5, #3
    s.mul        s10, s1, s5
    v.extract    s1, v1, #3
    s.shli       s5, s3, #32
    s.shli       s3, s1, #32
    s.or         s1, s2, s5
    v.extract    s2, v0, #3
    s.add        s5, s4, s7
    s.or         s4, s2, s3
    s.lshri      s2, s8, #32
    v.extract    s3, v7, #3
    s.sub        s7, s1, s4
    v.insert     v8, s8, #0
    v.extract    s1, v4, #4
    v.insert     v9, s2, #0
    v.extract    s2, v5, #4
    s.mul        s8, s3, s7
    v.extract    s3, v1, #4
    s.shli       s7, s2, #32
    s.shli       s2, s3, #32
    s.or         s3, s1, s7
    v.extract    s1, v0, #4
    s.add        s7, s6, s10
    s.or         s6, s1, s2
    s.lshri      s1, s5, #32
    v.extract    s2, v7, #4
    s.sub        s10, s3, s6
    v.insert     v8, s5, #1
    v.extract    s3, v4, #5
    v.insert     v9, s1, #1
    v.extract    s1, v5, #5
    s.mul        s5, s2, s10
    v.extract    s2, v1, #5
    s.shli       s10, s1, #32
    s.shli       s1, s2, #32
    s.or         s2, s3, s10
    v.extract    s3, v0, #5
    s.add        s10, s4, s8
    s.or         s4, s3, s1
    s.lshri      s1, s7, #32
    v.extract    s3, v7, #5
    s.sub        s8, s2, s4
    v.insert     v8, s7, #2
    v.extract    s2, v4, #6
    v.insert     v9, s1, #2
    v.extract    s1, v5, #6
    s.mul        s7, s3, s8
    v.extract    s3, v1, #6
    s.shli       s8, s1, #32
    s.shli       s1, s3, #32
    s.or         s3, s2, s8
    v.extract    s2, v0, #6
    s.add        s8, s6, s5
    s.or         s5, s2, s1
    s.lshri      s1, s10, #32
    v.extract    s2, v7, #6
    s.sub        s6, s3, s5
    v.insert     v8, s10, #3
    v.extract    s3, v4, #7
    v.insert     v9, s1, #3
    v.extract    s1, v5, #7
    s.mul        s10, s2, s6
    v.extract    s2, v1, #7
    s.shli       s6, s1, #32
    s.shli       s1, s2, #32
    s.or         s2, s3, s6
    v.extract    s3, v0, #7
    s.add        s6, s4, s7
    s.or         s4, s3, s1
    s.lshri      s1, s8, #32
    v.extract    s3, v7, #7
    s.sub        s7, s2, s4
    v.insert     v8, s8, #4
    v.extract    s2, v4, #8
    v.insert     v9, s1, #4
    v.extract    s1, v5, #8
    s.mul        s8, s3, s7
    v.extract    s3, v1, #8
    s.shli       s7, s1, #32
    s.shli       s1, s3, #32
    s.or         s3, s2, s7
    v.extract    s2, v0, #8
    s.add        s7, s5, s10
    s.or         s5, s2, s1
    s.lshri      s1, s6, #32
    v.extract    s2, v7, #8
    s.sub        s10, s3, s5
    v.insert     v8, s6, #5
    v.extract    s3, v4, #9
    v.insert     v9, s1, #5
    v.extract    s1, v5, #9
    s.mul        s6, s2, s10
    v.extract    s2, v1, #9
    s.shli       s10, s1, #32
    s.shli       s1, s2, #32
    s.or         s2, s3, s10
    v.extract    s3, v0, #9
    s.add        s10, s4, s8
    s.or         s4, s3, s1
    s.lshri      s1, s7, #32
    v.extract    s3, v7, #9
    s.sub        s8, s2, s4
    v.insert     v8, s7, #6
    v.extract    s2, v4, #10
    v.insert     v9, s1, #6
    v.extract    s1, v5, #10
    s.mul        s7, s3, s8
    v.extract    s3, v1, #10
    s.shli       s8, s1, #32
    s.shli       s1, s3, #32
    s.or         s3, s2, s8
    v.extract    s2, v0, #10
    s.add        s8, s5, s6
    s.or         s5, s2, s1
    s.lshri      s1, s10, #32
    v.extract    s2, v7, #10
    s.sub        s6, s3, s5
    v.insert     v8, s10, #7
    v.extract    s3, v4, #11
    v.insert     v9, s1, #7
    v.extract    s1, v5, #11
    s.mul        s10, s2, s6
    v.extract    s2, v1, #11
    s.shli       s6, s1, #32
    s.shli       s1, s2, #32
    s.or         s2, s3, s6
    v.extract    s3, v0, #11
    s.add        s6, s4, s7
    s.or         s4, s3, s1
    s.lshri      s1, s8, #32
    v.extract    s3, v7, #11
    s.sub        s7, s2, s4
    v.insert     v8, s8, #8
    v.extract    s2, v4, #12
    v.insert     v9, s1, #8
    v.extract    s1, v5, #12
    s.mul        s8, s3, s7
    v.extract    s3, v1, #12
    s.shli       s7, s1, #32
    s.shli       s1, s3, #32
    s.or         s3, s2, s7
    v.extract    s2, v0, #12
    s.add        s7, s5, s10
    s.or         s5, s2, s1
    s.lshri      s1, s6, #32
    v.extract    s2, v7, #12
    s.sub        s10, s3, s5
    v.insert     v8, s6, #9
    v.extract    s3, v4, #13
    v.insert     v9, s1, #9
    v.extract    s1, v5, #13
    s.mul        s6, s2, s10
    v.extract    s2, v1, #13
    s.shli       s10, s1, #32
    s.shli       s1, s2, #32
    s.or         s2, s3, s10
    v.extract    s3, v0, #13
    s.add        s10, s4, s8
    s.or         s4, s3, s1
    s.lshri      s1, s7, #32
    v.extract    s3, v7, #13
    s.sub        s8, s2, s4
    v.insert     v8, s7, #10
    v.extract    s2, v4, #14
    v.insert     v9, s1, #10
    v.extract    s1, v5, #14
    s.mul        s7, s3, s8
    v.extract    s3, v1, #14
    s.shli       s8, s1, #32
    s.shli       s1, s3, #32
    s.or         s3, s2, s8
    v.extract    s2, v0, #14
    s.add        s8, s5, s6
    s.or         s5, s2, s1
    s.lshri      s1, s10, #32
    v.extract    s2, v7, #14
    s.sub        s6, s3, s5
    v.insert     v8, s10, #11
    v.extract    s3, v4, #15
    v.insert     v9, s1, #11
    v.extract    s1, v5, #15
    s.mul        s10, s2, s6
    v.extract    s2, v1, #15
    s.shli       s6, s1, #32
    s.shli       s1, s2, #32
    s.or         s2, s3, s6
    v.extract    s3, v0, #15
    s.add        s6, s4, s7
    s.or         s4, s3, s1
    s.lshri      s1, s8, #32
    v.extract    s3, v7, #15
    s.sub        s7, s2, s4
    v.insert     v8, s8, #12
    v.insert     v9, s1, #12
    s.mul        s1, s3, s7
    s.lshri      s2, s6, #32
    s.add        s3, s5, s10
    v.insert     v8, s6, #13
    v.insert     v9, s2, #13
    s.lshri      s2, s3, #32
    s.add        s5, s4, s1
    v.insert     v8, s3, #14
    v.insert     v9, s2, #14
    s.lshri      s1, s5, #32
    v.insert     v8, s5, #15
    v.insert     v9, s1, #15
    s.movz       s1, #0
    v.extract    s2, v8, #0
    v.extract    s3, v9, #0
    v.extract    s4, v9, #1
    s.shli       s5, s3, #32
    v.movi       v0, #0
    s.or         s3, s2, s5
    v.extract    s2, v8, #1
    s.shli       s5, s4, #32
    s.cmp.ge     s4, s3, s1
    v.extract    s1, v9, #2
    s.or         s3, s2, s5
    s.movz       s2, #0
    v.insert     v0, s4, #0
    v.extract    s4, v8, #2
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s3, s2
    v.extract    s2, v9, #3
    s.or         s3, s4, s5
    s.movz       s4, #0
    v.insert     v0, s1, #1
    v.extract    s1, v8, #3
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s3, s4
    v.extract    s3, v9, #4
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #2
    v.extract    s2, v8, #4
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v9, #5
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v0, s3, #3
    v.extract    s3, v8, #5
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v9, #6
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v0, s1, #4
    v.extract    s1, v8, #6
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v9, #7
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #5
    v.extract    s2, v8, #7
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v9, #8
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v0, s3, #6
    v.extract    s3, v8, #8
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v9, #9
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v0, s1, #7
    v.extract    s1, v8, #9
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v9, #10
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #8
    v.extract    s2, v8, #10
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v9, #11
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v0, s3, #9
    v.extract    s3, v8, #11
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v9, #12
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v0, s1, #10
    v.extract    s1, v8, #12
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v9, #13
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v0, s2, #11
    v.extract    s2, v8, #13
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v9, #14
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v0, s3, #12
    v.extract    s3, v8, #14
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v9, #15
    v.extract    s4, v9, #0
    s.or         s6, s3, s5
    s.movz       s3, #0
    v.insert     v0, s1, #13
    v.extract    s1, v8, #15
    s.shli       s5, s2, #32
    v.extract    s2, v8, #0
    s.shli       s7, s4, #32
    s.cmp.ge     s4, s6, s3
    v.extract    s3, v9, #1
    s.or         s6, s1, s5
    s.movz       s1, #0
    s.or         s5, s2, s7
    s.movz       s2, #144
    v.insert     v0, s4, #14
    v.movi       v1, #0
    v.extract    s4, v8, #1
    s.shli       s7, s3, #32
    s.cmp.ge     s3, s6, s1
    s.cmp.lt     s1, s5, s2
    v.extract    s2, v9, #2
    s.or         s5, s4, s7
    s.movz       s4, #144
    v.insert     v0, s3, #15
    v.insert     v1, s1, #0
    v.extract    s1, v8, #2
    s.shli       s3, s2, #32
    s.cmp.lt     s2, s5, s4
    v.extract    s4, v9, #3
    s.or         s5, s1, s3
    s.movz       s1, #144
    v.insert     v1, s2, #1
    v.extract    s2, v8, #3
    s.shli       s3, s4, #32
    s.cmp.lt     s4, s5, s1
    v.extract    s1, v9, #4
    s.or         s5, s2, s3
    s.movz       s2, #144
    v.insert     v1, s4, #2
    v.extract    s3, v8, #4
    s.shli       s4, s1, #32
    s.cmp.lt     s1, s5, s2
    v.extract    s2, v9, #5
    s.or         s5, s3, s4
    s.movz       s3, #144
    v.insert     v1, s1, #3
    v.extract    s1, v8, #5
    s.shli       s4, s2, #32
    s.cmp.lt     s2, s5, s3
    v.extract    s3, v9, #6
    s.or         s5, s1, s4
    s.movz       s1, #144
    v.insert     v1, s2, #4
    v.extract    s2, v8, #6
    s.shli       s4, s3, #32
    s.cmp.lt     s3, s5, s1
    v.movi       v4, #0
    s.or         s1, s2, s4
    v.insert     v1, s3, #5
    v.cmp.ne     p2, v0, v4
    v.extract    s2, v9, #7
    s.movz       s3, #144
    v.extract    s4, v8, #7
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s1, s3
    v.extract    s1, v9, #8
    s.or         s3, s4, s5
    s.movz       s4, #144
    v.insert     v1, s2, #6
    v.extract    s2, v8, #8
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s3, s4
    v.extract    s3, v9, #9
    s.or         s4, s2, s5
    s.movz       s2, #144
    v.insert     v1, s1, #7
    v.extract    s1, v8, #9
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v9, #10
    s.or         s4, s1, s5
    s.movz       s1, #144
    v.insert     v1, s3, #8
    v.extract    s3, v8, #10
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v9, #11
    s.or         s4, s3, s5
    s.movz       s3, #144
    v.insert     v1, s2, #9
    v.extract    s2, v8, #11
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v9, #12
    s.or         s4, s2, s5
    s.movz       s2, #144
    v.insert     v1, s1, #10
    v.extract    s1, v8, #12
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v9, #13
    s.or         s4, s1, s5
    s.movz       s1, #144
    v.insert     v1, s3, #11
    v.extract    s3, v8, #13
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v9, #14
    s.or         s4, s3, s5
    s.movz       s3, #144
    v.insert     v1, s2, #12
    v.extract    s2, v8, #14
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v9, #15
    s.or         s4, s2, s5
    s.movz       s2, #144
    v.insert     v1, s1, #13
    v.extract    s1, v8, #15
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    s.or         s2, s1, s5
    s.movz       s1, #144
    v.insert     v1, s3, #14
    s.cmp.lt     s3, s2, s1
    v.movi       v0, #0
    v.insert     v1, s3, #15
    v.movi       v4, #0
    v.movi       v5, #1
    v.cmp.ne     p3, v1, v0
    p.and        p4, p2, p3
    s.movz       s1, #0
    @p4 v.sel        v0, v4, v5
    v.reduce.or  s2, v0
    s.cmp.eq     s3, s2, s1
    br.nz        s3, assert_ok_1
    trap         #677351
assert_ok_1:
    v.extract    s1, v9, #0
    v.extract    s2, v8, #0
    s.shli       s3, s1, #32
    v.extract    s1, v9, #1
    s.or         s4, s2, s3
    s.movz       s2, #256
    v.extract    s3, v8, #1
    s.shli       s5, s1, #32
    s.mul        s1, s4, s2
    v.extract    s2, v9, #2
    s.or         s4, s3, s5
    s.movz       s3, #256
    v.extract    s5, v8, #2
    s.shli       s6, s2, #32
    s.mul        s2, s4, s3
    v.extract    s3, v9, #3
    v.movi       v0, #0
    v.movi       v1, #0
    s.or         s4, s5, s6
    s.movz       s5, #256
    s.lshri      s6, s1, #32
    v.extract    s7, v8, #3
    s.shli       s8, s3, #32
    s.mul        s3, s4, s5
    v.extract    s4, v9, #4
    v.insert     v0, s1, #0
    v.insert     v1, s6, #0
    s.or         s1, s7, s8
    s.movz       s5, #256
    s.lshri      s6, s2, #32
    v.extract    s7, v8, #4
    s.shli       s8, s4, #32
    s.mul        s4, s1, s5
    v.extract    s1, v9, #5
    v.insert     v0, s2, #1
    v.insert     v1, s6, #1
    s.or         s2, s7, s8
    s.movz       s5, #256
    s.lshri      s6, s3, #32
    v.extract    s7, v8, #5
    s.shli       s8, s1, #32
    s.mul        s1, s2, s5
    v.extract    s2, v9, #6
    v.insert     v0, s3, #2
    v.insert     v1, s6, #2
    s.or         s3, s7, s8
    s.movz       s5, #256
    s.lshri      s6, s4, #32
    v.extract    s7, v8, #6
    s.shli       s8, s2, #32
    s.mul        s2, s3, s5
    v.extract    s3, v9, #7
    v.insert     v0, s4, #3
    v.insert     v1, s6, #3
    s.or         s4, s7, s8
    s.movz       s5, #256
    s.lshri      s6, s1, #32
    v.extract    s7, v8, #7
    s.shli       s8, s3, #32
    s.mul        s3, s4, s5
    v.extract    s4, v9, #8
    v.insert     v0, s1, #4
    v.insert     v1, s6, #4
    s.or         s1, s7, s8
    s.movz       s5, #256
    s.lshri      s6, s2, #32
    v.extract    s7, v8, #8
    s.shli       s8, s4, #32
    s.mul        s4, s1, s5
    v.extract    s1, v9, #9
    v.insert     v0, s2, #5
    v.insert     v1, s6, #5
    s.or         s2, s7, s8
    s.movz       s5, #256
    s.lshri      s6, s3, #32
    v.extract    s7, v8, #9
    s.shli       s8, s1, #32
    s.mul        s1, s2, s5
    v.extract    s2, v9, #10
    v.insert     v0, s3, #6
    v.insert     v1, s6, #6
    s.or         s3, s7, s8
    s.movz       s5, #256
    s.lshri      s6, s4, #32
    v.extract    s7, v8, #10
    s.shli       s8, s2, #32
    s.mul        s2, s3, s5
    v.extract    s3, v9, #11
    v.insert     v0, s4, #7
    v.insert     v1, s6, #7
    s.or         s4, s7, s8
    s.movz       s5, #256
    s.lshri      s6, s1, #32
    v.extract    s7, v8, #11
    s.shli       s8, s3, #32
    s.mul        s3, s4, s5
    v.extract    s4, v9, #12
    v.insert     v0, s1, #8
    v.insert     v1, s6, #8
    s.or         s1, s7, s8
    s.movz       s5, #256
    s.lshri      s6, s2, #32
    v.extract    s7, v8, #12
    s.shli       s8, s4, #32
    s.mul        s4, s1, s5
    v.extract    s1, v9, #13
    v.insert     v0, s2, #9
    v.insert     v1, s6, #9
    s.or         s2, s7, s8
    s.movz       s5, #256
    s.lshri      s6, s3, #32
    v.extract    s7, v8, #13
    s.shli       s8, s1, #32
    s.mul        s1, s2, s5
    v.extract    s2, v9, #14
    v.insert     v0, s3, #10
    v.insert     v1, s6, #10
    s.or         s3, s7, s8
    s.movz       s5, #256
    s.lshri      s6, s4, #32
    v.extract    s7, v8, #14
    s.shli       s8, s2, #32
    s.mul        s2, s3, s5
    v.extract    s3, v9, #15
    v.insert     v0, s4, #11
    v.insert     v1, s6, #11
    s.or         s4, s7, s8
    s.movz       s5, #256
    s.lshri      s6, s1, #32
    v.extract    s7, v8, #15
    s.shli       s8, s3, #32
    s.mul        s3, s4, s5
    v.insert     v0, s1, #12
    v.insert     v1, s6, #12
    s.or         s1, s7, s8
    s.movz       s4, #256
    s.lshri      s5, s2, #32
    v.extract    s6, v3, #0
    s.mul        s7, s1, s4
    v.insert     v0, s2, #13
    v.insert     v1, s5, #13
    s.shli       s1, s6, #32
    s.lshri      s2, s3, #32
    v.extract    s4, v3, #1
    s.ashri      s5, s1, #32
    v.insert     v0, s3, #14
    v.insert     v1, s2, #14
    v.movi       v4, #0
    v.movi       v5, #0
    s.shli       s1, s4, #32
    s.lshri      s2, s7, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v3, #2
    s.ashri      s6, s1, #32
    v.insert     v0, s7, #15
    v.insert     v1, s2, #15
    v.insert     v4, s5, #0
    v.insert     v5, s3, #0
    s.shli       s1, s4, #32
    s.lshri      s2, s6, #32
    v.extract    s3, v3, #3
    s.ashri      s4, s1, #32
    v.insert     v4, s6, #1
    v.insert     v5, s2, #1
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v3, #4
    s.ashri      s5, s1, #32
    v.insert     v4, s4, #2
    v.insert     v5, s2, #2
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v3, #5
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #3
    v.insert     v5, s2, #3
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v3, #6
    s.ashri      s5, s1, #32
    v.insert     v4, s4, #4
    v.insert     v5, s2, #4
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v3, #7
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #5
    v.insert     v5, s2, #5
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v3, #8
    s.ashri      s5, s1, #32
    v.insert     v4, s4, #6
    v.insert     v5, s2, #6
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v3, #9
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #7
    v.insert     v5, s2, #7
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v3, #10
    s.ashri      s5, s1, #32
    v.insert     v4, s4, #8
    v.insert     v5, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v3, #11
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #9
    v.insert     v5, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v3, #12
    s.ashri      s5, s1, #32
    v.insert     v4, s4, #10
    v.insert     v5, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v3, #13
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #11
    v.insert     v5, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v3, #14
    s.ashri      s5, s1, #32
    v.insert     v4, s4, #12
    v.insert     v5, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v3, #15
    s.ashri      s4, s1, #32
    v.insert     v4, s5, #13
    v.insert     v5, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    s.ashri      s3, s1, #32
    v.insert     v4, s4, #14
    v.insert     v5, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v4, s3, #15
    v.insert     v5, s1, #15
    v.extract    s1, v1, #0
    v.extract    s2, v4, #0
    v.extract    s3, v5, #0
    v.extract    s4, v0, #0
    s.shli       s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v5, #1
    v.extract    s6, v1, #1
    s.or         s7, s2, s5
    s.or         s2, s4, s3
    v.extract    s3, v4, #1
    s.shli       s4, s1, #32
    v.extract    s1, v0, #1
    s.shli       s5, s6, #32
    s.add        s6, s7, s2
    v.extract    s2, v5, #2
    v.extract    s7, v1, #2
    v.movi       v3, #0
    v.movi       v7, #0
    s.or         s8, s3, s4
    s.or         s3, s1, s5
    s.lshri      s1, s6, #32
    v.extract    s4, v4, #2
    s.shli       s5, s2, #32
    s.shli       s2, s7, #32
    s.add        s7, s8, s3
    v.extract    s3, v0, #2
    v.insert     v3, s6, #0
    v.extract    s6, v5, #3
    v.insert     v7, s1, #0
    v.extract    s1, v1, #3
    s.or         s8, s4, s5
    s.or         s4, s3, s2
    s.lshri      s2, s7, #32
    v.extract    s3, v4, #3
    s.shli       s5, s6, #32
    s.shli       s6, s1, #32
    s.add        s1, s8, s4
    v.extract    s4, v0, #3
    v.insert     v3, s7, #1
    v.extract    s7, v5, #4
    v.insert     v7, s2, #1
    v.extract    s2, v1, #4
    s.or         s8, s3, s5
    s.or         s3, s4, s6
    s.lshri      s4, s1, #32
    v.extract    s5, v4, #4
    s.shli       s6, s7, #32
    s.shli       s7, s2, #32
    s.add        s2, s8, s3
    v.extract    s3, v0, #4
    v.insert     v3, s1, #2
    v.extract    s1, v5, #5
    v.insert     v7, s4, #2
    v.extract    s4, v1, #5
    s.or         s8, s5, s6
    s.or         s5, s3, s7
    s.lshri      s3, s2, #32
    v.extract    s6, v4, #5
    s.shli       s7, s1, #32
    s.shli       s1, s4, #32
    s.add        s4, s8, s5
    v.extract    s5, v0, #5
    v.insert     v3, s2, #3
    v.extract    s2, v5, #6
    v.insert     v7, s3, #3
    v.extract    s3, v1, #6
    s.or         s8, s6, s7
    s.or         s6, s5, s1
    s.lshri      s1, s4, #32
    v.extract    s5, v4, #6
    s.shli       s7, s2, #32
    s.shli       s2, s3, #32
    s.add        s3, s8, s6
    v.extract    s6, v0, #6
    v.insert     v3, s4, #4
    v.extract    s4, v5, #7
    v.insert     v7, s1, #4
    v.extract    s1, v1, #7
    s.or         s8, s5, s7
    s.or         s5, s6, s2
    s.lshri      s2, s3, #32
    v.extract    s6, v4, #7
    s.shli       s7, s4, #32
    s.shli       s4, s1, #32
    s.add        s1, s8, s5
    v.extract    s5, v0, #7
    v.insert     v3, s3, #5
    v.extract    s3, v5, #8
    v.insert     v7, s2, #5
    v.extract    s2, v1, #8
    s.or         s8, s6, s7
    s.or         s6, s5, s4
    s.lshri      s4, s1, #32
    v.extract    s5, v4, #8
    s.shli       s7, s3, #32
    s.shli       s3, s2, #32
    s.add        s2, s8, s6
    v.extract    s6, v0, #8
    v.insert     v3, s1, #6
    v.extract    s1, v5, #9
    v.insert     v7, s4, #6
    v.extract    s4, v1, #9
    s.or         s8, s5, s7
    s.or         s5, s6, s3
    s.lshri      s3, s2, #32
    v.extract    s6, v4, #9
    s.shli       s7, s1, #32
    s.shli       s1, s4, #32
    s.add        s4, s8, s5
    v.extract    s5, v0, #9
    v.insert     v3, s2, #7
    v.extract    s2, v5, #10
    v.insert     v7, s3, #7
    v.extract    s3, v1, #10
    s.or         s8, s6, s7
    s.or         s6, s5, s1
    s.lshri      s1, s4, #32
    v.extract    s5, v4, #10
    s.shli       s7, s2, #32
    s.shli       s2, s3, #32
    s.add        s3, s8, s6
    v.extract    s6, v0, #10
    v.insert     v3, s4, #8
    v.extract    s4, v5, #11
    v.insert     v7, s1, #8
    v.extract    s1, v1, #11
    s.or         s8, s5, s7
    s.or         s5, s6, s2
    s.lshri      s2, s3, #32
    v.extract    s6, v4, #11
    s.shli       s7, s4, #32
    s.shli       s4, s1, #32
    s.add        s1, s8, s5
    v.extract    s5, v0, #11
    v.insert     v3, s3, #9
    v.extract    s3, v5, #12
    v.insert     v7, s2, #9
    v.extract    s2, v1, #12
    s.or         s8, s6, s7
    s.or         s6, s5, s4
    s.lshri      s4, s1, #32
    v.extract    s5, v4, #12
    s.shli       s7, s3, #32
    s.shli       s3, s2, #32
    s.add        s2, s8, s6
    v.extract    s6, v0, #12
    v.insert     v3, s1, #10
    v.extract    s1, v5, #13
    v.insert     v7, s4, #10
    v.extract    s4, v1, #13
    s.or         s8, s5, s7
    s.or         s5, s6, s3
    s.lshri      s3, s2, #32
    v.extract    s6, v4, #13
    s.shli       s7, s1, #32
    s.shli       s1, s4, #32
    s.add        s4, s8, s5
    v.extract    s5, v0, #13
    v.insert     v3, s2, #11
    v.extract    s2, v5, #14
    v.insert     v7, s3, #11
    s.movz       s3, #36864
    v.splat      v8, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s3, v1, #14
    s.or         s8, s6, s7
    s.or         s6, s5, s1
    s.lshri      s1, s4, #32
    v.extract    s5, v4, #14
    s.shli       s7, s2, #32
    s.shli       s2, s3, #32
    v.mul        v9, v2, v8
    s.add        s3, s8, s6
    v.extract    s6, v0, #14
    v.insert     v3, s4, #12
    v.extract    s4, v5, #15
    v.insert     v7, s1, #12
    v.extract    s1, v1, #15
    s.or         s8, s5, s7
    s.or         s5, s6, s2
    s.lshri      s2, s3, #32
    v.extract    s6, v4, #15
    s.shli       s7, s4, #32
    s.shli       s4, s1, #32
    s.add        s1, s8, s5
    v.extract    s5, v0, #15
    v.insert     v3, s3, #13
    v.extract    s3, v9, #0
    v.insert     v7, s2, #13
    s.or         s2, s6, s7
    s.or         s6, s5, s4
    s.shli       s4, s3, #32
    s.lshri      s3, s1, #32
    v.extract    s5, v9, #1
    s.add        s7, s2, s6
    s.ashri      s2, s4, #32
    v.insert     v3, s1, #14
    v.insert     v7, s3, #14
    v.movi       v0, #0
    v.movi       v1, #0
    s.shli       s1, s5, #32
    s.lshri      s3, s7, #32
    s.lshri      s4, s2, #32
    v.extract    s5, v9, #2
    s.ashri      s6, s1, #32
    v.insert     v3, s7, #15
    v.insert     v7, s3, #15
    v.insert     v0, s2, #0
    v.insert     v1, s4, #0
    s.shli       s1, s5, #32
    s.lshri      s2, s6, #32
    v.extract    s3, v9, #3
    s.ashri      s4, s1, #32
    v.insert     v0, s6, #1
    v.insert     v1, s2, #1
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #4
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #2
    v.insert     v1, s2, #2
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #5
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #3
    v.insert     v1, s2, #3
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #6
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #4
    v.insert     v1, s2, #4
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #7
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #5
    v.insert     v1, s2, #5
    s.lshri      s1, s4, #32
    v.insert     v0, s4, #6
    v.insert     v1, s1, #6
    s.movz       s1, #36864
    s.shli       s1, s3, #32
    v.extract    s2, v9, #8
    s.ashri      s3, s1, #32
    s.shli       s1, s2, #32
    s.lshri      s2, s3, #32
    v.extract    s4, v9, #9
    s.ashri      s5, s1, #32
    v.insert     v0, s3, #7
    v.insert     v1, s2, #7
    s.shli       s1, s4, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #10
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #8
    v.insert     v1, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #11
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #9
    v.insert     v1, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #12
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #10
    v.insert     v1, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #13
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #11
    v.insert     v1, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #14
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #12
    v.insert     v1, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #15
    s.ashri      s5, s1, #32
    v.insert     v0, s4, #13
    v.insert     v1, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    s.ashri      s3, s1, #32
    v.insert     v0, s5, #14
    v.insert     v1, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #15
    v.insert     v1, s1, #15
    v.extract    s1, v7, #0
    v.extract    s2, v3, #0
    v.extract    s3, v1, #0
    s.shli       s4, s1, #32
    v.extract    s1, v0, #0
    s.shli       s5, s3, #32
    v.extract    s3, v7, #1
    v.extract    s6, v1, #1
    s.or         s7, s2, s4
    s.or         s2, s1, s5
    v.movi       v2, #0
    v.extract    s1, v3, #1
    s.shli       s4, s3, #32
    v.extract    s3, v0, #1
    s.shli       s5, s6, #32
    s.add        s6, s7, s2
    v.extract    s2, v7, #2
    v.extract    s7, v1, #2
    s.or         s8, s1, s4
    s.or         s1, s3, s5
    v.movi       v4, #0
    v.insert     v2, s6, #0
    v.extract    s3, v3, #2
    s.shli       s4, s2, #32
    v.extract    s2, v0, #2
    s.shli       s5, s7, #32
    s.lshri      s7, s6, #32
    s.add        s6, s8, s1
    v.extract    s1, v7, #3
    s.or         s8, s3, s4
    v.extract    s3, v1, #3
    s.or         s4, s2, s5
    v.insert     v4, s7, #0
    v.insert     v2, s6, #1
    v.extract    s2, v3, #3
    s.shli       s5, s1, #32
    v.extract    s1, v0, #3
    s.shli       s7, s3, #32
    s.lshri      s3, s6, #32
    s.add        s6, s8, s4
    v.extract    s4, v7, #4
    s.or         s8, s2, s5
    v.extract    s2, v1, #4
    s.or         s5, s1, s7
    v.insert     v4, s3, #1
    v.insert     v2, s6, #2
    v.extract    s1, v3, #4
    s.shli       s3, s4, #32
    v.extract    s4, v0, #4
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s5
    v.extract    s5, v7, #5
    s.or         s8, s1, s3
    v.extract    s1, v1, #5
    s.or         s3, s4, s7
    v.insert     v4, s2, #2
    v.insert     v2, s6, #3
    v.extract    s2, v3, #5
    s.shli       s4, s5, #32
    v.extract    s5, v0, #5
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s3
    v.extract    s3, v7, #6
    s.or         s8, s2, s4
    v.extract    s2, v1, #6
    s.or         s4, s5, s7
    v.insert     v4, s1, #3
    v.insert     v2, s6, #4
    v.extract    s1, v3, #6
    s.shli       s5, s3, #32
    v.extract    s3, v0, #6
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s4
    v.extract    s4, v7, #7
    s.or         s8, s1, s5
    v.extract    s1, v1, #7
    s.or         s5, s3, s7
    v.insert     v4, s2, #4
    v.insert     v2, s6, #5
    v.extract    s2, v3, #7
    s.shli       s3, s4, #32
    v.extract    s4, v0, #7
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s5
    v.extract    s5, v7, #8
    s.or         s8, s2, s3
    v.extract    s2, v1, #8
    s.or         s3, s4, s7
    v.insert     v4, s1, #5
    v.insert     v2, s6, #6
    v.extract    s1, v3, #8
    s.shli       s4, s5, #32
    v.extract    s5, v0, #8
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s3
    v.extract    s3, v7, #9
    s.or         s8, s1, s4
    v.extract    s1, v1, #9
    s.or         s4, s5, s7
    v.insert     v4, s2, #6
    v.insert     v2, s6, #7
    v.extract    s2, v3, #9
    s.shli       s5, s3, #32
    v.extract    s3, v0, #9
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s4
    v.extract    s4, v7, #10
    s.or         s8, s2, s5
    v.extract    s2, v1, #10
    s.or         s5, s3, s7
    v.insert     v4, s1, #7
    v.insert     v2, s6, #8
    v.extract    s1, v3, #10
    s.shli       s3, s4, #32
    v.extract    s4, v0, #10
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s5
    v.extract    s5, v7, #11
    s.or         s8, s1, s3
    v.extract    s1, v1, #11
    s.or         s3, s4, s7
    v.insert     v4, s2, #8
    v.insert     v2, s6, #9
    v.extract    s2, v3, #11
    s.shli       s4, s5, #32
    v.extract    s5, v0, #11
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s3
    v.extract    s3, v7, #12
    s.or         s8, s2, s4
    v.extract    s2, v1, #12
    s.or         s4, s5, s7
    v.insert     v4, s1, #9
    v.insert     v2, s6, #10
    v.extract    s1, v3, #12
    s.shli       s5, s3, #32
    v.extract    s3, v0, #12
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s4
    v.extract    s4, v7, #13
    s.or         s8, s1, s5
    v.extract    s1, v1, #13
    s.or         s5, s3, s7
    v.insert     v4, s2, #10
    v.insert     v2, s6, #11
    v.extract    s2, v3, #13
    s.shli       s3, s4, #32
    v.extract    s4, v0, #13
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s5
    v.extract    s5, v7, #14
    s.or         s8, s2, s3
    v.extract    s2, v1, #14
    s.or         s3, s4, s7
    v.insert     v4, s1, #11
    v.insert     v2, s6, #12
    v.extract    s1, v3, #14
    s.shli       s4, s5, #32
    v.extract    s5, v0, #14
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s3
    v.extract    s3, v7, #15
    s.or         s8, s1, s4
    v.extract    s1, v1, #15
    s.or         s4, s5, s7
    v.insert     v4, s2, #12
    v.insert     v2, s6, #13
    v.extract    s2, v3, #15
    s.shli       s5, s3, #32
    v.extract    s3, v0, #15
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s4
    s.or         s4, s2, s5
    s.or         s2, s3, s7
    v.insert     v4, s1, #13
    v.insert     v2, s6, #14
    s.lshri      s1, s6, #32
    s.add        s3, s4, s2
    v.insert     v4, s1, #14
    v.insert     v2, s3, #15
    v.movi       v0, #31
    s.lshri      s1, s3, #32
    v.movi       v1, #1
    v.insert     v4, s1, #15
    v.ashr       v3, v2, v0
    v.movi       v0, #0
    s.movz       s1, #0
    v.cmp.ne     p2, v4, v3
    @p2 v.sel        v3, v1, v0
    v.reduce.or  s2, v3
    s.cmp.eq     s3, s2, s1
    br.nz        s3, narrow_ok_2
    trap         #677220
narrow_ok_2:
    @p1 v.st.scatter.h [s9, v2], v6
__rctx_next:
    exit
