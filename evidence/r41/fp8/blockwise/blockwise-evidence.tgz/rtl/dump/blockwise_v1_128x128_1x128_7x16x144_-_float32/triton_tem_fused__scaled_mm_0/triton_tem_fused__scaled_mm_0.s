    s.rdspecial  s1, pid.x
    s.movz       s2, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s3, s1, s2
    s.rdspecial  s1, arg_base
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #16
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s3
    s.ld.d       s4, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    v.add        v5, v4, v0
    v.movi       v0, #32
    s.ld.d       s5, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    v.iota       v4                              // arange(0, VLEN)
    v.add        v6, v1, v2
    s.ld.d       s6, [s1, #16]                   // arg_SA: device_ptr64 at arg_base+16
    v.iota       v1                              // arange(0, VLEN)
    v.add        v2, v3, v0
    s.ld.d       s7, [s1, #24]                   // arg_SB: device_ptr64 at arg_base+24
    v.movi       v0, #48
    s.ld.d       s8, [s1, #32]                   // out_ptr0: device_ptr64 at arg_base+32
    v.movi       v3, #7
    v.movi       v7, #0
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #64
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #80
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #96
    v.add        v14, v1, v0
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.lt     p1, v5, v7
    v.cmp.lt     p2, v3, v7
    v.add        v1, v8, v9
    v.movi       v8, #112
    v.add        v9, v10, v11
    v.sub        v10, v7, v5
    v.add        v11, v12, v13
    v.sub        v12, v7, v3
    v.add        v13, v0, v8
    v.movi       v0, #1
    @p1 v.sel        v8, v10, v5
    @p2 v.sel        v5, v12, v3
    v.movi       v3, #0
    v.movi       v10, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v12, s1
    v.shl        v15, v10, v0
    v.lshr       v16, v8, v12
    v.cmp.lt     p2, v10, v7
    v.and        v17, v16, v0
    v.shl        v16, v0, v12
    v.or         v12, v15, v17
    s.subi       s9, s1, #1
    v.cmp.geu    p3, v12, v5
    p.or         p4, p2, p3
    v.sub        v15, v12, v5
    @p4 v.sel        v17, v16, v7
    @p4 v.sel        v16, v15, v12
    v.or         v12, v3, v17
    v.mov        v10, v16
    v.mov        v3, v12
    s.mov        s1, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s1, s9
    br.nz        s10, idiv_1
    v.sub        v0, v7, v10
    @p1 v.sel        v3, v0, v10
    v.movi       v0, #16
    v.movi       v5, #0
    v.movi       v7, #1
    v.cmp.lt     p1, v4, v5
    v.cmp.lt     p2, v0, v5
    v.sub        v7, v5, v4
    @p1 v.sel        v8, v7, v4
    v.sub        v4, v5, v0
    @p2 v.sel        v7, v4, v0
    v.movi       v0, #15
    v.and        v4, v8, v0
    v.sub        v0, v5, v4
    @p1 v.sel        v5, v0, v4
    v.movi       v0, #16
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p1, v6, v4
    v.cmp.lt     p2, v0, v4
    v.sub        v7, v4, v6
    @p1 v.sel        v8, v7, v6
    v.sub        v6, v4, v0
    @p2 v.sel        v7, v6, v0
    v.movi       v0, #15
    v.and        v6, v8, v0
    v.sub        v0, v4, v6
    @p1 v.sel        v4, v0, v6
    v.movi       v0, #16
    v.movi       v6, #0
    v.movi       v7, #1
    v.cmp.lt     p1, v2, v6
    v.cmp.lt     p2, v0, v6
    v.sub        v7, v6, v2
    @p1 v.sel        v8, v7, v2
    v.sub        v2, v6, v0
    @p2 v.sel        v7, v2, v0
    v.movi       v0, #15
    v.and        v2, v8, v0
    v.sub        v0, v6, v2
    @p1 v.sel        v6, v0, v2
    v.movi       v0, #16
    v.movi       v2, #0
    v.movi       v7, #1
    v.cmp.lt     p1, v14, v2
    v.cmp.lt     p2, v0, v2
    v.sub        v7, v2, v14
    @p1 v.sel        v8, v7, v14
    v.sub        v7, v2, v0
    @p2 v.sel        v10, v7, v0
    v.movi       v0, #15
    v.and        v7, v8, v0
    v.sub        v0, v2, v7
    @p1 v.sel        v2, v0, v7
    v.movi       v0, #16
    v.movi       v7, #0
    v.movi       v8, #1
    v.cmp.lt     p1, v1, v7
    v.cmp.lt     p2, v0, v7
    v.sub        v8, v7, v1
    @p1 v.sel        v10, v8, v1
    v.sub        v1, v7, v0
    @p2 v.sel        v8, v1, v0
    v.movi       v0, #15
    v.and        v1, v10, v0
    v.sub        v0, v7, v1
    @p1 v.sel        v7, v0, v1
    v.movi       v0, #16
    v.movi       v1, #0
    v.movi       v8, #1
    v.cmp.lt     p1, v9, v1
    v.cmp.lt     p2, v0, v1
    v.sub        v8, v1, v9
    @p1 v.sel        v10, v8, v9
    v.sub        v8, v1, v0
    @p2 v.sel        v9, v8, v0
    v.movi       v0, #15
    v.and        v8, v10, v0
    v.sub        v0, v1, v8
    @p1 v.sel        v1, v0, v8
    v.movi       v0, #16
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p1, v11, v8
    v.cmp.lt     p2, v0, v8
    v.sub        v9, v8, v11
    @p1 v.sel        v10, v9, v11
    v.sub        v9, v8, v0
    @p2 v.sel        v11, v9, v0
    v.movi       v0, #15
    v.and        v9, v10, v0
    v.sub        v0, v8, v9
    @p1 v.sel        v8, v0, v9
    v.movi       v0, #16
    v.movi       v9, #0
    v.movi       v10, #1
    v.cmp.lt     p1, v13, v9
    v.cmp.lt     p2, v0, v9
    v.sub        v10, v9, v13
    @p1 v.sel        v11, v10, v13
    v.sub        v10, v9, v0
    @p2 v.sel        v12, v10, v0
    v.movi       v0, #15
    v.and        v10, v11, v0
    v.sub        v0, v9, v10
    @p1 v.sel        v9, v0, v10
    s.movz       s1, #32
    s.movz       s9, #48
    s.movz       s10, #64
    s.movz       s11, #80
    s.movz       s12, #96
    s.movz       s13, #112
    v.movi       v0, #128
    v.movi       v10, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v3, v10
    v.cmp.lt     p2, v0, v10
    v.sub        v11, v10, v3
    @p1 v.sel        v12, v11, v3
    v.sub        v11, v10, v0
    @p2 v.sel        v13, v11, v0
    v.movi       v0, #7
    v.lshr       v11, v12, v0
    v.sub        v0, v10, v11
    @p1 v.sel        v10, v0, v11
    s.movz       s14, #2
    v.movi       v0, #2
    v.mul        v11, v10, v0
    s.movz       s15, #0
    s.movz       s16, #1
    s.addi       s17, s15, #0
    s.movz       s18, #0
    s.addi       s19, s18, #0
    s.movz       s18, #0
    s.addi       s20, s18, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_2:
    s.cmp.ge     s18, s17, s14
    br.nz        s18, endfor_3
    s.movz       s18, #128
    s.mul        s21, s17, s18
    s.movz       s18, #144
    s.sub        s22, s18, s21
    v.splat      v0, s17
    s.shli       s18, s17, #2                    // element offset -> bytes (x4)
    s.add        s21, s6, s18                    // &arg_SA[...]
    v.ld.gather.w v0, [s21, v11]                 // index is in elements (ISA sec 9.1)
    s.mul        s18, s17, s2
    v.splat      v10, s18
    v.splat      v10, s18
    v.splat      v10, s18
    v.splat      v10, s18
    v.splat      v10, s18
    v.splat      v10, s18
    v.splat      v10, s18
    v.splat      v10, s18
    s.shli       s21, s18, #2                    // element offset -> bytes (x4)
    s.add        s18, s7, s21                    // &arg_SB[...]
    v.ld.gather.w v10, [s18, v5]                 // index is in elements (ISA sec 9.1)
    s.add        s18, s7, s21                    // &arg_SB[...]
    v.ld.gather.w v12, [s18, v4]                 // index is in elements (ISA sec 9.1)
    s.add        s18, s7, s21                    // &arg_SB[...]
    v.ld.gather.w v13, [s18, v6]                 // index is in elements (ISA sec 9.1)
    s.add        s18, s7, s21                    // &arg_SB[...]
    v.ld.gather.w v14, [s18, v2]                 // index is in elements (ISA sec 9.1)
    s.add        s18, s7, s21                    // &arg_SB[...]
    v.ld.gather.w v15, [s18, v7]                 // index is in elements (ISA sec 9.1)
    s.add        s18, s7, s21                    // &arg_SB[...]
    v.ld.gather.w v16, [s18, v1]                 // index is in elements (ISA sec 9.1)
    s.add        s18, s7, s21                    // &arg_SB[...]
    v.ld.gather.w v17, [s18, v8]                 // index is in elements (ISA sec 9.1)
    s.add        s18, s7, s21                    // &arg_SB[...]
    v.ld.gather.w v18, [s18, v9]                 // index is in elements (ISA sec 9.1)
    s.movz       s18, #144
    v.splat      v19, s18
    v.mul        v20, v5, v19
    s.movz       s18, #144
    v.splat      v19, s18
    v.mul        v21, v4, v19
    s.movz       s18, #144
    v.splat      v19, s18
    v.mul        v22, v6, v19
    s.movz       s18, #144
    v.splat      v19, s18
    v.mul        v23, v2, v19
    s.movz       s18, #144
    v.splat      v19, s18
    v.mul        v24, v7, v19
    s.movz       s18, #144
    v.splat      v19, s18
    v.mul        v25, v1, v19
    s.movz       s18, #144
    v.splat      v19, s18
    v.mul        v26, v8, v19
    s.movz       s18, #144
    v.splat      v19, s18
    v.mul        v27, v9, v19
    s.add        s18, s15, s22
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s21, arg_base
    s.ld.d       s23, [s21, #40]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.movi       v19, #0
    v.movi       v28, #0
    v.iota       v29                             // arange(0, VLEN)
    s.movz       s21, #0
    s.cmp.ge     s24, s18, s21
    v.extract    s21, v5, #0
    v.splat      v30, s21
    v.add        v31, v30, v29
    v.sub        v30, v5, v31
    v.reduce.or  s25, v30
    s.movz       s26, #0
    s.cmp.eq     s27, s25, s26
    s.movz       s25, #0
    s.cmp.ge     s26, s21, s25
    s.and        s25, s27, s26
    s.and        s26, s25, s24
    v.insert     v19, s26, #0
    v.insert     v28, s21, #0
    v.extract    s21, v4, #0
    v.splat      v30, s21
    v.add        v31, v30, v29
    v.sub        v30, v4, v31
    v.reduce.or  s25, v30
    s.movz       s26, #0
    s.cmp.eq     s27, s25, s26
    s.movz       s25, #0
    s.cmp.ge     s26, s21, s25
    s.and        s25, s27, s26
    s.and        s26, s25, s24
    v.insert     v19, s26, #1
    v.insert     v28, s21, #1
    v.extract    s21, v6, #0
    v.splat      v30, s21
    v.add        v31, v30, v29
    v.sub        v30, v6, v31
    v.reduce.or  s25, v30
    s.movz       s26, #0
    s.cmp.eq     s27, s25, s26
    s.movz       s25, #0
    s.cmp.ge     s26, s21, s25
    s.and        s25, s27, s26
    s.and        s26, s25, s24
    v.insert     v19, s26, #2
    v.insert     v28, s21, #2
    v.extract    s21, v2, #0
    v.splat      v30, s21
    v.add        v31, v30, v29
    v.sub        v30, v2, v31
    v.reduce.or  s25, v30
    s.movz       s26, #0
    s.cmp.eq     s27, s25, s26
    s.movz       s25, #0
    s.cmp.ge     s26, s21, s25
    s.and        s25, s27, s26
    s.and        s26, s25, s24
    v.insert     v19, s26, #3
    v.insert     v28, s21, #3
    v.extract    s21, v7, #0
    v.splat      v30, s21
    v.add        v31, v30, v29
    v.sub        v30, v7, v31
    v.reduce.or  s25, v30
    s.movz       s26, #0
    s.cmp.eq     s27, s25, s26
    s.movz       s25, #0
    s.cmp.ge     s26, s21, s25
    s.and        s25, s27, s26
    s.and        s26, s25, s24
    v.insert     v19, s26, #4
    v.insert     v28, s21, #4
    v.extract    s21, v1, #0
    v.splat      v30, s21
    v.add        v31, v30, v29
    v.sub        v30, v1, v31
    v.reduce.or  s25, v30
    s.movz       s26, #0
    s.cmp.eq     s27, s25, s26
    s.movz       s25, #0
    s.cmp.ge     s26, s21, s25
    s.and        s25, s27, s26
    s.and        s26, s25, s24
    v.insert     v19, s26, #5
    v.insert     v28, s21, #5
    v.extract    s21, v8, #0
    v.splat      v30, s21
    v.add        v31, v30, v29
    v.sub        v30, v8, v31
    v.reduce.or  s25, v30
    s.movz       s26, #0
    s.cmp.eq     s27, s25, s26
    s.movz       s25, #0
    s.cmp.ge     s26, s21, s25
    s.and        s25, s27, s26
    s.and        s26, s25, s24
    v.insert     v19, s26, #6
    v.insert     v28, s21, #6
    v.extract    s21, v9, #0
    v.splat      v30, s21
    v.add        v31, v30, v29
    v.sub        v29, v9, v31
    v.reduce.or  s25, v29
    s.movz       s26, #0
    s.cmp.eq     s27, s25, s26
    s.movz       s25, #0
    s.cmp.ge     s26, s21, s25
    s.and        s25, s27, s26
    s.and        s26, s25, s24
    v.insert     v19, s26, #7
    v.insert     v28, s21, #7
    s.add        s21, s5, s20
    s.addi       s24, s23, #0                    // TensorMap 0: W's rows for a transposed FP8 B
    s.movz       s25, #0
    s.st.d       [s24, #0], s21
    .li       s21, #2147483647
    s.st.d       [s24, #8], s21
    s.st.d       [s24, #16], s18
    s.movz       s21, #144
    s.st.d       [s24, #48], s21
    s.movz       s21, #1
    s.st.d       [s24, #56], s21
    .li       s21, #137438953488
    s.st.d       [s24, #88], s21
    .li       s21, #7705171329024
    s.st.d       [s24, #104], s21
    td.load      d0, [s24]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s21, s23, #256
    s.addi       s24, s23, #768                  // TensorMap 1: the gathered fallback B tile
    s.movz       s25, #0
    s.st.d       [s24, #0], s21
    s.movz       s21, #32
    s.st.d       [s24, #8], s21
    s.movz       s21, #16
    s.st.d       [s24, #16], s21
    s.movz       s21, #16
    s.st.d       [s24, #48], s21
    s.movz       s21, #1
    s.st.d       [s24, #56], s21
    .li       s21, #68719476768
    s.st.d       [s24, #88], s21
    .li       s21, #7705171329024
    s.st.d       [s24, #104], s21
    td.load      d1, [s24]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    s.addi       s21, s23, #1024                 // 512 bytes of repack scratch
    s.movz       s24, #144
    v.splat      v29, s24
    v.mul        v30, v3, v29
    v.extract    s24, v30, #0
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.iota       v29                             // arange(0, VLEN)
    s.movz       s25, #0
    s.add        s26, s25, s22                   // the tile origin
    v.splat      v31, s26
    v.cmp.lt     p1, v29, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #0
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #1
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #32
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #2
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #64
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #3
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #96
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #4
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #128
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #5
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #160
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #6
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #192
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #7
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #224
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #8
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #256
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #9
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #288
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #10
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #320
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #11
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #352
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #12
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #384
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #13
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #416
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #14
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #448
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #15
    s.add        s25, s24, s19
    s.add        s24, s4, s25
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s24, #0]
    s.addi       s24, s21, #480
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #0
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    s.movz       s24, #0
    s.add        s26, s24, s2                    // the tile origin
    v.splat      v31, s26
    v.add        v32, v29, v31
    s.movz       s24, #0
    s.add        s26, s24, s22                   // the tile origin
    v.splat      v31, s26
    v.cmp.lt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #16
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #1
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #48
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #2
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #80
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #3
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #112
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #4
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #144
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #5
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #176
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #6
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #208
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #7
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #240
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #8
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #272
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #9
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #304
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #10
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #336
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #11
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #368
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #12
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #400
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #13
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #432
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #14
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #464
    v.st.b       [s24, #0], v31
    v.extract    s24, v30, #15
    s.add        s25, s24, s19
    s.addi       s24, s25, #16
    s.add        s25, s4, s24
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s25, #0]
    s.addi       s24, s21, #496
    v.st.b       [s24, #0], v31
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v31, [s21, #0]
    v.mov        v48, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s21, #64
    v.ld.w       v31, [s24, #0]
    v.mov        v49, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s21, #128
    v.ld.w       v31, [s24, #0]
    v.mov        v50, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s21, #192
    v.ld.w       v31, [s24, #0]
    v.mov        v51, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s21, #256
    v.ld.w       v31, [s24, #0]
    v.mov        v52, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s21, #320
    v.ld.w       v31, [s24, #0]
    v.mov        v53, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s21, #384
    v.ld.w       v31, [s24, #0]
    v.mov        v54, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s21, #448
    v.ld.w       v31, [s24, #0]
    v.mov        v55, v31                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s21, v19, #0
    br.nz        s21, x8dot_done_4
    s.movz       s24, #0
    s.add        s25, s5, s20
    s.addi       s26, s24, #0
    s.addi       s24, s23, #256
x8dot_row_5:
    s.addi       s27, s18, #0
    v.movi       v31, #0
    s.sub        s28, s27, s26
    s.add        s27, s25, s26
    v.splat      v32, s28
    s.shli       s28, s26, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s27, v20]            // index is in elements (ISA sec 9.1)
    s.add        s27, s24, s28
    s.addi       s28, s26, #1
    s.movz       s29, #32
    v.st.b       [s27, #0], v31
    fence.acq_rel.device
    s.mov        s26, s28
    s.cmp.lt     s27, s26, s29
    br.nz        s27, x8dot_row_5
x8dot_done_4:
    v.splat      v31, s21
    v.movi       v32, #0
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s25, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s21
    v.movi       v32, #0
    s.movz       s21, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s26, s25                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s27, s21                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s26, s24            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s21, #0
    v.extract    s25, v28, #0
    s.mov        s26, s25                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s27, s21                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s26, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    mb.arm       s21, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s25, v19, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s21
    mb.wait      s21
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s25, x8dot_done_6
    s.movz       s26, #0
    s.add        s27, s5, s20
    s.addi       s28, s26, #0
    s.addi       s26, s23, #256
x8dot_row_7:
    s.addi       s29, s18, #0
    v.movi       v31, #0
    s.sub        s30, s29, s28
    s.add        s29, s27, s28
    v.splat      v32, s30
    s.shli       s30, s28, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s29, v21]            // index is in elements (ISA sec 9.1)
    s.add        s29, s26, s30
    s.addi       s30, s28, #1
    s.movz       s31, #32
    v.st.b       [s29, #0], v31
    fence.acq_rel.device
    s.mov        s28, s30
    s.cmp.lt     s29, s28, s31
    br.nz        s29, x8dot_row_7
x8dot_done_6:
    v.splat      v31, s25
    v.movi       v32, #0
    mb.arm       s26, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s27, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s25
    v.movi       v32, #0
    s.movz       s25, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s28, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s25                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s28, s26            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s25, #0
    v.extract    s27, v28, #1
    s.mov        s28, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s25                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s28, s26          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s26
    mb.arm       s25, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s27, v19, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s25
    mb.wait      s25
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s27, x8dot_done_8
    s.movz       s28, #0
    s.add        s29, s5, s20
    s.addi       s30, s28, #0
    s.addi       s28, s23, #256
x8dot_row_9:
    s.addi       s31, s18, #0
    v.movi       v31, #0
    s.sub        s32, s31, s30
    s.add        s31, s29, s30
    v.splat      v32, s32
    s.shli       s32, s30, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s31, v22]            // index is in elements (ISA sec 9.1)
    s.add        s31, s28, s32
    s.addi       s32, s30, #1
    s.movz       s33, #32
    v.st.b       [s31, #0], v31
    fence.acq_rel.device
    s.mov        s30, s32
    s.cmp.lt     s31, s30, s33
    br.nz        s31, x8dot_row_9
x8dot_done_8:
    v.splat      v31, s27
    v.movi       v32, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s27
    v.movi       v32, #0
    s.movz       s27, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s30, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s30, s28            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s27, #0
    v.extract    s29, v28, #2
    s.mov        s30, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s30, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s29, v19, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s27
    mb.wait      s27
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s29, x8dot_done_10
    s.movz       s30, #0
    s.add        s31, s5, s20
    s.addi       s32, s30, #0
    s.addi       s30, s23, #256
x8dot_row_11:
    s.addi       s33, s18, #0
    v.movi       v31, #0
    s.sub        s34, s33, s32
    s.add        s33, s31, s32
    v.splat      v32, s34
    s.shli       s34, s32, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s33, v23]            // index is in elements (ISA sec 9.1)
    s.add        s33, s30, s34
    s.addi       s34, s32, #1
    s.movz       s35, #32
    v.st.b       [s33, #0], v31
    fence.acq_rel.device
    s.mov        s32, s34
    s.cmp.lt     s33, s32, s35
    br.nz        s33, x8dot_row_11
x8dot_done_10:
    v.splat      v31, s29
    v.movi       v32, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s29
    v.movi       v32, #0
    s.movz       s29, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s32, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s32, s30            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s29, #0
    v.extract    s31, v28, #3
    s.mov        s32, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v19, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s31, x8dot_done_12
    s.movz       s32, #0
    s.add        s33, s5, s20
    s.addi       s34, s32, #0
    s.addi       s32, s23, #256
x8dot_row_13:
    s.addi       s35, s18, #0
    v.movi       v31, #0
    s.sub        s36, s35, s34
    s.add        s35, s33, s34
    v.splat      v32, s36
    s.shli       s36, s34, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s35, v24]            // index is in elements (ISA sec 9.1)
    s.add        s35, s32, s36
    s.addi       s36, s34, #1
    s.movz       s37, #32
    v.st.b       [s35, #0], v31
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s35, s34, s37
    br.nz        s35, x8dot_row_13
x8dot_done_12:
    v.splat      v31, s31
    v.movi       v32, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s31
    v.movi       v32, #0
    s.movz       s31, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s32            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s31, #0
    v.extract    s33, v28, #4
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v19, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_14
    s.movz       s34, #0
    s.add        s35, s5, s20
    s.addi       s36, s34, #0
    s.addi       s34, s23, #256
x8dot_row_15:
    s.addi       s37, s18, #0
    v.movi       v31, #0
    s.sub        s38, s37, s36
    s.add        s37, s35, s36
    v.splat      v32, s38
    s.shli       s38, s36, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s37, v25]            // index is in elements (ISA sec 9.1)
    s.add        s37, s34, s38
    s.addi       s38, s36, #1
    s.movz       s39, #32
    v.st.b       [s37, #0], v31
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_15
x8dot_done_14:
    v.splat      v31, s33
    v.movi       v32, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s33
    v.movi       v32, #0
    s.movz       s33, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s34            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s33, #0
    v.extract    s35, v28, #5
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v19, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_16
    s.movz       s36, #0
    s.add        s37, s5, s20
    s.addi       s38, s36, #0
    s.addi       s36, s23, #256
x8dot_row_17:
    s.addi       s39, s18, #0
    v.movi       v31, #0
    s.sub        s40, s39, s38
    s.add        s39, s37, s38
    v.splat      v32, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s39, v26]            // index is in elements (ISA sec 9.1)
    s.add        s39, s36, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v31
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_17
x8dot_done_16:
    v.splat      v31, s35
    v.movi       v32, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s35
    v.movi       v32, #0
    s.movz       s35, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s35, #0
    v.extract    s37, v28, #6
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v19, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_18
    s.movz       s38, #0
    s.add        s39, s5, s20
    s.addi       s40, s38, #0
    s.addi       s38, s23, #256
x8dot_row_19:
    s.addi       s41, s18, #0
    v.movi       v31, #0
    s.sub        s42, s41, s40
    s.add        s41, s39, s40
    v.splat      v32, s42
    s.shli       s42, s40, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s41, v27]            // index is in elements (ISA sec 9.1)
    s.add        s41, s38, s42
    s.addi       s42, s40, #1
    s.movz       s43, #32
    v.st.b       [s41, #0], v31
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s41, s40, s43
    br.nz        s41, x8dot_row_19
x8dot_done_18:
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v31, s37
    v.movi       v32, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s37
    v.movi       v32, #0
    v.cmp.eq     p2, v31, v32
    s.movz       s37, #0
    s.movz       s39, #0
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s38            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s37, v28, #7
    s.movz       s39, #0
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v48, v56, s37
    mb.wait      s37
    s.addi       s39, s23, #1536                 // 512 bytes of repack scratch
    v.extract    s40, v30, #0
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    s.movz       s40, #0
    s.add        s42, s40, s1                    // the tile origin
    v.splat      v31, s42
    v.add        v32, v29, v31
    s.movz       s40, #0
    s.add        s42, s40, s22                   // the tile origin
    v.splat      v31, s42
    v.cmp.lt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #0
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #1
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #32
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #2
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #64
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #3
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #96
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #4
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #128
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #5
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #160
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #6
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #192
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #7
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #224
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #8
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #256
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #9
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #288
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #10
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #320
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #11
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #352
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #12
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #384
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #13
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #416
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #14
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #448
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #15
    s.add        s41, s40, s19
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #480
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #0
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    s.movz       s40, #0
    s.add        s42, s40, s9                    // the tile origin
    v.splat      v31, s42
    v.add        v32, v29, v31
    s.movz       s40, #0
    s.add        s42, s40, s22                   // the tile origin
    v.splat      v31, s42
    v.cmp.lt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #16
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #1
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #48
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #2
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #80
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #3
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #112
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #4
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #144
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #5
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #176
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #6
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #208
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #7
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #240
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #8
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #272
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #9
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #304
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #10
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #336
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #11
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #368
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #12
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #400
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #13
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #432
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #14
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #464
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #15
    s.add        s41, s40, s19
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #496
    v.st.b       [s40, #0], v31
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v31, [s39, #0]
    v.mov        v48, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #64
    v.ld.w       v31, [s40, #0]
    v.mov        v49, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #128
    v.ld.w       v31, [s40, #0]
    v.mov        v50, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #192
    v.ld.w       v31, [s40, #0]
    v.mov        v51, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #256
    v.ld.w       v31, [s40, #0]
    v.mov        v52, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #320
    v.ld.w       v31, [s40, #0]
    v.mov        v53, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #384
    v.ld.w       v31, [s40, #0]
    v.mov        v54, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #448
    v.ld.w       v31, [s40, #0]
    v.mov        v55, v31                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s39, v19, #0
    br.nz        s39, x8dot_done_20
    s.movz       s40, #0
    s.add        s41, s5, s20
    s.addi       s42, s40, #0
    s.addi       s40, s41, #32
    s.addi       s41, s23, #256
x8dot_row_21:
    s.addi       s43, s18, #-32
    v.movi       v31, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v32, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s43, v20]            // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.addi       s44, s42, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v31
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s45
    br.nz        s43, x8dot_row_21
x8dot_done_20:
    v.splat      v31, s39
    v.movi       v32, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s39
    v.movi       v32, #0
    s.movz       s39, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s40            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s39, #32
    v.extract    s41, v28, #0
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v19, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s41, x8dot_done_22
    s.movz       s42, #0
    s.add        s43, s5, s20
    s.addi       s44, s42, #0
    s.addi       s42, s43, #32
    s.addi       s43, s23, #256
x8dot_row_23:
    s.addi       s45, s18, #-32
    v.movi       v31, #0
    s.sub        s46, s45, s44
    s.add        s45, s42, s44
    v.splat      v32, s46
    s.shli       s46, s44, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s45, v21]            // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.addi       s46, s44, #1
    s.movz       s47, #32
    v.st.b       [s45, #0], v31
    fence.acq_rel.device
    s.mov        s44, s46
    s.cmp.lt     s45, s44, s47
    br.nz        s45, x8dot_row_23
x8dot_done_22:
    v.splat      v31, s41
    v.movi       v32, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s41
    v.movi       v32, #0
    s.movz       s41, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s44, s42            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s41, #32
    v.extract    s43, v28, #1
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v19, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s43, x8dot_done_24
    s.movz       s44, #0
    s.add        s45, s5, s20
    s.addi       s46, s44, #0
    s.addi       s44, s45, #32
    s.addi       s45, s23, #256
x8dot_row_25:
    s.addi       s47, s18, #-32
    v.movi       v31, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v32, s48
    s.shli       s48, s46, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s47, v22]            // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.addi       s48, s46, #1
    s.movz       s49, #32
    v.st.b       [s47, #0], v31
    fence.acq_rel.device
    s.mov        s46, s48
    s.cmp.lt     s47, s46, s49
    br.nz        s47, x8dot_row_25
x8dot_done_24:
    v.splat      v31, s43
    v.movi       v32, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s43
    v.movi       v32, #0
    s.movz       s43, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s46, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s46, s44            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s43, #32
    v.extract    s45, v28, #2
    s.mov        s46, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v19, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s45, x8dot_done_26
    s.movz       s46, #0
    s.add        s47, s5, s20
    s.addi       s48, s46, #0
    s.addi       s46, s47, #32
    s.addi       s47, s23, #256
x8dot_row_27:
    s.addi       s49, s18, #-32
    v.movi       v31, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v32, s50
    s.shli       s50, s48, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s49, v23]            // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.addi       s50, s48, #1
    s.movz       s51, #32
    v.st.b       [s49, #0], v31
    fence.acq_rel.device
    s.mov        s48, s50
    s.cmp.lt     s49, s48, s51
    br.nz        s49, x8dot_row_27
x8dot_done_26:
    v.splat      v31, s45
    v.movi       v32, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s45
    v.movi       v32, #0
    s.movz       s45, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s48, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s48, s46            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s45, #32
    v.extract    s47, v28, #3
    s.mov        s48, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s48, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v19, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s47, x8dot_done_28
    s.movz       s48, #0
    s.add        s49, s5, s20
    s.addi       s50, s48, #0
    s.addi       s48, s49, #32
    s.addi       s49, s23, #256
x8dot_row_29:
    s.addi       s51, s18, #-32
    v.movi       v31, #0
    s.sub        s52, s51, s50
    s.add        s51, s48, s50
    v.splat      v32, s52
    s.shli       s52, s50, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s51, v24]            // index is in elements (ISA sec 9.1)
    s.add        s51, s49, s52
    s.addi       s52, s50, #1
    s.movz       s53, #32
    v.st.b       [s51, #0], v31
    fence.acq_rel.device
    s.mov        s50, s52
    s.cmp.lt     s51, s50, s53
    br.nz        s51, x8dot_row_29
x8dot_done_28:
    v.splat      v31, s47
    v.movi       v32, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s47
    v.movi       v32, #0
    s.movz       s47, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s50, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s50, s48            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s47, #32
    v.extract    s49, v28, #4
    s.mov        s50, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v19, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s49, x8dot_done_30
    s.movz       s50, #0
    s.add        s51, s5, s20
    s.addi       s52, s50, #0
    s.addi       s50, s51, #32
    s.addi       s51, s23, #256
x8dot_row_31:
    s.addi       s53, s18, #-32
    v.movi       v31, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v32, s54
    s.shli       s54, s52, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s53, v25]            // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.addi       s54, s52, #1
    s.movz       s55, #32
    v.st.b       [s53, #0], v31
    fence.acq_rel.device
    s.mov        s52, s54
    s.cmp.lt     s53, s52, s55
    br.nz        s53, x8dot_row_31
x8dot_done_30:
    v.splat      v31, s49
    v.movi       v32, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s51, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s49
    v.movi       v32, #0
    s.movz       s49, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s52, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s52, s50            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s49, #32
    v.extract    s51, v28, #5
    s.mov        s52, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v19, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s51, x8dot_done_32
    s.movz       s52, #0
    s.add        s53, s5, s20
    s.addi       s54, s52, #0
    s.addi       s52, s53, #32
    s.addi       s53, s23, #256
x8dot_row_33:
    s.addi       s55, s18, #-32
    v.movi       v31, #0
    s.sub        s56, s55, s54
    s.add        s55, s52, s54
    v.splat      v32, s56
    s.shli       s56, s54, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s55, v26]            // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    s.addi       s56, s54, #1
    s.movz       s57, #32
    v.st.b       [s55, #0], v31
    fence.acq_rel.device
    s.mov        s54, s56
    s.cmp.lt     s55, s54, s57
    br.nz        s55, x8dot_row_33
x8dot_done_32:
    v.splat      v31, s51
    v.movi       v32, #0
    mb.arm       s52, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s51
    v.movi       v32, #0
    s.movz       s51, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s54, s52            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s51, #32
    v.extract    s53, v28, #6
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v19, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_34
    s.movz       s54, #0
    s.add        s55, s5, s20
    s.addi       s56, s54, #0
    s.addi       s54, s55, #32
    s.addi       s55, s23, #256
x8dot_row_35:
    s.addi       s57, s18, #-32
    v.movi       v31, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v32, s58
    s.shli       s58, s56, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s57, v27]            // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.addi       s58, s56, #1
    s.movz       s59, #32
    v.st.b       [s57, #0], v31
    fence.acq_rel.device
    s.mov        s56, s58
    s.cmp.lt     s57, s56, s59
    br.nz        s57, x8dot_row_35
x8dot_done_34:
    mb.arm       s54, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v31, s53
    v.movi       v32, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s53
    v.movi       v32, #0
    v.cmp.eq     p2, v31, v32
    s.movz       s53, #0
    s.movz       s55, #0
    s.mov        s56, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s56, s54            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s53, v28, #7
    s.movz       s55, #32
    s.mov        s56, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s56, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v48, v56, s53
    mb.wait      s53
    s.addi       s55, s23, #2048                 // 512 bytes of repack scratch
    v.extract    s56, v30, #0
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    s.movz       s56, #0
    s.add        s58, s56, s10                   // the tile origin
    v.splat      v31, s58
    v.add        v32, v29, v31
    s.movz       s56, #0
    s.add        s58, s56, s22                   // the tile origin
    v.splat      v31, s58
    v.cmp.lt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #0
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #1
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #32
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #2
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #64
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #3
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #96
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #4
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #128
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #5
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #160
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #6
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #192
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #7
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #224
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #8
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #256
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #9
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #288
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #10
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #320
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #11
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #352
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #12
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #384
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #13
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #416
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #14
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #448
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #15
    s.add        s57, s56, s19
    s.addi       s56, s57, #64
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #480
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #0
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    s.movz       s56, #0
    s.add        s58, s56, s11                   // the tile origin
    v.splat      v31, s58
    v.add        v32, v29, v31
    s.movz       s56, #0
    s.add        s58, s56, s22                   // the tile origin
    v.splat      v31, s58
    v.cmp.lt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #16
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #1
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #48
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #2
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #80
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #3
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #112
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #4
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #144
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #5
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #176
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #6
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #208
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #7
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #240
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #8
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #272
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #9
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #304
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #10
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #336
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #11
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #368
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #12
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #400
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #13
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #432
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #14
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #464
    v.st.b       [s56, #0], v31
    v.extract    s56, v30, #15
    s.add        s57, s56, s19
    s.addi       s56, s57, #80
    s.add        s57, s4, s56
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s57, #0]
    s.addi       s56, s55, #496
    v.st.b       [s56, #0], v31
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v31, [s55, #0]
    v.mov        v48, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s56, s55, #64
    v.ld.w       v31, [s56, #0]
    v.mov        v49, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s56, s55, #128
    v.ld.w       v31, [s56, #0]
    v.mov        v50, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s56, s55, #192
    v.ld.w       v31, [s56, #0]
    v.mov        v51, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s56, s55, #256
    v.ld.w       v31, [s56, #0]
    v.mov        v52, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s56, s55, #320
    v.ld.w       v31, [s56, #0]
    v.mov        v53, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s56, s55, #384
    v.ld.w       v31, [s56, #0]
    v.mov        v54, v31                        // hand off through the shared window (sec 7.3)
    s.addi       s56, s55, #448
    v.ld.w       v31, [s56, #0]
    v.mov        v55, v31                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s55, v19, #0
    br.nz        s55, x8dot_done_36
    s.movz       s56, #0
    s.add        s57, s5, s20
    s.addi       s58, s56, #0
    s.addi       s56, s57, #64
    s.addi       s57, s23, #256
x8dot_row_37:
    s.addi       s59, s18, #-64
    v.movi       v31, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v32, s60
    s.shli       s60, s58, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s59, v20]            // index is in elements (ISA sec 9.1)
    s.add        s59, s57, s60
    s.addi       s60, s58, #1
    s.movz       s21, #32
    v.st.b       [s59, #0], v31
    fence.acq_rel.device
    s.mov        s58, s60
    s.cmp.lt     s24, s58, s21
    br.nz        s24, x8dot_row_37
x8dot_done_36:
    v.splat      v31, s55
    v.movi       v32, #0
    mb.arm       s21, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s24, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s55
    v.movi       v32, #0
    s.movz       s25, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s26, s24                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s27, s25                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s26, s21            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s24, #64
    v.extract    s25, v28, #0
    s.mov        s26, s25                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s27, s24                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s26, s21          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s21
    mb.arm       s24, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s25, v19, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s24
    mb.wait      s24
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s25, x8dot_done_38
    s.movz       s26, #0
    s.add        s27, s5, s20
    s.addi       s28, s26, #0
    s.addi       s26, s27, #64
    s.addi       s27, s23, #256
x8dot_row_39:
    s.addi       s29, s18, #-64
    v.movi       v31, #0
    s.sub        s30, s29, s28
    s.add        s29, s26, s28
    v.splat      v32, s30
    s.shli       s30, s28, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s29, v21]            // index is in elements (ISA sec 9.1)
    s.add        s29, s27, s30
    s.addi       s30, s28, #1
    s.movz       s31, #32
    v.st.b       [s29, #0], v31
    fence.acq_rel.device
    s.mov        s28, s30
    s.cmp.lt     s29, s28, s31
    br.nz        s29, x8dot_row_39
x8dot_done_38:
    v.splat      v31, s25
    v.movi       v32, #0
    mb.arm       s26, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s27, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s25
    v.movi       v32, #0
    s.movz       s25, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s28, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s25                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s28, s26            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s25, #64
    v.extract    s27, v28, #1
    s.mov        s28, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s25                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s28, s26          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s26
    mb.arm       s25, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s27, v19, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s25
    mb.wait      s25
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s27, x8dot_done_40
    s.movz       s28, #0
    s.add        s29, s5, s20
    s.addi       s30, s28, #0
    s.addi       s28, s29, #64
    s.addi       s29, s23, #256
x8dot_row_41:
    s.addi       s31, s18, #-64
    v.movi       v31, #0
    s.sub        s32, s31, s30
    s.add        s31, s28, s30
    v.splat      v32, s32
    s.shli       s32, s30, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s31, v22]            // index is in elements (ISA sec 9.1)
    s.add        s31, s29, s32
    s.addi       s32, s30, #1
    s.movz       s33, #32
    v.st.b       [s31, #0], v31
    fence.acq_rel.device
    s.mov        s30, s32
    s.cmp.lt     s31, s30, s33
    br.nz        s31, x8dot_row_41
x8dot_done_40:
    v.splat      v31, s27
    v.movi       v32, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s27
    v.movi       v32, #0
    s.movz       s27, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s30, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s30, s28            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s27, #64
    v.extract    s29, v28, #2
    s.mov        s30, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s30, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s29, v19, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s27
    mb.wait      s27
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s29, x8dot_done_42
    s.movz       s30, #0
    s.add        s31, s5, s20
    s.addi       s32, s30, #0
    s.addi       s30, s31, #64
    s.addi       s31, s23, #256
x8dot_row_43:
    s.addi       s33, s18, #-64
    v.movi       v31, #0
    s.sub        s34, s33, s32
    s.add        s33, s30, s32
    v.splat      v32, s34
    s.shli       s34, s32, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s33, v23]            // index is in elements (ISA sec 9.1)
    s.add        s33, s31, s34
    s.addi       s34, s32, #1
    s.movz       s35, #32
    v.st.b       [s33, #0], v31
    fence.acq_rel.device
    s.mov        s32, s34
    s.cmp.lt     s33, s32, s35
    br.nz        s33, x8dot_row_43
x8dot_done_42:
    v.splat      v31, s29
    v.movi       v32, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s29
    v.movi       v32, #0
    s.movz       s29, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s32, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s32, s30            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s29, #64
    v.extract    s31, v28, #3
    s.mov        s32, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v19, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s31, x8dot_done_44
    s.movz       s32, #0
    s.add        s33, s5, s20
    s.addi       s34, s32, #0
    s.addi       s32, s33, #64
    s.addi       s33, s23, #256
x8dot_row_45:
    s.addi       s35, s18, #-64
    v.movi       v31, #0
    s.sub        s36, s35, s34
    s.add        s35, s32, s34
    v.splat      v32, s36
    s.shli       s36, s34, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s35, v24]            // index is in elements (ISA sec 9.1)
    s.add        s35, s33, s36
    s.addi       s36, s34, #1
    s.movz       s37, #32
    v.st.b       [s35, #0], v31
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s35, s34, s37
    br.nz        s35, x8dot_row_45
x8dot_done_44:
    v.splat      v31, s31
    v.movi       v32, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s31
    v.movi       v32, #0
    s.movz       s31, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s32            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s31, #64
    v.extract    s33, v28, #4
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v19, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_46
    s.movz       s34, #0
    s.add        s35, s5, s20
    s.addi       s36, s34, #0
    s.addi       s34, s35, #64
    s.addi       s35, s23, #256
x8dot_row_47:
    s.addi       s37, s18, #-64
    v.movi       v31, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v32, s38
    s.shli       s38, s36, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s37, v25]            // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.addi       s38, s36, #1
    s.movz       s39, #32
    v.st.b       [s37, #0], v31
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_47
x8dot_done_46:
    v.splat      v31, s33
    v.movi       v32, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s33
    v.movi       v32, #0
    s.movz       s33, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s34            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s33, #64
    v.extract    s35, v28, #5
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v19, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_48
    s.movz       s36, #0
    s.add        s37, s5, s20
    s.addi       s38, s36, #0
    s.addi       s36, s37, #64
    s.addi       s37, s23, #256
x8dot_row_49:
    s.addi       s39, s18, #-64
    v.movi       v31, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v32, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s39, v26]            // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v31
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_49
x8dot_done_48:
    v.splat      v31, s35
    v.movi       v32, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s35
    v.movi       v32, #0
    s.movz       s35, #0
    v.cmp.eq     p2, v31, v32
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s35, #64
    v.extract    s37, v28, #6
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v19, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_50
    s.movz       s38, #0
    s.add        s39, s5, s20
    s.addi       s40, s38, #0
    s.addi       s38, s39, #64
    s.addi       s39, s23, #256
x8dot_row_51:
    s.addi       s41, s18, #-64
    v.movi       v31, #0
    s.sub        s42, s41, s40
    s.add        s41, s38, s40
    v.splat      v32, s42
    s.shli       s42, s40, #4
    v.cmp.gt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s41, v27]            // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.addi       s42, s40, #1
    s.movz       s43, #32
    v.st.b       [s41, #0], v31
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s41, s40, s43
    br.nz        s41, x8dot_row_51
x8dot_done_50:
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v31, s37
    v.movi       v32, #0
    v.cmp.ne     p1, v31, v32
    v.splat      v31, s37
    v.movi       v32, #0
    v.cmp.eq     p2, v31, v32
    s.movz       s37, #0
    s.movz       s39, #0
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s38            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s37, v28, #7
    s.movz       s39, #64
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v48, v56, s37
    mb.wait      s37
    s.addi       s39, s23, #2560                 // 512 bytes of repack scratch
    v.extract    s40, v30, #0
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    s.movz       s40, #0
    s.add        s42, s40, s12                   // the tile origin
    v.splat      v31, s42
    v.add        v32, v29, v31
    s.movz       s40, #0
    s.add        s42, s40, s22                   // the tile origin
    v.splat      v31, s42
    v.cmp.lt     p1, v32, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #0
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #1
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #32
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #2
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #64
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #3
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #96
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #4
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #128
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #5
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #160
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #6
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #192
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #7
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #224
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #8
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #256
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #9
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #288
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #10
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #320
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #11
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #352
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #12
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #384
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #13
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #416
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #14
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #448
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #15
    s.add        s41, s40, s19
    s.addi       s40, s41, #96
    s.add        s41, s4, s40
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s41, #0]
    s.addi       s40, s39, #480
    v.st.b       [s40, #0], v31
    v.extract    s40, v30, #0
    s.add        s41, s40, s19
    s.addi       s40, s41, #112
    s.add        s41, s4, s40
    s.movz       s40, #0
    s.add        s42, s40, s13                   // the tile origin
    v.splat      v31, s42
    v.add        v32, v29, v31
    s.movz       s40, #0
    s.add        s42, s40, s22                   // the tile origin
    v.splat      v29, s42
    v.cmp.lt     p1, v32, v29
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s41, #0]
    s.addi       s22, s39, #16
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #1
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #48
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #2
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #80
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #3
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #112
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #4
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #144
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #5
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #176
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #6
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #208
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #7
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #240
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #8
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #272
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #9
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #304
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #10
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #336
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #11
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #368
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #12
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #400
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #13
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #432
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #14
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #464
    v.st.b       [s22, #0], v29
    v.extract    s22, v30, #15
    s.add        s40, s22, s19
    s.addi       s22, s40, #112
    s.add        s40, s4, s22
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v29, [s40, #0]
    s.addi       s22, s39, #496
    v.st.b       [s22, #0], v29
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v29, [s39, #0]
    v.mov        v48, v29                        // hand off through the shared window (sec 7.3)
    s.addi       s22, s39, #64
    v.ld.w       v29, [s22, #0]
    v.mov        v49, v29                        // hand off through the shared window (sec 7.3)
    s.addi       s22, s39, #128
    v.ld.w       v29, [s22, #0]
    v.mov        v50, v29                        // hand off through the shared window (sec 7.3)
    s.addi       s22, s39, #192
    v.ld.w       v29, [s22, #0]
    v.mov        v51, v29                        // hand off through the shared window (sec 7.3)
    s.addi       s22, s39, #256
    v.ld.w       v29, [s22, #0]
    v.mov        v52, v29                        // hand off through the shared window (sec 7.3)
    s.addi       s22, s39, #320
    v.ld.w       v29, [s22, #0]
    v.mov        v53, v29                        // hand off through the shared window (sec 7.3)
    s.addi       s22, s39, #384
    v.ld.w       v29, [s22, #0]
    v.mov        v54, v29                        // hand off through the shared window (sec 7.3)
    s.addi       s22, s39, #448
    v.ld.w       v29, [s22, #0]
    v.mov        v55, v29                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s22, v19, #0
    br.nz        s22, x8dot_done_52
    s.movz       s39, #0
    s.add        s40, s5, s20
    s.addi       s41, s39, #0
    s.addi       s39, s40, #96
    s.addi       s40, s23, #256
x8dot_row_53:
    s.addi       s42, s18, #-96
    v.movi       v29, #0
    s.sub        s43, s42, s41
    s.add        s42, s39, s41
    v.splat      v30, s43
    s.shli       s43, s41, #4
    v.cmp.gt     p1, v30, v29
    v.movi       v29, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v29, [s42, v20]            // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.addi       s43, s41, #1
    s.movz       s44, #32
    v.st.b       [s42, #0], v29
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s42, s41, s44
    br.nz        s42, x8dot_row_53
x8dot_done_52:
    v.splat      v20, s22
    v.movi       v29, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.cmp.ne     p1, v20, v29
    v.splat      v20, s22
    v.movi       v29, #0
    s.movz       s22, #0
    v.cmp.eq     p2, v20, v29
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s22                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s22, #96
    v.extract    s40, v28, #0
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s22                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s22, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v19, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s22
    mb.wait      s22
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_54
    s.movz       s41, #0
    s.add        s42, s5, s20
    s.addi       s43, s41, #0
    s.addi       s41, s42, #96
    s.addi       s42, s23, #256
x8dot_row_55:
    s.addi       s44, s18, #-96
    v.movi       v20, #0
    s.sub        s45, s44, s43
    s.add        s44, s41, s43
    v.splat      v29, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v29, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s44, v21]            // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v20
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_55
x8dot_done_54:
    v.splat      v20, s40
    v.movi       v21, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.cmp.ne     p1, v20, v21
    v.splat      v20, s40
    v.movi       v21, #0
    s.movz       s40, #0
    v.cmp.eq     p2, v20, v21
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s40, #96
    v.extract    s42, v28, #1
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v19, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_56
    s.movz       s43, #0
    s.add        s44, s5, s20
    s.addi       s45, s43, #0
    s.addi       s43, s44, #96
    s.addi       s44, s23, #256
x8dot_row_57:
    s.addi       s46, s18, #-96
    v.movi       v20, #0
    s.sub        s47, s46, s45
    s.add        s46, s43, s45
    v.splat      v21, s47
    s.shli       s47, s45, #4
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s46, v22]            // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.addi       s47, s45, #1
    s.movz       s48, #32
    v.st.b       [s46, #0], v20
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_57
x8dot_done_56:
    v.splat      v20, s42
    v.movi       v21, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.cmp.ne     p1, v20, v21
    v.splat      v20, s42
    v.movi       v21, #0
    s.movz       s42, #0
    v.cmp.eq     p2, v20, v21
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s42, #96
    v.extract    s44, v28, #2
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v19, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_58
    s.movz       s45, #0
    s.add        s46, s5, s20
    s.addi       s47, s45, #0
    s.addi       s45, s46, #96
    s.addi       s46, s23, #256
x8dot_row_59:
    s.addi       s48, s18, #-96
    v.movi       v20, #0
    s.sub        s49, s48, s47
    s.add        s48, s45, s47
    v.splat      v21, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s48, v23]            // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s48, #0], v20
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_59
x8dot_done_58:
    v.splat      v20, s44
    v.movi       v21, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.cmp.ne     p1, v20, v21
    v.splat      v20, s44
    v.movi       v21, #0
    s.movz       s44, #0
    v.cmp.eq     p2, v20, v21
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s45            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s44, #96
    v.extract    s46, v28, #3
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v19, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_60
    s.movz       s47, #0
    s.add        s48, s5, s20
    s.addi       s49, s47, #0
    s.addi       s47, s48, #96
    s.addi       s48, s23, #256
x8dot_row_61:
    s.addi       s50, s18, #-96
    v.movi       v20, #0
    s.sub        s51, s50, s49
    s.add        s50, s47, s49
    v.splat      v21, s51
    s.shli       s51, s49, #4
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s50, v24]            // index is in elements (ISA sec 9.1)
    s.add        s50, s48, s51
    s.addi       s51, s49, #1
    s.movz       s52, #32
    v.st.b       [s50, #0], v20
    fence.acq_rel.device
    s.mov        s49, s51
    s.cmp.lt     s50, s49, s52
    br.nz        s50, x8dot_row_61
x8dot_done_60:
    v.splat      v20, s46
    v.movi       v21, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    v.cmp.ne     p1, v20, v21
    v.splat      v20, s46
    v.movi       v21, #0
    s.movz       s46, #0
    v.cmp.eq     p2, v20, v21
    s.mov        s49, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s47            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s46, #96
    v.extract    s48, v28, #4
    s.mov        s49, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v19, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_62
    s.movz       s49, #0
    s.add        s50, s5, s20
    s.addi       s51, s49, #0
    s.addi       s49, s50, #96
    s.addi       s50, s23, #256
x8dot_row_63:
    s.addi       s52, s18, #-96
    v.movi       v20, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v21, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s52, v25]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v20
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_63
x8dot_done_62:
    v.splat      v20, s48
    v.movi       v21, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.cmp.ne     p1, v20, v21
    v.splat      v20, s48
    v.movi       v21, #0
    s.movz       s48, #0
    v.cmp.eq     p2, v20, v21
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s49            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s48, #96
    v.extract    s50, v28, #5
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v19, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_64
    s.movz       s51, #0
    s.add        s52, s5, s20
    s.addi       s53, s51, #0
    s.addi       s51, s52, #96
    s.addi       s52, s23, #256
x8dot_row_65:
    s.addi       s54, s18, #-96
    v.movi       v20, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v21, s55
    s.shli       s55, s53, #4
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s54, v26]            // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.addi       s55, s53, #1
    s.movz       s56, #32
    v.st.b       [s54, #0], v20
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s54, s53, s56
    br.nz        s54, x8dot_row_65
x8dot_done_64:
    v.splat      v20, s50
    v.movi       v21, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    v.cmp.ne     p1, v20, v21
    v.splat      v20, s50
    v.movi       v21, #0
    s.movz       s50, #0
    v.cmp.eq     p2, v20, v21
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s51            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s50, #96
    v.extract    s52, v28, #6
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v19, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s52, x8dot_done_66
    s.movz       s53, #0
    s.add        s54, s5, s20
    s.addi       s55, s53, #0
    s.addi       s53, s54, #96
    s.addi       s54, s23, #256
x8dot_row_67:
    s.addi       s56, s18, #-96
    v.movi       v19, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v20, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s56, v27]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    s.movz       s58, #32
    v.st.b       [s56, #0], v19
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s58
    br.nz        s56, x8dot_row_67
x8dot_done_66:
    v.splat      v19, s52
    v.movi       v20, #0
    mb.arm       s18, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    s.movz       s54, #0
    v.cmp.ne     p1, v19, v20
    v.splat      v19, s52
    v.movi       v20, #0
    s.movz       s52, #96
    v.cmp.eq     p2, v19, v20
    s.mov        s55, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s18            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s53, v28, #7
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s18          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s18
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s53, #0
    m.mma.async.k32.e4m3 a15, v48, v56, s52
    mb.wait      s52
    s.addi       s54, s23, #3072
    a.vread      v19, a8, s53
    s.movz       s53, #1
    v.st.w       [s54, #0], v19
    s.addi       s55, s54, #64
    a.vread      v19, a8, s53
    s.movz       s53, #2
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #128
    a.vread      v19, a8, s53
    s.movz       s53, #3
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #192
    a.vread      v19, a8, s53
    s.movz       s53, #4
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #256
    a.vread      v19, a8, s53
    s.movz       s53, #5
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #320
    a.vread      v19, a8, s53
    s.movz       s53, #6
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #384
    a.vread      v19, a8, s53
    s.movz       s53, #7
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #448
    a.vread      v19, a8, s53
    s.movz       s53, #8
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #512
    a.vread      v19, a8, s53
    s.movz       s53, #9
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #576
    a.vread      v19, a8, s53
    s.movz       s53, #10
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #640
    a.vread      v19, a8, s53
    s.movz       s53, #11
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #704
    a.vread      v19, a8, s53
    s.movz       s53, #12
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #768
    a.vread      v19, a8, s53
    s.movz       s53, #13
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #832
    a.vread      v19, a8, s53
    s.movz       s53, #14
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #896
    a.vread      v19, a8, s53
    s.movz       s53, #15
    s.addi       s56, s54, #960
    v.st.w       [s55, #0], v19
    a.vread      v19, a8, s53
    s.movz       s53, #0
    s.addi       s54, s23, #4096
    v.st.w       [s56, #0], v19
    fence.acq_rel.device
    a.vread      v19, a9, s53
    s.movz       s53, #1
    s.addi       s55, s54, #64
    v.st.w       [s54, #0], v19
    a.vread      v19, a9, s53
    s.movz       s53, #2
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #128
    a.vread      v19, a9, s53
    s.movz       s53, #3
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #192
    a.vread      v19, a9, s53
    s.movz       s53, #4
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #256
    a.vread      v19, a9, s53
    s.movz       s53, #5
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #320
    a.vread      v19, a9, s53
    s.movz       s53, #6
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #384
    a.vread      v19, a9, s53
    s.movz       s53, #7
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #448
    a.vread      v19, a9, s53
    s.movz       s53, #8
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #512
    a.vread      v19, a9, s53
    s.movz       s53, #9
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #576
    a.vread      v19, a9, s53
    s.movz       s53, #10
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #640
    a.vread      v19, a9, s53
    s.movz       s53, #11
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #704
    a.vread      v19, a9, s53
    s.movz       s53, #12
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #768
    a.vread      v19, a9, s53
    s.movz       s53, #13
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #832
    a.vread      v19, a9, s53
    s.movz       s53, #14
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #896
    a.vread      v19, a9, s53
    s.movz       s53, #15
    s.addi       s56, s54, #960
    v.st.w       [s55, #0], v19
    a.vread      v19, a9, s53
    s.movz       s53, #0
    s.addi       s54, s23, #5120
    v.st.w       [s56, #0], v19
    fence.acq_rel.device
    a.vread      v19, a10, s53
    s.movz       s53, #1
    s.addi       s55, s54, #64
    v.st.w       [s54, #0], v19
    a.vread      v19, a10, s53
    s.movz       s53, #2
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #128
    a.vread      v19, a10, s53
    s.movz       s53, #3
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #192
    a.vread      v19, a10, s53
    s.movz       s53, #4
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #256
    a.vread      v19, a10, s53
    s.movz       s53, #5
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #320
    a.vread      v19, a10, s53
    s.movz       s53, #6
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #384
    a.vread      v19, a10, s53
    s.movz       s53, #7
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #448
    a.vread      v19, a10, s53
    s.movz       s53, #8
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #512
    a.vread      v19, a10, s53
    s.movz       s53, #9
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #576
    a.vread      v19, a10, s53
    s.movz       s53, #10
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #640
    a.vread      v19, a10, s53
    s.movz       s53, #11
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #704
    a.vread      v19, a10, s53
    s.movz       s53, #12
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #768
    a.vread      v19, a10, s53
    s.movz       s53, #13
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #832
    a.vread      v19, a10, s53
    s.movz       s53, #14
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #896
    a.vread      v19, a10, s53
    s.movz       s53, #15
    s.addi       s56, s54, #960
    v.st.w       [s55, #0], v19
    a.vread      v19, a10, s53
    s.movz       s53, #0
    s.addi       s54, s23, #6144
    v.st.w       [s56, #0], v19
    fence.acq_rel.device
    a.vread      v19, a11, s53
    s.movz       s53, #1
    s.addi       s55, s54, #64
    v.st.w       [s54, #0], v19
    a.vread      v19, a11, s53
    s.movz       s53, #2
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #128
    a.vread      v19, a11, s53
    s.movz       s53, #3
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #192
    a.vread      v19, a11, s53
    s.movz       s53, #4
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #256
    a.vread      v19, a11, s53
    s.movz       s53, #5
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #320
    a.vread      v19, a11, s53
    s.movz       s53, #6
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #384
    a.vread      v19, a11, s53
    s.movz       s53, #7
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #448
    a.vread      v19, a11, s53
    s.movz       s53, #8
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #512
    a.vread      v19, a11, s53
    s.movz       s53, #9
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #576
    a.vread      v19, a11, s53
    s.movz       s53, #10
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #640
    a.vread      v19, a11, s53
    s.movz       s53, #11
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #704
    a.vread      v19, a11, s53
    s.movz       s53, #12
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #768
    a.vread      v19, a11, s53
    s.movz       s53, #13
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #832
    a.vread      v19, a11, s53
    s.movz       s53, #14
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #896
    a.vread      v19, a11, s53
    s.movz       s53, #15
    s.addi       s56, s54, #960
    v.st.w       [s55, #0], v19
    a.vread      v19, a11, s53
    s.movz       s53, #0
    s.addi       s54, s23, #7168
    v.st.w       [s56, #0], v19
    fence.acq_rel.device
    a.vread      v19, a12, s53
    s.movz       s53, #1
    s.addi       s55, s54, #64
    v.st.w       [s54, #0], v19
    a.vread      v19, a12, s53
    s.movz       s53, #2
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #128
    a.vread      v19, a12, s53
    s.movz       s53, #3
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #192
    a.vread      v19, a12, s53
    s.movz       s53, #4
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #256
    a.vread      v19, a12, s53
    s.movz       s53, #5
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #320
    a.vread      v19, a12, s53
    s.movz       s53, #6
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #384
    a.vread      v19, a12, s53
    s.movz       s53, #7
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #448
    a.vread      v19, a12, s53
    s.movz       s53, #8
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #512
    a.vread      v19, a12, s53
    s.movz       s53, #9
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #576
    a.vread      v19, a12, s53
    s.movz       s53, #10
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #640
    a.vread      v19, a12, s53
    s.movz       s53, #11
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #704
    a.vread      v19, a12, s53
    s.movz       s53, #12
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #768
    a.vread      v19, a12, s53
    s.movz       s53, #13
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #832
    a.vread      v19, a12, s53
    s.movz       s53, #14
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #896
    a.vread      v19, a12, s53
    s.movz       s53, #15
    s.addi       s56, s54, #960
    v.st.w       [s55, #0], v19
    a.vread      v19, a12, s53
    s.movz       s53, #0
    s.addi       s54, s23, #8192
    v.st.w       [s56, #0], v19
    fence.acq_rel.device
    a.vread      v19, a13, s53
    s.movz       s53, #1
    s.addi       s55, s54, #64
    v.st.w       [s54, #0], v19
    a.vread      v19, a13, s53
    s.movz       s53, #2
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #128
    a.vread      v19, a13, s53
    s.movz       s53, #3
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #192
    a.vread      v19, a13, s53
    s.movz       s53, #4
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #256
    a.vread      v19, a13, s53
    s.movz       s53, #5
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #320
    a.vread      v19, a13, s53
    s.movz       s53, #6
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #384
    a.vread      v19, a13, s53
    s.movz       s53, #7
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #448
    a.vread      v19, a13, s53
    s.movz       s53, #8
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #512
    a.vread      v19, a13, s53
    s.movz       s53, #9
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #576
    a.vread      v19, a13, s53
    s.movz       s53, #10
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #640
    a.vread      v19, a13, s53
    s.movz       s53, #11
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #704
    a.vread      v19, a13, s53
    s.movz       s53, #12
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #768
    a.vread      v19, a13, s53
    s.movz       s53, #13
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #832
    a.vread      v19, a13, s53
    s.movz       s53, #14
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #896
    a.vread      v19, a13, s53
    s.movz       s53, #15
    s.addi       s56, s54, #960
    v.st.w       [s55, #0], v19
    a.vread      v19, a13, s53
    s.movz       s53, #0
    s.addi       s54, s23, #9216
    v.st.w       [s56, #0], v19
    fence.acq_rel.device
    a.vread      v19, a14, s53
    s.movz       s53, #1
    s.addi       s55, s54, #64
    v.st.w       [s54, #0], v19
    a.vread      v19, a14, s53
    s.movz       s53, #2
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #128
    a.vread      v19, a14, s53
    s.movz       s53, #3
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #192
    a.vread      v19, a14, s53
    s.movz       s53, #4
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #256
    a.vread      v19, a14, s53
    s.movz       s53, #5
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #320
    a.vread      v19, a14, s53
    s.movz       s53, #6
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #384
    a.vread      v19, a14, s53
    s.movz       s53, #7
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #448
    a.vread      v19, a14, s53
    s.movz       s53, #8
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #512
    a.vread      v19, a14, s53
    s.movz       s53, #9
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #576
    a.vread      v19, a14, s53
    s.movz       s53, #10
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #640
    a.vread      v19, a14, s53
    s.movz       s53, #11
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #704
    a.vread      v19, a14, s53
    s.movz       s53, #12
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #768
    a.vread      v19, a14, s53
    s.movz       s53, #13
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #832
    a.vread      v19, a14, s53
    s.movz       s53, #14
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #896
    a.vread      v19, a14, s53
    s.movz       s53, #15
    s.addi       s56, s54, #960
    v.st.w       [s55, #0], v19
    a.vread      v19, a14, s53
    s.movz       s53, #0
    s.addi       s54, s23, #10240
    v.st.w       [s56, #0], v19
    fence.acq_rel.device
    a.vread      v19, a15, s53
    s.movz       s53, #1
    s.addi       s55, s54, #64
    v.st.w       [s54, #0], v19
    a.vread      v19, a15, s53
    s.movz       s53, #2
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #128
    a.vread      v19, a15, s53
    s.movz       s53, #3
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #192
    a.vread      v19, a15, s53
    s.movz       s53, #4
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #256
    a.vread      v19, a15, s53
    s.movz       s53, #5
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #320
    a.vread      v19, a15, s53
    s.movz       s53, #6
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #384
    a.vread      v19, a15, s53
    s.movz       s53, #7
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #448
    a.vread      v19, a15, s53
    s.movz       s53, #8
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #512
    a.vread      v19, a15, s53
    s.movz       s53, #9
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #576
    a.vread      v19, a15, s53
    s.movz       s53, #10
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #640
    a.vread      v19, a15, s53
    s.movz       s53, #11
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #704
    a.vread      v19, a15, s53
    s.movz       s53, #12
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #768
    a.vread      v19, a15, s53
    s.movz       s53, #13
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #832
    a.vread      v19, a15, s53
    s.movz       s53, #14
    v.st.w       [s55, #0], v19
    s.addi       s55, s54, #896
    a.vread      v19, a15, s53
    s.movz       s53, #15
    s.addi       s56, s54, #960
    v.st.w       [s55, #0], v19
    a.vread      v19, a15, s53
    s.movz       s53, #0
    s.addi       s54, s23, #3072
    v.st.w       [s56, #0], v19
    fence.acq_rel.device
    a.vread      v19, a0, s53
    v.extract    s53, v0, #0
    v.splat      v20, s53
    s.addi       s53, s23, #11264
    s.movz       s55, #1
    v.ld.w       v21, [s54, #0]
    s.addi       s54, s23, #3136
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s53, #0], v21
    a.vread      v19, a0, s55
    v.extract    s55, v0, #1
    v.splat      v20, s55
    s.addi       s55, s53, #64
    v.ld.w       v21, [s54, #0]
    s.movz       s54, #2
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s55, #0], v21
    s.addi       s55, s23, #3200
    a.vread      v19, a0, s54
    v.extract    s54, v0, #2
    v.splat      v20, s54
    s.addi       s54, s53, #128
    v.ld.w       v21, [s55, #0]
    s.movz       s55, #3
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s54, #0], v21
    s.addi       s54, s23, #3264
    a.vread      v19, a0, s55
    v.extract    s55, v0, #3
    v.splat      v20, s55
    s.addi       s55, s53, #192
    v.ld.w       v21, [s54, #0]
    s.movz       s54, #4
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s55, #0], v21
    s.addi       s55, s23, #3328
    a.vread      v19, a0, s54
    v.extract    s54, v0, #4
    v.splat      v20, s54
    s.addi       s54, s53, #256
    v.ld.w       v21, [s55, #0]
    s.movz       s55, #5
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s54, #0], v21
    s.addi       s54, s23, #3392
    a.vread      v19, a0, s55
    v.extract    s55, v0, #5
    v.splat      v20, s55
    s.addi       s55, s53, #320
    v.ld.w       v21, [s54, #0]
    s.movz       s54, #6
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s55, #0], v21
    s.addi       s55, s23, #3456
    a.vread      v19, a0, s54
    v.extract    s54, v0, #6
    v.splat      v20, s54
    s.addi       s54, s53, #384
    v.ld.w       v21, [s55, #0]
    s.movz       s55, #7
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s54, #0], v21
    s.addi       s54, s23, #3520
    a.vread      v19, a0, s55
    v.extract    s55, v0, #7
    v.splat      v20, s55
    s.addi       s55, s53, #448
    v.ld.w       v21, [s54, #0]
    s.movz       s54, #8
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s55, #0], v21
    s.addi       s55, s23, #3584
    a.vread      v19, a0, s54
    v.extract    s54, v0, #8
    v.splat      v20, s54
    s.addi       s54, s53, #512
    v.ld.w       v21, [s55, #0]
    s.movz       s55, #9
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s54, #0], v21
    s.addi       s54, s23, #3648
    a.vread      v19, a0, s55
    v.extract    s55, v0, #9
    v.splat      v20, s55
    s.addi       s55, s53, #576
    v.ld.w       v21, [s54, #0]
    s.movz       s54, #10
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s55, #0], v21
    s.addi       s55, s23, #3712
    a.vread      v19, a0, s54
    v.extract    s54, v0, #10
    v.splat      v20, s54
    s.addi       s54, s53, #640
    v.ld.w       v21, [s55, #0]
    s.movz       s55, #11
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s54, #0], v21
    s.addi       s54, s23, #3776
    a.vread      v19, a0, s55
    v.extract    s55, v0, #11
    v.splat      v20, s55
    s.addi       s55, s53, #704
    v.ld.w       v21, [s54, #0]
    s.movz       s54, #12
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s55, #0], v21
    s.addi       s55, s23, #3840
    a.vread      v19, a0, s54
    v.extract    s54, v0, #12
    v.splat      v20, s54
    s.addi       s54, s53, #768
    v.ld.w       v21, [s55, #0]
    s.movz       s55, #13
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s54, #0], v21
    s.addi       s54, s23, #3904
    a.vread      v19, a0, s55
    v.extract    s55, v0, #13
    v.splat      v20, s55
    s.addi       s55, s53, #832
    v.ld.w       v21, [s54, #0]
    s.movz       s54, #14
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s55, #0], v21
    s.addi       s55, s23, #3968
    a.vread      v19, a0, s54
    v.extract    s54, v0, #14
    v.splat      v20, s54
    s.addi       s54, s53, #896
    s.addi       s56, s53, #960
    v.ld.w       v21, [s55, #0]
    s.movz       s53, #15
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v21, v19, v20
    v.st.w       [s54, #0], v21
    s.addi       s54, s23, #4032
    a.vread      v19, a0, s53
    v.extract    s53, v0, #15
    v.splat      v20, s53
    s.movz       s53, #0
    v.ld.w       v21, [s54, #0]
    s.addi       s54, s23, #4096
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v10
    vf.add       v10, v19, v20
    v.st.w       [s56, #0], v10
    fence.acq_rel.device
    a.vread      v10, a1, s53
    v.extract    s53, v0, #0
    v.splat      v19, s53
    s.addi       s53, s23, #12288
    s.movz       s55, #1
    v.ld.w       v20, [s54, #0]
    s.addi       s54, s23, #4160
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s53, #0], v20
    a.vread      v10, a1, s55
    v.extract    s55, v0, #1
    v.splat      v19, s55
    s.addi       s55, s53, #64
    v.ld.w       v20, [s54, #0]
    s.movz       s54, #2
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s55, #0], v20
    s.addi       s55, s23, #4224
    a.vread      v10, a1, s54
    v.extract    s54, v0, #2
    v.splat      v19, s54
    s.addi       s54, s53, #128
    v.ld.w       v20, [s55, #0]
    s.movz       s55, #3
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s54, #0], v20
    s.addi       s54, s23, #4288
    a.vread      v10, a1, s55
    v.extract    s55, v0, #3
    v.splat      v19, s55
    s.addi       s55, s53, #192
    v.ld.w       v20, [s54, #0]
    s.movz       s54, #4
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s55, #0], v20
    s.addi       s55, s23, #4352
    a.vread      v10, a1, s54
    v.extract    s54, v0, #4
    v.splat      v19, s54
    s.addi       s54, s53, #256
    v.ld.w       v20, [s55, #0]
    s.movz       s55, #5
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s54, #0], v20
    s.addi       s54, s23, #4416
    a.vread      v10, a1, s55
    v.extract    s55, v0, #5
    v.splat      v19, s55
    s.addi       s55, s53, #320
    v.ld.w       v20, [s54, #0]
    s.movz       s54, #6
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s55, #0], v20
    s.addi       s55, s23, #4480
    a.vread      v10, a1, s54
    v.extract    s54, v0, #6
    v.splat      v19, s54
    s.addi       s54, s53, #384
    v.ld.w       v20, [s55, #0]
    s.movz       s55, #7
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s54, #0], v20
    s.addi       s54, s23, #4544
    a.vread      v10, a1, s55
    v.extract    s55, v0, #7
    v.splat      v19, s55
    s.addi       s55, s53, #448
    v.ld.w       v20, [s54, #0]
    s.movz       s54, #8
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s55, #0], v20
    s.addi       s55, s23, #4608
    a.vread      v10, a1, s54
    v.extract    s54, v0, #8
    v.splat      v19, s54
    s.addi       s54, s53, #512
    v.ld.w       v20, [s55, #0]
    s.movz       s55, #9
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s54, #0], v20
    s.addi       s54, s23, #4672
    a.vread      v10, a1, s55
    v.extract    s55, v0, #9
    v.splat      v19, s55
    s.addi       s55, s53, #576
    v.ld.w       v20, [s54, #0]
    s.movz       s54, #10
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s55, #0], v20
    s.addi       s55, s23, #4736
    a.vread      v10, a1, s54
    v.extract    s54, v0, #10
    v.splat      v19, s54
    s.addi       s54, s53, #640
    v.ld.w       v20, [s55, #0]
    s.movz       s55, #11
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s54, #0], v20
    s.addi       s54, s23, #4800
    a.vread      v10, a1, s55
    v.extract    s55, v0, #11
    v.splat      v19, s55
    s.addi       s55, s53, #704
    v.ld.w       v20, [s54, #0]
    s.movz       s54, #12
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s55, #0], v20
    s.addi       s55, s23, #4864
    a.vread      v10, a1, s54
    v.extract    s54, v0, #12
    v.splat      v19, s54
    s.addi       s54, s53, #768
    v.ld.w       v20, [s55, #0]
    s.movz       s55, #13
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s54, #0], v20
    s.addi       s54, s23, #4928
    a.vread      v10, a1, s55
    v.extract    s55, v0, #13
    v.splat      v19, s55
    s.addi       s55, s53, #832
    v.ld.w       v20, [s54, #0]
    s.movz       s54, #14
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s55, #0], v20
    s.addi       s55, s23, #4992
    a.vread      v10, a1, s54
    v.extract    s54, v0, #14
    v.splat      v19, s54
    s.addi       s54, s53, #896
    s.addi       s56, s53, #960
    v.ld.w       v20, [s55, #0]
    s.movz       s53, #15
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v20, v10, v19
    v.st.w       [s54, #0], v20
    s.addi       s54, s23, #5056
    a.vread      v10, a1, s53
    v.extract    s53, v0, #15
    v.splat      v19, s53
    s.movz       s53, #0
    v.ld.w       v20, [s54, #0]
    s.addi       s54, s23, #5120
    vf.mul       v21, v20, v19
    vf.mul       v19, v21, v12
    vf.add       v12, v10, v19
    v.st.w       [s56, #0], v12
    fence.acq_rel.device
    a.vread      v10, a2, s53
    v.extract    s53, v0, #0
    v.splat      v12, s53
    s.addi       s53, s23, #13312
    s.movz       s55, #1
    v.ld.w       v19, [s54, #0]
    s.addi       s54, s23, #5184
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s53, #0], v19
    a.vread      v10, a2, s55
    v.extract    s55, v0, #1
    v.splat      v12, s55
    s.addi       s55, s53, #64
    v.ld.w       v19, [s54, #0]
    s.movz       s54, #2
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s55, #0], v19
    s.addi       s55, s23, #5248
    a.vread      v10, a2, s54
    v.extract    s54, v0, #2
    v.splat      v12, s54
    s.addi       s54, s53, #128
    v.ld.w       v19, [s55, #0]
    s.movz       s55, #3
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s54, #0], v19
    s.addi       s54, s23, #5312
    a.vread      v10, a2, s55
    v.extract    s55, v0, #3
    v.splat      v12, s55
    s.addi       s55, s53, #192
    v.ld.w       v19, [s54, #0]
    s.movz       s54, #4
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s55, #0], v19
    s.addi       s55, s23, #5376
    a.vread      v10, a2, s54
    v.extract    s54, v0, #4
    v.splat      v12, s54
    s.addi       s54, s53, #256
    v.ld.w       v19, [s55, #0]
    s.movz       s55, #5
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s54, #0], v19
    s.addi       s54, s23, #5440
    a.vread      v10, a2, s55
    v.extract    s55, v0, #5
    v.splat      v12, s55
    s.addi       s55, s53, #320
    v.ld.w       v19, [s54, #0]
    s.movz       s54, #6
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s55, #0], v19
    s.addi       s55, s23, #5504
    a.vread      v10, a2, s54
    v.extract    s54, v0, #6
    v.splat      v12, s54
    s.addi       s54, s53, #384
    v.ld.w       v19, [s55, #0]
    s.movz       s55, #7
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s54, #0], v19
    s.addi       s54, s23, #5568
    a.vread      v10, a2, s55
    v.extract    s55, v0, #7
    v.splat      v12, s55
    s.addi       s55, s53, #448
    v.ld.w       v19, [s54, #0]
    s.movz       s54, #8
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s55, #0], v19
    s.addi       s55, s23, #5632
    a.vread      v10, a2, s54
    v.extract    s54, v0, #8
    v.splat      v12, s54
    s.addi       s54, s53, #512
    v.ld.w       v19, [s55, #0]
    s.movz       s55, #9
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s54, #0], v19
    s.addi       s54, s23, #5696
    a.vread      v10, a2, s55
    v.extract    s55, v0, #9
    v.splat      v12, s55
    s.addi       s55, s53, #576
    v.ld.w       v19, [s54, #0]
    s.movz       s54, #10
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s55, #0], v19
    s.addi       s55, s23, #5760
    a.vread      v10, a2, s54
    v.extract    s54, v0, #10
    v.splat      v12, s54
    s.addi       s54, s53, #640
    v.ld.w       v19, [s55, #0]
    s.movz       s55, #11
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s54, #0], v19
    s.addi       s54, s23, #5824
    a.vread      v10, a2, s55
    v.extract    s55, v0, #11
    v.splat      v12, s55
    s.addi       s55, s53, #704
    v.ld.w       v19, [s54, #0]
    s.movz       s54, #12
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s55, #0], v19
    s.addi       s55, s23, #5888
    a.vread      v10, a2, s54
    v.extract    s54, v0, #12
    v.splat      v12, s54
    s.addi       s54, s53, #768
    v.ld.w       v19, [s55, #0]
    s.movz       s55, #13
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s54, #0], v19
    s.addi       s54, s23, #5952
    a.vread      v10, a2, s55
    v.extract    s55, v0, #13
    v.splat      v12, s55
    s.addi       s55, s53, #832
    v.ld.w       v19, [s54, #0]
    s.movz       s54, #14
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s55, #0], v19
    s.addi       s55, s23, #6016
    a.vread      v10, a2, s54
    v.extract    s54, v0, #14
    v.splat      v12, s54
    s.addi       s54, s53, #896
    s.addi       s56, s53, #960
    v.ld.w       v19, [s55, #0]
    s.movz       s53, #15
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v19, v10, v12
    v.st.w       [s54, #0], v19
    s.addi       s54, s23, #6080
    a.vread      v10, a2, s53
    v.extract    s53, v0, #15
    v.splat      v12, s53
    s.movz       s53, #0
    v.ld.w       v19, [s54, #0]
    s.addi       s54, s23, #6144
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v13
    vf.add       v13, v10, v12
    v.st.w       [s56, #0], v13
    fence.acq_rel.device
    a.vread      v10, a3, s53
    v.extract    s53, v0, #0
    v.splat      v12, s53
    s.addi       s53, s23, #14336
    s.movz       s55, #1
    v.ld.w       v13, [s54, #0]
    s.addi       s54, s23, #6208
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s53, #0], v13
    a.vread      v10, a3, s55
    v.extract    s55, v0, #1
    v.splat      v12, s55
    s.addi       s55, s53, #64
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #2
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #6272
    a.vread      v10, a3, s54
    v.extract    s54, v0, #2
    v.splat      v12, s54
    s.addi       s54, s53, #128
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #3
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #6336
    a.vread      v10, a3, s55
    v.extract    s55, v0, #3
    v.splat      v12, s55
    s.addi       s55, s53, #192
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #4
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #6400
    a.vread      v10, a3, s54
    v.extract    s54, v0, #4
    v.splat      v12, s54
    s.addi       s54, s53, #256
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #5
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #6464
    a.vread      v10, a3, s55
    v.extract    s55, v0, #5
    v.splat      v12, s55
    s.addi       s55, s53, #320
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #6
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #6528
    a.vread      v10, a3, s54
    v.extract    s54, v0, #6
    v.splat      v12, s54
    s.addi       s54, s53, #384
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #7
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #6592
    a.vread      v10, a3, s55
    v.extract    s55, v0, #7
    v.splat      v12, s55
    s.addi       s55, s53, #448
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #8
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #6656
    a.vread      v10, a3, s54
    v.extract    s54, v0, #8
    v.splat      v12, s54
    s.addi       s54, s53, #512
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #9
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #6720
    a.vread      v10, a3, s55
    v.extract    s55, v0, #9
    v.splat      v12, s55
    s.addi       s55, s53, #576
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #10
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #6784
    a.vread      v10, a3, s54
    v.extract    s54, v0, #10
    v.splat      v12, s54
    s.addi       s54, s53, #640
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #11
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #6848
    a.vread      v10, a3, s55
    v.extract    s55, v0, #11
    v.splat      v12, s55
    s.addi       s55, s53, #704
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #12
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #6912
    a.vread      v10, a3, s54
    v.extract    s54, v0, #12
    v.splat      v12, s54
    s.addi       s54, s53, #768
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #13
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #6976
    a.vread      v10, a3, s55
    v.extract    s55, v0, #13
    v.splat      v12, s55
    s.addi       s55, s53, #832
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #14
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #7040
    a.vread      v10, a3, s54
    v.extract    s54, v0, #14
    v.splat      v12, s54
    s.addi       s54, s53, #896
    s.addi       s56, s53, #960
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #15
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #7104
    a.vread      v10, a3, s53
    v.extract    s53, v0, #15
    v.splat      v12, s53
    s.movz       s53, #0
    v.ld.w       v13, [s54, #0]
    s.addi       s54, s23, #7168
    vf.mul       v19, v13, v12
    vf.mul       v12, v19, v14
    vf.add       v13, v10, v12
    v.st.w       [s56, #0], v13
    fence.acq_rel.device
    a.vread      v10, a4, s53
    v.extract    s53, v0, #0
    v.splat      v12, s53
    s.addi       s53, s23, #15360
    s.movz       s55, #1
    v.ld.w       v13, [s54, #0]
    s.addi       s54, s23, #7232
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s53, #0], v13
    a.vread      v10, a4, s55
    v.extract    s55, v0, #1
    v.splat      v12, s55
    s.addi       s55, s53, #64
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #2
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #7296
    a.vread      v10, a4, s54
    v.extract    s54, v0, #2
    v.splat      v12, s54
    s.addi       s54, s53, #128
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #3
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #7360
    a.vread      v10, a4, s55
    v.extract    s55, v0, #3
    v.splat      v12, s55
    s.addi       s55, s53, #192
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #4
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #7424
    a.vread      v10, a4, s54
    v.extract    s54, v0, #4
    v.splat      v12, s54
    s.addi       s54, s53, #256
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #5
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #7488
    a.vread      v10, a4, s55
    v.extract    s55, v0, #5
    v.splat      v12, s55
    s.addi       s55, s53, #320
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #6
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #7552
    a.vread      v10, a4, s54
    v.extract    s54, v0, #6
    v.splat      v12, s54
    s.addi       s54, s53, #384
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #7
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #7616
    a.vread      v10, a4, s55
    v.extract    s55, v0, #7
    v.splat      v12, s55
    s.addi       s55, s53, #448
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #8
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #7680
    a.vread      v10, a4, s54
    v.extract    s54, v0, #8
    v.splat      v12, s54
    s.addi       s54, s53, #512
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #9
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #7744
    a.vread      v10, a4, s55
    v.extract    s55, v0, #9
    v.splat      v12, s55
    s.addi       s55, s53, #576
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #10
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #7808
    a.vread      v10, a4, s54
    v.extract    s54, v0, #10
    v.splat      v12, s54
    s.addi       s54, s53, #640
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #11
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #7872
    a.vread      v10, a4, s55
    v.extract    s55, v0, #11
    v.splat      v12, s55
    s.addi       s55, s53, #704
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #12
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #7936
    a.vread      v10, a4, s54
    v.extract    s54, v0, #12
    v.splat      v12, s54
    s.addi       s54, s53, #768
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #13
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #8000
    a.vread      v10, a4, s55
    v.extract    s55, v0, #13
    v.splat      v12, s55
    s.addi       s55, s53, #832
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #14
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #8064
    a.vread      v10, a4, s54
    v.extract    s54, v0, #14
    v.splat      v12, s54
    s.addi       s54, s53, #896
    s.addi       s56, s53, #960
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #15
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #8128
    a.vread      v10, a4, s53
    v.extract    s53, v0, #15
    v.splat      v12, s53
    s.movz       s53, #0
    v.ld.w       v13, [s54, #0]
    s.addi       s54, s23, #8192
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v15
    vf.add       v13, v10, v12
    v.st.w       [s56, #0], v13
    fence.acq_rel.device
    a.vread      v10, a5, s53
    v.extract    s53, v0, #0
    v.splat      v12, s53
    s.addi       s53, s23, #16384
    s.movz       s55, #1
    v.ld.w       v13, [s54, #0]
    s.addi       s54, s23, #8256
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s53, #0], v13
    a.vread      v10, a5, s55
    v.extract    s55, v0, #1
    v.splat      v12, s55
    s.addi       s55, s53, #64
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #2
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #8320
    a.vread      v10, a5, s54
    v.extract    s54, v0, #2
    v.splat      v12, s54
    s.addi       s54, s53, #128
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #3
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #8384
    a.vread      v10, a5, s55
    v.extract    s55, v0, #3
    v.splat      v12, s55
    s.addi       s55, s53, #192
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #4
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #8448
    a.vread      v10, a5, s54
    v.extract    s54, v0, #4
    v.splat      v12, s54
    s.addi       s54, s53, #256
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #5
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #8512
    a.vread      v10, a5, s55
    v.extract    s55, v0, #5
    v.splat      v12, s55
    s.addi       s55, s53, #320
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #6
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #8576
    a.vread      v10, a5, s54
    v.extract    s54, v0, #6
    v.splat      v12, s54
    s.addi       s54, s53, #384
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #7
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #8640
    a.vread      v10, a5, s55
    v.extract    s55, v0, #7
    v.splat      v12, s55
    s.addi       s55, s53, #448
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #8
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #8704
    a.vread      v10, a5, s54
    v.extract    s54, v0, #8
    v.splat      v12, s54
    s.addi       s54, s53, #512
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #9
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #8768
    a.vread      v10, a5, s55
    v.extract    s55, v0, #9
    v.splat      v12, s55
    s.addi       s55, s53, #576
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #10
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #8832
    a.vread      v10, a5, s54
    v.extract    s54, v0, #10
    v.splat      v12, s54
    s.addi       s54, s53, #640
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #11
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #8896
    a.vread      v10, a5, s55
    v.extract    s55, v0, #11
    v.splat      v12, s55
    s.addi       s55, s53, #704
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #12
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #8960
    a.vread      v10, a5, s54
    v.extract    s54, v0, #12
    v.splat      v12, s54
    s.addi       s54, s53, #768
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #13
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #9024
    a.vread      v10, a5, s55
    v.extract    s55, v0, #13
    v.splat      v12, s55
    s.addi       s55, s53, #832
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #14
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #9088
    a.vread      v10, a5, s54
    v.extract    s54, v0, #14
    v.splat      v12, s54
    s.addi       s54, s53, #896
    s.addi       s56, s53, #960
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #15
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #9152
    a.vread      v10, a5, s53
    v.extract    s53, v0, #15
    v.splat      v12, s53
    s.movz       s53, #0
    v.ld.w       v13, [s54, #0]
    s.addi       s54, s23, #9216
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v16
    vf.add       v13, v10, v12
    v.st.w       [s56, #0], v13
    fence.acq_rel.device
    a.vread      v10, a6, s53
    v.extract    s53, v0, #0
    v.splat      v12, s53
    s.addi       s53, s23, #17408
    s.movz       s55, #1
    v.ld.w       v13, [s54, #0]
    s.addi       s54, s23, #9280
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s53, #0], v13
    a.vread      v10, a6, s55
    v.extract    s55, v0, #1
    v.splat      v12, s55
    s.addi       s55, s53, #64
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #2
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #9344
    a.vread      v10, a6, s54
    v.extract    s54, v0, #2
    v.splat      v12, s54
    s.addi       s54, s53, #128
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #3
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #9408
    a.vread      v10, a6, s55
    v.extract    s55, v0, #3
    v.splat      v12, s55
    s.addi       s55, s53, #192
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #4
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #9472
    a.vread      v10, a6, s54
    v.extract    s54, v0, #4
    v.splat      v12, s54
    s.addi       s54, s53, #256
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #5
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #9536
    a.vread      v10, a6, s55
    v.extract    s55, v0, #5
    v.splat      v12, s55
    s.addi       s55, s53, #320
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #6
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #9600
    a.vread      v10, a6, s54
    v.extract    s54, v0, #6
    v.splat      v12, s54
    s.addi       s54, s53, #384
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #7
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #9664
    a.vread      v10, a6, s55
    v.extract    s55, v0, #7
    v.splat      v12, s55
    s.addi       s55, s53, #448
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #8
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #9728
    a.vread      v10, a6, s54
    v.extract    s54, v0, #8
    v.splat      v12, s54
    s.addi       s54, s53, #512
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #9
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #9792
    a.vread      v10, a6, s55
    v.extract    s55, v0, #9
    v.splat      v12, s55
    s.addi       s55, s53, #576
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #10
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #9856
    a.vread      v10, a6, s54
    v.extract    s54, v0, #10
    v.splat      v12, s54
    s.addi       s54, s53, #640
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #11
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #9920
    a.vread      v10, a6, s55
    v.extract    s55, v0, #11
    v.splat      v12, s55
    s.addi       s55, s53, #704
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #12
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #9984
    a.vread      v10, a6, s54
    v.extract    s54, v0, #12
    v.splat      v12, s54
    s.addi       s54, s53, #768
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #13
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #10048
    a.vread      v10, a6, s55
    v.extract    s55, v0, #13
    v.splat      v12, s55
    s.addi       s55, s53, #832
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #14
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #10112
    a.vread      v10, a6, s54
    v.extract    s54, v0, #14
    v.splat      v12, s54
    s.addi       s54, s53, #896
    s.addi       s56, s53, #960
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #15
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #10176
    a.vread      v10, a6, s53
    v.extract    s53, v0, #15
    v.splat      v12, s53
    s.movz       s53, #0
    v.ld.w       v13, [s54, #0]
    s.addi       s54, s23, #10240
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v17
    vf.add       v13, v10, v12
    v.st.w       [s56, #0], v13
    fence.acq_rel.device
    a.vread      v10, a7, s53
    v.extract    s53, v0, #0
    v.splat      v12, s53
    s.addi       s53, s23, #18432
    s.movz       s55, #1
    v.ld.w       v13, [s54, #0]
    s.addi       s54, s23, #10304
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s53, #0], v13
    a.vread      v10, a7, s55
    v.extract    s55, v0, #1
    v.splat      v12, s55
    s.addi       s55, s53, #64
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #2
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #10368
    a.vread      v10, a7, s54
    v.extract    s54, v0, #2
    v.splat      v12, s54
    s.addi       s54, s53, #128
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #3
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #10432
    a.vread      v10, a7, s55
    v.extract    s55, v0, #3
    v.splat      v12, s55
    s.addi       s55, s53, #192
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #4
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #10496
    a.vread      v10, a7, s54
    v.extract    s54, v0, #4
    v.splat      v12, s54
    s.addi       s54, s53, #256
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #5
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #10560
    a.vread      v10, a7, s55
    v.extract    s55, v0, #5
    v.splat      v12, s55
    s.addi       s55, s53, #320
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #6
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #10624
    a.vread      v10, a7, s54
    v.extract    s54, v0, #6
    v.splat      v12, s54
    s.addi       s54, s53, #384
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #7
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #10688
    a.vread      v10, a7, s55
    v.extract    s55, v0, #7
    v.splat      v12, s55
    s.addi       s55, s53, #448
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #8
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #10752
    a.vread      v10, a7, s54
    v.extract    s54, v0, #8
    v.splat      v12, s54
    s.addi       s54, s53, #512
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #9
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #10816
    a.vread      v10, a7, s55
    v.extract    s55, v0, #9
    v.splat      v12, s55
    s.addi       s55, s53, #576
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #10
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #10880
    a.vread      v10, a7, s54
    v.extract    s54, v0, #10
    v.splat      v12, s54
    s.addi       s54, s53, #640
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #11
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #10944
    a.vread      v10, a7, s55
    v.extract    s55, v0, #11
    v.splat      v12, s55
    s.addi       s55, s53, #704
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #12
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #11008
    a.vread      v10, a7, s54
    v.extract    s54, v0, #12
    v.splat      v12, s54
    s.addi       s54, s53, #768
    v.ld.w       v13, [s55, #0]
    s.movz       s55, #13
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #11072
    a.vread      v10, a7, s55
    v.extract    s55, v0, #13
    v.splat      v12, s55
    s.addi       s55, s53, #832
    v.ld.w       v13, [s54, #0]
    s.movz       s54, #14
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s55, #0], v13
    s.addi       s55, s23, #11136
    a.vread      v10, a7, s54
    v.extract    s54, v0, #14
    v.splat      v12, s54
    s.addi       s54, s53, #896
    s.addi       s56, s53, #960
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #15
    vf.mul       v14, v13, v12
    vf.mul       v12, v14, v18
    vf.add       v13, v10, v12
    v.st.w       [s54, #0], v13
    s.addi       s54, s23, #11200
    a.vread      v10, a7, s53
    v.extract    s53, v0, #15
    v.splat      v0, s53
    s.addi       s53, s19, #128
    s.addi       s55, s53, #0
    v.ld.w       v12, [s54, #0]
    s.addi       s53, s20, #128
    s.addi       s54, s53, #0
    vf.mul       v13, v12, v0
    vf.mul       v0, v13, v18
    vf.add       v12, v10, v0
    v.st.w       [s56, #0], v12
    s.addi       s53, s23, #11264
    fence.acq_rel.device
    s.mov        s19, s55
    s.mov        s20, s54
    s.movz       s54, #0
    s.addi       s55, s23, #11328
    s.movz       s56, #1
    s.addi       s57, s23, #11392
    v.ld.w       v0, [s53, #0]
    s.movz       s53, #2
    a.vwrite     a0, s54, v0
    v.ld.w       v0, [s55, #0]
    s.addi       s54, s23, #11456
    s.movz       s55, #3
    a.vwrite     a0, s56, v0
    v.ld.w       v0, [s57, #0]
    s.addi       s56, s23, #11520
    s.movz       s57, #4
    a.vwrite     a0, s53, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s53, s23, #11584
    s.movz       s54, #5
    a.vwrite     a0, s55, v0
    v.ld.w       v0, [s56, #0]
    s.addi       s55, s23, #11648
    s.movz       s56, #6
    a.vwrite     a0, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #11712
    s.movz       s57, #7
    a.vwrite     a0, s54, v0
    v.ld.w       v0, [s55, #0]
    s.addi       s54, s23, #11776
    s.movz       s55, #8
    a.vwrite     a0, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #11840
    s.movz       s56, #9
    a.vwrite     a0, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #11904
    s.movz       s57, #10
    a.vwrite     a0, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #11968
    s.movz       s55, #11
    a.vwrite     a0, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #12032
    s.movz       s56, #12
    a.vwrite     a0, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #12096
    s.movz       s57, #13
    a.vwrite     a0, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #12160
    s.movz       s55, #14
    a.vwrite     a0, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #12224
    s.movz       s56, #15
    a.vwrite     a0, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #12288
    s.movz       s57, #0
    a.vwrite     a0, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #12352
    s.movz       s55, #1
    a.vwrite     a0, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #12416
    s.movz       s56, #2
    a.vwrite     a1, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #12480
    s.movz       s57, #3
    a.vwrite     a1, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #12544
    s.movz       s55, #4
    a.vwrite     a1, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #12608
    s.movz       s56, #5
    a.vwrite     a1, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #12672
    s.movz       s57, #6
    a.vwrite     a1, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #12736
    s.movz       s55, #7
    a.vwrite     a1, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #12800
    s.movz       s56, #8
    a.vwrite     a1, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #12864
    s.movz       s57, #9
    a.vwrite     a1, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #12928
    s.movz       s55, #10
    a.vwrite     a1, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #12992
    s.movz       s56, #11
    a.vwrite     a1, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #13056
    s.movz       s57, #12
    a.vwrite     a1, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #13120
    s.movz       s55, #13
    a.vwrite     a1, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #13184
    s.movz       s56, #14
    a.vwrite     a1, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #13248
    s.movz       s57, #15
    a.vwrite     a1, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #13312
    s.movz       s55, #0
    a.vwrite     a1, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #13376
    s.movz       s56, #1
    a.vwrite     a1, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #13440
    s.movz       s57, #2
    a.vwrite     a2, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #13504
    s.movz       s55, #3
    a.vwrite     a2, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #13568
    s.movz       s56, #4
    a.vwrite     a2, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #13632
    s.movz       s57, #5
    a.vwrite     a2, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #13696
    s.movz       s55, #6
    a.vwrite     a2, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #13760
    s.movz       s56, #7
    a.vwrite     a2, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #13824
    s.movz       s57, #8
    a.vwrite     a2, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #13888
    s.movz       s55, #9
    a.vwrite     a2, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #13952
    s.movz       s56, #10
    a.vwrite     a2, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #14016
    s.movz       s57, #11
    a.vwrite     a2, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #14080
    s.movz       s55, #12
    a.vwrite     a2, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #14144
    s.movz       s56, #13
    a.vwrite     a2, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #14208
    s.movz       s57, #14
    a.vwrite     a2, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #14272
    s.movz       s55, #15
    a.vwrite     a2, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #14336
    s.movz       s56, #0
    a.vwrite     a2, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #14400
    s.movz       s57, #1
    a.vwrite     a2, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #14464
    s.movz       s55, #2
    a.vwrite     a3, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #14528
    s.movz       s56, #3
    a.vwrite     a3, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #14592
    s.movz       s57, #4
    a.vwrite     a3, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #14656
    s.movz       s55, #5
    a.vwrite     a3, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #14720
    s.movz       s56, #6
    a.vwrite     a3, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #14784
    s.movz       s57, #7
    a.vwrite     a3, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #14848
    s.movz       s55, #8
    a.vwrite     a3, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #14912
    s.movz       s56, #9
    a.vwrite     a3, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #14976
    s.movz       s57, #10
    a.vwrite     a3, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #15040
    s.movz       s55, #11
    a.vwrite     a3, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #15104
    s.movz       s56, #12
    a.vwrite     a3, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #15168
    s.movz       s57, #13
    a.vwrite     a3, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #15232
    s.movz       s55, #14
    a.vwrite     a3, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #15296
    s.movz       s56, #15
    a.vwrite     a3, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #15360
    s.movz       s57, #0
    a.vwrite     a3, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #15424
    s.movz       s55, #1
    a.vwrite     a3, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #15488
    s.movz       s56, #2
    a.vwrite     a4, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #15552
    s.movz       s57, #3
    a.vwrite     a4, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #15616
    s.movz       s55, #4
    a.vwrite     a4, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #15680
    s.movz       s56, #5
    a.vwrite     a4, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #15744
    s.movz       s57, #6
    a.vwrite     a4, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #15808
    s.movz       s55, #7
    a.vwrite     a4, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #15872
    s.movz       s56, #8
    a.vwrite     a4, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #15936
    s.movz       s57, #9
    a.vwrite     a4, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #16000
    s.movz       s55, #10
    a.vwrite     a4, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #16064
    s.movz       s56, #11
    a.vwrite     a4, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #16128
    s.movz       s57, #12
    a.vwrite     a4, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #16192
    s.movz       s55, #13
    a.vwrite     a4, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #16256
    s.movz       s56, #14
    a.vwrite     a4, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #16320
    s.movz       s57, #15
    a.vwrite     a4, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #16384
    s.movz       s55, #0
    a.vwrite     a4, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #16448
    s.movz       s56, #1
    a.vwrite     a4, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #16512
    s.movz       s57, #2
    a.vwrite     a5, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #16576
    s.movz       s55, #3
    a.vwrite     a5, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #16640
    s.movz       s56, #4
    a.vwrite     a5, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #16704
    s.movz       s57, #5
    a.vwrite     a5, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #16768
    s.movz       s55, #6
    a.vwrite     a5, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #16832
    s.movz       s56, #7
    a.vwrite     a5, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #16896
    s.movz       s57, #8
    a.vwrite     a5, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #16960
    s.movz       s55, #9
    a.vwrite     a5, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #17024
    s.movz       s56, #10
    a.vwrite     a5, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #17088
    s.movz       s57, #11
    a.vwrite     a5, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #17152
    s.movz       s55, #12
    a.vwrite     a5, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #17216
    s.movz       s56, #13
    a.vwrite     a5, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #17280
    s.movz       s57, #14
    a.vwrite     a5, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #17344
    s.movz       s55, #15
    a.vwrite     a5, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #17408
    s.movz       s56, #0
    a.vwrite     a5, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #17472
    s.movz       s57, #1
    a.vwrite     a5, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #17536
    s.movz       s55, #2
    a.vwrite     a6, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #17600
    s.movz       s56, #3
    a.vwrite     a6, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #17664
    s.movz       s57, #4
    a.vwrite     a6, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #17728
    s.movz       s55, #5
    a.vwrite     a6, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #17792
    s.movz       s56, #6
    a.vwrite     a6, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #17856
    s.movz       s57, #7
    a.vwrite     a6, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #17920
    s.movz       s55, #8
    a.vwrite     a6, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #17984
    s.movz       s56, #9
    a.vwrite     a6, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #18048
    s.movz       s57, #10
    a.vwrite     a6, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #18112
    s.movz       s55, #11
    a.vwrite     a6, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #18176
    s.movz       s56, #12
    a.vwrite     a6, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #18240
    s.movz       s57, #13
    a.vwrite     a6, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #18304
    s.movz       s55, #14
    a.vwrite     a6, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #18368
    s.movz       s56, #15
    a.vwrite     a6, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #18432
    s.movz       s57, #0
    a.vwrite     a6, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #18496
    s.movz       s55, #1
    a.vwrite     a6, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #18560
    s.movz       s56, #2
    a.vwrite     a7, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #18624
    s.movz       s57, #3
    a.vwrite     a7, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #18688
    s.movz       s55, #4
    a.vwrite     a7, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #18752
    s.movz       s56, #5
    a.vwrite     a7, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #18816
    s.movz       s57, #6
    a.vwrite     a7, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #18880
    s.movz       s55, #7
    a.vwrite     a7, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #18944
    s.movz       s56, #8
    a.vwrite     a7, s57, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #19008
    s.movz       s57, #9
    a.vwrite     a7, s55, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #19072
    s.movz       s55, #10
    a.vwrite     a7, s56, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #19136
    s.movz       s56, #11
    a.vwrite     a7, s57, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #19200
    s.movz       s57, #12
    a.vwrite     a7, s55, v0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s23, #19264
    s.movz       s55, #13
    a.vwrite     a7, s56, v0
    v.ld.w       v0, [s54, #0]
    s.addi       s54, s23, #19328
    s.movz       s56, #14
    s.addi       s58, s23, #19392
    s.add        s23, s17, s16
    a.vwrite     a7, s57, v0
    v.ld.w       v0, [s53, #0]
    s.movz       s53, #15
    s.movz       s57, #1
    a.vwrite     a7, s55, v0
    v.ld.w       v0, [s54, #0]
    a.vwrite     a7, s56, v0
    v.ld.w       v0, [s58, #0]
    a.vwrite     a7, s53, v0
    s.mov        s17, s23
    br.nz        s57, for_2
endfor_3:
    s.movz       s4, #0
    s.muli       s5, s3, #64                     // a runtime tile origin, x64
    s.add        s6, s4, s3                      // the tile origin
    s.movz       s4, #7
    v.splat      v0, s6
    v.splat      v1, s4
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s4, #0
    v.cmp.lt     p1, v0, v1
    v.cmp.lt     p2, v2, v3
    s.add        s7, s8, s5                      // the tile origin
    s.addi       s5, s6, #1
    a.vread      v0, a0, s4
    v.splat      v3, s5
    s.addi       s4, s6, #2
    p.and        p3, p1, p2
    s.movz       s5, #1
    v.splat      v4, s4
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #64                     // row 1
    s.addi       s5, s6, #3
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #2
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #128                    // row 2
    s.addi       s5, s6, #4
    p.and        p3, p1, p2
    v.splat      v4, s5
    s.movz       s5, #3
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #192                    // row 3
    s.addi       s5, s6, #5
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #4
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #256                    // row 4
    s.addi       s5, s6, #6
    p.and        p3, p1, p2
    v.splat      v4, s5
    s.movz       s5, #5
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #320                    // row 5
    s.addi       s5, s6, #7
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #6
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #384                    // row 6
    s.addi       s5, s6, #8
    p.and        p3, p1, p2
    v.splat      v4, s5
    s.movz       s5, #7
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #448                    // row 7
    s.addi       s5, s6, #9
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #8
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #512                    // row 8
    s.addi       s5, s6, #10
    p.and        p3, p1, p2
    v.splat      v4, s5
    s.movz       s5, #9
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #576                    // row 9
    s.addi       s5, s6, #11
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #10
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #640                    // row 10
    s.addi       s5, s6, #12
    p.and        p3, p1, p2
    v.splat      v4, s5
    s.movz       s5, #11
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #704                    // row 11
    s.addi       s5, s6, #13
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #12
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #768                    // row 12
    s.addi       s5, s6, #14
    p.and        p3, p1, p2
    v.splat      v4, s5
    s.movz       s5, #13
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a0, s5
    s.addi       s4, s7, #832                    // row 13
    s.addi       s5, s6, #15
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #14
    @p3 v.st.w       [s4, #0], v0
    s.muli       s4, s2, #4                      // a runtime tile origin, x4
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a0, s5
    s.addi       s5, s7, #896                    // row 14
    p.and        p3, p1, p2
    v.splat      v4, s6
    s.addi       s14, s7, #960                   // row 15
    s.add        s7, s8, s4                      // the tile origin
    @p3 v.st.w       [s5, #0], v0
    s.muli       s4, s3, #64                     // a runtime tile origin, x64
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    v.cmp.lt     p1, v4, v1
    s.add        s5, s7, s4                      // the tile origin
    s.movz       s4, #15
    a.vread      v0, a0, s4
    s.movz       s4, #0
    v.splat      v3, s2
    s.add        s7, s4, s2                      // the tile origin
    @p3 v.st.w       [s14, #0], v0
    v.splat      v0, s7
    s.addi       s4, s6, #1
    v.add        v4, v2, v0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s7, #0
    v.cmp.lt     p2, v4, v3
    v.splat      v0, s4
    a.vread      v3, a1, s7
    s.addi       s4, s6, #2
    p.and        p3, p1, p2
    s.movz       s7, #1
    v.splat      v4, s4
    @p3 v.st.w       [s5, #0], v3
    v.cmp.lt     p1, v0, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #64                     // row 1
    s.addi       s7, s6, #3
    p.and        p3, p1, p2
    v.splat      v3, s7
    s.movz       s7, #2
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #128                    // row 2
    s.addi       s7, s6, #4
    p.and        p3, p1, p2
    v.splat      v4, s7
    s.movz       s7, #3
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #192                    // row 3
    s.addi       s7, s6, #5
    p.and        p3, p1, p2
    v.splat      v3, s7
    s.movz       s7, #4
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #256                    // row 4
    s.addi       s7, s6, #6
    p.and        p3, p1, p2
    v.splat      v4, s7
    s.movz       s7, #5
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #320                    // row 5
    s.addi       s7, s6, #7
    p.and        p3, p1, p2
    v.splat      v3, s7
    s.movz       s7, #6
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #384                    // row 6
    s.addi       s7, s6, #8
    p.and        p3, p1, p2
    v.splat      v4, s7
    s.movz       s7, #7
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #448                    // row 7
    s.addi       s7, s6, #9
    p.and        p3, p1, p2
    v.splat      v3, s7
    s.movz       s7, #8
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #512                    // row 8
    s.addi       s7, s6, #10
    p.and        p3, p1, p2
    v.splat      v4, s7
    s.movz       s7, #9
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #576                    // row 9
    s.addi       s7, s6, #11
    p.and        p3, p1, p2
    v.splat      v3, s7
    s.movz       s7, #10
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #640                    // row 10
    s.addi       s7, s6, #12
    p.and        p3, p1, p2
    v.splat      v4, s7
    s.movz       s7, #11
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #704                    // row 11
    s.addi       s7, s6, #13
    p.and        p3, p1, p2
    v.splat      v3, s7
    s.movz       s7, #12
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #768                    // row 12
    s.addi       s7, s6, #14
    p.and        p3, p1, p2
    v.splat      v4, s7
    s.movz       s7, #13
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a1, s7
    s.addi       s4, s5, #832                    // row 13
    s.addi       s7, s6, #15
    p.and        p3, p1, p2
    v.splat      v3, s7
    s.movz       s7, #14
    @p3 v.st.w       [s4, #0], v0
    s.muli       s4, s1, #4                      // a runtime tile origin, x4
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a1, s7
    s.addi       s7, s5, #896                    // row 14
    p.and        p3, p1, p2
    v.splat      v4, s6
    s.addi       s14, s5, #960                   // row 15
    s.add        s5, s8, s4                      // the tile origin
    @p3 v.st.w       [s7, #0], v0
    s.muli       s4, s3, #64                     // a runtime tile origin, x64
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    v.cmp.lt     p1, v4, v1
    s.add        s7, s5, s4                      // the tile origin
    s.movz       s4, #15
    a.vread      v0, a1, s4
    s.movz       s4, #0
    v.splat      v3, s2
    s.add        s5, s4, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    v.splat      v4, s5
    @p3 v.st.w       [s14, #0], v0
    v.add        v0, v2, v4
    s.addi       s4, s6, #1
    v.cmp.lt     p2, v0, v3
    v.splat      v0, s4
    a.vread      v3, a2, s1
    s.addi       s1, s6, #2
    p.and        p3, p1, p2
    s.movz       s4, #1
    v.splat      v4, s1
    @p3 v.st.w       [s7, #0], v3
    v.cmp.lt     p1, v0, v1
    a.vread      v0, a2, s4
    s.addi       s1, s7, #64                     // row 1
    s.addi       s4, s6, #3
    p.and        p3, p1, p2
    s.movz       s5, #2
    v.splat      v3, s4
    s.addi       s4, s7, #128                    // row 2
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a2, s5
    s.addi       s1, s6, #4
    p.and        p3, p1, p2
    s.movz       s5, #3
    v.splat      v4, s1
    s.addi       s1, s7, #192                    // row 3
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a2, s5
    s.addi       s4, s6, #5
    p.and        p3, p1, p2
    s.movz       s5, #4
    v.splat      v3, s4
    s.addi       s4, s7, #256                    // row 4
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a2, s5
    s.addi       s1, s6, #6
    p.and        p3, p1, p2
    s.movz       s5, #5
    v.splat      v4, s1
    s.addi       s1, s7, #320                    // row 5
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a2, s5
    s.addi       s4, s6, #7
    p.and        p3, p1, p2
    s.movz       s5, #6
    v.splat      v3, s4
    s.addi       s4, s7, #384                    // row 6
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a2, s5
    s.addi       s1, s6, #8
    p.and        p3, p1, p2
    s.movz       s5, #7
    v.splat      v4, s1
    s.addi       s1, s7, #448                    // row 7
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a2, s5
    s.addi       s4, s6, #9
    p.and        p3, p1, p2
    s.movz       s5, #8
    v.splat      v3, s4
    s.addi       s4, s7, #512                    // row 8
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a2, s5
    s.addi       s1, s6, #10
    p.and        p3, p1, p2
    s.movz       s5, #9
    v.splat      v4, s1
    s.addi       s1, s7, #576                    // row 9
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a2, s5
    s.addi       s4, s6, #11
    p.and        p3, p1, p2
    s.movz       s5, #10
    v.splat      v3, s4
    s.addi       s4, s7, #640                    // row 10
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a2, s5
    s.addi       s1, s6, #12
    p.and        p3, p1, p2
    s.movz       s5, #11
    v.splat      v4, s1
    s.addi       s1, s7, #704                    // row 11
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a2, s5
    s.addi       s4, s6, #13
    p.and        p3, p1, p2
    s.movz       s5, #12
    v.splat      v3, s4
    s.addi       s4, s7, #768                    // row 12
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a2, s5
    s.addi       s1, s6, #14
    p.and        p3, p1, p2
    s.movz       s5, #13
    v.splat      v4, s1
    s.addi       s1, s7, #832                    // row 13
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a2, s5
    s.addi       s4, s6, #15
    p.and        p3, p1, p2
    s.movz       s5, #14
    v.splat      v3, s4
    s.addi       s4, s7, #896                    // row 14
    s.addi       s14, s7, #960                   // row 15
    @p3 v.st.w       [s1, #0], v0
    s.muli       s1, s9, #4                      // a runtime tile origin, x4
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a2, s5
    s.muli       s5, s3, #64                     // a runtime tile origin, x64
    p.and        p3, p1, p2
    v.splat      v4, s6
    s.add        s7, s8, s1                      // the tile origin
    s.add        s1, s7, s5                      // the tile origin
    s.movz       s5, #15
    @p3 v.st.w       [s4, #0], v0
    s.movz       s4, #0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a2, s5
    s.add        s5, s4, s9                      // the tile origin
    v.splat      v3, s2
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s4, #0
    v.cmp.lt     p1, v4, v1
    v.splat      v4, s5
    @p3 v.st.w       [s14, #0], v0
    v.add        v0, v2, v4
    s.addi       s5, s6, #1
    v.cmp.lt     p2, v0, v3
    v.splat      v0, s5
    a.vread      v3, a3, s4
    s.addi       s4, s6, #2
    p.and        p3, p1, p2
    s.movz       s5, #1
    v.splat      v4, s4
    @p3 v.st.w       [s1, #0], v3
    v.cmp.lt     p1, v0, v1
    a.vread      v0, a3, s5
    s.addi       s4, s1, #64                     // row 1
    s.addi       s5, s6, #3
    p.and        p3, p1, p2
    s.movz       s7, #2
    v.splat      v3, s5
    s.addi       s5, s1, #128                    // row 2
    s.movz       s9, #3
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a3, s7
    s.addi       s4, s6, #4
    p.and        p3, p1, p2
    v.splat      v4, s4
    s.addi       s4, s1, #192                    // row 3
    s.movz       s7, #4
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a3, s9
    s.addi       s5, s6, #5
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.addi       s5, s1, #256                    // row 4
    s.movz       s9, #5
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a3, s7
    s.addi       s4, s6, #6
    p.and        p3, p1, p2
    v.splat      v4, s4
    s.addi       s4, s1, #320                    // row 5
    s.movz       s7, #6
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a3, s9
    s.addi       s5, s6, #7
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.addi       s5, s1, #384                    // row 6
    s.movz       s9, #7
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a3, s7
    s.addi       s4, s6, #8
    p.and        p3, p1, p2
    v.splat      v4, s4
    s.addi       s4, s1, #448                    // row 7
    s.movz       s7, #8
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a3, s9
    s.addi       s5, s6, #9
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.addi       s5, s1, #512                    // row 8
    s.movz       s9, #9
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a3, s7
    s.addi       s4, s6, #10
    p.and        p3, p1, p2
    v.splat      v4, s4
    s.addi       s4, s1, #576                    // row 9
    s.movz       s7, #10
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a3, s9
    s.addi       s5, s6, #11
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.addi       s5, s1, #640                    // row 10
    s.movz       s9, #11
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a3, s7
    s.addi       s4, s6, #12
    p.and        p3, p1, p2
    v.splat      v4, s4
    s.addi       s4, s1, #704                    // row 11
    s.movz       s7, #12
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a3, s9
    s.addi       s5, s6, #13
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.addi       s5, s1, #768                    // row 12
    s.movz       s9, #13
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a3, s7
    s.addi       s4, s6, #14
    p.and        p3, p1, p2
    v.splat      v4, s4
    s.addi       s4, s1, #832                    // row 13
    s.movz       s7, #14
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a3, s9
    s.addi       s5, s6, #15
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.addi       s5, s1, #896                    // row 14
    s.movz       s9, #15
    s.addi       s14, s1, #960                   // row 15
    @p3 v.st.w       [s4, #0], v0
    s.muli       s1, s10, #4                     // a runtime tile origin, x4
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a3, s7
    s.muli       s4, s3, #64                     // a runtime tile origin, x64
    p.and        p3, p1, p2
    v.splat      v4, s6
    s.add        s7, s8, s1                      // the tile origin
    s.add        s1, s7, s4                      // the tile origin
    @p3 v.st.w       [s5, #0], v0
    s.movz       s4, #0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a3, s9
    s.add        s5, s4, s10                     // the tile origin
    v.splat      v3, s2
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s4, #0
    v.cmp.lt     p1, v4, v1
    v.splat      v4, s5
    @p3 v.st.w       [s14, #0], v0
    v.add        v0, v2, v4
    s.addi       s5, s6, #1
    v.cmp.lt     p2, v0, v3
    v.splat      v0, s5
    a.vread      v3, a4, s4
    s.addi       s4, s6, #2
    p.and        p3, p1, p2
    s.movz       s5, #1
    v.splat      v4, s4
    @p3 v.st.w       [s1, #0], v3
    v.cmp.lt     p1, v0, v1
    a.vread      v0, a4, s5
    s.addi       s4, s1, #64                     // row 1
    s.addi       s5, s6, #3
    p.and        p3, p1, p2
    s.movz       s7, #2
    v.splat      v3, s5
    s.addi       s5, s1, #128                    // row 2
    s.movz       s9, #3
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a4, s7
    s.addi       s4, s6, #4
    p.and        p3, p1, p2
    v.splat      v4, s4
    s.addi       s4, s1, #192                    // row 3
    s.movz       s7, #4
    s.addi       s10, s1, #256                   // row 4
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a4, s9
    s.addi       s5, s6, #5
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #5
    s.addi       s9, s1, #320                    // row 5
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a4, s7
    s.addi       s4, s6, #6
    p.and        p3, p1, p2
    v.splat      v4, s4
    s.movz       s4, #6
    s.addi       s7, s1, #384                    // row 6
    @p3 v.st.w       [s10, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a4, s5
    s.addi       s5, s6, #7
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #7
    s.addi       s10, s1, #448                   // row 7
    @p3 v.st.w       [s9, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a4, s4
    s.addi       s4, s6, #8
    p.and        p3, p1, p2
    v.splat      v4, s4
    s.movz       s4, #8
    s.addi       s9, s1, #512                    // row 8
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a4, s5
    s.addi       s5, s6, #9
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #9
    s.addi       s7, s1, #576                    // row 9
    @p3 v.st.w       [s10, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a4, s4
    s.addi       s4, s6, #10
    p.and        p3, p1, p2
    v.splat      v4, s4
    s.movz       s4, #10
    s.addi       s10, s1, #640                   // row 10
    @p3 v.st.w       [s9, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a4, s5
    s.addi       s5, s6, #11
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #11
    s.addi       s9, s1, #704                    // row 11
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a4, s4
    s.addi       s4, s6, #12
    p.and        p3, p1, p2
    v.splat      v4, s4
    s.movz       s4, #12
    s.addi       s7, s1, #768                    // row 12
    @p3 v.st.w       [s10, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a4, s5
    s.addi       s5, s6, #13
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #13
    s.addi       s10, s1, #832                   // row 13
    @p3 v.st.w       [s9, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a4, s4
    s.addi       s4, s6, #14
    p.and        p3, p1, p2
    v.splat      v4, s4
    s.movz       s4, #14
    s.addi       s9, s1, #896                    // row 14
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a4, s5
    s.addi       s5, s6, #15
    p.and        p3, p1, p2
    v.splat      v3, s5
    s.movz       s5, #15
    s.addi       s7, s1, #960                    // row 15
    @p3 v.st.w       [s10, #0], v0
    s.muli       s1, s11, #4                     // a runtime tile origin, x4
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a4, s4
    s.muli       s4, s3, #64                     // a runtime tile origin, x64
    p.and        p3, p1, p2
    v.splat      v4, s6
    s.add        s10, s8, s1                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    s.add        s14, s10, s4                    // the tile origin
    @p3 v.st.w       [s9, #0], v0
    s.movz       s4, #0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a4, s5
    s.add        s5, s4, s11                     // the tile origin
    v.splat      v3, s2
    p.and        p3, p1, p2
    v.cmp.lt     p1, v4, v1
    v.splat      v4, s5
    v.add        v5, v2, v4
    @p3 v.st.w       [s7, #0], v0
    s.addi       s4, s6, #1
    v.cmp.lt     p2, v5, v3
    v.splat      v0, s4
    a.vread      v3, a5, s1
    s.addi       s1, s6, #2
    p.and        p3, p1, p2
    s.movz       s4, #1
    v.splat      v4, s1
    s.addi       s1, s14, #64                    // row 1
    @p3 v.st.w       [s14, #0], v3
    v.cmp.lt     p1, v0, v1
    a.vread      v0, a5, s4
    s.addi       s4, s6, #3
    p.and        p3, p1, p2
    s.movz       s5, #2
    v.splat      v3, s4
    s.addi       s4, s14, #128                   // row 2
    s.movz       s7, #3
    s.addi       s9, s14, #192                   // row 3
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a5, s5
    s.addi       s1, s6, #4
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.movz       s1, #4
    s.addi       s5, s14, #256                   // row 4
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a5, s7
    s.addi       s4, s6, #5
    p.and        p3, p1, p2
    v.splat      v3, s4
    s.movz       s4, #5
    s.addi       s7, s14, #320                   // row 5
    @p3 v.st.w       [s9, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a5, s1
    s.addi       s1, s6, #6
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.movz       s1, #6
    s.addi       s9, s14, #384                   // row 6
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a5, s4
    s.addi       s4, s6, #7
    p.and        p3, p1, p2
    v.splat      v3, s4
    s.movz       s4, #7
    s.addi       s5, s14, #448                   // row 7
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a5, s1
    s.addi       s1, s6, #8
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.movz       s1, #8
    s.addi       s7, s14, #512                   // row 8
    @p3 v.st.w       [s9, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a5, s4
    s.addi       s4, s6, #9
    p.and        p3, p1, p2
    v.splat      v3, s4
    s.movz       s4, #9
    s.addi       s9, s14, #576                   // row 9
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a5, s1
    s.addi       s1, s6, #10
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.movz       s1, #10
    s.addi       s5, s14, #640                   // row 10
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a5, s4
    s.addi       s4, s6, #11
    p.and        p3, p1, p2
    v.splat      v3, s4
    s.movz       s4, #11
    s.addi       s7, s14, #704                   // row 11
    @p3 v.st.w       [s9, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a5, s1
    s.addi       s1, s6, #12
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.movz       s1, #12
    s.addi       s9, s14, #768                   // row 12
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a5, s4
    s.addi       s4, s6, #13
    p.and        p3, p1, p2
    v.splat      v3, s4
    s.movz       s4, #13
    s.addi       s5, s14, #832                   // row 13
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a5, s1
    s.addi       s1, s6, #14
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.movz       s1, #14
    s.addi       s7, s14, #896                   // row 14
    @p3 v.st.w       [s9, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a5, s4
    s.addi       s4, s6, #15
    p.and        p3, p1, p2
    v.splat      v3, s4
    s.movz       s4, #15
    s.addi       s9, s14, #960                   // row 15
    @p3 v.st.w       [s5, #0], v0
    s.muli       s5, s12, #4                     // a runtime tile origin, x4
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a5, s1
    s.muli       s1, s3, #64                     // a runtime tile origin, x64
    p.and        p3, p1, p2
    v.splat      v4, s6
    s.add        s10, s8, s5                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    s.add        s11, s10, s1                    // the tile origin
    @p3 v.st.w       [s7, #0], v0
    s.movz       s1, #0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a5, s4
    s.add        s4, s1, s12                     // the tile origin
    v.splat      v3, s2
    p.and        p3, p1, p2
    v.cmp.lt     p1, v4, v1
    v.splat      v4, s4
    v.add        v5, v2, v4
    @p3 v.st.w       [s9, #0], v0
    s.addi       s1, s6, #1
    v.cmp.lt     p2, v5, v3
    v.splat      v0, s1
    a.vread      v3, a6, s5
    s.addi       s1, s6, #2
    p.and        p3, p1, p2
    s.movz       s4, #1
    v.splat      v4, s1
    s.addi       s1, s11, #64                    // row 1
    @p3 v.st.w       [s11, #0], v3
    v.cmp.lt     p1, v0, v1
    a.vread      v0, a6, s4
    s.addi       s4, s6, #3
    p.and        p3, p1, p2
    s.movz       s5, #2
    v.splat      v3, s4
    s.addi       s4, s11, #128                   // row 2
    s.movz       s7, #3
    s.addi       s9, s11, #192                   // row 3
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a6, s5
    s.addi       s1, s6, #4
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.movz       s1, #4
    s.addi       s5, s11, #256                   // row 4
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a6, s7
    s.addi       s4, s6, #5
    p.and        p3, p1, p2
    v.splat      v3, s4
    s.movz       s4, #5
    s.addi       s7, s11, #320                   // row 5
    @p3 v.st.w       [s9, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a6, s1
    s.addi       s1, s6, #6
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.movz       s1, #6
    s.addi       s9, s11, #384                   // row 6
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a6, s4
    s.addi       s4, s6, #7
    p.and        p3, p1, p2
    v.splat      v3, s4
    s.movz       s4, #7
    s.addi       s5, s11, #448                   // row 7
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a6, s1
    s.addi       s1, s6, #8
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.movz       s1, #8
    s.addi       s7, s11, #512                   // row 8
    @p3 v.st.w       [s9, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a6, s4
    s.addi       s4, s6, #9
    p.and        p3, p1, p2
    v.splat      v3, s4
    s.movz       s4, #9
    s.addi       s9, s11, #576                   // row 9
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a6, s1
    s.addi       s1, s6, #10
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.movz       s1, #10
    s.addi       s5, s11, #640                   // row 10
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a6, s4
    s.addi       s4, s6, #11
    p.and        p3, p1, p2
    v.splat      v3, s4
    s.movz       s4, #11
    s.addi       s7, s11, #704                   // row 11
    @p3 v.st.w       [s9, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a6, s1
    s.addi       s1, s6, #12
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.movz       s1, #12
    s.addi       s9, s11, #768                   // row 12
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a6, s4
    s.addi       s4, s6, #13
    p.and        p3, p1, p2
    v.splat      v3, s4
    s.movz       s4, #13
    s.addi       s5, s11, #832                   // row 13
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a6, s1
    s.addi       s1, s6, #14
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.movz       s1, #14
    s.addi       s7, s11, #896                   // row 14
    @p3 v.st.w       [s9, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a6, s4
    s.addi       s4, s6, #15
    p.and        p3, p1, p2
    v.splat      v3, s4
    s.movz       s4, #15
    s.addi       s9, s11, #960                   // row 15
    @p3 v.st.w       [s5, #0], v0
    s.muli       s5, s13, #4                     // a runtime tile origin, x4
    v.cmp.lt     p1, v4, v1
    a.vread      v0, a6, s1
    s.muli       s1, s3, #64                     // a runtime tile origin, x64
    p.and        p3, p1, p2
    v.splat      v4, s6
    s.add        s3, s8, s5                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    s.add        s8, s3, s1                      // the tile origin
    @p3 v.st.w       [s7, #0], v0
    s.movz       s1, #0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a6, s4
    s.add        s3, s1, s13                     // the tile origin
    v.splat      v3, s2
    p.and        p3, p1, p2
    v.cmp.lt     p1, v4, v1
    v.splat      v4, s3
    v.add        v5, v2, v4
    @p3 v.st.w       [s9, #0], v0
    s.addi       s1, s6, #1
    v.cmp.lt     p2, v5, v3
    v.splat      v0, s1
    a.vread      v2, a7, s5
    s.addi       s1, s6, #2
    p.and        p3, p1, p2
    s.movz       s2, #1
    v.splat      v3, s1
    s.addi       s1, s8, #64                     // row 1
    @p3 v.st.w       [s8, #0], v2
    v.cmp.lt     p1, v0, v1
    a.vread      v0, a7, s2
    s.addi       s2, s6, #3
    p.and        p3, p1, p2
    s.movz       s3, #2
    v.splat      v2, s2
    s.addi       s2, s8, #128                    // row 2
    s.movz       s4, #3
    s.addi       s5, s8, #192                    // row 3
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a7, s3
    s.addi       s1, s6, #4
    p.and        p3, p1, p2
    v.splat      v3, s1
    s.movz       s1, #4
    s.addi       s3, s8, #256                    // row 4
    @p3 v.st.w       [s2, #0], v0
    v.cmp.lt     p1, v2, v1
    a.vread      v0, a7, s4
    s.addi       s2, s6, #5
    p.and        p3, p1, p2
    v.splat      v2, s2
    s.movz       s2, #5
    s.addi       s4, s8, #320                    // row 5
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a7, s1
    s.addi       s1, s6, #6
    p.and        p3, p1, p2
    v.splat      v3, s1
    s.movz       s1, #6
    s.addi       s5, s8, #384                    // row 6
    @p3 v.st.w       [s3, #0], v0
    v.cmp.lt     p1, v2, v1
    a.vread      v0, a7, s2
    s.addi       s2, s6, #7
    p.and        p3, p1, p2
    v.splat      v2, s2
    s.movz       s2, #7
    s.addi       s3, s8, #448                    // row 7
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a7, s1
    s.addi       s1, s6, #8
    p.and        p3, p1, p2
    v.splat      v3, s1
    s.movz       s1, #8
    s.addi       s4, s8, #512                    // row 8
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v2, v1
    a.vread      v0, a7, s2
    s.addi       s2, s6, #9
    p.and        p3, p1, p2
    v.splat      v2, s2
    s.movz       s2, #9
    s.addi       s5, s8, #576                    // row 9
    @p3 v.st.w       [s3, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a7, s1
    s.addi       s1, s6, #10
    p.and        p3, p1, p2
    v.splat      v3, s1
    s.movz       s1, #10
    s.addi       s3, s8, #640                    // row 10
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v2, v1
    a.vread      v0, a7, s2
    s.addi       s2, s6, #11
    p.and        p3, p1, p2
    v.splat      v2, s2
    s.movz       s2, #11
    s.addi       s4, s8, #704                    // row 11
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a7, s1
    s.addi       s1, s6, #12
    p.and        p3, p1, p2
    v.splat      v3, s1
    s.movz       s1, #12
    s.addi       s5, s8, #768                    // row 12
    @p3 v.st.w       [s3, #0], v0
    v.cmp.lt     p1, v2, v1
    a.vread      v0, a7, s2
    s.addi       s2, s6, #13
    p.and        p3, p1, p2
    v.splat      v2, s2
    s.movz       s2, #13
    s.addi       s3, s8, #832                    // row 13
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a7, s1
    s.addi       s1, s6, #14
    p.and        p3, p1, p2
    v.splat      v3, s1
    s.movz       s1, #14
    s.addi       s4, s8, #896                    // row 14
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p1, v2, v1
    a.vread      v0, a7, s2
    s.addi       s2, s6, #15
    p.and        p3, p1, p2
    v.splat      v2, s2
    s.movz       s2, #15
    s.addi       s5, s8, #960                    // row 15
    @p3 v.st.w       [s3, #0], v0
    v.cmp.lt     p1, v3, v1
    a.vread      v0, a7, s1
    p.and        p3, p1, p2
    @p3 v.st.w       [s4, #0], v0
    v.cmp.lt     p1, v2, v1
    a.vread      v0, a7, s2
    p.and        p3, p1, p2
    @p3 v.st.w       [s5, #0], v0
    exit
    exit
