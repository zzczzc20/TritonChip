    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    s.movz       s2, #0
    v.iota       v0                              // arange(0, VLEN)
    s.add        s3, s2, s1                      // the tile origin
    s.rdspecial  s2, arg_base
    v.splat      v1, s3
    v.movi       v2, #0
    v.add        v3, v0, v1
    v.movi       v0, #0
    v.extract    s3, v3, #0
    s.shli       s4, s3, #32
    v.extract    s3, v3, #1
    s.ashri      s5, s4, #32
    s.shli       s4, s3, #32
    v.extract    s3, v3, #2
    s.lshri      s6, s5, #32
    s.ashri      s7, s4, #32
    s.shli       s4, s3, #32
    v.extract    s3, v3, #3
    s.ld.d       s8, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.lshri      s9, s7, #32
    s.ashri      s10, s4, #32
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.insert     v2, s5, #0
    v.insert     v0, s6, #0
    s.shli       s2, s3, #32
    v.extract    s3, v3, #4
    v.insert     v2, s7, #1
    v.insert     v0, s9, #1
    s.lshri      s5, s10, #32
    s.ashri      s6, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v3, #5
    v.insert     v2, s10, #2
    v.insert     v0, s5, #2
    s.lshri      s5, s6, #32
    s.ashri      s7, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v3, #6
    v.insert     v2, s6, #3
    v.insert     v0, s5, #3
    s.lshri      s5, s7, #32
    s.ashri      s6, s2, #32
    s.shli       s2, s3, #32
    v.insert     v2, s7, #4
    v.insert     v0, s5, #4
    s.lshri      s3, s6, #32
    v.insert     v2, s6, #5
    v.insert     v0, s3, #5
    s.rdspecial  s3, pid.y
    s.ashri      s5, s2, #32
    s.shli       s2, s3, #4                      // x16 as a shift
    v.extract    s3, v3, #7
    s.shli       s6, s3, #32
    v.extract    s3, v3, #8
    s.lshri      s7, s5, #32
    s.ashri      s9, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v3, #9
    v.insert     v2, s5, #6
    v.insert     v0, s7, #6
    s.lshri      s5, s9, #32
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v3, #10
    v.insert     v2, s9, #7
    v.insert     v0, s5, #7
    s.lshri      s5, s7, #32
    s.ashri      s9, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v3, #11
    v.insert     v2, s7, #8
    v.insert     v0, s5, #8
    s.lshri      s5, s9, #32
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v3, #12
    v.insert     v2, s9, #9
    v.insert     v0, s5, #9
    s.lshri      s5, s7, #32
    s.ashri      s9, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v3, #13
    v.insert     v2, s7, #10
    v.insert     v0, s5, #10
    s.lshri      s5, s9, #32
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v3, #14
    v.insert     v2, s9, #11
    v.insert     v0, s5, #11
    s.lshri      s5, s7, #32
    s.ashri      s9, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v3, #15
    v.insert     v2, s7, #12
    v.insert     v0, s5, #12
    s.lshri      s5, s9, #32
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.insert     v2, s9, #13
    v.insert     v0, s5, #13
    s.lshri      s3, s7, #32
    s.ashri      s5, s6, #32
    v.insert     v2, s7, #14
    v.insert     v0, s3, #14
    s.lshri      s3, s5, #32
    v.insert     v2, s5, #15
    v.insert     v0, s3, #15
    v.extract    s3, v2, #0
    v.extract    s5, v0, #0
    s.shli       s6, s5, #32
    v.extract    s5, v0, #1
    s.or         s7, s3, s6
    s.movz       s3, #17
    s.shli       s6, s5, #32
    v.extract    s5, v2, #1
    v.extract    s9, v0, #2
    v.movi       v1, #0
    s.cmp.lt     s10, s7, s3
    s.or         s7, s5, s6
    s.shli       s5, s9, #32
    v.extract    s6, v2, #2
    v.extract    s9, v0, #3
    v.insert     v1, s10, #0
    s.cmp.lt     s10, s7, s3
    s.or         s7, s6, s5
    s.shli       s5, s9, #32
    v.extract    s6, v2, #3
    v.extract    s9, v0, #4
    v.insert     v1, s10, #1
    s.cmp.lt     s10, s7, s3
    s.or         s7, s6, s5
    s.shli       s5, s9, #32
    v.extract    s6, v2, #4
    v.extract    s9, v0, #5
    v.insert     v1, s10, #2
    s.cmp.lt     s10, s7, s3
    s.or         s7, s6, s5
    s.shli       s5, s9, #32
    v.extract    s6, v2, #5
    v.extract    s9, v0, #6
    v.insert     v1, s10, #3
    s.cmp.lt     s10, s7, s3
    s.or         s3, s6, s5
    s.movz       s5, #17
    s.shli       s6, s9, #32
    v.extract    s7, v2, #6
    v.extract    s9, v0, #7
    v.insert     v1, s10, #4
    s.cmp.lt     s10, s3, s5
    s.or         s3, s7, s6
    s.movz       s5, #17
    s.shli       s6, s9, #32
    v.extract    s7, v2, #7
    v.extract    s9, v0, #8
    v.insert     v1, s10, #5
    s.cmp.lt     s10, s3, s5
    s.or         s3, s7, s6
    s.movz       s5, #17
    s.shli       s6, s9, #32
    v.extract    s7, v2, #8
    v.extract    s9, v0, #9
    v.insert     v1, s10, #6
    s.cmp.lt     s10, s3, s5
    s.or         s3, s7, s6
    s.movz       s5, #17
    s.shli       s6, s9, #32
    v.extract    s7, v2, #9
    v.extract    s9, v0, #10
    v.insert     v1, s10, #7
    s.cmp.lt     s10, s3, s5
    s.or         s3, s7, s6
    s.movz       s5, #17
    s.shli       s6, s9, #32
    v.extract    s7, v2, #10
    v.extract    s9, v0, #11
    v.insert     v1, s10, #8
    s.cmp.lt     s10, s3, s5
    s.or         s3, s7, s6
    s.movz       s5, #17
    s.shli       s6, s9, #32
    v.extract    s7, v2, #11
    v.extract    s9, v0, #12
    v.insert     v1, s10, #9
    s.cmp.lt     s10, s3, s5
    s.or         s3, s7, s6
    s.movz       s5, #17
    s.shli       s6, s9, #32
    v.extract    s7, v2, #12
    v.extract    s9, v0, #13
    v.insert     v1, s10, #10
    s.cmp.lt     s10, s3, s5
    s.or         s3, s7, s6
    s.movz       s5, #17
    s.shli       s6, s9, #32
    v.extract    s7, v2, #13
    v.extract    s9, v0, #14
    v.insert     v1, s10, #11
    s.cmp.lt     s10, s3, s5
    s.or         s3, s7, s6
    s.movz       s5, #17
    s.shli       s6, s9, #32
    v.extract    s7, v2, #14
    v.extract    s9, v0, #15
    v.insert     v1, s10, #12
    s.cmp.lt     s10, s3, s5
    s.or         s3, s7, s6
    s.movz       s5, #17
    s.shli       s6, s9, #32
    v.extract    s7, v2, #15
    v.insert     v1, s10, #13
    s.cmp.lt     s9, s3, s5
    s.or         s3, s7, s6
    s.movz       s5, #17
    s.muli       s6, s1, #32                     // a runtime tile origin, x32
    s.movz       s7, #0
    v.insert     v1, s9, #14
    s.cmp.lt     s9, s3, s5
    s.movz       s3, #0
    s.add        s5, s7, s2                      // the tile origin
    s.movz       s7, #32
    v.insert     v1, s9, #15
    v.movi       v0, #0
    s.add        s9, s3, s2                      // the tile origin
    s.add        s3, s5, s6                      // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s7
    v.cmp.ne     p1, v1, v0
    s.rdspecial  s5, role_id
    s.movz       s6, #1024
    v.cmpi.lt    p2, v3, #64
    v.splat      v0, s9
    v.mul        v1, v2, v4
    v.splat      v2, s3
    p.and        p3, p1, p2
    s.rdspecial  s7, arg_base
    s.mul        s10, s5, s6
    v.cmpi.lt    p4, v0, #32
    v.add        v0, v1, v2
    p.and        p5, p3, p4
    s.ld.d       s5, [s7, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s6, s9, #1
    s.addi       s7, s3, #1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v2, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.splat      v0, s6
    s.add        s6, s5, s10                     // this context's own scratch
    v.splat      v3, s7
    p.and        p3, p1, p2
    v.cmpi.lt    p4, v0, #32
    s.addi       s5, s6, #0
    v.add        v0, v1, v3
    p.and        p5, p3, p4
    s.addi       s7, s9, #2
    v.st.w       [s5, #0], v2
    s.addi       s10, s3, #2
    v.splat      v2, s7
    v.splat      v3, s10
    p.and        p3, p1, p2
    v.cmpi.lt    p4, v2, #32
    s.addi       s7, s5, #64
    v.add        v2, v1, v3
    p.and        p6, p3, p4
    s.addi       s10, s9, #3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v3, [s8, v0]               // index is in elements (ISA sec 9.1)
    s.addi       s11, s3, #3
    v.splat      v0, s10
    v.splat      v4, s11
    p.and        p3, p1, p2
    v.cmpi.lt    p4, v0, #32
    v.st.w       [s7, #0], v3
    s.addi       s7, s5, #128
    v.add        v0, v1, v4
    p.and        p5, p3, p4
    s.addi       s10, s9, #4
    s.addi       s11, s3, #4
    v.splat      v3, s10
    v.splat      v4, s11
    p.and        p3, p1, p2
    s.addi       s10, s5, #192
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.h v5, [s8, v2]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v3, #32
    v.add        v2, v1, v4
    p.and        p6, p3, p4
    s.addi       s11, s9, #5
    s.addi       s12, s3, #5
    v.st.w       [s7, #0], v5
    v.splat      v3, s11
    v.splat      v4, s12
    p.and        p3, p1, p2
    s.addi       s7, s5, #256
    v.add        v5, v1, v4
    s.addi       s11, s9, #6
    s.addi       s12, s3, #6
    v.splat      v4, s11
    v.splat      v6, s12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v7, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v3, #32
    p.and        p5, p3, p4
    p.and        p3, p1, p2
    s.addi       s11, s5, #320
    v.add        v0, v1, v6
    v.st.w       [s10, #0], v7
    s.addi       s10, s9, #7
    s.addi       s12, s3, #7
    v.splat      v3, s10
    v.splat      v6, s12
    s.addi       s10, s5, #384
    v.add        v7, v1, v6
    s.addi       s12, s9, #8
    s.addi       s13, s3, #8
    v.splat      v6, s12
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.h v8, [s8, v2]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v4, #32
    p.and        p6, p3, p4
    p.and        p3, p1, p2
    v.splat      v2, s13
    s.addi       s12, s5, #448
    v.st.w       [s7, #0], v8
    v.add        v4, v1, v2
    s.addi       s7, s9, #9
    s.addi       s13, s3, #9
    v.splat      v2, s7
    v.splat      v8, s13
    s.addi       s7, s5, #512
    v.add        v9, v1, v8
    s.addi       s13, s3, #10
    s.addi       s14, s5, #576
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v8, [s8, v5]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v3, #32
    p.and        p5, p3, p4
    p.and        p3, p1, p2
    v.splat      v3, s13
    s.addi       s13, s5, #640
    v.st.w       [s11, #0], v8
    s.addi       s11, s9, #10
    v.add        v5, v1, v3
    v.splat      v3, s11
    s.addi       s11, s3, #11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.h v8, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v6, #32
    p.and        p6, p3, p4
    p.and        p3, p1, p2
    v.splat      v0, s11
    s.addi       s11, s5, #704
    v.st.w       [s10, #0], v8
    s.addi       s10, s9, #11
    v.add        v6, v1, v0
    v.splat      v0, s10
    s.addi       s10, s3, #12
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v8, [s8, v7]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v2, #32
    p.and        p5, p3, p4
    p.and        p3, p1, p2
    v.splat      v2, s10
    s.addi       s10, s5, #768
    v.st.w       [s12, #0], v8
    s.addi       s12, s9, #12
    v.add        v7, v1, v2
    v.splat      v2, s12
    s.addi       s12, s3, #13
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.h v8, [s8, v4]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v3, #32
    p.and        p6, p3, p4
    p.and        p3, p1, p2
    v.splat      v3, s12
    s.addi       s12, s5, #832
    v.st.w       [s7, #0], v8
    s.addi       s7, s9, #13
    v.add        v4, v1, v3
    v.splat      v3, s7
    s.addi       s7, s3, #14
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v8, [s8, v9]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v0, #32
    p.and        p5, p3, p4
    p.and        p3, p1, p2
    v.splat      v0, s7
    s.addi       s7, s5, #896
    v.st.w       [s14, #0], v8
    s.addi       s14, s9, #14
    v.add        v8, v1, v0
    v.splat      v0, s14
    s.addi       s14, s3, #15
    s.addi       s3, s5, #960
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.h v9, [s8, v5]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v2, #32
    p.and        p6, p3, p4
    p.and        p3, p1, p2
    v.splat      v2, s14
    v.st.w       [s13, #0], v9
    s.addi       s5, s9, #15
    v.add        v5, v1, v2
    v.splat      v1, s5
    .li       s5, #1065353216
    v.splat      v2, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v9, [s8, v6]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v3, #32
    p.and        p5, p3, p4
    p.and        p3, p1, p2
    .li       s5, #1065353216
    v.splat      v3, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s11, #0], v9
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s5, s6, #0
    s.muli       s11, s1, #4                     // a runtime tile origin, x4
    s.muli       s1, s2, #256                    // a runtime tile origin, x256
    v.movi       v6, #0
    v.movi       v9, #0
    s.add        s2, s4, s11                     // the tile origin
    s.add        s4, s2, s1                      // the tile origin
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p6 v.ld.gather.h v10, [s8, v7]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v0, #32
    p.and        p6, p3, p4
    p.and        p3, p1, p2
    .li       s1, #1069066811
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s10, #0], v10
    .li       s1, #1060205080
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.h v10, [s8, v4]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v1, #32
    p.and        p5, p3, p4
    .li       s1, #1065353216
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s12, #0], v10
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.h v4, [s8, v8]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v4
    v.splat      v4, s9
    s.addi       s1, s6, #64
    v.cmpi.lt    p3, v4, #32
    p.and        p4, p2, p3
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v4, [s8, v5]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v4
    fence.acq_rel.device
    v.ld.w       v4, [s5, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s2, s9, #1
    vf.add       v5, v4, v2
    v.splat      v4, s2
    s.addi       s2, s4, #256                    // row 1
    v.rcp.approx v8, v5                          // ISA 8.8: <= 2**-22 relative
    v.cmpi.lt    p3, v4, #32
    p.and        p5, p2, p3
    vf.fms       v4, v5, v8, v1
    vf.fms       v10, v8, v4, v8
    s.addi       s3, s6, #128
    vf.neg       v4, v10                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v4, v4
    @p3 v.sel        v10, v4, v8
    vf.mul       v4, v3, v10                     // a/y: faithful quotient
    vf.fms       v8, v4, v5, v3
    vf.fms       v5, v8, v10, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p4 v.st.w       [s4, #0], v5
    v.ld.w       v4, [s1, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s1, s4, #512                    // row 2
    vf.add       v5, v4, v2
    s.addi       s5, s9, #2
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s5
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s5, s6, #192
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p5 v.st.w       [s2, #0], v5
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s2, s4, #768                    // row 3
    vf.add       v5, v4, v2
    s.addi       s3, s9, #3
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s3, s6, #256
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p4 v.st.w       [s1, #0], v5
    v.ld.w       v4, [s5, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s1, s4, #1024                   // row 4
    vf.add       v5, v4, v2
    s.addi       s5, s9, #4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s5
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s5, s6, #320
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p5 v.st.w       [s2, #0], v5
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s2, s4, #1280                   // row 5
    vf.add       v5, v4, v2
    s.addi       s3, s9, #5
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s3, s6, #384
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p4 v.st.w       [s1, #0], v5
    v.ld.w       v4, [s5, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s1, s4, #1536                   // row 6
    vf.add       v5, v4, v2
    s.addi       s5, s9, #6
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s5
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s5, s6, #448
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p5 v.st.w       [s2, #0], v5
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s2, s4, #1792                   // row 7
    vf.add       v5, v4, v2
    s.addi       s3, s9, #7
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s3, s6, #512
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p4 v.st.w       [s1, #0], v5
    v.ld.w       v4, [s5, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s1, s4, #2048                   // row 8
    vf.add       v5, v4, v2
    s.addi       s5, s9, #8
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s5
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s5, s6, #576
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p5 v.st.w       [s2, #0], v5
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s2, s4, #2304                   // row 9
    vf.add       v5, v4, v2
    s.addi       s3, s9, #9
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s3, s6, #640
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p4 v.st.w       [s1, #0], v5
    v.ld.w       v4, [s5, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s1, s4, #2560                   // row 10
    vf.add       v5, v4, v2
    s.addi       s5, s9, #10
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s5
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s5, s6, #704
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p5 v.st.w       [s2, #0], v5
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s2, s4, #2816                   // row 11
    vf.add       v5, v4, v2
    s.addi       s3, s9, #11
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s3, s6, #768
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p4 v.st.w       [s1, #0], v5
    v.ld.w       v4, [s5, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s1, s4, #3072                   // row 12
    vf.add       v5, v4, v2
    s.addi       s5, s9, #12
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s5
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s5, s6, #832
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p5 v.st.w       [s2, #0], v5
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s2, s4, #3328                   // row 13
    vf.add       v5, v4, v2
    s.addi       s3, s9, #13
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s3, s6, #896
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p4 v.st.w       [s1, #0], v5
    v.ld.w       v4, [s5, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s1, s4, #3584                   // row 14
    vf.add       v5, v4, v2
    s.addi       s5, s9, #14
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s5
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s5, s6, #960
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p5 v.st.w       [s2, #0], v5
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v7
    vf.fma       v5, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v5, v5
    @p3 v.sel        v4, v5, v8
    s.addi       s2, s4, #3840                   // row 15
    vf.add       v5, v4, v2
    s.addi       s3, s9, #15
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v5, v4, v1
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v8, v10, v4
    vf.mul       v4, v3, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v5, v3
    vf.fms       v5, v10, v8, v4
    vf.neg       v8, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v5, v8, v4
    @p1 v.sel        v4, v5, v6
    @p1 v.sel        v5, v4, v9
    @p4 v.st.w       [s1, #0], v5
    v.ld.w       v4, [s5, #0]
    vf.cvt.bf16.f32 v5, v4
    vf.neg       v4, v5
    vf.mul       v5, v4, v0
    v.exp2.approx v8, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v0, v5                 // the exact rounding error of x*log2(e)
    vf.mul       v0, v10, v7
    vf.fma       v4, v8, v0, v8                  // 2**t * 2**d
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v0, v4, v8
    vf.add       v4, v0, v2
    v.rcp.approx v0, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v2, v4, v0, v1
    vf.fms       v1, v0, v2, v0
    vf.neg       v2, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v1, v2, v0
    vf.mul       v0, v3, v1                      // a/y: faithful quotient
    vf.fms       v2, v0, v4, v3
    vf.fms       v3, v2, v1, v0
    vf.neg       v1, v3                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v2, v1, v0
    @p1 v.sel        v0, v2, v6
    @p1 v.sel        v1, v0, v9
    @p5 v.st.w       [s2, #0], v1
__rctx_next:
    exit
