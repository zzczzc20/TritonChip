    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #56
    v.movi       v2, #0
    s.rdspecial  s3, arg_base
    v.sub        v3, v2, v1
    v.splat      v4, s2
    v.cmp.lt     p1, v1, v2
    v.add        v5, v4, v0
    s.ld.d       s2, [s3, #0]                    // arg_X: device_ptr64 at arg_base+0
    v.sub        v4, v2, v5
    v.cmp.lt     p2, v5, v2
    s.ld.d       s4, [s3, #8]                    // arg_W: device_ptr64 at arg_base+8
    v.movi       v6, #1
    @p2 v.sel        v7, v4, v5
    s.ld.d       s5, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    @p1 v.sel        v4, v3, v1
    v.movi       v3, #0
    v.movi       v8, #0
    s.movz       s3, #31
idiv_1:
    v.splat      v9, s3
    v.shl        v10, v8, v6
    v.lshr       v11, v7, v9
    v.cmp.lt     p1, v8, v2
    v.and        v12, v11, v6
    v.shl        v11, v6, v9
    v.or         v9, v10, v12
    s.subi       s6, s3, #1
    v.cmp.geu    p3, v9, v4
    p.or         p4, p1, p3
    v.sub        v10, v9, v4
    @p4 v.sel        v12, v11, v2
    @p4 v.sel        v11, v10, v9
    v.or         v9, v3, v12
    v.mov        v8, v11
    v.mov        v3, v9
    s.mov        s3, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s3, s6
    br.nz        s7, idiv_1
    v.movi       v3, #0
    v.sub        v4, v2, v8
    v.sub        v2, v3, v5
    v.sub        v6, v3, v1
    v.cmp.lt     p1, v5, v3
    v.cmp.lt     p3, v1, v3
    @p2 v.sel        v7, v4, v8
    v.movi       v4, #1
    @p1 v.sel        v8, v2, v5
    @p3 v.sel        v2, v6, v1
    v.movi       v5, #0
    v.movi       v6, #0
    s.movz       s3, #31
idiv_2:
    v.splat      v9, s3
    v.shl        v10, v6, v4
    v.lshr       v11, v8, v9
    v.cmp.lt     p2, v6, v3
    v.and        v12, v11, v4
    v.shl        v11, v4, v9
    v.or         v9, v10, v12
    s.subi       s6, s3, #1
    v.cmp.geu    p4, v9, v2
    p.or         p5, p2, p4
    v.sub        v10, v9, v2
    @p5 v.sel        v12, v11, v3
    @p5 v.sel        v11, v10, v9
    v.or         v9, v5, v12
    v.mov        v6, v11
    v.mov        v5, v9
    s.mov        s3, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s3, s6
    br.nz        s7, idiv_2
    p.xor        p2, p1, p3
    v.sub        v2, v3, v5
    v.movi       v3, #0
    @p2 v.sel        v4, v2, v5
    v.sub        v2, v3, v1
    v.sub        v5, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.movi       v6, #1
    @p1 v.sel        v8, v5, v4
    @p2 v.sel        v5, v2, v1
    v.movi       v2, #0
    v.movi       v9, #0
    s.movz       s3, #31
idiv_3:
    v.splat      v10, s3
    v.shl        v11, v9, v6
    v.lshr       v12, v8, v10
    v.cmp.lt     p2, v9, v3
    v.and        v13, v12, v6
    v.shl        v12, v6, v10
    v.or         v10, v11, v13
    s.subi       s6, s3, #1
    v.cmp.geu    p3, v10, v5
    p.or         p4, p2, p3
    v.sub        v11, v10, v5
    @p4 v.sel        v13, v12, v3
    @p4 v.sel        v12, v11, v10
    v.or         v10, v2, v13
    v.mov        v9, v12
    v.mov        v2, v10
    s.mov        s3, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s3, s6
    br.nz        s7, idiv_3
    v.movi       v2, #0
    v.sub        v5, v3, v9
    v.sub        v3, v2, v4
    v.sub        v6, v2, v1
    v.cmp.lt     p2, v4, v2
    v.cmp.lt     p3, v1, v2
    @p1 v.sel        v8, v5, v9
    v.movi       v5, #1
    @p2 v.sel        v9, v3, v4
    @p3 v.sel        v3, v6, v1
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s3, #31
idiv_4:
    v.splat      v10, s3
    v.shl        v11, v6, v5
    v.lshr       v12, v9, v10
    v.cmp.lt     p1, v6, v2
    v.and        v13, v12, v5
    v.shl        v12, v5, v10
    v.or         v10, v11, v13
    s.subi       s6, s3, #1
    v.cmp.geu    p4, v10, v3
    p.or         p5, p1, p4
    v.sub        v11, v10, v3
    @p5 v.sel        v13, v12, v2
    @p5 v.sel        v12, v11, v10
    v.or         v10, v4, v13
    v.mov        v6, v12
    v.mov        v4, v10
    s.mov        s3, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s3, s6
    br.nz        s7, idiv_4
    s.rdspecial  s3, pid.y
    s.rdspecial  s6, role_id
    s.mul        s7, s3, s1
    s.movz       s3, #4160
    p.xor        p1, p2, p3
    v.sub        v3, v2, v4
    s.rdspecial  s8, arg_base
    s.mul        s9, s6, s3
    @p1 v.sel        v2, v3, v4
    .li       s3, #200704
    v.splat      v3, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.ld.d       s3, [s8, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v4, s7
    v.mul        v5, v2, v3
    v.add        v3, v4, v0
    s.add        s6, s3, s9                      // this context's own scratch
    s.movz       s3, #0
    v.extract    s8, v5, #0
    v.extract    s9, v5, #1
    v.extract    s10, v5, #2
    v.extract    s11, v5, #3
    v.extract    s12, v5, #4
    v.extract    s13, v5, #5
    v.extract    s14, v5, #6
    v.extract    s15, v5, #7
    v.splat      v4, s3
    v.splat      v6, s8
    s.addi       s8, s6, #0
    v.splat      v9, s9
    v.splat      v10, s10
    v.splat      v11, s11
    v.splat      v12, s12
    v.add        v13, v4, v6
    s.addi       s9, s8, #64
    v.add        v6, v4, v9
    s.addi       s10, s8, #128
    v.add        v9, v4, v10
    s.addi       s11, s8, #192
    v.add        v10, v4, v11
    s.addi       s12, s8, #256
    v.add        v11, v4, v12
    v.st.w       [s8, #0], v13
    v.splat      v12, s13
    s.addi       s13, s8, #320
    v.add        v13, v4, v12
    v.st.w       [s9, #0], v6
    v.splat      v6, s14
    s.addi       s9, s8, #384
    v.add        v12, v4, v6
    s.addi       s14, s8, #448
    v.st.w       [s10, #0], v9
    .li       s10, #200704
    v.splat      v6, s15
    v.extract    s15, v5, #8
    v.add        v9, v4, v6
    v.st.w       [s11, #0], v10
    v.extract    s11, v5, #9
    v.splat      v6, s15
    v.extract    s15, v5, #10
    v.add        v10, v4, v6
    v.st.w       [s12, #0], v11
    v.extract    s12, v5, #11
    v.splat      v6, s11
    v.extract    s11, v5, #12
    v.add        v11, v4, v6
    v.st.w       [s13, #0], v13
    v.extract    s13, v5, #13
    v.splat      v6, s15
    v.extract    s15, v5, #14
    v.add        v13, v4, v6
    s.movz       s16, #576
    v.st.w       [s9, #0], v12
    v.movi       v6, #576
    v.extract    s9, v5, #15
    v.splat      v5, s12
    v.mul        v12, v3, v6
    s.addi       s12, s8, #512
    v.add        v6, v4, v5
    v.st.w       [s14, #0], v9
    v.splat      v5, s11
    s.addi       s11, s8, #576
    s.addi       s14, s8, #640
    v.add        v9, v4, v5
    v.st.w       [s12, #0], v10
    v.splat      v5, s13
    s.addi       s12, s8, #704
    s.addi       s13, s8, #768
    v.add        v10, v4, v5
    v.st.w       [s11, #0], v11
    v.splat      v5, s15
    s.addi       s11, s8, #832
    s.addi       s15, s8, #896
    v.add        v11, v4, v5
    s.addi       s16, s8, #960
    v.st.w       [s14, #0], v13
    v.splat      v5, s9
    s.addi       s8, s6, #1024
    v.add        v13, v4, v5
    v.splat      v4, s3
    s.movz       s9, #36
    v.add        v5, v4, v12
    v.st.w       [s12, #0], v6
    s.movz       s12, #1
    v.st.w       [s13, #0], v9
    s.addi       s13, s3, #0
    v.st.w       [s11, #0], v10
    v.st.w       [s15, #0], v11
    v.st.w       [s16, #0], v13
    fence.acq_rel.device
    v.st.w       [s8, #0], v5
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s8, s13, s9
    br.nz        s8, endfor_6
    s.movz       s8, #0
    s.movz       s11, #0
    s.cmp.lt     s14, s13, s8
    s.movz       s8, #4
    s.sub        s15, s11, s14
    s.movz       s11, #0
    s.movz       s14, #0
    s.cmp.lt     s16, s8, s11
    s.xor        s11, s13, s15
    s.sub        s17, s14, s16
    s.sub        s14, s11, s15
    s.xor        s11, s15, s17
    s.lshri      s15, s14, #2
    s.movz       s16, #0
    s.xor        s18, s15, s11
    s.movz       s19, #0
    s.sub        s20, s18, s11
    s.movz       s11, #0
    s.cmp.lt     s18, s20, s16
    s.movz       s16, #0
    s.sub        s21, s19, s18
    .li       s18, #1431655766
    s.xor        s19, s20, s21
    s.cmp.lt     s22, s13, s11
    s.sub        s11, s19, s21
    s.sub        s19, s16, s22
    s.mul        s16, s11, s18
    s.xor        s18, s13, s19
    s.movz       s22, #3
    s.sub        s23, s18, s19
    s.muli       s18, s15, #4
    s.lshri      s15, s16, #32
    s.sub        s16, s14, s18
    s.movz       s14, #0
    s.lshri      s16, s23, #2
    s.cmp.lt     s18, s22, s14
    s.muli       s14, s16, #4
    s.sub        s16, s23, s14
    s.movz       s14, #0
    s.xor        s23, s16, s19
    s.sub        s16, s14, s18
    s.sub        s14, s23, s19
    s.movz       s18, #0
    s.mul        s19, s14, s1
    s.movz       s14, #0
    s.sub        s23, s11, s15
    s.cmp.lt     s24, s8, s18
    s.lshri      s18, s23, #1
    s.sub        s23, s14, s24
    s.add        s14, s15, s18
    s.xor        s15, s8, s23
    s.lshri      s18, s14, #1
    s.xor        s14, s21, s16
    s.muli       s21, s18, #3
    s.xor        s24, s8, s17
    s.sub        s8, s15, s23
    s.movz       s8, #0
    s.movz       s15, #0
    s.cmp.lt     s23, s20, s8
    s.xor        s8, s18, s14
    s.sub        s18, s15, s23
    .li       s15, #1431655766
    s.xor        s23, s20, s18
    s.sub        s20, s8, s14
    s.sub        s8, s23, s18
    s.movz       s14, #0
    s.mul        s23, s8, s15
    s.cmp.lt     s15, s22, s14
    s.sub        s14, s24, s17
    s.sub        s14, s20, s12
    v.movi       v4, #3584
    s.lshri      s17, s23, #32
    v.splat      v5, s14
    s.sub        s14, s8, s17
    v.add        v6, v5, v8
    s.lshri      s23, s14, #1
    v.mul        v5, v6, v4
    s.add        s14, s17, s23
    v.splat      v4, s19
    s.lshri      s17, s14, #1
    v.add        v9, v0, v4
    s.muli       s14, s17, #3
    s.movz       s17, #0
    s.xor        s23, s22, s16
    s.sub        s24, s17, s15
    s.movz       s15, #64
    s.sub        s17, s8, s14
    s.xor        s8, s22, s24
    s.xor        s14, s17, s18
    s.sub        s17, s23, s16
    s.sub        s16, s14, s18
    s.addi       s14, s6, #0
    s.sub        s17, s16, s12
    v.movi       v4, #64
    v.splat      v10, s17
    v.ld.w       v11, [s14, #0]
    v.add        v12, v10, v7
    v.extract    s14, v5, #0
    v.mul        v10, v12, v4
    v.splat      v13, s14
    v.extract    s14, v10, #0
    v.splat      v14, s14
    s.addi       s14, s6, #1088
    s.sub        s17, s11, s21
    s.movz       s11, #0
    v.iota       v15                             // arange(0, VLEN)
    s.add        s17, s11, s19                   // the tile origin
    v.add        v16, v13, v14
    v.splat      v13, s17
    s.addi       s11, s6, #64
    v.add        v14, v15, v13
    v.extract    s17, v5, #1
    v.add        v13, v16, v14
    v.extract    s18, v10, #1
    v.add        v16, v11, v13
    v.splat      v11, s17
    v.st.w       [s14, #0], v16
    s.addi       s17, s14, #64
    s.sub        s21, s8, s24
    v.splat      v13, s18
    s.addi       s8, s6, #128
    v.add        v16, v11, v13
    v.extract    s18, v5, #2
    v.add        v11, v16, v14
    v.extract    s21, v10, #2
    v.splat      v13, s18
    v.ld.w       v16, [s11, #0]
    v.splat      v17, s21
    s.addi       s11, s14, #128
    v.add        v18, v13, v17
    s.addi       s18, s6, #192
    v.add        v13, v18, v14
    v.extract    s21, v5, #3
    s.addi       s22, s14, #192
    s.movz       s23, #3584
    v.extract    s23, v10, #3
    v.add        v17, v16, v11
    v.splat      v11, s21
    v.st.w       [s17, #0], v17
    v.splat      v16, s23
    s.addi       s17, s6, #256
    v.add        v17, v11, v16
    v.extract    s21, v5, #4
    v.add        v11, v17, v14
    v.extract    s23, v10, #4
    v.splat      v16, s21
    v.splat      v17, s23
    s.addi       s21, s14, #256
    v.ld.w       v18, [s8, #0]
    v.add        v19, v16, v17
    s.addi       s8, s6, #320
    v.add        v16, v19, v14
    v.extract    s23, v5, #5
    v.splat      v17, s23
    v.extract    s23, v10, #5
    v.splat      v19, s23
    s.addi       s23, s14, #320
    v.add        v20, v17, v19
    v.add        v17, v18, v13
    v.add        v13, v20, v14
    v.st.w       [s11, #0], v17
    s.addi       s11, s6, #384
    v.ld.w       v17, [s18, #0]
    v.extract    s18, v5, #6
    v.splat      v18, s18
    v.extract    s18, v10, #6
    v.splat      v19, s18
    s.addi       s18, s14, #384
    v.add        v20, v18, v19
    v.add        v18, v20, v14
    v.add        v19, v17, v11
    v.st.w       [s22, #0], v19
    s.addi       s22, s6, #448
    v.ld.w       v11, [s17, #0]
    v.extract    s17, v5, #7
    v.splat      v17, s17
    v.extract    s17, v10, #7
    v.splat      v19, s17
    s.addi       s17, s14, #448
    v.add        v20, v17, v19
    v.add        v17, v20, v14
    v.add        v19, v11, v16
    v.st.w       [s21, #0], v19
    s.addi       s21, s6, #512
    v.ld.w       v11, [s8, #0]
    v.extract    s8, v5, #8
    v.splat      v16, s8
    v.extract    s8, v10, #8
    v.splat      v19, s8
    s.addi       s8, s14, #512
    v.add        v20, v16, v19
    v.add        v16, v20, v14
    v.add        v19, v11, v13
    v.st.w       [s23, #0], v19
    s.addi       s23, s6, #576
    v.ld.w       v11, [s11, #0]
    v.extract    s11, v5, #9
    v.splat      v13, s11
    v.extract    s11, v10, #9
    v.splat      v19, s11
    s.addi       s11, s14, #576
    v.add        v20, v13, v19
    v.add        v13, v20, v14
    v.add        v19, v11, v18
    v.st.w       [s18, #0], v19
    s.addi       s18, s6, #640
    v.ld.w       v11, [s22, #0]
    v.extract    s22, v5, #10
    v.splat      v18, s22
    v.extract    s22, v10, #10
    v.splat      v19, s22
    s.addi       s22, s14, #640
    v.add        v20, v18, v19
    v.add        v18, v20, v14
    v.add        v19, v11, v17
    v.st.w       [s17, #0], v19
    s.addi       s17, s6, #704
    v.ld.w       v11, [s21, #0]
    v.extract    s21, v5, #11
    v.splat      v17, s21
    v.extract    s21, v10, #11
    v.splat      v19, s21
    s.addi       s21, s14, #704
    v.add        v20, v17, v19
    v.add        v17, v20, v14
    v.add        v19, v11, v16
    v.st.w       [s8, #0], v19
    s.addi       s8, s6, #768
    v.ld.w       v11, [s23, #0]
    v.extract    s23, v5, #12
    v.splat      v16, s23
    v.extract    s23, v10, #12
    v.splat      v19, s23
    s.addi       s23, s14, #768
    v.add        v20, v16, v19
    v.add        v16, v20, v14
    v.add        v19, v11, v13
    v.st.w       [s11, #0], v19
    s.addi       s11, s6, #832
    v.ld.w       v11, [s18, #0]
    v.extract    s18, v5, #13
    v.splat      v13, s18
    v.extract    s18, v10, #13
    v.splat      v19, s18
    s.addi       s18, s14, #832
    v.add        v20, v13, v19
    v.add        v13, v20, v14
    v.add        v19, v11, v18
    v.st.w       [s22, #0], v19
    s.addi       s22, s6, #896
    v.ld.w       v11, [s17, #0]
    v.extract    s17, v5, #14
    v.splat      v18, s17
    v.extract    s17, v10, #14
    v.splat      v19, s17
    s.addi       s17, s14, #896
    v.add        v20, v18, v19
    v.movi       v18, #8
    v.add        v19, v20, v14
    s.addi       s24, s14, #960
    v.add        v20, v11, v17
    v.cmp.lt     p1, v2, v18
    v.st.w       [s21, #0], v20
    s.addi       s14, s6, #960
    v.movi       v11, #1
    v.movi       v17, #0
    @p1 v.sel        v18, v11, v17
    v.ld.w       v11, [s8, #0]
    v.extract    s8, v5, #15
    v.movi       v5, #0
    v.splat      v17, s8
    v.extract    s8, v10, #15
    v.splat      v10, s8
    v.movi       v20, #1
    v.cmp.ge     p1, v6, v5
    v.add        v21, v17, v10
    v.movi       v10, #0
    v.add        v17, v11, v16
    @p1 v.sel        v11, v20, v10
    v.st.w       [s23, #0], v17
    v.movi       v10, #1
    v.movi       v16, #0
    v.cmp.lt     p1, v6, v1
    v.add        v6, v21, v14
    @p1 v.sel        v14, v10, v16
    v.movi       v10, #1
    v.cmp.ge     p1, v12, v5
    v.ld.w       v5, [s11, #0]
    v.movi       v16, #0
    v.movi       v17, #1
    @p1 v.sel        v20, v10, v16
    v.movi       v10, #0
    v.cmp.lt     p1, v12, v1
    @p1 v.sel        v12, v17, v10
    v.cmp.lt     p1, v9, v4
    v.add        v4, v5, v13
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s8, #0
    v.st.w       [s18, #0], v4
    v.extract    s11, v18, #0
    s.addi       s18, s6, #1088
    v.ld.w       v4, [s22, #0]
    v.extract    s21, v11, #0
    v.splat      v5, s11
    v.movi       v9, #0
    v.splat      v10, s21
    v.movi       v13, #0
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p3, v10, v13
    v.add        v5, v4, v19
    p.and        p4, p2, p3
    v.st.w       [s17, #0], v5
    v.extract    s11, v14, #0
    v.splat      v4, s11
    v.movi       v5, #0
    v.ld.w       v9, [s14, #0]
    v.extract    s11, v20, #0
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s11
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v4, v5
    p.and        p4, p3, p2
    v.add        v4, v9, v6
    v.extract    s11, v12, #0
    v.st.w       [s24, #0], v4
    fence.acq_rel.device
    v.splat      v4, s11
    v.movi       v5, #0
    v.extract    s11, v18, #1
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s14, v11, #1
    p.and        p2, p3, p1
    v.splat      v4, s11
    v.ld.w       v5, [s18, #0]
    v.movi       v6, #0
    v.splat      v9, s14
    v.movi       v10, #0
    s.addi       s11, s6, #1152
    v.extract    s14, v14, #1
    v.cmp.ne     p3, v4, v6
    v.cmp.ne     p4, v9, v10
    v.splat      v4, s14
    v.movi       v6, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s2, v5]               // index is in elements (ISA sec 9.1)
    p.and        p2, p3, p4
    v.extract    s14, v20, #1
    v.cmp.ne     p3, v4, v6
    v.splat      v4, s14
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s14, v12, #1
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s14
    a.vwrite     a1, s8, v9
    v.ld.w       v5, [s11, #0]
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v4, v6
    p.and        p4, p3, p2
    v.extract    s8, v18, #2
    p.and        p2, p4, p1
    v.extract    s11, v11, #2
    v.splat      v4, s8
    v.movi       v6, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s11
    v.movi       v10, #0
    s.movz       s8, #1
    s.addi       s11, s6, #1216
    v.extract    s14, v14, #2
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v5, v10
    v.splat      v4, s14
    v.movi       v5, #0
    a.vwrite     a1, s8, v9
    v.ld.w       v6, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #2
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s8
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #2
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s8
    v.movi       v5, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v5
    p.and        p3, p4, p2
    v.extract    s8, v18, #3
    p.and        p2, p3, p1
    v.extract    s11, v11, #3
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v6]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #2
    s.addi       s11, s6, #1280
    v.extract    s14, v14, #3
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v4
    v.ld.w       v4, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #3
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #3
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s8, v18, #4
    p.and        p2, p3, p1
    v.extract    s11, v11, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #3
    s.addi       s11, s6, #1344
    v.extract    s14, v14, #4
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v5
    v.ld.w       v5, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #4
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #4
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s8, v18, #5
    p.and        p2, p3, p1
    v.extract    s11, v11, #5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #4
    s.addi       s11, s6, #1408
    v.extract    s14, v14, #5
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v4
    v.ld.w       v4, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #5
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #5
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s8, v18, #6
    p.and        p2, p3, p1
    v.extract    s11, v11, #6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #5
    s.addi       s11, s6, #1472
    v.extract    s14, v14, #6
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v5
    v.ld.w       v5, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #6
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #6
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s8, v18, #7
    p.and        p2, p3, p1
    v.extract    s11, v11, #7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #6
    s.addi       s11, s6, #1536
    v.extract    s14, v14, #7
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v4
    v.ld.w       v4, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #7
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #7
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s8, v18, #8
    p.and        p2, p3, p1
    v.extract    s11, v11, #8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #7
    s.addi       s11, s6, #1600
    v.extract    s14, v14, #8
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v5
    v.ld.w       v5, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #8
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #8
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s8, v18, #9
    p.and        p2, p3, p1
    v.extract    s11, v11, #9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #8
    s.addi       s11, s6, #1664
    v.extract    s14, v14, #9
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v4
    v.ld.w       v4, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #9
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #9
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s8, v18, #10
    p.and        p2, p3, p1
    v.extract    s11, v11, #10
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #9
    s.addi       s11, s6, #1728
    v.extract    s14, v14, #10
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v5
    v.ld.w       v5, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #10
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #10
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s8, v18, #11
    p.and        p2, p3, p1
    v.extract    s11, v11, #11
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #10
    s.addi       s11, s6, #1792
    v.extract    s14, v14, #11
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v4
    v.ld.w       v4, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #11
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #11
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s8, v18, #12
    p.and        p2, p3, p1
    v.extract    s11, v11, #12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #11
    s.addi       s11, s6, #1856
    v.extract    s14, v14, #12
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v5
    v.ld.w       v5, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #12
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #12
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s8, v18, #13
    p.and        p2, p3, p1
    v.extract    s11, v11, #13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #12
    s.addi       s11, s6, #1920
    v.extract    s14, v14, #13
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v4
    v.ld.w       v4, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #13
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #13
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s8, v18, #14
    p.and        p2, p3, p1
    v.extract    s11, v11, #14
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    v.splat      v4, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #13
    s.addi       s11, s6, #1984
    v.extract    s14, v14, #14
    v.cmp.ne     p2, v4, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v4, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v5
    v.ld.w       v5, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #14
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #14
    v.cmp.ne     p2, v4, v6
    v.splat      v4, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.extract    s8, v18, #15
    p.and        p2, p3, p1
    v.extract    s11, v11, #15
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.splat      v5, s8
    v.movi       v6, #0
    v.splat      v9, s11
    v.movi       v10, #0
    s.movz       s8, #14
    s.addi       s11, s6, #2048
    v.extract    s14, v14, #15
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v9, v10
    v.splat      v5, s14
    v.movi       v6, #0
    a.vwrite     a1, s8, v4
    v.ld.w       v4, [s11, #0]
    p.and        p4, p2, p3
    v.extract    s8, v20, #15
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s8, v12, #15
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s8
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    s.movz       s8, #192
    p.and        p2, p3, p1
    s.movz       s11, #15
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v4]               // index is in elements (ISA sec 9.1)
    s.addi       s14, s6, #1024
    s.mul        s17, s20, s8
    s.movz       s8, #0
    s.mul        s18, s16, s15
    s.add        s16, s8, s19                    // the tile origin
    s.addi       s8, s6, #2112
    s.add        s20, s16, s17                   // the tile origin
    s.addi       s16, s6, #1024
    s.add        s17, s20, s18                   // the tile origin
    a.vwrite     a1, s11, v5
    v.ld.w       v4, [s14, #0]
    v.splat      v5, s17
    s.addi       s11, s17, #1
    s.addi       s14, s8, #64
    v.splat      v6, s11
    s.addi       s11, s6, #1024
    s.addi       s18, s17, #2
    s.addi       s20, s8, #128
    v.splat      v9, s18
    s.addi       s18, s6, #1024
    v.add        v10, v4, v5
    s.addi       s21, s17, #3
    v.st.w       [s8, #0], v10
    v.splat      v4, s21
    s.addi       s21, s8, #192
    s.addi       s22, s6, #1024
    s.addi       s23, s17, #4
    s.addi       s24, s8, #256
    v.splat      v5, s23
    s.addi       s23, s6, #1024
    v.ld.w       v10, [s16, #0]
    s.addi       s16, s17, #5
    v.splat      v11, s16
    s.addi       s16, s8, #320
    v.add        v12, v10, v6
    v.st.w       [s14, #0], v12
    s.addi       s14, s6, #1024
    v.ld.w       v6, [s11, #0]
    s.addi       s11, s17, #6
    v.splat      v10, s11
    s.addi       s11, s8, #384
    v.add        v12, v6, v9
    v.st.w       [s20, #0], v12
    s.addi       s20, s6, #1024
    v.ld.w       v6, [s18, #0]
    s.addi       s18, s17, #7
    v.splat      v9, s18
    s.addi       s18, s8, #448
    v.add        v12, v6, v4
    v.st.w       [s21, #0], v12
    s.addi       s21, s6, #1024
    v.ld.w       v4, [s22, #0]
    s.addi       s22, s17, #8
    v.splat      v6, s22
    s.addi       s22, s8, #512
    v.add        v12, v4, v5
    v.st.w       [s24, #0], v12
    s.addi       s24, s6, #1024
    v.ld.w       v4, [s23, #0]
    s.addi       s23, s17, #9
    v.splat      v5, s23
    s.addi       s23, s8, #576
    v.add        v12, v4, v11
    v.st.w       [s16, #0], v12
    s.addi       s16, s6, #1024
    v.ld.w       v4, [s14, #0]
    s.addi       s14, s17, #10
    v.splat      v11, s14
    s.addi       s14, s8, #640
    v.add        v12, v4, v10
    v.st.w       [s11, #0], v12
    s.addi       s11, s6, #1024
    v.ld.w       v4, [s20, #0]
    s.addi       s20, s17, #11
    v.splat      v10, s20
    s.addi       s20, s8, #704
    v.add        v12, v4, v9
    v.st.w       [s18, #0], v12
    s.addi       s18, s6, #1024
    v.ld.w       v4, [s21, #0]
    s.addi       s21, s17, #12
    v.splat      v9, s21
    s.addi       s21, s8, #768
    v.add        v12, v4, v6
    v.st.w       [s22, #0], v12
    s.addi       s22, s6, #1024
    v.ld.w       v4, [s24, #0]
    s.addi       s24, s17, #13
    v.splat      v6, s24
    s.addi       s24, s8, #832
    v.add        v12, v4, v5
    v.st.w       [s23, #0], v12
    s.addi       s23, s6, #1024
    v.splat      v4, s15
    v.ld.w       v5, [s16, #0]
    s.addi       s16, s17, #14
    s.addi       s25, s17, #15
    v.splat      v12, s16
    s.addi       s16, s8, #896
    v.splat      v13, s25
    s.addi       s17, s6, #1024
    s.addi       s25, s8, #960
    v.add        v14, v5, v11
    v.st.w       [s14, #0], v14
    s.addi       s8, s6, #2112
    v.splat      v5, s15
    s.movz       s14, #0
    s.add        s15, s14, s7                    // the tile origin
    v.splat      v11, s15
    s.movz       s14, #0
    v.add        v14, v15, v11
    v.ld.w       v11, [s11, #0]
    s.add        s11, s14, s19                   // the tile origin
    v.cmp.lt     p1, v14, v5
    v.splat      v5, s11
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s14, #0
    v.cmp.lt     p2, v5, v4
    p.and        p3, p2, p1
    v.add        v5, v11, v10
    s.movz       s15, #1
    v.st.w       [s20, #0], v5
    s.addi       s19, s6, #2176
    v.ld.w       v5, [s18, #0]
    s.addi       s18, s11, #1
    v.splat      v10, s18
    v.cmp.lt     p2, v10, v4
    p.and        p4, p2, p1
    v.add        v10, v5, v9
    v.st.w       [s21, #0], v10
    s.addi       s18, s6, #2240
    s.movz       s20, #2
    v.ld.w       v5, [s22, #0]
    s.addi       s21, s11, #2
    v.splat      v9, s21
    v.add        v10, v5, v6
    v.cmp.lt     p2, v9, v4
    v.st.w       [s24, #0], v10
    p.and        p5, p2, p1
    v.ld.w       v5, [s23, #0]
    s.addi       s21, s6, #2304
    s.movz       s22, #3
    v.add        v6, v5, v12
    s.addi       s23, s11, #3
    v.st.w       [s16, #0], v6
    v.splat      v5, s23
    v.ld.w       v6, [s17, #0]
    s.movz       s16, #4
    v.add        v9, v6, v13
    s.addi       s17, s6, #2368
    v.st.w       [s25, #0], v9
    fence.acq_rel.device
    s.addi       s23, s11, #4
    v.splat      v6, s23
    v.ld.w       v9, [s8, #0]
    s.addi       s8, s6, #2432
    s.addi       s23, s11, #5
    s.movz       s24, #5
    v.splat      v10, s23
    s.movz       s23, #6
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s4, v9]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s14, v11
    v.ld.w       v5, [s19, #0]
    s.addi       s14, s6, #2496
    s.addi       s19, s11, #6
    v.splat      v9, s19
    s.movz       s19, #7
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v4
    p.and        p4, p2, p1
    a.vwrite     a2, s15, v11
    v.ld.w       v5, [s18, #0]
    s.addi       s15, s6, #2560
    s.addi       s18, s11, #7
    v.splat      v6, s18
    s.movz       s18, #8
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v4
    p.and        p5, p2, p1
    a.vwrite     a2, s20, v11
    v.ld.w       v5, [s21, #0]
    s.addi       s20, s6, #2624
    s.addi       s21, s11, #8
    v.splat      v10, s21
    s.movz       s21, #9
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v9, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s22, v11
    v.ld.w       v5, [s17, #0]
    s.addi       s17, s6, #2688
    s.addi       s22, s11, #9
    v.splat      v9, s22
    s.movz       s22, #10
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v4
    p.and        p4, p2, p1
    a.vwrite     a2, s16, v11
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s6, #2752
    s.addi       s16, s11, #10
    v.splat      v6, s16
    s.movz       s16, #11
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v4
    p.and        p5, p2, p1
    a.vwrite     a2, s24, v11
    v.ld.w       v5, [s14, #0]
    s.addi       s14, s6, #2816
    s.addi       s24, s11, #11
    v.splat      v10, s24
    s.movz       s24, #12
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v9, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s23, v11
    v.ld.w       v5, [s15, #0]
    s.addi       s15, s6, #2880
    s.addi       s23, s11, #12
    v.splat      v9, s23
    s.movz       s23, #13
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v4
    p.and        p4, p2, p1
    a.vwrite     a2, s19, v11
    v.ld.w       v5, [s20, #0]
    s.addi       s19, s6, #2944
    s.addi       s20, s11, #13
    v.splat      v6, s20
    s.movz       s20, #14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v4
    p.and        p5, p2, p1
    a.vwrite     a2, s18, v11
    v.ld.w       v5, [s17, #0]
    s.addi       s17, s6, #3008
    s.addi       s18, s11, #14
    v.splat      v10, s18
    s.movz       s18, #15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v9, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s21, v11
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s6, #3072
    s.addi       s21, s11, #15
    v.movi       v9, #0
    v.splat      v11, s21
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v12, [s4, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v4
    p.and        p4, p2, p1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s11, #0
    a.vwrite     a2, s22, v12
    v.ld.w       v5, [s14, #0]
    s.movz       s14, #0
    s.movz       s21, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v6, [s4, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v4
    p.and        p5, p2, p1
    a.vwrite     a2, s16, v6
    v.ld.w       v5, [s15, #0]
    s.movz       s15, #1
    s.movz       s16, #2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s4, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v11, v4
    p.and        p3, p2, p1
    a.vwrite     a2, s24, v6
    v.ld.w       v4, [s19, #0]
    s.movz       s19, #3
    s.movz       s22, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v5, [s4, v4]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s23, v5
    v.ld.w       v4, [s17, #0]
    s.movz       s17, #5
    s.movz       s23, #6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v5, [s4, v4]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s20, v5
    v.ld.w       v4, [s8, #0]
    s.movz       s8, #7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v5, [s4, v4]               // index is in elements (ISA sec 9.1)
    s.movz       s20, #8
    a.vwrite     a2, s18, v5
    a.vread      v4, a1, s14
    a.vread      v5, a2, s21
    v.extract    s14, v4, #0
    v.splat      v6, s14
    v.extract    s14, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s14
    a.vread      v6, a2, s15
    v.extract    s14, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s14
    a.vread      v6, a2, s16
    v.extract    s14, v4, #3
    vf.fma       v10, v5, v6, v11
    v.splat      v5, s14
    a.vread      v6, a2, s19
    v.extract    s14, v4, #4
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s14
    a.vread      v6, a2, s22
    v.extract    s14, v4, #5
    vf.fma       v10, v5, v6, v11
    v.splat      v5, s14
    a.vread      v6, a2, s17
    v.extract    s14, v4, #6
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s14
    a.vread      v6, a2, s23
    v.extract    s14, v4, #7
    vf.fma       v10, v5, v6, v11
    v.splat      v5, s14
    a.vread      v6, a2, s8
    v.extract    s8, v4, #8
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s20
    s.movz       s8, #9
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s8
    s.movz       s8, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s8
    s.movz       s8, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s8
    s.movz       s8, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s8
    s.movz       s8, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s8
    s.movz       s8, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s8
    s.movz       s8, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s8
    s.movz       s8, #1
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s11, v6
    a.vread      v4, a1, s8
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #1
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #2
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #2
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #3
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #4
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #5
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #6
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #7
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #8
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #9
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #9
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #10
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #11
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #11
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #12
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #13
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #13
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v11, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v11
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v11, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #14
    vf.fma       v10, v5, v6, v11
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v11, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v11
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #15
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s8, v6
    a.vread      v4, a1, s11
    a.vread      v5, a2, s14
    v.extract    s8, v4, #0
    v.splat      v6, s8
    v.extract    s8, v4, #1
    vf.fma       v10, v6, v5, v9
    v.splat      v5, s8
    a.vread      v6, a2, s15
    v.extract    s8, v4, #2
    vf.fma       v9, v5, v6, v10
    v.splat      v5, s8
    a.vread      v6, a2, s16
    s.movz       s8, #3
    vf.fma       v10, v5, v6, v9
    v.extract    s11, v4, #3
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #4
    vf.fma       v9, v5, v6, v10
    v.extract    s11, v4, #4
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #5
    vf.fma       v10, v5, v6, v9
    v.extract    s11, v4, #5
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #6
    vf.fma       v9, v5, v6, v10
    v.extract    s11, v4, #6
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #7
    vf.fma       v10, v5, v6, v9
    v.extract    s11, v4, #7
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #8
    vf.fma       v9, v5, v6, v10
    v.extract    s11, v4, #8
    v.splat      v5, s11
    a.vread      v6, a2, s8
    s.movz       s8, #15
    vf.fma       v10, v5, v6, v9
    s.movz       s11, #9
    v.extract    s14, v4, #9
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #10
    vf.fma       v9, v5, v6, v10
    v.extract    s14, v4, #10
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #11
    vf.fma       v10, v5, v6, v9
    v.extract    s14, v4, #11
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #12
    vf.fma       v9, v5, v6, v10
    v.extract    s14, v4, #12
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #13
    vf.fma       v10, v5, v6, v9
    v.extract    s14, v4, #13
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #14
    vf.fma       v9, v5, v6, v10
    v.extract    s14, v4, #14
    v.splat      v5, s14
    a.vread      v6, a2, s11
    s.movz       s11, #15
    vf.fma       v10, v5, v6, v9
    v.extract    s14, v4, #15
    v.splat      v4, s14
    a.vread      v5, a2, s11
    s.movz       s11, #0
    vf.fma       v6, v4, v5, v10
    s.movz       s14, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s15, #0
    s.movz       s16, #1
    a.vwrite     a3, s8, v6
    a.vread      v4, a0, s11
    a.vread      v5, a3, s14
    s.movz       s8, #1
    vf.add       v6, v4, v5
    s.movz       s11, #1
    s.movz       s14, #2
    s.movz       s17, #2
    a.vwrite     a4, s15, v6
    a.vread      v4, a0, s16
    a.vread      v5, a3, s8
    s.movz       s8, #2
    vf.add       v6, v4, v5
    s.movz       s15, #3
    s.movz       s16, #3
    s.movz       s18, #3
    a.vwrite     a4, s11, v6
    a.vread      v4, a0, s14
    a.vread      v5, a3, s17
    s.movz       s11, #4
    vf.add       v6, v4, v5
    s.movz       s14, #4
    s.movz       s17, #4
    s.movz       s19, #5
    a.vwrite     a4, s8, v6
    a.vread      v4, a0, s15
    a.vread      v5, a3, s16
    s.movz       s8, #5
    vf.add       v6, v4, v5
    s.movz       s15, #5
    s.movz       s16, #6
    s.movz       s20, #6
    a.vwrite     a4, s18, v6
    a.vread      v4, a0, s11
    a.vread      v5, a3, s14
    s.movz       s11, #6
    vf.add       v6, v4, v5
    s.movz       s14, #7
    s.movz       s18, #7
    s.movz       s21, #7
    a.vwrite     a4, s17, v6
    a.vread      v4, a0, s19
    a.vread      v5, a3, s8
    s.movz       s8, #8
    vf.add       v6, v4, v5
    s.movz       s17, #8
    s.movz       s19, #8
    s.movz       s22, #9
    a.vwrite     a4, s15, v6
    a.vread      v4, a0, s16
    a.vread      v5, a3, s20
    s.movz       s15, #9
    vf.add       v6, v4, v5
    s.movz       s16, #9
    s.movz       s20, #10
    s.movz       s23, #10
    a.vwrite     a4, s11, v6
    a.vread      v4, a0, s14
    a.vread      v5, a3, s18
    s.movz       s11, #10
    vf.add       v6, v4, v5
    s.movz       s14, #11
    s.movz       s18, #11
    s.movz       s24, #11
    a.vwrite     a4, s21, v6
    a.vread      v4, a0, s8
    a.vread      v5, a3, s17
    s.movz       s8, #12
    vf.add       v6, v4, v5
    s.movz       s17, #12
    s.movz       s21, #12
    s.movz       s25, #13
    a.vwrite     a4, s19, v6
    a.vread      v4, a0, s22
    a.vread      v5, a3, s15
    s.movz       s15, #13
    vf.add       v6, v4, v5
    s.movz       s19, #13
    s.movz       s22, #14
    a.vwrite     a4, s16, v6
    a.vread      v4, a0, s20
    a.vread      v5, a3, s23
    s.movz       s16, #14
    vf.add       v6, v4, v5
    s.movz       s20, #14
    s.movz       s23, #15
    a.vwrite     a4, s11, v6
    a.vread      v4, a0, s14
    a.vread      v5, a3, s18
    s.movz       s11, #15
    vf.add       v6, v4, v5
    s.movz       s14, #15
    s.movz       s18, #0
    a.vwrite     a4, s24, v6
    a.vread      v4, a0, s8
    a.vread      v5, a3, s17
    s.movz       s8, #0
    vf.add       v6, v4, v5
    s.movz       s17, #1
    s.movz       s24, #1
    a.vwrite     a4, s21, v6
    a.vread      v4, a0, s25
    a.vread      v5, a3, s15
    s.movz       s15, #2
    vf.add       v6, v4, v5
    s.movz       s21, #2
    s.movz       s25, #3
    a.vwrite     a4, s19, v6
    a.vread      v4, a0, s22
    a.vread      v5, a3, s16
    s.movz       s16, #3
    vf.add       v6, v4, v5
    s.movz       s19, #4
    s.movz       s22, #4
    a.vwrite     a4, s20, v6
    a.vread      v4, a0, s23
    a.vread      v5, a3, s11
    s.movz       s11, #5
    vf.add       v6, v4, v5
    s.movz       s20, #5
    s.movz       s23, #6
    a.vwrite     a4, s14, v6
    a.vread      v4, a4, s18
    s.movz       s14, #6
    a.vwrite     a0, s8, v4
    a.vread      v4, a4, s17
    s.movz       s8, #7
    a.vwrite     a0, s24, v4
    a.vread      v4, a4, s15
    s.movz       s15, #7
    a.vwrite     a0, s21, v4
    a.vread      v4, a4, s25
    s.movz       s17, #8
    a.vwrite     a0, s16, v4
    a.vread      v4, a4, s19
    s.movz       s16, #8
    a.vwrite     a0, s22, v4
    a.vread      v4, a4, s11
    s.movz       s11, #9
    a.vwrite     a0, s20, v4
    a.vread      v4, a4, s23
    s.movz       s18, #9
    a.vwrite     a0, s14, v4
    a.vread      v4, a4, s8
    s.movz       s8, #10
    a.vwrite     a0, s15, v4
    a.vread      v4, a4, s17
    s.movz       s14, #10
    a.vwrite     a0, s16, v4
    a.vread      v4, a4, s11
    s.movz       s11, #11
    a.vwrite     a0, s18, v4
    a.vread      v4, a4, s8
    s.movz       s8, #11
    a.vwrite     a0, s14, v4
    a.vread      v4, a4, s11
    s.movz       s11, #12
    a.vwrite     a0, s8, v4
    s.movz       s8, #12
    a.vread      v4, a4, s11
    s.movz       s11, #13
    a.vwrite     a0, s8, v4
    s.movz       s8, #13
    a.vread      v4, a4, s11
    s.movz       s11, #14
    a.vwrite     a0, s8, v4
    s.movz       s8, #14
    a.vread      v4, a4, s11
    s.movz       s11, #15
    a.vwrite     a0, s8, v4
    s.movz       s8, #15
    a.vread      v4, a4, s11
    s.add        s11, s13, s12
    s.movz       s14, #1
    a.vwrite     a0, s8, v4
    s.mov        s13, s11
    br.nz        s14, for_5
endfor_6:
    s.muli       s1, s7, #3136                   // a runtime tile origin, x3136
    s.movz       s2, #56
    s.movz       s4, #0
    s.movz       s7, #3136
    v.extract    s8, v8, #0
    v.extract    s9, v8, #1
    v.splat      v0, s8
    v.splat      v4, s2
    s.add        s2, s4, s1                      // the tile origin
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s7
    v.splat      v9, s9
    v.extract    s1, v7, #0
    v.extract    s4, v7, #1
    v.splat      v10, s1
    v.mul        v11, v0, v4
    v.mul        v0, v5, v6
    v.splat      v5, s2
    v.splat      v6, s4
    v.mul        v12, v9, v4
    v.extract    s1, v2, #0
    v.add        v9, v10, v11
    v.add        v10, v0, v5
    v.splat      v0, s1
    v.splat      v5, s10
    v.add        v11, v9, v10
    v.mul        v9, v0, v5
    v.movi       v0, #8
    v.add        v13, v6, v12
    v.movi       v6, #1
    v.movi       v12, #0
    v.movi       v14, #1
    v.movi       v15, #0
    s.addi       s1, s6, #3136
    v.add        v16, v11, v9
    v.splat      v9, s3
    v.cmp.lt     p1, v2, v0
    v.extract    s2, v2, #1
    v.splat      v0, s2
    v.add        v11, v13, v10
    v.cmp.lt     p2, v8, v1
    @p1 v.sel        v13, v6, v12
    v.mul        v6, v0, v5
    @p2 v.sel        v0, v14, v15
    v.add        v12, v11, v6
    v.movi       v6, #1
    v.movi       v11, #0
    v.add        v14, v9, v16
    s.addi       s2, s1, #64
    v.add        v15, v9, v12
    s.addi       s3, s1, #128
    v.cmp.lt     p1, v7, v1
    v.extract    s4, v8, #2
    v.extract    s7, v7, #2
    v.splat      v1, s7
    @p1 v.sel        v12, v6, v11
    v.splat      v6, s4
    v.st.w       [s1, #0], v14
    v.movi       v11, #64
    v.mul        v14, v6, v4
    v.cmp.lt     p1, v3, v11
    v.extract    s4, v8, #3
    v.extract    s7, v8, #4
    v.extract    s8, v8, #5
    v.splat      v3, s4
    v.splat      v6, s7
    v.splat      v11, s8
    v.extract    s4, v7, #3
    v.extract    s7, v7, #4
    v.extract    s8, v7, #5
    v.mul        v16, v3, v4
    v.mul        v3, v6, v4
    v.extract    s9, v2, #2
    v.extract    s10, v2, #3
    v.add        v6, v1, v14
    v.splat      v1, s4
    v.extract    s4, v2, #4
    v.add        v14, v1, v16
    v.splat      v1, s7
    v.add        v16, v6, v10
    v.add        v6, v1, v3
    v.splat      v1, s8
    v.add        v3, v14, v10
    v.add        v14, v6, v10
    s.addi       s7, s1, #192
    s.addi       s8, s1, #256
    v.st.w       [s2, #0], v15
    v.mul        v6, v11, v4
    v.extract    s2, v2, #5
    v.splat      v11, s9
    v.extract    s9, v7, #6
    v.add        v15, v1, v6
    v.splat      v1, s10
    v.mul        v6, v11, v5
    v.mul        v11, v1, v5
    v.add        v1, v15, v10
    v.add        v15, v16, v6
    v.extract    s10, v8, #6
    v.splat      v6, s9
    v.add        v16, v3, v11
    v.splat      v3, s4
    v.add        v11, v9, v15
    v.mul        v15, v3, v5
    v.add        v3, v9, v16
    v.add        v16, v14, v15
    v.splat      v14, s10
    v.add        v15, v9, v16
    s.addi       s4, s1, #320
    s.addi       s9, s1, #384
    v.st.w       [s3, #0], v11
    v.extract    s3, v8, #7
    v.splat      v11, s3
    v.extract    s3, v7, #7
    v.mul        v16, v14, v4
    v.extract    s10, v2, #6
    v.add        v14, v6, v16
    v.splat      v6, s3
    v.add        v16, v14, v10
    s.addi       s3, s1, #448
    v.st.w       [s7, #0], v3
    v.extract    s7, v8, #8
    v.splat      v3, s7
    v.extract    s7, v7, #8
    v.mul        v14, v11, v4
    v.add        v11, v6, v14
    v.splat      v6, s7
    v.extract    s7, v2, #7
    v.add        v14, v11, v10
    v.st.w       [s8, #0], v15
    v.mul        v11, v3, v4
    v.extract    s8, v2, #8
    v.splat      v3, s2
    v.extract    s2, v7, #9
    v.add        v15, v6, v11
    v.splat      v6, s10
    v.mul        v11, v3, v5
    v.mul        v3, v6, v5
    v.add        v6, v15, v10
    v.add        v15, v1, v11
    v.extract    s10, v8, #9
    v.splat      v1, s2
    v.add        v11, v16, v3
    v.splat      v3, s7
    v.add        v16, v9, v15
    v.mul        v15, v3, v5
    v.add        v3, v9, v11
    v.add        v11, v14, v15
    v.splat      v14, s10
    v.add        v15, v9, v11
    s.addi       s2, s1, #512
    s.addi       s7, s1, #576
    v.st.w       [s4, #0], v16
    v.extract    s4, v8, #10
    v.splat      v11, s4
    v.extract    s4, v7, #10
    v.mul        v16, v14, v4
    v.extract    s10, v2, #9
    v.add        v14, v1, v16
    v.splat      v1, s4
    v.add        v16, v14, v10
    s.addi       s4, s1, #640
    v.st.w       [s9, #0], v3
    v.extract    s9, v8, #11
    v.splat      v3, s9
    v.extract    s9, v7, #11
    v.mul        v14, v11, v4
    v.add        v11, v1, v14
    v.splat      v1, s9
    v.extract    s9, v2, #10
    v.add        v14, v11, v10
    v.st.w       [s3, #0], v15
    v.mul        v11, v3, v4
    v.extract    s3, v2, #11
    v.splat      v3, s8
    v.extract    s8, v7, #12
    v.add        v15, v1, v11
    v.splat      v1, s10
    v.mul        v11, v3, v5
    v.mul        v3, v1, v5
    v.add        v1, v15, v10
    v.add        v15, v6, v11
    v.extract    s10, v8, #12
    v.splat      v6, s8
    v.add        v11, v16, v3
    v.splat      v3, s9
    v.add        v16, v9, v15
    v.mul        v15, v3, v5
    v.add        v3, v9, v11
    v.add        v11, v14, v15
    v.splat      v14, s10
    v.add        v15, v9, v11
    s.addi       s8, s1, #704
    s.addi       s9, s1, #768
    v.st.w       [s2, #0], v16
    v.extract    s2, v8, #13
    v.splat      v11, s2
    v.extract    s2, v7, #13
    v.mul        v16, v14, v4
    v.extract    s10, v2, #12
    v.add        v14, v6, v16
    v.splat      v6, s2
    v.add        v16, v14, v10
    s.addi       s2, s1, #832
    v.st.w       [s7, #0], v3
    v.extract    s7, v8, #14
    v.splat      v3, s7
    v.extract    s7, v7, #14
    v.mul        v14, v11, v4
    v.add        v11, v6, v14
    v.splat      v6, s7
    v.extract    s7, v2, #13
    v.add        v14, v11, v10
    v.st.w       [s4, #0], v15
    v.mul        v11, v3, v4
    v.extract    s4, v2, #14
    v.splat      v3, s3
    v.extract    s3, v7, #15
    v.splat      v7, s10
    v.add        v15, v6, v11
    v.splat      v6, s7
    v.mul        v11, v3, v5
    v.mul        v3, v7, v5
    v.mul        v7, v6, v5
    v.add        v6, v15, v10
    v.add        v15, v1, v11
    v.extract    s7, v8, #15
    v.splat      v1, s3
    v.splat      v8, s4
    v.add        v11, v16, v3
    v.mul        v3, v8, v5
    v.add        v8, v14, v7
    v.add        v7, v6, v3
    v.add        v3, v9, v15
    v.splat      v6, s7
    v.add        v14, v9, v11
    v.add        v11, v9, v8
    s.addi       s3, s1, #896
    v.add        v8, v9, v7
    s.addi       s4, s1, #960
    v.st.w       [s8, #0], v3
    v.mul        v3, v6, v4
    v.extract    s1, v2, #15
    v.add        v2, v1, v3
    v.splat      v1, s1
    v.add        v3, v2, v10
    v.mul        v2, v1, v5
    s.movz       s1, #0
    v.add        v1, v3, v2
    s.addi       s7, s6, #3136
    v.add        v2, v9, v1
    v.st.w       [s9, #0], v14
    v.extract    s8, v13, #0
    v.extract    s9, v0, #0
    v.splat      v1, s8
    v.movi       v3, #0
    v.splat      v4, s9
    v.movi       v5, #0
    v.extract    s8, v12, #0
    v.cmp.ne     p2, v1, v3
    v.cmp.ne     p3, v4, v5
    v.st.w       [s2, #0], v11
    v.splat      v1, s8
    v.movi       v3, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v1, v3
    p.and        p3, p4, p2
    s.movz       s2, #1
    p.and        p2, p3, p1
    s.addi       s8, s6, #3200
    v.extract    s9, v13, #1
    v.st.w       [s3, #0], v8
    v.extract    s3, v0, #1
    v.splat      v1, s9
    v.movi       v3, #0
    v.splat      v4, s3
    v.movi       v5, #0
    v.extract    s3, v12, #1
    v.cmp.ne     p3, v1, v3
    v.cmp.ne     p4, v4, v5
    v.splat      v1, s3
    v.st.w       [s4, #0], v2
    fence.acq_rel.device
    a.vread      v2, a0, s1
    v.movi       v3, #0
    p.and        p5, p3, p4
    v.cmp.ne     p3, v1, v3
    p.and        p4, p5, p3
    s.movz       s1, #2
    p.and        p3, p4, p1
    s.addi       s3, s6, #3264
    v.ld.w       v1, [s7, #0]
    v.extract    s4, v13, #2
    v.extract    s7, v0, #2
    v.splat      v3, s4
    v.movi       v4, #0
    v.splat      v5, s7
    v.movi       v6, #0
    v.extract    s4, v12, #2
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s4
    @p2 v.st.scatter.w [s5, v1], v2
    a.vread      v1, a0, s2
    v.cmp.ne     p2, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p2
    v.cmp.ne     p2, v3, v2
    p.and        p4, p5, p2
    s.movz       s2, #3
    p.and        p2, p4, p1
    s.addi       s4, s6, #3328
    v.ld.w       v2, [s8, #0]
    v.extract    s7, v13, #3
    v.extract    s8, v0, #3
    v.splat      v3, s7
    v.movi       v4, #0
    v.splat      v5, s8
    v.movi       v6, #0
    v.extract    s7, v12, #3
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s7
    @p3 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p3, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p3
    v.cmp.ne     p3, v3, v2
    p.and        p4, p5, p3
    s.movz       s1, #4
    p.and        p3, p4, p1
    s.addi       s7, s6, #3392
    v.ld.w       v2, [s3, #0]
    v.extract    s3, v13, #4
    v.extract    s8, v0, #4
    v.splat      v3, s3
    v.movi       v4, #0
    v.splat      v5, s8
    v.movi       v6, #0
    v.extract    s3, v12, #4
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s3
    @p2 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s2
    v.cmp.ne     p2, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p2
    v.cmp.ne     p2, v3, v2
    p.and        p4, p5, p2
    s.movz       s2, #5
    p.and        p2, p4, p1
    s.addi       s3, s6, #3456
    v.ld.w       v2, [s4, #0]
    v.extract    s4, v13, #5
    v.extract    s8, v0, #5
    v.splat      v3, s4
    v.movi       v4, #0
    v.splat      v5, s8
    v.movi       v6, #0
    v.extract    s4, v12, #5
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s4
    @p3 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p3, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p3
    v.cmp.ne     p3, v3, v2
    p.and        p4, p5, p3
    s.movz       s1, #6
    p.and        p3, p4, p1
    s.addi       s4, s6, #3520
    v.ld.w       v2, [s7, #0]
    v.extract    s7, v13, #6
    v.extract    s8, v0, #6
    v.splat      v3, s7
    v.movi       v4, #0
    v.splat      v5, s8
    v.movi       v6, #0
    v.extract    s7, v12, #6
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s7
    @p2 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s2
    v.cmp.ne     p2, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p2
    v.cmp.ne     p2, v3, v2
    p.and        p4, p5, p2
    s.movz       s2, #7
    p.and        p2, p4, p1
    s.addi       s7, s6, #3584
    v.ld.w       v2, [s3, #0]
    v.extract    s3, v13, #7
    v.extract    s8, v0, #7
    v.splat      v3, s3
    v.movi       v4, #0
    v.splat      v5, s8
    v.movi       v6, #0
    v.extract    s3, v12, #7
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s3
    @p3 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p3, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p3
    v.cmp.ne     p3, v3, v2
    p.and        p4, p5, p3
    s.movz       s1, #8
    p.and        p3, p4, p1
    s.addi       s3, s6, #3648
    v.ld.w       v2, [s4, #0]
    v.extract    s4, v13, #8
    v.extract    s8, v0, #8
    v.splat      v3, s4
    v.movi       v4, #0
    v.splat      v5, s8
    v.movi       v6, #0
    v.extract    s4, v12, #8
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s4
    @p2 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s2
    v.cmp.ne     p2, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p2
    v.cmp.ne     p2, v3, v2
    p.and        p4, p5, p2
    s.movz       s2, #9
    p.and        p2, p4, p1
    s.addi       s4, s6, #3712
    v.ld.w       v2, [s7, #0]
    v.extract    s7, v13, #9
    v.extract    s8, v0, #9
    v.splat      v3, s7
    v.movi       v4, #0
    v.splat      v5, s8
    v.movi       v6, #0
    v.extract    s7, v12, #9
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s7
    @p3 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p3, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p3
    v.cmp.ne     p3, v3, v2
    p.and        p4, p5, p3
    s.movz       s1, #10
    p.and        p3, p4, p1
    s.addi       s7, s6, #3776
    v.ld.w       v2, [s3, #0]
    v.extract    s3, v13, #10
    v.extract    s8, v0, #10
    v.splat      v3, s3
    v.movi       v4, #0
    v.splat      v5, s8
    v.movi       v6, #0
    v.extract    s3, v12, #10
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s3
    @p2 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s2
    v.cmp.ne     p2, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p2
    v.cmp.ne     p2, v3, v2
    p.and        p4, p5, p2
    s.movz       s2, #11
    p.and        p2, p4, p1
    s.addi       s3, s6, #3840
    v.ld.w       v2, [s4, #0]
    v.extract    s4, v13, #11
    v.extract    s8, v0, #11
    v.splat      v3, s4
    v.movi       v4, #0
    v.splat      v5, s8
    v.movi       v6, #0
    v.extract    s4, v12, #11
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s4
    @p3 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p3, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p3
    v.cmp.ne     p3, v3, v2
    p.and        p4, p5, p3
    s.movz       s1, #12
    p.and        p3, p4, p1
    s.addi       s4, s6, #3904
    v.ld.w       v2, [s7, #0]
    v.extract    s7, v13, #12
    v.extract    s8, v0, #12
    v.splat      v3, s7
    v.movi       v4, #0
    v.splat      v5, s8
    v.movi       v6, #0
    v.extract    s7, v12, #12
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s7
    @p2 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s2
    v.cmp.ne     p2, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p2
    v.cmp.ne     p2, v3, v2
    p.and        p4, p5, p2
    s.movz       s2, #13
    p.and        p2, p4, p1
    s.addi       s7, s6, #3968
    v.ld.w       v2, [s3, #0]
    v.extract    s3, v13, #13
    v.extract    s8, v0, #13
    v.splat      v3, s3
    v.movi       v4, #0
    v.splat      v5, s8
    v.movi       v6, #0
    v.extract    s3, v12, #13
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s3
    @p3 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p3, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p3
    v.cmp.ne     p3, v3, v2
    p.and        p4, p5, p3
    s.movz       s1, #14
    p.and        p3, p4, p1
    s.addi       s3, s6, #4032
    v.ld.w       v2, [s4, #0]
    v.extract    s4, v13, #14
    v.extract    s8, v0, #14
    v.splat      v3, s4
    v.movi       v4, #0
    v.splat      v5, s8
    v.movi       v6, #0
    v.extract    s4, v12, #14
    v.cmp.ne     p4, v3, v4
    v.splat      v3, s4
    @p2 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s2
    v.cmp.ne     p2, v5, v6
    v.movi       v2, #0
    p.and        p5, p4, p2
    v.cmp.ne     p2, v3, v2
    p.and        p4, p5, p2
    s.movz       s2, #15
    p.and        p2, p4, p1
    s.addi       s4, s6, #4096
    v.ld.w       v2, [s7, #0]
    v.extract    s6, v13, #15
    v.extract    s7, v0, #15
    v.splat      v0, s6
    v.movi       v3, #0
    v.splat      v4, s7
    v.movi       v5, #0
    v.extract    s6, v12, #15
    v.cmp.ne     p4, v0, v3
    v.splat      v0, s6
    @p3 v.st.scatter.w [s5, v2], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p3, v4, v5
    v.movi       v2, #0
    p.and        p5, p4, p3
    v.cmp.ne     p3, v0, v2
    p.and        p4, p5, p3
    p.and        p3, p4, p1
    v.ld.w       v0, [s3, #0]
    @p2 v.st.scatter.w [s5, v0], v1
    a.vread      v0, a0, s2
    v.ld.w       v1, [s4, #0]
    @p3 v.st.scatter.w [s5, v1], v0
__rctx_next:
    exit
