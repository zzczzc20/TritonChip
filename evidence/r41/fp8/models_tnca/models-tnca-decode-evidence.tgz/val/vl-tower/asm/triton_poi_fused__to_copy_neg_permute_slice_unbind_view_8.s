    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #5
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.sub        v6, v1, v3
    @p1 v.sel        v7, v4, v5
    v.movi       v4, #0
    v.sub        v5, v0, v7
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v7, v0
    @p1 v.sel        v8, v6, v3
    v.movi       v6, #31
    @p2 v.sel        v9, v5, v7
    v.movi       v5, #15
    v.sub        v10, v4, v3
    v.cmp.lt     p3, v3, v4
    v.and        v11, v8, v6
    v.and        v6, v9, v5
    @p3 v.sel        v5, v10, v3
    v.sub        v3, v1, v11
    v.sub        v8, v0, v6
    @p1 v.sel        v9, v3, v11
    @p2 v.sel        v3, v8, v6
    s.rdspecial  s1, arg_base
    v.movi       v6, #32
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v8, #16
    v.movi       v10, #512
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.cmp.lt     p1, v6, v1
    v.sub        v11, v1, v6
    v.cmp.lt     p2, v6, v2
    v.sub        v1, v2, v6
    @p1 v.sel        v2, v11, v6
    v.movi       v2, #9
    v.cmp.lt     p1, v8, v0
    v.lshr       v11, v5, v2
    v.movi       v2, #1056
    v.sub        v5, v0, v8
    v.add        v0, v9, v2
    @p2 v.sel        v2, v1, v6
    v.sub        v1, v4, v11
    v.movi       v2, #64
    @p3 v.sel        v6, v1, v11
    v.mul        v1, v3, v2
    v.movi       v3, #3072
    v.add        v11, v0, v1
    v.mul        v0, v6, v3
    v.mul        v1, v7, v2
    v.add        v2, v11, v0
    v.sub        v0, v4, v10
    v.ld.gather.h v3, [s2, v2]                   // index is in elements (ISA sec 9.1)
    v.add        v2, v9, v1
    v.cmp.lt     p2, v10, v4
    @p1 v.sel        v1, v5, v8
    @p2 v.sel        v1, v0, v10
    vf.cvt.bf16.f32 v0, v3
    vf.neg       v1, v0
    v.st.scatter.w [s3, v2], v1
__rctx_next:
    exit
