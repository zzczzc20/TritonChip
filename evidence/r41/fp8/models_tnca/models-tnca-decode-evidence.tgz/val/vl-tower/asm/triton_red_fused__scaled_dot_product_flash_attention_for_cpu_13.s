    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    v.movi       v0, #0
    s.ld.d       s3, [s2, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.add        s6, s1, s5                      // this context's own scratch
    v.movi       v1, #0
    s.addi       s1, s6, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s5, #4096
    s.movz       s7, #256
    s.movz       s8, #1024
    s.movz       s9, #4
    .li       s10, #68719476737
    .li       s11, #2207613190144
    s.movz       s12, #0
    .li       s13, #4286578688
    v.splat      v2, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #0
    v.cmp.ne     p1, v0, v1
    s.ld.d       s13, [s2, #0]                   // in_out_ptr0: device_ptr64 at arg_base+0
    s.movz       s2, #0
    v.splat      v0, s4
    s.st.d       [s1, #0], s3
    v.iota       v0                              // arange(0, VLEN)
    p.mov        p2, p1
    s.st.d       [s1, #8], s5
    s.movz       s2, #256
    s.st.d       [s1, #16], s7
    s.movz       s5, #16
    s.st.d       [s1, #48], s8
    s.addi       s7, s12, #0
    s.st.d       [s1, #56], s9
    s.st.d       [s1, #88], s10
    s.st.d       [s1, #104], s11
    fence.release.device
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.mov        v3, v2
for_1:
    s.cmp.ge     s1, s7, s2
    br.nz        s1, endfor_2
    s.muli       s1, s4, #1024
    v.splat      v1, s7
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s8, #256
    s.movz       s9, #4096
    s.muli       s10, s7, #4
    v.add        v5, v1, v4
    v.movi       v1, #0
    v.splat      v4, s8
    v.splat      v6, s4
    v.movi       v7, #0
    v.splat      v8, s9
    v.cmp.ge     p1, v5, v1
    v.cmp.lt     p3, v5, v4
    v.cmp.ge     p4, v6, v7
    v.cmp.lt     p5, v6, v8
    s.add        s8, s3, s1
    p.and        p6, p1, p3
    p.and        p1, p4, p5
    s.add        s1, s8, s10
    p.and        p3, p6, p1
    v.movi       v1, #1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s1, #0]
    v.movi       v5, #0
    v.movi       v6, #0
    v.movi       v7, #1
    v.movi       v8, #0
    v.movi       v9, #1
    v.movi       v10, #0
    vf.cmp.eq    p1, v4, v2
    @p1 v.sel        v11, v1, v5
    v.movi       v1, #0
    v.cmp.eq     p1, v11, v6
    @p1 v.sel        v5, v7, v8
    @p1 v.sel        v6, v9, v10
    v.extract    s1, v5, #0
    v.movi       v5, #0
    s.lshri      s8, s1, #32
    v.extract    s9, v6, #1
    v.insert     v1, s1, #0
    v.insert     v5, s8, #0
    s.lshri      s1, s9, #32
    v.insert     v1, s9, #1
    v.insert     v5, s1, #1
    v.splat      v6, s7
    v.movi       v7, #1
    v.add        v8, v6, v0
    v.movi       v6, #0
    v.movi       v9, #256
    @p1 v.sel        v10, v7, v6
    v.cmp.lt     p3, v8, v9
    v.movi       v6, #1
    v.movi       v7, #0
    v.extract    s1, v10, #2
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #1
    v.movi       v7, #0
    s.lshri      s8, s1, #32
    v.extract    s9, v8, #3
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #1
    v.movi       v7, #0
    v.insert     v1, s1, #2
    v.insert     v5, s8, #2
    s.lshri      s1, s9, #32
    v.extract    s8, v8, #4
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #1
    v.movi       v7, #0
    v.insert     v1, s9, #3
    v.insert     v5, s1, #3
    s.lshri      s1, s8, #32
    v.extract    s9, v8, #5
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #1
    v.movi       v7, #0
    v.insert     v1, s8, #4
    v.insert     v5, s1, #4
    s.lshri      s1, s9, #32
    v.extract    s8, v8, #6
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #1
    v.movi       v7, #0
    v.insert     v1, s9, #5
    v.insert     v5, s1, #5
    s.lshri      s1, s8, #32
    v.extract    s9, v8, #7
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #1
    v.movi       v7, #0
    v.insert     v1, s8, #6
    v.insert     v5, s1, #6
    s.lshri      s1, s9, #32
    v.extract    s8, v8, #8
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #1
    v.movi       v7, #0
    v.insert     v1, s9, #7
    v.insert     v5, s1, #7
    s.lshri      s1, s8, #32
    v.extract    s9, v8, #9
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #1
    v.movi       v7, #0
    v.insert     v1, s8, #8
    v.insert     v5, s1, #8
    s.lshri      s1, s9, #32
    v.extract    s8, v8, #10
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #1
    v.movi       v7, #0
    v.insert     v1, s9, #9
    v.insert     v5, s1, #9
    s.lshri      s1, s8, #32
    v.extract    s9, v8, #11
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #1
    v.movi       v7, #0
    v.insert     v1, s8, #10
    v.insert     v5, s1, #10
    s.lshri      s1, s9, #32
    v.extract    s8, v8, #12
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #1
    v.movi       v7, #0
    v.insert     v1, s9, #11
    v.insert     v5, s1, #11
    s.lshri      s1, s8, #32
    v.extract    s9, v8, #13
    @p1 v.sel        v8, v6, v7
    v.movi       v6, #1
    v.movi       v7, #0
    v.insert     v1, s8, #12
    v.insert     v5, s1, #12
    s.lshri      s1, s9, #32
    v.extract    s8, v8, #14
    @p1 v.sel        v8, v6, v7
    v.insert     v1, s9, #13
    v.insert     v5, s1, #13
    s.lshri      s1, s8, #32
    v.extract    s9, v8, #15
    v.insert     v1, s8, #14
    v.insert     v5, s1, #14
    s.lshri      s1, s9, #32
    v.insert     v1, s9, #15
    v.insert     v5, s1, #15
    v.extract    s1, v1, #0
    v.extract    s8, v5, #0
    s.shli       s9, s8, #32
    v.extract    s8, v5, #1
    s.or         s10, s1, s9
    s.movz       s1, #0
    s.shli       s9, s8, #32
    v.extract    s8, v1, #1
    v.extract    s11, v5, #2
    v.movi       v6, #0
    s.cmp.ne     s14, s10, s1
    s.or         s1, s8, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #2
    v.extract    s11, v5, #3
    v.insert     v6, s14, #0
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #3
    v.extract    s11, v5, #4
    v.insert     v6, s14, #1
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #4
    v.extract    s11, v5, #5
    v.insert     v6, s14, #2
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #5
    v.extract    s11, v5, #6
    v.insert     v6, s14, #3
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #6
    v.extract    s11, v5, #7
    v.insert     v6, s14, #4
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #7
    v.extract    s11, v5, #8
    v.insert     v6, s14, #5
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #8
    v.extract    s11, v5, #9
    v.insert     v6, s14, #6
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #9
    v.extract    s11, v5, #10
    v.insert     v6, s14, #7
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #10
    v.extract    s11, v5, #11
    v.insert     v6, s14, #8
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #11
    v.extract    s11, v5, #12
    v.insert     v6, s14, #9
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #12
    v.extract    s11, v5, #13
    v.insert     v6, s14, #10
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #13
    v.extract    s11, v5, #14
    v.insert     v6, s14, #11
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #14
    v.extract    s11, v5, #15
    v.insert     v6, s14, #12
    s.cmp.ne     s14, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    s.shli       s9, s11, #32
    v.extract    s10, v1, #15
    v.insert     v6, s14, #13
    s.cmp.ne     s11, s1, s8
    s.or         s1, s10, s9
    s.movz       s8, #0
    v.insert     v6, s11, #14
    s.cmp.ne     s9, s1, s8
    v.movi       v1, #0
    v.insert     v6, s9, #15
    p.not        p1, p3
    v.cmp.ne     p4, v6, v1
    p.or         p5, p2, p4
    vf.max       v1, v3, v4
    p.and        p4, p3, p5
    p.and        p5, p1, p2
    v.movi       v4, #0
    p.or         p1, p4, p5
    @p3 v.sel        v5, v1, v3
    p.mov        p3, p1
    v.mov        v4, v5
    s.add        s1, s7, s5
    s.movz       s8, #1
    p.mov        p2, p3
    v.mov        v3, v4
    s.mov        s7, s1
    br.nz        s8, for_1
endfor_2:
    v.movi       v1, #1
    v.movi       v2, #0
    vf.cmp.uo    p1, v3, v3
    @p1 v.sel        v4, v1, v2
    v.movi       v1, #1
    v.movi       v2, #0
    v.reduce.or.b v5, v4
    v.movi       v4, #0
    vf.reduce.max.b v6, v3
    .li       s1, #2143289344
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p2 v.sel        v7, v1, v2
    v.cmp.ne     p1, v5, v4
    @p1 v.sel        v1, v3, v6
    v.movi       v2, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.reduce.or  s1, v7
    v.splat      v5, s1
    vf.add       v6, v1, v2
    s.addi       s1, s12, #0
    v.mov        v4, v3
for_3:
    s.cmp.ge     s7, s1, s2
    br.nz        s7, endfor_4
    s.muli       s7, s4, #1024
    v.splat      v1, s1
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s8, #256
    s.movz       s9, #4096
    s.muli       s10, s1, #4
    v.add        v8, v1, v7
    v.movi       v1, #0
    v.splat      v7, s8
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s9
    v.cmp.ge     p1, v8, v1
    v.cmp.lt     p2, v8, v7
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    s.add        s8, s3, s7
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s7, s8, s10
    p.and        p2, p5, p1
    v.extract    s8, v6, #0
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s7, #0]
    v.splat      v7, s8
    .li       s7, #1069066811
    v.splat      v8, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s7, #1060205080
    v.splat      v9, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s7, s4, s2
    v.splat      v10, s1
    v.movi       v11, #256
    v.add        v12, v10, v0
    v.movi       v10, #0
    s.add        s8, s1, s7
    vf.sub       v13, v1, v7
    s.shli       s9, s8, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p1, v12, v11
    s.add        s8, s13, s9                     // &in_out_ptr0[...]
    vf.mul       v1, v13, v8
    v.splat      v7, s7
    s.add        s7, s1, s5
    s.movz       s9, #1
    v.exp2.approx v11, v1                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v14, v13, v8, v1                // the exact rounding error of x*log2(e)
    v.add        v1, v12, v7
    vf.mul       v1, v14, v9
    vf.fma       v7, v11, v1, v11                // 2**t * 2**d
    vf.cmp.o     p2, v7, v7
    @p2 v.sel        v1, v7, v11
    vf.add       v7, v4, v1
    @p1 v.st.w       [s8, #0], v1
    @p1 v.sel        v1, v7, v4
    v.mov        v10, v1
    v.mov        v4, v10
    s.mov        s1, s7
    br.nz        s9, for_3
endfor_4:
    vf.reduce.add.b v1, v4
    vf.add       v4, v1, v2
    s.addi       s1, s6, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s3, #0
    s.st.d       [s1, #0], s13
    s.movz       s3, #4096
    s.st.d       [s1, #8], s3
    s.movz       s3, #256
    s.st.d       [s1, #16], s3
    s.movz       s3, #1024
    s.st.d       [s1, #48], s3
    s.movz       s3, #4
    s.st.d       [s1, #56], s3
    .li       s3, #68719476737
    s.st.d       [s1, #88], s3
    .li       s3, #2207613190144
    s.st.d       [s1, #104], s3
    fence.release.device
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s12, #0
for_5:
    s.cmp.ge     s3, s1, s2
    br.nz        s3, endfor_6
    v.extract    s3, v4, #0
    v.splat      v1, s3
    s.muli       s3, s4, #1024
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    v.splat      v6, s1
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s6, #256
    s.movz       s7, #4096
    s.muli       s8, s1, #4
    v.add        v8, v6, v7
    v.movi       v6, #0
    v.splat      v7, s6
    v.splat      v9, s4
    v.movi       v10, #0
    v.cmp.ge     p1, v8, v6
    v.splat      v6, s7
    v.cmp.lt     p2, v8, v7
    .li       s6, #1065353216
    v.splat      v7, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v6
    s.add        s6, s13, s3
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s3, s6, s8
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s3, #0]
    v.movi       v8, #0
    v.movi       v9, #1
    v.movi       v10, #0
    vf.fms       v11, v1, v2, v7
    v.cmp.eq     p1, v5, v8
    @p1 v.sel        v7, v9, v10
    v.splat      v8, s1
    vf.fms       v9, v2, v11, v2
    v.extract    s3, v7, #0
    v.splat      v7, s3
    v.add        v10, v8, v0
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    v.movi       v9, #0
    v.movi       v11, #256
    v.cmp.ne     p1, v7, v9
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v2
    v.cmp.lt     p2, v10, v11
    vf.mul       v2, v6, v7                      // a/y: faithful quotient
    s.mul        s3, s4, s2
    s.add        s6, s1, s5
    s.movz       s7, #1
    vf.fms       v8, v2, v1, v6
    s.add        s8, s1, s3
    v.splat      v1, s3
    vf.fms       v6, v8, v7, v2
    s.shli       s3, s8, #2                      // element offset -> bytes (x4)
    v.add        v7, v10, v1
    s.add        s8, s13, s3                     // &in_out_ptr0[...]
    vf.neg       v1, v6                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v1, v1
    @p3 v.sel        v6, v1, v2
    @p1 v.sel        v1, v3, v6
    @p2 v.st.w       [s8, #0], v1
    s.mov        s1, s6
    br.nz        s7, for_5
endfor_6:
__rctx_next:
    exit
