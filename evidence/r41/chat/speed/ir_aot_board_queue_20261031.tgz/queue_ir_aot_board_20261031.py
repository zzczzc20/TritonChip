#!/usr/bin/env python3
"""Run the gated TNCA-IR AOT regression after the queued Q35 diagnostic."""
import copy,json,sys
from pathlib import Path
WORK=Path.home()/'r41run3';ROOT=WORK/'runtime_ir_aot_board_20261031';OUT=WORK/'chat_ir_aot_board_20261031'
NAME='r41-ir-aot-fp16-gemm-20261031';PREDECESSOR=1207980
EXPECTED={'python/tnca/aot.py':'5c9b25f9c556f074ed5e030339a596d63fdccd3a4490e5f031487ed3f9cae18e',
          'compiler/python/tnca_cc/frontend.py':'9da757bdd887912596f3682f5e06e6ff3ef49a5fa5acdf78a2ea04d0ae3139c1',
          'tools/r41/chat_speed/ir_gemm_board_20261031.py':'bb460a3c253f9258439c4705cea56b9ff49554c19db474fce97dd519491eeaf1'}

def derive(old):
 s=copy.deepcopy(old);s['id']=NAME
 s['hypothesis']='The repaired TNCA-IR AOT path executes exact FP16 descriptor GEMM at optimization levels 0, 1 and 2 on the loaded run-2 image.'
 s['competing_explanations']=['optimized TNCA-IR compilation fails','board outputs differ from the exact 256-value reference','the loaded image or clock changes']
 s['expected_counter_changes']=['Each optimization level executes one device launch and records its device cycles.']
 s['expected_observations']=['Each of the three output tensors is bitwise equal to its exact reference.']
 s['sources']=['python/tnca/aot.py','compiler/python/tnca_cc/gemm.py','tools/r41/chat_speed/ir_gemm_board_20261031.py']
 s['registration']={'status':'registered-not-run','scope':'Board regression for the gated TNCA-IR AOT fix, after the Q35 quality diagnostic; no image programming.'}
 s.pop('chat_quality',None);s.pop('tolerance_rule',None)
 step=s['steps'][0];step['id']='ir-aot-gemm';step['timeout_seconds']=600
 step['argv']=['{home}/r41s2_fp8env/bin/python','-I','-u','{root}/tools/r41/chat_speed/ir_gemm_board_20261031.py','--out','{out}/ir-board']
 step['outputs']=['{out}/ir-board/result.json'];step['timing_boundary']='Each actual board launch records device cycles.'
 step['cache_state']='A separate fresh session per optimization level.'
 s['budget_note']='This is a separate 600-second maximum exactness regression, not a chat quality result.';s['budget_seconds']=600
 checks=[dict(path='ir-board/result.json',field=['status'],equals='pass'),dict(path='ir-board/result.json',field=['results'],length_equals=3)]
 for i in range(3):
  checks.extend([dict(path='ir-board/result.json',field=['results',i,'opt_level'],equals=i),dict(path='ir-board/result.json',field=['results',i,'bit_mismatches'],equals=0),dict(path='ir-board/result.json',field=['results',i,'elements'],equals=256)])
 return s,checks

def main():
 sys.path.insert(0,str(WORK/'runtime_activation_equal_20261031/tools/r41/run2_board'))
 import q35_timeout_recovery as recovery
 if OUT.exists():raise FileExistsError('IR board queue already exists')
 for name,want in EXPECTED.items():
  if recovery.digest(ROOT/name)!=want:raise ValueError('prepared source differs: '+name)
 source=ROOT/'spec/r41/run3/board/r41-q35-whole-prefill-multiturn-20261031.json';spec,checks=derive(json.loads(source.read_text()))
 manifest=ROOT/'spec/r41/run3/board'/(NAME+'.json')
 with manifest.open('x') as f:json.dump(spec,f,indent=2);f.write('\n')
 reg={'schema':'tnca-run2-stage-registration/1','id':NAME,'image_identity':{'sha256':recovery.IMAGE_SHA,'uuid':recovery.UUID},'experiments':[{'id':NAME,'manifest':str(manifest.relative_to(ROOT)),'sha256':recovery.digest(manifest),'budget_seconds':600,'checks':checks}]}
 OUT.mkdir();recovery.OUT=OUT;regpath=OUT/'registration.json';regpath.write_text(json.dumps(reg,indent=2)+'\n')
 try:
  recovery.record('waiting',preceding_queue_pid=PREDECESSOR,manifest_sha256=reg['experiments'][0]['sha256'],registration_sha256=recovery.digest(regpath))
  recovery.wait_pid(PREDECESSOR)
  for name,want in EXPECTED.items():
   if recovery.digest(ROOT/name)!=want:raise ValueError('source changed while waiting: '+name)
  if recovery.digest(manifest)!=reg['experiments'][0]['sha256']:raise ValueError('manifest changed while waiting')
  recovery.stage(ROOT,OUT/'session',regpath,OUT/'stage.log')
  recovery.record('finished',scope='FP16 TNCA-IR AOT board regression')
 except BaseException as exc:
  recovery.record('stopped',error=f'{type(exc).__name__}: {exc}');raise
if __name__=='__main__':main()
