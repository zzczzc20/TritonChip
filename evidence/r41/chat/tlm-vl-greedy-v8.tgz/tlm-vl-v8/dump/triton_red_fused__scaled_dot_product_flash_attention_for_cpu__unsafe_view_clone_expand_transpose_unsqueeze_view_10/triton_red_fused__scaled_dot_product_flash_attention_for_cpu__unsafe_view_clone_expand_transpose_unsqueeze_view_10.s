    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.movz       s1, #1
    s.rdspecial  s8, arg_base
    s.ld.d       s9, [s8, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s8, role_id
    s.movz       s10, #256
    s.mul        s11, s8, s10
    s.add        s8, s9, s11                     // this context's own scratch
    s.addi       s9, s8, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s8, #0
    s.st.d       [s9, #0], s3
    s.movz       s8, #16
    s.st.d       [s9, #8], s8
    s.movz       s8, #64
    s.st.d       [s9, #16], s8
    s.movz       s8, #256
    s.st.d       [s9, #48], s8
    s.movz       s8, #4
    s.st.d       [s9, #56], s8
    .li       s8, #68719476737
    s.st.d       [s9, #88], s8
    .li       s8, #2207613190144
    s.st.d       [s9, #104], s8
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s8, #1
    s.movz       s9, #0
    s.movz       s10, #64
    s.movz       s11, #16
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #128
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v4, v3, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v4, #7
    v.lshr       v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s1
    v.cmp.lt     p1, v4, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v4, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    v.cmp.ne     p1, v4, v5
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s8
    v.cmp.lt     p2, v4, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s5, v3]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    v.movi       v6, #1
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #127
    v.and        v2, v7, v0
    v.sub        v0, v5, v2
    @p2 v.sel        v5, v0, v2
    s.addi       s1, s9, #0
    v.movi       v0, #0
    v.movi       v2, #0
    v.mov        v2, v0
for_1:
    s.cmp.ge     s2, s1, s10
    br.nz        s2, endfor_2
    s.movz       s2, #0
    s.movz       s5, #0
    s.cmp.lt     s8, s4, s2
    s.movz       s2, #128
    s.sub        s9, s5, s8
    s.movz       s5, #0
    s.movz       s8, #0
    s.cmp.lt     s12, s2, s5
    s.xor        s5, s4, s9
    s.sub        s13, s8, s12
    s.sub        s8, s5, s9
    s.xor        s5, s9, s13
    s.lshri      s9, s8, #7
    v.splat      v6, s1
    s.xor        s12, s9, s5
    v.iota       v7                              // arange(0, VLEN)
    s.sub        s14, s12, s5
    s.movz       s5, #64
    s.movz       s12, #16
    s.muli       s15, s14, #256
    v.add        v8, v6, v7
    v.movi       v6, #0
    v.splat      v7, s5
    v.splat      v9, s14
    v.movi       v10, #0
    v.splat      v11, s12
    s.muli       s5, s1, #4
    v.cmp.ge     p2, v8, v6
    v.cmp.lt     p3, v8, v7
    v.cmp.ge     p4, v9, v10
    v.cmp.lt     p5, v9, v11
    s.add        s12, s3, s15
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.add        s14, s12, s5
    p.and        p3, p6, p2
    v.splat      v6, s1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v7, [s14, #0]
    v.movi       v8, #128
    v.add        v9, v6, v1
    v.extract    s5, v5, #0
    v.movi       v6, #64
    v.mul        v10, v9, v8
    v.splat      v8, s5
    v.cmp.lt     p2, v9, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.add        v11, v8, v10
    v.sub        v8, v6, v3
    v.cmp.lt     p3, v3, v6
    v.movi       v10, #2
    @p3 v.sel        v12, v8, v3
    s.muli       s5, s9, #128
    v.sub        v8, v6, v10
    v.lshr       v13, v12, v9
    s.xor        s9, s2, s13
    v.cmp.lt     p4, v10, v6
    v.sub        v9, v6, v13
    s.sub        s2, s9, s13
    v.movi       v6, #8192
    @p3 v.sel        v12, v9, v13
    s.sub        s2, s8, s5
    v.extract    s2, v4, #0
    .li       s5, #1065353216
    v.splat      v9, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v13, s2
    v.mul        v14, v12, v6
    v.movi       v6, #1
    v.rcp.approx v12, v13                        // ISA 8.8: <= 2**-22 relative
    v.extract    s2, v14, #0
    v.movi       v14, #0
    v.splat      v15, s2
    v.movi       v16, #0
    @p1 v.sel        v17, v6, v14
    v.add        v6, v11, v15
    v.movi       v11, #1
    v.movi       v14, #0
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v15, [s6, v6]              // index is in elements (ISA sec 9.1)
    v.cmp.eq     p3, v17, v16
    @p3 v.sel        v6, v11, v14
    v.movi       v11, #0
    v.movi       v14, #1
    v.extract    s2, v6, #0
    v.movi       v6, #0
    v.splat      v14, s2
    s.add        s2, s1, s11
    @p4 v.sel        v16, v8, v10
    v.cmp.ne     p3, v14, v11
    s.movz       s5, #1
    s.movz       s8, #8192
    vf.cvt.bf16.f32 v8, v15
    vf.fms       v10, v13, v12, v9
    vf.fms       v9, v12, v10, v12
    vf.neg       v10, v9                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v10, v10
    @p4 v.sel        v9, v10, v12
    vf.mul       v10, v7, v9                     // a/y: faithful quotient
    vf.fms       v11, v10, v13, v7
    vf.fms       v7, v11, v9, v10
    vf.neg       v9, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p4, v9, v9
    @p4 v.sel        v7, v9, v10
    @p3 v.sel        v9, v0, v7
    vf.mul       v7, v9, v8
    vf.add       v8, v2, v7
    @p2 v.sel        v7, v8, v2
    v.mov        v6, v7
    v.mov        v2, v6
    s.mov        s1, s2
    br.nz        s5, for_1
endfor_2:
    vf.reduce.add.b v0, v2
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #1                      // element offset -> bytes (x2)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s7, s2                      // &out_ptr1[...]
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v0, v1
    @p1 v.st.h       [s1, #0], v3
__rctx_next:
    exit
