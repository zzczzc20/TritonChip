    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    v.movi       v0, #0
    v.movi       v1, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #128
    s.movz       s6, #16
    s.ld.d       s7, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.splat      v2, s4
    v.iota       v3                              // arange(0, VLEN)
    s.ld.d       s8, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.addi       s9, s2, #0
    s.ld.d       s2, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s10, [s1, #32]                  // out_ptr0: device_ptr64 at arg_base+32
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s9, s5
    br.nz        s1, endfor_2
    v.movi       v4, #0
    v.movi       v5, #5
    v.sub        v6, v4, v2
    v.cmp.lt     p1, v2, v4
    @p1 v.sel        v7, v6, v2
    v.movi       v6, #0
    v.lshr       v8, v7, v5
    v.movi       v5, #0
    v.sub        v7, v4, v8
    v.movi       v9, #63
    @p1 v.sel        v10, v7, v8
    v.sub        v7, v5, v2
    v.sub        v8, v6, v10
    v.cmp.lt     p1, v10, v6
    @p1 v.sel        v11, v8, v10
    v.cmp.lt     p2, v2, v5
    v.and        v8, v11, v9
    @p2 v.sel        v9, v7, v2
    v.movi       v7, #31
    v.sub        v10, v6, v8
    v.and        v11, v9, v7
    @p1 v.sel        v7, v10, v8
    v.movi       v8, #128
    v.sub        v9, v5, v11
    v.mul        v10, v7, v8
    @p2 v.sel        v7, v9, v11
    v.splat      v8, s9
    v.movi       v9, #8192
    v.extract    s1, v10, #0
    v.add        v10, v8, v3
    v.mul        v8, v7, v9
    v.splat      v7, s1
    v.movi       v9, #128
    v.extract    s1, v8, #0
    v.add        v8, v10, v7
    v.cmp.lt     p1, v10, v9
    v.splat      v7, s1
    v.movi       v9, #32
    v.add        v10, v8, v7
    v.movi       v7, #64
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s3, v10]              // index is in elements (ISA sec 9.1)
    v.sub        v11, v4, v9
    v.sub        v12, v6, v7
    v.sub        v13, v5, v9
    v.cmp.lt     p2, v9, v4
    v.cmp.lt     p3, v7, v6
    v.cmp.lt     p4, v9, v5
    v.movi       v4, #1
    v.movi       v4, #0
    v.movi       v5, #2048
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s8, v10]              // index is in elements (ISA sec 9.1)
    @p2 v.sel        v14, v11, v9
    v.sub        v11, v4, v2
    v.cmp.lt     p2, v2, v4
    @p2 v.sel        v14, v11, v2
    v.movi       v11, #11
    v.sub        v15, v4, v5
    v.movi       v16, #1
    v.lshr       v16, v14, v11
    v.movi       v11, #1
    @p3 v.sel        v14, v12, v7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s2, v10]              // index is in elements (ISA sec 9.1)
    v.sub        v12, v4, v16
    v.cmp.lt     p3, v5, v4
    @p2 v.sel        v4, v12, v16
    v.movi       v12, #0
    v.movi       v14, #1
    v.cmp.eq     p2, v4, v12
    v.movi       v12, #0
    v.movi       v16, #1
    @p2 v.sel        v16, v14, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v12, [s7, v10]             // index is in elements (ISA sec 9.1)
    v.movi       v10, #1
    v.cmp.eq     p2, v4, v11
    v.movi       v4, #0
    vf.add       v11, v6, v7
    v.extract    s1, v16, #0
    @p2 v.sel        v6, v10, v4
    v.splat      v4, s1
    v.movi       v7, #0
    v.extract    s1, v6, #0
    vf.add       v6, v8, v12
    v.cmp.ne     p2, v4, v7
    v.splat      v4, s1
    v.movi       v7, #0
    @p2 v.sel        v8, v11, v0
    @p4 v.sel        v10, v13, v9
    v.cmp.ne     p2, v4, v7
    @p2 v.sel        v4, v6, v8
    s.movz       s1, #8192
    vf.mul       v6, v4, v4
    v.movi       v4, #0
    s.add        s1, s9, s6
    s.movz       s11, #1
    vf.add       v7, v1, v6
    v.movi       v6, #1
    @p3 v.sel        v6, v15, v5
    @p1 v.sel        v5, v7, v1
    v.mov        v4, v5
    v.mov        v1, v4
    s.mov        s9, s1
    br.nz        s11, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.movz       s1, #1
    vf.add       v2, v0, v1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s10, s2                     // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
