    s.rdspecial  s1, arg_base
    s.movz       s2, #15
    s.ld.sw      s3, [s1, #48]                   // N: i32 at arg_base+48
    s.rdspecial  s4, pid.x
    s.rdspecial  s5, pid.y
    s.ld.sw      s6, [s1, #40]                   // M: i32 at arg_base+40
    s.add        s7, s6, s2
    s.ld.d       s2, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.movz       s8, #16
    s.ld.d       s9, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.movz       s10, #0
    s.ld.d       s11, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.movz       s12, #0
    s.ld.d       s13, [s1, #24]                  // As: device_ptr64 at arg_base+24
    s.cmp.lt     s14, s7, s12
    s.ld.d       s12, [s1, #32]                  // Bs: device_ptr64 at arg_base+32
    s.sub        s15, s10, s14
    s.movz       s10, #0
    s.movz       s14, #0
    s.ld.sw      s16, [s1, #56]                  // K: i32 at arg_base+56
    s.cmp.lt     s17, s8, s10
    s.ld.sw      s10, [s1, #64]                  // stride_am: i32 at arg_base+64
    s.sub        s18, s14, s17
    s.ld.sw      s14, [s1, #72]                  // stride_bn: i32 at arg_base+72
    s.xor        s17, s7, s15
    s.ld.sw      s7, [s1, #80]                   // stride_cm: i32 at arg_base+80
    s.sub        s19, s17, s15
    s.ld.sw      s17, [s1, #88]                  // stride_bs_n: i32 at arg_base+88
    s.movz       s1, #127
    s.movz       s20, #0
    s.add        s21, s3, s1
    s.movz       s22, #0
    s.cmp.lt     s23, s21, s20
    s.movz       s20, #128
    s.sub        s24, s22, s23
    s.movz       s22, #0
    s.lshri      s23, s19, #4
    s.xor        s25, s15, s18
    s.muli       s15, s23, #16
    s.xor        s26, s8, s18
    s.xor        s27, s23, s25
    s.sub        s23, s26, s18
    s.movz       s18, #0
    s.xor        s23, s21, s24
    s.cmp.lt     s21, s20, s18
    s.sub        s18, s19, s15
    s.sub        s15, s22, s21
    s.sub        s18, s23, s24
    s.xor        s19, s20, s15
    s.sub        s21, s27, s25
    s.lshri      s22, s18, #7
    s.xor        s23, s24, s15
    s.movz       s24, #8
    s.xor        s25, s22, s23
    s.movz       s26, #0
    s.sub        s27, s25, s23
    s.movz       s23, #0
    s.mul        s25, s4, s27
    s.mul        s4, s27, s24
    s.muli       s27, s22, #128
    s.sub        s22, s19, s15
    s.movz       s15, #0
    s.add        s19, s25, s5
    s.cmp.lt     s5, s4, s15
    s.movz       s15, #0
    s.cmp.lt     s22, s19, s26
    s.sub        s25, s23, s5
    s.sub        s5, s15, s22
    s.sub        s15, s18, s27
    s.xor        s15, s4, s25
    s.xor        s18, s19, s5
    s.sub        s22, s15, s25
    s.movz       s15, #0
    s.movz       s23, #1
    s.sub        s26, s18, s5
    s.movz       s18, #0
    s.addi       s27, s15, #0
    s.cmp.eq     s15, s22, s23
    s.addi       s23, s18, #0
    s.mov        s27, s26
    br.nz        s15, sdiv_done_1
    s.movz       s15, #0
    s.mov        s27, s15
    s.movz       s15, #31
    s.addi       s18, s15, #0
sdiv_2:
    s.lshr       s15, s26, s18
    s.andi       s28, s15, #1
    s.shli       s15, s23, #1
    s.or         s29, s15, s28
    s.movz       s15, #0
    s.cmp.geu    s28, s29, s22
    s.sub        s30, s15, s28
    s.and        s15, s22, s30
    s.sub        s28, s29, s15
    s.mov        s23, s28
    s.movz       s15, #1
    s.shl        s28, s15, s18
    s.and        s15, s28, s30
    s.or         s28, s27, s15
    s.mov        s27, s28
    s.subi       s15, s18, #1
    s.mov        s18, s15
    s.movz       s15, #0
    s.cmp.ge     s28, s18, s15
    br.nz        s28, sdiv_2
sdiv_done_1:
    s.xor        s15, s5, s25
    s.movz       s5, #0
    s.xor        s18, s27, s15
    s.movz       s22, #0
    s.cmp.lt     s23, s4, s5
    s.sub        s5, s18, s15
    s.movz       s15, #0
    s.cmp.lt     s18, s19, s22
    s.sub        s22, s15, s23
    s.movz       s15, #0
    s.mul        s23, s5, s24
    s.sub        s5, s15, s18
    s.xor        s15, s4, s22
    s.xor        s4, s19, s5
    s.sub        s18, s15, s22
    s.movz       s15, #0
    s.sub        s19, s21, s23
    s.sub        s21, s4, s5
    s.movz       s4, #0
    s.addi       s22, s15, #0
    s.min.s      s15, s19, s24
    s.movz       s19, #1
    s.addi       s24, s4, #0
    s.cmp.eq     s4, s18, s19
    s.mov        s22, s21
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.mov        s22, s4
    s.movz       s4, #31
    s.addi       s19, s4, #0
sdiv_4:
    s.lshr       s4, s21, s19
    s.andi       s25, s4, #1
    s.shli       s4, s24, #1
    s.or         s26, s4, s25
    s.movz       s4, #0
    s.cmp.geu    s25, s26, s18
    s.sub        s27, s4, s25
    s.and        s4, s18, s27
    s.sub        s25, s26, s4
    s.mov        s24, s25
    s.movz       s4, #1
    s.shl        s25, s4, s19
    s.and        s4, s25, s27
    s.or         s25, s22, s4
    s.mov        s22, s25
    s.subi       s4, s19, #1
    s.mov        s19, s4
    s.movz       s4, #0
    s.cmp.ge     s25, s19, s4
    br.nz        s25, sdiv_4
sdiv_done_3:
    s.xor        s4, s24, s5
    s.movz       s18, #0
    s.sub        s19, s4, s5
    s.movz       s4, #0
    s.movz       s5, #0
    s.cmp.lt     s21, s15, s18
    s.movz       s18, #0
    s.cmp.lt     s22, s19, s4
    s.sub        s4, s5, s21
    s.sub        s5, s18, s22
    s.xor        s18, s15, s4
    s.xor        s21, s19, s5
    s.sub        s22, s18, s4
    s.movz       s4, #0
    s.movz       s18, #1
    s.sub        s24, s21, s5
    s.movz       s21, #0
    s.addi       s25, s4, #0
    s.cmp.eq     s4, s22, s18
    s.addi       s18, s21, #0
    s.mov        s25, s24
    br.nz        s4, sdiv_done_5
    s.movz       s4, #0
    s.mov        s25, s4
    s.movz       s4, #31
    s.addi       s21, s4, #0
sdiv_6:
    s.lshr       s4, s24, s21
    s.andi       s26, s4, #1
    s.shli       s4, s18, #1
    s.or         s27, s4, s26
    s.movz       s4, #0
    s.cmp.geu    s26, s27, s22
    s.sub        s28, s4, s26
    s.and        s4, s22, s28
    s.sub        s26, s27, s4
    s.mov        s18, s26
    s.movz       s4, #1
    s.shl        s26, s4, s21
    s.and        s4, s26, s28
    s.or         s26, s25, s4
    s.mov        s25, s26
    s.subi       s4, s21, #1
    s.mov        s21, s4
    s.movz       s4, #0
    s.cmp.ge     s26, s21, s4
    br.nz        s26, sdiv_6
sdiv_done_5:
    s.movz       s4, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.cmp.lt     s24, s15, s4
    s.cmp.lt     s4, s19, s21
    s.sub        s21, s22, s24
    s.movz       s22, #0
    s.xor        s24, s15, s21
    s.sub        s15, s22, s4
    s.xor        s4, s18, s5
    s.xor        s18, s19, s15
    s.sub        s19, s24, s21
    s.movz       s22, #0
    s.sub        s24, s4, s5
    s.sub        s4, s18, s15
    s.movz       s5, #0
    s.addi       s18, s22, #0
    s.add        s22, s23, s24
    s.movz       s23, #1
    s.addi       s24, s5, #0
    s.cmp.eq     s5, s19, s23
    s.mov        s18, s4
    br.nz        s5, sdiv_done_7
    s.movz       s5, #0
    s.mov        s18, s5
    s.movz       s5, #31
    s.addi       s23, s5, #0
sdiv_8:
    s.lshr       s5, s4, s23
    s.andi       s25, s5, #1
    s.shli       s5, s24, #1
    s.or         s26, s5, s25
    s.movz       s5, #0
    s.cmp.geu    s25, s26, s19
    s.sub        s27, s5, s25
    s.and        s5, s19, s27
    s.sub        s25, s26, s5
    s.mov        s24, s25
    s.movz       s5, #1
    s.shl        s25, s5, s23
    s.and        s5, s25, s27
    s.or         s25, s18, s5
    s.mov        s18, s25
    s.subi       s5, s23, #1
    s.mov        s23, s5
    s.movz       s5, #0
    s.cmp.ge     s25, s23, s5
    br.nz        s25, sdiv_8
sdiv_done_7:
    s.mul        s4, s22, s8
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s5, s15, s21
    v.splat      v1, s6
    v.movi       v2, #0
    v.splat      v3, s4
    s.xor        s15, s18, s5
    v.add        v4, v3, v0
    v.sub        v0, v2, v1
    v.sub        v3, v2, v4
    v.cmp.lt     p1, v4, v2
    v.cmp.lt     p2, v1, v2
    s.sub        s18, s15, s5
    v.movi       v5, #1
    @p1 v.sel        v6, v3, v4
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #0
    v.movi       v1, #0
    s.movz       s5, #31
idiv_9:
    v.splat      v4, s5
    v.shl        v7, v1, v5
    v.lshr       v8, v6, v4
    v.cmp.lt     p2, v1, v2
    v.and        v9, v8, v5
    v.shl        v8, v5, v4
    v.or         v4, v7, v9
    s.subi       s15, s5, #1
    v.cmp.geu    p3, v4, v3
    p.or         p4, p2, p3
    v.sub        v7, v4, v3
    @p4 v.sel        v9, v8, v2
    @p4 v.sel        v8, v7, v4
    v.or         v4, v0, v9
    v.mov        v1, v8
    v.mov        v0, v4
    s.mov        s5, s15
    s.movz       s15, #0
    s.cmp.ge     s19, s5, s15
    br.nz        s19, idiv_9
    s.mul        s5, s18, s20
    v.iota       v0                              // arange(0, VLEN)
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #16
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #32
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #48
    v.iota       v9                              // arange(0, VLEN)
    v.movi       v10, #64
    v.sub        v11, v2, v1
    v.iota       v2                              // arange(0, VLEN)
    v.add        v12, v3, v4
    v.add        v3, v5, v6
    v.add        v4, v7, v8
    v.add        v5, v9, v10
    @p1 v.sel        v6, v11, v1
    v.splat      v1, s5
    v.movi       v7, #80
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #96
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #112
    v.add        v13, v1, v0
    v.add        v0, v2, v7
    v.add        v1, v8, v9
    v.add        v2, v10, v11
    v.splat      v7, s3
    v.splat      v8, s5
    v.splat      v9, s5
    v.splat      v10, s5
    v.splat      v11, s5
    v.splat      v14, s5
    v.splat      v15, s5
    v.splat      v16, s5
    v.movi       v17, #0
    v.add        v18, v8, v12
    v.add        v8, v9, v3
    v.cmp.lt     p1, v13, v17
    v.add        v3, v10, v4
    v.cmp.lt     p2, v7, v17
    v.add        v4, v11, v5
    v.sub        v5, v17, v13
    v.add        v9, v14, v0
    v.add        v0, v15, v1
    v.sub        v1, v17, v7
    v.add        v10, v16, v2
    v.splat      v2, s3
    v.splat      v11, s3
    v.splat      v12, s3
    v.splat      v14, s3
    v.splat      v15, s3
    v.splat      v16, s3
    v.splat      v19, s3
    v.movi       v20, #1
    @p1 v.sel        v21, v5, v13
    @p2 v.sel        v5, v1, v7
    v.movi       v1, #0
    v.movi       v7, #0
    s.movz       s15, #31
idiv_10:
    v.splat      v13, s15
    v.shl        v22, v7, v20
    v.lshr       v23, v21, v13
    v.cmp.lt     p2, v7, v17
    v.and        v24, v23, v20
    v.shl        v23, v20, v13
    v.or         v13, v22, v24
    s.subi       s18, s15, #1
    v.cmp.geu    p3, v13, v5
    p.or         p4, p2, p3
    v.sub        v22, v13, v5
    @p4 v.sel        v24, v23, v17
    @p4 v.sel        v23, v22, v13
    v.or         v13, v1, v24
    v.mov        v7, v23
    v.mov        v1, v13
    s.mov        s15, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s15, s18
    br.nz        s19, idiv_10
    v.movi       v1, #0
    v.sub        v5, v17, v7
    v.sub        v13, v1, v18
    v.sub        v17, v1, v2
    v.cmp.lt     p2, v18, v1
    @p1 v.sel        v20, v5, v7
    v.cmp.lt     p1, v2, v1
    v.movi       v5, #1
    @p2 v.sel        v7, v13, v18
    @p1 v.sel        v13, v17, v2
    v.movi       v2, #0
    v.movi       v17, #0
    s.movz       s15, #31
idiv_11:
    v.splat      v18, s15
    v.shl        v21, v17, v5
    v.lshr       v22, v7, v18
    v.cmp.lt     p1, v17, v1
    v.and        v23, v22, v5
    v.shl        v22, v5, v18
    v.or         v18, v21, v23
    s.subi       s18, s15, #1
    v.cmp.geu    p3, v18, v13
    p.or         p4, p1, p3
    v.sub        v21, v18, v13
    @p4 v.sel        v23, v22, v1
    @p4 v.sel        v22, v21, v18
    v.or         v18, v2, v23
    v.mov        v17, v22
    v.mov        v2, v18
    s.mov        s15, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s15, s18
    br.nz        s19, idiv_11
    v.movi       v2, #0
    v.sub        v5, v1, v17
    v.sub        v1, v2, v8
    v.sub        v7, v2, v11
    v.cmp.lt     p1, v8, v2
    @p2 v.sel        v13, v5, v17
    v.cmp.lt     p2, v11, v2
    v.movi       v5, #1
    @p1 v.sel        v17, v1, v8
    @p2 v.sel        v1, v7, v11
    v.movi       v7, #0
    v.movi       v8, #0
    s.movz       s15, #31
idiv_12:
    v.splat      v11, s15
    v.shl        v18, v8, v5
    v.lshr       v21, v17, v11
    v.cmp.lt     p2, v8, v2
    v.and        v22, v21, v5
    v.shl        v21, v5, v11
    v.or         v11, v18, v22
    s.subi       s18, s15, #1
    v.cmp.geu    p3, v11, v1
    p.or         p4, p2, p3
    v.sub        v18, v11, v1
    @p4 v.sel        v22, v21, v2
    @p4 v.sel        v21, v18, v11
    v.or         v11, v7, v22
    v.mov        v8, v21
    v.mov        v7, v11
    s.mov        s15, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s15, s18
    br.nz        s19, idiv_12
    v.movi       v1, #0
    v.sub        v5, v2, v8
    v.sub        v2, v1, v3
    v.sub        v7, v1, v12
    v.cmp.lt     p2, v3, v1
    @p1 v.sel        v11, v5, v8
    v.cmp.lt     p1, v12, v1
    v.movi       v5, #1
    @p2 v.sel        v8, v2, v3
    @p1 v.sel        v2, v7, v12
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s15, #31
idiv_13:
    v.splat      v12, s15
    v.shl        v17, v7, v5
    v.lshr       v18, v8, v12
    v.cmp.lt     p1, v7, v1
    v.and        v21, v18, v5
    v.shl        v18, v5, v12
    v.or         v12, v17, v21
    s.subi       s18, s15, #1
    v.cmp.geu    p3, v12, v2
    p.or         p4, p1, p3
    v.sub        v17, v12, v2
    @p4 v.sel        v21, v18, v1
    @p4 v.sel        v18, v17, v12
    v.or         v12, v3, v21
    v.mov        v7, v18
    v.mov        v3, v12
    s.mov        s15, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s15, s18
    br.nz        s19, idiv_13
    v.movi       v2, #0
    v.sub        v3, v1, v7
    v.sub        v1, v2, v4
    v.sub        v5, v2, v14
    v.cmp.lt     p1, v4, v2
    @p2 v.sel        v8, v3, v7
    v.cmp.lt     p2, v14, v2
    v.movi       v3, #1
    @p1 v.sel        v7, v1, v4
    @p2 v.sel        v1, v5, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s15, #31
idiv_14:
    v.splat      v12, s15
    v.shl        v14, v5, v3
    v.lshr       v17, v7, v12
    v.cmp.lt     p2, v5, v2
    v.and        v18, v17, v3
    v.shl        v17, v3, v12
    v.or         v12, v14, v18
    s.subi       s18, s15, #1
    v.cmp.geu    p3, v12, v1
    p.or         p4, p2, p3
    v.sub        v14, v12, v1
    @p4 v.sel        v18, v17, v2
    @p4 v.sel        v17, v14, v12
    v.or         v12, v4, v18
    v.mov        v5, v17
    v.mov        v4, v12
    s.mov        s15, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s15, s18
    br.nz        s19, idiv_14
    v.movi       v1, #0
    v.sub        v3, v2, v5
    v.sub        v2, v1, v9
    v.sub        v4, v1, v15
    v.cmp.lt     p2, v9, v1
    @p1 v.sel        v7, v3, v5
    v.cmp.lt     p1, v15, v1
    v.movi       v3, #1
    @p2 v.sel        v5, v2, v9
    @p1 v.sel        v2, v4, v15
    v.movi       v4, #0
    v.movi       v9, #0
    s.movz       s15, #31
idiv_15:
    v.splat      v12, s15
    v.shl        v14, v9, v3
    v.lshr       v15, v5, v12
    v.cmp.lt     p1, v9, v1
    v.and        v17, v15, v3
    v.shl        v15, v3, v12
    v.or         v12, v14, v17
    s.subi       s18, s15, #1
    v.cmp.geu    p3, v12, v2
    p.or         p4, p1, p3
    v.sub        v14, v12, v2
    @p4 v.sel        v17, v15, v1
    @p4 v.sel        v15, v14, v12
    v.or         v12, v4, v17
    v.mov        v9, v15
    v.mov        v4, v12
    s.mov        s15, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s15, s18
    br.nz        s19, idiv_15
    v.movi       v2, #0
    v.sub        v3, v1, v9
    v.sub        v1, v2, v0
    v.sub        v4, v2, v16
    v.cmp.lt     p1, v0, v2
    @p2 v.sel        v5, v3, v9
    v.cmp.lt     p2, v16, v2
    v.movi       v3, #1
    @p1 v.sel        v9, v1, v0
    @p2 v.sel        v0, v4, v16
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s15, #31
idiv_16:
    v.splat      v12, s15
    v.shl        v14, v4, v3
    v.lshr       v15, v9, v12
    v.cmp.lt     p2, v4, v2
    v.and        v16, v15, v3
    v.shl        v15, v3, v12
    v.or         v12, v14, v16
    s.subi       s18, s15, #1
    v.cmp.geu    p3, v12, v0
    p.or         p4, p2, p3
    v.sub        v14, v12, v0
    @p4 v.sel        v16, v15, v2
    @p4 v.sel        v15, v14, v12
    v.or         v12, v1, v16
    v.mov        v4, v15
    v.mov        v1, v12
    s.mov        s15, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s15, s18
    br.nz        s19, idiv_16
    v.movi       v0, #0
    v.sub        v1, v2, v4
    v.sub        v2, v0, v10
    v.sub        v3, v0, v19
    v.cmp.lt     p2, v10, v0
    @p1 v.sel        v9, v1, v4
    v.cmp.lt     p1, v19, v0
    v.movi       v1, #1
    @p2 v.sel        v4, v2, v10
    @p1 v.sel        v2, v3, v19
    v.movi       v3, #0
    v.movi       v10, #0
    s.movz       s15, #31
idiv_17:
    v.splat      v12, s15
    v.shl        v14, v10, v1
    v.lshr       v15, v4, v12
    v.cmp.lt     p1, v10, v0
    v.and        v16, v15, v1
    v.shl        v15, v1, v12
    v.or         v12, v14, v16
    s.subi       s18, s15, #1
    v.cmp.geu    p3, v12, v2
    p.or         p4, p1, p3
    v.sub        v14, v12, v2
    @p4 v.sel        v16, v15, v0
    @p4 v.sel        v15, v14, v12
    v.or         v12, v3, v16
    v.mov        v10, v15
    v.mov        v3, v12
    s.mov        s15, s18
    s.movz       s18, #0
    s.cmp.ge     s19, s15, s18
    br.nz        s19, idiv_17
    v.sub        v1, v0, v10
    v.movi       v0, #0
    @p2 v.sel        v2, v1, v10
    v.sub        v1, v0, v20
    v.cmp.lt     p1, v20, v0
    @p1 v.sel        v3, v1, v20
    v.movi       v1, #7
    v.movi       v4, #128
    s.movz       s15, #32
    v.lshr       v10, v3, v1
    v.sub        v1, v0, v4
    v.cmp.lt     p2, v4, v0
    s.movz       s18, #48
    v.sub        v3, v0, v10
    s.movz       s19, #64
    @p1 v.sel        v0, v3, v10
    s.movz       s21, #80
    v.movi       v3, #128
    s.movz       s22, #96
    v.movi       v10, #0
    s.movz       s23, #112
    v.cmp.lt     p1, v13, v10
    v.movi       v12, #1
    v.sub        v12, v10, v13
    v.movi       v14, #7
    @p1 v.sel        v15, v12, v13
    v.sub        v12, v10, v3
    v.lshr       v16, v15, v14
    @p2 v.sel        v14, v1, v4
    v.movi       v1, #0
    v.sub        v4, v10, v16
    v.cmp.lt     p2, v11, v1
    v.movi       v14, #128
    @p1 v.sel        v15, v4, v16
    v.cmp.lt     p1, v3, v10
    v.movi       v4, #1
    v.sub        v4, v1, v11
    v.movi       v10, #7
    @p2 v.sel        v16, v4, v11
    v.sub        v4, v1, v14
    v.lshr       v17, v16, v10
    @p1 v.sel        v10, v12, v3
    v.movi       v3, #0
    v.sub        v10, v1, v17
    v.cmp.lt     p1, v8, v3
    v.movi       v12, #128
    @p2 v.sel        v16, v10, v17
    v.cmp.lt     p2, v14, v1
    v.movi       v1, #1
    v.sub        v1, v3, v8
    v.movi       v10, #7
    @p1 v.sel        v17, v1, v8
    v.sub        v1, v3, v12
    v.lshr       v18, v17, v10
    @p2 v.sel        v10, v4, v14
    v.movi       v4, #0
    v.sub        v10, v3, v18
    v.cmp.lt     p2, v7, v4
    v.movi       v14, #128
    @p1 v.sel        v17, v10, v18
    v.cmp.lt     p1, v12, v3
    v.movi       v3, #1
    v.sub        v3, v4, v7
    v.movi       v10, #7
    @p2 v.sel        v18, v3, v7
    v.sub        v3, v4, v14
    v.lshr       v19, v18, v10
    @p1 v.sel        v10, v1, v12
    v.movi       v1, #0
    v.sub        v10, v4, v19
    v.cmp.lt     p1, v5, v1
    v.movi       v12, #128
    @p2 v.sel        v18, v10, v19
    v.cmp.lt     p2, v14, v4
    v.movi       v4, #1
    v.sub        v4, v1, v5
    v.movi       v10, #7
    @p1 v.sel        v19, v4, v5
    v.sub        v4, v1, v12
    v.lshr       v21, v19, v10
    @p2 v.sel        v10, v3, v14
    v.movi       v3, #0
    v.sub        v10, v1, v21
    v.cmp.lt     p2, v9, v3
    v.movi       v14, #128
    @p1 v.sel        v19, v10, v21
    v.cmp.lt     p1, v12, v1
    v.movi       v1, #1
    v.sub        v1, v3, v9
    v.movi       v10, #7
    @p2 v.sel        v21, v1, v9
    v.sub        v1, v3, v14
    v.lshr       v22, v21, v10
    @p1 v.sel        v10, v4, v12
    v.movi       v4, #0
    v.sub        v10, v3, v22
    v.cmp.lt     p1, v2, v4
    v.movi       v12, #128
    @p2 v.sel        v21, v10, v22
    v.cmp.lt     p2, v14, v3
    v.movi       v3, #1
    v.sub        v3, v4, v2
    v.movi       v10, #7
    @p1 v.sel        v22, v3, v2
    v.sub        v3, v4, v12
    v.lshr       v23, v22, v10
    @p2 v.sel        v10, v1, v14
    v.sub        v1, v4, v23
    v.splat      v10, s17
    @p1 v.sel        v14, v1, v23
    v.splat      v1, s17
    v.splat      v22, s17
    v.splat      v23, s17
    v.splat      v24, s17
    v.cmp.lt     p1, v12, v4
    v.movi       v4, #1
    v.splat      v4, s17
    @p1 v.sel        v25, v3, v12
    s.add        s24, s16, s1
    s.movz       s1, #0
    s.movz       s25, #0
    s.cmp.lt     s26, s24, s1
    v.splat      v3, s17
    s.sub        s1, s25, s26
    s.movz       s25, #0
    v.splat      v12, s17
    s.movz       s17, #0
    v.mul        v25, v0, v10
    s.cmp.lt     s26, s20, s17
    v.mul        v0, v15, v1
    s.sub        s17, s25, s26
    v.mul        v1, v16, v22
    s.xor        s25, s24, s1
    v.mul        v10, v17, v23
    s.sub        s24, s25, s1
    v.mul        v15, v18, v24
    s.xor        s25, s20, s17
    v.mul        v16, v19, v4
    v.mul        v4, v21, v3
    s.lshri      s26, s24, #7
    v.mul        v3, v14, v12
    s.muli       s27, s26, #128
    s.ld.w       s28, [s13, #0]                  // one element, not a vector
    s.xor        s13, s1, s17
    s.sub        s1, s25, s17
    s.xor        s1, s26, s13
    s.movz       s17, #0
    s.movz       s25, #0
    s.sub        s26, s24, s27
    s.movz       s24, #0
    s.sub        s26, s1, s13
    s.movz       s1, #1
    s.addi       s13, s17, #0
    s.addi       s27, s25, #0
    s.addi       s25, s24, #0
    s.addi       s24, s12, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_26:
    s.cmp.ge     s12, s13, s26
    br.nz        s12, endfor_27
    s.mul        s12, s13, s20
    s.sub        s29, s16, s12
    v.splat      v12, s28
    v.splat      v14, s14
    v.mul        v17, v20, v14
    v.splat      v14, s14
    v.mul        v18, v13, v14
    v.splat      v14, s14
    v.mul        v19, v11, v14
    v.splat      v14, s14
    v.mul        v21, v8, v14
    v.splat      v14, s14
    v.mul        v22, v7, v14
    v.splat      v14, s14
    v.mul        v23, v5, v14
    v.splat      v14, s14
    v.mul        v24, v9, v14
    v.splat      v14, s14
    v.mul        v26, v2, v14
    v.ld.gather.w v14, [s24, v25]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v27, [s24, v0]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v28, [s24, v1]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v29, [s24, v10]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v30, [s24, v15]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v31, [s24, v16]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v32, [s24, v4]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v33, [s24, v3]                 // index is in elements (ISA sec 9.1)
    s.add        s12, s17, s29
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s30, arg_base
    s.ld.d       s31, [s30, #96]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.movi       v34, #0
    v.movi       v35, #0
    v.iota       v36                             // arange(0, VLEN)
    s.movz       s30, #0
    s.cmp.ge     s32, s12, s30
    v.extract    s30, v20, #0
    v.splat      v37, s30
    v.add        v38, v37, v36
    v.sub        v37, v20, v38
    v.reduce.or  s33, v37
    s.movz       s34, #0
    s.cmp.eq     s35, s33, s34
    s.movz       s33, #0
    s.cmp.ge     s34, s30, s33
    s.and        s33, s35, s34
    s.and        s34, s33, s32
    v.insert     v34, s34, #0
    v.insert     v35, s30, #0
    v.extract    s30, v13, #0
    v.splat      v37, s30
    v.add        v38, v37, v36
    v.sub        v37, v13, v38
    v.reduce.or  s33, v37
    s.movz       s34, #0
    s.cmp.eq     s35, s33, s34
    s.movz       s33, #0
    s.cmp.ge     s34, s30, s33
    s.and        s33, s35, s34
    s.and        s34, s33, s32
    v.insert     v34, s34, #1
    v.insert     v35, s30, #1
    v.extract    s30, v11, #0
    v.splat      v37, s30
    v.add        v38, v37, v36
    v.sub        v37, v11, v38
    v.reduce.or  s33, v37
    s.movz       s34, #0
    s.cmp.eq     s35, s33, s34
    s.movz       s33, #0
    s.cmp.ge     s34, s30, s33
    s.and        s33, s35, s34
    s.and        s34, s33, s32
    v.insert     v34, s34, #2
    v.insert     v35, s30, #2
    v.extract    s30, v8, #0
    v.splat      v37, s30
    v.add        v38, v37, v36
    v.sub        v37, v8, v38
    v.reduce.or  s33, v37
    s.movz       s34, #0
    s.cmp.eq     s35, s33, s34
    s.movz       s33, #0
    s.cmp.ge     s34, s30, s33
    s.and        s33, s35, s34
    s.and        s34, s33, s32
    v.insert     v34, s34, #3
    v.insert     v35, s30, #3
    v.extract    s30, v7, #0
    v.splat      v37, s30
    v.add        v38, v37, v36
    v.sub        v37, v7, v38
    v.reduce.or  s33, v37
    s.movz       s34, #0
    s.cmp.eq     s35, s33, s34
    s.movz       s33, #0
    s.cmp.ge     s34, s30, s33
    s.and        s33, s35, s34
    s.and        s34, s33, s32
    v.insert     v34, s34, #4
    v.insert     v35, s30, #4
    v.extract    s30, v5, #0
    v.splat      v37, s30
    v.add        v38, v37, v36
    v.sub        v37, v5, v38
    v.reduce.or  s33, v37
    s.movz       s34, #0
    s.cmp.eq     s35, s33, s34
    s.movz       s33, #0
    s.cmp.ge     s34, s30, s33
    s.and        s33, s35, s34
    s.and        s34, s33, s32
    v.insert     v34, s34, #5
    v.insert     v35, s30, #5
    v.extract    s30, v9, #0
    v.splat      v37, s30
    v.add        v38, v37, v36
    v.sub        v37, v9, v38
    v.reduce.or  s33, v37
    s.movz       s34, #0
    s.cmp.eq     s35, s33, s34
    s.movz       s33, #0
    s.cmp.ge     s34, s30, s33
    s.and        s33, s35, s34
    s.and        s34, s33, s32
    v.insert     v34, s34, #6
    v.insert     v35, s30, #6
    v.extract    s30, v2, #0
    v.splat      v37, s30
    v.add        v38, v37, v36
    v.sub        v36, v2, v38
    v.reduce.or  s33, v36
    s.movz       s34, #0
    s.cmp.eq     s35, s33, s34
    s.movz       s33, #0
    s.cmp.ge     s34, s30, s33
    s.and        s33, s35, s34
    s.and        s34, s33, s32
    v.insert     v34, s34, #7
    v.insert     v35, s30, #7
    s.add        s30, s9, s25
    s.addi       s32, s31, #0                    // TensorMap 0: W's rows for a transposed FP8 B
    s.movz       s33, #0
    s.st.d       [s32, #0], s30
    .li       s30, #2147483647
    s.st.d       [s32, #8], s30
    s.st.d       [s32, #16], s12
    s.st.d       [s32, #48], s14
    s.movz       s30, #1
    s.st.d       [s32, #56], s30
    .li       s30, #137438953488
    s.st.d       [s32, #88], s30
    .li       s30, #7705171329024
    s.st.d       [s32, #104], s30
    td.load      d0, [s32]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s30, s31, #256
    s.addi       s32, s31, #768                  // TensorMap 1: the gathered fallback B tile
    s.movz       s33, #0
    s.st.d       [s32, #0], s30
    s.movz       s30, #32
    s.st.d       [s32, #8], s30
    s.movz       s30, #16
    s.st.d       [s32, #16], s30
    s.movz       s30, #16
    s.st.d       [s32, #48], s30
    s.movz       s30, #1
    s.st.d       [s32, #56], s30
    .li       s30, #68719476768
    s.st.d       [s32, #88], s30
    .li       s30, #7705171329024
    s.st.d       [s32, #104], s30
    td.load      d1, [s32]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    s.addi       s30, s31, #1024                 // 512 bytes of repack scratch
    s.muli       s32, s10, #2
    s.muli       s33, s27, #2
    v.splat      v36, s32
    v.mul        v37, v6, v36
    v.extract    s32, v37, #0
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.iota       v36                             // arange(0, VLEN)
    s.movz       s34, #0
    s.add        s35, s34, s29                   // the tile origin
    v.splat      v38, s35
    v.cmp.lt     p1, v36, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v39, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    .li       s32, #1065353216
    v.splat      v40, s32                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v41, v12, v38, v40
    vf.fms       v42, v38, v41, v38
    vf.neg       v41, v42                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v42, v41, v38
    vf.mul       v38, v39, v42                   // a/y: faithful quotient
    vf.fms       v41, v38, v12, v39
    vf.fms       v39, v41, v42, v38
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v39, v41, v38
    vf.cvt.f32.e4m3 v38, v39
    v.movi       v41, #24
    v.lshr       v42, v39, v41
    v.movi       v39, #128
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #0
    v.st.b       [s32, #0], v42
    v.extract    s32, v37, #1
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #32
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #2
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #64
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #3
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #96
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #4
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #128
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #5
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #160
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #6
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #192
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #7
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #224
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #8
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #256
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #9
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #288
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #10
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #320
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #11
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #352
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #12
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #384
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #13
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #416
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #14
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #448
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #15
    s.add        s34, s32, s33
    s.add        s32, s2, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s32, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #480
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #0
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    s.movz       s32, #0
    s.add        s35, s32, s8                    // the tile origin
    v.splat      v38, s35
    v.add        v42, v36, v38
    s.movz       s32, #0
    s.add        s35, s32, s29                   // the tile origin
    v.splat      v38, s35
    v.cmp.lt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #16
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #1
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #48
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #2
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #80
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #3
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #112
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #4
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #144
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #5
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #176
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #6
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #208
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #7
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #240
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #8
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #272
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #9
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #304
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #10
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #336
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #11
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #368
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #12
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #400
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #13
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #432
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #14
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #464
    v.st.b       [s32, #0], v43
    v.extract    s32, v37, #15
    s.add        s34, s32, s33
    s.addi       s32, s34, #32
    s.add        s34, s2, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s34, #0]
    vf.cvt.bf16.f32 v42, v38
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v12, v38, v40
    vf.fms       v44, v38, v43, v38
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v38
    vf.mul       v38, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v38, v12, v42
    vf.fms       v42, v43, v44, v38
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v38
    vf.cvt.f32.e4m3 v38, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v38, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #496
    v.st.b       [s32, #0], v43
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v38, [s30, #0]
    v.mov        v48, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #64
    v.ld.w       v38, [s32, #0]
    v.mov        v49, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #128
    v.ld.w       v38, [s32, #0]
    v.mov        v50, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #192
    v.ld.w       v38, [s32, #0]
    v.mov        v51, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #256
    v.ld.w       v38, [s32, #0]
    v.mov        v52, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #320
    v.ld.w       v38, [s32, #0]
    v.mov        v53, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #384
    v.ld.w       v38, [s32, #0]
    v.mov        v54, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #448
    v.ld.w       v38, [s32, #0]
    v.mov        v55, v38                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s30, v34, #0
    br.nz        s30, x8dot_done_28
    s.movz       s32, #0
    s.add        s34, s9, s25
    s.addi       s35, s32, #0
    s.addi       s32, s31, #256
x8dot_row_29:
    s.addi       s36, s12, #0
    v.movi       v38, #0
    s.sub        s37, s36, s35
    s.add        s36, s34, s35
    v.splat      v42, s37
    s.shli       s37, s35, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s36, v17]            // index is in elements (ISA sec 9.1)
    s.add        s36, s32, s37
    s.addi       s37, s35, #1
    s.movz       s38, #32
    v.st.b       [s36, #0], v38
    fence.acq_rel.device
    s.mov        s35, s37
    s.cmp.lt     s36, s35, s38
    br.nz        s36, x8dot_row_29
x8dot_done_28:
    v.splat      v38, s30
    v.movi       v42, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s30
    v.movi       v42, #0
    s.movz       s30, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s32            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s30, #0
    v.extract    s34, v35, #0
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v34, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s30
    mb.wait      s30
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_30
    s.movz       s35, #0
    s.add        s36, s9, s25
    s.addi       s37, s35, #0
    s.addi       s35, s31, #256
x8dot_row_31:
    s.addi       s38, s12, #0
    v.movi       v38, #0
    s.sub        s39, s38, s37
    s.add        s38, s36, s37
    v.splat      v42, s39
    s.shli       s39, s37, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s38, v18]            // index is in elements (ISA sec 9.1)
    s.add        s38, s35, s39
    s.addi       s39, s37, #1
    s.movz       s40, #32
    v.st.b       [s38, #0], v38
    fence.acq_rel.device
    s.mov        s37, s39
    s.cmp.lt     s38, s37, s40
    br.nz        s38, x8dot_row_31
x8dot_done_30:
    v.splat      v38, s34
    v.movi       v42, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s34
    v.movi       v42, #0
    s.movz       s34, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s35            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s34, #0
    v.extract    s36, v35, #1
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v34, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_32
    s.movz       s37, #0
    s.add        s38, s9, s25
    s.addi       s39, s37, #0
    s.addi       s37, s31, #256
x8dot_row_33:
    s.addi       s40, s12, #0
    v.movi       v38, #0
    s.sub        s41, s40, s39
    s.add        s40, s38, s39
    v.splat      v42, s41
    s.shli       s41, s39, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s40, v19]            // index is in elements (ISA sec 9.1)
    s.add        s40, s37, s41
    s.addi       s41, s39, #1
    s.movz       s42, #32
    v.st.b       [s40, #0], v38
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s40, s39, s42
    br.nz        s40, x8dot_row_33
x8dot_done_32:
    v.splat      v38, s36
    v.movi       v42, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s36
    v.movi       v42, #0
    s.movz       s36, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s37            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s36, #0
    v.extract    s38, v35, #2
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v34, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_34
    s.movz       s39, #0
    s.add        s40, s9, s25
    s.addi       s41, s39, #0
    s.addi       s39, s31, #256
x8dot_row_35:
    s.addi       s42, s12, #0
    v.movi       v38, #0
    s.sub        s43, s42, s41
    s.add        s42, s40, s41
    v.splat      v42, s43
    s.shli       s43, s41, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s42, v21]            // index is in elements (ISA sec 9.1)
    s.add        s42, s39, s43
    s.addi       s43, s41, #1
    s.movz       s44, #32
    v.st.b       [s42, #0], v38
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s42, s41, s44
    br.nz        s42, x8dot_row_35
x8dot_done_34:
    v.splat      v38, s38
    v.movi       v42, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s38
    v.movi       v42, #0
    s.movz       s38, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s38, #0
    v.extract    s40, v35, #3
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v34, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_36
    s.movz       s41, #0
    s.add        s42, s9, s25
    s.addi       s43, s41, #0
    s.addi       s41, s31, #256
x8dot_row_37:
    s.addi       s44, s12, #0
    v.movi       v38, #0
    s.sub        s45, s44, s43
    s.add        s44, s42, s43
    v.splat      v42, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s44, v22]            // index is in elements (ISA sec 9.1)
    s.add        s44, s41, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v38
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_37
x8dot_done_36:
    v.splat      v38, s40
    v.movi       v42, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s40
    v.movi       v42, #0
    s.movz       s40, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s40, #0
    v.extract    s42, v35, #4
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v34, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_38
    s.movz       s43, #0
    s.add        s44, s9, s25
    s.addi       s45, s43, #0
    s.addi       s43, s31, #256
x8dot_row_39:
    s.addi       s46, s12, #0
    v.movi       v38, #0
    s.sub        s47, s46, s45
    s.add        s46, s44, s45
    v.splat      v42, s47
    s.shli       s47, s45, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s46, v23]            // index is in elements (ISA sec 9.1)
    s.add        s46, s43, s47
    s.addi       s47, s45, #1
    s.movz       s48, #32
    v.st.b       [s46, #0], v38
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_39
x8dot_done_38:
    v.splat      v38, s42
    v.movi       v42, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s42
    v.movi       v42, #0
    s.movz       s42, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s42, #0
    v.extract    s44, v35, #5
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v34, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_40
    s.movz       s45, #0
    s.add        s46, s9, s25
    s.addi       s47, s45, #0
    s.addi       s45, s31, #256
x8dot_row_41:
    s.addi       s48, s12, #0
    v.movi       v38, #0
    s.sub        s49, s48, s47
    s.add        s48, s46, s47
    v.splat      v42, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s48, v24]            // index is in elements (ISA sec 9.1)
    s.add        s48, s45, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s48, #0], v38
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_41
x8dot_done_40:
    v.splat      v38, s44
    v.movi       v42, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s44
    v.movi       v42, #0
    s.movz       s44, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s45            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s44, #0
    v.extract    s46, v35, #6
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v34, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_42
    s.movz       s47, #0
    s.add        s48, s9, s25
    s.addi       s49, s47, #0
    s.addi       s47, s31, #256
x8dot_row_43:
    s.addi       s50, s12, #0
    v.movi       v38, #0
    s.sub        s51, s50, s49
    s.add        s50, s48, s49
    v.splat      v42, s51
    s.shli       s51, s49, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s50, v26]            // index is in elements (ISA sec 9.1)
    s.add        s50, s47, s51
    s.addi       s51, s49, #1
    s.movz       s52, #32
    v.st.b       [s50, #0], v38
    fence.acq_rel.device
    s.mov        s49, s51
    s.cmp.lt     s50, s49, s52
    br.nz        s50, x8dot_row_43
x8dot_done_42:
    v.splat      v38, s46
    v.movi       v42, #0
    v.splat      v43, s46
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s47, v37, #0
    s.movz       s48, #0
    s.movz       s49, #0
    v.cmp.ne     p1, v38, v42
    s.add        s50, s47, s33
    v.movi       v38, #0
    s.addi       s47, s50, #64
    v.cmp.eq     p2, v43, v38
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s50, s46            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s48, #0
    s.movz       s49, #0
    s.add        s50, s48, s15                   // the tile origin
    s.add        s48, s2, s47
    v.splat      v38, s50
    v.extract    s47, v35, #7
    v.add        v42, v36, v38
    s.mov        s50, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s46          // predicated off still completes once (ISA sec 9A.3)
    s.movz       s47, #0
    mb.wait      s46
    s.add        s49, s47, s29                   // the tile origin
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.splat      v38, s49
    m.mma.async.k32.e4m3 a15, v48, v56, s47
    v.cmp.lt     p1, v42, v38
    mb.wait      s47
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s48, #0]
    s.addi       s48, s31, #1536                 // 512 bytes of repack scratch
    vf.cvt.bf16.f32 v43, v42
    s.addi       s49, s48, #0
    vf.fms       v42, v12, v38, v40
    vf.fms       v44, v38, v42, v38
    v.extract    s50, v37, #1
    vf.neg       v42, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v38
    s.addi       s50, s51, #64
    vf.mul       v38, v43, v44                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v42, v38, v12, v43
    vf.fms       v43, v42, v44, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v44, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v43, v44, v38
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v44, v43, v41
    v.and        v43, v44, v39
    v.or         v44, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v44
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #32
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #2
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #64
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #64
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #3
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #64
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #96
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #4
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #64
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #128
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #5
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #64
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #160
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #6
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #64
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #192
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #7
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #64
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #224
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #8
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #64
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #256
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #9
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #64
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #288
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #10
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #64
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #320
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #11
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #64
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #352
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #12
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #64
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #384
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #13
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #64
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #416
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #14
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #64
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #448
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #15
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #64
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #480
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #0
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v38, v43, v42
    s.addi       s50, s51, #96
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    vf.neg       v38, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v43, v38, v42
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    v.st.b       [s49, #0], v42
    s.movz       s49, #0
    s.add        s50, s49, s18                   // the tile origin
    v.splat      v42, s50
    s.movz       s49, #0
    v.add        v43, v36, v42
    s.add        s50, s49, s29                   // the tile origin
    v.splat      v42, s50
    v.cmp.lt     p1, v43, v42
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.cvt.bf16.f32 v43, v42
    s.addi       s49, s48, #16
    vf.fms       v42, v12, v38, v40
    vf.fms       v44, v38, v42, v38
    v.extract    s50, v37, #1
    vf.neg       v42, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v38
    s.addi       s50, s51, #96
    vf.mul       v38, v43, v44                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v42, v38, v12, v43
    vf.fms       v43, v42, v44, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v44, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v43, v44, v38
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v44, v43, v41
    v.and        v43, v44, v39
    v.or         v44, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v44
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #48
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #2
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #96
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #80
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #3
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #96
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #112
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #4
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #96
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #144
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #5
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #96
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #176
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #6
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #96
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #208
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #7
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #96
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #240
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #8
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #96
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #272
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #9
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #96
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #304
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #10
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #96
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #336
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #11
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #96
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #368
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #12
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #96
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #400
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #13
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #96
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #432
    vf.fms       v38, v42, v43, v42
    v.extract    s50, v37, #14
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s50, s51, #96
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s51, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s49, s48, #464
    vf.fms       v42, v38, v43, v38
    v.extract    s50, v37, #15
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s50, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s50, s51, #96
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s51, s2, s50
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s51, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s49, s48, #496
    vf.fms       v38, v42, v43, v42
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v38, v43, v42
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.addi       s50, s48, #64
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    vf.neg       v38, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v43, v38, v42
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s49, #0], v42
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s49, s48, #128
    v.ld.w       v38, [s48, #0]
    v.mov        v48, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s50, #0]
    s.addi       s50, s48, #192
    v.mov        v49, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s49, #0]
    s.addi       s49, s48, #256
    v.mov        v50, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s50, #0]
    s.addi       s50, s48, #320
    v.mov        v51, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s49, #0]
    s.addi       s49, s48, #384
    s.addi       s51, s48, #448
    v.mov        v52, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s50, #0]
    v.extract    s48, v34, #0
    v.mov        v53, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s49, #0]
    v.mov        v54, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s51, #0]
    v.mov        v55, v38                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_44
    s.movz       s49, #0
    s.add        s50, s9, s25
    s.addi       s51, s49, #0
    s.addi       s49, s50, #32
    s.addi       s50, s31, #256
x8dot_row_45:
    s.addi       s52, s12, #-32
    v.movi       v38, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v42, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s52, v17]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v38
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_45
x8dot_done_44:
    v.splat      v38, s48
    v.movi       v42, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s48
    v.movi       v42, #0
    s.movz       s48, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s49            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s48, #32
    v.extract    s50, v35, #0
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v34, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_46
    s.movz       s51, #0
    s.add        s52, s9, s25
    s.addi       s53, s51, #0
    s.addi       s51, s52, #32
    s.addi       s52, s31, #256
x8dot_row_47:
    s.addi       s54, s12, #-32
    v.movi       v38, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v42, s55
    s.shli       s55, s53, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s54, v18]            // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.addi       s55, s53, #1
    s.movz       s56, #32
    v.st.b       [s54, #0], v38
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s54, s53, s56
    br.nz        s54, x8dot_row_47
x8dot_done_46:
    v.splat      v38, s50
    v.movi       v42, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s50
    v.movi       v42, #0
    s.movz       s50, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s51            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s50, #32
    v.extract    s52, v35, #1
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v34, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s52, x8dot_done_48
    s.movz       s53, #0
    s.add        s54, s9, s25
    s.addi       s55, s53, #0
    s.addi       s53, s54, #32
    s.addi       s54, s31, #256
x8dot_row_49:
    s.addi       s56, s12, #-32
    v.movi       v38, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v42, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s56, v19]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    s.movz       s58, #32
    v.st.b       [s56, #0], v38
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s58
    br.nz        s56, x8dot_row_49
x8dot_done_48:
    v.splat      v38, s52
    v.movi       v42, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s52
    v.movi       v42, #0
    s.movz       s52, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s53            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s52, #32
    v.extract    s54, v35, #2
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v34, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s54, x8dot_done_50
    s.movz       s55, #0
    s.add        s56, s9, s25
    s.addi       s57, s55, #0
    s.addi       s55, s56, #32
    s.addi       s56, s31, #256
x8dot_row_51:
    s.addi       s58, s12, #-32
    v.movi       v38, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v42, s59
    s.shli       s59, s57, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s58, v21]            // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    s.addi       s59, s57, #1
    s.movz       s60, #32
    v.st.b       [s58, #0], v38
    fence.acq_rel.device
    s.mov        s57, s59
    s.cmp.lt     s58, s57, s60
    br.nz        s58, x8dot_row_51
x8dot_done_50:
    v.splat      v38, s54
    v.movi       v42, #0
    mb.arm       s55, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s56, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s54
    v.movi       v42, #0
    s.movz       s54, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s57, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s57, s55            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s54, #32
    v.extract    s56, v35, #3
    s.mov        s57, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s57, s55          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s55
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v34, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s56, x8dot_done_52
    s.movz       s57, #0
    s.add        s58, s9, s25
    s.addi       s59, s57, #0
    s.addi       s57, s58, #32
    s.addi       s58, s31, #256
x8dot_row_53:
    s.addi       s60, s12, #-32
    v.movi       v38, #0
    s.sub        s30, s60, s59
    s.add        s32, s57, s59
    v.splat      v42, s30
    s.shli       s30, s59, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s32, v22]            // index is in elements (ISA sec 9.1)
    s.add        s32, s58, s30
    s.addi       s30, s59, #1
    s.movz       s34, #32
    v.st.b       [s32, #0], v38
    fence.acq_rel.device
    s.mov        s59, s30
    s.cmp.lt     s30, s59, s34
    br.nz        s30, x8dot_row_53
x8dot_done_52:
    v.splat      v38, s56
    v.movi       v42, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s56
    v.movi       v42, #0
    s.movz       s34, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s30            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s32, #32
    v.extract    s34, v35, #4
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v34, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_54
    s.movz       s35, #0
    s.add        s36, s9, s25
    s.addi       s37, s35, #0
    s.addi       s35, s36, #32
    s.addi       s36, s31, #256
x8dot_row_55:
    s.addi       s38, s12, #-32
    v.movi       v38, #0
    s.sub        s39, s38, s37
    s.add        s38, s35, s37
    v.splat      v42, s39
    s.shli       s39, s37, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s38, v23]            // index is in elements (ISA sec 9.1)
    s.add        s38, s36, s39
    s.addi       s39, s37, #1
    s.movz       s40, #32
    v.st.b       [s38, #0], v38
    fence.acq_rel.device
    s.mov        s37, s39
    s.cmp.lt     s38, s37, s40
    br.nz        s38, x8dot_row_55
x8dot_done_54:
    v.splat      v38, s34
    v.movi       v42, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s34
    v.movi       v42, #0
    s.movz       s34, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s35            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s34, #32
    v.extract    s36, v35, #5
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v34, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_56
    s.movz       s37, #0
    s.add        s38, s9, s25
    s.addi       s39, s37, #0
    s.addi       s37, s38, #32
    s.addi       s38, s31, #256
x8dot_row_57:
    s.addi       s40, s12, #-32
    v.movi       v38, #0
    s.sub        s41, s40, s39
    s.add        s40, s37, s39
    v.splat      v42, s41
    s.shli       s41, s39, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s40, v24]            // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    s.addi       s41, s39, #1
    s.movz       s42, #32
    v.st.b       [s40, #0], v38
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s40, s39, s42
    br.nz        s40, x8dot_row_57
x8dot_done_56:
    v.splat      v38, s36
    v.movi       v42, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s36
    v.movi       v42, #0
    s.movz       s36, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s37            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s36, #32
    v.extract    s38, v35, #6
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v34, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_58
    s.movz       s39, #0
    s.add        s40, s9, s25
    s.addi       s41, s39, #0
    s.addi       s39, s40, #32
    s.addi       s40, s31, #256
x8dot_row_59:
    s.addi       s42, s12, #-32
    v.movi       v38, #0
    s.sub        s43, s42, s41
    s.add        s42, s39, s41
    v.splat      v42, s43
    s.shli       s43, s41, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s42, v26]            // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.addi       s43, s41, #1
    s.movz       s44, #32
    v.st.b       [s42, #0], v38
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s42, s41, s44
    br.nz        s42, x8dot_row_59
x8dot_done_58:
    v.splat      v38, s38
    v.movi       v42, #0
    v.splat      v43, s38
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s39, v37, #0
    s.movz       s40, #0
    s.movz       s41, #0
    v.cmp.ne     p1, v38, v42
    s.add        s42, s39, s33
    v.movi       v38, #0
    s.addi       s39, s42, #128
    v.cmp.eq     p2, v43, v38
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s38            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s40, #0
    s.movz       s41, #32
    s.add        s42, s40, s19                   // the tile origin
    s.add        s40, s2, s39
    v.splat      v38, s42
    v.extract    s39, v35, #7
    v.add        v42, v36, v38
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s38          // predicated off still completes once (ISA sec 9A.3)
    s.movz       s39, #0
    mb.wait      s38
    s.add        s41, s39, s29                   // the tile origin
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.splat      v38, s41
    m.mma.async.k32.e4m3 a15, v48, v56, s39
    v.cmp.lt     p1, v42, v38
    mb.wait      s39
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s40, #0]
    s.addi       s40, s31, #2048                 // 512 bytes of repack scratch
    vf.cvt.bf16.f32 v43, v42
    s.addi       s41, s40, #0
    vf.fms       v42, v12, v38, v40
    vf.fms       v44, v38, v42, v38
    v.extract    s42, v37, #1
    vf.neg       v42, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v38
    s.addi       s42, s43, #128
    vf.mul       v38, v43, v44                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v42, v38, v12, v43
    vf.fms       v43, v42, v44, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v44, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v43, v44, v38
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v44, v43, v41
    v.and        v43, v44, v39
    v.or         v44, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v44
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #32
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #2
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #128
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #64
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #3
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #128
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #96
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #4
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #128
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #128
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #5
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #128
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #160
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #6
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #128
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #192
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #7
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #128
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #224
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #8
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #128
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #256
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #9
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #128
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #288
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #10
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #128
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #320
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #11
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #128
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #352
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #12
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #128
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #384
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #13
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #128
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #416
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #14
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #128
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #448
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #15
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #128
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #480
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #0
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v38, v43, v42
    s.addi       s42, s43, #160
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    vf.neg       v38, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v43, v38, v42
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    v.st.b       [s41, #0], v42
    s.movz       s41, #0
    s.add        s42, s41, s21                   // the tile origin
    v.splat      v42, s42
    s.movz       s41, #0
    v.add        v43, v36, v42
    s.add        s42, s41, s29                   // the tile origin
    v.splat      v42, s42
    v.cmp.lt     p1, v43, v42
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.cvt.bf16.f32 v43, v42
    s.addi       s41, s40, #16
    vf.fms       v42, v12, v38, v40
    vf.fms       v44, v38, v42, v38
    v.extract    s42, v37, #1
    vf.neg       v42, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v38
    s.addi       s42, s43, #160
    vf.mul       v38, v43, v44                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v42, v38, v12, v43
    vf.fms       v43, v42, v44, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v44, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v43, v44, v38
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v44, v43, v41
    v.and        v43, v44, v39
    v.or         v44, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v44
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #48
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #2
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #160
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #80
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #3
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #160
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #112
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #4
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #160
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #144
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #5
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #160
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #176
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #6
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #160
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #208
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #7
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #160
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #240
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #8
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #160
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #272
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #9
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #160
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #304
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #10
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #160
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #336
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #11
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #160
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #368
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #12
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #160
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #400
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #13
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #160
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #432
    vf.fms       v38, v42, v43, v42
    v.extract    s42, v37, #14
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s42, s43, #160
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s43, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s41, s40, #464
    vf.fms       v42, v38, v43, v38
    v.extract    s42, v37, #15
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s42, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s42, s43, #160
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s43, s2, s42
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s43, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s41, s40, #496
    vf.fms       v38, v42, v43, v42
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v38, v43, v42
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.addi       s42, s40, #64
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    vf.neg       v38, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v43, v38, v42
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s41, #0], v42
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s41, s40, #128
    v.ld.w       v38, [s40, #0]
    v.mov        v48, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s42, #0]
    s.addi       s42, s40, #192
    v.mov        v49, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s41, #0]
    s.addi       s41, s40, #256
    v.mov        v50, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s42, #0]
    s.addi       s42, s40, #320
    v.mov        v51, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s41, #0]
    s.addi       s41, s40, #384
    s.addi       s43, s40, #448
    v.mov        v52, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s42, #0]
    v.extract    s40, v34, #0
    v.mov        v53, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s41, #0]
    v.mov        v54, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s43, #0]
    v.mov        v55, v38                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_60
    s.movz       s41, #0
    s.add        s42, s9, s25
    s.addi       s43, s41, #0
    s.addi       s41, s42, #64
    s.addi       s42, s31, #256
x8dot_row_61:
    s.addi       s44, s12, #-64
    v.movi       v38, #0
    s.sub        s45, s44, s43
    s.add        s44, s41, s43
    v.splat      v42, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s44, v17]            // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v38
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_61
x8dot_done_60:
    v.splat      v38, s40
    v.movi       v42, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s40
    v.movi       v42, #0
    s.movz       s40, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s40, #64
    v.extract    s42, v35, #0
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v34, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_62
    s.movz       s43, #0
    s.add        s44, s9, s25
    s.addi       s45, s43, #0
    s.addi       s43, s44, #64
    s.addi       s44, s31, #256
x8dot_row_63:
    s.addi       s46, s12, #-64
    v.movi       v38, #0
    s.sub        s47, s46, s45
    s.add        s46, s43, s45
    v.splat      v42, s47
    s.shli       s47, s45, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s46, v18]            // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.addi       s47, s45, #1
    s.movz       s48, #32
    v.st.b       [s46, #0], v38
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_63
x8dot_done_62:
    v.splat      v38, s42
    v.movi       v42, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s42
    v.movi       v42, #0
    s.movz       s42, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s42, #64
    v.extract    s44, v35, #1
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v34, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_64
    s.movz       s45, #0
    s.add        s46, s9, s25
    s.addi       s47, s45, #0
    s.addi       s45, s46, #64
    s.addi       s46, s31, #256
x8dot_row_65:
    s.addi       s48, s12, #-64
    v.movi       v38, #0
    s.sub        s49, s48, s47
    s.add        s48, s45, s47
    v.splat      v42, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s48, v19]            // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s48, #0], v38
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_65
x8dot_done_64:
    v.splat      v38, s44
    v.movi       v42, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s44
    v.movi       v42, #0
    s.movz       s44, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s45            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s44, #64
    v.extract    s46, v35, #2
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v34, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_66
    s.movz       s47, #0
    s.add        s48, s9, s25
    s.addi       s49, s47, #0
    s.addi       s47, s48, #64
    s.addi       s48, s31, #256
x8dot_row_67:
    s.addi       s50, s12, #-64
    v.movi       v38, #0
    s.sub        s51, s50, s49
    s.add        s50, s47, s49
    v.splat      v42, s51
    s.shli       s51, s49, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s50, v21]            // index is in elements (ISA sec 9.1)
    s.add        s50, s48, s51
    s.addi       s51, s49, #1
    s.movz       s52, #32
    v.st.b       [s50, #0], v38
    fence.acq_rel.device
    s.mov        s49, s51
    s.cmp.lt     s50, s49, s52
    br.nz        s50, x8dot_row_67
x8dot_done_66:
    v.splat      v38, s46
    v.movi       v42, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s46
    v.movi       v42, #0
    s.movz       s46, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s49, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s47            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s46, #64
    v.extract    s48, v35, #3
    s.mov        s49, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v34, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_68
    s.movz       s49, #0
    s.add        s50, s9, s25
    s.addi       s51, s49, #0
    s.addi       s49, s50, #64
    s.addi       s50, s31, #256
x8dot_row_69:
    s.addi       s52, s12, #-64
    v.movi       v38, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v42, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s52, v22]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v38
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_69
x8dot_done_68:
    v.splat      v38, s48
    v.movi       v42, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s48
    v.movi       v42, #0
    s.movz       s48, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s49            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s48, #64
    v.extract    s50, v35, #4
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v34, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_70
    s.movz       s51, #0
    s.add        s52, s9, s25
    s.addi       s53, s51, #0
    s.addi       s51, s52, #64
    s.addi       s52, s31, #256
x8dot_row_71:
    s.addi       s54, s12, #-64
    v.movi       v38, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v42, s55
    s.shli       s55, s53, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s54, v23]            // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.addi       s55, s53, #1
    s.movz       s56, #32
    v.st.b       [s54, #0], v38
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s54, s53, s56
    br.nz        s54, x8dot_row_71
x8dot_done_70:
    v.splat      v38, s50
    v.movi       v42, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s50
    v.movi       v42, #0
    s.movz       s50, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s51            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s50, #64
    v.extract    s52, v35, #5
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v34, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s52, x8dot_done_72
    s.movz       s53, #0
    s.add        s54, s9, s25
    s.addi       s55, s53, #0
    s.addi       s53, s54, #64
    s.addi       s54, s31, #256
x8dot_row_73:
    s.addi       s56, s12, #-64
    v.movi       v38, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v42, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s56, v24]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    s.movz       s58, #32
    v.st.b       [s56, #0], v38
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s58
    br.nz        s56, x8dot_row_73
x8dot_done_72:
    v.splat      v38, s52
    v.movi       v42, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    v.cmp.ne     p1, v38, v42
    v.splat      v38, s52
    v.movi       v42, #0
    s.movz       s52, #0
    v.cmp.eq     p2, v38, v42
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s53            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s52, #64
    v.extract    s54, v35, #6
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v34, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s54, x8dot_done_74
    s.movz       s55, #0
    s.add        s56, s9, s25
    s.addi       s57, s55, #0
    s.addi       s55, s56, #64
    s.addi       s56, s31, #256
x8dot_row_75:
    s.addi       s58, s12, #-64
    v.movi       v38, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v42, s59
    s.shli       s59, s57, #4
    v.cmp.gt     p1, v42, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s58, v26]            // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    s.addi       s59, s57, #1
    s.movz       s60, #32
    v.st.b       [s58, #0], v38
    fence.acq_rel.device
    s.mov        s57, s59
    s.cmp.lt     s58, s57, s60
    br.nz        s58, x8dot_row_75
x8dot_done_74:
    v.splat      v38, s54
    v.movi       v42, #0
    v.splat      v43, s54
    mb.arm       s54, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s55, v37, #0
    s.movz       s56, #0
    s.movz       s57, #0
    v.cmp.ne     p1, v38, v42
    s.add        s58, s55, s33
    v.movi       v38, #0
    s.addi       s55, s58, #192
    v.cmp.eq     p2, v43, v38
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s58, s54            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s56, #0
    s.movz       s57, #64
    s.add        s58, s56, s22                   // the tile origin
    s.add        s56, s2, s55
    v.splat      v38, s58
    v.extract    s55, v35, #7
    v.add        v42, v36, v38
    s.mov        s58, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s58, s54          // predicated off still completes once (ISA sec 9A.3)
    s.movz       s55, #0
    mb.wait      s54
    s.add        s57, s55, s29                   // the tile origin
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.splat      v38, s57
    m.mma.async.k32.e4m3 a15, v48, v56, s55
    v.cmp.lt     p1, v42, v38
    mb.wait      s55
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s56, #0]
    s.addi       s56, s31, #2560                 // 512 bytes of repack scratch
    vf.cvt.bf16.f32 v43, v42
    s.addi       s57, s56, #0
    vf.fms       v42, v12, v38, v40
    vf.fms       v44, v38, v42, v38
    v.extract    s58, v37, #1
    vf.neg       v42, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v38
    s.addi       s58, s59, #192
    vf.mul       v38, v43, v44                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v42, v38, v12, v43
    vf.fms       v43, v42, v44, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v44, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v43, v44, v38
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v44, v43, v41
    v.and        v43, v44, v39
    v.or         v44, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v44
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s59, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s57, s56, #32
    vf.fms       v38, v42, v43, v42
    v.extract    s58, v37, #2
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s58, s59, #192
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s59, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s57, s56, #64
    vf.fms       v42, v38, v43, v38
    v.extract    s58, v37, #3
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s58, s59, #192
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s59, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s57, s56, #96
    vf.fms       v38, v42, v43, v42
    v.extract    s58, v37, #4
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s58, s59, #192
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s59, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s57, s56, #128
    vf.fms       v42, v38, v43, v38
    v.extract    s58, v37, #5
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s58, s59, #192
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s59, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s57, s56, #160
    vf.fms       v38, v42, v43, v42
    v.extract    s58, v37, #6
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s58, s59, #192
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s59, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s57, s56, #192
    vf.fms       v42, v38, v43, v38
    v.extract    s58, v37, #7
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s58, s59, #192
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s59, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s57, s56, #224
    vf.fms       v38, v42, v43, v42
    v.extract    s58, v37, #8
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s58, s59, #192
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s59, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s57, s56, #256
    vf.fms       v42, v38, v43, v38
    v.extract    s58, v37, #9
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s58, s59, #192
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s59, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s57, s56, #288
    vf.fms       v38, v42, v43, v42
    v.extract    s58, v37, #10
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s58, s59, #192
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s59, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s57, s56, #320
    vf.fms       v42, v38, v43, v38
    v.extract    s58, v37, #11
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s58, s59, #192
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s59, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s57, s56, #352
    vf.fms       v38, v42, v43, v42
    v.extract    s58, v37, #12
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s58, s59, #192
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s59, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s57, s56, #384
    vf.fms       v42, v38, v43, v38
    v.extract    s58, v37, #13
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s58, s59, #192
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s59, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s57, s56, #416
    vf.fms       v38, v42, v43, v42
    v.extract    s58, v37, #14
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v38, v43, v42
    s.addi       s58, s59, #192
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v42
    vf.cvt.f32.e4m3 v42, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v42, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s59, #0]
    vf.fms       v43, v12, v38, v40
    vf.cvt.bf16.f32 v44, v42
    s.addi       s57, s56, #448
    vf.fms       v42, v38, v43, v38
    v.extract    s58, v37, #15
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v38
    s.addi       s58, s59, #192
    vf.mul       v38, v44, v42                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v38, v12, v44
    vf.fms       v44, v43, v42, v38
    v.rcp.approx v42, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v44, v43, v38
    vf.cvt.f32.e4m3 v38, v44
    v.lshr       v43, v44, v41
    v.and        v44, v43, v39
    v.or         v43, v38, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s57, #0], v43
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s59, #0]
    vf.fms       v43, v12, v42, v40
    vf.cvt.bf16.f32 v44, v38
    s.addi       s57, s56, #480
    vf.fms       v38, v42, v43, v42
    v.extract    s58, v37, #0
    vf.neg       v43, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s59, s58, s33
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v38, v43, v42
    s.addi       s58, s59, #224
    vf.mul       v42, v44, v38                   // a/y: faithful quotient
    s.add        s59, s2, s58
    vf.fms       v43, v42, v12, v44
    vf.fms       v44, v43, v38, v42
    vf.neg       v38, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v43, v38, v42
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    v.st.b       [s57, #0], v42
    s.movz       s57, #0
    s.add        s58, s57, s23                   // the tile origin
    v.splat      v42, s58
    s.movz       s57, #0
    v.add        v43, v36, v42
    s.add        s58, s57, s29                   // the tile origin
    v.splat      v36, s58
    v.cmp.lt     p1, v43, v36
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v36, [s59, #0]
    vf.cvt.bf16.f32 v42, v36
    s.addi       s29, s56, #16
    vf.fms       v36, v12, v38, v40
    vf.fms       v43, v38, v36, v38
    v.extract    s57, v37, #1
    vf.neg       v36, v43                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v36, v36
    @p2 v.sel        v43, v36, v38
    s.addi       s57, s58, #224
    vf.mul       v36, v42, v43                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v38, v36, v12, v42
    vf.fms       v42, v38, v43, v36
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v36
    vf.cvt.f32.e4m3 v36, v42
    v.lshr       v43, v42, v41
    v.and        v42, v43, v39
    v.or         v43, v36, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v43
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v36, [s58, #0]
    vf.fms       v42, v12, v38, v40
    vf.cvt.bf16.f32 v43, v36
    s.addi       s29, s56, #48
    vf.fms       v36, v38, v42, v38
    v.extract    s57, v37, #2
    vf.neg       v42, v36                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v36, v42, v38
    s.addi       s57, s58, #224
    vf.mul       v38, v43, v36                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v38, v12, v43
    vf.fms       v43, v42, v36, v38
    v.rcp.approx v36, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v38
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s58, #0]
    vf.fms       v42, v12, v36, v40
    vf.cvt.bf16.f32 v43, v38
    s.addi       s29, s56, #80
    vf.fms       v38, v36, v42, v36
    v.extract    s57, v37, #3
    vf.neg       v42, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v38, v42, v36
    s.addi       s57, s58, #224
    vf.mul       v36, v43, v38                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v36, v12, v43
    vf.fms       v43, v42, v38, v36
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v36
    vf.cvt.f32.e4m3 v36, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v36, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v36, [s58, #0]
    vf.fms       v42, v12, v38, v40
    vf.cvt.bf16.f32 v43, v36
    s.addi       s29, s56, #112
    vf.fms       v36, v38, v42, v38
    v.extract    s57, v37, #4
    vf.neg       v42, v36                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v36, v42, v38
    s.addi       s57, s58, #224
    vf.mul       v38, v43, v36                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v38, v12, v43
    vf.fms       v43, v42, v36, v38
    v.rcp.approx v36, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v38
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s58, #0]
    vf.fms       v42, v12, v36, v40
    vf.cvt.bf16.f32 v43, v38
    s.addi       s29, s56, #144
    vf.fms       v38, v36, v42, v36
    v.extract    s57, v37, #5
    vf.neg       v42, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v38, v42, v36
    s.addi       s57, s58, #224
    vf.mul       v36, v43, v38                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v36, v12, v43
    vf.fms       v43, v42, v38, v36
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v36
    vf.cvt.f32.e4m3 v36, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v36, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v36, [s58, #0]
    vf.fms       v42, v12, v38, v40
    vf.cvt.bf16.f32 v43, v36
    s.addi       s29, s56, #176
    vf.fms       v36, v38, v42, v38
    v.extract    s57, v37, #6
    vf.neg       v42, v36                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v36, v42, v38
    s.addi       s57, s58, #224
    vf.mul       v38, v43, v36                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v38, v12, v43
    vf.fms       v43, v42, v36, v38
    v.rcp.approx v36, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v38
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s58, #0]
    vf.fms       v42, v12, v36, v40
    vf.cvt.bf16.f32 v43, v38
    s.addi       s29, s56, #208
    vf.fms       v38, v36, v42, v36
    v.extract    s57, v37, #7
    vf.neg       v42, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v38, v42, v36
    s.addi       s57, s58, #224
    vf.mul       v36, v43, v38                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v36, v12, v43
    vf.fms       v43, v42, v38, v36
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v36
    vf.cvt.f32.e4m3 v36, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v36, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v36, [s58, #0]
    vf.fms       v42, v12, v38, v40
    vf.cvt.bf16.f32 v43, v36
    s.addi       s29, s56, #240
    vf.fms       v36, v38, v42, v38
    v.extract    s57, v37, #8
    vf.neg       v42, v36                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v36, v42, v38
    s.addi       s57, s58, #224
    vf.mul       v38, v43, v36                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v38, v12, v43
    vf.fms       v43, v42, v36, v38
    v.rcp.approx v36, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v38
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s58, #0]
    vf.fms       v42, v12, v36, v40
    vf.cvt.bf16.f32 v43, v38
    s.addi       s29, s56, #272
    vf.fms       v38, v36, v42, v36
    v.extract    s57, v37, #9
    vf.neg       v42, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v38, v42, v36
    s.addi       s57, s58, #224
    vf.mul       v36, v43, v38                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v36, v12, v43
    vf.fms       v43, v42, v38, v36
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v36
    vf.cvt.f32.e4m3 v36, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v36, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v36, [s58, #0]
    vf.fms       v42, v12, v38, v40
    vf.cvt.bf16.f32 v43, v36
    s.addi       s29, s56, #304
    vf.fms       v36, v38, v42, v38
    v.extract    s57, v37, #10
    vf.neg       v42, v36                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v36, v42, v38
    s.addi       s57, s58, #224
    vf.mul       v38, v43, v36                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v38, v12, v43
    vf.fms       v43, v42, v36, v38
    v.rcp.approx v36, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v38
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s58, #0]
    vf.fms       v42, v12, v36, v40
    vf.cvt.bf16.f32 v43, v38
    s.addi       s29, s56, #336
    vf.fms       v38, v36, v42, v36
    v.extract    s57, v37, #11
    vf.neg       v42, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v38, v42, v36
    s.addi       s57, s58, #224
    vf.mul       v36, v43, v38                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v36, v12, v43
    vf.fms       v43, v42, v38, v36
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v36
    vf.cvt.f32.e4m3 v36, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v36, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v36, [s58, #0]
    vf.fms       v42, v12, v38, v40
    vf.cvt.bf16.f32 v43, v36
    s.addi       s29, s56, #368
    vf.fms       v36, v38, v42, v38
    v.extract    s57, v37, #12
    vf.neg       v42, v36                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v36, v42, v38
    s.addi       s57, s58, #224
    vf.mul       v38, v43, v36                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v38, v12, v43
    vf.fms       v43, v42, v36, v38
    v.rcp.approx v36, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v38
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s58, #0]
    vf.fms       v42, v12, v36, v40
    vf.cvt.bf16.f32 v43, v38
    s.addi       s29, s56, #400
    vf.fms       v38, v36, v42, v36
    v.extract    s57, v37, #13
    vf.neg       v42, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v38, v42, v36
    s.addi       s57, s58, #224
    vf.mul       v36, v43, v38                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v36, v12, v43
    vf.fms       v43, v42, v38, v36
    v.rcp.approx v38, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v36
    vf.cvt.f32.e4m3 v36, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v36, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v36, [s58, #0]
    vf.fms       v42, v12, v38, v40
    vf.cvt.bf16.f32 v43, v36
    s.addi       s29, s56, #432
    vf.fms       v36, v38, v42, v38
    v.extract    s57, v37, #14
    vf.neg       v42, v36                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v36, v42, v38
    s.addi       s57, s58, #224
    vf.mul       v38, v43, v36                   // a/y: faithful quotient
    s.add        s58, s2, s57
    vf.fms       v42, v38, v12, v43
    vf.fms       v43, v42, v36, v38
    v.rcp.approx v36, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v38
    vf.cvt.f32.e4m3 v38, v43
    v.lshr       v42, v43, v41
    v.and        v43, v42, v39
    v.or         v42, v38, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v42
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v38, [s58, #0]
    vf.fms       v42, v12, v36, v40
    vf.cvt.bf16.f32 v43, v38
    s.addi       s29, s56, #464
    vf.fms       v38, v36, v42, v36
    v.extract    s57, v37, #15
    vf.neg       v37, v38                        // Newton step: r0*(2 - x*r0)
    s.add        s58, s57, s33
    vf.cmp.o     p2, v37, v37
    @p2 v.sel        v38, v37, v36
    s.addi       s33, s58, #224
    vf.mul       v36, v43, v38                   // a/y: faithful quotient
    s.add        s57, s2, s33
    vf.fms       v37, v36, v12, v43
    vf.fms       v42, v37, v38, v36
    v.rcp.approx v37, v12                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v38, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v38, v38
    @p2 v.sel        v42, v38, v36
    vf.cvt.f32.e4m3 v36, v42
    v.lshr       v38, v42, v41
    v.and        v42, v38, v39
    v.or         v38, v36, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v38
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v36, [s57, #0]
    vf.fms       v38, v12, v37, v40
    vf.cvt.bf16.f32 v40, v36
    s.addi       s29, s56, #496
    vf.fms       v36, v37, v38, v37
    vf.neg       v38, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v38, v38
    @p1 v.sel        v36, v38, v37
    vf.mul       v37, v40, v36                   // a/y: faithful quotient
    s.addi       s33, s56, #64
    vf.fms       v38, v37, v12, v40
    vf.fms       v12, v38, v36, v37
    vf.neg       v36, v12                        // a/y: one correction to the IEEE quotient
    s.addi       s57, s56, #128
    vf.cmp.o     p1, v36, v36
    @p1 v.sel        v12, v36, v37
    vf.cvt.f32.e4m3 v36, v12
    v.lshr       v37, v12, v41
    s.addi       s58, s56, #192
    v.and        v12, v37, v39
    v.or         v37, v36, v12                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v37
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s29, s56, #256
    v.ld.w       v12, [s56, #0]
    v.mov        v48, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s33, #0]
    s.addi       s33, s56, #320
    v.mov        v49, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s57, #0]
    s.addi       s57, s56, #384
    s.addi       s59, s56, #448
    v.mov        v50, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s58, #0]
    v.extract    s56, v34, #0
    v.mov        v51, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s29, #0]
    v.mov        v52, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s33, #0]
    v.mov        v53, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s57, #0]
    v.mov        v54, v12                        // hand off through the shared window (sec 7.3)
    v.ld.w       v12, [s59, #0]
    v.mov        v55, v12                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s56, x8dot_done_76
    s.movz       s29, #0
    s.add        s33, s9, s25
    s.addi       s57, s29, #0
    s.addi       s29, s33, #96
    s.addi       s33, s31, #256
x8dot_row_77:
    s.addi       s58, s12, #-96
    v.movi       v12, #0
    s.sub        s59, s58, s57
    s.add        s58, s29, s57
    v.splat      v36, s59
    s.shli       s59, s57, #4
    v.cmp.gt     p1, v36, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s58, v17]            // index is in elements (ISA sec 9.1)
    s.add        s58, s33, s59
    s.addi       s59, s57, #1
    s.movz       s60, #32
    v.st.b       [s58, #0], v12
    fence.acq_rel.device
    s.mov        s57, s59
    s.cmp.lt     s58, s57, s60
    br.nz        s58, x8dot_row_77
x8dot_done_76:
    v.splat      v12, s56
    v.movi       v17, #0
    mb.arm       s29, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.cmp.ne     p1, v12, v17
    v.splat      v12, s56
    v.movi       v17, #0
    s.movz       s56, #0
    v.cmp.eq     p2, v12, v17
    s.mov        s57, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s57, s29            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s33, #96
    v.extract    s56, v35, #0
    s.mov        s57, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s57, s29          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s29
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v34, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s56, x8dot_done_78
    s.movz       s57, #0
    s.add        s58, s9, s25
    s.addi       s59, s57, #0
    s.addi       s57, s58, #96
    s.addi       s58, s31, #256
x8dot_row_79:
    s.addi       s60, s12, #-96
    v.movi       v12, #0
    s.sub        s29, s60, s59
    s.add        s30, s57, s59
    v.splat      v17, s29
    s.shli       s29, s59, #4
    v.cmp.gt     p1, v17, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s30, v18]            // index is in elements (ISA sec 9.1)
    s.add        s30, s58, s29
    s.addi       s29, s59, #1
    s.movz       s32, #32
    v.st.b       [s30, #0], v12
    fence.acq_rel.device
    s.mov        s59, s29
    s.cmp.lt     s29, s59, s32
    br.nz        s29, x8dot_row_79
x8dot_done_78:
    v.splat      v12, s56
    v.movi       v17, #0
    mb.arm       s29, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    v.cmp.ne     p1, v12, v17
    v.splat      v12, s56
    v.movi       v17, #0
    s.movz       s32, #0
    v.cmp.eq     p2, v12, v17
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s33, s29            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s30, #96
    v.extract    s32, v35, #1
    s.mov        s33, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s29          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s29
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s32, v34, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s30
    mb.wait      s30
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s32, x8dot_done_80
    s.movz       s33, #0
    s.add        s34, s9, s25
    s.addi       s35, s33, #0
    s.addi       s33, s34, #96
    s.addi       s34, s31, #256
x8dot_row_81:
    s.addi       s36, s12, #-96
    v.movi       v12, #0
    s.sub        s37, s36, s35
    s.add        s36, s33, s35
    v.splat      v17, s37
    s.shli       s37, s35, #4
    v.cmp.gt     p1, v17, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s36, v19]            // index is in elements (ISA sec 9.1)
    s.add        s36, s34, s37
    s.addi       s37, s35, #1
    s.movz       s38, #32
    v.st.b       [s36, #0], v12
    fence.acq_rel.device
    s.mov        s35, s37
    s.cmp.lt     s36, s35, s38
    br.nz        s36, x8dot_row_81
x8dot_done_80:
    v.splat      v12, s32
    v.movi       v17, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.cmp.ne     p1, v12, v17
    v.splat      v12, s32
    v.movi       v17, #0
    s.movz       s32, #0
    v.cmp.eq     p2, v12, v17
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s33            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s32, #96
    v.extract    s34, v35, #2
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v34, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_82
    s.movz       s35, #0
    s.add        s36, s9, s25
    s.addi       s37, s35, #0
    s.addi       s35, s36, #96
    s.addi       s36, s31, #256
x8dot_row_83:
    s.addi       s38, s12, #-96
    v.movi       v12, #0
    s.sub        s39, s38, s37
    s.add        s38, s35, s37
    v.splat      v17, s39
    s.shli       s39, s37, #4
    v.cmp.gt     p1, v17, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s38, v21]            // index is in elements (ISA sec 9.1)
    s.add        s38, s36, s39
    s.addi       s39, s37, #1
    s.movz       s40, #32
    v.st.b       [s38, #0], v12
    fence.acq_rel.device
    s.mov        s37, s39
    s.cmp.lt     s38, s37, s40
    br.nz        s38, x8dot_row_83
x8dot_done_82:
    v.splat      v12, s34
    v.movi       v17, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.cmp.ne     p1, v12, v17
    v.splat      v12, s34
    v.movi       v17, #0
    s.movz       s34, #0
    v.cmp.eq     p2, v12, v17
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s35            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s34, #96
    v.extract    s36, v35, #3
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v34, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_84
    s.movz       s37, #0
    s.add        s38, s9, s25
    s.addi       s39, s37, #0
    s.addi       s37, s38, #96
    s.addi       s38, s31, #256
x8dot_row_85:
    s.addi       s40, s12, #-96
    v.movi       v12, #0
    s.sub        s41, s40, s39
    s.add        s40, s37, s39
    v.splat      v17, s41
    s.shli       s41, s39, #4
    v.cmp.gt     p1, v17, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s40, v22]            // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    s.addi       s41, s39, #1
    s.movz       s42, #32
    v.st.b       [s40, #0], v12
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s40, s39, s42
    br.nz        s40, x8dot_row_85
x8dot_done_84:
    v.splat      v12, s36
    v.movi       v17, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.cmp.ne     p1, v12, v17
    v.splat      v12, s36
    v.movi       v17, #0
    s.movz       s36, #0
    v.cmp.eq     p2, v12, v17
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s37            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s36, #96
    v.extract    s38, v35, #4
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v34, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_86
    s.movz       s39, #0
    s.add        s40, s9, s25
    s.addi       s41, s39, #0
    s.addi       s39, s40, #96
    s.addi       s40, s31, #256
x8dot_row_87:
    s.addi       s42, s12, #-96
    v.movi       v12, #0
    s.sub        s43, s42, s41
    s.add        s42, s39, s41
    v.splat      v17, s43
    s.shli       s43, s41, #4
    v.cmp.gt     p1, v17, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s42, v23]            // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.addi       s43, s41, #1
    s.movz       s44, #32
    v.st.b       [s42, #0], v12
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s42, s41, s44
    br.nz        s42, x8dot_row_87
x8dot_done_86:
    v.splat      v12, s38
    v.movi       v17, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.cmp.ne     p1, v12, v17
    v.splat      v12, s38
    v.movi       v17, #0
    s.movz       s38, #0
    v.cmp.eq     p2, v12, v17
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s38, #96
    v.extract    s40, v35, #5
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v34, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_88
    s.movz       s41, #0
    s.add        s42, s9, s25
    s.addi       s43, s41, #0
    s.addi       s41, s42, #96
    s.addi       s42, s31, #256
x8dot_row_89:
    s.addi       s44, s12, #-96
    v.movi       v12, #0
    s.sub        s45, s44, s43
    s.add        s44, s41, s43
    v.splat      v17, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v17, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s44, v24]            // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v12
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_89
x8dot_done_88:
    v.splat      v12, s40
    v.movi       v17, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.cmp.ne     p1, v12, v17
    v.splat      v12, s40
    v.movi       v17, #0
    s.movz       s40, #0
    v.cmp.eq     p2, v12, v17
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s40, #96
    v.extract    s42, v35, #6
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v34, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_90
    s.movz       s43, #0
    s.add        s44, s9, s25
    s.addi       s45, s43, #0
    s.addi       s43, s44, #96
    s.addi       s44, s31, #256
x8dot_row_91:
    s.addi       s46, s12, #-96
    v.movi       v12, #0
    s.sub        s47, s46, s45
    s.add        s46, s43, s45
    v.splat      v17, s47
    s.shli       s47, s45, #4
    v.cmp.gt     p1, v17, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v12, [s46, v26]            // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.addi       s47, s45, #1
    s.movz       s48, #32
    v.st.b       [s46, #0], v12
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_91
x8dot_done_90:
    v.splat      v12, s42
    v.movi       v17, #0
    mb.arm       s12, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    s.movz       s44, #0
    v.cmp.ne     p1, v12, v17
    v.splat      v12, s42
    v.movi       v17, #0
    s.movz       s42, #96
    v.cmp.eq     p2, v12, v17
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s12            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s43, v35, #7
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s12          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s12
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s43, #0
    m.mma.async.k32.e4m3 a15, v48, v56, s42
    mb.wait      s42
    s.addi       s44, s31, #3072
    a.vread      v12, a8, s43
    s.movz       s43, #1
    v.st.w       [s44, #0], v12
    s.addi       s45, s44, #64
    a.vread      v12, a8, s43
    s.movz       s43, #2
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #128
    a.vread      v12, a8, s43
    s.movz       s43, #3
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #192
    a.vread      v12, a8, s43
    s.movz       s43, #4
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #256
    a.vread      v12, a8, s43
    s.movz       s43, #5
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #320
    a.vread      v12, a8, s43
    s.movz       s43, #6
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #384
    a.vread      v12, a8, s43
    s.movz       s43, #7
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #448
    a.vread      v12, a8, s43
    s.movz       s43, #8
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #512
    a.vread      v12, a8, s43
    s.movz       s43, #9
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #576
    a.vread      v12, a8, s43
    s.movz       s43, #10
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #640
    a.vread      v12, a8, s43
    s.movz       s43, #11
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #704
    a.vread      v12, a8, s43
    s.movz       s43, #12
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #768
    a.vread      v12, a8, s43
    s.movz       s43, #13
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #832
    a.vread      v12, a8, s43
    s.movz       s43, #14
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #896
    a.vread      v12, a8, s43
    s.movz       s43, #15
    s.addi       s46, s44, #960
    v.st.w       [s45, #0], v12
    a.vread      v12, a8, s43
    s.movz       s43, #0
    s.addi       s44, s31, #4096
    v.st.w       [s46, #0], v12
    fence.acq_rel.device
    a.vread      v12, a9, s43
    s.movz       s43, #1
    s.addi       s45, s44, #64
    v.st.w       [s44, #0], v12
    a.vread      v12, a9, s43
    s.movz       s43, #2
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #128
    a.vread      v12, a9, s43
    s.movz       s43, #3
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #192
    a.vread      v12, a9, s43
    s.movz       s43, #4
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #256
    a.vread      v12, a9, s43
    s.movz       s43, #5
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #320
    a.vread      v12, a9, s43
    s.movz       s43, #6
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #384
    a.vread      v12, a9, s43
    s.movz       s43, #7
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #448
    a.vread      v12, a9, s43
    s.movz       s43, #8
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #512
    a.vread      v12, a9, s43
    s.movz       s43, #9
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #576
    a.vread      v12, a9, s43
    s.movz       s43, #10
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #640
    a.vread      v12, a9, s43
    s.movz       s43, #11
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #704
    a.vread      v12, a9, s43
    s.movz       s43, #12
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #768
    a.vread      v12, a9, s43
    s.movz       s43, #13
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #832
    a.vread      v12, a9, s43
    s.movz       s43, #14
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #896
    a.vread      v12, a9, s43
    s.movz       s43, #15
    s.addi       s46, s44, #960
    v.st.w       [s45, #0], v12
    a.vread      v12, a9, s43
    s.movz       s43, #0
    s.addi       s44, s31, #5120
    v.st.w       [s46, #0], v12
    fence.acq_rel.device
    a.vread      v12, a10, s43
    s.movz       s43, #1
    s.addi       s45, s44, #64
    v.st.w       [s44, #0], v12
    a.vread      v12, a10, s43
    s.movz       s43, #2
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #128
    a.vread      v12, a10, s43
    s.movz       s43, #3
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #192
    a.vread      v12, a10, s43
    s.movz       s43, #4
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #256
    a.vread      v12, a10, s43
    s.movz       s43, #5
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #320
    a.vread      v12, a10, s43
    s.movz       s43, #6
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #384
    a.vread      v12, a10, s43
    s.movz       s43, #7
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #448
    a.vread      v12, a10, s43
    s.movz       s43, #8
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #512
    a.vread      v12, a10, s43
    s.movz       s43, #9
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #576
    a.vread      v12, a10, s43
    s.movz       s43, #10
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #640
    a.vread      v12, a10, s43
    s.movz       s43, #11
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #704
    a.vread      v12, a10, s43
    s.movz       s43, #12
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #768
    a.vread      v12, a10, s43
    s.movz       s43, #13
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #832
    a.vread      v12, a10, s43
    s.movz       s43, #14
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #896
    a.vread      v12, a10, s43
    s.movz       s43, #15
    s.addi       s46, s44, #960
    v.st.w       [s45, #0], v12
    a.vread      v12, a10, s43
    s.movz       s43, #0
    s.addi       s44, s31, #6144
    v.st.w       [s46, #0], v12
    fence.acq_rel.device
    a.vread      v12, a11, s43
    s.movz       s43, #1
    s.addi       s45, s44, #64
    v.st.w       [s44, #0], v12
    a.vread      v12, a11, s43
    s.movz       s43, #2
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #128
    a.vread      v12, a11, s43
    s.movz       s43, #3
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #192
    a.vread      v12, a11, s43
    s.movz       s43, #4
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #256
    a.vread      v12, a11, s43
    s.movz       s43, #5
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #320
    a.vread      v12, a11, s43
    s.movz       s43, #6
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #384
    a.vread      v12, a11, s43
    s.movz       s43, #7
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #448
    a.vread      v12, a11, s43
    s.movz       s43, #8
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #512
    a.vread      v12, a11, s43
    s.movz       s43, #9
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #576
    a.vread      v12, a11, s43
    s.movz       s43, #10
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #640
    a.vread      v12, a11, s43
    s.movz       s43, #11
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #704
    a.vread      v12, a11, s43
    s.movz       s43, #12
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #768
    a.vread      v12, a11, s43
    s.movz       s43, #13
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #832
    a.vread      v12, a11, s43
    s.movz       s43, #14
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #896
    a.vread      v12, a11, s43
    s.movz       s43, #15
    s.addi       s46, s44, #960
    v.st.w       [s45, #0], v12
    a.vread      v12, a11, s43
    s.movz       s43, #0
    s.addi       s44, s31, #7168
    v.st.w       [s46, #0], v12
    fence.acq_rel.device
    a.vread      v12, a12, s43
    s.movz       s43, #1
    s.addi       s45, s44, #64
    v.st.w       [s44, #0], v12
    a.vread      v12, a12, s43
    s.movz       s43, #2
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #128
    a.vread      v12, a12, s43
    s.movz       s43, #3
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #192
    a.vread      v12, a12, s43
    s.movz       s43, #4
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #256
    a.vread      v12, a12, s43
    s.movz       s43, #5
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #320
    a.vread      v12, a12, s43
    s.movz       s43, #6
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #384
    a.vread      v12, a12, s43
    s.movz       s43, #7
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #448
    a.vread      v12, a12, s43
    s.movz       s43, #8
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #512
    a.vread      v12, a12, s43
    s.movz       s43, #9
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #576
    a.vread      v12, a12, s43
    s.movz       s43, #10
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #640
    a.vread      v12, a12, s43
    s.movz       s43, #11
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #704
    a.vread      v12, a12, s43
    s.movz       s43, #12
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #768
    a.vread      v12, a12, s43
    s.movz       s43, #13
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #832
    a.vread      v12, a12, s43
    s.movz       s43, #14
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #896
    a.vread      v12, a12, s43
    s.movz       s43, #15
    s.addi       s46, s44, #960
    v.st.w       [s45, #0], v12
    a.vread      v12, a12, s43
    s.movz       s43, #0
    s.addi       s44, s31, #8192
    v.st.w       [s46, #0], v12
    fence.acq_rel.device
    a.vread      v12, a13, s43
    s.movz       s43, #1
    s.addi       s45, s44, #64
    v.st.w       [s44, #0], v12
    a.vread      v12, a13, s43
    s.movz       s43, #2
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #128
    a.vread      v12, a13, s43
    s.movz       s43, #3
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #192
    a.vread      v12, a13, s43
    s.movz       s43, #4
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #256
    a.vread      v12, a13, s43
    s.movz       s43, #5
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #320
    a.vread      v12, a13, s43
    s.movz       s43, #6
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #384
    a.vread      v12, a13, s43
    s.movz       s43, #7
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #448
    a.vread      v12, a13, s43
    s.movz       s43, #8
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #512
    a.vread      v12, a13, s43
    s.movz       s43, #9
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #576
    a.vread      v12, a13, s43
    s.movz       s43, #10
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #640
    a.vread      v12, a13, s43
    s.movz       s43, #11
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #704
    a.vread      v12, a13, s43
    s.movz       s43, #12
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #768
    a.vread      v12, a13, s43
    s.movz       s43, #13
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #832
    a.vread      v12, a13, s43
    s.movz       s43, #14
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #896
    a.vread      v12, a13, s43
    s.movz       s43, #15
    s.addi       s46, s44, #960
    v.st.w       [s45, #0], v12
    a.vread      v12, a13, s43
    s.movz       s43, #0
    s.addi       s44, s31, #9216
    v.st.w       [s46, #0], v12
    fence.acq_rel.device
    a.vread      v12, a14, s43
    s.movz       s43, #1
    s.addi       s45, s44, #64
    v.st.w       [s44, #0], v12
    a.vread      v12, a14, s43
    s.movz       s43, #2
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #128
    a.vread      v12, a14, s43
    s.movz       s43, #3
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #192
    a.vread      v12, a14, s43
    s.movz       s43, #4
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #256
    a.vread      v12, a14, s43
    s.movz       s43, #5
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #320
    a.vread      v12, a14, s43
    s.movz       s43, #6
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #384
    a.vread      v12, a14, s43
    s.movz       s43, #7
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #448
    a.vread      v12, a14, s43
    s.movz       s43, #8
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #512
    a.vread      v12, a14, s43
    s.movz       s43, #9
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #576
    a.vread      v12, a14, s43
    s.movz       s43, #10
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #640
    a.vread      v12, a14, s43
    s.movz       s43, #11
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #704
    a.vread      v12, a14, s43
    s.movz       s43, #12
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #768
    a.vread      v12, a14, s43
    s.movz       s43, #13
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #832
    a.vread      v12, a14, s43
    s.movz       s43, #14
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #896
    a.vread      v12, a14, s43
    s.movz       s43, #15
    s.addi       s46, s44, #960
    v.st.w       [s45, #0], v12
    a.vread      v12, a14, s43
    s.movz       s43, #0
    s.addi       s44, s31, #10240
    v.st.w       [s46, #0], v12
    fence.acq_rel.device
    a.vread      v12, a15, s43
    s.movz       s43, #1
    s.addi       s45, s44, #64
    v.st.w       [s44, #0], v12
    a.vread      v12, a15, s43
    s.movz       s43, #2
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #128
    a.vread      v12, a15, s43
    s.movz       s43, #3
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #192
    a.vread      v12, a15, s43
    s.movz       s43, #4
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #256
    a.vread      v12, a15, s43
    s.movz       s43, #5
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #320
    a.vread      v12, a15, s43
    s.movz       s43, #6
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #384
    a.vread      v12, a15, s43
    s.movz       s43, #7
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #448
    a.vread      v12, a15, s43
    s.movz       s43, #8
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #512
    a.vread      v12, a15, s43
    s.movz       s43, #9
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #576
    a.vread      v12, a15, s43
    s.movz       s43, #10
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #640
    a.vread      v12, a15, s43
    s.movz       s43, #11
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #704
    a.vread      v12, a15, s43
    s.movz       s43, #12
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #768
    a.vread      v12, a15, s43
    s.movz       s43, #13
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #832
    a.vread      v12, a15, s43
    s.movz       s43, #14
    v.st.w       [s45, #0], v12
    s.addi       s45, s44, #896
    a.vread      v12, a15, s43
    s.movz       s43, #15
    s.addi       s46, s44, #960
    v.st.w       [s45, #0], v12
    a.vread      v12, a15, s43
    s.movz       s43, #0
    s.addi       s44, s31, #3072
    v.st.w       [s46, #0], v12
    fence.acq_rel.device
    a.vread      v12, a0, s43
    s.addi       s43, s31, #11264
    s.movz       s45, #1
    v.ld.w       v17, [s44, #0]
    s.addi       s44, s31, #3136
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s43, #0], v17
    a.vread      v12, a0, s45
    s.addi       s45, s43, #64
    v.ld.w       v17, [s44, #0]
    s.movz       s44, #2
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s45, #0], v17
    s.addi       s45, s31, #3200
    a.vread      v12, a0, s44
    s.addi       s44, s43, #128
    v.ld.w       v17, [s45, #0]
    s.movz       s45, #3
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s44, #0], v17
    s.addi       s44, s31, #3264
    a.vread      v12, a0, s45
    s.addi       s45, s43, #192
    v.ld.w       v17, [s44, #0]
    s.movz       s44, #4
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s45, #0], v17
    s.addi       s45, s31, #3328
    a.vread      v12, a0, s44
    s.addi       s44, s43, #256
    v.ld.w       v17, [s45, #0]
    s.movz       s45, #5
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s44, #0], v17
    s.addi       s44, s31, #3392
    a.vread      v12, a0, s45
    s.addi       s45, s43, #320
    v.ld.w       v17, [s44, #0]
    s.movz       s44, #6
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s45, #0], v17
    s.addi       s45, s31, #3456
    a.vread      v12, a0, s44
    s.addi       s44, s43, #384
    v.ld.w       v17, [s45, #0]
    s.movz       s45, #7
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s44, #0], v17
    s.addi       s44, s31, #3520
    a.vread      v12, a0, s45
    s.addi       s45, s43, #448
    v.ld.w       v17, [s44, #0]
    s.movz       s44, #8
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s45, #0], v17
    s.addi       s45, s31, #3584
    a.vread      v12, a0, s44
    s.addi       s44, s43, #512
    v.ld.w       v17, [s45, #0]
    s.movz       s45, #9
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s44, #0], v17
    s.addi       s44, s31, #3648
    a.vread      v12, a0, s45
    s.addi       s45, s43, #576
    v.ld.w       v17, [s44, #0]
    s.movz       s44, #10
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s45, #0], v17
    s.addi       s45, s31, #3712
    a.vread      v12, a0, s44
    s.addi       s44, s43, #640
    v.ld.w       v17, [s45, #0]
    s.movz       s45, #11
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s44, #0], v17
    s.addi       s44, s31, #3776
    a.vread      v12, a0, s45
    s.addi       s45, s43, #704
    v.ld.w       v17, [s44, #0]
    s.movz       s44, #12
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s45, #0], v17
    s.addi       s45, s31, #3840
    a.vread      v12, a0, s44
    s.addi       s44, s43, #768
    v.ld.w       v17, [s45, #0]
    s.movz       s45, #13
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s44, #0], v17
    s.addi       s44, s31, #3904
    a.vread      v12, a0, s45
    s.addi       s45, s43, #832
    v.ld.w       v17, [s44, #0]
    s.movz       s44, #14
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s45, #0], v17
    s.addi       s45, s31, #3968
    a.vread      v12, a0, s44
    s.addi       s44, s43, #896
    s.addi       s46, s43, #960
    v.ld.w       v17, [s45, #0]
    s.movz       s43, #15
    vf.mul       v18, v17, v14
    vf.add       v17, v12, v18
    v.st.w       [s44, #0], v17
    s.addi       s44, s31, #4032
    a.vread      v12, a0, s43
    s.movz       s43, #0
    v.ld.w       v17, [s44, #0]
    s.addi       s44, s31, #4096
    vf.mul       v18, v17, v14
    vf.add       v14, v12, v18
    v.st.w       [s46, #0], v14
    fence.acq_rel.device
    a.vread      v12, a1, s43
    s.addi       s43, s31, #12288
    s.movz       s45, #1
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #4160
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s43, #0], v14
    a.vread      v12, a1, s45
    s.addi       s45, s43, #64
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #2
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #4224
    a.vread      v12, a1, s44
    s.addi       s44, s43, #128
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #3
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #4288
    a.vread      v12, a1, s45
    s.addi       s45, s43, #192
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #4
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #4352
    a.vread      v12, a1, s44
    s.addi       s44, s43, #256
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #5
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #4416
    a.vread      v12, a1, s45
    s.addi       s45, s43, #320
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #6
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #4480
    a.vread      v12, a1, s44
    s.addi       s44, s43, #384
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #7
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #4544
    a.vread      v12, a1, s45
    s.addi       s45, s43, #448
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #8
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #4608
    a.vread      v12, a1, s44
    s.addi       s44, s43, #512
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #9
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #4672
    a.vread      v12, a1, s45
    s.addi       s45, s43, #576
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #10
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #4736
    a.vread      v12, a1, s44
    s.addi       s44, s43, #640
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #11
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #4800
    a.vread      v12, a1, s45
    s.addi       s45, s43, #704
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #12
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #4864
    a.vread      v12, a1, s44
    s.addi       s44, s43, #768
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #13
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #4928
    a.vread      v12, a1, s45
    s.addi       s45, s43, #832
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #14
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #4992
    a.vread      v12, a1, s44
    s.addi       s44, s43, #896
    s.addi       s46, s43, #960
    v.ld.w       v14, [s45, #0]
    s.movz       s43, #15
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #5056
    a.vread      v12, a1, s43
    s.movz       s43, #0
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #5120
    vf.mul       v17, v14, v27
    vf.add       v14, v12, v17
    v.st.w       [s46, #0], v14
    fence.acq_rel.device
    a.vread      v12, a2, s43
    s.addi       s43, s31, #13312
    s.movz       s45, #1
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #5184
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s43, #0], v14
    a.vread      v12, a2, s45
    s.addi       s45, s43, #64
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #2
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #5248
    a.vread      v12, a2, s44
    s.addi       s44, s43, #128
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #3
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #5312
    a.vread      v12, a2, s45
    s.addi       s45, s43, #192
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #4
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #5376
    a.vread      v12, a2, s44
    s.addi       s44, s43, #256
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #5
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #5440
    a.vread      v12, a2, s45
    s.addi       s45, s43, #320
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #6
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #5504
    a.vread      v12, a2, s44
    s.addi       s44, s43, #384
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #7
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #5568
    a.vread      v12, a2, s45
    s.addi       s45, s43, #448
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #8
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #5632
    a.vread      v12, a2, s44
    s.addi       s44, s43, #512
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #9
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #5696
    a.vread      v12, a2, s45
    s.addi       s45, s43, #576
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #10
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #5760
    a.vread      v12, a2, s44
    s.addi       s44, s43, #640
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #11
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #5824
    a.vread      v12, a2, s45
    s.addi       s45, s43, #704
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #12
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #5888
    a.vread      v12, a2, s44
    s.addi       s44, s43, #768
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #13
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #5952
    a.vread      v12, a2, s45
    s.addi       s45, s43, #832
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #14
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #6016
    a.vread      v12, a2, s44
    s.addi       s44, s43, #896
    s.addi       s46, s43, #960
    v.ld.w       v14, [s45, #0]
    s.movz       s43, #15
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #6080
    a.vread      v12, a2, s43
    s.movz       s43, #0
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #6144
    vf.mul       v17, v14, v28
    vf.add       v14, v12, v17
    v.st.w       [s46, #0], v14
    fence.acq_rel.device
    a.vread      v12, a3, s43
    s.addi       s43, s31, #14336
    s.movz       s45, #1
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #6208
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s43, #0], v14
    a.vread      v12, a3, s45
    s.addi       s45, s43, #64
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #2
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #6272
    a.vread      v12, a3, s44
    s.addi       s44, s43, #128
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #3
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #6336
    a.vread      v12, a3, s45
    s.addi       s45, s43, #192
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #4
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #6400
    a.vread      v12, a3, s44
    s.addi       s44, s43, #256
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #5
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #6464
    a.vread      v12, a3, s45
    s.addi       s45, s43, #320
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #6
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #6528
    a.vread      v12, a3, s44
    s.addi       s44, s43, #384
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #7
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #6592
    a.vread      v12, a3, s45
    s.addi       s45, s43, #448
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #8
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #6656
    a.vread      v12, a3, s44
    s.addi       s44, s43, #512
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #9
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #6720
    a.vread      v12, a3, s45
    s.addi       s45, s43, #576
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #10
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #6784
    a.vread      v12, a3, s44
    s.addi       s44, s43, #640
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #11
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #6848
    a.vread      v12, a3, s45
    s.addi       s45, s43, #704
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #12
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #6912
    a.vread      v12, a3, s44
    s.addi       s44, s43, #768
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #13
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #6976
    a.vread      v12, a3, s45
    s.addi       s45, s43, #832
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #14
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #7040
    a.vread      v12, a3, s44
    s.addi       s44, s43, #896
    s.addi       s46, s43, #960
    v.ld.w       v14, [s45, #0]
    s.movz       s43, #15
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #7104
    a.vread      v12, a3, s43
    s.movz       s43, #0
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #7168
    vf.mul       v17, v14, v29
    vf.add       v14, v12, v17
    v.st.w       [s46, #0], v14
    fence.acq_rel.device
    a.vread      v12, a4, s43
    s.addi       s43, s31, #15360
    s.movz       s45, #1
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #7232
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s43, #0], v14
    a.vread      v12, a4, s45
    s.addi       s45, s43, #64
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #2
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #7296
    a.vread      v12, a4, s44
    s.addi       s44, s43, #128
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #3
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #7360
    a.vread      v12, a4, s45
    s.addi       s45, s43, #192
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #4
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #7424
    a.vread      v12, a4, s44
    s.addi       s44, s43, #256
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #5
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #7488
    a.vread      v12, a4, s45
    s.addi       s45, s43, #320
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #6
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #7552
    a.vread      v12, a4, s44
    s.addi       s44, s43, #384
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #7
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #7616
    a.vread      v12, a4, s45
    s.addi       s45, s43, #448
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #8
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #7680
    a.vread      v12, a4, s44
    s.addi       s44, s43, #512
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #9
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #7744
    a.vread      v12, a4, s45
    s.addi       s45, s43, #576
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #10
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #7808
    a.vread      v12, a4, s44
    s.addi       s44, s43, #640
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #11
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #7872
    a.vread      v12, a4, s45
    s.addi       s45, s43, #704
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #12
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #7936
    a.vread      v12, a4, s44
    s.addi       s44, s43, #768
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #13
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #8000
    a.vread      v12, a4, s45
    s.addi       s45, s43, #832
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #14
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #8064
    a.vread      v12, a4, s44
    s.addi       s44, s43, #896
    s.addi       s46, s43, #960
    v.ld.w       v14, [s45, #0]
    s.movz       s43, #15
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #8128
    a.vread      v12, a4, s43
    s.movz       s43, #0
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #8192
    vf.mul       v17, v14, v30
    vf.add       v14, v12, v17
    v.st.w       [s46, #0], v14
    fence.acq_rel.device
    a.vread      v12, a5, s43
    s.addi       s43, s31, #16384
    s.movz       s45, #1
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #8256
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s43, #0], v14
    a.vread      v12, a5, s45
    s.addi       s45, s43, #64
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #2
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #8320
    a.vread      v12, a5, s44
    s.addi       s44, s43, #128
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #3
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #8384
    a.vread      v12, a5, s45
    s.addi       s45, s43, #192
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #4
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #8448
    a.vread      v12, a5, s44
    s.addi       s44, s43, #256
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #5
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #8512
    a.vread      v12, a5, s45
    s.addi       s45, s43, #320
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #6
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #8576
    a.vread      v12, a5, s44
    s.addi       s44, s43, #384
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #7
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #8640
    a.vread      v12, a5, s45
    s.addi       s45, s43, #448
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #8
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #8704
    a.vread      v12, a5, s44
    s.addi       s44, s43, #512
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #9
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #8768
    a.vread      v12, a5, s45
    s.addi       s45, s43, #576
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #10
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #8832
    a.vread      v12, a5, s44
    s.addi       s44, s43, #640
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #11
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #8896
    a.vread      v12, a5, s45
    s.addi       s45, s43, #704
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #12
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #8960
    a.vread      v12, a5, s44
    s.addi       s44, s43, #768
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #13
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #9024
    a.vread      v12, a5, s45
    s.addi       s45, s43, #832
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #14
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #9088
    a.vread      v12, a5, s44
    s.addi       s44, s43, #896
    s.addi       s46, s43, #960
    v.ld.w       v14, [s45, #0]
    s.movz       s43, #15
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #9152
    a.vread      v12, a5, s43
    s.movz       s43, #0
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #9216
    vf.mul       v17, v14, v31
    vf.add       v14, v12, v17
    v.st.w       [s46, #0], v14
    fence.acq_rel.device
    a.vread      v12, a6, s43
    s.addi       s43, s31, #17408
    s.movz       s45, #1
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #9280
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s43, #0], v14
    a.vread      v12, a6, s45
    s.addi       s45, s43, #64
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #2
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #9344
    a.vread      v12, a6, s44
    s.addi       s44, s43, #128
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #3
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #9408
    a.vread      v12, a6, s45
    s.addi       s45, s43, #192
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #4
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #9472
    a.vread      v12, a6, s44
    s.addi       s44, s43, #256
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #5
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #9536
    a.vread      v12, a6, s45
    s.addi       s45, s43, #320
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #6
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #9600
    a.vread      v12, a6, s44
    s.addi       s44, s43, #384
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #7
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #9664
    a.vread      v12, a6, s45
    s.addi       s45, s43, #448
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #8
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #9728
    a.vread      v12, a6, s44
    s.addi       s44, s43, #512
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #9
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #9792
    a.vread      v12, a6, s45
    s.addi       s45, s43, #576
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #10
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #9856
    a.vread      v12, a6, s44
    s.addi       s44, s43, #640
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #11
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #9920
    a.vread      v12, a6, s45
    s.addi       s45, s43, #704
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #12
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #9984
    a.vread      v12, a6, s44
    s.addi       s44, s43, #768
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #13
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #10048
    a.vread      v12, a6, s45
    s.addi       s45, s43, #832
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #14
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #10112
    a.vread      v12, a6, s44
    s.addi       s44, s43, #896
    s.addi       s46, s43, #960
    v.ld.w       v14, [s45, #0]
    s.movz       s43, #15
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #10176
    a.vread      v12, a6, s43
    s.movz       s43, #0
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #10240
    vf.mul       v17, v14, v32
    vf.add       v14, v12, v17
    v.st.w       [s46, #0], v14
    fence.acq_rel.device
    a.vread      v12, a7, s43
    s.addi       s43, s31, #18432
    s.movz       s45, #1
    v.ld.w       v14, [s44, #0]
    s.addi       s44, s31, #10304
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s43, #0], v14
    a.vread      v12, a7, s45
    s.addi       s45, s43, #64
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #2
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #10368
    a.vread      v12, a7, s44
    s.addi       s44, s43, #128
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #3
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #10432
    a.vread      v12, a7, s45
    s.addi       s45, s43, #192
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #4
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #10496
    a.vread      v12, a7, s44
    s.addi       s44, s43, #256
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #5
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #10560
    a.vread      v12, a7, s45
    s.addi       s45, s43, #320
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #6
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #10624
    a.vread      v12, a7, s44
    s.addi       s44, s43, #384
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #7
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #10688
    a.vread      v12, a7, s45
    s.addi       s45, s43, #448
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #8
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #10752
    a.vread      v12, a7, s44
    s.addi       s44, s43, #512
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #9
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #10816
    a.vread      v12, a7, s45
    s.addi       s45, s43, #576
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #10
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #10880
    a.vread      v12, a7, s44
    s.addi       s44, s43, #640
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #11
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #10944
    a.vread      v12, a7, s45
    s.addi       s45, s43, #704
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #12
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #11008
    a.vread      v12, a7, s44
    s.addi       s44, s43, #768
    v.ld.w       v14, [s45, #0]
    s.movz       s45, #13
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #11072
    a.vread      v12, a7, s45
    s.addi       s45, s43, #832
    v.ld.w       v14, [s44, #0]
    s.movz       s44, #14
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s45, #0], v14
    s.addi       s45, s31, #11136
    a.vread      v12, a7, s44
    s.addi       s44, s43, #896
    s.addi       s46, s43, #960
    v.ld.w       v14, [s45, #0]
    s.movz       s43, #15
    vf.mul       v17, v14, v33
    vf.add       v14, v12, v17
    v.st.w       [s44, #0], v14
    s.addi       s44, s31, #11200
    a.vread      v12, a7, s43
    s.addi       s43, s27, #128
    s.addi       s45, s24, #4                    // &ptr_carry_19[1] (a constant offset, x4)
    s.addi       s45, s43, #0
    s.addi       s43, s24, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    s.addi       s43, s24, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    s.addi       s43, s24, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    s.addi       s43, s24, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    v.ld.w       v14, [s44, #0]
    s.addi       s43, s25, #128
    s.addi       s44, s24, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    s.addi       s44, s43, #0
    vf.mul       v17, v14, v33
    s.addi       s43, s24, #4                    // &ptr_carry_25[1] (a constant offset, x4)
    vf.add       v14, v12, v17
    v.st.w       [s46, #0], v14
    s.addi       s43, s24, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    fence.acq_rel.device
    s.addi       s46, s43, #0
    s.mov        s27, s45
    s.addi       s43, s31, #11264
    s.mov        s25, s44
    s.mov        s24, s46
    s.movz       s44, #0
    s.addi       s45, s31, #11328
    v.ld.w       v12, [s43, #0]
    s.movz       s43, #1
    s.addi       s46, s31, #11392
    s.movz       s47, #2
    s.addi       s48, s31, #11456
    a.vwrite     a0, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #3
    s.addi       s45, s31, #11520
    a.vwrite     a0, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #4
    s.addi       s46, s31, #11584
    a.vwrite     a0, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #5
    s.addi       s48, s31, #11648
    a.vwrite     a0, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #6
    s.addi       s45, s31, #11712
    a.vwrite     a0, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #7
    s.addi       s46, s31, #11776
    a.vwrite     a0, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #8
    s.addi       s48, s31, #11840
    a.vwrite     a0, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #9
    s.addi       s45, s31, #11904
    a.vwrite     a0, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #10
    s.addi       s46, s31, #11968
    a.vwrite     a0, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #11
    s.addi       s48, s31, #12032
    a.vwrite     a0, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #12
    s.addi       s45, s31, #12096
    a.vwrite     a0, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #13
    s.addi       s46, s31, #12160
    a.vwrite     a0, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #14
    s.addi       s48, s31, #12224
    a.vwrite     a0, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #15
    s.addi       s45, s31, #12288
    a.vwrite     a0, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #0
    s.addi       s46, s31, #12352
    a.vwrite     a0, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #1
    s.addi       s48, s31, #12416
    a.vwrite     a0, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #2
    s.addi       s45, s31, #12480
    a.vwrite     a1, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #3
    s.addi       s46, s31, #12544
    a.vwrite     a1, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #4
    s.addi       s48, s31, #12608
    a.vwrite     a1, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #5
    s.addi       s45, s31, #12672
    a.vwrite     a1, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #6
    s.addi       s46, s31, #12736
    a.vwrite     a1, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #7
    s.addi       s48, s31, #12800
    a.vwrite     a1, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #8
    s.addi       s45, s31, #12864
    a.vwrite     a1, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #9
    s.addi       s46, s31, #12928
    a.vwrite     a1, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #10
    s.addi       s48, s31, #12992
    a.vwrite     a1, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #11
    s.addi       s45, s31, #13056
    a.vwrite     a1, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #12
    s.addi       s46, s31, #13120
    a.vwrite     a1, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #13
    s.addi       s48, s31, #13184
    a.vwrite     a1, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #14
    s.addi       s45, s31, #13248
    a.vwrite     a1, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #15
    s.addi       s46, s31, #13312
    a.vwrite     a1, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #0
    s.addi       s48, s31, #13376
    a.vwrite     a1, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #1
    s.addi       s45, s31, #13440
    a.vwrite     a1, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #2
    s.addi       s46, s31, #13504
    a.vwrite     a2, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #3
    s.addi       s48, s31, #13568
    a.vwrite     a2, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #4
    s.addi       s45, s31, #13632
    a.vwrite     a2, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #5
    s.addi       s46, s31, #13696
    a.vwrite     a2, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #6
    s.addi       s48, s31, #13760
    a.vwrite     a2, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #7
    s.addi       s45, s31, #13824
    a.vwrite     a2, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #8
    s.addi       s46, s31, #13888
    a.vwrite     a2, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #9
    s.addi       s48, s31, #13952
    a.vwrite     a2, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #10
    s.addi       s45, s31, #14016
    a.vwrite     a2, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #11
    s.addi       s46, s31, #14080
    a.vwrite     a2, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #12
    s.addi       s48, s31, #14144
    a.vwrite     a2, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #13
    s.addi       s45, s31, #14208
    a.vwrite     a2, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #14
    s.addi       s46, s31, #14272
    a.vwrite     a2, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #15
    s.addi       s48, s31, #14336
    a.vwrite     a2, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #0
    s.addi       s45, s31, #14400
    a.vwrite     a2, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #1
    s.addi       s46, s31, #14464
    a.vwrite     a2, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #2
    s.addi       s48, s31, #14528
    a.vwrite     a3, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #3
    s.addi       s45, s31, #14592
    a.vwrite     a3, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #4
    s.addi       s46, s31, #14656
    a.vwrite     a3, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #5
    s.addi       s48, s31, #14720
    a.vwrite     a3, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #6
    s.addi       s45, s31, #14784
    a.vwrite     a3, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #7
    s.addi       s46, s31, #14848
    a.vwrite     a3, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #8
    s.addi       s48, s31, #14912
    a.vwrite     a3, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #9
    s.addi       s45, s31, #14976
    a.vwrite     a3, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #10
    s.addi       s46, s31, #15040
    a.vwrite     a3, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #11
    s.addi       s48, s31, #15104
    a.vwrite     a3, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #12
    s.addi       s45, s31, #15168
    a.vwrite     a3, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #13
    s.addi       s46, s31, #15232
    a.vwrite     a3, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #14
    s.addi       s48, s31, #15296
    a.vwrite     a3, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #15
    s.addi       s45, s31, #15360
    a.vwrite     a3, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #0
    s.addi       s46, s31, #15424
    a.vwrite     a3, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #1
    s.addi       s48, s31, #15488
    a.vwrite     a3, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #2
    s.addi       s45, s31, #15552
    a.vwrite     a4, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #3
    s.addi       s46, s31, #15616
    a.vwrite     a4, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #4
    s.addi       s48, s31, #15680
    a.vwrite     a4, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #5
    s.addi       s45, s31, #15744
    a.vwrite     a4, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #6
    s.addi       s46, s31, #15808
    a.vwrite     a4, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #7
    s.addi       s48, s31, #15872
    a.vwrite     a4, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #8
    s.addi       s45, s31, #15936
    a.vwrite     a4, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #9
    s.addi       s46, s31, #16000
    a.vwrite     a4, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #10
    s.addi       s48, s31, #16064
    a.vwrite     a4, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #11
    s.addi       s45, s31, #16128
    a.vwrite     a4, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #12
    s.addi       s46, s31, #16192
    a.vwrite     a4, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #13
    s.addi       s48, s31, #16256
    a.vwrite     a4, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #14
    s.addi       s45, s31, #16320
    a.vwrite     a4, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #15
    s.addi       s46, s31, #16384
    a.vwrite     a4, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #0
    s.addi       s48, s31, #16448
    a.vwrite     a4, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #1
    s.addi       s45, s31, #16512
    a.vwrite     a4, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #2
    s.addi       s46, s31, #16576
    a.vwrite     a5, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #3
    s.addi       s48, s31, #16640
    a.vwrite     a5, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #4
    s.addi       s45, s31, #16704
    a.vwrite     a5, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #5
    s.addi       s46, s31, #16768
    a.vwrite     a5, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #6
    s.addi       s48, s31, #16832
    a.vwrite     a5, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #7
    s.addi       s45, s31, #16896
    a.vwrite     a5, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #8
    s.addi       s46, s31, #16960
    a.vwrite     a5, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #9
    s.addi       s48, s31, #17024
    a.vwrite     a5, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #10
    s.addi       s45, s31, #17088
    a.vwrite     a5, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #11
    s.addi       s46, s31, #17152
    a.vwrite     a5, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #12
    s.addi       s48, s31, #17216
    a.vwrite     a5, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #13
    s.addi       s45, s31, #17280
    a.vwrite     a5, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #14
    s.addi       s46, s31, #17344
    a.vwrite     a5, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #15
    s.addi       s48, s31, #17408
    a.vwrite     a5, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #0
    s.addi       s45, s31, #17472
    a.vwrite     a5, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #1
    s.addi       s46, s31, #17536
    a.vwrite     a5, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #2
    s.addi       s48, s31, #17600
    a.vwrite     a6, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #3
    s.addi       s45, s31, #17664
    a.vwrite     a6, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #4
    s.addi       s46, s31, #17728
    a.vwrite     a6, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #5
    s.addi       s48, s31, #17792
    a.vwrite     a6, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #6
    s.addi       s45, s31, #17856
    a.vwrite     a6, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #7
    s.addi       s46, s31, #17920
    a.vwrite     a6, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #8
    s.addi       s48, s31, #17984
    a.vwrite     a6, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #9
    s.addi       s45, s31, #18048
    a.vwrite     a6, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #10
    s.addi       s46, s31, #18112
    a.vwrite     a6, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #11
    s.addi       s48, s31, #18176
    a.vwrite     a6, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #12
    s.addi       s45, s31, #18240
    a.vwrite     a6, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #13
    s.addi       s46, s31, #18304
    a.vwrite     a6, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #14
    s.addi       s48, s31, #18368
    a.vwrite     a6, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #15
    s.addi       s45, s31, #18432
    a.vwrite     a6, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #0
    s.addi       s46, s31, #18496
    a.vwrite     a6, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #1
    s.addi       s48, s31, #18560
    a.vwrite     a6, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #2
    s.addi       s45, s31, #18624
    a.vwrite     a7, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #3
    s.addi       s46, s31, #18688
    a.vwrite     a7, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #4
    s.addi       s48, s31, #18752
    a.vwrite     a7, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #5
    s.addi       s45, s31, #18816
    a.vwrite     a7, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #6
    s.addi       s46, s31, #18880
    a.vwrite     a7, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #7
    s.addi       s48, s31, #18944
    a.vwrite     a7, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #8
    s.addi       s45, s31, #19008
    a.vwrite     a7, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #9
    s.addi       s46, s31, #19072
    a.vwrite     a7, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #10
    s.addi       s48, s31, #19136
    a.vwrite     a7, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #11
    s.addi       s45, s31, #19200
    a.vwrite     a7, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #12
    s.addi       s46, s31, #19264
    a.vwrite     a7, s47, v12
    v.ld.w       v12, [s48, #0]
    s.movz       s47, #13
    s.addi       s48, s31, #19328
    s.addi       s49, s31, #19392
    a.vwrite     a7, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s31, #14
    s.movz       s44, #15
    s.add        s45, s13, s1
    a.vwrite     a7, s43, v12
    v.ld.w       v12, [s46, #0]
    s.movz       s43, #1
    a.vwrite     a7, s47, v12
    v.ld.w       v12, [s48, #0]
    a.vwrite     a7, s31, v12
    v.ld.w       v12, [s49, #0]
    a.vwrite     a7, s44, v12
    s.mov        s13, s45
    br.nz        s43, for_26
endfor_27:
    s.mul        s1, s4, s7
    s.movz       s2, #0
    v.splat      v0, s28
    a.vread      v1, a0, s2
    s.muli       s2, s5, #2
    s.muli       s8, s1, #2
    vf.mul       v2, v1, v0
    s.muli       s1, s7, #2
    s.addi       s7, s5, #16
    s.addi       s9, s5, #32
    s.movz       s10, #0
    vf.cvt.f32.bf16 v1, v2
    s.add        s13, s8, s2
    s.addi       s14, s5, #48
    s.add        s15, s10, s4                    // the tile origin
    s.add        s4, s11, s13
    s.addi       s10, s5, #64
    v.splat      v2, s15
    s.addi       s13, s5, #80
    s.movz       s16, #0
    s.addi       s17, s5, #96
    s.add        s18, s16, s6                    // the tile origin
    s.addi       s6, s5, #112
    s.movz       s16, #0
    v.iota       v3                              // arange(0, VLEN)
    s.add        s19, s16, s5                    // the tile origin
    s.movz       s5, #0
    v.splat      v4, s19
    s.add        s16, s5, s3                     // the tile origin
    v.splat      v5, s18
    v.add        v6, v3, v4
    v.cmp.lt     p1, v2, v5
    v.splat      v2, s16
    s.movz       s5, #1
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    s.muli       s16, s1, #1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a0, s5
    s.addi       s4, s15, #1
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.muli       s16, s1, #2
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #2
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #3
    s.muli       s16, s1, #3
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #3
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #4
    s.muli       s16, s1, #4
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #4
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #5
    s.muli       s16, s1, #5
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #5
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #6
    s.muli       s16, s1, #6
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #6
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #7
    s.muli       s16, s1, #7
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #7
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #8
    s.muli       s16, s1, #8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #8
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #9
    s.muli       s16, s1, #9
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #9
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #10
    s.muli       s16, s1, #10
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #10
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.muli       s16, s1, #11
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #11
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #12
    s.muli       s16, s1, #12
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #12
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #13
    s.muli       s16, s1, #13
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #13
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #14
    s.muli       s16, s1, #14
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #14
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #15
    s.muli       s16, s1, #15
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a0, s4
    s.addi       s4, s15, #15
    vf.mul       v2, v1, v0
    s.add        s5, s16, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s2, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #0
    s.movz       s5, #0
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a1, s4
    s.muli       s2, s7, #2
    s.add        s4, s5, s7                      // the tile origin
    s.movz       s5, #0
    vf.mul       v2, v1, v0
    v.splat      v1, s4
    s.add        s4, s5, s3                      // the tile origin
    v.splat      v4, s15
    v.add        v6, v3, v1
    vf.cvt.f32.bf16 v1, v2
    s.add        s5, s8, s2
    v.cmp.lt     p1, v4, v5
    v.splat      v2, s4
    s.add        s4, s11, s5
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.muli       s7, s1, #1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a1, s5
    s.addi       s4, s15, #1
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.muli       s7, s1, #2
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #2
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #3
    s.muli       s7, s1, #3
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #3
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #4
    s.muli       s7, s1, #4
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #4
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #5
    s.muli       s7, s1, #5
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #5
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #6
    s.muli       s7, s1, #6
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #6
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #7
    s.muli       s7, s1, #7
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #7
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #8
    s.muli       s7, s1, #8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #8
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #9
    s.muli       s7, s1, #9
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #9
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #10
    s.muli       s7, s1, #10
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #10
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.muli       s7, s1, #11
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #11
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #12
    s.muli       s7, s1, #12
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #12
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #13
    s.muli       s7, s1, #13
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #13
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #14
    s.muli       s7, s1, #14
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #14
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #15
    s.muli       s7, s1, #15
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a1, s4
    s.addi       s4, s15, #15
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s2, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #0
    s.movz       s5, #0
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a2, s4
    s.muli       s2, s9, #2
    s.add        s4, s5, s9                      // the tile origin
    s.movz       s5, #0
    vf.mul       v2, v1, v0
    v.splat      v1, s4
    s.add        s4, s5, s3                      // the tile origin
    v.splat      v4, s15
    v.add        v6, v3, v1
    vf.cvt.f32.bf16 v1, v2
    s.add        s5, s8, s2
    v.cmp.lt     p1, v4, v5
    v.splat      v2, s4
    s.add        s4, s11, s5
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.muli       s7, s1, #1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a2, s5
    s.addi       s4, s15, #1
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.muli       s7, s1, #2
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #2
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #3
    s.muli       s7, s1, #3
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #3
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #4
    s.muli       s7, s1, #4
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #4
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #5
    s.muli       s7, s1, #5
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #5
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #6
    s.muli       s7, s1, #6
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #6
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #7
    s.muli       s7, s1, #7
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #7
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #8
    s.muli       s7, s1, #8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #8
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #9
    s.muli       s7, s1, #9
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #9
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #10
    s.muli       s7, s1, #10
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #10
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.muli       s7, s1, #11
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #11
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #12
    s.muli       s7, s1, #12
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #12
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #13
    s.muli       s7, s1, #13
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #13
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #14
    s.muli       s7, s1, #14
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #14
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #15
    s.muli       s7, s1, #15
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a2, s4
    s.addi       s4, s15, #15
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s2, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #0
    s.movz       s5, #0
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a3, s4
    s.muli       s2, s14, #2
    s.add        s4, s5, s14                     // the tile origin
    s.movz       s5, #0
    vf.mul       v2, v1, v0
    v.splat      v1, s4
    s.add        s4, s5, s3                      // the tile origin
    v.splat      v4, s15
    v.add        v6, v3, v1
    vf.cvt.f32.bf16 v1, v2
    s.add        s5, s8, s2
    v.cmp.lt     p1, v4, v5
    v.splat      v2, s4
    s.add        s4, s11, s5
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.muli       s7, s1, #1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a3, s5
    s.addi       s4, s15, #1
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.muli       s7, s1, #2
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #2
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #3
    s.muli       s7, s1, #3
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #3
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #4
    s.muli       s7, s1, #4
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #4
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #5
    s.muli       s7, s1, #5
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #5
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #6
    s.muli       s7, s1, #6
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #6
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #7
    s.muli       s7, s1, #7
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #7
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #8
    s.muli       s7, s1, #8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #8
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #9
    s.muli       s7, s1, #9
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #9
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #10
    s.muli       s7, s1, #10
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #10
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.muli       s7, s1, #11
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #11
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #12
    s.muli       s7, s1, #12
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #12
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #13
    s.muli       s7, s1, #13
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #13
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #14
    s.muli       s7, s1, #14
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #14
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #15
    s.muli       s7, s1, #15
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a3, s4
    s.addi       s4, s15, #15
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s2, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #0
    s.movz       s5, #0
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a4, s4
    s.muli       s2, s10, #2
    s.add        s4, s5, s10                     // the tile origin
    s.movz       s5, #0
    vf.mul       v2, v1, v0
    v.splat      v1, s4
    s.add        s4, s5, s3                      // the tile origin
    v.splat      v4, s15
    v.add        v6, v3, v1
    vf.cvt.f32.bf16 v1, v2
    s.add        s5, s8, s2
    v.cmp.lt     p1, v4, v5
    v.splat      v2, s4
    s.add        s4, s11, s5
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.muli       s7, s1, #1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a4, s5
    s.addi       s4, s15, #1
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.muli       s7, s1, #2
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #2
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #3
    s.muli       s7, s1, #3
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #3
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #4
    s.muli       s7, s1, #4
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #4
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #5
    s.muli       s7, s1, #5
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #5
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #6
    s.muli       s7, s1, #6
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #6
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #7
    s.muli       s7, s1, #7
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #7
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #8
    s.muli       s7, s1, #8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #8
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #9
    s.muli       s7, s1, #9
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #9
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #10
    s.muli       s7, s1, #10
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #10
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.muli       s7, s1, #11
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #11
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #12
    s.muli       s7, s1, #12
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #12
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #13
    s.muli       s7, s1, #13
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #13
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #14
    s.muli       s7, s1, #14
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #14
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #15
    s.muli       s7, s1, #15
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a4, s4
    s.addi       s4, s15, #15
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s2, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #0
    s.movz       s5, #0
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a5, s4
    s.muli       s2, s13, #2
    s.add        s4, s5, s13                     // the tile origin
    s.movz       s5, #0
    vf.mul       v2, v1, v0
    v.splat      v1, s4
    s.add        s4, s5, s3                      // the tile origin
    v.splat      v4, s15
    v.add        v6, v3, v1
    vf.cvt.f32.bf16 v1, v2
    s.add        s5, s8, s2
    v.cmp.lt     p1, v4, v5
    v.splat      v2, s4
    s.add        s4, s11, s5
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.muli       s7, s1, #1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a5, s5
    s.addi       s4, s15, #1
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.muli       s7, s1, #2
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #2
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #3
    s.muli       s7, s1, #3
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #3
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #4
    s.muli       s7, s1, #4
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #4
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #5
    s.muli       s7, s1, #5
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #5
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #6
    s.muli       s7, s1, #6
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #6
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #7
    s.muli       s7, s1, #7
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #7
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #8
    s.muli       s7, s1, #8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #8
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #9
    s.muli       s7, s1, #9
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #9
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #10
    s.muli       s7, s1, #10
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #10
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.muli       s7, s1, #11
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #11
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #12
    s.muli       s7, s1, #12
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #12
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #13
    s.muli       s7, s1, #13
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #13
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #14
    s.muli       s7, s1, #14
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #14
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #15
    s.muli       s7, s1, #15
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a5, s4
    s.addi       s4, s15, #15
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s2, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #0
    s.movz       s5, #0
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a6, s4
    s.muli       s2, s17, #2
    s.add        s4, s5, s17                     // the tile origin
    s.movz       s5, #0
    vf.mul       v2, v1, v0
    v.splat      v1, s4
    s.add        s4, s5, s3                      // the tile origin
    v.splat      v4, s15
    v.add        v6, v3, v1
    vf.cvt.f32.bf16 v1, v2
    s.add        s5, s8, s2
    v.cmp.lt     p1, v4, v5
    v.splat      v2, s4
    s.add        s4, s11, s5
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.muli       s7, s1, #1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a6, s5
    s.addi       s4, s15, #1
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.muli       s7, s1, #2
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #2
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #3
    s.muli       s7, s1, #3
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #3
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #4
    s.muli       s7, s1, #4
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #4
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #5
    s.muli       s7, s1, #5
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #5
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #6
    s.muli       s7, s1, #6
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #6
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #7
    s.muli       s7, s1, #7
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #7
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #8
    s.muli       s7, s1, #8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #8
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #9
    s.muli       s7, s1, #9
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #9
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #10
    s.muli       s7, s1, #10
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #10
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.muli       s7, s1, #11
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #11
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #12
    s.muli       s7, s1, #12
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #12
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #13
    s.muli       s7, s1, #13
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #13
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #14
    s.muli       s7, s1, #14
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #14
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s5, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #15
    s.muli       s7, s1, #15
    @p3 v.st.h       [s5, #0], v4
    a.vread      v1, a6, s4
    s.addi       s4, s15, #15
    vf.mul       v2, v1, v0
    s.add        s5, s7, s8
    v.splat      v1, s4
    s.add        s4, s5, s2
    vf.cvt.f32.bf16 v4, v2
    v.cmp.lt     p1, v1, v5
    s.add        s2, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #0
    s.movz       s5, #0
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a7, s4
    s.muli       s2, s6, #2
    s.add        s4, s5, s6                      // the tile origin
    s.movz       s5, #0
    vf.mul       v2, v1, v0
    v.splat      v1, s4
    s.add        s4, s5, s3                      // the tile origin
    v.splat      v4, s15
    v.add        v6, v3, v1
    v.splat      v1, s4
    vf.cvt.f32.bf16 v3, v2
    s.add        s3, s8, s2
    v.cmp.lt     p1, v4, v5
    v.cmp.lt     p2, v6, v1
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #1
    s.muli       s5, s1, #1
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #1
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #2
    s.muli       s5, s1, #2
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #2
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #3
    s.muli       s5, s1, #3
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #3
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #4
    s.muli       s5, s1, #4
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #4
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #5
    s.muli       s5, s1, #5
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #5
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #6
    s.muli       s5, s1, #6
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #6
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #7
    s.muli       s5, s1, #7
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #7
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #8
    s.muli       s5, s1, #8
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #8
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #9
    s.muli       s5, s1, #9
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #9
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #10
    s.muli       s5, s1, #10
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #10
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #11
    s.muli       s5, s1, #11
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #11
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #12
    s.muli       s5, s1, #12
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #12
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #13
    s.muli       s5, s1, #13
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #13
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #14
    s.muli       s5, s1, #14
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s3, s15, #14
    vf.mul       v2, v1, v0
    s.add        s4, s5, s8
    v.splat      v1, s3
    s.add        s3, s4, s2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v1, v5
    s.add        s4, s11, s3
    p.and        p3, p1, p2
    s.movz       s3, #15
    s.muli       s5, s1, #15
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s3
    s.addi       s1, s15, #15
    vf.mul       v2, v1, v0
    s.add        s3, s5, s8
    v.splat      v0, s1
    s.add        s1, s3, s2
    vf.cvt.f32.bf16 v1, v2
    v.cmp.lt     p1, v0, v5
    s.add        s2, s11, s1
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v1
    exit
    exit
