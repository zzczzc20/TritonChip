import sys
from tnca.cli import sim_main
sys.exit(sim_main(['prepare', '--profile', sys.argv[1] if len(sys.argv) > 1 else 'core-vrf-sync-v5']))
