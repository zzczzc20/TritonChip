    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (2 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    .li       s9, #1054295293
    v.splat      v0, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
tiles_1:
    // tile 1 of the iteration: lanes t0 + 128
    s.addi       s9, s8, #128
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s10, s1, s8
    s.add        s11, s1, s9
    s.shli       s9, s10, #1
    s.shli       s12, s11, #1
    s.add        s13, s3, s9
    s.add        s9, s3, s12
    v.ld.h       v1, [s13, #0]
    s.shli       s12, s10, #2
    s.add        s10, s7, s12
    v.ld.h       v2, [s13, #32]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    v.ld.h       v3, [s13, #64]
    vf.cvt.f16.f32 v4, v2
    vf.mul       v2, v4, v0
    v.ld.h       v4, [s13, #96]
    vf.cvt.f16.f32 v5, v3
    vf.mul       v3, v5, v0
    v.ld.h       v5, [s13, #128]
    vf.cvt.f16.f32 v6, v4
    vf.mul       v4, v6, v0
    v.ld.h       v6, [s13, #160]
    vf.cvt.f16.f32 v7, v5
    vf.mul       v5, v7, v0
    v.ld.h       v7, [s13, #192]
    vf.cvt.f16.f32 v8, v6
    vf.mul       v6, v8, v0
    v.ld.h       v8, [s13, #224]
    vf.cvt.f16.f32 v9, v7
    vf.mul       v7, v9, v0
    v.ld.h       v9, [s9, #0]
    vf.cvt.f16.f32 v10, v8
    vf.mul       v8, v10, v0
    v.ld.h       v10, [s9, #32]
    vf.cvt.f16.f32 v11, v9
    vf.mul       v9, v11, v0
    v.ld.h       v11, [s9, #64]
    vf.cvt.f16.f32 v12, v10
    s.shli       s12, s11, #2
    vf.mul       v10, v12, v0
    v.ld.h       v12, [s9, #96]
    vf.cvt.f16.f32 v13, v11
    s.add        s11, s7, s12
    vf.mul       v11, v13, v0
    v.ld.h       v13, [s9, #128]
    vf.cvt.f16.f32 v14, v12
    vf.mul       v12, v14, v0
    v.ld.h       v14, [s9, #160]
    vf.cvt.f16.f32 v15, v13
    vf.mul       v13, v15, v0
    v.ld.h       v15, [s9, #192]
    vf.cvt.f16.f32 v16, v14
    vf.mul       v14, v16, v0
    v.ld.h       v16, [s9, #224]
    vf.cvt.f16.f32 v17, v15
    vf.mul       v15, v17, v0
    vf.cvt.f16.f32 v17, v16
    v.st.w       [s10, #0], v1
    vf.mul       v1, v17, v0
    v.st.w       [s10, #64], v2
    v.st.w       [s10, #128], v3
    v.st.w       [s10, #192], v4
    v.st.w       [s10, #256], v5
    v.st.w       [s10, #320], v6
    v.st.w       [s10, #384], v7
    v.st.w       [s10, #448], v8
    v.st.w       [s11, #0], v9
    v.st.w       [s11, #64], v10
    v.st.w       [s11, #128], v11
    v.st.w       [s11, #192], v12
    v.st.w       [s11, #256], v13
    v.st.w       [s11, #320], v14
    v.st.w       [s11, #384], v15
    v.st.w       [s11, #448], v1
    s.addi       s8, s8, #256
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
