    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #2
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #1
    s.movz       s6, #6
    s.xor        s8, s5, s3
    s.movz       s9, #1
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s6, #0
    s.min.s      s11, s8, s9
    s.movz       s8, #0
    s.cmp.lt     s9, s11, s3
    s.movz       s3, #0
    s.cmp.lt     s12, s4, s6
    s.sub        s6, s8, s9
    s.sub        s8, s3, s12
    s.xor        s3, s11, s6
    s.muli       s9, s5, #2
    s.movz       s5, #0
    s.movz       s12, #1
    s.xor        s13, s4, s8
    s.sub        s14, s3, s6
    s.rdspecial  s3, arg_base
    s.xor        s6, s1, s7
    s.movz       s15, #0
    s.sub        s16, s13, s8
    s.addi       s13, s5, #0
    s.cmp.eq     s5, s14, s12
    s.ld.d       s12, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s6, s7
    s.sub        s6, s2, s9
    s.addi       s2, s15, #0
    s.ld.d       s6, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s7, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s13, s16
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s13, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s16, s3
    s.shli       s9, s2, #1
    s.andi       s15, s5, #1
    s.movz       s5, #0
    s.or         s17, s9, s15
    s.movz       s9, #1
    s.cmp.geu    s15, s17, s14
    s.shl        s18, s9, s3
    s.sub        s9, s5, s15
    s.subi       s5, s3, #1
    s.and        s15, s14, s9
    s.and        s19, s18, s9
    s.sub        s9, s17, s15
    s.or         s15, s13, s19
    s.mov        s2, s9
    s.mov        s13, s15
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s3, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s3
    s.movz       s3, #0
    s.sub        s13, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s13
    s.movz       s4, #0
    s.sub        s14, s9, s13
    s.cmp.lt     s9, s11, s3
    s.lshri      s3, s14, #1
    s.movz       s15, #0
    s.muli       s16, s3, #2
    s.sub        s3, s4, s9
    s.movz       s4, #0
    s.cmp.lt     s9, s1, s15
    s.xor        s15, s11, s3
    s.sub        s11, s14, s16
    s.movz       s14, #0
    s.xor        s16, s11, s13
    s.xor        s11, s2, s8
    s.sub        s2, s16, s13
    s.sub        s13, s14, s9
    s.cmp.lt     s9, s2, s5
    s.sub        s5, s15, s3
    s.sub        s14, s4, s9
    s.movz       s4, #0
    s.xor        s9, s2, s14
    s.movz       s2, #1
    s.sub        s15, s11, s8
    s.xor        s8, s1, s13
    s.sub        s1, s9, s14
    s.movz       s9, #0
    s.addi       s11, s4, #0
    s.cmp.eq     s4, s5, s2
    s.add        s2, s10, s15
    s.sub        s10, s8, s13
    s.addi       s8, s9, #0
    s.mov        s11, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s9, #31
    s.mov        s11, s4
    s.addi       s4, s9, #0
sdiv_4:
    s.lshr       s9, s1, s4
    s.shli       s10, s8, #1
    s.andi       s13, s9, #1
    s.movz       s9, #0
    s.or         s15, s10, s13
    s.movz       s10, #1
    s.cmp.geu    s13, s15, s5
    s.shl        s16, s10, s4
    s.sub        s10, s9, s13
    s.subi       s9, s4, #1
    s.and        s13, s5, s10
    s.and        s17, s16, s10
    s.sub        s10, s15, s13
    s.or         s13, s11, s17
    s.mov        s8, s10
    s.mov        s11, s13
    s.mov        s4, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s4, s9
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.movz       s1, #16
    .li       s4, #1431655766
    s.mul        s5, s2, s1
    s.rdspecial  s8, pid.z
    s.rdspecial  s9, npid.y
    s.xor        s10, s14, s3
    s.mul        s3, s8, s9
    s.mul        s8, s5, s4
    s.xor        s4, s11, s10
    s.rdspecial  s9, pid.y
    s.sub        s11, s4, s10
    s.add        s4, s9, s3
    s.lshri      s3, s8, #32
    s.mul        s8, s11, s1
    s.sub        s9, s5, s3
    s.movz       s10, #3
    s.lshri      s13, s9, #1
    s.rdspecial  s9, arg_base
    s.add        s14, s3, s13
    s.min.s      s3, s4, s10
    s.lshri      s10, s14, #6
    s.movz       s13, #9216
    s.muli       s14, s10, #96
    s.movz       s10, #3072
    s.ld.d       s15, [s9, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.mul        s9, s3, s13
    s.mul        s13, s3, s10
    s.sub        s3, s5, s14
    s.andi       s14, s8, #31
    s.rdspecial  s16, role_id
    s.movz       s17, #6144
    s.movz       s18, #0
    v.splat      v0, s2
    s.mul        s2, s16, s17
    v.splat      v1, s18
    v.splat      v2, s11
    v.splat      v3, s18
    v.iota       v4                              // arange(0, VLEN)
    s.add        s11, s15, s2                    // this context's own scratch
    v.splat      v5, s5
    s.addi       s2, s11, #0
    v.cmp.ge     p1, v0, v1
    s.muli       s15, s3, #96                    // a runtime tile origin, x96
    s.movz       s16, #0
    v.splat      v0, s8
    v.splat      v1, s3
    v.cmp.ge     p1, v2, v3
    s.add        s3, s16, s15                    // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    s.add        s15, s3, s9                     // the tile origin
    v.iota       v3                              // arange(0, VLEN)
    v.add        v6, v5, v4
    s.addi       s3, s15, #96
    v.splat      v5, s15
    s.addi       s9, s2, #64
    v.add        v6, v0, v4
    s.addi       s16, s15, #192
    s.addi       s17, s15, #288
    v.splat      v0, s3
    v.splat      v4, s16
    v.add        v6, v2, v5
    v.add        v5, v2, v0
    v.add        v0, v2, v4
    s.addi       s3, s2, #128
    s.addi       s16, s2, #192
    v.add        v4, v1, v3
    s.addi       s19, s15, #384
    v.splat      v1, s17
    v.splat      v3, s14
    s.addi       s17, s2, #256
    v.add        v4, v2, v1
    s.movz       s20, #96
    s.addi       s21, s18, #0
    v.st.w       [s2, #0], v6
    v.splat      v1, s19
    v.st.w       [s9, #0], v5
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v2, v1
    v.add        v1, v3, v5
    s.addi       s9, s15, #480
    s.addi       s18, s15, #576
    s.addi       s19, s15, #672
    v.splat      v1, s9
    s.addi       s9, s15, #768
    v.splat      v3, s18
    s.addi       s18, s15, #864
    v.add        v5, v2, v1
    v.add        v1, v2, v3
    v.st.w       [s3, #0], v0
    s.addi       s3, s15, #960
    v.splat      v0, s19
    s.addi       s19, s15, #1056
    v.add        v3, v2, v0
    v.st.w       [s16, #0], v4
    s.addi       s16, s15, #1152
    v.splat      v0, s9
    s.addi       s9, s15, #1248
    v.add        v4, v2, v0
    v.st.w       [s17, #0], v6
    s.addi       s17, s15, #1344
    v.splat      v0, s18
    s.addi       s18, s2, #320
    s.addi       s22, s15, #1440
    v.add        v6, v2, v0
    v.st.w       [s18, #0], v5
    v.splat      v0, s3
    s.addi       s3, s2, #384
    s.addi       s15, s11, #1024
    v.add        v5, v2, v0
    v.st.w       [s3, #0], v1
    s.movz       s3, #0
    v.splat      v0, s19
    s.addi       s18, s2, #448
    s.add        s19, s3, s14                    // the tile origin
    v.add        v1, v2, v0
    s.add        s3, s19, s13                    // the tile origin
    s.addi       s13, s2, #512
    s.addi       s14, s2, #576
    v.st.w       [s18, #0], v3
    s.addi       s18, s3, #32
    v.splat      v0, s16
    s.addi       s16, s2, #640
    v.add        v3, v2, v0
    v.st.w       [s13, #0], v4
    s.addi       s13, s3, #64
    v.splat      v0, s9
    s.addi       s9, s2, #704
    v.add        v4, v2, v0
    v.st.w       [s14, #0], v6
    s.addi       s14, s3, #96
    v.splat      v0, s17
    s.addi       s17, s2, #768
    v.add        v6, v2, v0
    v.st.w       [s16, #0], v5
    s.addi       s16, s3, #128
    v.splat      v0, s22
    s.addi       s19, s2, #832
    v.add        v5, v2, v0
    v.st.w       [s9, #0], v1
    s.addi       s9, s3, #160
    v.splat      v0, s3
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v3
    s.addi       s17, s3, #192
    v.splat      v0, s18
    s.addi       s18, s2, #896
    s.addi       s22, s2, #960
    v.add        v3, v2, v0
    v.st.w       [s19, #0], v4
    s.addi       s2, s3, #224
    v.splat      v0, s13
    s.addi       s13, s15, #64
    v.add        v4, v2, v0
    v.st.w       [s18, #0], v6
    s.addi       s18, s3, #256
    v.splat      v0, s14
    s.addi       s14, s15, #128
    v.add        v6, v2, v0
    v.st.w       [s22, #0], v5
    v.splat      v0, s16
    s.addi       s16, s15, #192
    s.addi       s19, s15, #256
    v.add        v5, v2, v0
    fence.acq_rel.device
    v.st.w       [s15, #0], v1
    v.splat      v0, s9
    s.addi       s9, s3, #288
    v.add        v1, v2, v0
    v.st.w       [s13, #0], v3
    s.addi       s13, s3, #320
    v.splat      v0, s17
    s.addi       s17, s3, #352
    v.add        v3, v2, v0
    v.st.w       [s14, #0], v4
    s.addi       s14, s3, #384
    v.splat      v0, s2
    s.addi       s2, s3, #416
    v.add        v4, v2, v0
    v.st.w       [s16, #0], v6
    s.addi       s16, s3, #448
    v.splat      v0, s18
    s.addi       s18, s15, #320
    v.add        v6, v2, v0
    v.st.w       [s19, #0], v5
    s.addi       s19, s3, #480
    v.splat      v0, s9
    s.addi       s3, s15, #384
    s.addi       s9, s15, #448
    v.add        v5, v2, v0
    v.st.w       [s18, #0], v1
    v.splat      v0, s13
    s.addi       s13, s15, #512
    s.addi       s18, s15, #576
    v.add        v1, v2, v0
    v.st.w       [s3, #0], v3
    v.splat      v0, s17
    s.addi       s3, s15, #640
    s.addi       s17, s15, #704
    v.add        v3, v2, v0
    v.st.w       [s9, #0], v4
    v.splat      v0, s14
    s.addi       s9, s15, #768
    s.addi       s14, s15, #832
    v.add        v4, v2, v0
    v.st.w       [s13, #0], v6
    v.splat      v0, s2
    s.addi       s2, s15, #896
    s.addi       s13, s15, #960
    v.add        v6, v2, v0
    v.st.w       [s18, #0], v5
    v.splat      v0, s16
    v.add        v5, v2, v0
    v.st.w       [s3, #0], v1
    v.splat      v0, s19
    v.add        v1, v2, v0
    v.st.w       [s17, #0], v3
    v.st.w       [s9, #0], v4
    v.st.w       [s14, #0], v6
    v.st.w       [s2, #0], v5
    v.st.w       [s13, #0], v1
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s2, s21, s20
    br.nz        s2, endfor_6
    s.addi       s2, s11, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s3, #0
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #64
    s.movz       s9, #1
    s.addi       s13, s11, #128
    s.movz       s14, #2
    s.addi       s15, s11, #192
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v1
    v.ld.w       v0, [s2, #0]
    s.movz       s2, #3
    s.addi       s3, s11, #256
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s9, v1
    v.ld.w       v0, [s13, #0]
    s.movz       s9, #4
    s.addi       s13, s11, #320
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v1
    v.ld.w       v0, [s15, #0]
    s.movz       s14, #5
    s.addi       s15, s11, #384
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v1
    v.ld.w       v0, [s3, #0]
    s.movz       s2, #6
    s.addi       s3, s11, #448
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s9, v1
    v.ld.w       v0, [s13, #0]
    s.movz       s9, #7
    s.addi       s13, s11, #512
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v1
    v.ld.w       v0, [s15, #0]
    s.movz       s14, #8
    s.addi       s15, s11, #576
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v1
    v.ld.w       v0, [s3, #0]
    s.movz       s2, #9
    s.addi       s3, s11, #640
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s9, v1
    v.ld.w       v0, [s13, #0]
    s.movz       s9, #10
    s.addi       s13, s11, #704
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v1
    v.ld.w       v0, [s15, #0]
    s.movz       s14, #11
    s.addi       s15, s11, #768
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v1
    v.ld.w       v0, [s3, #0]
    s.movz       s2, #12
    s.addi       s3, s11, #832
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s9, v1
    v.ld.w       v0, [s13, #0]
    s.movz       s9, #13
    s.addi       s13, s11, #896
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v1
    v.ld.w       v0, [s15, #0]
    s.movz       s14, #14
    s.addi       s15, s11, #960
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v1
    v.ld.w       v0, [s3, #0]
    s.movz       s2, #15
    s.addi       s3, s11, #1024
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s9, v1
    v.ld.w       v0, [s13, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    s.addi       s13, s11, #1088
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s14, v1
    v.ld.w       v0, [s15, #0]
    s.movz       s14, #1
    s.addi       s15, s11, #1152
    v.ld.gather.w v1, [s12, v0]                  // index is in elements (ISA sec 9.1)
    s.movz       s16, #2
    a.vwrite     a1, s2, v1
    v.ld.w       v0, [s3, #0]
    s.addi       s2, s11, #1216
    s.movz       s3, #3
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s9, v1
    v.ld.w       v0, [s13, #0]
    s.addi       s9, s11, #1280
    s.movz       s13, #4
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v1
    v.ld.w       v0, [s15, #0]
    s.addi       s14, s11, #1344
    s.movz       s15, #5
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v1
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #1408
    s.movz       s16, #6
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s3, v1
    v.ld.w       v0, [s9, #0]
    s.addi       s3, s11, #1472
    s.movz       s9, #7
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v1
    v.ld.w       v0, [s14, #0]
    s.addi       s13, s11, #1536
    s.movz       s14, #8
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v1
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #1600
    s.movz       s15, #9
    v.movi       v1, #0
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #1664
    s.movz       s16, #10
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s9, v3
    v.ld.w       v0, [s13, #0]
    s.addi       s9, s11, #1728
    s.movz       s13, #11
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #1792
    s.movz       s14, #12
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #1856
    s.movz       s15, #13
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s11, #1920
    s.movz       s16, #14
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v3
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #1984
    s.movz       s13, #15
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v0, [s3, #0]
    s.movz       s3, #0
    s.movz       s14, #0
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v0, [s9, #0]
    s.movz       s9, #1
    s.movz       s15, #2
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v0, [s2, #0]
    s.movz       s2, #3
    s.movz       s16, #4
    v.ld.gather.w v3, [s6, v0]                   // index is in elements (ISA sec 9.1)
    s.movz       s17, #5
    a.vwrite     a2, s13, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s14
    a.vread      v4, a2, s9
    v.extract    s3, v0, #0
    v.extract    s9, v0, #1
    v.splat      v5, s3
    v.splat      v6, s9
    v.extract    s3, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s3
    a.vread      v5, a2, s15
    v.extract    s3, v0, #3
    a.vread      v8, a2, s2
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s3
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #1
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #1
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #2
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #2
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #3
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #3
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #4
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #4
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #5
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #5
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #6
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #6
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #7
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #7
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #8
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #8
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #9
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #10
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #10
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #11
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #11
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #12
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #12
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #13
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #13
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #14
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v0, #3
    a.vread      v8, a2, s15
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v0, #5
    a.vread      v3, a2, s17
    v.splat      v5, s2
    v.extract    s2, v0, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v8, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s3, #8
    v.splat      v3, s2
    a.vread      v5, a2, s3
    s.movz       s2, #14
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v9, v6, v7, v10
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v10, v3, v5, v9
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v4, v8, v10
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v8, a2, s9
    vf.fma       v10, v6, v7, v9
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v3, v5, v10
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v3, s3
    a.vread      v5, a2, s9
    vf.fma       v10, v4, v8, v9
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v8, v6, v7, v10
    s.movz       s3, #15
    s.movz       s9, #0
    s.movz       s13, #1
    s.movz       s14, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s15, #3
    s.movz       s16, #4
    s.movz       s17, #5
    vf.fma       v3, v0, v4, v6
    a.vwrite     a3, s2, v3
    a.vread      v0, a1, s3
    a.vread      v3, a2, s9
    a.vread      v4, a2, s13
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    v.splat      v5, s2
    v.splat      v6, s3
    v.extract    s2, v0, #2
    vf.fma       v7, v5, v3, v1
    v.splat      v1, s2
    a.vread      v3, a2, s14
    v.extract    s2, v0, #3
    a.vread      v5, a2, s15
    vf.fma       v8, v6, v4, v7
    v.splat      v4, s2
    v.extract    s2, v0, #4
    a.vread      v6, a2, s16
    v.splat      v7, s2
    vf.fma       v9, v1, v3, v8
    v.extract    s2, v0, #5
    a.vread      v1, a2, s17
    v.splat      v3, s2
    v.extract    s2, v0, #6
    vf.fma       v8, v4, v5, v9
    s.movz       s3, #6
    v.splat      v4, s2
    a.vread      v5, a2, s3
    v.extract    s2, v0, #7
    vf.fma       v9, v7, v6, v8
    s.movz       s3, #7
    v.splat      v6, s2
    a.vread      v7, a2, s3
    v.extract    s2, v0, #8
    vf.fma       v8, v3, v1, v9
    s.movz       s3, #8
    v.splat      v1, s2
    a.vread      v3, a2, s3
    s.movz       s2, #15
    vf.fma       v9, v4, v5, v8
    v.extract    s3, v0, #9
    s.movz       s9, #9
    v.splat      v4, s3
    a.vread      v5, a2, s9
    vf.fma       v8, v6, v7, v9
    v.extract    s3, v0, #10
    s.movz       s9, #10
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v9, v1, v3, v8
    v.extract    s3, v0, #11
    s.movz       s9, #11
    v.splat      v1, s3
    a.vread      v3, a2, s9
    vf.fma       v8, v4, v5, v9
    v.extract    s3, v0, #12
    s.movz       s9, #12
    v.splat      v4, s3
    a.vread      v5, a2, s9
    vf.fma       v9, v6, v7, v8
    v.extract    s3, v0, #13
    s.movz       s9, #13
    v.splat      v6, s3
    a.vread      v7, a2, s9
    vf.fma       v8, v1, v3, v9
    v.extract    s3, v0, #14
    s.movz       s9, #14
    v.splat      v1, s3
    a.vread      v3, a2, s9
    vf.fma       v9, v4, v5, v8
    v.extract    s3, v0, #15
    s.movz       s9, #15
    v.splat      v0, s3
    a.vread      v4, a2, s9
    vf.fma       v5, v6, v7, v9
    s.addi       s3, s11, #0
    v.splat      v6, s1
    s.addi       s9, s11, #2048
    s.addi       s13, s11, #64
    vf.fma       v7, v1, v3, v5
    s.addi       s14, s9, #64
    s.addi       s15, s11, #128
    s.addi       s16, s9, #128
    s.addi       s17, s11, #192
    vf.fma       v1, v0, v4, v7
    a.vwrite     a3, s2, v1
    v.ld.w       v0, [s3, #0]
    s.addi       s2, s9, #192
    s.addi       s3, s11, #256
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s9, #256
    v.add        v1, v0, v6
    v.st.w       [s14, #0], v1
    s.addi       s14, s11, #320
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #320
    v.add        v1, v0, v6
    v.st.w       [s16, #0], v1
    s.addi       s16, s11, #384
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s9, #384
    v.add        v1, v0, v6
    v.st.w       [s2, #0], v1
    s.addi       s2, s11, #448
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s9, #448
    v.add        v1, v0, v6
    v.st.w       [s13, #0], v1
    s.addi       s13, s11, #512
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #512
    v.add        v1, v0, v6
    v.st.w       [s15, #0], v1
    s.addi       s15, s11, #576
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s9, #576
    v.add        v1, v0, v6
    v.st.w       [s17, #0], v1
    s.addi       s17, s11, #640
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s9, #640
    v.add        v1, v0, v6
    v.st.w       [s3, #0], v1
    s.addi       s3, s11, #704
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s9, #704
    v.add        v1, v0, v6
    v.st.w       [s14, #0], v1
    s.addi       s14, s11, #768
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #768
    v.add        v1, v0, v6
    v.st.w       [s16, #0], v1
    s.addi       s16, s11, #832
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s9, #832
    v.add        v1, v0, v6
    v.st.w       [s2, #0], v1
    s.addi       s2, s11, #896
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s9, #896
    s.addi       s18, s9, #960
    v.add        v1, v0, v6
    v.st.w       [s13, #0], v1
    s.addi       s9, s11, #960
    v.ld.w       v0, [s14, #0]
    s.addi       s13, s11, #1024
    v.add        v1, v0, v6
    v.st.w       [s15, #0], v1
    s.movz       s14, #512
    v.splat      v0, s14
    s.addi       s14, s11, #3072
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s11, #1088
    v.add        v3, v1, v6
    v.st.w       [s17, #0], v3
    s.addi       s16, s14, #64
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s11, #1152
    v.add        v3, v1, v6
    v.st.w       [s3, #0], v3
    s.addi       s3, s14, #128
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s11, #1216
    v.add        v3, v1, v6
    v.st.w       [s18, #0], v3
    fence.acq_rel.device
    s.addi       s17, s14, #192
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s11, #1280
    v.add        v3, v1, v0
    v.st.w       [s14, #0], v3
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s14, #256
    v.add        v3, v1, v0
    v.st.w       [s16, #0], v3
    s.addi       s16, s11, #1344
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s14, #320
    v.add        v3, v1, v0
    v.st.w       [s3, #0], v3
    s.addi       s3, s11, #1408
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s14, #384
    v.add        v3, v1, v0
    v.st.w       [s17, #0], v3
    s.addi       s17, s11, #1472
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s14, #448
    v.add        v3, v1, v0
    v.st.w       [s15, #0], v3
    s.addi       s15, s11, #1536
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s14, #512
    v.add        v3, v1, v0
    v.st.w       [s2, #0], v3
    s.addi       s2, s11, #1600
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s14, #576
    v.add        v3, v1, v0
    v.st.w       [s9, #0], v3
    s.addi       s9, s11, #1664
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s14, #640
    v.add        v3, v1, v0
    v.st.w       [s13, #0], v3
    s.addi       s13, s11, #1728
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s14, #704
    v.add        v3, v1, v0
    v.st.w       [s16, #0], v3
    s.addi       s16, s11, #1792
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s14, #768
    v.add        v3, v1, v0
    v.st.w       [s3, #0], v3
    s.addi       s3, s11, #1856
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s14, #832
    v.add        v3, v1, v0
    v.st.w       [s17, #0], v3
    s.addi       s17, s11, #1920
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s14, #896
    s.addi       s18, s14, #960
    v.add        v3, v1, v0
    v.st.w       [s15, #0], v3
    s.addi       s14, s11, #1984
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s11, #2048
    v.add        v3, v1, v0
    v.st.w       [s2, #0], v3
    s.addi       s2, s11, #4096
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s11, #2112
    v.add        v3, v1, v0
    v.st.w       [s9, #0], v3
    s.addi       s9, s2, #64
    v.ld.w       v1, [s17, #0]
    s.addi       s16, s11, #2176
    v.add        v3, v1, v0
    v.st.w       [s13, #0], v3
    s.addi       s13, s2, #128
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s11, #2240
    v.add        v3, v1, v0
    v.st.w       [s18, #0], v3
    fence.acq_rel.device
    s.addi       s17, s2, #192
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s11, #2304
    v.st.w       [s2, #0], v0
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #256
    v.st.w       [s9, #0], v0
    s.addi       s9, s11, #2368
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #320
    v.st.w       [s13, #0], v0
    s.addi       s13, s11, #2432
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s2, #384
    v.st.w       [s17, #0], v0
    s.addi       s17, s11, #2496
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #448
    v.st.w       [s3, #0], v0
    s.addi       s3, s11, #2560
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s2, #512
    v.st.w       [s16, #0], v0
    s.addi       s16, s11, #2624
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s2, #576
    v.st.w       [s14, #0], v0
    s.addi       s14, s11, #2688
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s2, #640
    v.st.w       [s15, #0], v0
    s.addi       s15, s11, #2752
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #704
    v.st.w       [s9, #0], v0
    s.addi       s9, s11, #2816
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #768
    v.st.w       [s13, #0], v0
    s.addi       s13, s11, #2880
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s2, #832
    v.st.w       [s17, #0], v0
    s.addi       s17, s11, #2944
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s2, #896
    s.addi       s18, s2, #960
    v.st.w       [s3, #0], v0
    s.addi       s2, s11, #3008
    v.ld.w       v0, [s9, #0]
    s.addi       s3, s11, #3072
    v.st.w       [s16, #0], v0
    s.addi       s9, s11, #5120
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #3136
    v.st.w       [s14, #0], v0
    s.addi       s14, s9, #64
    v.ld.w       v0, [s17, #0]
    s.addi       s16, s11, #3200
    v.st.w       [s15, #0], v0
    s.addi       s15, s9, #128
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #3264
    v.st.w       [s18, #0], v0
    fence.acq_rel.device
    s.addi       s17, s9, #192
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #3328
    v.st.w       [s9, #0], v0
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s9, #256
    v.st.w       [s14, #0], v0
    s.addi       s14, s11, #3392
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s9, #320
    v.st.w       [s15, #0], v0
    s.addi       s15, s11, #3456
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s9, #384
    v.st.w       [s17, #0], v0
    s.addi       s17, s11, #3520
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s9, #448
    v.st.w       [s13, #0], v0
    s.addi       s13, s11, #3584
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #512
    v.st.w       [s16, #0], v0
    s.addi       s16, s11, #3648
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #576
    v.st.w       [s2, #0], v0
    s.addi       s2, s11, #3712
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s9, #640
    v.st.w       [s3, #0], v0
    s.addi       s3, s11, #3776
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s9, #704
    v.st.w       [s14, #0], v0
    s.addi       s14, s11, #3840
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s9, #768
    v.st.w       [s15, #0], v0
    s.addi       s15, s11, #3904
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s9, #832
    v.st.w       [s17, #0], v0
    s.addi       s17, s11, #3968
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s9, #896
    s.addi       s18, s9, #960
    v.st.w       [s13, #0], v0
    s.addi       s9, s11, #4032
    v.ld.w       v0, [s14, #0]
    s.movz       s13, #0
    v.st.w       [s16, #0], v0
    s.movz       s14, #0
    v.ld.w       v0, [s15, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s15, #0
    v.st.w       [s2, #0], v0
    s.movz       s2, #1
    v.ld.w       v0, [s17, #0]
    s.movz       s16, #1
    v.st.w       [s3, #0], v0
    s.movz       s3, #1
    v.ld.w       v0, [s9, #0]
    s.movz       s9, #2
    v.st.w       [s18, #0], v0
    fence.acq_rel.device
    a.vread      v0, a0, s13
    a.vread      v1, a3, s14
    s.movz       s13, #2
    s.movz       s14, #2
    vf.add       v3, v0, v1
    s.movz       s17, #3
    a.vwrite     a4, s15, v3
    a.vread      v0, a0, s2
    a.vread      v1, a3, s16
    s.movz       s2, #3
    s.movz       s15, #3
    vf.add       v3, v0, v1
    s.movz       s16, #4
    a.vwrite     a4, s3, v3
    a.vread      v0, a0, s9
    a.vread      v1, a3, s13
    s.movz       s3, #4
    s.movz       s9, #4
    vf.add       v3, v0, v1
    s.movz       s13, #5
    a.vwrite     a4, s14, v3
    a.vread      v0, a0, s17
    a.vread      v1, a3, s2
    s.movz       s2, #5
    s.movz       s14, #5
    vf.add       v3, v0, v1
    s.movz       s17, #6
    a.vwrite     a4, s15, v3
    a.vread      v0, a0, s16
    a.vread      v1, a3, s3
    s.movz       s3, #6
    s.movz       s15, #6
    vf.add       v3, v0, v1
    s.movz       s16, #7
    a.vwrite     a4, s9, v3
    a.vread      v0, a0, s13
    a.vread      v1, a3, s2
    s.movz       s2, #7
    s.movz       s9, #7
    vf.add       v3, v0, v1
    s.movz       s13, #8
    a.vwrite     a4, s14, v3
    a.vread      v0, a0, s17
    a.vread      v1, a3, s3
    s.movz       s3, #8
    s.movz       s14, #8
    vf.add       v3, v0, v1
    s.movz       s17, #9
    a.vwrite     a4, s15, v3
    a.vread      v0, a0, s16
    a.vread      v1, a3, s2
    s.movz       s2, #9
    s.movz       s15, #9
    vf.add       v3, v0, v1
    s.movz       s16, #10
    a.vwrite     a4, s9, v3
    a.vread      v0, a0, s13
    a.vread      v1, a3, s3
    s.movz       s3, #10
    s.movz       s9, #10
    vf.add       v3, v0, v1
    s.movz       s13, #11
    a.vwrite     a4, s14, v3
    a.vread      v0, a0, s17
    a.vread      v1, a3, s2
    s.movz       s2, #11
    s.movz       s14, #11
    vf.add       v3, v0, v1
    s.movz       s17, #12
    a.vwrite     a4, s15, v3
    a.vread      v0, a0, s16
    a.vread      v1, a3, s3
    s.movz       s3, #12
    s.movz       s15, #12
    vf.add       v3, v0, v1
    s.movz       s16, #13
    a.vwrite     a4, s9, v3
    a.vread      v0, a0, s13
    a.vread      v1, a3, s2
    s.movz       s2, #13
    s.movz       s9, #13
    vf.add       v3, v0, v1
    s.movz       s13, #14
    a.vwrite     a4, s14, v3
    a.vread      v0, a0, s17
    a.vread      v1, a3, s3
    s.movz       s3, #14
    s.movz       s14, #14
    vf.add       v3, v0, v1
    s.movz       s17, #15
    a.vwrite     a4, s15, v3
    a.vread      v0, a0, s16
    a.vread      v1, a3, s2
    s.movz       s2, #15
    s.movz       s15, #15
    vf.add       v3, v0, v1
    s.addi       s16, s11, #4096
    a.vwrite     a4, s9, v3
    a.vread      v0, a0, s13
    a.vread      v1, a3, s3
    s.addi       s3, s11, #0
    s.addi       s9, s11, #4160
    vf.add       v3, v0, v1
    s.addi       s13, s11, #64
    a.vwrite     a4, s14, v3
    a.vread      v0, a0, s17
    a.vread      v1, a3, s2
    s.addi       s2, s11, #4224
    s.addi       s14, s11, #128
    vf.add       v3, v0, v1
    s.addi       s17, s11, #4288
    a.vwrite     a4, s15, v3
    v.ld.w       v0, [s16, #0]
    s.addi       s15, s11, #192
    s.addi       s16, s11, #4352
    v.st.w       [s3, #0], v0
    s.addi       s3, s11, #256
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s11, #4416
    v.st.w       [s13, #0], v0
    s.addi       s13, s11, #320
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #4480
    v.st.w       [s14, #0], v0
    s.addi       s14, s11, #384
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s11, #4544
    v.st.w       [s15, #0], v0
    s.addi       s15, s11, #448
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #4608
    v.st.w       [s3, #0], v0
    s.addi       s3, s11, #512
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s11, #4672
    v.st.w       [s13, #0], v0
    s.addi       s13, s11, #576
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #4736
    v.st.w       [s14, #0], v0
    s.addi       s14, s11, #640
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s11, #4800
    v.st.w       [s15, #0], v0
    s.addi       s15, s11, #704
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #4864
    v.st.w       [s3, #0], v0
    s.addi       s3, s11, #768
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s11, #4928
    v.st.w       [s13, #0], v0
    s.addi       s13, s11, #832
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #4992
    v.st.w       [s14, #0], v0
    s.addi       s14, s11, #896
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s11, #5056
    v.st.w       [s15, #0], v0
    s.addi       s15, s11, #960
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #5120
    v.st.w       [s3, #0], v0
    s.addi       s3, s11, #1024
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s11, #5184
    v.st.w       [s13, #0], v0
    s.addi       s13, s11, #1088
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #5248
    v.st.w       [s14, #0], v0
    s.addi       s14, s11, #1152
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s11, #5312
    v.st.w       [s15, #0], v0
    fence.acq_rel.device
    s.addi       s15, s11, #1216
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #5376
    v.st.w       [s3, #0], v0
    s.addi       s3, s11, #1280
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s11, #5440
    v.st.w       [s13, #0], v0
    s.addi       s13, s11, #1344
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #5504
    v.st.w       [s14, #0], v0
    s.addi       s14, s11, #1408
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s11, #5568
    v.st.w       [s15, #0], v0
    s.addi       s15, s11, #1472
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #5632
    v.st.w       [s3, #0], v0
    s.addi       s3, s11, #1536
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s11, #5696
    v.st.w       [s13, #0], v0
    s.addi       s13, s11, #1600
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #5760
    v.st.w       [s14, #0], v0
    s.addi       s14, s11, #1664
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s11, #5824
    v.st.w       [s15, #0], v0
    s.addi       s15, s11, #1728
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #5888
    v.st.w       [s3, #0], v0
    s.addi       s3, s11, #1792
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s11, #5952
    v.st.w       [s13, #0], v0
    s.addi       s13, s11, #1856
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s11, #6016
    v.st.w       [s14, #0], v0
    s.addi       s14, s11, #1920
    v.ld.w       v0, [s17, #0]
    s.addi       s17, s11, #6080
    s.addi       s18, s11, #1984
    v.st.w       [s15, #0], v0
    s.movz       s15, #0
    v.ld.w       v0, [s16, #0]
    s.movz       s16, #0
    v.st.w       [s3, #0], v0
    s.movz       s3, #1
    v.ld.w       v0, [s9, #0]
    s.movz       s9, #1
    v.st.w       [s13, #0], v0
    s.movz       s13, #2
    v.ld.w       v0, [s2, #0]
    s.movz       s2, #2
    v.st.w       [s14, #0], v0
    s.movz       s14, #3
    v.ld.w       v0, [s17, #0]
    s.movz       s17, #3
    v.st.w       [s18, #0], v0
    fence.acq_rel.device
    a.vread      v0, a4, s15
    s.movz       s15, #4
    s.movz       s18, #4
    a.vwrite     a0, s16, v0
    a.vread      v0, a4, s3
    s.movz       s3, #5
    s.movz       s16, #5
    a.vwrite     a0, s9, v0
    a.vread      v0, a4, s13
    s.movz       s9, #6
    s.movz       s13, #6
    a.vwrite     a0, s2, v0
    a.vread      v0, a4, s14
    s.movz       s2, #7
    s.movz       s14, #7
    a.vwrite     a0, s17, v0
    a.vread      v0, a4, s15
    s.movz       s15, #8
    s.movz       s17, #8
    a.vwrite     a0, s18, v0
    a.vread      v0, a4, s3
    s.movz       s3, #9
    s.movz       s18, #9
    a.vwrite     a0, s16, v0
    a.vread      v0, a4, s9
    s.movz       s9, #10
    s.movz       s16, #10
    a.vwrite     a0, s13, v0
    a.vread      v0, a4, s2
    s.movz       s2, #11
    s.movz       s13, #11
    a.vwrite     a0, s14, v0
    a.vread      v0, a4, s15
    s.movz       s14, #12
    s.movz       s15, #12
    a.vwrite     a0, s17, v0
    a.vread      v0, a4, s3
    s.movz       s3, #13
    s.movz       s17, #13
    a.vwrite     a0, s18, v0
    a.vread      v0, a4, s9
    s.movz       s9, #14
    s.movz       s18, #14
    a.vwrite     a0, s16, v0
    a.vread      v0, a4, s2
    s.movz       s2, #15
    s.movz       s16, #15
    a.vwrite     a0, s13, v0
    a.vread      v0, a4, s14
    s.add        s13, s21, s1
    s.movz       s14, #1
    a.vwrite     a0, s15, v0
    a.vread      v0, a4, s3
    a.vwrite     a0, s17, v0
    a.vread      v0, a4, s9
    a.vwrite     a0, s18, v0
    a.vread      v0, a4, s2
    a.vwrite     a0, s16, v0
    s.mov        s21, s13
    br.nz        s14, for_5
endfor_6:
    s.movz       s1, #0
    s.mul        s2, s4, s10
    s.add        s3, s1, s8                      // the tile origin
    s.movz       s1, #0
    s.muli       s6, s8, #4                      // a runtime tile origin, x4
    v.splat      v0, s3
    s.add        s3, s1, s5                      // the tile origin
    s.movz       s1, #32
    s.muli       s8, s5, #128                    // a runtime tile origin, x128
    s.movz       s5, #4
    v.splat      v1, s3
    v.splat      v3, s20
    v.add        v4, v2, v0
    v.splat      v0, s1
    s.muli       s1, s2, #4                      // a runtime tile origin, x4
    s.addi       s2, s3, #1
    v.splat      v2, s4
    v.splat      v5, s5
    s.add        s4, s7, s6                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    v.cmp.lt     p1, v1, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s2
    s.add        s2, s4, s8                      // the tile origin
    p.and        p3, p1, p2
    s.addi       s4, s3, #2
    v.cmp.lt     p1, v2, v5
    a.vread      v1, a0, s5
    s.add        s5, s2, s1                      // the tile origin
    p.and        p4, p3, p1
    s.movz       s1, #1
    v.cmp.lt     p3, v0, v3
    v.splat      v0, s4
    p.and        p5, p3, p2
    s.addi       s2, s3, #3
    @p4 v.st.w       [s5, #0], v1
    a.vread      v1, a0, s1
    s.addi       s1, s5, #128                    // row 1
    p.and        p3, p5, p1
    s.movz       s4, #2
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s2
    p.and        p5, p4, p2
    s.addi       s2, s3, #4
    s.addi       s6, s5, #256                    // row 2
    p.and        p4, p5, p1
    s.movz       s7, #3
    v.splat      v2, s2
    s.addi       s2, s3, #5
    s.addi       s8, s5, #384                    // row 3
    s.movz       s9, #4
    v.splat      v4, s2
    s.addi       s2, s3, #6
    @p3 v.st.w       [s1, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p3, v0, v3
    p.and        p5, p3, p2
    s.addi       s1, s5, #512                    // row 4
    p.and        p3, p5, p1
    s.movz       s4, #5
    v.splat      v0, s2
    s.addi       s2, s3, #7
    s.addi       s10, s5, #640                   // row 5
    s.movz       s11, #6
    v.splat      v5, s2
    s.addi       s2, s5, #768                    // row 6
    @p4 v.st.w       [s6, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.addi       s6, s3, #8
    p.and        p4, p5, p1
    s.movz       s7, #7
    v.splat      v2, s6
    s.addi       s6, s5, #896                    // row 7
    @p3 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    s.addi       s8, s3, #9
    p.and        p3, p5, p1
    s.movz       s9, #8
    v.splat      v4, s8
    s.addi       s8, s5, #1024                   // row 8
    @p4 v.st.w       [s1, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.addi       s1, s3, #10
    p.and        p4, p5, p1
    s.movz       s4, #9
    v.splat      v0, s1
    s.addi       s1, s5, #1152                   // row 9
    @p3 v.st.w       [s10, #0], v1
    a.vread      v1, a0, s11
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    s.addi       s10, s3, #11
    p.and        p3, p5, p1
    s.movz       s11, #10
    v.splat      v5, s10
    s.addi       s10, s5, #1280                  // row 10
    @p4 v.st.w       [s2, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.addi       s2, s3, #12
    p.and        p4, p5, p1
    s.movz       s7, #11
    v.splat      v2, s2
    s.addi       s2, s5, #1408                   // row 11
    @p3 v.st.w       [s6, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    s.addi       s6, s3, #13
    p.and        p3, p5, p1
    s.movz       s9, #12
    v.splat      v4, s6
    s.addi       s6, s5, #1536                   // row 12
    @p4 v.st.w       [s8, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.addi       s4, s3, #14
    p.and        p4, p5, p1
    s.movz       s8, #13
    v.splat      v0, s4
    s.addi       s4, s5, #1664                   // row 13
    @p3 v.st.w       [s1, #0], v1
    a.vread      v1, a0, s11
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    s.addi       s1, s3, #15
    p.and        p3, p5, p1
    s.movz       s3, #14
    v.splat      v5, s1
    s.addi       s1, s5, #1792                   // row 14
    s.movz       s11, #15
    s.addi       s12, s5, #1920                  // row 15
    @p4 v.st.w       [s10, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s2, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s6, #0], v1
    a.vread      v1, a0, s8
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s4, #0], v1
    a.vread      v0, a0, s3
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    p.and        p2, p5, p1
    @p4 v.st.w       [s1, #0], v0
    a.vread      v0, a0, s11
    @p2 v.st.w       [s12, #0], v0
__rctx_next:
    exit
