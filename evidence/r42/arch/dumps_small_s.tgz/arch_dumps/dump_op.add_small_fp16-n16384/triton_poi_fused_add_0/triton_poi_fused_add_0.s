    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s8, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
__rctx_program:
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (3 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s9, s4, #0
tiles_1:
    // tile 1 of the iteration: lanes t0 + 128
    s.addi       s10, s9, #128
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s11, s1, s9
    s.add        s12, s1, s10
    s.shli       s10, s11, #1
    s.shli       s11, s12, #1
    s.add        s12, s3, s10
    s.add        s13, s7, s10
    s.add        s14, s3, s11
    s.add        s15, s7, s11
    v.ld.h       v0, [s12, #0]
    v.ld.h       v1, [s12, #32]
    vf.cvt.f16.f32 v2, v0
    v.ld.h       v0, [s12, #64]
    vf.cvt.f16.f32 v3, v1
    v.ld.h       v1, [s12, #96]
    vf.cvt.f16.f32 v4, v0
    v.ld.h       v0, [s12, #128]
    vf.cvt.f16.f32 v5, v1
    v.ld.h       v1, [s12, #160]
    vf.cvt.f16.f32 v6, v0
    v.ld.h       v0, [s12, #192]
    vf.cvt.f16.f32 v7, v1
    v.ld.h       v1, [s12, #224]
    vf.cvt.f16.f32 v8, v0
    v.ld.h       v0, [s13, #0]
    vf.cvt.f16.f32 v9, v1
    v.ld.h       v1, [s13, #32]
    vf.cvt.f16.f32 v10, v0
    vf.add       v0, v2, v10
    v.ld.h       v2, [s13, #64]
    vf.cvt.f16.f32 v10, v1
    vf.add       v1, v3, v10
    v.ld.h       v3, [s13, #96]
    vf.cvt.f16.f32 v10, v2
    vf.cvt.f32.f16 v2, v0
    vf.add       v0, v4, v10
    v.ld.h       v4, [s13, #128]
    vf.cvt.f16.f32 v10, v3
    vf.cvt.f32.f16 v3, v1
    vf.add       v1, v5, v10
    v.ld.h       v5, [s13, #160]
    vf.cvt.f16.f32 v10, v4
    vf.cvt.f32.f16 v4, v0
    vf.add       v0, v6, v10
    v.ld.h       v6, [s13, #192]
    vf.cvt.f16.f32 v10, v5
    vf.cvt.f32.f16 v5, v1
    vf.add       v1, v7, v10
    v.ld.h       v7, [s13, #224]
    vf.cvt.f16.f32 v10, v6
    vf.cvt.f32.f16 v6, v0
    vf.cvt.f32.f16 v0, v1
    vf.add       v1, v8, v10
    vf.cvt.f32.f16 v8, v1
    v.ld.h       v1, [s14, #0]
    vf.cvt.f16.f32 v10, v7
    vf.add       v7, v9, v10
    vf.cvt.f32.f16 v9, v7
    v.ld.h       v7, [s14, #32]
    vf.cvt.f16.f32 v10, v1
    s.add        s12, s8, s10
    v.ld.h       v1, [s14, #64]
    vf.cvt.f16.f32 v11, v7
    v.ld.h       v7, [s14, #96]
    vf.cvt.f16.f32 v12, v1
    v.ld.h       v1, [s14, #128]
    vf.cvt.f16.f32 v13, v7
    v.ld.h       v7, [s14, #160]
    vf.cvt.f16.f32 v14, v1
    v.ld.h       v1, [s14, #192]
    vf.cvt.f16.f32 v15, v7
    v.ld.h       v7, [s14, #224]
    vf.cvt.f16.f32 v16, v1
    v.ld.h       v1, [s15, #0]
    vf.cvt.f16.f32 v17, v7
    v.ld.h       v7, [s15, #32]
    vf.cvt.f16.f32 v18, v1
    vf.add       v1, v10, v18
    v.ld.h       v10, [s15, #64]
    vf.cvt.f16.f32 v18, v7
    vf.add       v7, v11, v18
    v.ld.h       v11, [s15, #96]
    vf.cvt.f16.f32 v18, v10
    vf.add       v10, v12, v18
    v.ld.h       v12, [s15, #128]
    vf.cvt.f16.f32 v18, v11
    vf.add       v11, v13, v18
    v.ld.h       v13, [s15, #160]
    vf.cvt.f16.f32 v18, v12
    vf.add       v12, v14, v18
    v.ld.h       v14, [s15, #192]
    vf.cvt.f16.f32 v18, v13
    vf.add       v13, v15, v18
    v.ld.h       v15, [s15, #224]
    vf.cvt.f16.f32 v18, v14
    vf.cvt.f32.f16 v14, v1
    vf.cvt.f32.f16 v1, v7
    vf.cvt.f32.f16 v7, v10
    vf.cvt.f32.f16 v10, v11
    vf.add       v11, v16, v18
    vf.cvt.f32.f16 v16, v12
    vf.cvt.f32.f16 v12, v13
    s.add        s10, s8, s11
    vf.cvt.f32.f16 v13, v11
    vf.cvt.f16.f32 v11, v15
    v.st.h       [s12, #0], v2
    vf.add       v2, v17, v11
    vf.cvt.f32.f16 v11, v2
    v.st.h       [s12, #32], v3
    v.st.h       [s12, #64], v4
    v.st.h       [s12, #96], v5
    v.st.h       [s12, #128], v6
    v.st.h       [s12, #160], v0
    v.st.h       [s12, #192], v8
    v.st.h       [s12, #224], v9
    v.st.h       [s10, #0], v14
    v.st.h       [s10, #32], v1
    v.st.h       [s10, #64], v7
    v.st.h       [s10, #96], v10
    v.st.h       [s10, #128], v16
    v.st.h       [s10, #160], v12
    v.st.h       [s10, #192], v13
    v.st.h       [s10, #224], v11
    s.addi       s9, s9, #256
    s.cmp.lt     s10, s9, s2
    br.nz        s10, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s9, s1, s6
    s.mov        s5, s1
    br.nz        s9, __rctx_program
    exit
