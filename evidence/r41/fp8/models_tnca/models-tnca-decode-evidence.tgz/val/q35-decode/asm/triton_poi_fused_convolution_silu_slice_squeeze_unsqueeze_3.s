    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #5
    v.add        v3, v1, v0
    v.movi       v0, #4
    s.rdspecial  s2, arg_base
    v.mul        v1, v3, v2
    v.movi       v2, #1
    v.mul        v4, v3, v0
    v.movi       v3, #2
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.add        v5, v1, v2
    v.add        v6, v1, v3
    s.ld.d       s4, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.add        v7, v4, v2
    v.movi       v2, #3
    v.ld.gather.h v8, [s3, v5]                   // index is in elements (ISA sec 9.1)
    v.add        v5, v1, v2
    v.add        v9, v4, v3
    v.add        v3, v1, v0
    v.add        v0, v4, v2
    .li       s5, #1069066811
    v.splat      v1, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.gather.h v2, [s4, v4]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v4, v8
    .li       s5, #1060205080
    v.splat      v8, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.gather.h v10, [s3, v6]                  // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v6, v2
    vf.mul       v2, v4, v6
    v.ld.gather.h v4, [s4, v7]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v6, v10
    v.ld.gather.h v7, [s3, v5]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v5, v4
    vf.mul       v4, v6, v5
    v.ld.gather.h v5, [s4, v9]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v6, v7
    vf.add       v7, v2, v4
    v.ld.gather.h v2, [s3, v3]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v3, v5
    vf.mul       v4, v6, v3
    v.ld.gather.h v3, [s4, v0]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v0, v2
    vf.add       v2, v7, v4
    vf.cvt.bf16.f32 v4, v3
    s.ld.d       s3, [s2, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    .li       s2, #1065353216
    v.splat      v3, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v6, v0, v4
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    s.add        s1, s3, s2                      // &out_ptr1[...]
    vf.add       v0, v2, v6
    vf.neg       v2, v0
    vf.mul       v4, v2, v1
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v2, v1, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v7, v8
    vf.fma       v2, v6, v1, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v6
    vf.add       v2, v1, v3
    v.rcp.approx v1, v2                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v2, v1, v5
    vf.fms       v4, v1, v3, v1
    vf.neg       v3, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v4, v3, v1
    vf.mul       v1, v0, v4                      // a/y: faithful quotient
    vf.fms       v3, v1, v2, v0
    vf.fms       v0, v3, v4, v1
    vf.neg       v2, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v1
    vf.cvt.f32.bf16 v1, v0
    v.st.h       [s1, #0], v1
__rctx_next:
    exit
