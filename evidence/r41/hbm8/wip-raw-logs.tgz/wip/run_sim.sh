#!/bin/bash
# run_sim.sh TAG RTLROOT BASE CASE... : one detached process per case
tag=$1; rtl=$2; base=$3; shift 3
mkdir -p ~/r41-hbm8-runs/sim
for case in "$@"; do
  out=~/r41-hbm8-runs/sim/$case-$tag
  log=$out.log
  setsid -f bash -c "source ~/tc_env/env.sh; cd ~/r41-hbm8; export TNCA_HOST_TIMEOUT=14400; /usr/bin/time -v ~/tc_env/torchenv/bin/python tools/performance_harness/hbm8_case.py --sim --case $case --rtl-root $rtl --hbm-base $base --out $out; echo EXIT=\$?" > $log 2>&1 < /dev/null
done
