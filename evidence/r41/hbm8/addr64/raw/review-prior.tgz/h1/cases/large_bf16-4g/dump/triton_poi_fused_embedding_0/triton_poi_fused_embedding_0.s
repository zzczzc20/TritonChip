    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.add        s3, s2, s1
    s.rdspecial  s1, npid.x
    s.cmp.ge     s2, s3, s1
    br.nz        s2, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s4, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.movz       s1, #16
    s.movz       s6, #0
    s.movz       s7, #1
    s.movz       s8, #2
    s.movz       s9, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s15, #9
    s.movz       s16, #10
    s.movz       s17, #11
    s.movz       s18, #12
    s.movz       s19, #13
    s.movz       s20, #14
    s.movz       s21, #15
    s.movz       s22, #0
    s.movz       s23, #0
    s.movz       s24, #0
    s.movz       s25, #0
    s.movz       s26, #0
    s.movz       s27, #0
    s.movz       s28, #0
    s.movz       s29, #0
    s.movz       s30, #0
    s.movz       s31, #0
    s.movz       s32, #0
    s.movz       s33, #0
    s.movz       s34, #0
    s.movz       s35, #0
    s.movz       s36, #0
    s.movz       s37, #0
    .li       s38, #1114112
    .li       s39, #1114112
    .li       s40, #1114112
    .li       s41, #1114112
    .li       s42, #1114112
    .li       s43, #1114112
    .li       s44, #1114112
    .li       s45, #1114112
    .li       s46, #1114112
    .li       s47, #1114112
    .li       s48, #1114112
    .li       s49, #1114112
    .li       s50, #1114112
    .li       s51, #1114112
    .li       s52, #1114112
    .li       s53, #1114112
    s.movz       s54, #0
    s.shli       s55, s3, #32
    s.ashri      s3, s55, #32
    s.mul        s55, s3, s1
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #0
    v.movi       v2, #0
    v.extract    s1, v0, #0
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #0
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #0
    v.extract    s1, v0, #1
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #1
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #1
    v.extract    s1, v0, #2
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #2
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #2
    v.extract    s1, v0, #3
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #3
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #3
    v.extract    s1, v0, #4
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #4
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #4
    v.extract    s1, v0, #5
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #5
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #5
    v.extract    s1, v0, #6
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #6
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #6
    v.extract    s1, v0, #7
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #7
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #7
    v.extract    s1, v0, #8
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #8
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #8
    v.extract    s1, v0, #9
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #9
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #9
    v.extract    s1, v0, #10
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #10
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #10
    v.extract    s1, v0, #11
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #11
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #11
    v.extract    s1, v0, #12
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #12
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #12
    v.extract    s1, v0, #13
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #13
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #13
    v.extract    s1, v0, #14
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #14
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #14
    v.extract    s1, v0, #15
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    v.insert     v1, s1, #15
    s.lshri      s3, s1, #32
    v.insert     v2, s3, #15
    v.movi       v0, #0
    v.movi       v3, #0
    v.insert     v0, s55, #0
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #0
    v.insert     v0, s55, #1
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #1
    v.insert     v0, s55, #2
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #2
    v.insert     v0, s55, #3
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #3
    v.insert     v0, s55, #4
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #4
    v.insert     v0, s55, #5
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #5
    v.insert     v0, s55, #6
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #6
    v.insert     v0, s55, #7
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #7
    v.insert     v0, s55, #8
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #8
    v.insert     v0, s55, #9
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #9
    v.insert     v0, s55, #10
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #10
    v.insert     v0, s55, #11
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #11
    v.insert     v0, s55, #12
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #12
    v.insert     v0, s55, #13
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #13
    v.insert     v0, s55, #14
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #14
    v.insert     v0, s55, #15
    s.lshri      s1, s55, #32
    v.insert     v3, s1, #15
    v.movi       v4, #0
    v.movi       v5, #0
    v.extract    s1, v0, #0
    v.extract    s3, v3, #0
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #0
    v.extract    s56, v2, #0
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #0
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #0
    v.extract    s1, v0, #1
    v.extract    s3, v3, #1
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #1
    v.extract    s56, v2, #1
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #1
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #1
    v.extract    s1, v0, #2
    v.extract    s3, v3, #2
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #2
    v.extract    s56, v2, #2
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #2
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #2
    v.extract    s1, v0, #3
    v.extract    s3, v3, #3
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #3
    v.extract    s56, v2, #3
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #3
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #3
    v.extract    s1, v0, #4
    v.extract    s3, v3, #4
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #4
    v.extract    s56, v2, #4
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #4
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #4
    v.extract    s1, v0, #5
    v.extract    s3, v3, #5
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #5
    v.extract    s56, v2, #5
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #5
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #5
    v.extract    s1, v0, #6
    v.extract    s3, v3, #6
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #6
    v.extract    s56, v2, #6
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #6
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #6
    v.extract    s1, v0, #7
    v.extract    s3, v3, #7
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #7
    v.extract    s56, v2, #7
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #7
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #7
    v.extract    s1, v0, #8
    v.extract    s3, v3, #8
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #8
    v.extract    s56, v2, #8
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #8
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #8
    v.extract    s1, v0, #9
    v.extract    s3, v3, #9
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #9
    v.extract    s56, v2, #9
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #9
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #9
    v.extract    s1, v0, #10
    v.extract    s3, v3, #10
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #10
    v.extract    s56, v2, #10
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #10
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #10
    v.extract    s1, v0, #11
    v.extract    s3, v3, #11
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #11
    v.extract    s56, v2, #11
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #11
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #11
    v.extract    s1, v0, #12
    v.extract    s3, v3, #12
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #12
    v.extract    s56, v2, #12
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #12
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #12
    v.extract    s1, v0, #13
    v.extract    s3, v3, #13
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #13
    v.extract    s56, v2, #13
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #13
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #13
    v.extract    s1, v0, #14
    v.extract    s3, v3, #14
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #14
    v.extract    s56, v2, #14
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #14
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #14
    v.extract    s1, v0, #15
    v.extract    s3, v3, #15
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    v.extract    s1, v1, #15
    v.extract    s56, v2, #15
    s.shli       s57, s56, #32
    s.or         s56, s1, s57
    s.add        s1, s3, s56
    v.insert     v4, s1, #15
    s.lshri      s3, s1, #32
    v.insert     v5, s3, #15
    v.movi       v0, #0
    v.movi       v1, #0
    v.extract    s1, v4, #0
    v.extract    s3, v5, #0
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #0
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #0
    v.extract    s1, v4, #1
    v.extract    s3, v5, #1
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #1
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #1
    v.extract    s1, v4, #2
    v.extract    s3, v5, #2
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #2
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #2
    v.extract    s1, v4, #3
    v.extract    s3, v5, #3
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #3
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #3
    v.extract    s1, v4, #4
    v.extract    s3, v5, #4
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #4
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #4
    v.extract    s1, v4, #5
    v.extract    s3, v5, #5
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #5
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #5
    v.extract    s1, v4, #6
    v.extract    s3, v5, #6
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #6
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #6
    v.extract    s1, v4, #7
    v.extract    s3, v5, #7
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #7
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #7
    v.extract    s1, v4, #8
    v.extract    s3, v5, #8
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #8
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #8
    v.extract    s1, v4, #9
    v.extract    s3, v5, #9
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #9
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #9
    v.extract    s1, v4, #10
    v.extract    s3, v5, #10
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #10
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #10
    v.extract    s1, v4, #11
    v.extract    s3, v5, #11
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #11
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #11
    v.extract    s1, v4, #12
    v.extract    s3, v5, #12
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #12
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #12
    v.extract    s1, v4, #13
    v.extract    s3, v5, #13
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #13
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #13
    v.extract    s1, v4, #14
    v.extract    s3, v5, #14
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #14
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #14
    v.extract    s1, v4, #15
    v.extract    s3, v5, #15
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s3, s56, s1
    s.lshri      s56, s3, #11
    s.xor        s3, s56, s1
    s.sub        s56, s3, s1
    v.insert     v0, s56, #15
    s.lshri      s1, s56, #32
    v.insert     v1, s1, #15
    v.movi       v2, #0
    v.movi       v3, #0
    v.extract    s1, v4, #0
    v.extract    s3, v5, #0
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #0
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #0
    v.extract    s1, v4, #1
    v.extract    s3, v5, #1
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #1
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #1
    v.extract    s1, v4, #2
    v.extract    s3, v5, #2
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #2
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #2
    v.extract    s1, v4, #3
    v.extract    s3, v5, #3
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #3
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #3
    v.extract    s1, v4, #4
    v.extract    s3, v5, #4
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #4
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #4
    v.extract    s1, v4, #5
    v.extract    s3, v5, #5
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #5
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #5
    v.extract    s1, v4, #6
    v.extract    s3, v5, #6
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #6
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #6
    v.extract    s1, v4, #7
    v.extract    s3, v5, #7
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #7
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #7
    v.extract    s1, v4, #8
    v.extract    s3, v5, #8
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #8
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #8
    v.extract    s1, v4, #9
    v.extract    s3, v5, #9
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #9
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #9
    v.extract    s1, v4, #10
    v.extract    s3, v5, #10
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #10
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #10
    v.extract    s1, v4, #11
    v.extract    s3, v5, #11
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #11
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #11
    v.extract    s1, v4, #12
    v.extract    s3, v5, #12
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #12
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #12
    v.extract    s1, v4, #13
    v.extract    s3, v5, #13
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #13
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #13
    v.extract    s1, v4, #14
    v.extract    s3, v5, #14
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #14
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #14
    v.extract    s1, v4, #15
    v.extract    s3, v5, #15
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.ashri      s1, s3, #63
    s.xor        s56, s3, s1
    s.sub        s57, s56, s1
    s.lshri      s56, s57, #11
    s.xor        s57, s56, s1
    s.sub        s56, s57, s1
    s.muli       s1, s56, #2048
    s.sub        s56, s3, s1
    v.insert     v2, s56, #15
    s.lshri      s1, s56, #32
    v.insert     v3, s1, #15
    v.movi       v4, #0
    v.extract    s1, v0, #0
    v.extract    s3, v1, #0
    s.shli       s56, s3, #32
    s.or         s3, s1, s56
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 0: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s6
    v.cmp.eq     p1, v5, v6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s3, #4
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s1, v4]               // index is in elements (ISA sec 9.1)
    v.extract    s1, v0, #1
    v.extract    s3, v1, #1
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 1: a 64-bit address
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v8, s7
    v.cmp.eq     p1, v7, v8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v8, v7, v5
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v7, v5, v6
    v.extract    s1, v0, #2
    v.extract    s3, v1, #2
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 2: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s8
    v.cmp.eq     p1, v5, v6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v6, v5, v8
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v8, v5, v7
    v.extract    s1, v0, #3
    v.extract    s3, v1, #3
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 3: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v7, s9
    v.cmp.eq     p1, v5, v7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v7, v5, v6
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v6, v5, v8
    v.extract    s1, v0, #4
    v.extract    s3, v1, #4
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 4: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v8, s10
    v.cmp.eq     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v8, v5, v7
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v7, v5, v6
    v.extract    s1, v0, #5
    v.extract    s3, v1, #5
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 5: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s11
    v.cmp.eq     p1, v5, v6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v6, v5, v8
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v8, v5, v7
    v.extract    s1, v0, #6
    v.extract    s3, v1, #6
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 6: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v7, s12
    v.cmp.eq     p1, v5, v7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v7, v5, v6
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v6, v5, v8
    v.extract    s1, v0, #7
    v.extract    s3, v1, #7
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 7: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v8, s13
    v.cmp.eq     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v8, v5, v7
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v7, v5, v6
    v.extract    s1, v0, #8
    v.extract    s3, v1, #8
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 8: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s14
    v.cmp.eq     p1, v5, v6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v6, v5, v8
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v8, v5, v7
    v.extract    s1, v0, #9
    v.extract    s3, v1, #9
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 9: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v7, s15
    v.cmp.eq     p1, v5, v7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v7, v5, v6
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v6, v5, v8
    v.extract    s1, v0, #10
    v.extract    s3, v1, #10
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 10: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v8, s16
    v.cmp.eq     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v8, v5, v7
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v7, v5, v6
    v.extract    s1, v0, #11
    v.extract    s3, v1, #11
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 11: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s17
    v.cmp.eq     p1, v5, v6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v6, v5, v8
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v8, v5, v7
    v.extract    s1, v0, #12
    v.extract    s3, v1, #12
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 12: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v7, s18
    v.cmp.eq     p1, v5, v7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v7, v5, v6
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v6, v5, v8
    v.extract    s1, v0, #13
    v.extract    s3, v1, #13
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 13: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v8, s19
    v.cmp.eq     p1, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v8, v5, v7
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v7, v5, v6
    v.extract    s1, v0, #14
    v.extract    s3, v1, #14
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 14: a 64-bit address
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s20
    v.cmp.eq     p1, v5, v6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v6, v5, v8
    s.addi       s1, s3, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v8, v5, v7
    v.extract    s1, v0, #15
    v.extract    s3, v1, #15
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.shli       s1, s3, #3
    s.add        s3, s2, s1                      // lane 15: a 64-bit address
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s21
    v.cmp.eq     p1, v0, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s3, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v1, v0, v6
    s.addi       s1, s3, #4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s1, v4]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v4, v0, v8
    v.movi       v0, #0
    v.extract    s1, v1, #0
    v.extract    s2, v4, #0
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s22
    v.insert     v0, s1, #0
    v.extract    s1, v1, #1
    v.extract    s2, v4, #1
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s23
    v.insert     v0, s1, #1
    v.extract    s1, v1, #2
    v.extract    s2, v4, #2
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s24
    v.insert     v0, s1, #2
    v.extract    s1, v1, #3
    v.extract    s2, v4, #3
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s25
    v.insert     v0, s1, #3
    v.extract    s1, v1, #4
    v.extract    s2, v4, #4
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s26
    v.insert     v0, s1, #4
    v.extract    s1, v1, #5
    v.extract    s2, v4, #5
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s27
    v.insert     v0, s1, #5
    v.extract    s1, v1, #6
    v.extract    s2, v4, #6
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s28
    v.insert     v0, s1, #6
    v.extract    s1, v1, #7
    v.extract    s2, v4, #7
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s29
    v.insert     v0, s1, #7
    v.extract    s1, v1, #8
    v.extract    s2, v4, #8
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s30
    v.insert     v0, s1, #8
    v.extract    s1, v1, #9
    v.extract    s2, v4, #9
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s31
    v.insert     v0, s1, #9
    v.extract    s1, v1, #10
    v.extract    s2, v4, #10
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s32
    v.insert     v0, s1, #10
    v.extract    s1, v1, #11
    v.extract    s2, v4, #11
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s33
    v.insert     v0, s1, #11
    v.extract    s1, v1, #12
    v.extract    s2, v4, #12
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s34
    v.insert     v0, s1, #12
    v.extract    s1, v1, #13
    v.extract    s2, v4, #13
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s35
    v.insert     v0, s1, #13
    v.extract    s1, v1, #14
    v.extract    s2, v4, #14
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s36
    v.insert     v0, s1, #14
    v.extract    s1, v1, #15
    v.extract    s2, v4, #15
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.ge     s1, s2, s37
    v.insert     v0, s1, #15
    v.movi       v5, #0
    v.cmp.ne     p1, v0, v5
    v.movi       v0, #0
    v.extract    s1, v1, #0
    v.extract    s2, v4, #0
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s38
    v.insert     v0, s1, #0
    v.extract    s1, v1, #1
    v.extract    s2, v4, #1
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s39
    v.insert     v0, s1, #1
    v.extract    s1, v1, #2
    v.extract    s2, v4, #2
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s40
    v.insert     v0, s1, #2
    v.extract    s1, v1, #3
    v.extract    s2, v4, #3
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s41
    v.insert     v0, s1, #3
    v.extract    s1, v1, #4
    v.extract    s2, v4, #4
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s42
    v.insert     v0, s1, #4
    v.extract    s1, v1, #5
    v.extract    s2, v4, #5
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s43
    v.insert     v0, s1, #5
    v.extract    s1, v1, #6
    v.extract    s2, v4, #6
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s44
    v.insert     v0, s1, #6
    v.extract    s1, v1, #7
    v.extract    s2, v4, #7
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s45
    v.insert     v0, s1, #7
    v.extract    s1, v1, #8
    v.extract    s2, v4, #8
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s46
    v.insert     v0, s1, #8
    v.extract    s1, v1, #9
    v.extract    s2, v4, #9
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s47
    v.insert     v0, s1, #9
    v.extract    s1, v1, #10
    v.extract    s2, v4, #10
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s48
    v.insert     v0, s1, #10
    v.extract    s1, v1, #11
    v.extract    s2, v4, #11
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s49
    v.insert     v0, s1, #11
    v.extract    s1, v1, #12
    v.extract    s2, v4, #12
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s50
    v.insert     v0, s1, #12
    v.extract    s1, v1, #13
    v.extract    s2, v4, #13
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s51
    v.insert     v0, s1, #13
    v.extract    s1, v1, #14
    v.extract    s2, v4, #14
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s52
    v.insert     v0, s1, #14
    v.extract    s1, v1, #15
    v.extract    s2, v4, #15
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.cmp.lt     s1, s2, s53
    v.insert     v0, s1, #15
    v.movi       v5, #0
    v.cmp.ne     p2, v0, v5
    p.and        p3, p1, p2
    v.movi       v0, #0
    v.movi       v5, #1
    @p3 v.sel        v6, v0, v5
    v.reduce.or  s1, v6
    s.cmp.eq     s2, s1, s54
    br.nz        s2, assert_ok_1
    trap         #677351
assert_ok_1:
    v.movi       v0, #0
    v.movi       v5, #0
    v.extract    s1, v1, #0
    v.extract    s2, v4, #0
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #0
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #0
    v.extract    s1, v1, #1
    v.extract    s2, v4, #1
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #1
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #1
    v.extract    s1, v1, #2
    v.extract    s2, v4, #2
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #2
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #2
    v.extract    s1, v1, #3
    v.extract    s2, v4, #3
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #3
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #3
    v.extract    s1, v1, #4
    v.extract    s2, v4, #4
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #4
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #4
    v.extract    s1, v1, #5
    v.extract    s2, v4, #5
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #5
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #5
    v.extract    s1, v1, #6
    v.extract    s2, v4, #6
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #6
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #6
    v.extract    s1, v1, #7
    v.extract    s2, v4, #7
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #7
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #7
    v.extract    s1, v1, #8
    v.extract    s2, v4, #8
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #8
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #8
    v.extract    s1, v1, #9
    v.extract    s2, v4, #9
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #9
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #9
    v.extract    s1, v1, #10
    v.extract    s2, v4, #10
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #10
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #10
    v.extract    s1, v1, #11
    v.extract    s2, v4, #11
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #11
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #11
    v.extract    s1, v1, #12
    v.extract    s2, v4, #12
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #12
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #12
    v.extract    s1, v1, #13
    v.extract    s2, v4, #13
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #13
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #13
    v.extract    s1, v1, #14
    v.extract    s2, v4, #14
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #14
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #14
    v.extract    s1, v1, #15
    v.extract    s2, v4, #15
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.movz       s1, #2048
    s.mul        s3, s2, s1
    v.insert     v0, s3, #15
    s.lshri      s1, s3, #32
    v.insert     v5, s1, #15
    v.movi       v1, #0
    v.movi       v4, #0
    v.extract    s1, v2, #0
    v.extract    s2, v3, #0
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #0
    v.extract    s3, v5, #0
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #0
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #0
    v.extract    s1, v2, #1
    v.extract    s2, v3, #1
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #1
    v.extract    s3, v5, #1
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #1
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #1
    v.extract    s1, v2, #2
    v.extract    s2, v3, #2
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #2
    v.extract    s3, v5, #2
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #2
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #2
    v.extract    s1, v2, #3
    v.extract    s2, v3, #3
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #3
    v.extract    s3, v5, #3
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #3
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #3
    v.extract    s1, v2, #4
    v.extract    s2, v3, #4
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #4
    v.extract    s3, v5, #4
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #4
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #4
    v.extract    s1, v2, #5
    v.extract    s2, v3, #5
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #5
    v.extract    s3, v5, #5
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #5
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #5
    v.extract    s1, v2, #6
    v.extract    s2, v3, #6
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #6
    v.extract    s3, v5, #6
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #6
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #6
    v.extract    s1, v2, #7
    v.extract    s2, v3, #7
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #7
    v.extract    s3, v5, #7
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #7
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #7
    v.extract    s1, v2, #8
    v.extract    s2, v3, #8
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #8
    v.extract    s3, v5, #8
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #8
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #8
    v.extract    s1, v2, #9
    v.extract    s2, v3, #9
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #9
    v.extract    s3, v5, #9
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #9
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #9
    v.extract    s1, v2, #10
    v.extract    s2, v3, #10
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #10
    v.extract    s3, v5, #10
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #10
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #10
    v.extract    s1, v2, #11
    v.extract    s2, v3, #11
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #11
    v.extract    s3, v5, #11
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #11
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #11
    v.extract    s1, v2, #12
    v.extract    s2, v3, #12
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #12
    v.extract    s3, v5, #12
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #12
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #12
    v.extract    s1, v2, #13
    v.extract    s2, v3, #13
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #13
    v.extract    s3, v5, #13
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #13
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #13
    v.extract    s1, v2, #14
    v.extract    s2, v3, #14
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #14
    v.extract    s3, v5, #14
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #14
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #14
    v.extract    s1, v2, #15
    v.extract    s2, v3, #15
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    v.extract    s1, v0, #15
    v.extract    s3, v5, #15
    s.shli       s6, s3, #32
    s.or         s3, s1, s6
    s.add        s1, s2, s3
    v.insert     v1, s1, #15
    s.lshri      s2, s1, #32
    v.insert     v4, s2, #15
    v.movi       v0, #0
    v.extract    s1, v1, #0
    v.extract    s2, v4, #0
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 0: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #0
    v.splat      v3, s1
    v.cmp.eq     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.extract    s1, v1, #1
    v.extract    s2, v4, #1
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 1: a 64-bit address
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s1, #1
    v.splat      v5, s1
    v.cmp.eq     p1, v3, v5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v5, v3, v2
    v.extract    s1, v1, #2
    v.extract    s2, v4, #2
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 2: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #2
    v.splat      v3, s1
    v.cmp.eq     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v3, v2, v5
    v.extract    s1, v1, #3
    v.extract    s2, v4, #3
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 3: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #3
    v.splat      v5, s1
    v.cmp.eq     p1, v2, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v5, v2, v3
    v.extract    s1, v1, #4
    v.extract    s2, v4, #4
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 4: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #4
    v.splat      v3, s1
    v.cmp.eq     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v3, v2, v5
    v.extract    s1, v1, #5
    v.extract    s2, v4, #5
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 5: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #5
    v.splat      v5, s1
    v.cmp.eq     p1, v2, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v5, v2, v3
    v.extract    s1, v1, #6
    v.extract    s2, v4, #6
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 6: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #6
    v.splat      v3, s1
    v.cmp.eq     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v3, v2, v5
    v.extract    s1, v1, #7
    v.extract    s2, v4, #7
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 7: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #7
    v.splat      v5, s1
    v.cmp.eq     p1, v2, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v5, v2, v3
    v.extract    s1, v1, #8
    v.extract    s2, v4, #8
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 8: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #8
    v.splat      v3, s1
    v.cmp.eq     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v3, v2, v5
    v.extract    s1, v1, #9
    v.extract    s2, v4, #9
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 9: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #9
    v.splat      v5, s1
    v.cmp.eq     p1, v2, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v5, v2, v3
    v.extract    s1, v1, #10
    v.extract    s2, v4, #10
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 10: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #10
    v.splat      v3, s1
    v.cmp.eq     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v3, v2, v5
    v.extract    s1, v1, #11
    v.extract    s2, v4, #11
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 11: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #11
    v.splat      v5, s1
    v.cmp.eq     p1, v2, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v5, v2, v3
    v.extract    s1, v1, #12
    v.extract    s2, v4, #12
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 12: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #12
    v.splat      v3, s1
    v.cmp.eq     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v3, v2, v5
    v.extract    s1, v1, #13
    v.extract    s2, v4, #13
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 13: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #13
    v.splat      v5, s1
    v.cmp.eq     p1, v2, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v5, v2, v3
    v.extract    s1, v1, #14
    v.extract    s2, v4, #14
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 14: a 64-bit address
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s1, #14
    v.splat      v3, s1
    v.cmp.eq     p1, v2, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v3, v2, v5
    v.extract    s1, v1, #15
    v.extract    s2, v4, #15
    s.shli       s3, s2, #32
    s.or         s2, s1, s3
    s.shli       s1, s2, #1
    s.add        s2, s4, s1                      // lane 15: a 64-bit address
    v.iota       v1                              // arange(0, VLEN)
    s.movz       s1, #15
    v.splat      v2, s1
    v.cmp.eq     p1, v1, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v0, v1, v3
    s.shli       s1, s55, #1                     // element offset -> bytes (x2)
    s.add        s2, s5, s1                      // &out_ptr0[...]
    v.st.h       [s2, #0], v0
__rctx_next:
    exit
