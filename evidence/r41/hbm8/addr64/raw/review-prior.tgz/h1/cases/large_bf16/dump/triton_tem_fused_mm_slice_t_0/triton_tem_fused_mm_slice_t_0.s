    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    .li       s1, #2415722496
    s.add        s6, s3, s1                      // the pointer's constant offset (2415722496 bytes)
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #3072
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #2048                   // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s7, #0], s6
    .li       s1, #2147483647
    s.st.d       [s7, #8], s1
    .li       s1, #2147483647
    s.st.d       [s7, #16], s1
    s.movz       s1, #4096
    s.st.d       [s7, #48], s1
    s.movz       s1, #2
    s.st.d       [s7, #56], s1
    .li       s1, #68719476752
    s.st.d       [s7, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s7, #104], s1
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #3
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s1, s9
    s.sub        s9, s8, s10
    s.xor        s8, s1, s9
    s.sub        s10, s8, s9
    .li       s8, #1431655766
    s.movz       s10, #1
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #1
    s.cmp.lt     s18, s4, s7
    s.sub        s7, s6, s18
    s.xor        s6, s4, s7
    s.sub        s18, s6, s7
    s.mul        s6, s18, s8
    s.lshri      s8, s6, #32
    s.sub        s6, s18, s8
    s.lshri      s19, s6, #1
    s.add        s6, s8, s19
    s.lshri      s8, s6, #1
    s.muli       s6, s8, #3
    s.sub        s19, s18, s6
    s.xor        s6, s7, s9
    s.xor        s7, s8, s6
    s.sub        s8, s7, s6
    s.sub        s6, s10, s8
    s.min.s      s7, s6, s10
    s.cmp.lt     s6, s4, s12
    s.sub        s9, s11, s6
    s.cmp.lt     s6, s7, s14
    s.sub        s11, s13, s6
    s.xor        s6, s4, s9
    s.sub        s12, s6, s9
    s.xor        s6, s7, s11
    s.sub        s13, s6, s11
    s.addi       s6, s15, #0
    s.addi       s11, s16, #0
    s.cmp.eq     s14, s13, s17
    s.mov        s6, s12
    br.nz        s14, sdiv_done_1
    s.movz       s14, #0
    s.movz       s15, #31
    s.mov        s6, s14
    s.addi       s14, s15, #0
sdiv_2:
    s.lshr       s15, s12, s14
    s.shli       s16, s11, #1
    s.andi       s17, s15, #1
    s.movz       s15, #0
    s.or         s18, s16, s17
    s.movz       s16, #1
    s.cmp.geu    s17, s18, s13
    s.shl        s19, s16, s14
    s.sub        s16, s15, s17
    s.subi       s15, s14, #1
    s.and        s17, s13, s16
    s.and        s20, s19, s16
    s.sub        s16, s18, s17
    s.or         s17, s6, s20
    s.mov        s11, s16
    s.mov        s6, s17
    s.mov        s14, s15
    s.movz       s15, #0
    s.cmp.ge     s16, s14, s15
    br.nz        s16, sdiv_2
sdiv_done_1:
    s.movz       s6, #0
    s.movz       s12, #0
    s.cmp.lt     s13, s4, s6
    .li       s6, #1431655766
    s.sub        s14, s12, s13
    s.movz       s12, #0
    s.xor        s13, s4, s14
    s.movz       s4, #0
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.mul        s16, s15, s6
    s.cmp.lt     s6, s7, s12
    s.movz       s12, #0
    s.sub        s17, s13, s6
    s.movz       s6, #0
    s.lshri      s13, s16, #32
    s.cmp.lt     s16, s1, s12
    s.xor        s12, s7, s17
    s.xor        s7, s11, s9
    s.sub        s11, s12, s17
    s.sub        s12, s7, s9
    s.sub        s7, s15, s13
    s.add        s9, s8, s12
    s.lshri      s8, s7, #1
    s.movz       s7, #0
    s.add        s12, s13, s8
    s.sub        s8, s7, s16
    s.lshri      s7, s12, #1
    s.movz       s12, #0
    s.muli       s13, s7, #3
    s.movz       s7, #1
    s.xor        s16, s1, s8
    s.addi       s1, s12, #0
    s.cmp.eq     s12, s11, s7
    s.sub        s7, s15, s13
    s.movz       s13, #0
    s.xor        s15, s7, s14
    s.sub        s7, s16, s8
    s.sub        s7, s15, s14
    s.addi       s8, s13, #0
    s.cmp.lt     s13, s7, s4
    s.sub        s4, s6, s13
    s.xor        s6, s7, s4
    s.sub        s7, s6, s4
    s.mov        s1, s7
    br.nz        s12, sdiv_done_3
    s.movz       s6, #0
    s.movz       s12, #31
    s.mov        s1, s6
    s.addi       s6, s12, #0
sdiv_4:
    s.lshr       s12, s7, s6
    s.shli       s13, s8, #1
    s.andi       s14, s12, #1
    s.movz       s12, #0
    s.or         s15, s13, s14
    s.movz       s13, #1
    s.cmp.geu    s14, s15, s11
    s.shl        s16, s13, s6
    s.sub        s13, s12, s14
    s.subi       s12, s6, #1
    s.and        s14, s11, s13
    s.and        s18, s16, s13
    s.sub        s13, s15, s14
    s.or         s14, s1, s18
    s.mov        s8, s13
    s.mov        s1, s14
    s.mov        s6, s12
    s.movz       s12, #0
    s.cmp.ge     s13, s6, s12
    br.nz        s13, sdiv_4
sdiv_done_3:
    s.xor        s6, s4, s17
    s.movz       s4, #16
    s.xor        s7, s1, s6
    .li       s1, #1431655766
    s.sub        s8, s7, s6
    s.mul        s6, s9, s4
    s.mul        s7, s8, s4
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #0
    v.movi       v2, #3
    v.splat      v3, s6
    s.mul        s11, s7, s1
    v.movi       v4, #4
    v.add        v5, v3, v0
    s.movz       s1, #0
    v.splat      v3, s9
    s.lshri      s9, s11, #32
    v.sub        v6, v1, v5
    s.sub        s11, s7, s9
    v.cmp.lt     p1, v5, v1
    s.lshri      s12, s11, #1
    @p1 v.sel        v7, v6, v5
    s.add        s11, s9, s12
    v.splat      v5, s1
    s.lshri      s9, s11, #5
    v.and        v6, v7, v2
    s.muli       s11, s9, #48
    v.splat      v2, s8
    v.splat      v7, s1
    v.cmp.lt     p2, v4, v1
    v.cmp.ge     p3, v3, v5
    s.sub        s8, s7, s11
    v.splat      v3, s7
    v.sub        v5, v1, v4
    v.sub        v8, v1, v6
    v.cmp.ge     p3, v2, v7
    v.splat      v1, s8
    v.iota       v2                              // arange(0, VLEN)
    v.add        v7, v3, v0
    v.movi       v0, #1
    @p2 v.sel        v0, v5, v4
    @p1 v.sel        v0, v8, v6
    v.add        v3, v1, v2
    s.movz       s9, #4
    s.addi       s11, s1, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s12, s11, s9
    br.nz        s12, endfor_6
    s.mul        s12, s11, s4
    s.rdspecial  s13, arg_base
    s.ld.d       s14, [s13, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s13, role_id
    s.movz       s15, #3072
    s.mul        s16, s13, s15
    s.add        s13, s14, s16                   // this context's own scratch
    s.addi       s14, s13, #0
    v.splat      v1, s1
    s.movz       s15, #0
    s.add        s16, s15, s12                   // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s16
    v.add        v4, v2, v3
    v.extract    s15, v0, #0
    v.splat      v2, s15
    s.movz       s15, #64
    v.splat      v3, s15
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s14, #0], v5
    s.addi       s15, s14, #64
    v.extract    s16, v0, #1
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #128
    v.extract    s16, v0, #2
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #192
    v.extract    s16, v0, #3
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #256
    v.extract    s16, v0, #4
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #320
    v.extract    s16, v0, #5
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #384
    v.extract    s16, v0, #6
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #448
    v.extract    s16, v0, #7
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #512
    v.extract    s16, v0, #8
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #576
    v.extract    s16, v0, #9
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #640
    v.extract    s16, v0, #10
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #704
    v.extract    s16, v0, #11
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #768
    v.extract    s16, v0, #12
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #832
    v.extract    s16, v0, #13
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #896
    v.extract    s16, v0, #14
    v.splat      v2, s16
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v5
    s.addi       s15, s14, #960
    v.extract    s14, v0, #15
    v.splat      v2, s14
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    v.add        v3, v1, v2
    v.st.w       [s15, #0], v3
    fence.acq_rel.device
    s.addi       s14, s13, #1024
    s.addi       s15, s13, #0
    v.ld.w       v1, [s15, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s15, s14, #64
    s.addi       s16, s13, #64
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #128
    s.addi       s16, s13, #128
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #192
    s.addi       s16, s13, #192
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #256
    s.addi       s16, s13, #256
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #320
    s.addi       s16, s13, #320
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #384
    s.addi       s16, s13, #384
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #448
    s.addi       s16, s13, #448
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #512
    s.addi       s16, s13, #512
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #576
    s.addi       s16, s13, #576
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #640
    s.addi       s16, s13, #640
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #704
    s.addi       s16, s13, #704
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #768
    s.addi       s16, s13, #768
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #832
    s.addi       s16, s13, #832
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #896
    s.addi       s16, s13, #896
    v.ld.w       v1, [s16, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s14, #960
    s.addi       s14, s13, #960
    v.ld.w       v1, [s14, #0]
    v.ld.gather.h v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    fence.acq_rel.device
    .li       s14, #2415722496
    s.add        s15, s3, s14                    // &arg_B[1207861248] (a constant offset, x2)
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s14, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s15, s8                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s12                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s15, s14
    mb.wait      s14
    s.addi       s12, s13, #2304                 // 512 bytes of repack scratch
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s15, s13, #1024
    v.ld.w       v1, [s15, #0]
    v.st.h       [s12, #0], v1
    s.addi       s15, s13, #1088
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #32                   // row 1
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1152
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #64                   // row 2
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1216
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #96                   // row 3
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1280
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #128                  // row 4
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1344
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #160                  // row 5
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1408
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #192                  // row 6
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1472
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #224                  // row 7
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1536
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #256                  // row 8
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1600
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #288                  // row 9
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1664
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #320                  // row 10
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1728
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #352                  // row 11
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1792
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #384                  // row 12
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1856
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #416                  // row 13
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1920
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #448                  // row 14
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #1984
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s12, #480                  // row 15
    v.st.h       [s15, #0], v1
    s.addi       s15, s13, #2816                 // TensorMap 1: a repacked tile
    s.movz       s13, #0
    s.st.d       [s15, #0], s12
    s.movz       s12, #16
    s.st.d       [s15, #8], s12
    s.movz       s12, #16
    s.st.d       [s15, #16], s12
    s.movz       s12, #32
    s.st.d       [s15, #48], s12
    s.movz       s12, #2
    s.st.d       [s15, #56], s12
    .li       s12, #68719476752
    s.st.d       [s15, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s15, #104], s12
    fence.release.device
    td.load      d1, [s15]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s12, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s15, s12                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s12                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s15, s13
    mb.wait      s13
    mb.arm       s12, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v48, v56, s12
    mb.wait      s12
    s.add        s15, s11, s10
    s.mov        s11, s15
    s.movz       s15, #1
    br.nz        s15, for_5
endfor_6:
    s.movz       s1, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.add        s3, s1, s7                      // the tile origin
    s.movz       s1, #0
    s.muli       s4, s7, #2                      // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s3
    a.vread      v2, a0, s2
    s.add        s2, s1, s6                      // the tile origin
    s.movz       s1, #48
    s.muli       s3, s6, #96                     // a runtime tile origin, x96
    v.splat      v3, s2
    v.splat      v4, s9
    v.add        v5, v0, v1
    v.splat      v0, s1
    vf.cvt.f32.bf16 v1, v2
    s.add        s1, s5, s4                      // the tile origin
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s4, s1, s3                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s1, #1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v0, a0, s1
    s.addi       s1, s2, #1
    s.addi       s3, s4, #96                     // row 1
    v.splat      v1, s1
    vf.cvt.f32.bf16 v2, v0
    s.movz       s1, #2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s5, s2, #2
    s.addi       s6, s4, #192                    // row 2
    v.splat      v0, s5
    s.movz       s5, #3
    s.addi       s7, s2, #3
    @p3 v.st.h       [s3, #0], v2
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    v.splat      v1, s7
    s.addi       s1, s4, #288                    // row 3
    s.movz       s3, #4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    s.addi       s7, s2, #4
    s.addi       s8, s4, #384                    // row 4
    v.splat      v1, s7
    s.movz       s7, #5
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s5, s2, #5
    s.addi       s6, s4, #480                    // row 5
    v.splat      v0, s5
    s.movz       s5, #6
    s.addi       s9, s2, #6
    v.splat      v2, s9
    s.addi       s9, s4, #576                    // row 6
    @p4 v.st.h       [s1, #0], v1
    a.vread      v1, a0, s3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.movz       s1, #7
    s.addi       s3, s2, #7
    v.splat      v1, s3
    s.addi       s3, s4, #672                    // row 7
    @p3 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s7
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.movz       s7, #8
    s.addi       s8, s2, #8
    v.splat      v0, s8
    s.addi       s8, s4, #768                    // row 8
    @p4 v.st.h       [s6, #0], v2
    a.vread      v2, a0, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s5, #9
    s.addi       s6, s2, #9
    v.splat      v2, s6
    s.addi       s6, s4, #864                    // row 9
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.movz       s1, #10
    s.addi       s9, s2, #10
    v.splat      v1, s9
    s.addi       s9, s4, #960                    // row 10
    @p4 v.st.h       [s3, #0], v0
    a.vread      v0, a0, s7
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.movz       s3, #11
    s.addi       s7, s2, #11
    v.splat      v0, s7
    s.addi       s7, s4, #1056                   // row 11
    @p3 v.st.h       [s8, #0], v2
    a.vread      v2, a0, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s5, #12
    s.addi       s8, s2, #12
    v.splat      v2, s8
    s.addi       s8, s4, #1152                   // row 12
    @p4 v.st.h       [s6, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.movz       s1, #13
    s.addi       s6, s2, #13
    v.splat      v1, s6
    s.addi       s6, s4, #1248                   // row 13
    @p3 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.movz       s3, #14
    s.addi       s9, s2, #14
    s.addi       s10, s2, #15
    v.splat      v0, s9
    s.addi       s2, s4, #1344                   // row 14
    v.splat      v3, s10
    s.movz       s9, #15
    s.addi       s10, s4, #1440                  // row 15
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    @p3 v.st.h       [s8, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s2, #0], v1
    a.vread      v0, a0, s9
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s10, #0], v1
__rctx_next:
    exit
