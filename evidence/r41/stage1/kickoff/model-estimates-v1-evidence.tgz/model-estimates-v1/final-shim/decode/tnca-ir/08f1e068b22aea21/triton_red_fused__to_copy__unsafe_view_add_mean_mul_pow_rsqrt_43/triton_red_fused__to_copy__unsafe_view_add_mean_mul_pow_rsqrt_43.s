    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    v.iota       v0                              // arange(0, VLEN)
    s.rdspecial  s1, arg_base
    s.ld.d       s5, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s1, s5, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s6, #0
    s.st.d       [s1, #0], s2
    s.movz       s6, #2048
    s.st.d       [s1, #8], s6
    s.movz       s6, #2
    s.st.d       [s1, #48], s6
    s.movz       s6, #16
    s.st.d       [s1, #88], s6
    .li       s6, #1103806595072
    s.st.d       [s1, #104], s6
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s5, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 1)
    s.movz       s5, #0
    s.st.d       [s1, #0], s3
    s.movz       s5, #2048
    s.st.d       [s1, #8], s5
    s.movz       s5, #2
    s.st.d       [s1, #48], s5
    s.movz       s5, #16
    s.st.d       [s1, #88], s5
    .li       s5, #1103806595072
    s.st.d       [s1, #104], s5
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s5, #2048
    s.movz       s6, #16
    s.addi       s7, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s8, s7, s5
    br.nz        s8, endfor_2
    v.splat      v1, s7
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s7
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s8, #2048
    s.movz       s9, #2048
    s.muli       s10, s7, #2
    s.muli       s11, s7, #2
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s8
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s9
    v.cmp.ge     p1, v6, v1
    v.cmp.lt     p2, v6, v3
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    s.add        s8, s2, s10
    p.and        p5, p1, p2
    s.add        s9, s3, s11
    p.and        p1, p3, p4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v1, [s8, #0]
    v.splat      v3, s7
    v.movi       v4, #2048
    v.movi       v5, #0
    v.add        v6, v3, v0
    s.add        s8, s7, s6
    s.movz       s10, #1
    v.cmp.lt     p2, v6, v4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s9, #0]
    vf.cvt.bf16.f32 v4, v1
    vf.cvt.bf16.f32 v1, v3
    vf.add       v3, v4, v1
    vf.mul       v1, v3, v3
    vf.add       v3, v2, v1
    @p2 v.sel        v1, v3, v2
    v.mov        v5, v1
    v.mov        v2, v5
    s.mov        s7, s8
    br.nz        s10, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    s.addi       s7, s1, #0
    vf.add       v3, v1, v2
for_3:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_4
    .li       s1, #1157627904
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #897988541
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v1                          // ISA 8.8: <= 2**-22 relative
    v.splat      v6, s7
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v8, s7
    v.iota       v9                              // arange(0, VLEN)
    s.movz       s1, #2048
    s.movz       s8, #2048
    s.muli       s9, s7, #2
    s.muli       s10, s7, #2
    v.add        v10, v6, v7
    v.movi       v6, #0
    v.add        v7, v8, v9
    v.splat      v8, s1
    v.cmp.ge     p1, v10, v6
    v.movi       v6, #0
    v.cmp.lt     p2, v10, v8
    v.splat      v8, s8
    v.cmp.ge     p3, v7, v6
    v.splat      v6, s7
    v.cmp.lt     p4, v7, v8
    s.add        s1, s2, s9
    p.and        p5, p1, p2
    s.add        s8, s3, s10
    p.and        p1, p3, p4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v7, [s1, #0]
    v.add        v8, v6, v0
    v.movi       v6, #2048
    s.shli       s1, s7, #1                      // element offset -> bytes (x2)
    vf.fms       v9, v1, v5, v2
    .li       s9, #1077936128
    v.splat      v1, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s9, #3204448256
    v.splat      v2, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s9, s4, s1                      // &in_ptr1[...]
    v.cmp.lt     p2, v8, v6
    vf.fms       v6, v5, v9, v5
    .li       s10, #1065353216
    v.splat      v8, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s10, s2, s1                     // &in_out_ptr0[...]
    vf.neg       v9, v6                          // Newton step: r0*(2 - x*r0)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s8, #0]
    vf.cvt.bf16.f32 v10, v7
    s.add        s1, s7, s6
    s.movz       s8, #1
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v7, v9, v5
    vf.mul       v5, v3, v7                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v7, v5, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s9, #0]
    vf.cvt.bf16.f32 v5, v6
    v.rsqrt.approx v6, v7                        // ISA 8.8: <= 2**-22 relative
    vf.add       v9, v10, v5
    vf.cvt.bf16.f32 v5, v4
    vf.add       v4, v5, v8
    vf.mul       v5, v6, v6
    vf.mul       v8, v6, v2
    vf.fms       v2, v7, v5, v1
    vf.mul       v1, v8, v2                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v2, v1, v6
    v.extract    s9, v2, #0
    v.splat      v1, s9
    vf.mul       v2, v9, v1
    vf.mul       v1, v2, v4
    vf.cvt.f32.bf16 v2, v1
    @p2 v.st.h       [s10, #0], v2
    s.mov        s7, s1
    br.nz        s8, for_3
endfor_4:
    exit
    exit
