import concurrent.futures as cf
import hashlib,json,os,pathlib,subprocess,time,sys
H=pathlib.Path.home()
R=H/"r41-hbm8"
O=H/"r41-hbm8-final-27dfbf3"
O.mkdir(exist_ok=False)
os.chdir(R)
os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:5])
avail=int(next(l.split()[1] for l in pathlib.Path("/proc/meminfo").read_text().splitlines() if l.startswith("MemAvailable:")))
assert avail >= 40*1024*1024, avail
assert hashlib.sha256((R/"tools/performance_harness/hbm8_case.py").read_bytes()).hexdigest()=="0b8dd931239cbcde488763121d12b5c1c8f16cef21f7fa0256a5259e64271ad7"
env=dict(os.environ,MAX_JOBS="1",OMP_NUM_THREADS="1",MKL_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",TNCA_HOST_TIMEOUT="14400")
image=H/"r41-hbm8-rtl54"
tasks=[(c,"img54-b0",image,0) for c in ("window","negatives","clamp","samples","crossing","alias","bigoffset","dma","stream")]
tasks += [(c,"img54-b4g",image,1<<32) for c in ("samples","alias","crossing")]
tasks += [(c,"frozen-b0",R,0) for c in ("samples","crossing")]
sys.path.insert(0,str(R))
from archbench.provenance import software_tree
snapshot={"software_tree":software_tree(R,refresh=True),"affinity":sorted(os.sched_getaffinity(0)),"mem_available_kb":avail,"case_sha256":hashlib.sha256((R/"tools/performance_harness/hbm8_case.py").read_bytes()).hexdigest(),"rtl_sha256":{str(p.relative_to(image)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((image/"rtl").rglob("*")) if p.is_file()}}
(O/"snapshot.json").write_text(json.dumps(snapshot,indent=1))
def run(t):
 c,tag,rtl,base=t
 name=c+"-"+tag
 cmd=["/usr/bin/time","-v",str(H/"tc_env/torchenv/bin/python"),"tools/performance_harness/hbm8_case.py","--sim","--case",c,"--rtl-root",str(rtl),"--hbm-base",hex(base),"--out",str(O/name)]
 print("START",name,flush=True)
 with (O/(name+".log")).open("w") as f:
  rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 print("END",name,rc,flush=True)
 return {"case":name,"exit":rc,"argv":cmd}
with cf.ThreadPoolExecutor(max_workers=5) as ex:
 results=list(ex.map(run,tasks))
snapshot["software_tree_at_end"]=software_tree(R,refresh=True)
(O/"snapshot.json").write_text(json.dumps(snapshot,indent=1))
(O/"results.json").write_text(json.dumps(results,indent=1))
print("SIM-QUALIFY-DONE",flush=True)

