    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s8, [s1, #48]                   // out_ptr0: device_ptr64 at arg_base+48
    s.ld.d       s9, [s1, #56]                   // out_ptr2: device_ptr64 at arg_base+56
    s.ld.d       s10, [s1, #64]                  // out_ptr3: device_ptr64 at arg_base+64
    v.iota       v0                              // arange(0, VLEN)
    s.ld.d       s1, [s2, #0]                    // one element, not a vector
    v.movi       v1, #0
    v.movi       v2, #0
    v.insert     v1, s1, #0
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #0
    v.insert     v1, s1, #1
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #1
    v.insert     v1, s1, #2
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #2
    v.insert     v1, s1, #3
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #3
    v.insert     v1, s1, #4
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #4
    v.insert     v1, s1, #5
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #5
    v.insert     v1, s1, #6
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #6
    v.insert     v1, s1, #7
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #7
    v.insert     v1, s1, #8
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #8
    v.insert     v1, s1, #9
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #9
    v.insert     v1, s1, #10
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #10
    v.insert     v1, s1, #11
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #11
    v.insert     v1, s1, #12
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #12
    v.insert     v1, s1, #13
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #13
    v.insert     v1, s1, #14
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #14
    v.insert     v1, s1, #15
    s.lshri      s2, s1, #32
    v.insert     v2, s2, #15
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #80]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s1, s2, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s11, #0
    s.st.d       [s1, #0], s4
    s.movz       s11, #2560
    s.st.d       [s1, #8], s11
    s.movz       s11, #2
    s.st.d       [s1, #48], s11
    s.movz       s11, #16
    s.st.d       [s1, #88], s11
    .li       s11, #1103806595072
    s.st.d       [s1, #104], s11
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s2, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 1)
    s.movz       s11, #0
    s.st.d       [s1, #0], s5
    s.movz       s11, #2560
    s.st.d       [s1, #8], s11
    s.movz       s11, #2
    s.st.d       [s1, #48], s11
    s.movz       s11, #16
    s.st.d       [s1, #88], s11
    .li       s11, #1103806595072
    s.st.d       [s1, #104], s11
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s2, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 1)
    s.movz       s11, #0
    s.st.d       [s1, #0], s6
    s.movz       s11, #2560
    s.st.d       [s1, #8], s11
    s.movz       s11, #2
    s.st.d       [s1, #48], s11
    s.movz       s11, #16
    s.st.d       [s1, #88], s11
    .li       s11, #1103806595072
    s.st.d       [s1, #104], s11
    td.load      d2, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s11, #2560
    s.movz       s12, #16
    s.addi       s13, s1, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.mov        v4, v3
for_1:
    s.cmp.ge     s14, s13, s11
    br.nz        s14, endfor_2
    v.splat      v3, s13
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s13
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v8, s13
    v.iota       v9                              // arange(0, VLEN)
    s.movz       s14, #2560
    s.movz       s15, #2560
    s.movz       s16, #2560
    v.extract    s17, v2, #0
    s.muli       s18, s13, #2
    s.muli       s19, s13, #2
    v.add        v10, v3, v5
    v.movi       v3, #0
    v.splat      v5, s14
    s.muli       s14, s13, #2
    v.add        v11, v6, v7
    v.movi       v6, #0
    v.splat      v7, s15
    v.add        v12, v8, v9
    v.movi       v8, #0
    v.splat      v9, s16
    v.extract    s15, v1, #0
    s.shli       s16, s17, #32
    v.cmp.ge     p1, v10, v3
    s.or         s17, s15, s16
    v.cmp.lt     p2, v10, v5
    v.cmp.ge     p3, v11, v6
    v.cmp.lt     p4, v11, v7
    v.movi       v3, #0
    s.add        s15, s4, s18
    p.and        p5, p1, p2
    v.cmp.ge     p1, v12, v8
    s.add        s16, s5, s19
    p.and        p2, p3, p4
    v.cmp.lt     p3, v12, v9
    s.add        s18, s6, s14
    p.and        p4, p1, p3
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v5, [s15, #0]
    v.splat      v6, s13
    s.movz       s14, #0
    v.movi       v7, #2560
    v.add        v8, v6, v0
    s.cmp.ge     s15, s17, s14
    v.cmp.lt     p1, v8, v7
    v.extract    s14, v2, #1
    v.extract    s17, v1, #1
    s.shli       s19, s14, #32
    v.extract    s14, v2, #2
    s.or         s20, s17, s19
    s.movz       s17, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v6, [s16, #0]
    v.extract    s16, v1, #2
    s.shli       s19, s14, #32
    s.cmp.ge     s14, s20, s17
    s.or         s17, s16, s19
    s.movz       s16, #0
    vf.cvt.bf16.f32 v7, v5
    v.extract    s19, v2, #3
    s.cmp.ge     s20, s17, s16
    v.extract    s16, v1, #3
    s.shli       s17, s19, #32
    s.or         s19, s16, s17
    v.extract    s16, v2, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s18, #0]
    v.insert     v3, s15, #0
    s.movz       s15, #0
    v.extract    s17, v1, #4
    v.insert     v3, s14, #1
    s.shli       s14, s16, #32
    s.cmp.ge     s16, s19, s15
    v.insert     v3, s20, #2
    s.or         s15, s17, s14
    s.movz       s14, #0
    v.insert     v3, s16, #3
    vf.cvt.bf16.f32 v9, v6
    v.extract    s16, v2, #5
    v.extract    s17, v1, #5
    s.shli       s18, s16, #32
    s.cmp.ge     s16, s15, s14
    v.extract    s14, v2, #6
    s.or         s15, s17, s18
    s.movz       s17, #0
    v.insert     v3, s16, #4
    v.extract    s16, v1, #6
    s.shli       s18, s14, #32
    s.cmp.ge     s14, s15, s17
    s.or         s15, s16, s18
    v.insert     v3, s14, #5
    vf.cvt.bf16.f32 v6, v5
    v.extract    s14, v2, #7
    s.movz       s16, #0
    v.extract    s17, v1, #7
    s.shli       s18, s14, #32
    s.cmp.ge     s14, s15, s16
    v.extract    s15, v2, #8
    s.or         s16, s17, s18
    s.movz       s17, #0
    v.insert     v3, s14, #6
    v.extract    s14, v1, #8
    s.shli       s18, s15, #32
    s.cmp.ge     s15, s16, s17
    v.extract    s16, v2, #9
    s.or         s17, s14, s18
    s.movz       s14, #0
    v.insert     v3, s15, #7
    v.extract    s15, v1, #9
    s.shli       s18, s16, #32
    s.cmp.ge     s16, s17, s14
    v.extract    s14, v2, #10
    s.or         s17, s15, s18
    s.movz       s15, #0
    v.insert     v3, s16, #8
    v.extract    s16, v1, #10
    s.shli       s18, s14, #32
    s.cmp.ge     s14, s17, s15
    v.extract    s15, v2, #11
    s.or         s17, s16, s18
    s.movz       s16, #0
    v.insert     v3, s14, #9
    v.extract    s14, v1, #11
    s.shli       s18, s15, #32
    s.cmp.ge     s15, s17, s16
    v.extract    s16, v2, #12
    s.or         s17, s14, s18
    s.movz       s14, #0
    v.insert     v3, s15, #10
    v.extract    s15, v1, #12
    s.shli       s18, s16, #32
    s.cmp.ge     s16, s17, s14
    v.extract    s14, v2, #13
    s.or         s17, s15, s18
    s.movz       s15, #0
    v.insert     v3, s16, #11
    v.extract    s16, v1, #13
    s.shli       s18, s14, #32
    s.cmp.ge     s14, s17, s15
    v.extract    s15, v2, #14
    s.or         s17, s16, s18
    s.movz       s16, #0
    v.insert     v3, s14, #12
    v.extract    s14, v1, #14
    s.shli       s18, s15, #32
    s.cmp.ge     s15, s17, s16
    v.extract    s16, v2, #15
    v.extract    s17, v2, #0
    s.or         s19, s14, s18
    s.movz       s14, #0
    v.insert     v3, s15, #13
    v.extract    s15, v1, #15
    s.shli       s18, s16, #32
    v.extract    s16, v1, #0
    s.shli       s20, s17, #32
    s.cmp.ge     s17, s19, s14
    v.extract    s14, v2, #1
    s.or         s19, s15, s18
    s.movz       s15, #0
    s.or         s18, s16, s20
    .li       s16, #248320
    v.insert     v3, s17, #14
    v.movi       v5, #0
    v.extract    s17, v1, #1
    s.shli       s20, s14, #32
    s.cmp.ge     s14, s19, s15
    s.cmp.lt     s15, s18, s16
    v.extract    s16, v2, #2
    s.or         s18, s17, s20
    .li       s17, #248320
    v.insert     v3, s14, #15
    v.insert     v5, s15, #0
    v.extract    s14, v1, #2
    s.shli       s15, s16, #32
    s.cmp.lt     s16, s18, s17
    v.extract    s17, v2, #3
    s.or         s18, s14, s15
    .li       s14, #248320
    v.insert     v5, s16, #1
    v.extract    s15, v1, #3
    s.shli       s16, s17, #32
    s.cmp.lt     s17, s18, s14
    v.extract    s14, v2, #4
    s.or         s18, s15, s16
    .li       s15, #248320
    v.insert     v5, s17, #2
    v.extract    s16, v1, #4
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s18, s15
    v.extract    s15, v2, #5
    s.or         s18, s16, s17
    .li       s16, #248320
    v.insert     v5, s14, #3
    v.extract    s14, v1, #5
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s18, s16
    v.extract    s16, v2, #6
    s.or         s18, s14, s17
    .li       s14, #248320
    v.insert     v5, s15, #4
    v.extract    s15, v1, #6
    s.shli       s17, s16, #32
    s.cmp.lt     s16, s18, s14
    v.movi       v10, #0
    s.or         s14, s15, s17
    v.insert     v5, s16, #5
    v.cmp.ne     p2, v3, v10
    v.extract    s15, v2, #7
    .li       s16, #248320
    v.extract    s17, v1, #7
    s.shli       s18, s15, #32
    s.cmp.lt     s15, s14, s16
    v.extract    s14, v2, #8
    s.or         s16, s17, s18
    .li       s17, #248320
    v.insert     v5, s15, #6
    v.extract    s15, v1, #8
    s.shli       s18, s14, #32
    s.cmp.lt     s14, s16, s17
    v.extract    s16, v2, #9
    s.or         s17, s15, s18
    .li       s15, #248320
    v.insert     v5, s14, #7
    v.extract    s14, v1, #9
    s.shli       s18, s16, #32
    s.cmp.lt     s16, s17, s15
    v.extract    s15, v2, #10
    s.or         s17, s14, s18
    .li       s14, #248320
    v.insert     v5, s16, #8
    v.extract    s16, v1, #10
    s.shli       s18, s15, #32
    s.cmp.lt     s15, s17, s14
    v.extract    s14, v2, #11
    s.or         s17, s16, s18
    .li       s16, #248320
    v.insert     v5, s15, #9
    v.extract    s15, v1, #11
    s.shli       s18, s14, #32
    s.cmp.lt     s14, s17, s16
    v.extract    s16, v2, #12
    s.or         s17, s15, s18
    .li       s15, #248320
    v.insert     v5, s14, #10
    v.extract    s14, v1, #12
    s.shli       s18, s16, #32
    s.cmp.lt     s16, s17, s15
    v.extract    s15, v2, #13
    s.or         s17, s14, s18
    .li       s14, #248320
    v.insert     v5, s16, #11
    v.extract    s16, v1, #13
    s.shli       s18, s15, #32
    s.cmp.lt     s15, s17, s14
    v.extract    s14, v2, #14
    s.or         s17, s16, s18
    .li       s16, #248320
    v.insert     v5, s15, #12
    v.extract    s15, v1, #14
    s.shli       s18, s14, #32
    s.cmp.lt     s14, s17, s16
    v.extract    s16, v2, #15
    s.or         s17, s15, s18
    .li       s15, #248320
    v.insert     v5, s14, #13
    v.extract    s14, v1, #15
    s.shli       s18, s16, #32
    s.cmp.lt     s16, s17, s15
    s.or         s15, s14, s18
    .li       s14, #248320
    v.insert     v5, s16, #14
    s.cmp.lt     s16, s15, s14
    v.movi       v3, #0
    v.insert     v5, s16, #15
    v.movi       v10, #0
    v.movi       v11, #1
    v.cmp.ne     p3, v5, v3
    p.and        p4, p2, p3
    s.movz       s14, #0
    @p4 v.sel        v3, v10, v11
    v.reduce.or  s15, v3
    s.cmp.eq     s16, s15, s14
    br.nz        s16, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s14, v2, #0
    v.extract    s15, v1, #0
    s.shli       s16, s14, #32
    v.extract    s14, v2, #1
    s.or         s17, s15, s16
    s.movz       s15, #2560
    v.extract    s16, v1, #1
    s.shli       s18, s14, #32
    s.mul        s14, s17, s15
    v.extract    s15, v2, #2
    s.or         s17, s16, s18
    s.movz       s16, #2560
    v.extract    s18, v1, #2
    s.shli       s19, s15, #32
    s.mul        s15, s17, s16
    v.extract    s16, v2, #3
    v.movi       v3, #0
    v.movi       v5, #0
    s.or         s17, s18, s19
    s.movz       s18, #2560
    s.lshri      s19, s14, #32
    v.extract    s20, v1, #3
    s.shli       s21, s16, #32
    s.mul        s16, s17, s18
    v.extract    s17, v2, #4
    v.insert     v3, s14, #0
    v.insert     v5, s19, #0
    s.or         s14, s20, s21
    s.movz       s18, #2560
    s.lshri      s19, s15, #32
    v.extract    s20, v1, #4
    s.shli       s21, s17, #32
    s.mul        s17, s14, s18
    v.extract    s14, v2, #5
    v.insert     v3, s15, #1
    v.insert     v5, s19, #1
    s.or         s15, s20, s21
    s.movz       s18, #2560
    s.lshri      s19, s16, #32
    v.extract    s20, v1, #5
    s.shli       s21, s14, #32
    s.mul        s14, s15, s18
    v.extract    s15, v2, #6
    v.insert     v3, s16, #2
    v.insert     v5, s19, #2
    s.or         s16, s20, s21
    s.movz       s18, #2560
    s.lshri      s19, s17, #32
    v.extract    s20, v1, #6
    s.shli       s21, s15, #32
    s.mul        s15, s16, s18
    v.extract    s16, v2, #7
    v.insert     v3, s17, #3
    v.insert     v5, s19, #3
    s.or         s17, s20, s21
    s.movz       s18, #2560
    s.lshri      s19, s14, #32
    v.extract    s20, v1, #7
    s.shli       s21, s16, #32
    s.mul        s16, s17, s18
    v.extract    s17, v2, #8
    v.insert     v3, s14, #4
    v.insert     v5, s19, #4
    s.or         s14, s20, s21
    s.movz       s18, #2560
    s.lshri      s19, s15, #32
    v.extract    s20, v1, #8
    s.shli       s21, s17, #32
    s.mul        s17, s14, s18
    v.extract    s14, v2, #9
    v.insert     v3, s15, #5
    v.insert     v5, s19, #5
    s.or         s15, s20, s21
    s.movz       s18, #2560
    s.lshri      s19, s16, #32
    v.extract    s20, v1, #9
    s.shli       s21, s14, #32
    s.mul        s14, s15, s18
    v.extract    s15, v2, #10
    v.insert     v3, s16, #6
    v.insert     v5, s19, #6
    s.or         s16, s20, s21
    s.movz       s18, #2560
    s.lshri      s19, s17, #32
    v.extract    s20, v1, #10
    s.shli       s21, s15, #32
    s.mul        s15, s16, s18
    v.extract    s16, v2, #11
    v.insert     v3, s17, #7
    v.insert     v5, s19, #7
    s.or         s17, s20, s21
    s.movz       s18, #2560
    s.lshri      s19, s14, #32
    v.extract    s20, v1, #11
    s.shli       s21, s16, #32
    s.mul        s16, s17, s18
    v.extract    s17, v2, #12
    v.insert     v3, s14, #8
    v.insert     v5, s19, #8
    s.or         s14, s20, s21
    s.movz       s18, #2560
    s.lshri      s19, s15, #32
    v.extract    s20, v1, #12
    s.shli       s21, s17, #32
    s.mul        s17, s14, s18
    v.extract    s14, v2, #13
    v.insert     v3, s15, #9
    v.insert     v5, s19, #9
    s.or         s15, s20, s21
    s.movz       s18, #2560
    s.lshri      s19, s16, #32
    v.extract    s20, v1, #13
    s.shli       s21, s14, #32
    s.mul        s14, s15, s18
    v.extract    s15, v2, #14
    v.insert     v3, s16, #10
    v.insert     v5, s19, #10
    s.or         s16, s20, s21
    s.movz       s18, #2560
    s.lshri      s19, s17, #32
    v.extract    s20, v1, #14
    s.shli       s21, s15, #32
    s.mul        s15, s16, s18
    v.extract    s16, v2, #15
    v.insert     v3, s17, #11
    v.insert     v5, s19, #11
    s.or         s17, s20, s21
    s.movz       s18, #2560
    s.lshri      s19, s14, #32
    v.extract    s20, v1, #15
    s.shli       s21, s16, #32
    s.mul        s16, s17, s18
    v.insert     v3, s14, #12
    v.insert     v5, s19, #12
    s.or         s14, s20, s21
    s.movz       s17, #2560
    s.lshri      s18, s15, #32
    v.extract    s19, v8, #0
    s.mul        s20, s14, s17
    v.insert     v3, s15, #13
    v.insert     v5, s18, #13
    s.shli       s14, s19, #32
    s.lshri      s15, s16, #32
    v.extract    s17, v8, #1
    s.ashri      s18, s14, #32
    v.insert     v3, s16, #14
    v.insert     v5, s15, #14
    v.movi       v10, #0
    v.movi       v11, #0
    s.shli       s14, s17, #32
    s.lshri      s15, s20, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v8, #2
    s.ashri      s19, s14, #32
    v.insert     v3, s20, #15
    v.insert     v5, s15, #15
    v.insert     v10, s18, #0
    v.insert     v11, s16, #0
    s.shli       s14, s17, #32
    s.lshri      s15, s19, #32
    v.extract    s16, v8, #3
    s.ashri      s17, s14, #32
    v.insert     v10, s19, #1
    v.insert     v11, s15, #1
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v8, #4
    s.ashri      s18, s14, #32
    v.insert     v10, s17, #2
    v.insert     v11, s15, #2
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v8, #5
    s.ashri      s17, s14, #32
    v.insert     v10, s18, #3
    v.insert     v11, s15, #3
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v8, #6
    s.ashri      s18, s14, #32
    v.insert     v10, s17, #4
    v.insert     v11, s15, #4
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v8, #7
    s.ashri      s17, s14, #32
    v.insert     v10, s18, #5
    v.insert     v11, s15, #5
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v8, #8
    s.ashri      s18, s14, #32
    v.insert     v10, s17, #6
    v.insert     v11, s15, #6
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v8, #9
    s.ashri      s17, s14, #32
    v.insert     v10, s18, #7
    v.insert     v11, s15, #7
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v8, #10
    s.ashri      s18, s14, #32
    v.insert     v10, s17, #8
    v.insert     v11, s15, #8
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v8, #11
    s.ashri      s17, s14, #32
    v.insert     v10, s18, #9
    v.insert     v11, s15, #9
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v8, #12
    s.ashri      s18, s14, #32
    v.insert     v10, s17, #10
    v.insert     v11, s15, #10
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v8, #13
    s.ashri      s17, s14, #32
    v.insert     v10, s18, #11
    v.insert     v11, s15, #11
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v8, #14
    s.ashri      s18, s14, #32
    v.insert     v10, s17, #12
    v.insert     v11, s15, #12
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v8, #15
    s.ashri      s17, s14, #32
    v.insert     v10, s18, #13
    v.insert     v11, s15, #13
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    s.ashri      s16, s14, #32
    v.insert     v10, s17, #14
    v.insert     v11, s15, #14
    s.lshri      s14, s16, #32
    v.insert     v10, s16, #15
    v.insert     v11, s14, #15
    v.extract    s14, v5, #0
    v.extract    s15, v10, #0
    v.extract    s16, v11, #0
    v.extract    s17, v3, #0
    s.shli       s18, s16, #32
    s.shli       s16, s14, #32
    v.extract    s14, v11, #1
    v.extract    s19, v5, #1
    s.or         s20, s15, s18
    s.or         s15, s17, s16
    v.movi       v8, #0
    v.extract    s16, v10, #1
    s.shli       s17, s14, #32
    v.extract    s14, v3, #1
    s.shli       s18, s19, #32
    s.add        s19, s20, s15
    v.extract    s15, v11, #2
    v.extract    s20, v5, #2
    s.or         s21, s16, s17
    s.or         s16, s14, s18
    v.movi       v12, #0
    v.insert     v8, s19, #0
    v.extract    s14, v10, #2
    s.shli       s17, s15, #32
    v.extract    s15, v3, #2
    s.shli       s18, s20, #32
    s.lshri      s20, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v11, #3
    s.or         s21, s14, s17
    v.extract    s14, v5, #3
    s.or         s17, s15, s18
    v.insert     v12, s20, #0
    v.insert     v8, s19, #1
    v.extract    s15, v10, #3
    s.shli       s18, s16, #32
    v.extract    s16, v3, #3
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s17
    v.extract    s17, v11, #4
    s.or         s21, s15, s18
    v.extract    s15, v5, #4
    s.or         s18, s16, s20
    v.insert     v12, s14, #1
    v.insert     v8, s19, #2
    v.extract    s14, v10, #4
    s.shli       s16, s17, #32
    v.extract    s17, v3, #4
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s18
    v.extract    s18, v11, #5
    s.or         s21, s14, s16
    v.extract    s14, v5, #5
    s.or         s16, s17, s20
    v.insert     v12, s15, #2
    v.insert     v8, s19, #3
    v.extract    s15, v10, #5
    s.shli       s17, s18, #32
    v.extract    s18, v3, #5
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v11, #6
    s.or         s21, s15, s17
    v.extract    s15, v5, #6
    s.or         s17, s18, s20
    v.insert     v12, s14, #3
    v.insert     v8, s19, #4
    v.extract    s14, v10, #6
    s.shli       s18, s16, #32
    v.extract    s16, v3, #6
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s17
    v.extract    s17, v11, #7
    s.or         s21, s14, s18
    v.extract    s14, v5, #7
    s.or         s18, s16, s20
    v.insert     v12, s15, #4
    v.insert     v8, s19, #5
    v.extract    s15, v10, #7
    s.shli       s16, s17, #32
    v.extract    s17, v3, #7
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s18
    v.extract    s18, v11, #8
    s.or         s21, s15, s16
    v.extract    s15, v5, #8
    s.or         s16, s17, s20
    v.insert     v12, s14, #5
    v.insert     v8, s19, #6
    v.extract    s14, v10, #8
    s.shli       s17, s18, #32
    v.extract    s18, v3, #8
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v11, #9
    s.or         s21, s14, s17
    v.extract    s14, v5, #9
    s.or         s17, s18, s20
    v.insert     v12, s15, #6
    v.insert     v8, s19, #7
    v.extract    s15, v10, #9
    s.shli       s18, s16, #32
    v.extract    s16, v3, #9
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s17
    v.extract    s17, v11, #10
    s.or         s21, s15, s18
    v.extract    s15, v5, #10
    s.or         s18, s16, s20
    v.insert     v12, s14, #7
    v.insert     v8, s19, #8
    v.extract    s14, v10, #10
    s.shli       s16, s17, #32
    v.extract    s17, v3, #10
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s18
    v.extract    s18, v11, #11
    s.or         s21, s14, s16
    v.extract    s14, v5, #11
    s.or         s16, s17, s20
    v.insert     v12, s15, #8
    v.insert     v8, s19, #9
    v.extract    s15, v10, #11
    s.shli       s17, s18, #32
    v.extract    s18, v3, #11
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v11, #12
    s.or         s21, s15, s17
    v.extract    s15, v5, #12
    s.or         s17, s18, s20
    v.insert     v12, s14, #9
    v.insert     v8, s19, #10
    v.extract    s14, v10, #12
    s.shli       s18, s16, #32
    v.extract    s16, v3, #12
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s17
    v.extract    s17, v11, #13
    s.or         s21, s14, s18
    v.extract    s14, v5, #13
    s.or         s18, s16, s20
    v.insert     v12, s15, #10
    v.insert     v8, s19, #11
    v.extract    s15, v10, #13
    s.shli       s16, s17, #32
    v.extract    s17, v3, #13
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s18
    v.extract    s18, v11, #14
    s.or         s21, s15, s16
    v.extract    s15, v5, #14
    s.or         s16, s17, s20
    v.insert     v12, s14, #11
    v.insert     v8, s19, #12
    v.extract    s14, v10, #14
    s.shli       s17, s18, #32
    v.extract    s18, v3, #14
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v11, #15
    s.or         s21, s14, s17
    v.extract    s14, v5, #15
    s.or         s17, s18, s20
    v.insert     v12, s15, #12
    v.insert     v8, s19, #13
    v.extract    s15, v10, #15
    s.shli       s18, s16, #32
    v.extract    s16, v3, #15
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s17
    s.or         s17, s15, s18
    s.or         s15, s16, s20
    v.insert     v12, s14, #13
    v.insert     v8, s19, #14
    s.lshri      s14, s19, #32
    s.add        s16, s17, s15
    v.insert     v12, s14, #14
    v.insert     v8, s16, #15
    v.movi       v3, #31
    s.lshri      s14, s16, #32
    v.movi       v5, #1
    v.insert     v12, s14, #15
    v.ashr       v10, v8, v3
    v.movi       v3, #0
    s.movz       s14, #0
    v.cmp.ne     p2, v12, v10
    @p2 v.sel        v10, v5, v3
    v.reduce.or  s15, v10
    s.cmp.eq     s16, s15, s14
    br.nz        s16, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s3, v8]               // index is in elements (ISA sec 9.1)
    s.shli       s14, s13, #1                    // element offset -> bytes (x2)
    v.movi       v5, #0
    s.add        s15, s8, s14                    // &out_ptr0[...]
    s.add        s14, s13, s12
    s.movz       s16, #1
    vf.cvt.bf16.f32 v8, v3
    vf.add       v3, v8, v7
    vf.add       v7, v3, v9
    vf.add       v3, v7, v6
    vf.mul       v6, v3, v3
    vf.cvt.f32.bf16 v7, v3
    vf.add       v3, v4, v6
    @p1 v.st.h       [s15, #0], v7
    @p1 v.sel        v6, v3, v4
    v.mov        v5, v6
    v.mov        v4, v5
    s.mov        s13, s14
    br.nz        s16, for_1
endfor_2:
    vf.reduce.add.b v1, v4
    v.movi       v2, #0
    vf.add       v3, v1, v2
    s.addi       s3, s2, #768                    // TensorMap 3: tl.make_tensor_descriptor (rank 1)
    s.movz       s2, #0
    s.st.d       [s3, #0], s8
    s.movz       s2, #2560
    s.st.d       [s3, #8], s2
    s.movz       s2, #2
    s.st.d       [s3, #48], s2
    s.movz       s2, #16
    s.st.d       [s3, #88], s2
    .li       s2, #1103806595072
    s.st.d       [s3, #104], s2
    td.load      d3, [s3]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s2, s1, #0
for_5:
    s.cmp.ge     s1, s2, s11
    br.nz        s1, endfor_6
    .li       s1, #1159725056
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #897988541
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v1                          // ISA 8.8: <= 2**-22 relative
    v.splat      v6, s2
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s1, #2560
    v.splat      v8, s2
    s.muli       s3, s2, #2
    v.add        v9, v6, v7
    v.movi       v6, #0
    v.splat      v7, s1
    v.add        v10, v8, v0
    v.movi       v8, #2560
    s.shli       s1, s2, #1                      // element offset -> bytes (x2)
    v.cmp.ge     p1, v9, v6
    v.cmp.lt     p2, v9, v7
    .li       s4, #1077936128
    v.splat      v6, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #3204448256
    v.splat      v7, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s4, s8, s3
    p.and        p3, p1, p2
    s.add        s3, s7, s1                      // &in_ptr5[...]
    v.cmp.lt     p1, v10, v8
    fence.acq_rel.device
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v8, [s4, #0]
    .li       s4, #1065353216
    v.splat      v9, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s4, s9, s1                      // &out_ptr2[...]
    s.add        s5, s10, s1                     // &out_ptr3[...]
    s.add        s1, s2, s12
    s.movz       s6, #1
    vf.fms       v10, v1, v5, v2
    vf.fms       v2, v5, v10, v5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v10, [s3, #0]
    vf.cvt.bf16.f32 v11, v8
    fence.acq_rel.device
    vf.neg       v8, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v2, v8, v5
    vf.mul       v5, v3, v2                      // a/y: faithful quotient
    vf.cvt.bf16.f32 v8, v10
    vf.fms       v10, v5, v1, v3
    vf.add       v1, v8, v9
    vf.fms       v8, v10, v2, v5
    vf.neg       v2, v8                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v8, v2, v5
    vf.add       v2, v8, v4
    v.rsqrt.approx v4, v2                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v4, v4
    vf.mul       v8, v4, v7
    vf.fms       v7, v2, v5, v6
    vf.mul       v2, v8, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v5, v2, v4
    v.extract    s3, v5, #0
    v.splat      v2, s3
    vf.mul       v4, v11, v2
    vf.mul       v2, v4, v1
    vf.cvt.f32.bf16 v1, v2
    @p1 v.st.h       [s4, #0], v1
    @p1 v.st.h       [s5, #0], v1
    s.mov        s2, s1
    br.nz        s6, for_5
endfor_6:
    exit
    exit
