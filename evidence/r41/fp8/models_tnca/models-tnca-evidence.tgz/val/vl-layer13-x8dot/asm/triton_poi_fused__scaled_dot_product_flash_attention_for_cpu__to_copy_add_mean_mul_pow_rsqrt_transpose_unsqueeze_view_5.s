    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, pid.y
    s.movz       s2, #16
    s.rdspecial  s3, role_id
    s.mul        s5, s1, s2
    s.movz       s1, #17408
    s.movz       s6, #0
    s.rdspecial  s7, arg_base
    s.mul        s8, s3, s1
    s.add        s1, s6, s5                      // the tile origin
    s.movz       s3, #81
    s.ld.d       s6, [s7, #112]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v0, s1
    v.splat      v1, s3
    v.movi       v2, #0
    s.rdspecial  s3, arg_base
    s.add        s7, s6, s8                      // this context's own scratch
    v.sub        v3, v2, v0
    v.sub        v4, v2, v1
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    s.ld.d       s6, [s3, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.addi       s8, s7, #0
    v.iota       v5                              // arange(0, VLEN)
    s.ld.d       s9, [s3, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.mul        s10, s4, s2
    v.movi       v5, #1
    s.ld.d       s4, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    @p1 v.sel        v6, v3, v0
    @p2 v.sel        v0, v4, v1
    s.ld.d       s11, [s3, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    v.movi       v3, #0
    v.movi       v4, #0
    s.ld.d       s12, [s3, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.movz       s13, #31
    s.ld.d       s14, [s3, #40]                  // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s15, [s3, #48]                  // in_ptr6: device_ptr64 at arg_base+48
    s.ld.d       s16, [s3, #56]                  // in_ptr7: device_ptr64 at arg_base+56
    s.ld.d       s17, [s3, #64]                  // in_ptr8: device_ptr64 at arg_base+64
    s.ld.d       s18, [s3, #72]                  // in_ptr9: device_ptr64 at arg_base+72
    s.ld.d       s19, [s3, #80]                  // out_ptr0: device_ptr64 at arg_base+80
    s.ld.d       s20, [s3, #88]                  // out_ptr1: device_ptr64 at arg_base+88
idiv_1:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v2
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s3, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v2
    @p4 v.sel        v9, v8, v7
    v.or         v7, v3, v10
    v.mov        v4, v9
    v.mov        v3, v7
    s.mov        s13, s3
    s.movz       s3, #0
    s.cmp.ge     s21, s13, s3
    br.nz        s21, idiv_1
    s.addi       s3, s1, #1
    v.sub        v0, v2, v4
    v.splat      v2, s3
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s8, #0], v5
    s.addi       s3, s8, #64
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_2:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_2
    s.addi       s13, s1, #2
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #128
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_3:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_3
    s.addi       s13, s1, #3
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #192
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_4:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_4
    s.addi       s13, s1, #4
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #256
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_5:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_5
    s.addi       s13, s1, #5
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #320
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_6:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_6
    s.addi       s13, s1, #6
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #384
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_7:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_7
    s.addi       s13, s1, #7
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #448
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_8:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_8
    s.addi       s13, s1, #8
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #512
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_9:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_9
    s.addi       s13, s1, #9
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #576
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_10:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_10
    s.addi       s13, s1, #10
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #640
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_11:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_11
    s.addi       s13, s1, #11
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #704
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_12:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_12
    s.addi       s13, s1, #12
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #768
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_13:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_13
    s.addi       s13, s1, #13
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #832
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_14:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_14
    s.addi       s13, s1, #14
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #896
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s13, #31
idiv_15:
    v.splat      v7, s13
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_15
    s.addi       s13, s1, #15
    v.sub        v0, v3, v4
    v.splat      v2, s13
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    s.addi       s3, s8, #960
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s8, #31
idiv_16:
    v.splat      v7, s8
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p2, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s13, s8, #1
    v.cmp.geu    p3, v7, v0
    p.or         p4, p2, p3
    v.sub        v8, v7, v0
    @p4 v.sel        v10, v9, v3
    @p4 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s8, s13
    s.movz       s13, #0
    s.cmp.ge     s21, s8, s13
    br.nz        s21, idiv_16
    v.sub        v0, v3, v4
    v.splat      v2, s1
    v.movi       v3, #0
    @p1 v.sel        v5, v0, v4
    v.sub        v0, v3, v2
    v.sub        v4, v3, v1
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v1, v3
    v.st.w       [s3, #0], v5
    fence.acq_rel.device
    s.addi       s3, s7, #1024
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v2
    @p2 v.sel        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    s.movz       s8, #31
idiv_17:
    v.splat      v7, s8
    v.shl        v8, v4, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v4, v3
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s13, s8, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v3
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v4, v9
    v.mov        v2, v7
    s.mov        s8, s13
    s.movz       s13, #0
    s.cmp.ge     s21, s8, s13
    br.nz        s21, idiv_17
    s.addi       s8, s1, #1
    p.xor        p3, p1, p2
    v.sub        v0, v3, v2
    v.splat      v3, s8
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s3, #0], v5
    s.addi       s8, s3, #64
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_18:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_18
    s.addi       s13, s1, #2
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #128
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_19:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_19
    s.addi       s13, s1, #3
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #192
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_20:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_20
    s.addi       s13, s1, #4
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #256
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_21:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_21
    s.addi       s13, s1, #5
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #320
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_22:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_22
    s.addi       s13, s1, #6
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #384
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_23:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_23
    s.addi       s13, s1, #7
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #448
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_24:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_24
    s.addi       s13, s1, #8
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #512
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_25:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_25
    s.addi       s13, s1, #9
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #576
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_26:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_26
    s.addi       s13, s1, #10
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #640
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_27:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_27
    s.addi       s13, s1, #11
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #704
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_28:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_28
    s.addi       s13, s1, #12
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #768
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_29:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_29
    s.addi       s13, s1, #13
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #832
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_30:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_30
    s.addi       s13, s1, #14
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #896
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v2, #0
    v.movi       v3, #0
    s.movz       s13, #31
idiv_31:
    v.splat      v7, s13
    v.shl        v8, v3, v5
    v.lshr       v9, v6, v7
    v.cmp.lt     p3, v3, v4
    v.and        v10, v9, v5
    v.shl        v9, v5, v7
    v.or         v7, v8, v10
    s.subi       s21, s13, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p3, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v4
    @p5 v.sel        v9, v8, v7
    v.or         v7, v2, v10
    v.mov        v3, v9
    v.mov        v2, v7
    s.mov        s13, s21
    s.movz       s21, #0
    s.cmp.ge     s22, s13, s21
    br.nz        s22, idiv_31
    s.addi       s13, s1, #15
    p.xor        p3, p1, p2
    v.sub        v0, v4, v2
    v.splat      v3, s13
    v.movi       v4, #0
    @p3 v.sel        v5, v0, v2
    v.sub        v0, v4, v3
    v.sub        v2, v4, v1
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v1, v4
    v.st.w       [s8, #0], v5
    s.addi       s8, s3, #960
    v.movi       v5, #1
    @p1 v.sel        v6, v0, v3
    @p2 v.sel        v0, v2, v1
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s3, #31
idiv_32:
    v.splat      v3, s3
    v.shl        v7, v2, v5
    v.lshr       v8, v6, v3
    v.cmp.lt     p3, v2, v4
    v.and        v9, v8, v5
    v.shl        v8, v5, v3
    v.or         v3, v7, v9
    s.subi       s13, s3, #1
    v.cmp.geu    p4, v3, v0
    p.or         p5, p3, p4
    v.sub        v7, v3, v0
    @p5 v.sel        v9, v8, v4
    @p5 v.sel        v8, v7, v3
    v.or         v3, v1, v9
    v.mov        v2, v8
    v.mov        v1, v3
    s.mov        s3, s13
    s.movz       s13, #0
    s.cmp.ge     s21, s3, s13
    br.nz        s21, idiv_32
    p.xor        p3, p1, p2
    v.sub        v0, v4, v1
    s.addi       s3, s7, #1024
    @p3 v.sel        v2, v0, v1
    s.addi       s13, s7, #0
    v.st.w       [s8, #0], v2
    fence.acq_rel.device
    s.movz       s8, #0
    s.movz       s21, #128
    s.add        s22, s8, s10                    // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s22
    v.splat      v2, s21
    s.movz       s8, #2048
    v.add        v3, v0, v1
    v.ld.w       v0, [s3, #0]
    v.splat      v1, s8
    s.movz       s3, #0
    // a masked 1x16 tile with contiguous rows: one predicated load a row
    s.addi       s8, s7, #2048
    v.splat      v4, s3
    s.addi       s22, s7, #1088
    s.addi       s23, s7, #64
    s.addi       s24, s8, #64
    s.addi       s25, s7, #1152
    s.addi       s26, s7, #128
    v.ld.w       v5, [s13, #0]
    v.mul        v6, v0, v2
    s.addi       s13, s8, #128
    v.add        v0, v3, v6
    v.mul        v6, v5, v1
    v.add        v5, v0, v6
    v.add        v0, v4, v5
    v.st.w       [s8, #0], v0
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s7, #1216
    v.ld.w       v5, [s23, #0]
    v.mul        v6, v0, v2
    s.addi       s23, s8, #192
    v.add        v0, v3, v6
    v.mul        v6, v5, v1
    v.add        v5, v0, v6
    v.add        v0, v4, v5
    v.st.w       [s24, #0], v0
    s.muli       s24, s10, #2                    // a runtime tile origin, x2
    s.add        s27, s6, s24                    // the tile origin
    s.addi       s6, s7, #192
    v.ld.w       v0, [s25, #0]
    s.addi       s24, s7, #1280
    v.ld.w       v5, [s26, #0]
    v.mul        v6, v0, v2
    s.addi       s25, s7, #256
    v.add        v0, v3, v6
    v.mul        v6, v5, v1
    v.add        v5, v0, v6
    v.add        v0, v4, v5
    v.st.w       [s13, #0], v0
    s.addi       s13, s8, #256
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s7, #1344
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v0, v2
    s.addi       s6, s7, #320
    v.add        v0, v3, v6
    v.mul        v6, v5, v1
    v.add        v5, v0, v6
    v.add        v0, v4, v5
    v.st.w       [s23, #0], v0
    s.addi       s23, s8, #320
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s7, #1408
    v.ld.w       v5, [s25, #0]
    v.mul        v6, v0, v2
    s.addi       s25, s7, #384
    v.add        v0, v3, v6
    v.mul        v6, v5, v1
    v.add        v5, v0, v6
    v.add        v0, v4, v5
    v.st.w       [s13, #0], v0
    s.addi       s13, s8, #384
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s7, #1472
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v0, v2
    s.addi       s6, s7, #448
    v.add        v0, v3, v6
    v.mul        v6, v5, v1
    v.add        v5, v0, v6
    v.add        v0, v4, v5
    v.st.w       [s23, #0], v0
    s.addi       s23, s8, #448
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s7, #1536
    v.ld.w       v5, [s25, #0]
    v.mul        v6, v0, v2
    s.addi       s25, s7, #512
    v.add        v0, v3, v6
    v.mul        v6, v5, v1
    v.add        v5, v0, v6
    v.add        v0, v4, v5
    v.st.w       [s13, #0], v0
    s.addi       s13, s8, #512
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s7, #1600
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v0, v2
    s.addi       s6, s7, #576
    v.add        v0, v3, v6
    v.mul        v6, v5, v1
    v.add        v5, v0, v6
    v.add        v0, v4, v5
    v.st.w       [s23, #0], v0
    s.addi       s23, s8, #576
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s7, #1664
    v.ld.w       v5, [s25, #0]
    v.mul        v6, v0, v2
    s.addi       s25, s7, #640
    v.add        v0, v3, v6
    v.mul        v6, v5, v1
    v.add        v5, v0, v6
    v.add        v0, v4, v5
    v.st.w       [s13, #0], v0
    s.addi       s13, s8, #640
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s7, #1728
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v0, v2
    s.addi       s6, s7, #704
    v.add        v0, v3, v6
    v.mul        v6, v5, v1
    v.add        v5, v0, v6
    v.add        v0, v4, v5
    v.st.w       [s23, #0], v0
    s.addi       s23, s8, #704
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s7, #1792
    v.ld.w       v5, [s25, #0]
    v.mul        v6, v0, v2
    s.addi       s25, s7, #768
    v.add        v0, v3, v6
    v.mul        v6, v5, v1
    v.add        v5, v0, v6
    v.add        v0, v4, v5
    v.st.w       [s13, #0], v0
    s.addi       s13, s8, #768
    v.ld.w       v0, [s22, #0]
    s.addi       s22, s7, #1856
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v0, v2
    s.addi       s6, s7, #832
    v.add        v0, v3, v6
    v.mul        v6, v5, v1
    v.add        v5, v0, v6
    v.add        v0, v4, v5
    v.st.w       [s23, #0], v0
    s.addi       s23, s8, #832
    v.splat      v0, s21
    s.addi       s21, s7, #1920
    v.cmp.lt     p1, v3, v0
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s7, #896
    v.splat      v5, s1
    v.ld.w       v6, [s25, #0]
    v.mul        v7, v0, v2
    s.addi       s25, s8, #896
    v.add        v0, v3, v7
    s.addi       s26, s8, #960
    v.mul        v7, v6, v1
    v.add        v6, v0, v7
    v.add        v0, v4, v6
    v.st.w       [s13, #0], v0
    s.addi       s8, s7, #1984
    v.ld.w       v0, [s22, #0]
    s.addi       s13, s7, #960
    v.ld.w       v6, [s6, #0]
    v.mul        v7, v0, v2
    s.addi       s6, s7, #2048
    v.add        v0, v3, v7
    v.mul        v7, v6, v1
    v.add        v6, v0, v7
    v.add        v0, v4, v6
    v.st.w       [s23, #0], v0
    s.movz       s22, #1296
    v.splat      v0, s22
    s.addi       s22, s7, #3072
    v.cmp.lt     p2, v5, v0
    p.and        p3, p1, p2
    v.ld.w       v5, [s21, #0]
    s.addi       s21, s7, #2112
    v.ld.w       v6, [s24, #0]
    v.mul        v7, v5, v2
    s.addi       s23, s1, #1
    v.add        v5, v3, v7
    v.splat      v7, s23
    s.addi       s23, s22, #64
    v.cmp.lt     p2, v7, v0
    p.and        p4, p1, p2
    v.mul        v7, v6, v1
    v.add        v6, v5, v7
    v.add        v5, v4, v6
    v.st.w       [s25, #0], v5
    s.addi       s24, s7, #2176
    v.ld.w       v5, [s8, #0]
    s.addi       s8, s1, #2
    v.splat      v6, s8
    s.addi       s8, s22, #128
    v.cmp.lt     p2, v6, v0
    p.and        p5, p1, p2
    v.ld.w       v6, [s13, #0]
    v.mul        v7, v5, v2
    s.addi       s13, s7, #2240
    v.add        v5, v3, v7
    v.mul        v7, v6, v1
    v.add        v1, v5, v7
    v.add        v5, v4, v1
    v.st.w       [s26, #0], v5
    fence.acq_rel.device
    s.addi       s25, s1, #3
    v.splat      v1, s25
    s.addi       s25, s22, #192
    v.ld.w       v4, [s6, #0]
    s.addi       s6, s7, #2304
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s9, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v0
    p.and        p3, p1, p2
    v.st.w       [s22, #0], v5
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s1, #4
    v.splat      v4, s21
    s.addi       s21, s22, #256
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s9, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p4, p1, p2
    v.st.w       [s23, #0], v5
    s.addi       s23, s7, #2368
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s1, #5
    v.splat      v4, s24
    s.addi       s24, s22, #320
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s9, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    v.st.w       [s8, #0], v5
    s.addi       s8, s7, #2432
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s1, #6
    v.splat      v4, s13
    s.addi       s13, s22, #384
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s9, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    v.st.w       [s25, #0], v5
    s.addi       s25, s7, #2496
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s1, #7
    v.splat      v4, s6
    s.addi       s6, s22, #448
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s9, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p4, p1, p2
    v.st.w       [s21, #0], v5
    s.addi       s21, s7, #2560
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s1, #8
    v.splat      v4, s23
    s.addi       s23, s22, #512
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s9, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    v.st.w       [s24, #0], v5
    s.addi       s24, s7, #2624
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s1, #9
    v.splat      v4, s8
    s.addi       s8, s22, #576
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s9, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    v.st.w       [s13, #0], v5
    s.addi       s13, s7, #2688
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s1, #10
    v.splat      v4, s25
    s.addi       s25, s22, #640
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s9, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p4, p1, p2
    v.st.w       [s6, #0], v5
    s.addi       s6, s7, #2752
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s1, #11
    v.splat      v4, s21
    s.addi       s21, s22, #704
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s9, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    v.st.w       [s23, #0], v5
    s.addi       s23, s7, #2816
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s1, #12
    v.splat      v4, s24
    s.addi       s24, s22, #768
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s9, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    v.st.w       [s8, #0], v5
    s.addi       s8, s7, #2880
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s1, #13
    v.splat      v4, s13
    s.addi       s13, s22, #832
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s9, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p4, p1, p2
    v.st.w       [s25, #0], v5
    s.addi       s25, s7, #2944
    v.splat      v1, s3
    v.ld.w       v4, [s6, #0]
    s.addi       s6, s1, #14
    v.splat      v5, s2
    v.splat      v6, s6
    s.addi       s2, s22, #896
    s.addi       s6, s7, #3008
    s.addi       s26, s22, #960
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v7, [s9, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v0
    p.and        p5, p1, p2
    v.st.w       [s21, #0], v7
    s.addi       s21, s1, #15
    v.splat      v4, s21
    s.addi       s21, s7, #0
    v.ld.w       v6, [s23, #0]
    s.addi       s22, s7, #1024
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v7, [s9, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    v.st.w       [s24, #0], v7
    s.addi       s23, s7, #4096
    v.ld.w       v4, [s8, #0]
    s.addi       s8, s7, #64
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s9, v4]               // index is in elements (ISA sec 9.1)
    v.st.w       [s13, #0], v6
    s.addi       s13, s7, #1088
    v.ld.w       v4, [s25, #0]
    s.addi       s24, s23, #64
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s9, v4]               // index is in elements (ISA sec 9.1)
    v.st.w       [s2, #0], v6
    s.addi       s2, s7, #128
    v.ld.w       v4, [s6, #0]
    s.addi       s6, s7, #1152
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s9, v4]               // index is in elements (ISA sec 9.1)
    s.addi       s9, s23, #128
    v.st.w       [s26, #0], v6
    fence.acq_rel.device
    s.addi       s25, s7, #192
    v.ld.w       v4, [s21, #0]
    s.addi       s21, s7, #1216
    v.ld.w       v6, [s22, #0]
    v.mul        v7, v4, v5
    s.addi       s22, s23, #192
    v.add        v4, v6, v7
    v.add        v6, v1, v4
    v.st.w       [s23, #0], v6
    v.ld.w       v4, [s8, #0]
    s.addi       s8, s7, #256
    v.ld.w       v6, [s13, #0]
    v.mul        v7, v4, v5
    s.addi       s13, s7, #1280
    v.add        v4, v6, v7
    v.add        v6, v1, v4
    v.st.w       [s24, #0], v6
    s.addi       s24, s23, #256
    v.ld.w       v4, [s2, #0]
    s.addi       s2, s7, #320
    v.ld.w       v6, [s6, #0]
    v.mul        v7, v4, v5
    s.addi       s6, s7, #1344
    v.add        v4, v6, v7
    v.add        v6, v1, v4
    v.st.w       [s9, #0], v6
    s.addi       s9, s23, #320
    v.ld.w       v4, [s25, #0]
    s.addi       s25, s7, #384
    v.ld.w       v6, [s21, #0]
    v.mul        v7, v4, v5
    s.addi       s21, s7, #1408
    v.add        v4, v6, v7
    v.add        v6, v1, v4
    v.st.w       [s22, #0], v6
    s.addi       s22, s23, #384
    v.ld.w       v4, [s8, #0]
    s.addi       s8, s7, #448
    v.ld.w       v6, [s13, #0]
    v.mul        v7, v4, v5
    s.addi       s13, s7, #1472
    v.add        v4, v6, v7
    v.add        v6, v1, v4
    v.st.w       [s24, #0], v6
    s.addi       s24, s23, #448
    v.ld.w       v4, [s2, #0]
    s.addi       s2, s7, #512
    v.ld.w       v6, [s6, #0]
    v.mul        v7, v4, v5
    s.addi       s6, s7, #1536
    v.add        v4, v6, v7
    v.add        v6, v1, v4
    v.st.w       [s9, #0], v6
    s.addi       s9, s23, #512
    v.ld.w       v4, [s25, #0]
    s.addi       s25, s7, #576
    v.ld.w       v6, [s21, #0]
    v.mul        v7, v4, v5
    s.addi       s21, s7, #1600
    v.add        v4, v6, v7
    v.add        v6, v1, v4
    v.st.w       [s22, #0], v6
    s.addi       s22, s23, #576
    v.ld.w       v4, [s8, #0]
    s.addi       s8, s7, #640
    v.ld.w       v6, [s13, #0]
    v.mul        v7, v4, v5
    s.addi       s13, s7, #1664
    v.add        v4, v6, v7
    v.add        v6, v1, v4
    v.st.w       [s24, #0], v6
    s.addi       s24, s23, #640
    v.ld.w       v4, [s2, #0]
    s.addi       s2, s7, #704
    v.ld.w       v6, [s6, #0]
    v.mul        v7, v4, v5
    s.addi       s6, s7, #1728
    v.add        v4, v6, v7
    v.add        v6, v1, v4
    v.st.w       [s9, #0], v6
    s.addi       s9, s23, #704
    v.ld.w       v4, [s25, #0]
    s.addi       s25, s7, #768
    v.ld.w       v6, [s21, #0]
    v.mul        v7, v4, v5
    s.addi       s21, s7, #1792
    v.add        v4, v6, v7
    v.add        v6, v1, v4
    v.st.w       [s22, #0], v6
    s.addi       s22, s23, #768
    v.ld.w       v4, [s8, #0]
    s.addi       s8, s7, #832
    v.ld.w       v6, [s13, #0]
    v.mul        v7, v4, v5
    s.addi       s13, s7, #1856
    v.add        v4, v6, v7
    v.add        v6, v1, v4
    v.st.w       [s24, #0], v6
    s.addi       s24, s23, #832
    v.splat      v4, s1
    v.ld.w       v6, [s2, #0]
    s.addi       s2, s7, #896
    v.ld.w       v7, [s6, #0]
    v.mul        v8, v6, v5
    s.addi       s6, s7, #1920
    v.iota       v6                              // arange(0, VLEN)
    v.cmp.lt     p2, v4, v0
    v.add        v4, v7, v8
    v.add        v7, v1, v4
    v.st.w       [s9, #0], v7
    s.addi       s9, s23, #896
    s.addi       s26, s23, #960
    v.ld.w       v4, [s25, #0]
    s.addi       s23, s7, #960
    v.ld.w       v7, [s21, #0]
    v.mul        v8, v4, v5
    s.addi       s21, s7, #1984
    v.add        v4, v7, v8
    v.add        v7, v1, v4
    v.iota       v4                              // arange(0, VLEN)
    v.st.w       [s22, #0], v7
    s.addi       s22, s7, #4096
    v.ld.w       v7, [s8, #0]
    s.movz       s8, #1
    v.splat      v8, s8
    // a computed 16x1 tile, into an accumulator (ISA sec 9B)
    s.movz       s8, #0
    v.cmp.lt     p3, v6, v8
    p.and        p4, p3, p2
    v.ld.w       v6, [s13, #0]
    v.mul        v8, v7, v5
    s.addi       s13, s7, #4160
    v.add        v7, v6, v8
    v.add        v6, v1, v7
    v.st.w       [s24, #0], v6
    s.addi       s24, s1, #1
    v.splat      v6, s24
    s.movz       s24, #1
    v.cmp.lt     p2, v6, v0
    v.splat      v6, s24
    s.movz       s24, #1
    v.cmp.lt     p3, v4, v6
    p.and        p5, p3, p2
    v.ld.w       v4, [s2, #0]
    s.addi       s2, s7, #4224
    v.ld.w       v6, [s6, #0]
    v.mul        v7, v4, v5
    s.addi       s6, s1, #2
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v8, s6
    s.movz       s6, #1
    v.cmp.lt     p2, v8, v0
    v.splat      v8, s6
    s.movz       s6, #2
    v.add        v9, v6, v7
    v.add        v6, v1, v9
    v.st.w       [s9, #0], v6
    s.addi       s9, s7, #4288
    v.ld.w       v6, [s23, #0]
    s.movz       s23, #3
    v.ld.w       v7, [s21, #0]
    v.mul        v9, v6, v5
    s.addi       s21, s1, #3
    v.splat      v5, s21
    v.add        v6, v7, v9
    v.iota       v7                              // arange(0, VLEN)
    v.add        v9, v1, v6
    s.movz       s21, #1
    v.st.w       [s26, #0], v9
    fence.acq_rel.device
    v.splat      v1, s21
    v.ld.w       v6, [s22, #0]
    s.addi       s21, s7, #4352
    s.addi       s22, s1, #4
    v.iota       v9                              // arange(0, VLEN)
    v.splat      v10, s22
    s.movz       s22, #4
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v6]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v4, v8
    p.and        p4, p3, p2
    v.cmp.lt     p2, v5, v0
    s.movz       s25, #1
    a.vwrite     a0, s8, v11
    v.ld.w       v4, [s13, #0]
    v.splat      v5, s25
    s.addi       s8, s7, #4416
    s.addi       s13, s1, #5
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v8, s13
    s.movz       s13, #5
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v7, v1
    p.and        p5, p3, p2
    v.cmp.lt     p2, v10, v0
    s.movz       s25, #1
    a.vwrite     a0, s24, v11
    v.ld.w       v1, [s2, #0]
    v.splat      v4, s25
    s.addi       s2, s7, #4480
    s.addi       s24, s1, #6
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v10, s24
    s.movz       s24, #6
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v9, v5
    p.and        p4, p3, p2
    v.cmp.lt     p2, v8, v0
    s.movz       s25, #1
    a.vwrite     a0, s6, v11
    v.ld.w       v1, [s9, #0]
    v.splat      v5, s25
    s.addi       s6, s7, #4544
    s.addi       s9, s1, #7
    v.iota       v8                              // arange(0, VLEN)
    v.splat      v9, s9
    s.movz       s9, #7
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v4
    p.and        p5, p3, p2
    v.cmp.lt     p2, v10, v0
    s.movz       s25, #1
    a.vwrite     a0, s23, v11
    v.ld.w       v1, [s21, #0]
    v.splat      v4, s25
    s.addi       s21, s7, #4608
    s.addi       s23, s1, #8
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v10, s23
    s.movz       s23, #8
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v7, v5
    p.and        p4, p3, p2
    v.cmp.lt     p2, v9, v0
    s.movz       s25, #1
    a.vwrite     a0, s22, v11
    v.ld.w       v1, [s8, #0]
    v.splat      v5, s25
    s.addi       s8, s7, #4672
    s.addi       s22, s1, #9
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v9, s22
    s.movz       s22, #9
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v8, v4
    p.and        p5, p3, p2
    v.cmp.lt     p2, v10, v0
    s.movz       s25, #1
    a.vwrite     a0, s13, v11
    v.ld.w       v1, [s2, #0]
    v.splat      v4, s25
    s.addi       s2, s7, #4736
    s.addi       s13, s1, #10
    v.iota       v8                              // arange(0, VLEN)
    v.splat      v10, s13
    s.movz       s13, #10
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v5
    p.and        p4, p3, p2
    v.cmp.lt     p2, v9, v0
    s.movz       s25, #1
    a.vwrite     a0, s24, v11
    v.ld.w       v1, [s6, #0]
    v.splat      v5, s25
    s.addi       s6, s7, #4800
    s.addi       s24, s1, #11
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v9, s24
    s.movz       s24, #11
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v7, v4
    p.and        p5, p3, p2
    v.cmp.lt     p2, v10, v0
    s.movz       s25, #1
    a.vwrite     a0, s9, v11
    v.ld.w       v1, [s21, #0]
    v.splat      v4, s25
    s.addi       s9, s7, #4864
    s.addi       s21, s1, #12
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v10, s21
    s.movz       s21, #12
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v8, v5
    p.and        p4, p3, p2
    v.cmp.lt     p2, v9, v0
    s.movz       s25, #1
    a.vwrite     a0, s23, v11
    v.ld.w       v1, [s8, #0]
    v.splat      v5, s25
    s.addi       s8, s7, #4928
    s.addi       s23, s1, #13
    v.iota       v8                              // arange(0, VLEN)
    v.splat      v9, s23
    s.movz       s23, #13
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v4
    p.and        p5, p3, p2
    v.cmp.lt     p2, v10, v0
    s.movz       s25, #1
    a.vwrite     a0, s22, v11
    v.ld.w       v1, [s2, #0]
    v.splat      v4, s25
    s.addi       s2, s7, #4992
    s.addi       s22, s1, #14
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v10, s22
    s.movz       s22, #14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s4, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v7, v5
    p.and        p4, p3, p2
    v.cmp.lt     p2, v9, v0
    s.movz       s25, #1
    a.vwrite     a0, s13, v11
    v.ld.w       v1, [s6, #0]
    v.splat      v5, s25
    s.addi       s6, s7, #5056
    s.addi       s13, s1, #15
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v9, s13
    s.movz       s13, #15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s4, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v8, v4
    p.and        p5, p3, p2
    v.cmp.lt     p2, v10, v0
    s.movz       s25, #1
    a.vwrite     a0, s24, v11
    v.ld.w       v1, [s9, #0]
    v.splat      v4, s25
    s.addi       s9, s7, #0
    s.addi       s24, s7, #5120
    s.addi       s25, s24, #64
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s4, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v5
    p.and        p4, p3, p2
    v.cmp.lt     p2, v9, v0
    a.vwrite     a0, s21, v8
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s7, #64
    s.addi       s21, s7, #128
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v5, [s4, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v7, v4
    p.and        p5, p3, p2
    a.vwrite     a0, s23, v5
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s24, #128
    s.addi       s23, s7, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s4, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s22, v4
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s24, #192
    s.addi       s22, s7, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s4, v1]               // index is in elements (ISA sec 9.1)
    s.addi       s4, s24, #256
    a.vwrite     a0, s13, v4
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s7, #320
    s.addi       s13, s24, #320
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    v.st.w       [s24, #0], v1
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s7, #384
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    v.st.w       [s25, #0], v1
    s.addi       s25, s24, #384
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s7, #448
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    v.st.w       [s2, #0], v1
    s.addi       s2, s24, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s7, #512
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    v.st.w       [s6, #0], v1
    s.addi       s6, s24, #512
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s7, #576
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    v.st.w       [s4, #0], v1
    s.addi       s4, s24, #576
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s7, #640
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    v.st.w       [s13, #0], v1
    s.addi       s13, s24, #640
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s7, #704
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    v.st.w       [s25, #0], v1
    s.addi       s25, s24, #704
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s7, #768
    v.mul        v4, v1, v2
    v.add        v1, v3, v4
    v.st.w       [s2, #0], v1
    s.addi       s2, s24, #768
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s7, #832
    v.splat      v4, s3
    v.mul        v5, v1, v2
    v.add        v1, v3, v5
    v.st.w       [s6, #0], v1
    s.addi       s6, s24, #832
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s7, #896
    v.mul        v5, v1, v2
    v.add        v1, v3, v5
    v.st.w       [s4, #0], v1
    s.addi       s4, s24, #896
    s.addi       s26, s24, #960
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s7, #960
    v.mul        v5, v1, v2
    v.add        v1, v3, v5
    v.st.w       [s13, #0], v1
    s.addi       s13, s7, #5120
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s7, #6144
    v.mul        v5, v1, v2
    v.add        v1, v3, v5
    v.st.w       [s25, #0], v1
    s.addi       s24, s7, #5184
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s8, #64
    v.mul        v5, v1, v2
    v.add        v1, v3, v5
    v.st.w       [s2, #0], v1
    s.addi       s2, s7, #5248
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s8, #128
    v.mul        v5, v1, v2
    v.add        v1, v3, v5
    v.st.w       [s6, #0], v1
    s.addi       s6, s7, #5312
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s8, #192
    v.mul        v5, v1, v2
    v.add        v1, v3, v5
    v.st.w       [s4, #0], v1
    s.addi       s4, s7, #5376
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s8, #256
    v.mul        v5, v1, v2
    v.add        v1, v3, v5
    v.st.w       [s26, #0], v1
    fence.acq_rel.device
    s.addi       s25, s7, #5440
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s8, #320
    v.add        v5, v4, v1
    v.st.w       [s8, #0], v5
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s7, #5504
    v.add        v5, v4, v1
    v.st.w       [s21, #0], v5
    s.addi       s21, s8, #384
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s7, #5568
    v.add        v5, v4, v1
    v.st.w       [s23, #0], v5
    s.addi       s23, s8, #448
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s7, #5632
    v.add        v5, v4, v1
    v.st.w       [s22, #0], v5
    s.addi       s22, s8, #512
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s7, #5696
    v.add        v5, v4, v1
    v.st.w       [s9, #0], v5
    s.addi       s9, s8, #576
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s7, #5760
    v.add        v5, v4, v1
    v.st.w       [s13, #0], v5
    s.addi       s13, s8, #640
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s7, #5824
    v.add        v5, v4, v1
    v.st.w       [s21, #0], v5
    s.addi       s21, s8, #704
    v.splat      v1, s1
    v.ld.w       v5, [s2, #0]
    s.addi       s2, s7, #5888
    v.cmp.lt     p2, v1, v0
    v.add        v1, v4, v5
    p.and        p3, p1, p2
    v.st.w       [s23, #0], v1
    s.addi       s23, s8, #768
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s7, #5952
    v.add        v5, v4, v1
    v.st.w       [s22, #0], v5
    s.addi       s22, s8, #832
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s7, #6016
    v.add        v5, v4, v1
    v.st.w       [s9, #0], v5
    s.addi       s9, s8, #896
    s.addi       s26, s8, #960
    v.ld.w       v1, [s25, #0]
    s.addi       s8, s7, #6080
    v.add        v5, v4, v1
    v.st.w       [s13, #0], v5
    s.addi       s13, s7, #6144
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s7, #7168
    v.add        v5, v4, v1
    v.st.w       [s21, #0], v5
    s.addi       s21, s7, #6208
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #1
    v.splat      v5, s2
    s.addi       s2, s24, #64
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    v.add        v5, v4, v1
    v.st.w       [s23, #0], v5
    s.addi       s23, s7, #6272
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s1, #2
    v.splat      v5, s6
    s.addi       s6, s24, #128
    v.cmp.lt     p2, v5, v0
    p.and        p5, p1, p2
    v.add        v5, v4, v1
    v.st.w       [s22, #0], v5
    s.addi       s22, s7, #6336
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s1, #3
    v.splat      v5, s4
    s.addi       s4, s24, #192
    v.add        v6, v4, v1
    v.st.w       [s9, #0], v6
    s.addi       s9, s7, #6400
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s1, #4
    v.splat      v6, s8
    s.addi       s8, s24, #256
    v.add        v7, v4, v1
    v.st.w       [s26, #0], v7
    fence.acq_rel.device
    s.addi       s25, s7, #6464
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s1, #5
    v.splat      v4, s13
    s.addi       s13, s24, #320
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v7, [s11, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v0
    p.and        p3, p1, p2
    v.st.w       [s24, #0], v7
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s7, #6528
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s11, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v0
    p.and        p4, p1, p2
    v.st.w       [s2, #0], v5
    s.addi       s2, s1, #6
    v.splat      v1, s2
    s.addi       s2, s24, #384
    v.ld.w       v5, [s23, #0]
    s.addi       s23, s7, #6592
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s11, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    v.st.w       [s6, #0], v6
    s.addi       s6, s1, #7
    v.splat      v4, s6
    s.addi       s6, s24, #448
    v.ld.w       v5, [s22, #0]
    s.addi       s22, s7, #6656
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s11, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v0
    p.and        p3, p1, p2
    v.st.w       [s4, #0], v6
    s.addi       s4, s1, #8
    v.splat      v1, s4
    s.addi       s4, s24, #512
    v.ld.w       v5, [s9, #0]
    s.addi       s9, s7, #6720
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s11, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p4, p1, p2
    v.st.w       [s8, #0], v6
    s.addi       s8, s1, #9
    v.splat      v4, s8
    s.addi       s8, s24, #576
    v.ld.w       v5, [s25, #0]
    s.addi       s25, s7, #6784
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s11, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v0
    p.and        p5, p1, p2
    v.st.w       [s13, #0], v6
    s.addi       s13, s1, #10
    v.splat      v1, s13
    s.addi       s13, s24, #640
    v.ld.w       v5, [s21, #0]
    s.addi       s21, s7, #6848
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s11, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    v.st.w       [s2, #0], v6
    s.addi       s2, s1, #11
    v.splat      v4, s2
    s.addi       s2, s24, #704
    v.ld.w       v5, [s23, #0]
    s.addi       s23, s7, #6912
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s11, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v0
    p.and        p4, p1, p2
    v.st.w       [s6, #0], v6
    s.addi       s6, s1, #12
    v.splat      v1, s6
    s.addi       s6, s24, #768
    v.ld.w       v5, [s22, #0]
    s.addi       s22, s7, #6976
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s11, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    v.st.w       [s4, #0], v6
    s.addi       s4, s1, #13
    v.splat      v4, s4
    s.addi       s4, s24, #832
    v.ld.w       v5, [s9, #0]
    s.addi       s9, s7, #7040
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s11, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v0
    p.and        p3, p1, p2
    v.st.w       [s8, #0], v6
    s.addi       s8, s1, #14
    v.splat      v1, s8
    s.addi       s8, s24, #896
    s.addi       s26, s24, #960
    v.ld.w       v5, [s25, #0]
    s.addi       s24, s7, #7104
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s11, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p4, p1, p2
    v.st.w       [s13, #0], v6
    s.addi       s13, s1, #15
    v.splat      v4, s13
    s.addi       s13, s7, #7168
    v.ld.w       v5, [s21, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s21, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s11, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v0
    p.and        p5, p1, p2
    v.st.w       [s2, #0], v6
    s.addi       s2, s7, #7232
    v.ld.w       v1, [s23, #0]
    s.movz       s23, #1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s11, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    v.st.w       [s6, #0], v5
    s.addi       s6, s7, #7296
    v.ld.w       v1, [s22, #0]
    s.movz       s22, #2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s11, v1]              // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v4
    s.addi       s4, s7, #7360
    v.ld.w       v1, [s9, #0]
    s.movz       s9, #3
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v4, [s11, v1]              // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v4
    s.addi       s8, s7, #7424
    v.ld.w       v1, [s24, #0]
    s.movz       s24, #4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s11, v1]              // index is in elements (ISA sec 9.1)
    s.addi       s11, s7, #7488
    v.st.w       [s26, #0], v4
    fence.acq_rel.device
    s.movz       s25, #5
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s7, #7552
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a1, s21, v4
    v.ld.w       v1, [s2, #0]
    s.movz       s2, #6
    s.addi       s21, s7, #7616
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a1, s23, v4
    v.ld.w       v1, [s6, #0]
    s.movz       s6, #7
    s.addi       s23, s7, #7680
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a1, s22, v4
    v.ld.w       v1, [s4, #0]
    s.movz       s4, #8
    s.addi       s22, s7, #7744
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a1, s9, v4
    v.ld.w       v1, [s8, #0]
    s.movz       s8, #9
    s.addi       s9, s7, #7808
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a1, s24, v4
    v.ld.w       v1, [s11, #0]
    s.movz       s11, #10
    s.addi       s24, s7, #7872
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a1, s25, v4
    v.ld.w       v1, [s13, #0]
    s.movz       s13, #11
    s.addi       s25, s7, #7936
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a1, s2, v4
    v.ld.w       v1, [s21, #0]
    s.movz       s2, #12
    s.addi       s21, s7, #8000
    v.splat      v4, s3
    vf.cvt.bf16.f32 v5, v1
    a.vwrite     a1, s6, v5
    v.ld.w       v1, [s23, #0]
    s.movz       s6, #13
    s.addi       s23, s7, #8064
    vf.cvt.bf16.f32 v5, v1
    a.vwrite     a1, s4, v5
    v.ld.w       v1, [s22, #0]
    s.movz       s4, #14
    s.addi       s22, s7, #8128
    vf.cvt.bf16.f32 v5, v1
    a.vwrite     a1, s8, v5
    v.ld.w       v1, [s9, #0]
    s.movz       s8, #15
    s.addi       s9, s7, #5120
    vf.cvt.bf16.f32 v5, v1
    a.vwrite     a1, s11, v5
    v.ld.w       v1, [s24, #0]
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s11, s7, #8192
    s.addi       s24, s7, #5184
    vf.cvt.bf16.f32 v5, v1
    a.vwrite     a1, s13, v5
    v.ld.w       v1, [s25, #0]
    s.addi       s13, s11, #64
    s.addi       s25, s7, #5248
    vf.cvt.bf16.f32 v5, v1
    a.vwrite     a1, s2, v5
    v.ld.w       v1, [s21, #0]
    s.addi       s2, s11, #128
    s.addi       s21, s7, #5312
    vf.cvt.bf16.f32 v5, v1
    a.vwrite     a1, s6, v5
    v.ld.w       v1, [s23, #0]
    s.addi       s6, s11, #192
    s.addi       s23, s7, #5376
    vf.cvt.bf16.f32 v5, v1
    a.vwrite     a1, s4, v5
    v.ld.w       v1, [s22, #0]
    s.addi       s4, s11, #256
    s.addi       s22, s7, #5440
    vf.cvt.bf16.f32 v5, v1
    a.vwrite     a1, s8, v5
    v.ld.w       v1, [s9, #0]
    s.addi       s8, s11, #320
    s.addi       s9, s7, #5504
    v.add        v5, v4, v1
    v.st.w       [s11, #0], v5
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s11, #384
    v.add        v5, v4, v1
    v.st.w       [s13, #0], v5
    s.addi       s13, s7, #5568
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s11, #448
    v.add        v5, v4, v1
    v.st.w       [s2, #0], v5
    s.addi       s2, s7, #5632
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s11, #512
    v.add        v5, v4, v1
    v.st.w       [s6, #0], v5
    s.muli       s6, s10, #2                     // a runtime tile origin, x2
    s.add        s26, s12, s6                    // the tile origin
    s.muli       s6, s5, #256                    // a runtime tile origin, x256
    v.ld.w       v1, [s23, #0]
    s.addi       s12, s11, #576
    s.add        s23, s26, s6                    // the tile origin
    s.addi       s6, s7, #5696
    v.add        v5, v4, v1
    v.st.w       [s4, #0], v5
    s.addi       s4, s7, #5760
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s11, #640
    v.add        v5, v4, v1
    v.st.w       [s8, #0], v5
    s.addi       s8, s7, #5824
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s11, #704
    v.add        v5, v4, v1
    v.st.w       [s24, #0], v5
    s.addi       s24, s7, #5888
    v.splat      v1, s1
    v.ld.w       v5, [s13, #0]
    s.addi       s13, s11, #768
    v.cmp.lt     p2, v1, v0
    v.add        v1, v4, v5
    p.and        p3, p1, p2
    v.st.w       [s25, #0], v1
    s.addi       s25, s7, #5952
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s11, #832
    v.add        v5, v4, v1
    v.st.w       [s21, #0], v5
    s.addi       s21, s7, #6016
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s11, #896
    s.addi       s26, s11, #960
    v.add        v5, v4, v1
    v.st.w       [s12, #0], v5
    s.addi       s11, s7, #6080
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s7, #8192
    v.add        v5, v4, v1
    v.st.w       [s22, #0], v5
    s.addi       s12, s7, #9216
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s7, #8256
    v.add        v5, v4, v1
    v.st.w       [s9, #0], v5
    s.addi       s9, s1, #1
    v.splat      v1, s9
    s.addi       s9, s12, #64
    v.cmp.lt     p2, v1, v0
    p.and        p4, p1, p2
    v.ld.w       v1, [s24, #0]
    s.addi       s22, s7, #8320
    v.add        v5, v4, v1
    v.st.w       [s13, #0], v5
    s.addi       s13, s1, #2
    v.splat      v1, s13
    s.addi       s13, s12, #128
    v.cmp.lt     p2, v1, v0
    p.and        p5, p1, p2
    v.ld.w       v1, [s25, #0]
    s.addi       s24, s7, #8384
    v.add        v5, v4, v1
    v.st.w       [s2, #0], v5
    s.addi       s2, s1, #3
    v.splat      v1, s2
    s.addi       s2, s12, #192
    v.ld.w       v5, [s21, #0]
    s.addi       s21, s7, #8448
    v.add        v6, v4, v5
    v.st.w       [s6, #0], v6
    s.addi       s6, s1, #4
    v.splat      v5, s6
    s.addi       s6, s12, #256
    v.ld.w       v6, [s11, #0]
    s.addi       s11, s12, #320
    v.add        v7, v4, v6
    v.st.w       [s26, #0], v7
    fence.acq_rel.device
    s.addi       s25, s7, #8512
    v.ld.w       v4, [s4, #0]
    s.addi       s4, s1, #5
    v.splat      v6, s4
    s.addi       s4, s12, #384
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v7, [s14, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v0
    p.and        p3, p1, p2
    v.st.w       [s12, #0], v7
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s7, #8576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    v.st.w       [s9, #0], v4
    s.addi       s9, s1, #6
    v.splat      v1, s9
    s.addi       s9, s7, #8640
    v.ld.w       v4, [s22, #0]
    s.addi       s22, s1, #7
    v.splat      v5, s22
    s.addi       s22, s12, #448
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v7, [s14, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v0
    p.and        p5, p1, p2
    v.st.w       [s13, #0], v7
    s.addi       s13, s7, #8704
    v.ld.w       v4, [s24, #0]
    s.addi       s24, s1, #8
    v.splat      v6, s24
    s.addi       s24, s12, #512
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v7, [s14, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v0
    p.and        p3, p1, p2
    v.st.w       [s2, #0], v7
    s.addi       s2, s7, #8768
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s1, #9
    v.splat      v4, s21
    s.addi       s21, s12, #576
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v7, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    v.st.w       [s6, #0], v7
    s.addi       s6, s7, #8832
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s1, #10
    v.splat      v5, s25
    s.addi       s25, s12, #640
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v7, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v0
    p.and        p5, p1, p2
    v.st.w       [s11, #0], v7
    s.addi       s11, s7, #8896
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s1, #11
    v.splat      v6, s8
    s.addi       s8, s12, #704
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v7, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    v.st.w       [s4, #0], v7
    s.addi       s4, s7, #8960
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s1, #12
    v.splat      v4, s9
    s.addi       s9, s12, #768
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v7, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    v.st.w       [s22, #0], v7
    s.addi       s22, s7, #9024
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s1, #13
    v.splat      v5, s13
    s.addi       s13, s12, #832
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v7, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v0
    p.and        p5, p1, p2
    v.st.w       [s24, #0], v7
    s.addi       s24, s7, #9088
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #14
    v.splat      v6, s2
    s.addi       s2, s12, #896
    s.addi       s26, s12, #960
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v7, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    v.st.w       [s21, #0], v7
    s.addi       s12, s7, #9152
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s1, #15
    v.splat      v4, s6
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v7, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    v.st.w       [s25, #0], v7
    s.addi       s21, s7, #9216
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s7, #9280
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v0
    p.and        p5, p1, p2
    v.st.w       [s8, #0], v5
    s.movz       s8, #1
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s7, #9344
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    v.st.w       [s9, #0], v5
    s.movz       s9, #2
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s7, #9408
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.st.w       [s13, #0], v4
    s.movz       s13, #3
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s7, #9472
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v4, [s14, v1]              // index is in elements (ISA sec 9.1)
    v.st.w       [s2, #0], v4
    s.movz       s2, #4
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s7, #9536
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s14, v1]              // index is in elements (ISA sec 9.1)
    s.movz       s14, #5
    v.st.w       [s26, #0], v4
    fence.acq_rel.device
    s.addi       s25, s7, #9600
    v.ld.w       v1, [s21, #0]
    s.movz       s21, #6
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a2, s6, v4
    v.ld.w       v1, [s11, #0]
    s.addi       s6, s7, #9664
    s.movz       s11, #7
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a2, s8, v4
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s7, #9728
    s.movz       s8, #8
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a2, s9, v4
    v.ld.w       v1, [s22, #0]
    s.addi       s9, s7, #9792
    s.movz       s22, #9
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a2, s13, v4
    v.ld.w       v1, [s24, #0]
    s.addi       s13, s7, #9856
    s.movz       s24, #10
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a2, s2, v4
    v.ld.w       v1, [s12, #0]
    s.addi       s2, s7, #9920
    s.movz       s12, #11
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a2, s14, v4
    v.ld.w       v1, [s25, #0]
    s.addi       s14, s7, #9984
    s.movz       s25, #12
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a2, s21, v4
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s7, #10048
    s.movz       s21, #13
    vf.cvt.bf16.f32 v4, v1
    a.vwrite     a2, s11, v4
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s7, #10112
    s.movz       s11, #14
    v.movi       v4, #0
    v.movi       v5, #1
    vf.cvt.bf16.f32 v5, v1
    a.vwrite     a2, s8, v5
    v.ld.w       v1, [s9, #0]
    s.addi       s8, s7, #10176
    s.movz       s9, #15
    v.movi       v5, #1
    vf.cvt.bf16.f32 v6, v1
    a.vwrite     a2, s22, v6
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s7, #1024
    // a masked 1x16 tile with contiguous rows: one predicated load a row
    s.addi       s22, s7, #10240
    vf.cvt.bf16.f32 v6, v1
    a.vwrite     a2, s24, v6
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s7, #1088
    v.movi       v6, #0
    s.addi       s24, s22, #64
    v.movi       v7, #1
    vf.cvt.bf16.f32 v7, v1
    a.vwrite     a2, s12, v7
    v.ld.w       v1, [s14, #0]
    s.muli       s12, s10, #2                    // a runtime tile origin, x2
    s.movz       s14, #2
    v.splat      v7, s14
    s.add        s14, s15, s12                   // the tile origin
    v.sub        v8, v4, v7
    v.sub        v9, v6, v7
    v.cmp.lt     p2, v7, v4
    vf.cvt.bf16.f32 v10, v1
    v.movi       v1, #1
    v.cmp.lt     p3, v7, v6
    @p2 v.sel        v11, v8, v7
    a.vwrite     a2, s25, v10
    v.ld.w       v8, [s6, #0]
    @p3 v.sel        v10, v9, v7
    vf.cvt.bf16.f32 v9, v8
    s.addi       s6, s22, #128
    a.vwrite     a2, s21, v9
    v.ld.w       v8, [s4, #0]
    s.addi       s4, s7, #1152
    v.movi       v9, #0
    v.movi       v10, #1
    vf.cvt.bf16.f32 v10, v8
    a.vwrite     a2, s11, v10
    v.ld.w       v8, [s8, #0]
    v.sub        v10, v9, v7
    v.cmp.lt     p2, v7, v9
    vf.cvt.bf16.f32 v11, v8
    @p2 v.sel        v8, v10, v7
    a.vwrite     a2, s9, v11
    v.ld.w       v8, [s13, #0]
    v.movi       v10, #1
    s.addi       s8, s7, #1216
    v.movi       v11, #0
    s.addi       s9, s22, #192
    v.movi       v12, #1
    v.sub        v12, v4, v8
    v.cmp.lt     p2, v8, v4
    @p2 v.sel        v13, v12, v8
    v.movi       v8, #1
    v.lshr       v12, v13, v5
    v.sub        v5, v11, v7
    v.sub        v13, v4, v12
    v.cmp.lt     p3, v7, v11
    @p2 v.sel        v4, v13, v12
    @p3 v.sel        v12, v5, v7
    v.st.w       [s22, #0], v4
    s.addi       s11, s7, #1280
    s.addi       s12, s22, #256
    v.ld.w       v4, [s2, #0]
    v.movi       v5, #0
    v.movi       v12, #1
    v.sub        v12, v6, v4
    v.cmp.lt     p2, v4, v6
    @p2 v.sel        v13, v12, v4
    v.movi       v4, #1
    v.lshr       v12, v13, v1
    v.sub        v1, v5, v7
    v.sub        v13, v6, v12
    v.cmp.lt     p3, v7, v5
    @p2 v.sel        v6, v13, v12
    @p3 v.sel        v12, v1, v7
    v.st.w       [s24, #0], v6
    s.addi       s2, s7, #1344
    s.addi       s13, s22, #320
    v.ld.w       v1, [s4, #0]
    v.movi       v6, #0
    v.movi       v12, #1
    v.sub        v12, v9, v1
    v.cmp.lt     p2, v1, v9
    @p2 v.sel        v13, v12, v1
    v.movi       v1, #1
    v.lshr       v12, v13, v10
    v.sub        v10, v6, v7
    v.sub        v13, v9, v12
    v.cmp.lt     p3, v7, v6
    @p2 v.sel        v9, v13, v12
    @p3 v.sel        v12, v10, v7
    v.st.w       [s6, #0], v9
    s.addi       s4, s7, #1408
    s.addi       s6, s22, #384
    v.ld.w       v9, [s8, #0]
    v.movi       v10, #0
    v.movi       v12, #1
    v.sub        v12, v11, v9
    v.cmp.lt     p2, v9, v11
    @p2 v.sel        v13, v12, v9
    v.movi       v9, #1
    v.lshr       v12, v13, v8
    v.sub        v8, v10, v7
    v.sub        v13, v11, v12
    v.cmp.lt     p3, v7, v10
    @p2 v.sel        v11, v13, v12
    @p3 v.sel        v12, v8, v7
    v.st.w       [s9, #0], v11
    s.addi       s8, s7, #1472
    s.addi       s9, s22, #448
    v.ld.w       v8, [s11, #0]
    v.movi       v11, #0
    v.movi       v12, #1
    v.sub        v12, v5, v8
    v.cmp.lt     p2, v8, v5
    @p2 v.sel        v13, v12, v8
    v.movi       v8, #1
    v.lshr       v12, v13, v4
    v.sub        v4, v11, v7
    v.sub        v13, v5, v12
    v.cmp.lt     p3, v7, v11
    @p2 v.sel        v5, v13, v12
    @p3 v.sel        v12, v4, v7
    v.st.w       [s12, #0], v5
    s.addi       s11, s7, #1536
    s.addi       s12, s22, #512
    v.ld.w       v4, [s2, #0]
    v.movi       v5, #0
    v.movi       v12, #1
    v.sub        v12, v6, v4
    v.cmp.lt     p2, v4, v6
    @p2 v.sel        v13, v12, v4
    v.movi       v4, #1
    v.lshr       v12, v13, v1
    v.sub        v1, v5, v7
    v.sub        v13, v6, v12
    v.cmp.lt     p3, v7, v5
    @p2 v.sel        v6, v13, v12
    @p3 v.sel        v12, v1, v7
    v.st.w       [s13, #0], v6
    s.addi       s2, s7, #1600
    s.addi       s13, s22, #576
    v.ld.w       v1, [s4, #0]
    v.movi       v6, #0
    v.movi       v12, #1
    v.sub        v12, v10, v1
    v.cmp.lt     p2, v1, v10
    @p2 v.sel        v13, v12, v1
    v.movi       v1, #1
    v.lshr       v12, v13, v9
    v.sub        v9, v6, v7
    v.sub        v13, v10, v12
    v.cmp.lt     p3, v7, v6
    @p2 v.sel        v10, v13, v12
    @p3 v.sel        v12, v9, v7
    v.st.w       [s6, #0], v10
    s.addi       s4, s7, #1664
    s.addi       s6, s22, #640
    v.ld.w       v9, [s8, #0]
    v.movi       v10, #0
    v.movi       v12, #1
    v.sub        v12, v11, v9
    v.cmp.lt     p2, v9, v11
    @p2 v.sel        v13, v12, v9
    v.movi       v9, #1
    v.lshr       v12, v13, v8
    v.sub        v8, v10, v7
    v.sub        v13, v11, v12
    v.cmp.lt     p3, v7, v10
    @p2 v.sel        v11, v13, v12
    @p3 v.sel        v12, v8, v7
    v.st.w       [s9, #0], v11
    s.addi       s8, s7, #1728
    s.addi       s9, s22, #704
    v.ld.w       v8, [s11, #0]
    v.movi       v11, #0
    v.movi       v12, #1
    v.sub        v12, v5, v8
    v.cmp.lt     p2, v8, v5
    @p2 v.sel        v13, v12, v8
    v.movi       v8, #1
    v.lshr       v12, v13, v4
    v.sub        v4, v11, v7
    v.sub        v13, v5, v12
    v.cmp.lt     p3, v7, v11
    @p2 v.sel        v5, v13, v12
    @p3 v.sel        v12, v4, v7
    v.st.w       [s12, #0], v5
    s.addi       s11, s7, #1792
    s.addi       s12, s22, #768
    v.ld.w       v4, [s2, #0]
    v.movi       v5, #0
    v.movi       v12, #1
    v.sub        v12, v6, v4
    v.cmp.lt     p2, v4, v6
    @p2 v.sel        v13, v12, v4
    v.movi       v4, #1
    v.lshr       v12, v13, v1
    v.sub        v1, v5, v7
    v.sub        v13, v6, v12
    v.cmp.lt     p3, v7, v5
    @p2 v.sel        v6, v13, v12
    @p3 v.sel        v12, v1, v7
    v.st.w       [s13, #0], v6
    s.addi       s2, s7, #1856
    s.addi       s13, s22, #832
    v.ld.w       v1, [s4, #0]
    v.movi       v6, #0
    v.movi       v12, #1
    v.sub        v12, v10, v1
    v.cmp.lt     p2, v1, v10
    @p2 v.sel        v13, v12, v1
    v.movi       v1, #1
    v.lshr       v12, v13, v9
    v.sub        v9, v6, v7
    v.sub        v13, v10, v12
    v.cmp.lt     p3, v7, v6
    @p2 v.sel        v10, v13, v12
    @p3 v.sel        v12, v9, v7
    v.st.w       [s6, #0], v10
    s.addi       s4, s7, #1920
    s.addi       s6, s22, #896
    v.ld.w       v9, [s8, #0]
    v.movi       v10, #0
    v.movi       v12, #1
    v.sub        v12, v11, v9
    v.cmp.lt     p2, v9, v11
    @p2 v.sel        v13, v12, v9
    v.movi       v9, #1
    v.lshr       v12, v13, v8
    v.sub        v8, v10, v7
    v.sub        v13, v11, v12
    v.cmp.lt     p3, v7, v10
    @p2 v.sel        v11, v13, v12
    @p3 v.sel        v12, v8, v7
    v.st.w       [s9, #0], v11
    s.addi       s8, s7, #1984
    s.addi       s9, s22, #960
    v.ld.w       v8, [s11, #0]
    v.movi       v11, #0
    v.movi       v12, #1
    v.sub        v12, v5, v8
    v.cmp.lt     p2, v8, v5
    @p2 v.sel        v13, v12, v8
    v.movi       v8, #1
    v.lshr       v12, v13, v4
    v.sub        v4, v11, v7
    v.sub        v13, v5, v12
    v.cmp.lt     p3, v7, v11
    @p2 v.sel        v5, v13, v12
    @p3 v.sel        v12, v4, v7
    v.st.w       [s12, #0], v5
    s.addi       s11, s7, #11264
    v.ld.w       v4, [s2, #0]
    s.addi       s2, s7, #10240
    v.splat      v5, s3
    v.sub        v7, v6, v4
    v.cmp.lt     p2, v4, v6
    @p2 v.sel        v12, v7, v4
    s.addi       s12, s7, #0
    v.lshr       v4, v12, v1
    s.movz       s15, #1024
    v.sub        v1, v6, v4
    v.splat      v6, s15
    @p2 v.sel        v7, v1, v4
    v.st.w       [s13, #0], v7
    s.addi       s13, s7, #10304
    s.addi       s15, s11, #64
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s7, #64
    v.sub        v4, v10, v1
    v.cmp.lt     p2, v1, v10
    @p2 v.sel        v7, v4, v1
    s.addi       s21, s7, #10368
    v.lshr       v1, v7, v9
    s.addi       s22, s11, #128
    v.sub        v4, v10, v1
    @p2 v.sel        v7, v4, v1
    v.st.w       [s6, #0], v7
    s.addi       s6, s7, #128
    v.ld.w       v1, [s8, #0]
    v.sub        v4, v11, v1
    v.cmp.lt     p2, v1, v11
    @p2 v.sel        v7, v4, v1
    s.addi       s8, s7, #10432
    v.lshr       v1, v7, v8
    s.addi       s24, s7, #192
    v.sub        v4, v11, v1
    s.addi       s25, s11, #192
    @p2 v.sel        v7, v4, v1
    v.st.w       [s9, #0], v7
    fence.acq_rel.device
    s.addi       s9, s7, #10496
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s11, #256
    v.ld.w       v4, [s12, #0]
    v.mul        v7, v1, v2
    s.addi       s12, s7, #256
    v.add        v1, v3, v7
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s11, #0], v1
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s7, #10560
    v.ld.w       v4, [s4, #0]
    v.mul        v7, v1, v2
    s.addi       s4, s7, #320
    v.add        v1, v3, v7
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s15, #0], v1
    s.addi       s15, s11, #320
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s7, #10624
    v.ld.w       v4, [s6, #0]
    v.mul        v7, v1, v2
    s.addi       s6, s7, #384
    v.add        v1, v3, v7
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s22, #0], v1
    s.addi       s22, s11, #384
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s7, #10688
    v.ld.w       v4, [s24, #0]
    v.mul        v7, v1, v2
    s.addi       s24, s7, #448
    v.add        v1, v3, v7
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s25, #0], v1
    s.addi       s25, s11, #448
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s7, #10752
    v.ld.w       v4, [s12, #0]
    v.mul        v7, v1, v2
    s.addi       s12, s7, #512
    v.add        v1, v3, v7
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s2, #0], v1
    s.addi       s2, s11, #512
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s7, #10816
    v.ld.w       v4, [s4, #0]
    v.mul        v7, v1, v2
    s.addi       s4, s7, #576
    v.add        v1, v3, v7
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s15, #0], v1
    s.addi       s15, s11, #576
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s7, #10880
    v.ld.w       v4, [s6, #0]
    v.mul        v7, v1, v2
    s.addi       s6, s7, #640
    v.add        v1, v3, v7
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s22, #0], v1
    s.addi       s22, s11, #640
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s7, #10944
    v.ld.w       v4, [s24, #0]
    v.mul        v7, v1, v2
    s.addi       s24, s7, #704
    v.add        v1, v3, v7
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s25, #0], v1
    s.addi       s25, s11, #704
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s7, #11008
    v.ld.w       v4, [s12, #0]
    v.mul        v7, v1, v2
    s.addi       s12, s7, #768
    v.add        v1, v3, v7
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s2, #0], v1
    s.addi       s2, s11, #768
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s7, #11072
    v.ld.w       v4, [s4, #0]
    v.mul        v7, v1, v2
    s.addi       s4, s7, #832
    v.add        v1, v3, v7
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s15, #0], v1
    s.addi       s15, s11, #832
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s7, #11136
    v.ld.w       v4, [s6, #0]
    v.mul        v7, v1, v2
    s.addi       s6, s7, #896
    v.add        v1, v3, v7
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s22, #0], v1
    s.addi       s22, s11, #896
    s.addi       s26, s11, #960
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s7, #11200
    v.ld.w       v4, [s24, #0]
    v.mul        v7, v1, v2
    s.addi       s11, s7, #960
    v.add        v1, v3, v7
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s25, #0], v1
    s.addi       s24, s7, #11264
    v.splat      v1, s1
    v.cmp.lt     p2, v1, v0
    v.ld.w       v1, [s9, #0]
    p.and        p3, p1, p2
    s.addi       s9, s7, #12288
    v.ld.w       v4, [s12, #0]
    v.mul        v7, v1, v2
    v.add        v1, v3, v7
    s.addi       s12, s7, #11328
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s2, #0], v1
    s.addi       s2, s1, #1
    v.splat      v1, s2
    s.addi       s2, s9, #64
    v.cmp.lt     p2, v1, v0
    p.and        p4, p1, p2
    v.ld.w       v1, [s13, #0]
    v.ld.w       v4, [s4, #0]
    v.mul        v7, v1, v2
    s.addi       s4, s9, #128
    v.add        v1, v3, v7
    s.addi       s13, s7, #11392
    v.mul        v7, v4, v6
    v.add        v4, v1, v7
    v.add        v1, v5, v4
    v.st.w       [s15, #0], v1
    s.addi       s15, s1, #2
    v.splat      v1, s15
    s.addi       s15, s9, #192
    v.cmp.lt     p2, v1, v0
    p.and        p5, p1, p2
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s7, #11456
    v.ld.w       v4, [s6, #0]
    v.mul        v7, v1, v2
    v.add        v1, v3, v7
    s.addi       s6, s1, #3
    v.splat      v7, s6
    v.mul        v8, v4, v6
    v.add        v4, v1, v8
    v.add        v1, v5, v4
    v.st.w       [s22, #0], v1
    s.addi       s6, s7, #11520
    s.addi       s22, s9, #256
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s1, #4
    v.ld.w       v4, [s11, #0]
    v.mul        v8, v1, v2
    v.splat      v1, s8
    v.add        v2, v3, v8
    v.mul        v3, v4, v6
    v.add        v4, v2, v3
    s.addi       s8, s9, #320
    v.add        v2, v5, v4
    s.addi       s11, s7, #11584
    v.st.w       [s26, #0], v2
    fence.acq_rel.device
    s.addi       s25, s1, #5
    v.splat      v2, s25
    v.ld.w       v3, [s24, #0]
    s.addi       s24, s9, #384
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s16, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v0
    p.and        p3, p1, p2
    s.addi       s25, s7, #11648
    v.st.w       [s9, #0], v4
    v.ld.w       v3, [s12, #0]
    s.addi       s12, s1, #6
    v.splat      v4, s12
    s.addi       s12, s9, #448
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s16, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v0
    p.and        p4, p1, p2
    v.st.w       [s2, #0], v5
    s.addi       s2, s7, #11712
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s1, #7
    v.splat      v3, s13
    s.addi       s13, s9, #512
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s16, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v0
    p.and        p5, p1, p2
    v.st.w       [s4, #0], v5
    s.addi       s4, s7, #11776
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s1, #8
    v.splat      v2, s21
    s.addi       s21, s9, #576
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s16, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    v.st.w       [s15, #0], v5
    s.addi       s15, s7, #11840
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s1, #9
    v.splat      v4, s6
    s.addi       s6, s9, #640
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s16, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v0
    p.and        p4, p1, p2
    v.st.w       [s22, #0], v5
    s.addi       s22, s7, #11904
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s1, #10
    v.splat      v3, s11
    s.addi       s11, s9, #704
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s16, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v0
    p.and        p5, p1, p2
    v.st.w       [s8, #0], v5
    s.addi       s8, s7, #11968
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s1, #11
    v.splat      v2, s25
    s.addi       s25, s9, #768
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s16, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    v.st.w       [s24, #0], v5
    s.addi       s24, s7, #12032
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #12
    v.splat      v4, s2
    s.addi       s2, s9, #832
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s16, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v0
    p.and        p4, p1, p2
    v.st.w       [s12, #0], v5
    s.addi       s12, s7, #12096
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s1, #13
    v.splat      v3, s4
    s.addi       s4, s9, #896
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v5, [s16, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v0
    p.and        p5, p1, p2
    v.st.w       [s13, #0], v5
    s.addi       s13, s7, #12160
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s1, #14
    s.addi       s26, s9, #960
    v.splat      v2, s15
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s16, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    s.addi       s9, s7, #12224
    v.st.w       [s21, #0], v5
    s.addi       s15, s1, #15
    v.splat      v1, s15
    v.ld.w       v4, [s22, #0]
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v5, [s16, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v0
    p.and        p4, p1, p2
    s.addi       s15, s7, #13312
    v.st.w       [s6, #0], v5
    s.addi       s6, s7, #0
    v.splat      v3, s3
    v.ld.w       v4, [s8, #0]
    s.addi       s8, s7, #10240
    s.movz       s21, #8
    v.splat      v5, s21
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s16, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v0
    p.and        p5, p1, p2
    v.st.w       [s11, #0], v6
    s.addi       s11, s15, #64
    v.ld.w       v2, [s24, #0]
    s.addi       s21, s7, #64
    s.addi       s22, s7, #10304
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s16, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v0
    p.and        p3, p1, p2
    v.st.w       [s25, #0], v4
    s.addi       s24, s15, #128
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s7, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v2, [s16, v1]              // index is in elements (ISA sec 9.1)
    v.st.w       [s2, #0], v2
    s.addi       s2, s7, #10368
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s7, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v2, [s16, v1]              // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v2
    s.addi       s4, s7, #10432
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s15, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s16, v1]              // index is in elements (ISA sec 9.1)
    s.addi       s16, s7, #256
    v.st.w       [s26, #0], v2
    fence.acq_rel.device
    s.addi       s25, s7, #10496
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s15, #256
    v.ld.w       v2, [s8, #0]
    v.mul        v4, v1, v5
    s.addi       s8, s7, #320
    v.add        v1, v4, v2
    v.add        v2, v3, v1
    v.st.w       [s15, #0], v2
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s7, #10560
    v.ld.w       v2, [s22, #0]
    v.mul        v4, v1, v5
    s.addi       s22, s15, #320
    v.add        v1, v4, v2
    v.add        v2, v3, v1
    v.st.w       [s11, #0], v2
    s.addi       s11, s7, #384
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s7, #10624
    v.ld.w       v2, [s2, #0]
    v.mul        v4, v1, v5
    s.addi       s2, s15, #384
    v.add        v1, v4, v2
    v.add        v2, v3, v1
    v.st.w       [s24, #0], v2
    s.addi       s24, s7, #448
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s7, #10688
    v.ld.w       v2, [s4, #0]
    v.mul        v4, v1, v5
    s.addi       s4, s15, #448
    v.add        v1, v4, v2
    v.add        v2, v3, v1
    v.st.w       [s9, #0], v2
    s.addi       s9, s7, #512
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s7, #10752
    v.ld.w       v2, [s25, #0]
    v.mul        v4, v1, v5
    s.addi       s25, s15, #512
    v.add        v1, v4, v2
    v.add        v2, v3, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s7, #576
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s7, #10816
    v.ld.w       v2, [s21, #0]
    v.mul        v4, v1, v5
    s.addi       s21, s15, #576
    v.add        v1, v4, v2
    v.add        v2, v3, v1
    v.st.w       [s22, #0], v2
    s.addi       s22, s7, #640
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s7, #10880
    v.ld.w       v2, [s12, #0]
    v.mul        v4, v1, v5
    s.addi       s12, s15, #640
    v.add        v1, v4, v2
    v.add        v2, v3, v1
    v.st.w       [s2, #0], v2
    s.addi       s2, s7, #704
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s7, #10944
    v.ld.w       v2, [s13, #0]
    v.mul        v4, v1, v5
    s.addi       s13, s15, #704
    v.add        v1, v4, v2
    v.add        v2, v3, v1
    v.st.w       [s4, #0], v2
    s.addi       s4, s7, #768
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s7, #11008
    v.ld.w       v2, [s16, #0]
    v.mul        v4, v1, v5
    s.addi       s16, s15, #768
    v.add        v1, v4, v2
    v.add        v2, v3, v1
    v.st.w       [s25, #0], v2
    s.addi       s25, s7, #832
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s7, #11072
    v.ld.w       v2, [s8, #0]
    v.mul        v4, v1, v5
    s.addi       s8, s15, #832
    v.add        v1, v4, v2
    v.add        v2, v3, v1
    v.st.w       [s21, #0], v2
    s.addi       s21, s7, #896
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s7, #11136
    v.ld.w       v2, [s11, #0]
    v.mul        v4, v1, v5
    s.addi       s11, s15, #896
    s.addi       s26, s15, #960
    v.add        v1, v4, v2
    v.add        v2, v3, v1
    v.st.w       [s12, #0], v2
    s.addi       s12, s7, #960
    v.splat      v1, s1
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s7, #11200
    v.cmp.lt     p2, v1, v0
    v.ld.w       v1, [s24, #0]
    v.mul        v4, v2, v5
    s.addi       s15, s7, #13312
    v.iota       v2                              // arange(0, VLEN)
    v.add        v6, v4, v1
    v.add        v1, v3, v6
    v.st.w       [s13, #0], v1
    s.movz       s13, #1
    v.splat      v1, s13
    // a computed 16x1 tile, into an accumulator (ISA sec 9B)
    s.movz       s13, #0
    v.cmp.lt     p3, v2, v1
    p.and        p4, p3, p2
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s7, #13376
    v.ld.w       v2, [s9, #0]
    v.mul        v4, v1, v5
    s.addi       s9, s1, #1
    v.splat      v1, s9
    s.movz       s9, #1
    v.add        v6, v4, v2
    v.cmp.lt     p2, v1, v0
    v.add        v1, v3, v6
    v.iota       v2                              // arange(0, VLEN)
    v.st.w       [s16, #0], v1
    s.movz       s16, #1
    v.splat      v1, s16
    v.cmp.lt     p3, v2, v1
    v.ld.w       v1, [s25, #0]
    p.and        p5, p3, p2
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v1, v5
    s.movz       s6, #2
    v.add        v1, v4, v2
    s.addi       s16, s7, #13440
    v.add        v2, v3, v1
    v.st.w       [s8, #0], v2
    s.addi       s8, s1, #2
    v.splat      v1, s8
    v.cmp.lt     p2, v1, v0
    v.ld.w       v1, [s21, #0]
    v.iota       v2                              // arange(0, VLEN)
    v.ld.w       v4, [s22, #0]
    v.mul        v6, v1, v5
    s.movz       s8, #1
    v.splat      v1, s8
    v.add        v7, v6, v4
    v.add        v4, v3, v7
    v.st.w       [s11, #0], v4
    s.addi       s8, s7, #13504
    s.movz       s11, #3
    v.ld.w       v4, [s12, #0]
    v.ld.w       v6, [s2, #0]
    v.mul        v7, v4, v5
    s.addi       s2, s1, #3
    v.splat      v4, s2
    v.add        v5, v7, v6
    v.iota       v6                              // arange(0, VLEN)
    v.add        v7, v3, v5
    s.movz       s2, #1
    v.st.w       [s26, #0], v7
    fence.acq_rel.device
    v.splat      v3, s2
    v.ld.w       v5, [s15, #0]
    s.addi       s2, s7, #13568
    s.addi       s12, s1, #4
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v8, s12
    s.movz       s12, #4
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s17, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v2, v1
    p.and        p4, p3, p2
    v.cmp.lt     p2, v4, v0
    s.movz       s15, #1
    a.vwrite     a3, s13, v9
    v.ld.w       v1, [s4, #0]
    v.splat      v2, s15
    s.addi       s4, s7, #13632
    s.addi       s13, s1, #5
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s13
    s.movz       s13, #5
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v3
    p.and        p5, p3, p2
    v.cmp.lt     p2, v8, v0
    s.movz       s15, #1
    a.vwrite     a3, s9, v9
    v.ld.w       v1, [s16, #0]
    v.splat      v3, s15
    s.addi       s9, s7, #13696
    s.addi       s15, s1, #6
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v8, s15
    s.movz       s15, #6
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v7, v2
    p.and        p4, p3, p2
    v.cmp.lt     p2, v5, v0
    s.movz       s16, #1
    a.vwrite     a3, s6, v9
    v.ld.w       v1, [s8, #0]
    v.splat      v2, s16
    s.addi       s6, s7, #13760
    s.addi       s8, s1, #7
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v7, s8
    s.movz       s8, #7
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    v.cmp.lt     p2, v8, v0
    s.movz       s16, #1
    a.vwrite     a3, s11, v9
    v.ld.w       v1, [s2, #0]
    v.splat      v3, s16
    s.addi       s2, s7, #13824
    s.addi       s11, s1, #8
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v8, s11
    s.movz       s11, #8
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v2
    p.and        p4, p3, p2
    v.cmp.lt     p2, v7, v0
    s.movz       s16, #1
    a.vwrite     a3, s12, v9
    v.ld.w       v1, [s4, #0]
    v.splat      v2, s16
    s.addi       s4, s7, #13888
    s.addi       s12, s1, #9
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v7, s12
    s.movz       s12, #9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    v.cmp.lt     p2, v8, v0
    s.movz       s16, #1
    a.vwrite     a3, s13, v9
    v.ld.w       v1, [s9, #0]
    v.splat      v3, s16
    s.addi       s9, s7, #13952
    s.addi       s13, s1, #10
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v8, s13
    s.movz       s13, #10
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v4, v2
    p.and        p4, p3, p2
    v.cmp.lt     p2, v7, v0
    s.movz       s16, #1
    a.vwrite     a3, s15, v9
    v.ld.w       v1, [s6, #0]
    v.splat      v2, s16
    s.addi       s6, s7, #14016
    s.addi       s15, s1, #11
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v7, s15
    s.movz       s15, #11
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v3
    p.and        p5, p3, p2
    v.cmp.lt     p2, v8, v0
    s.movz       s16, #1
    a.vwrite     a3, s8, v9
    v.ld.w       v1, [s2, #0]
    v.splat      v3, s16
    s.addi       s2, s7, #14080
    s.addi       s8, s1, #12
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v8, s8
    s.movz       s8, #12
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v5, v2
    p.and        p4, p3, p2
    v.cmp.lt     p2, v7, v0
    s.movz       s16, #1
    a.vwrite     a3, s11, v9
    v.ld.w       v1, [s4, #0]
    v.splat      v2, s16
    s.addi       s4, s7, #14144
    s.addi       s11, s1, #13
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v7, s11
    s.movz       s11, #13
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    v.cmp.lt     p2, v8, v0
    s.movz       s16, #1
    a.vwrite     a3, s12, v9
    v.ld.w       v1, [s9, #0]
    v.splat      v3, s16
    s.addi       s9, s7, #14208
    s.addi       s12, s1, #14
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v8, s12
    s.movz       s12, #14
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v2
    p.and        p4, p3, p2
    v.cmp.lt     p2, v7, v0
    s.movz       s16, #1
    a.vwrite     a3, s13, v9
    v.ld.w       v1, [s6, #0]
    v.splat      v2, s16
    s.addi       s6, s7, #14272
    s.addi       s13, s1, #15
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v7, s13
    s.movz       s13, #15
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    v.cmp.lt     p2, v8, v0
    s.movz       s16, #1
    a.vwrite     a3, s15, v9
    v.ld.w       v1, [s2, #0]
    v.splat      v3, s16
    s.addi       s2, s7, #10240
    s.addi       s15, s7, #5120
    s.movz       s16, #10368
    v.splat      v5, s3
    s.addi       s21, s7, #14336
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v4, v2
    p.and        p4, p3, p2
    v.cmp.lt     p2, v7, v0
    v.splat      v1, s16
    a.vwrite     a3, s8, v8
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s7, #10304
    s.addi       s8, s7, #5184
    s.addi       s16, s21, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s17, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v3
    p.and        p5, p3, p2
    a.vwrite     a3, s11, v4
    v.ld.w       v2, [s9, #0]
    s.addi       s9, s7, #10368
    s.addi       s11, s7, #5248
    s.addi       s22, s21, #128
    s.addi       s24, s7, #5312
    s.addi       s25, s21, #192
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s17, v2]              // index is in elements (ISA sec 9.1)
    a.vwrite     a3, s12, v3
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s7, #10432
    s.addi       s12, s7, #10496
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v3, [s17, v2]              // index is in elements (ISA sec 9.1)
    s.addi       s17, s7, #5376
    a.vwrite     a3, s13, v3
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s21, #256
    s.addi       s13, s7, #5440
    v.ld.w       v3, [s15, #0]
    v.mul        v4, v2, v1
    s.addi       s15, s7, #10560
    v.add        v2, v3, v4
    v.add        v3, v5, v2
    v.st.w       [s21, #0], v3
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s21, #320
    v.ld.w       v3, [s8, #0]
    v.mul        v4, v2, v1
    s.addi       s8, s7, #10624
    v.add        v2, v3, v4
    v.add        v3, v5, v2
    v.st.w       [s16, #0], v3
    s.addi       s16, s7, #5504
    v.ld.w       v2, [s9, #0]
    s.addi       s9, s21, #384
    v.ld.w       v3, [s11, #0]
    v.mul        v4, v2, v1
    s.addi       s11, s7, #10688
    v.add        v2, v3, v4
    v.add        v3, v5, v2
    v.st.w       [s22, #0], v3
    s.addi       s22, s7, #5568
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s21, #448
    v.ld.w       v3, [s24, #0]
    v.mul        v4, v2, v1
    s.addi       s24, s7, #10752
    v.add        v2, v3, v4
    v.add        v3, v5, v2
    v.st.w       [s25, #0], v3
    s.addi       s25, s7, #5632
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s21, #512
    v.ld.w       v3, [s17, #0]
    v.mul        v4, v2, v1
    s.addi       s17, s7, #10816
    v.add        v2, v3, v4
    v.add        v3, v5, v2
    v.st.w       [s2, #0], v3
    s.addi       s2, s7, #5696
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s21, #576
    v.ld.w       v3, [s13, #0]
    v.mul        v4, v2, v1
    s.addi       s13, s7, #10880
    v.add        v2, v3, v4
    v.add        v3, v5, v2
    v.st.w       [s4, #0], v3
    s.addi       s4, s7, #5760
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s21, #640
    v.ld.w       v3, [s16, #0]
    v.mul        v4, v2, v1
    s.addi       s16, s7, #10944
    v.add        v2, v3, v4
    v.add        v3, v5, v2
    v.st.w       [s9, #0], v3
    s.addi       s9, s7, #5824
    v.ld.w       v2, [s11, #0]
    s.addi       s11, s21, #704
    v.ld.w       v3, [s22, #0]
    v.mul        v4, v2, v1
    s.addi       s22, s7, #11008
    v.add        v2, v3, v4
    v.add        v3, v5, v2
    v.st.w       [s6, #0], v3
    s.addi       s6, s7, #5888
    v.ld.w       v2, [s24, #0]
    s.addi       s24, s21, #768
    v.ld.w       v3, [s25, #0]
    v.mul        v4, v2, v1
    s.addi       s25, s7, #11072
    v.add        v2, v3, v4
    v.add        v3, v5, v2
    v.st.w       [s12, #0], v3
    s.addi       s12, s7, #5952
    v.ld.w       v2, [s17, #0]
    s.addi       s17, s21, #832
    v.ld.w       v3, [s2, #0]
    v.mul        v4, v2, v1
    s.addi       s2, s7, #11136
    v.add        v2, v3, v4
    v.add        v3, v5, v2
    v.st.w       [s15, #0], v3
    s.addi       s15, s7, #6016
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s21, #896
    s.addi       s26, s21, #960
    v.ld.w       v3, [s4, #0]
    v.mul        v4, v2, v1
    s.addi       s4, s7, #11200
    v.add        v2, v3, v4
    v.add        v3, v5, v2
    v.st.w       [s8, #0], v3
    s.addi       s8, s7, #6080
    v.splat      v2, s1
    v.ld.w       v3, [s16, #0]
    s.addi       s16, s7, #14336
    v.ld.w       v4, [s9, #0]
    v.mul        v6, v3, v1
    v.cmp.lt     p2, v2, v0
    p.and        p3, p1, p2
    s.addi       s9, s7, #15360
    v.add        v2, v4, v6
    v.add        v3, v5, v2
    v.st.w       [s11, #0], v3
    s.addi       s11, s7, #14400
    v.ld.w       v2, [s22, #0]
    s.addi       s21, s1, #1
    v.splat      v3, s21
    s.addi       s21, s9, #64
    v.ld.w       v4, [s6, #0]
    v.mul        v6, v2, v1
    v.cmp.lt     p2, v3, v0
    p.and        p4, p1, p2
    v.add        v2, v4, v6
    s.addi       s6, s9, #128
    v.add        v3, v5, v2
    v.st.w       [s24, #0], v3
    s.addi       s22, s7, #14464
    v.ld.w       v2, [s25, #0]
    s.addi       s24, s1, #2
    v.splat      v3, s24
    v.ld.w       v4, [s12, #0]
    v.mul        v6, v2, v1
    v.cmp.lt     p2, v3, v0
    p.and        p5, p1, p2
    v.add        v2, v4, v6
    s.addi       s12, s9, #192
    v.add        v3, v5, v2
    s.addi       s24, s7, #14528
    v.st.w       [s17, #0], v3
    s.addi       s17, s1, #3
    v.splat      v2, s17
    v.ld.w       v3, [s2, #0]
    v.ld.w       v4, [s15, #0]
    v.mul        v6, v3, v1
    v.add        v3, v4, v6
    s.addi       s2, s9, #256
    v.add        v4, v5, v3
    s.addi       s15, s7, #14592
    v.st.w       [s13, #0], v4
    s.addi       s13, s1, #4
    v.splat      v3, s13
    v.ld.w       v4, [s4, #0]
    v.ld.w       v6, [s8, #0]
    v.mul        v7, v4, v1
    v.add        v4, v6, v7
    s.addi       s4, s9, #320
    v.add        v6, v5, v4
    s.addi       s8, s7, #14656
    v.st.w       [s26, #0], v6
    fence.acq_rel.device
    s.addi       s13, s1, #5
    v.splat      v4, s13
    v.ld.w       v5, [s16, #0]
    s.addi       s13, s9, #384
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s18, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v0
    p.and        p3, p1, p2
    s.addi       s16, s7, #14720
    v.st.w       [s9, #0], v6
    s.addi       s17, s1, #6
    v.splat      v2, s17
    v.ld.w       v5, [s11, #0]
    s.addi       s11, s9, #448
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s18, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v0
    p.and        p4, p1, p2
    s.addi       s17, s7, #14784
    v.st.w       [s21, #0], v6
    s.addi       s21, s1, #7
    v.splat      v3, s21
    v.ld.w       v5, [s22, #0]
    s.addi       s21, s9, #512
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s18, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    s.addi       s22, s7, #14848
    v.st.w       [s6, #0], v6
    s.addi       s6, s1, #8
    v.splat      v4, s6
    v.ld.w       v5, [s24, #0]
    s.addi       s6, s9, #576
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s18, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v0
    p.and        p3, p1, p2
    s.addi       s24, s7, #14912
    v.st.w       [s12, #0], v6
    s.addi       s12, s1, #9
    v.splat      v2, s12
    v.ld.w       v5, [s15, #0]
    s.addi       s12, s9, #640
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s18, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v0
    p.and        p4, p1, p2
    s.addi       s15, s7, #14976
    v.st.w       [s2, #0], v6
    s.addi       s2, s1, #10
    v.splat      v3, s2
    v.ld.w       v5, [s8, #0]
    s.addi       s2, s9, #704
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s18, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    s.addi       s8, s7, #15040
    v.st.w       [s4, #0], v6
    s.addi       s4, s1, #11
    v.splat      v4, s4
    v.ld.w       v5, [s16, #0]
    s.addi       s4, s9, #768
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s18, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v0
    p.and        p3, p1, p2
    s.addi       s16, s7, #15104
    v.st.w       [s13, #0], v6
    s.addi       s13, s1, #12
    v.splat      v2, s13
    v.ld.w       v5, [s17, #0]
    s.addi       s13, s9, #832
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s18, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v0
    p.and        p4, p1, p2
    s.addi       s17, s7, #15168
    v.st.w       [s11, #0], v6
    s.addi       s11, s1, #13
    v.splat      v3, s11
    v.ld.w       v5, [s22, #0]
    s.addi       s11, s9, #896
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v6, [s18, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    s.addi       s22, s7, #15232
    v.st.w       [s21, #0], v6
    s.addi       s21, s1, #14
    v.splat      v4, s21
    v.ld.w       v5, [s24, #0]
    s.addi       s21, s9, #960
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s18, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v0
    p.and        p3, p1, p2
    s.addi       s9, s7, #15296
    v.st.w       [s6, #0], v6
    s.addi       s6, s1, #15
    v.splat      v2, s6
    v.ld.w       v5, [s15, #0]
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v6, [s18, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v0
    p.and        p4, p1, p2
    .li       s6, #1124073472
    v.splat      v3, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s12, #0], v6
    .li       s6, #1124073472
    v.splat      v5, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s6, #897988541
    v.splat      v6, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s6, #1050163184
    v.splat      v7, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v8, [s8, #0]
    .li       s6, #897988541
    v.splat      v9, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s6, #1050163184
    v.splat      v10, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.h v11, [s18, v8]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    s.addi       s8, s7, #12288
    v.st.w       [s2, #0], v11
    s.movz       s2, #0
    v.ld.w       v4, [s16, #0]
    v.rcp.approx v8, v5                          // ISA 8.8: <= 2**-22 relative
    .li       s12, #1065353216
    v.splat      v11, s12                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v12, [s18, v4]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v0
    p.and        p3, p1, p2
    v.st.w       [s4, #0], v12
    v.ld.w       v2, [s17, #0]
    vf.fms       v4, v5, v8, v11
    vf.fms       v12, v8, v4, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s18, v2]              // index is in elements (ISA sec 9.1)
    vf.neg       v2, v12                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v2, v2
    v.st.w       [s13, #0], v4
    @p2 v.sel        v4, v2, v8
    .li       s4, #1077936128
    v.splat      v2, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v8, [s22, #0]
    .li       s4, #3204448256
    v.splat      v12, s4                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.h v13, [s18, v8]             // index is in elements (ISA sec 9.1)
    v.st.w       [s11, #0], v13
    v.ld.w       v8, [s9, #0]
    s.movz       s4, #0
    s.addi       s9, s7, #15360
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v13, [s18, v8]             // index is in elements (ISA sec 9.1)
    v.st.w       [s21, #0], v13
    fence.acq_rel.device
    s.movz       s11, #0
    s.movz       s12, #1
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v8, [s14, #0]
    v.ld.w       v13, [s8, #0]
    a.vread      v14, a3, s2
    a.vread      v15, a1, s4
    vf.mul       v16, v14, v4                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v17, v8
    s.addi       s2, s7, #12352
    vf.fms       v8, v16, v5, v14
    v.ld.w       v14, [s9, #0]
    vf.fms       v18, v8, v4, v16
    vf.cvt.bf16.f32 v4, v13
    v.rcp.approx v8, v5                          // ISA 8.8: <= 2**-22 relative
    a.vread      v13, a2, s11
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    s.movz       s4, #1
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v16
    vf.cvt.bf16.f32 v16, v14
    vf.add       v14, v18, v9
    vf.mul       v18, v16, v13
    v.rsqrt.approx v13, v14                      // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v5, v8, v11
    vf.fms       v19, v8, v16, v8
    vf.neg       v16, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v16, v16
    vf.mul       v19, v13, v13
    @p2 v.sel        v20, v16, v8
    vf.mul       v8, v13, v12
    vf.fms       v16, v14, v19, v2
    vf.mul       v14, v8, v16                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v14, v14
    @p2 v.sel        v8, v14, v13
    v.extract    s8, v8, #0
    v.splat      v8, s8
    s.movz       s8, #1
    vf.mul       v13, v4, v8
    vf.mul       v4, v17, v13
    s.addi       s9, s7, #15424
    vf.mul       v8, v4, v15
    s.movz       s11, #1
    s.movz       s13, #2
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s6, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s6, s7, #12416
    v.ld.w       v8, [s2, #0]
    a.vread      v13, a3, s4
    a.vread      v14, a1, s8
    vf.mul       v15, v13, v20                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #2
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s9, #0]
    vf.fms       v18, v17, v20, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s11
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #2
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s8, s7, #15488
    vf.mul       v8, v4, v14
    s.movz       s9, #2
    s.movz       s11, #3
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s12, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s12, s7, #12480
    v.ld.w       v8, [s6, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #3
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s8, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s9
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #3
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #15552
    vf.mul       v8, v4, v14
    s.movz       s8, #3
    s.movz       s9, #4
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s13, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s13, s7, #12544
    v.ld.w       v8, [s12, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #4
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s6, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s8
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #4
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #15616
    vf.mul       v8, v4, v14
    s.movz       s8, #4
    s.movz       s12, #5
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s11, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s11, s7, #12608
    v.ld.w       v8, [s13, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #5
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s6, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s8
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #5
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #15680
    vf.mul       v8, v4, v14
    s.movz       s8, #5
    s.movz       s13, #6
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s9, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s9, s7, #12672
    v.ld.w       v8, [s11, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #6
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s6, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s8
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #6
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #15744
    vf.mul       v8, v4, v14
    s.movz       s8, #6
    s.movz       s11, #7
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s12, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s12, s7, #12736
    v.ld.w       v8, [s9, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #7
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s6, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s8
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #7
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #15808
    vf.mul       v8, v4, v14
    s.movz       s8, #7
    s.movz       s9, #8
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s13, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s13, s7, #12800
    v.ld.w       v8, [s12, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #8
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s6, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s8
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #8
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #15872
    vf.mul       v8, v4, v14
    s.movz       s8, #8
    s.movz       s12, #9
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s11, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s11, s7, #12864
    v.ld.w       v8, [s13, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #9
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s6, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s8
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #9
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #15936
    vf.mul       v8, v4, v14
    s.movz       s8, #9
    s.movz       s13, #10
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s9, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s9, s7, #12928
    v.ld.w       v8, [s11, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #10
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s6, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s8
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #10
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #16000
    vf.mul       v8, v4, v14
    s.movz       s8, #10
    s.movz       s11, #11
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s12, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s12, s7, #12992
    v.ld.w       v8, [s9, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #11
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s6, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s8
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #11
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #16064
    vf.mul       v8, v4, v14
    s.movz       s8, #11
    s.movz       s9, #12
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s13, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s13, s7, #13056
    v.ld.w       v8, [s12, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #12
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s6, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s8
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #12
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #16128
    vf.mul       v8, v4, v14
    s.movz       s8, #12
    s.movz       s12, #13
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s11, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s11, s7, #13120
    v.ld.w       v8, [s13, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #13
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s6, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s8
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #13
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #16192
    vf.mul       v8, v4, v14
    s.movz       s8, #13
    s.movz       s13, #14
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s9, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s9, s7, #13184
    v.ld.w       v8, [s11, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #14
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s6, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s8
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #14
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #16256
    vf.mul       v8, v4, v14
    s.movz       s8, #14
    s.movz       s11, #15
    vf.add       v4, v8, v18
    vf.mul       v8, v4, v10
    a.vwrite     a4, s12, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.addi       s12, s7, #13248
    v.ld.w       v8, [s9, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    v.rcp.approx v4, v5                          // ISA 8.8: <= 2**-22 relative
    s.movz       s2, #15
    vf.fms       v17, v15, v5, v13
    v.ld.w       v13, [s6, #0]
    vf.fms       v18, v17, v19, v15
    vf.cvt.bf16.f32 v17, v8
    a.vread      v8, a2, s8
    vf.neg       v19, v18                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v19, v19
    @p2 v.sel        v18, v19, v15
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v18, v9
    vf.mul       v18, v15, v8
    v.rsqrt.approx v8, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v5, v4, v11
    vf.fms       v19, v4, v15, v4
    vf.neg       v15, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v19, v15, v4
    vf.mul       v4, v8, v8
    vf.mul       v15, v8, v12
    vf.fms       v20, v13, v4, v2
    vf.mul       v4, v15, v20                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v13, v4, v8
    v.extract    s4, v13, #0
    v.splat      v4, s4
    s.movz       s4, #15
    vf.mul       v8, v17, v4
    vf.mul       v4, v16, v8
    s.addi       s6, s7, #16320
    vf.mul       v8, v4, v14
    s.movz       s8, #15
    s.muli       s9, s10, #4                     // a runtime tile origin, x4
    vf.add       v4, v8, v18
    s.add        s15, s19, s9                    // the tile origin
    vf.mul       v8, v4, v10
    s.muli       s9, s5, #512                    // a runtime tile origin, x512
    a.vwrite     a4, s13, v8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    s.add        s5, s15, s9                     // the tile origin
    v.ld.w       v8, [s12, #0]
    a.vread      v13, a3, s2
    a.vread      v14, a1, s4
    vf.mul       v15, v13, v19                   // a/y: faithful quotient
    vf.cvt.bf16.f32 v16, v4
    s.addi       s2, s7, #3072
    vf.fms       v4, v15, v5, v13
    v.ld.w       v5, [s6, #0]
    vf.fms       v13, v4, v19, v15
    vf.cvt.bf16.f32 v4, v8
    v.rcp.approx v8, v3                          // ISA 8.8: <= 2**-22 relative
    a.vread      v17, a2, s8
    vf.neg       v18, v13                        // a/y: one correction to the IEEE quotient
    s.movz       s4, #0
    vf.cmp.o     p2, v18, v18
    @p2 v.sel        v13, v18, v15
    vf.cvt.bf16.f32 v15, v5
    vf.add       v5, v13, v9
    vf.mul       v9, v15, v17
    v.rsqrt.approx v13, v5                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v8, v11
    vf.fms       v17, v8, v15, v8
    vf.neg       v15, v17                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    vf.mul       v17, v13, v13
    vf.mul       v18, v13, v12
    @p2 v.sel        v19, v15, v8
    vf.fms       v8, v5, v17, v2
    vf.mul       v5, v18, v8                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v5, v5
    @p2 v.sel        v8, v5, v13
    v.extract    s6, v8, #0
    v.splat      v5, s6
    vf.mul       v8, v4, v5
    vf.mul       v4, v16, v8
    s.movz       s6, #0
    vf.mul       v5, v4, v14
    v.splat      v4, s1
    s.movz       s8, #0
    v.cmp.lt     p2, v4, v0
    vf.add       v4, v5, v9
    p.and        p3, p1, p2
    vf.mul       v5, v4, v10
    a.vwrite     a4, s11, v5
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s1
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    v.ld.w       v5, [s2, #0]
    a.vread      v8, a0, s4
    a.vread      v9, a1, s6
    vf.mul       v10, v8, v19                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v13, v4
    s.addi       s2, s7, #3136
    vf.fms       v4, v10, v3, v8
    vf.cvt.bf16.f32 v8, v5
    vf.fms       v5, v4, v19, v10
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v14, [s23, #0]
    a.vread      v15, a2, s8
    vf.neg       v16, v5                         // a/y: one correction to the IEEE quotient
    s.movz       s4, #1
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v5, v16, v10
    vf.cvt.bf16.f32 v10, v14
    vf.add       v14, v5, v6
    vf.mul       v5, v10, v15
    v.rsqrt.approx v10, v14                      // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v10, v10
    vf.mul       v15, v10, v12
    vf.fms       v17, v14, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v14, v4, v10
    v.extract    s6, v14, #0
    v.splat      v4, s6
    vf.mul       v10, v8, v4
    vf.mul       v4, v13, v10
    s.movz       s6, #1
    vf.mul       v8, v4, v9
    s.addi       s8, s1, #1
    s.addi       s9, s23, #256                   // row 1
    v.splat      v4, s8
    vf.add       v9, v8, v5
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    s.movz       s8, #1
    vf.mul       v4, v9, v7
    s.addi       s11, s5, #512                   // row 1
    @p4 v.st.w       [s5, #0], v4
    s.addi       s12, s1, #1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s12
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s6
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s9, #0]
    a.vread      v15, a2, s8
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3200
    s.movz       s4, #2
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #2
    s.movz       s8, #2
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #512                   // row 2
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #2
    s.addi       s12, s5, #1024                  // row 2
    @p4 v.st.w       [s11, #0], v4
    s.addi       s11, s1, #2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s11
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3264
    s.movz       s4, #3
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #3
    s.movz       s8, #3
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #768                   // row 3
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #3
    s.addi       s11, s5, #1536                  // row 3
    @p4 v.st.w       [s12, #0], v4
    s.addi       s12, s1, #3
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s12
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3328
    s.movz       s4, #4
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #4
    s.movz       s8, #4
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #1024                  // row 4
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #4
    s.addi       s12, s5, #2048                  // row 4
    @p4 v.st.w       [s11, #0], v4
    s.addi       s11, s1, #4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s11
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3392
    s.movz       s4, #5
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #5
    s.movz       s8, #5
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #1280                  // row 5
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #5
    s.addi       s11, s5, #2560                  // row 5
    @p4 v.st.w       [s12, #0], v4
    s.addi       s12, s1, #5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s12
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3456
    s.movz       s4, #6
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #6
    s.movz       s8, #6
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #1536                  // row 6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #6
    s.addi       s12, s5, #3072                  // row 6
    @p4 v.st.w       [s11, #0], v4
    s.addi       s11, s1, #6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s11
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3520
    s.movz       s4, #7
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #7
    s.movz       s8, #7
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #1792                  // row 7
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #7
    s.addi       s11, s5, #3584                  // row 7
    @p4 v.st.w       [s12, #0], v4
    s.addi       s12, s1, #7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s12
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3584
    s.movz       s4, #8
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #8
    s.movz       s8, #8
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #2048                  // row 8
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #8
    s.addi       s12, s5, #4096                  // row 8
    @p4 v.st.w       [s11, #0], v4
    s.addi       s11, s1, #8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s11
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3648
    s.movz       s4, #9
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #9
    s.movz       s8, #9
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #2304                  // row 9
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #9
    s.addi       s11, s5, #4608                  // row 9
    @p4 v.st.w       [s12, #0], v4
    s.addi       s12, s1, #9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s12
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3712
    s.movz       s4, #10
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #10
    s.movz       s8, #10
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #2560                  // row 10
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #10
    s.addi       s12, s5, #5120                  // row 10
    @p4 v.st.w       [s11, #0], v4
    s.addi       s11, s1, #10
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s11
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3776
    s.movz       s4, #11
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #11
    s.movz       s8, #11
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #2816                  // row 11
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #11
    s.addi       s11, s5, #5632                  // row 11
    @p4 v.st.w       [s12, #0], v4
    s.addi       s12, s1, #11
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s12
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3840
    s.movz       s4, #12
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #12
    s.movz       s8, #12
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #3072                  // row 12
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #12
    s.addi       s12, s5, #6144                  // row 12
    @p4 v.st.w       [s11, #0], v4
    s.addi       s11, s1, #12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s11
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3904
    s.movz       s4, #13
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #13
    s.movz       s8, #13
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #3328                  // row 13
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #13
    s.addi       s11, s5, #6656                  // row 13
    @p4 v.st.w       [s12, #0], v4
    s.addi       s12, s1, #13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s12
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #3968
    s.movz       s4, #14
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v16, v4, v15, v4
    vf.neg       v15, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v16, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v17, v9, v4, v2
    vf.mul       v4, v15, v17                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #14
    s.movz       s8, #14
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #3584                  // row 14
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #14
    s.addi       s12, s5, #7168                  // row 14
    @p4 v.st.w       [s11, #0], v4
    s.addi       s11, s1, #14
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s11
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v16                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v5, v8
    vf.fms       v8, v4, v16, v13
    v.rcp.approx v4, v3                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s6, #0]
    a.vread      v15, a2, s9
    vf.neg       v16, v8                         // a/y: one correction to the IEEE quotient
    s.addi       s2, s7, #4032
    s.movz       s4, #15
    vf.cmp.o     p2, v16, v16
    @p2 v.sel        v8, v16, v13
    vf.cvt.bf16.f32 v13, v9
    vf.add       v9, v8, v6
    vf.mul       v8, v13, v15
    v.rsqrt.approx v13, v9                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v4, v11
    vf.fms       v11, v4, v15, v4
    vf.neg       v15, v11                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v15, v15
    @p2 v.sel        v11, v15, v4
    vf.mul       v4, v13, v13
    vf.mul       v15, v13, v12
    vf.fms       v16, v9, v4, v2
    vf.mul       v4, v15, v16                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v9, v4, v13
    v.extract    s6, v9, #0
    v.splat      v4, s6
    vf.mul       v9, v5, v4
    vf.mul       v4, v14, v9
    vf.mul       v5, v4, v10
    s.addi       s6, s1, #15
    s.movz       s8, #15
    v.splat      v4, s6
    vf.add       v9, v5, v8
    v.cmp.lt     p2, v4, v0
    s.addi       s6, s23, #3840                  // row 15
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.movz       s9, #15
    s.addi       s11, s5, #7680                  // row 15
    @p4 v.st.w       [s12, #0], v4
    s.addi       s5, s1, #15
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s27, #0]
    v.splat      v5, s5
    v.ld.w       v8, [s2, #0]
    a.vread      v9, a0, s4
    a.vread      v10, a1, s8
    vf.mul       v13, v9, v11                    // a/y: faithful quotient
    vf.cvt.bf16.f32 v14, v4
    v.cmp.lt     p2, v5, v0
    p.and        p4, p1, p2
    vf.fms       v4, v13, v3, v9
    vf.cvt.bf16.f32 v3, v8
    vf.fms       v5, v4, v11, v13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s6, #0]
    a.vread      v8, a2, s9
    s.addi       s2, s7, #0
    vf.neg       v9, v5                          // a/y: one correction to the IEEE quotient
    s.muli       s4, s10, #81                    // a runtime tile origin, x81
    s.movz       s5, #0
    vf.cvt.bf16.f32 v5, v4
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v4, v9, v13
    s.addi       s6, s7, #1024
    vf.add       v9, v4, v6
    vf.mul       v4, v5, v8
    s.movz       s8, #81
    s.add        s9, s5, s4                      // the tile origin
    v.rsqrt.approx v5, v9                        // ISA 8.8: <= 2**-22 relative
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v8, s8
    v.splat      v11, s9
    v.mul        v13, v6, v8
    v.splat      v6, s3
    v.add        v8, v13, v11
    s.addi       s3, s7, #16384
    vf.mul       v11, v5, v5
    vf.mul       v13, v5, v12
    vf.fms       v12, v9, v11, v2
    vf.mul       v2, v13, v12                    // Newton step: 0.5*r0*(3 - x*r0^2)
    s.addi       s4, s3, #64
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v9, v2, v5
    s.addi       s5, s7, #64
    v.extract    s8, v9, #0
    v.splat      v2, s8
    s.addi       s8, s7, #1088
    vf.mul       v5, v3, v2
    vf.mul       v2, v14, v5
    vf.mul       v3, v2, v10
    s.addi       s9, s7, #128
    s.addi       s10, s7, #1152
    s.addi       s12, s3, #128
    vf.add       v2, v3, v4
    s.addi       s13, s3, #192
    vf.mul       v3, v2, v7
    s.addi       s14, s7, #192
    s.addi       s15, s7, #1216
    @p4 v.st.w       [s11, #0], v3
    s.addi       s11, s3, #256
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s7, #256
    s.addi       s16, s7, #1280
    s.addi       s17, s3, #320
    v.ld.w       v3, [s6, #0]
    v.add        v4, v2, v8
    s.addi       s6, s7, #320
    v.mul        v2, v3, v1
    s.addi       s18, s7, #1344
    v.add        v3, v4, v2
    v.add        v2, v6, v3
    v.st.w       [s3, #0], v2
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s3, #384
    v.ld.w       v3, [s8, #0]
    v.add        v4, v2, v8
    s.addi       s8, s7, #384
    v.mul        v2, v3, v1
    s.addi       s19, s7, #1408
    v.add        v3, v4, v2
    v.add        v2, v6, v3
    v.st.w       [s4, #0], v2
    v.ld.w       v2, [s9, #0]
    s.addi       s4, s3, #448
    v.ld.w       v3, [s10, #0]
    v.add        v4, v2, v8
    s.addi       s9, s7, #448
    v.mul        v2, v3, v1
    s.addi       s10, s7, #1472
    v.add        v3, v4, v2
    v.add        v2, v6, v3
    v.st.w       [s12, #0], v2
    v.ld.w       v2, [s14, #0]
    s.addi       s12, s3, #512
    v.ld.w       v3, [s15, #0]
    v.add        v4, v2, v8
    s.addi       s14, s7, #512
    v.mul        v2, v3, v1
    s.addi       s15, s7, #1536
    v.add        v3, v4, v2
    v.add        v2, v6, v3
    v.st.w       [s13, #0], v2
    v.ld.w       v2, [s2, #0]
    s.addi       s2, s3, #576
    v.ld.w       v3, [s16, #0]
    v.add        v4, v2, v8
    s.addi       s13, s7, #576
    v.mul        v2, v3, v1
    s.addi       s16, s7, #1600
    v.add        v3, v4, v2
    v.add        v2, v6, v3
    v.st.w       [s11, #0], v2
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s3, #640
    v.ld.w       v3, [s18, #0]
    v.add        v4, v2, v8
    s.addi       s11, s7, #640
    v.mul        v2, v3, v1
    s.addi       s18, s7, #1664
    v.add        v3, v4, v2
    v.add        v2, v6, v3
    v.st.w       [s17, #0], v2
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s3, #704
    v.ld.w       v3, [s19, #0]
    v.add        v4, v2, v8
    s.addi       s17, s7, #704
    v.mul        v2, v3, v1
    s.addi       s19, s7, #1728
    v.add        v3, v4, v2
    v.add        v2, v6, v3
    v.st.w       [s5, #0], v2
    v.ld.w       v2, [s9, #0]
    s.addi       s5, s3, #768
    v.ld.w       v3, [s10, #0]
    v.add        v4, v2, v8
    s.addi       s9, s7, #768
    v.mul        v2, v3, v1
    s.addi       s10, s7, #1792
    v.add        v3, v4, v2
    v.add        v2, v6, v3
    v.st.w       [s4, #0], v2
    v.ld.w       v2, [s14, #0]
    s.addi       s4, s3, #832
    v.ld.w       v3, [s15, #0]
    v.add        v4, v2, v8
    s.addi       s14, s7, #832
    v.mul        v2, v3, v1
    s.addi       s15, s7, #1856
    v.add        v3, v4, v2
    v.add        v2, v6, v3
    v.st.w       [s12, #0], v2
    v.ld.w       v2, [s13, #0]
    s.addi       s12, s3, #896
    v.ld.w       v3, [s16, #0]
    v.add        v4, v2, v8
    s.addi       s13, s7, #896
    v.mul        v2, v3, v1
    s.addi       s16, s7, #1920
    v.add        v3, v4, v2
    v.add        v2, v6, v3
    v.st.w       [s2, #0], v2
    v.ld.w       v2, [s11, #0]
    s.addi       s2, s3, #960
    v.ld.w       v3, [s18, #0]
    v.add        v4, v2, v8
    s.addi       s3, s7, #960
    v.mul        v2, v3, v1
    s.addi       s11, s7, #1984
    v.add        v3, v4, v2
    v.add        v2, v6, v3
    v.st.w       [s6, #0], v2
    v.ld.w       v2, [s17, #0]
    v.ld.w       v3, [s19, #0]
    v.add        v4, v2, v8
    s.movz       s6, #0
    s.addi       s17, s7, #16384
    v.mul        v2, v3, v1
    v.add        v3, v4, v2
    v.splat      v2, s1
    v.add        v4, v6, v3
    v.cmp.lt     p2, v2, v0
    v.st.w       [s8, #0], v4
    p.and        p3, p1, p2
    s.movz       s8, #1
    v.ld.w       v2, [s9, #0]
    v.ld.w       v3, [s10, #0]
    v.add        v4, v2, v8
    s.addi       s9, s7, #16448
    s.addi       s10, s1, #1
    v.mul        v2, v3, v1
    v.splat      v3, s10
    v.add        v5, v4, v2
    v.cmp.lt     p2, v3, v0
    v.add        v2, v6, v5
    p.and        p4, p1, p2
    v.st.w       [s5, #0], v2
    s.movz       s5, #2
    v.ld.w       v2, [s14, #0]
    s.addi       s10, s7, #16512
    v.ld.w       v3, [s15, #0]
    v.add        v4, v2, v8
    s.addi       s14, s1, #2
    v.splat      v2, s14
    v.mul        v5, v3, v1
    v.cmp.lt     p2, v2, v0
    v.add        v2, v4, v5
    p.and        p5, p1, p2
    v.add        v3, v6, v2
    v.st.w       [s4, #0], v3
    s.movz       s4, #3
    s.addi       s14, s7, #16576
    v.ld.w       v2, [s13, #0]
    v.ld.w       v3, [s16, #0]
    v.add        v4, v2, v8
    s.addi       s13, s1, #3
    v.splat      v2, s13
    v.mul        v5, v3, v1
    v.add        v3, v4, v5
    v.add        v4, v6, v3
    s.movz       s13, #4
    v.st.w       [s12, #0], v4
    s.addi       s12, s7, #16640
    v.ld.w       v3, [s3, #0]
    s.addi       s3, s1, #4
    v.ld.w       v4, [s11, #0]
    v.add        v5, v3, v8
    v.splat      v3, s3
    v.mul        v7, v4, v1
    v.add        v1, v5, v7
    s.movz       s3, #5
    v.add        v4, v6, v1
    v.st.w       [s2, #0], v4
    fence.acq_rel.device
    a.vread      v1, a4, s6
    s.addi       s2, s7, #16704
    s.addi       s6, s1, #5
    v.splat      v4, s6
    v.ld.w       v5, [s17, #0]
    s.movz       s6, #6
    @p3 v.st.scatter.w [s20, v5], v1
    a.vread      v1, a4, s8
    v.cmp.lt     p2, v2, v0
    p.and        p3, p1, p2
    s.addi       s8, s7, #16768
    s.addi       s11, s1, #6
    v.splat      v2, s11
    v.ld.w       v5, [s9, #0]
    s.movz       s9, #7
    @p4 v.st.scatter.w [s20, v5], v1
    a.vread      v1, a4, s5
    v.cmp.lt     p2, v3, v0
    p.and        p4, p1, p2
    s.addi       s5, s7, #16832
    s.addi       s11, s1, #7
    v.splat      v3, s11
    v.ld.w       v5, [s10, #0]
    s.movz       s10, #8
    @p5 v.st.scatter.w [s20, v5], v1
    a.vread      v1, a4, s4
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    s.addi       s4, s7, #16896
    s.addi       s11, s1, #8
    v.splat      v4, s11
    v.ld.w       v5, [s14, #0]
    s.movz       s11, #9
    @p3 v.st.scatter.w [s20, v5], v1
    a.vread      v1, a4, s13
    v.cmp.lt     p2, v2, v0
    p.and        p3, p1, p2
    s.addi       s13, s7, #16960
    s.addi       s14, s1, #9
    v.splat      v2, s14
    v.ld.w       v5, [s12, #0]
    s.movz       s12, #10
    @p4 v.st.scatter.w [s20, v5], v1
    a.vread      v1, a4, s3
    v.cmp.lt     p2, v3, v0
    p.and        p4, p1, p2
    s.addi       s3, s7, #17024
    s.addi       s14, s1, #10
    v.splat      v3, s14
    v.ld.w       v5, [s2, #0]
    s.movz       s2, #11
    @p5 v.st.scatter.w [s20, v5], v1
    a.vread      v1, a4, s6
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    s.addi       s6, s7, #17088
    s.addi       s14, s1, #11
    v.splat      v4, s14
    v.ld.w       v5, [s8, #0]
    s.movz       s8, #12
    @p3 v.st.scatter.w [s20, v5], v1
    a.vread      v1, a4, s9
    v.cmp.lt     p2, v2, v0
    p.and        p3, p1, p2
    s.addi       s9, s7, #17152
    s.addi       s14, s1, #12
    v.splat      v2, s14
    v.ld.w       v5, [s5, #0]
    s.movz       s5, #13
    @p4 v.st.scatter.w [s20, v5], v1
    a.vread      v1, a4, s10
    v.cmp.lt     p2, v3, v0
    p.and        p4, p1, p2
    s.addi       s10, s7, #17216
    s.addi       s14, s1, #13
    v.splat      v3, s14
    v.ld.w       v5, [s4, #0]
    s.movz       s4, #14
    @p5 v.st.scatter.w [s20, v5], v1
    a.vread      v1, a4, s11
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    s.addi       s11, s7, #17280
    s.addi       s14, s1, #14
    v.splat      v4, s14
    v.ld.w       v5, [s13, #0]
    s.movz       s13, #15
    @p3 v.st.scatter.w [s20, v5], v1
    a.vread      v1, a4, s12
    v.cmp.lt     p2, v2, v0
    p.and        p3, p1, p2
    s.addi       s12, s7, #17344
    s.addi       s7, s1, #15
    v.splat      v2, s7
    v.ld.w       v5, [s3, #0]
    @p4 v.st.scatter.w [s20, v5], v1
    a.vread      v1, a4, s2
    v.cmp.lt     p2, v3, v0
    p.and        p4, p1, p2
    v.ld.w       v3, [s6, #0]
    @p5 v.st.scatter.w [s20, v3], v1
    a.vread      v1, a4, s8
    v.cmp.lt     p2, v4, v0
    p.and        p5, p1, p2
    v.ld.w       v3, [s9, #0]
    @p3 v.st.scatter.w [s20, v3], v1
    a.vread      v1, a4, s5
    v.cmp.lt     p2, v2, v0
    p.and        p3, p1, p2
    v.ld.w       v0, [s10, #0]
    @p4 v.st.scatter.w [s20, v0], v1
    a.vread      v0, a4, s4
    v.ld.w       v1, [s11, #0]
    @p5 v.st.scatter.w [s20, v1], v0
    a.vread      v0, a4, s13
    v.ld.w       v1, [s12, #0]
    @p3 v.st.scatter.w [s20, v1], v0
__rctx_next:
    exit
