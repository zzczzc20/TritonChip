import json,math,torch
from pathlib import Path
from safetensors.torch import load_file
h=Path.home(); roots=[h/'r41_profile_q35_lru',h/'r41_profile_q35_sqrt',h/'r41_profile_q35_astage_lru']; result={'schema':'r41-q35-corrected-model-tlm/1','scope':'four-layer Qwen3.5; uncalibrated DP TLM, not board','routes':[]}
for d in roots:
 r=json.load(open(d/'report.json'));p=json.load(open(d/'profile/launches.json'));row={'route':d.name,'status':r.get('status'),'cpu_numerical_fallback':r.get('cpu_numerical_fallback'),'generated_tokens':r.get('generated_tokens'),'steps':[]}
 for step,kind in ((1,'prefill'),(2,'decode')):
  xs=[x for x in p['launches'] if x['step']==step and not x.get('skipped',False)];fs=[x for x in xs if x['kernel']=='w8a8_block_dynamic_fp8_matmul_kernel'];mac=ins=0
  for x in fs:
   a=next(z for z in x['args'] if z.get('role')=='act' and z.get('dtype')=='bfloat16');w=next(z for z in x['args'] if z.get('role')=='weight' and z.get('dtype')=='float8_e4m3fn');mac+=math.prod(a['shape'][:-1])*math.prod(w['shape']);ins+=sum(v for k,v in x['counters'].items() if k.startswith('core_') and k.endswith('_instructions'))
  reported=next(z for z in r['steps'] if z['kind']==kind)
  row['steps'].append(dict(kind=kind,launches=len(xs),device_cycles=sum(x['device_cycles'] for x in xs),code_loads=sum(x['code_load_count'] for x in xs),code_bytes=sum(x['code_upload_bytes'] for x in xs),evictions=sum(x['evicted'] for x in xs),host_read_calls=reported['transfers_inside_step']['host_read_calls'],fp8_launches=len(fs),fp8_macs=mac,fp8_instructions=ins,fp8_instructions_per_mac=ins/mac,fp8_cycles=sum(x['device_cycles'] for x in fs)))
 result['routes'].append(row)
a=load_file(str(roots[0]/'logits.safetensors'));result['logits']={}
for d in roots[1:]:
 b=load_file(str(d/'logits.safetensors'));result['logits'][d.name]={k:dict(elements=a[k].numel(),bit_mismatches=int((a[k].contiguous().view(torch.int16)!=b[k].contiguous().view(torch.int16)).sum())) for k in a}
result['caveat']='reduced-depth model compared to TLM control; not independent full-model CPU quality or board throughput; completed-event counters';(h/'r41_q35_corrected_compare_20261031.json').write_text(json.dumps(result,indent=2)+'\n')
