# Kernel synthesis wrapper: cap threads at 6 on the shared x86 host, then run the unchanged flow script.
set_param general.maxThreads 6
source [file join [lindex $argv 0] flow/fpga/synth_r40_multicore.tcl]
