    .li       s1, #196608
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s1, #196864
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #63, #1                     // v63..v63
    mb.arm       s1, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    .li       s2, #-1
    .li       s3, #0
    .li       s4, #0
    s.mov        s5, s2                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s6, s3                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s7, s4                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s5, s1
    mb.wait      s1
    mb.arm       s2, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    .li       s3, #2
    s.mov        s4, s3                          // coordinates must be consecutive (ISA sec 9E)
    t.st.async.h w0, d1, s4, s2
    mb.wait      s2

exit
