#!/usr/bin/env bash
set -euo pipefail
root="$1";label="$2"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd "$root"
tree=$(PYTHONPATH="$PWD:$PWD/python:$PWD/compiler/python:$PWD/tools/asm" "$HOME/flux-venv/bin/python" -c 'from archbench.provenance import software_tree; from pathlib import Path; print(software_tree(Path.cwd(),refresh=True))')
exec "$HOME/flux-venv/bin/python" tools/performance_harness/default_change_audit.py run --source-root "$PWD" --software-tree "$tree" --label "$label" --out "$HOME/r41_current_div_${label}_113_20261101" --jobs 2
