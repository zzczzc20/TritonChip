    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #512
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s2
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #64
    s.st.d       [s6, #48], s1
    s.movz       s1, #4
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #512
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #256                    // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s3
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #64
    s.st.d       [s6, #48], s1
    s.movz       s1, #4
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d1, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #1
    s.movz       s3, #0
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #1
    s.sub        s12, s1, s4
    s.min.s      s13, s12, s1
    s.cmp.lt     s1, s4, s6
    s.sub        s6, s3, s1
    s.cmp.lt     s1, s13, s8
    s.sub        s3, s7, s1
    s.xor        s1, s4, s6
    s.sub        s7, s1, s6
    s.xor        s1, s13, s3
    s.sub        s8, s1, s3
    s.addi       s1, s9, #0
    s.addi       s3, s10, #0
    s.cmp.eq     s9, s8, s11
    s.mov        s1, s7
    br.nz        s9, sdiv_done_1
    s.movz       s9, #0
    s.movz       s10, #31
    s.mov        s1, s9
    s.addi       s9, s10, #0
sdiv_2:
    s.lshr       s10, s7, s9
    s.shli       s11, s3, #1
    s.andi       s12, s10, #1
    s.movz       s10, #0
    s.or         s14, s11, s12
    s.movz       s11, #1
    s.cmp.geu    s12, s14, s8
    s.shl        s15, s11, s9
    s.sub        s11, s10, s12
    s.subi       s10, s9, #1
    s.and        s12, s8, s11
    s.and        s16, s15, s11
    s.sub        s11, s14, s12
    s.or         s12, s1, s16
    s.mov        s3, s11
    s.mov        s1, s12
    s.mov        s9, s10
    s.movz       s10, #0
    s.cmp.ge     s11, s9, s10
    br.nz        s11, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s13, s1
    s.movz       s1, #0
    s.cmp.lt     s11, s7, s8
    s.sub        s8, s9, s10
    s.sub        s9, s1, s11
    s.xor        s1, s13, s8
    s.xor        s10, s3, s6
    s.xor        s3, s7, s9
    s.sub        s11, s1, s8
    s.movz       s1, #0
    s.movz       s12, #1
    s.sub        s13, s10, s6
    s.sub        s6, s3, s9
    s.movz       s3, #0
    s.addi       s10, s1, #0
    s.cmp.eq     s1, s11, s12
    s.add        s12, s4, s13
    s.addi       s4, s3, #0
    s.mov        s10, s6
    br.nz        s1, sdiv_done_3
    s.movz       s1, #0
    s.movz       s3, #31
    s.mov        s10, s1
    s.addi       s1, s3, #0
sdiv_4:
    s.lshr       s3, s6, s1
    s.shli       s13, s4, #1
    s.andi       s14, s3, #1
    s.movz       s3, #0
    s.or         s15, s13, s14
    s.movz       s13, #1
    s.cmp.geu    s14, s15, s11
    s.shl        s16, s13, s1
    s.sub        s13, s3, s14
    s.subi       s3, s1, #1
    s.and        s14, s11, s13
    s.and        s17, s16, s13
    s.sub        s13, s15, s14
    s.or         s14, s10, s17
    s.mov        s4, s13
    s.mov        s10, s14
    s.mov        s1, s3
    s.movz       s3, #0
    s.cmp.ge     s13, s1, s3
    br.nz        s13, sdiv_4
sdiv_done_3:
    s.rdspecial  s1, pid.z
    s.rdspecial  s3, npid.y
    s.xor        s4, s9, s8
    s.mul        s6, s1, s3
    s.rdspecial  s1, pid.y
    s.xor        s3, s10, s4
    s.movz       s8, #16
    s.movz       s9, #127
    s.add        s10, s1, s6
    s.sub        s1, s3, s4
    s.mul        s3, s12, s8
    s.min.s      s4, s10, s9
    s.movz       s6, #256
    s.mul        s9, s1, s8
    s.mul        s11, s4, s6
    w.def        w0, #48, #16                    // v48..v63
    mb.arm       s4, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.andi       s13, s3, #15
    s.andi       s14, s9, #15
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s15, s13                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s11                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w0, d0, s15, s4
    mb.wait      s4
    w.def        w1, #32, #16                    // v32..v47
    mb.arm       s15, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s16, #0
    s.add        s17, s14, s11
    v.movi       v0, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s18, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s19, s17                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w1, d1, s18, s15
    mb.wait      s15
    v.extract    s11, v48, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s16, #0
    v.splat      v1, s11
    v.splat      v2, s12
    v.extract    s11, v48, #1
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s7
    v.splat      v4, s11
    v.splat      v5, s1
    v.splat      v6, s7
    v.iota       v7                              // arange(0, VLEN)
    v.cmp.ge     p1, v2, v1
    vf.fma       v1, v4, v33, v3
    v.extract    s1, v48, #2
    v.splat      v2, s3
    v.splat      v3, s9
    v.splat      v4, s13
    v.cmp.ge     p1, v5, v6
    v.splat      v5, s1
    v.extract    s1, v48, #3
    v.add        v6, v2, v7
    vf.fma       v2, v5, v34, v1
    v.splat      v1, s1
    v.extract    s1, v48, #4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v3, v7
    vf.fma       v3, v1, v35, v2
    v.splat      v1, s1
    v.extract    s1, v48, #5
    v.splat      v2, s14
    v.iota       v6                              // arange(0, VLEN)
    vf.fma       v7, v1, v36, v3
    v.add        v1, v4, v5
    v.splat      v1, s1
    v.extract    s1, v48, #6
    v.add        v3, v2, v6
    vf.fma       v2, v1, v37, v7
    v.splat      v1, s1
    v.extract    s1, v48, #7
    v.extract    s7, v48, #8
    v.splat      v3, s1
    vf.fma       v4, v1, v38, v2
    v.splat      v1, s7
    v.extract    s1, v48, #9
    v.extract    s7, v48, #10
    v.splat      v2, s1
    vf.fma       v5, v3, v39, v4
    v.splat      v3, s7
    v.extract    s1, v48, #11
    v.extract    s7, v48, #12
    v.splat      v4, s1
    vf.fma       v6, v1, v40, v5
    v.splat      v1, s7
    v.extract    s1, v48, #13
    v.extract    s7, v48, #14
    v.splat      v5, s1
    vf.fma       v7, v2, v41, v6
    v.splat      v2, s7
    v.extract    s1, v48, #15
    s.movz       s7, #1
    v.splat      v6, s1
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v4, v43, v8
    vf.fma       v4, v1, v44, v3
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v6, v47, v3
    a.vwrite     a0, s16, v1
    v.extract    s1, v49, #0
    v.extract    s11, v49, #1
    v.splat      v1, s1
    v.splat      v2, s11
    v.extract    s1, v49, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v49, #3
    v.extract    s11, v49, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s11
    v.extract    s1, v49, #5
    v.extract    s11, v49, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s11
    v.extract    s1, v49, #7
    v.extract    s11, v49, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s11
    v.extract    s1, v49, #9
    v.extract    s11, v49, #10
    v.extract    s12, v49, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v49, #12
    v.extract    s13, v49, #13
    v.extract    s14, v49, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s11
    v.extract    s11, v49, #15
    v.splat      v6, s12
    s.movz       s12, #2
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s11
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s1, v50, #0
    v.extract    s7, v50, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v50, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v50, #3
    v.extract    s7, v50, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v50, #5
    v.extract    s7, v50, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v50, #7
    v.extract    s7, v50, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v50, #9
    v.extract    s7, v50, #10
    v.extract    s11, v50, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v50, #12
    v.extract    s13, v50, #13
    v.extract    s14, v50, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v50, #15
    v.splat      v6, s11
    s.movz       s11, #3
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s12, v1
    v.extract    s1, v51, #0
    v.extract    s7, v51, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v51, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v51, #3
    v.extract    s7, v51, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v51, #5
    v.extract    s7, v51, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v51, #7
    v.extract    s7, v51, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v51, #9
    v.extract    s7, v51, #10
    v.extract    s12, v51, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v51, #12
    v.extract    s13, v51, #13
    v.extract    s14, v51, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v51, #15
    v.splat      v6, s12
    s.movz       s12, #4
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v52, #0
    v.extract    s7, v52, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v52, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v52, #3
    v.extract    s7, v52, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v52, #5
    v.extract    s7, v52, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v52, #7
    v.extract    s7, v52, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v52, #9
    v.extract    s7, v52, #10
    v.extract    s11, v52, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v52, #12
    v.extract    s13, v52, #13
    v.extract    s14, v52, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v52, #15
    v.splat      v6, s11
    s.movz       s11, #5
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s12, v1
    v.extract    s1, v53, #0
    v.extract    s7, v53, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v53, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v53, #3
    v.extract    s7, v53, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v53, #5
    v.extract    s7, v53, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v53, #7
    v.extract    s7, v53, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v53, #9
    v.extract    s7, v53, #10
    v.extract    s12, v53, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v53, #12
    v.extract    s13, v53, #13
    v.extract    s14, v53, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v53, #15
    v.splat      v6, s12
    s.movz       s12, #6
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v54, #0
    v.extract    s7, v54, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v54, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v54, #3
    v.extract    s7, v54, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v54, #5
    v.extract    s7, v54, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v54, #7
    v.extract    s7, v54, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v54, #9
    v.extract    s7, v54, #10
    v.extract    s11, v54, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v54, #12
    v.extract    s13, v54, #13
    v.extract    s14, v54, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v54, #15
    v.splat      v6, s11
    s.movz       s11, #7
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s12, v1
    v.extract    s1, v55, #0
    v.extract    s7, v55, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v55, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v55, #3
    v.extract    s7, v55, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v55, #5
    v.extract    s7, v55, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v55, #7
    v.extract    s7, v55, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v55, #9
    v.extract    s7, v55, #10
    v.extract    s12, v55, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v55, #12
    v.extract    s13, v55, #13
    v.extract    s14, v55, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v55, #15
    v.splat      v6, s12
    s.movz       s12, #8
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v56, #0
    v.extract    s7, v56, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v56, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v56, #3
    v.extract    s7, v56, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v56, #5
    v.extract    s7, v56, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v56, #7
    v.extract    s7, v56, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v56, #9
    v.extract    s7, v56, #10
    v.extract    s11, v56, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v56, #12
    v.extract    s13, v56, #13
    v.extract    s14, v56, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v56, #15
    v.splat      v6, s11
    s.movz       s11, #9
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s12, v1
    v.extract    s1, v57, #0
    v.extract    s7, v57, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v57, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v57, #3
    v.extract    s7, v57, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v57, #5
    v.extract    s7, v57, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v57, #7
    v.extract    s7, v57, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v57, #9
    v.extract    s7, v57, #10
    v.extract    s12, v57, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v57, #12
    v.extract    s13, v57, #13
    v.extract    s14, v57, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v57, #15
    v.splat      v6, s12
    s.movz       s12, #10
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v58, #0
    v.extract    s7, v58, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v58, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v58, #3
    v.extract    s7, v58, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v58, #5
    v.extract    s7, v58, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v58, #7
    v.extract    s7, v58, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v58, #9
    v.extract    s7, v58, #10
    v.extract    s11, v58, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v58, #12
    v.extract    s13, v58, #13
    v.extract    s14, v58, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v58, #15
    v.splat      v6, s11
    s.movz       s11, #11
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s12, v1
    v.extract    s1, v59, #0
    v.extract    s7, v59, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v59, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v59, #3
    v.extract    s7, v59, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v59, #5
    v.extract    s7, v59, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v59, #7
    v.extract    s7, v59, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v59, #9
    v.extract    s7, v59, #10
    v.extract    s12, v59, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v59, #12
    v.extract    s13, v59, #13
    v.extract    s14, v59, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v59, #15
    v.splat      v6, s12
    s.movz       s12, #12
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v60, #0
    v.extract    s7, v60, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v60, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v60, #3
    v.extract    s7, v60, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v60, #5
    v.extract    s7, v60, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v60, #7
    v.extract    s7, v60, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v60, #9
    v.extract    s7, v60, #10
    v.extract    s11, v60, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v60, #12
    v.extract    s13, v60, #13
    v.extract    s14, v60, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v60, #15
    v.splat      v6, s11
    s.movz       s11, #13
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s12, v1
    v.extract    s1, v61, #0
    v.extract    s7, v61, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v61, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v61, #3
    v.extract    s7, v61, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v61, #5
    v.extract    s7, v61, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v61, #7
    v.extract    s7, v61, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v61, #9
    v.extract    s7, v61, #10
    v.extract    s12, v61, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v61, #12
    v.extract    s13, v61, #13
    v.extract    s14, v61, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v61, #15
    v.splat      v6, s12
    s.movz       s12, #14
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s11, v1
    v.extract    s1, v62, #0
    v.extract    s7, v62, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v62, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v1, s1
    v.extract    s1, v62, #3
    v.extract    s7, v62, #4
    v.splat      v4, s1
    vf.fma       v5, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v62, #5
    v.extract    s7, v62, #6
    v.splat      v3, s1
    vf.fma       v6, v1, v34, v5
    v.splat      v1, s7
    v.extract    s1, v62, #7
    v.extract    s7, v62, #8
    v.splat      v5, s1
    vf.fma       v7, v4, v35, v6
    v.splat      v4, s7
    v.extract    s1, v62, #9
    v.extract    s7, v62, #10
    v.extract    s11, v62, #11
    vf.fma       v6, v2, v36, v7
    v.splat      v2, s1
    v.extract    s1, v62, #12
    v.extract    s13, v62, #13
    v.extract    s14, v62, #14
    vf.fma       v7, v3, v37, v6
    v.splat      v3, s7
    v.extract    s7, v62, #15
    v.splat      v6, s11
    s.movz       s11, #15
    vf.fma       v8, v1, v38, v7
    v.splat      v1, s1
    vf.fma       v7, v5, v39, v8
    v.splat      v5, s13
    vf.fma       v8, v4, v40, v7
    v.splat      v4, s14
    vf.fma       v7, v2, v41, v8
    v.splat      v2, s7
    vf.fma       v8, v3, v42, v7
    vf.fma       v3, v6, v43, v8
    vf.fma       v6, v1, v44, v3
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v4, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s12, v1
    v.extract    s1, v63, #0
    v.extract    s7, v63, #1
    v.splat      v1, s1
    v.splat      v2, s7
    v.extract    s1, v63, #2
    vf.fma       v3, v1, v32, v0
    v.splat      v0, s1
    v.extract    s1, v63, #3
    v.extract    s7, v63, #4
    v.splat      v1, s1
    vf.fma       v4, v2, v33, v3
    v.splat      v2, s7
    v.extract    s1, v63, #5
    v.extract    s7, v63, #6
    v.splat      v3, s1
    vf.fma       v5, v0, v34, v4
    v.splat      v0, s7
    v.extract    s1, v63, #7
    v.extract    s7, v63, #8
    v.splat      v4, s1
    vf.fma       v6, v1, v35, v5
    v.splat      v1, s7
    v.extract    s1, v63, #9
    v.extract    s7, v63, #10
    v.splat      v5, s1
    vf.fma       v7, v2, v36, v6
    v.splat      v2, s7
    v.extract    s1, v63, #11
    v.extract    s7, v63, #12
    v.extract    s12, v63, #13
    vf.fma       v6, v3, v37, v7
    v.splat      v3, s1
    v.extract    s1, v63, #14
    s.mul        s13, s10, s6
    s.muli       s6, s9, #4                      // a runtime tile origin, x4
    vf.fma       v7, v0, v38, v6
    v.splat      v0, s7
    v.extract    s7, v63, #15
    v.splat      v6, s12
    s.muli       s12, s3, #64                    // a runtime tile origin, x64
    vf.fma       v8, v4, v39, v7
    v.splat      v4, s1
    s.movz       s1, #128
    s.muli       s14, s13, #4                    // a runtime tile origin, x4
    s.add        s16, s2, s6                     // the tile origin
    vf.fma       v7, v1, v40, v8
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    v.splat      v1, s7
    s.add        s6, s2, s3                      // the tile origin
    s.add        s2, s16, s12                    // the tile origin
    vf.fma       v8, v5, v41, v7
    s.movz       s7, #0
    v.iota       v5                              // arange(0, VLEN)
    s.add        s12, s7, s9                     // the tile origin
    s.add        s7, s2, s14                     // the tile origin
    vf.fma       v7, v2, v42, v8
    v.splat      v2, s12
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s2, s9, #4                      // a runtime tile origin, x4
    s.muli       s9, s3, #64                     // a runtime tile origin, x64
    v.add        v8, v5, v2
    vf.fma       v2, v3, v43, v7
    v.splat      v3, s6
    v.splat      v5, s8
    s.movz       s3, #0
    s.muli       s12, s13, #4                    // a runtime tile origin, x4
    vf.fma       v7, v0, v44, v2
    v.splat      v0, s8
    v.cmp.lt     p1, v3, v5
    v.splat      v2, s10
    v.cmp.lt     p2, v8, v0
    vf.fma       v0, v6, v45, v7
    v.splat      v3, s1
    p.and        p3, p1, p2
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v3
    vf.fma       v2, v4, v46, v0
    p.and        p4, p3, p1
    s.addi       s1, s6, #1
    v.splat      v0, s6
    v.splat      v3, s1
    vf.fma       v4, v1, v47, v2
    s.add        s1, s5, s2                      // the tile origin
    v.cmp.lt     p3, v0, v5
    s.add        s2, s1, s9                      // the tile origin
    p.and        p5, p3, p2
    a.vwrite     a0, s11, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s7, #0]
    a.vread      v1, a0, s3
    v.cmp.lt     p3, v3, v5
    p.and        p4, p3, p2
    vf.add       v2, v1, v6
    s.add        s1, s2, s12                     // the tile origin
    p.and        p3, p5, p1
    s.addi       s2, s7, #64                     // row 1
    p.and        p5, p4, p1
    s.movz       s3, #1
    s.addi       s5, s6, #1
    s.addi       s8, s6, #2
    v.splat      v1, s5
    v.splat      v3, s8
    s.addi       s5, s1, #64                     // row 1
    s.addi       s8, s7, #128                    // row 2
    s.movz       s9, #2
    s.addi       s10, s6, #2
    vf.add       v4, v0, v2
    s.addi       s11, s6, #3
    v.splat      v0, s10
    v.splat      v2, s11
    s.addi       s10, s1, #128                   // row 2
    @p3 v.st.w       [s1, #0], v4
    v.cmp.lt     p3, v1, v5
    p.and        p4, p3, p2
    s.addi       s11, s7, #192                   // row 3
    p.and        p3, p4, p1
    s.movz       s12, #3
    s.addi       s13, s6, #3
    s.addi       s14, s1, #192                   // row 3
    v.splat      v1, s13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v4, [s2, #0]
    a.vread      v7, a0, s3
    v.cmp.lt     p4, v3, v5
    p.and        p5, p4, p2
    vf.add       v3, v7, v6
    p.and        p4, p5, p1
    s.addi       s2, s6, #4
    s.addi       s3, s7, #256                    // row 4
    v.splat      v7, s2
    vf.add       v8, v4, v3
    s.movz       s2, #4
    @p3 v.st.w       [s5, #0], v8
    v.cmp.lt     p3, v0, v5
    p.and        p5, p3, p2
    s.addi       s5, s6, #4
    p.and        p3, p5, p1
    v.splat      v0, s5
    s.addi       s5, s1, #256                    // row 4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s8, #0]
    a.vread      v4, a0, s9
    v.cmp.lt     p4, v2, v5
    p.and        p5, p4, p2
    vf.add       v2, v4, v6
    p.and        p4, p5, p1
    s.addi       s8, s6, #5
    s.addi       s9, s7, #320                    // row 5
    v.splat      v4, s8
    vf.add       v8, v3, v2
    s.movz       s8, #5
    @p3 v.st.w       [s10, #0], v8
    v.cmp.lt     p3, v1, v5
    p.and        p5, p3, p2
    s.addi       s10, s6, #5
    p.and        p3, p5, p1
    v.splat      v1, s10
    s.addi       s10, s1, #320                   // row 5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s11, #0]
    a.vread      v3, a0, s12
    v.cmp.lt     p4, v7, v5
    p.and        p5, p4, p2
    vf.add       v7, v3, v6
    p.and        p4, p5, p1
    s.addi       s11, s6, #6
    s.addi       s12, s7, #384                   // row 6
    v.splat      v3, s11
    vf.add       v8, v2, v7
    s.movz       s11, #6
    @p3 v.st.w       [s14, #0], v8
    v.cmp.lt     p3, v0, v5
    p.and        p5, p3, p2
    s.addi       s13, s6, #6
    p.and        p3, p5, p1
    v.splat      v0, s13
    s.addi       s13, s1, #384                   // row 6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s3, #0]
    a.vread      v7, a0, s2
    v.cmp.lt     p4, v4, v5
    p.and        p5, p4, p2
    vf.add       v4, v7, v6
    p.and        p4, p5, p1
    s.addi       s2, s6, #7
    s.addi       s3, s7, #448                    // row 7
    v.splat      v7, s2
    vf.add       v8, v2, v4
    s.movz       s2, #7
    @p3 v.st.w       [s5, #0], v8
    v.cmp.lt     p3, v1, v5
    p.and        p5, p3, p2
    s.addi       s5, s6, #7
    p.and        p3, p5, p1
    v.splat      v1, s5
    s.addi       s5, s1, #448                    // row 7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s9, #0]
    a.vread      v4, a0, s8
    v.cmp.lt     p4, v3, v5
    p.and        p5, p4, p2
    vf.add       v3, v4, v6
    p.and        p4, p5, p1
    s.addi       s8, s6, #8
    s.addi       s9, s7, #512                    // row 8
    v.splat      v4, s8
    vf.add       v8, v2, v3
    s.movz       s8, #8
    @p3 v.st.w       [s10, #0], v8
    v.cmp.lt     p3, v0, v5
    p.and        p5, p3, p2
    s.addi       s10, s6, #8
    p.and        p3, p5, p1
    v.splat      v0, s10
    s.addi       s10, s1, #512                   // row 8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s12, #0]
    a.vread      v3, a0, s11
    v.cmp.lt     p4, v7, v5
    p.and        p5, p4, p2
    vf.add       v7, v3, v6
    p.and        p4, p5, p1
    s.addi       s11, s6, #9
    s.addi       s12, s7, #576                   // row 9
    v.splat      v3, s11
    vf.add       v8, v2, v7
    s.movz       s11, #9
    @p3 v.st.w       [s13, #0], v8
    v.cmp.lt     p3, v1, v5
    p.and        p5, p3, p2
    s.addi       s13, s6, #9
    p.and        p3, p5, p1
    v.splat      v1, s13
    s.addi       s13, s1, #576                   // row 9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s3, #0]
    a.vread      v7, a0, s2
    v.cmp.lt     p4, v4, v5
    p.and        p5, p4, p2
    vf.add       v4, v7, v6
    p.and        p4, p5, p1
    s.addi       s2, s6, #10
    s.addi       s3, s7, #640                    // row 10
    v.splat      v7, s2
    vf.add       v8, v2, v4
    s.movz       s2, #10
    @p3 v.st.w       [s5, #0], v8
    v.cmp.lt     p3, v0, v5
    p.and        p5, p3, p2
    s.addi       s5, s6, #10
    p.and        p3, p5, p1
    v.splat      v0, s5
    s.addi       s5, s1, #640                    // row 10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s9, #0]
    a.vread      v4, a0, s8
    v.cmp.lt     p4, v3, v5
    p.and        p5, p4, p2
    vf.add       v3, v4, v6
    p.and        p4, p5, p1
    s.addi       s8, s6, #11
    s.addi       s9, s7, #704                    // row 11
    v.splat      v4, s8
    vf.add       v8, v2, v3
    s.movz       s8, #11
    @p3 v.st.w       [s10, #0], v8
    v.cmp.lt     p3, v1, v5
    p.and        p5, p3, p2
    s.addi       s10, s6, #11
    p.and        p3, p5, p1
    v.splat      v1, s10
    s.addi       s10, s1, #704                   // row 11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s12, #0]
    a.vread      v3, a0, s11
    v.cmp.lt     p4, v7, v5
    p.and        p5, p4, p2
    vf.add       v7, v3, v6
    p.and        p4, p5, p1
    s.addi       s11, s6, #12
    s.addi       s12, s7, #768                   // row 12
    v.splat      v3, s11
    vf.add       v8, v2, v7
    s.movz       s11, #12
    @p3 v.st.w       [s13, #0], v8
    v.cmp.lt     p3, v0, v5
    p.and        p5, p3, p2
    s.addi       s13, s6, #12
    p.and        p3, p5, p1
    v.splat      v0, s13
    s.addi       s13, s1, #768                   // row 12
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s3, #0]
    a.vread      v7, a0, s2
    v.cmp.lt     p4, v4, v5
    p.and        p5, p4, p2
    vf.add       v4, v7, v6
    p.and        p4, p5, p1
    s.addi       s2, s6, #13
    s.addi       s3, s7, #832                    // row 13
    v.splat      v7, s2
    vf.add       v8, v2, v4
    s.movz       s2, #13
    @p3 v.st.w       [s5, #0], v8
    v.cmp.lt     p3, v1, v5
    p.and        p5, p3, p2
    s.addi       s5, s6, #13
    p.and        p3, p5, p1
    v.splat      v1, s5
    s.addi       s5, s1, #832                    // row 13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s9, #0]
    a.vread      v4, a0, s8
    v.cmp.lt     p4, v3, v5
    p.and        p5, p4, p2
    vf.add       v3, v4, v6
    p.and        p4, p5, p1
    s.addi       s8, s6, #14
    s.addi       s9, s7, #896                    // row 14
    v.splat      v4, s8
    vf.add       v8, v2, v3
    s.movz       s8, #14
    @p3 v.st.w       [s10, #0], v8
    v.cmp.lt     p3, v0, v5
    p.and        p5, p3, p2
    s.addi       s10, s6, #14
    p.and        p3, p5, p1
    v.splat      v0, s10
    s.addi       s10, s1, #896                   // row 14
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s12, #0]
    a.vread      v3, a0, s11
    v.cmp.lt     p4, v7, v5
    p.and        p5, p4, p2
    vf.add       v7, v3, v6
    p.and        p4, p5, p1
    s.addi       s11, s6, #15
    s.addi       s12, s7, #960                   // row 15
    v.splat      v3, s11
    vf.add       v8, v2, v7
    s.movz       s7, #15
    @p3 v.st.w       [s13, #0], v8
    v.cmp.lt     p3, v1, v5
    p.and        p5, p3, p2
    s.addi       s11, s6, #15
    p.and        p3, p5, p1
    v.splat      v1, s11
    s.addi       s6, s1, #960                    // row 15
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s3, #0]
    a.vread      v7, a0, s2
    v.cmp.lt     p4, v4, v5
    p.and        p5, p4, p2
    vf.add       v4, v7, v6
    p.and        p4, p5, p1
    vf.add       v7, v2, v4
    @p3 v.st.w       [s5, #0], v7
    v.cmp.lt     p3, v0, v5
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s9, #0]
    a.vread      v2, a0, s8
    v.cmp.lt     p4, v3, v5
    p.and        p5, p4, p2
    vf.add       v3, v2, v6
    p.and        p4, p5, p1
    vf.add       v2, v0, v3
    @p3 v.st.w       [s10, #0], v2
    v.cmp.lt     p3, v1, v5
    p.and        p5, p3, p2
    p.and        p2, p5, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s12, #0]
    a.vread      v1, a0, s7
    vf.add       v2, v1, v6
    vf.add       v1, v0, v2
    @p2 v.st.w       [s6, #0], v1
__rctx_next:
    exit
