module gold(input [63:0] a,input [15:0] tv,tbyp,
input [79:0] tbase,tsize,input [95:0] tlsb,output [11:0] result);
localparam ADDR_W=64,DCO_T=16,RANK_BITS=5;
function [11:0] owner;
        input [ADDR_W-1:0]      a;
        input [DCO_T-1:0]       tv;
        input [DCO_T*RANK_BITS-1:0]    tbase;
        input [DCO_T*RANK_BITS-1:0]    tsize;
        input [DCO_T-1:0]       tbyp;
        input [DCO_T*6-1:0]     tlsb;
        integer k;
        reg     hit, byp;
        reg [RANK_BITS-1:0] best, b, z;
        reg [3:0]  idx;
        reg [5:0]  lsb;
        begin
            hit = 1'b0; best = {RANK_BITS{1'b0}}; byp = 1'b0; idx = 4'd0; lsb = 6'd0;
            for (k = 0; k < DCO_T; k = k + 1) begin
                b = tbase[k*RANK_BITS +: RANK_BITS];
                z = tsize[k*RANK_BITS +: RANK_BITS];
                if (tv[k] &&
                    (!hit || b > best)) begin
                    hit = 1'b1; best = b; byp = tbyp[k]; idx = k[3:0];
                    lsb = tlsb[k*6 +: 6];
                end
            end
            owner = {hit, byp, idx, lsb};
        end
    endfunction
assign result=owner(a,tv,tbase,tsize,tbyp,tlsb);
endmodule
module gate(input [63:0] a,input [15:0] tv,tbyp,
input [79:0] tbase,tsize,input [95:0] tlsb,output [11:0] result);
localparam ADDR_W=64,DCO_T=16,RANK_BITS=5;
function automatic [11:0] owner;
        input [ADDR_W-1:0] a;
        input [DCO_T-1:0] tv;
        input [DCO_T*RANK_BITS-1:0] tbase, tsize;
        input [DCO_T-1:0] tbyp;
        input [DCO_T*6-1:0] tlsb;
        integer k, j;
        reg hit, byp, blocked;
        reg [RANK_BITS-1:0] b, z, best;
        reg [3:0] idx;
        reg [5:0] lsb;
        reg [DCO_T-1:0] eligible_mask;
        reg [11:0] selected;
        begin
          if (DCO_T < 8) begin
            hit = 1'b0; best = {RANK_BITS{1'b0}}; byp = 1'b0; idx = 4'd0; lsb = 6'd0;
            for (k = 0; k < DCO_T; k = k + 1) begin
                b = tbase[k*RANK_BITS +: RANK_BITS];
                z = tsize[k*RANK_BITS +: RANK_BITS];
                if (tv[k] &&
                    (!hit || b > best)) begin
                    hit = 1'b1; best = b; byp = tbyp[k]; idx = k[3:0];
                    lsb = tlsb[k*6 +: 6];
                end
            end
            owner = {hit, byp, idx, lsb};
          end else begin
            
            
            
            eligible_mask = {DCO_T{1'b0}};
            for (k = 0; k < DCO_T; k = k + 1) begin
                b = tbase[k*RANK_BITS +: RANK_BITS];
                z = tsize[k*RANK_BITS +: RANK_BITS];
                if (tv[k])
                    eligible_mask[k] = 1'b1;
            end
            owner = 12'd0;
            for (k = 0; k < DCO_T; k = k + 1) begin
                b = tbase[k*RANK_BITS +: RANK_BITS];
                blocked = 1'b0;
                for (j = 0; j < DCO_T; j = j + 1) begin
                    if (j < k) begin
                        if (eligible_mask[j] && tbase[j*RANK_BITS +: RANK_BITS] >= b) blocked = 1'b1;
                    end else if (j > k) begin
                        if (eligible_mask[j] && tbase[j*RANK_BITS +: RANK_BITS] > b) blocked = 1'b1;
                    end
                end
                
                
                selected = (eligible_mask[k] && !blocked) ?
                    {1'b1, tbyp[k], k[3:0], tlsb[k*6 +: 6]} : 12'd0;
                owner = owner | selected;
            end
          end
        end
    endfunction
assign result=owner(a,tv,tbase,tsize,tbyp,tlsb);
endmodule
