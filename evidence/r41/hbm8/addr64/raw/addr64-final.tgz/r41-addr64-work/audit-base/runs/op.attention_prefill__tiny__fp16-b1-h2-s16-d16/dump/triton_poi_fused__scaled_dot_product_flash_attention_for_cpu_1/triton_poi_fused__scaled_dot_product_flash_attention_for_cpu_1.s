    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.rdspecial  s1, pid.y
    s.movz       s5, #16
    s.shli       s6, s1, #4                      // x16 as a shift
    s.shli       s1, s4, #4                      // x16 as a shift
    s.rdspecial  s4, arg_base
    s.ld.d       s7, [s4, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s4, role_id
    s.movz       s8, #2048
    s.mul        s9, s4, s8
    s.add        s4, s7, s9                      // this context's own scratch
    s.addi       s7, s4, #0
    s.movz       s8, #0
    v.splat      v0, s8
    s.add        s9, s8, s6                      // the tile origin
    v.splat      v1, s9
    v.splat      v2, s5
    v.movi       v3, #0
    v.cmp.lt     p1, v1, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v1
    @p1 v.sel        v5, v4, v1
    v.sub        v1, v3, v2
    @p2 v.sel        v4, v1, v2
    v.movi       v1, #15
    v.and        v4, v5, v1
    v.sub        v1, v3, v4
    @p1 v.sel        v3, v1, v4
    s.muli       s10, s1, #16                    // a runtime tile origin, x16
    s.add        s11, s8, s10                    // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v4, s5
    v.mul        v5, v1, v4
    v.splat      v1, s11
    v.add        v4, v5, v1
    v.add        v1, v3, v4
    v.splat      v3, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v3, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v3
    @p1 v.sel        v7, v6, v3
    v.sub        v3, v5, v2
    @p2 v.sel        v6, v3, v2
    v.movi       v3, #4
    v.lshr       v6, v7, v3
    v.sub        v3, v5, v6
    @p1 v.sel        v5, v3, v6
    s.movz       s5, #256
    v.splat      v3, s5
    v.mul        v6, v5, v3
    v.add        v5, v1, v6
    v.add        v1, v0, v5
    v.st.w       [s7, #0], v1
    s.addi       s5, s7, #64
    s.addi       s8, s9, #1
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #1
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #128
    s.addi       s8, s9, #2
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #2
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #192
    s.addi       s8, s9, #3
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #3
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #256
    s.addi       s8, s9, #4
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #4
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #320
    s.addi       s8, s9, #5
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #5
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #384
    s.addi       s8, s9, #6
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #6
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #448
    s.addi       s8, s9, #7
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #7
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #512
    s.addi       s8, s9, #8
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #8
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #576
    s.addi       s8, s9, #9
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #9
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #640
    s.addi       s8, s9, #10
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #10
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #704
    s.addi       s8, s9, #11
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #11
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #768
    s.addi       s8, s9, #12
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #12
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #832
    s.addi       s8, s9, #13
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #13
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #896
    s.addi       s8, s9, #14
    v.splat      v1, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s8, s9, #14
    v.splat      v5, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #4
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s7, #960
    s.addi       s7, s9, #15
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #15
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s9, #15
    v.splat      v4, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v4, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v4
    @p1 v.sel        v7, v6, v4
    v.sub        v4, v5, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v2, #4
    v.lshr       v4, v7, v2
    v.sub        v2, v5, v4
    @p1 v.sel        v5, v2, v4
    v.mul        v2, v5, v3
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s5, #0], v1
    fence.acq_rel.device
    s.addi       s5, s4, #1024
    s.addi       s7, s4, #0
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #0
    s.add        s8, s7, s1                      // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s8
    v.add        v3, v1, v2
    v.cmpi.lt    p1, v3, #16
    v.splat      v1, s9
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v1
    s.addi       s7, s5, #64
    s.addi       s8, s4, #64
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #1
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #128
    s.addi       s8, s4, #128
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #2
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #192
    s.addi       s8, s4, #192
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #3
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #256
    s.addi       s8, s4, #256
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #4
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #320
    s.addi       s8, s4, #320
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #5
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #384
    s.addi       s8, s4, #384
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #6
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #448
    s.addi       s8, s4, #448
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #7
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #512
    s.addi       s8, s4, #512
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #8
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #576
    s.addi       s8, s4, #576
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #9
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #640
    s.addi       s8, s4, #640
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #10
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #704
    s.addi       s8, s4, #704
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #11
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #768
    s.addi       s8, s4, #768
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #12
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #832
    s.addi       s8, s4, #832
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #13
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #896
    s.addi       s8, s4, #896
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #14
    v.splat      v1, s8
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s5, #960
    s.addi       s5, s4, #960
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s9, #15
    v.splat      v1, s5
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    fence.acq_rel.device
    .li       s2, #1056964608
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s2, s1, #4                      // a runtime tile origin, x4
    s.add        s1, s3, s2                      // the tile origin
    s.muli       s2, s6, #64                     // a runtime tile origin, x64
    s.add        s3, s1, s2                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s1, s4, #1024
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    v.splat      v2, s9
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s3, #0], v1
    s.addi       s1, s4, #1088
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #64                     // row 1
    s.addi       s2, s9, #1
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1152
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #128                    // row 2
    s.addi       s2, s9, #2
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1216
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #192                    // row 3
    s.addi       s2, s9, #3
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1280
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #256                    // row 4
    s.addi       s2, s9, #4
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1344
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #320                    // row 5
    s.addi       s2, s9, #5
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1408
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #384                    // row 6
    s.addi       s2, s9, #6
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1472
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #448                    // row 7
    s.addi       s2, s9, #7
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1536
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #512                    // row 8
    s.addi       s2, s9, #8
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1600
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #576                    // row 9
    s.addi       s2, s9, #9
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1664
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #640                    // row 10
    s.addi       s2, s9, #10
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1728
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #704                    // row 11
    s.addi       s2, s9, #11
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1792
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #768                    // row 12
    s.addi       s2, s9, #12
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1856
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #832                    // row 13
    s.addi       s2, s9, #13
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1920
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #896                    // row 14
    s.addi       s2, s9, #14
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1984
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #960                    // row 15
    s.addi       s2, s9, #15
    v.splat      v0, s2
    v.cmpi.lt    p2, v0, #32
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v1
__rctx_next:
    exit
