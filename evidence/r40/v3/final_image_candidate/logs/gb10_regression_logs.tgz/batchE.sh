#!/bin/sh
# Batch E on GB10 (after D): remaining R40 grid/MMIO lanes of CI on this branch.
. ~/tc_env/env.sh
cd ~/tc_hw_final
L=~/tc_hw_logs
while [ ! -f $L/D_done.log ]; do sleep 30; done
lane() { name=$1; shift; ( "$@" ; echo "EXIT=$?" ) > $L/E_$name.log 2>&1; }
( lane transport nice -n 10 make r40-physical-grid-transport r40-physical-grid-runtime r40-multicore-backend TRITON_PYTHON=$TORCH_PYTHON ) &
( lane native_smoke nice -n 10 make r40-multicore-native-smoke TRITON_PYTHON=$TORCH_PYTHON ) &
( lane mmio_checks nice -n 10 make r40-multicore-mmio-checks TRITON_PYTHON=$TORCH_PYTHON ) &
wait
echo BATCH_E_DONE > $L/E_done.log
