    s.rdspecial  s1, arg_base
    v.movi       v0, #0
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    s.ld.d       s3, [s2, #0]                    // one element, not a vector
    s.lshri      s4, s3, #32
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.lshri      s6, s3, #32
    s.lshri      s7, s3, #32
    s.ld.d       s8, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.lshri      s9, s3, #32
    s.lshri      s10, s3, #32
    s.ld.d       s11, [s1, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    v.insert     v0, s3, #0
    v.insert     v1, s4, #0
    v.insert     v0, s3, #1
    v.insert     v1, s6, #1
    v.insert     v0, s3, #2
    v.insert     v1, s7, #2
    v.insert     v0, s3, #3
    v.insert     v1, s9, #3
    v.insert     v0, s3, #4
    v.insert     v1, s10, #4
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #5
    v.insert     v1, s1, #5
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #6
    v.insert     v1, s1, #6
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #7
    v.insert     v1, s1, #7
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #8
    v.insert     v1, s1, #8
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #9
    v.insert     v1, s1, #9
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #10
    v.insert     v1, s1, #10
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #11
    v.insert     v1, s1, #11
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #12
    v.insert     v1, s1, #12
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #13
    v.insert     v1, s1, #13
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #14
    v.insert     v1, s1, #14
    s.lshri      s1, s3, #32
    s.movz       s4, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.insert     v0, s3, #15
    v.insert     v1, s1, #15
    s.movz       s1, #1024
    s.movz       s3, #16
    s.addi       s6, s4, #0
    v.mov        v4, v3
for_1:
    s.cmp.ge     s7, s6, s1
    br.nz        s7, endfor_2
    v.extract    s7, v1, #0
    s.shli       s9, s7, #32
    v.extract    s7, v0, #0
    v.extract    s10, v1, #1
    s.or         s12, s7, s9
    s.movz       s7, #0
    s.shli       s9, s10, #32
    v.extract    s10, v0, #1
    v.extract    s13, v1, #2
    v.movi       v3, #0
    s.cmp.ge     s14, s12, s7
    s.or         s7, s10, s9
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v0, #2
    v.extract    s13, v1, #3
    v.insert     v3, s14, #0
    s.cmp.ge     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v0, #3
    v.extract    s13, v1, #4
    v.insert     v3, s14, #1
    s.cmp.ge     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v0, #4
    v.extract    s13, v1, #5
    v.insert     v3, s14, #2
    s.cmp.ge     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v0, #5
    v.insert     v3, s14, #3
    s.cmp.ge     s13, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #0
    v.extract    s10, v0, #6
    v.insert     v3, s13, #4
    s.cmp.ge     s12, s7, s9
    v.splat      v5, s6
    v.extract    s7, v1, #6
    v.insert     v3, s12, #5
    v.add        v6, v5, v2
    s.shli       s9, s7, #32
    v.movi       v5, #1024
    s.or         s7, s10, s9
    v.cmp.lt     p1, v6, v5
    v.extract    s9, v1, #7
    s.movz       s10, #0
    s.shli       s12, s9, #32
    v.extract    s9, v0, #7
    v.extract    s13, v1, #8
    s.cmp.ge     s14, s7, s10
    s.or         s7, s9, s12
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v0, #8
    v.extract    s13, v1, #9
    v.insert     v3, s14, #6
    s.cmp.ge     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v0, #9
    v.extract    s13, v1, #10
    v.insert     v3, s14, #7
    s.cmp.ge     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v0, #10
    v.extract    s13, v1, #11
    v.insert     v3, s14, #8
    s.cmp.ge     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v0, #11
    v.extract    s13, v1, #12
    v.insert     v3, s14, #9
    s.cmp.ge     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v0, #12
    v.extract    s13, v1, #13
    v.insert     v3, s14, #10
    s.cmp.ge     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v0, #13
    v.extract    s13, v1, #14
    v.insert     v3, s14, #11
    s.cmp.ge     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v0, #14
    v.extract    s13, v1, #15
    v.insert     v3, s14, #12
    v.extract    s14, v1, #0
    s.cmp.ge     s15, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    s.shli       s12, s14, #32
    v.extract    s13, v0, #15
    v.insert     v3, s15, #13
    v.extract    s14, v0, #0
    s.cmp.ge     s15, s7, s9
    v.extract    s7, v1, #1
    s.or         s9, s13, s10
    s.movz       s10, #0
    s.or         s13, s14, s12
    s.movz       s12, #32000
    s.shli       s14, s7, #32
    v.insert     v3, s15, #14
    v.extract    s7, v0, #1
    s.cmp.ge     s15, s9, s10
    v.extract    s9, v1, #2
    v.movi       v5, #0
    s.cmp.lt     s10, s13, s12
    s.or         s12, s7, s14
    s.movz       s7, #32000
    s.shli       s13, s9, #32
    v.extract    s9, v0, #2
    v.insert     v3, s15, #15
    v.extract    s14, v1, #3
    v.insert     v5, s10, #0
    s.cmp.lt     s10, s12, s7
    s.or         s7, s9, s13
    s.movz       s9, #32000
    s.shli       s12, s14, #32
    v.extract    s13, v0, #3
    v.extract    s14, v1, #4
    v.insert     v5, s10, #1
    s.cmp.lt     s10, s7, s9
    s.or         s7, s13, s12
    s.movz       s9, #32000
    s.shli       s12, s14, #32
    v.extract    s13, v0, #4
    v.extract    s14, v1, #5
    v.insert     v5, s10, #2
    s.cmp.lt     s10, s7, s9
    s.or         s7, s13, s12
    s.movz       s9, #32000
    s.shli       s12, s14, #32
    v.extract    s13, v0, #5
    v.extract    s14, v1, #6
    v.insert     v5, s10, #3
    s.cmp.lt     s10, s7, s9
    s.or         s7, s13, s12
    s.movz       s9, #32000
    s.shli       s12, s14, #32
    v.extract    s13, v0, #6
    v.insert     v5, s10, #4
    s.cmp.lt     s10, s7, s9
    v.movi       v7, #0
    s.or         s7, s13, s12
    v.insert     v5, s10, #5
    v.cmp.ne     p2, v3, v7
    v.extract    s9, v1, #7
    s.movz       s10, #32000
    s.shli       s12, s9, #32
    v.extract    s9, v0, #7
    v.extract    s13, v1, #8
    s.cmp.lt     s14, s7, s10
    s.or         s7, s9, s12
    s.movz       s9, #32000
    s.shli       s10, s13, #32
    v.extract    s12, v0, #8
    v.extract    s13, v1, #9
    v.insert     v5, s14, #6
    s.cmp.lt     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #32000
    s.shli       s10, s13, #32
    v.extract    s12, v0, #9
    v.extract    s13, v1, #10
    v.insert     v5, s14, #7
    s.cmp.lt     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #32000
    s.shli       s10, s13, #32
    v.extract    s12, v0, #10
    v.extract    s13, v1, #11
    v.insert     v5, s14, #8
    s.cmp.lt     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #32000
    s.shli       s10, s13, #32
    v.extract    s12, v0, #11
    v.extract    s13, v1, #12
    v.insert     v5, s14, #9
    s.cmp.lt     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #32000
    s.shli       s10, s13, #32
    v.extract    s12, v0, #12
    v.extract    s13, v1, #13
    v.insert     v5, s14, #10
    s.cmp.lt     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #32000
    s.shli       s10, s13, #32
    v.extract    s12, v0, #13
    v.extract    s13, v1, #14
    v.insert     v5, s14, #11
    s.cmp.lt     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #32000
    s.shli       s10, s13, #32
    v.extract    s12, v0, #14
    v.extract    s13, v1, #15
    v.insert     v5, s14, #12
    s.cmp.lt     s14, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #32000
    s.shli       s10, s13, #32
    v.extract    s12, v0, #15
    v.insert     v5, s14, #13
    s.cmp.lt     s13, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #32000
    v.insert     v5, s13, #14
    s.cmp.lt     s10, s7, s9
    v.movi       v3, #0
    v.insert     v5, s10, #15
    v.movi       v7, #0
    v.cmp.ne     p3, v5, v3
    p.and        p4, p2, p3
    v.movi       v3, #1
    s.movz       s7, #0
    @p4 v.sel        v5, v7, v3
    v.reduce.or  s9, v5
    s.cmp.eq     s10, s9, s7
    br.nz        s10, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s7, v1, #0
    s.shli       s9, s7, #32
    v.extract    s7, v0, #0
    v.extract    s10, v1, #1
    s.or         s12, s7, s9
    s.movz       s7, #1024
    s.shli       s9, s10, #32
    v.extract    s10, v0, #1
    v.extract    s13, v1, #2
    s.mul        s14, s12, s7
    s.or         s7, s10, s9
    s.movz       s9, #1024
    s.shli       s10, s13, #32
    v.extract    s12, v0, #2
    v.extract    s13, v1, #3
    s.mul        s15, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #1024
    s.shli       s10, s13, #32
    v.extract    s12, v0, #3
    v.extract    s13, v1, #4
    s.mul        s16, s7, s9
    s.or         s7, s12, s10
    s.movz       s9, #1024
    s.shli       s10, s13, #32
    v.movi       v3, #0
    v.movi       v5, #0
    s.lshri      s12, s14, #32
    s.mul        s13, s7, s9
    v.extract    s7, v0, #4
    s.or         s9, s7, s10
    v.extract    s7, v1, #5
    s.shli       s10, s7, #32
    v.insert     v3, s14, #0
    s.movz       s7, #1024
    v.insert     v5, s12, #0
    s.lshri      s12, s15, #32
    s.mul        s14, s9, s7
    v.extract    s7, v0, #5
    s.or         s9, s7, s10
    v.extract    s7, v1, #6
    s.shli       s10, s7, #32
    v.insert     v3, s15, #1
    s.movz       s7, #1024
    v.insert     v5, s12, #1
    s.lshri      s12, s16, #32
    s.mul        s15, s9, s7
    v.extract    s7, v0, #6
    s.or         s9, s7, s10
    v.extract    s7, v1, #7
    s.shli       s10, s7, #32
    v.insert     v3, s16, #2
    s.movz       s7, #1024
    v.insert     v5, s12, #2
    s.lshri      s12, s13, #32
    s.mul        s16, s9, s7
    v.extract    s7, v0, #7
    s.or         s9, s7, s10
    v.extract    s7, v1, #8
    s.shli       s10, s7, #32
    v.insert     v3, s13, #3
    s.movz       s7, #1024
    v.insert     v5, s12, #3
    s.lshri      s12, s14, #32
    s.mul        s13, s9, s7
    v.extract    s7, v0, #8
    s.or         s9, s7, s10
    v.extract    s7, v1, #9
    s.shli       s10, s7, #32
    v.insert     v3, s14, #4
    s.movz       s7, #1024
    v.insert     v5, s12, #4
    s.lshri      s12, s15, #32
    s.mul        s14, s9, s7
    v.extract    s7, v0, #9
    s.or         s9, s7, s10
    v.extract    s7, v1, #10
    s.shli       s10, s7, #32
    v.insert     v3, s15, #5
    s.movz       s7, #1024
    v.insert     v5, s12, #5
    s.lshri      s12, s16, #32
    s.mul        s15, s9, s7
    v.extract    s7, v0, #10
    s.or         s9, s7, s10
    v.extract    s7, v1, #11
    s.shli       s10, s7, #32
    v.insert     v3, s16, #6
    s.movz       s7, #1024
    v.insert     v5, s12, #6
    s.lshri      s12, s13, #32
    s.mul        s16, s9, s7
    v.extract    s7, v0, #11
    s.or         s9, s7, s10
    v.extract    s7, v1, #12
    s.shli       s10, s7, #32
    v.insert     v3, s13, #7
    s.movz       s7, #1024
    v.insert     v5, s12, #7
    s.lshri      s12, s14, #32
    s.mul        s13, s9, s7
    v.extract    s7, v0, #12
    s.or         s9, s7, s10
    v.extract    s7, v1, #13
    s.shli       s10, s7, #32
    v.insert     v3, s14, #8
    s.movz       s7, #1024
    v.insert     v5, s12, #8
    s.lshri      s12, s15, #32
    s.mul        s14, s9, s7
    v.extract    s7, v0, #13
    s.or         s9, s7, s10
    v.extract    s7, v1, #14
    s.shli       s10, s7, #32
    v.insert     v3, s15, #9
    s.movz       s7, #1024
    v.insert     v5, s12, #9
    s.lshri      s12, s16, #32
    s.mul        s15, s9, s7
    v.extract    s7, v0, #14
    s.or         s9, s7, s10
    v.extract    s7, v1, #15
    s.shli       s10, s7, #32
    v.insert     v3, s16, #10
    s.movz       s7, #1024
    v.insert     v5, s12, #10
    s.lshri      s12, s13, #32
    s.mul        s16, s9, s7
    v.extract    s7, v0, #15
    s.or         s9, s7, s10
    s.movz       s7, #1024
    v.insert     v3, s13, #11
    v.insert     v5, s12, #11
    s.lshri      s10, s14, #32
    s.mul        s12, s9, s7
    v.extract    s7, v6, #0
    v.insert     v3, s14, #12
    v.insert     v5, s10, #12
    s.lshri      s9, s15, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #1
    v.insert     v3, s15, #13
    v.insert     v5, s9, #13
    s.lshri      s9, s16, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #2
    v.insert     v3, s16, #14
    v.insert     v5, s9, #14
    s.lshri      s9, s12, #32
    v.movi       v7, #0
    v.movi       v8, #0
    s.lshri      s14, s13, #32
    s.ashri      s15, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #3
    v.insert     v3, s12, #15
    v.insert     v5, s9, #15
    v.insert     v7, s13, #0
    v.insert     v8, s14, #0
    s.lshri      s9, s15, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #4
    v.insert     v7, s15, #1
    v.insert     v8, s9, #1
    s.lshri      s9, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #5
    v.insert     v7, s12, #2
    v.insert     v8, s9, #2
    s.lshri      s9, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #6
    v.insert     v7, s13, #3
    v.insert     v8, s9, #3
    s.lshri      s9, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #7
    v.insert     v7, s12, #4
    v.insert     v8, s9, #4
    s.lshri      s9, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #8
    v.insert     v7, s13, #5
    v.insert     v8, s9, #5
    s.lshri      s9, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #9
    v.insert     v7, s12, #6
    v.insert     v8, s9, #6
    s.lshri      s9, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #10
    v.insert     v7, s13, #7
    v.insert     v8, s9, #7
    s.lshri      s9, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #11
    v.insert     v7, s12, #8
    v.insert     v8, s9, #8
    s.lshri      s9, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #12
    v.insert     v7, s13, #9
    v.insert     v8, s9, #9
    s.lshri      s9, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #13
    v.insert     v7, s12, #10
    v.insert     v8, s9, #10
    s.lshri      s9, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #14
    v.insert     v7, s13, #11
    v.insert     v8, s9, #11
    s.lshri      s9, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v6, #15
    v.insert     v7, s12, #12
    v.insert     v8, s9, #12
    s.lshri      s9, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s7, #32
    v.insert     v7, s13, #13
    v.insert     v8, s9, #13
    s.lshri      s7, s12, #32
    s.ashri      s9, s10, #32
    v.insert     v7, s12, #14
    v.insert     v8, s7, #14
    s.lshri      s7, s9, #32
    v.insert     v7, s9, #15
    v.insert     v8, s7, #15
    v.extract    s7, v5, #0
    v.extract    s9, v8, #0
    s.shli       s10, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v7, #0
    v.extract    s12, v3, #0
    v.extract    s13, v8, #1
    v.extract    s14, v5, #1
    s.or         s15, s7, s10
    s.or         s7, s12, s9
    s.shli       s9, s13, #32
    s.shli       s10, s14, #32
    v.extract    s12, v7, #1
    v.extract    s13, v3, #1
    v.extract    s14, v8, #2
    v.movi       v6, #0
    s.add        s16, s15, s7
    v.extract    s7, v5, #2
    s.or         s15, s12, s9
    s.or         s9, s13, s10
    s.shli       s10, s14, #32
    s.shli       s12, s7, #32
    v.extract    s7, v7, #2
    v.extract    s13, v3, #2
    v.movi       v9, #0
    v.insert     v6, s16, #0
    s.lshri      s14, s16, #32
    s.add        s16, s15, s9
    v.extract    s9, v8, #3
    s.or         s15, s7, s10
    v.extract    s7, v5, #3
    s.or         s10, s13, s12
    s.shli       s12, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v7, #3
    v.insert     v9, s14, #0
    v.extract    s13, v3, #3
    v.insert     v6, s16, #1
    s.lshri      s14, s16, #32
    s.add        s16, s15, s10
    v.extract    s10, v8, #4
    s.or         s15, s7, s12
    v.extract    s7, v5, #4
    s.or         s12, s13, s9
    s.shli       s9, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v7, #4
    v.insert     v9, s14, #1
    v.extract    s13, v3, #4
    v.insert     v6, s16, #2
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v8, #5
    s.or         s15, s7, s9
    v.extract    s7, v5, #5
    s.or         s9, s13, s10
    s.shli       s10, s12, #32
    s.shli       s12, s7, #32
    v.extract    s7, v7, #5
    v.insert     v9, s14, #2
    v.extract    s13, v3, #5
    v.insert     v6, s16, #3
    s.lshri      s14, s16, #32
    s.add        s16, s15, s9
    v.extract    s9, v8, #6
    s.or         s15, s7, s10
    v.extract    s7, v5, #6
    s.or         s10, s13, s12
    s.shli       s12, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v7, #6
    v.insert     v9, s14, #3
    v.extract    s13, v3, #6
    v.insert     v6, s16, #4
    s.lshri      s14, s16, #32
    s.add        s16, s15, s10
    v.extract    s10, v8, #7
    s.or         s15, s7, s12
    v.extract    s7, v5, #7
    s.or         s12, s13, s9
    s.shli       s9, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v7, #7
    v.insert     v9, s14, #4
    v.extract    s13, v3, #7
    v.insert     v6, s16, #5
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v8, #8
    s.or         s15, s7, s9
    v.extract    s7, v5, #8
    s.or         s9, s13, s10
    s.shli       s10, s12, #32
    s.shli       s12, s7, #32
    v.extract    s7, v7, #8
    v.insert     v9, s14, #5
    v.extract    s13, v3, #8
    v.insert     v6, s16, #6
    s.lshri      s14, s16, #32
    s.add        s16, s15, s9
    v.extract    s9, v8, #9
    s.or         s15, s7, s10
    v.extract    s7, v5, #9
    s.or         s10, s13, s12
    s.shli       s12, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v7, #9
    v.insert     v9, s14, #6
    v.extract    s13, v3, #9
    v.insert     v6, s16, #7
    s.lshri      s14, s16, #32
    s.add        s16, s15, s10
    v.extract    s10, v8, #10
    s.or         s15, s7, s12
    v.extract    s7, v5, #10
    s.or         s12, s13, s9
    s.shli       s9, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v7, #10
    v.insert     v9, s14, #7
    v.extract    s13, v3, #10
    v.insert     v6, s16, #8
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v8, #11
    s.or         s15, s7, s9
    v.extract    s7, v5, #11
    s.or         s9, s13, s10
    s.shli       s10, s12, #32
    s.shli       s12, s7, #32
    v.extract    s7, v7, #11
    v.insert     v9, s14, #8
    v.extract    s13, v3, #11
    v.insert     v6, s16, #9
    s.lshri      s14, s16, #32
    s.add        s16, s15, s9
    v.extract    s9, v8, #12
    s.or         s15, s7, s10
    v.extract    s7, v5, #12
    s.or         s10, s13, s12
    s.shli       s12, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v7, #12
    v.insert     v9, s14, #9
    v.extract    s13, v3, #12
    v.insert     v6, s16, #10
    s.lshri      s14, s16, #32
    s.add        s16, s15, s10
    v.extract    s10, v8, #13
    s.or         s15, s7, s12
    v.extract    s7, v5, #13
    s.or         s12, s13, s9
    s.shli       s9, s10, #32
    s.shli       s10, s7, #32
    v.extract    s7, v7, #13
    v.insert     v9, s14, #10
    v.extract    s13, v3, #13
    v.insert     v6, s16, #11
    s.lshri      s14, s16, #32
    s.add        s16, s15, s12
    v.extract    s12, v8, #14
    s.or         s15, s7, s9
    v.extract    s7, v5, #14
    s.or         s9, s13, s10
    s.shli       s10, s12, #32
    s.shli       s12, s7, #32
    v.extract    s7, v7, #14
    v.insert     v9, s14, #11
    v.extract    s13, v3, #14
    v.insert     v6, s16, #12
    s.lshri      s14, s16, #32
    s.add        s16, s15, s9
    v.extract    s9, v8, #15
    s.or         s15, s7, s10
    v.extract    s7, v5, #15
    s.or         s10, s13, s12
    s.shli       s12, s9, #32
    s.shli       s9, s7, #32
    v.extract    s7, v7, #15
    v.insert     v9, s14, #12
    v.extract    s13, v3, #15
    v.insert     v6, s16, #13
    s.lshri      s14, s16, #32
    s.add        s16, s15, s10
    s.or         s10, s7, s12
    s.or         s7, s13, s9
    v.insert     v9, s14, #13
    v.insert     v6, s16, #14
    s.lshri      s9, s16, #32
    s.add        s12, s10, s7
    v.insert     v9, s9, #14
    v.insert     v6, s12, #15
    s.lshri      s7, s12, #32
    v.movi       v3, #31
    v.insert     v9, s7, #15
    v.ashr       v5, v6, v3
    v.movi       v3, #1
    v.movi       v7, #0
    v.cmp.ne     p2, v9, v5
    @p2 v.sel        v5, v3, v7
    s.movz       s7, #0
    v.reduce.or  s9, v5
    s.cmp.eq     s10, s9, s7
    br.nz        s10, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s5, v6]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    s.add        s7, s6, s3
    s.movz       s9, #1
    vf.cvt.f16.f32 v6, v3
    vf.mul       v3, v6, v6
    vf.add       v6, v4, v3
    @p1 v.sel        v3, v6, v4
    v.mov        v5, v3
    v.mov        v4, v5
    s.mov        s6, s7
    br.nz        s9, for_1
endfor_2:
    s.ld.d       s6, [s2, #0]                    // one element, not a vector
    v.movi       v0, #0
    v.movi       v1, #0
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #0
    v.insert     v1, s2, #0
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #1
    v.insert     v1, s2, #1
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #2
    v.insert     v1, s2, #2
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #3
    v.insert     v1, s2, #3
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #4
    v.insert     v1, s2, #4
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #5
    v.insert     v1, s2, #5
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #6
    v.insert     v1, s2, #6
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #7
    v.insert     v1, s2, #7
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #8
    v.insert     v1, s2, #8
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #9
    v.insert     v1, s2, #9
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #10
    v.insert     v1, s2, #10
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #11
    v.insert     v1, s2, #11
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #12
    v.insert     v1, s2, #12
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #13
    v.insert     v1, s2, #13
    vf.reduce.add.b v3, v4
    v.movi       v4, #0
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #14
    vf.add       v5, v3, v4
    v.insert     v1, s2, #14
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #15
    v.insert     v1, s2, #15
    s.addi       s2, s4, #0
for_5:
    s.cmp.ge     s4, s2, s1
    br.nz        s4, endfor_6
    v.extract    s4, v1, #0
    s.shli       s6, s4, #32
    v.splat      v3, s2
    v.extract    s4, v0, #0
    v.extract    s7, v1, #1
    s.shli       s9, s2, #1                      // element offset -> bytes (x2)
    s.or         s10, s4, s6
    s.movz       s4, #0
    s.shli       s6, s7, #32
    v.add        v4, v3, v2
    v.movi       v3, #1024
    v.extract    s7, v0, #1
    v.extract    s12, v1, #2
    s.add        s13, s8, s9                     // &in_ptr2[...]
    v.movi       v6, #0
    s.cmp.ge     s14, s10, s4
    s.or         s4, s7, s6
    s.movz       s6, #0
    s.shli       s7, s12, #32
    v.cmp.lt     p1, v4, v3
    v.extract    s10, v0, #2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s13, #0]
    v.extract    s12, v1, #3
    v.insert     v6, s14, #0
    s.cmp.ge     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #0
    s.shli       s7, s12, #32
    v.extract    s10, v0, #3
    v.extract    s12, v1, #4
    v.insert     v6, s13, #1
    s.cmp.ge     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #0
    s.shli       s7, s12, #32
    v.extract    s10, v0, #4
    v.extract    s12, v1, #5
    v.insert     v6, s13, #2
    s.cmp.ge     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #0
    s.shli       s7, s12, #32
    v.extract    s10, v0, #5
    v.extract    s12, v1, #6
    v.insert     v6, s13, #3
    s.cmp.ge     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #0
    s.shli       s7, s12, #32
    v.extract    s10, v0, #6
    v.insert     v6, s13, #4
    s.cmp.ge     s12, s4, s6
    s.or         s4, s10, s7
    v.insert     v6, s12, #5
    vf.cvt.f16.f32 v7, v3
    v.extract    s6, v1, #7
    s.movz       s7, #0
    s.shli       s10, s6, #32
    v.extract    s6, v0, #7
    v.extract    s12, v1, #8
    s.cmp.ge     s13, s4, s7
    s.or         s4, s6, s10
    s.movz       s6, #0
    s.shli       s7, s12, #32
    v.extract    s10, v0, #8
    v.extract    s12, v1, #9
    v.insert     v6, s13, #6
    s.cmp.ge     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #0
    s.shli       s7, s12, #32
    v.extract    s10, v0, #9
    v.extract    s12, v1, #10
    v.insert     v6, s13, #7
    s.cmp.ge     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #0
    s.shli       s7, s12, #32
    v.extract    s10, v0, #10
    v.extract    s12, v1, #11
    v.insert     v6, s13, #8
    s.cmp.ge     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #0
    s.shli       s7, s12, #32
    v.extract    s10, v0, #11
    v.extract    s12, v1, #12
    v.insert     v6, s13, #9
    s.cmp.ge     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #0
    s.shli       s7, s12, #32
    v.extract    s10, v0, #12
    v.extract    s12, v1, #13
    v.insert     v6, s13, #10
    s.cmp.ge     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #0
    s.shli       s7, s12, #32
    v.extract    s10, v0, #13
    v.extract    s12, v1, #14
    v.insert     v6, s13, #11
    s.cmp.ge     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #0
    s.shli       s7, s12, #32
    v.extract    s10, v0, #14
    v.extract    s12, v1, #15
    v.insert     v6, s13, #12
    v.extract    s13, v1, #0
    s.cmp.ge     s14, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #0
    s.shli       s7, s12, #32
    s.shli       s10, s13, #32
    v.extract    s12, v0, #15
    v.insert     v6, s14, #13
    v.extract    s13, v0, #0
    s.cmp.ge     s14, s4, s6
    v.extract    s4, v1, #1
    s.or         s6, s12, s7
    s.movz       s7, #0
    s.or         s12, s13, s10
    s.movz       s10, #32000
    s.shli       s13, s4, #32
    v.insert     v6, s14, #14
    v.extract    s4, v0, #1
    s.cmp.ge     s14, s6, s7
    v.extract    s6, v1, #2
    v.movi       v3, #0
    s.cmp.lt     s7, s12, s10
    s.or         s10, s4, s13
    s.movz       s4, #32000
    s.shli       s12, s6, #32
    v.extract    s6, v0, #2
    v.insert     v6, s14, #15
    v.extract    s13, v1, #3
    v.insert     v3, s7, #0
    s.cmp.lt     s7, s10, s4
    s.or         s4, s6, s12
    s.movz       s6, #32000
    s.shli       s10, s13, #32
    v.extract    s12, v0, #3
    v.extract    s13, v1, #4
    v.insert     v3, s7, #1
    s.cmp.lt     s7, s4, s6
    s.or         s4, s12, s10
    s.movz       s6, #32000
    s.shli       s10, s13, #32
    v.extract    s12, v0, #4
    v.extract    s13, v1, #5
    v.insert     v3, s7, #2
    s.cmp.lt     s7, s4, s6
    s.or         s4, s12, s10
    s.movz       s6, #32000
    s.shli       s10, s13, #32
    v.extract    s12, v0, #5
    v.extract    s13, v1, #6
    v.insert     v3, s7, #3
    s.cmp.lt     s7, s4, s6
    s.or         s4, s12, s10
    s.movz       s6, #32000
    s.shli       s10, s13, #32
    v.extract    s12, v0, #6
    v.insert     v3, s7, #4
    s.cmp.lt     s7, s4, s6
    v.movi       v8, #0
    s.or         s4, s12, s10
    v.insert     v3, s7, #5
    v.cmp.ne     p2, v6, v8
    v.extract    s6, v1, #7
    s.movz       s7, #32000
    s.shli       s10, s6, #32
    v.extract    s6, v0, #7
    v.extract    s12, v1, #8
    s.cmp.lt     s13, s4, s7
    s.or         s4, s6, s10
    s.movz       s6, #32000
    s.shli       s7, s12, #32
    v.extract    s10, v0, #8
    v.extract    s12, v1, #9
    v.insert     v3, s13, #6
    s.cmp.lt     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #32000
    s.shli       s7, s12, #32
    v.extract    s10, v0, #9
    v.extract    s12, v1, #10
    v.insert     v3, s13, #7
    s.cmp.lt     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #32000
    s.shli       s7, s12, #32
    v.extract    s10, v0, #10
    v.extract    s12, v1, #11
    v.insert     v3, s13, #8
    s.cmp.lt     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #32000
    s.shli       s7, s12, #32
    v.extract    s10, v0, #11
    v.extract    s12, v1, #12
    v.insert     v3, s13, #9
    s.cmp.lt     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #32000
    s.shli       s7, s12, #32
    v.extract    s10, v0, #12
    v.extract    s12, v1, #13
    v.insert     v3, s13, #10
    s.cmp.lt     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #32000
    s.shli       s7, s12, #32
    v.extract    s10, v0, #13
    v.extract    s12, v1, #14
    v.insert     v3, s13, #11
    s.cmp.lt     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #32000
    s.shli       s7, s12, #32
    v.extract    s10, v0, #14
    v.extract    s12, v1, #15
    v.insert     v3, s13, #12
    s.cmp.lt     s13, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #32000
    s.shli       s7, s12, #32
    v.extract    s10, v0, #15
    v.insert     v3, s13, #13
    s.cmp.lt     s12, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #32000
    v.insert     v3, s12, #14
    s.cmp.lt     s7, s4, s6
    v.movi       v6, #0
    v.insert     v3, s7, #15
    v.movi       v8, #0
    v.cmp.ne     p3, v3, v6
    p.and        p4, p2, p3
    v.movi       v3, #1
    s.movz       s4, #0
    @p4 v.sel        v6, v8, v3
    v.reduce.or  s6, v6
    s.cmp.eq     s7, s6, s4
    br.nz        s7, assert_ok_7
    trap         #677351
assert_ok_7:
    v.extract    s4, v1, #0
    s.shli       s6, s4, #32
    v.extract    s4, v0, #0
    v.extract    s7, v1, #1
    s.or         s10, s4, s6
    s.movz       s4, #1024
    s.shli       s6, s7, #32
    v.extract    s7, v0, #1
    v.extract    s12, v1, #2
    s.mul        s13, s10, s4
    s.or         s4, s7, s6
    s.movz       s6, #1024
    s.shli       s7, s12, #32
    v.extract    s10, v0, #2
    v.extract    s12, v1, #3
    s.mul        s14, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #1024
    s.shli       s7, s12, #32
    v.extract    s10, v0, #3
    v.extract    s12, v1, #4
    s.mul        s15, s4, s6
    s.or         s4, s10, s7
    s.movz       s6, #1024
    s.shli       s7, s12, #32
    v.movi       v3, #0
    v.movi       v6, #0
    s.lshri      s10, s13, #32
    s.mul        s12, s4, s6
    v.extract    s4, v0, #4
    s.or         s6, s4, s7
    v.extract    s4, v1, #5
    s.shli       s7, s4, #32
    v.insert     v3, s13, #0
    s.movz       s4, #1024
    v.insert     v6, s10, #0
    s.lshri      s10, s14, #32
    s.mul        s13, s6, s4
    v.extract    s4, v0, #5
    s.or         s6, s4, s7
    v.extract    s4, v1, #6
    s.shli       s7, s4, #32
    v.insert     v3, s14, #1
    s.movz       s4, #1024
    v.insert     v6, s10, #1
    s.lshri      s10, s15, #32
    s.mul        s14, s6, s4
    v.extract    s4, v0, #6
    s.or         s6, s4, s7
    v.extract    s4, v1, #7
    s.shli       s7, s4, #32
    v.insert     v3, s15, #2
    s.movz       s4, #1024
    v.insert     v6, s10, #2
    s.lshri      s10, s12, #32
    s.mul        s15, s6, s4
    v.extract    s4, v0, #7
    s.or         s6, s4, s7
    v.extract    s4, v1, #8
    s.shli       s7, s4, #32
    v.insert     v3, s12, #3
    s.movz       s4, #1024
    v.insert     v6, s10, #3
    s.lshri      s10, s13, #32
    s.mul        s12, s6, s4
    v.extract    s4, v0, #8
    s.or         s6, s4, s7
    v.extract    s4, v1, #9
    s.shli       s7, s4, #32
    v.insert     v3, s13, #4
    s.movz       s4, #1024
    v.insert     v6, s10, #4
    s.lshri      s10, s14, #32
    s.mul        s13, s6, s4
    v.extract    s4, v0, #9
    s.or         s6, s4, s7
    v.extract    s4, v1, #10
    s.shli       s7, s4, #32
    v.insert     v3, s14, #5
    s.movz       s4, #1024
    v.insert     v6, s10, #5
    s.lshri      s10, s15, #32
    s.mul        s14, s6, s4
    v.extract    s4, v0, #10
    s.or         s6, s4, s7
    v.extract    s4, v1, #11
    s.shli       s7, s4, #32
    v.insert     v3, s15, #6
    s.movz       s4, #1024
    v.insert     v6, s10, #6
    s.lshri      s10, s12, #32
    s.mul        s15, s6, s4
    v.extract    s4, v0, #11
    s.or         s6, s4, s7
    v.extract    s4, v1, #12
    s.shli       s7, s4, #32
    v.insert     v3, s12, #7
    s.movz       s4, #1024
    v.insert     v6, s10, #7
    s.lshri      s10, s13, #32
    s.mul        s12, s6, s4
    v.extract    s4, v0, #12
    s.or         s6, s4, s7
    v.extract    s4, v1, #13
    s.shli       s7, s4, #32
    v.insert     v3, s13, #8
    s.movz       s4, #1024
    v.insert     v6, s10, #8
    s.lshri      s10, s14, #32
    s.mul        s13, s6, s4
    v.extract    s4, v0, #13
    s.or         s6, s4, s7
    v.extract    s4, v1, #14
    s.shli       s7, s4, #32
    v.insert     v3, s14, #9
    s.movz       s4, #1024
    v.insert     v6, s10, #9
    s.lshri      s10, s15, #32
    s.mul        s14, s6, s4
    v.extract    s4, v0, #14
    s.or         s6, s4, s7
    v.extract    s4, v1, #15
    s.shli       s7, s4, #32
    v.insert     v3, s15, #10
    s.movz       s4, #1024
    v.insert     v6, s10, #10
    s.lshri      s10, s12, #32
    s.mul        s15, s6, s4
    v.extract    s4, v0, #15
    s.or         s6, s4, s7
    s.movz       s4, #1024
    v.insert     v3, s12, #11
    v.insert     v6, s10, #11
    s.lshri      s7, s13, #32
    s.mul        s10, s6, s4
    v.extract    s4, v4, #0
    v.insert     v3, s13, #12
    v.insert     v6, s7, #12
    s.lshri      s6, s14, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #1
    v.insert     v3, s14, #13
    v.insert     v6, s6, #13
    s.lshri      s6, s15, #32
    s.ashri      s12, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #2
    v.insert     v3, s15, #14
    v.insert     v6, s6, #14
    s.lshri      s6, s10, #32
    v.movi       v8, #0
    v.movi       v9, #0
    s.lshri      s13, s12, #32
    s.ashri      s14, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #3
    v.insert     v3, s10, #15
    v.insert     v6, s6, #15
    v.insert     v8, s12, #0
    v.insert     v9, s13, #0
    s.lshri      s6, s14, #32
    s.ashri      s10, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #4
    v.insert     v8, s14, #1
    v.insert     v9, s6, #1
    s.lshri      s6, s10, #32
    s.ashri      s12, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #5
    v.insert     v8, s10, #2
    v.insert     v9, s6, #2
    s.lshri      s6, s12, #32
    s.ashri      s10, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #6
    v.insert     v8, s12, #3
    v.insert     v9, s6, #3
    s.lshri      s6, s10, #32
    s.ashri      s12, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #7
    v.insert     v8, s10, #4
    v.insert     v9, s6, #4
    s.lshri      s6, s12, #32
    s.ashri      s10, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #8
    v.insert     v8, s12, #5
    v.insert     v9, s6, #5
    s.lshri      s6, s10, #32
    s.ashri      s12, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #9
    v.insert     v8, s10, #6
    v.insert     v9, s6, #6
    s.lshri      s6, s12, #32
    s.ashri      s10, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #10
    v.insert     v8, s12, #7
    v.insert     v9, s6, #7
    s.lshri      s6, s10, #32
    s.ashri      s12, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #11
    v.insert     v8, s10, #8
    v.insert     v9, s6, #8
    s.lshri      s6, s12, #32
    s.ashri      s10, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #12
    v.insert     v8, s12, #9
    v.insert     v9, s6, #9
    s.lshri      s6, s10, #32
    s.ashri      s12, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #13
    v.insert     v8, s10, #10
    v.insert     v9, s6, #10
    s.lshri      s6, s12, #32
    s.ashri      s10, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #14
    v.insert     v8, s12, #11
    v.insert     v9, s6, #11
    s.lshri      s6, s10, #32
    s.ashri      s12, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v4, #15
    v.insert     v8, s10, #12
    v.insert     v9, s6, #12
    s.lshri      s6, s12, #32
    s.ashri      s10, s7, #32
    s.shli       s7, s4, #32
    v.insert     v8, s12, #13
    v.insert     v9, s6, #13
    s.lshri      s4, s10, #32
    s.ashri      s6, s7, #32
    v.insert     v8, s10, #14
    v.insert     v9, s4, #14
    s.lshri      s4, s6, #32
    v.insert     v8, s6, #15
    v.insert     v9, s4, #15
    v.extract    s4, v6, #0
    v.extract    s6, v9, #0
    s.shli       s7, s6, #32
    s.shli       s6, s4, #32
    v.extract    s4, v8, #0
    v.extract    s10, v3, #0
    v.extract    s12, v9, #1
    v.extract    s13, v6, #1
    s.or         s14, s4, s7
    s.or         s4, s10, s6
    s.shli       s6, s12, #32
    s.shli       s7, s13, #32
    v.extract    s10, v8, #1
    v.extract    s12, v3, #1
    v.extract    s13, v9, #2
    v.movi       v4, #0
    s.add        s15, s14, s4
    v.extract    s4, v6, #2
    s.or         s14, s10, s6
    s.or         s6, s12, s7
    s.shli       s7, s13, #32
    s.shli       s10, s4, #32
    v.extract    s4, v8, #2
    v.extract    s12, v3, #2
    v.movi       v10, #0
    v.insert     v4, s15, #0
    s.lshri      s13, s15, #32
    s.add        s15, s14, s6
    v.extract    s6, v9, #3
    s.or         s14, s4, s7
    v.extract    s4, v6, #3
    s.or         s7, s12, s10
    s.shli       s10, s6, #32
    s.shli       s6, s4, #32
    v.extract    s4, v8, #3
    v.insert     v10, s13, #0
    v.extract    s12, v3, #3
    v.insert     v4, s15, #1
    s.lshri      s13, s15, #32
    s.add        s15, s14, s7
    v.extract    s7, v9, #4
    s.or         s14, s4, s10
    v.extract    s4, v6, #4
    s.or         s10, s12, s6
    s.shli       s6, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v8, #4
    v.insert     v10, s13, #1
    v.extract    s12, v3, #4
    v.insert     v4, s15, #2
    s.lshri      s13, s15, #32
    s.add        s15, s14, s10
    v.extract    s10, v9, #5
    s.or         s14, s4, s6
    v.extract    s4, v6, #5
    s.or         s6, s12, s7
    s.shli       s7, s10, #32
    s.shli       s10, s4, #32
    v.extract    s4, v8, #5
    v.insert     v10, s13, #2
    v.extract    s12, v3, #5
    v.insert     v4, s15, #3
    s.lshri      s13, s15, #32
    s.add        s15, s14, s6
    v.extract    s6, v9, #6
    s.or         s14, s4, s7
    v.extract    s4, v6, #6
    s.or         s7, s12, s10
    s.shli       s10, s6, #32
    s.shli       s6, s4, #32
    v.extract    s4, v8, #6
    v.insert     v10, s13, #3
    v.extract    s12, v3, #6
    v.insert     v4, s15, #4
    s.lshri      s13, s15, #32
    s.add        s15, s14, s7
    v.extract    s7, v9, #7
    s.or         s14, s4, s10
    v.extract    s4, v6, #7
    s.or         s10, s12, s6
    s.shli       s6, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v8, #7
    v.insert     v10, s13, #4
    v.extract    s12, v3, #7
    v.insert     v4, s15, #5
    s.lshri      s13, s15, #32
    s.add        s15, s14, s10
    v.extract    s10, v9, #8
    s.or         s14, s4, s6
    v.extract    s4, v6, #8
    s.or         s6, s12, s7
    s.shli       s7, s10, #32
    s.shli       s10, s4, #32
    v.extract    s4, v8, #8
    v.insert     v10, s13, #5
    v.extract    s12, v3, #8
    v.insert     v4, s15, #6
    s.lshri      s13, s15, #32
    s.add        s15, s14, s6
    v.extract    s6, v9, #9
    s.or         s14, s4, s7
    v.extract    s4, v6, #9
    s.or         s7, s12, s10
    s.shli       s10, s6, #32
    s.shli       s6, s4, #32
    v.extract    s4, v8, #9
    v.insert     v10, s13, #6
    v.extract    s12, v3, #9
    v.insert     v4, s15, #7
    s.lshri      s13, s15, #32
    s.add        s15, s14, s7
    v.extract    s7, v9, #10
    s.or         s14, s4, s10
    v.extract    s4, v6, #10
    s.or         s10, s12, s6
    s.shli       s6, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v8, #10
    v.insert     v10, s13, #7
    v.extract    s12, v3, #10
    v.insert     v4, s15, #8
    s.lshri      s13, s15, #32
    s.add        s15, s14, s10
    v.extract    s10, v9, #11
    s.or         s14, s4, s6
    v.extract    s4, v6, #11
    s.or         s6, s12, s7
    s.shli       s7, s10, #32
    s.shli       s10, s4, #32
    v.extract    s4, v8, #11
    v.insert     v10, s13, #8
    v.extract    s12, v3, #11
    v.insert     v4, s15, #9
    s.lshri      s13, s15, #32
    s.add        s15, s14, s6
    v.extract    s6, v9, #12
    s.or         s14, s4, s7
    v.extract    s4, v6, #12
    s.or         s7, s12, s10
    s.shli       s10, s6, #32
    s.shli       s6, s4, #32
    v.extract    s4, v8, #12
    v.insert     v10, s13, #9
    v.extract    s12, v3, #12
    v.insert     v4, s15, #10
    s.lshri      s13, s15, #32
    s.add        s15, s14, s7
    v.extract    s7, v9, #13
    s.or         s14, s4, s10
    v.extract    s4, v6, #13
    s.or         s10, s12, s6
    s.shli       s6, s7, #32
    s.shli       s7, s4, #32
    v.extract    s4, v8, #13
    v.insert     v10, s13, #10
    v.extract    s12, v3, #13
    v.insert     v4, s15, #11
    s.lshri      s13, s15, #32
    s.add        s15, s14, s10
    v.extract    s10, v9, #14
    s.or         s14, s4, s6
    v.extract    s4, v6, #14
    s.or         s6, s12, s7
    s.shli       s7, s10, #32
    s.shli       s10, s4, #32
    v.extract    s4, v8, #14
    v.insert     v10, s13, #11
    v.extract    s12, v3, #14
    v.insert     v4, s15, #12
    s.lshri      s13, s15, #32
    s.add        s15, s14, s6
    v.extract    s6, v9, #15
    s.or         s14, s4, s7
    v.extract    s4, v6, #15
    s.or         s7, s12, s10
    s.shli       s10, s6, #32
    s.shli       s6, s4, #32
    v.extract    s4, v8, #15
    v.insert     v10, s13, #12
    v.extract    s12, v3, #15
    v.insert     v4, s15, #13
    s.lshri      s13, s15, #32
    s.add        s15, s14, s7
    s.or         s7, s4, s10
    s.or         s4, s12, s6
    v.insert     v10, s13, #13
    v.insert     v4, s15, #14
    s.lshri      s6, s15, #32
    s.add        s10, s7, s4
    v.insert     v10, s6, #14
    v.insert     v4, s10, #15
    s.lshri      s4, s10, #32
    v.movi       v3, #31
    v.insert     v10, s4, #15
    v.ashr       v6, v4, v3
    v.movi       v3, #1
    v.movi       v8, #0
    v.cmp.ne     p2, v10, v6
    @p2 v.sel        v6, v3, v8
    s.movz       s4, #0
    v.reduce.or  s6, v6
    s.cmp.eq     s7, s6, s4
    br.nz        s7, narrow_ok_8
    trap         #677220
narrow_ok_8:
    .li       s4, #1149239296
    v.splat      v3, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #1065353216
    v.splat      v6, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v8, v3                          // ISA 8.8: <= 2**-22 relative
    .li       s4, #925353388
    v.splat      v9, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #1077936128
    v.splat      v10, s4                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #3204448256
    v.splat      v11, s4                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v12, [s5, v4]              // index is in elements (ISA sec 9.1)
    s.add        s4, s11, s9                     // &out_ptr1[...]
    s.add        s6, s2, s3
    s.movz       s7, #1
    vf.cvt.f16.f32 v4, v12
    vf.fms       v12, v3, v8, v6
    vf.fms       v3, v8, v12, v8
    vf.neg       v6, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v3, v6, v8
    vf.mul       v6, v5, v3                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v3, v6, v9
    v.rsqrt.approx v6, v3                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v6, v6
    vf.mul       v9, v6, v11
    vf.fms       v11, v3, v8, v10
    vf.mul       v3, v9, v11                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v8, v3, v6
    v.extract    s9, v8, #0
    v.splat      v3, s9
    vf.mul       v6, v4, v3
    vf.mul       v3, v6, v7
    vf.cvt.f32.f16 v4, v3
    @p1 v.st.h       [s4, #0], v4
    s.mov        s2, s6
    br.nz        s7, for_5
endfor_6:
    exit
    exit
