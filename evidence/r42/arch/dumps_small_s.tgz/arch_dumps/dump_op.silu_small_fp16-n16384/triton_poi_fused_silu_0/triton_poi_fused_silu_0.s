    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (2 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    .li       s9, #1069066811
    v.splat      v0, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s9, #1060205080
    v.splat      v1, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s9, #1065353216
    v.splat      v2, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
tiles_1:
    // tile 1 of the iteration: lanes t0 + 128
    s.addi       s9, s8, #128
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s10, s1, s8
    s.add        s11, s1, s9
    s.shli       s9, s10, #1
    s.shli       s10, s11, #1
    s.add        s11, s3, s9
    s.add        s12, s3, s10
    v.ld.h       v3, [s11, #0]
    v.ld.h       v4, [s11, #32]
    vf.cvt.f16.f32 v5, v3
    vf.neg       v3, v5
    vf.mul       v6, v3, v0
    v.ld.h       v7, [s11, #64]
    vf.cvt.f16.f32 v8, v4
    v.exp2.approx v4, v6                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v3, v0, v6                  // the exact rounding error of x*log2(e)
    vf.neg       v3, v8
    vf.mul       v6, v9, v1
    vf.mul       v9, v3, v0
    v.ld.h       v10, [s11, #96]
    vf.cvt.f16.f32 v11, v7
    v.exp2.approx v7, v9                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v12, v3, v0, v9                 // the exact rounding error of x*log2(e)
    vf.neg       v3, v11
    vf.mul       v9, v12, v1
    vf.mul       v12, v3, v0
    v.ld.h       v13, [s11, #128]
    vf.cvt.f16.f32 v14, v10
    v.exp2.approx v10, v12                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v15, v3, v0, v12                // the exact rounding error of x*log2(e)
    vf.fma       v3, v4, v6, v4                  // 2**t * 2**d
    vf.neg       v6, v14
    vf.mul       v12, v15, v1
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v15, v3, v4
    v.ld.h       v3, [s11, #160]
    vf.cvt.f16.f32 v4, v13
    vf.fma       v13, v7, v9, v7                 // 2**t * 2**d
    vf.neg       v9, v4
    vf.cmp.o     p1, v13, v13
    @p1 v.sel        v16, v13, v7
    v.ld.h       v7, [s11, #192]
    vf.cvt.f16.f32 v13, v3
    vf.fma       v3, v10, v12, v10               // 2**t * 2**d
    vf.neg       v12, v13
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v17, v3, v10
    v.ld.h       v3, [s11, #224]
    vf.cvt.f16.f32 v10, v7
    vf.mul       v7, v6, v0
    vf.neg       v18, v10
    v.exp2.approx v19, v7                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v20, v6, v0, v7                 // the exact rounding error of x*log2(e)
    v.ld.h       v6, [s12, #0]
    vf.cvt.f16.f32 v7, v3
    vf.mul       v3, v20, v1
    vf.neg       v20, v7
    v.ld.h       v21, [s12, #32]
    vf.fma       v22, v19, v3, v19               // 2**t * 2**d
    v.ld.h       v3, [s12, #64]
    vf.cmp.o     p1, v22, v22
    v.ld.h       v23, [s12, #96]
    @p1 v.sel        v24, v22, v19
    v.ld.h       v19, [s12, #128]
    vf.mul       v22, v9, v0
    v.ld.h       v25, [s12, #160]
    vf.fms       v26, v9, v0, v22                // the exact rounding error of x*log2(e)
    v.ld.h       v9, [s12, #192]
    v.exp2.approx v27, v22                       // ISA 8.8: <= 2**-22 relative
    v.ld.h       v22, [s12, #224]
    vf.mul       v28, v12, v0
    vf.mul       v29, v18, v0
    vf.mul       v30, v20, v0
    vf.mul       v31, v26, v1
    vf.add       v26, v15, v2
    v.exp2.approx v15, v28                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v32, v12, v0, v28               // the exact rounding error of x*log2(e)
    v.exp2.approx v12, v29                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v28, v18, v0, v29               // the exact rounding error of x*log2(e)
    v.exp2.approx v18, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v29, v20, v0, v30               // the exact rounding error of x*log2(e)
    vf.mul       v20, v32, v1
    vf.add       v30, v16, v2
    vf.mul       v16, v28, v1
    vf.fma       v28, v27, v31, v27              // 2**t * 2**d
    vf.mul       v31, v29, v1
    vf.add       v29, v17, v2
    vf.add       v17, v24, v2
    v.rcp.approx v24, v26                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v32, v28, v27
    v.rcp.approx v27, v30                        // ISA 8.8: <= 2**-22 relative
    vf.add       v28, v32, v2
    vf.fma       v32, v15, v20, v15              // 2**t * 2**d
    vf.fma       v20, v12, v16, v12              // 2**t * 2**d
    vf.fma       v16, v18, v31, v18              // 2**t * 2**d
    vf.cmp.o     p1, v32, v32
    @p1 v.sel        v31, v32, v15
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v15, v20, v12
    vf.cmp.o     p1, v16, v16
    @p1 v.sel        v12, v16, v18
    vf.add       v16, v31, v2
    vf.add       v18, v15, v2
    vf.add       v15, v12, v2
    v.rcp.approx v12, v29                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v20, v17                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v31, v28                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v32, v26, v24, v2
    vf.fms       v26, v30, v27, v2
    vf.fms       v30, v24, v32, v24
    vf.fms       v32, v27, v26, v27
    vf.neg       v26, v30                        // Newton step: r0*(2 - x*r0)
    vf.neg       v30, v32                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v26, v26
    vf.cmp.o     p2, v30, v30
    @p1 v.sel        v32, v26, v24
    v.rcp.approx v24, v16                        // ISA 8.8: <= 2**-22 relative
    @p2 v.sel        v26, v30, v27
    v.rcp.approx v27, v18                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v30, v5, v32                    // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v5, v15                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v32, v8, v26                    // a/y as a refined reciprocal (ISA has no divide)
    vf.fms       v8, v29, v12, v2
    vf.fms       v26, v17, v20, v2
    vf.fms       v17, v28, v31, v2
    vf.cvt.f32.f16 v28, v30
    vf.cvt.f32.f16 v29, v32
    vf.fms       v30, v12, v8, v12
    vf.fms       v8, v20, v26, v20
    vf.fms       v26, v31, v17, v31
    s.add        s11, s7, s9
    vf.neg       v17, v30                        // Newton step: r0*(2 - x*r0)
    vf.neg       v30, v8                         // Newton step: r0*(2 - x*r0)
    vf.neg       v8, v26                         // Newton step: r0*(2 - x*r0)
    v.st.h       [s11, #0], v28
    vf.cmp.o     p1, v17, v17
    vf.cmp.o     p2, v30, v30
    @p1 v.sel        v26, v17, v12
    vf.cmp.o     p1, v8, v8
    @p2 v.sel        v12, v30, v20
    @p1 v.sel        v17, v8, v31
    vf.fms       v8, v16, v24, v2
    vf.mul       v16, v11, v26                   // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f16.f32 v11, v6
    vf.cvt.f16.f32 v6, v21
    vf.fms       v20, v18, v27, v2
    vf.fms       v18, v15, v5, v2
    vf.fms       v15, v24, v8, v24
    vf.mul       v8, v14, v12                    // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f16.f32 v12, v3
    vf.cvt.f16.f32 v3, v23
    vf.cvt.f16.f32 v14, v19
    vf.cvt.f16.f32 v19, v25
    vf.cvt.f16.f32 v21, v9
    vf.cvt.f16.f32 v9, v22
    vf.neg       v22, v11
    vf.fms       v23, v27, v20, v27
    vf.fms       v20, v5, v18, v5
    vf.neg       v18, v15                        // Newton step: r0*(2 - x*r0)
    vf.mul       v15, v4, v17                    // a/y as a refined reciprocal (ISA has no divide)
    vf.neg       v4, v6
    vf.neg       v17, v12
    vf.neg       v25, v3
    vf.neg       v26, v14
    vf.neg       v28, v19
    vf.neg       v30, v23                        // Newton step: r0*(2 - x*r0)
    vf.neg       v23, v20                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v18, v18
    vf.neg       v20, v21
    @p1 v.sel        v31, v18, v24
    vf.neg       v18, v9
    vf.cmp.o     p1, v30, v30
    vf.cmp.o     p2, v23, v23
    @p1 v.sel        v24, v30, v27
    @p2 v.sel        v27, v23, v5
    vf.mul       v5, v13, v31                    // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v13, v22, v0
    vf.mul       v23, v10, v24                   // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v10, v4, v0
    vf.mul       v24, v7, v27                    // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v7, v17, v0
    v.exp2.approx v27, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v30, v22, v0, v13               // the exact rounding error of x*log2(e)
    v.exp2.approx v13, v10                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v22, v4, v0, v10                // the exact rounding error of x*log2(e)
    v.exp2.approx v4, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v17, v0, v7                // the exact rounding error of x*log2(e)
    vf.mul       v7, v30, v1
    vf.cvt.f32.f16 v17, v16
    vf.mul       v16, v22, v1
    vf.cvt.f32.f16 v22, v8
    vf.mul       v8, v10, v1
    vf.cvt.f32.f16 v10, v15
    vf.cvt.f32.f16 v15, v5
    vf.cvt.f32.f16 v5, v23
    vf.mul       v23, v25, v0
    vf.cvt.f32.f16 v30, v24
    v.st.h       [s11, #32], v29
    v.exp2.approx v24, v23                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v29, v25, v0, v23               // the exact rounding error of x*log2(e)
    vf.mul       v23, v29, v1
    vf.fma       v25, v27, v7, v27               // 2**t * 2**d
    vf.fma       v7, v13, v16, v13               // 2**t * 2**d
    v.st.h       [s11, #64], v17
    vf.fma       v16, v4, v8, v4                 // 2**t * 2**d
    vf.cmp.o     p1, v25, v25
    @p1 v.sel        v8, v25, v27
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v17, v7, v13
    vf.cmp.o     p1, v16, v16
    @p1 v.sel        v7, v16, v4
    v.st.h       [s11, #96], v22
    vf.fma       v4, v24, v23, v24               // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v13, v4, v24
    v.st.h       [s11, #128], v10
    vf.mul       v4, v26, v0
    v.st.h       [s11, #160], v15
    vf.fms       v10, v26, v0, v4                // the exact rounding error of x*log2(e)
    v.st.h       [s11, #192], v5
    v.exp2.approx v5, v4                         // ISA 8.8: <= 2**-22 relative
    v.st.h       [s11, #224], v30
    vf.mul       v4, v28, v0
    vf.mul       v15, v20, v0
    vf.mul       v16, v18, v0
    vf.mul       v22, v10, v1
    vf.add       v10, v8, v2
    v.exp2.approx v8, v4                         // ISA 8.8: <= 2**-22 relative
    v.exp2.approx v23, v15                       // ISA 8.8: <= 2**-22 relative
    v.exp2.approx v24, v16                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v25, v28, v0, v4                // the exact rounding error of x*log2(e)
    vf.fms       v4, v20, v0, v15                // the exact rounding error of x*log2(e)
    vf.fms       v15, v18, v0, v16               // the exact rounding error of x*log2(e)
    vf.add       v16, v17, v2
    vf.add       v17, v7, v2
    vf.mul       v7, v25, v1
    vf.mul       v18, v4, v1
    vf.mul       v4, v15, v1
    vf.fma       v15, v5, v22, v5                // 2**t * 2**d
    vf.add       v20, v13, v2
    v.rcp.approx v13, v10                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v22, v16                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v25, v17                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v15, v15
    @p1 v.sel        v26, v15, v5
    v.rcp.approx v5, v20                         // ISA 8.8: <= 2**-22 relative
    vf.add       v15, v26, v2
    vf.fma       v26, v8, v7, v8                 // 2**t * 2**d
    vf.fma       v7, v23, v18, v23               // 2**t * 2**d
    vf.fma       v18, v24, v4, v24               // 2**t * 2**d
    vf.cmp.o     p1, v26, v26
    vf.cmp.o     p2, v7, v7
    @p1 v.sel        v4, v26, v8
    vf.cmp.o     p1, v18, v18
    @p2 v.sel        v8, v7, v23
    @p1 v.sel        v7, v18, v24
    vf.add       v18, v4, v2
    vf.add       v4, v8, v2
    vf.add       v8, v7, v2
    v.rcp.approx v7, v15                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v23, v10, v13, v2
    v.rcp.approx v10, v18                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v24, v4                         // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v26, v8                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v27, v16, v22, v2
    vf.fms       v16, v17, v25, v2
    vf.fms       v17, v20, v5, v2
    vf.fms       v20, v13, v23, v13
    vf.fms       v23, v22, v27, v22
    vf.fms       v27, v25, v16, v25
    vf.fms       v16, v5, v17, v5
    vf.neg       v17, v20                        // Newton step: r0*(2 - x*r0)
    vf.neg       v20, v23                        // Newton step: r0*(2 - x*r0)
    vf.neg       v23, v27                        // Newton step: r0*(2 - x*r0)
    vf.neg       v27, v16                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v17, v17
    @p1 v.sel        v16, v17, v13
    vf.cmp.o     p1, v20, v20
    vf.cmp.o     p2, v23, v23
    @p1 v.sel        v13, v20, v22
    vf.cmp.o     p1, v27, v27
    @p2 v.sel        v17, v23, v25
    @p1 v.sel        v20, v27, v5
    vf.mul       v5, v11, v16                    // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v11, v6, v13                    // a/y as a refined reciprocal (ISA has no divide)
    vf.fms       v6, v15, v7, v2
    vf.mul       v13, v12, v17                   // a/y as a refined reciprocal (ISA has no divide)
    vf.fms       v12, v18, v10, v2
    vf.fms       v15, v4, v24, v2
    vf.fms       v4, v8, v26, v2
    vf.fms       v8, v7, v6, v7
    vf.mul       v6, v3, v20                     // a/y as a refined reciprocal (ISA has no divide)
    vf.fms       v3, v10, v12, v10
    vf.fms       v12, v24, v15, v24
    vf.fms       v15, v26, v4, v26
    vf.neg       v4, v8                          // Newton step: r0*(2 - x*r0)
    vf.cvt.f32.f16 v8, v5
    vf.neg       v5, v3                          // Newton step: r0*(2 - x*r0)
    vf.neg       v3, v12                         // Newton step: r0*(2 - x*r0)
    vf.neg       v12, v15                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v15, v4, v7
    vf.cmp.o     p1, v5, v5
    vf.cmp.o     p2, v3, v3
    @p1 v.sel        v4, v5, v10
    vf.cmp.o     p1, v12, v12
    @p2 v.sel        v5, v3, v24
    @p1 v.sel        v3, v12, v26
    vf.mul       v7, v14, v15                    // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v10, v19, v4                    // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v4, v21, v5                     // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v5, v9, v3                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.f16 v3, v11
    vf.cvt.f32.f16 v9, v13
    vf.cvt.f32.f16 v11, v6
    vf.cvt.f32.f16 v6, v7
    vf.cvt.f32.f16 v7, v10
    vf.cvt.f32.f16 v10, v4
    vf.cvt.f32.f16 v4, v5
    s.add        s9, s7, s10
    v.st.h       [s9, #0], v8
    v.st.h       [s9, #32], v3
    v.st.h       [s9, #64], v9
    v.st.h       [s9, #96], v11
    v.st.h       [s9, #128], v6
    v.st.h       [s9, #160], v7
    v.st.h       [s9, #192], v10
    v.st.h       [s9, #224], v4
    s.addi       s8, s8, #256
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
