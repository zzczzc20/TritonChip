    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.rdspecial  s1, pid.y
    s.shli       s5, s1, #4                      // x16 as a shift
    s.shli       s1, s4, #4                      // x16 as a shift
    s.rdspecial  s4, arg_base
    s.ld.d       s6, [s4, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s4, role_id
    s.movz       s7, #2048
    s.mul        s8, s4, s7
    s.add        s4, s6, s8                      // this context's own scratch
    s.addi       s6, s4, #0
    s.movz       s7, #0
    v.splat      v0, s7
    s.add        s8, s7, s5                      // the tile origin
    v.splat      v1, s8
    s.movz       s9, #64
    v.splat      v2, s9
    v.movi       v3, #0
    v.cmp.lt     p1, v1, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v1
    @p1 v.sel        v5, v4, v1
    v.sub        v1, v3, v2
    @p2 v.sel        v4, v1, v2
    v.movi       v1, #63
    v.and        v4, v5, v1
    v.sub        v1, v3, v4
    @p1 v.sel        v3, v1, v4
    s.muli       s10, s1, #64                    // a runtime tile origin, x64
    s.add        s11, s7, s10                    // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v4, s9
    v.mul        v5, v1, v4
    v.splat      v1, s11
    v.add        v4, v5, v1
    v.add        v1, v3, v4
    v.splat      v3, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v3, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v3
    @p1 v.sel        v7, v6, v3
    v.sub        v3, v5, v2
    @p2 v.sel        v6, v3, v2
    v.movi       v3, #6
    v.lshr       v6, v7, v3
    v.sub        v3, v5, v6
    @p1 v.sel        v5, v3, v6
    s.movz       s7, #32768
    v.splat      v3, s7
    v.mul        v6, v5, v3
    v.add        v5, v1, v6
    v.add        v1, v0, v5
    v.st.w       [s6, #0], v1
    s.addi       s7, s6, #64
    s.addi       s9, s8, #1
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #1
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #128
    s.addi       s9, s8, #2
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #2
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #192
    s.addi       s9, s8, #3
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #3
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #256
    s.addi       s9, s8, #4
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #4
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #320
    s.addi       s9, s8, #5
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #5
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #384
    s.addi       s9, s8, #6
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #6
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #448
    s.addi       s9, s8, #7
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #7
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #512
    s.addi       s9, s8, #8
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #8
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #576
    s.addi       s9, s8, #9
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #9
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #640
    s.addi       s9, s8, #10
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #10
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #704
    s.addi       s9, s8, #11
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #11
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #768
    s.addi       s9, s8, #12
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #12
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #832
    s.addi       s9, s8, #13
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #13
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #896
    s.addi       s9, s8, #14
    v.splat      v1, s9
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s9, s8, #14
    v.splat      v5, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #960
    s.addi       s6, s8, #15
    v.splat      v1, s6
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s6, s8, #15
    v.splat      v4, s6
    v.movi       v5, #0
    v.cmp.lt     p1, v4, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v4
    @p1 v.sel        v7, v6, v4
    v.sub        v4, v5, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v2, #6
    v.lshr       v4, v7, v2
    v.sub        v2, v5, v4
    @p1 v.sel        v5, v2, v4
    v.mul        v2, v5, v3
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s7, #0], v1
    fence.acq_rel.device
    s.addi       s6, s4, #1024
    s.addi       s7, s4, #0
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #0
    s.add        s8, s7, s1                      // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s8
    v.add        v3, v1, v2
    v.cmpi.lt    p1, v3, #512
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s6, #0], v1
    s.addi       s7, s6, #64
    s.addi       s8, s4, #64
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #128
    s.addi       s8, s4, #128
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #192
    s.addi       s8, s4, #192
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #256
    s.addi       s8, s4, #256
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #320
    s.addi       s8, s4, #320
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #384
    s.addi       s8, s4, #384
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #448
    s.addi       s8, s4, #448
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #512
    s.addi       s8, s4, #512
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #576
    s.addi       s8, s4, #576
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #640
    s.addi       s8, s4, #640
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #704
    s.addi       s8, s4, #704
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #768
    s.addi       s8, s4, #768
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #832
    s.addi       s8, s4, #832
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #896
    s.addi       s8, s4, #896
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    s.addi       s7, s6, #960
    s.addi       s6, s4, #960
    v.ld.w       v0, [s6, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v1
    fence.acq_rel.device
    .li       s2, #1052050675
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s2, s1, #4                      // a runtime tile origin, x4
    s.add        s1, s3, s2                      // the tile origin
    s.muli       s2, s5, #2048                   // a runtime tile origin, x2048
    s.add        s3, s1, s2                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s1, s4, #1024
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s3, #0], v1
    s.addi       s1, s4, #1088
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #2048                   // row 1
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1152
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #4096                   // row 2
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1216
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #6144                   // row 3
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1280
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #8192                   // row 4
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1344
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #10240                  // row 5
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1408
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #12288                  // row 6
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1472
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #14336                  // row 7
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1536
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #16384                  // row 8
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1600
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #18432                  // row 9
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1664
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #20480                  // row 10
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1728
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #22528                  // row 11
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1792
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #24576                  // row 12
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1856
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #26624                  // row 13
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1920
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #28672                  // row 14
    @p1 v.st.w       [s1, #0], v1
    s.addi       s1, s4, #1984
    v.ld.w       v1, [s1, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s1, s3, #30720                  // row 15
    @p1 v.st.w       [s1, #0], v1
__rctx_next:
    exit
