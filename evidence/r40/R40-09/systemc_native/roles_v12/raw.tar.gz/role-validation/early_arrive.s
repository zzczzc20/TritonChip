
    s.rdspecial s1, role_id
    br.z s1, producer
    .li s5, #0x10000
    mb.wait s5
    v.mov v2, v1
    s.rdspecial s2, pid.x
    s.shli s2, s2, #6
    .li s3, #0x50000
    s.add s3, s3, s2
    v.st.w [s3, #0], v2
    exit
producer:
    .li s4, #40
delay:
    s.subi s4, s4, #1
    br.nz s4, delay
    mb.arm s5, b0, #1, #0
    .li s2, #0x3f800000
    v.splat v0, s2
    v.exp2.approx v1, v0
    mb.arrive b0
    exit
