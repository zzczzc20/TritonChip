    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #48]                   // N: i32 at arg_base+48
    s.movz       s4, #0
    s.movz       s5, #0
    s.movz       s6, #128
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s6, s7
    s.movz       s7, #15
    s.sub        s10, s8, s9
    s.rdspecial  s8, pid.x
    s.movz       s9, #0
    s.add        s11, s3, s2
    s.ld.sw      s12, [s1, #40]                  // M: i32 at arg_base+40
    s.cmp.lt     s13, s11, s4
    s.movz       s4, #0
    s.sub        s14, s5, s13
    s.rdspecial  s5, pid.y
    s.xor        s13, s11, s14
    s.movz       s11, #16
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.movz       s16, #0
    s.cmp.lt     s17, s11, s13
    s.add        s13, s12, s7
    s.sub        s7, s16, s17
    s.cmp.lt     s16, s13, s9
    s.xor        s9, s11, s7
    s.sub        s17, s4, s16
    s.xor        s4, s6, s10
    s.xor        s16, s13, s17
    s.xor        s13, s17, s7
    s.sub        s18, s16, s17
    s.ld.d       s16, [s1, #0]                   // A: device_ptr64 at arg_base+0
    s.lshri      s17, s18, #4
    s.sub        s19, s9, s7
    s.muli       s7, s17, #16
    s.xor        s9, s17, s13
    s.sub        s17, s4, s10
    s.sub        s4, s9, s13
    s.sub        s9, s18, s7
    s.ld.d       s7, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.lshri      s9, s15, #7
    s.ld.d       s13, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.muli       s17, s9, #128
    s.ld.d       s18, [s1, #24]                  // As: device_ptr64 at arg_base+24
    s.sub        s19, s15, s17
    s.ld.d       s15, [s1, #32]                  // Bs: device_ptr64 at arg_base+32
    s.xor        s17, s14, s10
    s.xor        s10, s9, s17
    s.sub        s9, s10, s17
    s.ld.sw      s10, [s1, #56]                  // K: i32 at arg_base+56
    s.mul        s14, s8, s9
    s.ld.sw      s8, [s1, #64]                   // stride_am: i32 at arg_base+64
    s.add        s17, s14, s5
    s.ld.sw      s5, [s1, #72]                   // stride_bn: i32 at arg_base+72
    s.movz       s14, #8
    s.ld.sw      s19, [s1, #80]                  // stride_cm: i32 at arg_base+80
    s.mul        s1, s9, s14
    s.movz       s9, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s1, s9
    s.cmp.lt     s9, s17, s20
    s.sub        s20, s21, s23
    s.sub        s21, s22, s9
    s.xor        s9, s1, s20
    s.xor        s22, s17, s21
    s.sub        s23, s9, s20
    s.movz       s9, #0
    s.movz       s24, #1
    s.sub        s25, s22, s21
    s.movz       s22, #0
    s.addi       s26, s9, #0
    s.cmp.eq     s9, s23, s24
    s.addi       s24, s22, #0
    s.mov        s26, s25
    br.nz        s9, sdiv_done_1
    s.movz       s9, #0
    s.movz       s22, #31
    s.mov        s26, s9
    s.addi       s9, s22, #0
sdiv_2:
    s.lshr       s22, s25, s9
    s.shli       s27, s24, #1
    s.andi       s28, s22, #1
    s.movz       s22, #0
    s.or         s29, s27, s28
    s.movz       s27, #1
    s.cmp.geu    s28, s29, s23
    s.shl        s30, s27, s9
    s.sub        s27, s22, s28
    s.subi       s22, s9, #1
    s.and        s28, s23, s27
    s.and        s31, s30, s27
    s.sub        s27, s29, s28
    s.or         s28, s26, s31
    s.mov        s24, s27
    s.mov        s26, s28
    s.mov        s9, s22
    s.movz       s22, #0
    s.cmp.ge     s27, s9, s22
    br.nz        s27, sdiv_2
sdiv_done_1:
    s.xor        s9, s21, s20
    s.movz       s20, #0
    s.xor        s21, s26, s9
    s.movz       s22, #0
    s.movz       s23, #0
    s.cmp.lt     s24, s1, s20
    s.sub        s20, s21, s9
    s.movz       s9, #0
    s.cmp.lt     s21, s17, s22
    s.sub        s22, s23, s24
    s.mul        s23, s20, s14
    s.sub        s20, s9, s21
    s.xor        s9, s1, s22
    s.xor        s1, s17, s20
    s.sub        s17, s9, s22
    s.movz       s9, #0
    s.movz       s21, #1
    s.sub        s22, s4, s23
    s.sub        s4, s1, s20
    s.movz       s1, #0
    s.addi       s24, s9, #0
    s.cmp.eq     s9, s17, s21
    s.min.s      s21, s22, s14
    s.addi       s14, s1, #0
    s.mov        s24, s4
    br.nz        s9, sdiv_done_3
    s.movz       s1, #0
    s.movz       s9, #31
    s.mov        s24, s1
    s.addi       s1, s9, #0
sdiv_4:
    s.lshr       s9, s4, s1
    s.shli       s22, s14, #1
    s.andi       s25, s9, #1
    s.movz       s9, #0
    s.or         s26, s22, s25
    s.movz       s22, #1
    s.cmp.geu    s25, s26, s17
    s.shl        s27, s22, s1
    s.sub        s22, s9, s25
    s.subi       s9, s1, #1
    s.and        s25, s17, s22
    s.and        s28, s27, s22
    s.sub        s22, s26, s25
    s.or         s25, s24, s28
    s.mov        s14, s22
    s.mov        s24, s25
    s.mov        s1, s9
    s.movz       s9, #0
    s.cmp.ge     s22, s1, s9
    br.nz        s22, sdiv_4
sdiv_done_3:
    s.xor        s1, s14, s20
    s.movz       s4, #0
    s.sub        s9, s1, s20
    s.movz       s1, #0
    s.movz       s14, #0
    s.cmp.lt     s17, s21, s4
    s.movz       s4, #0
    s.cmp.lt     s20, s9, s1
    s.sub        s1, s14, s17
    s.sub        s14, s4, s20
    s.xor        s4, s21, s1
    s.xor        s17, s9, s14
    s.sub        s20, s4, s1
    s.movz       s1, #0
    s.movz       s4, #1
    s.sub        s22, s17, s14
    s.movz       s17, #0
    s.addi       s24, s1, #0
    s.cmp.eq     s1, s20, s4
    s.addi       s4, s17, #0
    s.mov        s24, s22
    br.nz        s1, sdiv_done_5
    s.movz       s1, #0
    s.movz       s17, #31
    s.mov        s24, s1
    s.addi       s1, s17, #0
sdiv_6:
    s.lshr       s17, s22, s1
    s.shli       s25, s4, #1
    s.andi       s26, s17, #1
    s.movz       s17, #0
    s.or         s27, s25, s26
    s.movz       s25, #1
    s.cmp.geu    s26, s27, s20
    s.shl        s28, s25, s1
    s.sub        s25, s17, s26
    s.subi       s17, s1, #1
    s.and        s26, s20, s25
    s.and        s29, s28, s25
    s.sub        s25, s27, s26
    s.or         s26, s24, s29
    s.mov        s4, s25
    s.mov        s24, s26
    s.mov        s1, s17
    s.movz       s17, #0
    s.cmp.ge     s25, s1, s17
    br.nz        s25, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.movz       s17, #0
    s.movz       s20, #0
    s.cmp.lt     s22, s21, s1
    s.movz       s1, #0
    s.cmp.lt     s24, s9, s17
    s.sub        s17, s20, s22
    s.sub        s20, s1, s24
    s.xor        s1, s21, s17
    s.xor        s21, s4, s14
    s.xor        s4, s9, s20
    s.sub        s9, s1, s17
    s.movz       s1, #0
    s.movz       s22, #1
    s.sub        s24, s21, s14
    s.sub        s14, s4, s20
    s.movz       s4, #0
    s.addi       s21, s1, #0
    s.cmp.eq     s1, s9, s22
    s.add        s22, s23, s24
    s.addi       s23, s4, #0
    s.mov        s21, s14
    br.nz        s1, sdiv_done_7
    s.movz       s1, #0
    s.movz       s4, #31
    s.mov        s21, s1
    s.addi       s1, s4, #0
sdiv_8:
    s.lshr       s4, s14, s1
    s.shli       s24, s23, #1
    s.andi       s25, s4, #1
    s.movz       s4, #0
    s.or         s26, s24, s25
    s.movz       s24, #1
    s.cmp.geu    s25, s26, s9
    s.shl        s27, s24, s1
    s.sub        s24, s4, s25
    s.subi       s4, s1, #1
    s.and        s25, s9, s24
    s.and        s28, s27, s24
    s.sub        s24, s26, s25
    s.or         s25, s21, s28
    s.mov        s23, s24
    s.mov        s21, s25
    s.mov        s1, s4
    s.movz       s4, #0
    s.cmp.ge     s24, s1, s4
    br.nz        s24, sdiv_8
sdiv_done_7:
    s.mul        s1, s22, s11
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s12
    v.movi       v2, #0
    s.xor        s4, s20, s17
    v.splat      v3, s1
    v.sub        v4, v2, v1
    s.xor        s9, s21, s4
    v.add        v5, v3, v0
    v.cmp.lt     p1, v1, v2
    s.sub        s14, s9, s4
    v.sub        v0, v2, v5
    v.cmp.lt     p2, v5, v2
    v.movi       v3, #1
    @p2 v.sel        v6, v0, v5
    @p1 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s4, #31
idiv_9:
    v.splat      v5, s4
    v.shl        v7, v4, v3
    v.cmp.lt     p1, v4, v2
    v.lshr       v8, v6, v5
    v.shl        v9, v3, v5
    s.subi       s9, s4, #1
    v.and        v5, v8, v3
    s.movz       s17, #0
    v.or         v8, v7, v5
    v.cmp.geu    p3, v8, v0
    p.or         p4, p1, p3
    v.sub        v5, v8, v0
    @p4 v.sel        v7, v9, v2
    @p4 v.sel        v9, v5, v8
    v.or         v5, v1, v7
    v.mov        v4, v9
    v.mov        v1, v5
    s.mov        s4, s9
    s.cmp.ge     s9, s4, s17
    br.nz        s9, idiv_9
    s.mul        s4, s14, s6
    v.iota       v0                              // arange(0, VLEN)
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v3, #16
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s4
    v.movi       v7, #32
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #48
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #64
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #80
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #96
    v.iota       v16                             // arange(0, VLEN)
    v.movi       v17, #112
    v.add        v18, v6, v0
    v.splat      v0, s3
    v.sub        v6, v2, v4
    v.add        v2, v1, v3
    v.add        v1, v5, v7
    v.add        v3, v8, v9
    v.add        v5, v10, v11
    v.add        v7, v12, v13
    v.add        v8, v14, v15
    v.add        v9, v16, v17
    v.splat      v10, s4
    v.splat      v11, s4
    v.splat      v12, s4
    v.splat      v13, s4
    v.splat      v14, s4
    v.splat      v15, s4
    v.splat      v16, s4
    @p2 v.sel        v17, v6, v4
    v.movi       v4, #0
    v.add        v6, v10, v2
    v.add        v2, v11, v1
    v.sub        v1, v4, v18
    v.sub        v10, v4, v0
    v.cmp.lt     p1, v18, v4
    v.cmp.lt     p2, v0, v4
    v.add        v11, v12, v3
    v.add        v3, v13, v5
    v.add        v5, v14, v7
    v.add        v7, v15, v8
    v.add        v8, v16, v9
    v.splat      v9, s3
    v.splat      v12, s3
    v.splat      v13, s3
    v.splat      v14, s3
    v.splat      v15, s3
    v.splat      v16, s3
    v.splat      v19, s3
    v.movi       v20, #1
    @p1 v.sel        v21, v1, v18
    @p2 v.sel        v1, v10, v0
    v.movi       v0, #0
    v.movi       v10, #0
    s.movz       s9, #31
idiv_10:
    v.splat      v18, s9
    v.shl        v22, v10, v20
    v.cmp.lt     p2, v10, v4
    v.lshr       v23, v21, v18
    v.shl        v24, v20, v18
    s.subi       s14, s9, #1
    v.and        v18, v23, v20
    s.movz       s17, #0
    v.or         v23, v22, v18
    v.cmp.geu    p3, v23, v1
    p.or         p4, p2, p3
    v.sub        v18, v23, v1
    @p4 v.sel        v22, v24, v4
    @p4 v.sel        v24, v18, v23
    v.or         v18, v0, v22
    v.mov        v10, v24
    v.mov        v0, v18
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_10
    v.movi       v0, #0
    v.sub        v1, v4, v10
    v.movi       v4, #1
    v.sub        v18, v0, v6
    v.sub        v20, v0, v9
    v.cmp.lt     p2, v6, v0
    v.cmp.lt     p3, v9, v0
    @p1 v.sel        v21, v1, v10
    @p2 v.sel        v1, v18, v6
    @p3 v.sel        v6, v20, v9
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s9, #31
idiv_11:
    v.splat      v18, s9
    v.shl        v20, v10, v4
    v.cmp.lt     p1, v10, v0
    v.lshr       v22, v1, v18
    v.shl        v23, v4, v18
    s.subi       s14, s9, #1
    v.and        v18, v22, v4
    s.movz       s17, #0
    v.or         v22, v20, v18
    v.cmp.geu    p3, v22, v6
    p.or         p4, p1, p3
    v.sub        v18, v22, v6
    @p4 v.sel        v20, v23, v0
    @p4 v.sel        v23, v18, v22
    v.or         v18, v9, v20
    v.mov        v10, v23
    v.mov        v9, v18
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_11
    v.movi       v1, #0
    v.sub        v4, v0, v10
    v.movi       v0, #1
    v.sub        v6, v1, v2
    v.sub        v9, v1, v12
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p3, v12, v1
    @p2 v.sel        v18, v4, v10
    @p1 v.sel        v4, v6, v2
    @p3 v.sel        v2, v9, v12
    v.movi       v6, #0
    v.movi       v9, #0
    s.movz       s9, #31
idiv_12:
    v.splat      v10, s9
    v.shl        v12, v9, v0
    v.cmp.lt     p2, v9, v1
    v.lshr       v20, v4, v10
    v.shl        v22, v0, v10
    s.subi       s14, s9, #1
    v.and        v10, v20, v0
    s.movz       s17, #0
    v.or         v20, v12, v10
    v.cmp.geu    p3, v20, v2
    p.or         p4, p2, p3
    v.sub        v10, v20, v2
    @p4 v.sel        v12, v22, v1
    @p4 v.sel        v22, v10, v20
    v.or         v10, v6, v12
    v.mov        v9, v22
    v.mov        v6, v10
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_12
    v.movi       v0, #0
    v.sub        v2, v1, v9
    v.movi       v1, #1
    v.sub        v4, v0, v11
    v.sub        v6, v0, v13
    v.cmp.lt     p2, v11, v0
    v.cmp.lt     p3, v13, v0
    @p1 v.sel        v10, v2, v9
    @p2 v.sel        v2, v4, v11
    @p3 v.sel        v4, v6, v13
    v.movi       v6, #0
    v.movi       v9, #0
    s.movz       s9, #31
idiv_13:
    v.splat      v11, s9
    v.shl        v12, v9, v1
    v.cmp.lt     p1, v9, v0
    v.lshr       v13, v2, v11
    v.shl        v20, v1, v11
    s.subi       s14, s9, #1
    v.and        v11, v13, v1
    s.movz       s17, #0
    v.or         v13, v12, v11
    v.cmp.geu    p3, v13, v4
    p.or         p4, p1, p3
    v.sub        v11, v13, v4
    @p4 v.sel        v12, v20, v0
    @p4 v.sel        v20, v11, v13
    v.or         v11, v6, v12
    v.mov        v9, v20
    v.mov        v6, v11
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_13
    v.movi       v1, #0
    v.sub        v2, v0, v9
    v.movi       v0, #1
    v.sub        v4, v1, v3
    v.sub        v6, v1, v14
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p3, v14, v1
    @p2 v.sel        v11, v2, v9
    @p1 v.sel        v2, v4, v3
    @p3 v.sel        v3, v6, v14
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s9, #31
idiv_14:
    v.splat      v9, s9
    v.shl        v12, v6, v0
    v.cmp.lt     p2, v6, v1
    v.lshr       v13, v2, v9
    v.shl        v14, v0, v9
    s.subi       s14, s9, #1
    v.and        v9, v13, v0
    s.movz       s17, #0
    v.or         v13, v12, v9
    v.cmp.geu    p3, v13, v3
    p.or         p4, p2, p3
    v.sub        v9, v13, v3
    @p4 v.sel        v12, v14, v1
    @p4 v.sel        v14, v9, v13
    v.or         v9, v4, v12
    v.mov        v6, v14
    v.mov        v4, v9
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_14
    v.movi       v0, #0
    v.sub        v2, v1, v6
    v.movi       v1, #1
    v.sub        v3, v0, v5
    v.sub        v4, v0, v15
    v.cmp.lt     p2, v5, v0
    v.cmp.lt     p3, v15, v0
    @p1 v.sel        v9, v2, v6
    @p2 v.sel        v2, v3, v5
    @p3 v.sel        v3, v4, v15
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s9, #31
idiv_15:
    v.splat      v6, s9
    v.shl        v12, v5, v1
    v.cmp.lt     p1, v5, v0
    v.lshr       v13, v2, v6
    v.shl        v14, v1, v6
    s.subi       s14, s9, #1
    v.and        v6, v13, v1
    s.movz       s17, #0
    v.or         v13, v12, v6
    v.cmp.geu    p3, v13, v3
    p.or         p4, p1, p3
    v.sub        v6, v13, v3
    @p4 v.sel        v12, v14, v0
    @p4 v.sel        v14, v6, v13
    v.or         v6, v4, v12
    v.mov        v5, v14
    v.mov        v4, v6
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_15
    v.movi       v1, #0
    v.sub        v2, v0, v5
    v.movi       v0, #1
    v.sub        v3, v1, v7
    v.sub        v4, v1, v16
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p3, v16, v1
    @p2 v.sel        v6, v2, v5
    @p1 v.sel        v2, v3, v7
    @p3 v.sel        v3, v4, v16
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s9, #31
idiv_16:
    v.splat      v7, s9
    v.shl        v12, v5, v0
    v.cmp.lt     p2, v5, v1
    v.lshr       v13, v2, v7
    v.shl        v14, v0, v7
    s.subi       s14, s9, #1
    v.and        v7, v13, v0
    s.movz       s17, #0
    v.or         v13, v12, v7
    v.cmp.geu    p3, v13, v3
    p.or         p4, p2, p3
    v.sub        v7, v13, v3
    @p4 v.sel        v12, v14, v1
    @p4 v.sel        v14, v7, v13
    v.or         v7, v4, v12
    v.mov        v5, v14
    v.mov        v4, v7
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_16
    v.movi       v0, #0
    v.sub        v2, v1, v5
    v.movi       v1, #1
    v.sub        v3, v0, v8
    v.sub        v4, v0, v19
    v.cmp.lt     p2, v8, v0
    v.cmp.lt     p3, v19, v0
    @p1 v.sel        v7, v2, v5
    @p2 v.sel        v2, v3, v8
    @p3 v.sel        v3, v4, v19
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s9, #31
idiv_17:
    v.splat      v8, s9
    v.shl        v12, v5, v1
    v.cmp.lt     p1, v5, v0
    v.lshr       v13, v2, v8
    v.shl        v14, v1, v8
    s.subi       s14, s9, #1
    v.and        v8, v13, v1
    s.movz       s17, #0
    v.or         v13, v12, v8
    v.cmp.geu    p3, v13, v3
    p.or         p4, p1, p3
    v.sub        v8, v13, v3
    @p4 v.sel        v12, v14, v0
    @p4 v.sel        v14, v8, v13
    v.or         v8, v4, v12
    v.mov        v5, v14
    v.mov        v4, v8
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_17
    s.add        s9, s10, s2
    s.movz       s2, #0
    s.movz       s14, #0
    s.cmp.lt     s17, s9, s2
    s.movz       s2, #0
    s.sub        s20, s14, s17
    s.movz       s14, #0
    s.xor        s17, s9, s20
    s.cmp.lt     s9, s6, s2
    s.sub        s2, s17, s20
    s.sub        s17, s14, s9
    s.lshri      s9, s2, #7
    s.xor        s14, s20, s17
    s.muli       s20, s9, #128
    v.sub        v1, v0, v5
    s.xor        s21, s6, s17
    s.xor        s22, s9, s14
    s.movz       s9, #0
    s.movz       s23, #0
    s.movz       s24, #0
    @p2 v.sel        v0, v1, v5
    s.movz       s25, #32
    s.movz       s26, #48
    s.movz       s27, #64
    s.movz       s28, #80
    s.movz       s29, #96
    s.movz       s30, #112
    v.ld.gather.w v1, [s18, v17]                 // index is in elements (ISA sec 9.1)
    s.sub        s18, s21, s17
    s.sub        s17, s2, s20
    s.sub        s2, s22, s14
    s.movz       s14, #1
    s.addi       s17, s9, #0
    s.addi       s18, s23, #0
    s.addi       s20, s24, #0
    s.ld.w       s21, [s15, #0]                  // one element, not a vector
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_18:
    s.cmp.ge     s15, s17, s2
    br.nz        s15, endfor_19
    s.mul        s15, s17, s6
    s.sub        s22, s10, s15
    v.splat      v2, s5
    v.mul        v3, v21, v2
    v.splat      v2, s5
    v.mul        v4, v18, v2
    v.splat      v2, s5
    v.mul        v5, v10, v2
    v.splat      v2, s5
    v.mul        v8, v11, v2
    v.splat      v2, s5
    v.mul        v12, v9, v2
    v.splat      v2, s5
    v.mul        v13, v6, v2
    v.splat      v2, s5
    v.mul        v14, v7, v2
    v.splat      v2, s5
    v.mul        v15, v0, v2
    s.add        s15, s9, s22
    // tl.dot 16x128 by 128x128 FP8 as (B^T A^T)^T: B^T rows are contiguous loads, A is scattered into the MMA B operand
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s23, #16
    v.splat      v16, s23
    v.mul        v19, v2, v16
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v16, #7
    v.and        v20, v2, v16
    v.movi       v2, #2
    v.shl        v16, v20, v2
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v20, #3
    v.lshr       v22, v2, v20
    v.movi       v2, #0
    v.cmp.eq     p1, v22, v2
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v20, #3
    v.lshr       v22, v2, v20
    v.movi       v2, #1
    v.cmp.eq     p2, v22, v2
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    s.rdspecial  s23, arg_base
    s.ld.d       s24, [s23, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s23, s24, #0                    // 512 bytes of repack scratch
    v.splat      v2, s8
    v.mul        v20, v17, v2
    v.extract    s31, v20, #0
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s32, #0
    s.add        s33, s32, s22                   // the tile origin
    v.splat      v22, s33
    v.cmp.lt     p3, v2, v22
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #0
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #1
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #1
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #2
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #2
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #3
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #3
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #4
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #4
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #5
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #5
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #6
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #6
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #7
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #7
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #8
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #8
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #9
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #9
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #10
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #10
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #11
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #11
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #12
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #12
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #13
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #13
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #14
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #14
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #15
    s.add        s32, s31, s18
    s.add        s31, s16, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s31, #0]
    s.addi       s31, s23, #15
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #0
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    s.movz       s31, #0
    s.add        s33, s31, s11                   // the tile origin
    v.splat      v22, s33
    v.add        v23, v2, v22
    s.movz       s31, #0
    s.add        s33, s31, s22                   // the tile origin
    v.splat      v22, s33
    v.cmp.lt     p3, v23, v22
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #256
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #1
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #257
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #2
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #258
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #3
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #259
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #4
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #260
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #5
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #261
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #6
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #262
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #7
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #263
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #8
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #264
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #9
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #265
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #10
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #266
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #11
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #267
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #12
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #268
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #13
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #269
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #14
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #270
    v.st.scatter.b [s31, v19], v22
    v.extract    s31, v20, #15
    s.add        s32, s31, s18
    s.addi       s31, s32, #16
    s.add        s32, s16, s31
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s32, #0]
    s.addi       s31, s23, #271
    v.st.scatter.b [s31, v19], v22
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v22, [s23, #0]
    v.mov        v48, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s31, s23, #64
    v.ld.w       v22, [s31, #0]
    v.mov        v49, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s31, s23, #128
    v.ld.w       v22, [s31, #0]
    v.mov        v50, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s31, s23, #192
    v.ld.w       v22, [s31, #0]
    v.mov        v51, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s31, s23, #256
    v.ld.w       v22, [s31, #0]
    v.mov        v52, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s31, s23, #320
    v.ld.w       v22, [s31, #0]
    v.mov        v53, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s31, s23, #384
    v.ld.w       v22, [s31, #0]
    v.mov        v54, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s31, s23, #448
    v.ld.w       v22, [s31, #0]
    v.mov        v55, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s23, s15, #0
    v.splat      v22, s23
    v.sub        v23, v22, v16
    v.movi       v22, #0
    v.cmp.gt     p3, v23, v22
    v.movi       v22, #0
    v.max.s      v24, v23, v22
    v.movi       v22, #4
    v.min.s      v23, v24, v22
    v.movi       v22, #1
    v.movi       v24, #3
    v.shl        v25, v23, v24
    v.shl        v24, v22, v25
    v.movi       v22, #1
    v.sub        v25, v24, v22
    v.movi       v22, #4
    v.cmp.ge     p4, v23, v22
    v.movi       v22, #-1
    @p4 v.sel        v23, v22, v25
    s.add        s23, s7, s20
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s31, v3, #0
    s.add        s32, s23, s31
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s32, #0]
    v.extract    s31, v3, #1
    s.add        s32, s23, s31
    s.addi       s31, s32, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s31, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s31, v3, #2
    s.add        s32, s23, s31
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s32, #0]
    v.extract    s31, v3, #3
    s.add        s32, s23, s31
    s.addi       s31, s32, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s31, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s31, v3, #4
    s.add        s32, s23, s31
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s32, #0]
    v.extract    s31, v3, #5
    s.add        s32, s23, s31
    s.addi       s31, s32, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s31, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s31, v3, #6
    s.add        s32, s23, s31
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s32, #0]
    v.extract    s31, v3, #7
    s.add        s32, s23, s31
    s.addi       s31, s32, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s31, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s31, v3, #8
    s.add        s32, s23, s31
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s32, #0]
    v.extract    s31, v3, #9
    s.add        s32, s23, s31
    s.addi       s31, s32, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s31, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s31, v3, #10
    s.add        s32, s23, s31
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s32, #0]
    v.extract    s31, v3, #11
    s.add        s32, s23, s31
    s.addi       s31, s32, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s31, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s31, v3, #12
    s.add        s32, s23, s31
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s32, #0]
    v.extract    s31, v3, #13
    s.add        s32, s23, s31
    s.addi       s31, s32, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s31, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s31, v3, #14
    s.add        s32, s23, s31
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s32, #0]
    v.extract    s31, v3, #15
    s.add        s32, s23, s31
    s.addi       s23, s32, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s23, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s23, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s23
    mb.wait      s23
    s.add        s31, s7, s20
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s32, v4, #0
    s.add        s33, s31, s32
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s33, #0]
    v.extract    s32, v4, #1
    s.add        s33, s31, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s32, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v4, #2
    s.add        s33, s31, s32
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s33, #0]
    v.extract    s32, v4, #3
    s.add        s33, s31, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s32, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v4, #4
    s.add        s33, s31, s32
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s33, #0]
    v.extract    s32, v4, #5
    s.add        s33, s31, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s32, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v4, #6
    s.add        s33, s31, s32
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s33, #0]
    v.extract    s32, v4, #7
    s.add        s33, s31, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s32, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v4, #8
    s.add        s33, s31, s32
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s33, #0]
    v.extract    s32, v4, #9
    s.add        s33, s31, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s32, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v4, #10
    s.add        s33, s31, s32
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s33, #0]
    v.extract    s32, v4, #11
    s.add        s33, s31, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s32, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v4, #12
    s.add        s33, s31, s32
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s33, #0]
    v.extract    s32, v4, #13
    s.add        s33, s31, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s32, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v4, #14
    s.add        s33, s31, s32
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s33, #0]
    v.extract    s32, v4, #15
    s.add        s33, s31, s32
    s.addi       s31, s33, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s31, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s31, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s31
    mb.wait      s31
    s.add        s32, s7, s20
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s33, v5, #0
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s34, #0]
    v.extract    s33, v5, #1
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s33, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v5, #2
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s34, #0]
    v.extract    s33, v5, #3
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s33, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v5, #4
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s34, #0]
    v.extract    s33, v5, #5
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s33, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v5, #6
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s34, #0]
    v.extract    s33, v5, #7
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s33, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v5, #8
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s34, #0]
    v.extract    s33, v5, #9
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s33, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v5, #10
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s34, #0]
    v.extract    s33, v5, #11
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s33, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v5, #12
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s34, #0]
    v.extract    s33, v5, #13
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s33, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v5, #14
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s34, #0]
    v.extract    s33, v5, #15
    s.add        s34, s32, s33
    s.addi       s32, s34, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s32, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s32, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s32
    mb.wait      s32
    s.add        s33, s7, s20
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s34, v8, #0
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s35, #0]
    v.extract    s34, v8, #1
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v8, #2
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s35, #0]
    v.extract    s34, v8, #3
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v8, #4
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s35, #0]
    v.extract    s34, v8, #5
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v8, #6
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s35, #0]
    v.extract    s34, v8, #7
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v8, #8
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s35, #0]
    v.extract    s34, v8, #9
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v8, #10
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s35, #0]
    v.extract    s34, v8, #11
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v8, #12
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s35, #0]
    v.extract    s34, v8, #13
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v8, #14
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s35, #0]
    v.extract    s34, v8, #15
    s.add        s35, s33, s34
    s.addi       s33, s35, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s33, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s33, b3, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s33
    mb.wait      s33
    s.add        s34, s7, s20
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s35, v12, #0
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s36, #0]
    v.extract    s35, v12, #1
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v12, #2
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s36, #0]
    v.extract    s35, v12, #3
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v12, #4
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s36, #0]
    v.extract    s35, v12, #5
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v12, #6
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s36, #0]
    v.extract    s35, v12, #7
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v12, #8
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s36, #0]
    v.extract    s35, v12, #9
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v12, #10
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s36, #0]
    v.extract    s35, v12, #11
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v12, #12
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s36, #0]
    v.extract    s35, v12, #13
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v12, #14
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s36, #0]
    v.extract    s35, v12, #15
    s.add        s36, s34, s35
    s.addi       s34, s36, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s34, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s34, b4, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s34
    mb.wait      s34
    s.add        s35, s7, s20
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s36, v13, #0
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s37, #0]
    v.extract    s36, v13, #1
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v13, #2
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s37, #0]
    v.extract    s36, v13, #3
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v13, #4
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s37, #0]
    v.extract    s36, v13, #5
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v13, #6
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s37, #0]
    v.extract    s36, v13, #7
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v13, #8
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s37, #0]
    v.extract    s36, v13, #9
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v13, #10
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s37, #0]
    v.extract    s36, v13, #11
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v13, #12
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s37, #0]
    v.extract    s36, v13, #13
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v13, #14
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s37, #0]
    v.extract    s36, v13, #15
    s.add        s37, s35, s36
    s.addi       s35, s37, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s35, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s35, b5, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s35
    mb.wait      s35
    s.add        s36, s7, s20
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s37, v14, #0
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s38, #0]
    v.extract    s37, v14, #1
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v14, #2
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s38, #0]
    v.extract    s37, v14, #3
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v14, #4
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s38, #0]
    v.extract    s37, v14, #5
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v14, #6
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s38, #0]
    v.extract    s37, v14, #7
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v14, #8
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s38, #0]
    v.extract    s37, v14, #9
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v14, #10
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s38, #0]
    v.extract    s37, v14, #11
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v14, #12
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s38, #0]
    v.extract    s37, v14, #13
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v14, #14
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s38, #0]
    v.extract    s37, v14, #15
    s.add        s38, s36, s37
    s.addi       s36, s38, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s36, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b6, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s36
    mb.wait      s36
    s.add        s37, s7, s20
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s38, v15, #0
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s39, #0]
    v.extract    s38, v15, #1
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v15, #2
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s39, #0]
    v.extract    s38, v15, #3
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v15, #4
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s39, #0]
    v.extract    s38, v15, #5
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v15, #6
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s39, #0]
    v.extract    s38, v15, #7
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v15, #8
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s39, #0]
    v.extract    s38, v15, #9
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v15, #10
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s39, #0]
    v.extract    s38, v15, #11
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v15, #12
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s39, #0]
    v.extract    s38, v15, #13
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v15, #14
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s39, #0]
    v.extract    s38, v15, #15
    s.add        s39, s37, s38
    s.addi       s37, s39, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s37, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b7, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s37
    mb.wait      s37
    s.addi       s38, s24, #512                  // 512 bytes of repack scratch
    v.extract    s39, v20, #0
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    s.movz       s39, #0
    s.add        s41, s39, s25                   // the tile origin
    v.splat      v22, s41
    v.add        v23, v2, v22
    s.movz       s39, #0
    s.add        s41, s39, s22                   // the tile origin
    v.splat      v22, s41
    v.cmp.lt     p3, v23, v22
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #0
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #1
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #1
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #2
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #2
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #3
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #3
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #4
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #4
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #5
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #5
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #6
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #6
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #7
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #7
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #8
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #8
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #9
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #9
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #10
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #10
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #11
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #11
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #12
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #12
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #13
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #13
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #14
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #14
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #15
    s.add        s40, s39, s18
    s.addi       s39, s40, #32
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #15
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #0
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    s.movz       s39, #0
    s.add        s41, s39, s26                   // the tile origin
    v.splat      v22, s41
    v.add        v23, v2, v22
    s.movz       s39, #0
    s.add        s41, s39, s22                   // the tile origin
    v.splat      v22, s41
    v.cmp.lt     p3, v23, v22
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #256
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #1
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #257
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #2
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #258
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #3
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #259
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #4
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #260
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #5
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #261
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #6
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #262
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #7
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #263
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #8
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #264
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #9
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #265
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #10
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #266
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #11
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #267
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #12
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #268
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #13
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #269
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #14
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #270
    v.st.scatter.b [s39, v19], v22
    v.extract    s39, v20, #15
    s.add        s40, s39, s18
    s.addi       s39, s40, #48
    s.add        s40, s16, s39
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s40, #0]
    s.addi       s39, s38, #271
    v.st.scatter.b [s39, v19], v22
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v22, [s38, #0]
    v.mov        v48, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s39, s38, #64
    v.ld.w       v22, [s39, #0]
    v.mov        v49, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s39, s38, #128
    v.ld.w       v22, [s39, #0]
    v.mov        v50, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s39, s38, #192
    v.ld.w       v22, [s39, #0]
    v.mov        v51, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s39, s38, #256
    v.ld.w       v22, [s39, #0]
    v.mov        v52, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s39, s38, #320
    v.ld.w       v22, [s39, #0]
    v.mov        v53, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s39, s38, #384
    v.ld.w       v22, [s39, #0]
    v.mov        v54, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s39, s38, #448
    v.ld.w       v22, [s39, #0]
    v.mov        v55, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s38, s15, #-32
    v.splat      v22, s38
    v.sub        v23, v22, v16
    v.movi       v22, #0
    v.cmp.gt     p3, v23, v22
    v.movi       v22, #0
    v.max.s      v24, v23, v22
    v.movi       v22, #4
    v.min.s      v23, v24, v22
    v.movi       v22, #1
    v.movi       v24, #3
    v.shl        v25, v23, v24
    v.shl        v24, v22, v25
    v.movi       v22, #1
    v.sub        v25, v24, v22
    v.movi       v22, #4
    v.cmp.ge     p4, v23, v22
    v.movi       v22, #-1
    @p4 v.sel        v23, v22, v25
    s.addi       s38, s20, #32
    s.add        s39, s7, s38
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s38, v3, #0
    s.add        s40, s39, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s40, #0]
    v.extract    s38, v3, #1
    s.add        s40, s39, s38
    s.addi       s38, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v3, #2
    s.add        s40, s39, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s40, #0]
    v.extract    s38, v3, #3
    s.add        s40, s39, s38
    s.addi       s38, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v3, #4
    s.add        s40, s39, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s40, #0]
    v.extract    s38, v3, #5
    s.add        s40, s39, s38
    s.addi       s38, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v3, #6
    s.add        s40, s39, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s40, #0]
    v.extract    s38, v3, #7
    s.add        s40, s39, s38
    s.addi       s38, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v3, #8
    s.add        s40, s39, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s40, #0]
    v.extract    s38, v3, #9
    s.add        s40, s39, s38
    s.addi       s38, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v3, #10
    s.add        s40, s39, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s40, #0]
    v.extract    s38, v3, #11
    s.add        s40, s39, s38
    s.addi       s38, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v3, #12
    s.add        s40, s39, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s40, #0]
    v.extract    s38, v3, #13
    s.add        s40, s39, s38
    s.addi       s38, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v3, #14
    s.add        s40, s39, s38
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s40, #0]
    v.extract    s38, v3, #15
    s.add        s40, s39, s38
    s.addi       s38, s40, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s38, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s38, b8, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s38
    mb.wait      s38
    s.addi       s39, s20, #32
    s.add        s40, s7, s39
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s39, v4, #0
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s41, #0]
    v.extract    s39, v4, #1
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v4, #2
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s41, #0]
    v.extract    s39, v4, #3
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v4, #4
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s41, #0]
    v.extract    s39, v4, #5
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v4, #6
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s41, #0]
    v.extract    s39, v4, #7
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v4, #8
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s41, #0]
    v.extract    s39, v4, #9
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v4, #10
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s41, #0]
    v.extract    s39, v4, #11
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v4, #12
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s41, #0]
    v.extract    s39, v4, #13
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v4, #14
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s41, #0]
    v.extract    s39, v4, #15
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s39, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s39, b9, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s39
    mb.wait      s39
    s.addi       s40, s20, #32
    s.add        s41, s7, s40
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s40, v5, #0
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s42, #0]
    v.extract    s40, v5, #1
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v5, #2
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s42, #0]
    v.extract    s40, v5, #3
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v5, #4
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s42, #0]
    v.extract    s40, v5, #5
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v5, #6
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s42, #0]
    v.extract    s40, v5, #7
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v5, #8
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s42, #0]
    v.extract    s40, v5, #9
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v5, #10
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s42, #0]
    v.extract    s40, v5, #11
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v5, #12
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s42, #0]
    v.extract    s40, v5, #13
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v5, #14
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s42, #0]
    v.extract    s40, v5, #15
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s40, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s40, b10, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s40
    mb.wait      s40
    s.addi       s41, s20, #32
    s.add        s42, s7, s41
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s41, v8, #0
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s43, #0]
    v.extract    s41, v8, #1
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v8, #2
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s43, #0]
    v.extract    s41, v8, #3
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v8, #4
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s43, #0]
    v.extract    s41, v8, #5
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v8, #6
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s43, #0]
    v.extract    s41, v8, #7
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v8, #8
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s43, #0]
    v.extract    s41, v8, #9
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v8, #10
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s43, #0]
    v.extract    s41, v8, #11
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v8, #12
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s43, #0]
    v.extract    s41, v8, #13
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v8, #14
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s43, #0]
    v.extract    s41, v8, #15
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s41, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s41, b11, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s41
    mb.wait      s41
    s.addi       s42, s20, #32
    s.add        s43, s7, s42
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s42, v12, #0
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s44, #0]
    v.extract    s42, v12, #1
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v12, #2
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s44, #0]
    v.extract    s42, v12, #3
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v12, #4
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s44, #0]
    v.extract    s42, v12, #5
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v12, #6
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s44, #0]
    v.extract    s42, v12, #7
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v12, #8
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s44, #0]
    v.extract    s42, v12, #9
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v12, #10
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s44, #0]
    v.extract    s42, v12, #11
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v12, #12
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s44, #0]
    v.extract    s42, v12, #13
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v12, #14
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s44, #0]
    v.extract    s42, v12, #15
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s42, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s42, b12, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s42
    mb.wait      s42
    s.addi       s43, s20, #32
    s.add        s44, s7, s43
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s43, v13, #0
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s45, #0]
    v.extract    s43, v13, #1
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v13, #2
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s45, #0]
    v.extract    s43, v13, #3
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v13, #4
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s45, #0]
    v.extract    s43, v13, #5
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v13, #6
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s45, #0]
    v.extract    s43, v13, #7
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v13, #8
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s45, #0]
    v.extract    s43, v13, #9
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v13, #10
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s45, #0]
    v.extract    s43, v13, #11
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v13, #12
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s45, #0]
    v.extract    s43, v13, #13
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v13, #14
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s45, #0]
    v.extract    s43, v13, #15
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s43, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s43, b13, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s43
    mb.wait      s43
    s.addi       s44, s20, #32
    s.add        s45, s7, s44
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s44, v14, #0
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s46, #0]
    v.extract    s44, v14, #1
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v14, #2
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s46, #0]
    v.extract    s44, v14, #3
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v14, #4
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s46, #0]
    v.extract    s44, v14, #5
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v14, #6
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s46, #0]
    v.extract    s44, v14, #7
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v14, #8
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s46, #0]
    v.extract    s44, v14, #9
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v14, #10
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s46, #0]
    v.extract    s44, v14, #11
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v14, #12
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s46, #0]
    v.extract    s44, v14, #13
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v14, #14
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s46, #0]
    v.extract    s44, v14, #15
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s44, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s44, b14, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s44
    mb.wait      s44
    s.addi       s45, s20, #32
    s.add        s46, s7, s45
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s45, v15, #0
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s47, #0]
    v.extract    s45, v15, #1
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v15, #2
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s47, #0]
    v.extract    s45, v15, #3
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v15, #4
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s47, #0]
    v.extract    s45, v15, #5
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v15, #6
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s47, #0]
    v.extract    s45, v15, #7
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v15, #8
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s47, #0]
    v.extract    s45, v15, #9
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v15, #10
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s47, #0]
    v.extract    s45, v15, #11
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v15, #12
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s47, #0]
    v.extract    s45, v15, #13
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v15, #14
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s47, #0]
    v.extract    s45, v15, #15
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s45, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s45, b15, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s45
    mb.wait      s45
    s.addi       s46, s24, #1024                 // 512 bytes of repack scratch
    v.extract    s47, v20, #0
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    s.movz       s47, #0
    s.add        s49, s47, s27                   // the tile origin
    v.splat      v22, s49
    v.add        v23, v2, v22
    s.movz       s47, #0
    s.add        s49, s47, s22                   // the tile origin
    v.splat      v22, s49
    v.cmp.lt     p3, v23, v22
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #0
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #1
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #1
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #2
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #2
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #3
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #3
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #4
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #4
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #5
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #5
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #6
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #6
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #7
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #7
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #8
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #8
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #9
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #9
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #10
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #10
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #11
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #11
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #12
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #12
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #13
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #13
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #14
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #14
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #15
    s.add        s48, s47, s18
    s.addi       s47, s48, #64
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #15
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #0
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    s.movz       s47, #0
    s.add        s49, s47, s28                   // the tile origin
    v.splat      v22, s49
    v.add        v23, v2, v22
    s.movz       s47, #0
    s.add        s49, s47, s22                   // the tile origin
    v.splat      v22, s49
    v.cmp.lt     p3, v23, v22
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #256
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #1
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #257
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #2
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #258
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #3
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #259
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #4
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #260
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #5
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #261
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #6
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #262
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #7
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #263
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #8
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #264
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #9
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #265
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #10
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #266
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #11
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #267
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #12
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #268
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #13
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #269
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #14
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #270
    v.st.scatter.b [s47, v19], v22
    v.extract    s47, v20, #15
    s.add        s48, s47, s18
    s.addi       s47, s48, #80
    s.add        s48, s16, s47
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s48, #0]
    s.addi       s47, s46, #271
    v.st.scatter.b [s47, v19], v22
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v22, [s46, #0]
    v.mov        v48, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s47, s46, #64
    v.ld.w       v22, [s47, #0]
    v.mov        v49, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s47, s46, #128
    v.ld.w       v22, [s47, #0]
    v.mov        v50, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s47, s46, #192
    v.ld.w       v22, [s47, #0]
    v.mov        v51, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s47, s46, #256
    v.ld.w       v22, [s47, #0]
    v.mov        v52, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s47, s46, #320
    v.ld.w       v22, [s47, #0]
    v.mov        v53, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s47, s46, #384
    v.ld.w       v22, [s47, #0]
    v.mov        v54, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s47, s46, #448
    v.ld.w       v22, [s47, #0]
    v.mov        v55, v22                        // hand off through the shared window (sec 7.3)
    s.addi       s46, s15, #-64
    v.splat      v22, s46
    v.sub        v23, v22, v16
    v.movi       v22, #0
    v.cmp.gt     p3, v23, v22
    v.movi       v22, #0
    v.max.s      v24, v23, v22
    v.movi       v22, #4
    v.min.s      v23, v24, v22
    v.movi       v22, #1
    v.movi       v24, #3
    v.shl        v25, v23, v24
    v.shl        v24, v22, v25
    v.movi       v22, #1
    v.sub        v25, v24, v22
    v.movi       v22, #4
    v.cmp.ge     p4, v23, v22
    v.movi       v22, #-1
    @p4 v.sel        v23, v22, v25
    s.addi       s46, s20, #64
    s.add        s47, s7, s46
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s46, v3, #0
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s48, #0]
    v.extract    s46, v3, #1
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v3, #2
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s48, #0]
    v.extract    s46, v3, #3
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v3, #4
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s48, #0]
    v.extract    s46, v3, #5
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v3, #6
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s48, #0]
    v.extract    s46, v3, #7
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v3, #8
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s48, #0]
    v.extract    s46, v3, #9
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v3, #10
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s48, #0]
    v.extract    s46, v3, #11
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v3, #12
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s48, #0]
    v.extract    s46, v3, #13
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v3, #14
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s48, #0]
    v.extract    s46, v3, #15
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s46, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s46, b16, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s46
    mb.wait      s46
    s.addi       s47, s20, #64
    s.add        s48, s7, s47
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s47, v4, #0
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s49, #0]
    v.extract    s47, v4, #1
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v4, #2
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s49, #0]
    v.extract    s47, v4, #3
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v4, #4
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s49, #0]
    v.extract    s47, v4, #5
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v4, #6
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s49, #0]
    v.extract    s47, v4, #7
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v4, #8
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s49, #0]
    v.extract    s47, v4, #9
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v4, #10
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s49, #0]
    v.extract    s47, v4, #11
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v4, #12
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s49, #0]
    v.extract    s47, v4, #13
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v4, #14
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s49, #0]
    v.extract    s47, v4, #15
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s47, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s47, b17, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s47
    mb.wait      s47
    s.addi       s48, s20, #64
    s.add        s49, s7, s48
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s48, v5, #0
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s50, #0]
    v.extract    s48, v5, #1
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v5, #2
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s50, #0]
    v.extract    s48, v5, #3
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v5, #4
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s50, #0]
    v.extract    s48, v5, #5
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v5, #6
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s50, #0]
    v.extract    s48, v5, #7
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v5, #8
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s50, #0]
    v.extract    s48, v5, #9
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v5, #10
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s50, #0]
    v.extract    s48, v5, #11
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v5, #12
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s50, #0]
    v.extract    s48, v5, #13
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v5, #14
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s50, #0]
    v.extract    s48, v5, #15
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s48, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s48, b18, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s48
    mb.wait      s48
    s.addi       s49, s20, #64
    s.add        s50, s7, s49
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s49, v8, #0
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s51, #0]
    v.extract    s49, v8, #1
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v8, #2
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s51, #0]
    v.extract    s49, v8, #3
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v8, #4
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s51, #0]
    v.extract    s49, v8, #5
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v8, #6
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s51, #0]
    v.extract    s49, v8, #7
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v8, #8
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s51, #0]
    v.extract    s49, v8, #9
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v8, #10
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s51, #0]
    v.extract    s49, v8, #11
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v8, #12
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s51, #0]
    v.extract    s49, v8, #13
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v8, #14
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s51, #0]
    v.extract    s49, v8, #15
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s49, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s49, b19, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s49
    mb.wait      s49
    s.addi       s50, s20, #64
    s.add        s51, s7, s50
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s50, v12, #0
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s52, #0]
    v.extract    s50, v12, #1
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v12, #2
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s52, #0]
    v.extract    s50, v12, #3
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v12, #4
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s52, #0]
    v.extract    s50, v12, #5
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v12, #6
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s52, #0]
    v.extract    s50, v12, #7
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v12, #8
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s52, #0]
    v.extract    s50, v12, #9
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v12, #10
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s52, #0]
    v.extract    s50, v12, #11
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v12, #12
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s52, #0]
    v.extract    s50, v12, #13
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v12, #14
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s52, #0]
    v.extract    s50, v12, #15
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s50, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s50, b20, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s50
    mb.wait      s50
    s.addi       s51, s20, #64
    s.add        s52, s7, s51
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s51, v13, #0
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s53, #0]
    v.extract    s51, v13, #1
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v13, #2
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s53, #0]
    v.extract    s51, v13, #3
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v13, #4
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s53, #0]
    v.extract    s51, v13, #5
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v13, #6
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s53, #0]
    v.extract    s51, v13, #7
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v13, #8
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s53, #0]
    v.extract    s51, v13, #9
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v13, #10
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s53, #0]
    v.extract    s51, v13, #11
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v13, #12
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s53, #0]
    v.extract    s51, v13, #13
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v13, #14
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s53, #0]
    v.extract    s51, v13, #15
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s51, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s51, b21, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s51
    mb.wait      s51
    s.addi       s52, s20, #64
    s.add        s53, s7, s52
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s52, v14, #0
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s54, #0]
    v.extract    s52, v14, #1
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v14, #2
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s54, #0]
    v.extract    s52, v14, #3
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v14, #4
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s54, #0]
    v.extract    s52, v14, #5
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v14, #6
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s54, #0]
    v.extract    s52, v14, #7
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v14, #8
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s54, #0]
    v.extract    s52, v14, #9
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v14, #10
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s54, #0]
    v.extract    s52, v14, #11
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v14, #12
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s54, #0]
    v.extract    s52, v14, #13
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v14, #14
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s54, #0]
    v.extract    s52, v14, #15
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s52, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s52, b22, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s52
    mb.wait      s52
    s.addi       s53, s20, #64
    s.add        s54, s7, s53
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s53, v15, #0
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s55, #0]
    v.extract    s53, v15, #1
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v56, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v15, #2
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s55, #0]
    v.extract    s53, v15, #3
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v57, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v15, #4
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s55, #0]
    v.extract    s53, v15, #5
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v58, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v15, #6
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s55, #0]
    v.extract    s53, v15, #7
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v59, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v15, #8
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s55, #0]
    v.extract    s53, v15, #9
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v60, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v15, #10
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s55, #0]
    v.extract    s53, v15, #11
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v61, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v15, #12
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s55, #0]
    v.extract    s53, v15, #13
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v62, v22                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v15, #14
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v22, [s55, #0]
    v.extract    s53, v15, #15
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v24, [s53, #0]
    v.or         v25, v22, v24
    v.and        v22, v25, v23
    v.mov        v63, v22                        // hand off through the shared window (sec 7.3)
    mb.arm       s53, b23, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s53
    mb.wait      s53
    s.addi       s54, s24, #1536                 // 512 bytes of repack scratch
    v.extract    s55, v20, #0
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    s.movz       s55, #0
    s.add        s57, s55, s29                   // the tile origin
    v.splat      v22, s57
    v.add        v23, v2, v22
    s.movz       s55, #0
    s.add        s57, s55, s22                   // the tile origin
    v.splat      v22, s57
    v.cmp.lt     p3, v23, v22
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #0
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #1
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #1
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #2
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #2
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #3
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #3
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #4
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #4
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #5
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #5
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #6
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #6
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #7
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #7
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #8
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #8
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #9
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #9
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #10
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #10
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #11
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #11
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #12
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #12
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #13
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #13
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #14
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #14
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #15
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v22, [s56, #0]
    s.addi       s55, s54, #15
    v.st.scatter.b [s55, v19], v22
    v.extract    s55, v20, #0
    s.add        s56, s55, s18
    s.addi       s55, s56, #112
    s.add        s56, s16, s55
    s.movz       s55, #0
    s.add        s57, s55, s30                   // the tile origin
    v.splat      v22, s57
    v.add        v23, v2, v22
    s.movz       s55, #0
    s.add        s57, s55, s22                   // the tile origin
    v.splat      v2, s57
    v.cmp.lt     p3, v23, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s56, #0]
    s.addi       s22, s54, #256
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #1
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #257
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #2
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #258
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #3
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #259
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #4
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #260
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #5
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #261
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #6
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #262
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #7
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #263
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #8
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #264
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #9
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #265
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #10
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #266
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #11
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #267
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #12
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #268
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #13
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #269
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #14
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #270
    v.st.scatter.b [s22, v19], v2
    v.extract    s22, v20, #15
    s.add        s55, s22, s18
    s.addi       s22, s55, #112
    s.add        s55, s16, s22
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.b       v2, [s55, #0]
    s.addi       s22, s54, #271
    v.st.scatter.b [s22, v19], v2
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v2, [s54, #0]
    v.mov        v48, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s22, s54, #64
    v.ld.w       v2, [s22, #0]
    v.mov        v49, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s22, s54, #128
    v.ld.w       v2, [s22, #0]
    v.mov        v50, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s22, s54, #192
    v.ld.w       v2, [s22, #0]
    v.mov        v51, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s22, s54, #256
    v.ld.w       v2, [s22, #0]
    v.mov        v52, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s22, s54, #320
    v.ld.w       v2, [s22, #0]
    v.mov        v53, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s22, s54, #384
    v.ld.w       v2, [s22, #0]
    v.mov        v54, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s22, s54, #448
    v.ld.w       v2, [s22, #0]
    v.mov        v55, v2                         // hand off through the shared window (sec 7.3)
    s.addi       s22, s15, #-96
    v.splat      v2, s22
    v.sub        v20, v2, v16
    v.movi       v2, #0
    v.cmp.gt     p3, v20, v2
    v.movi       v2, #0
    v.max.s      v16, v20, v2
    v.movi       v2, #4
    v.min.s      v20, v16, v2
    v.movi       v2, #1
    v.movi       v16, #3
    v.shl        v22, v20, v16
    v.shl        v16, v2, v22
    v.movi       v2, #1
    v.sub        v22, v16, v2
    v.movi       v2, #4
    v.cmp.ge     p4, v20, v2
    v.movi       v2, #-1
    @p4 v.sel        v16, v2, v22
    s.addi       s15, s20, #96
    s.add        s22, s7, s15
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s15, v3, #0
    s.add        s54, s22, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s54, #0]
    v.extract    s15, v3, #1
    s.add        s54, s22, s15
    s.addi       s15, s54, #-32
    p.and        p4, p2, p3
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v20, [s15, #0]
    v.or         v22, v2, v20
    v.and        v2, v22, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v3, #2
    s.add        s54, s22, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s54, #0]
    v.extract    s15, v3, #3
    s.add        s54, s22, s15
    s.addi       s15, s54, #-32
    p.and        p4, p2, p3
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v20, [s15, #0]
    v.or         v22, v2, v20
    v.and        v2, v22, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v3, #4
    s.add        s54, s22, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s54, #0]
    v.extract    s15, v3, #5
    s.add        s54, s22, s15
    s.addi       s15, s54, #-32
    p.and        p4, p2, p3
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v20, [s15, #0]
    v.or         v22, v2, v20
    v.and        v2, v22, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v3, #6
    s.add        s54, s22, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s54, #0]
    v.extract    s15, v3, #7
    s.add        s54, s22, s15
    s.addi       s15, s54, #-32
    p.and        p4, p2, p3
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v20, [s15, #0]
    v.or         v22, v2, v20
    v.and        v2, v22, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v3, #8
    s.add        s54, s22, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s54, #0]
    v.extract    s15, v3, #9
    s.add        s54, s22, s15
    s.addi       s15, s54, #-32
    p.and        p4, p2, p3
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v20, [s15, #0]
    v.or         v22, v2, v20
    v.and        v2, v22, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v3, #10
    s.add        s54, s22, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s54, #0]
    v.extract    s15, v3, #11
    s.add        s54, s22, s15
    s.addi       s15, s54, #-32
    p.and        p4, p2, p3
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v20, [s15, #0]
    v.or         v22, v2, v20
    v.and        v2, v22, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v3, #12
    s.add        s54, s22, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s54, #0]
    v.extract    s15, v3, #13
    s.add        s54, s22, s15
    s.addi       s15, s54, #-32
    p.and        p4, p2, p3
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v20, [s15, #0]
    v.or         v22, v2, v20
    v.and        v2, v22, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v3, #14
    s.add        s54, s22, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s54, #0]
    v.extract    s15, v3, #15
    s.add        s54, s22, s15
    s.addi       s15, s54, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s15, #0]
    v.or         v20, v2, v3
    v.and        v2, v20, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s15, b24, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s15
    mb.wait      s15
    s.addi       s22, s20, #96
    s.add        s54, s7, s22
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s22, v4, #0
    s.add        s55, s54, s22
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s55, #0]
    v.extract    s22, v4, #1
    s.add        s55, s54, s22
    s.addi       s22, s55, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s22, #0]
    v.or         v20, v2, v3
    v.and        v2, v20, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s22, v4, #2
    s.add        s55, s54, s22
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s55, #0]
    v.extract    s22, v4, #3
    s.add        s55, s54, s22
    s.addi       s22, s55, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s22, #0]
    v.or         v20, v2, v3
    v.and        v2, v20, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s22, v4, #4
    s.add        s55, s54, s22
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s55, #0]
    v.extract    s22, v4, #5
    s.add        s55, s54, s22
    s.addi       s22, s55, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s22, #0]
    v.or         v20, v2, v3
    v.and        v2, v20, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s22, v4, #6
    s.add        s55, s54, s22
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s55, #0]
    v.extract    s22, v4, #7
    s.add        s55, s54, s22
    s.addi       s22, s55, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s22, #0]
    v.or         v20, v2, v3
    v.and        v2, v20, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s22, v4, #8
    s.add        s55, s54, s22
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s55, #0]
    v.extract    s22, v4, #9
    s.add        s55, s54, s22
    s.addi       s22, s55, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s22, #0]
    v.or         v20, v2, v3
    v.and        v2, v20, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s22, v4, #10
    s.add        s55, s54, s22
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s55, #0]
    v.extract    s22, v4, #11
    s.add        s55, s54, s22
    s.addi       s22, s55, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s22, #0]
    v.or         v20, v2, v3
    v.and        v2, v20, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s22, v4, #12
    s.add        s55, s54, s22
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s55, #0]
    v.extract    s22, v4, #13
    s.add        s55, s54, s22
    s.addi       s22, s55, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s22, #0]
    v.or         v20, v2, v3
    v.and        v2, v20, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s22, v4, #14
    s.add        s55, s54, s22
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s55, #0]
    v.extract    s22, v4, #15
    s.add        s55, s54, s22
    s.addi       s22, s55, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s22, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s22, b25, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s22
    mb.wait      s22
    s.addi       s54, s20, #96
    s.add        s55, s7, s54
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s54, v5, #0
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s56, #0]
    v.extract    s54, v5, #1
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s54, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s54, v5, #2
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s56, #0]
    v.extract    s54, v5, #3
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s54, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s54, v5, #4
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s56, #0]
    v.extract    s54, v5, #5
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s54, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s54, v5, #6
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s56, #0]
    v.extract    s54, v5, #7
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s54, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s54, v5, #8
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s56, #0]
    v.extract    s54, v5, #9
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s54, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s54, v5, #10
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s56, #0]
    v.extract    s54, v5, #11
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s54, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s54, v5, #12
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s56, #0]
    v.extract    s54, v5, #13
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s54, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s54, v5, #14
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s56, #0]
    v.extract    s54, v5, #15
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s54, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s54, b26, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s54
    mb.wait      s54
    s.addi       s55, s20, #96
    s.add        s56, s7, s55
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s55, v8, #0
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s55, v8, #1
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s55, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s55, v8, #2
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s55, v8, #3
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s55, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s55, v8, #4
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s55, v8, #5
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s55, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s55, v8, #6
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s55, v8, #7
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s55, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s55, v8, #8
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s55, v8, #9
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s55, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s55, v8, #10
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s55, v8, #11
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s55, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s55, v8, #12
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s55, v8, #13
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s55, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s55, v8, #14
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s57, #0]
    v.extract    s55, v8, #15
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s55, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s55, b27, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s55
    mb.wait      s55
    s.addi       s56, s20, #96
    s.add        s57, s7, s56
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s56, v12, #0
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s56, v12, #1
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s56, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s56, v12, #2
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s56, v12, #3
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s56, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s56, v12, #4
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s56, v12, #5
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s56, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s56, v12, #6
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s56, v12, #7
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s56, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s56, v12, #8
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s56, v12, #9
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s56, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s56, v12, #10
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s56, v12, #11
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s56, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s56, v12, #12
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s56, v12, #13
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s56, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s56, v12, #14
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s58, #0]
    v.extract    s56, v12, #15
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s56, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s56, b28, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s56
    mb.wait      s56
    s.addi       s57, s20, #96
    s.add        s58, s7, s57
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s57, v13, #0
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v13, #1
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v13, #2
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v13, #3
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v13, #4
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v13, #5
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v13, #6
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v13, #7
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v13, #8
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v13, #9
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v13, #10
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v13, #11
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v13, #12
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v13, #13
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s57, v13, #14
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s59, #0]
    v.extract    s57, v13, #15
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s57, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s57, b29, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s57
    mb.wait      s57
    s.addi       s58, s20, #96
    s.add        s59, s7, s58
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s58, v14, #0
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v14, #1
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v14, #2
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v14, #3
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v14, #4
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v14, #5
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v14, #6
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v14, #7
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v14, #8
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v14, #9
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v14, #10
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v14, #11
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v14, #12
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v14, #13
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s58, v14, #14
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s60, #0]
    v.extract    s58, v14, #15
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s58, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s58, b30, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s58
    mb.wait      s58
    s.addi       s59, s20, #96
    s.add        s60, s7, s59
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s59, v15, #0
    s.add        s15, s60, s59
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s15, #0]
    v.extract    s15, v15, #1
    s.add        s22, s60, s15
    s.addi       s15, s22, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s15, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v56, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v15, #2
    s.add        s22, s60, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s22, #0]
    v.extract    s15, v15, #3
    s.add        s22, s60, s15
    s.addi       s15, s22, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s15, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v57, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v15, #4
    s.add        s22, s60, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s22, #0]
    v.extract    s15, v15, #5
    s.add        s22, s60, s15
    s.addi       s15, s22, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s15, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v58, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v15, #6
    s.add        s22, s60, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s22, #0]
    v.extract    s15, v15, #7
    s.add        s22, s60, s15
    s.addi       s15, s22, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s15, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v59, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v15, #8
    s.add        s22, s60, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s22, #0]
    v.extract    s15, v15, #9
    s.add        s22, s60, s15
    s.addi       s15, s22, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s15, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v15, #10
    s.add        s22, s60, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s22, #0]
    v.extract    s15, v15, #11
    s.add        s22, s60, s15
    s.addi       s15, s22, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s15, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v15, #12
    s.add        s22, s60, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s22, #0]
    v.extract    s15, v15, #13
    s.add        s22, s60, s15
    s.addi       s15, s22, #-32
    p.and        p4, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s15, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.extract    s15, v15, #14
    s.add        s22, s60, s15
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s22, #0]
    v.extract    s15, v15, #15
    s.add        s22, s60, s15
    s.addi       s15, s22, #-32
    p.and        p1, p2, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s15, #0]
    v.or         v4, v2, v3
    v.and        v2, v4, v16
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    mb.arm       s15, b31, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s15
    mb.wait      s15
    s.addi       s22, s24, #2048
    s.movz       s23, #0
    a.vread      v2, a8, s23
    v.st.scatter.w [s22, v19], v2
    s.addi       s23, s22, #4
    s.movz       s31, #1
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #8
    s.movz       s31, #2
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #12
    s.movz       s31, #3
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #16
    s.movz       s31, #4
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #20
    s.movz       s31, #5
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #24
    s.movz       s31, #6
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #28
    s.movz       s31, #7
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #32
    s.movz       s31, #8
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #36
    s.movz       s31, #9
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #40
    s.movz       s31, #10
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #44
    s.movz       s31, #11
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #48
    s.movz       s31, #12
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #52
    s.movz       s31, #13
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #56
    s.movz       s31, #14
    a.vread      v2, a8, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #60
    s.movz       s22, #15
    a.vread      v2, a8, s22
    v.st.scatter.w [s23, v19], v2
    fence.acq_rel.device
    s.addi       s22, s24, #3072
    s.movz       s23, #0
    a.vread      v2, a9, s23
    v.st.scatter.w [s22, v19], v2
    s.addi       s23, s22, #4
    s.movz       s31, #1
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #8
    s.movz       s31, #2
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #12
    s.movz       s31, #3
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #16
    s.movz       s31, #4
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #20
    s.movz       s31, #5
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #24
    s.movz       s31, #6
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #28
    s.movz       s31, #7
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #32
    s.movz       s31, #8
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #36
    s.movz       s31, #9
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #40
    s.movz       s31, #10
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #44
    s.movz       s31, #11
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #48
    s.movz       s31, #12
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #52
    s.movz       s31, #13
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #56
    s.movz       s31, #14
    a.vread      v2, a9, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #60
    s.movz       s22, #15
    a.vread      v2, a9, s22
    v.st.scatter.w [s23, v19], v2
    fence.acq_rel.device
    s.addi       s22, s24, #4096
    s.movz       s23, #0
    a.vread      v2, a10, s23
    v.st.scatter.w [s22, v19], v2
    s.addi       s23, s22, #4
    s.movz       s31, #1
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #8
    s.movz       s31, #2
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #12
    s.movz       s31, #3
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #16
    s.movz       s31, #4
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #20
    s.movz       s31, #5
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #24
    s.movz       s31, #6
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #28
    s.movz       s31, #7
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #32
    s.movz       s31, #8
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #36
    s.movz       s31, #9
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #40
    s.movz       s31, #10
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #44
    s.movz       s31, #11
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #48
    s.movz       s31, #12
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #52
    s.movz       s31, #13
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #56
    s.movz       s31, #14
    a.vread      v2, a10, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #60
    s.movz       s22, #15
    a.vread      v2, a10, s22
    v.st.scatter.w [s23, v19], v2
    fence.acq_rel.device
    s.addi       s22, s24, #5120
    s.movz       s23, #0
    a.vread      v2, a11, s23
    v.st.scatter.w [s22, v19], v2
    s.addi       s23, s22, #4
    s.movz       s31, #1
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #8
    s.movz       s31, #2
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #12
    s.movz       s31, #3
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #16
    s.movz       s31, #4
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #20
    s.movz       s31, #5
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #24
    s.movz       s31, #6
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #28
    s.movz       s31, #7
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #32
    s.movz       s31, #8
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #36
    s.movz       s31, #9
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #40
    s.movz       s31, #10
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #44
    s.movz       s31, #11
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #48
    s.movz       s31, #12
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #52
    s.movz       s31, #13
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #56
    s.movz       s31, #14
    a.vread      v2, a11, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #60
    s.movz       s22, #15
    a.vread      v2, a11, s22
    v.st.scatter.w [s23, v19], v2
    fence.acq_rel.device
    s.addi       s22, s24, #6144
    s.movz       s23, #0
    a.vread      v2, a12, s23
    v.st.scatter.w [s22, v19], v2
    s.addi       s23, s22, #4
    s.movz       s31, #1
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #8
    s.movz       s31, #2
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #12
    s.movz       s31, #3
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #16
    s.movz       s31, #4
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #20
    s.movz       s31, #5
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #24
    s.movz       s31, #6
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #28
    s.movz       s31, #7
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #32
    s.movz       s31, #8
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #36
    s.movz       s31, #9
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #40
    s.movz       s31, #10
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #44
    s.movz       s31, #11
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #48
    s.movz       s31, #12
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #52
    s.movz       s31, #13
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #56
    s.movz       s31, #14
    a.vread      v2, a12, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #60
    s.movz       s22, #15
    a.vread      v2, a12, s22
    v.st.scatter.w [s23, v19], v2
    fence.acq_rel.device
    s.addi       s22, s24, #7168
    s.movz       s23, #0
    a.vread      v2, a13, s23
    v.st.scatter.w [s22, v19], v2
    s.addi       s23, s22, #4
    s.movz       s31, #1
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #8
    s.movz       s31, #2
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #12
    s.movz       s31, #3
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #16
    s.movz       s31, #4
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #20
    s.movz       s31, #5
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #24
    s.movz       s31, #6
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #28
    s.movz       s31, #7
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #32
    s.movz       s31, #8
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #36
    s.movz       s31, #9
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #40
    s.movz       s31, #10
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #44
    s.movz       s31, #11
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #48
    s.movz       s31, #12
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #52
    s.movz       s31, #13
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #56
    s.movz       s31, #14
    a.vread      v2, a13, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #60
    s.movz       s22, #15
    a.vread      v2, a13, s22
    v.st.scatter.w [s23, v19], v2
    fence.acq_rel.device
    s.addi       s22, s24, #8192
    s.movz       s23, #0
    a.vread      v2, a14, s23
    v.st.scatter.w [s22, v19], v2
    s.addi       s23, s22, #4
    s.movz       s31, #1
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #8
    s.movz       s31, #2
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #12
    s.movz       s31, #3
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #16
    s.movz       s31, #4
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #20
    s.movz       s31, #5
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #24
    s.movz       s31, #6
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #28
    s.movz       s31, #7
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #32
    s.movz       s31, #8
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #36
    s.movz       s31, #9
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #40
    s.movz       s31, #10
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #44
    s.movz       s31, #11
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #48
    s.movz       s31, #12
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #52
    s.movz       s31, #13
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #56
    s.movz       s31, #14
    a.vread      v2, a14, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #60
    s.movz       s22, #15
    a.vread      v2, a14, s22
    v.st.scatter.w [s23, v19], v2
    fence.acq_rel.device
    s.addi       s22, s24, #9216
    s.movz       s23, #0
    a.vread      v2, a15, s23
    v.st.scatter.w [s22, v19], v2
    s.addi       s23, s22, #4
    s.movz       s31, #1
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #8
    s.movz       s31, #2
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #12
    s.movz       s31, #3
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #16
    s.movz       s31, #4
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #20
    s.movz       s31, #5
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #24
    s.movz       s31, #6
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #28
    s.movz       s31, #7
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #32
    s.movz       s31, #8
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #36
    s.movz       s31, #9
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #40
    s.movz       s31, #10
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #44
    s.movz       s31, #11
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #48
    s.movz       s31, #12
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #52
    s.movz       s31, #13
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #56
    s.movz       s31, #14
    a.vread      v2, a15, s31
    v.st.scatter.w [s23, v19], v2
    s.addi       s23, s22, #60
    s.movz       s22, #15
    a.vread      v2, a15, s22
    v.st.scatter.w [s23, v19], v2
    fence.acq_rel.device
    s.addi       s22, s24, #10240
    s.movz       s23, #0
    a.vread      v2, a0, s23
    s.addi       s23, s24, #2048
    v.ld.w       v3, [s23, #0]
    vf.add       v4, v2, v3
    v.st.w       [s22, #0], v4
    s.addi       s23, s22, #64
    s.movz       s31, #1
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2112
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #128
    s.movz       s31, #2
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2176
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #192
    s.movz       s31, #3
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2240
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #256
    s.movz       s31, #4
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2304
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #320
    s.movz       s31, #5
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2368
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #384
    s.movz       s31, #6
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2432
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #448
    s.movz       s31, #7
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2496
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #512
    s.movz       s31, #8
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2560
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #576
    s.movz       s31, #9
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2624
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #640
    s.movz       s31, #10
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2688
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #704
    s.movz       s31, #11
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2752
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #768
    s.movz       s31, #12
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2816
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #832
    s.movz       s31, #13
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2880
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #896
    s.movz       s31, #14
    a.vread      v2, a0, s31
    s.addi       s31, s24, #2944
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #960
    s.movz       s22, #15
    a.vread      v2, a0, s22
    s.addi       s22, s24, #3008
    v.ld.w       v3, [s22, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    fence.acq_rel.device
    s.addi       s22, s24, #11264
    s.movz       s23, #0
    a.vread      v2, a1, s23
    s.addi       s23, s24, #3072
    v.ld.w       v3, [s23, #0]
    vf.add       v4, v2, v3
    v.st.w       [s22, #0], v4
    s.addi       s23, s22, #64
    s.movz       s31, #1
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3136
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #128
    s.movz       s31, #2
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3200
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #192
    s.movz       s31, #3
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3264
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #256
    s.movz       s31, #4
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3328
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #320
    s.movz       s31, #5
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3392
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #384
    s.movz       s31, #6
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3456
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #448
    s.movz       s31, #7
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3520
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #512
    s.movz       s31, #8
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3584
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #576
    s.movz       s31, #9
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3648
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #640
    s.movz       s31, #10
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3712
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #704
    s.movz       s31, #11
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3776
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #768
    s.movz       s31, #12
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3840
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #832
    s.movz       s31, #13
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3904
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #896
    s.movz       s31, #14
    a.vread      v2, a1, s31
    s.addi       s31, s24, #3968
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #960
    s.movz       s22, #15
    a.vread      v2, a1, s22
    s.addi       s22, s24, #4032
    v.ld.w       v3, [s22, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    fence.acq_rel.device
    s.addi       s22, s24, #12288
    s.movz       s23, #0
    a.vread      v2, a2, s23
    s.addi       s23, s24, #4096
    v.ld.w       v3, [s23, #0]
    vf.add       v4, v2, v3
    v.st.w       [s22, #0], v4
    s.addi       s23, s22, #64
    s.movz       s31, #1
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4160
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #128
    s.movz       s31, #2
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4224
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #192
    s.movz       s31, #3
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4288
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #256
    s.movz       s31, #4
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4352
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #320
    s.movz       s31, #5
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4416
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #384
    s.movz       s31, #6
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4480
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #448
    s.movz       s31, #7
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4544
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #512
    s.movz       s31, #8
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4608
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #576
    s.movz       s31, #9
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4672
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #640
    s.movz       s31, #10
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4736
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #704
    s.movz       s31, #11
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4800
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #768
    s.movz       s31, #12
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4864
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #832
    s.movz       s31, #13
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4928
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #896
    s.movz       s31, #14
    a.vread      v2, a2, s31
    s.addi       s31, s24, #4992
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #960
    s.movz       s22, #15
    a.vread      v2, a2, s22
    s.addi       s22, s24, #5056
    v.ld.w       v3, [s22, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    fence.acq_rel.device
    s.addi       s22, s24, #13312
    s.movz       s23, #0
    a.vread      v2, a3, s23
    s.addi       s23, s24, #5120
    v.ld.w       v3, [s23, #0]
    vf.add       v4, v2, v3
    v.st.w       [s22, #0], v4
    s.addi       s23, s22, #64
    s.movz       s31, #1
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5184
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #128
    s.movz       s31, #2
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5248
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #192
    s.movz       s31, #3
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5312
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #256
    s.movz       s31, #4
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5376
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #320
    s.movz       s31, #5
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5440
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #384
    s.movz       s31, #6
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5504
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #448
    s.movz       s31, #7
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5568
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #512
    s.movz       s31, #8
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5632
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #576
    s.movz       s31, #9
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5696
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #640
    s.movz       s31, #10
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5760
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #704
    s.movz       s31, #11
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5824
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #768
    s.movz       s31, #12
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5888
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #832
    s.movz       s31, #13
    a.vread      v2, a3, s31
    s.addi       s31, s24, #5952
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #896
    s.movz       s31, #14
    a.vread      v2, a3, s31
    s.addi       s31, s24, #6016
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #960
    s.movz       s22, #15
    a.vread      v2, a3, s22
    s.addi       s22, s24, #6080
    v.ld.w       v3, [s22, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    fence.acq_rel.device
    s.addi       s22, s24, #14336
    s.movz       s23, #0
    a.vread      v2, a4, s23
    s.addi       s23, s24, #6144
    v.ld.w       v3, [s23, #0]
    vf.add       v4, v2, v3
    v.st.w       [s22, #0], v4
    s.addi       s23, s22, #64
    s.movz       s31, #1
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6208
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #128
    s.movz       s31, #2
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6272
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #192
    s.movz       s31, #3
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6336
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #256
    s.movz       s31, #4
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6400
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #320
    s.movz       s31, #5
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6464
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #384
    s.movz       s31, #6
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6528
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #448
    s.movz       s31, #7
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6592
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #512
    s.movz       s31, #8
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6656
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #576
    s.movz       s31, #9
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6720
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #640
    s.movz       s31, #10
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6784
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #704
    s.movz       s31, #11
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6848
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #768
    s.movz       s31, #12
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6912
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #832
    s.movz       s31, #13
    a.vread      v2, a4, s31
    s.addi       s31, s24, #6976
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #896
    s.movz       s31, #14
    a.vread      v2, a4, s31
    s.addi       s31, s24, #7040
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #960
    s.movz       s22, #15
    a.vread      v2, a4, s22
    s.addi       s22, s24, #7104
    v.ld.w       v3, [s22, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    fence.acq_rel.device
    s.addi       s22, s24, #15360
    s.movz       s23, #0
    a.vread      v2, a5, s23
    s.addi       s23, s24, #7168
    v.ld.w       v3, [s23, #0]
    vf.add       v4, v2, v3
    v.st.w       [s22, #0], v4
    s.addi       s23, s22, #64
    s.movz       s31, #1
    a.vread      v2, a5, s31
    s.addi       s31, s24, #7232
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #128
    s.movz       s31, #2
    a.vread      v2, a5, s31
    s.addi       s31, s24, #7296
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #192
    s.movz       s31, #3
    a.vread      v2, a5, s31
    s.addi       s31, s24, #7360
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #256
    s.movz       s31, #4
    a.vread      v2, a5, s31
    s.addi       s31, s24, #7424
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #320
    s.movz       s31, #5
    a.vread      v2, a5, s31
    s.addi       s31, s24, #7488
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #384
    s.movz       s31, #6
    a.vread      v2, a5, s31
    s.addi       s31, s24, #7552
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #448
    s.movz       s31, #7
    a.vread      v2, a5, s31
    s.addi       s31, s24, #7616
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #512
    s.movz       s31, #8
    a.vread      v2, a5, s31
    s.addi       s31, s24, #7680
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #576
    s.movz       s31, #9
    a.vread      v2, a5, s31
    s.addi       s31, s24, #7744
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #640
    s.movz       s31, #10
    a.vread      v2, a5, s31
    s.addi       s31, s24, #7808
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #704
    s.movz       s31, #11
    a.vread      v2, a5, s31
    s.addi       s31, s24, #7872
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #768
    s.movz       s31, #12
    a.vread      v2, a5, s31
    s.addi       s31, s24, #7936
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #832
    s.movz       s31, #13
    a.vread      v2, a5, s31
    s.addi       s31, s24, #8000
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #896
    s.movz       s31, #14
    a.vread      v2, a5, s31
    s.addi       s31, s24, #8064
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #960
    s.movz       s22, #15
    a.vread      v2, a5, s22
    s.addi       s22, s24, #8128
    v.ld.w       v3, [s22, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    fence.acq_rel.device
    s.addi       s22, s24, #16384
    s.movz       s23, #0
    a.vread      v2, a6, s23
    s.addi       s23, s24, #8192
    v.ld.w       v3, [s23, #0]
    vf.add       v4, v2, v3
    v.st.w       [s22, #0], v4
    s.addi       s23, s22, #64
    s.movz       s31, #1
    a.vread      v2, a6, s31
    s.addi       s31, s24, #8256
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #128
    s.movz       s31, #2
    a.vread      v2, a6, s31
    s.addi       s31, s24, #8320
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #192
    s.movz       s31, #3
    a.vread      v2, a6, s31
    s.addi       s31, s24, #8384
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #256
    s.movz       s31, #4
    a.vread      v2, a6, s31
    s.addi       s31, s24, #8448
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #320
    s.movz       s31, #5
    a.vread      v2, a6, s31
    s.addi       s31, s24, #8512
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #384
    s.movz       s31, #6
    a.vread      v2, a6, s31
    s.addi       s31, s24, #8576
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #448
    s.movz       s31, #7
    a.vread      v2, a6, s31
    s.addi       s31, s24, #8640
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #512
    s.movz       s31, #8
    a.vread      v2, a6, s31
    s.addi       s31, s24, #8704
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #576
    s.movz       s31, #9
    a.vread      v2, a6, s31
    s.addi       s31, s24, #8768
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #640
    s.movz       s31, #10
    a.vread      v2, a6, s31
    s.addi       s31, s24, #8832
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #704
    s.movz       s31, #11
    a.vread      v2, a6, s31
    s.addi       s31, s24, #8896
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #768
    s.movz       s31, #12
    a.vread      v2, a6, s31
    s.addi       s31, s24, #8960
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #832
    s.movz       s31, #13
    a.vread      v2, a6, s31
    s.addi       s31, s24, #9024
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #896
    s.movz       s31, #14
    a.vread      v2, a6, s31
    s.addi       s31, s24, #9088
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #960
    s.movz       s22, #15
    a.vread      v2, a6, s22
    s.addi       s22, s24, #9152
    v.ld.w       v3, [s22, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    fence.acq_rel.device
    s.addi       s22, s24, #17408
    s.movz       s23, #0
    a.vread      v2, a7, s23
    s.addi       s23, s24, #9216
    v.ld.w       v3, [s23, #0]
    vf.add       v4, v2, v3
    v.st.w       [s22, #0], v4
    s.addi       s23, s22, #64
    s.movz       s31, #1
    a.vread      v2, a7, s31
    s.addi       s31, s24, #9280
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #128
    s.movz       s31, #2
    a.vread      v2, a7, s31
    s.addi       s31, s24, #9344
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #192
    s.movz       s31, #3
    a.vread      v2, a7, s31
    s.addi       s31, s24, #9408
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #256
    s.movz       s31, #4
    a.vread      v2, a7, s31
    s.addi       s31, s24, #9472
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #320
    s.movz       s31, #5
    a.vread      v2, a7, s31
    s.addi       s31, s24, #9536
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #384
    s.movz       s31, #6
    a.vread      v2, a7, s31
    s.addi       s31, s24, #9600
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #448
    s.movz       s31, #7
    a.vread      v2, a7, s31
    s.addi       s31, s24, #9664
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #512
    s.movz       s31, #8
    a.vread      v2, a7, s31
    s.addi       s31, s24, #9728
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #576
    s.movz       s31, #9
    a.vread      v2, a7, s31
    s.addi       s31, s24, #9792
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #640
    s.movz       s31, #10
    a.vread      v2, a7, s31
    s.addi       s31, s24, #9856
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #704
    s.movz       s31, #11
    a.vread      v2, a7, s31
    s.addi       s31, s24, #9920
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #768
    s.movz       s31, #12
    a.vread      v2, a7, s31
    s.addi       s31, s24, #9984
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #832
    s.movz       s31, #13
    a.vread      v2, a7, s31
    s.addi       s31, s24, #10048
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #896
    s.movz       s31, #14
    a.vread      v2, a7, s31
    s.addi       s31, s24, #10112
    v.ld.w       v3, [s31, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    s.addi       s23, s22, #960
    s.movz       s22, #15
    a.vread      v2, a7, s22
    s.addi       s22, s24, #10176
    v.ld.w       v3, [s22, #0]
    vf.add       v4, v2, v3
    v.st.w       [s23, #0], v4
    fence.acq_rel.device
    s.addi       s22, s18, #128
    s.addi       s23, s22, #0
    s.addi       s22, s20, #128
    s.addi       s31, s22, #0
    s.mov        s18, s23
    s.mov        s20, s31
    s.movz       s22, #0
    s.addi       s23, s24, #10240
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #1
    s.addi       s23, s24, #10304
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #2
    s.addi       s23, s24, #10368
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #3
    s.addi       s23, s24, #10432
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #4
    s.addi       s23, s24, #10496
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #5
    s.addi       s23, s24, #10560
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #6
    s.addi       s23, s24, #10624
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #7
    s.addi       s23, s24, #10688
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #8
    s.addi       s23, s24, #10752
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #9
    s.addi       s23, s24, #10816
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #10
    s.addi       s23, s24, #10880
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #11
    s.addi       s23, s24, #10944
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #12
    s.addi       s23, s24, #11008
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #13
    s.addi       s23, s24, #11072
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #14
    s.addi       s23, s24, #11136
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #15
    s.addi       s23, s24, #11200
    v.ld.w       v2, [s23, #0]
    a.vwrite     a0, s22, v2
    s.movz       s22, #0
    s.addi       s23, s24, #11264
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #1
    s.addi       s23, s24, #11328
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #2
    s.addi       s23, s24, #11392
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #3
    s.addi       s23, s24, #11456
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #4
    s.addi       s23, s24, #11520
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #5
    s.addi       s23, s24, #11584
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #6
    s.addi       s23, s24, #11648
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #7
    s.addi       s23, s24, #11712
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #8
    s.addi       s23, s24, #11776
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #9
    s.addi       s23, s24, #11840
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #10
    s.addi       s23, s24, #11904
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #11
    s.addi       s23, s24, #11968
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #12
    s.addi       s23, s24, #12032
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #13
    s.addi       s23, s24, #12096
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #14
    s.addi       s23, s24, #12160
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #15
    s.addi       s23, s24, #12224
    v.ld.w       v2, [s23, #0]
    a.vwrite     a1, s22, v2
    s.movz       s22, #0
    s.addi       s23, s24, #12288
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #1
    s.addi       s23, s24, #12352
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #2
    s.addi       s23, s24, #12416
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #3
    s.addi       s23, s24, #12480
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #4
    s.addi       s23, s24, #12544
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #5
    s.addi       s23, s24, #12608
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #6
    s.addi       s23, s24, #12672
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #7
    s.addi       s23, s24, #12736
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #8
    s.addi       s23, s24, #12800
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #9
    s.addi       s23, s24, #12864
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #10
    s.addi       s23, s24, #12928
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #11
    s.addi       s23, s24, #12992
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #12
    s.addi       s23, s24, #13056
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #13
    s.addi       s23, s24, #13120
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #14
    s.addi       s23, s24, #13184
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #15
    s.addi       s23, s24, #13248
    v.ld.w       v2, [s23, #0]
    a.vwrite     a2, s22, v2
    s.movz       s22, #0
    s.addi       s23, s24, #13312
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #1
    s.addi       s23, s24, #13376
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #2
    s.addi       s23, s24, #13440
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #3
    s.addi       s23, s24, #13504
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #4
    s.addi       s23, s24, #13568
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #5
    s.addi       s23, s24, #13632
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #6
    s.addi       s23, s24, #13696
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #7
    s.addi       s23, s24, #13760
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #8
    s.addi       s23, s24, #13824
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #9
    s.addi       s23, s24, #13888
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #10
    s.addi       s23, s24, #13952
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #11
    s.addi       s23, s24, #14016
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #12
    s.addi       s23, s24, #14080
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #13
    s.addi       s23, s24, #14144
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #14
    s.addi       s23, s24, #14208
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #15
    s.addi       s23, s24, #14272
    v.ld.w       v2, [s23, #0]
    a.vwrite     a3, s22, v2
    s.movz       s22, #0
    s.addi       s23, s24, #14336
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #1
    s.addi       s23, s24, #14400
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #2
    s.addi       s23, s24, #14464
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #3
    s.addi       s23, s24, #14528
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #4
    s.addi       s23, s24, #14592
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #5
    s.addi       s23, s24, #14656
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #6
    s.addi       s23, s24, #14720
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #7
    s.addi       s23, s24, #14784
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #8
    s.addi       s23, s24, #14848
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #9
    s.addi       s23, s24, #14912
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #10
    s.addi       s23, s24, #14976
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #11
    s.addi       s23, s24, #15040
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #12
    s.addi       s23, s24, #15104
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #13
    s.addi       s23, s24, #15168
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #14
    s.addi       s23, s24, #15232
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #15
    s.addi       s23, s24, #15296
    v.ld.w       v2, [s23, #0]
    a.vwrite     a4, s22, v2
    s.movz       s22, #0
    s.addi       s23, s24, #15360
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #1
    s.addi       s23, s24, #15424
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #2
    s.addi       s23, s24, #15488
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #3
    s.addi       s23, s24, #15552
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #4
    s.addi       s23, s24, #15616
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #5
    s.addi       s23, s24, #15680
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #6
    s.addi       s23, s24, #15744
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #7
    s.addi       s23, s24, #15808
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #8
    s.addi       s23, s24, #15872
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #9
    s.addi       s23, s24, #15936
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #10
    s.addi       s23, s24, #16000
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #11
    s.addi       s23, s24, #16064
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #12
    s.addi       s23, s24, #16128
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #13
    s.addi       s23, s24, #16192
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #14
    s.addi       s23, s24, #16256
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #15
    s.addi       s23, s24, #16320
    v.ld.w       v2, [s23, #0]
    a.vwrite     a5, s22, v2
    s.movz       s22, #0
    s.addi       s23, s24, #16384
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #1
    s.addi       s23, s24, #16448
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #2
    s.addi       s23, s24, #16512
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #3
    s.addi       s23, s24, #16576
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #4
    s.addi       s23, s24, #16640
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #5
    s.addi       s23, s24, #16704
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #6
    s.addi       s23, s24, #16768
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #7
    s.addi       s23, s24, #16832
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #8
    s.addi       s23, s24, #16896
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #9
    s.addi       s23, s24, #16960
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #10
    s.addi       s23, s24, #17024
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #11
    s.addi       s23, s24, #17088
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #12
    s.addi       s23, s24, #17152
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #13
    s.addi       s23, s24, #17216
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #14
    s.addi       s23, s24, #17280
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #15
    s.addi       s23, s24, #17344
    v.ld.w       v2, [s23, #0]
    a.vwrite     a6, s22, v2
    s.movz       s22, #0
    s.addi       s23, s24, #17408
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #1
    s.addi       s23, s24, #17472
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #2
    s.addi       s23, s24, #17536
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #3
    s.addi       s23, s24, #17600
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #4
    s.addi       s23, s24, #17664
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #5
    s.addi       s23, s24, #17728
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #6
    s.addi       s23, s24, #17792
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #7
    s.addi       s23, s24, #17856
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #8
    s.addi       s23, s24, #17920
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #9
    s.addi       s23, s24, #17984
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #10
    s.addi       s23, s24, #18048
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #11
    s.addi       s23, s24, #18112
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #12
    s.addi       s23, s24, #18176
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #13
    s.addi       s23, s24, #18240
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #14
    s.addi       s23, s24, #18304
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.movz       s22, #15
    s.addi       s23, s24, #18368
    v.ld.w       v2, [s23, #0]
    a.vwrite     a7, s22, v2
    s.add        s22, s17, s14
    s.mov        s17, s22
    s.movz       s22, #1
    br.nz        s22, for_18
endfor_19:
    s.movz       s2, #0
    v.extract    s5, v1, #0
    a.vread      v0, a0, s2
    v.splat      v2, s5
    s.mul        s2, s1, s19
    v.splat      v3, s21
    vf.mul       v4, v0, v2
    s.movz       s5, #0
    s.movz       s6, #0
    s.add        s7, s5, s4                      // the tile origin
    s.movz       s5, #0
    vf.mul       v0, v4, v3
    s.movz       s8, #0
    s.muli       s9, s2, #2
    s.muli       s2, s4, #2
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s7
    s.add        s7, s6, s1                      // the tile origin
    s.add        s1, s5, s12                     // the tile origin
    s.add        s5, s8, s3                      // the tile origin
    v.splat      v5, s7
    v.splat      v6, s1
    v.add        v7, v2, v4
    v.splat      v4, s5
    vf.cvt.f32.bf16 v8, v0
    s.add        s1, s9, s2
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v7, v4
    s.add        s5, s13, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    v.extract    s6, v1, #1
    @p3 v.st.h       [s5, #0], v8
    a.vread      v0, a0, s1
    v.splat      v4, s6
    s.muli       s1, s19, #2
    s.addi       s5, s4, #16
    vf.mul       v5, v0, v4
    s.addi       s6, s4, #32
    s.addi       s8, s7, #1
    s.muli       s10, s1, #1
    s.addi       s11, s4, #48
    vf.mul       v0, v5, v3
    v.splat      v4, s8
    s.addi       s8, s4, #64
    s.add        s12, s10, s9
    v.cmp.lt     p1, v4, v6
    vf.cvt.f32.bf16 v4, v0
    s.add        s10, s12, s2
    s.addi       s12, s4, #80
    s.add        s14, s13, s10
    p.and        p3, p1, p2
    s.addi       s10, s4, #96
    @p3 v.st.h       [s14, #0], v4
    s.addi       s14, s4, #112
    s.movz       s4, #2
    v.extract    s16, v1, #2
    a.vread      v0, a0, s4
    v.splat      v4, s16
    s.muli       s4, s1, #2
    s.addi       s16, s7, #2
    vf.mul       v5, v0, v4
    v.splat      v0, s16
    s.movz       s16, #3
    s.add        s17, s4, s9
    v.cmp.lt     p1, v0, v6
    vf.mul       v0, v5, v3
    s.add        s4, s17, s2
    p.and        p3, p1, p2
    s.add        s17, s13, s4
    v.extract    s4, v1, #3
    vf.cvt.f32.bf16 v4, v0
    v.splat      v0, s4
    s.muli       s4, s1, #3
    s.addi       s18, s7, #3
    s.movz       s19, #4
    @p3 v.st.h       [s17, #0], v4
    a.vread      v4, a0, s16
    s.add        s16, s4, s9
    v.splat      v5, s18
    vf.mul       v7, v4, v0
    s.add        s4, s16, s2
    v.cmp.lt     p1, v5, v6
    s.add        s16, s13, s4
    p.and        p3, p1, p2
    vf.mul       v0, v7, v3
    v.extract    s4, v1, #4
    s.muli       s17, s1, #4
    v.splat      v4, s4
    s.addi       s4, s7, #4
    vf.cvt.f32.bf16 v5, v0
    v.splat      v0, s4
    s.add        s4, s17, s9
    s.movz       s17, #5
    s.add        s18, s4, s2
    @p3 v.st.h       [s16, #0], v5
    a.vread      v5, a0, s19
    v.cmp.lt     p1, v0, v6
    s.add        s4, s13, s18
    vf.mul       v0, v5, v4
    p.and        p3, p1, p2
    v.extract    s16, v1, #5
    s.muli       s18, s1, #5
    v.splat      v4, s16
    vf.mul       v5, v0, v3
    s.addi       s16, s7, #5
    s.movz       s19, #6
    s.add        s20, s18, s9
    v.splat      v0, s16
    vf.cvt.f32.bf16 v7, v5
    s.add        s16, s20, s2
    v.cmp.lt     p1, v0, v6
    s.add        s18, s13, s16
    p.and        p4, p1, p2
    @p3 v.st.h       [s4, #0], v7
    a.vread      v0, a0, s17
    v.extract    s4, v1, #6
    s.muli       s16, s1, #6
    vf.mul       v5, v0, v4
    v.splat      v0, s4
    s.addi       s4, s7, #6
    s.movz       s17, #7
    s.add        s20, s16, s9
    vf.mul       v4, v5, v3
    v.splat      v5, s4
    s.add        s4, s20, s2
    v.extract    s16, v1, #7
    v.cmp.lt     p1, v5, v6
    vf.cvt.f32.bf16 v5, v4
    s.add        s20, s13, s4
    p.and        p3, p1, p2
    v.splat      v4, s16
    s.muli       s4, s1, #7
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a0, s19
    s.addi       s16, s7, #7
    s.movz       s18, #8
    vf.mul       v7, v5, v0
    s.add        s19, s4, s9
    v.splat      v0, s16
    s.add        s4, s19, s2
    v.extract    s16, v1, #8
    vf.mul       v5, v7, v3
    v.cmp.lt     p1, v0, v6
    s.add        s19, s13, s4
    p.and        p4, p1, p2
    v.splat      v0, s16
    vf.cvt.f32.bf16 v7, v5
    s.muli       s4, s1, #8
    s.addi       s16, s7, #8
    s.movz       s21, #9
    v.splat      v5, s16
    @p3 v.st.h       [s20, #0], v7
    a.vread      v7, a0, s17
    s.add        s16, s4, s9
    v.cmp.lt     p1, v5, v6
    vf.mul       v5, v7, v4
    s.add        s4, s16, s2
    p.and        p3, p1, p2
    s.add        s16, s13, s4
    v.extract    s4, v1, #9
    vf.mul       v4, v5, v3
    v.splat      v5, s4
    s.muli       s4, s1, #9
    s.addi       s17, s7, #9
    s.movz       s20, #10
    vf.cvt.f32.bf16 v7, v4
    v.splat      v4, s17
    s.add        s17, s4, s9
    v.extract    s4, v1, #10
    s.add        s22, s17, s2
    @p4 v.st.h       [s19, #0], v7
    a.vread      v7, a0, s18
    v.cmp.lt     p1, v4, v6
    s.add        s17, s13, s22
    vf.mul       v4, v7, v0
    p.and        p4, p1, p2
    v.splat      v0, s4
    s.muli       s4, s1, #10
    s.addi       s18, s7, #10
    vf.mul       v7, v4, v3
    v.splat      v4, s18
    s.movz       s18, #11
    s.add        s19, s4, s9
    v.extract    s4, v1, #11
    vf.cvt.f32.bf16 v8, v7
    s.add        s22, s19, s2
    v.splat      v7, s4
    s.add        s4, s13, s22
    s.muli       s19, s1, #11
    @p3 v.st.h       [s16, #0], v8
    a.vread      v8, a0, s21
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v8, v5
    s.addi       s16, s7, #11
    s.add        s21, s19, s9
    v.splat      v5, s16
    s.add        s16, s21, s2
    vf.mul       v8, v4, v3
    s.add        s19, s13, s16
    s.movz       s16, #12
    v.extract    s21, v1, #12
    vf.cvt.f32.bf16 v4, v8
    v.splat      v8, s21
    s.muli       s21, s1, #12
    s.addi       s22, s7, #12
    @p4 v.st.h       [s17, #0], v4
    a.vread      v4, a0, s20
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v4, v0
    s.add        s17, s21, s9
    v.splat      v0, s22
    s.add        s20, s17, s2
    s.movz       s17, #13
    vf.mul       v4, v5, v3
    s.add        s21, s13, s20
    v.extract    s20, v1, #13
    v.splat      v5, s20
    vf.cvt.f32.bf16 v9, v4
    s.muli       s20, s1, #13
    s.addi       s22, s7, #13
    v.splat      v4, s22
    @p3 v.st.h       [s4, #0], v9
    a.vread      v9, a0, s18
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s4, s20, s9
    s.movz       s18, #14
    s.add        s20, s4, s2
    v.extract    s4, v1, #14
    vf.mul       v7, v0, v3
    s.add        s22, s13, s20
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #14
    s.addi       s20, s7, #14
    v.splat      v7, s20
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a0, s16
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v8
    s.add        s16, s4, s9
    s.movz       s4, #15
    s.add        s19, s16, s2
    v.extract    s16, v1, #15
    vf.mul       v8, v4, v3
    s.add        s20, s13, s19
    v.splat      v4, s16
    vf.cvt.f32.bf16 v9, v8
    s.muli       s16, s1, #15
    s.addi       s19, s7, #15
    v.splat      v8, s19
    @p3 v.st.h       [s21, #0], v9
    a.vread      v9, a0, s17
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v5
    s.add        s17, s16, s9
    s.movz       s16, #0
    s.add        s19, s17, s2
    v.extract    s2, v1, #0
    vf.mul       v5, v7, v3
    s.add        s17, s13, s19
    v.splat      v7, s2
    vf.cvt.f32.bf16 v9, v5
    s.movz       s2, #0
    s.muli       s19, s5, #2
    s.add        s21, s2, s5                     // the tile origin
    v.splat      v5, s7
    @p4 v.st.h       [s22, #0], v9
    a.vread      v9, a0, s18
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.movz       s2, #0
    v.splat      v0, s21
    s.add        s5, s2, s3                      // the tile origin
    s.add        s2, s9, s19
    vf.mul       v9, v8, v3
    v.add        v8, v2, v0
    v.splat      v0, s5
    v.cmp.lt     p1, v5, v6
    s.add        s5, s13, s2
    vf.cvt.f32.bf16 v5, v9
    s.movz       s2, #1
    v.extract    s18, v1, #1
    s.muli       s21, s1, #1
    v.splat      v9, s18
    @p3 v.st.h       [s20, #0], v5
    a.vread      v5, a0, s4
    v.cmp.lt     p2, v8, v0
    p.and        p3, p1, p2
    vf.mul       v0, v5, v4
    s.addi       s4, s7, #1
    s.add        s18, s21, s9
    v.splat      v4, s4
    s.add        s4, s18, s19
    vf.mul       v5, v0, v3
    s.add        s18, s13, s4
    vf.cvt.f32.bf16 v0, v5
    s.movz       s4, #2
    v.extract    s20, v1, #2
    s.muli       s21, s1, #2
    v.splat      v5, s20
    @p4 v.st.h       [s17, #0], v0
    a.vread      v0, a1, s16
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v7
    s.addi       s16, s7, #2
    s.add        s17, s21, s9
    v.splat      v0, s16
    s.add        s16, s17, s19
    vf.mul       v7, v4, v3
    s.add        s17, s13, s16
    vf.cvt.f32.bf16 v4, v7
    s.movz       s16, #3
    v.extract    s20, v1, #3
    s.muli       s21, s1, #3
    v.splat      v7, s20
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a1, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s2, s7, #3
    s.add        s5, s21, s9
    v.splat      v4, s2
    s.add        s2, s5, s19
    vf.mul       v8, v0, v3
    s.add        s5, s13, s2
    s.movz       s2, #4
    v.extract    s20, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s20
    s.muli       s20, s1, #4
    s.addi       s21, s7, #4
    @p4 v.st.h       [s18, #0], v0
    a.vread      v0, a1, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v5
    s.add        s4, s20, s9
    v.splat      v0, s21
    s.add        s18, s4, s19
    s.movz       s4, #5
    vf.mul       v5, v4, v3
    s.add        s20, s13, s18
    v.extract    s18, v1, #5
    v.splat      v4, s18
    vf.cvt.f32.bf16 v9, v5
    s.muli       s18, s1, #5
    s.addi       s21, s7, #5
    v.splat      v5, s21
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a1, s16
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s16, s18, s9
    s.movz       s17, #6
    s.add        s18, s16, s19
    v.extract    s16, v1, #6
    vf.mul       v7, v0, v3
    s.add        s21, s13, s18
    v.splat      v0, s16
    vf.cvt.f32.bf16 v9, v7
    s.muli       s16, s1, #6
    s.addi       s18, s7, #6
    v.splat      v7, s18
    @p4 v.st.h       [s5, #0], v9
    a.vread      v9, a1, s2
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.add        s2, s16, s9
    s.movz       s5, #7
    s.add        s16, s2, s19
    v.extract    s2, v1, #7
    vf.mul       v8, v5, v3
    s.add        s18, s13, s16
    v.splat      v5, s2
    vf.cvt.f32.bf16 v9, v8
    s.muli       s2, s1, #7
    s.addi       s16, s7, #7
    v.splat      v8, s16
    @p3 v.st.h       [s20, #0], v9
    a.vread      v9, a1, s4
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s4, s2, s9
    s.movz       s2, #8
    s.add        s16, s4, s19
    v.extract    s4, v1, #8
    vf.mul       v4, v7, v3
    s.add        s20, s13, s16
    v.splat      v7, s4
    vf.cvt.f32.bf16 v9, v4
    s.muli       s4, s1, #8
    s.addi       s16, s7, #8
    v.splat      v4, s16
    @p4 v.st.h       [s21, #0], v9
    a.vread      v9, a1, s17
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s16, s4, s9
    s.movz       s4, #9
    s.add        s17, s16, s19
    v.extract    s16, v1, #9
    vf.mul       v0, v8, v3
    s.add        s21, s13, s17
    v.splat      v8, s16
    vf.cvt.f32.bf16 v9, v0
    s.muli       s16, s1, #9
    s.addi       s17, s7, #9
    v.splat      v0, s17
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a1, s5
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s5, s16, s9
    s.movz       s16, #10
    s.add        s17, s5, s19
    v.extract    s5, v1, #10
    vf.mul       v5, v4, v3
    s.add        s18, s13, s17
    v.splat      v4, s5
    vf.cvt.f32.bf16 v9, v5
    s.muli       s5, s1, #10
    s.addi       s17, s7, #10
    v.splat      v5, s17
    @p4 v.st.h       [s20, #0], v9
    a.vread      v9, a1, s2
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v7
    s.add        s2, s5, s9
    s.movz       s5, #11
    s.add        s17, s2, s19
    v.extract    s2, v1, #11
    vf.mul       v7, v0, v3
    s.add        s20, s13, s17
    v.splat      v0, s2
    vf.cvt.f32.bf16 v9, v7
    s.muli       s2, s1, #11
    s.addi       s17, s7, #11
    v.splat      v7, s17
    @p3 v.st.h       [s21, #0], v9
    a.vread      v9, a1, s4
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v8
    s.add        s4, s2, s9
    s.movz       s2, #12
    s.add        s17, s4, s19
    v.extract    s4, v1, #12
    vf.mul       v8, v5, v3
    s.add        s21, s13, s17
    v.splat      v5, s4
    vf.cvt.f32.bf16 v9, v8
    s.muli       s4, s1, #12
    s.addi       s17, s7, #12
    v.splat      v8, s17
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a1, s16
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s16, s4, s9
    s.movz       s4, #13
    s.add        s17, s16, s19
    v.extract    s16, v1, #13
    vf.mul       v4, v7, v3
    s.add        s18, s13, s17
    v.splat      v7, s16
    vf.cvt.f32.bf16 v9, v4
    s.muli       s16, s1, #13
    s.addi       s17, s7, #13
    v.splat      v4, s17
    @p3 v.st.h       [s20, #0], v9
    a.vread      v9, a1, s5
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s5, s16, s9
    s.movz       s16, #14
    s.add        s17, s5, s19
    v.extract    s5, v1, #14
    vf.mul       v0, v8, v3
    s.add        s20, s13, s17
    v.splat      v8, s5
    vf.cvt.f32.bf16 v9, v0
    s.muli       s5, s1, #14
    s.addi       s17, s7, #14
    v.splat      v0, s17
    @p4 v.st.h       [s21, #0], v9
    a.vread      v9, a1, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s2, s5, s9
    s.movz       s5, #15
    s.add        s17, s2, s19
    v.extract    s2, v1, #15
    vf.mul       v5, v4, v3
    s.add        s21, s13, s17
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #15
    s.addi       s17, s7, #15
    v.splat      v5, s17
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a1, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s4, s2, s9
    s.movz       s2, #0
    s.add        s17, s4, s19
    v.extract    s4, v1, #0
    vf.mul       v7, v0, v3
    s.add        s18, s13, s17
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v7
    s.movz       s4, #0
    s.muli       s17, s6, #2
    s.add        s19, s4, s6                     // the tile origin
    v.splat      v7, s7
    @p4 v.st.h       [s20, #0], v9
    a.vread      v9, a1, s16
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.movz       s4, #0
    v.splat      v8, s19
    s.add        s6, s4, s3                      // the tile origin
    s.add        s4, s9, s17
    vf.mul       v9, v5, v3
    v.add        v5, v2, v8
    v.splat      v8, s6
    v.cmp.lt     p1, v7, v6
    s.add        s6, s13, s4
    vf.cvt.f32.bf16 v7, v9
    s.movz       s4, #1
    v.extract    s16, v1, #1
    s.muli       s19, s1, #1
    v.splat      v9, s16
    @p3 v.st.h       [s21, #0], v7
    a.vread      v7, a1, s5
    v.cmp.lt     p2, v5, v8
    p.and        p3, p1, p2
    vf.mul       v5, v7, v4
    s.addi       s5, s7, #1
    s.add        s16, s19, s9
    v.splat      v4, s5
    s.add        s5, s16, s17
    vf.mul       v7, v5, v3
    s.add        s16, s13, s5
    vf.cvt.f32.bf16 v5, v7
    s.movz       s5, #2
    v.extract    s19, v1, #2
    s.muli       s20, s1, #2
    v.splat      v7, s19
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a2, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v5, v0
    s.addi       s2, s7, #2
    s.add        s18, s20, s9
    v.splat      v0, s2
    s.add        s2, s18, s17
    vf.mul       v5, v4, v3
    s.add        s18, s13, s2
    vf.cvt.f32.bf16 v4, v5
    s.movz       s2, #3
    v.extract    s19, v1, #3
    s.muli       s20, s1, #3
    v.splat      v5, s19
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a2, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s4, s7, #3
    s.add        s6, s20, s9
    v.splat      v4, s4
    s.add        s4, s6, s17
    vf.mul       v8, v0, v3
    s.add        s6, s13, s4
    s.movz       s4, #4
    v.extract    s19, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s19
    s.muli       s19, s1, #4
    s.addi       s20, s7, #4
    @p4 v.st.h       [s16, #0], v0
    a.vread      v0, a2, s5
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v7
    s.add        s5, s19, s9
    v.splat      v0, s20
    s.add        s16, s5, s17
    s.movz       s5, #5
    vf.mul       v7, v4, v3
    s.add        s19, s13, s16
    v.extract    s16, v1, #5
    v.splat      v4, s16
    vf.cvt.f32.bf16 v9, v7
    s.muli       s16, s1, #5
    s.addi       s20, s7, #5
    v.splat      v7, s20
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a2, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s2, s16, s9
    s.movz       s16, #6
    s.add        s18, s2, s17
    v.extract    s2, v1, #6
    vf.mul       v5, v0, v3
    s.add        s20, s13, s18
    v.splat      v0, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #6
    s.addi       s18, s7, #6
    v.splat      v5, s18
    @p4 v.st.h       [s6, #0], v9
    a.vread      v9, a2, s4
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.add        s4, s2, s9
    s.movz       s2, #7
    s.add        s6, s4, s17
    v.extract    s4, v1, #7
    vf.mul       v8, v7, v3
    s.add        s18, s13, s6
    v.splat      v7, s4
    vf.cvt.f32.bf16 v9, v8
    s.muli       s4, s1, #7
    s.addi       s6, s7, #7
    v.splat      v8, s6
    @p3 v.st.h       [s19, #0], v9
    a.vread      v9, a2, s5
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v4
    s.add        s5, s4, s9
    s.movz       s4, #8
    s.add        s6, s5, s17
    v.extract    s5, v1, #8
    vf.mul       v4, v5, v3
    s.add        s19, s13, s6
    v.splat      v5, s5
    vf.cvt.f32.bf16 v9, v4
    s.muli       s5, s1, #8
    s.addi       s6, s7, #8
    v.splat      v4, s6
    @p4 v.st.h       [s20, #0], v9
    a.vread      v9, a2, s16
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s6, s5, s9
    s.movz       s5, #9
    s.add        s16, s6, s17
    v.extract    s6, v1, #9
    vf.mul       v0, v8, v3
    s.add        s20, s13, s16
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v0
    s.muli       s6, s1, #9
    s.addi       s16, s7, #9
    v.splat      v0, s16
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a2, s2
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.add        s2, s6, s9
    s.movz       s6, #10
    s.add        s16, s2, s17
    v.extract    s2, v1, #10
    vf.mul       v7, v4, v3
    s.add        s18, s13, s16
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v7
    s.muli       s2, s1, #10
    s.addi       s16, s7, #10
    v.splat      v7, s16
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a2, s4
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v5
    s.add        s4, s2, s9
    s.movz       s2, #11
    s.add        s16, s4, s17
    v.extract    s4, v1, #11
    vf.mul       v5, v0, v3
    s.add        s19, s13, s16
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #11
    s.addi       s16, s7, #11
    v.splat      v5, s16
    @p3 v.st.h       [s20, #0], v9
    a.vread      v9, a2, s5
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v8
    s.add        s5, s4, s9
    s.movz       s4, #12
    s.add        s16, s5, s17
    v.extract    s5, v1, #12
    vf.mul       v8, v7, v3
    s.add        s20, s13, s16
    v.splat      v7, s5
    vf.cvt.f32.bf16 v9, v8
    s.muli       s5, s1, #12
    s.addi       s16, s7, #12
    v.splat      v8, s16
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a2, s6
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v4
    s.add        s6, s5, s9
    s.movz       s5, #13
    s.add        s16, s6, s17
    v.extract    s6, v1, #13
    vf.mul       v4, v5, v3
    s.add        s18, s13, s16
    v.splat      v5, s6
    vf.cvt.f32.bf16 v9, v4
    s.muli       s6, s1, #13
    s.addi       s16, s7, #13
    v.splat      v4, s16
    @p3 v.st.h       [s19, #0], v9
    a.vread      v9, a2, s2
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s2, s6, s9
    s.movz       s6, #14
    s.add        s16, s2, s17
    v.extract    s2, v1, #14
    vf.mul       v0, v8, v3
    s.add        s19, s13, s16
    v.splat      v8, s2
    vf.cvt.f32.bf16 v9, v0
    s.muli       s2, s1, #14
    s.addi       s16, s7, #14
    v.splat      v0, s16
    @p4 v.st.h       [s20, #0], v9
    a.vread      v9, a2, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v7
    s.add        s4, s2, s9
    s.movz       s2, #15
    s.add        s16, s4, s17
    v.extract    s4, v1, #15
    vf.mul       v7, v4, v3
    s.add        s20, s13, s16
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #15
    s.addi       s16, s7, #15
    v.splat      v7, s16
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a2, s5
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s5, s4, s9
    s.movz       s4, #0
    s.add        s16, s5, s17
    v.extract    s5, v1, #0
    vf.mul       v5, v0, v3
    s.add        s17, s13, s16
    v.splat      v0, s5
    vf.cvt.f32.bf16 v9, v5
    s.movz       s5, #0
    s.muli       s16, s11, #2
    s.add        s18, s5, s11                    // the tile origin
    v.splat      v5, s7
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a2, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.movz       s5, #0
    v.splat      v8, s18
    s.add        s6, s5, s3                      // the tile origin
    s.add        s5, s9, s16
    vf.mul       v9, v7, v3
    v.add        v7, v2, v8
    v.splat      v8, s6
    v.cmp.lt     p1, v5, v6
    s.add        s6, s13, s5
    vf.cvt.f32.bf16 v5, v9
    s.movz       s5, #1
    v.extract    s11, v1, #1
    s.muli       s18, s1, #1
    v.splat      v9, s11
    @p3 v.st.h       [s20, #0], v5
    a.vread      v5, a2, s2
    v.cmp.lt     p2, v7, v8
    p.and        p3, p1, p2
    vf.mul       v7, v5, v4
    s.addi       s2, s7, #1
    s.add        s11, s18, s9
    v.splat      v4, s2
    s.add        s2, s11, s16
    vf.mul       v5, v7, v3
    s.add        s11, s13, s2
    vf.cvt.f32.bf16 v7, v5
    s.movz       s2, #2
    v.extract    s18, v1, #2
    s.muli       s19, s1, #2
    v.splat      v5, s18
    @p4 v.st.h       [s17, #0], v7
    a.vread      v7, a3, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v7, v0
    s.addi       s4, s7, #2
    s.add        s17, s19, s9
    v.splat      v0, s4
    s.add        s4, s17, s16
    vf.mul       v7, v4, v3
    s.add        s17, s13, s4
    vf.cvt.f32.bf16 v4, v7
    s.movz       s4, #3
    v.extract    s18, v1, #3
    s.muli       s19, s1, #3
    v.splat      v7, s18
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a3, s5
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s5, s7, #3
    s.add        s6, s19, s9
    v.splat      v4, s5
    s.add        s5, s6, s16
    vf.mul       v8, v0, v3
    s.add        s6, s13, s5
    s.movz       s5, #4
    v.extract    s18, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s18
    s.muli       s18, s1, #4
    s.addi       s19, s7, #4
    @p4 v.st.h       [s11, #0], v0
    a.vread      v0, a3, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v5
    s.add        s2, s18, s9
    v.splat      v0, s19
    s.add        s11, s2, s16
    s.movz       s2, #5
    vf.mul       v5, v4, v3
    s.add        s18, s13, s11
    v.extract    s11, v1, #5
    v.splat      v4, s11
    vf.cvt.f32.bf16 v9, v5
    s.muli       s11, s1, #5
    s.addi       s19, s7, #5
    v.splat      v5, s19
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s4, s11, s9
    s.movz       s11, #6
    s.add        s17, s4, s16
    v.extract    s4, v1, #6
    vf.mul       v7, v0, v3
    s.add        s19, s13, s17
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #6
    s.addi       s17, s7, #6
    v.splat      v7, s17
    @p4 v.st.h       [s6, #0], v9
    a.vread      v9, a3, s5
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.add        s5, s4, s9
    s.movz       s4, #7
    s.add        s6, s5, s16
    v.extract    s5, v1, #7
    vf.mul       v8, v5, v3
    s.add        s17, s13, s6
    v.splat      v5, s5
    vf.cvt.f32.bf16 v9, v8
    s.muli       s5, s1, #7
    s.addi       s6, s7, #7
    v.splat      v8, s6
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a3, s2
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s2, s5, s9
    s.movz       s5, #8
    s.add        s6, s2, s16
    v.extract    s2, v1, #8
    vf.mul       v4, v7, v3
    s.add        s18, s13, s6
    v.splat      v7, s2
    vf.cvt.f32.bf16 v9, v4
    s.muli       s2, s1, #8
    s.addi       s6, s7, #8
    v.splat      v4, s6
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a3, s11
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s6, s2, s9
    s.movz       s2, #9
    s.add        s11, s6, s16
    v.extract    s6, v1, #9
    vf.mul       v0, v8, v3
    s.add        s19, s13, s11
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v0
    s.muli       s6, s1, #9
    s.addi       s11, s7, #9
    v.splat      v0, s11
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s4
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s4, s6, s9
    s.movz       s6, #10
    s.add        s11, s4, s16
    v.extract    s4, v1, #10
    vf.mul       v5, v4, v3
    s.add        s17, s13, s11
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #10
    s.addi       s11, s7, #10
    v.splat      v5, s11
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a3, s5
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v7
    s.add        s5, s4, s9
    s.movz       s4, #11
    s.add        s11, s5, s16
    v.extract    s5, v1, #11
    vf.mul       v7, v0, v3
    s.add        s18, s13, s11
    v.splat      v0, s5
    vf.cvt.f32.bf16 v9, v7
    s.muli       s5, s1, #11
    s.addi       s11, s7, #11
    v.splat      v7, s11
    @p3 v.st.h       [s19, #0], v9
    a.vread      v9, a3, s2
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v8
    s.add        s2, s5, s9
    s.movz       s5, #12
    s.add        s11, s2, s16
    v.extract    s2, v1, #12
    vf.mul       v8, v5, v3
    s.add        s19, s13, s11
    v.splat      v5, s2
    vf.cvt.f32.bf16 v9, v8
    s.muli       s2, s1, #12
    s.addi       s11, s7, #12
    v.splat      v8, s11
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s6, s2, s9
    s.movz       s2, #13
    s.add        s11, s6, s16
    v.extract    s6, v1, #13
    vf.mul       v4, v7, v3
    s.add        s17, s13, s11
    v.splat      v7, s6
    vf.cvt.f32.bf16 v9, v4
    s.muli       s6, s1, #13
    s.addi       s11, s7, #13
    v.splat      v4, s11
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a3, s4
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s4, s6, s9
    s.movz       s6, #14
    s.add        s11, s4, s16
    v.extract    s4, v1, #14
    vf.mul       v0, v8, v3
    s.add        s18, s13, s11
    v.splat      v8, s4
    vf.cvt.f32.bf16 v9, v0
    s.muli       s4, s1, #14
    s.addi       s11, s7, #14
    v.splat      v0, s11
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a3, s5
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s5, s4, s9
    s.movz       s4, #15
    s.add        s11, s5, s16
    v.extract    s5, v1, #15
    vf.mul       v5, v4, v3
    s.add        s19, s13, s11
    v.splat      v4, s5
    vf.cvt.f32.bf16 v9, v5
    s.muli       s5, s1, #15
    s.addi       s11, s7, #15
    v.splat      v5, s11
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s2, s5, s9
    s.movz       s5, #0
    s.add        s11, s2, s16
    v.extract    s2, v1, #0
    vf.mul       v7, v0, v3
    s.add        s16, s13, s11
    v.splat      v0, s2
    vf.cvt.f32.bf16 v9, v7
    s.movz       s2, #0
    s.muli       s11, s8, #2
    s.add        s17, s2, s8                     // the tile origin
    v.splat      v7, s7
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a3, s6
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.movz       s2, #0
    v.splat      v8, s17
    s.add        s6, s2, s3                      // the tile origin
    s.add        s2, s9, s11
    vf.mul       v9, v5, v3
    v.add        v5, v2, v8
    v.splat      v8, s6
    v.cmp.lt     p1, v7, v6
    s.add        s6, s13, s2
    vf.cvt.f32.bf16 v7, v9
    s.movz       s2, #1
    v.extract    s8, v1, #1
    s.muli       s17, s1, #1
    v.splat      v9, s8
    @p3 v.st.h       [s19, #0], v7
    a.vread      v7, a3, s4
    v.cmp.lt     p2, v5, v8
    p.and        p3, p1, p2
    vf.mul       v5, v7, v4
    s.addi       s4, s7, #1
    s.add        s8, s17, s9
    v.splat      v4, s4
    s.add        s4, s8, s11
    vf.mul       v7, v5, v3
    s.add        s8, s13, s4
    vf.cvt.f32.bf16 v5, v7
    s.movz       s4, #2
    v.extract    s17, v1, #2
    s.muli       s18, s1, #2
    v.splat      v7, s17
    @p4 v.st.h       [s16, #0], v5
    a.vread      v5, a4, s5
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v5, v0
    s.addi       s5, s7, #2
    s.add        s16, s18, s9
    v.splat      v0, s5
    s.add        s5, s16, s11
    vf.mul       v5, v4, v3
    s.add        s16, s13, s5
    vf.cvt.f32.bf16 v4, v5
    s.movz       s5, #3
    v.extract    s17, v1, #3
    s.muli       s18, s1, #3
    v.splat      v5, s17
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a4, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s2, s7, #3
    s.add        s6, s18, s9
    v.splat      v4, s2
    s.add        s2, s6, s11
    vf.mul       v8, v0, v3
    s.add        s6, s13, s2
    s.movz       s2, #4
    v.extract    s17, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s17
    s.muli       s17, s1, #4
    s.addi       s18, s7, #4
    @p4 v.st.h       [s8, #0], v0
    a.vread      v0, a4, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v7
    s.add        s4, s17, s9
    v.splat      v0, s18
    s.add        s8, s4, s11
    s.movz       s4, #5
    vf.mul       v7, v4, v3
    s.add        s17, s13, s8
    v.extract    s8, v1, #5
    v.splat      v4, s8
    vf.cvt.f32.bf16 v9, v7
    s.muli       s8, s1, #5
    s.addi       s18, s7, #5
    v.splat      v7, s18
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a4, s5
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s5, s8, s9
    s.movz       s8, #6
    s.add        s16, s5, s11
    v.extract    s5, v1, #6
    vf.mul       v5, v0, v3
    s.add        s18, s13, s16
    v.splat      v0, s5
    vf.cvt.f32.bf16 v9, v5
    s.muli       s5, s1, #6
    s.addi       s16, s7, #6
    v.splat      v5, s16
    @p4 v.st.h       [s6, #0], v9
    a.vread      v9, a4, s2
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.add        s2, s5, s9
    s.movz       s5, #7
    s.add        s6, s2, s11
    v.extract    s2, v1, #7
    vf.mul       v8, v7, v3
    s.add        s16, s13, s6
    v.splat      v7, s2
    vf.cvt.f32.bf16 v9, v8
    s.muli       s2, s1, #7
    s.addi       s6, s7, #7
    v.splat      v8, s6
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s4
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v4
    s.add        s4, s2, s9
    s.movz       s2, #8
    s.add        s6, s4, s11
    v.extract    s4, v1, #8
    vf.mul       v4, v5, v3
    s.add        s17, s13, s6
    v.splat      v5, s4
    vf.cvt.f32.bf16 v9, v4
    s.muli       s4, s1, #8
    s.addi       s6, s7, #8
    v.splat      v4, s6
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a4, s8
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s6, s4, s9
    s.movz       s4, #9
    s.add        s8, s6, s11
    v.extract    s6, v1, #9
    vf.mul       v0, v8, v3
    s.add        s18, s13, s8
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v0
    s.muli       s6, s1, #9
    s.addi       s8, s7, #9
    v.splat      v0, s8
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a4, s5
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.add        s5, s6, s9
    s.movz       s6, #10
    s.add        s8, s5, s11
    v.extract    s5, v1, #10
    vf.mul       v7, v4, v3
    s.add        s16, s13, s8
    v.splat      v4, s5
    vf.cvt.f32.bf16 v9, v7
    s.muli       s5, s1, #10
    s.addi       s8, s7, #10
    v.splat      v7, s8
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s2
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v5
    s.add        s2, s5, s9
    s.movz       s5, #11
    s.add        s8, s2, s11
    v.extract    s2, v1, #11
    vf.mul       v5, v0, v3
    s.add        s17, s13, s8
    v.splat      v0, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #11
    s.addi       s8, s7, #11
    v.splat      v5, s8
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a4, s4
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v8
    s.add        s4, s2, s9
    s.movz       s2, #12
    s.add        s8, s4, s11
    v.extract    s4, v1, #12
    vf.mul       v8, v7, v3
    s.add        s18, s13, s8
    v.splat      v7, s4
    vf.cvt.f32.bf16 v9, v8
    s.muli       s4, s1, #12
    s.addi       s8, s7, #12
    v.splat      v8, s8
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a4, s6
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v4
    s.add        s6, s4, s9
    s.movz       s4, #13
    s.add        s8, s6, s11
    v.extract    s6, v1, #13
    vf.mul       v4, v5, v3
    s.add        s16, s13, s8
    v.splat      v5, s6
    vf.cvt.f32.bf16 v9, v4
    s.muli       s6, s1, #13
    s.addi       s8, s7, #13
    v.splat      v4, s8
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s5
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s5, s6, s9
    s.movz       s6, #14
    s.add        s8, s5, s11
    v.extract    s5, v1, #14
    vf.mul       v0, v8, v3
    s.add        s17, s13, s8
    v.splat      v8, s5
    vf.cvt.f32.bf16 v9, v0
    s.muli       s5, s1, #14
    s.addi       s8, s7, #14
    v.splat      v0, s8
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a4, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v7
    s.add        s2, s5, s9
    s.movz       s5, #15
    s.add        s8, s2, s11
    v.extract    s2, v1, #15
    vf.mul       v7, v4, v3
    s.add        s18, s13, s8
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v7
    s.muli       s2, s1, #15
    s.addi       s8, s7, #15
    v.splat      v7, s8
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a4, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s4, s2, s9
    s.movz       s2, #0
    s.add        s8, s4, s11
    v.extract    s4, v1, #0
    vf.mul       v5, v0, v3
    s.add        s11, s13, s8
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v5
    s.movz       s4, #0
    s.muli       s8, s12, #2
    s.add        s16, s4, s12                    // the tile origin
    v.splat      v5, s7
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.movz       s4, #0
    v.splat      v8, s16
    s.add        s6, s4, s3                      // the tile origin
    s.add        s4, s9, s8
    vf.mul       v9, v7, v3
    v.add        v7, v2, v8
    v.splat      v8, s6
    v.cmp.lt     p1, v5, v6
    s.add        s6, s13, s4
    vf.cvt.f32.bf16 v5, v9
    s.movz       s4, #1
    v.extract    s12, v1, #1
    s.muli       s16, s1, #1
    v.splat      v9, s12
    @p3 v.st.h       [s18, #0], v5
    a.vread      v5, a4, s5
    v.cmp.lt     p2, v7, v8
    p.and        p3, p1, p2
    vf.mul       v7, v5, v4
    s.addi       s5, s7, #1
    s.add        s12, s16, s9
    v.splat      v4, s5
    s.add        s5, s12, s8
    vf.mul       v5, v7, v3
    s.add        s12, s13, s5
    vf.cvt.f32.bf16 v7, v5
    s.movz       s5, #2
    v.extract    s16, v1, #2
    s.muli       s17, s1, #2
    v.splat      v5, s16
    @p4 v.st.h       [s11, #0], v7
    a.vread      v7, a5, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v7, v0
    s.addi       s2, s7, #2
    s.add        s11, s17, s9
    v.splat      v0, s2
    s.add        s2, s11, s8
    vf.mul       v7, v4, v3
    s.add        s11, s13, s2
    vf.cvt.f32.bf16 v4, v7
    s.movz       s2, #3
    v.extract    s16, v1, #3
    s.muli       s17, s1, #3
    v.splat      v7, s16
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a5, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s4, s7, #3
    s.add        s6, s17, s9
    v.splat      v4, s4
    s.add        s4, s6, s8
    vf.mul       v8, v0, v3
    s.add        s6, s13, s4
    s.movz       s4, #4
    v.extract    s16, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s16
    s.muli       s16, s1, #4
    s.addi       s17, s7, #4
    @p4 v.st.h       [s12, #0], v0
    a.vread      v0, a5, s5
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v5
    s.add        s5, s16, s9
    v.splat      v0, s17
    s.add        s12, s5, s8
    s.movz       s5, #5
    vf.mul       v5, v4, v3
    s.add        s16, s13, s12
    v.extract    s12, v1, #5
    v.splat      v4, s12
    vf.cvt.f32.bf16 v9, v5
    s.muli       s12, s1, #5
    s.addi       s17, s7, #5
    v.splat      v5, s17
    @p3 v.st.h       [s11, #0], v9
    a.vread      v9, a5, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s2, s12, s9
    s.movz       s11, #6
    s.add        s12, s2, s8
    v.extract    s2, v1, #6
    vf.mul       v7, v0, v3
    s.add        s17, s13, s12
    v.splat      v0, s2
    vf.cvt.f32.bf16 v9, v7
    s.muli       s2, s1, #6
    s.addi       s12, s7, #6
    v.splat      v7, s12
    @p4 v.st.h       [s6, #0], v9
    a.vread      v9, a5, s4
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.add        s4, s2, s9
    s.movz       s2, #7
    s.add        s6, s4, s8
    v.extract    s4, v1, #7
    vf.mul       v8, v5, v3
    s.add        s12, s13, s6
    v.splat      v5, s4
    vf.cvt.f32.bf16 v9, v8
    s.muli       s4, s1, #7
    s.addi       s6, s7, #7
    v.splat      v8, s6
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a5, s5
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s5, s4, s9
    s.movz       s4, #8
    s.add        s6, s5, s8
    v.extract    s5, v1, #8
    vf.mul       v4, v7, v3
    s.add        s16, s13, s6
    v.splat      v7, s5
    vf.cvt.f32.bf16 v9, v4
    s.muli       s5, s1, #8
    s.addi       s6, s7, #8
    v.splat      v4, s6
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a5, s11
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s6, s5, s9
    s.movz       s5, #9
    s.add        s11, s6, s8
    v.extract    s6, v1, #9
    vf.mul       v0, v8, v3
    s.add        s17, s13, s11
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v0
    s.muli       s6, s1, #9
    s.addi       s11, s7, #9
    v.splat      v0, s11
    @p3 v.st.h       [s12, #0], v9
    a.vread      v9, a5, s2
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s2, s6, s9
    s.movz       s6, #10
    s.add        s11, s2, s8
    v.extract    s2, v1, #10
    vf.mul       v5, v4, v3
    s.add        s12, s13, s11
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #10
    s.addi       s11, s7, #10
    v.splat      v5, s11
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a5, s4
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v7
    s.add        s4, s2, s9
    s.movz       s2, #11
    s.add        s11, s4, s8
    v.extract    s4, v1, #11
    vf.mul       v7, v0, v3
    s.add        s16, s13, s11
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #11
    s.addi       s11, s7, #11
    v.splat      v7, s11
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a5, s5
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v8
    s.add        s5, s4, s9
    s.movz       s4, #12
    s.add        s11, s5, s8
    v.extract    s5, v1, #12
    vf.mul       v8, v5, v3
    s.add        s17, s13, s11
    v.splat      v5, s5
    vf.cvt.f32.bf16 v9, v8
    s.muli       s5, s1, #12
    s.addi       s11, s7, #12
    v.splat      v8, s11
    @p4 v.st.h       [s12, #0], v9
    a.vread      v9, a5, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s6, s5, s9
    s.movz       s5, #13
    s.add        s11, s6, s8
    v.extract    s6, v1, #13
    vf.mul       v4, v7, v3
    s.add        s12, s13, s11
    v.splat      v7, s6
    vf.cvt.f32.bf16 v9, v4
    s.muli       s6, s1, #13
    s.addi       s11, s7, #13
    v.splat      v4, s11
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a5, s2
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s2, s6, s9
    s.movz       s6, #14
    s.add        s11, s2, s8
    v.extract    s2, v1, #14
    vf.mul       v0, v8, v3
    s.add        s16, s13, s11
    v.splat      v8, s2
    vf.cvt.f32.bf16 v9, v0
    s.muli       s2, s1, #14
    s.addi       s11, s7, #14
    v.splat      v0, s11
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a5, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s4, s2, s9
    s.movz       s2, #15
    s.add        s11, s4, s8
    v.extract    s4, v1, #15
    vf.mul       v5, v4, v3
    s.add        s17, s13, s11
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #15
    s.addi       s11, s7, #15
    v.splat      v5, s11
    @p3 v.st.h       [s12, #0], v9
    a.vread      v9, a5, s5
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s5, s4, s9
    s.movz       s4, #0
    s.add        s11, s5, s8
    v.extract    s5, v1, #0
    vf.mul       v7, v0, v3
    s.add        s8, s13, s11
    v.splat      v0, s5
    vf.cvt.f32.bf16 v9, v7
    s.movz       s5, #0
    s.muli       s11, s10, #2
    s.add        s12, s5, s10                    // the tile origin
    v.splat      v7, s7
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a5, s6
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.movz       s5, #0
    v.splat      v8, s12
    s.add        s6, s5, s3                      // the tile origin
    s.add        s5, s9, s11
    vf.mul       v9, v5, v3
    v.add        v5, v2, v8
    v.splat      v8, s6
    v.cmp.lt     p1, v7, v6
    s.add        s6, s13, s5
    vf.cvt.f32.bf16 v7, v9
    s.movz       s5, #1
    v.extract    s10, v1, #1
    s.muli       s12, s1, #1
    v.splat      v9, s10
    @p3 v.st.h       [s17, #0], v7
    a.vread      v7, a5, s2
    v.cmp.lt     p2, v5, v8
    p.and        p3, p1, p2
    vf.mul       v5, v7, v4
    s.addi       s2, s7, #1
    s.add        s10, s12, s9
    v.splat      v4, s2
    s.add        s2, s10, s11
    vf.mul       v7, v5, v3
    s.add        s10, s13, s2
    vf.cvt.f32.bf16 v5, v7
    s.movz       s2, #2
    v.extract    s12, v1, #2
    s.muli       s16, s1, #2
    v.splat      v7, s12
    @p4 v.st.h       [s8, #0], v5
    a.vread      v5, a6, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v5, v0
    s.addi       s4, s7, #2
    s.add        s8, s16, s9
    v.splat      v0, s4
    s.add        s4, s8, s11
    vf.mul       v5, v4, v3
    s.add        s8, s13, s4
    vf.cvt.f32.bf16 v4, v5
    s.movz       s4, #3
    v.extract    s12, v1, #3
    s.muli       s16, s1, #3
    v.splat      v5, s12
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a6, s5
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s5, s7, #3
    s.add        s6, s16, s9
    v.splat      v4, s5
    s.add        s5, s6, s11
    vf.mul       v8, v0, v3
    s.add        s6, s13, s5
    s.movz       s5, #4
    v.extract    s12, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s12
    s.muli       s12, s1, #4
    s.addi       s16, s7, #4
    @p4 v.st.h       [s10, #0], v0
    a.vread      v0, a6, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v7
    s.add        s2, s12, s9
    v.splat      v0, s16
    s.add        s10, s2, s11
    s.movz       s2, #5
    vf.mul       v7, v4, v3
    s.add        s12, s13, s10
    v.extract    s10, v1, #5
    v.splat      v4, s10
    vf.cvt.f32.bf16 v9, v7
    s.muli       s10, s1, #5
    s.addi       s16, s7, #5
    v.splat      v7, s16
    @p3 v.st.h       [s8, #0], v9
    a.vread      v9, a6, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s4, s10, s9
    s.movz       s8, #6
    s.add        s10, s4, s11
    v.extract    s4, v1, #6
    vf.mul       v5, v0, v3
    s.add        s16, s13, s10
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #6
    s.addi       s10, s7, #6
    v.splat      v5, s10
    @p4 v.st.h       [s6, #0], v9
    a.vread      v9, a6, s5
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.add        s5, s4, s9
    s.movz       s4, #7
    s.add        s6, s5, s11
    v.extract    s5, v1, #7
    vf.mul       v8, v7, v3
    s.add        s10, s13, s6
    v.splat      v7, s5
    vf.cvt.f32.bf16 v9, v8
    s.muli       s5, s1, #7
    s.addi       s6, s7, #7
    v.splat      v8, s6
    @p3 v.st.h       [s12, #0], v9
    a.vread      v9, a6, s2
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v4
    s.add        s2, s5, s9
    s.movz       s5, #8
    s.add        s6, s2, s11
    v.extract    s2, v1, #8
    vf.mul       v4, v5, v3
    s.add        s12, s13, s6
    v.splat      v5, s2
    vf.cvt.f32.bf16 v9, v4
    s.muli       s2, s1, #8
    s.addi       s6, s7, #8
    v.splat      v4, s6
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a6, s8
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s6, s2, s9
    s.movz       s2, #9
    s.add        s8, s6, s11
    v.extract    s6, v1, #9
    vf.mul       v0, v8, v3
    s.add        s16, s13, s8
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v0
    s.muli       s6, s1, #9
    s.addi       s8, s7, #9
    v.splat      v0, s8
    @p3 v.st.h       [s10, #0], v9
    a.vread      v9, a6, s4
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.add        s4, s6, s9
    s.movz       s6, #10
    s.add        s8, s4, s11
    v.extract    s4, v1, #10
    vf.mul       v7, v4, v3
    s.add        s10, s13, s8
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #10
    s.addi       s8, s7, #10
    v.splat      v7, s8
    @p4 v.st.h       [s12, #0], v9
    a.vread      v9, a6, s5
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v5
    s.add        s5, s4, s9
    s.movz       s4, #11
    s.add        s8, s5, s11
    v.extract    s5, v1, #11
    vf.mul       v5, v0, v3
    s.add        s12, s13, s8
    v.splat      v0, s5
    vf.cvt.f32.bf16 v9, v5
    s.muli       s5, s1, #11
    s.addi       s8, s7, #11
    v.splat      v5, s8
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a6, s2
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v8
    s.add        s2, s5, s9
    s.movz       s5, #12
    s.add        s8, s2, s11
    v.extract    s2, v1, #12
    vf.mul       v8, v7, v3
    s.add        s16, s13, s8
    v.splat      v7, s2
    vf.cvt.f32.bf16 v9, v8
    s.muli       s2, s1, #12
    s.addi       s8, s7, #12
    v.splat      v8, s8
    @p4 v.st.h       [s10, #0], v9
    a.vread      v9, a6, s6
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v4
    s.add        s6, s2, s9
    s.movz       s2, #13
    s.add        s8, s6, s11
    v.extract    s6, v1, #13
    vf.mul       v4, v5, v3
    s.add        s10, s13, s8
    v.splat      v5, s6
    vf.cvt.f32.bf16 v9, v4
    s.muli       s6, s1, #13
    s.addi       s8, s7, #13
    v.splat      v4, s8
    @p3 v.st.h       [s12, #0], v9
    a.vread      v9, a6, s4
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s4, s6, s9
    s.movz       s6, #14
    s.add        s8, s4, s11
    v.extract    s4, v1, #14
    vf.mul       v0, v8, v3
    s.add        s12, s13, s8
    v.splat      v8, s4
    vf.cvt.f32.bf16 v9, v0
    s.muli       s4, s1, #14
    s.addi       s8, s7, #14
    v.splat      v0, s8
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a6, s5
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v7
    s.add        s5, s4, s9
    s.movz       s4, #15
    s.add        s8, s5, s11
    v.extract    s5, v1, #15
    vf.mul       v7, v4, v3
    s.add        s16, s13, s8
    v.splat      v4, s5
    vf.cvt.f32.bf16 v9, v7
    s.muli       s5, s1, #15
    s.addi       s8, s7, #15
    v.splat      v7, s8
    @p3 v.st.h       [s10, #0], v9
    a.vread      v9, a6, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s2, s5, s9
    s.movz       s5, #0
    s.add        s8, s2, s11
    v.extract    s2, v1, #0
    vf.mul       v5, v0, v3
    s.add        s10, s13, s8
    v.splat      v0, s2
    vf.cvt.f32.bf16 v9, v5
    s.movz       s2, #0
    s.muli       s8, s14, #2
    s.add        s11, s2, s14                    // the tile origin
    v.splat      v5, s7
    @p4 v.st.h       [s12, #0], v9
    a.vread      v9, a6, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.movz       s2, #0
    v.splat      v8, s11
    s.add        s6, s2, s3                      // the tile origin
    s.add        s2, s9, s8
    vf.mul       v9, v7, v3
    v.add        v7, v2, v8
    v.splat      v2, s6
    v.cmp.lt     p1, v5, v6
    s.add        s3, s13, s2
    vf.cvt.f32.bf16 v5, v9
    s.movz       s2, #1
    v.extract    s6, v1, #1
    s.muli       s11, s1, #1
    v.splat      v8, s6
    @p3 v.st.h       [s16, #0], v5
    a.vread      v5, a6, s4
    v.cmp.lt     p2, v7, v2
    p.and        p3, p1, p2
    vf.mul       v2, v5, v4
    s.addi       s4, s7, #1
    s.add        s6, s11, s9
    v.splat      v4, s4
    s.add        s4, s6, s8
    vf.mul       v5, v2, v3
    s.add        s6, s13, s4
    vf.cvt.f32.bf16 v2, v5
    s.movz       s4, #2
    v.extract    s11, v1, #2
    s.muli       s12, s1, #2
    v.splat      v5, s11
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a7, s5
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v2, v0
    s.addi       s5, s7, #2
    s.add        s10, s12, s9
    v.splat      v0, s5
    s.add        s5, s10, s8
    vf.mul       v2, v4, v3
    s.add        s10, s13, s5
    vf.cvt.f32.bf16 v4, v2
    s.movz       s5, #3
    v.extract    s11, v1, #3
    s.muli       s12, s1, #3
    v.splat      v2, s11
    @p3 v.st.h       [s3, #0], v4
    a.vread      v4, a7, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v8
    s.addi       s2, s7, #3
    s.add        s3, s12, s9
    v.splat      v4, s2
    s.add        s2, s3, s8
    vf.mul       v7, v0, v3
    s.add        s3, s13, s2
    s.movz       s2, #4
    v.extract    s11, v1, #4
    vf.cvt.f32.bf16 v0, v7
    v.splat      v7, s11
    s.muli       s11, s1, #4
    s.addi       s12, s7, #4
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a7, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v5
    s.add        s4, s11, s9
    v.splat      v0, s12
    s.add        s6, s4, s8
    s.movz       s4, #5
    vf.mul       v5, v4, v3
    s.add        s11, s13, s6
    v.extract    s6, v1, #5
    v.splat      v4, s6
    vf.cvt.f32.bf16 v8, v5
    s.muli       s6, s1, #5
    s.addi       s12, s7, #5
    v.splat      v5, s12
    @p3 v.st.h       [s10, #0], v8
    a.vread      v8, a7, s5
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v8, v2
    s.add        s5, s6, s9
    s.movz       s6, #6
    s.add        s10, s5, s8
    v.extract    s5, v1, #6
    vf.mul       v2, v0, v3
    s.add        s12, s13, s10
    v.splat      v0, s5
    vf.cvt.f32.bf16 v8, v2
    s.muli       s5, s1, #6
    s.addi       s10, s7, #6
    v.splat      v2, s10
    @p4 v.st.h       [s3, #0], v8
    a.vread      v8, a7, s2
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v8, v7
    s.add        s2, s5, s9
    s.movz       s3, #7
    s.add        s5, s2, s8
    v.extract    s2, v1, #7
    vf.mul       v7, v5, v3
    s.add        s10, s13, s5
    v.splat      v5, s2
    vf.cvt.f32.bf16 v8, v7
    s.muli       s2, s1, #7
    s.addi       s5, s7, #7
    v.splat      v7, s5
    @p3 v.st.h       [s11, #0], v8
    a.vread      v8, a7, s4
    v.cmp.lt     p1, v2, v6
    p.and        p3, p1, p2
    vf.mul       v2, v8, v4
    s.add        s4, s2, s9
    s.movz       s2, #8
    s.add        s5, s4, s8
    v.extract    s4, v1, #8
    vf.mul       v4, v2, v3
    s.add        s11, s13, s5
    v.splat      v2, s4
    vf.cvt.f32.bf16 v8, v4
    s.muli       s4, s1, #8
    s.addi       s5, s7, #8
    v.splat      v4, s5
    @p4 v.st.h       [s12, #0], v8
    a.vread      v8, a7, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v8, v0
    s.add        s5, s4, s9
    s.movz       s4, #9
    s.add        s6, s5, s8
    v.extract    s5, v1, #9
    vf.mul       v0, v7, v3
    s.add        s12, s13, s6
    v.splat      v7, s5
    vf.cvt.f32.bf16 v8, v0
    s.muli       s5, s1, #9
    s.addi       s6, s7, #9
    v.splat      v0, s6
    @p3 v.st.h       [s10, #0], v8
    a.vread      v8, a7, s3
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v8, v5
    s.add        s3, s5, s9
    s.movz       s5, #10
    s.add        s6, s3, s8
    v.extract    s3, v1, #10
    vf.mul       v5, v4, v3
    s.add        s10, s13, s6
    v.splat      v4, s3
    vf.cvt.f32.bf16 v8, v5
    s.muli       s3, s1, #10
    s.addi       s6, s7, #10
    v.splat      v5, s6
    @p4 v.st.h       [s11, #0], v8
    a.vread      v8, a7, s2
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v8, v2
    s.add        s2, s3, s9
    s.movz       s3, #11
    s.add        s6, s2, s8
    v.extract    s2, v1, #11
    vf.mul       v2, v0, v3
    s.add        s11, s13, s6
    v.splat      v0, s2
    vf.cvt.f32.bf16 v8, v2
    s.muli       s2, s1, #11
    s.addi       s6, s7, #11
    v.splat      v2, s6
    @p3 v.st.h       [s12, #0], v8
    a.vread      v8, a7, s4
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v8, v7
    s.add        s4, s2, s9
    s.movz       s2, #12
    s.add        s6, s4, s8
    v.extract    s4, v1, #12
    vf.mul       v7, v5, v3
    s.add        s12, s13, s6
    v.splat      v5, s4
    vf.cvt.f32.bf16 v8, v7
    s.muli       s4, s1, #12
    s.addi       s6, s7, #12
    v.splat      v7, s6
    @p4 v.st.h       [s10, #0], v8
    a.vread      v8, a7, s5
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v8, v4
    s.add        s5, s4, s9
    s.movz       s4, #13
    s.add        s6, s5, s8
    v.extract    s5, v1, #13
    vf.mul       v4, v2, v3
    s.add        s10, s13, s6
    v.splat      v2, s5
    vf.cvt.f32.bf16 v8, v4
    s.muli       s5, s1, #13
    s.addi       s6, s7, #13
    v.splat      v4, s6
    @p3 v.st.h       [s11, #0], v8
    a.vread      v8, a7, s3
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v8, v0
    s.add        s3, s5, s9
    s.movz       s5, #14
    s.add        s6, s3, s8
    v.extract    s3, v1, #14
    vf.mul       v0, v7, v3
    s.add        s11, s13, s6
    v.splat      v7, s3
    vf.cvt.f32.bf16 v8, v0
    s.muli       s3, s1, #14
    s.addi       s6, s7, #14
    v.splat      v0, s6
    @p4 v.st.h       [s12, #0], v8
    a.vread      v8, a7, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v8, v5
    s.add        s2, s3, s9
    s.movz       s3, #15
    s.add        s6, s2, s8
    v.extract    s2, v1, #15
    vf.mul       v1, v4, v3
    s.add        s12, s13, s6
    v.splat      v4, s2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s2, s1, #15
    s.addi       s1, s7, #15
    v.splat      v1, s1
    @p3 v.st.h       [s10, #0], v5
    a.vread      v5, a7, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v5, v2
    s.add        s1, s2, s9
    s.add        s2, s1, s8
    vf.mul       v2, v0, v3
    s.add        s1, s13, s2
    vf.cvt.f32.bf16 v0, v2
    @p4 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v1, v6
    p.and        p4, p1, p2
    vf.mul       v1, v0, v7
    vf.mul       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s12, #0], v1
    a.vread      v0, a7, s3
    vf.mul       v1, v0, v4
    vf.mul       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s1, #0], v1
    exit
    exit
