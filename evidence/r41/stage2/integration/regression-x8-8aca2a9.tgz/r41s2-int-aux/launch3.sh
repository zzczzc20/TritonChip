#!/bin/bash
cd ~ && . ~/tc_env/env.sh
(cd r41s2-int && make r2-stage-data >/dev/null 2>&1)
for x in a b; do rm -rf r41s2-int-x8$x; cp -a r41s2-int r41s2-int-x8$x; done
grep -n "^R39_SW5" r41s2-int-x8b/Makefile | head -2
sed -i '/^R39_SW5/,/[^\\]$/ s/HAS_TENSOR_XPOSE=1/HAS_TENSOR_XPOSE=2/' r41s2-int-x8b/Makefile
grep -c "HAS_TENSOR_XPOSE=2" r41s2-int-x8b/Makefile
L="bash $HOME/r41s2-int-aux/lane.sh"
setsid nohup $L r41s2-int-x8a X8A "make r41-xpose8-rtl" "make r38-xpose-rtl" "make core" "make core-r39sw5" "make top" "make unit" "make compiler-rtl" "make triton-e2e" </dev/null >/dev/null 2>&1 &
setsid nohup $L r41s2-int-x8b X8B "make core-r39sw5" </dev/null >/dev/null 2>&1 &
sleep 2; tail -n1 ~/r41s2-int-logs/X8*.lane
