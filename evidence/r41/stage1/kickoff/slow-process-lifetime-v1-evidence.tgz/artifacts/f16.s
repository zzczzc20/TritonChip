    .li       s1, #262144
    .li       s2, #278528
    .li       s3, #294912
    v.iota       v0                              // arange(0, VLEN)
    .li       s4, #13
    v.splat      v1, s4
    v.cmp.lt     p1, v0, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s1, #0]
    vf.cvt.f16.f32 v1, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s2, #0]
    vf.cvt.f16.f32 v2, v0
    vf.add       v0, v1, v2
    vf.cvt.f32.f16 v1, v0
    @p1 v.st.h       [s3, #0], v1

exit
