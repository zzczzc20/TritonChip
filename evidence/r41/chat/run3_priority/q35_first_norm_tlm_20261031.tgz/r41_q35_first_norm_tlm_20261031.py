#!/usr/bin/env python3
"""First-layer standalone RMSNorm on actual prompt embedding, DP TLM."""
import json,sys,time
from pathlib import Path
import torch
from safetensors.torch import load_file,save_file
h=Path.home();tree=h/'r41_q35_multiturn_diag_20261031';sys.path[:0]=[str(tree/'tools/models'),str(tree),str(tree/'python'),str(tree/'compiler/python'),str(tree/'tools/asm')]
import chat
chat.L.use_tnca(str(tree))
args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1'])
start=time.monotonic();app=chat.ChatApplication(args)
a=load_file(str(h/'r41_q35_first_components_cpu_20261031_diag/states.safetensors'));x=a['embedding'];expected=a['input_layernorm'];norm=app.model.model.language_model.layers[0].input_layernorm
stage,dev=chat.L.place(norm,'tnca','eager')
with torch.no_grad():got=stage(x.to(dev)).detach().cpu().contiguous().clone()
if got.shape!=expected.shape or got.dtype!=expected.dtype:raise ValueError('shape or dtype mismatch')
f=expected.float();g=got.float();diff=(f-g).abs();result={'schema':'r41-q35-first-norm-tlm/1','scope':'isolated one-op DP TLM on CPU-captured embedding; graph differs from full model and is not board evidence','shape':list(got.shape),'elements':got.numel(),'bit_mismatches':int((got.view(torch.int16)!=expected.view(torch.int16)).sum()),'relative_l2':float((f-g).norm()/f.norm().clamp_min(1e-30)),'max_abs':float(diff.max()),'seconds':time.monotonic()-start}
out=h/'r41_q35_first_norm_tlm_20261031_diag';out.mkdir(exist_ok=False);save_file({'got':got,'expected':expected.contiguous().clone()},str(out/'states.safetensors'));(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
