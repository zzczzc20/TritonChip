source /tools/Xilinx/Vivado/2023.2/settings64.sh >/dev/null 2>&1
cd /home/zzhouch/tnca_build/r40_final_cut_reporting_probe_20261017
timeout 900 nice -n 19 vivado -mode batch -source /home/zzhouch/tnca_build/r40_final_cut_reporting_probe_20261017/diagnose_r40_checkpoint.tcl -tclargs /home/zzhouch/tnca_build/r40_hit_owner_module_20261017/reports/routed.dcp /home/zzhouch/tnca_build/r40_final_cut_reporting_probe_20261017/reports final-cache-cuts > stdout.log 2>&1
echo $? > runner.exit
