from pathlib import Path
import subprocess,json,itertools
root=Path.cwd();out=root/'results';out.mkdir(exist_ok=False);results=[]
def run(name,args,expected=0):
 p=subprocess.run(args,capture_output=True,text=True,timeout=120);text=p.stdout+p.stderr;(out/(name+'.log')).write_text(text)
 assert p.returncode==expected,(name,p.returncode,text)
 return text
for sync,full,lat in itertools.product((0,1),(0,1),(1,8,31)):
 name=f's{sync}_f{full}_l{lat}';args=['iverilog','-g2012','-I','rtl/common','-s','tb_nuca_maintenance',f'-Ptb_nuca_maintenance.SYNC_TAG_BANK={sync}',f'-Ptb_nuca_maintenance.FULL_TAG={full}',f'-Ptb_nuca_maintenance.LATENCY={lat}','-o',str(out/'test.vvp'),'rtl/nuca/tnca_nuca_slice.v','tb/common/tnca_dram_model.v','tb/nuca/tb_nuca_maintenance.v']
 run(name+'_build',args);text=run(name,['vvp',str(out/'test.vvp')]);assert 'NUCA MAINTENANCE PASS' in text,text;results.append(dict(sync=sync,full=full,lat=lat,output=text));print('PASS',name,flush=True)
s=(root/'rtl/nuca/tnca_nuca_slice.v').read_text();needle='!(maint_requested && maint_ready)';assert s.count(needle)==1
(root/'mutant.v').write_text(s.replace(needle,'!maint_requested'));args[-3]='mutant.v'
run('mutation_build',args);text=run('mutation',['vvp',str(out/'test.vvp')],1);assert 'synchronous tag read did not follow selected request set' in text,text
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('P0 TAG MAINTENANCE AND ALIGNMENT MUTATION PASS',flush=True)
