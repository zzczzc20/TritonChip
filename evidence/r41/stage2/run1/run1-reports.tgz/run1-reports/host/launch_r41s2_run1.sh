#!/bin/bash
# R41 Stage 2 full run 1/5 (measurement) launcher. Never loads a board.
set -eu
SHA=c9f25787494a8414f9ab19e03bea6fb3fa794d20; S12=${SHA:0:12}
SRC=$HOME/tnca_src_r41s2_run1_$S12
B=$HOME/tnca_build/r41s2_run1_$S12
ARC=$HOME/tnca_src_r41s2_run1_$S12.tar.gz
CFG=$SRC/evidence/r41/stage2/integration/image.tcl
[ ! -e "$B" ] || { echo "build root exists"; exit 2; }
[ ! -e "$SRC" ] || { echo "source root exists"; exit 2; }
avail=$(awk '/MemAvailable/{print int($2/1048576)}' /proc/meminfo)
[ "$avail" -ge 38 ] || { echo "MemAvailable ${avail} GB < 38"; exit 3; }
mkdir -p "$SRC"; tar -xzf "$ARC" -C "$SRC"
chmod -R a-w "$SRC"
cat > $HOME/tnca_build/r41s2_run1_$S12.launch.json <<J
{"run":"R41 Stage 2 full run 1/5 (measurement)","source_commit":"$SHA",
 "source_archive":"$ARC","source_archive_sha256":"$(sha256sum $ARC|cut -d' ' -f1)",
 "image_tcl_sha256":"$(sha256sum $CFG|cut -d' ' -f1)",
 "image_json_sha256":"$(sha256sum $SRC/evidence/r41/stage2/integration/image.json|cut -d' ' -f1)",
 "runner":"flow/fpga/run_r40_attempt01.sh (attempt-3 runner: VPP_JOBS=2, SSI_SpreadSLLs, place_r40_multicore.tcl PRE, u280_multicore_hbm.cfg, --kernel_frequency 0:100)",
 "build_root":"$B","mem_available_gb_at_launch":$avail,"started_utc":"$(date -u +%FT%TZ)","nice":10}
J
cd $HOME
setsid nice -n 10 bash "$SRC/flow/fpga/run_r40_attempt01.sh" "$B" "$CFG" > $HOME/tnca_build/r41s2_run1_$S12.detach.log 2>&1 < /dev/null &
echo "launched pid $!"
