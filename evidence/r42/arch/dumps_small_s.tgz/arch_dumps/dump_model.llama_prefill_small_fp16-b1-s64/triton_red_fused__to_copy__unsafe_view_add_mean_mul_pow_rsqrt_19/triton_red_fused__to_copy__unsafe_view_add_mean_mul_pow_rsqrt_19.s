    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #1536
    s.rdspecial  s4, arg_base
    s.mul        s5, s2, s1
    s.movz       s1, #0
    s.movz       s2, #128
    s.movz       s6, #32
    s.movz       s7, #64
    s.movz       s8, #1
    s.rdspecial  s8, role_id
    s.rdspecial  s9, npid.x
    s.ld.d       s10, [s4, #0]                   // in_ptr0: device_ptr64 at arg_base+0
    s.add        s11, s3, s5                     // this context's own scratch
    s.ld.d       s3, [s4, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s4, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s11, [s4, #24]                  // out_ptr1: device_ptr64 at arg_base+24
__rctx_program:
    s.addi       s4, s1, #0
    s.muli       s12, s8, #256
    s.muli       s13, s4, #2
    s.muli       s14, s4, #2
    v.splat      v0, s8
    v.movi       v1, #0
    v.splat      v2, s7
    v.movi       v3, #0
    v.movi       v4, #0
    v.movi       v5, #0
    s.add        s15, s10, s12
    s.add        s16, s3, s12
    v.cmp.ge     p1, v0, v1
    v.cmp.lt     p2, v0, v2
    v.mov        v4, v3
    v.mov        v5, v3
    p.and        p3, p1, p2
    s.add        s12, s15, s13
    s.add        s13, s16, s14
for_1:
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s12, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s12, #32]
    vf.cvt.f16.f32 v2, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s13, #0]
    vf.cvt.f16.f32 v3, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s13, #32]
    vf.cvt.f16.f32 v6, v0
    vf.add       v0, v2, v6
    vf.mul       v2, v0, v0
    vf.cvt.f16.f32 v0, v1
    vf.add       v4, v4, v2
    vf.add       v1, v3, v0
    vf.mul       v0, v1, v1
    vf.add       v5, v5, v0
    s.addi       s12, s12, #64                   // the next iteration's address
    s.addi       s13, s13, #64                   // the next iteration's address
    s.add        s4, s4, s6
    s.cmp.lt     s14, s4, s2
    br.nz        s14, for_1
endfor_2:
    .li       s4, #1124073472
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #1065353216
    v.splat      v1, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.add.b v2, v4
    v.rcp.approx v3, v0                          // ISA 8.8: <= 2**-22 relative
    vf.reduce.add.b v4, v5
    v.movi       v5, #0
    .li       s4, #925353388
    v.splat      v6, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v7, v2, v4
    .li       s4, #1077936128
    v.splat      v2, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #3204448256
    v.splat      v4, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s4, s8, s2
    s.addi       s12, s1, #0
    vf.add       v8, v7, v5
    s.muli       s13, s12, #2
    s.muli       s14, s12, #2
    v.splat      v5, s8
    s.add        s17, s12, s4
    s.shli       s4, s12, #1                     // element offset -> bytes (x2)
    s.shli       s18, s17, #1                    // element offset -> bytes (x2)
    s.movz       s17, #1
    s.add        s17, s15, s13
    s.add        s13, s16, s14
    s.add        s14, s5, s4                     // &in_ptr2[...]
    s.add        s4, s11, s18                    // &out_ptr1[...]
    vf.fms       v7, v0, v3, v1
    v.movi       v0, #0
    v.cmp.ge     p1, v5, v0
    vf.fms       v0, v3, v7, v3
    v.splat      v1, s7
    v.cmp.lt     p2, v5, v1
    vf.neg       v1, v0                          // Newton step: r0*(2 - x*r0)
    p.and        p3, p1, p2
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v3
    vf.mul       v1, v8, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v0, v1, v6
    v.rsqrt.approx v1, v0                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v1, v1
    vf.mul       v5, v1, v4
    vf.fms       v4, v0, v3, v2
    vf.mul       v0, v5, v4                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v2, v0, v1
    v.extract    s15, v2, #0
    v.splat      v0, s15
for_3:
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s17, #0]
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s17, #32]
    vf.cvt.f16.f32 v3, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s13, #0]
    vf.cvt.f16.f32 v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s13, #32]
    vf.cvt.f16.f32 v5, v1
    vf.add       v1, v3, v5
    vf.mul       v3, v1, v0
    v.ld.h       v1, [s14, #0]
    vf.cvt.f16.f32 v5, v2
    vf.add       v2, v4, v5
    vf.mul       v4, v2, v0
    v.ld.h       v2, [s14, #32]
    vf.cvt.f16.f32 v5, v1
    vf.mul       v1, v3, v5
    vf.cvt.f32.f16 v3, v1
    vf.cvt.f16.f32 v1, v2
    v.st.h       [s4, #0], v3
    vf.mul       v2, v4, v1
    vf.cvt.f32.f16 v1, v2
    v.st.h       [s4, #32], v1
    s.addi       s17, s17, #64                   // the next iteration's address
    s.addi       s13, s13, #64                   // the next iteration's address
    s.addi       s14, s14, #64                   // the next iteration's address
    s.addi       s4, s4, #64                     // the next iteration's address
    s.add        s12, s12, s6
    s.cmp.lt     s15, s12, s2
    br.nz        s15, for_3
endfor_4:
__rctx_next:
    s.addi       s4, s8, #2                      // the next program of this context: + 2
    s.cmp.lt     s12, s4, s9
    s.mov        s8, s4
    br.nz        s12, __rctx_program
    exit
