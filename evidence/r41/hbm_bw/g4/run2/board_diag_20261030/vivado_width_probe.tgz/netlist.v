// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2023.2 (lin64) Build 4029153 Fri Oct 13 20:13:54 MDT 2023
// Date        : Fri Oct 30 17:54:12 2026
// Host        : ee4e138 running 64-bit Ubuntu 24.04.5 LTS
// Command     : write_verilog -force netlist.v
// Design      : probe
// Purpose     : This is a Verilog netlist of the current design or from a specific cell of the design. The output is an
//               IEEE 1364-2001 compliant Verilog HDL file that contains netlist information obtained from the input
//               design files.
// Device      : xcu280-fsvh2892-2L-e
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* FIXED = "4" *) (* MAC_CUTS = "5'b11101" *) (* MAC_LAT = "1'b0" *) 
(* STRUCTURAL_NETLIST = "yes" *)
module probe
   (observed,
    fixed_observed);
  output [7:0]observed;
  output [7:0]fixed_observed;

  wire \<const0> ;
  wire \<const1> ;
  wire [7:0]fixed_observed;
  wire [7:0]observed;

  GND GND
       (.G(\<const0> ));
  VCC VCC
       (.P(\<const1> ));
  OBUF \fixed_observed_OBUF[0]_inst 
       (.I(\<const0> ),
        .O(fixed_observed[0]));
  OBUF \fixed_observed_OBUF[1]_inst 
       (.I(\<const0> ),
        .O(fixed_observed[1]));
  OBUF \fixed_observed_OBUF[2]_inst 
       (.I(\<const1> ),
        .O(fixed_observed[2]));
  OBUF \fixed_observed_OBUF[3]_inst 
       (.I(\<const0> ),
        .O(fixed_observed[3]));
  OBUF \fixed_observed_OBUF[4]_inst 
       (.I(\<const0> ),
        .O(fixed_observed[4]));
  OBUF \fixed_observed_OBUF[5]_inst 
       (.I(\<const0> ),
        .O(fixed_observed[5]));
  OBUF \fixed_observed_OBUF[6]_inst 
       (.I(\<const0> ),
        .O(fixed_observed[6]));
  OBUF \fixed_observed_OBUF[7]_inst 
       (.I(\<const0> ),
        .O(fixed_observed[7]));
  OBUF \observed_OBUF[0]_inst 
       (.I(\<const0> ),
        .O(observed[0]));
  OBUF \observed_OBUF[1]_inst 
       (.I(\<const0> ),
        .O(observed[1]));
  OBUF \observed_OBUF[2]_inst 
       (.I(\<const0> ),
        .O(observed[2]));
  OBUF \observed_OBUF[3]_inst 
       (.I(\<const0> ),
        .O(observed[3]));
  OBUF \observed_OBUF[4]_inst 
       (.I(\<const0> ),
        .O(observed[4]));
  OBUF \observed_OBUF[5]_inst 
       (.I(\<const0> ),
        .O(observed[5]));
  OBUF \observed_OBUF[6]_inst 
       (.I(\<const0> ),
        .O(observed[6]));
  OBUF \observed_OBUF[7]_inst 
       (.I(\<const0> ),
        .O(observed[7]));
endmodule
