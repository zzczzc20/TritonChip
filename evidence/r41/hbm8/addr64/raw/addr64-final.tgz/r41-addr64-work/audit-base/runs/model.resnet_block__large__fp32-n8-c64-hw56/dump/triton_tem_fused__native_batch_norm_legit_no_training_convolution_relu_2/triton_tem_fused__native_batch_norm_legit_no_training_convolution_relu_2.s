    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #56
    v.movi       v2, #0
    s.rdspecial  s3, arg_base
    v.movi       v3, #1
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    s.ld.d       s2, [s3, #0]                    // arg_X: device_ptr64 at arg_base+0
    @p1 v.sel        v4, v5, v1
    v.sub        v5, v2, v6
    v.cmp.lt     p1, v6, v2
    v.movi       v7, #0
    @p1 v.sel        v8, v5, v6
    v.movi       v5, #0
    s.movz       s4, #31
    s.ld.d       s5, [s3, #8]                    // arg_W: device_ptr64 at arg_base+8
    s.ld.d       s6, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s7, [s3, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s8, [s3, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s9, [s3, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s10, [s3, #48]                  // out_ptr1: device_ptr64 at arg_base+48
idiv_1:
    v.splat      v9, s4
    v.shl        v10, v5, v3
    v.cmp.lt     p2, v5, v2
    v.lshr       v11, v8, v9
    v.shl        v12, v3, v9
    s.subi       s3, s4, #1
    v.and        v9, v11, v3
    s.movz       s11, #0
    v.or         v11, v10, v9
    v.cmp.geu    p3, v11, v4
    p.or         p4, p2, p3
    v.sub        v9, v11, v4
    @p4 v.sel        v10, v12, v2
    @p4 v.sel        v12, v9, v11
    v.or         v9, v7, v10
    v.mov        v5, v12
    v.mov        v7, v9
    s.mov        s4, s3
    s.cmp.ge     s3, s4, s11
    br.nz        s3, idiv_1
    v.movi       v3, #0
    v.sub        v4, v2, v5
    v.movi       v2, #1
    v.sub        v7, v3, v6
    v.sub        v8, v3, v1
    v.cmp.lt     p2, v6, v3
    v.cmp.lt     p3, v1, v3
    @p1 v.sel        v9, v4, v5
    @p2 v.sel        v4, v7, v6
    @p3 v.sel        v5, v8, v1
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_2:
    v.splat      v8, s3
    v.shl        v10, v7, v2
    v.cmp.lt     p1, v7, v3
    v.lshr       v11, v4, v8
    v.shl        v12, v2, v8
    s.subi       s4, s3, #1
    v.and        v8, v11, v2
    s.movz       s11, #0
    v.or         v11, v10, v8
    v.cmp.geu    p4, v11, v5
    p.or         p5, p1, p4
    v.sub        v8, v11, v5
    @p5 v.sel        v10, v12, v3
    @p5 v.sel        v12, v8, v11
    v.or         v8, v6, v10
    v.mov        v7, v12
    v.mov        v6, v8
    s.mov        s3, s4
    s.cmp.ge     s4, s3, s11
    br.nz        s4, idiv_2
    v.sub        v2, v3, v6
    p.xor        p1, p2, p3
    v.movi       v3, #0
    @p1 v.sel        v4, v2, v6
    v.movi       v2, #1
    v.sub        v5, v3, v1
    v.sub        v6, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    @p1 v.sel        v7, v6, v4
    @p2 v.sel        v6, v5, v1
    v.movi       v5, #0
    v.movi       v8, #0
    s.movz       s3, #31
idiv_3:
    v.splat      v10, s3
    v.shl        v11, v8, v2
    v.cmp.lt     p2, v8, v3
    v.lshr       v12, v7, v10
    v.shl        v13, v2, v10
    s.subi       s4, s3, #1
    v.and        v10, v12, v2
    s.movz       s11, #0
    v.or         v12, v11, v10
    v.cmp.geu    p3, v12, v6
    p.or         p4, p2, p3
    v.sub        v10, v12, v6
    @p4 v.sel        v11, v13, v3
    @p4 v.sel        v13, v10, v12
    v.or         v10, v5, v11
    v.mov        v8, v13
    v.mov        v5, v10
    s.mov        s3, s4
    s.cmp.ge     s4, s3, s11
    br.nz        s4, idiv_3
    v.movi       v2, #0
    v.sub        v5, v3, v8
    v.movi       v3, #1
    v.sub        v6, v2, v4
    v.sub        v7, v2, v1
    v.cmp.lt     p2, v4, v2
    v.cmp.lt     p3, v1, v2
    @p1 v.sel        v10, v5, v8
    @p2 v.sel        v5, v6, v4
    @p3 v.sel        v4, v7, v1
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s3, #31
idiv_4:
    v.splat      v8, s3
    v.shl        v11, v7, v3
    v.cmp.lt     p1, v7, v2
    v.lshr       v12, v5, v8
    v.shl        v13, v3, v8
    s.subi       s4, s3, #1
    v.and        v8, v12, v3
    s.movz       s11, #0
    v.or         v12, v11, v8
    v.cmp.geu    p4, v12, v4
    p.or         p5, p1, p4
    v.sub        v8, v12, v4
    @p5 v.sel        v11, v13, v2
    @p5 v.sel        v13, v8, v12
    v.or         v8, v6, v11
    v.mov        v7, v13
    v.mov        v6, v8
    s.mov        s3, s4
    s.cmp.ge     s4, s3, s11
    br.nz        s4, idiv_4
    s.rdspecial  s3, pid.y
    s.rdspecial  s4, arg_base
    v.sub        v3, v2, v6
    s.mul        s11, s3, s1
    s.ld.d       s3, [s4, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    p.xor        p1, p2, p3
    .li       s4, #200704
    v.splat      v2, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v4, v3, v6
    s.rdspecial  s4, role_id
    s.movz       s12, #4160
    v.splat      v3, s11
    v.mul        v5, v4, v2
    s.mul        s13, s4, s12
    v.add        v2, v3, v0
    s.movz       s4, #0
    v.extract    s12, v5, #0
    v.extract    s14, v5, #1
    v.extract    s15, v5, #2
    v.extract    s16, v5, #3
    v.extract    s17, v5, #4
    v.extract    s18, v5, #5
    v.extract    s19, v5, #6
    s.add        s20, s3, s13                    // this context's own scratch
    v.extract    s3, v5, #7
    v.splat      v3, s4
    v.splat      v6, s12
    v.splat      v7, s14
    v.splat      v8, s15
    v.splat      v11, s16
    v.splat      v12, s17
    s.addi       s12, s20, #0
    v.add        v13, v3, v6
    v.add        v6, v3, v7
    v.add        v7, v3, v8
    v.add        v8, v3, v11
    v.add        v11, v3, v12
    s.addi       s13, s12, #64
    s.addi       s14, s12, #128
    s.addi       s15, s12, #192
    s.addi       s16, s12, #256
    v.st.w       [s12, #0], v13
    v.splat      v12, s18
    s.addi       s17, s12, #320
    v.add        v13, v3, v12
    v.st.w       [s13, #0], v6
    v.splat      v6, s19
    s.addi       s13, s12, #384
    s.addi       s18, s12, #448
    v.add        v12, v3, v6
    v.st.w       [s14, #0], v7
    .li       s14, #200704
    v.splat      v6, s3
    v.extract    s3, v5, #8
    v.add        v7, v3, v6
    v.st.w       [s15, #0], v8
    v.extract    s15, v5, #9
    v.splat      v6, s3
    v.extract    s3, v5, #10
    v.add        v8, v3, v6
    v.st.w       [s16, #0], v11
    v.extract    s16, v5, #11
    v.splat      v6, s15
    v.extract    s15, v5, #12
    v.add        v11, v3, v6
    v.st.w       [s17, #0], v13
    v.extract    s17, v5, #13
    v.splat      v6, s3
    v.extract    s3, v5, #14
    s.movz       s19, #576
    v.add        v13, v3, v6
    v.st.w       [s13, #0], v12
    v.movi       v6, #576
    v.extract    s13, v5, #15
    v.splat      v5, s16
    v.mul        v12, v2, v6
    s.addi       s16, s12, #512
    v.add        v6, v3, v5
    v.st.w       [s18, #0], v7
    v.splat      v5, s15
    s.addi       s15, s12, #576
    s.addi       s18, s12, #640
    v.add        v7, v3, v5
    v.st.w       [s16, #0], v8
    v.splat      v5, s17
    s.addi       s16, s12, #704
    s.addi       s17, s12, #768
    v.add        v8, v3, v5
    v.st.w       [s15, #0], v11
    v.splat      v5, s3
    s.addi       s3, s12, #832
    s.addi       s15, s12, #896
    v.add        v11, v3, v5
    s.addi       s19, s12, #960
    v.st.w       [s18, #0], v13
    v.splat      v5, s13
    s.addi       s12, s20, #1024
    s.movz       s13, #36
    v.add        v13, v3, v5
    v.splat      v3, s4
    v.add        v5, v3, v12
    v.st.w       [s16, #0], v6
    s.movz       s16, #1
    v.st.w       [s17, #0], v7
    s.addi       s17, s4, #0
    v.st.w       [s3, #0], v8
    v.st.w       [s15, #0], v11
    v.st.w       [s19, #0], v13
    fence.acq_rel.device
    v.st.w       [s12, #0], v5
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s3, s17, s13
    br.nz        s3, endfor_6
    s.movz       s3, #0
    s.movz       s12, #0
    s.cmp.lt     s15, s17, s3
    s.movz       s3, #4
    s.sub        s18, s12, s15
    s.movz       s12, #0
    s.movz       s15, #0
    s.cmp.lt     s19, s3, s12
    s.xor        s12, s17, s18
    s.sub        s21, s15, s19
    s.sub        s15, s12, s18
    s.xor        s12, s18, s21
    s.lshri      s18, s15, #2
    s.movz       s19, #0
    s.xor        s22, s18, s12
    s.movz       s23, #0
    s.sub        s24, s22, s12
    s.movz       s12, #0
    s.cmp.lt     s22, s24, s19
    s.movz       s19, #0
    s.sub        s25, s23, s22
    .li       s22, #1431655766
    s.xor        s23, s24, s25
    s.cmp.lt     s26, s17, s12
    s.sub        s12, s23, s25
    s.sub        s23, s19, s26
    s.mul        s19, s12, s22
    s.movz       s22, #3
    s.movz       s26, #0
    s.muli       s27, s18, #4
    s.cmp.lt     s18, s22, s26
    s.lshri      s26, s19, #32
    s.sub        s19, s15, s27
    s.xor        s15, s17, s23
    s.movz       s19, #0
    s.sub        s27, s15, s23
    s.sub        s15, s19, s18
    s.lshri      s18, s27, #2
    s.muli       s19, s18, #4
    s.sub        s18, s27, s19
    s.movz       s19, #0
    s.xor        s27, s18, s23
    s.cmp.lt     s18, s3, s19
    s.sub        s19, s27, s23
    s.movz       s23, #0
    s.mul        s27, s19, s1
    s.sub        s19, s12, s26
    s.sub        s28, s23, s18
    s.lshri      s18, s19, #1
    s.xor        s19, s3, s28
    s.add        s23, s26, s18
    s.xor        s18, s25, s15
    s.lshri      s25, s23, #1
    s.xor        s23, s3, s21
    s.muli       s3, s25, #3
    s.sub        s26, s19, s28
    s.movz       s19, #0
    s.movz       s26, #0
    s.cmp.lt     s28, s24, s19
    s.xor        s19, s25, s18
    s.sub        s25, s26, s28
    .li       s26, #1431655766
    s.xor        s28, s24, s25
    s.sub        s24, s19, s18
    s.sub        s18, s28, s25
    s.movz       s19, #0
    s.mul        s28, s18, s26
    s.cmp.lt     s26, s22, s19
    s.sub        s19, s23, s21
    s.sub        s19, s24, s16
    v.movi       v3, #3584
    s.lshri      s21, s28, #32
    v.splat      v5, s19
    s.sub        s19, s18, s21
    v.splat      v6, s27
    s.lshri      s23, s19, #1
    v.add        v7, v5, v10
    s.add        s19, s21, s23
    v.add        v5, v0, v6
    s.lshri      s21, s19, #1
    v.mul        v6, v7, v3
    s.muli       s19, s21, #3
    s.movz       s21, #0
    s.xor        s23, s22, s15
    s.sub        s28, s21, s26
    s.movz       s21, #64
    s.sub        s26, s18, s19
    s.xor        s18, s22, s28
    s.xor        s19, s26, s25
    s.sub        s22, s23, s15
    s.sub        s15, s19, s25
    s.addi       s19, s20, #0
    s.sub        s22, s15, s16
    v.ld.w       v3, [s19, #0]
    v.splat      v8, s22
    v.movi       v11, #64
    v.extract    s19, v6, #0
    v.add        v12, v8, v9
    v.splat      v8, s19
    s.addi       s19, s20, #1088
    v.mul        v13, v12, v11
    s.sub        s22, s12, s3
    s.movz       s3, #0
    v.extract    s12, v13, #0
    s.add        s22, s3, s27                    // the tile origin
    v.splat      v14, s12
    v.iota       v15                             // arange(0, VLEN)
    v.splat      v16, s22
    v.add        v17, v8, v14
    s.addi       s3, s20, #64
    v.add        v8, v15, v16
    v.extract    s12, v6, #1
    v.extract    s22, v13, #1
    v.add        v14, v17, v8
    v.splat      v16, s12
    s.addi       s12, s19, #64
    v.add        v17, v3, v14
    s.sub        s23, s18, s28
    v.splat      v3, s22
    v.st.w       [s19, #0], v17
    s.addi       s18, s20, #128
    v.add        v14, v16, v3
    v.extract    s22, v6, #2
    v.extract    s23, v13, #2
    v.add        v3, v14, v8
    v.splat      v14, s22
    v.splat      v16, s23
    s.addi       s22, s19, #128
    s.addi       s23, s20, #192
    v.add        v17, v14, v16
    v.extract    s25, v6, #3
    s.addi       s26, s19, #192
    v.add        v14, v17, v8
    s.movz       s28, #3584
    v.splat      v16, s25
    v.extract    s25, v13, #3
    v.ld.w       v17, [s3, #0]
    v.splat      v18, s25
    s.addi       s3, s20, #256
    v.extract    s25, v6, #4
    v.add        v19, v16, v18
    v.splat      v16, s25
    v.extract    s25, v13, #4
    v.add        v18, v19, v8
    v.splat      v19, s25
    s.addi       s25, s19, #256
    v.add        v20, v16, v19
    v.add        v16, v20, v8
    v.add        v19, v17, v3
    v.st.w       [s12, #0], v19
    s.addi       s12, s20, #320
    v.ld.w       v3, [s18, #0]
    v.extract    s18, v6, #5
    v.splat      v17, s18
    v.extract    s18, v13, #5
    v.splat      v19, s18
    s.addi       s18, s19, #320
    v.add        v20, v17, v19
    v.add        v17, v20, v8
    v.add        v19, v3, v14
    v.st.w       [s22, #0], v19
    s.addi       s22, s20, #384
    v.ld.w       v3, [s23, #0]
    v.extract    s23, v6, #6
    v.splat      v14, s23
    v.extract    s23, v13, #6
    v.splat      v19, s23
    s.addi       s23, s19, #384
    v.add        v20, v14, v19
    v.add        v14, v20, v8
    v.add        v19, v3, v18
    v.st.w       [s26, #0], v19
    s.addi       s26, s20, #448
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v6, #7
    v.splat      v18, s3
    v.extract    s3, v13, #7
    v.splat      v19, s3
    s.addi       s3, s19, #448
    v.add        v20, v18, v19
    v.add        v18, v20, v8
    v.add        v19, v3, v16
    v.st.w       [s25, #0], v19
    s.addi       s25, s20, #512
    v.ld.w       v3, [s12, #0]
    v.extract    s12, v6, #8
    v.splat      v16, s12
    v.extract    s12, v13, #8
    v.splat      v19, s12
    s.addi       s12, s19, #512
    v.add        v20, v16, v19
    v.add        v16, v20, v8
    v.add        v19, v3, v17
    v.st.w       [s18, #0], v19
    s.addi       s18, s20, #576
    v.ld.w       v3, [s22, #0]
    v.extract    s22, v6, #9
    v.splat      v17, s22
    v.extract    s22, v13, #9
    v.splat      v19, s22
    s.addi       s22, s19, #576
    v.add        v20, v17, v19
    v.add        v17, v20, v8
    v.add        v19, v3, v14
    v.st.w       [s23, #0], v19
    s.addi       s23, s20, #640
    v.ld.w       v3, [s26, #0]
    v.extract    s26, v6, #10
    v.splat      v14, s26
    v.extract    s26, v13, #10
    v.splat      v19, s26
    s.addi       s26, s19, #640
    v.add        v20, v14, v19
    v.add        v14, v20, v8
    v.add        v19, v3, v18
    v.st.w       [s3, #0], v19
    s.addi       s3, s20, #704
    v.ld.w       v3, [s25, #0]
    v.extract    s25, v6, #11
    v.splat      v18, s25
    v.extract    s25, v13, #11
    v.splat      v19, s25
    s.addi       s25, s19, #704
    v.add        v20, v18, v19
    v.add        v18, v20, v8
    v.add        v19, v3, v16
    v.st.w       [s12, #0], v19
    s.addi       s12, s20, #768
    v.ld.w       v3, [s18, #0]
    v.extract    s18, v6, #12
    v.splat      v16, s18
    v.extract    s18, v13, #12
    v.splat      v19, s18
    s.addi       s18, s19, #768
    v.add        v20, v16, v19
    v.add        v16, v20, v8
    v.add        v19, v3, v17
    v.st.w       [s22, #0], v19
    s.addi       s22, s20, #832
    v.ld.w       v3, [s23, #0]
    v.extract    s23, v6, #13
    v.splat      v17, s23
    v.extract    s23, v13, #13
    v.splat      v19, s23
    s.addi       s23, s19, #832
    v.add        v20, v17, v19
    v.add        v17, v20, v8
    v.add        v19, v3, v14
    v.st.w       [s26, #0], v19
    s.addi       s26, s20, #896
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v6, #14
    v.movi       v14, #8
    v.splat      v19, s3
    v.extract    s3, v13, #14
    v.splat      v20, s3
    s.addi       s3, s19, #896
    s.addi       s28, s19, #960
    v.add        v21, v19, v20
    v.add        v19, v21, v8
    v.add        v20, v3, v18
    v.cmp.lt     p1, v4, v14
    v.st.w       [s25, #0], v20
    s.addi       s19, s20, #960
    v.movi       v3, #1
    v.movi       v14, #0
    @p1 v.sel        v18, v3, v14
    v.ld.w       v3, [s12, #0]
    v.extract    s12, v6, #15
    v.movi       v6, #0
    v.splat      v14, s12
    v.extract    s12, v13, #15
    v.movi       v13, #1
    v.splat      v20, s12
    v.cmp.ge     p1, v7, v6
    v.cmp.lt     p2, v7, v1
    v.add        v7, v14, v20
    v.movi       v14, #0
    v.movi       v20, #1
    v.add        v21, v7, v8
    @p1 v.sel        v7, v13, v14
    v.add        v8, v3, v16
    v.movi       v3, #0
    v.st.w       [s18, #0], v8
    v.movi       v8, #1
    @p2 v.sel        v13, v20, v3
    v.cmp.ge     p1, v12, v6
    v.ld.w       v3, [s22, #0]
    v.movi       v6, #0
    v.movi       v14, #1
    v.movi       v16, #0
    @p1 v.sel        v20, v8, v6
    v.cmp.lt     p1, v12, v1
    @p1 v.sel        v6, v14, v16
    v.cmp.lt     p1, v5, v11
    v.add        v5, v3, v17
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s12, #0
    v.st.w       [s23, #0], v5
    s.addi       s18, s20, #1088
    v.extract    s22, v18, #0
    v.ld.w       v3, [s26, #0]
    v.extract    s23, v7, #0
    v.splat      v5, s22
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p3, v11, v12
    v.add        v5, v3, v19
    p.and        p4, p2, p3
    v.st.w       [s3, #0], v5
    v.extract    s3, v13, #0
    v.movi       v3, #0
    v.splat      v5, s3
    v.ld.w       v8, [s19, #0]
    v.extract    s3, v20, #0
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v5, v3
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p3, p2
    v.add        v3, v8, v21
    v.extract    s3, v6, #0
    v.st.w       [s28, #0], v3
    fence.acq_rel.device
    v.splat      v3, s3
    v.movi       v5, #0
    s.addi       s3, s20, #1152
    v.extract    s19, v18, #1
    v.cmp.ne     p2, v3, v5
    p.and        p3, p4, p2
    v.extract    s22, v7, #1
    p.and        p2, p3, p1
    v.splat      v3, s19
    v.movi       v5, #0
    v.splat      v8, s22
    v.movi       v11, #0
    v.extract    s19, v13, #1
    v.movi       v12, #0
    v.splat      v14, s19
    v.extract    s19, v20, #1
    v.ld.w       v16, [s18, #0]
    v.cmp.ne     p3, v3, v5
    v.cmp.ne     p4, v8, v11
    p.and        p5, p3, p4
    v.splat      v3, s19
    v.movi       v5, #0
    v.extract    s18, v6, #1
    v.cmp.ne     p3, v14, v12
    p.and        p4, p5, p3
    v.splat      v8, s18
    v.movi       v11, #0
    v.cmp.ne     p3, v3, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v8, v11
    p.and        p4, p5, p3
    s.movz       s18, #1
    p.and        p3, p4, p1
    s.addi       s19, s20, #1216
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v3, [s2, v16]              // index is in elements (ISA sec 9.1)
    v.extract    s22, v18, #2
    v.extract    s23, v7, #2
    v.splat      v5, s22
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0
    v.extract    s22, v13, #2
    v.movi       v14, #0
    v.splat      v16, s22
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v12
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s22, #2
    a.vwrite     a1, s12, v3
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #2
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #2
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s20, #1280
    p.and        p2, p4, p1
    v.extract    s12, v18, #3
    v.extract    s23, v7, #3
    v.splat      v5, s12
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s12, v13, #3
    v.movi       v14, #0
    v.splat      v16, s12
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s12, #3
    a.vwrite     a1, s18, v12
    v.ld.w       v3, [s19, #0]
    v.extract    s18, v20, #3
    v.movi       v5, #0
    v.splat      v8, s18
    v.extract    s18, v6, #3
    v.movi       v11, #0
    v.splat      v12, s18
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s18, s20, #1344
    p.and        p3, p4, p1
    v.extract    s19, v18, #4
    v.extract    s23, v7, #4
    v.splat      v5, s19
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s19, v13, #4
    v.movi       v14, #0
    v.splat      v16, s19
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s19, #4
    a.vwrite     a1, s22, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #4
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #4
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s20, #1408
    p.and        p2, p4, p1
    v.extract    s22, v18, #5
    v.extract    s23, v7, #5
    v.splat      v5, s22
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s22, v13, #5
    v.movi       v14, #0
    v.splat      v16, s22
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s22, #5
    a.vwrite     a1, s12, v12
    v.ld.w       v3, [s18, #0]
    v.extract    s12, v20, #5
    v.movi       v5, #0
    v.splat      v8, s12
    v.extract    s12, v6, #5
    v.movi       v11, #0
    v.splat      v12, s12
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s12, s20, #1472
    p.and        p3, p4, p1
    v.extract    s18, v18, #6
    v.extract    s23, v7, #6
    v.splat      v5, s18
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s18, v13, #6
    v.movi       v14, #0
    v.splat      v16, s18
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s18, #6
    a.vwrite     a1, s19, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #6
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #6
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s20, #1536
    p.and        p2, p4, p1
    v.extract    s19, v18, #7
    v.extract    s23, v7, #7
    v.splat      v5, s19
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s19, v13, #7
    v.movi       v14, #0
    v.splat      v16, s19
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s19, #7
    a.vwrite     a1, s22, v12
    v.ld.w       v3, [s12, #0]
    v.extract    s12, v20, #7
    v.movi       v5, #0
    v.splat      v8, s12
    v.extract    s12, v6, #7
    v.movi       v11, #0
    v.splat      v12, s12
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s12, s20, #1600
    p.and        p3, p4, p1
    v.extract    s22, v18, #8
    v.extract    s23, v7, #8
    v.splat      v5, s22
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s22, v13, #8
    v.movi       v14, #0
    v.splat      v16, s22
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s22, #8
    a.vwrite     a1, s18, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #8
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #8
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s20, #1664
    p.and        p2, p4, p1
    v.extract    s18, v18, #9
    v.extract    s23, v7, #9
    v.splat      v5, s18
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s18, v13, #9
    v.movi       v14, #0
    v.splat      v16, s18
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s18, #9
    a.vwrite     a1, s19, v12
    v.ld.w       v3, [s12, #0]
    v.extract    s12, v20, #9
    v.movi       v5, #0
    v.splat      v8, s12
    v.extract    s12, v6, #9
    v.movi       v11, #0
    v.splat      v12, s12
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s12, s20, #1728
    p.and        p3, p4, p1
    v.extract    s19, v18, #10
    v.extract    s23, v7, #10
    v.splat      v5, s19
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s19, v13, #10
    v.movi       v14, #0
    v.splat      v16, s19
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s19, #10
    a.vwrite     a1, s22, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #10
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #10
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s20, #1792
    p.and        p2, p4, p1
    v.extract    s22, v18, #11
    v.extract    s23, v7, #11
    v.splat      v5, s22
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s22, v13, #11
    v.movi       v14, #0
    v.splat      v16, s22
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s22, #11
    a.vwrite     a1, s18, v12
    v.ld.w       v3, [s12, #0]
    v.extract    s12, v20, #11
    v.movi       v5, #0
    v.splat      v8, s12
    v.extract    s12, v6, #11
    v.movi       v11, #0
    v.splat      v12, s12
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s12, s20, #1856
    p.and        p3, p4, p1
    v.extract    s18, v18, #12
    v.extract    s23, v7, #12
    v.splat      v5, s18
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s18, v13, #12
    v.movi       v14, #0
    v.splat      v16, s18
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s18, #12
    a.vwrite     a1, s19, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #12
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #12
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s20, #1920
    p.and        p2, p4, p1
    v.extract    s19, v18, #13
    v.extract    s23, v7, #13
    v.splat      v5, s19
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s19, v13, #13
    v.movi       v14, #0
    v.splat      v16, s19
    v.cmp.ne     p3, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    s.movz       s19, #13
    a.vwrite     a1, s22, v12
    v.ld.w       v3, [s12, #0]
    v.extract    s12, v20, #13
    v.movi       v5, #0
    v.splat      v8, s12
    v.extract    s12, v6, #13
    v.movi       v11, #0
    v.splat      v12, s12
    v.cmp.ne     p3, v8, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    s.addi       s12, s20, #1984
    p.and        p3, p4, p1
    v.extract    s22, v18, #14
    v.extract    s23, v7, #14
    v.splat      v5, s22
    v.movi       v8, #0
    v.splat      v11, s23
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v12, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s22, v13, #14
    v.movi       v14, #0
    v.splat      v16, s22
    v.cmp.ne     p2, v5, v8
    v.cmp.ne     p4, v11, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    s.movz       s22, #14
    a.vwrite     a1, s18, v12
    v.ld.w       v3, [s3, #0]
    v.extract    s3, v20, #14
    v.movi       v5, #0
    v.splat      v8, s3
    v.extract    s3, v6, #14
    v.movi       v11, #0
    v.splat      v12, s3
    v.cmp.ne     p2, v8, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p5, p2
    s.addi       s3, s20, #2048
    p.and        p2, p4, p1
    v.extract    s18, v18, #15
    v.extract    s23, v7, #15
    v.splat      v5, s18
    v.movi       v7, #0
    v.splat      v8, s23
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s18, v13, #15
    v.movi       v12, #0
    v.splat      v13, s18
    v.cmp.ne     p3, v5, v7
    v.cmp.ne     p4, v8, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v13, v12
    p.and        p4, p5, p3
    s.movz       s18, #15
    a.vwrite     a1, s19, v11
    v.ld.w       v3, [s12, #0]
    v.extract    s12, v20, #15
    v.movi       v5, #0
    v.splat      v7, s12
    v.extract    s12, v6, #15
    v.movi       v6, #0
    v.splat      v8, s12
    v.cmp.ne     p3, v7, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v8, v6
    p.and        p4, p5, p3
    s.addi       s12, s20, #1024
    p.and        p3, p4, p1
    s.movz       s19, #192
    s.movz       s23, #0
    s.mul        s25, s24, s19
    s.mul        s19, s15, s21
    s.add        s15, s23, s27                   // the tile origin
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s2, v3]               // index is in elements (ISA sec 9.1)
    s.addi       s23, s20, #2112
    s.add        s24, s15, s25                   // the tile origin
    s.addi       s15, s20, #1024
    s.add        s25, s24, s19                   // the tile origin
    s.addi       s19, s23, #64
    v.splat      v3, s25
    s.addi       s24, s25, #1
    a.vwrite     a1, s22, v5
    v.ld.w       v5, [s3, #0]
    v.splat      v6, s24
    s.addi       s3, s20, #1024
    s.addi       s22, s25, #2
    s.addi       s24, s23, #128
    v.splat      v7, s22
    s.addi       s22, s20, #1024
    s.addi       s26, s25, #3
    v.splat      v8, s26
    s.addi       s26, s23, #192
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s2, v5]              // index is in elements (ISA sec 9.1)
    s.addi       s28, s20, #1024
    a.vwrite     a1, s18, v11
    v.ld.w       v5, [s12, #0]
    s.addi       s12, s25, #4
    s.addi       s18, s23, #256
    v.splat      v11, s12
    s.addi       s12, s20, #1024
    v.add        v12, v5, v3
    v.st.w       [s23, #0], v12
    v.ld.w       v3, [s15, #0]
    s.addi       s15, s25, #5
    v.splat      v5, s15
    s.addi       s15, s23, #320
    v.add        v12, v3, v6
    v.st.w       [s19, #0], v12
    s.addi       s19, s20, #1024
    v.ld.w       v3, [s3, #0]
    s.addi       s3, s25, #6
    v.splat      v6, s3
    s.addi       s3, s23, #384
    v.add        v12, v3, v7
    v.st.w       [s24, #0], v12
    s.addi       s24, s20, #1024
    v.ld.w       v3, [s22, #0]
    s.addi       s22, s25, #7
    v.splat      v7, s22
    s.addi       s22, s23, #448
    v.add        v12, v3, v8
    v.st.w       [s26, #0], v12
    s.addi       s26, s20, #1024
    v.ld.w       v3, [s28, #0]
    s.addi       s28, s25, #8
    v.splat      v8, s28
    s.addi       s28, s23, #512
    v.add        v12, v3, v11
    v.st.w       [s18, #0], v12
    s.addi       s18, s20, #1024
    v.ld.w       v3, [s12, #0]
    s.addi       s12, s25, #9
    v.splat      v11, s12
    s.addi       s12, s23, #576
    v.add        v12, v3, v5
    v.st.w       [s15, #0], v12
    s.addi       s15, s20, #1024
    v.ld.w       v3, [s19, #0]
    s.addi       s19, s25, #10
    v.splat      v5, s19
    s.addi       s19, s23, #640
    v.add        v12, v3, v6
    v.st.w       [s3, #0], v12
    s.addi       s3, s20, #1024
    v.ld.w       v3, [s24, #0]
    s.addi       s24, s25, #11
    v.splat      v6, s24
    s.addi       s24, s23, #704
    v.add        v12, v3, v7
    v.st.w       [s22, #0], v12
    s.addi       s22, s20, #1024
    v.ld.w       v3, [s26, #0]
    s.addi       s26, s25, #12
    v.splat      v7, s26
    s.addi       s26, s23, #768
    v.add        v12, v3, v8
    v.st.w       [s28, #0], v12
    s.addi       s28, s20, #1024
    v.ld.w       v3, [s18, #0]
    s.addi       s18, s25, #13
    v.splat      v8, s18
    s.addi       s18, s23, #832
    v.add        v12, v3, v11
    v.st.w       [s12, #0], v12
    s.addi       s12, s20, #1024
    v.splat      v3, s21
    v.ld.w       v11, [s15, #0]
    s.addi       s15, s25, #14
    s.addi       s29, s25, #15
    v.splat      v12, s15
    s.addi       s15, s23, #896
    v.splat      v13, s29
    s.addi       s25, s20, #1024
    s.addi       s29, s23, #960
    v.add        v14, v11, v5
    v.st.w       [s19, #0], v14
    s.addi       s19, s20, #2112
    v.splat      v5, s21
    s.movz       s21, #0
    s.add        s23, s21, s11                   // the tile origin
    v.splat      v11, s23
    s.movz       s21, #0
    s.add        s23, s21, s27                   // the tile origin
    v.add        v14, v15, v11
    v.splat      v11, s23
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s21, #0
    v.cmp.lt     p1, v14, v5
    v.cmp.lt     p2, v11, v3
    v.ld.w       v5, [s3, #0]
    p.and        p3, p2, p1
    v.add        v11, v5, v6
    s.movz       s3, #1
    v.st.w       [s24, #0], v11
    s.addi       s24, s20, #2176
    v.ld.w       v5, [s22, #0]
    s.addi       s22, s23, #1
    v.splat      v6, s22
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    v.add        v6, v5, v7
    v.st.w       [s26, #0], v6
    s.addi       s22, s20, #2240
    s.movz       s26, #2
    v.ld.w       v5, [s28, #0]
    s.addi       s27, s23, #2
    v.splat      v6, s27
    v.add        v7, v5, v8
    v.cmp.lt     p2, v6, v3
    v.st.w       [s18, #0], v7
    p.and        p5, p2, p1
    v.ld.w       v5, [s12, #0]
    s.addi       s12, s20, #2304
    s.movz       s18, #3
    v.add        v6, v5, v12
    s.addi       s27, s23, #3
    v.st.w       [s15, #0], v6
    v.splat      v5, s27
    v.ld.w       v6, [s25, #0]
    s.movz       s15, #4
    v.add        v7, v6, v13
    s.addi       s25, s20, #2368
    v.st.w       [s29, #0], v7
    fence.acq_rel.device
    s.addi       s27, s23, #4
    v.splat      v6, s27
    v.ld.w       v7, [s19, #0]
    s.addi       s19, s20, #2432
    s.addi       s27, s23, #5
    s.movz       s28, #5
    v.splat      v8, s27
    s.movz       s27, #6
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s5, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s21, v11
    v.ld.w       v5, [s24, #0]
    s.addi       s21, s20, #2496
    s.addi       s24, s23, #6
    v.splat      v7, s24
    s.movz       s24, #7
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    a.vwrite     a2, s3, v11
    v.ld.w       v5, [s22, #0]
    s.addi       s3, s20, #2560
    s.addi       s22, s23, #7
    v.splat      v6, s22
    s.movz       s22, #8
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v3
    p.and        p5, p2, p1
    a.vwrite     a2, s26, v11
    v.ld.w       v5, [s12, #0]
    s.addi       s12, s20, #2624
    s.addi       s26, s23, #8
    v.splat      v8, s26
    s.movz       s26, #9
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s18, v11
    v.ld.w       v5, [s25, #0]
    s.addi       s18, s20, #2688
    s.addi       s25, s23, #9
    v.splat      v7, s25
    s.movz       s25, #10
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    a.vwrite     a2, s15, v11
    v.ld.w       v5, [s19, #0]
    s.addi       s15, s20, #2752
    s.addi       s19, s23, #10
    v.splat      v6, s19
    s.movz       s19, #11
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v3
    p.and        p5, p2, p1
    a.vwrite     a2, s28, v11
    v.ld.w       v5, [s21, #0]
    s.addi       s21, s20, #2816
    s.addi       s28, s23, #11
    v.splat      v8, s28
    s.movz       s28, #12
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s27, v11
    v.ld.w       v5, [s3, #0]
    s.addi       s3, s20, #2880
    s.addi       s27, s23, #12
    v.splat      v7, s27
    s.movz       s27, #13
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    a.vwrite     a2, s24, v11
    v.ld.w       v5, [s12, #0]
    s.addi       s12, s20, #2944
    s.addi       s24, s23, #13
    v.splat      v6, s24
    s.movz       s24, #14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v3
    p.and        p5, p2, p1
    a.vwrite     a2, s22, v11
    v.ld.w       v5, [s18, #0]
    s.addi       s18, s20, #3008
    s.addi       s22, s23, #14
    v.splat      v8, s22
    s.movz       s22, #15
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s26, v11
    v.ld.w       v5, [s15, #0]
    s.addi       s15, s20, #3072
    s.addi       s26, s23, #15
    v.movi       v7, #0
    v.splat      v11, s26
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v12, [s5, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s23, #0
    a.vwrite     a2, s25, v12
    v.ld.w       v5, [s21, #0]
    s.movz       s21, #0
    s.movz       s25, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v6, [s5, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v3
    p.and        p5, p2, p1
    a.vwrite     a2, s19, v6
    v.ld.w       v5, [s3, #0]
    s.movz       s3, #1
    s.movz       s19, #2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s5, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v11, v3
    p.and        p3, p2, p1
    a.vwrite     a2, s28, v6
    v.ld.w       v3, [s12, #0]
    s.movz       s12, #3
    s.movz       s26, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v5, [s5, v3]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s27, v5
    v.ld.w       v3, [s18, #0]
    s.movz       s18, #5
    s.movz       s27, #6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v5, [s5, v3]               // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s24, v5
    v.ld.w       v3, [s15, #0]
    s.movz       s15, #7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v5, [s5, v3]               // index is in elements (ISA sec 9.1)
    s.movz       s24, #8
    a.vwrite     a2, s22, v5
    a.vread      v3, a1, s21
    a.vread      v5, a2, s25
    a.vread      v6, a2, s3
    v.extract    s3, v3, #0
    v.extract    s21, v3, #1
    v.splat      v8, s3
    v.splat      v11, s21
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s19
    v.extract    s3, v3, #3
    a.vread      v13, a2, s12
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s26
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s18
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s27
    v.extract    s3, v3, #7
    a.vread      v15, a2, s15
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s24
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #1
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s24, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s25, #7
    s.movz       s26, #8
    s.movz       s27, #1
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s23, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s24
    v.extract    s3, v3, #7
    a.vread      v15, a2, s25
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s26
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #2
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s26, #2
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #3
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s27, #3
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s26, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #4
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s26, #4
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #5
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s27, #5
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s26, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #6
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s26, #6
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #7
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s27, #7
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s26, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #8
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s26, #8
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #9
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s27, #9
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s26, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #10
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s26, #10
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #11
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s27, #11
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s26, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #12
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s26, #12
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #13
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s27, #13
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s26, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #14
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s26, #14
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s27, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v8, a2, s18
    v.extract    s3, v3, #3
    a.vread      v13, a2, s19
    vf.fma       v14, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v15, v5, v8, v14
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v8, s3
    v.extract    s3, v3, #6
    vf.fma       v14, v6, v13, v15
    v.splat      v6, s3
    a.vread      v13, a2, s23
    v.extract    s3, v3, #7
    a.vread      v15, a2, s24
    vf.fma       v16, v12, v11, v14
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v14, s3
    vf.fma       v17, v8, v5, v16
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v15, a2, s12
    vf.fma       v16, v14, v12, v17
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v14, a2, s12
    vf.fma       v17, v5, v8, v16
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v6, v13, v17
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v13, a2, s12
    vf.fma       v17, v11, v15, v16
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v15, v12, v14, v17
    s.movz       s3, #15
    s.movz       s12, #0
    s.movz       s15, #1
    s.movz       s18, #2
    vf.fma       v12, v5, v8, v15
    s.movz       s19, #3
    s.movz       s21, #4
    s.movz       s22, #5
    s.movz       s23, #6
    vf.fma       v5, v6, v13, v12
    s.movz       s24, #7
    s.movz       s25, #8
    s.movz       s27, #15
    vf.fma       v6, v3, v11, v5
    a.vwrite     a3, s26, v6
    a.vread      v3, a1, s3
    a.vread      v5, a2, s12
    a.vread      v6, a2, s15
    v.extract    s3, v3, #0
    v.extract    s12, v3, #1
    v.splat      v8, s3
    v.splat      v11, s12
    v.extract    s3, v3, #2
    vf.fma       v12, v8, v5, v7
    v.splat      v5, s3
    a.vread      v7, a2, s18
    v.extract    s3, v3, #3
    a.vread      v8, a2, s19
    vf.fma       v13, v11, v6, v12
    v.splat      v6, s3
    v.extract    s3, v3, #4
    a.vread      v11, a2, s21
    v.splat      v12, s3
    vf.fma       v14, v5, v7, v13
    v.extract    s3, v3, #5
    a.vread      v5, a2, s22
    v.splat      v7, s3
    v.extract    s3, v3, #6
    vf.fma       v13, v6, v8, v14
    v.splat      v6, s3
    a.vread      v8, a2, s23
    v.extract    s3, v3, #7
    a.vread      v14, a2, s24
    vf.fma       v15, v12, v11, v13
    v.splat      v11, s3
    v.extract    s3, v3, #8
    a.vread      v12, a2, s25
    v.splat      v13, s3
    vf.fma       v16, v7, v5, v15
    v.extract    s3, v3, #9
    s.movz       s12, #9
    v.splat      v5, s3
    a.vread      v7, a2, s12
    vf.fma       v15, v6, v8, v16
    v.extract    s3, v3, #10
    s.movz       s12, #10
    v.splat      v6, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v11, v14, v15
    v.extract    s3, v3, #11
    s.movz       s12, #11
    v.splat      v11, s3
    a.vread      v14, a2, s12
    vf.fma       v15, v13, v12, v16
    v.extract    s3, v3, #12
    s.movz       s12, #12
    v.splat      v12, s3
    a.vread      v13, a2, s12
    vf.fma       v16, v5, v7, v15
    v.extract    s3, v3, #13
    s.movz       s12, #13
    v.splat      v5, s3
    a.vread      v7, a2, s12
    vf.fma       v15, v6, v8, v16
    v.extract    s3, v3, #14
    s.movz       s12, #14
    v.splat      v6, s3
    a.vread      v8, a2, s12
    vf.fma       v16, v11, v14, v15
    v.extract    s3, v3, #15
    s.movz       s12, #15
    v.splat      v3, s3
    a.vread      v11, a2, s12
    vf.fma       v14, v12, v13, v16
    s.movz       s3, #0
    s.movz       s12, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s15, #0
    s.movz       s18, #1
    vf.fma       v12, v5, v7, v14
    s.movz       s19, #1
    s.movz       s21, #1
    s.movz       s22, #2
    s.movz       s23, #2
    vf.fma       v5, v6, v8, v12
    s.movz       s24, #2
    s.movz       s25, #3
    s.movz       s26, #3
    s.movz       s28, #3
    vf.fma       v6, v3, v11, v5
    s.movz       s29, #4
    a.vwrite     a3, s27, v6
    a.vread      v3, a0, s3
    a.vread      v5, a3, s12
    s.movz       s3, #4
    s.movz       s12, #4
    vf.add       v6, v3, v5
    s.movz       s27, #5
    a.vwrite     a4, s15, v6
    a.vread      v3, a0, s18
    a.vread      v5, a3, s19
    s.movz       s15, #5
    s.movz       s18, #5
    vf.add       v6, v3, v5
    s.movz       s19, #6
    a.vwrite     a4, s21, v6
    a.vread      v3, a0, s22
    a.vread      v5, a3, s23
    s.movz       s21, #6
    s.movz       s22, #6
    vf.add       v6, v3, v5
    s.movz       s23, #7
    a.vwrite     a4, s24, v6
    a.vread      v3, a0, s25
    a.vread      v5, a3, s26
    s.movz       s24, #7
    s.movz       s25, #7
    vf.add       v6, v3, v5
    s.movz       s26, #8
    a.vwrite     a4, s28, v6
    a.vread      v3, a0, s29
    a.vread      v5, a3, s3
    s.movz       s3, #8
    s.movz       s28, #8
    vf.add       v6, v3, v5
    s.movz       s29, #9
    a.vwrite     a4, s12, v6
    a.vread      v3, a0, s27
    a.vread      v5, a3, s15
    s.movz       s12, #9
    s.movz       s15, #9
    vf.add       v6, v3, v5
    s.movz       s27, #10
    a.vwrite     a4, s18, v6
    a.vread      v3, a0, s19
    a.vread      v5, a3, s21
    s.movz       s18, #10
    s.movz       s19, #10
    vf.add       v6, v3, v5
    s.movz       s21, #11
    a.vwrite     a4, s22, v6
    a.vread      v3, a0, s23
    a.vread      v5, a3, s24
    s.movz       s22, #11
    s.movz       s23, #11
    vf.add       v6, v3, v5
    s.movz       s24, #12
    a.vwrite     a4, s25, v6
    a.vread      v3, a0, s26
    a.vread      v5, a3, s3
    s.movz       s3, #12
    s.movz       s25, #12
    vf.add       v6, v3, v5
    s.movz       s26, #13
    a.vwrite     a4, s28, v6
    a.vread      v3, a0, s29
    a.vread      v5, a3, s12
    s.movz       s12, #13
    s.movz       s28, #13
    vf.add       v6, v3, v5
    s.movz       s29, #14
    a.vwrite     a4, s15, v6
    a.vread      v3, a0, s27
    a.vread      v5, a3, s18
    s.movz       s15, #14
    s.movz       s18, #14
    vf.add       v6, v3, v5
    s.movz       s27, #15
    a.vwrite     a4, s19, v6
    a.vread      v3, a0, s21
    a.vread      v5, a3, s22
    s.movz       s19, #15
    s.movz       s21, #15
    vf.add       v6, v3, v5
    s.movz       s22, #0
    a.vwrite     a4, s23, v6
    a.vread      v3, a0, s24
    a.vread      v5, a3, s3
    s.movz       s3, #0
    s.movz       s23, #1
    vf.add       v6, v3, v5
    s.movz       s24, #1
    a.vwrite     a4, s25, v6
    a.vread      v3, a0, s26
    a.vread      v5, a3, s12
    s.movz       s12, #2
    s.movz       s25, #2
    vf.add       v6, v3, v5
    s.movz       s26, #3
    a.vwrite     a4, s28, v6
    a.vread      v3, a0, s29
    a.vread      v5, a3, s15
    s.movz       s15, #3
    s.movz       s28, #4
    vf.add       v6, v3, v5
    s.movz       s29, #4
    a.vwrite     a4, s18, v6
    a.vread      v3, a0, s27
    a.vread      v5, a3, s19
    s.movz       s18, #5
    s.movz       s19, #5
    vf.add       v6, v3, v5
    s.movz       s27, #6
    a.vwrite     a4, s21, v6
    a.vread      v3, a4, s22
    s.movz       s21, #6
    s.movz       s22, #7
    a.vwrite     a0, s3, v3
    a.vread      v3, a4, s23
    s.movz       s3, #7
    s.movz       s23, #8
    a.vwrite     a0, s24, v3
    a.vread      v3, a4, s12
    s.movz       s12, #8
    s.movz       s24, #9
    a.vwrite     a0, s25, v3
    a.vread      v3, a4, s26
    s.movz       s25, #9
    s.movz       s26, #10
    a.vwrite     a0, s15, v3
    a.vread      v3, a4, s28
    s.movz       s15, #10
    s.movz       s28, #11
    a.vwrite     a0, s29, v3
    a.vread      v3, a4, s18
    s.movz       s18, #11
    s.movz       s29, #12
    a.vwrite     a0, s19, v3
    a.vread      v3, a4, s27
    s.movz       s19, #12
    s.movz       s27, #13
    a.vwrite     a0, s21, v3
    a.vread      v3, a4, s22
    s.movz       s21, #13
    s.movz       s22, #14
    a.vwrite     a0, s3, v3
    a.vread      v3, a4, s23
    s.movz       s3, #14
    s.movz       s23, #15
    a.vwrite     a0, s12, v3
    a.vread      v3, a4, s24
    s.movz       s12, #15
    s.add        s24, s17, s16
    a.vwrite     a0, s25, v3
    a.vread      v3, a4, s26
    s.movz       s25, #1
    a.vwrite     a0, s15, v3
    a.vread      v3, a4, s28
    a.vwrite     a0, s18, v3
    a.vread      v3, a4, s29
    a.vwrite     a0, s19, v3
    a.vread      v3, a4, s27
    a.vwrite     a0, s21, v3
    a.vread      v3, a4, s22
    a.vwrite     a0, s3, v3
    a.vread      v3, a4, s23
    a.vwrite     a0, s12, v3
    s.mov        s17, s24
    br.nz        s25, for_5
endfor_6:
    s.muli       s1, s11, #3136                  // a runtime tile origin, x3136
    v.extract    s2, v10, #0
    s.movz       s3, #56
    s.movz       s5, #3136
    s.movz       s12, #0
    v.splat      v0, s2
    v.splat      v3, s3
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s5
    v.extract    s2, v9, #0
    s.add        s3, s12, s1                     // the tile origin
    v.splat      v7, s2
    v.mul        v8, v0, v3
    v.mul        v0, v5, v6
    v.splat      v5, s3
    v.add        v6, v7, v8
    s.movz       s1, #0
    s.muli       s2, s11, #4                     // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s3, s11, #4                     // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s5, s11, #4                     // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s12, s11, #4                    // a runtime tile origin, x4
    s.add        s13, s1, s11                    // the tile origin
    v.movi       v7, #8
    v.add        v8, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.movi       v11, #1
    v.movi       v12, #0
    v.movi       v13, #1
    v.movi       v14, #0
    v.movi       v15, #64
    v.iota       v16                             // arange(0, VLEN)
    v.splat      v17, s13
    v.cmp.lt     p1, v4, v7
    v.extract    s1, v4, #0
    v.add        v7, v6, v8
    v.splat      v6, s1
    v.cmp.lt     p2, v10, v1
    v.cmp.lt     p3, v9, v1
    @p1 v.sel        v1, v0, v5
    v.splat      v0, s14
    s.movz       s1, #3136
    @p2 v.sel        v5, v11, v12
    v.mul        v11, v6, v0
    v.splat      v6, s1
    v.movi       v12, #0
    v.add        v18, v7, v11
    @p3 v.sel        v7, v13, v14
    v.cmp.lt     p1, v6, v12
    v.sub        v11, v12, v18
    v.cmp.lt     p2, v18, v12
    v.cmp.lt     p3, v2, v15
    v.sub        v2, v12, v6
    s.add        s1, s6, s2                      // the tile origin
    s.add        s2, s7, s3                      // the tile origin
    s.add        s3, s8, s5                      // the tile origin
    s.add        s5, s9, s12                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    .li       s6, #925353388
    v.splat      v13, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v14, #0
    s.addi       s6, s20, #3136
    v.splat      v15, s4
    v.add        v19, v16, v17
    v.movi       v16, #1
    @p2 v.sel        v17, v11, v18
    @p1 v.sel        v11, v2, v6
    v.movi       v2, #0
    v.movi       v18, #0
    s.movz       s4, #31
idiv_7:
    v.splat      v20, s4
    v.shl        v21, v18, v16
    v.cmp.lt     p1, v18, v12
    v.lshr       v22, v17, v20
    v.shl        v23, v16, v20
    s.subi       s7, s4, #1
    v.and        v20, v22, v16
    s.movz       s8, #0
    v.or         v22, v21, v20
    v.cmp.geu    p4, v22, v11
    p.or         p5, p1, p4
    v.sub        v20, v22, v11
    @p5 v.sel        v21, v23, v12
    @p5 v.sel        v23, v20, v22
    v.or         v20, v2, v21
    v.mov        v18, v23
    v.mov        v2, v20
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s8
    br.nz        s7, idiv_7
    v.extract    s4, v10, #1
    v.sub        v2, v12, v18
    v.splat      v11, s4
    s.movz       s4, #64
    v.extract    s7, v9, #1
    @p2 v.sel        v12, v2, v18
    v.splat      v2, s4
    v.splat      v16, s7
    v.mul        v17, v11, v3
    v.extract    s4, v4, #0
    v.extract    s7, v4, #1
    v.mul        v11, v12, v2
    v.splat      v12, s4
    v.add        v18, v16, v17
    v.splat      v16, s7
    v.add        v17, v19, v11
    v.mul        v11, v12, v0
    v.add        v12, v18, v8
    v.mul        v18, v16, v0
    v.add        v16, v17, v11
    v.movi       v11, #0
    v.add        v17, v12, v18
    v.add        v12, v15, v16
    v.sub        v16, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s6, #0], v12
    s.addi       s4, s6, #64
    v.movi       v12, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v16, v6
    v.movi       v16, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_8:
    v.splat      v21, s7
    v.shl        v22, v18, v12
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v12, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v12
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v16, v22
    v.mov        v18, v24
    v.mov        v16, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_8
    v.extract    s7, v10, #2
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #2
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #1
    v.extract    s8, v4, #2
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #128
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_9:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_9
    v.extract    s7, v10, #3
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #3
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #2
    v.extract    s8, v4, #3
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #192
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_10:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_10
    v.extract    s7, v10, #4
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #4
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #3
    v.extract    s8, v4, #4
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #256
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_11:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_11
    v.extract    s7, v10, #5
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #5
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #4
    v.extract    s8, v4, #5
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #320
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_12:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_12
    v.extract    s7, v10, #6
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #6
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #5
    v.extract    s8, v4, #6
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #384
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_13:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_13
    v.extract    s7, v10, #7
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #7
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #6
    v.extract    s8, v4, #7
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #448
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_14:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_14
    v.extract    s7, v10, #8
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #8
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #7
    v.extract    s8, v4, #8
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #512
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_15:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_15
    v.extract    s7, v10, #9
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #9
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #8
    v.extract    s8, v4, #9
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #576
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_16:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_16
    v.extract    s7, v10, #10
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #10
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #9
    v.extract    s8, v4, #10
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #640
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_17:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_17
    v.extract    s7, v10, #11
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #11
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #10
    v.extract    s8, v4, #11
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #704
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_18:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_18
    v.extract    s7, v10, #12
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #12
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #11
    v.extract    s8, v4, #12
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #768
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_19:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_19
    v.extract    s7, v10, #13
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #13
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #12
    v.extract    s8, v4, #13
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #832
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_20:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_20
    v.extract    s7, v10, #14
    v.sub        v12, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #14
    @p1 v.sel        v16, v12, v18
    v.splat      v12, s7
    v.mul        v17, v11, v3
    v.extract    s7, v4, #13
    v.extract    s8, v4, #14
    v.mul        v11, v16, v2
    v.splat      v16, s7
    v.add        v18, v12, v17
    v.splat      v12, s8
    v.add        v17, v19, v11
    v.mul        v11, v16, v0
    v.add        v16, v18, v8
    v.mul        v18, v12, v0
    v.add        v12, v17, v11
    v.movi       v11, #0
    v.add        v17, v16, v18
    v.add        v16, v15, v12
    v.sub        v12, v11, v6
    v.sub        v18, v11, v17
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v6, v11
    v.st.w       [s4, #0], v16
    s.addi       s4, s6, #896
    v.movi       v16, #1
    @p1 v.sel        v20, v18, v17
    @p2 v.sel        v17, v12, v6
    v.movi       v12, #0
    v.movi       v18, #0
    s.movz       s7, #31
idiv_21:
    v.splat      v21, s7
    v.shl        v22, v18, v16
    v.cmp.lt     p2, v18, v11
    v.lshr       v23, v20, v21
    v.shl        v24, v16, v21
    s.subi       s8, s7, #1
    v.and        v21, v23, v16
    s.movz       s9, #0
    v.or         v23, v22, v21
    v.cmp.geu    p4, v23, v17
    p.or         p5, p2, p4
    v.sub        v21, v23, v17
    @p5 v.sel        v22, v24, v11
    @p5 v.sel        v24, v21, v23
    v.or         v21, v12, v22
    v.mov        v18, v24
    v.mov        v12, v21
    s.mov        s7, s8
    s.cmp.ge     s8, s7, s9
    br.nz        s8, idiv_21
    v.extract    s7, v10, #15
    v.sub        v10, v11, v18
    v.splat      v11, s7
    v.extract    s7, v9, #15
    @p1 v.sel        v9, v10, v18
    v.splat      v10, s7
    v.mul        v12, v11, v3
    v.extract    s7, v4, #14
    v.extract    s8, v4, #15
    v.mul        v3, v9, v2
    v.splat      v9, s7
    v.add        v11, v10, v12
    v.splat      v10, s8
    v.add        v12, v19, v3
    v.mul        v3, v9, v0
    v.add        v9, v11, v8
    v.mul        v8, v10, v0
    v.add        v10, v12, v3
    v.movi       v3, #0
    v.add        v11, v9, v8
    v.add        v8, v15, v10
    v.sub        v9, v3, v6
    v.sub        v10, v3, v11
    v.cmp.lt     p1, v11, v3
    v.cmp.lt     p2, v6, v3
    v.st.w       [s4, #0], v8
    s.addi       s4, s6, #960
    v.movi       v8, #1
    @p1 v.sel        v12, v10, v11
    @p2 v.sel        v10, v9, v6
    v.movi       v6, #0
    v.movi       v9, #0
    s.movz       s6, #31
idiv_22:
    v.splat      v11, s6
    v.shl        v16, v9, v8
    v.cmp.lt     p2, v9, v3
    v.lshr       v17, v12, v11
    v.shl        v18, v8, v11
    s.subi       s7, s6, #1
    v.and        v11, v17, v8
    s.movz       s8, #0
    v.or         v17, v16, v11
    v.cmp.geu    p4, v17, v10
    p.or         p5, p2, p4
    v.sub        v11, v17, v10
    @p5 v.sel        v16, v18, v3
    @p5 v.sel        v18, v11, v17
    v.or         v11, v6, v16
    v.mov        v9, v18
    v.mov        v6, v11
    s.mov        s6, s7
    s.cmp.ge     s7, s6, s8
    br.nz        s7, idiv_22
    v.sub        v6, v3, v9
    v.extract    s6, v4, #15
    v.extract    s7, v1, #0
    @p1 v.sel        v3, v6, v9
    v.splat      v4, s6
    v.extract    s6, v5, #0
    v.mul        v6, v3, v2
    v.splat      v2, s7
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s6, v7, #0
    v.add        v10, v19, v6
    v.mul        v6, v4, v0
    v.splat      v0, s6
    v.movi       v4, #0
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p2, v8, v9
    v.add        v2, v10, v6
    p.and        p4, p1, p2
    v.cmp.ne     p1, v0, v4
    p.and        p2, p4, p1
    v.add        v0, v15, v2
    s.movz       s6, #0
    p.and        p1, p2, p3
    v.st.w       [s4, #0], v0
    fence.acq_rel.device
    a.vread      v0, a0, s6
    v.extract    s4, v1, #0
    v.extract    s6, v5, #0
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v4, s6
    v.movi       v6, #0
    v.extract    s4, v7, #0
    v.movi       v8, #0
    v.splat      v9, s4
    v.cmp.ne     p2, v2, v3
    v.cmp.ne     p4, v4, v6
    p.and        p5, p2, p4
    v.cmp.ne     p2, v9, v8
    p.and        p4, p5, p2
    v.extract    s4, v1, #0
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s2, #0]
    p.and        p1, p4, p3
    v.extract    s6, v5, #0
    v.splat      v3, s4
    v.movi       v4, #0
    v.splat      v6, s6
    v.movi       v8, #0
    v.extract    s4, v7, #0
    v.movi       v9, #0
    v.splat      v10, s4
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p4, v6, v8
    v.extract    s4, v1, #0
    p.and        p5, p2, p4
    v.cmp.ne     p2, v10, v9
    v.splat      v3, s4
    .li       s4, #1077936128
    v.splat      v4, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #3204448256
    v.splat      v6, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v8, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.movi       v9, #0
    p.and        p1, p5, p2
    v.rsqrt.approx v10, v8                       // ISA 8.8: <= 2**-22 relative
    p.and        p2, p1, p3
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v11, [s3, #0]
    vf.sub       v12, v0, v2
    v.extract    s4, v5, #0
    v.movi       v0, #0
    v.splat      v2, s4
    v.extract    s4, v7, #0
    v.movi       v15, #0
    v.cmp.ne     p1, v3, v9
    v.splat      v3, s4
    v.cmp.ne     p2, v2, v0
    p.and        p4, p1, p2
    v.cmp.ne     p1, v3, v15
    p.and        p2, p4, p1
    s.addi       s4, s20, #3136
    vf.mul       v0, v10, v10
    vf.mul       v2, v10, v6
    p.and        p1, p2, p3
    v.extract    s6, v1, #0
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v3, [s5, #0]
    vf.fms       v9, v8, v0, v4
    v.extract    s7, v5, #0
    v.splat      v0, s6
    v.movi       v8, #0
    v.splat      v15, s7
    vf.mul       v16, v2, v9                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v15, v2
    vf.cmp.o     p4, v16, v16
    @p4 v.sel        v0, v16, v10
    v.extract    s6, v7, #0
    p.and        p4, p1, p2
    vf.mul       v2, v12, v0
    v.splat      v0, s6
    v.movi       v8, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #1
    vf.mul       v10, v2, v11
    v.extract    s6, v1, #1
    v.extract    s7, v5, #1
    v.splat      v2, s6
    v.movi       v11, #0
    vf.add       v12, v10, v3
    v.splat      v3, s7
    v.movi       v10, #0
    v.extract    s6, v7, #1
    v.cmp.ne     p1, v2, v11
    v.cmp.ne     p2, v3, v10
    p.and        p5, p1, p2
    vf.max.prop  v2, v12, v14
    v.splat      v3, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v0, v8
    p.and        p2, p4, p1
    v.cmp.ne     p1, v3, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v2
    a.vread      v0, a0, s4
    v.extract    s4, v1, #1
    v.extract    s6, v5, #1
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #1
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #1
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #1
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #1
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #1
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #1
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #1
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3200
    p.and        p1, p2, p3
    v.extract    s6, v1, #1
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #1
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #1
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #2
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #2
    v.extract    s7, v5, #2
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #2
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #2
    v.extract    s6, v5, #2
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #2
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #2
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #2
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #2
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #2
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #2
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #2
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3264
    p.and        p1, p2, p3
    v.extract    s6, v1, #2
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #2
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #2
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #3
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #3
    v.extract    s7, v5, #3
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #3
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #3
    v.extract    s6, v5, #3
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #3
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #3
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #3
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #3
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #3
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #3
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3328
    p.and        p1, p2, p3
    v.extract    s6, v1, #3
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #3
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #3
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #4
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #4
    v.extract    s7, v5, #4
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #4
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #4
    v.extract    s6, v5, #4
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #4
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #4
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #4
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #4
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #4
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #4
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #4
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3392
    p.and        p1, p2, p3
    v.extract    s6, v1, #4
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #4
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #4
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #5
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #5
    v.extract    s7, v5, #5
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #5
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #5
    v.extract    s6, v5, #5
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #5
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #5
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #5
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #5
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #5
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #5
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #5
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3456
    p.and        p1, p2, p3
    v.extract    s6, v1, #5
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #5
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #5
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #6
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #6
    v.extract    s7, v5, #6
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #6
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #6
    v.extract    s6, v5, #6
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #6
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #6
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #6
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #6
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #6
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #6
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #6
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3520
    p.and        p1, p2, p3
    v.extract    s6, v1, #6
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #6
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #6
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #7
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #7
    v.extract    s7, v5, #7
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #7
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #7
    v.extract    s6, v5, #7
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #7
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #7
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #7
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #7
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #7
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #7
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #7
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3584
    p.and        p1, p2, p3
    v.extract    s6, v1, #7
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #7
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #7
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #8
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #8
    v.extract    s7, v5, #8
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #8
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #8
    v.extract    s6, v5, #8
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #8
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #8
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #8
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #8
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #8
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #8
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #8
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3648
    p.and        p1, p2, p3
    v.extract    s6, v1, #8
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #8
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #8
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #9
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #9
    v.extract    s7, v5, #9
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #9
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #9
    v.extract    s6, v5, #9
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #9
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #9
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #9
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #9
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #9
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #9
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #9
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3712
    p.and        p1, p2, p3
    v.extract    s6, v1, #9
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #9
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #9
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #10
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #10
    v.extract    s7, v5, #10
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #10
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #10
    v.extract    s6, v5, #10
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #10
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #10
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #10
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #10
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #10
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #10
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #10
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3776
    p.and        p1, p2, p3
    v.extract    s6, v1, #10
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #10
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #10
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #11
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #11
    v.extract    s7, v5, #11
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #11
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #11
    v.extract    s6, v5, #11
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #11
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #11
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #11
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #11
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #11
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #11
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #11
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3840
    p.and        p1, p2, p3
    v.extract    s6, v1, #11
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #11
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #11
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #12
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #12
    v.extract    s7, v5, #12
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #12
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #12
    v.extract    s6, v5, #12
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #12
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #12
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #12
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #12
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #12
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #12
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #12
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3904
    p.and        p1, p2, p3
    v.extract    s6, v1, #12
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #12
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #12
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #13
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #13
    v.extract    s7, v5, #13
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #13
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #13
    v.extract    s6, v5, #13
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #13
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #13
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #13
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #13
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #13
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #13
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #13
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #3968
    p.and        p1, p2, p3
    v.extract    s6, v1, #13
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #13
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #13
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #14
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #14
    v.extract    s7, v5, #14
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #14
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #14
    v.extract    s6, v5, #14
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #14
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #14
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s6, v5, #14
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s6
    v.movi       v10, #0
    v.extract    s4, v7, #14
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s4, v1, #14
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s4
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s4, v5, #14
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s4
    v.movi       v2, #0
    v.extract    s4, v7, #14
    v.movi       v11, #0
    v.splat      v12, s4
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s4, s20, #4032
    p.and        p1, p2, p3
    v.extract    s6, v1, #14
    vf.mul       v0, v3, v3
    vf.mul       v2, v3, v6
    v.extract    s7, v5, #14
    v.splat      v11, s6
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v12, [s5, #0]
    vf.fms       v15, v9, v0, v4
    v.movi       v0, #0
    v.splat      v9, s7
    v.cmp.ne     p1, v11, v0
    vf.mul       v0, v2, v15                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v2, #0
    v.cmp.ne     p2, v9, v2
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v2, v0, v3
    v.extract    s6, v7, #14
    p.and        p4, p1, p2
    vf.mul       v0, v10, v2
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v9, [s4, #0]
    s.movz       s4, #15
    vf.mul       v10, v0, v8
    v.extract    s6, v1, #15
    v.extract    s7, v5, #15
    v.splat      v0, s6
    v.movi       v8, #0
    vf.add       v11, v10, v12
    v.splat      v10, s7
    v.movi       v12, #0
    v.extract    s6, v7, #15
    v.cmp.ne     p1, v0, v8
    v.cmp.ne     p2, v10, v12
    p.and        p5, p1, p2
    vf.max.prop  v0, v11, v14
    v.splat      v8, s6
    v.movi       v10, #0
    v.cmp.ne     p1, v2, v3
    p.and        p2, p4, p1
    v.cmp.ne     p1, v8, v10
    p.and        p4, p5, p1
    p.and        p1, p2, p3
    p.and        p2, p4, p3
    @p1 v.st.scatter.w [s10, v9], v0
    a.vread      v0, a0, s4
    v.extract    s4, v1, #15
    v.extract    s6, v5, #15
    v.splat      v2, s4
    v.movi       v3, #0
    v.splat      v8, s6
    v.movi       v9, #0
    v.extract    s4, v7, #15
    v.movi       v10, #0
    v.splat      v11, s4
    v.cmp.ne     p1, v2, v3
    v.cmp.ne     p4, v8, v9
    p.and        p5, p1, p4
    v.cmp.ne     p1, v11, v10
    p.and        p4, p5, p1
    v.extract    s4, v1, #15
    p.and        p1, p4, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.extract    s2, v5, #15
    v.splat      v3, s4
    v.movi       v8, #0
    v.splat      v9, s2
    v.movi       v10, #0
    v.extract    s2, v7, #15
    v.movi       v11, #0
    v.splat      v12, s2
    v.cmp.ne     p2, v3, v8
    v.cmp.ne     p4, v9, v10
    v.extract    s2, v1, #15
    p.and        p5, p2, p4
    v.cmp.ne     p2, v12, v11
    v.splat      v3, s2
    v.movi       v8, #0
    p.and        p4, p5, p2
    vf.add       v9, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v2, [s1, #0]
    v.extract    s1, v5, #15
    p.and        p1, p4, p3
    v.cmp.ne     p2, v3, v8
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s3, #0]
    vf.sub       v10, v0, v2
    v.splat      v0, s1
    v.movi       v2, #0
    v.extract    s1, v7, #15
    v.movi       v11, #0
    v.splat      v12, s1
    v.cmp.ne     p1, v0, v2
    p.and        p4, p2, p1
    v.cmp.ne     p1, v12, v11
    p.and        p2, p4, p1
    s.addi       s1, s20, #4096
    p.and        p1, p2, p3
    v.extract    s2, v1, #15
    vf.mul       v0, v3, v3
    vf.mul       v1, v3, v6
    v.extract    s3, v5, #15
    v.splat      v2, s2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s5, #0]
    vf.fms       v6, v9, v0, v4
    v.movi       v0, #0
    v.splat      v4, s3
    v.movi       v9, #0
    v.cmp.ne     p1, v2, v0
    vf.mul       v0, v1, v6                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.cmp.ne     p2, v4, v9
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v1, v0, v3
    v.extract    s2, v7, #15
    p.and        p4, p1, p2
    vf.mul       v0, v10, v1
    v.splat      v1, s2
    v.movi       v2, #0
    v.ld.w       v3, [s1, #0]
    vf.mul       v4, v0, v8
    v.cmp.ne     p1, v1, v2
    p.and        p2, p4, p1
    p.and        p1, p2, p3
    vf.add       v0, v4, v5
    vf.max.prop  v1, v0, v14
    @p1 v.st.scatter.w [s10, v3], v1
__rctx_next:
    exit
