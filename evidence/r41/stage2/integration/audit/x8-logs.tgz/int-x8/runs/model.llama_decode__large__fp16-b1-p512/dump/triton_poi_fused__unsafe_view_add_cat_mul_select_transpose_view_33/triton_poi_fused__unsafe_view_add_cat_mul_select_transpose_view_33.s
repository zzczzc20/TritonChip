    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #0
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.sub        v4, v0, v3
    @p1 v.sel        v5, v1, v3
    v.movi       v1, #15
    s.rdspecial  s1, arg_base
    v.cmp.lt     p2, v3, v0
    @p2 v.sel        v6, v4, v3
    v.movi       v4, #32767
    v.lshr       v7, v5, v1
    .li       s2, #2359296
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.and        v5, v6, v4
    v.sub        v4, v2, v7
    v.add        v6, v3, v1
    v.sub        v1, v0, v5
    @p1 v.sel        v3, v4, v7
    v.ld.gather.h v4, [s2, v6]                   // index is in elements (ISA sec 9.1)
    s.movz       s2, #32832
    v.splat      v6, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.movz       s2, #32768
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p2 v.sel        v8, v1, v5
    v.mul        v1, v3, v6
    v.sub        v3, v0, v7
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.sub        v5, v2, v7
    v.add        v6, v8, v1
    v.cmp.lt     p1, v7, v0
    v.cmp.lt     p2, v7, v2
    @p1 v.sel        v0, v3, v7
    @p2 v.sel        v0, v5, v7
    v.st.scatter.h [s2, v6], v4
__rctx_next:
    exit
