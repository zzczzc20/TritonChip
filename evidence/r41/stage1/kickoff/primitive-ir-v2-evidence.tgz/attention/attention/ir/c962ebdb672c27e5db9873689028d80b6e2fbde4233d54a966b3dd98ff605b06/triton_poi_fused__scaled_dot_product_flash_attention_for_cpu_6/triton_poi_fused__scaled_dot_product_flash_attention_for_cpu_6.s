    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #1280
    v.movi       v2, #0
    v.movi       v3, #10240
    s.rdspecial  s1, arg_base
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v0, #1
    v.sub        v4, v2, v6
    v.cmp.lt     p2, v6, v2
    v.cmp.lt     p3, v6, v3
    @p2 v.sel        v3, v4, v6
    @p1 v.sel        v4, v5, v1
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s4, #31
    s.ld.d       s5, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
idiv_1:
    v.splat      v8, s4
    v.shl        v9, v7, v0
    v.cmp.lt     p1, v7, v2
    v.lshr       v10, v3, v8
    v.shl        v11, v0, v8
    s.subi       s1, s4, #1
    v.and        v8, v10, v0
    s.movz       s6, #0
    v.or         v10, v9, v8
    v.cmp.geu    p4, v10, v4
    p.or         p5, p1, p4
    v.sub        v8, v10, v4
    @p5 v.sel        v9, v11, v2
    @p5 v.sel        v11, v8, v10
    v.or         v8, v5, v9
    v.mov        v7, v11
    v.mov        v5, v8
    s.mov        s4, s1
    s.cmp.ge     s1, s4, s6
    br.nz        s1, idiv_1
    v.movi       v0, #5120
    v.movi       v3, #0
    v.sub        v4, v2, v7
    v.movi       v2, #1
    v.sub        v5, v3, v6
    v.sub        v8, v3, v0
    v.cmp.lt     p1, v6, v3
    v.cmp.lt     p4, v0, v3
    @p2 v.sel        v9, v4, v7
    @p1 v.sel        v4, v5, v6
    @p4 v.sel        v5, v8, v0
    v.movi       v0, #0
    v.movi       v6, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v7, s1
    v.shl        v8, v6, v2
    v.cmp.lt     p2, v6, v3
    v.lshr       v10, v4, v7
    v.shl        v11, v2, v7
    s.subi       s4, s1, #1
    v.and        v7, v10, v2
    s.movz       s6, #0
    v.or         v10, v8, v7
    v.cmp.geu    p5, v10, v5
    p.or         p6, p2, p5
    v.sub        v7, v10, v5
    @p6 v.sel        v8, v11, v3
    @p6 v.sel        v11, v7, v10
    v.or         v7, v0, v8
    v.mov        v6, v11
    v.mov        v0, v7
    s.mov        s1, s4
    s.cmp.ge     s4, s1, s6
    br.nz        s4, idiv_2
    v.sub        v2, v3, v0
    p.xor        p2, p1, p4
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    @p2 v.sel        v3, v2, v0
    s.add        s2, s5, s1                      // &out_ptr0[...]
    s.movz       s1, #1280
    v.mul        v0, v3, v1
    v.add        v1, v9, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v0, [s3, v1]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v1, v0
    @p3 v.st.w       [s2, #0], v1
__rctx_next:
    exit
