    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #1024
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s3
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #2048
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #8589934592
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #64
    s.movz       s3, #0
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s1, s8
    s.sub        s8, s7, s9
    s.xor        s7, s1, s8
    s.sub        s9, s7, s8
    s.movz       s7, #1
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #1
    s.cmp.lt     s16, s4, s6
    s.sub        s6, s3, s16
    s.xor        s3, s4, s6
    s.sub        s16, s3, s6
    s.lshri      s3, s16, #6
    s.muli       s17, s3, #64
    s.sub        s18, s16, s17
    s.xor        s16, s6, s8
    s.xor        s6, s3, s16
    s.sub        s3, s6, s16
    s.sub        s6, s7, s3
    s.min.s      s8, s6, s7
    s.cmp.lt     s6, s4, s10
    s.sub        s10, s9, s6
    s.cmp.lt     s6, s8, s12
    s.sub        s9, s11, s6
    s.xor        s6, s4, s10
    s.sub        s11, s6, s10
    s.xor        s6, s8, s9
    s.sub        s12, s6, s9
    s.addi       s6, s13, #0
    s.addi       s9, s14, #0
    s.cmp.eq     s13, s12, s15
    s.mov        s6, s11
    br.nz        s13, sdiv_done_1
    s.movz       s13, #0
    s.movz       s14, #31
    s.mov        s6, s13
    s.addi       s13, s14, #0
sdiv_2:
    s.lshr       s14, s11, s13
    s.shli       s15, s9, #1
    s.andi       s16, s14, #1
    s.movz       s14, #0
    s.or         s17, s15, s16
    s.movz       s15, #1
    s.cmp.geu    s16, s17, s12
    s.shl        s18, s15, s13
    s.sub        s15, s14, s16
    s.subi       s14, s13, #1
    s.and        s16, s12, s15
    s.and        s19, s18, s15
    s.sub        s15, s17, s16
    s.or         s16, s6, s19
    s.mov        s9, s15
    s.mov        s6, s16
    s.mov        s13, s14
    s.movz       s14, #0
    s.cmp.ge     s15, s13, s14
    br.nz        s15, sdiv_2
sdiv_done_1:
    s.movz       s6, #0
    s.movz       s11, #0
    s.cmp.lt     s12, s4, s6
    s.movz       s6, #0
    s.sub        s13, s11, s12
    s.movz       s11, #0
    s.xor        s12, s4, s13
    s.movz       s4, #0
    s.sub        s14, s12, s13
    s.cmp.lt     s12, s8, s6
    s.lshri      s6, s14, #6
    s.movz       s15, #0
    s.muli       s16, s6, #64
    s.movz       s6, #0
    s.sub        s17, s4, s12
    s.movz       s4, #0
    s.cmp.lt     s12, s1, s15
    s.sub        s15, s14, s16
    s.xor        s14, s8, s17
    s.xor        s8, s15, s13
    s.xor        s15, s9, s10
    s.sub        s9, s8, s13
    s.sub        s8, s4, s12
    s.cmp.lt     s4, s9, s11
    s.sub        s11, s14, s17
    s.sub        s12, s6, s4
    s.movz       s4, #0
    s.xor        s6, s9, s12
    s.movz       s9, #1
    s.sub        s13, s15, s10
    s.xor        s10, s1, s8
    s.sub        s14, s6, s12
    s.movz       s6, #0
    s.addi       s15, s4, #0
    s.cmp.eq     s4, s11, s9
    s.add        s9, s3, s13
    s.sub        s3, s10, s8
    s.addi       s3, s6, #0
    s.mov        s15, s14
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s6, #31
    s.mov        s15, s4
    s.addi       s4, s6, #0
sdiv_4:
    s.lshr       s6, s14, s4
    s.shli       s8, s3, #1
    s.andi       s10, s6, #1
    s.movz       s6, #0
    s.or         s13, s8, s10
    s.movz       s8, #1
    s.cmp.geu    s10, s13, s11
    s.shl        s16, s8, s4
    s.sub        s8, s6, s10
    s.subi       s6, s4, #1
    s.and        s10, s11, s8
    s.and        s18, s16, s8
    s.sub        s8, s13, s10
    s.or         s10, s15, s18
    s.mov        s3, s8
    s.mov        s15, s10
    s.mov        s4, s6
    s.movz       s6, #0
    s.cmp.ge     s8, s4, s6
    br.nz        s8, sdiv_4
sdiv_done_3:
    s.xor        s3, s12, s17
    s.movz       s4, #16
    s.xor        s6, s15, s3
    s.movz       s8, #0
    s.sub        s10, s6, s3
    v.splat      v0, s9
    s.mul        s3, s10, s4
    v.splat      v1, s8
    v.splat      v2, s10
    v.splat      v3, s8
    v.iota       v4                              // arange(0, VLEN)
    s.andi       s6, s3, #1023
    v.splat      v5, s3
    v.splat      v6, s6
    v.cmp.ge     p1, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ge     p1, v2, v3
    v.add        v1, v5, v4
    v.add        v1, v6, v0
    s.addi       s10, s8, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s8, s10, s1
    br.nz        s8, endfor_6
    s.mul        s8, s10, s4
    s.muli       s11, s8, #2                     // a runtime tile origin, x2
    s.add        s12, s2, s11                    // the tile origin
    v.ld.h       v0, [s12, #0]
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s12, s6                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s13, s8                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s12, s11
    mb.wait      s11
    s.rdspecial  s8, arg_base
    s.ld.d       s12, [s8, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s8, role_id
    s.movz       s13, #1024
    s.mul        s14, s8, s13
    s.add        s8, s12, s14                    // this context's own scratch
    s.addi       s12, s8, #256                   // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s12, #0], v0
    s.addi       s13, s12, #32                   // row 1
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #64                   // row 2
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #96                   // row 3
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #128                  // row 4
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #160                  // row 5
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #192                  // row 6
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #224                  // row 7
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #256                  // row 8
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #288                  // row 9
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #320                  // row 10
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #352                  // row 11
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #384                  // row 12
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #416                  // row 13
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #448                  // row 14
    v.st.h       [s13, #0], v0
    s.addi       s13, s12, #480                  // row 15
    v.st.h       [s13, #0], v0
    s.addi       s13, s8, #768                   // TensorMap 1: a repacked tile
    s.movz       s8, #0
    s.st.d       [s13, #0], s12
    s.movz       s8, #16
    s.st.d       [s13, #8], s8
    s.movz       s8, #16
    s.st.d       [s13, #16], s8
    s.movz       s8, #32
    s.st.d       [s13, #48], s8
    s.movz       s8, #2
    s.st.d       [s13, #56], s8
    .li       s8, #68719476752
    s.st.d       [s13, #88], s8
    .li       s8, #8589934592
    s.st.d       [s13, #104], s8
    fence.release.device
    td.load      d1, [s13]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s8, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s12, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s13, s8                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s8                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s13, s12
    mb.wait      s12
    mb.arm       s8, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v48, v56, s8
    mb.wait      s8
    s.add        s13, s10, s7
    s.mov        s10, s13
    s.movz       s13, #1
    br.nz        s13, for_5
endfor_6:
    s.mul        s1, s9, s4
    s.movz       s2, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s4, #0
    s.add        s6, s2, s3                      // the tile origin
    s.movz       s2, #0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    a.vread      v2, a0, s4
    s.add        s4, s2, s1                      // the tile origin
    s.movz       s2, #1024
    s.muli       s6, s3, #2                      // a runtime tile origin, x2
    v.splat      v3, s4
    v.splat      v5, s7
    v.add        v6, v0, v1
    v.splat      v0, s2
    vf.cvt.f32.f16 v1, v2
    v.cmp.lt     p1, v3, v5
    v.cmp.lt     p2, v6, v0
    s.add        s2, s5, s6                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s3, #1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v0, a0, s3
    s.addi       s3, s4, #1
    s.movz       s5, #2
    v.splat      v1, s3
    vf.cvt.f32.f16 v2, v0
    s.addi       s3, s4, #2
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    v.splat      v0, s3
    s.movz       s3, #3
    s.addi       s6, s4, #3
    v.cmp.lt     p1, v0, v5
    p.and        p4, p1, p2
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s5
    v.splat      v1, s6
    s.movz       s5, #4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    v.splat      v0, s1
    v.add        v1, v0, v4
    s.addi       s1, s4, #4
    s.movz       s6, #5
    v.splat      v0, s1
    @p4 v.st.h       [s2, #0], v2
    a.vread      v1, a0, s3
    v.cmp.lt     p1, v0, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s1, s4, #5
    s.movz       s3, #6
    v.splat      v1, s1
    s.addi       s1, s4, #6
    s.movz       s7, #7
    v.splat      v2, s1
    s.addi       s1, s4, #7
    s.movz       s9, #8
    v.splat      v3, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s1, s4, #8
    s.movz       s5, #9
    v.splat      v0, s1
    s.addi       s1, s4, #9
    s.movz       s10, #10
    v.splat      v4, s1
    s.addi       s1, s4, #10
    v.splat      v6, s1
    @p4 v.st.h       [s2, #0], v1
    a.vread      v1, a0, s6
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.movz       s1, #11
    s.addi       s6, s4, #11
    v.splat      v1, s6
    @p3 v.st.h       [s2, #0], v2
    a.vread      v2, a0, s3
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.movz       s3, #12
    s.addi       s6, s4, #12
    v.splat      v2, s6
    @p4 v.st.h       [s2, #0], v3
    a.vread      v3, a0, s7
    v.cmp.lt     p1, v0, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v3
    s.movz       s6, #13
    s.addi       s7, s4, #13
    v.splat      v3, s7
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s9
    v.cmp.lt     p1, v4, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v4, v0
    s.movz       s7, #14
    s.addi       s9, s4, #14
    v.splat      v0, s9
    @p4 v.st.h       [s2, #0], v4
    a.vread      v4, a0, s5
    v.cmp.lt     p1, v6, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v6, v4
    s.movz       s5, #15
    s.addi       s9, s4, #15
    v.splat      v4, s9
    @p3 v.st.h       [s2, #0], v6
    a.vread      v6, a0, s10
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v6
    @p4 v.st.h       [s2, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s2, #0], v2
    a.vread      v1, a0, s3
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s2, #0], v2
    a.vread      v1, a0, s6
    v.cmp.lt     p1, v0, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s7
    v.cmp.lt     p1, v4, v5
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s2, #0], v1
    a.vread      v0, a0, s5
    vf.cvt.f32.f16 v1, v0
    @p3 v.st.h       [s2, #0], v1
__rctx_next:
    exit
