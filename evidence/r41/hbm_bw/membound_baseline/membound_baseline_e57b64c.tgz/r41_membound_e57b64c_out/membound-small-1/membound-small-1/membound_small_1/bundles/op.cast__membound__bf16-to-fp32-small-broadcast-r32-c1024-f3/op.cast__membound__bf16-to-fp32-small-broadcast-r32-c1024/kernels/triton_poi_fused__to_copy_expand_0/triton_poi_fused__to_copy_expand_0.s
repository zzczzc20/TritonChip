    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s2, arg_base
    v.add        v3, v1, v0
    v.movi       v0, #1023
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.movi       v4, #1024
    @p1 v.sel        v5, v1, v3
    s.shli       s4, s1, #2                      // element offset -> bytes (x4)
    v.sub        v1, v2, v4
    v.and        v3, v5, v0
    v.cmp.lt     p2, v4, v2
    @p2 v.sel        v0, v1, v4
    v.sub        v0, v2, v3
    s.ld.d       s1, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    @p1 v.sel        v1, v0, v3
    v.ld.gather.h v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.add        s2, s1, s4                      // &out_ptr0[...]
    vf.cvt.bf16.f32 v1, v0
    v.st.w       [s2, #0], v1
__rctx_next:
    exit
