.org 0
mb.arm s1, b4, #0, #1
exit
