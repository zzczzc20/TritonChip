    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #4160
    s.rdspecial  s4, arg_base
    s.mul        s5, s2, s1
    s.movz       s1, #16
    s.rdspecial  s2, pid.y
    s.movz       s6, #4096
    s.mul        s6, s2, s1
    s.movz       s2, #0
    s.movz       s7, #144
    s.movz       s7, #9
    s.add        s8, s3, s5                      // this context's own scratch
    s.ld.d       s3, [s4, #0]                    // arg_X: device_ptr64 at arg_base+0
    s.addi       s5, s8, #0
    s.addi       s9, s8, #1024
    s.addi       s10, s5, #64
    s.addi       s11, s5, #128
    s.addi       s12, s5, #192
    s.addi       s13, s5, #256
    s.addi       s14, s5, #320
    s.addi       s15, s5, #384
    s.addi       s16, s5, #448
    s.addi       s17, s5, #512
    s.ld.d       s18, [s4, #8]                   // arg_W: device_ptr64 at arg_base+8
    s.addi       s19, s5, #576
    s.addi       s20, s5, #640
    s.addi       s21, s5, #704
    s.addi       s22, s5, #768
    s.addi       s23, s5, #832
    s.addi       s24, s5, #896
    s.addi       s25, s5, #960
    s.movz       s26, #1
    s.rdspecial  s27, role_id
    s.rdspecial  s28, npid.x
    s.ld.d       s29, [s4, #16]                  // out_ptr0: device_ptr64 at arg_base+16
__rctx_program:
    s.mul        s4, s27, s1
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #0
    v.movi       v2, #4
    v.movi       v3, #0
    v.splat      v4, s4
    v.movi       v5, #4
    v.movi       v6, #0
    v.add        v7, v4, v0
    v.movi       v4, #0
    v.movi       v8, #15
    v.sub        v9, v1, v7
    v.cmp.lt     p1, v7, v1
    v.sub        v10, v6, v7
    @p1 v.sel        v11, v9, v7
    v.cmp.lt     p2, v7, v6
    @p2 v.sel        v9, v10, v7
    v.lshr       v7, v11, v2
    v.movi       v2, #15
    v.movi       v10, #16
    v.sub        v11, v1, v7
    v.splat      v12, s6
    v.and        v13, v9, v8
    @p1 v.sel        v8, v11, v7
    v.sub        v7, v6, v10
    v.sub        v9, v6, v13
    v.cmp.lt     p1, v8, v3
    v.cmp.lt     p3, v8, v4
    v.movi       v11, #1
    v.add        v11, v12, v0
    @p2 v.sel        v12, v9, v13
    v.sub        v9, v3, v8
    v.cmp.lt     p2, v10, v6
    v.movi       v6, #4096
    @p1 v.sel        v13, v9, v8
    @p2 v.sel        v9, v7, v10
    v.sub        v7, v4, v8
    v.lshr       v9, v13, v5
    v.splat      v5, s2
    @p3 v.sel        v13, v7, v8
    v.sub        v7, v3, v9
    v.cmp.lt     p2, v10, v1
    v.and        v8, v13, v2
    @p1 v.sel        v2, v7, v9
    v.sub        v7, v1, v10
    v.sub        v1, v4, v10
    v.mul        v9, v2, v6
    v.sub        v6, v4, v8
    v.cmp.lt     p1, v10, v4
    v.extract    s4, v9, #0
    v.extract    s30, v9, #1
    v.splat      v4, s4
    v.movi       v13, #1
    v.extract    s4, v9, #2
    v.extract    s31, v9, #3
    v.add        v13, v5, v4
    @p2 v.sel        v4, v7, v10
    v.extract    s32, v9, #4
    v.splat      v4, s30
    v.cmp.lt     p2, v10, v3
    v.sub        v7, v3, v10
    v.add        v3, v5, v4
    v.movi       v4, #1
    v.extract    s30, v9, #5
    v.extract    s33, v9, #6
    @p1 v.sel        v4, v1, v10
    v.splat      v1, s4
    v.extract    s4, v9, #7
    @p3 v.sel        v4, v6, v8
    v.splat      v6, s31
    v.add        v8, v5, v1
    v.movi       v1, #1
    v.extract    s31, v9, #8
    v.add        v1, v5, v6
    @p2 v.sel        v6, v7, v10
    v.splat      v6, s32
    v.extract    s32, v9, #9
    v.st.w       [s5, #0], v13
    v.splat      v7, s30
    v.extract    s30, v9, #10
    v.add        v13, v5, v6
    v.add        v6, v5, v7
    v.st.w       [s10, #0], v3
    v.splat      v3, s33
    v.extract    s33, v9, #11
    v.add        v7, v5, v3
    v.st.w       [s11, #0], v8
    v.splat      v3, s4
    v.extract    s4, v9, #12
    v.add        v8, v5, v3
    v.st.w       [s12, #0], v1
    v.movi       v1, #144
    v.mul        v3, v11, v1
    v.st.w       [s13, #0], v13
    v.splat      v1, s31
    v.extract    s31, v9, #13
    v.add        v13, v5, v1
    v.st.w       [s14, #0], v6
    v.splat      v1, s32
    v.extract    s32, v9, #14
    v.add        v6, v5, v1
    v.st.w       [s15, #0], v7
    v.splat      v1, s30
    v.extract    s30, v9, #15
    v.splat      v7, s33
    v.add        v9, v5, v1
    s.addi       s33, s2, #0
    v.add        v1, v5, v7
    v.st.w       [s16, #0], v8
    v.splat      v7, s4
    v.add        v8, v5, v7
    v.st.w       [s17, #0], v13
    v.splat      v7, s31
    v.add        v13, v5, v7
    v.st.w       [s19, #0], v6
    v.splat      v6, s32
    v.add        v7, v5, v6
    v.st.w       [s20, #0], v9
    v.splat      v6, s30
    v.add        v9, v5, v6
    v.splat      v5, s2
    v.add        v6, v5, v3
    v.st.w       [s21, #0], v1
    v.st.w       [s22, #0], v8
    v.st.w       [s23, #0], v13
    v.st.w       [s24, #0], v7
    v.st.w       [s25, #0], v9
    fence.acq_rel.device
    v.st.w       [s9, #0], v6
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_1:
    s.cmp.ge     s4, s33, s7
    br.nz        s4, endfor_2
    s.movz       s4, #0
    .li       s30, #1431655766
    s.cmp.lt     s31, s33, s4
    s.cmp.lt     s32, s33, s4
    s.sub        s34, s4, s31
    s.sub        s31, s4, s32
    s.xor        s32, s33, s34
    s.xor        s35, s33, s31
    s.sub        s36, s32, s34
    s.sub        s32, s35, s31
    s.mul        s35, s36, s30
    s.mul        s37, s32, s30
    s.movz       s30, #3
    s.addi       s38, s8, #0
    s.cmp.lt     s39, s30, s4
    s.lshri      s40, s35, #32
    s.lshri      s35, s37, #32
    s.sub        s37, s36, s40
    s.sub        s41, s32, s35
    s.lshri      s42, s37, #1
    s.lshri      s37, s41, #1
    s.add        s41, s40, s42
    s.sub        s40, s4, s39
    s.lshri      s4, s41, #1
    s.add        s39, s35, s37
    s.muli       s35, s4, #3
    s.lshri      s4, s39, #1
    s.xor        s37, s31, s40
    v.ld.w       v1, [s38, #0]
    s.xor        s31, s4, s37
    s.sub        s38, s36, s35
    s.sub        s35, s31, s37
    s.xor        s31, s38, s34
    s.sub        s36, s35, s26
    s.sub        s37, s31, s34
    v.splat      v3, s36
    s.sub        s31, s37, s26
    v.movi       v5, #256
    v.splat      v6, s31
    v.add        v7, v3, v4
    v.iota       v3                              // arange(0, VLEN)
    v.add        v8, v6, v12
    v.mul        v6, v7, v5
    s.addi       s31, s8, #1088
    v.mul        v5, v8, v10
    v.extract    s34, v6, #0
    s.muli       s36, s4, #3
    v.extract    s4, v5, #0
    v.splat      v9, s34
    v.splat      v13, s4
    s.xor        s4, s30, s40
    s.sub        s34, s32, s36
    v.add        v14, v9, v13
    s.sub        s32, s4, s40
    s.addi       s4, s8, #64
    v.add        v9, v14, v3
    v.extract    s32, v6, #1
    v.extract    s34, v5, #1
    v.add        v13, v1, v9
    v.splat      v1, s32
    v.splat      v9, s34
    v.st.w       [s31, #0], v13
    s.addi       s32, s31, #64
    v.add        v13, v1, v9
    s.addi       s34, s8, #128
    v.extract    s36, v6, #2
    v.add        v1, v13, v3
    v.extract    s38, v5, #2
    v.splat      v9, s36
    v.splat      v13, s38
    s.addi       s36, s31, #128
    s.addi       s38, s8, #192
    v.add        v14, v9, v13
    v.extract    s39, v6, #3
    v.extract    s40, v5, #3
    v.add        v9, v14, v3
    v.splat      v13, s39
    v.splat      v14, s40
    s.addi       s39, s31, #192
    v.ld.w       v15, [s4, #0]
    v.add        v16, v13, v14
    s.movz       s4, #256
    s.addi       s4, s8, #256
    v.add        v13, v16, v3
    v.extract    s40, v6, #4
    v.extract    s41, v5, #4
    v.splat      v14, s40
    v.splat      v16, s41
    s.addi       s40, s31, #256
    s.addi       s41, s8, #320
    v.add        v17, v14, v16
    v.add        v14, v17, v3
    v.add        v16, v15, v1
    v.st.w       [s32, #0], v16
    v.extract    s32, v6, #5
    v.splat      v1, s32
    v.extract    s32, v5, #5
    v.splat      v15, s32
    s.addi       s32, s31, #320
    v.add        v16, v1, v15
    v.add        v1, v16, v3
    v.ld.w       v15, [s34, #0]
    s.addi       s34, s8, #384
    v.add        v16, v15, v9
    v.st.w       [s36, #0], v16
    v.extract    s36, v6, #6
    v.splat      v9, s36
    v.extract    s36, v5, #6
    v.splat      v15, s36
    s.addi       s36, s31, #384
    v.add        v16, v9, v15
    v.add        v9, v16, v3
    v.ld.w       v15, [s38, #0]
    s.addi       s38, s8, #448
    v.add        v16, v15, v13
    v.st.w       [s39, #0], v16
    v.extract    s39, v6, #7
    v.splat      v13, s39
    v.extract    s39, v5, #7
    v.splat      v15, s39
    s.addi       s39, s31, #448
    v.add        v16, v13, v15
    v.add        v13, v16, v3
    v.ld.w       v15, [s4, #0]
    s.addi       s4, s8, #512
    v.add        v16, v15, v14
    v.st.w       [s40, #0], v16
    v.extract    s40, v6, #8
    v.splat      v14, s40
    v.extract    s40, v5, #8
    v.splat      v15, s40
    s.addi       s40, s31, #512
    v.add        v16, v14, v15
    v.add        v14, v16, v3
    v.ld.w       v15, [s41, #0]
    s.addi       s41, s8, #576
    v.add        v16, v15, v1
    v.st.w       [s32, #0], v16
    v.extract    s32, v6, #9
    v.splat      v1, s32
    v.extract    s32, v5, #9
    v.splat      v15, s32
    s.addi       s32, s31, #576
    v.add        v16, v1, v15
    v.add        v1, v16, v3
    v.ld.w       v15, [s34, #0]
    s.addi       s34, s8, #640
    v.add        v16, v15, v9
    v.st.w       [s36, #0], v16
    v.extract    s36, v6, #10
    v.splat      v9, s36
    v.extract    s36, v5, #10
    v.splat      v15, s36
    s.addi       s36, s31, #640
    v.add        v16, v9, v15
    v.add        v9, v16, v3
    v.ld.w       v15, [s38, #0]
    s.addi       s38, s8, #704
    v.add        v16, v15, v13
    v.st.w       [s39, #0], v16
    v.extract    s39, v6, #11
    v.splat      v13, s39
    v.extract    s39, v5, #11
    v.splat      v15, s39
    s.addi       s39, s31, #704
    v.add        v16, v13, v15
    v.add        v13, v16, v3
    v.ld.w       v15, [s4, #0]
    s.addi       s4, s8, #768
    v.add        v16, v15, v14
    v.st.w       [s40, #0], v16
    v.extract    s40, v6, #12
    v.splat      v14, s40
    v.extract    s40, v5, #12
    v.splat      v15, s40
    s.addi       s40, s31, #768
    v.add        v16, v14, v15
    v.add        v14, v16, v3
    v.ld.w       v15, [s41, #0]
    s.addi       s41, s8, #832
    v.add        v16, v15, v1
    v.st.w       [s32, #0], v16
    v.extract    s32, v6, #13
    v.splat      v1, s32
    v.extract    s32, v5, #13
    v.splat      v15, s32
    s.addi       s32, s31, #832
    v.add        v16, v1, v15
    v.add        v1, v16, v3
    v.ld.w       v15, [s34, #0]
    s.addi       s34, s8, #896
    v.add        v16, v15, v9
    v.st.w       [s36, #0], v16
    v.extract    s36, v6, #14
    v.splat      v9, s36
    v.extract    s36, v5, #14
    v.splat      v15, s36
    s.addi       s36, s31, #896
    s.addi       s42, s31, #960
    v.add        v16, v9, v15
    v.add        v9, v16, v3
    v.ld.w       v15, [s38, #0]
    s.addi       s31, s8, #960
    v.movi       v16, #1
    v.add        v17, v15, v13
    v.cmp.lt     p1, v2, v16
    v.st.w       [s39, #0], v17
    v.extract    s38, v6, #15
    v.movi       v6, #0
    v.splat      v13, s38
    v.extract    s38, v5, #15
    v.cmp.ge     p2, v7, v6
    v.splat      v5, s38
    @p1 v.sel        v15, v16, v6
    v.add        v17, v13, v5
    v.add        v5, v17, v3
    v.ld.w       v13, [s4, #0]
    v.movi       v17, #1
    v.movi       v18, #0
    @p2 v.sel        v19, v16, v6
    v.cmp.lt     p1, v7, v10
    @p1 v.sel        v7, v17, v18
    v.cmp.ge     p1, v8, v6
    @p1 v.sel        v6, v17, v18
    v.add        v16, v13, v14
    v.cmp.lt     p1, v8, v10
    v.st.w       [s40, #0], v16
    @p1 v.sel        v8, v17, v18
    v.cmp.lt     p1, v0, v10
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    v.ld.w       v13, [s41, #0]
    s.addi       s38, s8, #1088
    v.extract    s39, v15, #0
    v.extract    s40, v19, #0
    v.splat      v14, s39
    v.movi       v16, #0
    v.cmp.ne     p2, v14, v16
    v.add        v14, v13, v1
    v.splat      v1, s40
    v.st.w       [s32, #0], v14
    v.extract    s32, v7, #0
    v.cmp.ne     p3, v1, v16
    p.and        p4, p2, p3
    v.ld.w       v1, [s34, #0]
    v.splat      v13, s32
    v.movi       v14, #0
    v.extract    s32, v6, #0
    v.splat      v16, s32
    v.cmp.ne     p2, v13, v14
    p.and        p3, p4, p2
    v.cmp.ne     p2, v16, v14
    v.add        v13, v1, v9
    p.and        p4, p3, p2
    v.st.w       [s36, #0], v13
    v.extract    s32, v8, #0
    v.movi       v1, #0
    v.splat      v9, s32
    v.ld.w       v13, [s31, #0]
    v.cmp.ne     p2, v9, v1
    p.and        p3, p4, p2
    s.addi       s31, s8, #1152
    p.and        p2, p3, p1
    s.movz       s32, #1
    v.add        v1, v13, v5
    v.st.w       [s42, #0], v1
    fence.acq_rel.device
    v.extract    s34, v15, #1
    v.extract    s36, v19, #1
    v.splat      v1, s34
    v.movi       v5, #0
    v.splat      v9, s36
    v.extract    s34, v7, #1
    v.movi       v13, #0
    v.splat      v14, s34
    v.extract    s34, v6, #1
    v.cmp.ne     p3, v1, v5
    v.cmp.ne     p4, v9, v5
    p.and        p5, p3, p4
    v.splat      v1, s34
    v.extract    s34, v8, #1
    v.cmp.ne     p3, v14, v13
    p.and        p4, p5, p3
    v.ld.w       v5, [s38, #0]
    v.splat      v9, s34
    v.movi       v14, #0
    v.cmp.ne     p3, v1, v13
    p.and        p5, p4, p3
    v.cmp.ne     p3, v9, v14
    p.and        p4, p5, p3
    s.addi       s34, s8, #1216
    p.and        p3, p4, p1
    v.extract    s36, v15, #2
    v.extract    s38, v19, #2
    v.splat      v1, s36
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s36, v7, #2
    v.movi       v14, #0
    v.splat      v16, s36
    v.extract    s36, v6, #2
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s36
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s36, #2
    a.vwrite     a1, s4, v17
    v.ld.w       v1, [s31, #0]
    v.extract    s4, v8, #2
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s8, #1280
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s31, v15, #3
    p.and        p2, p4, p1
    v.extract    s38, v19, #3
    v.splat      v5, s31
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s31, v7, #3
    v.movi       v14, #0
    v.splat      v16, s31
    v.extract    s31, v6, #3
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s31
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v14
    s.movz       s31, #3
    a.vwrite     a1, s32, v17
    v.ld.w       v1, [s34, #0]
    v.extract    s32, v8, #3
    v.movi       v5, #0
    v.splat      v9, s32
    p.and        p5, p4, p3
    s.addi       s32, s8, #1344
    v.cmp.ne     p3, v9, v5
    p.and        p4, p5, p3
    v.extract    s34, v15, #4
    p.and        p3, p4, p1
    v.extract    s38, v19, #4
    v.splat      v5, s34
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s34, v7, #4
    v.movi       v14, #0
    v.splat      v16, s34
    v.extract    s34, v6, #4
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s34
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s34, #4
    a.vwrite     a1, s36, v17
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v8, #4
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s8, #1408
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s36, v15, #5
    p.and        p2, p4, p1
    v.extract    s38, v19, #5
    v.splat      v5, s36
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s36, v7, #5
    v.movi       v14, #0
    v.splat      v16, s36
    v.extract    s36, v6, #5
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s36
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v14
    s.movz       s36, #5
    a.vwrite     a1, s31, v17
    v.ld.w       v1, [s32, #0]
    v.extract    s31, v8, #5
    v.movi       v5, #0
    v.splat      v9, s31
    p.and        p5, p4, p3
    s.addi       s31, s8, #1472
    v.cmp.ne     p3, v9, v5
    p.and        p4, p5, p3
    v.extract    s32, v15, #6
    p.and        p3, p4, p1
    v.extract    s38, v19, #6
    v.splat      v5, s32
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s32, v7, #6
    v.movi       v14, #0
    v.splat      v16, s32
    v.extract    s32, v6, #6
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s32
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s32, #6
    a.vwrite     a1, s34, v17
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v8, #6
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s8, #1536
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s34, v15, #7
    p.and        p2, p4, p1
    v.extract    s38, v19, #7
    v.splat      v5, s34
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s34, v7, #7
    v.movi       v14, #0
    v.splat      v16, s34
    v.extract    s34, v6, #7
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s34
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v14
    s.movz       s34, #7
    a.vwrite     a1, s36, v17
    v.ld.w       v1, [s31, #0]
    v.extract    s31, v8, #7
    v.movi       v5, #0
    v.splat      v9, s31
    p.and        p5, p4, p3
    s.addi       s31, s8, #1600
    v.cmp.ne     p3, v9, v5
    p.and        p4, p5, p3
    v.extract    s36, v15, #8
    p.and        p3, p4, p1
    v.extract    s38, v19, #8
    v.splat      v5, s36
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s36, v7, #8
    v.movi       v14, #0
    v.splat      v16, s36
    v.extract    s36, v6, #8
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s36
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s36, #8
    a.vwrite     a1, s32, v17
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v8, #8
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s8, #1664
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s32, v15, #9
    p.and        p2, p4, p1
    v.extract    s38, v19, #9
    v.splat      v5, s32
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s32, v7, #9
    v.movi       v14, #0
    v.splat      v16, s32
    v.extract    s32, v6, #9
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s32
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v14
    s.movz       s32, #9
    a.vwrite     a1, s34, v17
    v.ld.w       v1, [s31, #0]
    v.extract    s31, v8, #9
    v.movi       v5, #0
    v.splat      v9, s31
    p.and        p5, p4, p3
    s.addi       s31, s8, #1728
    v.cmp.ne     p3, v9, v5
    p.and        p4, p5, p3
    v.extract    s34, v15, #10
    p.and        p3, p4, p1
    v.extract    s38, v19, #10
    v.splat      v5, s34
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s34, v7, #10
    v.movi       v14, #0
    v.splat      v16, s34
    v.extract    s34, v6, #10
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s34
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s34, #10
    a.vwrite     a1, s36, v17
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v8, #10
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s8, #1792
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s36, v15, #11
    p.and        p2, p4, p1
    v.extract    s38, v19, #11
    v.splat      v5, s36
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s36, v7, #11
    v.movi       v14, #0
    v.splat      v16, s36
    v.extract    s36, v6, #11
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s36
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v14
    s.movz       s36, #11
    a.vwrite     a1, s32, v17
    v.ld.w       v1, [s31, #0]
    v.extract    s31, v8, #11
    v.movi       v5, #0
    v.splat      v9, s31
    p.and        p5, p4, p3
    s.addi       s31, s8, #1856
    v.cmp.ne     p3, v9, v5
    p.and        p4, p5, p3
    v.extract    s32, v15, #12
    p.and        p3, p4, p1
    v.extract    s38, v19, #12
    v.splat      v5, s32
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s32, v7, #12
    v.movi       v14, #0
    v.splat      v16, s32
    v.extract    s32, v6, #12
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s32
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s32, #12
    a.vwrite     a1, s34, v17
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v8, #12
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s8, #1920
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s34, v15, #13
    p.and        p2, p4, p1
    v.extract    s38, v19, #13
    v.splat      v5, s34
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s34, v7, #13
    v.movi       v14, #0
    v.splat      v16, s34
    v.extract    s34, v6, #13
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s34
    v.cmp.ne     p3, v16, v14
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v14
    s.movz       s34, #13
    a.vwrite     a1, s36, v17
    v.ld.w       v1, [s31, #0]
    v.extract    s31, v8, #13
    v.movi       v5, #0
    v.splat      v9, s31
    p.and        p5, p4, p3
    s.addi       s31, s8, #1984
    v.cmp.ne     p3, v9, v5
    p.and        p4, p5, p3
    v.extract    s36, v15, #14
    p.and        p3, p4, p1
    v.extract    s38, v19, #14
    v.splat      v5, s36
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s36, v7, #14
    v.movi       v14, #0
    v.splat      v16, s36
    v.extract    s36, v6, #14
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v17, [s3, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p2, p4
    v.splat      v1, s36
    v.cmp.ne     p2, v16, v14
    p.and        p4, p5, p2
    v.cmp.ne     p2, v1, v14
    s.movz       s36, #14
    a.vwrite     a1, s32, v17
    v.ld.w       v1, [s4, #0]
    v.extract    s4, v8, #14
    v.movi       v5, #0
    v.splat      v9, s4
    p.and        p5, p4, p2
    s.addi       s4, s8, #2048
    v.cmp.ne     p2, v9, v5
    p.and        p4, p5, p2
    v.extract    s32, v15, #15
    p.and        p2, p4, p1
    v.extract    s38, v19, #15
    v.splat      v5, s32
    v.movi       v9, #0
    v.splat      v13, s38
    v.extract    s32, v7, #15
    v.movi       v7, #0
    v.splat      v14, s32
    v.extract    s32, v6, #15
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s3, v1]               // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v5, v9
    v.cmp.ne     p4, v13, v9
    p.and        p5, p3, p4
    v.splat      v1, s32
    v.cmp.ne     p3, v14, v7
    p.and        p4, p5, p3
    v.cmp.ne     p3, v1, v7
    s.movz       s32, #15
    a.vwrite     a1, s34, v6
    v.ld.w       v1, [s31, #0]
    v.extract    s31, v8, #15
    v.movi       v5, #0
    v.splat      v6, s31
    p.and        p5, p4, p3
    s.addi       s31, s8, #1024
    v.cmp.ne     p3, v6, v5
    p.and        p4, p5, p3
    s.movz       s34, #48
    p.and        p3, p4, p1
    s.mul        s38, s35, s34
    s.mul        s34, s37, s1
    s.movz       s35, #0
    s.addi       s37, s8, #2112
    s.add        s39, s35, s38                   // the tile origin
    s.addi       s35, s37, #64
    s.add        s38, s39, s34                   // the tile origin
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s3, v1]               // index is in elements (ISA sec 9.1)
    v.splat      v1, s38
    s.addi       s34, s38, #1
    s.addi       s39, s37, #128
    v.splat      v6, s34
    a.vwrite     a1, s36, v5
    v.ld.w       v5, [s4, #0]
    s.addi       s4, s38, #2
    s.addi       s34, s38, #3
    v.splat      v7, s4
    v.splat      v8, s34
    s.addi       s4, s37, #192
    s.addi       s34, s38, #4
    s.addi       s36, s37, #256
    v.splat      v9, s34
    s.addi       s34, s38, #5
    s.addi       s40, s37, #320
    v.splat      v13, s34
    s.addi       s34, s38, #6
    s.addi       s41, s37, #384
    v.splat      v14, s34
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v15, [s3, v5]              // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s32, v15
    v.ld.w       v5, [s31, #0]
    s.addi       s32, s38, #7
    s.addi       s34, s37, #448
    v.splat      v15, s32
    s.addi       s32, s38, #8
    v.splat      v16, s32
    s.addi       s32, s37, #512
    v.add        v17, v5, v1
    v.st.w       [s37, #0], v17
    v.ld.w       v1, [s31, #0]
    v.add        v5, v1, v6
    v.st.w       [s35, #0], v5
    s.addi       s35, s8, #1024
    v.ld.w       v1, [s31, #0]
    v.add        v5, v1, v7
    v.st.w       [s39, #0], v5
    s.addi       s39, s38, #9
    v.splat      v1, s39
    s.addi       s39, s37, #576
    v.ld.w       v5, [s31, #0]
    v.add        v6, v5, v8
    v.st.w       [s4, #0], v6
    s.addi       s4, s38, #10
    v.splat      v5, s4
    s.addi       s4, s37, #640
    v.ld.w       v6, [s31, #0]
    v.add        v7, v6, v9
    v.st.w       [s36, #0], v7
    s.addi       s36, s38, #11
    v.splat      v6, s36
    s.addi       s36, s37, #704
    v.ld.w       v7, [s31, #0]
    v.add        v8, v7, v13
    v.st.w       [s40, #0], v8
    s.addi       s40, s38, #12
    v.splat      v7, s40
    s.addi       s40, s37, #768
    v.ld.w       v8, [s31, #0]
    v.add        v9, v8, v14
    v.st.w       [s41, #0], v9
    s.addi       s41, s38, #13
    v.splat      v8, s41
    s.addi       s41, s37, #832
    v.ld.w       v9, [s31, #0]
    v.add        v13, v9, v15
    v.st.w       [s34, #0], v13
    s.addi       s34, s38, #14
    s.addi       s42, s38, #15
    v.splat      v9, s34
    s.addi       s34, s37, #896
    v.splat      v13, s42
    s.addi       s38, s37, #960
    v.ld.w       v14, [s31, #0]
    s.addi       s31, s8, #2112
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s37, #0
    v.add        v15, v14, v16
    v.st.w       [s32, #0], v15
    v.splat      v14, s2
    v.splat      v15, s1
    v.cmp.lt     p1, v14, v15
    v.ld.w       v14, [s35, #0]
    s.add        s32, s37, s6                    // the tile origin
    v.splat      v16, s32
    v.add        v17, v3, v16
    v.add        v3, v14, v1
    v.cmp.lt     p2, v17, v15
    v.st.w       [s39, #0], v3
    p.and        p3, p1, p2
    v.ld.w       v1, [s35, #0]
    s.addi       s32, s8, #2176
    s.movz       s39, #1
    v.add        v3, v1, v5
    v.st.w       [s4, #0], v3
    v.splat      v1, s26
    v.cmp.lt     p1, v1, v15
    v.ld.w       v1, [s35, #0]
    p.and        p4, p1, p2
    v.add        v3, v1, v6
    s.movz       s4, #2
    v.st.w       [s36, #0], v3
    s.addi       s36, s8, #2240
    v.ld.w       v1, [s35, #0]
    v.splat      v3, s4
    v.cmp.lt     p1, v3, v15
    p.and        p5, p1, p2
    v.add        v3, v1, v7
    v.st.w       [s40, #0], v3
    s.movz       s40, #3
    v.ld.w       v1, [s35, #0]
    v.splat      v3, s30
    s.addi       s30, s8, #2304
    v.add        v5, v1, v8
    v.st.w       [s41, #0], v5
    v.ld.w       v1, [s35, #0]
    s.addi       s41, s8, #2368
    v.add        v5, v1, v9
    v.st.w       [s34, #0], v5
    s.movz       s34, #4
    v.splat      v1, s34
    v.ld.w       v5, [s35, #0]
    v.add        v6, v5, v13
    s.movz       s35, #5
    v.st.w       [s38, #0], v6
    fence.acq_rel.device
    s.addi       s38, s8, #2432
    v.splat      v5, s35
    v.ld.w       v6, [s31, #0]
    s.addi       s31, s8, #2496
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s18, v6]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v15
    p.and        p3, p1, p2
    a.vwrite     a2, s37, v7
    v.ld.w       v3, [s32, #0]
    s.movz       s32, #6
    s.addi       s37, s8, #2560
    v.splat      v6, s32
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s18, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v15
    p.and        p4, p1, p2
    a.vwrite     a2, s39, v7
    v.ld.w       v1, [s36, #0]
    s.movz       s36, #7
    s.addi       s39, s8, #2624
    v.splat      v3, s36
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s18, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v15
    p.and        p5, p1, p2
    a.vwrite     a2, s4, v7
    v.ld.w       v1, [s30, #0]
    s.movz       s4, #8
    s.addi       s30, s8, #2688
    v.splat      v5, s4
    v.splat      v7, s7
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v8, [s18, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v15
    p.and        p3, p1, p2
    a.vwrite     a2, s40, v8
    v.ld.w       v1, [s41, #0]
    s.movz       s40, #9
    s.addi       s41, s8, #2752
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v6, [s18, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v15
    p.and        p4, p1, p2
    a.vwrite     a2, s34, v6
    v.ld.w       v1, [s38, #0]
    s.movz       s34, #10
    s.addi       s38, s8, #2816
    v.splat      v3, s34
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v6, [s18, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v15
    p.and        p5, p1, p2
    a.vwrite     a2, s35, v6
    v.ld.w       v1, [s31, #0]
    s.movz       s31, #11
    s.addi       s35, s8, #2880
    v.splat      v5, s31
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s18, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v15
    p.and        p3, p1, p2
    a.vwrite     a2, s32, v6
    v.ld.w       v1, [s37, #0]
    s.movz       s32, #12
    s.addi       s37, s8, #2944
    v.splat      v6, s32
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s18, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v15
    p.and        p4, p1, p2
    a.vwrite     a2, s36, v7
    v.ld.w       v1, [s39, #0]
    s.movz       s36, #13
    s.addi       s39, s8, #3008
    v.splat      v3, s36
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s18, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v15
    p.and        p5, p1, p2
    a.vwrite     a2, s4, v7
    v.ld.w       v1, [s30, #0]
    s.movz       s4, #14
    s.addi       s30, s8, #3072
    v.splat      v5, s4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s18, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v15
    p.and        p3, p1, p2
    a.vwrite     a2, s40, v7
    v.ld.w       v1, [s41, #0]
    s.movz       s40, #15
    s.movz       s41, #0
    v.splat      v6, s40
    v.movi       v7, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s18, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v15
    p.and        p4, p1, p2
    a.vwrite     a2, s34, v8
    v.ld.w       v1, [s38, #0]
    v.movi       v3, #0
    s.movz       s34, #1
    s.movz       s38, #2
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s18, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v15
    p.and        p5, p1, p2
    a.vwrite     a2, s31, v8
    v.ld.w       v1, [s35, #0]
    s.movz       s31, #3
    v.movi       v5, #1
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v8, [s18, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v15
    p.and        p3, p1, p2
    a.vwrite     a2, s32, v8
    v.ld.w       v1, [s37, #0]
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v6, [s18, v1]              // index is in elements (ISA sec 9.1)
    v.movi       v1, #2
    a.vwrite     a2, s36, v6
    v.ld.w       v6, [s39, #0]
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v8, [s18, v6]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s4, v8
    v.ld.w       v6, [s30, #0]
    v.movi       v8, #3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v9, [s18, v6]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s40, v9
    a.vread      v6, a1, s41
    a.vread      v9, a1, s34
    a.vread      v13, a1, s38
    a.vread      v14, a1, s31
    a.vread      v15, a2, s41
    v.permute    v16, v6, v3
    a.vread      v17, a2, s34
    v.permute    v18, v6, v5
    vf.fma       v19, v16, v15, v7
    v.permute    v16, v9, v3
    a.vread      v20, a2, s38
    v.permute    v21, v6, v1
    vf.fma       v22, v16, v15, v7
    vf.fma       v16, v18, v17, v19
    v.permute    v18, v9, v5
    a.vread      v19, a2, s31
    v.permute    v23, v6, v8
    vf.fma       v24, v18, v17, v22
    vf.fma       v18, v21, v20, v16
    v.permute    v16, v13, v3
    v.movi       v21, #4
    s.movz       s4, #4
    vf.fma       v22, v16, v15, v7
    vf.fma       v16, v23, v19, v18
    v.permute    v18, v9, v1
    s.movz       s30, #5
    v.permute    v23, v14, v3
    vf.fma       v3, v18, v20, v24
    a.vread      v18, a2, s4
    vf.fma       v24, v23, v15, v7
    v.permute    v15, v6, v21
    vf.fma       v23, v15, v18, v16
    v.permute    v15, v13, v5
    s.movz       s4, #6
    v.permute    v16, v14, v5
    vf.fma       v5, v15, v17, v22
    v.movi       v15, #5
    vf.fma       v22, v16, v17, v24
    v.permute    v16, v9, v8
    a.vread      v17, a2, s30
    vf.fma       v24, v16, v19, v3
    v.permute    v3, v6, v15
    vf.fma       v16, v3, v17, v23
    v.permute    v3, v13, v1
    v.permute    v23, v14, v1
    s.movz       s30, #7
    vf.fma       v1, v3, v20, v5
    v.movi       v3, #6
    vf.fma       v5, v23, v20, v22
    v.permute    v20, v9, v21
    a.vread      v22, a2, s4
    vf.fma       v23, v20, v18, v24
    v.permute    v20, v6, v3
    vf.fma       v24, v20, v22, v16
    v.permute    v16, v13, v8
    v.permute    v20, v14, v8
    s.movz       s4, #8
    vf.fma       v8, v16, v19, v1
    v.movi       v1, #7
    vf.fma       v16, v20, v19, v5
    v.permute    v5, v9, v15
    a.vread      v19, a2, s30
    vf.fma       v20, v5, v17, v23
    v.permute    v5, v6, v1
    vf.fma       v23, v5, v19, v24
    v.permute    v5, v13, v21
    v.permute    v24, v14, v21
    s.movz       s30, #9
    vf.fma       v21, v5, v18, v8
    v.movi       v5, #8
    vf.fma       v8, v24, v18, v16
    v.permute    v16, v9, v3
    a.vread      v18, a2, s4
    vf.fma       v24, v16, v22, v20
    v.permute    v16, v6, v5
    vf.fma       v20, v16, v18, v23
    v.permute    v16, v13, v15
    v.permute    v23, v14, v15
    s.movz       s4, #10
    vf.fma       v15, v16, v17, v21
    v.movi       v16, #9
    vf.fma       v21, v23, v17, v8
    v.permute    v8, v9, v1
    a.vread      v17, a2, s30
    vf.fma       v23, v8, v19, v24
    v.permute    v8, v6, v16
    vf.fma       v24, v8, v17, v20
    v.permute    v8, v13, v3
    v.permute    v20, v14, v3
    s.movz       s30, #11
    vf.fma       v3, v8, v22, v15
    v.movi       v8, #10
    vf.fma       v15, v20, v22, v21
    v.permute    v20, v9, v5
    a.vread      v21, a2, s4
    vf.fma       v22, v20, v18, v23
    v.permute    v20, v6, v8
    vf.fma       v23, v20, v21, v24
    v.permute    v20, v13, v1
    v.permute    v24, v14, v1
    s.movz       s4, #12
    vf.fma       v1, v20, v19, v3
    v.movi       v3, #11
    vf.fma       v20, v24, v19, v15
    v.permute    v15, v9, v16
    a.vread      v19, a2, s30
    vf.fma       v24, v15, v17, v22
    v.permute    v15, v6, v3
    vf.fma       v22, v15, v19, v23
    v.permute    v15, v13, v5
    v.permute    v23, v14, v5
    s.movz       s30, #13
    vf.fma       v5, v15, v18, v1
    v.movi       v1, #12
    vf.fma       v15, v23, v18, v20
    v.permute    v18, v9, v8
    a.vread      v20, a2, s4
    vf.fma       v23, v18, v21, v24
    v.permute    v18, v6, v1
    vf.fma       v24, v18, v20, v22
    v.permute    v18, v13, v16
    v.permute    v22, v14, v16
    s.movz       s4, #14
    vf.fma       v16, v18, v17, v5
    v.movi       v5, #13
    vf.fma       v18, v22, v17, v15
    v.permute    v15, v9, v3
    a.vread      v17, a2, s30
    vf.fma       v22, v15, v19, v23
    v.permute    v15, v6, v5
    vf.fma       v23, v15, v17, v24
    v.permute    v15, v13, v8
    v.permute    v24, v14, v8
    s.movz       s30, #15
    vf.fma       v8, v15, v21, v16
    v.movi       v15, #14
    vf.fma       v16, v24, v21, v18
    v.permute    v18, v9, v1
    a.vread      v21, a2, s4
    vf.fma       v24, v18, v20, v22
    v.permute    v18, v6, v15
    vf.fma       v22, v18, v21, v23
    v.permute    v18, v13, v3
    v.permute    v23, v14, v3
    s.movz       s4, #0
    vf.fma       v3, v18, v19, v8
    v.movi       v8, #15
    vf.fma       v18, v23, v19, v16
    v.permute    v16, v9, v5
    a.vread      v19, a2, s30
    v.permute    v23, v6, v8
    vf.fma       v6, v16, v17, v24
    v.permute    v16, v13, v1
    vf.fma       v24, v23, v19, v22
    v.permute    v22, v9, v15
    vf.fma       v23, v16, v20, v3
    a.vread      v3, a0, s4
    vf.fma       v16, v22, v21, v6
    v.permute    v6, v13, v5
    v.permute    v22, v9, v8
    vf.add       v9, v3, v24
    v.permute    v3, v14, v1
    vf.fma       v1, v6, v17, v23
    v.permute    v6, v13, v15
    vf.fma       v23, v22, v19, v16
    s.movz       s30, #1
    vf.fma       v16, v3, v20, v18
    a.vwrite     a0, s4, v9
    a.vread      v3, a0, s30
    v.permute    v9, v14, v5
    vf.fma       v5, v6, v21, v1
    v.permute    v1, v13, v8
    vf.add       v6, v3, v23
    vf.fma       v3, v9, v17, v16
    v.permute    v9, v14, v15
    vf.fma       v13, v1, v19, v5
    s.movz       s31, #2
    a.vwrite     a0, s30, v6
    a.vread      v1, a0, s31
    vf.fma       v5, v9, v21, v3
    v.permute    v3, v14, v8
    vf.add       v6, v1, v13
    s.movz       s32, #3
    s.movz       s34, #4
    vf.fma       v1, v3, v19, v5
    v.movi       v3, #0
    a.vwrite     a0, s31, v6
    a.vread      v5, a0, s32
    s.movz       s35, #5
    s.movz       s36, #6
    vf.add       v6, v5, v1
    s.movz       s37, #7
    v.movi       v1, #1
    v.movi       v5, #2
    v.movi       v8, #3
    a.vwrite     a0, s32, v6
    a.vread      v6, a1, s34
    a.vread      v9, a1, s35
    a.vread      v13, a1, s36
    a.vread      v14, a1, s37
    a.vread      v15, a2, s4
    v.permute    v16, v6, v3
    a.vread      v17, a2, s30
    v.permute    v18, v6, v1
    vf.fma       v19, v16, v15, v7
    v.permute    v16, v9, v3
    a.vread      v20, a2, s31
    v.permute    v21, v6, v5
    vf.fma       v22, v16, v15, v7
    vf.fma       v16, v18, v17, v19
    v.permute    v18, v9, v1
    a.vread      v19, a2, s32
    v.permute    v23, v6, v8
    vf.fma       v24, v18, v17, v22
    vf.fma       v18, v21, v20, v16
    v.permute    v16, v13, v3
    v.movi       v21, #4
    v.permute    v22, v14, v3
    vf.fma       v3, v16, v15, v7
    vf.fma       v16, v23, v19, v18
    v.permute    v18, v9, v5
    vf.fma       v23, v22, v15, v7
    a.vread      v15, a2, s34
    vf.fma       v22, v18, v20, v24
    v.permute    v18, v6, v21
    s.movz       s4, #6
    vf.fma       v24, v18, v15, v16
    v.permute    v16, v13, v1
    v.permute    v18, v14, v1
    vf.fma       v1, v16, v17, v3
    v.movi       v3, #5
    vf.fma       v16, v18, v17, v23
    v.permute    v17, v9, v8
    a.vread      v18, a2, s35
    s.movz       s30, #7
    vf.fma       v23, v17, v19, v22
    v.permute    v17, v6, v3
    vf.fma       v22, v17, v18, v24
    v.permute    v17, v13, v5
    v.permute    v24, v14, v5
    vf.fma       v5, v17, v20, v1
    v.movi       v1, #6
    vf.fma       v17, v24, v20, v16
    v.permute    v16, v9, v21
    a.vread      v20, a2, s4
    vf.fma       v24, v16, v15, v23
    v.permute    v16, v6, v1
    vf.fma       v23, v16, v20, v22
    v.permute    v16, v13, v8
    s.movz       s4, #8
    v.permute    v22, v14, v8
    vf.fma       v8, v16, v19, v5
    v.movi       v5, #7
    vf.fma       v16, v22, v19, v17
    v.permute    v17, v9, v3
    a.vread      v19, a2, s30
    vf.fma       v22, v17, v18, v24
    v.permute    v17, v6, v5
    vf.fma       v24, v17, v19, v23
    v.permute    v17, v13, v21
    v.permute    v23, v14, v21
    s.movz       s30, #9
    vf.fma       v21, v17, v15, v8
    v.movi       v8, #8
    vf.fma       v17, v23, v15, v16
    v.permute    v15, v9, v1
    a.vread      v16, a2, s4
    vf.fma       v23, v15, v20, v22
    v.permute    v15, v6, v8
    vf.fma       v22, v15, v16, v24
    v.permute    v15, v13, v3
    v.permute    v24, v14, v3
    s.movz       s4, #10
    vf.fma       v3, v15, v18, v21
    v.movi       v15, #9
    vf.fma       v21, v24, v18, v17
    v.permute    v17, v9, v5
    a.vread      v18, a2, s30
    vf.fma       v24, v17, v19, v23
    v.permute    v17, v6, v15
    vf.fma       v23, v17, v18, v22
    v.permute    v17, v13, v1
    v.permute    v22, v14, v1
    s.movz       s30, #11
    vf.fma       v1, v17, v20, v3
    v.movi       v3, #10
    vf.fma       v17, v22, v20, v21
    v.permute    v20, v9, v8
    a.vread      v21, a2, s4
    vf.fma       v22, v20, v16, v24
    v.permute    v20, v6, v3
    vf.fma       v24, v20, v21, v23
    v.permute    v20, v13, v5
    v.permute    v23, v14, v5
    s.movz       s4, #12
    vf.fma       v5, v20, v19, v1
    v.movi       v1, #11
    vf.fma       v20, v23, v19, v17
    v.permute    v17, v9, v15
    a.vread      v19, a2, s30
    vf.fma       v23, v17, v18, v22
    v.permute    v17, v6, v1
    vf.fma       v22, v17, v19, v24
    v.permute    v17, v13, v8
    v.permute    v24, v14, v8
    s.movz       s30, #13
    vf.fma       v8, v17, v16, v5
    v.movi       v5, #12
    vf.fma       v17, v24, v16, v20
    v.permute    v16, v9, v3
    a.vread      v20, a2, s4
    vf.fma       v24, v16, v21, v23
    v.permute    v16, v6, v5
    vf.fma       v23, v16, v20, v22
    v.permute    v16, v13, v15
    v.permute    v22, v14, v15
    s.movz       s4, #14
    vf.fma       v15, v16, v18, v8
    v.movi       v8, #13
    vf.fma       v16, v22, v18, v17
    v.permute    v17, v9, v1
    a.vread      v18, a2, s30
    vf.fma       v22, v17, v19, v24
    v.permute    v17, v6, v8
    vf.fma       v24, v17, v18, v23
    v.permute    v17, v13, v3
    v.permute    v23, v14, v3
    s.movz       s30, #15
    vf.fma       v3, v17, v21, v15
    v.movi       v15, #14
    vf.fma       v17, v23, v21, v16
    v.permute    v16, v9, v5
    a.vread      v21, a2, s4
    vf.fma       v23, v16, v20, v22
    v.permute    v16, v6, v15
    vf.fma       v22, v16, v21, v24
    v.permute    v16, v13, v1
    v.permute    v24, v14, v1
    s.movz       s4, #4
    vf.fma       v1, v16, v19, v3
    v.movi       v3, #15
    vf.fma       v16, v24, v19, v17
    v.permute    v17, v9, v8
    a.vread      v19, a2, s30
    v.permute    v24, v6, v3
    vf.fma       v6, v17, v18, v23
    v.permute    v17, v13, v5
    vf.fma       v23, v24, v19, v22
    v.permute    v22, v9, v15
    vf.fma       v24, v17, v20, v1
    a.vread      v1, a0, s4
    vf.fma       v17, v22, v21, v6
    v.permute    v6, v13, v8
    v.permute    v22, v9, v3
    vf.add       v9, v1, v23
    v.permute    v1, v14, v5
    vf.fma       v5, v6, v18, v24
    v.permute    v6, v13, v15
    vf.fma       v23, v22, v19, v17
    s.movz       s30, #5
    vf.fma       v17, v1, v20, v16
    a.vwrite     a0, s4, v9
    a.vread      v1, a0, s30
    v.permute    v9, v14, v8
    vf.fma       v8, v6, v21, v5
    v.permute    v5, v13, v3
    vf.add       v6, v1, v23
    vf.fma       v1, v9, v18, v17
    v.permute    v9, v14, v15
    vf.fma       v13, v5, v19, v8
    s.movz       s4, #6
    a.vwrite     a0, s30, v6
    a.vread      v5, a0, s4
    vf.fma       v6, v9, v21, v1
    v.permute    v1, v14, v3
    vf.add       v3, v5, v13
    s.movz       s30, #7
    s.movz       s31, #8
    vf.fma       v5, v1, v19, v6
    v.movi       v1, #0
    a.vwrite     a0, s4, v3
    a.vread      v3, a0, s30
    s.movz       s4, #9
    s.movz       s32, #10
    vf.add       v6, v3, v5
    s.movz       s34, #11
    s.movz       s35, #0
    v.movi       v3, #1
    s.movz       s36, #1
    a.vwrite     a0, s30, v6
    a.vread      v5, a1, s31
    a.vread      v6, a1, s4
    a.vread      v8, a1, s32
    a.vread      v9, a1, s34
    a.vread      v13, a2, s35
    v.permute    v14, v5, v1
    a.vread      v15, a2, s36
    v.permute    v16, v5, v3
    vf.fma       v17, v14, v13, v7
    v.movi       v14, #2
    v.permute    v18, v6, v1
    s.movz       s4, #2
    v.permute    v19, v5, v14
    vf.fma       v20, v16, v15, v17
    a.vread      v16, a2, s4
    vf.fma       v17, v18, v13, v7
    v.movi       v18, #3
    v.permute    v21, v6, v3
    vf.fma       v22, v19, v16, v20
    s.movz       s4, #3
    v.permute    v19, v5, v18
    a.vread      v20, a2, s4
    v.permute    v23, v8, v1
    vf.fma       v24, v21, v15, v17
    v.movi       v17, #4
    vf.fma       v21, v19, v20, v22
    v.permute    v19, v6, v14
    s.movz       s4, #4
    vf.fma       v22, v23, v13, v7
    vf.fma       v23, v19, v16, v24
    a.vread      v19, a2, s4
    v.permute    v24, v9, v1
    s.movz       s4, #5
    vf.fma       v1, v24, v13, v7
    v.permute    v13, v5, v17
    vf.fma       v24, v13, v19, v21
    v.permute    v13, v8, v3
    v.permute    v21, v9, v3
    s.movz       s30, #6
    vf.fma       v3, v13, v15, v22
    v.movi       v13, #5
    vf.fma       v22, v21, v15, v1
    v.permute    v1, v6, v18
    a.vread      v15, a2, s4
    vf.fma       v21, v1, v20, v23
    v.permute    v1, v5, v13
    vf.fma       v23, v1, v15, v24
    v.permute    v1, v8, v14
    v.permute    v24, v9, v14
    s.movz       s4, #7
    vf.fma       v14, v1, v16, v3
    v.movi       v1, #6
    vf.fma       v3, v24, v16, v22
    v.permute    v16, v6, v17
    a.vread      v22, a2, s30
    vf.fma       v24, v16, v19, v21
    v.permute    v16, v5, v1
    vf.fma       v21, v16, v22, v23
    v.permute    v16, v8, v18
    v.permute    v23, v9, v18
    s.movz       s30, #8
    vf.fma       v18, v16, v20, v14
    v.movi       v14, #7
    vf.fma       v16, v23, v20, v3
    v.permute    v3, v6, v13
    a.vread      v20, a2, s4
    vf.fma       v23, v3, v15, v24
    v.permute    v3, v5, v14
    vf.fma       v24, v3, v20, v21
    v.permute    v3, v8, v17
    v.permute    v21, v9, v17
    s.movz       s4, #9
    vf.fma       v17, v3, v19, v18
    v.movi       v3, #8
    vf.fma       v18, v21, v19, v16
    v.permute    v16, v6, v1
    a.vread      v19, a2, s30
    vf.fma       v21, v16, v22, v23
    v.permute    v16, v5, v3
    vf.fma       v23, v16, v19, v24
    v.permute    v16, v8, v13
    v.permute    v24, v9, v13
    s.movz       s30, #10
    vf.fma       v13, v16, v15, v17
    v.movi       v16, #9
    vf.fma       v17, v24, v15, v18
    v.permute    v15, v6, v14
    a.vread      v18, a2, s4
    vf.fma       v24, v15, v20, v21
    v.permute    v15, v5, v16
    vf.fma       v21, v15, v18, v23
    v.permute    v15, v8, v1
    v.permute    v23, v9, v1
    s.movz       s4, #11
    vf.fma       v1, v15, v22, v13
    v.movi       v13, #10
    vf.fma       v15, v23, v22, v17
    v.permute    v17, v6, v3
    a.vread      v22, a2, s30
    vf.fma       v23, v17, v19, v24
    v.permute    v17, v5, v13
    vf.fma       v24, v17, v22, v21
    v.permute    v17, v8, v14
    v.permute    v21, v9, v14
    s.movz       s30, #12
    vf.fma       v14, v17, v20, v1
    v.movi       v1, #11
    vf.fma       v17, v21, v20, v15
    v.permute    v15, v6, v16
    a.vread      v20, a2, s4
    vf.fma       v21, v15, v18, v23
    v.permute    v15, v5, v1
    vf.fma       v23, v15, v20, v24
    v.permute    v15, v8, v3
    v.permute    v24, v9, v3
    s.movz       s4, #13
    vf.fma       v3, v15, v19, v14
    v.movi       v14, #12
    vf.fma       v15, v24, v19, v17
    v.permute    v17, v6, v13
    a.vread      v19, a2, s30
    vf.fma       v24, v17, v22, v21
    v.permute    v17, v5, v14
    vf.fma       v21, v17, v19, v23
    v.permute    v17, v8, v16
    v.permute    v23, v9, v16
    s.movz       s31, #14
    vf.fma       v16, v17, v18, v3
    v.movi       v3, #13
    vf.fma       v17, v23, v18, v15
    v.permute    v15, v6, v1
    a.vread      v18, a2, s4
    vf.fma       v23, v15, v20, v24
    v.permute    v15, v5, v3
    vf.fma       v24, v15, v18, v21
    v.permute    v15, v8, v13
    v.permute    v21, v9, v13
    s.movz       s32, #15
    vf.fma       v13, v15, v22, v16
    v.movi       v15, #14
    vf.fma       v16, v21, v22, v17
    v.permute    v17, v6, v14
    a.vread      v21, a2, s31
    vf.fma       v22, v17, v19, v23
    v.permute    v17, v5, v15
    vf.fma       v23, v17, v21, v24
    v.permute    v17, v8, v1
    v.permute    v24, v9, v1
    s.movz       s34, #8
    vf.fma       v1, v17, v20, v13
    v.movi       v13, #15
    vf.fma       v17, v24, v20, v16
    v.permute    v16, v6, v3
    a.vread      v20, a2, s32
    v.permute    v24, v5, v13
    vf.fma       v5, v16, v18, v22
    v.permute    v16, v8, v14
    vf.fma       v22, v24, v20, v23
    v.permute    v23, v6, v15
    vf.fma       v24, v16, v19, v1
    a.vread      v1, a0, s34
    vf.fma       v16, v23, v21, v5
    v.permute    v5, v8, v3
    v.permute    v23, v6, v13
    vf.add       v6, v1, v22
    v.permute    v1, v9, v14
    vf.fma       v14, v5, v18, v24
    v.permute    v5, v8, v15
    vf.fma       v22, v23, v20, v16
    s.movz       s35, #9
    vf.fma       v16, v1, v19, v17
    a.vwrite     a0, s34, v6
    a.vread      v1, a0, s35
    v.permute    v6, v9, v3
    vf.fma       v3, v5, v21, v14
    v.permute    v5, v8, v13
    vf.add       v8, v1, v22
    vf.fma       v1, v6, v18, v16
    v.permute    v6, v9, v15
    vf.fma       v14, v5, v20, v3
    s.movz       s34, #10
    a.vwrite     a0, s35, v8
    a.vread      v3, a0, s34
    vf.fma       v5, v6, v21, v1
    v.permute    v1, v9, v13
    vf.add       v6, v3, v14
    s.movz       s35, #11
    v.movi       v3, #0
    vf.fma       v8, v1, v20, v5
    s.movz       s36, #0
    a.vwrite     a0, s34, v6
    a.vread      v1, a0, s35
    v.movi       v5, #1
    s.movz       s34, #1
    vf.add       v6, v1, v8
    v.movi       v1, #2
    s.movz       s37, #2
    v.movi       v8, #3
    s.movz       s38, #3
    a.vwrite     a0, s35, v6
    a.vread      v6, a1, s30
    a.vread      v9, a1, s4
    a.vread      v13, a1, s31
    a.vread      v14, a1, s32
    a.vread      v15, a2, s36
    v.permute    v16, v6, v3
    a.vread      v17, a2, s34
    v.permute    v18, v6, v5
    vf.fma       v19, v16, v15, v7
    v.permute    v16, v9, v3
    a.vread      v20, a2, s37
    v.permute    v21, v6, v1
    vf.fma       v22, v16, v15, v7
    vf.fma       v16, v18, v17, v19
    v.permute    v18, v9, v5
    a.vread      v19, a2, s38
    v.permute    v23, v6, v8
    vf.fma       v24, v18, v17, v22
    vf.fma       v18, v21, v20, v16
    v.permute    v16, v13, v3
    v.movi       v21, #4
    s.movz       s4, #4
    vf.fma       v22, v16, v15, v7
    vf.fma       v16, v23, v19, v18
    v.permute    v18, v9, v1
    v.permute    v23, v14, v3
    s.movz       s30, #5
    vf.fma       v3, v18, v20, v24
    a.vread      v18, a2, s4
    vf.fma       v24, v23, v15, v7
    v.permute    v7, v6, v21
    v.permute    v15, v13, v5
    v.permute    v23, v14, v5
    vf.fma       v5, v7, v18, v16
    v.movi       v7, #5
    vf.fma       v16, v15, v17, v22
    v.permute    v15, v9, v8
    s.movz       s4, #6
    vf.fma       v22, v23, v17, v24
    a.vread      v17, a2, s30
    v.permute    v23, v6, v7
    vf.fma       v24, v15, v19, v3
    v.permute    v3, v13, v1
    vf.fma       v15, v23, v17, v5
    v.movi       v5, #6
    vf.fma       v23, v3, v20, v16
    v.permute    v3, v9, v21
    v.permute    v16, v14, v1
    s.movz       s30, #7
    vf.fma       v1, v3, v18, v24
    a.vread      v3, a2, s4
    vf.fma       v24, v16, v20, v22
    v.permute    v16, v6, v5
    v.permute    v20, v13, v8
    v.permute    v22, v14, v8
    vf.fma       v8, v16, v3, v15
    v.movi       v15, #7
    vf.fma       v16, v20, v19, v23
    v.permute    v20, v9, v7
    s.movz       s4, #8
    vf.fma       v23, v22, v19, v24
    a.vread      v19, a2, s30
    v.permute    v22, v6, v15
    vf.fma       v24, v20, v17, v1
    v.permute    v1, v13, v21
    vf.fma       v20, v22, v19, v8
    v.movi       v8, #8
    vf.fma       v22, v1, v18, v16
    v.permute    v1, v9, v5
    v.permute    v16, v14, v21
    s.movz       s30, #9
    vf.fma       v21, v1, v3, v24
    a.vread      v1, a2, s4
    vf.fma       v24, v16, v18, v23
    v.permute    v16, v6, v8
    v.permute    v18, v13, v7
    v.permute    v23, v14, v7
    vf.fma       v7, v16, v1, v20
    v.movi       v16, #9
    vf.fma       v20, v18, v17, v22
    v.permute    v18, v9, v15
    s.movz       s4, #10
    vf.fma       v22, v23, v17, v24
    a.vread      v17, a2, s30
    v.permute    v23, v6, v16
    vf.fma       v24, v18, v19, v21
    v.permute    v18, v13, v5
    vf.fma       v21, v23, v17, v7
    v.movi       v7, #10
    vf.fma       v23, v18, v3, v20
    v.permute    v18, v9, v8
    v.permute    v20, v14, v5
    s.movz       s30, #11
    vf.fma       v5, v18, v1, v24
    a.vread      v18, a2, s4
    vf.fma       v24, v20, v3, v22
    v.permute    v3, v6, v7
    v.permute    v20, v13, v15
    v.permute    v22, v14, v15
    vf.fma       v15, v3, v18, v21
    v.movi       v3, #11
    vf.fma       v21, v20, v19, v23
    v.permute    v20, v9, v16
    s.movz       s4, #12
    vf.fma       v23, v22, v19, v24
    a.vread      v19, a2, s30
    v.permute    v22, v6, v3
    vf.fma       v24, v20, v17, v5
    v.permute    v5, v13, v8
    vf.fma       v20, v22, v19, v15
    v.movi       v15, #12
    vf.fma       v22, v5, v1, v21
    v.permute    v5, v9, v7
    v.permute    v21, v14, v8
    s.movz       s30, #13
    vf.fma       v8, v5, v18, v24
    a.vread      v5, a2, s4
    vf.fma       v24, v21, v1, v23
    v.permute    v1, v6, v15
    v.permute    v21, v13, v16
    v.permute    v23, v14, v16
    vf.fma       v16, v1, v5, v20
    v.movi       v1, #13
    vf.fma       v20, v21, v17, v22
    v.permute    v21, v9, v3
    s.movz       s31, #14
    vf.fma       v22, v23, v17, v24
    a.vread      v17, a2, s30
    v.permute    v23, v6, v1
    vf.fma       v24, v21, v19, v8
    v.permute    v8, v13, v7
    vf.fma       v21, v23, v17, v16
    v.movi       v16, #14
    vf.fma       v23, v8, v18, v20
    v.permute    v8, v9, v15
    v.permute    v20, v14, v7
    s.movz       s32, #15
    vf.fma       v7, v8, v5, v24
    a.vread      v8, a2, s31
    vf.fma       v24, v20, v18, v22
    v.permute    v18, v6, v16
    v.permute    v20, v13, v3
    v.permute    v22, v14, v3
    vf.fma       v3, v18, v8, v21
    v.movi       v18, #15
    vf.fma       v21, v20, v19, v23
    v.permute    v20, v9, v1
    v.permute    v23, v6, v18
    vf.fma       v6, v22, v19, v24
    a.vread      v19, a2, s32
    v.permute    v22, v13, v15
    vf.fma       v24, v20, v17, v7
    v.permute    v7, v9, v16
    vf.fma       v20, v23, v19, v3
    vf.fma       v3, v22, v5, v21
    a.vread      v21, a0, s4
    v.permute    v22, v13, v1
    vf.fma       v23, v7, v8, v24
    v.permute    v7, v9, v18
    vf.add       v9, v21, v20
    v.permute    v20, v14, v15
    vf.fma       v15, v22, v17, v3
    v.permute    v3, v13, v16
    vf.fma       v21, v7, v19, v23
    vf.fma       v7, v20, v5, v6
    a.vwrite     a0, s4, v9
    a.vread      v5, a0, s30
    v.permute    v6, v14, v1
    vf.fma       v1, v3, v8, v15
    v.permute    v3, v13, v18
    vf.add       v9, v5, v21
    vf.fma       v5, v6, v17, v7
    v.permute    v6, v14, v16
    vf.fma       v7, v3, v19, v1
    v.permute    v1, v14, v18
    a.vwrite     a0, s30, v9
    a.vread      v3, a0, s31
    vf.fma       v9, v6, v8, v5
    s.add        s4, s33, s26
    vf.add       v5, v3, v7
    s.movz       s30, #1
    vf.fma       v3, v1, v19, v9
    a.vwrite     a0, s31, v5
    a.vread      v1, a0, s32
    vf.add       v5, v1, v3
    a.vwrite     a0, s32, v5
    s.mov        s33, s4
    br.nz        s30, for_1
endfor_2:
    s.movz       s4, #0
    v.extract    s30, v12, #0
    s.add        s31, s4, s6                     // the tile origin
    v.extract    s4, v12, #1
    v.extract    s32, v12, #2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s31
    v.splat      v3, s30
    v.splat      v5, s1
    v.splat      v6, s4
    v.splat      v7, s32
    v.extract    s4, v4, #0
    s.movz       s30, #256
    v.extract    s31, v4, #1
    v.extract    s32, v4, #2
    v.add        v8, v0, v1
    v.mul        v0, v3, v5
    v.splat      v1, s4
    v.splat      v3, s30
    v.mul        v9, v6, v5
    v.splat      v6, s31
    v.mul        v13, v7, v5
    v.splat      v7, s32
    v.add        v14, v8, v0
    v.mul        v0, v1, v3
    v.add        v1, v8, v9
    v.mul        v9, v6, v3
    v.add        v6, v8, v13
    v.splat      v13, s2
    v.add        v15, v14, v0
    v.add        v0, v1, v9
    s.addi       s4, s8, #3136
    v.add        v1, v13, v15
    v.add        v9, v13, v0
    s.addi       s30, s4, #64
    s.addi       s31, s4, #128
    v.movi       v0, #1
    v.mul        v14, v7, v3
    v.movi       v7, #0
    v.st.w       [s4, #0], v1
    v.cmp.lt     p1, v2, v0
    v.add        v1, v6, v14
    v.cmp.lt     p2, v4, v10
    v.movi       v2, #1
    v.add        v6, v13, v1
    @p1 v.sel        v1, v0, v7
    s.addi       s32, s4, #192
    @p2 v.sel        v14, v0, v7
    v.extract    s33, v12, #3
    v.cmp.lt     p1, v12, v10
    v.splat      v0, s33
    @p1 v.sel        v15, v2, v7
    v.cmp.lt     p1, v11, v10
    v.extract    s33, v12, #4
    v.extract    s34, v12, #5
    v.extract    s35, v12, #6
    v.splat      v2, s33
    v.splat      v7, s34
    v.splat      v10, s35
    v.extract    s33, v4, #3
    v.extract    s34, v4, #4
    v.extract    s35, v4, #5
    v.mul        v11, v0, v5
    v.mul        v0, v2, v5
    v.mul        v2, v7, v5
    v.add        v7, v8, v11
    v.add        v11, v8, v0
    v.add        v0, v8, v2
    v.st.w       [s30, #0], v9
    v.extract    s30, v12, #7
    v.splat      v2, s33
    v.extract    s33, v4, #6
    v.mul        v9, v10, v5
    v.mul        v10, v2, v3
    v.add        v2, v8, v9
    v.add        v9, v7, v10
    v.splat      v7, s30
    s.addi       s30, s4, #256
    v.add        v10, v13, v9
    v.st.w       [s31, #0], v6
    v.extract    s31, v12, #8
    v.splat      v6, s34
    v.extract    s34, v4, #7
    v.mul        v9, v7, v5
    v.mul        v7, v6, v3
    v.add        v6, v8, v9
    v.add        v9, v11, v7
    v.splat      v7, s31
    s.addi       s31, s4, #320
    v.add        v11, v13, v9
    v.st.w       [s32, #0], v10
    v.extract    s32, v12, #9
    v.splat      v9, s35
    v.extract    s35, v4, #8
    v.mul        v10, v7, v5
    v.mul        v7, v9, v3
    v.add        v9, v8, v10
    v.add        v10, v0, v7
    v.splat      v0, s32
    s.addi       s32, s4, #384
    v.add        v7, v13, v10
    v.st.w       [s30, #0], v11
    v.extract    s30, v12, #10
    v.splat      v10, s33
    v.extract    s33, v4, #9
    v.mul        v11, v0, v5
    v.mul        v0, v10, v3
    v.add        v10, v8, v11
    v.add        v11, v2, v0
    v.splat      v0, s30
    s.addi       s30, s4, #448
    v.add        v2, v13, v11
    v.st.w       [s31, #0], v7
    v.extract    s31, v12, #11
    v.splat      v7, s34
    v.extract    s34, v4, #10
    v.mul        v11, v0, v5
    v.mul        v0, v7, v3
    v.add        v7, v8, v11
    v.add        v11, v6, v0
    v.splat      v0, s31
    s.addi       s31, s4, #512
    v.add        v6, v13, v11
    v.st.w       [s32, #0], v2
    v.extract    s32, v12, #12
    v.splat      v2, s35
    v.extract    s35, v4, #11
    v.mul        v11, v0, v5
    v.mul        v0, v2, v3
    v.add        v2, v8, v11
    v.add        v11, v9, v0
    v.splat      v0, s32
    s.addi       s32, s4, #576
    v.add        v9, v13, v11
    v.st.w       [s30, #0], v6
    v.extract    s30, v12, #13
    v.splat      v6, s33
    v.extract    s33, v4, #12
    v.mul        v11, v0, v5
    v.mul        v0, v6, v3
    v.add        v6, v8, v11
    v.add        v11, v10, v0
    v.splat      v0, s30
    s.addi       s30, s4, #640
    v.add        v10, v13, v11
    v.st.w       [s31, #0], v9
    v.extract    s31, v12, #14
    v.splat      v9, s34
    v.extract    s34, v4, #13
    v.mul        v11, v0, v5
    v.mul        v0, v9, v3
    v.add        v9, v8, v11
    v.add        v11, v7, v0
    v.splat      v0, s31
    s.addi       s31, s4, #704
    v.add        v7, v13, v11
    v.st.w       [s32, #0], v10
    v.extract    s32, v12, #15
    v.splat      v10, s35
    v.splat      v11, s32
    v.extract    s32, v4, #14
    v.mul        v12, v0, v5
    v.mul        v0, v10, v3
    s.addi       s35, s4, #768
    v.add        v10, v8, v12
    v.add        v12, v2, v0
    v.splat      v0, s33
    s.addi       s33, s4, #832
    v.add        v2, v13, v12
    v.mul        v12, v0, v3
    v.add        v0, v6, v12
    v.splat      v6, s34
    s.addi       s34, s4, #896
    v.add        v12, v13, v0
    v.mul        v0, v6, v3
    s.addi       s36, s4, #960
    v.st.w       [s30, #0], v7
    v.extract    s4, v4, #15
    v.splat      v4, s32
    v.mul        v6, v11, v5
    v.splat      v5, s4
    v.mul        v7, v4, v3
    v.add        v4, v8, v6
    v.mul        v6, v5, v3
    v.add        v3, v9, v0
    v.add        v0, v10, v7
    v.add        v5, v4, v6
    v.add        v4, v13, v3
    v.add        v3, v13, v0
    v.add        v0, v13, v5
    s.movz       s4, #0
    v.st.w       [s31, #0], v2
    s.addi       s30, s8, #3136
    v.extract    s31, v1, #0
    v.movi       v2, #0
    v.splat      v5, s31
    v.extract    s31, v14, #0
    v.splat      v6, s31
    v.extract    s31, v15, #0
    v.cmp.ne     p2, v5, v2
    v.cmp.ne     p3, v6, v2
    p.and        p4, p2, p3
    v.st.w       [s35, #0], v12
    v.splat      v2, s31
    v.movi       v5, #0
    s.movz       s31, #1
    s.addi       s32, s8, #3200
    v.cmp.ne     p2, v2, v5
    p.and        p3, p4, p2
    p.and        p2, p3, p1
    v.st.w       [s33, #0], v4
    v.extract    s33, v1, #1
    v.movi       v2, #0
    v.splat      v4, s33
    v.extract    s33, v14, #1
    v.movi       v5, #0
    v.splat      v6, s33
    v.extract    s33, v15, #1
    v.cmp.ne     p3, v4, v2
    v.splat      v4, s33
    v.cmp.ne     p4, v6, v2
    p.and        p5, p3, p4
    v.cmp.ne     p3, v4, v5
    v.st.w       [s34, #0], v3
    p.and        p4, p5, p3
    s.movz       s33, #2
    p.and        p3, p4, p1
    s.addi       s34, s8, #3264
    v.movi       v2, #0
    v.st.w       [s36, #0], v0
    fence.acq_rel.device
    a.vread      v0, a0, s4
    v.extract    s4, v1, #2
    v.extract    s35, v14, #2
    v.splat      v3, s4
    v.splat      v4, s35
    v.extract    s4, v15, #2
    v.cmp.ne     p4, v3, v2
    v.ld.w       v3, [s30, #0]
    v.splat      v5, s4
    v.movi       v6, #0
    s.movz       s4, #3
    s.addi       s30, s8, #3328
    v.extract    s35, v1, #3
    v.movi       v7, #0
    v.splat      v8, s35
    v.extract    s35, v14, #3
    @p2 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s31
    v.cmp.ne     p2, v4, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v6
    p.and        p4, p5, p2
    v.splat      v2, s35
    p.and        p2, p4, p1
    v.extract    s31, v15, #3
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s32, #0]
    v.splat      v4, s31
    v.movi       v5, #0
    s.movz       s31, #4
    s.addi       s32, s8, #3392
    v.extract    s35, v1, #4
    v.movi       v6, #0
    v.splat      v8, s35
    v.extract    s35, v14, #4
    @p3 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s33
    v.cmp.ne     p3, v2, v7
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    v.splat      v2, s35
    p.and        p3, p4, p1
    v.extract    s33, v15, #4
    v.cmp.ne     p4, v8, v6
    v.ld.w       v3, [s34, #0]
    v.splat      v4, s33
    v.movi       v5, #0
    s.movz       s33, #5
    s.addi       s34, s8, #3456
    v.extract    s35, v1, #5
    v.movi       v7, #0
    v.splat      v8, s35
    v.extract    s35, v14, #5
    @p2 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s4
    v.cmp.ne     p2, v2, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v5
    p.and        p4, p5, p2
    v.splat      v2, s35
    p.and        p2, p4, p1
    v.extract    s4, v15, #5
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s30, #0]
    v.splat      v4, s4
    v.movi       v5, #0
    s.movz       s4, #6
    s.addi       s30, s8, #3520
    v.extract    s35, v1, #6
    v.movi       v6, #0
    v.splat      v8, s35
    v.extract    s35, v14, #6
    @p3 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s31
    v.cmp.ne     p3, v2, v7
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    v.splat      v2, s35
    p.and        p3, p4, p1
    v.extract    s31, v15, #6
    v.cmp.ne     p4, v8, v6
    v.ld.w       v3, [s32, #0]
    v.splat      v4, s31
    v.movi       v5, #0
    s.movz       s31, #7
    s.addi       s32, s8, #3584
    v.extract    s35, v1, #7
    v.movi       v7, #0
    v.splat      v8, s35
    v.extract    s35, v14, #7
    @p2 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s33
    v.cmp.ne     p2, v2, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v5
    p.and        p4, p5, p2
    v.splat      v2, s35
    p.and        p2, p4, p1
    v.extract    s33, v15, #7
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s34, #0]
    v.splat      v4, s33
    v.movi       v5, #0
    s.movz       s33, #8
    s.addi       s34, s8, #3648
    v.extract    s35, v1, #8
    v.movi       v6, #0
    v.splat      v8, s35
    v.extract    s35, v14, #8
    @p3 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s4
    v.cmp.ne     p3, v2, v7
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    v.splat      v2, s35
    p.and        p3, p4, p1
    v.extract    s4, v15, #8
    v.cmp.ne     p4, v8, v6
    v.ld.w       v3, [s30, #0]
    v.splat      v4, s4
    v.movi       v5, #0
    s.movz       s4, #9
    s.addi       s30, s8, #3712
    v.extract    s35, v1, #9
    v.movi       v7, #0
    v.splat      v8, s35
    v.extract    s35, v14, #9
    @p2 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s31
    v.cmp.ne     p2, v2, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v5
    p.and        p4, p5, p2
    v.splat      v2, s35
    p.and        p2, p4, p1
    v.extract    s31, v15, #9
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s32, #0]
    v.splat      v4, s31
    v.movi       v5, #0
    s.movz       s31, #10
    s.addi       s32, s8, #3776
    v.extract    s35, v1, #10
    v.movi       v6, #0
    v.splat      v8, s35
    v.extract    s35, v14, #10
    @p3 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s33
    v.cmp.ne     p3, v2, v7
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    v.splat      v2, s35
    p.and        p3, p4, p1
    v.extract    s33, v15, #10
    v.cmp.ne     p4, v8, v6
    v.ld.w       v3, [s34, #0]
    v.splat      v4, s33
    v.movi       v5, #0
    s.movz       s33, #11
    s.addi       s34, s8, #3840
    v.extract    s35, v1, #11
    v.movi       v7, #0
    v.splat      v8, s35
    v.extract    s35, v14, #11
    @p2 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s4
    v.cmp.ne     p2, v2, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v5
    p.and        p4, p5, p2
    v.splat      v2, s35
    p.and        p2, p4, p1
    v.extract    s4, v15, #11
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s30, #0]
    v.splat      v4, s4
    v.movi       v5, #0
    s.movz       s4, #12
    s.addi       s30, s8, #3904
    v.extract    s35, v1, #12
    v.movi       v6, #0
    v.splat      v8, s35
    v.extract    s35, v14, #12
    @p3 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s31
    v.cmp.ne     p3, v2, v7
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    v.splat      v2, s35
    p.and        p3, p4, p1
    v.extract    s31, v15, #12
    v.cmp.ne     p4, v8, v6
    v.ld.w       v3, [s32, #0]
    v.splat      v4, s31
    v.movi       v5, #0
    s.movz       s31, #13
    s.addi       s32, s8, #3968
    v.extract    s35, v1, #13
    v.movi       v7, #0
    v.splat      v8, s35
    v.extract    s35, v14, #13
    @p2 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s33
    v.cmp.ne     p2, v2, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v5
    p.and        p4, p5, p2
    v.splat      v2, s35
    p.and        p2, p4, p1
    v.extract    s33, v15, #13
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s34, #0]
    v.splat      v4, s33
    v.movi       v5, #0
    s.movz       s33, #14
    s.addi       s34, s8, #4032
    v.extract    s35, v1, #14
    v.movi       v6, #0
    v.splat      v8, s35
    v.extract    s35, v14, #14
    @p3 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s4
    v.cmp.ne     p3, v2, v7
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    v.splat      v2, s35
    p.and        p3, p4, p1
    v.extract    s4, v15, #14
    v.cmp.ne     p4, v8, v6
    v.ld.w       v3, [s30, #0]
    v.splat      v4, s4
    v.movi       v5, #0
    s.movz       s4, #15
    s.addi       s30, s8, #4096
    v.extract    s35, v1, #15
    v.movi       v1, #0
    v.splat      v7, s35
    v.extract    s35, v14, #15
    @p2 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s31
    v.cmp.ne     p2, v2, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v5
    p.and        p4, p5, p2
    v.splat      v2, s35
    p.and        p2, p4, p1
    v.extract    s31, v15, #15
    v.cmp.ne     p4, v7, v1
    v.ld.w       v3, [s32, #0]
    v.splat      v4, s31
    v.movi       v5, #0
    @p3 v.st.scatter.w [s29, v3], v0
    a.vread      v0, a0, s33
    v.cmp.ne     p3, v2, v1
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    p.and        p3, p4, p1
    v.ld.w       v1, [s34, #0]
    @p2 v.st.scatter.w [s29, v1], v0
    a.vread      v0, a0, s4
    v.ld.w       v1, [s30, #0]
    @p3 v.st.scatter.w [s29, v1], v0
__rctx_next:
    s.addi       s4, s27, #2                     // the next program of this context: + 2
    s.cmp.lt     s30, s4, s28
    s.mov        s27, s4
    br.nz        s30, __rctx_program
    exit
