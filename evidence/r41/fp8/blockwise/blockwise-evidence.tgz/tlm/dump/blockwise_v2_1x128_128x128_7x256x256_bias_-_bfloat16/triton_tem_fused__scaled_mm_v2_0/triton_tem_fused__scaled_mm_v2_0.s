    s.rdspecial  s1, pid.x
    s.movz       s2, #0
    s.movz       s3, #0
    s.cmp.lt     s4, s1, s2
    s.movz       s2, #0
    s.sub        s5, s3, s4
    s.movz       s3, #0
    s.cmp.lt     s4, s1, s2
    s.xor        s2, s1, s5
    s.movz       s6, #2
    s.sub        s7, s3, s4
    s.movz       s3, #0
    s.sub        s4, s2, s5
    s.movz       s2, #0
    s.cmp.lt     s8, s6, s3
    s.xor        s3, s1, s7
    s.lshri      s1, s4, #1
    s.sub        s9, s2, s8
    s.sub        s2, s3, s7
    s.muli       s3, s1, #2
    s.lshri      s1, s2, #1
    s.xor        s8, s7, s9
    s.movz       s7, #16
    s.xor        s10, s1, s8
    s.sub        s11, s4, s3
    s.sub        s3, s10, s8
    s.xor        s4, s11, s5
    s.mul        s8, s3, s7
    s.sub        s3, s4, s5
    s.movz       s4, #0
    s.movz       s5, #0
    s.cmp.lt     s10, s6, s4
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s8
    s.muli       s4, s1, #2
    s.sub        s1, s5, s10
    s.rdspecial  s5, arg_base
    v.add        v2, v1, v0
    s.xor        s10, s6, s9
    s.xor        s11, s6, s1
    s.ld.d       s12, [s5, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.movz       s13, #128
    s.sub        s14, s10, s9
    s.ld.d       s9, [s5, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.mul        s10, s3, s13
    s.sub        s3, s2, s4
    s.ld.d       s2, [s5, #16]                   // arg_SA: device_ptr64 at arg_base+16
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s3, s11, s1
    s.ld.d       s1, [s5, #24]                   // arg_SB: device_ptr64 at arg_base+24
    v.iota       v1                              // arange(0, VLEN)
    s.ld.d       s3, [s5, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    v.movi       v3, #16
    s.ld.d       s4, [s5, #40]                   // out_ptr1: device_ptr64 at arg_base+40
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #32
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #48
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #64
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #80
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #96
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #112
    v.movi       v16, #7
    v.movi       v17, #0
    v.add        v18, v1, v3
    v.add        v1, v4, v5
    v.add        v3, v6, v7
    v.add        v4, v8, v9
    v.add        v5, v10, v11
    v.add        v6, v12, v13
    v.add        v7, v14, v15
    v.splat      v8, s10
    v.splat      v9, s10
    v.splat      v10, s10
    v.splat      v11, s10
    v.splat      v12, s10
    v.splat      v13, s10
    v.splat      v14, s10
    v.splat      v15, s10
    v.sub        v19, v17, v2
    v.sub        v20, v17, v16
    v.cmp.lt     p1, v2, v17
    v.cmp.lt     p2, v16, v17
    v.add        v21, v8, v0
    v.add        v0, v9, v18
    v.add        v8, v10, v1
    v.add        v1, v11, v3
    v.add        v3, v12, v4
    v.add        v4, v13, v5
    v.add        v5, v14, v6
    v.add        v6, v15, v7
    v.movi       v7, #1
    @p1 v.sel        v9, v19, v2
    @p2 v.sel        v2, v20, v16
    v.movi       v10, #0
    v.movi       v11, #0
    s.movz       s5, #31
idiv_1:
    v.splat      v12, s5
    v.shl        v13, v11, v7
    v.lshr       v14, v9, v12
    v.cmp.lt     p2, v11, v17
    v.and        v15, v14, v7
    v.shl        v14, v7, v12
    v.or         v12, v13, v15
    s.subi       s11, s5, #1
    v.cmp.geu    p3, v12, v2
    p.or         p4, p2, p3
    v.sub        v13, v12, v2
    @p4 v.sel        v15, v14, v17
    @p4 v.sel        v14, v13, v12
    v.or         v12, v10, v15
    v.mov        v11, v14
    v.mov        v10, v12
    s.mov        s5, s11
    s.movz       s11, #0
    s.cmp.ge     s14, s5, s11
    br.nz        s14, idiv_1
    v.sub        v2, v17, v11
    @p1 v.sel        v7, v2, v11
    v.movi       v2, #256
    v.movi       v9, #0
    v.movi       v10, #1
    v.cmp.lt     p1, v21, v9
    v.cmp.lt     p2, v2, v9
    v.sub        v10, v9, v21
    @p1 v.sel        v11, v10, v21
    v.sub        v10, v9, v2
    @p2 v.sel        v12, v10, v2
    v.movi       v2, #255
    v.and        v10, v11, v2
    v.sub        v2, v9, v10
    @p1 v.sel        v9, v2, v10
    v.movi       v2, #256
    v.movi       v10, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v0, v10
    v.cmp.lt     p2, v2, v10
    v.sub        v11, v10, v0
    @p1 v.sel        v12, v11, v0
    v.sub        v0, v10, v2
    @p2 v.sel        v11, v0, v2
    v.movi       v0, #255
    v.and        v2, v12, v0
    v.sub        v0, v10, v2
    @p1 v.sel        v10, v0, v2
    v.movi       v0, #256
    v.movi       v2, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v8, v2
    v.cmp.lt     p2, v0, v2
    v.sub        v11, v2, v8
    @p1 v.sel        v12, v11, v8
    v.sub        v8, v2, v0
    @p2 v.sel        v11, v8, v0
    v.movi       v0, #255
    v.and        v8, v12, v0
    v.sub        v0, v2, v8
    @p1 v.sel        v2, v0, v8
    v.movi       v0, #256
    v.movi       v8, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v1, v8
    v.cmp.lt     p2, v0, v8
    v.sub        v11, v8, v1
    @p1 v.sel        v12, v11, v1
    v.sub        v1, v8, v0
    @p2 v.sel        v11, v1, v0
    v.movi       v0, #255
    v.and        v1, v12, v0
    v.sub        v0, v8, v1
    @p1 v.sel        v8, v0, v1
    v.movi       v0, #256
    v.movi       v1, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v0, v1
    v.sub        v11, v1, v3
    @p1 v.sel        v12, v11, v3
    v.sub        v3, v1, v0
    @p2 v.sel        v11, v3, v0
    v.movi       v0, #255
    v.and        v3, v12, v0
    v.sub        v0, v1, v3
    @p1 v.sel        v1, v0, v3
    v.movi       v0, #256
    v.movi       v3, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v0, v3
    v.sub        v11, v3, v4
    @p1 v.sel        v12, v11, v4
    v.sub        v4, v3, v0
    @p2 v.sel        v11, v4, v0
    v.movi       v0, #255
    v.and        v4, v12, v0
    v.sub        v0, v3, v4
    @p1 v.sel        v3, v0, v4
    v.movi       v0, #256
    v.movi       v4, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v5, v4
    v.cmp.lt     p2, v0, v4
    v.sub        v11, v4, v5
    @p1 v.sel        v12, v11, v5
    v.sub        v5, v4, v0
    @p2 v.sel        v11, v5, v0
    v.movi       v0, #255
    v.and        v5, v12, v0
    v.sub        v0, v4, v5
    @p1 v.sel        v4, v0, v5
    v.movi       v0, #256
    v.movi       v5, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v6, v5
    v.cmp.lt     p2, v0, v5
    v.sub        v11, v5, v6
    @p1 v.sel        v12, v11, v6
    v.sub        v6, v5, v0
    @p2 v.sel        v11, v6, v0
    v.movi       v0, #255
    v.and        v6, v12, v0
    v.sub        v0, v5, v6
    @p1 v.sel        v5, v0, v6
    s.movz       s5, #32
    s.movz       s11, #48
    s.movz       s14, #64
    s.movz       s15, #80
    s.movz       s16, #96
    s.movz       s17, #112
    v.movi       v0, #128
    v.movi       v6, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v9, v6
    v.cmp.lt     p2, v0, v6
    v.sub        v11, v6, v9
    @p1 v.sel        v12, v11, v9
    v.sub        v11, v6, v0
    @p2 v.sel        v13, v11, v0
    v.movi       v0, #7
    v.lshr       v11, v12, v0
    v.sub        v0, v6, v11
    @p1 v.sel        v6, v0, v11
    v.movi       v0, #128
    v.movi       v11, #0
    v.movi       v12, #1
    v.cmp.lt     p1, v10, v11
    v.cmp.lt     p2, v0, v11
    v.sub        v12, v11, v10
    @p1 v.sel        v13, v12, v10
    v.sub        v12, v11, v0
    @p2 v.sel        v14, v12, v0
    v.movi       v0, #7
    v.lshr       v12, v13, v0
    v.sub        v0, v11, v12
    @p1 v.sel        v11, v0, v12
    v.movi       v0, #128
    v.movi       v12, #0
    v.movi       v13, #1
    v.cmp.lt     p1, v2, v12
    v.cmp.lt     p2, v0, v12
    v.sub        v13, v12, v2
    @p1 v.sel        v14, v13, v2
    v.sub        v13, v12, v0
    @p2 v.sel        v15, v13, v0
    v.movi       v0, #7
    v.lshr       v13, v14, v0
    v.sub        v0, v12, v13
    @p1 v.sel        v12, v0, v13
    v.movi       v0, #128
    v.movi       v13, #0
    v.movi       v14, #1
    v.cmp.lt     p1, v8, v13
    v.cmp.lt     p2, v0, v13
    v.sub        v14, v13, v8
    @p1 v.sel        v15, v14, v8
    v.sub        v14, v13, v0
    @p2 v.sel        v16, v14, v0
    v.movi       v0, #7
    v.lshr       v14, v15, v0
    v.sub        v0, v13, v14
    @p1 v.sel        v13, v0, v14
    v.movi       v0, #128
    v.movi       v14, #0
    v.movi       v15, #1
    v.cmp.lt     p1, v1, v14
    v.cmp.lt     p2, v0, v14
    v.sub        v15, v14, v1
    @p1 v.sel        v16, v15, v1
    v.sub        v15, v14, v0
    @p2 v.sel        v17, v15, v0
    v.movi       v0, #7
    v.lshr       v15, v16, v0
    v.sub        v0, v14, v15
    @p1 v.sel        v14, v0, v15
    v.movi       v0, #128
    v.movi       v15, #0
    v.movi       v16, #1
    v.cmp.lt     p1, v3, v15
    v.cmp.lt     p2, v0, v15
    v.sub        v16, v15, v3
    @p1 v.sel        v17, v16, v3
    v.sub        v16, v15, v0
    @p2 v.sel        v18, v16, v0
    v.movi       v0, #7
    v.lshr       v16, v17, v0
    v.sub        v0, v15, v16
    @p1 v.sel        v15, v0, v16
    v.movi       v0, #128
    v.movi       v16, #0
    v.movi       v17, #1
    v.cmp.lt     p1, v4, v16
    v.cmp.lt     p2, v0, v16
    v.sub        v17, v16, v4
    @p1 v.sel        v18, v17, v4
    v.sub        v17, v16, v0
    @p2 v.sel        v19, v17, v0
    v.movi       v0, #7
    v.lshr       v17, v18, v0
    v.sub        v0, v16, v17
    @p1 v.sel        v16, v0, v17
    v.movi       v0, #128
    v.movi       v17, #0
    v.movi       v18, #1
    v.cmp.lt     p1, v5, v17
    v.cmp.lt     p2, v0, v17
    v.sub        v18, v17, v5
    @p1 v.sel        v19, v18, v5
    v.sub        v18, v17, v0
    @p2 v.sel        v20, v18, v0
    v.movi       v0, #7
    v.lshr       v18, v19, v0
    v.sub        v0, v17, v18
    @p1 v.sel        v17, v0, v18
    s.movz       s18, #4
    v.movi       v0, #4
    v.mul        v18, v6, v0
    v.movi       v0, #4
    v.mul        v6, v11, v0
    v.movi       v0, #4
    v.mul        v11, v12, v0
    v.movi       v0, #4
    v.mul        v12, v13, v0
    v.movi       v0, #4
    v.mul        v13, v14, v0
    v.movi       v0, #4
    v.mul        v14, v15, v0
    v.movi       v0, #4
    v.mul        v15, v16, v0
    v.movi       v0, #4
    v.mul        v16, v17, v0
    s.movz       s18, #0
    s.movz       s19, #1
    s.addi       s20, s18, #0
    s.movz       s21, #0
    s.addi       s22, s21, #0
    s.movz       s21, #0
    s.addi       s23, s21, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_2:
    s.cmp.ge     s21, s20, s6
    br.nz        s21, endfor_3
    s.mul        s21, s20, s13
    s.movz       s24, #7
    s.movz       s25, #256
    s.mul        s26, s20, s24
    s.shli       s24, s20, #2                    // element offset -> bytes (x4)
    s.sub        s27, s25, s21
    s.add        s21, s1, s24                    // &arg_SB[...]
    s.add        s25, s1, s24                    // &arg_SB[...]
    s.shli       s28, s26, #2                    // element offset -> bytes (x4)
    s.add        s29, s1, s24                    // &arg_SB[...]
    s.add        s30, s2, s28                    // &arg_SA[...]
    s.add        s28, s1, s24                    // &arg_SB[...]
    s.add        s31, s1, s24                    // &arg_SB[...]
    s.add        s32, s1, s24                    // &arg_SB[...]
    s.add        s33, s1, s24                    // &arg_SB[...]
    s.add        s34, s1, s24                    // &arg_SB[...]
    v.ld.gather.w v0, [s30, v7]                  // index is in elements (ISA sec 9.1)
    s.movz       s24, #256
    v.splat      v17, s26
    s.movz       s26, #256
    v.splat      v17, s24
    s.movz       s24, #256
    v.splat      v19, s26
    s.movz       s26, #256
    v.splat      v20, s24
    s.movz       s24, #256
    v.ld.gather.w v21, [s21, v18]                // index is in elements (ISA sec 9.1)
    s.movz       s21, #256
    v.splat      v22, s26
    s.movz       s26, #256
    v.splat      v23, s24
    s.movz       s24, #256
    v.splat      v24, s21
    v.splat      v25, s26
    v.splat      v26, s24
    v.splat      v27, s20
    v.ld.gather.w v27, [s25, v6]                 // index is in elements (ISA sec 9.1)
    v.splat      v28, s20
    s.add        s21, s18, s27
    v.splat      v28, s20
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s24, arg_base
    v.splat      v28, s20
    v.splat      v28, s20
    v.movi       v28, #0
    v.splat      v29, s20
    v.movi       v29, #0
    v.ld.gather.w v30, [s29, v11]                // index is in elements (ISA sec 9.1)
    v.splat      v31, s20
    v.iota       v31                             // arange(0, VLEN)
    v.splat      v32, s20
    v.extract    s25, v9, #0
    v.splat      v32, s25
    s.movz       s26, #0
    v.add        v33, v32, v31
    s.movz       s29, #0
    v.sub        v32, v9, v33
    s.cmp.ge     s30, s21, s29
    v.ld.gather.w v33, [s28, v12]                // index is in elements (ISA sec 9.1)
    s.movz       s28, #0
    v.mul        v34, v9, v17
    s.cmp.ge     s29, s25, s28
    v.mul        v17, v10, v19
    v.mul        v19, v2, v20
    v.mul        v20, v8, v22
    v.mul        v22, v1, v23
    v.mul        v23, v3, v24
    v.mul        v24, v4, v25
    v.ld.gather.w v25, [s31, v13]                // index is in elements (ISA sec 9.1)
    v.reduce.or  s28, v32
    s.cmp.eq     s31, s28, s26
    v.mul        v32, v5, v26
    s.and        s26, s31, s29
    s.and        s28, s26, s30
    v.ld.gather.w v26, [s32, v14]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s33, v15]                // index is in elements (ISA sec 9.1)
    v.extract    s26, v10, #0
    v.splat      v36, s26
    v.ld.gather.w v37, [s34, v16]                // index is in elements (ISA sec 9.1)
    v.extract    s29, v2, #0
    v.add        v38, v36, v31
    v.splat      v36, s29
    v.extract    s31, v8, #0
    v.sub        v39, v10, v38
    v.add        v38, v36, v31
    v.splat      v36, s31
    s.movz       s32, #0
    s.movz       s33, #0
    v.sub        v40, v2, v38
    v.add        v38, v36, v31
    s.cmp.ge     s34, s26, s33
    s.ld.d       s33, [s24, #48]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.sub        v36, v8, v38
    v.insert     v28, s28, #0
    v.extract    s24, v1, #0
    v.splat      v38, s24
    v.insert     v29, s25, #0
    v.reduce.or  s25, v39
    s.cmp.eq     s28, s25, s32
    s.movz       s25, #0
    v.add        v39, v38, v31
    s.and        s32, s28, s34
    s.movz       s28, #0
    v.sub        v38, v1, v39
    s.cmp.ge     s34, s29, s28
    s.and        s28, s32, s30
    v.insert     v28, s28, #1
    v.extract    s28, v3, #0
    v.splat      v39, s28
    v.insert     v29, s26, #1
    v.reduce.or  s26, v40
    s.cmp.eq     s32, s26, s25
    s.movz       s25, #0
    v.add        v40, v39, v31
    s.and        s26, s32, s34
    s.movz       s32, #0
    v.sub        v39, v3, v40
    s.cmp.ge     s34, s31, s32
    s.and        s32, s26, s30
    v.insert     v28, s32, #2
    v.extract    s26, v4, #0
    v.splat      v40, s26
    v.insert     v29, s29, #2
    v.reduce.or  s29, v36
    s.cmp.eq     s32, s29, s25
    s.movz       s25, #0
    v.add        v36, v40, v31
    s.and        s29, s32, s34
    s.movz       s32, #0
    v.sub        v40, v4, v36
    s.cmp.ge     s34, s24, s32
    s.and        s32, s29, s30
    v.insert     v28, s32, #3
    v.extract    s29, v5, #0
    v.splat      v36, s29
    v.insert     v29, s31, #3
    v.reduce.or  s31, v38
    s.cmp.eq     s32, s31, s25
    s.movz       s25, #0
    v.add        v38, v36, v31
    s.and        s31, s32, s34
    s.movz       s32, #0
    v.sub        v31, v5, v38
    s.cmp.ge     s34, s28, s32
    s.and        s32, s31, s30
    s.movz       s31, #0
    v.insert     v28, s32, #4
    v.reduce.or  s31, v39
    s.cmp.eq     s32, s31, s25
    s.movz       s25, #0
    s.and        s31, s32, s34
    s.movz       s32, #0
    v.insert     v29, s24, #4
    v.reduce.or  s24, v40
    s.cmp.eq     s34, s24, s25
    s.cmp.ge     s24, s26, s32
    s.movz       s25, #0
    s.and        s32, s31, s30
    s.and        s31, s34, s24
    s.movz       s24, #0
    v.insert     v28, s32, #5
    v.reduce.or  s32, v31
    s.cmp.eq     s34, s32, s25
    s.cmp.ge     s25, s29, s24
    v.insert     v29, s28, #5
    s.and        s24, s31, s30
    s.and        s28, s34, s25
    v.insert     v28, s24, #6
    v.insert     v29, s26, #6
    s.movz       s24, #256
    s.and        s25, s28, s30
    v.splat      v31, s24
    s.add        s24, s9, s23
    v.mul        v36, v7, v31
    s.addi       s26, s33, #0                    // TensorMap 0: W's rows for a transposed FP8 B
    v.extract    s28, v36, #0
    .li       s30, #2147483647
    s.movz       s31, #256
    s.movz       s32, #1
    v.insert     v28, s25, #7
    s.add        s25, s28, s22
    .li       s28, #137438953488
    v.insert     v29, s29, #7
    s.movz       s29, #0
    v.iota       v31                             // arange(0, VLEN)
    s.add        s34, s29, s27                   // the tile origin
    s.add        s29, s12, s25
    s.st.d       [s26, #0], s24
    v.splat      v38, s34
    .li       s24, #7705171329024
    s.addi       s25, s33, #256
    v.cmp.lt     p1, v31, v38
    s.st.d       [s26, #8], s30
    s.addi       s30, s33, #768                  // TensorMap 1: the gathered fallback B tile
    s.movz       s34, #0
    s.st.d       [s26, #16], s21
    s.st.d       [s26, #48], s31
    s.movz       s31, #32
    s.st.d       [s26, #56], s32
    s.movz       s32, #16
    s.st.d       [s26, #88], s28
    s.movz       s28, #16
    s.st.d       [s26, #104], s24
    s.movz       s24, #1
    td.load      d0, [s26]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s26, #68719476768
    s.st.d       [s30, #0], s25
    .li       s25, #7705171329024
    s.st.d       [s30, #8], s31
    v.extract    s31, v36, #1
    s.add        s34, s31, s22
    s.st.d       [s30, #16], s32
    s.addi       s31, s33, #1024                 // 512 bytes of repack scratch
    s.add        s32, s12, s34
    s.st.d       [s30, #48], s28
    s.addi       s28, s31, #0
    s.st.d       [s30, #56], s24
    v.extract    s24, v36, #2
    s.add        s34, s24, s22
    s.st.d       [s30, #88], s26
    s.addi       s24, s31, #32
    s.add        s26, s12, s34
    s.st.d       [s30, #104], s25
    td.load      d1, [s30]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    v.extract    s25, v36, #3
    s.add        s29, s25, s22
    s.addi       s25, s31, #64
    v.st.b       [s28, #0], v38
    s.add        s28, s12, s29
    v.extract    s29, v36, #4
    s.add        s30, s29, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s32, #0]
    s.addi       s29, s31, #96
    s.add        s32, s12, s30
    v.extract    s30, v36, #5
    v.st.b       [s24, #0], v38
    s.add        s24, s30, s22
    s.addi       s30, s31, #128
    s.add        s34, s12, s24
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s26, #0]
    v.extract    s24, v36, #6
    s.add        s26, s24, s22
    v.st.b       [s25, #0], v38
    s.addi       s24, s31, #160
    s.add        s25, s12, s26
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s28, #0]
    v.extract    s26, v36, #7
    s.add        s28, s26, s22
    v.st.b       [s29, #0], v38
    s.addi       s26, s31, #192
    s.add        s29, s12, s28
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s32, #0]
    v.extract    s28, v36, #8
    s.add        s32, s28, s22
    v.st.b       [s30, #0], v38
    s.addi       s28, s31, #224
    s.add        s30, s12, s32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s34, #0]
    v.extract    s32, v36, #9
    s.add        s34, s32, s22
    v.st.b       [s24, #0], v38
    s.addi       s24, s31, #256
    s.add        s32, s12, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s25, #0]
    v.extract    s25, v36, #10
    s.add        s34, s25, s22
    v.st.b       [s26, #0], v38
    s.addi       s25, s31, #288
    s.add        s26, s12, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    v.extract    s29, v36, #11
    s.add        s34, s29, s22
    v.st.b       [s28, #0], v38
    s.addi       s28, s31, #320
    s.add        s29, s12, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s30, #0]
    v.extract    s30, v36, #12
    s.add        s34, s30, s22
    v.st.b       [s24, #0], v38
    s.addi       s24, s31, #352
    s.add        s30, s12, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s32, #0]
    v.extract    s32, v36, #13
    s.add        s34, s32, s22
    v.st.b       [s25, #0], v38
    s.addi       s25, s31, #384
    s.add        s32, s12, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s26, #0]
    v.extract    s26, v36, #14
    s.add        s34, s26, s22
    v.st.b       [s28, #0], v38
    s.addi       s26, s31, #416
    s.add        s28, s12, s34
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    v.extract    s29, v36, #15
    s.add        s34, s29, s22
    v.st.b       [s24, #0], v38
    s.movz       s24, #0
    s.add        s29, s12, s34
    s.add        s34, s24, s7                    // the tile origin
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s30, #0]
    v.extract    s24, v36, #0
    s.add        s30, s24, s22
    v.splat      v39, s34
    v.st.b       [s25, #0], v38
    s.movz       s24, #0
    s.addi       s25, s31, #448
    s.add        s34, s24, s27                   // the tile origin
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s32, #0]
    s.addi       s24, s30, #16
    v.add        v40, v31, v39
    v.splat      v39, s34
    v.st.b       [s26, #0], v38
    v.extract    s26, v36, #1
    s.addi       s30, s31, #480
    s.add        s32, s12, s24
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s28, #0]
    s.add        s24, s26, s22
    v.cmp.lt     p2, v40, v39
    s.addi       s26, s24, #16
    v.st.b       [s25, #0], v38
    v.extract    s24, v36, #2
    s.addi       s25, s31, #16
    s.add        s28, s12, s26
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.add        s26, s24, s22
    v.extract    s24, v36, #3
    s.addi       s29, s26, #16
    v.st.b       [s30, #0], v38
    s.addi       s26, s31, #48
    s.add        s30, s12, s29
    s.add        s29, s24, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s32, #0]
    s.addi       s24, s29, #16
    v.extract    s29, v36, #4
    s.addi       s32, s31, #80
    v.st.b       [s25, #0], v38
    s.add        s25, s12, s24
    s.add        s24, s29, s22
    v.extract    s29, v36, #5
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s28, #0]
    s.addi       s28, s24, #16
    s.addi       s24, s31, #112
    s.add        s34, s12, s28
    v.st.b       [s26, #0], v38
    s.add        s26, s29, s22
    v.extract    s28, v36, #6
    s.addi       s29, s26, #16
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s30, #0]
    s.addi       s26, s31, #144
    s.add        s30, s12, s29
    s.add        s29, s28, s22
    v.st.b       [s32, #0], v38
    s.addi       s28, s29, #16
    v.extract    s29, v36, #7
    s.add        s32, s12, s28
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s25, #0]
    s.addi       s25, s31, #176
    s.add        s28, s29, s22
    v.st.b       [s24, #0], v38
    s.addi       s24, s28, #16
    v.extract    s28, v36, #8
    s.add        s29, s12, s24
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s34, #0]
    s.addi       s24, s31, #208
    s.add        s34, s28, s22
    v.st.b       [s26, #0], v38
    s.addi       s26, s34, #16
    v.extract    s28, v36, #9
    s.add        s34, s12, s26
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s30, #0]
    s.addi       s26, s31, #240
    s.add        s30, s28, s22
    v.st.b       [s25, #0], v38
    s.addi       s25, s30, #16
    v.extract    s28, v36, #10
    s.add        s30, s12, s25
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s32, #0]
    s.addi       s25, s31, #272
    s.add        s32, s28, s22
    v.st.b       [s24, #0], v38
    s.addi       s24, s32, #16
    v.extract    s28, v36, #11
    s.add        s32, s12, s24
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s29, #0]
    s.addi       s24, s31, #304
    s.add        s29, s28, s22
    v.st.b       [s26, #0], v38
    s.addi       s26, s29, #16
    v.extract    s28, v36, #12
    s.add        s29, s12, s26
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s34, #0]
    s.addi       s26, s31, #336
    s.add        s34, s28, s22
    v.st.b       [s25, #0], v38
    s.addi       s25, s34, #16
    v.extract    s28, v36, #13
    s.add        s34, s12, s25
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s30, #0]
    s.addi       s25, s31, #368
    s.add        s30, s28, s22
    v.st.b       [s24, #0], v38
    s.addi       s24, s30, #16
    v.extract    s28, v36, #14
    s.add        s30, s12, s24
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s32, #0]
    s.addi       s24, s31, #400
    s.add        s32, s28, s22
    v.st.b       [s26, #0], v38
    s.addi       s26, s32, #16
    v.extract    s28, v36, #15
    s.add        s32, s12, s26
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s29, #0]
    s.addi       s26, s31, #432
    s.add        s29, s28, s22
    v.st.b       [s25, #0], v38
    s.addi       s25, s29, #16
    s.addi       s28, s31, #464
    s.add        s29, s12, s25
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s34, #0]
    s.addi       s25, s31, #496
    v.st.b       [s24, #0], v38
    s.addi       s24, s31, #64
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s30, #0]
    s.addi       s30, s31, #128
    v.st.b       [s26, #0], v38
    s.addi       s26, s31, #192
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s32, #0]
    s.addi       s32, s31, #256
    v.st.b       [s28, #0], v38
    s.addi       s28, s31, #320
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s29, #0]
    s.addi       s29, s31, #384
    v.st.b       [s25, #0], v38
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s25, s31, #448
    v.ld.w       v38, [s31, #0]
    v.extract    s31, v28, #0
    v.mov        v48, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s24, #0]
    v.mov        v49, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s30, #0]
    v.mov        v50, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s26, #0]
    v.mov        v51, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s32, #0]
    v.mov        v52, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s28, #0]
    v.mov        v53, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s29, #0]
    v.mov        v54, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s25, #0]
    v.mov        v55, v38                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s31, x8dot_done_4
    s.movz       s24, #0
    s.add        s25, s9, s23
    s.addi       s26, s24, #0
    s.addi       s24, s33, #256
x8dot_row_5:
    s.addi       s28, s21, #0
    v.movi       v38, #0
    s.sub        s29, s28, s26
    s.add        s28, s25, s26
    v.splat      v39, s29
    s.shli       s29, s26, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s28, v34]            // index is in elements (ISA sec 9.1)
    s.add        s28, s24, s29
    s.addi       s29, s26, #1
    s.movz       s30, #32
    v.st.b       [s28, #0], v38
    fence.acq_rel.device
    s.mov        s26, s29
    s.cmp.lt     s28, s26, s30
    br.nz        s28, x8dot_row_5
x8dot_done_4:
    v.splat      v38, s31
    v.movi       v39, #0
    v.splat      v40, s31
    v.movi       v41, #0
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s25, #0
    s.movz       s26, #0
    s.movz       s28, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s29, v29, #0
    s.mov        s30, s25                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s30, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s25, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s25, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    mb.arm       s25, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s26, v28, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s25
    mb.wait      s25
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s26, x8dot_done_6
    s.movz       s28, #0
    s.add        s29, s9, s23
    s.addi       s30, s28, #0
    s.addi       s28, s33, #256
x8dot_row_7:
    s.addi       s31, s21, #0
    v.movi       v38, #0
    s.sub        s32, s31, s30
    s.add        s31, s29, s30
    v.splat      v39, s32
    s.shli       s32, s30, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s31, v17]            // index is in elements (ISA sec 9.1)
    s.add        s31, s28, s32
    s.addi       s32, s30, #1
    s.movz       s34, #32
    v.st.b       [s31, #0], v38
    fence.acq_rel.device
    s.mov        s30, s32
    s.cmp.lt     s31, s30, s34
    br.nz        s31, x8dot_row_7
x8dot_done_6:
    v.splat      v38, s26
    v.movi       v39, #0
    v.splat      v40, s26
    v.movi       v41, #0
    mb.arm       s26, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s28, #0
    s.movz       s29, #0
    s.movz       s30, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s31, v29, #1
    s.mov        s34, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s26            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s28, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s28, s26          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s26
    mb.arm       s28, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s29, v28, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s28
    mb.wait      s28
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s29, x8dot_done_8
    s.movz       s30, #0
    s.add        s31, s9, s23
    s.addi       s32, s30, #0
    s.addi       s30, s33, #256
x8dot_row_9:
    s.addi       s34, s21, #0
    v.movi       v38, #0
    s.sub        s35, s34, s32
    s.add        s34, s31, s32
    v.splat      v39, s35
    s.shli       s35, s32, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s34, v19]            // index is in elements (ISA sec 9.1)
    s.add        s34, s30, s35
    s.addi       s35, s32, #1
    s.movz       s36, #32
    v.st.b       [s34, #0], v38
    fence.acq_rel.device
    s.mov        s32, s35
    s.cmp.lt     s34, s32, s36
    br.nz        s34, x8dot_row_9
x8dot_done_8:
    v.splat      v38, s29
    v.movi       v39, #0
    v.splat      v40, s29
    v.movi       v41, #0
    mb.arm       s29, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    s.movz       s31, #0
    s.movz       s32, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s34, v29, #2
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s29            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s30, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s30, s29          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s29
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v28, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s30
    mb.wait      s30
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s31, x8dot_done_10
    s.movz       s32, #0
    s.add        s34, s9, s23
    s.addi       s35, s32, #0
    s.addi       s32, s33, #256
x8dot_row_11:
    s.addi       s36, s21, #0
    v.movi       v38, #0
    s.sub        s37, s36, s35
    s.add        s36, s34, s35
    v.splat      v39, s37
    s.shli       s37, s35, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s36, v20]            // index is in elements (ISA sec 9.1)
    s.add        s36, s32, s37
    s.addi       s37, s35, #1
    s.movz       s38, #32
    v.st.b       [s36, #0], v38
    fence.acq_rel.device
    s.mov        s35, s37
    s.cmp.lt     s36, s35, s38
    br.nz        s36, x8dot_row_11
x8dot_done_10:
    v.splat      v38, s31
    v.movi       v39, #0
    v.splat      v40, s31
    v.movi       v41, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    s.movz       s34, #0
    s.movz       s35, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s36, v29, #3
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v28, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_12
    s.movz       s35, #0
    s.add        s36, s9, s23
    s.addi       s37, s35, #0
    s.addi       s35, s33, #256
x8dot_row_13:
    s.addi       s38, s21, #0
    v.movi       v38, #0
    s.sub        s39, s38, s37
    s.add        s38, s36, s37
    v.splat      v39, s39
    s.shli       s39, s37, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s38, v22]            // index is in elements (ISA sec 9.1)
    s.add        s38, s35, s39
    s.addi       s39, s37, #1
    s.movz       s40, #32
    v.st.b       [s38, #0], v38
    fence.acq_rel.device
    s.mov        s37, s39
    s.cmp.lt     s38, s37, s40
    br.nz        s38, x8dot_row_13
x8dot_done_12:
    v.splat      v38, s34
    v.movi       v39, #0
    v.splat      v40, s34
    v.movi       v41, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    s.movz       s36, #0
    s.movz       s37, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s38, v29, #4
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v28, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_14
    s.movz       s37, #0
    s.add        s38, s9, s23
    s.addi       s39, s37, #0
    s.addi       s37, s33, #256
x8dot_row_15:
    s.addi       s40, s21, #0
    v.movi       v38, #0
    s.sub        s41, s40, s39
    s.add        s40, s38, s39
    v.splat      v39, s41
    s.shli       s41, s39, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s40, v23]            // index is in elements (ISA sec 9.1)
    s.add        s40, s37, s41
    s.addi       s41, s39, #1
    s.movz       s42, #32
    v.st.b       [s40, #0], v38
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s40, s39, s42
    br.nz        s40, x8dot_row_15
x8dot_done_14:
    v.splat      v38, s36
    v.movi       v39, #0
    v.splat      v40, s36
    v.movi       v41, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    s.movz       s38, #0
    s.movz       s39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s40, v29, #5
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v28, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_16
    s.movz       s39, #0
    s.add        s40, s9, s23
    s.addi       s41, s39, #0
    s.addi       s39, s33, #256
x8dot_row_17:
    s.addi       s42, s21, #0
    v.movi       v38, #0
    s.sub        s43, s42, s41
    s.add        s42, s40, s41
    v.splat      v39, s43
    s.shli       s43, s41, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s42, v24]            // index is in elements (ISA sec 9.1)
    s.add        s42, s39, s43
    s.addi       s43, s41, #1
    s.movz       s44, #32
    v.st.b       [s42, #0], v38
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s42, s41, s44
    br.nz        s42, x8dot_row_17
x8dot_done_16:
    v.splat      v38, s38
    v.movi       v39, #0
    v.splat      v40, s38
    v.movi       v41, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    s.movz       s40, #0
    s.movz       s41, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s42, v29, #6
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v28, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_18
    s.movz       s41, #0
    s.add        s42, s9, s23
    s.addi       s43, s41, #0
    s.addi       s41, s33, #256
x8dot_row_19:
    s.addi       s44, s21, #0
    v.movi       v38, #0
    s.sub        s45, s44, s43
    s.add        s44, s42, s43
    v.splat      v39, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s44, v32]            // index is in elements (ISA sec 9.1)
    s.add        s44, s41, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v38
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_19
x8dot_done_18:
    s.movz       s41, #0
    v.extract    s42, v36, #0
    s.add        s43, s41, s5                    // the tile origin
    s.movz       s41, #0
    s.add        s44, s42, s22
    v.splat      v38, s40
    v.movi       v39, #0
    v.splat      v40, s40
    v.movi       v41, #0
    v.splat      v42, s43
    s.add        s40, s41, s27                   // the tile origin
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    s.movz       s43, #0
    s.movz       s45, #0
    s.addi       s46, s44, #32
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s44, v29, #7
    v.add        v38, v31, v42
    v.splat      v39, s40
    v.extract    s40, v36, #1
    s.mov        s47, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s43, s12, s46
    s.add        s44, s40, s22
    v.cmp.lt     p1, v38, v39
    m.mma.async.k32.e4m3 a15, v48, v56, s42
    mb.wait      s42
    s.addi       s40, s33, #1536                 // 512 bytes of repack scratch
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s43, #0]
    s.addi       s43, s44, #32
    v.extract    s44, v36, #2
    s.addi       s45, s40, #0
    s.add        s46, s12, s43
    s.add        s43, s44, s22
    v.st.b       [s45, #0], v38
    s.addi       s44, s43, #32
    v.extract    s43, v36, #3
    s.addi       s45, s40, #32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s46, #0]
    s.add        s46, s12, s44
    s.add        s44, s43, s22
    v.extract    s43, v36, #4
    v.st.b       [s45, #0], v38
    s.addi       s45, s44, #32
    s.addi       s44, s40, #64
    s.add        s47, s12, s45
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s46, #0]
    s.add        s45, s43, s22
    v.extract    s43, v36, #5
    s.addi       s46, s45, #32
    v.st.b       [s44, #0], v38
    s.addi       s44, s40, #96
    s.add        s45, s12, s46
    s.add        s46, s43, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s47, #0]
    s.addi       s43, s46, #32
    v.extract    s46, v36, #6
    s.addi       s47, s40, #128
    v.st.b       [s44, #0], v38
    s.add        s44, s12, s43
    s.add        s43, s46, s22
    v.extract    s46, v36, #7
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s45, #0]
    s.addi       s45, s43, #32
    s.addi       s43, s40, #160
    s.add        s48, s12, s45
    v.st.b       [s47, #0], v38
    s.add        s45, s46, s22
    v.extract    s46, v36, #8
    s.addi       s47, s45, #32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s44, s40, #192
    s.add        s45, s12, s47
    s.add        s47, s46, s22
    v.st.b       [s43, #0], v38
    s.addi       s43, s47, #32
    v.extract    s46, v36, #9
    s.addi       s47, s40, #224
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s48, #0]
    s.add        s48, s12, s43
    s.add        s43, s46, s22
    v.extract    s46, v36, #10
    v.st.b       [s44, #0], v38
    s.addi       s44, s43, #32
    s.addi       s43, s40, #256
    s.add        s49, s12, s44
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s45, #0]
    s.add        s44, s46, s22
    v.extract    s45, v36, #11
    s.addi       s46, s44, #32
    v.st.b       [s47, #0], v38
    s.addi       s44, s40, #288
    s.add        s47, s12, s46
    s.add        s46, s45, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s48, #0]
    s.addi       s45, s46, #32
    v.extract    s46, v36, #12
    s.add        s48, s12, s45
    v.st.b       [s43, #0], v38
    s.addi       s43, s40, #320
    s.add        s45, s46, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s49, #0]
    s.addi       s46, s45, #32
    v.extract    s45, v36, #13
    s.add        s49, s12, s46
    v.st.b       [s44, #0], v38
    s.addi       s44, s40, #352
    s.add        s46, s45, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s47, #0]
    s.addi       s45, s46, #32
    v.extract    s46, v36, #14
    s.add        s47, s12, s45
    v.st.b       [s43, #0], v38
    s.addi       s43, s40, #384
    s.add        s45, s46, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s48, #0]
    s.addi       s46, s45, #32
    v.extract    s45, v36, #15
    s.add        s48, s12, s46
    v.st.b       [s44, #0], v38
    s.addi       s44, s40, #416
    s.add        s46, s45, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s49, #0]
    s.movz       s45, #0
    s.addi       s49, s46, #32
    s.add        s46, s45, s11                   // the tile origin
    v.st.b       [s43, #0], v38
    v.extract    s43, v36, #0
    s.add        s45, s12, s49
    s.add        s49, s43, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s47, #0]
    s.movz       s43, #0
    v.splat      v39, s46
    s.addi       s46, s40, #448
    v.st.b       [s44, #0], v38
    s.add        s44, s43, s27                   // the tile origin
    s.addi       s43, s49, #48
    v.add        v38, v31, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v39, [s48, #0]
    v.splat      v40, s44
    v.extract    s44, v36, #1
    s.addi       s47, s40, #480
    v.st.b       [s46, #0], v39
    s.add        s46, s12, s43
    s.add        s43, s44, s22
    v.cmp.lt     p2, v38, v40
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s45, #0]
    s.addi       s44, s43, #48
    v.extract    s43, v36, #2
    s.addi       s45, s40, #16
    v.st.b       [s47, #0], v38
    s.add        s47, s12, s44
    s.add        s44, s43, s22
    v.extract    s43, v36, #3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s46, #0]
    s.addi       s46, s44, #48
    s.addi       s44, s40, #48
    s.add        s48, s12, s46
    v.st.b       [s45, #0], v38
    s.add        s45, s43, s22
    v.extract    s43, v36, #4
    s.addi       s46, s45, #48
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s47, #0]
    s.addi       s45, s40, #80
    s.add        s47, s12, s46
    s.add        s46, s43, s22
    v.st.b       [s44, #0], v38
    s.addi       s43, s46, #48
    v.extract    s44, v36, #5
    s.addi       s46, s40, #112
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s48, #0]
    s.add        s48, s12, s43
    s.add        s43, s44, s22
    v.extract    s44, v36, #6
    v.st.b       [s45, #0], v38
    s.addi       s45, s43, #48
    s.addi       s43, s40, #144
    s.add        s49, s12, s45
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s47, #0]
    s.add        s45, s44, s22
    v.extract    s44, v36, #7
    s.addi       s47, s45, #48
    v.st.b       [s46, #0], v38
    s.addi       s45, s40, #176
    s.add        s46, s12, s47
    s.add        s47, s44, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s48, #0]
    s.addi       s44, s47, #48
    v.extract    s47, v36, #8
    s.add        s48, s12, s44
    v.st.b       [s43, #0], v38
    s.addi       s43, s40, #208
    s.add        s44, s47, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s49, #0]
    s.addi       s47, s44, #48
    v.extract    s44, v36, #9
    s.add        s49, s12, s47
    v.st.b       [s45, #0], v38
    s.addi       s45, s40, #240
    s.add        s47, s44, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s46, #0]
    s.addi       s44, s47, #48
    v.extract    s46, v36, #10
    s.add        s47, s12, s44
    v.st.b       [s43, #0], v38
    s.addi       s43, s40, #272
    s.add        s44, s46, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s48, #0]
    s.addi       s46, s44, #48
    v.extract    s44, v36, #11
    s.add        s48, s12, s46
    v.st.b       [s45, #0], v38
    s.addi       s45, s40, #304
    s.add        s46, s44, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s49, #0]
    s.addi       s44, s46, #48
    v.extract    s46, v36, #12
    s.add        s49, s12, s44
    v.st.b       [s43, #0], v38
    s.addi       s43, s40, #336
    s.add        s44, s46, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s47, #0]
    s.addi       s46, s44, #48
    v.extract    s44, v36, #13
    s.add        s47, s12, s46
    v.st.b       [s45, #0], v38
    s.addi       s45, s40, #368
    s.add        s46, s44, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s48, #0]
    s.addi       s44, s46, #48
    v.extract    s46, v36, #14
    s.add        s48, s12, s44
    v.st.b       [s43, #0], v38
    s.addi       s43, s40, #400
    s.add        s44, s46, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s49, #0]
    s.addi       s46, s44, #48
    v.extract    s44, v36, #15
    s.add        s49, s12, s46
    v.st.b       [s45, #0], v38
    s.addi       s45, s40, #432
    s.add        s46, s44, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s47, #0]
    s.addi       s44, s46, #48
    s.addi       s46, s40, #464
    s.add        s47, s12, s44
    v.st.b       [s43, #0], v38
    s.addi       s43, s40, #496
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s48, #0]
    s.addi       s44, s40, #64
    v.st.b       [s45, #0], v38
    s.addi       s45, s40, #128
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s49, #0]
    s.addi       s48, s40, #192
    v.st.b       [s46, #0], v38
    s.addi       s46, s40, #256
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s47, #0]
    s.addi       s47, s40, #320
    v.st.b       [s43, #0], v38
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s43, s40, #384
    v.ld.w       v38, [s40, #0]
    s.addi       s49, s40, #448
    v.mov        v48, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s44, #0]
    v.extract    s40, v28, #0
    v.mov        v49, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s45, #0]
    v.mov        v50, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s48, #0]
    v.mov        v51, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s46, #0]
    v.mov        v52, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s47, #0]
    v.mov        v53, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s43, #0]
    v.mov        v54, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s49, #0]
    v.mov        v55, v38                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_20
    s.movz       s43, #0
    s.add        s44, s9, s23
    s.addi       s45, s43, #0
    s.addi       s43, s44, #32
    s.addi       s44, s33, #256
x8dot_row_21:
    s.addi       s46, s21, #-32
    v.movi       v38, #0
    s.sub        s47, s46, s45
    s.add        s46, s43, s45
    v.splat      v39, s47
    s.shli       s47, s45, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s46, v34]            // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.addi       s47, s45, #1
    s.movz       s48, #32
    v.st.b       [s46, #0], v38
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_21
x8dot_done_20:
    v.splat      v38, s40
    v.movi       v39, #0
    v.splat      v40, s40
    v.movi       v41, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    s.movz       s44, #0
    s.movz       s45, #32
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s46, v29, #0
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v28, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_22
    s.movz       s45, #0
    s.add        s46, s9, s23
    s.addi       s47, s45, #0
    s.addi       s45, s46, #32
    s.addi       s46, s33, #256
x8dot_row_23:
    s.addi       s48, s21, #-32
    v.movi       v38, #0
    s.sub        s49, s48, s47
    s.add        s48, s45, s47
    v.splat      v39, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s48, v17]            // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s48, #0], v38
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_23
x8dot_done_22:
    v.splat      v38, s44
    v.movi       v39, #0
    v.splat      v40, s44
    v.movi       v41, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    s.movz       s46, #0
    s.movz       s47, #32
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s48, v29, #1
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v28, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_24
    s.movz       s47, #0
    s.add        s48, s9, s23
    s.addi       s49, s47, #0
    s.addi       s47, s48, #32
    s.addi       s48, s33, #256
x8dot_row_25:
    s.addi       s50, s21, #-32
    v.movi       v38, #0
    s.sub        s51, s50, s49
    s.add        s50, s47, s49
    v.splat      v39, s51
    s.shli       s51, s49, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s50, v19]            // index is in elements (ISA sec 9.1)
    s.add        s50, s48, s51
    s.addi       s51, s49, #1
    s.movz       s52, #32
    v.st.b       [s50, #0], v38
    fence.acq_rel.device
    s.mov        s49, s51
    s.cmp.lt     s50, s49, s52
    br.nz        s50, x8dot_row_25
x8dot_done_24:
    v.splat      v38, s46
    v.movi       v39, #0
    v.splat      v40, s46
    v.movi       v41, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    s.movz       s48, #0
    s.movz       s49, #32
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s50, v29, #2
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v28, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_26
    s.movz       s49, #0
    s.add        s50, s9, s23
    s.addi       s51, s49, #0
    s.addi       s49, s50, #32
    s.addi       s50, s33, #256
x8dot_row_27:
    s.addi       s52, s21, #-32
    v.movi       v38, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v39, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s52, v20]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v38
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_27
x8dot_done_26:
    v.splat      v38, s48
    v.movi       v39, #0
    v.splat      v40, s48
    v.movi       v41, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    s.movz       s50, #0
    s.movz       s51, #32
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s52, v29, #3
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v28, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_28
    s.movz       s51, #0
    s.add        s52, s9, s23
    s.addi       s53, s51, #0
    s.addi       s51, s52, #32
    s.addi       s52, s33, #256
x8dot_row_29:
    s.addi       s54, s21, #-32
    v.movi       v38, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v39, s55
    s.shli       s55, s53, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s54, v22]            // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.addi       s55, s53, #1
    s.movz       s56, #32
    v.st.b       [s54, #0], v38
    fence.acq_rel.device
    s.mov        s53, s55
    s.cmp.lt     s54, s53, s56
    br.nz        s54, x8dot_row_29
x8dot_done_28:
    v.splat      v38, s50
    v.movi       v39, #0
    v.splat      v40, s50
    v.movi       v41, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s51, #0
    s.movz       s52, #0
    s.movz       s53, #32
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s54, v29, #4
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v28, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s52, x8dot_done_30
    s.movz       s53, #0
    s.add        s54, s9, s23
    s.addi       s55, s53, #0
    s.addi       s53, s54, #32
    s.addi       s54, s33, #256
x8dot_row_31:
    s.addi       s56, s21, #-32
    v.movi       v38, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v39, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s56, v23]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    s.movz       s58, #32
    v.st.b       [s56, #0], v38
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s58
    br.nz        s56, x8dot_row_31
x8dot_done_30:
    v.splat      v38, s52
    v.movi       v39, #0
    v.splat      v40, s52
    v.movi       v41, #0
    mb.arm       s52, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    s.movz       s54, #0
    s.movz       s55, #32
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s56, v29, #5
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s57, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v28, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s54, x8dot_done_32
    s.movz       s55, #0
    s.add        s56, s9, s23
    s.addi       s57, s55, #0
    s.addi       s55, s56, #32
    s.addi       s56, s33, #256
x8dot_row_33:
    s.addi       s58, s21, #-32
    v.movi       v38, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v39, s59
    s.shli       s59, s57, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s58, v24]            // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    s.addi       s59, s57, #1
    s.movz       s60, #32
    v.st.b       [s58, #0], v38
    fence.acq_rel.device
    s.mov        s57, s59
    s.cmp.lt     s58, s57, s60
    br.nz        s58, x8dot_row_33
x8dot_done_32:
    v.splat      v38, s54
    v.movi       v39, #0
    v.splat      v40, s54
    v.movi       v41, #0
    mb.arm       s54, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s55, #0
    s.movz       s56, #0
    s.movz       s57, #32
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s58, v29, #6
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s60, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s59, s54            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s58                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v28, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s55
    mb.wait      s55
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s56, x8dot_done_34
    s.movz       s57, #0
    s.add        s58, s9, s23
    s.addi       s59, s57, #0
    s.addi       s57, s58, #32
    s.addi       s58, s33, #256
x8dot_row_35:
    s.addi       s60, s21, #-32
    v.movi       v38, #0
    s.sub        s24, s60, s59
    s.add        s25, s57, s59
    v.splat      v39, s24
    s.shli       s24, s59, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s25, v32]            // index is in elements (ISA sec 9.1)
    s.add        s25, s58, s24
    s.addi       s24, s59, #1
    s.movz       s26, #32
    v.st.b       [s25, #0], v38
    fence.acq_rel.device
    s.mov        s59, s24
    s.cmp.lt     s24, s59, s26
    br.nz        s24, x8dot_row_35
x8dot_done_34:
    s.movz       s24, #0
    v.extract    s25, v36, #0
    s.add        s26, s24, s14                   // the tile origin
    s.movz       s24, #0
    s.add        s28, s25, s22
    v.splat      v38, s56
    v.movi       v39, #0
    v.splat      v40, s56
    v.movi       v41, #0
    v.splat      v42, s26
    s.add        s25, s24, s27                   // the tile origin
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s26, #0
    s.movz       s29, #0
    s.movz       s30, #32
    s.addi       s31, s28, #64
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s28, v29, #7
    v.add        v38, v31, v42
    v.splat      v39, s25
    v.extract    s25, v36, #1
    s.mov        s34, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s28, s12, s31
    s.add        s29, s25, s22
    v.cmp.lt     p1, v38, v39
    m.mma.async.k32.e4m3 a15, v48, v56, s26
    mb.wait      s26
    s.addi       s25, s33, #2048                 // 512 bytes of repack scratch
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s28, #0]
    s.addi       s28, s29, #64
    v.extract    s29, v36, #2
    s.addi       s30, s25, #0
    s.add        s31, s12, s28
    s.add        s28, s29, s22
    v.st.b       [s30, #0], v38
    s.addi       s29, s28, #64
    v.extract    s28, v36, #3
    s.addi       s30, s25, #32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.add        s31, s12, s29
    s.add        s29, s28, s22
    v.extract    s28, v36, #4
    v.st.b       [s30, #0], v38
    s.addi       s30, s29, #64
    s.addi       s29, s25, #64
    s.add        s32, s12, s30
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.add        s30, s28, s22
    v.extract    s28, v36, #5
    s.addi       s31, s30, #64
    v.st.b       [s29, #0], v38
    s.addi       s29, s25, #96
    s.add        s30, s12, s31
    s.add        s31, s28, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s32, #0]
    s.addi       s28, s31, #64
    v.extract    s31, v36, #6
    s.addi       s32, s25, #128
    v.st.b       [s29, #0], v38
    s.add        s29, s12, s28
    s.add        s28, s31, s22
    v.extract    s31, v36, #7
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s30, #0]
    s.addi       s30, s28, #64
    s.addi       s28, s25, #160
    s.add        s34, s12, s30
    v.st.b       [s32, #0], v38
    s.add        s30, s31, s22
    v.extract    s31, v36, #8
    s.addi       s32, s30, #64
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s29, s25, #192
    s.add        s30, s12, s32
    s.add        s32, s31, s22
    v.st.b       [s28, #0], v38
    s.addi       s28, s32, #64
    v.extract    s31, v36, #9
    s.addi       s32, s25, #224
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s34, #0]
    s.add        s34, s12, s28
    s.add        s28, s31, s22
    v.extract    s31, v36, #10
    v.st.b       [s29, #0], v38
    s.addi       s29, s28, #64
    s.addi       s28, s25, #256
    s.add        s35, s12, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s30, #0]
    s.add        s29, s31, s22
    v.extract    s30, v36, #11
    s.addi       s31, s29, #64
    v.st.b       [s32, #0], v38
    s.addi       s29, s25, #288
    s.add        s32, s12, s31
    s.add        s31, s30, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s34, #0]
    s.addi       s30, s31, #64
    v.extract    s31, v36, #12
    s.add        s34, s12, s30
    v.st.b       [s28, #0], v38
    s.addi       s28, s25, #320
    s.add        s30, s31, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s35, #0]
    s.addi       s31, s30, #64
    v.extract    s30, v36, #13
    s.add        s35, s12, s31
    v.st.b       [s29, #0], v38
    s.addi       s29, s25, #352
    s.add        s31, s30, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s32, #0]
    s.addi       s30, s31, #64
    v.extract    s31, v36, #14
    s.add        s32, s12, s30
    v.st.b       [s28, #0], v38
    s.addi       s28, s25, #384
    s.add        s30, s31, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s34, #0]
    s.addi       s31, s30, #64
    v.extract    s30, v36, #15
    s.add        s34, s12, s31
    v.st.b       [s29, #0], v38
    s.addi       s29, s25, #416
    s.add        s31, s30, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s35, #0]
    s.movz       s30, #0
    s.addi       s35, s31, #64
    s.add        s31, s30, s15                   // the tile origin
    v.st.b       [s28, #0], v38
    v.extract    s28, v36, #0
    s.add        s30, s12, s35
    s.add        s35, s28, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s32, #0]
    s.movz       s28, #0
    v.splat      v39, s31
    s.addi       s31, s25, #448
    v.st.b       [s29, #0], v38
    s.add        s29, s28, s27                   // the tile origin
    s.addi       s28, s35, #80
    v.add        v38, v31, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v39, [s34, #0]
    v.splat      v40, s29
    v.extract    s29, v36, #1
    s.addi       s32, s25, #480
    v.st.b       [s31, #0], v39
    s.add        s31, s12, s28
    s.add        s28, s29, s22
    v.cmp.lt     p2, v38, v40
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s30, #0]
    s.addi       s29, s28, #80
    v.extract    s28, v36, #2
    s.addi       s30, s25, #16
    v.st.b       [s32, #0], v38
    s.add        s32, s12, s29
    s.add        s29, s28, s22
    v.extract    s28, v36, #3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s31, #0]
    s.addi       s31, s29, #80
    s.addi       s29, s25, #48
    s.add        s34, s12, s31
    v.st.b       [s30, #0], v38
    s.add        s30, s28, s22
    v.extract    s28, v36, #4
    s.addi       s31, s30, #80
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s32, #0]
    s.addi       s30, s25, #80
    s.add        s32, s12, s31
    s.add        s31, s28, s22
    v.st.b       [s29, #0], v38
    s.addi       s28, s31, #80
    v.extract    s29, v36, #5
    s.addi       s31, s25, #112
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s34, #0]
    s.add        s34, s12, s28
    s.add        s28, s29, s22
    v.extract    s29, v36, #6
    v.st.b       [s30, #0], v38
    s.addi       s30, s28, #80
    s.addi       s28, s25, #144
    s.add        s35, s12, s30
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s32, #0]
    s.add        s30, s29, s22
    v.extract    s29, v36, #7
    s.addi       s32, s30, #80
    v.st.b       [s31, #0], v38
    s.addi       s30, s25, #176
    s.add        s31, s12, s32
    s.add        s32, s29, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s34, #0]
    s.addi       s29, s32, #80
    v.extract    s32, v36, #8
    s.add        s34, s12, s29
    v.st.b       [s28, #0], v38
    s.addi       s28, s25, #208
    s.add        s29, s32, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s35, #0]
    s.addi       s32, s29, #80
    v.extract    s29, v36, #9
    s.add        s35, s12, s32
    v.st.b       [s30, #0], v38
    s.addi       s30, s25, #240
    s.add        s32, s29, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s31, #0]
    s.addi       s29, s32, #80
    v.extract    s31, v36, #10
    s.add        s32, s12, s29
    v.st.b       [s28, #0], v38
    s.addi       s28, s25, #272
    s.add        s29, s31, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s34, #0]
    s.addi       s31, s29, #80
    v.extract    s29, v36, #11
    s.add        s34, s12, s31
    v.st.b       [s30, #0], v38
    s.addi       s30, s25, #304
    s.add        s31, s29, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s35, #0]
    s.addi       s29, s31, #80
    v.extract    s31, v36, #12
    s.add        s35, s12, s29
    v.st.b       [s28, #0], v38
    s.addi       s28, s25, #336
    s.add        s29, s31, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s32, #0]
    s.addi       s31, s29, #80
    v.extract    s29, v36, #13
    s.add        s32, s12, s31
    v.st.b       [s30, #0], v38
    s.addi       s30, s25, #368
    s.add        s31, s29, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s34, #0]
    s.addi       s29, s31, #80
    v.extract    s31, v36, #14
    s.add        s34, s12, s29
    v.st.b       [s28, #0], v38
    s.addi       s28, s25, #400
    s.add        s29, s31, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s35, #0]
    s.addi       s31, s29, #80
    v.extract    s29, v36, #15
    s.add        s35, s12, s31
    v.st.b       [s30, #0], v38
    s.addi       s30, s25, #432
    s.add        s31, s29, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s32, #0]
    s.addi       s29, s31, #80
    s.addi       s31, s25, #464
    s.add        s32, s12, s29
    v.st.b       [s28, #0], v38
    s.addi       s28, s25, #496
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s34, #0]
    s.addi       s29, s25, #64
    v.st.b       [s30, #0], v38
    s.addi       s30, s25, #128
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s35, #0]
    s.addi       s34, s25, #192
    v.st.b       [s31, #0], v38
    s.addi       s31, s25, #256
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v38, [s32, #0]
    s.addi       s32, s25, #320
    v.st.b       [s28, #0], v38
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s28, s25, #384
    v.ld.w       v38, [s25, #0]
    s.addi       s35, s25, #448
    v.mov        v48, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s29, #0]
    v.extract    s25, v28, #0
    v.mov        v49, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s30, #0]
    v.mov        v50, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s34, #0]
    v.mov        v51, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s31, #0]
    v.mov        v52, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s32, #0]
    v.mov        v53, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s28, #0]
    v.mov        v54, v38                        // hand off through the shared window (sec 7.3)
    v.ld.w       v38, [s35, #0]
    v.mov        v55, v38                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s25, x8dot_done_36
    s.movz       s28, #0
    s.add        s29, s9, s23
    s.addi       s30, s28, #0
    s.addi       s28, s29, #64
    s.addi       s29, s33, #256
x8dot_row_37:
    s.addi       s31, s21, #-64
    v.movi       v38, #0
    s.sub        s32, s31, s30
    s.add        s31, s28, s30
    v.splat      v39, s32
    s.shli       s32, s30, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s31, v34]            // index is in elements (ISA sec 9.1)
    s.add        s31, s29, s32
    s.addi       s32, s30, #1
    s.movz       s34, #32
    v.st.b       [s31, #0], v38
    fence.acq_rel.device
    s.mov        s30, s32
    s.cmp.lt     s31, s30, s34
    br.nz        s31, x8dot_row_37
x8dot_done_36:
    v.splat      v38, s25
    v.movi       v39, #0
    v.splat      v40, s25
    v.movi       v41, #0
    mb.arm       s25, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s28, #0
    s.movz       s29, #0
    s.movz       s30, #64
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s31, v29, #0
    s.mov        s34, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s25            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s28, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s28, s25          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s25
    mb.arm       s28, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s29, v28, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s28
    mb.wait      s28
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s29, x8dot_done_38
    s.movz       s30, #0
    s.add        s31, s9, s23
    s.addi       s32, s30, #0
    s.addi       s30, s31, #64
    s.addi       s31, s33, #256
x8dot_row_39:
    s.addi       s34, s21, #-64
    v.movi       v38, #0
    s.sub        s35, s34, s32
    s.add        s34, s30, s32
    v.splat      v39, s35
    s.shli       s35, s32, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s34, v17]            // index is in elements (ISA sec 9.1)
    s.add        s34, s31, s35
    s.addi       s35, s32, #1
    s.movz       s36, #32
    v.st.b       [s34, #0], v38
    fence.acq_rel.device
    s.mov        s32, s35
    s.cmp.lt     s34, s32, s36
    br.nz        s34, x8dot_row_39
x8dot_done_38:
    v.splat      v38, s29
    v.movi       v39, #0
    v.splat      v40, s29
    v.movi       v41, #0
    mb.arm       s29, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    s.movz       s31, #0
    s.movz       s32, #64
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s34, v29, #1
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s29            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s30, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s30, s29          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s29
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v28, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s30
    mb.wait      s30
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s31, x8dot_done_40
    s.movz       s32, #0
    s.add        s34, s9, s23
    s.addi       s35, s32, #0
    s.addi       s32, s34, #64
    s.addi       s34, s33, #256
x8dot_row_41:
    s.addi       s36, s21, #-64
    v.movi       v38, #0
    s.sub        s37, s36, s35
    s.add        s36, s32, s35
    v.splat      v39, s37
    s.shli       s37, s35, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s36, v19]            // index is in elements (ISA sec 9.1)
    s.add        s36, s34, s37
    s.addi       s37, s35, #1
    s.movz       s38, #32
    v.st.b       [s36, #0], v38
    fence.acq_rel.device
    s.mov        s35, s37
    s.cmp.lt     s36, s35, s38
    br.nz        s36, x8dot_row_41
x8dot_done_40:
    v.splat      v38, s31
    v.movi       v39, #0
    v.splat      v40, s31
    v.movi       v41, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    s.movz       s34, #0
    s.movz       s35, #64
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s36, v29, #2
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v28, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_42
    s.movz       s35, #0
    s.add        s36, s9, s23
    s.addi       s37, s35, #0
    s.addi       s35, s36, #64
    s.addi       s36, s33, #256
x8dot_row_43:
    s.addi       s38, s21, #-64
    v.movi       v38, #0
    s.sub        s39, s38, s37
    s.add        s38, s35, s37
    v.splat      v39, s39
    s.shli       s39, s37, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s38, v20]            // index is in elements (ISA sec 9.1)
    s.add        s38, s36, s39
    s.addi       s39, s37, #1
    s.movz       s40, #32
    v.st.b       [s38, #0], v38
    fence.acq_rel.device
    s.mov        s37, s39
    s.cmp.lt     s38, s37, s40
    br.nz        s38, x8dot_row_43
x8dot_done_42:
    v.splat      v38, s34
    v.movi       v39, #0
    v.splat      v40, s34
    v.movi       v41, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    s.movz       s36, #0
    s.movz       s37, #64
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s38, v29, #3
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v28, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_44
    s.movz       s37, #0
    s.add        s38, s9, s23
    s.addi       s39, s37, #0
    s.addi       s37, s38, #64
    s.addi       s38, s33, #256
x8dot_row_45:
    s.addi       s40, s21, #-64
    v.movi       v38, #0
    s.sub        s41, s40, s39
    s.add        s40, s37, s39
    v.splat      v39, s41
    s.shli       s41, s39, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s40, v22]            // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    s.addi       s41, s39, #1
    s.movz       s42, #32
    v.st.b       [s40, #0], v38
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s40, s39, s42
    br.nz        s40, x8dot_row_45
x8dot_done_44:
    v.splat      v38, s36
    v.movi       v39, #0
    v.splat      v40, s36
    v.movi       v41, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    s.movz       s38, #0
    s.movz       s39, #64
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s40, v29, #4
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v28, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_46
    s.movz       s39, #0
    s.add        s40, s9, s23
    s.addi       s41, s39, #0
    s.addi       s39, s40, #64
    s.addi       s40, s33, #256
x8dot_row_47:
    s.addi       s42, s21, #-64
    v.movi       v38, #0
    s.sub        s43, s42, s41
    s.add        s42, s39, s41
    v.splat      v39, s43
    s.shli       s43, s41, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s42, v23]            // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.addi       s43, s41, #1
    s.movz       s44, #32
    v.st.b       [s42, #0], v38
    fence.acq_rel.device
    s.mov        s41, s43
    s.cmp.lt     s42, s41, s44
    br.nz        s42, x8dot_row_47
x8dot_done_46:
    v.splat      v38, s38
    v.movi       v39, #0
    v.splat      v40, s38
    v.movi       v41, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    s.movz       s40, #0
    s.movz       s41, #64
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s42, v29, #5
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v28, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_48
    s.movz       s41, #0
    s.add        s42, s9, s23
    s.addi       s43, s41, #0
    s.addi       s41, s42, #64
    s.addi       s42, s33, #256
x8dot_row_49:
    s.addi       s44, s21, #-64
    v.movi       v38, #0
    s.sub        s45, s44, s43
    s.add        s44, s41, s43
    v.splat      v39, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s44, v24]            // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v38
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_49
x8dot_done_48:
    v.splat      v38, s40
    v.movi       v39, #0
    v.splat      v40, s40
    v.movi       v41, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    s.movz       s42, #0
    s.movz       s43, #64
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s44, v29, #6
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v28, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_50
    s.movz       s43, #0
    s.add        s44, s9, s23
    s.addi       s45, s43, #0
    s.addi       s43, s44, #64
    s.addi       s44, s33, #256
x8dot_row_51:
    s.addi       s46, s21, #-64
    v.movi       v38, #0
    s.sub        s47, s46, s45
    s.add        s46, s43, s45
    v.splat      v39, s47
    s.shli       s47, s45, #4
    v.cmp.gt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s46, v32]            // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.addi       s47, s45, #1
    s.movz       s48, #32
    v.st.b       [s46, #0], v38
    fence.acq_rel.device
    s.mov        s45, s47
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_51
x8dot_done_50:
    s.movz       s43, #0
    v.extract    s44, v36, #0
    s.add        s45, s43, s16                   // the tile origin
    s.movz       s43, #0
    s.add        s46, s44, s22
    v.splat      v38, s42
    v.movi       v39, #0
    v.splat      v40, s42
    v.movi       v41, #0
    v.splat      v42, s45
    s.add        s42, s43, s27                   // the tile origin
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    s.movz       s45, #0
    s.movz       s47, #64
    s.addi       s48, s46, #96
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v40, v41
    v.extract    s46, v29, #7
    v.add        v38, v31, v42
    v.splat      v39, s42
    v.extract    s42, v36, #1
    s.mov        s49, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s45, s12, s48
    s.add        s46, s42, s22
    v.cmp.lt     p1, v38, v39
    m.mma.async.k32.e4m3 a15, v48, v56, s44
    mb.wait      s44
    s.addi       s42, s33, #2560                 // 512 bytes of repack scratch
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s45, #0]
    s.addi       s45, s46, #96
    v.extract    s46, v36, #2
    s.addi       s47, s42, #0
    s.add        s48, s12, s45
    s.add        s45, s46, s22
    v.st.b       [s47, #0], v38
    s.addi       s46, s45, #96
    v.extract    s45, v36, #3
    s.addi       s47, s42, #32
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s48, #0]
    s.add        s48, s12, s46
    s.add        s46, s45, s22
    v.extract    s45, v36, #4
    v.st.b       [s47, #0], v38
    s.addi       s47, s46, #96
    s.addi       s46, s42, #64
    s.add        s49, s12, s47
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s48, #0]
    s.add        s47, s45, s22
    v.extract    s45, v36, #5
    s.addi       s48, s47, #96
    v.st.b       [s46, #0], v38
    s.addi       s46, s42, #96
    s.add        s47, s12, s48
    s.add        s48, s45, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s49, #0]
    s.addi       s45, s48, #96
    v.extract    s48, v36, #6
    s.addi       s49, s42, #128
    v.st.b       [s46, #0], v38
    s.add        s46, s12, s45
    s.add        s45, s48, s22
    v.extract    s48, v36, #7
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s47, #0]
    s.addi       s47, s45, #96
    s.addi       s45, s42, #160
    s.add        s50, s12, s47
    v.st.b       [s49, #0], v38
    s.add        s47, s48, s22
    v.extract    s48, v36, #8
    s.addi       s49, s47, #96
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s46, #0]
    s.addi       s46, s42, #192
    s.add        s47, s12, s49
    s.add        s49, s48, s22
    v.st.b       [s45, #0], v38
    s.addi       s45, s49, #96
    v.extract    s48, v36, #9
    s.addi       s49, s42, #224
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s50, #0]
    s.add        s50, s12, s45
    s.add        s45, s48, s22
    v.extract    s48, v36, #10
    v.st.b       [s46, #0], v38
    s.addi       s46, s45, #96
    s.addi       s45, s42, #256
    s.add        s51, s12, s46
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s47, #0]
    s.add        s46, s48, s22
    v.extract    s47, v36, #11
    s.addi       s48, s46, #96
    v.st.b       [s49, #0], v38
    s.addi       s46, s42, #288
    s.add        s49, s12, s48
    s.add        s48, s47, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s50, #0]
    s.addi       s47, s48, #96
    v.extract    s48, v36, #12
    s.add        s50, s12, s47
    v.st.b       [s45, #0], v38
    s.addi       s45, s42, #320
    s.add        s47, s48, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s51, #0]
    s.addi       s48, s47, #96
    v.extract    s47, v36, #13
    s.add        s51, s12, s48
    v.st.b       [s46, #0], v38
    s.addi       s46, s42, #352
    s.add        s48, s47, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s49, #0]
    s.addi       s47, s48, #96
    v.extract    s48, v36, #14
    s.add        s49, s12, s47
    v.st.b       [s45, #0], v38
    s.addi       s45, s42, #384
    s.add        s47, s48, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s50, #0]
    s.addi       s48, s47, #96
    v.extract    s47, v36, #15
    s.add        s50, s12, s48
    v.st.b       [s46, #0], v38
    s.addi       s46, s42, #416
    s.add        s48, s47, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s51, #0]
    s.movz       s47, #0
    s.addi       s51, s48, #96
    s.add        s48, s47, s17                   // the tile origin
    v.st.b       [s45, #0], v38
    v.extract    s45, v36, #0
    s.add        s47, s12, s51
    s.add        s51, s45, s22
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s49, #0]
    s.movz       s45, #0
    v.splat      v39, s48
    s.addi       s48, s42, #448
    v.st.b       [s46, #0], v38
    s.add        s46, s45, s27                   // the tile origin
    s.addi       s27, s51, #112
    v.add        v38, v31, v39
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s50, #0]
    v.splat      v39, s46
    v.extract    s45, v36, #1
    s.addi       s46, s42, #480
    v.st.b       [s48, #0], v31
    s.add        s48, s12, s27
    s.add        s27, s45, s22
    v.cmp.lt     p2, v38, v39
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v31, [s47, #0]
    s.addi       s45, s27, #112
    v.extract    s27, v36, #2
    s.addi       s47, s42, #16
    v.st.b       [s46, #0], v31
    s.add        s46, s12, s45
    s.add        s45, s27, s22
    v.extract    s27, v36, #3
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s48, #0]
    s.addi       s48, s45, #112
    s.addi       s45, s42, #48
    s.add        s49, s12, s48
    v.st.b       [s47, #0], v31
    s.add        s47, s27, s22
    v.extract    s27, v36, #4
    s.addi       s48, s47, #112
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s46, #0]
    s.addi       s46, s42, #80
    s.add        s47, s12, s48
    s.add        s48, s27, s22
    v.st.b       [s45, #0], v31
    s.addi       s27, s48, #112
    v.extract    s45, v36, #5
    s.addi       s48, s42, #112
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s49, #0]
    s.add        s49, s12, s27
    s.add        s27, s45, s22
    v.extract    s45, v36, #6
    v.st.b       [s46, #0], v31
    s.addi       s46, s27, #112
    s.addi       s27, s42, #144
    s.add        s50, s12, s46
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s47, #0]
    s.add        s46, s45, s22
    v.extract    s45, v36, #7
    s.addi       s47, s46, #112
    v.st.b       [s48, #0], v31
    s.addi       s46, s42, #176
    s.add        s48, s12, s47
    s.add        s47, s45, s22
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s49, #0]
    s.addi       s45, s47, #112
    v.extract    s47, v36, #8
    s.addi       s49, s42, #208
    v.st.b       [s27, #0], v31
    s.add        s27, s12, s45
    s.add        s45, s47, s22
    v.extract    s47, v36, #9
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s50, #0]
    s.addi       s50, s45, #112
    s.addi       s45, s42, #240
    s.add        s51, s12, s50
    v.st.b       [s46, #0], v31
    s.add        s46, s47, s22
    v.extract    s47, v36, #10
    s.addi       s50, s46, #112
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s48, #0]
    s.addi       s46, s42, #272
    s.add        s48, s12, s50
    s.add        s50, s47, s22
    v.st.b       [s49, #0], v31
    s.addi       s47, s50, #112
    v.extract    s49, v36, #11
    s.add        s50, s12, s47
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s27, #0]
    s.addi       s27, s42, #304
    s.add        s47, s49, s22
    v.st.b       [s45, #0], v31
    s.addi       s45, s47, #112
    v.extract    s47, v36, #12
    s.add        s49, s12, s45
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s51, #0]
    s.addi       s45, s42, #336
    s.add        s51, s47, s22
    v.st.b       [s46, #0], v31
    s.addi       s46, s51, #112
    v.extract    s47, v36, #13
    s.add        s51, s12, s46
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s48, #0]
    s.addi       s46, s42, #368
    s.add        s48, s47, s22
    v.st.b       [s27, #0], v31
    s.addi       s27, s48, #112
    v.extract    s47, v36, #14
    s.add        s48, s12, s27
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s50, #0]
    s.addi       s27, s42, #400
    s.add        s50, s47, s22
    v.st.b       [s45, #0], v31
    s.addi       s45, s50, #112
    v.extract    s47, v36, #15
    s.add        s50, s12, s45
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s49, #0]
    s.addi       s45, s42, #432
    s.add        s49, s47, s22
    v.st.b       [s46, #0], v31
    s.addi       s46, s49, #112
    s.addi       s47, s42, #464
    s.add        s49, s12, s46
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s51, #0]
    s.addi       s46, s42, #496
    v.st.b       [s27, #0], v31
    s.addi       s27, s42, #64
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s48, #0]
    s.addi       s48, s42, #128
    v.st.b       [s45, #0], v31
    s.addi       s45, s42, #192
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s50, #0]
    s.addi       s50, s42, #256
    v.st.b       [s47, #0], v31
    s.addi       s47, s42, #320
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v31, [s49, #0]
    s.addi       s49, s42, #384
    v.st.b       [s46, #0], v31
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s46, s42, #448
    v.ld.w       v31, [s42, #0]
    v.extract    s42, v28, #0
    v.mov        v48, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s27, #0]
    v.mov        v49, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s48, #0]
    v.mov        v50, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s45, #0]
    v.mov        v51, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s50, #0]
    v.mov        v52, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s47, #0]
    v.mov        v53, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s49, #0]
    v.mov        v54, v31                        // hand off through the shared window (sec 7.3)
    v.ld.w       v31, [s46, #0]
    v.mov        v55, v31                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_52
    s.movz       s27, #0
    s.add        s45, s9, s23
    s.addi       s46, s27, #0
    s.addi       s27, s45, #96
    s.addi       s45, s33, #256
x8dot_row_53:
    s.addi       s47, s21, #-96
    v.movi       v31, #0
    s.sub        s48, s47, s46
    s.add        s47, s27, s46
    v.splat      v36, s48
    s.shli       s48, s46, #4
    v.cmp.gt     p1, v36, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s47, v34]            // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.addi       s48, s46, #1
    s.movz       s49, #32
    v.st.b       [s47, #0], v31
    fence.acq_rel.device
    s.mov        s46, s48
    s.cmp.lt     s47, s46, s49
    br.nz        s47, x8dot_row_53
x8dot_done_52:
    v.splat      v31, s42
    v.movi       v34, #0
    v.splat      v36, s42
    v.movi       v38, #0
    mb.arm       s27, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    s.movz       s45, #0
    s.movz       s46, #96
    v.cmp.ne     p1, v31, v34
    v.cmp.eq     p2, v36, v38
    v.extract    s47, v29, #0
    s.mov        s48, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s48, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s48, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s48, s27          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v28, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s45, x8dot_done_54
    s.movz       s46, #0
    s.add        s47, s9, s23
    s.addi       s48, s46, #0
    s.addi       s46, s47, #96
    s.addi       s47, s33, #256
x8dot_row_55:
    s.addi       s49, s21, #-96
    v.movi       v31, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v34, s50
    s.shli       s50, s48, #4
    v.cmp.gt     p1, v34, v31
    v.movi       v31, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v31, [s49, v17]            // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.addi       s50, s48, #1
    s.movz       s51, #32
    v.st.b       [s49, #0], v31
    fence.acq_rel.device
    s.mov        s48, s50
    s.cmp.lt     s49, s48, s51
    br.nz        s49, x8dot_row_55
x8dot_done_54:
    v.splat      v17, s45
    v.movi       v31, #0
    v.splat      v34, s45
    v.movi       v36, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    s.movz       s47, #0
    s.movz       s48, #96
    v.cmp.ne     p1, v17, v31
    v.cmp.eq     p2, v34, v36
    v.extract    s49, v29, #1
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s50, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v28, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s47, x8dot_done_56
    s.movz       s48, #0
    s.add        s49, s9, s23
    s.addi       s50, s48, #0
    s.addi       s48, s49, #96
    s.addi       s49, s33, #256
x8dot_row_57:
    s.addi       s51, s21, #-96
    v.movi       v17, #0
    s.sub        s52, s51, s50
    s.add        s51, s48, s50
    v.splat      v31, s52
    s.shli       s52, s50, #4
    v.cmp.gt     p1, v31, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s51, v19]            // index is in elements (ISA sec 9.1)
    s.add        s51, s49, s52
    s.addi       s52, s50, #1
    s.movz       s53, #32
    v.st.b       [s51, #0], v17
    fence.acq_rel.device
    s.mov        s50, s52
    s.cmp.lt     s51, s50, s53
    br.nz        s51, x8dot_row_57
x8dot_done_56:
    v.splat      v17, s47
    v.movi       v19, #0
    v.splat      v31, s47
    v.movi       v34, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    s.movz       s49, #0
    s.movz       s50, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v31, v34
    v.extract    s51, v29, #2
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s52, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s48, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s48, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v28, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s49, x8dot_done_58
    s.movz       s50, #0
    s.add        s51, s9, s23
    s.addi       s52, s50, #0
    s.addi       s50, s51, #96
    s.addi       s51, s33, #256
x8dot_row_59:
    s.addi       s53, s21, #-96
    v.movi       v17, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v19, s54
    s.shli       s54, s52, #4
    v.cmp.gt     p1, v19, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s53, v20]            // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.addi       s54, s52, #1
    s.movz       s55, #32
    v.st.b       [s53, #0], v17
    fence.acq_rel.device
    s.mov        s52, s54
    s.cmp.lt     s53, s52, s55
    br.nz        s53, x8dot_row_59
x8dot_done_58:
    v.splat      v17, s49
    v.movi       v19, #0
    v.splat      v20, s49
    v.movi       v31, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    s.movz       s51, #0
    s.movz       s52, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v20, v31
    v.extract    s53, v29, #3
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s54, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v28, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s51, x8dot_done_60
    s.movz       s52, #0
    s.add        s53, s9, s23
    s.addi       s54, s52, #0
    s.addi       s52, s53, #96
    s.addi       s53, s33, #256
x8dot_row_61:
    s.addi       s55, s21, #-96
    v.movi       v17, #0
    s.sub        s56, s55, s54
    s.add        s55, s52, s54
    v.splat      v19, s56
    s.shli       s56, s54, #4
    v.cmp.gt     p1, v19, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s55, v22]            // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    s.addi       s56, s54, #1
    s.movz       s57, #32
    v.st.b       [s55, #0], v17
    fence.acq_rel.device
    s.mov        s54, s56
    s.cmp.lt     s55, s54, s57
    br.nz        s55, x8dot_row_61
x8dot_done_60:
    v.splat      v17, s51
    v.movi       v19, #0
    v.splat      v20, s51
    v.movi       v22, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    s.movz       s53, #0
    s.movz       s54, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v20, v22
    v.extract    s55, v29, #4
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s56, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v28, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_62
    s.movz       s54, #0
    s.add        s55, s9, s23
    s.addi       s56, s54, #0
    s.addi       s54, s55, #96
    s.addi       s55, s33, #256
x8dot_row_63:
    s.addi       s57, s21, #-96
    v.movi       v17, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v19, s58
    s.shli       s58, s56, #4
    v.cmp.gt     p1, v19, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s57, v23]            // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.addi       s58, s56, #1
    s.movz       s59, #32
    v.st.b       [s57, #0], v17
    fence.acq_rel.device
    s.mov        s56, s58
    s.cmp.lt     s57, s56, s59
    br.nz        s57, x8dot_row_63
x8dot_done_62:
    v.splat      v17, s53
    v.movi       v19, #0
    v.splat      v20, s53
    v.movi       v22, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    s.movz       s55, #0
    s.movz       s56, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v20, v22
    v.extract    s57, v29, #5
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s58, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s57                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v28, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s55, x8dot_done_64
    s.movz       s56, #0
    s.add        s57, s9, s23
    s.addi       s58, s56, #0
    s.addi       s56, s57, #96
    s.addi       s57, s33, #256
x8dot_row_65:
    s.addi       s59, s21, #-96
    v.movi       v17, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v19, s60
    s.shli       s60, s58, #4
    v.cmp.gt     p1, v19, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s59, v24]            // index is in elements (ISA sec 9.1)
    s.add        s59, s57, s60
    s.addi       s60, s58, #1
    s.movz       s24, #32
    v.st.b       [s59, #0], v17
    fence.acq_rel.device
    s.mov        s58, s60
    s.cmp.lt     s25, s58, s24
    br.nz        s25, x8dot_row_65
x8dot_done_64:
    v.splat      v17, s55
    v.movi       v19, #0
    v.splat      v20, s55
    v.movi       v22, #0
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s25, #0
    s.movz       s26, #0
    s.movz       s27, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v20, v22
    v.extract    s28, v29, #6
    s.mov        s29, s25                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s29, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s25, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s25, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    mb.arm       s25, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s26, v28, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s25
    mb.wait      s25
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s26, x8dot_done_66
    s.movz       s27, #0
    s.add        s28, s9, s23
    s.addi       s29, s27, #0
    s.addi       s27, s28, #96
    s.addi       s28, s33, #256
x8dot_row_67:
    s.addi       s30, s21, #-96
    v.movi       v17, #0
    s.sub        s31, s30, s29
    s.add        s30, s27, s29
    v.splat      v19, s31
    s.shli       s31, s29, #4
    v.cmp.gt     p1, v19, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s30, v32]            // index is in elements (ISA sec 9.1)
    s.add        s30, s28, s31
    s.addi       s31, s29, #1
    s.movz       s32, #32
    v.st.b       [s30, #0], v17
    fence.acq_rel.device
    s.mov        s29, s31
    s.cmp.lt     s30, s29, s32
    br.nz        s30, x8dot_row_67
x8dot_done_66:
    v.splat      v17, s26
    v.movi       v19, #0
    v.splat      v20, s26
    v.movi       v22, #0
    mb.arm       s21, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s26, #0
    s.movz       s27, #0
    s.movz       s28, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v20, v22
    v.extract    s29, v29, #7
    s.mov        s30, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s30, s21            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s26, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s27, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s26, s21          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s21
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s27, #0
    m.mma.async.k32.e4m3 a15, v48, v56, s26
    mb.wait      s26
    s.addi       s28, s33, #3072
    a.vread      v17, a8, s27
    s.movz       s27, #1
    v.st.w       [s28, #0], v17
    s.addi       s29, s28, #64
    a.vread      v17, a8, s27
    s.movz       s27, #2
    s.addi       s30, s28, #128
    s.movz       s31, #3
    s.addi       s32, s28, #192
    s.movz       s34, #4
    v.st.w       [s29, #0], v17
    a.vread      v17, a8, s27
    s.addi       s27, s28, #256
    s.movz       s29, #5
    v.st.w       [s30, #0], v17
    a.vread      v17, a8, s31
    s.addi       s30, s28, #320
    s.movz       s31, #6
    v.st.w       [s32, #0], v17
    a.vread      v17, a8, s34
    s.addi       s32, s28, #384
    s.movz       s34, #7
    v.st.w       [s27, #0], v17
    a.vread      v17, a8, s29
    s.addi       s27, s28, #448
    s.movz       s29, #8
    v.st.w       [s30, #0], v17
    a.vread      v17, a8, s31
    s.addi       s30, s28, #512
    s.movz       s31, #9
    v.st.w       [s32, #0], v17
    a.vread      v17, a8, s34
    s.addi       s32, s28, #576
    s.movz       s34, #10
    v.st.w       [s27, #0], v17
    a.vread      v17, a8, s29
    s.addi       s27, s28, #640
    s.movz       s29, #11
    v.st.w       [s30, #0], v17
    a.vread      v17, a8, s31
    s.addi       s30, s28, #704
    s.movz       s31, #12
    v.st.w       [s32, #0], v17
    a.vread      v17, a8, s34
    s.addi       s32, s28, #768
    s.movz       s34, #13
    v.st.w       [s27, #0], v17
    a.vread      v17, a8, s29
    s.addi       s27, s28, #832
    s.movz       s29, #14
    v.st.w       [s30, #0], v17
    a.vread      v17, a8, s31
    s.addi       s30, s28, #896
    s.movz       s31, #15
    s.addi       s35, s28, #960
    v.st.w       [s32, #0], v17
    a.vread      v17, a8, s34
    s.movz       s28, #0
    s.addi       s32, s33, #4096
    v.st.w       [s27, #0], v17
    a.vread      v17, a8, s29
    s.movz       s27, #1
    s.addi       s29, s32, #64
    v.st.w       [s30, #0], v17
    a.vread      v17, a8, s31
    s.movz       s30, #2
    s.addi       s31, s32, #128
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    a.vread      v17, a9, s28
    s.movz       s28, #3
    s.addi       s34, s32, #192
    v.st.w       [s32, #0], v17
    a.vread      v17, a9, s27
    s.movz       s27, #4
    v.st.w       [s29, #0], v17
    a.vread      v17, a9, s30
    s.addi       s29, s32, #256
    s.movz       s30, #5
    v.st.w       [s31, #0], v17
    a.vread      v17, a9, s28
    s.addi       s28, s32, #320
    s.movz       s31, #6
    v.st.w       [s34, #0], v17
    a.vread      v17, a9, s27
    s.addi       s27, s32, #384
    s.movz       s34, #7
    v.st.w       [s29, #0], v17
    a.vread      v17, a9, s30
    s.addi       s29, s32, #448
    s.movz       s30, #8
    v.st.w       [s28, #0], v17
    a.vread      v17, a9, s31
    s.addi       s28, s32, #512
    s.movz       s31, #9
    v.st.w       [s27, #0], v17
    a.vread      v17, a9, s34
    s.addi       s27, s32, #576
    s.movz       s34, #10
    v.st.w       [s29, #0], v17
    a.vread      v17, a9, s30
    s.addi       s29, s32, #640
    s.movz       s30, #11
    v.st.w       [s28, #0], v17
    a.vread      v17, a9, s31
    s.addi       s28, s32, #704
    s.movz       s31, #12
    v.st.w       [s27, #0], v17
    a.vread      v17, a9, s34
    s.addi       s27, s32, #768
    s.movz       s34, #13
    v.st.w       [s29, #0], v17
    a.vread      v17, a9, s30
    s.addi       s29, s32, #832
    s.movz       s30, #14
    v.st.w       [s28, #0], v17
    a.vread      v17, a9, s31
    s.addi       s28, s32, #896
    s.movz       s31, #15
    s.addi       s35, s32, #960
    v.st.w       [s27, #0], v17
    a.vread      v17, a9, s34
    s.movz       s27, #0
    s.addi       s32, s33, #5120
    v.st.w       [s29, #0], v17
    a.vread      v17, a9, s30
    s.movz       s29, #1
    s.addi       s30, s32, #64
    v.st.w       [s28, #0], v17
    a.vread      v17, a9, s31
    s.movz       s28, #2
    s.addi       s31, s32, #128
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    a.vread      v17, a10, s27
    s.movz       s27, #3
    s.addi       s34, s32, #192
    v.st.w       [s32, #0], v17
    a.vread      v17, a10, s29
    s.movz       s29, #4
    v.st.w       [s30, #0], v17
    a.vread      v17, a10, s28
    s.addi       s28, s32, #256
    s.movz       s30, #5
    v.st.w       [s31, #0], v17
    a.vread      v17, a10, s27
    s.addi       s27, s32, #320
    s.movz       s31, #6
    v.st.w       [s34, #0], v17
    a.vread      v17, a10, s29
    s.addi       s29, s32, #384
    s.movz       s34, #7
    v.st.w       [s28, #0], v17
    a.vread      v17, a10, s30
    s.addi       s28, s32, #448
    s.movz       s30, #8
    v.st.w       [s27, #0], v17
    a.vread      v17, a10, s31
    s.addi       s27, s32, #512
    s.movz       s31, #9
    v.st.w       [s29, #0], v17
    a.vread      v17, a10, s34
    s.addi       s29, s32, #576
    s.movz       s34, #10
    v.st.w       [s28, #0], v17
    a.vread      v17, a10, s30
    s.addi       s28, s32, #640
    s.movz       s30, #11
    v.st.w       [s27, #0], v17
    a.vread      v17, a10, s31
    s.addi       s27, s32, #704
    s.movz       s31, #12
    v.st.w       [s29, #0], v17
    a.vread      v17, a10, s34
    s.addi       s29, s32, #768
    s.movz       s34, #13
    v.st.w       [s28, #0], v17
    a.vread      v17, a10, s30
    s.addi       s28, s32, #832
    s.movz       s30, #14
    v.st.w       [s27, #0], v17
    a.vread      v17, a10, s31
    s.addi       s27, s32, #896
    s.movz       s31, #15
    s.addi       s35, s32, #960
    v.st.w       [s29, #0], v17
    a.vread      v17, a10, s34
    s.movz       s29, #0
    s.addi       s32, s33, #6144
    v.st.w       [s28, #0], v17
    a.vread      v17, a10, s30
    s.movz       s28, #1
    s.addi       s30, s32, #64
    v.st.w       [s27, #0], v17
    a.vread      v17, a10, s31
    s.movz       s27, #2
    s.addi       s31, s32, #128
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    a.vread      v17, a11, s29
    s.movz       s29, #3
    s.addi       s34, s32, #192
    v.st.w       [s32, #0], v17
    a.vread      v17, a11, s28
    s.movz       s28, #4
    v.st.w       [s30, #0], v17
    a.vread      v17, a11, s27
    s.addi       s27, s32, #256
    s.movz       s30, #5
    v.st.w       [s31, #0], v17
    a.vread      v17, a11, s29
    s.addi       s29, s32, #320
    s.movz       s31, #6
    v.st.w       [s34, #0], v17
    a.vread      v17, a11, s28
    s.addi       s28, s32, #384
    s.movz       s34, #7
    v.st.w       [s27, #0], v17
    a.vread      v17, a11, s30
    s.addi       s27, s32, #448
    s.movz       s30, #8
    v.st.w       [s29, #0], v17
    a.vread      v17, a11, s31
    s.addi       s29, s32, #512
    s.movz       s31, #9
    v.st.w       [s28, #0], v17
    a.vread      v17, a11, s34
    s.addi       s28, s32, #576
    s.movz       s34, #10
    v.st.w       [s27, #0], v17
    a.vread      v17, a11, s30
    s.addi       s27, s32, #640
    s.movz       s30, #11
    v.st.w       [s29, #0], v17
    a.vread      v17, a11, s31
    s.addi       s29, s32, #704
    s.movz       s31, #12
    v.st.w       [s28, #0], v17
    a.vread      v17, a11, s34
    s.addi       s28, s32, #768
    s.movz       s34, #13
    v.st.w       [s27, #0], v17
    a.vread      v17, a11, s30
    s.addi       s27, s32, #832
    s.movz       s30, #14
    v.st.w       [s29, #0], v17
    a.vread      v17, a11, s31
    s.addi       s29, s32, #896
    s.movz       s31, #15
    s.addi       s35, s32, #960
    v.st.w       [s28, #0], v17
    a.vread      v17, a11, s34
    s.movz       s28, #0
    s.addi       s32, s33, #7168
    v.st.w       [s27, #0], v17
    a.vread      v17, a11, s30
    s.movz       s27, #1
    s.addi       s30, s32, #64
    v.st.w       [s29, #0], v17
    a.vread      v17, a11, s31
    s.movz       s29, #2
    s.addi       s31, s32, #128
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    a.vread      v17, a12, s28
    s.movz       s28, #3
    s.addi       s34, s32, #192
    v.st.w       [s32, #0], v17
    a.vread      v17, a12, s27
    s.movz       s27, #4
    v.st.w       [s30, #0], v17
    a.vread      v17, a12, s29
    s.addi       s29, s32, #256
    s.movz       s30, #5
    v.st.w       [s31, #0], v17
    a.vread      v17, a12, s28
    s.addi       s28, s32, #320
    s.movz       s31, #6
    v.st.w       [s34, #0], v17
    a.vread      v17, a12, s27
    s.addi       s27, s32, #384
    s.movz       s34, #7
    v.st.w       [s29, #0], v17
    a.vread      v17, a12, s30
    s.addi       s29, s32, #448
    s.movz       s30, #8
    v.st.w       [s28, #0], v17
    a.vread      v17, a12, s31
    s.addi       s28, s32, #512
    s.movz       s31, #9
    v.st.w       [s27, #0], v17
    a.vread      v17, a12, s34
    s.addi       s27, s32, #576
    s.movz       s34, #10
    v.st.w       [s29, #0], v17
    a.vread      v17, a12, s30
    s.addi       s29, s32, #640
    s.movz       s30, #11
    v.st.w       [s28, #0], v17
    a.vread      v17, a12, s31
    s.addi       s28, s32, #704
    s.movz       s31, #12
    v.st.w       [s27, #0], v17
    a.vread      v17, a12, s34
    s.addi       s27, s32, #768
    s.movz       s34, #13
    v.st.w       [s29, #0], v17
    a.vread      v17, a12, s30
    s.addi       s29, s32, #832
    s.movz       s30, #14
    v.st.w       [s28, #0], v17
    a.vread      v17, a12, s31
    s.addi       s28, s32, #896
    s.movz       s31, #15
    s.addi       s35, s32, #960
    v.st.w       [s27, #0], v17
    a.vread      v17, a12, s34
    s.movz       s27, #0
    s.addi       s32, s33, #8192
    v.st.w       [s29, #0], v17
    a.vread      v17, a12, s30
    s.movz       s29, #1
    s.addi       s30, s32, #64
    v.st.w       [s28, #0], v17
    a.vread      v17, a12, s31
    s.movz       s28, #2
    s.addi       s31, s32, #128
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    a.vread      v17, a13, s27
    s.movz       s27, #3
    s.addi       s34, s32, #192
    v.st.w       [s32, #0], v17
    a.vread      v17, a13, s29
    s.movz       s29, #4
    v.st.w       [s30, #0], v17
    a.vread      v17, a13, s28
    s.addi       s28, s32, #256
    s.movz       s30, #5
    v.st.w       [s31, #0], v17
    a.vread      v17, a13, s27
    s.addi       s27, s32, #320
    s.movz       s31, #6
    v.st.w       [s34, #0], v17
    a.vread      v17, a13, s29
    s.addi       s29, s32, #384
    s.movz       s34, #7
    v.st.w       [s28, #0], v17
    a.vread      v17, a13, s30
    s.addi       s28, s32, #448
    s.movz       s30, #8
    v.st.w       [s27, #0], v17
    a.vread      v17, a13, s31
    s.addi       s27, s32, #512
    s.movz       s31, #9
    v.st.w       [s29, #0], v17
    a.vread      v17, a13, s34
    s.addi       s29, s32, #576
    s.movz       s34, #10
    v.st.w       [s28, #0], v17
    a.vread      v17, a13, s30
    s.addi       s28, s32, #640
    s.movz       s30, #11
    v.st.w       [s27, #0], v17
    a.vread      v17, a13, s31
    s.addi       s27, s32, #704
    s.movz       s31, #12
    v.st.w       [s29, #0], v17
    a.vread      v17, a13, s34
    s.addi       s29, s32, #768
    s.movz       s34, #13
    v.st.w       [s28, #0], v17
    a.vread      v17, a13, s30
    s.addi       s28, s32, #832
    s.movz       s30, #14
    v.st.w       [s27, #0], v17
    a.vread      v17, a13, s31
    s.addi       s27, s32, #896
    s.movz       s31, #15
    s.addi       s35, s32, #960
    v.st.w       [s29, #0], v17
    a.vread      v17, a13, s34
    s.movz       s29, #0
    s.addi       s32, s33, #9216
    v.st.w       [s28, #0], v17
    a.vread      v17, a13, s30
    s.movz       s28, #1
    s.addi       s30, s32, #64
    v.st.w       [s27, #0], v17
    a.vread      v17, a13, s31
    s.movz       s27, #2
    s.addi       s31, s32, #128
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    a.vread      v17, a14, s29
    s.movz       s29, #3
    s.addi       s34, s32, #192
    v.st.w       [s32, #0], v17
    a.vread      v17, a14, s28
    s.movz       s28, #4
    v.st.w       [s30, #0], v17
    a.vread      v17, a14, s27
    s.addi       s27, s32, #256
    s.movz       s30, #5
    v.st.w       [s31, #0], v17
    a.vread      v17, a14, s29
    s.addi       s29, s32, #320
    s.movz       s31, #6
    v.st.w       [s34, #0], v17
    a.vread      v17, a14, s28
    s.addi       s28, s32, #384
    s.movz       s34, #7
    v.st.w       [s27, #0], v17
    a.vread      v17, a14, s30
    s.addi       s27, s32, #448
    s.movz       s30, #8
    v.st.w       [s29, #0], v17
    a.vread      v17, a14, s31
    s.addi       s29, s32, #512
    s.movz       s31, #9
    v.st.w       [s28, #0], v17
    a.vread      v17, a14, s34
    s.addi       s28, s32, #576
    s.movz       s34, #10
    v.st.w       [s27, #0], v17
    a.vread      v17, a14, s30
    s.addi       s27, s32, #640
    s.movz       s30, #11
    v.st.w       [s29, #0], v17
    a.vread      v17, a14, s31
    s.addi       s29, s32, #704
    s.movz       s31, #12
    v.st.w       [s28, #0], v17
    a.vread      v17, a14, s34
    s.addi       s28, s32, #768
    s.movz       s34, #13
    v.st.w       [s27, #0], v17
    a.vread      v17, a14, s30
    s.addi       s27, s32, #832
    s.movz       s30, #14
    v.st.w       [s29, #0], v17
    a.vread      v17, a14, s31
    s.addi       s29, s32, #896
    s.movz       s31, #15
    s.addi       s35, s32, #960
    v.st.w       [s28, #0], v17
    a.vread      v17, a14, s34
    s.movz       s28, #0
    s.addi       s32, s33, #10240
    v.st.w       [s27, #0], v17
    a.vread      v17, a14, s30
    s.movz       s27, #1
    s.addi       s30, s32, #64
    v.st.w       [s29, #0], v17
    a.vread      v17, a14, s31
    s.movz       s29, #2
    s.addi       s31, s32, #128
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    a.vread      v17, a15, s28
    s.movz       s28, #3
    s.addi       s34, s32, #192
    v.st.w       [s32, #0], v17
    a.vread      v17, a15, s27
    s.movz       s27, #4
    v.st.w       [s30, #0], v17
    a.vread      v17, a15, s29
    s.addi       s29, s32, #256
    s.movz       s30, #5
    v.st.w       [s31, #0], v17
    a.vread      v17, a15, s28
    s.addi       s28, s32, #320
    s.movz       s31, #6
    v.st.w       [s34, #0], v17
    a.vread      v17, a15, s27
    s.addi       s27, s32, #384
    s.movz       s34, #7
    v.st.w       [s29, #0], v17
    a.vread      v17, a15, s30
    s.addi       s29, s32, #448
    s.movz       s30, #8
    v.st.w       [s28, #0], v17
    a.vread      v17, a15, s31
    s.addi       s28, s32, #512
    s.movz       s31, #9
    v.st.w       [s27, #0], v17
    a.vread      v17, a15, s34
    s.addi       s27, s32, #576
    s.movz       s34, #10
    v.st.w       [s29, #0], v17
    a.vread      v17, a15, s30
    s.addi       s29, s32, #640
    s.movz       s30, #11
    v.st.w       [s28, #0], v17
    a.vread      v17, a15, s31
    s.addi       s28, s32, #704
    s.movz       s31, #12
    v.st.w       [s27, #0], v17
    a.vread      v17, a15, s34
    s.addi       s27, s32, #768
    s.movz       s34, #13
    v.st.w       [s29, #0], v17
    a.vread      v17, a15, s30
    s.addi       s29, s32, #832
    s.movz       s30, #14
    v.st.w       [s28, #0], v17
    a.vread      v17, a15, s31
    s.addi       s28, s32, #896
    s.movz       s31, #15
    s.addi       s35, s32, #960
    v.st.w       [s27, #0], v17
    a.vread      v17, a15, s34
    s.movz       s27, #0
    s.addi       s32, s33, #3072
    v.st.w       [s29, #0], v17
    a.vread      v17, a15, s30
    v.extract    s29, v0, #0
    v.splat      v19, s29
    s.addi       s29, s33, #11264
    s.movz       s30, #1
    v.st.w       [s28, #0], v17
    a.vread      v17, a15, s31
    s.addi       s28, s33, #3136
    v.extract    s31, v0, #1
    v.splat      v20, s31
    s.addi       s31, s29, #64
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    a.vread      v17, a0, s27
    s.movz       s27, #2
    s.addi       s34, s33, #3200
    v.ld.w       v22, [s32, #0]
    v.extract    s32, v0, #2
    v.splat      v23, s32
    s.addi       s32, s29, #128
    vf.mul       v24, v22, v19
    vf.mul       v19, v24, v21
    vf.add       v22, v17, v19
    v.st.w       [s29, #0], v22
    a.vread      v17, a0, s30
    s.movz       s30, #3
    v.ld.w       v19, [s28, #0]
    s.addi       s28, s33, #3264
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    a.vread      v17, a0, s27
    v.extract    s27, v0, #3
    v.splat      v19, s27
    s.addi       s27, s29, #192
    s.movz       s31, #4
    v.ld.w       v20, [s34, #0]
    s.addi       s34, s33, #3328
    vf.mul       v22, v20, v23
    vf.mul       v20, v22, v21
    vf.add       v22, v17, v20
    v.st.w       [s32, #0], v22
    a.vread      v17, a0, s30
    v.extract    s30, v0, #4
    v.splat      v20, s30
    s.addi       s30, s29, #256
    s.movz       s32, #5
    v.ld.w       v22, [s28, #0]
    s.addi       s28, s33, #3392
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v21
    vf.add       v22, v17, v19
    v.st.w       [s27, #0], v22
    a.vread      v17, a0, s31
    v.extract    s27, v0, #5
    v.splat      v19, s27
    s.addi       s27, s29, #320
    s.movz       s31, #6
    v.ld.w       v22, [s34, #0]
    s.addi       s34, s33, #3456
    vf.mul       v23, v22, v20
    vf.mul       v20, v23, v21
    vf.add       v22, v17, v20
    v.st.w       [s30, #0], v22
    a.vread      v17, a0, s32
    v.extract    s30, v0, #6
    v.splat      v20, s30
    s.addi       s30, s29, #384
    s.movz       s32, #7
    v.ld.w       v22, [s28, #0]
    s.addi       s28, s33, #3520
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v21
    vf.add       v22, v17, v19
    v.st.w       [s27, #0], v22
    a.vread      v17, a0, s31
    v.extract    s27, v0, #7
    v.splat      v19, s27
    s.addi       s27, s29, #448
    s.movz       s31, #8
    v.ld.w       v22, [s34, #0]
    s.addi       s34, s33, #3584
    vf.mul       v23, v22, v20
    vf.mul       v20, v23, v21
    vf.add       v22, v17, v20
    v.st.w       [s30, #0], v22
    a.vread      v17, a0, s32
    v.extract    s30, v0, #8
    v.splat      v20, s30
    s.addi       s30, s29, #512
    s.movz       s32, #9
    v.ld.w       v22, [s28, #0]
    s.addi       s28, s33, #3648
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v21
    vf.add       v22, v17, v19
    v.st.w       [s27, #0], v22
    a.vread      v17, a0, s31
    v.extract    s27, v0, #9
    v.splat      v19, s27
    s.addi       s27, s29, #576
    s.movz       s31, #10
    v.ld.w       v22, [s34, #0]
    s.addi       s34, s33, #3712
    vf.mul       v23, v22, v20
    vf.mul       v20, v23, v21
    vf.add       v22, v17, v20
    v.st.w       [s30, #0], v22
    a.vread      v17, a0, s32
    v.extract    s30, v0, #10
    v.splat      v20, s30
    s.addi       s30, s29, #640
    s.movz       s32, #11
    v.ld.w       v22, [s28, #0]
    s.addi       s28, s33, #3776
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v21
    vf.add       v22, v17, v19
    v.st.w       [s27, #0], v22
    a.vread      v17, a0, s31
    v.extract    s27, v0, #11
    v.splat      v19, s27
    s.addi       s27, s29, #704
    s.movz       s31, #12
    v.ld.w       v22, [s34, #0]
    s.addi       s34, s33, #3840
    vf.mul       v23, v22, v20
    vf.mul       v20, v23, v21
    vf.add       v22, v17, v20
    v.st.w       [s30, #0], v22
    a.vread      v17, a0, s32
    v.extract    s30, v0, #12
    v.splat      v20, s30
    s.addi       s30, s29, #768
    s.movz       s32, #13
    v.ld.w       v22, [s28, #0]
    s.addi       s28, s33, #3904
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v21
    vf.add       v22, v17, v19
    v.st.w       [s27, #0], v22
    a.vread      v17, a0, s31
    v.extract    s27, v0, #13
    v.splat      v19, s27
    s.addi       s27, s29, #832
    s.movz       s31, #14
    v.ld.w       v22, [s34, #0]
    s.addi       s34, s33, #3968
    vf.mul       v23, v22, v20
    vf.mul       v20, v23, v21
    vf.add       v22, v17, v20
    v.st.w       [s30, #0], v22
    a.vread      v17, a0, s32
    v.extract    s30, v0, #14
    v.splat      v20, s30
    s.addi       s30, s29, #896
    s.movz       s32, #15
    s.addi       s35, s29, #960
    v.ld.w       v22, [s28, #0]
    s.addi       s28, s33, #4032
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v21
    vf.add       v22, v17, v19
    v.st.w       [s27, #0], v22
    a.vread      v17, a0, s31
    v.extract    s27, v0, #15
    v.splat      v19, s27
    s.movz       s27, #0
    s.addi       s29, s33, #4096
    v.ld.w       v22, [s34, #0]
    v.extract    s31, v0, #0
    v.splat      v23, s31
    s.addi       s31, s33, #12288
    vf.mul       v24, v22, v20
    vf.mul       v20, v24, v21
    vf.add       v22, v17, v20
    v.st.w       [s30, #0], v22
    a.vread      v17, a0, s32
    s.movz       s30, #1
    s.addi       s32, s33, #4160
    v.ld.w       v20, [s28, #0]
    v.extract    s28, v0, #1
    v.splat      v22, s28
    s.addi       s28, s31, #64
    vf.mul       v24, v20, v19
    vf.mul       v19, v24, v21
    vf.add       v20, v17, v19
    v.st.w       [s35, #0], v20
    fence.acq_rel.device
    a.vread      v17, a1, s27
    s.movz       s27, #2
    s.addi       s34, s33, #4224
    v.ld.w       v19, [s29, #0]
    v.extract    s29, v0, #2
    v.splat      v20, s29
    s.addi       s29, s31, #128
    vf.mul       v21, v19, v23
    vf.mul       v19, v21, v27
    vf.add       v21, v17, v19
    v.st.w       [s31, #0], v21
    a.vread      v17, a1, s30
    s.movz       s30, #3
    v.ld.w       v19, [s32, #0]
    s.addi       s32, s33, #4288
    vf.mul       v21, v19, v22
    vf.mul       v19, v21, v27
    vf.add       v21, v17, v19
    v.st.w       [s28, #0], v21
    a.vread      v17, a1, s27
    v.extract    s27, v0, #3
    v.splat      v19, s27
    s.addi       s27, s31, #192
    s.movz       s28, #4
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #4352
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v27
    vf.add       v21, v17, v20
    v.st.w       [s29, #0], v21
    a.vread      v17, a1, s30
    v.extract    s29, v0, #4
    v.splat      v20, s29
    s.addi       s29, s31, #256
    s.movz       s30, #5
    v.ld.w       v21, [s32, #0]
    s.addi       s32, s33, #4416
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v27
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a1, s28
    v.extract    s27, v0, #5
    v.splat      v19, s27
    s.addi       s27, s31, #320
    s.movz       s28, #6
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #4480
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v27
    vf.add       v21, v17, v20
    v.st.w       [s29, #0], v21
    a.vread      v17, a1, s30
    v.extract    s29, v0, #6
    v.splat      v20, s29
    s.addi       s29, s31, #384
    s.movz       s30, #7
    v.ld.w       v21, [s32, #0]
    s.addi       s32, s33, #4544
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v27
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a1, s28
    v.extract    s27, v0, #7
    v.splat      v19, s27
    s.addi       s27, s31, #448
    s.movz       s28, #8
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #4608
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v27
    vf.add       v21, v17, v20
    v.st.w       [s29, #0], v21
    a.vread      v17, a1, s30
    v.extract    s29, v0, #8
    v.splat      v20, s29
    s.addi       s29, s31, #512
    s.movz       s30, #9
    v.ld.w       v21, [s32, #0]
    s.addi       s32, s33, #4672
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v27
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a1, s28
    v.extract    s27, v0, #9
    v.splat      v19, s27
    s.addi       s27, s31, #576
    s.movz       s28, #10
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #4736
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v27
    vf.add       v21, v17, v20
    v.st.w       [s29, #0], v21
    a.vread      v17, a1, s30
    v.extract    s29, v0, #10
    v.splat      v20, s29
    s.addi       s29, s31, #640
    s.movz       s30, #11
    v.ld.w       v21, [s32, #0]
    s.addi       s32, s33, #4800
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v27
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a1, s28
    v.extract    s27, v0, #11
    v.splat      v19, s27
    s.addi       s27, s31, #704
    s.movz       s28, #12
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #4864
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v27
    vf.add       v21, v17, v20
    v.st.w       [s29, #0], v21
    a.vread      v17, a1, s30
    v.extract    s29, v0, #12
    v.splat      v20, s29
    s.addi       s29, s31, #768
    s.movz       s30, #13
    v.ld.w       v21, [s32, #0]
    s.addi       s32, s33, #4928
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v27
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a1, s28
    v.extract    s27, v0, #13
    v.splat      v19, s27
    s.addi       s27, s31, #832
    s.movz       s28, #14
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #4992
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v27
    vf.add       v21, v17, v20
    v.st.w       [s29, #0], v21
    a.vread      v17, a1, s30
    v.extract    s29, v0, #14
    v.splat      v20, s29
    s.addi       s29, s31, #896
    s.movz       s30, #15
    s.addi       s35, s31, #960
    v.ld.w       v21, [s32, #0]
    s.addi       s31, s33, #5056
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v27
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a1, s28
    v.extract    s27, v0, #15
    v.splat      v19, s27
    s.movz       s27, #0
    s.addi       s28, s33, #5120
    v.ld.w       v21, [s34, #0]
    v.extract    s32, v0, #0
    v.splat      v22, s32
    s.addi       s32, s33, #13312
    vf.mul       v23, v21, v20
    vf.mul       v20, v23, v27
    vf.add       v21, v17, v20
    v.st.w       [s29, #0], v21
    a.vread      v17, a1, s30
    s.movz       s29, #1
    s.addi       s30, s33, #5184
    v.ld.w       v20, [s31, #0]
    v.extract    s31, v0, #1
    v.splat      v21, s31
    s.addi       s31, s32, #64
    vf.mul       v23, v20, v19
    vf.mul       v19, v23, v27
    vf.add       v20, v17, v19
    v.st.w       [s35, #0], v20
    fence.acq_rel.device
    a.vread      v17, a2, s27
    s.movz       s27, #2
    s.addi       s34, s33, #5248
    v.ld.w       v19, [s28, #0]
    v.extract    s28, v0, #2
    v.splat      v20, s28
    s.addi       s28, s32, #128
    vf.mul       v23, v19, v22
    vf.mul       v19, v23, v30
    vf.add       v22, v17, v19
    v.st.w       [s32, #0], v22
    a.vread      v17, a2, s29
    s.movz       s29, #3
    v.ld.w       v19, [s30, #0]
    s.addi       s30, s33, #5312
    vf.mul       v22, v19, v21
    vf.mul       v19, v22, v30
    vf.add       v21, v17, v19
    v.st.w       [s31, #0], v21
    a.vread      v17, a2, s27
    v.extract    s27, v0, #3
    v.splat      v19, s27
    s.addi       s27, s32, #192
    s.movz       s31, #4
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #5376
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v30
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a2, s29
    v.extract    s28, v0, #4
    v.splat      v20, s28
    s.addi       s28, s32, #256
    s.movz       s29, #5
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s33, #5440
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v30
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a2, s31
    v.extract    s27, v0, #5
    v.splat      v19, s27
    s.addi       s27, s32, #320
    s.movz       s31, #6
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #5504
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v30
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a2, s29
    v.extract    s28, v0, #6
    v.splat      v20, s28
    s.addi       s28, s32, #384
    s.movz       s29, #7
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s33, #5568
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v30
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a2, s31
    v.extract    s27, v0, #7
    v.splat      v19, s27
    s.addi       s27, s32, #448
    s.movz       s31, #8
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #5632
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v30
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a2, s29
    v.extract    s28, v0, #8
    v.splat      v20, s28
    s.addi       s28, s32, #512
    s.movz       s29, #9
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s33, #5696
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v30
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a2, s31
    v.extract    s27, v0, #9
    v.splat      v19, s27
    s.addi       s27, s32, #576
    s.movz       s31, #10
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #5760
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v30
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a2, s29
    v.extract    s28, v0, #10
    v.splat      v20, s28
    s.addi       s28, s32, #640
    s.movz       s29, #11
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s33, #5824
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v30
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a2, s31
    v.extract    s27, v0, #11
    v.splat      v19, s27
    s.addi       s27, s32, #704
    s.movz       s31, #12
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #5888
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v30
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a2, s29
    v.extract    s28, v0, #12
    v.splat      v20, s28
    s.addi       s28, s32, #768
    s.movz       s29, #13
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s33, #5952
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v30
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a2, s31
    v.extract    s27, v0, #13
    v.splat      v19, s27
    s.addi       s27, s32, #832
    s.movz       s31, #14
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #6016
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v30
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a2, s29
    v.extract    s28, v0, #14
    v.splat      v20, s28
    s.addi       s28, s32, #896
    s.movz       s29, #15
    s.addi       s35, s32, #960
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s33, #6080
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v30
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a2, s31
    v.extract    s27, v0, #15
    v.splat      v19, s27
    s.movz       s27, #0
    s.addi       s31, s33, #6144
    v.ld.w       v21, [s34, #0]
    v.extract    s32, v0, #0
    v.splat      v22, s32
    s.addi       s32, s33, #14336
    vf.mul       v23, v21, v20
    vf.mul       v20, v23, v30
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a2, s29
    s.movz       s28, #1
    s.addi       s29, s33, #6208
    v.ld.w       v20, [s30, #0]
    v.extract    s30, v0, #1
    v.splat      v21, s30
    s.addi       s30, s32, #64
    vf.mul       v23, v20, v19
    vf.mul       v19, v23, v30
    vf.add       v20, v17, v19
    v.st.w       [s35, #0], v20
    fence.acq_rel.device
    a.vread      v17, a3, s27
    s.movz       s27, #2
    s.addi       s34, s33, #6272
    v.ld.w       v19, [s31, #0]
    v.extract    s31, v0, #2
    v.splat      v20, s31
    s.addi       s31, s32, #128
    vf.mul       v23, v19, v22
    vf.mul       v19, v23, v33
    vf.add       v22, v17, v19
    v.st.w       [s32, #0], v22
    a.vread      v17, a3, s28
    s.movz       s28, #3
    v.ld.w       v19, [s29, #0]
    s.addi       s29, s33, #6336
    vf.mul       v22, v19, v21
    vf.mul       v19, v22, v33
    vf.add       v21, v17, v19
    v.st.w       [s30, #0], v21
    a.vread      v17, a3, s27
    v.extract    s27, v0, #3
    v.splat      v19, s27
    s.addi       s27, s32, #192
    s.movz       s30, #4
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #6400
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v33
    vf.add       v21, v17, v20
    v.st.w       [s31, #0], v21
    a.vread      v17, a3, s28
    v.extract    s28, v0, #4
    v.splat      v20, s28
    s.addi       s28, s32, #256
    s.movz       s31, #5
    v.ld.w       v21, [s29, #0]
    s.addi       s29, s33, #6464
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v33
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a3, s30
    v.extract    s27, v0, #5
    v.splat      v19, s27
    s.addi       s27, s32, #320
    s.movz       s30, #6
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #6528
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v33
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a3, s31
    v.extract    s28, v0, #6
    v.splat      v20, s28
    s.addi       s28, s32, #384
    s.movz       s31, #7
    v.ld.w       v21, [s29, #0]
    s.addi       s29, s33, #6592
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v33
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a3, s30
    v.extract    s27, v0, #7
    v.splat      v19, s27
    s.addi       s27, s32, #448
    s.movz       s30, #8
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #6656
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v33
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a3, s31
    v.extract    s28, v0, #8
    v.splat      v20, s28
    s.addi       s28, s32, #512
    s.movz       s31, #9
    v.ld.w       v21, [s29, #0]
    s.addi       s29, s33, #6720
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v33
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a3, s30
    v.extract    s27, v0, #9
    v.splat      v19, s27
    s.addi       s27, s32, #576
    s.movz       s30, #10
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #6784
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v33
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a3, s31
    v.extract    s28, v0, #10
    v.splat      v20, s28
    s.addi       s28, s32, #640
    s.movz       s31, #11
    v.ld.w       v21, [s29, #0]
    s.addi       s29, s33, #6848
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v33
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a3, s30
    v.extract    s27, v0, #11
    v.splat      v19, s27
    s.addi       s27, s32, #704
    s.movz       s30, #12
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #6912
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v33
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a3, s31
    v.extract    s28, v0, #12
    v.splat      v20, s28
    s.addi       s28, s32, #768
    s.movz       s31, #13
    v.ld.w       v21, [s29, #0]
    s.addi       s29, s33, #6976
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v33
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a3, s30
    v.extract    s27, v0, #13
    v.splat      v19, s27
    s.addi       s27, s32, #832
    s.movz       s30, #14
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #7040
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v33
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a3, s31
    v.extract    s28, v0, #14
    v.splat      v20, s28
    s.addi       s28, s32, #896
    s.movz       s31, #15
    s.addi       s35, s32, #960
    v.ld.w       v21, [s29, #0]
    s.addi       s29, s33, #7104
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v33
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a3, s30
    v.extract    s27, v0, #15
    v.splat      v19, s27
    s.movz       s27, #0
    s.addi       s30, s33, #7168
    v.ld.w       v21, [s34, #0]
    v.extract    s32, v0, #0
    v.splat      v22, s32
    s.addi       s32, s33, #15360
    vf.mul       v23, v21, v20
    vf.mul       v20, v23, v33
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a3, s31
    s.movz       s28, #1
    s.addi       s31, s33, #7232
    v.ld.w       v20, [s29, #0]
    v.extract    s29, v0, #1
    v.splat      v21, s29
    s.addi       s29, s32, #64
    vf.mul       v23, v20, v19
    vf.mul       v19, v23, v33
    vf.add       v20, v17, v19
    v.st.w       [s35, #0], v20
    fence.acq_rel.device
    a.vread      v17, a4, s27
    s.movz       s27, #2
    s.addi       s34, s33, #7296
    v.ld.w       v19, [s30, #0]
    v.extract    s30, v0, #2
    v.splat      v20, s30
    s.addi       s30, s32, #128
    vf.mul       v23, v19, v22
    vf.mul       v19, v23, v25
    vf.add       v22, v17, v19
    v.st.w       [s32, #0], v22
    a.vread      v17, a4, s28
    s.movz       s28, #3
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s33, #7360
    vf.mul       v22, v19, v21
    vf.mul       v19, v22, v25
    vf.add       v21, v17, v19
    v.st.w       [s29, #0], v21
    a.vread      v17, a4, s27
    v.extract    s27, v0, #3
    v.splat      v19, s27
    s.addi       s27, s32, #192
    s.movz       s29, #4
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #7424
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v25
    vf.add       v21, v17, v20
    v.st.w       [s30, #0], v21
    a.vread      v17, a4, s28
    v.extract    s28, v0, #4
    v.splat      v20, s28
    s.addi       s28, s32, #256
    s.movz       s30, #5
    v.ld.w       v21, [s31, #0]
    s.addi       s31, s33, #7488
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v25
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a4, s29
    v.extract    s27, v0, #5
    v.splat      v19, s27
    s.addi       s27, s32, #320
    s.movz       s29, #6
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #7552
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v25
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a4, s30
    v.extract    s28, v0, #6
    v.splat      v20, s28
    s.addi       s28, s32, #384
    s.movz       s30, #7
    v.ld.w       v21, [s31, #0]
    s.addi       s31, s33, #7616
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v25
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a4, s29
    v.extract    s27, v0, #7
    v.splat      v19, s27
    s.addi       s27, s32, #448
    s.movz       s29, #8
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #7680
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v25
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a4, s30
    v.extract    s28, v0, #8
    v.splat      v20, s28
    s.addi       s28, s32, #512
    s.movz       s30, #9
    v.ld.w       v21, [s31, #0]
    s.addi       s31, s33, #7744
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v25
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a4, s29
    v.extract    s27, v0, #9
    v.splat      v19, s27
    s.addi       s27, s32, #576
    s.movz       s29, #10
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #7808
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v25
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a4, s30
    v.extract    s28, v0, #10
    v.splat      v20, s28
    s.addi       s28, s32, #640
    s.movz       s30, #11
    v.ld.w       v21, [s31, #0]
    s.addi       s31, s33, #7872
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v25
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a4, s29
    v.extract    s27, v0, #11
    v.splat      v19, s27
    s.addi       s27, s32, #704
    s.movz       s29, #12
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #7936
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v25
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a4, s30
    v.extract    s28, v0, #12
    v.splat      v20, s28
    s.addi       s28, s32, #768
    s.movz       s30, #13
    v.ld.w       v21, [s31, #0]
    s.addi       s31, s33, #8000
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v25
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a4, s29
    v.extract    s27, v0, #13
    v.splat      v19, s27
    s.addi       s27, s32, #832
    s.movz       s29, #14
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #8064
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v25
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a4, s30
    v.extract    s28, v0, #14
    v.splat      v20, s28
    s.addi       s28, s32, #896
    s.movz       s30, #15
    s.addi       s35, s32, #960
    v.ld.w       v21, [s31, #0]
    s.addi       s31, s33, #8128
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v25
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a4, s29
    v.extract    s27, v0, #15
    v.splat      v19, s27
    s.movz       s27, #0
    s.addi       s29, s33, #8192
    v.ld.w       v21, [s34, #0]
    v.extract    s32, v0, #0
    v.splat      v22, s32
    s.addi       s32, s33, #16384
    vf.mul       v23, v21, v20
    vf.mul       v20, v23, v25
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a4, s30
    s.movz       s28, #1
    s.addi       s30, s33, #8256
    v.ld.w       v20, [s31, #0]
    v.extract    s31, v0, #1
    v.splat      v21, s31
    s.addi       s31, s32, #64
    vf.mul       v23, v20, v19
    vf.mul       v19, v23, v25
    vf.add       v20, v17, v19
    v.st.w       [s35, #0], v20
    fence.acq_rel.device
    a.vread      v17, a5, s27
    s.movz       s27, #2
    s.addi       s34, s33, #8320
    v.ld.w       v19, [s29, #0]
    v.extract    s29, v0, #2
    v.splat      v20, s29
    s.addi       s29, s32, #128
    vf.mul       v23, v19, v22
    vf.mul       v19, v23, v26
    vf.add       v22, v17, v19
    v.st.w       [s32, #0], v22
    a.vread      v17, a5, s28
    s.movz       s28, #3
    v.ld.w       v19, [s30, #0]
    s.addi       s30, s33, #8384
    vf.mul       v22, v19, v21
    vf.mul       v19, v22, v26
    vf.add       v21, v17, v19
    v.st.w       [s31, #0], v21
    a.vread      v17, a5, s27
    v.extract    s27, v0, #3
    v.splat      v19, s27
    s.addi       s27, s32, #192
    s.movz       s31, #4
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #8448
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v26
    vf.add       v21, v17, v20
    v.st.w       [s29, #0], v21
    a.vread      v17, a5, s28
    v.extract    s28, v0, #4
    v.splat      v20, s28
    s.addi       s28, s32, #256
    s.movz       s29, #5
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s33, #8512
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v26
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a5, s31
    v.extract    s27, v0, #5
    v.splat      v19, s27
    s.addi       s27, s32, #320
    s.movz       s31, #6
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #8576
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v26
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a5, s29
    v.extract    s28, v0, #6
    v.splat      v20, s28
    s.addi       s28, s32, #384
    s.movz       s29, #7
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s33, #8640
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v26
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a5, s31
    v.extract    s27, v0, #7
    v.splat      v19, s27
    s.addi       s27, s32, #448
    s.movz       s31, #8
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #8704
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v26
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a5, s29
    v.extract    s28, v0, #8
    v.splat      v20, s28
    s.addi       s28, s32, #512
    s.movz       s29, #9
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s33, #8768
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v26
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a5, s31
    v.extract    s27, v0, #9
    v.splat      v19, s27
    s.addi       s27, s32, #576
    s.movz       s31, #10
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #8832
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v26
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a5, s29
    v.extract    s28, v0, #10
    v.splat      v20, s28
    s.addi       s28, s32, #640
    s.movz       s29, #11
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s33, #8896
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v26
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a5, s31
    v.extract    s27, v0, #11
    v.splat      v19, s27
    s.addi       s27, s32, #704
    s.movz       s31, #12
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #8960
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v26
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a5, s29
    v.extract    s28, v0, #12
    v.splat      v20, s28
    s.addi       s28, s32, #768
    s.movz       s29, #13
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s33, #9024
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v26
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a5, s31
    v.extract    s27, v0, #13
    v.splat      v19, s27
    s.addi       s27, s32, #832
    s.movz       s31, #14
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #9088
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v26
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a5, s29
    v.extract    s28, v0, #14
    v.splat      v20, s28
    s.addi       s28, s32, #896
    s.movz       s29, #15
    s.addi       s35, s32, #960
    v.ld.w       v21, [s30, #0]
    s.addi       s30, s33, #9152
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v26
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a5, s31
    v.extract    s27, v0, #15
    v.splat      v19, s27
    s.movz       s27, #0
    s.addi       s31, s33, #9216
    v.ld.w       v21, [s34, #0]
    v.extract    s32, v0, #0
    v.splat      v22, s32
    s.addi       s32, s33, #17408
    vf.mul       v23, v21, v20
    vf.mul       v20, v23, v26
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a5, s29
    s.movz       s28, #1
    s.addi       s29, s33, #9280
    v.ld.w       v20, [s30, #0]
    v.extract    s30, v0, #1
    v.splat      v21, s30
    s.addi       s30, s32, #64
    vf.mul       v23, v20, v19
    vf.mul       v19, v23, v26
    vf.add       v20, v17, v19
    v.st.w       [s35, #0], v20
    fence.acq_rel.device
    a.vread      v17, a6, s27
    s.movz       s27, #2
    s.addi       s34, s33, #9344
    v.ld.w       v19, [s31, #0]
    v.extract    s31, v0, #2
    v.splat      v20, s31
    s.addi       s31, s32, #128
    vf.mul       v23, v19, v22
    vf.mul       v19, v23, v35
    vf.add       v22, v17, v19
    v.st.w       [s32, #0], v22
    a.vread      v17, a6, s28
    s.movz       s28, #3
    v.ld.w       v19, [s29, #0]
    s.addi       s29, s33, #9408
    vf.mul       v22, v19, v21
    vf.mul       v19, v22, v35
    vf.add       v21, v17, v19
    v.st.w       [s30, #0], v21
    a.vread      v17, a6, s27
    v.extract    s27, v0, #3
    v.splat      v19, s27
    s.addi       s27, s32, #192
    s.movz       s30, #4
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #9472
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v35
    vf.add       v21, v17, v20
    v.st.w       [s31, #0], v21
    a.vread      v17, a6, s28
    v.extract    s28, v0, #4
    v.splat      v20, s28
    s.addi       s28, s32, #256
    s.movz       s31, #5
    v.ld.w       v21, [s29, #0]
    s.addi       s29, s33, #9536
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v35
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a6, s30
    v.extract    s27, v0, #5
    v.splat      v19, s27
    s.addi       s27, s32, #320
    s.movz       s30, #6
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #9600
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v35
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a6, s31
    v.extract    s28, v0, #6
    v.splat      v20, s28
    s.addi       s28, s32, #384
    s.movz       s31, #7
    v.ld.w       v21, [s29, #0]
    s.addi       s29, s33, #9664
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v35
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a6, s30
    v.extract    s27, v0, #7
    v.splat      v19, s27
    s.addi       s27, s32, #448
    s.movz       s30, #8
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #9728
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v35
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a6, s31
    v.extract    s28, v0, #8
    v.splat      v20, s28
    s.addi       s28, s32, #512
    s.movz       s31, #9
    v.ld.w       v21, [s29, #0]
    s.addi       s29, s33, #9792
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v35
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a6, s30
    v.extract    s27, v0, #9
    v.splat      v19, s27
    s.addi       s27, s32, #576
    s.movz       s30, #10
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #9856
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v35
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a6, s31
    v.extract    s28, v0, #10
    v.splat      v20, s28
    s.addi       s28, s32, #640
    s.movz       s31, #11
    v.ld.w       v21, [s29, #0]
    s.addi       s29, s33, #9920
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v35
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a6, s30
    v.extract    s27, v0, #11
    v.splat      v19, s27
    s.addi       s27, s32, #704
    s.movz       s30, #12
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #9984
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v35
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a6, s31
    v.extract    s28, v0, #12
    v.splat      v20, s28
    s.addi       s28, s32, #768
    s.movz       s31, #13
    v.ld.w       v21, [s29, #0]
    s.addi       s29, s33, #10048
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v35
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a6, s30
    v.extract    s27, v0, #13
    v.splat      v19, s27
    s.addi       s27, s32, #832
    s.movz       s30, #14
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #10112
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v35
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a6, s31
    v.extract    s28, v0, #14
    v.splat      v20, s28
    s.addi       s28, s32, #896
    s.movz       s31, #15
    s.addi       s35, s32, #960
    v.ld.w       v21, [s29, #0]
    s.addi       s29, s33, #10176
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v35
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a6, s30
    v.extract    s27, v0, #15
    v.splat      v19, s27
    s.movz       s27, #0
    s.addi       s30, s33, #10240
    v.ld.w       v21, [s34, #0]
    v.extract    s32, v0, #0
    v.splat      v22, s32
    s.addi       s32, s33, #18432
    vf.mul       v23, v21, v20
    vf.mul       v20, v23, v35
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a6, s31
    s.movz       s28, #1
    s.addi       s31, s33, #10304
    v.ld.w       v20, [s29, #0]
    v.extract    s29, v0, #1
    v.splat      v21, s29
    s.addi       s29, s32, #64
    vf.mul       v23, v20, v19
    vf.mul       v19, v23, v35
    vf.add       v20, v17, v19
    v.st.w       [s35, #0], v20
    fence.acq_rel.device
    a.vread      v17, a7, s27
    s.movz       s27, #2
    s.addi       s34, s33, #10368
    v.ld.w       v19, [s30, #0]
    v.extract    s30, v0, #2
    v.splat      v20, s30
    s.addi       s30, s32, #128
    vf.mul       v23, v19, v22
    vf.mul       v19, v23, v37
    vf.add       v22, v17, v19
    v.st.w       [s32, #0], v22
    a.vread      v17, a7, s28
    s.movz       s28, #3
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s33, #10432
    vf.mul       v22, v19, v21
    vf.mul       v19, v22, v37
    vf.add       v21, v17, v19
    v.st.w       [s29, #0], v21
    a.vread      v17, a7, s27
    v.extract    s27, v0, #3
    v.splat      v19, s27
    s.addi       s27, s32, #192
    s.movz       s29, #4
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #10496
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v37
    vf.add       v21, v17, v20
    v.st.w       [s30, #0], v21
    a.vread      v17, a7, s28
    v.extract    s28, v0, #4
    v.splat      v20, s28
    s.addi       s28, s32, #256
    s.movz       s30, #5
    v.ld.w       v21, [s31, #0]
    s.addi       s31, s33, #10560
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v37
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a7, s29
    v.extract    s27, v0, #5
    v.splat      v19, s27
    s.addi       s27, s32, #320
    s.movz       s29, #6
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #10624
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v37
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a7, s30
    v.extract    s28, v0, #6
    v.splat      v20, s28
    s.addi       s28, s32, #384
    s.movz       s30, #7
    v.ld.w       v21, [s31, #0]
    s.addi       s31, s33, #10688
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v37
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a7, s29
    v.extract    s27, v0, #7
    v.splat      v19, s27
    s.addi       s27, s32, #448
    s.movz       s29, #8
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #10752
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v37
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a7, s30
    v.extract    s28, v0, #8
    v.splat      v20, s28
    s.addi       s28, s32, #512
    s.movz       s30, #9
    v.ld.w       v21, [s31, #0]
    s.addi       s31, s33, #10816
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v37
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a7, s29
    v.extract    s27, v0, #9
    v.splat      v19, s27
    s.addi       s27, s32, #576
    s.movz       s29, #10
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #10880
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v37
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a7, s30
    v.extract    s28, v0, #10
    v.splat      v20, s28
    s.addi       s28, s32, #640
    s.movz       s30, #11
    v.ld.w       v21, [s31, #0]
    s.addi       s31, s33, #10944
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v37
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a7, s29
    v.extract    s27, v0, #11
    v.splat      v19, s27
    s.addi       s27, s32, #704
    s.movz       s29, #12
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #11008
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v37
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a7, s30
    v.extract    s28, v0, #12
    v.splat      v20, s28
    s.addi       s28, s32, #768
    s.movz       s30, #13
    v.ld.w       v21, [s31, #0]
    s.addi       s31, s33, #11072
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v37
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a7, s29
    v.extract    s27, v0, #13
    v.splat      v19, s27
    s.addi       s27, s32, #832
    s.movz       s29, #14
    v.ld.w       v21, [s34, #0]
    s.addi       s34, s33, #11136
    vf.mul       v22, v21, v20
    vf.mul       v20, v22, v37
    vf.add       v21, v17, v20
    v.st.w       [s28, #0], v21
    a.vread      v17, a7, s30
    v.extract    s28, v0, #14
    v.splat      v20, s28
    s.addi       s28, s32, #896
    s.movz       s30, #15
    s.addi       s35, s32, #960
    v.ld.w       v21, [s31, #0]
    s.addi       s31, s33, #11200
    vf.mul       v22, v21, v19
    vf.mul       v19, v22, v37
    vf.add       v21, v17, v19
    v.st.w       [s27, #0], v21
    a.vread      v17, a7, s29
    v.extract    s27, v0, #15
    v.splat      v0, s27
    s.addi       s27, s22, #128
    s.addi       s29, s23, #128
    s.addi       s32, s27, #0
    s.addi       s27, s29, #0
    v.ld.w       v19, [s34, #0]
    s.addi       s29, s33, #11264
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v37
    vf.add       v20, v17, v19
    v.st.w       [s28, #0], v20
    a.vread      v17, a7, s30
    s.movz       s28, #0
    s.addi       s30, s33, #11328
    v.ld.w       v19, [s31, #0]
    s.movz       s31, #1
    vf.mul       v20, v19, v0
    vf.mul       v0, v20, v37
    vf.add       v19, v17, v0
    v.st.w       [s35, #0], v19
    fence.acq_rel.device
    s.mov        s22, s32
    s.mov        s23, s27
    s.addi       s27, s33, #11392
    s.movz       s32, #2
    s.addi       s34, s33, #11456
    s.movz       s35, #3
    s.addi       s36, s33, #11520
    v.ld.w       v0, [s29, #0]
    s.movz       s29, #4
    a.vwrite     a0, s28, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s28, s33, #11584
    s.movz       s30, #5
    a.vwrite     a0, s31, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #11648
    s.movz       s31, #6
    a.vwrite     a0, s32, v0
    v.ld.w       v0, [s34, #0]
    s.addi       s32, s33, #11712
    s.movz       s34, #7
    a.vwrite     a0, s35, v0
    v.ld.w       v0, [s36, #0]
    s.addi       s35, s33, #11776
    s.movz       s36, #8
    a.vwrite     a0, s29, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #11840
    s.movz       s29, #9
    a.vwrite     a0, s30, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #11904
    s.movz       s30, #10
    a.vwrite     a0, s31, v0
    v.ld.w       v0, [s32, #0]
    s.addi       s31, s33, #11968
    s.movz       s32, #11
    a.vwrite     a0, s34, v0
    v.ld.w       v0, [s35, #0]
    s.addi       s34, s33, #12032
    s.movz       s35, #12
    a.vwrite     a0, s36, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #12096
    s.movz       s36, #13
    a.vwrite     a0, s29, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #12160
    s.movz       s29, #14
    a.vwrite     a0, s30, v0
    v.ld.w       v0, [s31, #0]
    s.addi       s30, s33, #12224
    s.movz       s31, #15
    a.vwrite     a0, s32, v0
    v.ld.w       v0, [s34, #0]
    s.addi       s32, s33, #12288
    s.movz       s34, #0
    a.vwrite     a0, s35, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #12352
    s.movz       s35, #1
    a.vwrite     a0, s36, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #12416
    s.movz       s36, #2
    a.vwrite     a0, s29, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s29, s33, #12480
    s.movz       s30, #3
    a.vwrite     a0, s31, v0
    v.ld.w       v0, [s32, #0]
    s.addi       s31, s33, #12544
    s.movz       s32, #4
    a.vwrite     a1, s34, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #12608
    s.movz       s34, #5
    a.vwrite     a1, s35, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #12672
    s.movz       s35, #6
    a.vwrite     a1, s36, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #12736
    s.movz       s36, #7
    a.vwrite     a1, s30, v0
    v.ld.w       v0, [s31, #0]
    s.addi       s30, s33, #12800
    s.movz       s31, #8
    a.vwrite     a1, s32, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #12864
    s.movz       s32, #9
    a.vwrite     a1, s34, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #12928
    s.movz       s34, #10
    a.vwrite     a1, s35, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #12992
    s.movz       s35, #11
    a.vwrite     a1, s36, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #13056
    s.movz       s36, #12
    a.vwrite     a1, s31, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #13120
    s.movz       s31, #13
    a.vwrite     a1, s32, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #13184
    s.movz       s32, #14
    a.vwrite     a1, s34, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #13248
    s.movz       s34, #15
    a.vwrite     a1, s35, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #13312
    s.movz       s35, #0
    a.vwrite     a1, s36, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #13376
    s.movz       s36, #1
    a.vwrite     a1, s31, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #13440
    s.movz       s31, #2
    a.vwrite     a1, s32, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #13504
    s.movz       s32, #3
    a.vwrite     a1, s34, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #13568
    s.movz       s34, #4
    a.vwrite     a2, s35, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #13632
    s.movz       s35, #5
    a.vwrite     a2, s36, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #13696
    s.movz       s36, #6
    a.vwrite     a2, s31, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #13760
    s.movz       s31, #7
    a.vwrite     a2, s32, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #13824
    s.movz       s32, #8
    a.vwrite     a2, s34, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #13888
    s.movz       s34, #9
    a.vwrite     a2, s35, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #13952
    s.movz       s35, #10
    a.vwrite     a2, s36, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #14016
    s.movz       s36, #11
    a.vwrite     a2, s31, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #14080
    s.movz       s31, #12
    a.vwrite     a2, s32, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #14144
    s.movz       s32, #13
    a.vwrite     a2, s34, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #14208
    s.movz       s34, #14
    a.vwrite     a2, s35, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #14272
    s.movz       s35, #15
    a.vwrite     a2, s36, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #14336
    s.movz       s36, #0
    a.vwrite     a2, s31, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #14400
    s.movz       s31, #1
    a.vwrite     a2, s32, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #14464
    s.movz       s32, #2
    a.vwrite     a2, s34, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #14528
    s.movz       s34, #3
    a.vwrite     a2, s35, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #14592
    s.movz       s35, #4
    a.vwrite     a3, s36, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #14656
    s.movz       s36, #5
    a.vwrite     a3, s31, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #14720
    s.movz       s31, #6
    a.vwrite     a3, s32, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #14784
    s.movz       s32, #7
    a.vwrite     a3, s34, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #14848
    s.movz       s34, #8
    a.vwrite     a3, s35, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #14912
    s.movz       s35, #9
    a.vwrite     a3, s36, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #14976
    s.movz       s36, #10
    a.vwrite     a3, s31, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #15040
    s.movz       s31, #11
    a.vwrite     a3, s32, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #15104
    s.movz       s32, #12
    a.vwrite     a3, s34, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #15168
    s.movz       s34, #13
    a.vwrite     a3, s35, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #15232
    s.movz       s35, #14
    a.vwrite     a3, s36, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #15296
    s.movz       s36, #15
    a.vwrite     a3, s31, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #15360
    s.movz       s31, #0
    a.vwrite     a3, s32, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #15424
    s.movz       s32, #1
    a.vwrite     a3, s34, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #15488
    s.movz       s34, #2
    a.vwrite     a3, s35, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #15552
    s.movz       s35, #3
    a.vwrite     a3, s36, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #15616
    s.movz       s36, #4
    a.vwrite     a4, s31, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #15680
    s.movz       s31, #5
    a.vwrite     a4, s32, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #15744
    s.movz       s32, #6
    a.vwrite     a4, s34, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #15808
    s.movz       s34, #7
    a.vwrite     a4, s35, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #15872
    s.movz       s35, #8
    a.vwrite     a4, s36, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #15936
    s.movz       s36, #9
    a.vwrite     a4, s31, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #16000
    s.movz       s31, #10
    a.vwrite     a4, s32, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #16064
    s.movz       s32, #11
    a.vwrite     a4, s34, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #16128
    s.movz       s34, #12
    a.vwrite     a4, s35, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #16192
    s.movz       s35, #13
    a.vwrite     a4, s36, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #16256
    s.movz       s36, #14
    a.vwrite     a4, s31, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #16320
    s.movz       s31, #15
    a.vwrite     a4, s32, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #16384
    s.movz       s32, #0
    a.vwrite     a4, s34, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #16448
    s.movz       s34, #1
    a.vwrite     a4, s35, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #16512
    s.movz       s35, #2
    a.vwrite     a4, s36, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #16576
    s.movz       s36, #3
    a.vwrite     a4, s31, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #16640
    s.movz       s31, #4
    a.vwrite     a5, s32, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #16704
    s.movz       s32, #5
    a.vwrite     a5, s34, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #16768
    s.movz       s34, #6
    a.vwrite     a5, s35, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #16832
    s.movz       s35, #7
    a.vwrite     a5, s36, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #16896
    s.movz       s36, #8
    a.vwrite     a5, s31, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #16960
    s.movz       s31, #9
    a.vwrite     a5, s32, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #17024
    s.movz       s32, #10
    a.vwrite     a5, s34, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #17088
    s.movz       s34, #11
    a.vwrite     a5, s35, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #17152
    s.movz       s35, #12
    a.vwrite     a5, s36, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #17216
    s.movz       s36, #13
    a.vwrite     a5, s31, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #17280
    s.movz       s31, #14
    a.vwrite     a5, s32, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #17344
    s.movz       s32, #15
    a.vwrite     a5, s34, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #17408
    s.movz       s34, #0
    a.vwrite     a5, s35, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #17472
    s.movz       s35, #1
    a.vwrite     a5, s36, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #17536
    s.movz       s36, #2
    a.vwrite     a5, s31, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #17600
    s.movz       s31, #3
    a.vwrite     a5, s32, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #17664
    s.movz       s32, #4
    a.vwrite     a6, s34, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #17728
    s.movz       s34, #5
    a.vwrite     a6, s35, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #17792
    s.movz       s35, #6
    a.vwrite     a6, s36, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #17856
    s.movz       s36, #7
    a.vwrite     a6, s31, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #17920
    s.movz       s31, #8
    a.vwrite     a6, s32, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #17984
    s.movz       s32, #9
    a.vwrite     a6, s34, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #18048
    s.movz       s34, #10
    a.vwrite     a6, s35, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #18112
    s.movz       s35, #11
    a.vwrite     a6, s36, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #18176
    s.movz       s36, #12
    a.vwrite     a6, s31, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #18240
    s.movz       s31, #13
    a.vwrite     a6, s32, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #18304
    s.movz       s32, #14
    a.vwrite     a6, s34, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #18368
    s.movz       s34, #15
    a.vwrite     a6, s35, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #18432
    s.movz       s35, #0
    a.vwrite     a6, s36, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #18496
    s.movz       s36, #1
    a.vwrite     a6, s31, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #18560
    s.movz       s31, #2
    a.vwrite     a6, s32, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #18624
    s.movz       s32, #3
    a.vwrite     a6, s34, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #18688
    s.movz       s34, #4
    a.vwrite     a7, s35, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #18752
    s.movz       s35, #5
    a.vwrite     a7, s36, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #18816
    s.movz       s36, #6
    a.vwrite     a7, s31, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #18880
    s.movz       s31, #7
    a.vwrite     a7, s32, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #18944
    s.movz       s32, #8
    s.add        s37, s20, s19
    a.vwrite     a7, s34, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #19008
    s.movz       s34, #9
    a.vwrite     a7, s35, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #19072
    s.movz       s35, #10
    a.vwrite     a7, s36, v0
    v.ld.w       v0, [s29, #0]
    s.addi       s29, s33, #19136
    s.movz       s36, #11
    a.vwrite     a7, s31, v0
    v.ld.w       v0, [s30, #0]
    s.addi       s30, s33, #19200
    s.movz       s31, #12
    a.vwrite     a7, s32, v0
    v.ld.w       v0, [s28, #0]
    s.addi       s28, s33, #19264
    s.movz       s32, #13
    a.vwrite     a7, s34, v0
    v.ld.w       v0, [s27, #0]
    s.addi       s27, s33, #19328
    s.movz       s34, #14
    s.addi       s38, s33, #19392
    a.vwrite     a7, s35, v0
    v.ld.w       v0, [s29, #0]
    s.movz       s29, #15
    s.movz       s33, #1
    a.vwrite     a7, s36, v0
    v.ld.w       v0, [s30, #0]
    a.vwrite     a7, s31, v0
    v.ld.w       v0, [s28, #0]
    a.vwrite     a7, s32, v0
    v.ld.w       v0, [s27, #0]
    a.vwrite     a7, s34, v0
    v.ld.w       v0, [s38, #0]
    a.vwrite     a7, s29, v0
    s.mov        s20, s37
    br.nz        s33, for_2
endfor_3:
    s.addi       s1, s10, #16
    s.addi       s2, s10, #32
    s.addi       s5, s10, #48
    s.addi       s6, s10, #64
    s.addi       s7, s10, #80
    s.addi       s9, s10, #96
    s.addi       s11, s10, #112
    s.muli       s12, s10, #2                    // a runtime tile origin, x2
    s.add        s13, s3, s12                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s12, s1, #2                     // a runtime tile origin, x2
    s.add        s14, s3, s12                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s12, s2, #2                     // a runtime tile origin, x2
    s.add        s15, s3, s12                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s12, s5, #2                     // a runtime tile origin, x2
    s.add        s16, s3, s12                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s12, s6, #2                     // a runtime tile origin, x2
    s.add        s17, s3, s12                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s12, s7, #2                     // a runtime tile origin, x2
    s.add        s18, s3, s12                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s12, s9, #2                     // a runtime tile origin, x2
    s.add        s19, s3, s12                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s12, s11, #2                    // a runtime tile origin, x2
    s.add        s20, s3, s12                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s3, s10, #2                     // a runtime tile origin, x2
    s.add        s12, s4, s3                     // the tile origin
    s.muli       s3, s8, #512                    // a runtime tile origin, x512
    s.add        s22, s12, s3                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    a.vread      v0, a0, s3
    s.movz       s3, #0
    s.add        s12, s3, s8                     // the tile origin
    v.splat      v1, s12
    s.movz       s3, #7
    v.splat      v2, s3
    v.cmp.lt     p1, v1, v2
    s.movz       s3, #0
    s.add        s23, s3, s10                    // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v3, s23
    v.add        v4, v1, v3
    s.movz       s3, #256
    v.splat      v3, s3
    v.cmp.lt     p2, v4, v3
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s22, #0], v0
    s.movz       s10, #1
    a.vread      v0, a0, s10
    s.addi       s10, s12, #1
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #512                  // row 1
    s.addi       s23, s12, #1
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #2
    a.vread      v0, a0, s10
    s.addi       s10, s12, #2
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #1024                 // row 2
    s.addi       s23, s12, #2
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #3
    a.vread      v0, a0, s10
    s.addi       s10, s12, #3
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #1536                 // row 3
    s.addi       s23, s12, #3
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #4
    a.vread      v0, a0, s10
    s.addi       s10, s12, #4
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #2048                 // row 4
    s.addi       s23, s12, #4
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #5
    a.vread      v0, a0, s10
    s.addi       s10, s12, #5
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #2560                 // row 5
    s.addi       s23, s12, #5
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #6
    a.vread      v0, a0, s10
    s.addi       s10, s12, #6
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #3072                 // row 6
    s.addi       s23, s12, #6
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #7
    a.vread      v0, a0, s10
    s.addi       s10, s12, #7
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #3584                 // row 7
    s.addi       s23, s12, #7
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #8
    a.vread      v0, a0, s10
    s.addi       s10, s12, #8
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #4096                 // row 8
    s.addi       s23, s12, #8
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #9
    a.vread      v0, a0, s10
    s.addi       s10, s12, #9
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #4608                 // row 9
    s.addi       s23, s12, #9
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #10
    a.vread      v0, a0, s10
    s.addi       s10, s12, #10
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #5120                 // row 10
    s.addi       s23, s12, #10
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #11
    a.vread      v0, a0, s10
    s.addi       s10, s12, #11
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #5632                 // row 11
    s.addi       s23, s12, #11
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #12
    a.vread      v0, a0, s10
    s.addi       s10, s12, #12
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #6144                 // row 12
    s.addi       s23, s12, #12
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #13
    a.vread      v0, a0, s10
    s.addi       s10, s12, #13
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #6656                 // row 13
    s.addi       s23, s12, #13
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #14
    a.vread      v0, a0, s10
    s.addi       s10, s12, #14
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #7168                 // row 14
    s.addi       s23, s12, #14
    v.splat      v3, s23
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s10, #15
    a.vread      v0, a0, s10
    s.addi       s10, s12, #15
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s10, s22, #7680                 // row 15
    s.addi       s13, s12, #15
    v.splat      v3, s13
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.muli       s10, s1, #2                     // a runtime tile origin, x2
    s.add        s13, s4, s10                    // the tile origin
    s.muli       s10, s8, #512                   // a runtime tile origin, x512
    s.add        s22, s13, s10                   // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s10, #0
    a.vread      v0, a1, s10
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    s.movz       s10, #0
    s.add        s13, s10, s1                    // the tile origin
    v.splat      v3, s13
    v.add        v4, v1, v3
    v.splat      v3, s3
    v.cmp.lt     p2, v4, v3
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s22, #0], v0
    s.movz       s1, #1
    a.vread      v0, a1, s1
    s.addi       s1, s12, #1
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #512                   // row 1
    s.addi       s10, s12, #1
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #2
    a.vread      v0, a1, s1
    s.addi       s1, s12, #2
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #1024                  // row 2
    s.addi       s10, s12, #2
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #3
    a.vread      v0, a1, s1
    s.addi       s1, s12, #3
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #1536                  // row 3
    s.addi       s10, s12, #3
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #4
    a.vread      v0, a1, s1
    s.addi       s1, s12, #4
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #2048                  // row 4
    s.addi       s10, s12, #4
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #5
    a.vread      v0, a1, s1
    s.addi       s1, s12, #5
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #2560                  // row 5
    s.addi       s10, s12, #5
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #6
    a.vread      v0, a1, s1
    s.addi       s1, s12, #6
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #3072                  // row 6
    s.addi       s10, s12, #6
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #7
    a.vread      v0, a1, s1
    s.addi       s1, s12, #7
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #3584                  // row 7
    s.addi       s10, s12, #7
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #8
    a.vread      v0, a1, s1
    s.addi       s1, s12, #8
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #4096                  // row 8
    s.addi       s10, s12, #8
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #9
    a.vread      v0, a1, s1
    s.addi       s1, s12, #9
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #4608                  // row 9
    s.addi       s10, s12, #9
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #10
    a.vread      v0, a1, s1
    s.addi       s1, s12, #10
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #5120                  // row 10
    s.addi       s10, s12, #10
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #11
    a.vread      v0, a1, s1
    s.addi       s1, s12, #11
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #5632                  // row 11
    s.addi       s10, s12, #11
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #12
    a.vread      v0, a1, s1
    s.addi       s1, s12, #12
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #6144                  // row 12
    s.addi       s10, s12, #12
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #13
    a.vread      v0, a1, s1
    s.addi       s1, s12, #13
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #6656                  // row 13
    s.addi       s10, s12, #13
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #14
    a.vread      v0, a1, s1
    s.addi       s1, s12, #14
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #7168                  // row 14
    s.addi       s10, s12, #14
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #15
    a.vread      v0, a1, s1
    s.addi       s1, s12, #15
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s22, #7680                  // row 15
    s.addi       s10, s12, #15
    v.splat      v3, s10
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.muli       s1, s2, #2                      // a runtime tile origin, x2
    s.add        s10, s4, s1                     // the tile origin
    s.muli       s1, s8, #512                    // a runtime tile origin, x512
    s.add        s13, s10, s1                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v0, a2, s1
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    s.movz       s1, #0
    s.add        s10, s1, s2                     // the tile origin
    v.splat      v3, s10
    v.add        v4, v1, v3
    v.splat      v3, s3
    v.cmp.lt     p2, v4, v3
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s13, #0], v0
    s.movz       s1, #1
    a.vread      v0, a2, s1
    s.addi       s1, s12, #1
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #512                   // row 1
    s.addi       s2, s12, #1
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #2
    a.vread      v0, a2, s1
    s.addi       s1, s12, #2
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #1024                  // row 2
    s.addi       s2, s12, #2
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #3
    a.vread      v0, a2, s1
    s.addi       s1, s12, #3
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #1536                  // row 3
    s.addi       s2, s12, #3
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #4
    a.vread      v0, a2, s1
    s.addi       s1, s12, #4
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #2048                  // row 4
    s.addi       s2, s12, #4
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #5
    a.vread      v0, a2, s1
    s.addi       s1, s12, #5
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #2560                  // row 5
    s.addi       s2, s12, #5
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #6
    a.vread      v0, a2, s1
    s.addi       s1, s12, #6
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #3072                  // row 6
    s.addi       s2, s12, #6
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #7
    a.vread      v0, a2, s1
    s.addi       s1, s12, #7
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #3584                  // row 7
    s.addi       s2, s12, #7
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #8
    a.vread      v0, a2, s1
    s.addi       s1, s12, #8
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #4096                  // row 8
    s.addi       s2, s12, #8
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #9
    a.vread      v0, a2, s1
    s.addi       s1, s12, #9
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #4608                  // row 9
    s.addi       s2, s12, #9
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #10
    a.vread      v0, a2, s1
    s.addi       s1, s12, #10
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #5120                  // row 10
    s.addi       s2, s12, #10
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #11
    a.vread      v0, a2, s1
    s.addi       s1, s12, #11
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #5632                  // row 11
    s.addi       s2, s12, #11
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #12
    a.vread      v0, a2, s1
    s.addi       s1, s12, #12
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #6144                  // row 12
    s.addi       s2, s12, #12
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #13
    a.vread      v0, a2, s1
    s.addi       s1, s12, #13
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #6656                  // row 13
    s.addi       s2, s12, #13
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #14
    a.vread      v0, a2, s1
    s.addi       s1, s12, #14
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #7168                  // row 14
    s.addi       s2, s12, #14
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #15
    a.vread      v0, a2, s1
    s.addi       s1, s12, #15
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s13, #7680                  // row 15
    s.addi       s2, s12, #15
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.muli       s1, s5, #2                      // a runtime tile origin, x2
    s.add        s2, s4, s1                      // the tile origin
    s.muli       s1, s8, #512                    // a runtime tile origin, x512
    s.add        s10, s2, s1                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v0, a3, s1
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    s.movz       s1, #0
    s.add        s2, s1, s5                      // the tile origin
    v.splat      v3, s2
    v.add        v4, v1, v3
    v.splat      v3, s3
    v.cmp.lt     p2, v4, v3
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s10, #0], v0
    s.movz       s1, #1
    a.vread      v0, a3, s1
    s.addi       s1, s12, #1
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #512                   // row 1
    s.addi       s2, s12, #1
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #2
    a.vread      v0, a3, s1
    s.addi       s1, s12, #2
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #1024                  // row 2
    s.addi       s2, s12, #2
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #3
    a.vread      v0, a3, s1
    s.addi       s1, s12, #3
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #1536                  // row 3
    s.addi       s2, s12, #3
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #4
    a.vread      v0, a3, s1
    s.addi       s1, s12, #4
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #2048                  // row 4
    s.addi       s2, s12, #4
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #5
    a.vread      v0, a3, s1
    s.addi       s1, s12, #5
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #2560                  // row 5
    s.addi       s2, s12, #5
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #6
    a.vread      v0, a3, s1
    s.addi       s1, s12, #6
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #3072                  // row 6
    s.addi       s2, s12, #6
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #7
    a.vread      v0, a3, s1
    s.addi       s1, s12, #7
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #3584                  // row 7
    s.addi       s2, s12, #7
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #8
    a.vread      v0, a3, s1
    s.addi       s1, s12, #8
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #4096                  // row 8
    s.addi       s2, s12, #8
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #9
    a.vread      v0, a3, s1
    s.addi       s1, s12, #9
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #4608                  // row 9
    s.addi       s2, s12, #9
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #10
    a.vread      v0, a3, s1
    s.addi       s1, s12, #10
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #5120                  // row 10
    s.addi       s2, s12, #10
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #11
    a.vread      v0, a3, s1
    s.addi       s1, s12, #11
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #5632                  // row 11
    s.addi       s2, s12, #11
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #12
    a.vread      v0, a3, s1
    s.addi       s1, s12, #12
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #6144                  // row 12
    s.addi       s2, s12, #12
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #13
    a.vread      v0, a3, s1
    s.addi       s1, s12, #13
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #6656                  // row 13
    s.addi       s2, s12, #13
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #14
    a.vread      v0, a3, s1
    s.addi       s1, s12, #14
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #7168                  // row 14
    s.addi       s2, s12, #14
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #15
    a.vread      v0, a3, s1
    s.addi       s1, s12, #15
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s16, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s10, #7680                  // row 15
    s.addi       s2, s12, #15
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.muli       s1, s6, #2                      // a runtime tile origin, x2
    s.add        s2, s4, s1                      // the tile origin
    s.muli       s1, s8, #512                    // a runtime tile origin, x512
    s.add        s5, s2, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v0, a4, s1
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    s.movz       s1, #0
    s.add        s2, s1, s6                      // the tile origin
    v.splat      v3, s2
    v.add        v4, v1, v3
    v.splat      v3, s3
    v.cmp.lt     p2, v4, v3
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s5, #0], v0
    s.movz       s1, #1
    a.vread      v0, a4, s1
    s.addi       s1, s12, #1
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #512                    // row 1
    s.addi       s2, s12, #1
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #2
    a.vread      v0, a4, s1
    s.addi       s1, s12, #2
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #1024                   // row 2
    s.addi       s2, s12, #2
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #3
    a.vread      v0, a4, s1
    s.addi       s1, s12, #3
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #1536                   // row 3
    s.addi       s2, s12, #3
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #4
    a.vread      v0, a4, s1
    s.addi       s1, s12, #4
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #2048                   // row 4
    s.addi       s2, s12, #4
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #5
    a.vread      v0, a4, s1
    s.addi       s1, s12, #5
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #2560                   // row 5
    s.addi       s2, s12, #5
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #6
    a.vread      v0, a4, s1
    s.addi       s1, s12, #6
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #3072                   // row 6
    s.addi       s2, s12, #6
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #7
    a.vread      v0, a4, s1
    s.addi       s1, s12, #7
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #3584                   // row 7
    s.addi       s2, s12, #7
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #8
    a.vread      v0, a4, s1
    s.addi       s1, s12, #8
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #4096                   // row 8
    s.addi       s2, s12, #8
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #9
    a.vread      v0, a4, s1
    s.addi       s1, s12, #9
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #4608                   // row 9
    s.addi       s2, s12, #9
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #10
    a.vread      v0, a4, s1
    s.addi       s1, s12, #10
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #5120                   // row 10
    s.addi       s2, s12, #10
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #11
    a.vread      v0, a4, s1
    s.addi       s1, s12, #11
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #5632                   // row 11
    s.addi       s2, s12, #11
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #12
    a.vread      v0, a4, s1
    s.addi       s1, s12, #12
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #6144                   // row 12
    s.addi       s2, s12, #12
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #13
    a.vread      v0, a4, s1
    s.addi       s1, s12, #13
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #6656                   // row 13
    s.addi       s2, s12, #13
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #14
    a.vread      v0, a4, s1
    s.addi       s1, s12, #14
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #7168                   // row 14
    s.addi       s2, s12, #14
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #15
    a.vread      v0, a4, s1
    s.addi       s1, s12, #15
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s17, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #7680                   // row 15
    s.addi       s2, s12, #15
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.muli       s1, s7, #2                      // a runtime tile origin, x2
    s.add        s2, s4, s1                      // the tile origin
    s.muli       s1, s8, #512                    // a runtime tile origin, x512
    s.add        s5, s2, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v0, a5, s1
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    s.movz       s1, #0
    s.add        s2, s1, s7                      // the tile origin
    v.splat      v3, s2
    v.add        v4, v1, v3
    v.splat      v3, s3
    v.cmp.lt     p2, v4, v3
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s5, #0], v0
    s.movz       s1, #1
    a.vread      v0, a5, s1
    s.addi       s1, s12, #1
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #512                    // row 1
    s.addi       s2, s12, #1
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #2
    a.vread      v0, a5, s1
    s.addi       s1, s12, #2
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #1024                   // row 2
    s.addi       s2, s12, #2
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #3
    a.vread      v0, a5, s1
    s.addi       s1, s12, #3
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #1536                   // row 3
    s.addi       s2, s12, #3
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #4
    a.vread      v0, a5, s1
    s.addi       s1, s12, #4
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #2048                   // row 4
    s.addi       s2, s12, #4
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #5
    a.vread      v0, a5, s1
    s.addi       s1, s12, #5
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #2560                   // row 5
    s.addi       s2, s12, #5
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #6
    a.vread      v0, a5, s1
    s.addi       s1, s12, #6
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #3072                   // row 6
    s.addi       s2, s12, #6
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #7
    a.vread      v0, a5, s1
    s.addi       s1, s12, #7
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #3584                   // row 7
    s.addi       s2, s12, #7
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #8
    a.vread      v0, a5, s1
    s.addi       s1, s12, #8
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #4096                   // row 8
    s.addi       s2, s12, #8
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #9
    a.vread      v0, a5, s1
    s.addi       s1, s12, #9
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #4608                   // row 9
    s.addi       s2, s12, #9
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #10
    a.vread      v0, a5, s1
    s.addi       s1, s12, #10
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #5120                   // row 10
    s.addi       s2, s12, #10
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #11
    a.vread      v0, a5, s1
    s.addi       s1, s12, #11
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #5632                   // row 11
    s.addi       s2, s12, #11
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #12
    a.vread      v0, a5, s1
    s.addi       s1, s12, #12
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #6144                   // row 12
    s.addi       s2, s12, #12
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #13
    a.vread      v0, a5, s1
    s.addi       s1, s12, #13
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #6656                   // row 13
    s.addi       s2, s12, #13
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #14
    a.vread      v0, a5, s1
    s.addi       s1, s12, #14
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #7168                   // row 14
    s.addi       s2, s12, #14
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #15
    a.vread      v0, a5, s1
    s.addi       s1, s12, #15
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s18, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #7680                   // row 15
    s.addi       s2, s12, #15
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.muli       s1, s9, #2                      // a runtime tile origin, x2
    s.add        s2, s4, s1                      // the tile origin
    s.muli       s1, s8, #512                    // a runtime tile origin, x512
    s.add        s5, s2, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v0, a6, s1
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    s.movz       s1, #0
    s.add        s2, s1, s9                      // the tile origin
    v.splat      v3, s2
    v.add        v4, v1, v3
    v.splat      v3, s3
    v.cmp.lt     p2, v4, v3
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s5, #0], v0
    s.movz       s1, #1
    a.vread      v0, a6, s1
    s.addi       s1, s12, #1
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #512                    // row 1
    s.addi       s2, s12, #1
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #2
    a.vread      v0, a6, s1
    s.addi       s1, s12, #2
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #1024                   // row 2
    s.addi       s2, s12, #2
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #3
    a.vread      v0, a6, s1
    s.addi       s1, s12, #3
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #1536                   // row 3
    s.addi       s2, s12, #3
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #4
    a.vread      v0, a6, s1
    s.addi       s1, s12, #4
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #2048                   // row 4
    s.addi       s2, s12, #4
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #5
    a.vread      v0, a6, s1
    s.addi       s1, s12, #5
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #2560                   // row 5
    s.addi       s2, s12, #5
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #6
    a.vread      v0, a6, s1
    s.addi       s1, s12, #6
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #3072                   // row 6
    s.addi       s2, s12, #6
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #7
    a.vread      v0, a6, s1
    s.addi       s1, s12, #7
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #3584                   // row 7
    s.addi       s2, s12, #7
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #8
    a.vread      v0, a6, s1
    s.addi       s1, s12, #8
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #4096                   // row 8
    s.addi       s2, s12, #8
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #9
    a.vread      v0, a6, s1
    s.addi       s1, s12, #9
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #4608                   // row 9
    s.addi       s2, s12, #9
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #10
    a.vread      v0, a6, s1
    s.addi       s1, s12, #10
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #5120                   // row 10
    s.addi       s2, s12, #10
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #11
    a.vread      v0, a6, s1
    s.addi       s1, s12, #11
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #5632                   // row 11
    s.addi       s2, s12, #11
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #12
    a.vread      v0, a6, s1
    s.addi       s1, s12, #12
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #6144                   // row 12
    s.addi       s2, s12, #12
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #13
    a.vread      v0, a6, s1
    s.addi       s1, s12, #13
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #6656                   // row 13
    s.addi       s2, s12, #13
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #14
    a.vread      v0, a6, s1
    s.addi       s1, s12, #14
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #7168                   // row 14
    s.addi       s2, s12, #14
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #15
    a.vread      v0, a6, s1
    s.addi       s1, s12, #15
    v.splat      v3, s1
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s19, #0]
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v0, v4
    vf.cvt.f32.bf16 v0, v3
    s.addi       s1, s5, #7680                   // row 15
    s.addi       s2, s12, #15
    v.splat      v3, s2
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.muli       s1, s11, #2                     // a runtime tile origin, x2
    s.add        s2, s4, s1                      // the tile origin
    s.muli       s1, s8, #512                    // a runtime tile origin, x512
    s.add        s4, s2, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v0, a7, s1
    v.splat      v3, s12
    v.cmp.lt     p1, v3, v2
    s.movz       s1, #0
    s.add        s2, s1, s11                     // the tile origin
    v.splat      v3, s2
    v.add        v4, v1, v3
    v.splat      v1, s3
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    v.splat      v1, s12
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s4, #0], v0
    s.movz       s1, #1
    a.vread      v0, a7, s1
    s.addi       s1, s12, #1
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #512                    // row 1
    s.addi       s2, s12, #1
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #2
    a.vread      v0, a7, s1
    s.addi       s1, s12, #2
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #1024                   // row 2
    s.addi       s2, s12, #2
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #3
    a.vread      v0, a7, s1
    s.addi       s1, s12, #3
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #1536                   // row 3
    s.addi       s2, s12, #3
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #4
    a.vread      v0, a7, s1
    s.addi       s1, s12, #4
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #2048                   // row 4
    s.addi       s2, s12, #4
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #5
    a.vread      v0, a7, s1
    s.addi       s1, s12, #5
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #2560                   // row 5
    s.addi       s2, s12, #5
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #6
    a.vread      v0, a7, s1
    s.addi       s1, s12, #6
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #3072                   // row 6
    s.addi       s2, s12, #6
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #7
    a.vread      v0, a7, s1
    s.addi       s1, s12, #7
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #3584                   // row 7
    s.addi       s2, s12, #7
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #8
    a.vread      v0, a7, s1
    s.addi       s1, s12, #8
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #4096                   // row 8
    s.addi       s2, s12, #8
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #9
    a.vread      v0, a7, s1
    s.addi       s1, s12, #9
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #4608                   // row 9
    s.addi       s2, s12, #9
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #10
    a.vread      v0, a7, s1
    s.addi       s1, s12, #10
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #5120                   // row 10
    s.addi       s2, s12, #10
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #11
    a.vread      v0, a7, s1
    s.addi       s1, s12, #11
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #5632                   // row 11
    s.addi       s2, s12, #11
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #12
    a.vread      v0, a7, s1
    s.addi       s1, s12, #12
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #6144                   // row 12
    s.addi       s2, s12, #12
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #13
    a.vread      v0, a7, s1
    s.addi       s1, s12, #13
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #6656                   // row 13
    s.addi       s2, s12, #13
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #14
    a.vread      v0, a7, s1
    s.addi       s1, s12, #14
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #7168                   // row 14
    s.addi       s2, s12, #14
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    s.movz       s1, #15
    a.vread      v0, a7, s1
    s.addi       s1, s12, #15
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    vf.cvt.bf16.f32 v3, v1
    vf.add       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s4, #7680                   // row 15
    s.addi       s2, s12, #15
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
    exit
    exit
