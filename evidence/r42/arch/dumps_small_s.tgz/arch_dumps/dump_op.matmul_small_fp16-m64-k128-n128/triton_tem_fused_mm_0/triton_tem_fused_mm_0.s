    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s5, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s6, #512
    s.mul        s7, s1, s6
    s.add        s1, s5, s7                      // this context's own scratch
    s.addi       s5, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.st.d       [s5, #0], s2
    .li       s1, #2147483647
    s.st.d       [s5, #8], s1
    s.st.d       [s5, #16], s1
    s.movz       s2, #256
    s.st.d       [s5, #48], s2
    s.movz       s6, #2
    s.st.d       [s5, #56], s6
    .li       s7, #68719476752
    s.st.d       [s5, #88], s7
    .li       s8, #8589934592
    s.st.d       [s5, #104], s8
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s5, arg_base
    s.ld.d       s9, [s5, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s5, role_id
    s.movz       s10, #512
    s.mul        s11, s5, s10
    s.add        s5, s9, s11                     // this context's own scratch
    s.addi       s9, s5, #256                    // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.st.d       [s9, #0], s3
    s.st.d       [s9, #8], s1
    s.st.d       [s9, #16], s1
    s.st.d       [s9, #48], s2
    s.st.d       [s9, #56], s6
    s.st.d       [s9, #88], s7
    s.st.d       [s9, #104], s8
    fence.release.device
    td.load      d1, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #8
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s2
    s.sub        s5, s2, s3
    s.movz       s3, #4
    s.movz       s6, #1
    s.rdspecial  s7, role_id
    s.rdspecial  s8, npid.x
__rctx_program:
    s.cmp.lt     s9, s7, s2
    s.addi       s10, s2, #0
    s.sub        s11, s2, s9
    s.addi       s9, s2, #0
    s.xor        s12, s7, s11
    s.xor        s13, s11, s5
    s.sub        s14, s12, s11
    s.lshri      s15, s14, #3
    s.mov        s10, s14
    s.xor        s16, s15, s13
    s.sub        s15, s16, s13
    s.sub        s13, s3, s15
    s.min.s      s16, s13, s6
    s.cmp.lt     s13, s16, s2
    s.sub        s17, s2, s13
    s.xor        s13, s16, s17
    s.sub        s16, s13, s17
    s.cmp.eq     s13, s16, s6
    br.nz        s13, sdiv_done_1
    s.movz       s18, #0
    s.movz       s19, #31
    s.mov        s10, s18
    s.addi       s20, s19, #0
sdiv_2:
    s.lshr       s19, s14, s20
    s.shli       s21, s9, #1
    s.andi       s22, s19, #1
    s.shl        s19, s6, s20
    s.or         s23, s21, s22
    s.cmp.geu    s21, s23, s16
    s.sub        s22, s18, s21
    s.and        s21, s16, s22
    s.and        s24, s19, s22
    s.sub        s9, s23, s21
    s.or         s10, s10, s24
    s.subi       s20, s20, #1
    s.cmp.ge     s19, s20, s18
    br.nz        s19, sdiv_2
sdiv_done_1:
    s.sub        s10, s12, s11
    s.xor        s12, s9, s11
    s.lshri      s9, s10, #3
    s.sub        s14, s12, s11
    s.muli       s12, s9, #8
    s.addi       s9, s2, #0
    s.add        s18, s15, s14
    s.addi       s14, s2, #0
    s.sub        s15, s10, s12
    s.xor        s10, s15, s11
    s.sub        s12, s10, s11
    s.cmp.lt     s10, s12, s2
    s.sub        s11, s2, s10
    s.xor        s10, s12, s11
    s.sub        s12, s10, s11
    s.mov        s9, s12
    br.nz        s13, sdiv_done_3
    s.movz       s10, #0
    s.movz       s13, #31
    s.mov        s9, s10
    s.addi       s15, s13, #0
    s.movz       s13, #1
sdiv_4:
    s.lshr       s19, s12, s15
    s.shli       s20, s14, #1
    s.andi       s21, s19, #1
    s.shl        s19, s13, s15
    s.or         s22, s20, s21
    s.cmp.geu    s20, s22, s16
    s.sub        s21, s10, s20
    s.and        s20, s16, s21
    s.and        s23, s19, s21
    s.sub        s14, s22, s20
    s.or         s9, s9, s23
    s.subi       s15, s15, #1
    s.cmp.ge     s19, s15, s10
    br.nz        s19, sdiv_4
sdiv_done_3:
    s.xor        s10, s11, s17
    s.movz       s11, #16
    s.xor        s12, s9, s10
    s.mul        s9, s18, s11
    s.sub        s13, s12, s10
    s.movz       s10, #0
    s.mul        s12, s13, s11
    s.addi       s13, s10, #0
    s.andi       s14, s9, #63
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.andi       s15, s12, #127
for_5:
    s.cmp.ge     s16, s13, s1
    br.nz        s16, endfor_6
    s.mul        s16, s13, s11
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s17, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s18, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s19, s16                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s18, s17
    w.def        w1, #48, #8                     // v48..v55
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s18, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s19, s15                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s18, s17
    mb.wait      s17
gemm_pipe:
    mb.arm       s16, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s18, #1
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v56, v48, s16
    s.add        s13, s13, s6
    s.cmp.ge     s18, s13, s1
    br.nz        s18, gemm_pipe_drain0
    s.mul        s18, s13, s11
    w.def        w2, #40, #8                     // v40..v47
    mb.arm       s19, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s20, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s20, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s21, s18                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w2, d0, s20, s19
    w.def        w3, #32, #8                     // v32..v39
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s20, s18                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s21, s15                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w3, d1, s20, s19
    mb.wait      s19
    mb.wait      s16
    mb.arm       s18, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v40, v32, s18
    s.add        s13, s13, s6
    s.cmp.ge     s20, s13, s1
    br.nz        s20, gemm_pipe_drain1
    s.mul        s20, s13, s11
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s21, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s22, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s23, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s20                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s23, s21
    w.def        w1, #48, #8                     // v48..v55
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s23, s20                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s15                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s23, s21
    mb.wait      s21
    mb.wait      s18
    br.nz        s22, gemm_pipe
gemm_pipe_drain0:
    s.movz       s11, #1
    mb.wait      s16
    br.nz        s11, endfor_6
gemm_pipe_drain1:
    mb.wait      s18
endfor_6:
    s.add        s11, s10, s12                   // the tile origin
    s.muli       s13, s12, #2                    // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s11
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    a.vread      v2, a0, s10
    s.add        s11, s10, s9                    // the tile origin
    s.movz       s10, #64
    s.movz       s12, #128
    s.muli       s14, s9, #256                   // a runtime tile origin, x256
    v.splat      v3, s11
    v.splat      v4, s10
    v.add        v5, v0, v1
    v.splat      v0, s12
    vf.cvt.f32.f16 v1, v2
    s.add        s9, s4, s13                     // the tile origin
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s10, s9, s14                    // the tile origin
    p.and        p3, p1, p2
    s.movz       s9, #1
    @p3 v.st.h       [s10, #0], v1
    a.vread      v0, a0, s9
    s.addi       s9, s11, #1
    s.addi       s12, s10, #256                  // row 1
    v.splat      v1, s9
    vf.cvt.f32.f16 v2, v0
    s.movz       s9, #2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s13, s11, #2
    s.addi       s14, s10, #512                  // row 2
    v.splat      v0, s13
    s.movz       s13, #3
    s.addi       s15, s11, #3
    @p3 v.st.h       [s12, #0], v2
    a.vread      v1, a0, s9
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    v.splat      v1, s15
    s.addi       s9, s10, #768                   // row 3
    s.movz       s12, #4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    s.addi       s15, s11, #4
    s.addi       s20, s10, #1024                 // row 4
    v.splat      v1, s15
    s.movz       s15, #5
    @p3 v.st.h       [s14, #0], v0
    a.vread      v0, a0, s13
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s13, s11, #5
    s.addi       s14, s10, #1280                 // row 5
    v.splat      v0, s13
    s.movz       s13, #6
    s.addi       s22, s11, #6
    v.splat      v2, s22
    s.addi       s22, s10, #1536                 // row 6
    @p4 v.st.h       [s9, #0], v1
    a.vread      v1, a0, s12
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.movz       s9, #7
    s.addi       s12, s11, #7
    v.splat      v1, s12
    s.addi       s12, s10, #1792                 // row 7
    @p3 v.st.h       [s20, #0], v0
    a.vread      v0, a0, s15
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.movz       s15, #8
    s.addi       s20, s11, #8
    v.splat      v0, s20
    s.addi       s20, s10, #2048                 // row 8
    @p4 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s13
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.movz       s13, #9
    s.addi       s14, s11, #9
    v.splat      v2, s14
    s.addi       s14, s10, #2304                 // row 9
    @p3 v.st.h       [s22, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.movz       s9, #10
    s.addi       s22, s11, #10
    v.splat      v1, s22
    s.addi       s22, s10, #2560                 // row 10
    @p4 v.st.h       [s12, #0], v0
    a.vread      v0, a0, s15
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.movz       s12, #11
    s.addi       s15, s11, #11
    v.splat      v0, s15
    s.addi       s15, s10, #2816                 // row 11
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a0, s13
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.movz       s13, #12
    s.addi       s20, s11, #12
    v.splat      v2, s20
    s.addi       s20, s10, #3072                 // row 12
    @p4 v.st.h       [s14, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.movz       s9, #13
    s.addi       s14, s11, #13
    v.splat      v1, s14
    s.addi       s14, s10, #3328                 // row 13
    @p3 v.st.h       [s22, #0], v0
    a.vread      v0, a0, s12
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.movz       s12, #14
    s.addi       s22, s11, #14
    s.addi       s23, s11, #15
    v.splat      v0, s22
    s.addi       s11, s10, #3584                 // row 14
    v.splat      v3, s23
    s.movz       s22, #15
    s.addi       s23, s10, #3840                 // row 15
    @p4 v.st.h       [s15, #0], v2
    a.vread      v2, a0, s13
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    @p3 v.st.h       [s20, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s14, #0], v0
    a.vread      v0, a0, s12
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v0
    @p3 v.st.h       [s11, #0], v1
    a.vread      v0, a0, s22
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s23, #0], v1
__rctx_next:
    s.addi       s9, s7, #2                      // the next program of this context: + 2
    s.cmp.lt     s10, s9, s8
    s.mov        s7, s9
    br.nz        s10, __rctx_program
    exit
