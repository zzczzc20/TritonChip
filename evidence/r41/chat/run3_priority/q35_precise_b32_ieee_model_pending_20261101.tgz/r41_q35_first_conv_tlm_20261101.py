#!/usr/bin/env python3
"""Isolated real first-layer causal convolution on the same CPU inputs."""
import json,sys,time
from pathlib import Path
import torch
from torch import nn
from safetensors.torch import load_file,save_file
h=Path.home();tree=h/'r41_q35_multiturn_diag_20261031';sys.path[:0]=[str(tree/'tools/models'),str(tree),str(tree/'python'),str(tree/'compiler/python'),str(tree/'tools/asm')]
import chat
from transformers.models.qwen3_5.modeling_qwen3_5 import causal_conv1d_fn
class Conv(nn.Module):
 def __init__(self,layer):
  super().__init__();self.weight=nn.Parameter(layer.conv1d.weight.detach().squeeze(1).clone());self.bias=nn.Parameter(layer.conv1d.bias.detach().clone()) if layer.conv1d.bias is not None else None;self.activation=layer.activation
 def forward(self,x):return causal_conv1d_fn(x,self.weight,self.bias,activation=self.activation)
chat.L.use_tnca(str(tree));args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1']);start=time.monotonic();app=chat.ChatApplication(args)
p=load_file(str(h/'r41_q35_first_delta_cpu_20261031_diag/states.safetensors'));x=p['linear_attn.in_proj_qkv'].transpose(1,2).contiguous();expected=p['conv_output'];stage=Conv(app.model.model.language_model.layers[0].linear_attn).eval()
with torch.no_grad():check=stage(x)
if not torch.equal(check,expected):raise ValueError('CPU reconstruction differs')
stage,dev=chat.L.place(stage,'tnca','eager')
with torch.no_grad():got=stage(x.to(dev)).detach().cpu().contiguous().clone()
if got.shape!=expected.shape or got.dtype!=expected.dtype:raise ValueError('shape or dtype mismatch')
d=(got.float()-expected.float()).abs();r={'schema':'r41-q35-first-conv-tlm/1','scope':'isolated DP TLM convolution, precision casts, b32 and IEEE division; not full graph or board','elements':got.numel(),'bit_mismatches':int((got.view(torch.int16)!=expected.view(torch.int16)).sum()),'max_abs':float(d.max()),'relative_l2':float(d.norm()/expected.float().norm().clamp_min(1e-30)),'seconds':time.monotonic()-start}
out=h/'r41_q35_first_conv_tlm_20261101_diag';out.mkdir(exist_ok=False);save_file({'x':x,'expected':expected.clone(),'got':got},str(out/'states.safetensors'));(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
