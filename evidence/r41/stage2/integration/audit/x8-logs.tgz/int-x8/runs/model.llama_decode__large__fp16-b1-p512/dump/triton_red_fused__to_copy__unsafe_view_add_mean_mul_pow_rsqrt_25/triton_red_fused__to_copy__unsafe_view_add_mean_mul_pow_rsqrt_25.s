    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // out_ptr1: device_ptr64 at arg_base+40
    v.iota       v0                              // arange(0, VLEN)
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s1, s8, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s9, #0
    s.st.d       [s1, #0], s2
    s.movz       s9, #2048
    s.st.d       [s1, #8], s9
    s.movz       s9, #2
    s.st.d       [s1, #48], s9
    s.movz       s9, #16
    s.st.d       [s1, #88], s9
    .li       s9, #4294967296
    s.st.d       [s1, #104], s9
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s8, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 1)
    s.movz       s9, #0
    s.st.d       [s1, #0], s3
    s.movz       s9, #2048
    s.st.d       [s1, #8], s9
    s.movz       s9, #2
    s.st.d       [s1, #48], s9
    s.movz       s9, #16
    s.st.d       [s1, #88], s9
    .li       s9, #4294967296
    s.st.d       [s1, #104], s9
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s8, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 1)
    s.movz       s9, #0
    s.st.d       [s1, #0], s4
    s.movz       s9, #2048
    s.st.d       [s1, #8], s9
    s.movz       s9, #2
    s.st.d       [s1, #48], s9
    s.movz       s9, #16
    s.st.d       [s1, #88], s9
    .li       s9, #4294967296
    s.st.d       [s1, #104], s9
    td.load      d2, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s8, #768                    // TensorMap 3: tl.make_tensor_descriptor (rank 1)
    s.movz       s8, #0
    s.st.d       [s1, #0], s5
    s.movz       s8, #2048
    s.st.d       [s1, #8], s8
    s.movz       s8, #2
    s.st.d       [s1, #48], s8
    s.movz       s8, #16
    s.st.d       [s1, #88], s8
    .li       s8, #4294967296
    s.st.d       [s1, #104], s8
    td.load      d3, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s8, #2048
    s.movz       s9, #16
    s.addi       s10, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s11, s10, s8
    br.nz        s11, endfor_2
    s.muli       s11, s10, #2
    v.splat      v1, s10
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s12, #2048
    s.muli       s13, s10, #2
    v.splat      v4, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s14, #2048
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s12
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s14
    v.cmp.ge     p1, v6, v1
    v.cmp.lt     p2, v6, v3
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    s.muli       s12, s10, #2
    v.splat      v1, s10
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s14, #2048
    s.add        s15, s2, s11
    p.and        p5, p1, p2
    s.add        s11, s3, s13
    p.and        p1, p3, p4
    v.add        v4, v1, v3
    v.movi       v1, #0
    v.splat      v3, s14
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v5, [s15, #0]
    v.cmp.ge     p2, v4, v1
    v.cmp.lt     p3, v4, v3
    s.muli       s13, s10, #2
    v.splat      v1, s10
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s11, #0]
    s.add        s11, s4, s12
    p.and        p1, p2, p3
    v.add        v6, v1, v3
    vf.cvt.f16.f32 v1, v5
    s.add        s12, s5, s13
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s11, #0]
    vf.cvt.f16.f32 v5, v4
    v.splat      v4, s10
    v.movi       v7, #0
    v.add        v8, v4, v0
    v.cmp.ge     p1, v6, v7
    vf.cvt.f16.f32 v4, v3
    v.movi       v3, #2048
    s.movz       s11, #2048
    v.cmp.lt     p2, v8, v3
    v.splat      v3, s11
    vf.add       v7, v1, v5
    v.cmp.lt     p3, v6, v3
    p.and        p4, p1, p3
    v.movi       v1, #0
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v3, [s12, #0]
    vf.add       v5, v7, v4
    s.add        s11, s10, s9
    s.movz       s12, #1
    vf.cvt.f16.f32 v4, v3
    vf.add       v3, v5, v4
    vf.mul       v4, v3, v3
    vf.add       v3, v2, v4
    @p2 v.sel        v4, v3, v2
    v.mov        v1, v4
    v.mov        v2, v1
    s.mov        s10, s11
    br.nz        s12, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    s.addi       s10, s1, #0
    vf.add       v3, v1, v2
for_3:
    s.cmp.ge     s1, s10, s8
    br.nz        s1, endfor_4
    s.muli       s1, s10, #2
    v.splat      v1, s10
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s11, #2048
    s.muli       s12, s10, #2
    v.splat      v4, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s13, #2048
    v.add        v6, v1, v2
    v.movi       v1, #0
    v.splat      v2, s11
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s13
    v.cmp.ge     p1, v6, v1
    v.cmp.lt     p2, v6, v2
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    s.muli       s11, s10, #2
    v.splat      v1, s10
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s13, #2048
    s.add        s14, s2, s1
    p.and        p5, p1, p2
    s.add        s1, s3, s12
    p.and        p1, p3, p4
    v.add        v4, v1, v2
    v.movi       v1, #0
    v.splat      v2, s13
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v5, [s14, #0]
    v.cmp.ge     p2, v4, v1
    v.cmp.lt     p3, v4, v2
    s.muli       s12, s10, #2
    v.splat      v1, s10
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s1, #0]
    s.add        s1, s4, s11
    p.and        p1, p2, p3
    v.add        v6, v1, v2
    vf.cvt.f16.f32 v1, v5
    s.add        s11, s5, s12
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s1, #0]
    vf.cvt.f16.f32 v5, v4
    v.splat      v4, s10
    v.movi       v7, #0
    v.add        v8, v4, v0
    v.cmp.ge     p1, v6, v7
    vf.cvt.f16.f32 v4, v2
    v.movi       v2, #2048
    s.movz       s1, #2048
    v.cmp.lt     p2, v8, v2
    .li       s12, #1157627904
    v.splat      v2, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s12, #1065353216
    v.splat      v7, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v8, v2                          // ISA 8.8: <= 2**-22 relative
    .li       s12, #925353388
    v.splat      v9, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v10, s1
    vf.add       v11, v1, v5
    v.cmp.lt     p3, v6, v10
    p.and        p4, p1, p3
    .li       s1, #1077936128
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s11, #0]
    s.shli       s1, s10, #1                     // element offset -> bytes (x2)
    vf.add       v10, v11, v4
    s.add        s11, s6, s1                     // &in_ptr4[...]
    s.add        s12, s7, s1                     // &out_ptr1[...]
    s.add        s1, s10, s9
    vf.cvt.f16.f32 v4, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v6, [s11, #0]
    s.movz       s11, #1
    vf.add       v11, v10, v4
    vf.cvt.f16.f32 v4, v6
    vf.fms       v6, v2, v8, v7
    vf.fms       v2, v8, v6, v8
    vf.neg       v6, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v2, v6, v8
    vf.mul       v6, v3, v2                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v2, v6, v9
    v.rsqrt.approx v6, v2                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v7, v6, v6
    vf.mul       v8, v6, v5
    vf.fms       v5, v2, v7, v1
    vf.mul       v1, v8, v5                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v2, v1, v6
    v.extract    s13, v2, #0
    v.splat      v1, s13
    vf.mul       v2, v11, v1
    vf.mul       v1, v2, v4
    vf.cvt.f32.f16 v2, v1
    @p2 v.st.h       [s12, #0], v2
    s.mov        s10, s1
    br.nz        s11, for_3
endfor_4:
    exit
    exit
