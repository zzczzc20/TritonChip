    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #1024
    s.rdspecial  s4, arg_base
    s.mul        s5, s2, s1
    s.movz       s1, #0
    s.movz       s2, #128
    s.movz       s6, #32
    s.movz       s7, #64
    s.movz       s8, #1
    s.rdspecial  s8, role_id
    s.rdspecial  s9, npid.x
    s.ld.d       s10, [s4, #0]                   // in_ptr0: device_ptr64 at arg_base+0
    s.add        s11, s3, s5                     // this context's own scratch
    s.ld.d       s3, [s4, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s4, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s11, [s4, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s12, [s4, #32]                  // out_ptr1: device_ptr64 at arg_base+32
__rctx_program:
    s.mul        s4, s8, s2
    s.addi       s13, s1, #0
    s.muli       s14, s8, #256
    s.muli       s15, s13, #2
    v.splat      v0, s8
    v.movi       v1, #0
    v.splat      v2, s7
    s.add        s16, s13, s4
    v.movi       v3, #0
    v.movi       v4, #0
    v.movi       v5, #0
    s.add        s17, s3, s14
    s.shli       s14, s16, #1                    // element offset -> bytes (x2)
    v.cmp.ge     p1, v0, v1
    v.cmp.lt     p2, v0, v2
    v.mov        v4, v3
    v.mov        v5, v3
    p.and        p3, p1, p2
    s.add        s16, s10, s14                   // &in_ptr0[...]
    s.add        s14, s17, s15
for_1:
    v.ld.h       v0, [s16, #0]
    v.ld.h       v1, [s16, #32]
    vf.cvt.f16.f32 v2, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s14, #0]
    vf.cvt.f16.f32 v6, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s14, #32]
    vf.cvt.f16.f32 v7, v0
    vf.add       v0, v2, v7
    vf.add       v4, v4, v0
    vf.cvt.f16.f32 v0, v1
    vf.add       v1, v6, v0
    vf.add       v5, v5, v1
    s.addi       s16, s16, #64                   // the next iteration's address
    s.addi       s14, s14, #64                   // the next iteration's address
    s.add        s13, s13, s6
    s.cmp.lt     s15, s13, s2
    br.nz        s15, for_1
endfor_2:
    .li       s13, #1124073472
    v.splat      v0, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s13, #1065353216
    v.splat      v1, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.add.b v2, v4
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.reduce.add.b v6, v5
    v.movi       v5, #0
    s.addi       s13, s1, #0
    vf.add       v7, v2, v6
    s.muli       s14, s13, #2
    v.splat      v2, s8
    v.movi       v6, #0
    v.splat      v8, s7
    vf.add       v9, v7, v5
    s.add        s15, s13, s4
    v.movi       v7, #0
    v.movi       v10, #0
    s.shli       s4, s15, #1                     // element offset -> bytes (x2)
    v.cmp.ge     p1, v2, v6
    v.cmp.lt     p2, v2, v8
    v.mov        v7, v3
    v.mov        v10, v3
    p.and        p3, p1, p2
    s.add        s15, s10, s4                    // &in_ptr0[...]
    s.add        s4, s17, s14
    vf.fms       v2, v0, v4, v1
    vf.fms       v3, v4, v2, v4
    vf.neg       v2, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v3, v2, v4
    vf.mul       v2, v9, v3                      // a/y as a refined reciprocal (ISA has no divide)
    v.extract    s14, v2, #0
    v.splat      v2, s14
for_3:
    v.ld.h       v3, [s15, #0]
    v.ld.h       v4, [s15, #32]
    vf.cvt.f16.f32 v6, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s4, #0]
    vf.cvt.f16.f32 v8, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s4, #32]
    vf.cvt.f16.f32 v9, v3
    vf.add       v3, v6, v9
    vf.sub       v6, v3, v2
    vf.cvt.f16.f32 v3, v4
    vf.mul       v4, v6, v6
    vf.add       v6, v8, v3
    vf.add       v7, v7, v4
    vf.sub       v3, v6, v2
    vf.mul       v4, v3, v3
    vf.add       v10, v10, v4
    s.addi       s15, s15, #64                   // the next iteration's address
    s.addi       s4, s4, #64                     // the next iteration's address
    s.add        s13, s13, s6
    s.cmp.lt     s16, s13, s2
    br.nz        s16, for_3
endfor_4:
    v.rcp.approx v2, v0                          // ISA 8.8: <= 2**-22 relative
    vf.reduce.add.b v3, v7
    vf.reduce.add.b v4, v10
    .li       s4, #925353388
    v.splat      v6, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #1077936128
    v.splat      v7, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v8, v3, v4
    .li       s4, #3204448256
    v.splat      v3, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s4, s8, s2
    s.addi       s13, s1, #0
    s.muli       s15, s8, #256
    vf.add       v4, v8, v5
    s.movz       s16, #64
    s.muli       s17, s13, #2
    v.splat      v5, s8
    v.movi       v8, #0
    s.add        s18, s13, s4
    s.add        s19, s13, s4
    s.add        s4, s3, s15
    s.shli       s15, s18, #1                    // element offset -> bytes (x2)
    s.shli       s18, s13, #1                    // element offset -> bytes (x2)
    s.shli       s20, s13, #1                    // element offset -> bytes (x2)
    s.shli       s21, s19, #1                    // element offset -> bytes (x2)
    v.cmp.ge     p1, v5, v8
    v.splat      v8, s16
    s.movz       s16, #1
    s.add        s16, s10, s15                   // &in_ptr0[...]
    v.cmp.lt     p2, v5, v8
    p.and        p3, p1, p2
    vf.fms       v5, v0, v2, v1
    v.splat      v0, s14
    s.add        s14, s4, s17
    s.add        s4, s5, s18                     // &in_ptr2[...]
    s.add        s15, s11, s20                   // &in_ptr3[...]
    vf.fms       v1, v2, v5, v2
    s.add        s17, s12, s21                   // &out_ptr1[...]
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v1, v5, v2
    vf.mul       v2, v4, v1                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v1, v2, v6
    v.rsqrt.approx v2, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v2, v2
    vf.mul       v5, v2, v3
    vf.fms       v3, v1, v4, v7
    vf.mul       v1, v5, v3                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v3, v1, v2
    v.extract    s18, v3, #0
    v.splat      v1, s18
for_5:
    v.ld.h       v2, [s16, #0]
    v.ld.h       v3, [s16, #32]
    vf.cvt.f16.f32 v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s14, #0]
    vf.cvt.f16.f32 v5, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s14, #32]
    vf.cvt.f16.f32 v6, v2
    vf.add       v2, v4, v6
    vf.sub       v4, v2, v0
    vf.cvt.f16.f32 v2, v3
    v.ld.h       v3, [s4, #0]
    vf.mul       v6, v4, v1
    vf.add       v4, v5, v2
    vf.sub       v2, v4, v0
    v.ld.h       v4, [s4, #32]
    vf.cvt.f16.f32 v5, v3
    vf.mul       v3, v2, v1
    vf.mul       v2, v6, v5
    v.ld.h       v5, [s15, #0]
    vf.cvt.f16.f32 v6, v4
    vf.mul       v4, v3, v6
    v.ld.h       v3, [s15, #32]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v2, v6
    vf.cvt.f32.f16 v2, v5
    vf.cvt.f16.f32 v5, v3
    v.st.h       [s17, #0], v2
    vf.add       v2, v4, v5
    vf.cvt.f32.f16 v3, v2
    v.st.h       [s17, #32], v3
    s.addi       s16, s16, #64                   // the next iteration's address
    s.addi       s14, s14, #64                   // the next iteration's address
    s.addi       s4, s4, #64                     // the next iteration's address
    s.addi       s15, s15, #64                   // the next iteration's address
    s.addi       s17, s17, #64                   // the next iteration's address
    s.add        s13, s13, s6
    s.cmp.lt     s18, s13, s2
    br.nz        s18, for_5
endfor_6:
__rctx_next:
    s.addi       s4, s8, #2                      // the next program of this context: + 2
    s.cmp.lt     s13, s4, s9
    s.mov        s8, s4
    br.nz        s13, __rctx_program
    exit
