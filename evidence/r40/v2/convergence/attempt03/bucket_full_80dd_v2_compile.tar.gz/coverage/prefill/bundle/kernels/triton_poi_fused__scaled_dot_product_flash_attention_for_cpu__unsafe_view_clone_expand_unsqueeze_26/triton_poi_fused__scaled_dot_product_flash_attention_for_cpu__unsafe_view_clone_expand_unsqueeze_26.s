    s.rdspecial  s1, role_id
    s.rdspecial  s2, npid.x
__rctx_program:
    s.rdspecial  s3, arg_base
    s.ld.d       s4, [s3, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s5, [s3, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.rdspecial  s3, pid.y
    s.shli       s6, s3, #4                      // x16 as a shift
    s.shli       s3, s1, #4                      // x16 as a shift
    s.rdspecial  s7, arg_base
    s.ld.d       s8, [s7, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s7, role_id
    s.movz       s9, #2048
    s.mul        s10, s7, s9
    s.add        s7, s8, s10                     // this context's own scratch
    s.addi       s8, s7, #0
    s.movz       s9, #0
    v.splat      v0, s9
    s.add        s10, s9, s6                     // the tile origin
    v.splat      v1, s10
    s.movz       s11, #64
    v.splat      v2, s11
    v.movi       v3, #0
    v.cmp.lt     p1, v1, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v1
    @p1 v.sel        v5, v4, v1
    v.sub        v1, v3, v2
    @p2 v.sel        v4, v1, v2
    v.movi       v1, #63
    v.and        v4, v5, v1
    v.sub        v1, v3, v4
    @p1 v.sel        v3, v1, v4
    s.muli       s12, s3, #64                    // a runtime tile origin, x64
    s.add        s13, s9, s12                    // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v4, s11
    v.mul        v5, v1, v4
    v.splat      v1, s13
    v.add        v4, v5, v1
    v.add        v1, v3, v4
    v.splat      v3, s10
    v.movi       v5, #0
    v.cmp.lt     p1, v3, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v3
    @p1 v.sel        v7, v6, v3
    v.sub        v3, v5, v2
    @p2 v.sel        v6, v3, v2
    v.movi       v3, #6
    v.lshr       v6, v7, v3
    v.sub        v3, v5, v6
    @p1 v.sel        v5, v3, v6
    s.movz       s9, #4
    v.splat      v3, s9
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v3
    @p2 v.sel        v7, v5, v3
    v.movi       v5, #2
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    s.movz       s9, #32768
    v.splat      v5, s9
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s8, #0], v1
    s.addi       s9, s8, #64
    s.addi       s11, s10, #1
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #1
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #128
    s.addi       s11, s10, #2
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #2
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #192
    s.addi       s11, s10, #3
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #3
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #256
    s.addi       s11, s10, #4
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #4
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #320
    s.addi       s11, s10, #5
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #5
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #384
    s.addi       s11, s10, #6
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #6
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #448
    s.addi       s11, s10, #7
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #7
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #512
    s.addi       s11, s10, #8
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #8
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #576
    s.addi       s11, s10, #9
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #9
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #640
    s.addi       s11, s10, #10
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #10
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #704
    s.addi       s11, s10, #11
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #11
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #768
    s.addi       s11, s10, #12
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #12
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #832
    s.addi       s11, s10, #13
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #13
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #896
    s.addi       s11, s10, #14
    v.splat      v1, s11
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s11, s10, #14
    v.splat      v6, s11
    v.movi       v7, #0
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v2, v7
    v.sub        v8, v7, v6
    @p1 v.sel        v9, v8, v6
    v.sub        v6, v7, v2
    @p2 v.sel        v8, v6, v2
    v.movi       v6, #6
    v.lshr       v8, v9, v6
    v.sub        v6, v7, v8
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v3, v6
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v8, v7
    v.sub        v7, v6, v3
    @p2 v.sel        v8, v7, v3
    v.movi       v7, #2
    v.lshr       v8, v9, v7
    v.sub        v7, v6, v8
    @p1 v.sel        v6, v7, v8
    v.mul        v7, v6, v5
    v.add        v6, v1, v7
    v.add        v1, v0, v6
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #960
    s.addi       s8, s10, #15
    v.splat      v1, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v1, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v1
    @p1 v.sel        v8, v7, v1
    v.sub        v1, v6, v2
    @p2 v.sel        v7, v1, v2
    v.movi       v1, #63
    v.and        v7, v8, v1
    v.sub        v1, v6, v7
    @p1 v.sel        v6, v1, v7
    v.add        v1, v6, v4
    s.addi       s8, s10, #15
    v.splat      v4, s8
    v.movi       v6, #0
    v.cmp.lt     p1, v4, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v4
    @p1 v.sel        v8, v7, v4
    v.sub        v4, v6, v2
    @p2 v.sel        v7, v4, v2
    v.movi       v2, #6
    v.lshr       v4, v8, v2
    v.sub        v2, v6, v4
    @p1 v.sel        v6, v2, v4
    v.movi       v2, #0
    v.cmp.lt     p1, v6, v2
    v.cmp.lt     p2, v3, v2
    v.sub        v4, v2, v6
    @p1 v.sel        v7, v4, v6
    v.sub        v4, v2, v3
    @p2 v.sel        v6, v4, v3
    v.movi       v3, #2
    v.lshr       v4, v7, v3
    v.sub        v3, v2, v4
    @p1 v.sel        v2, v3, v4
    v.mul        v3, v2, v5
    v.add        v2, v1, v3
    v.add        v1, v0, v2
    v.st.w       [s9, #0], v1
    fence.acq_rel.device
    s.addi       s8, s7, #1024
    s.addi       s9, s7, #0
    v.ld.w       v0, [s9, #0]
    s.movz       s9, #0
    s.add        s10, s9, s3                     // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s10
    v.add        v3, v1, v2
    v.cmpi.lt    p1, v3, #512
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v1
    s.addi       s9, s8, #64
    s.addi       s10, s7, #64
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #128
    s.addi       s10, s7, #128
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #192
    s.addi       s10, s7, #192
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #256
    s.addi       s10, s7, #256
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #320
    s.addi       s10, s7, #320
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #384
    s.addi       s10, s7, #384
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #448
    s.addi       s10, s7, #448
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #512
    s.addi       s10, s7, #512
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #576
    s.addi       s10, s7, #576
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #640
    s.addi       s10, s7, #640
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #704
    s.addi       s10, s7, #704
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #768
    s.addi       s10, s7, #768
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #832
    s.addi       s10, s7, #832
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #896
    s.addi       s10, s7, #896
    v.ld.w       v0, [s10, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    s.addi       s9, s8, #960
    s.addi       s8, s7, #960
    v.ld.w       v0, [s8, #0]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v1
    fence.acq_rel.device
    .li       s4, #1052050675
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s4, s3, #4                      // a runtime tile origin, x4
    s.add        s3, s5, s4                      // the tile origin
    s.muli       s4, s6, #2048                   // a runtime tile origin, x2048
    s.add        s5, s3, s4                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s3, s7, #1024
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    @p1 v.st.w       [s5, #0], v1
    s.addi       s3, s7, #1088
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #2048                   // row 1
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1152
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #4096                   // row 2
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1216
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #6144                   // row 3
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1280
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #8192                   // row 4
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1344
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #10240                  // row 5
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1408
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #12288                  // row 6
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1472
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #14336                  // row 7
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1536
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #16384                  // row 8
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1600
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #18432                  // row 9
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1664
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #20480                  // row 10
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1728
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #22528                  // row 11
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1792
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #24576                  // row 12
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1856
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #26624                  // row 13
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1920
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #28672                  // row 14
    @p1 v.st.w       [s3, #0], v1
    s.addi       s3, s7, #1984
    v.ld.w       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v2, v0
    s.addi       s3, s5, #30720                  // row 15
    @p1 v.st.w       [s3, #0], v1
__rctx_next:
    s.addi       s3, s1, #2                      // the next program of this context: + 2
    s.cmp.lt     s4, s3, s2
    s.mov        s1, s3
    br.nz        s4, __rctx_program
    exit
