    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #1
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.shli       s5, s4, #3                      // element offset -> bytes (x8)
    v.movi       v0, #0
    v.movi       v1, #1
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s2
    v.shl        v4, v0, v1
    v.movi       v0, #0
    v.movi       v1, #0
    s.movz       s2, #0
    v.cmp.lt     p1, v2, v3
    s.add        s6, s3, s5                      // &in_ptr0[...]
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.addi       s5, s6, #4
    s.movz       s7, #2048
    s.movz       s8, #16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s9, s2, #0
    s.ld.d       s10, [s1, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s11, [s1, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.ld.d       s12, [s1, #32]                  // out_ptr2: device_ptr64 at arg_base+32
    s.ld.d       s13, [s1, #40]                  // out_ptr3: device_ptr64 at arg_base+40
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s6, v4]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s5, v4]               // index is in elements (ISA sec 9.1)
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s9, s7
    br.nz        s1, endfor_2
    v.extract    s1, v5, #0
    v.extract    s5, v5, #0
    v.extract    s6, v3, #0
    s.shli       s14, s1, #32
    v.extract    s1, v3, #0
    s.shli       s15, s5, #32
    s.or         s5, s6, s14
    s.movz       s6, #0
    s.or         s14, s1, s15
    .li       s1, #151936
    v.movi       v0, #0
    v.movi       v4, #0
    s.cmp.ge     s15, s5, s6
    s.cmp.lt     s5, s14, s1
    v.insert     v0, s15, #0
    v.movi       v6, #0
    v.insert     v4, s5, #0
    v.movi       v7, #0
    v.cmp.ne     p1, v0, v6
    v.movi       v0, #0
    v.cmp.ne     p2, v4, v7
    v.movi       v4, #1
    s.movz       s1, #1
    p.and        p3, p1, p2
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v7, s1
    @p3 v.sel        v8, v0, v4
    v.splat      v0, s9
    v.cmp.lt     p1, v6, v7
    @p1 v.reduce.or  s1, v8
    s.movz       s5, #0
    v.add        v4, v0, v2
    v.movi       v0, #2048
    s.cmp.eq     s6, s1, s5
    v.cmp.lt     p1, v4, v0
    br.nz        s6, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s1, v5, #0
    v.extract    s5, v3, #0
    s.shli       s6, s1, #32
    s.movz       s1, #2048
    s.or         s14, s5, s6
    v.extract    s5, v4, #0
    s.mul        s6, s14, s1
    s.shli       s1, s5, #32
    v.extract    s5, v4, #1
    s.ashri      s14, s1, #32
    v.movi       v0, #0
    v.movi       v6, #0
    v.movi       v7, #0
    v.movi       v8, #0
    s.shli       s1, s5, #32
    s.lshri      s5, s6, #32
    s.lshri      s15, s14, #32
    v.extract    s16, v4, #2
    s.ashri      s17, s1, #32
    v.insert     v0, s6, #0
    v.insert     v6, s5, #0
    v.insert     v7, s14, #0
    v.insert     v8, s15, #0
    s.shli       s1, s16, #32
    s.lshri      s5, s17, #32
    v.extract    s6, v4, #3
    s.ashri      s14, s1, #32
    v.insert     v7, s17, #1
    v.insert     v8, s5, #1
    s.shli       s1, s6, #32
    s.lshri      s5, s14, #32
    v.extract    s6, v4, #4
    s.ashri      s15, s1, #32
    v.insert     v7, s14, #2
    v.insert     v8, s5, #2
    s.shli       s1, s6, #32
    s.lshri      s5, s15, #32
    v.extract    s6, v4, #5
    s.ashri      s14, s1, #32
    v.insert     v7, s15, #3
    v.insert     v8, s5, #3
    s.shli       s1, s6, #32
    s.lshri      s5, s14, #32
    v.extract    s6, v4, #6
    s.ashri      s15, s1, #32
    v.insert     v7, s14, #4
    v.insert     v8, s5, #4
    s.shli       s1, s6, #32
    s.lshri      s5, s15, #32
    v.extract    s6, v4, #7
    s.ashri      s14, s1, #32
    v.insert     v7, s15, #5
    v.insert     v8, s5, #5
    s.shli       s1, s6, #32
    s.lshri      s5, s14, #32
    v.extract    s6, v4, #8
    s.ashri      s15, s1, #32
    v.insert     v7, s14, #6
    v.insert     v8, s5, #6
    s.shli       s1, s6, #32
    s.lshri      s5, s15, #32
    v.extract    s6, v4, #9
    s.ashri      s14, s1, #32
    v.insert     v7, s15, #7
    v.insert     v8, s5, #7
    s.shli       s1, s6, #32
    s.lshri      s5, s14, #32
    v.extract    s6, v4, #10
    s.ashri      s15, s1, #32
    v.insert     v7, s14, #8
    v.insert     v8, s5, #8
    s.shli       s1, s6, #32
    s.lshri      s5, s15, #32
    v.extract    s6, v4, #11
    s.ashri      s14, s1, #32
    v.insert     v7, s15, #9
    v.insert     v8, s5, #9
    s.shli       s1, s6, #32
    s.lshri      s5, s14, #32
    v.extract    s6, v4, #12
    s.ashri      s15, s1, #32
    v.insert     v7, s14, #10
    v.insert     v8, s5, #10
    s.shli       s1, s6, #32
    s.lshri      s5, s15, #32
    v.extract    s6, v4, #13
    s.ashri      s14, s1, #32
    v.insert     v7, s15, #11
    v.insert     v8, s5, #11
    s.shli       s1, s6, #32
    s.lshri      s5, s14, #32
    v.extract    s6, v4, #14
    s.ashri      s15, s1, #32
    v.insert     v7, s14, #12
    v.insert     v8, s5, #12
    s.shli       s1, s6, #32
    s.lshri      s5, s15, #32
    v.extract    s6, v4, #15
    v.extract    s14, v6, #0
    s.ashri      s16, s1, #32
    v.insert     v7, s15, #13
    v.insert     v8, s5, #13
    s.shli       s1, s6, #32
    v.extract    s5, v0, #0
    s.shli       s6, s14, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v6, #0
    s.ashri      s17, s1, #32
    s.or         s1, s5, s6
    v.insert     v7, s16, #14
    v.insert     v8, s14, #14
    v.movi       v4, #0
    v.movi       v9, #0
    v.extract    s5, v0, #0
    s.shli       s6, s15, #32
    s.lshri      s14, s17, #32
    s.lshri      s15, s1, #32
    v.extract    s16, v6, #0
    s.or         s18, s5, s6
    v.insert     v7, s17, #15
    v.insert     v8, s14, #15
    v.insert     v4, s1, #0
    v.insert     v9, s15, #0
    v.extract    s1, v0, #0
    s.shli       s5, s16, #32
    s.lshri      s6, s18, #32
    v.extract    s14, v6, #0
    s.or         s15, s1, s5
    v.insert     v4, s18, #1
    v.insert     v9, s6, #1
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s15, #32
    v.extract    s14, v6, #0
    s.or         s16, s1, s5
    v.insert     v4, s15, #2
    v.insert     v9, s6, #2
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s16, #32
    v.extract    s14, v6, #0
    s.or         s15, s1, s5
    v.insert     v4, s16, #3
    v.insert     v9, s6, #3
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s15, #32
    v.extract    s14, v6, #0
    s.or         s16, s1, s5
    v.insert     v4, s15, #4
    v.insert     v9, s6, #4
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s16, #32
    v.extract    s14, v6, #0
    s.or         s15, s1, s5
    v.insert     v4, s16, #5
    v.insert     v9, s6, #5
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s15, #32
    v.extract    s14, v6, #0
    s.or         s16, s1, s5
    v.insert     v4, s15, #6
    v.insert     v9, s6, #6
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s16, #32
    v.extract    s14, v6, #0
    s.or         s15, s1, s5
    v.insert     v4, s16, #7
    v.insert     v9, s6, #7
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s15, #32
    v.extract    s14, v6, #0
    s.or         s16, s1, s5
    v.insert     v4, s15, #8
    v.insert     v9, s6, #8
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s16, #32
    v.extract    s14, v6, #0
    s.or         s15, s1, s5
    v.insert     v4, s16, #9
    v.insert     v9, s6, #9
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s15, #32
    v.extract    s14, v6, #0
    s.or         s16, s1, s5
    v.insert     v4, s15, #10
    v.insert     v9, s6, #10
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s16, #32
    v.extract    s14, v6, #0
    s.or         s15, s1, s5
    v.insert     v4, s16, #11
    v.insert     v9, s6, #11
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s15, #32
    v.extract    s14, v6, #0
    s.or         s16, s1, s5
    v.insert     v4, s15, #12
    v.insert     v9, s6, #12
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s16, #32
    v.extract    s14, v6, #0
    s.or         s15, s1, s5
    v.insert     v4, s16, #13
    v.insert     v9, s6, #13
    v.extract    s1, v0, #0
    s.shli       s5, s14, #32
    s.lshri      s6, s15, #32
    s.or         s14, s1, s5
    v.insert     v4, s15, #14
    v.insert     v9, s6, #14
    s.lshri      s1, s14, #32
    v.insert     v4, s14, #15
    v.insert     v9, s1, #15
    v.extract    s1, v8, #0
    v.extract    s5, v7, #0
    v.extract    s6, v9, #0
    s.shli       s14, s1, #32
    v.extract    s1, v4, #0
    s.shli       s15, s6, #32
    v.extract    s6, v8, #1
    v.extract    s16, v9, #1
    s.or         s17, s5, s14
    s.or         s5, s1, s15
    v.movi       v0, #0
    v.extract    s1, v7, #1
    s.shli       s14, s6, #32
    v.extract    s6, v4, #1
    s.shli       s15, s16, #32
    s.add        s16, s17, s5
    v.extract    s5, v8, #2
    v.extract    s17, v9, #2
    s.or         s18, s1, s14
    s.or         s1, s6, s15
    v.movi       v6, #0
    v.insert     v0, s16, #0
    v.extract    s6, v7, #2
    s.shli       s14, s5, #32
    v.extract    s5, v4, #2
    s.shli       s15, s17, #32
    s.lshri      s17, s16, #32
    s.add        s16, s18, s1
    v.extract    s1, v8, #3
    s.or         s18, s6, s14
    v.extract    s6, v9, #3
    s.or         s14, s5, s15
    v.insert     v6, s17, #0
    v.insert     v0, s16, #1
    v.extract    s5, v7, #3
    s.shli       s15, s1, #32
    v.extract    s1, v4, #3
    s.shli       s17, s6, #32
    s.lshri      s6, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v8, #4
    s.or         s18, s5, s15
    v.extract    s5, v9, #4
    s.or         s15, s1, s17
    v.insert     v6, s6, #1
    v.insert     v0, s16, #2
    v.extract    s1, v7, #4
    s.shli       s6, s14, #32
    v.extract    s14, v4, #4
    s.shli       s17, s5, #32
    s.lshri      s5, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v8, #5
    s.or         s18, s1, s6
    v.extract    s1, v9, #5
    s.or         s6, s14, s17
    v.insert     v6, s5, #2
    v.insert     v0, s16, #3
    v.extract    s5, v7, #5
    s.shli       s14, s15, #32
    v.extract    s15, v4, #5
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s6
    v.extract    s6, v8, #6
    s.or         s18, s5, s14
    v.extract    s5, v9, #6
    s.or         s14, s15, s17
    v.insert     v6, s1, #3
    v.insert     v0, s16, #4
    v.extract    s1, v7, #6
    s.shli       s15, s6, #32
    v.extract    s6, v4, #6
    s.shli       s17, s5, #32
    s.lshri      s5, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v8, #7
    s.or         s18, s1, s15
    v.extract    s1, v9, #7
    s.or         s15, s6, s17
    v.insert     v6, s5, #4
    v.insert     v0, s16, #5
    v.extract    s5, v7, #7
    s.shli       s6, s14, #32
    v.extract    s14, v4, #7
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v8, #8
    s.or         s18, s5, s6
    v.extract    s5, v9, #8
    s.or         s6, s14, s17
    v.insert     v6, s1, #5
    v.insert     v0, s16, #6
    v.extract    s1, v7, #8
    s.shli       s14, s15, #32
    v.extract    s15, v4, #8
    s.shli       s17, s5, #32
    s.lshri      s5, s16, #32
    s.add        s16, s18, s6
    v.extract    s6, v8, #9
    s.or         s18, s1, s14
    v.extract    s1, v9, #9
    s.or         s14, s15, s17
    v.insert     v6, s5, #6
    v.insert     v0, s16, #7
    v.extract    s5, v7, #9
    s.shli       s15, s6, #32
    v.extract    s6, v4, #9
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v8, #10
    s.or         s18, s5, s15
    v.extract    s5, v9, #10
    s.or         s15, s6, s17
    v.insert     v6, s1, #7
    v.insert     v0, s16, #8
    v.extract    s1, v7, #10
    s.shli       s6, s14, #32
    v.extract    s14, v4, #10
    s.shli       s17, s5, #32
    s.lshri      s5, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v8, #11
    s.or         s18, s1, s6
    v.extract    s1, v9, #11
    s.or         s6, s14, s17
    v.insert     v6, s5, #8
    v.insert     v0, s16, #9
    v.extract    s5, v7, #11
    s.shli       s14, s15, #32
    v.extract    s15, v4, #11
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s6
    v.extract    s6, v8, #12
    s.or         s18, s5, s14
    v.extract    s5, v9, #12
    s.or         s14, s15, s17
    v.insert     v6, s1, #9
    v.insert     v0, s16, #10
    v.extract    s1, v7, #12
    s.shli       s15, s6, #32
    v.extract    s6, v4, #12
    s.shli       s17, s5, #32
    s.lshri      s5, s16, #32
    s.add        s16, s18, s14
    v.extract    s14, v8, #13
    s.or         s18, s1, s15
    v.extract    s1, v9, #13
    s.or         s15, s6, s17
    v.insert     v6, s5, #10
    v.insert     v0, s16, #11
    v.extract    s5, v7, #13
    s.shli       s6, s14, #32
    v.extract    s14, v4, #13
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s15
    v.extract    s15, v8, #14
    s.or         s18, s5, s6
    v.extract    s5, v9, #14
    s.or         s6, s14, s17
    v.insert     v6, s1, #11
    v.insert     v0, s16, #12
    v.extract    s1, v7, #14
    s.shli       s14, s15, #32
    v.extract    s15, v4, #14
    s.shli       s17, s5, #32
    s.lshri      s5, s16, #32
    s.add        s16, s18, s6
    v.extract    s6, v8, #15
    s.or         s18, s1, s14
    v.extract    s1, v9, #15
    s.or         s14, s15, s17
    v.insert     v6, s5, #12
    v.insert     v0, s16, #13
    v.extract    s5, v7, #15
    s.shli       s15, s6, #32
    v.extract    s6, v4, #15
    s.shli       s17, s1, #32
    s.lshri      s1, s16, #32
    s.add        s16, s18, s14
    s.or         s14, s5, s15
    s.or         s5, s6, s17
    v.insert     v6, s1, #13
    v.insert     v0, s16, #14
    s.lshri      s1, s16, #32
    s.add        s6, s14, s5
    v.insert     v6, s1, #14
    v.insert     v0, s6, #15
    v.movi       v4, #31
    s.lshri      s1, s6, #32
    v.movi       v7, #1
    v.insert     v6, s1, #15
    v.ashr       v8, v0, v4
    v.movi       v4, #0
    s.movz       s1, #0
    v.cmp.ne     p2, v6, v8
    @p2 v.sel        v6, v7, v4
    v.reduce.or  s5, v6
    s.cmp.eq     s6, s5, s1
    br.nz        s6, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v4, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.movi       v0, #0
    s.add        s1, s9, s8
    s.movz       s5, #1
    vf.cvt.bf16.f32 v6, v4
    vf.mul       v4, v6, v6
    vf.add       v6, v1, v4
    @p1 v.sel        v4, v6, v1
    v.mov        v0, v4
    v.mov        v1, v0
    s.mov        s9, s1
    br.nz        s5, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s1, s2, #0
    vf.add       v4, v0, v1
for_5:
    s.cmp.ge     s2, s1, s7
    br.nz        s2, endfor_6
    v.splat      v0, s1
    v.extract    s2, v5, #0
    v.extract    s5, v5, #0
    v.extract    s6, v3, #0
    s.shli       s9, s2, #32
    v.extract    s2, v3, #0
    s.shli       s14, s5, #32
    v.add        v1, v0, v2
    v.movi       v0, #2048
    s.shli       s5, s1, #1                      // element offset -> bytes (x2)
    s.or         s15, s6, s9
    s.movz       s6, #0
    s.or         s9, s2, s14
    .li       s2, #151936
    s.add        s14, s10, s5                    // &in_ptr2[...]
    v.movi       v6, #0
    v.movi       v7, #0
    v.cmp.lt     p1, v1, v0
    s.cmp.ge     s5, s15, s6
    s.cmp.lt     s6, s9, s2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s14, #0]
    v.insert     v6, s5, #0
    v.movi       v8, #0
    v.insert     v7, s6, #0
    v.movi       v9, #0
    v.cmp.ne     p2, v6, v8
    v.movi       v6, #0
    v.cmp.ne     p3, v7, v9
    v.movi       v7, #1
    s.movz       s2, #1
    p.and        p4, p2, p3
    v.iota       v8                              // arange(0, VLEN)
    v.splat      v9, s2
    @p4 v.sel        v10, v6, v7
    s.movz       s2, #0
    v.cmp.lt     p2, v8, v9
    @p2 v.reduce.or  s5, v10
    vf.cvt.bf16.f32 v6, v0
    s.cmp.eq     s6, s5, s2
    br.nz        s6, assert_ok_7
    trap         #677351
assert_ok_7:
    v.extract    s2, v5, #0
    v.extract    s5, v3, #0
    s.shli       s6, s2, #32
    s.movz       s2, #2048
    s.or         s9, s5, s6
    v.extract    s5, v1, #0
    s.mul        s6, s9, s2
    s.shli       s2, s5, #32
    v.extract    s5, v1, #1
    s.ashri      s9, s2, #32
    v.movi       v0, #0
    v.movi       v7, #0
    v.movi       v8, #0
    v.movi       v9, #0
    s.shli       s2, s5, #32
    s.lshri      s5, s6, #32
    s.lshri      s14, s9, #32
    v.extract    s15, v1, #2
    s.ashri      s16, s2, #32
    v.insert     v0, s6, #0
    v.insert     v7, s5, #0
    v.insert     v8, s9, #0
    v.insert     v9, s14, #0
    s.shli       s2, s15, #32
    s.lshri      s5, s16, #32
    v.extract    s6, v1, #3
    s.ashri      s9, s2, #32
    v.insert     v8, s16, #1
    v.insert     v9, s5, #1
    s.shli       s2, s6, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v1, #4
    s.ashri      s14, s2, #32
    v.insert     v8, s9, #2
    v.insert     v9, s5, #2
    s.shli       s2, s6, #32
    s.lshri      s5, s14, #32
    v.extract    s6, v1, #5
    s.ashri      s9, s2, #32
    v.insert     v8, s14, #3
    v.insert     v9, s5, #3
    s.shli       s2, s6, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v1, #6
    s.ashri      s14, s2, #32
    v.insert     v8, s9, #4
    v.insert     v9, s5, #4
    s.shli       s2, s6, #32
    s.lshri      s5, s14, #32
    v.extract    s6, v1, #7
    s.ashri      s9, s2, #32
    v.insert     v8, s14, #5
    v.insert     v9, s5, #5
    s.shli       s2, s6, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v1, #8
    s.ashri      s14, s2, #32
    v.insert     v8, s9, #6
    v.insert     v9, s5, #6
    s.shli       s2, s6, #32
    s.lshri      s5, s14, #32
    v.extract    s6, v1, #9
    s.ashri      s9, s2, #32
    v.insert     v8, s14, #7
    v.insert     v9, s5, #7
    s.shli       s2, s6, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v1, #10
    s.ashri      s14, s2, #32
    v.insert     v8, s9, #8
    v.insert     v9, s5, #8
    s.shli       s2, s6, #32
    s.lshri      s5, s14, #32
    v.extract    s6, v1, #11
    s.ashri      s9, s2, #32
    v.insert     v8, s14, #9
    v.insert     v9, s5, #9
    s.shli       s2, s6, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v1, #12
    s.ashri      s14, s2, #32
    v.insert     v8, s9, #10
    v.insert     v9, s5, #10
    s.shli       s2, s6, #32
    s.lshri      s5, s14, #32
    v.extract    s6, v1, #13
    s.ashri      s9, s2, #32
    v.insert     v8, s14, #11
    v.insert     v9, s5, #11
    s.shli       s2, s6, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v1, #14
    s.ashri      s14, s2, #32
    v.insert     v8, s9, #12
    v.insert     v9, s5, #12
    s.shli       s2, s6, #32
    s.lshri      s5, s14, #32
    v.extract    s6, v1, #15
    v.extract    s9, v7, #0
    s.ashri      s15, s2, #32
    v.insert     v8, s14, #13
    v.insert     v9, s5, #13
    s.shli       s2, s6, #32
    v.extract    s5, v0, #0
    s.shli       s6, s9, #32
    s.lshri      s9, s15, #32
    v.extract    s14, v7, #0
    s.ashri      s16, s2, #32
    s.or         s2, s5, s6
    v.insert     v8, s15, #14
    v.insert     v9, s9, #14
    v.movi       v10, #0
    v.movi       v11, #0
    v.extract    s5, v0, #0
    s.shli       s6, s14, #32
    s.lshri      s9, s16, #32
    s.lshri      s14, s2, #32
    v.extract    s15, v7, #0
    s.or         s17, s5, s6
    v.insert     v8, s16, #15
    v.insert     v9, s9, #15
    v.insert     v10, s2, #0
    v.insert     v11, s14, #0
    v.extract    s2, v0, #0
    s.shli       s5, s15, #32
    s.lshri      s6, s17, #32
    v.extract    s9, v7, #0
    s.or         s14, s2, s5
    v.insert     v10, s17, #1
    v.insert     v11, s6, #1
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s14, #32
    v.extract    s9, v7, #0
    s.or         s15, s2, s5
    v.insert     v10, s14, #2
    v.insert     v11, s6, #2
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s15, #32
    v.extract    s9, v7, #0
    s.or         s14, s2, s5
    v.insert     v10, s15, #3
    v.insert     v11, s6, #3
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s14, #32
    v.extract    s9, v7, #0
    s.or         s15, s2, s5
    v.insert     v10, s14, #4
    v.insert     v11, s6, #4
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s15, #32
    v.extract    s9, v7, #0
    s.or         s14, s2, s5
    v.insert     v10, s15, #5
    v.insert     v11, s6, #5
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s14, #32
    v.extract    s9, v7, #0
    s.or         s15, s2, s5
    v.insert     v10, s14, #6
    v.insert     v11, s6, #6
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s15, #32
    v.extract    s9, v7, #0
    s.or         s14, s2, s5
    v.insert     v10, s15, #7
    v.insert     v11, s6, #7
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s14, #32
    v.extract    s9, v7, #0
    s.or         s15, s2, s5
    v.insert     v10, s14, #8
    v.insert     v11, s6, #8
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s15, #32
    v.extract    s9, v7, #0
    s.or         s14, s2, s5
    v.insert     v10, s15, #9
    v.insert     v11, s6, #9
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s14, #32
    v.extract    s9, v7, #0
    s.or         s15, s2, s5
    v.insert     v10, s14, #10
    v.insert     v11, s6, #10
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s15, #32
    v.extract    s9, v7, #0
    s.or         s14, s2, s5
    v.insert     v10, s15, #11
    v.insert     v11, s6, #11
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s14, #32
    v.extract    s9, v7, #0
    s.or         s15, s2, s5
    v.insert     v10, s14, #12
    v.insert     v11, s6, #12
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s15, #32
    v.extract    s9, v7, #0
    s.or         s14, s2, s5
    v.insert     v10, s15, #13
    v.insert     v11, s6, #13
    v.extract    s2, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s14, #32
    s.or         s9, s2, s5
    v.insert     v10, s14, #14
    v.insert     v11, s6, #14
    s.lshri      s2, s9, #32
    v.insert     v10, s9, #15
    v.insert     v11, s2, #15
    v.extract    s2, v9, #0
    v.extract    s5, v8, #0
    v.extract    s6, v11, #0
    s.shli       s9, s2, #32
    v.extract    s2, v10, #0
    s.shli       s14, s6, #32
    v.extract    s6, v9, #1
    v.extract    s15, v11, #1
    s.or         s16, s5, s9
    s.or         s5, s2, s14
    v.movi       v0, #0
    v.extract    s2, v8, #1
    s.shli       s9, s6, #32
    v.extract    s6, v10, #1
    s.shli       s14, s15, #32
    s.add        s15, s16, s5
    v.extract    s5, v9, #2
    v.extract    s16, v11, #2
    s.or         s17, s2, s9
    s.or         s2, s6, s14
    v.movi       v7, #0
    v.insert     v0, s15, #0
    v.extract    s6, v8, #2
    s.shli       s9, s5, #32
    v.extract    s5, v10, #2
    s.shli       s14, s16, #32
    s.lshri      s16, s15, #32
    s.add        s15, s17, s2
    v.extract    s2, v9, #3
    s.or         s17, s6, s9
    v.extract    s6, v11, #3
    s.or         s9, s5, s14
    v.insert     v7, s16, #0
    v.insert     v0, s15, #1
    v.extract    s5, v8, #3
    s.shli       s14, s2, #32
    v.extract    s2, v10, #3
    s.shli       s16, s6, #32
    s.lshri      s6, s15, #32
    s.add        s15, s17, s9
    v.extract    s9, v9, #4
    s.or         s17, s5, s14
    v.extract    s5, v11, #4
    s.or         s14, s2, s16
    v.insert     v7, s6, #1
    v.insert     v0, s15, #2
    v.extract    s2, v8, #4
    s.shli       s6, s9, #32
    v.extract    s9, v10, #4
    s.shli       s16, s5, #32
    s.lshri      s5, s15, #32
    s.add        s15, s17, s14
    v.extract    s14, v9, #5
    s.or         s17, s2, s6
    v.extract    s2, v11, #5
    s.or         s6, s9, s16
    v.insert     v7, s5, #2
    v.insert     v0, s15, #3
    v.extract    s5, v8, #5
    s.shli       s9, s14, #32
    v.extract    s14, v10, #5
    s.shli       s16, s2, #32
    s.lshri      s2, s15, #32
    s.add        s15, s17, s6
    v.extract    s6, v9, #6
    s.or         s17, s5, s9
    v.extract    s5, v11, #6
    s.or         s9, s14, s16
    v.insert     v7, s2, #3
    v.insert     v0, s15, #4
    v.extract    s2, v8, #6
    s.shli       s14, s6, #32
    v.extract    s6, v10, #6
    s.shli       s16, s5, #32
    s.lshri      s5, s15, #32
    s.add        s15, s17, s9
    v.extract    s9, v9, #7
    s.or         s17, s2, s14
    v.extract    s2, v11, #7
    s.or         s14, s6, s16
    v.insert     v7, s5, #4
    v.insert     v0, s15, #5
    v.extract    s5, v8, #7
    s.shli       s6, s9, #32
    v.extract    s9, v10, #7
    s.shli       s16, s2, #32
    s.lshri      s2, s15, #32
    s.add        s15, s17, s14
    v.extract    s14, v9, #8
    s.or         s17, s5, s6
    v.extract    s5, v11, #8
    s.or         s6, s9, s16
    v.insert     v7, s2, #5
    v.insert     v0, s15, #6
    v.extract    s2, v8, #8
    s.shli       s9, s14, #32
    v.extract    s14, v10, #8
    s.shli       s16, s5, #32
    s.lshri      s5, s15, #32
    s.add        s15, s17, s6
    v.extract    s6, v9, #9
    s.or         s17, s2, s9
    v.extract    s2, v11, #9
    s.or         s9, s14, s16
    v.insert     v7, s5, #6
    v.insert     v0, s15, #7
    v.extract    s5, v8, #9
    s.shli       s14, s6, #32
    v.extract    s6, v10, #9
    s.shli       s16, s2, #32
    s.lshri      s2, s15, #32
    s.add        s15, s17, s9
    v.extract    s9, v9, #10
    s.or         s17, s5, s14
    v.extract    s5, v11, #10
    s.or         s14, s6, s16
    v.insert     v7, s2, #7
    v.insert     v0, s15, #8
    v.extract    s2, v8, #10
    s.shli       s6, s9, #32
    v.extract    s9, v10, #10
    s.shli       s16, s5, #32
    s.lshri      s5, s15, #32
    s.add        s15, s17, s14
    v.extract    s14, v9, #11
    s.or         s17, s2, s6
    v.extract    s2, v11, #11
    s.or         s6, s9, s16
    v.insert     v7, s5, #8
    v.insert     v0, s15, #9
    v.extract    s5, v8, #11
    s.shli       s9, s14, #32
    v.extract    s14, v10, #11
    s.shli       s16, s2, #32
    s.lshri      s2, s15, #32
    s.add        s15, s17, s6
    v.extract    s6, v9, #12
    s.or         s17, s5, s9
    v.extract    s5, v11, #12
    s.or         s9, s14, s16
    v.insert     v7, s2, #9
    v.insert     v0, s15, #10
    v.extract    s2, v8, #12
    s.shli       s14, s6, #32
    v.extract    s6, v10, #12
    s.shli       s16, s5, #32
    s.lshri      s5, s15, #32
    s.add        s15, s17, s9
    v.extract    s9, v9, #13
    s.or         s17, s2, s14
    v.extract    s2, v11, #13
    s.or         s14, s6, s16
    v.insert     v7, s5, #10
    v.insert     v0, s15, #11
    v.extract    s5, v8, #13
    s.shli       s6, s9, #32
    v.extract    s9, v10, #13
    s.shli       s16, s2, #32
    s.lshri      s2, s15, #32
    s.add        s15, s17, s14
    v.extract    s14, v9, #14
    s.or         s17, s5, s6
    v.extract    s5, v11, #14
    s.or         s6, s9, s16
    v.insert     v7, s2, #11
    v.insert     v0, s15, #12
    v.extract    s2, v8, #14
    s.shli       s9, s14, #32
    v.extract    s14, v10, #14
    s.shli       s16, s5, #32
    s.lshri      s5, s15, #32
    s.add        s15, s17, s6
    v.extract    s6, v9, #15
    s.or         s17, s2, s9
    v.extract    s2, v11, #15
    s.or         s9, s14, s16
    v.insert     v7, s5, #12
    v.insert     v0, s15, #13
    v.extract    s5, v8, #15
    s.shli       s14, s6, #32
    v.extract    s6, v10, #15
    s.shli       s16, s2, #32
    s.lshri      s2, s15, #32
    s.add        s15, s17, s9
    s.or         s9, s5, s14
    s.or         s5, s6, s16
    v.insert     v7, s2, #13
    v.insert     v0, s15, #14
    s.lshri      s2, s15, #32
    s.add        s6, s9, s5
    v.insert     v7, s2, #14
    v.insert     v0, s6, #15
    v.movi       v8, #31
    s.lshri      s2, s6, #32
    v.movi       v9, #1
    v.insert     v7, s2, #15
    v.ashr       v10, v0, v8
    v.movi       v8, #0
    s.movz       s2, #0
    v.cmp.ne     p2, v7, v10
    @p2 v.sel        v7, v9, v8
    v.reduce.or  s5, v7
    s.cmp.eq     s6, s5, s2
    br.nz        s6, narrow_ok_8
    trap         #677220
narrow_ok_8:
    .li       s2, #1157627904
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #897988541
    v.splat      v9, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v10, v7                         // ISA 8.8: <= 2**-22 relative
    .li       s2, #1077936128
    v.splat      v11, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v12, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v13, [s3, v0]              // index is in elements (ISA sec 9.1)
    s.mul        s2, s4, s7
    s.add        s5, s1, s8
    s.movz       s6, #1
    s.add        s9, s1, s2
    v.splat      v0, s2
    s.shli       s2, s9, #1                      // element offset -> bytes (x2)
    s.add        s9, s11, s2                     // &out_ptr1[...]
    s.add        s14, s12, s2                    // &out_ptr2[...]
    s.add        s15, s13, s2                    // &out_ptr3[...]
    v.add        v14, v1, v0
    vf.cvt.bf16.f32 v0, v13
    vf.fms       v1, v7, v10, v8
    vf.fms       v8, v10, v1, v10
    vf.neg       v1, v8                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v8, v1, v10
    vf.mul       v1, v4, v8                      // a/y: faithful quotient
    vf.fms       v10, v1, v7, v4
    vf.fms       v7, v10, v8, v1
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v1
    vf.add       v1, v7, v9
    v.rsqrt.approx v7, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v7, v7
    vf.mul       v9, v7, v12
    vf.fms       v10, v1, v8, v11
    vf.mul       v1, v9, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v8, v1, v7
    v.extract    s2, v8, #0
    v.splat      v1, s2
    vf.mul       v7, v0, v1
    vf.mul       v0, v6, v7
    vf.cvt.f32.bf16 v1, v0
    @p1 v.st.h       [s9, #0], v1
    @p1 v.st.h       [s14, #0], v1
    @p1 v.st.h       [s15, #0], v1
    s.mov        s1, s5
    br.nz        s6, for_5
endfor_6:
__rctx_next:
    exit
