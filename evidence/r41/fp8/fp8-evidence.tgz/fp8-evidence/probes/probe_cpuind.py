"""W8A8 quantisation: Inductor's own CPU (C++) compile vs TNCA's compile vs eager."""
import os, sys
ROOT = os.path.expanduser(os.environ.get('ROOT', '~/r41-fp8-audit/cand2'))
sys.path.insert(0, ROOT + '/tools/performance_harness')
mode = sys.argv[1]
import torch
from fp8_cases import w8a8_linear
g = torch.Generator().manual_seed(23)
cases = []
for lead, K, N in [((16,), 64, 32), ((64,), 256, 192), ((2, 13), 96, 80)]:
    x = (torch.randn(*lead, K, generator=g) * 2).to(torch.bfloat16)
    w = (torch.randn(N, K, generator=g) * torch.pow(2.0, torch.randint(-2, 3, (N, K), generator=g).float())).to(torch.float8_e4m3fn)
    ws, xs = torch.tensor(0.0213), torch.tensor(0.0157)
    bias = torch.randn(N, generator=g).to(torch.bfloat16)
    cases.append((x, w, ws, xs, bias))
if mode == 'cpu':
    outs = []
    for args in cases:
        torch._dynamo.reset()
        f = torch.compile(w8a8_linear, backend='inductor', fullgraph=True)
        outs.append(tuple(t.clone() for t in f(*args)))
    torch.save(outs, os.path.expanduser('~/fp8w/cpu_inductor_w8a8.pt'))
    print('saved')
else:
    sys.path[:0] = [ROOT, ROOT+'/python', ROOT+'/compiler/python', ROOT+'/tools/asm', ROOT+'/tools/performance_harness/systemc']
    os.environ.update(TNCA_PROFILE='core-vrf-sync-v5', TNCA_TORCH_DEVICE='native', TNCA_INDEX_OPT='1', TNCA_BACKEND='systemc-tlm-grid',
                      TNCA_TLM_BINARY=os.path.expanduser('~/r41-fp8-build/tnca-chip'))
    import triton, tnca, tlm_backend
    tlm_backend.register()
    import tnca.torch_device as D; D.register()
    from fp8_cases import compare, summary_of
    ref = torch.load(os.path.expanduser('~/fp8w/cpu_inductor_w8a8.pt'))
    for args, (qc, yc) in zip(cases, ref):
        torch._dynamo.reset()
        f = torch.compile(w8a8_linear, backend='inductor', fullgraph=True)
        q, y = f(*[a.to('tnca') for a in args])
        qe, ye = w8a8_linear(*args)
        print(tuple(args[0].shape), 'TNCA q vs Inductor-CPU q:', summary_of(compare(q.cpu(), qc)), '| eager q vs Inductor-CPU q:', summary_of(compare(qe, qc)),
              '| TNCA y vs Inductor-CPU y:', summary_of(compare(y.cpu(), yc)), compare(y.cpu(), yc).get('max_ulp_diff'))
