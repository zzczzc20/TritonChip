    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    s.movz       s2, #0
    v.iota       v0                              // arange(0, VLEN)
    s.add        s3, s2, s1                      // the tile origin
    v.movi       v1, #0
    v.splat      v2, s3
    s.rdspecial  s3, role_id
    v.add        v3, v0, v2
    s.movz       s4, #5440
    v.sub        v0, v1, v3
    s.rdspecial  s5, arg_base
    s.mul        s6, s3, s4
    v.cmp.lt     p1, v3, v1
    @p1 v.sel        v2, v0, v3
    v.movi       v0, #63
    s.ld.d       s3, [s5, #72]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.and        v4, v2, v0
    s.rdspecial  s4, arg_base
    s.add        s5, s3, s6                      // this context's own scratch
    v.sub        v0, v1, v4
    s.addi       s3, s5, #0
    @p1 v.sel        v2, v0, v4
    s.addi       s6, s5, #0
    s.ld.d       s7, [s4, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s8, pid.y
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s9, s5, #64
    s.ld.d       s10, [s4, #8]                   // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v0, #0
    s.shli       s11, s8, #4                     // x16 as a shift
    s.ld.d       s8, [s4, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.muli       s12, s11, #32                   // a runtime tile origin, x32
    s.muli       s13, s1, #2                     // a runtime tile origin, x2
    s.ld.d       s14, [s4, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.muli       s15, s11, #6144                 // a runtime tile origin, x6144
    s.movz       s16, #64
    s.ld.d       s17, [s4, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.add        s18, s2, s12                    // the tile origin
    s.add        s2, s7, s13                     // the tile origin
    s.ld.d       s12, [s4, #40]                  // out_ptr0: device_ptr64 at arg_base+40
    v.splat      v4, s18
    s.add        s13, s2, s15                    // the tile origin
    s.ld.d       s2, [s4, #48]                   // out_ptr1: device_ptr64 at arg_base+48
    v.movi       v5, #31
    s.addi       s4, s5, #0
    v.st.w       [s3, #0], v2
    fence.acq_rel.device
    v.movi       v2, #0
    s.addi       s3, s18, #32
    s.addi       s15, s9, #64
    v.splat      v6, s3
    s.movz       s3, #32
    v.splat      v7, s16
    v.splat      v8, s3
    v.sub        v9, v1, v7
    v.ld.w       v10, [s6, #0]
    v.sub        v11, v0, v8
    v.sub        v12, v2, v8
    v.cmp.lt     p1, v7, v1
    v.movi       v1, #31
    v.cmp.lt     p2, v8, v0
    v.cmp.lt     p3, v8, v2
    @p1 v.sel        v13, v9, v7
    s.addi       s3, s5, #0
    v.movi       v9, #0
    v.sub        v13, v0, v10
    v.cmp.lt     p1, v10, v0
    @p1 v.sel        v14, v13, v10
    v.movi       v10, #31
    v.and        v13, v14, v5
    s.addi       s6, s18, #64
    v.sub        v5, v0, v13
    v.splat      v0, s6
    @p1 v.sel        v14, v5, v13
    s.addi       s6, s9, #128
    v.add        v5, v4, v14
    s.addi       s16, s5, #0
    v.st.w       [s9, #0], v5
    s.addi       s19, s18, #96
    v.sub        v4, v9, v8
    v.splat      v5, s19
    s.addi       s19, s9, #192
    v.cmp.lt     p1, v8, v9
    @p2 v.sel        v13, v11, v8
    v.movi       v11, #0
    v.movi       v13, #31
    v.sub        v14, v11, v8
    v.ld.w       v15, [s4, #0]
    v.cmp.lt     p2, v8, v11
    @p3 v.sel        v16, v12, v8
    @p1 v.sel        v12, v4, v8
    @p2 v.sel        v4, v14, v8
    v.sub        v4, v2, v15
    v.cmp.lt     p1, v15, v2
    @p1 v.sel        v12, v4, v15
    s.addi       s4, s5, #0
    v.and        v4, v12, v1
    v.movi       v1, #0
    v.sub        v12, v2, v4
    v.cmp.lt     p2, v8, v1
    @p1 v.sel        v2, v12, v4
    v.add        v4, v6, v2
    v.sub        v2, v1, v8
    v.st.w       [s15, #0], v4
    v.movi       v4, #31
    s.addi       s15, s18, #128
    @p2 v.sel        v6, v2, v8
    v.splat      v2, s15
    s.addi       s15, s9, #256
    v.ld.w       v6, [s3, #0]
    v.sub        v12, v9, v6
    v.cmp.lt     p1, v6, v9
    @p1 v.sel        v14, v12, v6
    s.addi       s3, s5, #0
    v.and        v6, v14, v10
    v.movi       v10, #0
    v.sub        v12, v9, v6
    v.cmp.lt     p2, v8, v10
    @p1 v.sel        v9, v12, v6
    v.add        v6, v0, v9
    v.sub        v0, v10, v8
    v.st.w       [s6, #0], v6
    v.movi       v6, #31
    s.addi       s6, s18, #160
    @p2 v.sel        v9, v0, v8
    v.splat      v0, s6
    s.addi       s6, s9, #320
    v.ld.w       v9, [s16, #0]
    v.sub        v12, v11, v9
    v.cmp.lt     p1, v9, v11
    @p1 v.sel        v14, v12, v9
    s.addi       s16, s5, #0
    v.and        v9, v14, v13
    v.movi       v12, #0
    v.sub        v13, v11, v9
    v.cmp.lt     p2, v8, v12
    @p1 v.sel        v11, v13, v9
    v.add        v9, v5, v11
    v.sub        v5, v12, v8
    v.st.w       [s19, #0], v9
    v.movi       v9, #31
    s.addi       s19, s18, #192
    @p2 v.sel        v11, v5, v8
    v.splat      v5, s19
    s.addi       s19, s9, #384
    v.ld.w       v11, [s4, #0]
    v.sub        v13, v1, v11
    v.cmp.lt     p1, v11, v1
    @p1 v.sel        v14, v13, v11
    s.addi       s4, s5, #0
    v.and        v11, v14, v4
    v.movi       v4, #0
    v.sub        v13, v1, v11
    v.cmp.lt     p2, v8, v4
    @p1 v.sel        v1, v13, v11
    v.add        v11, v2, v1
    v.sub        v1, v4, v8
    v.st.w       [s15, #0], v11
    v.movi       v2, #31
    s.addi       s15, s18, #224
    @p2 v.sel        v11, v1, v8
    v.splat      v1, s15
    s.addi       s15, s9, #448
    v.ld.w       v11, [s3, #0]
    v.sub        v13, v10, v11
    v.cmp.lt     p1, v11, v10
    @p1 v.sel        v14, v13, v11
    s.addi       s3, s5, #0
    v.and        v11, v14, v6
    v.movi       v6, #0
    v.sub        v13, v10, v11
    v.cmp.lt     p2, v8, v6
    @p1 v.sel        v10, v13, v11
    v.add        v11, v0, v10
    v.sub        v0, v6, v8
    v.st.w       [s6, #0], v11
    v.movi       v10, #31
    s.addi       s6, s18, #256
    @p2 v.sel        v11, v0, v8
    v.splat      v0, s6
    s.addi       s6, s9, #512
    v.ld.w       v11, [s16, #0]
    v.sub        v13, v12, v11
    v.cmp.lt     p1, v11, v12
    @p1 v.sel        v14, v13, v11
    s.addi       s16, s5, #0
    v.and        v11, v14, v9
    v.movi       v9, #0
    v.sub        v13, v12, v11
    v.cmp.lt     p2, v8, v9
    @p1 v.sel        v12, v13, v11
    v.add        v11, v5, v12
    v.sub        v5, v9, v8
    v.st.w       [s19, #0], v11
    v.movi       v11, #31
    s.addi       s19, s18, #288
    @p2 v.sel        v12, v5, v8
    v.splat      v5, s19
    s.addi       s19, s9, #576
    v.ld.w       v12, [s4, #0]
    v.sub        v13, v4, v12
    v.cmp.lt     p1, v12, v4
    @p1 v.sel        v14, v13, v12
    s.addi       s4, s5, #0
    v.and        v12, v14, v2
    v.movi       v2, #0
    v.sub        v13, v4, v12
    v.cmp.lt     p2, v8, v2
    @p1 v.sel        v4, v13, v12
    v.add        v12, v1, v4
    v.sub        v1, v2, v8
    v.st.w       [s15, #0], v12
    v.movi       v4, #31
    s.addi       s15, s18, #320
    @p2 v.sel        v12, v1, v8
    v.splat      v1, s15
    s.addi       s15, s9, #640
    v.ld.w       v12, [s3, #0]
    v.sub        v13, v6, v12
    v.cmp.lt     p1, v12, v6
    @p1 v.sel        v14, v13, v12
    s.addi       s3, s5, #0
    v.and        v12, v14, v10
    v.movi       v10, #0
    v.sub        v13, v6, v12
    v.cmp.lt     p2, v8, v10
    @p1 v.sel        v6, v13, v12
    v.add        v12, v0, v6
    v.sub        v0, v10, v8
    v.st.w       [s6, #0], v12
    v.movi       v6, #31
    s.addi       s6, s18, #352
    @p2 v.sel        v12, v0, v8
    v.splat      v0, s6
    s.addi       s6, s9, #704
    v.ld.w       v12, [s16, #0]
    v.sub        v13, v9, v12
    v.cmp.lt     p1, v12, v9
    @p1 v.sel        v14, v13, v12
    s.addi       s16, s5, #0
    v.and        v12, v14, v11
    v.movi       v11, #0
    v.sub        v13, v9, v12
    v.cmp.lt     p2, v8, v11
    @p1 v.sel        v9, v13, v12
    v.add        v12, v5, v9
    v.sub        v5, v11, v8
    v.st.w       [s19, #0], v12
    v.movi       v9, #31
    s.addi       s19, s18, #384
    @p2 v.sel        v12, v5, v8
    v.splat      v5, s19
    s.addi       s19, s9, #768
    v.ld.w       v12, [s4, #0]
    v.sub        v13, v2, v12
    v.cmp.lt     p1, v12, v2
    @p1 v.sel        v14, v13, v12
    s.addi       s4, s5, #0
    v.and        v12, v14, v4
    v.movi       v4, #0
    v.sub        v13, v2, v12
    v.cmp.lt     p2, v8, v4
    @p1 v.sel        v2, v13, v12
    v.add        v12, v1, v2
    v.sub        v1, v4, v8
    v.st.w       [s15, #0], v12
    v.movi       v2, #31
    s.addi       s15, s18, #416
    @p2 v.sel        v12, v1, v8
    v.splat      v1, s15
    s.addi       s15, s9, #832
    v.ld.w       v12, [s3, #0]
    v.sub        v13, v10, v12
    v.cmp.lt     p1, v12, v10
    @p1 v.sel        v14, v13, v12
    s.addi       s3, s5, #0
    v.and        v12, v14, v6
    v.movi       v6, #0
    v.sub        v13, v10, v12
    v.cmp.lt     p2, v8, v6
    @p1 v.sel        v10, v13, v12
    v.add        v12, v0, v10
    v.sub        v0, v6, v8
    v.st.w       [s6, #0], v12
    v.movi       v10, #31
    s.addi       s6, s18, #448
    @p2 v.sel        v12, v0, v8
    v.splat      v0, s6
    s.addi       s6, s9, #896
    v.ld.w       v12, [s16, #0]
    v.sub        v13, v11, v12
    v.cmp.lt     p1, v12, v11
    @p1 v.sel        v14, v13, v12
    s.addi       s16, s5, #0
    v.and        v12, v14, v9
    v.movi       v9, #0
    v.sub        v13, v11, v12
    s.addi       s20, s18, #480
    @p1 v.sel        v11, v13, v12
    v.splat      v12, s20
    v.add        v13, v5, v11
    s.addi       s18, s9, #960
    v.st.w       [s19, #0], v13
    v.movi       v5, #31
    v.sub        v11, v9, v8
    v.cmp.lt     p1, v8, v9
    @p1 v.sel        v13, v11, v8
    v.ld.w       v8, [s4, #0]
    v.sub        v11, v4, v8
    v.cmp.lt     p1, v8, v4
    @p1 v.sel        v13, v11, v8
    s.addi       s4, s5, #64
    v.and        v8, v13, v2
    s.movz       s9, #0
    v.sub        v2, v4, v8
    v.splat      v4, s9
    @p1 v.sel        v11, v2, v8
    s.addi       s19, s5, #1088
    v.add        v2, v1, v11
    v.st.w       [s15, #0], v2
    s.addi       s15, s5, #128
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s19, #64
    v.sub        v2, v6, v1
    v.cmp.lt     p1, v1, v6
    @p1 v.sel        v8, v2, v1
    v.and        v1, v8, v10
    v.sub        v2, v6, v1
    @p1 v.sel        v6, v2, v1
    v.add        v1, v0, v6
    v.st.w       [s6, #0], v1
    s.addi       s6, s5, #192
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s19, #128
    v.sub        v1, v9, v0
    v.cmp.lt     p1, v0, v9
    @p1 v.sel        v2, v1, v0
    v.and        v0, v2, v5
    v.sub        v1, v9, v0
    @p1 v.sel        v2, v1, v0
    v.add        v0, v12, v2
    v.st.w       [s18, #0], v0
    fence.acq_rel.device
    s.addi       s18, s5, #256
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s19, #192
    v.add        v1, v4, v0
    v.st.w       [s19, #0], v1
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s5, #320
    v.add        v1, v4, v0
    v.st.w       [s3, #0], v1
    s.addi       s3, s19, #256
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s5, #384
    v.add        v1, v4, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s19, #320
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s5, #448
    v.add        v1, v4, v0
    v.st.w       [s4, #0], v1
    s.addi       s4, s19, #384
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s5, #512
    v.add        v1, v4, v0
    v.st.w       [s3, #0], v1
    s.addi       s3, s19, #448
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s5, #576
    v.add        v1, v4, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s19, #512
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s5, #640
    v.add        v1, v4, v0
    v.st.w       [s4, #0], v1
    s.addi       s4, s19, #576
    v.cmpi.lt    p1, v3, #1024
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s5, #704
    v.add        v1, v4, v0
    v.st.w       [s3, #0], v1
    s.addi       s3, s19, #640
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s5, #768
    v.add        v1, v4, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s19, #704
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s5, #832
    v.add        v1, v4, v0
    v.st.w       [s4, #0], v1
    s.addi       s4, s19, #768
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s5, #896
    v.add        v1, v4, v0
    v.st.w       [s3, #0], v1
    s.addi       s3, s19, #832
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s5, #960
    v.add        v1, v4, v0
    v.st.w       [s16, #0], v1
    s.addi       s16, s19, #896
    s.addi       s20, s19, #960
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s5, #1024
    v.add        v1, v4, v0
    v.st.w       [s4, #0], v1
    s.addi       s4, s5, #1088
    v.ld.w       v0, [s15, #0]
    s.movz       s15, #0
    s.add        s19, s15, s11                   // the tile origin
    v.splat      v1, s19
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.add        v1, v4, v0
    v.st.w       [s3, #0], v1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s3, #0
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s5, #1152
    v.add        v1, v4, v0
    v.st.w       [s16, #0], v1
    s.addi       s15, s19, #1
    v.splat      v0, s15
    s.movz       s15, #1
    v.cmpi.lt    p2, v0, #256
    p.and        p4, p1, p2
    v.ld.w       v0, [s18, #0]
    s.addi       s16, s5, #1216
    v.add        v1, v4, v0
    v.st.w       [s20, #0], v1
    fence.acq_rel.device
    s.addi       s18, s19, #2
    v.splat      v0, s18
    s.movz       s18, #2
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s5, #1280
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s3, v1
    v.ld.w       v0, [s6, #0]
    s.addi       s3, s19, #3
    s.movz       s6, #3
    v.splat      v1, s3
    s.addi       s3, s5, #1344
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s15, v1
    v.ld.w       v0, [s16, #0]
    s.addi       s15, s19, #4
    s.movz       s16, #4
    v.splat      v1, s15
    s.addi       s15, s5, #1408
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s18, v1
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s19, #5
    s.movz       s18, #5
    v.splat      v1, s4
    s.addi       s4, s5, #1472
    v.cmpi.lt    p2, v1, #256
    p.and        p5, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s6, v1
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s19, #6
    s.movz       s6, #6
    v.splat      v1, s3
    s.addi       s3, s5, #1536
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s16, v1
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s19, #7
    s.movz       s16, #7
    v.splat      v1, s15
    s.addi       s15, s5, #1600
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s18, v1
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s19, #8
    s.movz       s18, #8
    v.splat      v1, s4
    s.addi       s4, s5, #1664
    v.cmpi.lt    p2, v1, #256
    p.and        p5, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s6, v1
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s19, #9
    s.movz       s6, #9
    v.splat      v1, s3
    s.addi       s3, s5, #1728
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s16, v1
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s19, #10
    s.movz       s16, #10
    v.splat      v1, s15
    s.addi       s15, s5, #1792
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s18, v1
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s19, #11
    s.movz       s18, #11
    v.splat      v1, s4
    s.addi       s4, s5, #1856
    v.cmpi.lt    p2, v1, #256
    p.and        p5, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s6, v1
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s19, #12
    s.movz       s6, #12
    v.splat      v1, s3
    s.addi       s3, s5, #1920
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s16, v1
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s19, #13
    s.movz       s16, #13
    v.splat      v1, s15
    s.addi       s15, s5, #1984
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    v.splat      v1, s9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v2, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s18, v2
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s19, #14
    s.movz       s18, #14
    v.splat      v2, s4
    s.addi       s4, s5, #2048
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s6, v2
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s19, #15
    s.movz       s6, #15
    v.splat      v2, s3
    s.addi       s3, s5, #64
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s16, v2
    v.ld.w       v0, [s15, #0]
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s15, s5, #2112
    s.addi       s16, s5, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v2, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s18, v2
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s15, #64
    s.addi       s18, s5, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s10, v0]              // index is in elements (ISA sec 9.1)
    s.addi       s10, s15, #128
    a.vwrite     a0, s6, v2
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #256
    s.addi       s6, s15, #192
    v.add        v2, v1, v0
    v.st.w       [s15, #0], v2
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s5, #320
    v.add        v2, v1, v0
    v.st.w       [s4, #0], v2
    s.addi       s4, s15, #256
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s5, #384
    v.add        v2, v1, v0
    v.st.w       [s10, #0], v2
    s.addi       s10, s15, #320
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #448
    v.add        v2, v1, v0
    v.st.w       [s6, #0], v2
    s.addi       s6, s15, #384
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s5, #512
    v.add        v2, v1, v0
    v.st.w       [s4, #0], v2
    s.addi       s4, s15, #448
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s5, #576
    v.add        v2, v1, v0
    v.st.w       [s10, #0], v2
    s.addi       s10, s15, #512
    v.ld.w       v0, [s3, #0]
    s.muli       s3, s1, #4                      // a runtime tile origin, x4
    s.add        s20, s8, s3                     // the tile origin
    s.muli       s3, s11, #4096                  // a runtime tile origin, x4096
    v.add        v2, v1, v0
    v.st.w       [s6, #0], v2
    s.addi       s6, s15, #576
    s.add        s8, s20, s3                     // the tile origin
    s.addi       s3, s5, #640
    v.splat      v0, s19
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s5, #704
    v.cmpi.lt    p2, v0, #256
    v.add        v0, v1, v2
    p.and        p3, p1, p2
    v.st.w       [s4, #0], v0
    s.addi       s4, s15, #640
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s5, #768
    v.add        v2, v1, v0
    v.st.w       [s10, #0], v2
    s.addi       s10, s15, #704
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #832
    v.add        v2, v1, v0
    v.st.w       [s6, #0], v2
    s.addi       s6, s15, #768
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s5, #896
    v.add        v2, v1, v0
    v.st.w       [s4, #0], v2
    s.addi       s4, s15, #832
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s5, #960
    v.add        v2, v1, v0
    v.st.w       [s10, #0], v2
    s.addi       s10, s15, #896
    s.addi       s20, s15, #960
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #1024
    v.add        v2, v1, v0
    v.st.w       [s6, #0], v2
    s.addi       s6, s5, #2112
    v.ld.w       v0, [s16, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s15, #0
    v.add        v2, v1, v0
    v.st.w       [s4, #0], v2
    s.addi       s4, s5, #2176
    v.ld.w       v0, [s18, #0]
    s.addi       s16, s19, #1
    v.splat      v2, s16
    s.movz       s16, #1
    v.cmpi.lt    p2, v2, #256
    p.and        p4, p1, p2
    v.add        v2, v1, v0
    v.st.w       [s10, #0], v2
    s.addi       s10, s5, #2240
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s19, #2
    v.splat      v2, s3
    s.movz       s3, #2
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    v.add        v2, v1, v0
    v.st.w       [s20, #0], v2
    fence.acq_rel.device
    s.addi       s18, s5, #2304
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s19, #3
    v.splat      v1, s6
    s.movz       s6, #3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    a.vwrite     a1, s15, v2
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s5, #2368
    s.addi       s15, s19, #4
    v.splat      v1, s15
    s.movz       s15, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    a.vwrite     a1, s16, v2
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s5, #2432
    s.addi       s16, s19, #5
    v.splat      v1, s16
    s.movz       s16, #5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v2, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p5, p1, p2
    a.vwrite     a1, s3, v2
    v.ld.w       v0, [s18, #0]
    s.addi       s3, s5, #2496
    s.addi       s18, s19, #6
    v.splat      v1, s18
    s.movz       s18, #6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    a.vwrite     a1, s6, v2
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s5, #2560
    s.addi       s6, s19, #7
    v.splat      v1, s6
    s.movz       s6, #7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    a.vwrite     a1, s15, v2
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s5, #2624
    s.addi       s15, s19, #8
    v.splat      v1, s15
    s.movz       s15, #8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v2, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p5, p1, p2
    a.vwrite     a1, s16, v2
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #2688
    s.addi       s16, s19, #9
    v.splat      v1, s16
    s.movz       s16, #9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    a.vwrite     a1, s18, v2
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s5, #2752
    s.addi       s18, s19, #10
    v.splat      v1, s18
    s.movz       s18, #10
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    a.vwrite     a1, s6, v2
    v.ld.w       v0, [s10, #0]
    s.addi       s6, s5, #2816
    s.addi       s10, s19, #11
    v.splat      v1, s10
    s.movz       s10, #11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v2, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p5, p1, p2
    a.vwrite     a1, s15, v2
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #2880
    s.addi       s15, s19, #12
    v.splat      v1, s15
    s.movz       s15, #12
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    a.vwrite     a1, s16, v2
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s5, #2944
    s.addi       s16, s19, #13
    s.addi       s20, s7, #2048                  // the tile's origin
    v.splat      v1, s16
    s.movz       s7, #13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    a.vwrite     a1, s18, v2
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s5, #3008
    s.addi       s16, s19, #14
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    .li       s18, #1052050675
    v.splat      v1, s18                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v2, s16
    s.movz       s16, #14
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    .li       s18, #1052050675
    v.splat      v0, s18                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    a.vwrite     a1, s10, v4
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s5, #3072
    s.addi       s10, s19, #15
    v.splat      v4, s19
    v.splat      v5, s10
    s.muli       s10, s1, #2                     // a runtime tile origin, x2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s14, v2]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    s.add        s18, s20, s10                   // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s10, s1, #4                     // a runtime tile origin, x4
    s.add        s20, s17, s10                   // the tile origin
    a.vwrite     a1, s15, v6
    v.ld.w       v2, [s4, #0]
    s.muli       s4, s11, #6144                  // a runtime tile origin, x6144
    s.muli       s10, s11, #4096                 // a runtime tile origin, x4096
    v.splat      v5, s19
    s.movz       s15, #15
    s.add        s17, s18, s4                    // the tile origin
    s.add        s4, s20, s10                    // the tile origin
    s.movz       s10, #0
    s.movz       s18, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v6, [s14, v2]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    a.vwrite     a1, s7, v6
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s19, #1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s7, #0
    v.splat      v4, s6
    s.addi       s6, s17, #6144                  // row 1
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v6, [s14, v2]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #256
    p.and        p5, p1, p2
    a.vwrite     a1, s16, v6
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s19, #1
    s.movz       s16, #1
    v.splat      v5, s3
    s.addi       s3, s4, #4096                   // row 1
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s14, v2]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    s.movz       s14, #1
    a.vwrite     a1, s15, v6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s17, #0]
    a.vread      v4, a0, s10
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    s.movz       s10, #1
    s.addi       s15, s19, #2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v5, [s4, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s18
    s.addi       s18, s19, #2
    v.splat      v8, s15
    vf.mul       v9, v6, v4
    v.splat      v4, s18
    v.cmpi.lt    p2, v8, #256
    s.addi       s15, s17, #12288                // row 2
    p.and        p5, p1, p2
    vf.mul       v6, v5, v2
    s.movz       s18, #2
    vf.add       v2, v9, v6
    vf.mul       v5, v2, v0
    a.vwrite     a2, s7, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    a.vread      v5, a0, s16
    v.cmpi.lt    p2, v4, #256
    s.addi       s6, s4, #8192                   // row 2
    p.and        p3, p1, p2
    s.movz       s7, #2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s10
    s.addi       s3, s19, #3
    s.movz       s10, #2
    vf.mul       v8, v6, v5
    s.addi       s16, s19, #3
    v.splat      v5, s3
    v.splat      v6, s16
    v.cmpi.lt    p2, v5, #256
    vf.mul       v5, v4, v2
    s.addi       s3, s17, #18432                 // row 3
    p.and        p4, p1, p2
    s.movz       s16, #3
    vf.add       v2, v8, v5
    vf.mul       v4, v2, v0
    a.vwrite     a2, s14, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v2, [s15, #0]
    a.vread      v4, a0, s18
    v.cmpi.lt    p2, v6, #256
    s.addi       s14, s4, #12288                 // row 3
    p.and        p5, p1, p2
    s.movz       s15, #3
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s6, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s7
    s.addi       s6, s19, #4
    s.movz       s7, #3
    vf.mul       v8, v6, v4
    s.addi       s18, s19, #4
    v.splat      v4, s6
    v.splat      v6, s18
    v.cmpi.lt    p2, v4, #256
    vf.mul       v4, v5, v2
    s.addi       s6, s17, #24576                 // row 4
    p.and        p3, p1, p2
    s.movz       s18, #4
    vf.add       v2, v8, v4
    vf.mul       v4, v2, v0
    a.vwrite     a2, s10, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s3, #0]
    a.vread      v4, a0, s16
    v.cmpi.lt    p2, v6, #256
    s.addi       s3, s4, #16384                  // row 4
    p.and        p4, p1, p2
    s.movz       s10, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v5, [s14, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s15
    s.addi       s14, s19, #5
    s.movz       s15, #4
    vf.mul       v8, v6, v4
    s.addi       s16, s19, #5
    v.splat      v4, s14
    v.splat      v6, s16
    v.cmpi.lt    p2, v4, #256
    vf.mul       v4, v5, v2
    s.addi       s14, s17, #30720                // row 5
    p.and        p5, p1, p2
    s.movz       s16, #5
    vf.add       v2, v8, v4
    vf.mul       v4, v2, v0
    a.vwrite     a2, s7, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    a.vread      v4, a0, s18
    v.cmpi.lt    p2, v6, #256
    s.addi       s6, s4, #20480                  // row 5
    p.and        p3, p1, p2
    s.movz       s7, #5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s3, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s10
    s.addi       s3, s19, #6
    s.movz       s10, #36864
    vf.mul       v8, v6, v4
    s.addi       s18, s19, #6
    v.splat      v4, s3
    v.splat      v6, s18
    v.cmpi.lt    p2, v4, #256
    vf.mul       v4, v5, v2
    s.movz       s3, #5
    s.add        s18, s17, s10                   // row 6
    p.and        p4, p1, p2
    vf.add       v2, v8, v4
    s.movz       s10, #6
    vf.mul       v4, v2, v0
    a.vwrite     a2, s15, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v2, [s14, #0]
    a.vread      v4, a0, s16
    v.cmpi.lt    p2, v6, #256
    s.addi       s14, s4, #24576                 // row 6
    p.and        p5, p1, p2
    s.movz       s15, #6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s6, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s7
    s.addi       s6, s19, #7
    s.movz       s7, #43008
    vf.mul       v8, v6, v4
    s.addi       s16, s19, #7
    v.splat      v4, s6
    v.splat      v6, s16
    v.cmpi.lt    p2, v4, #256
    vf.mul       v4, v5, v2
    s.movz       s6, #6
    s.add        s16, s17, s7                    // row 7
    p.and        p3, p1, p2
    vf.add       v2, v8, v4
    s.movz       s7, #7
    vf.mul       v4, v2, v0
    a.vwrite     a2, s3, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s18, #0]
    a.vread      v4, a0, s10
    v.cmpi.lt    p2, v6, #256
    s.addi       s3, s4, #28672                  // row 7
    p.and        p4, p1, p2
    s.movz       s10, #7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v5, [s14, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s15
    s.addi       s14, s19, #8
    s.movz       s15, #49152
    vf.mul       v8, v6, v4
    s.addi       s18, s19, #8
    v.splat      v4, s14
    v.splat      v6, s18
    s.movz       s14, #32768
    vf.mul       v9, v5, v2
    v.cmpi.lt    p2, v4, #256
    s.movz       s18, #7
    s.add        s20, s17, s15                   // row 8
    vf.add       v2, v8, v9
    p.and        p5, p1, p2
    s.add        s15, s4, s14                    // row 8
    vf.mul       v4, v2, v0
    a.vwrite     a2, s6, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s16, #0]
    a.vread      v4, a0, s7
    v.cmpi.lt    p2, v6, #256
    s.movz       s6, #8
    p.and        p3, p1, p2
    s.movz       s7, #8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s3, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s10
    s.addi       s3, s19, #9
    s.movz       s10, #55296
    vf.mul       v8, v6, v4
    s.addi       s14, s19, #9
    v.splat      v4, s3
    v.splat      v6, s14
    s.movz       s3, #36864
    vf.mul       v9, v5, v2
    v.cmpi.lt    p2, v4, #256
    s.movz       s14, #8
    s.add        s16, s17, s10                   // row 9
    vf.add       v2, v8, v9
    p.and        p4, p1, p2
    s.add        s10, s4, s3                     // row 9
    vf.mul       v4, v2, v0
    a.vwrite     a2, s18, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v2, [s20, #0]
    a.vread      v4, a0, s6
    v.cmpi.lt    p2, v6, #256
    s.movz       s3, #9
    p.and        p5, p1, p2
    s.movz       s6, #9
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s15, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s7
    s.addi       s7, s19, #10
    s.movz       s15, #61440
    vf.mul       v8, v6, v4
    s.addi       s18, s19, #10
    v.splat      v4, s7
    v.splat      v6, s18
    s.movz       s7, #40960
    vf.mul       v9, v5, v2
    v.cmpi.lt    p2, v4, #256
    s.movz       s18, #9
    s.add        s20, s17, s15                   // row 10
    vf.add       v2, v8, v9
    p.and        p3, p1, p2
    s.add        s15, s4, s7                     // row 10
    vf.mul       v4, v2, v0
    a.vwrite     a2, s14, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s16, #0]
    a.vread      v4, a0, s3
    v.cmpi.lt    p2, v6, #256
    s.movz       s3, #10
    p.and        p4, p1, p2
    s.movz       s7, #10
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v5, [s10, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s6
    s.addi       s6, s19, #11
    .li       s10, #67584
    vf.mul       v8, v6, v4
    s.addi       s14, s19, #11
    v.splat      v4, s6
    v.splat      v6, s14
    s.movz       s6, #45056
    vf.mul       v9, v5, v2
    v.cmpi.lt    p2, v4, #256
    s.movz       s14, #10
    s.add        s16, s17, s10                   // row 11
    vf.add       v2, v8, v9
    p.and        p5, p1, p2
    s.add        s10, s4, s6                     // row 11
    vf.mul       v4, v2, v0
    a.vwrite     a2, s18, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s20, #0]
    a.vread      v4, a0, s3
    v.cmpi.lt    p2, v6, #256
    s.movz       s3, #11
    p.and        p3, p1, p2
    s.movz       s6, #11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s15, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s7
    s.addi       s7, s19, #12
    .li       s15, #73728
    vf.mul       v8, v6, v4
    s.addi       s18, s19, #12
    v.splat      v4, s7
    v.splat      v6, s18
    s.movz       s7, #49152
    vf.mul       v9, v5, v2
    v.cmpi.lt    p2, v4, #256
    s.movz       s18, #11
    s.add        s20, s17, s15                   // row 12
    vf.add       v2, v8, v9
    p.and        p4, p1, p2
    s.add        s15, s4, s7                     // row 12
    vf.mul       v4, v2, v0
    a.vwrite     a2, s14, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v2, [s16, #0]
    a.vread      v4, a0, s3
    v.cmpi.lt    p2, v6, #256
    s.movz       s3, #12
    p.and        p5, p1, p2
    s.movz       s7, #12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s10, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s6
    s.addi       s6, s19, #13
    .li       s10, #79872
    vf.mul       v8, v6, v4
    s.addi       s14, s19, #13
    v.splat      v4, s6
    v.splat      v6, s14
    s.movz       s6, #53248
    vf.mul       v9, v5, v2
    v.cmpi.lt    p2, v4, #256
    s.movz       s14, #12
    s.add        s16, s17, s10                   // row 13
    vf.add       v2, v8, v9
    p.and        p3, p1, p2
    s.add        s10, s4, s6                     // row 13
    vf.mul       v4, v2, v0
    a.vwrite     a2, s18, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s20, #0]
    a.vread      v4, a0, s3
    v.cmpi.lt    p2, v6, #256
    s.movz       s3, #13
    p.and        p4, p1, p2
    s.movz       s6, #13
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v5, [s15, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s7
    s.addi       s7, s19, #14
    .li       s15, #86016
    vf.mul       v8, v6, v4
    s.addi       s18, s19, #14
    v.splat      v4, s7
    v.splat      v6, s18
    s.movz       s7, #57344
    vf.mul       v9, v5, v2
    v.cmpi.lt    p2, v4, #256
    s.movz       s18, #13
    s.add        s20, s17, s15                   // row 14
    vf.add       v2, v8, v9
    p.and        p5, p1, p2
    s.add        s15, s4, s7                     // row 14
    vf.mul       v4, v2, v0
    a.vwrite     a2, s14, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s16, #0]
    a.vread      v4, a0, s3
    v.cmpi.lt    p2, v6, #256
    s.movz       s3, #14
    p.and        p3, p1, p2
    s.movz       s7, #14
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s10, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s6
    s.addi       s6, s19, #15
    .li       s10, #92160
    vf.mul       v8, v6, v4
    s.addi       s14, s19, #15
    v.splat      v4, s6
    v.splat      v6, s14
    s.movz       s6, #61440
    vf.mul       v9, v5, v2
    v.cmpi.lt    p2, v4, #256
    s.movz       s14, #14
    s.add        s16, s17, s10                   // row 15
    vf.add       v2, v8, v9
    p.and        p4, p1, p2
    s.movz       s10, #15
    s.add        s17, s4, s6                     // row 15
    vf.mul       v4, v2, v0
    s.movz       s4, #15
    a.vwrite     a2, s18, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v2, [s20, #0]
    a.vread      v4, a0, s3
    v.cmpi.lt    p2, v6, #256
    p.and        p5, p1, p2
    s.movz       s3, #15
    s.addi       s6, s5, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s15, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s7
    s.muli       s7, s11, #64                    // a runtime tile origin, x64
    s.movz       s15, #0
    vf.mul       v8, v6, v4
    v.movi       v4, #0
    v.movi       v6, #6
    v.sub        v9, v4, v3
    v.cmp.lt     p2, v3, v4
    vf.mul       v10, v5, v2
    @p2 v.sel        v2, v9, v3
    s.add        s18, s15, s7                    // the tile origin
    v.lshr       v5, v2, v6
    vf.add       v2, v8, v10
    v.sub        v6, v4, v5
    s.movz       s7, #16384
    v.splat      v8, s18
    vf.mul       v9, v2, v0
    @p2 v.sel        v2, v6, v5
    v.splat      v5, s7
    v.splat      v6, s9
    a.vwrite     a2, s14, v9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v9, [s16, #0]
    a.vread      v10, a0, s10
    v.mul        v11, v2, v5
    s.addi       s7, s5, #3136
    s.addi       s9, s5, #0
    s.addi       s10, s18, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v2, [s17, #0]
    vf.cvt.bf16.f32 v12, v9
    a.vread      v9, a1, s4
    v.movi       v13, #0
    v.splat      v14, s10
    vf.mul       v15, v12, v10
    v.sub        v10, v13, v3
    v.cmp.lt     p2, v3, v13
    @p2 v.sel        v12, v10, v3
    v.movi       v10, #6
    vf.mul       v16, v2, v9
    v.lshr       v2, v12, v10
    s.addi       s4, s7, #64
    v.sub        v9, v13, v2
    vf.add       v10, v15, v16
    @p2 v.sel        v12, v9, v2
    v.sub        v2, v4, v7
    v.mul        v9, v12, v5
    vf.mul       v12, v10, v0
    v.sub        v0, v13, v7
    v.cmp.lt     p2, v7, v4
    v.cmp.lt     p3, v7, v13
    a.vwrite     a2, s3, v12
    v.ld.w       v4, [s6, #0]
    s.addi       s3, s5, #0
    v.movi       v10, #0
    s.addi       s6, s18, #128
    v.cmp.lt     p4, v3, v10
    v.splat      v12, s6
    s.addi       s6, s7, #128
    @p2 v.sel        v13, v2, v7
    v.cmp.lt     p2, v7, v10
    @p3 v.sel        v2, v0, v7
    v.add        v0, v4, v8
    v.sub        v2, v10, v3
    v.add        v4, v0, v11
    @p4 v.sel        v0, v2, v3
    v.add        v2, v6, v4
    v.movi       v4, #6
    v.st.w       [s7, #0], v2
    v.lshr       v2, v0, v4
    s.addi       s10, s5, #0
    v.sub        v0, v10, v2
    v.movi       v4, #0
    @p4 v.sel        v8, v0, v2
    v.cmp.lt     p3, v3, v4
    v.mul        v0, v8, v5
    s.addi       s14, s18, #192
    s.addi       s15, s7, #192
    v.ld.w       v2, [s9, #0]
    v.sub        v8, v4, v3
    v.splat      v11, s14
    @p3 v.sel        v13, v8, v3
    v.sub        v8, v10, v7
    v.cmp.lt     p4, v7, v4
    @p2 v.sel        v10, v8, v7
    v.add        v8, v2, v14
    v.movi       v2, #6
    v.add        v10, v8, v9
    v.lshr       v8, v13, v2
    v.add        v2, v6, v10
    v.sub        v9, v4, v8
    v.st.w       [s4, #0], v2
    @p3 v.sel        v2, v9, v8
    s.addi       s4, s5, #0
    v.mul        v8, v2, v5
    v.movi       v2, #0
    s.addi       s9, s18, #256
    v.cmp.lt     p2, v3, v2
    v.splat      v9, s9
    s.addi       s9, s7, #256
    v.sub        v10, v4, v7
    v.ld.w       v4, [s3, #0]
    v.sub        v13, v2, v3
    v.cmp.lt     p3, v7, v2
    @p2 v.sel        v14, v13, v3
    @p4 v.sel        v13, v10, v7
    v.add        v10, v4, v12
    v.movi       v4, #6
    v.add        v12, v10, v0
    v.lshr       v0, v14, v4
    v.add        v4, v6, v12
    v.sub        v10, v2, v0
    v.st.w       [s6, #0], v4
    @p2 v.sel        v4, v10, v0
    s.addi       s3, s5, #0
    v.mul        v0, v4, v5
    v.movi       v4, #0
    s.addi       s6, s18, #320
    v.cmp.lt     p2, v3, v4
    v.splat      v10, s6
    s.addi       s6, s7, #320
    v.sub        v12, v2, v7
    v.ld.w       v2, [s10, #0]
    v.sub        v13, v4, v3
    v.cmp.lt     p4, v7, v4
    @p2 v.sel        v14, v13, v3
    @p3 v.sel        v13, v12, v7
    v.add        v12, v2, v11
    v.movi       v2, #6
    v.add        v11, v12, v8
    v.lshr       v8, v14, v2
    v.add        v2, v6, v11
    v.sub        v11, v4, v8
    v.st.w       [s15, #0], v2
    @p2 v.sel        v2, v11, v8
    s.addi       s10, s5, #0
    v.mul        v8, v2, v5
    v.movi       v2, #0
    s.addi       s14, s18, #384
    v.cmp.lt     p2, v3, v2
    v.splat      v11, s14
    s.addi       s14, s7, #384
    v.sub        v12, v4, v7
    v.ld.w       v4, [s4, #0]
    v.sub        v13, v2, v3
    v.cmp.lt     p3, v7, v2
    @p2 v.sel        v14, v13, v3
    @p4 v.sel        v13, v12, v7
    v.add        v12, v4, v9
    v.movi       v4, #6
    v.add        v9, v12, v0
    v.lshr       v0, v14, v4
    v.add        v4, v6, v9
    v.sub        v9, v2, v0
    v.st.w       [s9, #0], v4
    @p2 v.sel        v4, v9, v0
    s.addi       s4, s5, #0
    v.mul        v0, v4, v5
    v.movi       v4, #0
    s.addi       s9, s18, #448
    v.cmp.lt     p2, v3, v4
    v.splat      v9, s9
    s.addi       s9, s7, #448
    v.sub        v12, v2, v7
    v.ld.w       v2, [s3, #0]
    v.sub        v13, v4, v3
    v.cmp.lt     p4, v7, v4
    @p2 v.sel        v14, v13, v3
    @p3 v.sel        v13, v12, v7
    v.add        v12, v2, v10
    v.movi       v2, #6
    v.add        v10, v12, v8
    v.lshr       v8, v14, v2
    v.add        v2, v6, v10
    v.sub        v10, v4, v8
    v.st.w       [s6, #0], v2
    @p2 v.sel        v2, v10, v8
    s.addi       s3, s5, #0
    v.mul        v8, v2, v5
    v.movi       v2, #0
    s.addi       s6, s18, #512
    v.cmp.lt     p2, v3, v2
    v.splat      v10, s6
    s.addi       s6, s7, #512
    v.sub        v12, v4, v7
    v.ld.w       v4, [s10, #0]
    v.sub        v13, v2, v3
    v.cmp.lt     p3, v7, v2
    @p2 v.sel        v14, v13, v3
    @p4 v.sel        v13, v12, v7
    v.add        v12, v4, v11
    v.movi       v4, #6
    v.add        v11, v12, v0
    v.lshr       v0, v14, v4
    v.add        v4, v6, v11
    v.sub        v11, v2, v0
    v.st.w       [s14, #0], v4
    @p2 v.sel        v4, v11, v0
    s.addi       s10, s5, #0
    v.mul        v0, v4, v5
    v.movi       v4, #0
    s.addi       s14, s18, #576
    v.cmp.lt     p2, v3, v4
    v.splat      v11, s14
    s.addi       s14, s7, #576
    v.sub        v12, v2, v7
    v.ld.w       v2, [s4, #0]
    v.sub        v13, v4, v3
    v.cmp.lt     p4, v7, v4
    @p2 v.sel        v14, v13, v3
    @p3 v.sel        v13, v12, v7
    v.add        v12, v2, v9
    v.movi       v2, #6
    v.add        v9, v12, v8
    v.lshr       v8, v14, v2
    v.add        v2, v6, v9
    v.sub        v9, v4, v8
    v.st.w       [s9, #0], v2
    @p2 v.sel        v2, v9, v8
    s.addi       s4, s5, #0
    v.mul        v8, v2, v5
    v.movi       v2, #0
    s.addi       s9, s18, #640
    v.cmp.lt     p2, v3, v2
    v.splat      v9, s9
    s.addi       s9, s7, #640
    v.sub        v12, v4, v7
    v.ld.w       v4, [s3, #0]
    v.sub        v13, v2, v3
    v.cmp.lt     p3, v7, v2
    @p2 v.sel        v14, v13, v3
    @p4 v.sel        v13, v12, v7
    v.add        v12, v4, v10
    v.movi       v4, #6
    v.add        v10, v12, v0
    v.lshr       v0, v14, v4
    v.add        v4, v6, v10
    v.sub        v10, v2, v0
    v.st.w       [s6, #0], v4
    @p2 v.sel        v4, v10, v0
    s.addi       s3, s5, #0
    v.mul        v0, v4, v5
    v.movi       v4, #0
    s.addi       s6, s18, #704
    v.cmp.lt     p2, v3, v4
    v.splat      v10, s6
    s.addi       s6, s7, #704
    v.sub        v12, v2, v7
    v.ld.w       v2, [s10, #0]
    v.sub        v13, v4, v3
    v.cmp.lt     p4, v7, v4
    @p2 v.sel        v14, v13, v3
    @p3 v.sel        v13, v12, v7
    v.add        v12, v2, v11
    v.movi       v2, #6
    v.add        v11, v12, v8
    v.lshr       v8, v14, v2
    v.add        v2, v6, v11
    v.sub        v11, v4, v8
    v.st.w       [s14, #0], v2
    @p2 v.sel        v2, v11, v8
    s.addi       s10, s5, #0
    v.mul        v8, v2, v5
    v.movi       v2, #0
    s.addi       s14, s18, #768
    v.cmp.lt     p2, v3, v2
    v.splat      v11, s14
    s.addi       s14, s7, #768
    v.sub        v12, v4, v7
    v.ld.w       v4, [s4, #0]
    v.sub        v13, v2, v3
    v.cmp.lt     p3, v7, v2
    @p2 v.sel        v14, v13, v3
    @p4 v.sel        v13, v12, v7
    v.add        v12, v4, v9
    v.movi       v4, #6
    v.add        v9, v12, v0
    v.lshr       v0, v14, v4
    v.add        v4, v6, v9
    v.sub        v9, v2, v0
    v.st.w       [s9, #0], v4
    @p2 v.sel        v4, v9, v0
    s.addi       s4, s5, #0
    v.mul        v0, v4, v5
    v.movi       v4, #0
    s.addi       s9, s18, #832
    v.cmp.lt     p2, v3, v4
    v.splat      v9, s9
    s.addi       s9, s7, #832
    v.sub        v12, v2, v7
    v.ld.w       v2, [s3, #0]
    v.sub        v13, v4, v3
    v.cmp.lt     p4, v7, v4
    @p2 v.sel        v14, v13, v3
    @p3 v.sel        v13, v12, v7
    v.add        v12, v2, v10
    v.movi       v2, #6
    v.add        v10, v12, v8
    v.lshr       v8, v14, v2
    v.add        v2, v6, v10
    v.sub        v10, v4, v8
    v.st.w       [s6, #0], v2
    @p2 v.sel        v2, v10, v8
    s.addi       s3, s5, #0
    v.mul        v8, v2, v5
    v.movi       v2, #0
    s.addi       s6, s18, #896
    v.cmp.lt     p2, v3, v2
    v.splat      v10, s6
    s.addi       s6, s7, #896
    v.sub        v12, v4, v7
    v.ld.w       v4, [s10, #0]
    v.sub        v13, v2, v3
    v.cmp.lt     p3, v7, v2
    @p2 v.sel        v14, v13, v3
    @p4 v.sel        v13, v12, v7
    v.add        v12, v4, v11
    v.movi       v4, #6
    v.add        v11, v12, v0
    v.lshr       v0, v14, v4
    v.add        v4, v6, v11
    v.sub        v11, v2, v0
    v.st.w       [s14, #0], v4
    @p2 v.sel        v4, v11, v0
    s.addi       s10, s5, #0
    v.mul        v0, v4, v5
    v.movi       v4, #0
    s.addi       s14, s18, #960
    v.cmp.lt     p2, v3, v4
    v.splat      v11, s14
    s.addi       s14, s7, #960
    v.sub        v12, v2, v7
    v.ld.w       v2, [s4, #0]
    v.sub        v13, v4, v3
    v.cmp.lt     p4, v7, v4
    @p2 v.sel        v14, v13, v3
    @p3 v.sel        v3, v12, v7
    v.add        v3, v2, v9
    v.movi       v2, #6
    v.add        v9, v3, v8
    v.lshr       v3, v14, v2
    v.add        v2, v6, v9
    v.sub        v8, v4, v3
    v.st.w       [s9, #0], v2
    @p2 v.sel        v2, v8, v3
    v.splat      v3, s19
    v.mul        v8, v2, v5
    v.cmpi.lt    p2, v3, #256
    p.and        p3, p1, p2
    s.movz       s4, #0
    v.sub        v2, v4, v7
    @p4 v.sel        v3, v2, v7
    v.ld.w       v2, [s3, #0]
    v.splat      v3, s19
    v.cmpi.lt    p2, v3, #256
    v.add        v3, v2, v10
    p.and        p4, p1, p2
    v.add        v2, v3, v0
    s.movz       s3, #0
    v.add        v0, v6, v2
    s.addi       s7, s5, #3136
    v.st.w       [s6, #0], v0
    s.addi       s6, s19, #1
    v.splat      v0, s19
    v.splat      v2, s6
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    s.addi       s6, s13, #6144                  // row 1
    v.ld.w       v0, [s10, #0]
    s.movz       s9, #1
    v.add        v3, v0, v11
    s.addi       s10, s19, #1
    v.add        v0, v3, v8
    v.splat      v3, s10
    v.add        v4, v6, v0
    s.addi       s10, s8, #4096                  // row 1
    v.st.w       [s14, #0], v4
    fence.acq_rel.device
    s.movz       s14, #1
    s.addi       s15, s5, #3200
    s.addi       s16, s19, #1
    v.splat      v0, s16
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s13, #0]
    a.vread      v5, a0, s4
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    s.addi       s4, s13, #12288                 // row 2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s8, #0]
    vf.cvt.bf16.f32 v6, v4
    a.vread      v4, a1, s3
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v6, v5
    s.addi       s3, s19, #2
    s.movz       s16, #2
    v.splat      v5, s3
    s.addi       s3, s8, #8192                   // row 2
    vf.mul       v6, v2, v4
    v.ld.w       v2, [s7, #0]
    s.addi       s7, s19, #2
    vf.add       v4, v3, v6
    v.splat      v3, s7
    vf.mul       v6, v4, v1
    s.movz       s7, #2
    @p5 v.st.scatter.w [s12, v2], v6
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    s.addi       s17, s5, #3264
    s.addi       s18, s19, #2
    v.splat      v0, s18
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s6, #0]
    a.vread      v4, a0, s9
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s10, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s14
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v6, v4
    s.addi       s6, s19, #3
    s.addi       s9, s13, #18432                 // row 3
    v.splat      v4, s6
    s.movz       s6, #3
    vf.mul       v6, v5, v2
    v.ld.w       v2, [s15, #0]
    s.addi       s10, s8, #12288                 // row 3
    vf.add       v5, v3, v6
    s.addi       s14, s19, #3
    vf.mul       v3, v5, v1
    v.splat      v5, s14
    s.movz       s14, #3
    @p5 v.st.scatter.w [s12, v2], v3
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    s.addi       s15, s5, #3328
    s.addi       s18, s19, #3
    v.splat      v0, s18
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    a.vread      v3, a0, s16
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s7
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    vf.mul       v5, v6, v3
    s.addi       s3, s19, #4
    s.addi       s4, s13, #24576                 // row 4
    v.splat      v3, s3
    s.movz       s3, #4
    vf.mul       v6, v4, v2
    v.ld.w       v2, [s17, #0]
    s.addi       s7, s8, #16384                  // row 4
    vf.add       v4, v5, v6
    s.addi       s16, s19, #4
    vf.mul       v5, v4, v1
    v.splat      v4, s16
    s.movz       s16, #4
    @p5 v.st.scatter.w [s12, v2], v5
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    s.addi       s17, s5, #3392
    s.addi       s18, s19, #4
    v.splat      v0, s18
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s9, #0]
    a.vread      v5, a0, s6
    v.cmpi.lt    p2, v3, #256
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s10, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s14
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    vf.mul       v4, v6, v5
    s.addi       s6, s19, #5
    s.addi       s9, s13, #30720                 // row 5
    v.splat      v5, s6
    s.movz       s6, #5
    vf.mul       v6, v3, v2
    v.ld.w       v2, [s15, #0]
    s.addi       s10, s8, #20480                 // row 5
    vf.add       v3, v4, v6
    s.addi       s14, s19, #5
    vf.mul       v4, v3, v1
    v.splat      v3, s14
    s.movz       s14, #5
    @p5 v.st.scatter.w [s12, v2], v4
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    s.addi       s15, s5, #3456
    s.addi       s18, s19, #5
    v.splat      v0, s18
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    a.vread      v4, a0, s3
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s7, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s16
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v6, v4
    s.addi       s3, s19, #6
    s.movz       s4, #36864
    v.splat      v4, s3
    s.add        s3, s13, s4                     // row 6
    vf.mul       v6, v5, v2
    v.ld.w       v2, [s17, #0]
    s.movz       s4, #6
    vf.add       v5, v3, v6
    s.addi       s7, s8, #24576                  // row 6
    vf.mul       v3, v5, v1
    s.addi       s16, s19, #6
    s.movz       s17, #6
    v.splat      v5, s16
    @p5 v.st.scatter.w [s12, v2], v3
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    s.addi       s16, s5, #3520
    s.addi       s18, s19, #6
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s9, #0]
    a.vread      v2, a0, s6
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    v.splat      v3, s18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s10, #0]
    vf.cvt.bf16.f32 v6, v0
    a.vread      v0, a1, s14
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    vf.mul       v5, v6, v2
    s.addi       s6, s19, #7
    s.movz       s9, #43008
    v.splat      v2, s6
    s.add        s6, s13, s9                     // row 7
    vf.mul       v6, v4, v0
    v.ld.w       v0, [s15, #0]
    s.movz       s9, #7
    vf.add       v4, v5, v6
    vf.mul       v5, v4, v1
    s.addi       s10, s19, #7
    s.addi       s14, s8, #28672                 // row 7
    v.splat      v4, s10
    @p5 v.st.scatter.w [s12, v0], v5
    v.cmpi.lt    p2, v3, #256
    p.and        p5, p1, p2
    s.movz       s10, #7
    s.addi       s15, s5, #3584
    s.addi       s18, s19, #7
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    a.vread      v3, a0, s4
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.splat      v2, s18
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s7, #0]
    vf.cvt.bf16.f32 v6, v0
    a.vread      v0, a1, s17
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    vf.mul       v4, v6, v3
    s.addi       s3, s19, #8
    s.movz       s4, #49152
    v.splat      v3, s3
    s.add        s3, s13, s4                     // row 8
    vf.mul       v6, v5, v0
    v.ld.w       v0, [s16, #0]
    s.movz       s4, #8
    vf.add       v5, v4, v6
    vf.mul       v4, v5, v1
    s.addi       s7, s19, #8
    s.movz       s16, #32768
    v.splat      v5, s7
    @p5 v.st.scatter.w [s12, v0], v4
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s7, s8, s16                     // row 8
    s.movz       s16, #8
    s.addi       s17, s5, #3648
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s6, #0]
    a.vread      v2, a0, s9
    v.cmpi.lt    p2, v3, #256
    p.and        p3, p1, p2
    s.addi       s6, s19, #8
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s14, #0]
    vf.cvt.bf16.f32 v4, v0
    a.vread      v0, a1, s10
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    vf.mul       v5, v4, v2
    s.addi       s9, s19, #9
    v.splat      v2, s6
    v.splat      v4, s9
    s.movz       s6, #55296
    vf.mul       v6, v3, v0
    v.ld.w       v0, [s15, #0]
    s.add        s9, s13, s6                     // row 9
    s.movz       s6, #9
    vf.add       v3, v5, v6
    vf.mul       v5, v3, v1
    s.addi       s10, s19, #9
    s.movz       s14, #36864
    v.splat      v3, s10
    @p5 v.st.scatter.w [s12, v0], v5
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s10, s8, s14                    // row 9
    s.movz       s14, #9
    s.addi       s15, s5, #3712
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    a.vread      v2, a0, s4
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s7, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s16
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v5, v2
    s.addi       s3, s19, #9
    s.addi       s4, s19, #10
    v.splat      v2, s3
    v.splat      v5, s4
    vf.mul       v6, v4, v0
    v.ld.w       v0, [s17, #0]
    s.movz       s3, #61440
    s.movz       s4, #10
    vf.add       v4, v3, v6
    s.add        s7, s13, s3                     // row 10
    vf.mul       v3, v4, v1
    s.addi       s3, s19, #10
    s.movz       s16, #40960
    v.splat      v4, s3
    @p5 v.st.scatter.w [s12, v0], v3
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s3, s8, s16                     // row 10
    s.movz       s16, #10
    s.addi       s17, s5, #3776
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s9, #0]
    a.vread      v2, a0, s6
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s10, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s14
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    vf.mul       v4, v5, v2
    s.addi       s6, s19, #10
    s.addi       s9, s19, #11
    v.splat      v2, s6
    v.splat      v5, s9
    vf.mul       v6, v3, v0
    v.ld.w       v0, [s15, #0]
    .li       s6, #67584
    s.movz       s9, #11
    vf.add       v3, v4, v6
    s.add        s10, s13, s6                    // row 11
    vf.mul       v4, v3, v1
    s.addi       s6, s19, #11
    s.movz       s14, #45056
    v.splat      v3, s6
    @p5 v.st.scatter.w [s12, v0], v4
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s6, s8, s14                     // row 11
    s.movz       s14, #11
    s.addi       s15, s5, #3840
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s7, #0]
    a.vread      v2, a0, s4
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s16
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v5, v2
    s.addi       s3, s19, #11
    s.addi       s4, s19, #12
    v.splat      v2, s3
    v.splat      v5, s4
    vf.mul       v6, v4, v0
    v.ld.w       v0, [s17, #0]
    .li       s3, #73728
    s.movz       s4, #12
    vf.add       v4, v3, v6
    s.add        s7, s13, s3                     // row 12
    vf.mul       v3, v4, v1
    s.addi       s3, s19, #12
    s.movz       s16, #49152
    v.splat      v4, s3
    @p5 v.st.scatter.w [s12, v0], v3
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s3, s8, s16                     // row 12
    s.movz       s16, #12
    s.addi       s17, s5, #3904
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s10, #0]
    a.vread      v2, a0, s9
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s6, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s14
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    vf.mul       v4, v5, v2
    s.addi       s6, s19, #12
    s.addi       s9, s19, #13
    v.splat      v2, s6
    v.splat      v5, s9
    vf.mul       v6, v3, v0
    v.ld.w       v0, [s15, #0]
    .li       s6, #79872
    s.movz       s9, #13
    vf.add       v3, v4, v6
    s.add        s10, s13, s6                    // row 13
    vf.mul       v4, v3, v1
    s.addi       s6, s19, #13
    s.movz       s14, #53248
    v.splat      v3, s6
    @p5 v.st.scatter.w [s12, v0], v4
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s6, s8, s14                     // row 13
    s.movz       s14, #13
    s.addi       s15, s5, #3968
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s7, #0]
    a.vread      v2, a0, s4
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s16
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v5, v2
    s.addi       s3, s19, #13
    s.addi       s4, s19, #14
    v.splat      v2, s3
    v.splat      v5, s4
    vf.mul       v6, v4, v0
    v.ld.w       v0, [s17, #0]
    .li       s3, #86016
    s.movz       s4, #14
    vf.add       v4, v3, v6
    s.add        s7, s13, s3                     // row 14
    vf.mul       v3, v4, v1
    s.addi       s3, s19, #14
    s.movz       s16, #57344
    v.splat      v4, s3
    @p5 v.st.scatter.w [s12, v0], v3
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s3, s8, s16                     // row 14
    s.movz       s16, #14
    s.addi       s17, s5, #4032
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s10, #0]
    a.vread      v2, a0, s9
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s6, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s14
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    vf.mul       v4, v5, v2
    s.addi       s6, s19, #14
    s.addi       s9, s19, #15
    v.splat      v2, s6
    v.splat      v5, s9
    vf.mul       v6, v3, v0
    v.ld.w       v0, [s15, #0]
    .li       s6, #92160
    s.movz       s9, #15
    vf.add       v3, v4, v6
    s.add        s10, s13, s6                    // row 15
    vf.mul       v4, v3, v1
    s.addi       s6, s19, #15
    s.movz       s13, #61440
    v.splat      v3, s6
    @p5 v.st.scatter.w [s12, v0], v4
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s6, s8, s13                     // row 15
    s.movz       s8, #15
    s.addi       s13, s5, #4096
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s7, #0]
    a.vread      v2, a0, s4
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s16
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v5, v2
    s.addi       s3, s19, #15
    s.addi       s4, s5, #4160                   // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    v.splat      v2, s3
    s.movz       s3, #1024
    vf.mul       v5, v4, v0
    v.ld.w       v0, [s17, #0]
    s.movz       s7, #256
    s.movz       s14, #1024
    vf.add       v4, v3, v5
    s.movz       s15, #4
    vf.mul       v3, v4, v1
    .li       s16, #68719476752
    .li       s17, #2207613190144
    s.addi       s18, s5, #4416                  // 1024 bytes of repack scratch
    @p5 v.st.scatter.w [s12, v0], v3
    s.movz       s5, #1
    v.cmpi.lt    p2, v2, #256
    s.muli       s19, s5, #64
    p.and        p5, p1, p2
    // tile epilogue: 16 rows through the vector unit, as f32 (ISA sec 9B)
    s.movz       s5, #0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s10, #0]
    a.vread      v2, a0, s9
    s.movz       s9, #1
    s.add        s10, s18, s19
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s6, #0]
    vf.cvt.bf16.f32 v4, v0
    a.vread      v0, a1, s8
    s.movz       s6, #2
    vf.mul       v5, v4, v2
    s.movz       s8, #2
    s.movz       s19, #3
    s.muli       s20, s8, #64
    s.muli       s8, s19, #64
    vf.mul       v2, v3, v0
    v.ld.w       v0, [s13, #0]
    s.movz       s13, #3
    s.add        s19, s18, s20
    vf.add       v3, v5, v2
    s.add        s20, s18, s8
    vf.mul       v2, v3, v1
    @p5 v.st.scatter.w [s12, v0], v2
    s.movz       s8, #4
    s.muli       s12, s8, #64
    s.add        s8, s18, s12
    s.st.d       [s4, #0], s2
    s.st.d       [s4, #8], s3
    s.movz       s3, #5
    s.st.d       [s4, #16], s7
    s.muli       s7, s3, #64
    s.movz       s3, #6
    s.st.d       [s4, #48], s14
    s.movz       s12, #4
    s.muli       s14, s3, #64
    s.st.d       [s4, #56], s15
    s.movz       s3, #7
    s.add        s15, s18, s7
    s.st.d       [s4, #88], s16
    s.movz       s7, #5
    s.muli       s16, s3, #64
    s.st.d       [s4, #104], s17
    fence.release.device
    td.load      d0, [s4]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    a.vread      v0, a2, s5
    s.movz       s3, #8
    v.st.w       [s18, #0], v0
    a.vread      v0, a2, s9
    s.movz       s4, #6
    s.muli       s5, s3, #64
    s.movz       s3, #9
    s.add        s9, s18, s14
    s.movz       s14, #7
    s.muli       s17, s3, #64
    s.add        s3, s18, s16
    s.add        s16, s18, s5
    v.st.w       [s10, #0], v0
    a.vread      v0, a2, s6
    s.movz       s5, #10
    s.movz       s6, #8
    s.muli       s10, s5, #64
    s.add        s5, s18, s17
    s.add        s17, s18, s10
    v.st.w       [s19, #0], v0
    a.vread      v0, a2, s13
    s.movz       s10, #11
    s.movz       s13, #9
    s.muli       s19, s10, #64
    s.add        s10, s18, s19
    v.st.w       [s20, #0], v0
    a.vread      v0, a2, s12
    s.movz       s12, #12
    s.movz       s19, #10
    s.muli       s20, s12, #64
    s.add        s12, s18, s20
    v.st.w       [s8, #0], v0
    a.vread      v0, a2, s7
    s.movz       s7, #13
    s.movz       s8, #11
    s.muli       s20, s7, #64
    s.add        s7, s18, s20
    v.st.w       [s15, #0], v0
    a.vread      v0, a2, s4
    s.movz       s4, #14
    s.movz       s15, #12
    s.muli       s20, s4, #64
    s.add        s4, s18, s20
    v.st.w       [s9, #0], v0
    a.vread      v0, a2, s14
    s.movz       s9, #15
    s.movz       s14, #13
    s.muli       s20, s9, #64
    s.add        s9, s18, s20
    v.st.w       [s3, #0], v0
    a.vread      v0, a2, s6
    s.movz       s3, #0
    s.movz       s6, #0
    s.muli       s20, s3, #64
    v.st.w       [s16, #0], v0
    a.vread      v0, a2, s13
    s.muli       s3, s6, #4
    s.movz       s6, #14
    s.movz       s13, #16
    s.add        s16, s18, s20
    s.movz       s18, #15
    s.add        s20, s16, s3
    // tl.trans: 16 columns, gathered %c1982:scalar elements apart (ISA sec 9.1)
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s13
    v.st.w       [s5, #0], v0
    a.vread      v0, a2, s19
    v.mul        v3, v1, v2                      // one element per source row
    s.addi       s3, s20, #4                     // column 1
    s.addi       s5, s20, #8                     // column 2
    s.addi       s13, s20, #12                   // column 3
    v.st.w       [s17, #0], v0
    a.vread      v0, a2, s8
    s.addi       s8, s20, #16                    // column 4
    s.addi       s16, s20, #20                   // column 5
    s.addi       s17, s20, #24                   // column 6
    v.st.w       [s10, #0], v0
    a.vread      v0, a2, s15
    s.addi       s10, s20, #28                   // column 7
    s.addi       s15, s20, #32                   // column 8
    v.st.w       [s12, #0], v0
    a.vread      v0, a2, s14
    s.addi       s12, s20, #36                   // column 9
    s.addi       s14, s20, #40                   // column 10
    v.st.w       [s7, #0], v0
    a.vread      v0, a2, s6
    s.addi       s6, s20, #44                    // column 11
    s.addi       s7, s20, #48                    // column 12
    v.st.w       [s4, #0], v0
    a.vread      v0, a2, s18
    s.addi       s4, s20, #52                    // column 13
    s.addi       s18, s20, #56                   // column 14
    v.splat      v1, s11
    s.muli       s19, s11, #4
    v.st.w       [s9, #0], v0
    s.addi       s9, s20, #60                    // column 15
    fence.acq_rel.device
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v2, #0
    v.add        v4, v1, v0
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ge     p1, v4, v2
    v.cmpi.lt    p2, v4, #256
    v.ld.gather.w v2, [s20, v3]                  // index is in elements (ISA sec 9.1)
    s.muli       s11, s1, #1024
    v.cmp.ge     p3, v0, v1
    v.cmpi.lt    p4, v0, #1024
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s20, s2, s11
    s.movz       s2, #1
    s.add        s11, s20, s19
    p.and        p2, p5, p1
    v.ld.gather.w v0, [s3, v3]                   // index is in elements (ISA sec 9.1)
    s.muli       s3, s2, #1024
    s.add        s2, s11, s3
    v.ld.gather.w v1, [s5, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s3, s1, #1
    v.splat      v4, s3
    v.ld.gather.w v5, [s13, v3]                  // index is in elements (ISA sec 9.1)
    v.movi       v6, #0
    v.cmp.ge     p1, v4, v6
    v.ld.gather.w v6, [s8, v3]                   // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p3, v4, #1024
    p.and        p4, p1, p3
    v.ld.gather.w v4, [s16, v3]                  // index is in elements (ISA sec 9.1)
    p.and        p1, p5, p4
    v.ld.gather.w v7, [s17, v3]                  // index is in elements (ISA sec 9.1)
    s.movz       s3, #2
    s.muli       s5, s3, #1024
    v.ld.gather.w v8, [s10, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s3, s1, #2
    s.add        s8, s11, s5
    v.ld.gather.w v9, [s15, v3]                  // index is in elements (ISA sec 9.1)
    v.splat      v10, s3
    v.movi       v11, #0
    v.ld.gather.w v12, [s12, v3]                 // index is in elements (ISA sec 9.1)
    v.cmp.ge     p3, v10, v11
    v.ld.gather.w v11, [s14, v3]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v13, [s6, v3]                  // index is in elements (ISA sec 9.1)
    s.movz       s3, #3
    v.ld.gather.w v14, [s7, v3]                  // index is in elements (ISA sec 9.1)
    s.muli       s5, s3, #1024
    s.add        s3, s11, s5
    v.ld.gather.w v15, [s4, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s4, s1, #3
    v.splat      v16, s4
    v.ld.gather.w v17, [s18, v3]                 // index is in elements (ISA sec 9.1)
    v.movi       v18, #0
    v.ld.gather.w v19, [s9, v3]                  // index is in elements (ISA sec 9.1)
    s.movz       s4, #4
    s.addi       s5, s1, #4
    s.movz       s6, #5
    s.muli       s7, s4, #1024
    v.splat      v3, s5
    v.movi       v20, #0
    s.muli       s4, s6, #1024
    s.add        s5, s11, s7
    @p2 v.st.w       [s11, #0], v2
    s.addi       s6, s1, #5
    s.movz       s7, #6
    v.splat      v2, s6
    v.movi       v21, #0
    s.muli       s6, s7, #1024
    v.cmpi.lt    p2, v10, #1024
    p.and        p4, p3, p2
    v.cmp.ge     p2, v16, v18
    p.and        p3, p5, p4
    s.add        s7, s11, s4
    s.add        s4, s11, s6
    @p1 v.st.w       [s2, #0], v0
    s.addi       s2, s1, #6
    s.movz       s6, #7
    v.splat      v0, s2
    v.movi       v10, #0
    s.muli       s2, s6, #1024
    v.cmpi.lt    p1, v16, #1024
    p.and        p4, p2, p1
    v.cmp.ge     p1, v3, v20
    p.and        p2, p5, p4
    s.add        s6, s11, s2
    @p3 v.st.w       [s8, #0], v1
    s.addi       s2, s1, #7
    s.movz       s8, #8
    v.splat      v1, s2
    v.movi       v16, #0
    s.muli       s2, s8, #1024
    v.cmpi.lt    p3, v3, #1024
    p.and        p4, p1, p3
    v.cmp.ge     p1, v2, v21
    p.and        p3, p5, p4
    s.add        s8, s11, s2
    @p2 v.st.w       [s3, #0], v5
    s.addi       s2, s1, #8
    s.movz       s3, #9
    v.splat      v3, s2
    v.movi       v5, #0
    s.muli       s2, s3, #1024
    v.cmpi.lt    p2, v2, #1024
    p.and        p4, p1, p2
    v.cmp.ge     p1, v0, v10
    p.and        p2, p5, p4
    s.add        s3, s11, s2
    @p3 v.st.w       [s5, #0], v6
    s.addi       s2, s1, #9
    s.movz       s5, #10
    v.splat      v2, s2
    v.movi       v6, #0
    s.muli       s2, s5, #1024
    v.cmpi.lt    p3, v0, #1024
    p.and        p4, p1, p3
    v.cmp.ge     p1, v1, v16
    p.and        p3, p5, p4
    s.add        s5, s11, s2
    @p2 v.st.w       [s7, #0], v4
    s.addi       s2, s1, #10
    s.movz       s7, #11
    v.splat      v0, s2
    v.movi       v4, #0
    s.muli       s2, s7, #1024
    v.cmpi.lt    p2, v1, #1024
    p.and        p4, p1, p2
    v.cmp.ge     p1, v3, v5
    p.and        p2, p5, p4
    s.add        s7, s11, s2
    @p3 v.st.w       [s4, #0], v7
    s.addi       s2, s1, #11
    s.movz       s4, #12
    v.splat      v1, s2
    v.movi       v5, #0
    s.muli       s2, s4, #1024
    v.cmpi.lt    p3, v3, #1024
    p.and        p4, p1, p3
    v.cmp.ge     p1, v2, v6
    p.and        p3, p5, p4
    s.add        s4, s11, s2
    @p2 v.st.w       [s6, #0], v8
    s.addi       s2, s1, #12
    s.movz       s6, #13
    v.splat      v3, s2
    v.movi       v6, #0
    s.muli       s2, s6, #1024
    v.cmpi.lt    p2, v2, #1024
    p.and        p4, p1, p2
    v.cmp.ge     p1, v0, v4
    p.and        p2, p5, p4
    s.add        s6, s11, s2
    @p3 v.st.w       [s8, #0], v9
    s.addi       s2, s1, #13
    s.movz       s8, #14
    v.splat      v2, s2
    v.movi       v4, #0
    s.muli       s2, s8, #1024
    v.cmpi.lt    p3, v0, #1024
    p.and        p4, p1, p3
    v.cmp.ge     p1, v1, v5
    p.and        p3, p5, p4
    s.add        s8, s11, s2
    @p2 v.st.w       [s3, #0], v12
    s.addi       s2, s1, #14
    s.movz       s3, #15
    v.splat      v0, s2
    v.movi       v5, #0
    s.muli       s2, s3, #1024
    v.cmpi.lt    p2, v1, #1024
    p.and        p4, p1, p2
    v.cmp.ge     p1, v3, v6
    p.and        p2, p5, p4
    s.add        s3, s11, s2
    @p3 v.st.w       [s5, #0], v11
    s.addi       s2, s1, #15
    v.movi       v1, #0
    v.splat      v6, s2
    v.cmpi.lt    p3, v3, #1024
    p.and        p4, p1, p3
    v.cmp.ge     p1, v2, v4
    p.and        p3, p5, p4
    @p2 v.st.w       [s7, #0], v13
    v.cmpi.lt    p2, v2, #1024
    p.and        p4, p1, p2
    v.cmp.ge     p1, v0, v5
    p.and        p2, p5, p4
    @p3 v.st.w       [s4, #0], v14
    v.cmpi.lt    p3, v0, #1024
    p.and        p4, p1, p3
    v.cmp.ge     p1, v6, v1
    p.and        p3, p5, p4
    @p2 v.st.w       [s6, #0], v15
    v.cmpi.lt    p2, v6, #1024
    p.and        p4, p1, p2
    p.and        p1, p5, p4
    @p3 v.st.w       [s8, #0], v17
    @p1 v.st.w       [s3, #0], v19
__rctx_next:
    exit
