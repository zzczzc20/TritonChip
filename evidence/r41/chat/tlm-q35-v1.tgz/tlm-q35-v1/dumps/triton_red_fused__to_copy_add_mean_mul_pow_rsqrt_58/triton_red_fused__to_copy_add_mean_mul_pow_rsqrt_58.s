    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr3: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // in_ptr4: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // out_ptr1: device_ptr64 at arg_base+48
    s.ld.d       s10, [s1, #56]                  // out_ptr2: device_ptr64 at arg_base+56
    s.rdspecial  s1, arg_base
    s.ld.d       s11, [s1, #80]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s12, #1280
    s.mul        s13, s1, s12
    s.add        s1, s11, s13                    // this context's own scratch
    s.addi       s11, s1, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s2
    s.movz       s12, #15
    s.st.d       [s11, #8], s12
    s.movz       s12, #2560
    s.st.d       [s11, #16], s12
    s.movz       s12, #5120
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d0, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #256                   // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s3
    s.movz       s12, #15
    s.st.d       [s11, #8], s12
    s.movz       s12, #2560
    s.st.d       [s11, #16], s12
    s.movz       s12, #5120
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d1, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #512                   // TensorMap 2: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s5
    s.movz       s12, #15
    s.st.d       [s11, #8], s12
    s.movz       s12, #2560
    s.st.d       [s11, #16], s12
    s.movz       s12, #5120
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d2, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #768                   // TensorMap 3: tl.make_tensor_descriptor (rank 2)
    s.movz       s12, #0
    s.st.d       [s11, #0], s6
    s.movz       s12, #15
    s.st.d       [s11, #8], s12
    s.movz       s12, #2560
    s.st.d       [s11, #16], s12
    s.movz       s12, #5120
    s.st.d       [s11, #48], s12
    s.movz       s12, #2
    s.st.d       [s11, #56], s12
    .li       s12, #68719476737
    s.st.d       [s11, #88], s12
    .li       s12, #1108101562368
    s.st.d       [s11, #104], s12
    fence.release.device
    td.load      d3, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s1, #1024                  // TensorMap 4: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s11, #0], s7
    s.movz       s1, #15
    s.st.d       [s11, #8], s1
    s.movz       s1, #2560
    s.st.d       [s11, #16], s1
    s.movz       s1, #5120
    s.st.d       [s11, #48], s1
    s.movz       s1, #2
    s.st.d       [s11, #56], s1
    .li       s1, #68719476737
    s.st.d       [s11, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s11, #104], s1
    fence.release.device
    td.load      d4, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s11, #2560
    s.movz       s12, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s13, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s14, s13, s11
    br.nz        s14, endfor_2
    v.splat      v1, s13
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s13
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s14, #2560
    s.movz       s15, #15
    s.movz       s16, #2560
    s.movz       s17, #15
    s.muli       s18, s4, #5120
    s.muli       s19, s4, #5120
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s14
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s15
    v.add        v10, v4, v5
    v.movi       v4, #0
    v.splat      v5, s16
    v.splat      v11, s4
    v.movi       v12, #0
    s.muli       s14, s13, #2
    s.muli       s15, s13, #2
    v.cmp.ge     p1, v6, v1
    v.splat      v1, s17
    v.cmp.lt     p2, v6, v3
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s16, s2, s18
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v5
    p.and        p2, p3, p4
    v.cmp.ge     p3, v11, v12
    s.add        s17, s3, s19
    p.and        p4, p5, p1
    v.cmp.lt     p1, v11, v1
    p.and        p5, p3, p1
    s.add        s18, s16, s14
    p.and        p1, p6, p2
    s.add        s14, s17, s15
    p.and        p2, p4, p5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s18, #0]
    v.splat      v3, s13
    v.movi       v4, #2560
    v.add        v5, v3, v0
    s.muli       s15, s4, #5120
    v.cmp.lt     p1, v5, v4
    v.splat      v3, s13
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s16, #2560
    s.movz       s17, #15
    v.add        v6, v3, v4
    v.movi       v3, #0
    v.splat      v4, s16
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s17
    s.muli       s16, s13, #2
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v10, [s14, #0]
    v.cmp.ge     p2, v6, v3
    v.cmp.lt     p3, v6, v4
    v.cmp.ge     p4, v7, v8
    v.cmp.lt     p5, v7, v9
    s.add        s14, s5, s15
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.muli       s15, s4, #5120
    s.add        s17, s14, s16
    p.and        p3, p6, p2
    vf.cvt.bf16.f32 v3, v1
    v.splat      v1, s13
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s14, #2560
    s.movz       s16, #15
    v.add        v6, v1, v4
    v.movi       v1, #0
    v.splat      v4, s14
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s16
    s.muli       s14, s13, #2
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v11, [s17, #0]
    v.cmp.ge     p2, v6, v1
    v.cmp.lt     p3, v6, v4
    v.cmp.ge     p4, v7, v8
    v.cmp.lt     p5, v7, v9
    s.add        s16, s6, s15
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.muli       s15, s4, #5120
    s.add        s17, s16, s14
    p.and        p3, p6, p2
    vf.cvt.bf16.f32 v1, v10
    v.splat      v4, s13
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s14, #2560
    s.movz       s16, #15
    v.add        v7, v4, v6
    v.movi       v4, #0
    v.splat      v6, s14
    v.splat      v8, s4
    v.movi       v9, #0
    v.splat      v10, s16
    s.muli       s14, s13, #2
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v12, [s17, #0]
    v.cmp.ge     p2, v7, v4
    v.cmp.lt     p3, v7, v6
    v.cmp.ge     p4, v8, v9
    v.cmp.lt     p5, v8, v10
    s.add        s16, s7, s15
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.add        s15, s16, s14
    p.and        p3, p6, p2
    vf.cvt.bf16.f32 v4, v11
    vf.add       v6, v3, v1
    s.mul        s14, s4, s11
    v.movi       v1, #0
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s15, #0]
    vf.cvt.bf16.f32 v7, v12
    vf.add       v8, v6, v4
    s.add        s15, s13, s14
    v.splat      v4, s14
    s.shli       s14, s15, #1                    // element offset -> bytes (x2)
    s.add        s15, s13, s12
    vf.add       v6, v8, v7
    s.add        s16, s2, s14                    // &in_out_ptr0[...]
    s.movz       s14, #1
    v.add        v7, v5, v4
    vf.cvt.bf16.f32 v4, v3
    vf.add       v3, v6, v4
    vf.mul       v4, v3, v3
    vf.cvt.f32.bf16 v5, v3
    vf.add       v3, v2, v4
    @p1 v.st.h       [s16, #0], v5
    @p1 v.sel        v4, v3, v2
    v.mov        v1, v4
    v.mov        v2, v1
    s.mov        s13, s15
    br.nz        s14, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    s.addi       s3, s1, #0
    vf.add       v3, v1, v2
for_3:
    s.cmp.ge     s1, s3, s11
    br.nz        s1, endfor_4
    .li       s1, #1159725056
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #897988541
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v1                          // ISA 8.8: <= 2**-22 relative
    v.splat      v6, s3
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s1, #2560
    s.movz       s5, #15
    s.muli       s6, s4, #5120
    v.add        v8, v6, v7
    v.movi       v6, #0
    v.splat      v7, s1
    v.splat      v9, s4
    v.movi       v10, #0
    s.muli       s1, s3, #2
    v.cmp.ge     p1, v8, v6
    v.splat      v6, s5
    v.cmp.lt     p2, v8, v7
    v.splat      v7, s3
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v6
    v.add        v6, v7, v0
    v.movi       v7, #2560
    s.add        s5, s2, s6
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.shli       s6, s3, #1                      // element offset -> bytes (x2)
    s.add        s7, s5, s1
    p.and        p2, p5, p1
    s.add        s1, s8, s6                      // &in_ptr4[...]
    v.cmp.lt     p1, v6, v7
    vf.fms       v7, v1, v5, v2
    .li       s5, #1077936128
    v.splat      v2, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    fence.acq_rel.device
    .li       s5, #3204448256
    v.splat      v8, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v9, [s7, #0]
    vf.fms       v10, v5, v7, v5
    .li       s5, #1065353216
    v.splat      v7, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s5, s4, s11
    s.add        s6, s3, s12
    vf.neg       v11, v10                        // Newton step: r0*(2 - x*r0)
    s.add        s7, s3, s5
    v.splat      v10, s5
    s.shli       s5, s7, #1                      // element offset -> bytes (x2)
    vf.cmp.o     p2, v11, v11
    @p2 v.sel        v12, v11, v5
    s.add        s7, s9, s5                      // &out_ptr1[...]
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v5, [s1, #0]
    vf.cvt.bf16.f32 v11, v9
    s.add        s1, s10, s5                     // &out_ptr2[...]
    s.movz       s5, #1
    fence.acq_rel.device
    v.add        v9, v6, v10
    vf.mul       v6, v3, v12                     // a/y: faithful quotient
    vf.fms       v9, v6, v1, v3
    vf.cvt.bf16.f32 v1, v5
    vf.fms       v5, v9, v12, v6
    vf.add       v9, v1, v7
    vf.neg       v1, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v5, v1, v6
    vf.add       v1, v5, v4
    v.rsqrt.approx v4, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v4, v4
    vf.mul       v6, v4, v8
    vf.fms       v7, v1, v5, v2
    vf.mul       v1, v6, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v2, v1, v4
    v.extract    s13, v2, #0
    v.splat      v1, s13
    vf.mul       v2, v11, v1
    vf.mul       v1, v2, v9
    vf.cvt.f32.bf16 v2, v1
    @p1 v.st.h       [s7, #0], v2
    @p1 v.st.h       [s1, #0], v2
    s.mov        s3, s6
    br.nz        s5, for_3
endfor_4:
__rctx_next:
    exit
