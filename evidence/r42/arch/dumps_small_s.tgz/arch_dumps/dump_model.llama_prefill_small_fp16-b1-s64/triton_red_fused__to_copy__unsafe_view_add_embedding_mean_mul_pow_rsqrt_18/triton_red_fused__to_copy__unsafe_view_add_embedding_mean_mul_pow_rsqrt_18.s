    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #72]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s1, #1792
    s.rdspecial  s4, arg_base
    s.mul        s5, s2, s1
    s.movz       s1, #16
    s.movz       s2, #1
    s.movz       s6, #0
    s.movz       s7, #128
    s.movz       s8, #32
    s.rdspecial  s9, role_id
    s.rdspecial  s10, npid.x
    s.ld.d       s11, [s4, #0]                   // in_out_ptr0: device_ptr64 at arg_base+0
    s.add        s12, s3, s5                     // this context's own scratch
    s.ld.d       s3, [s4, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.ld.d       s5, [s4, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    s.ld.d       s12, [s4, #24]                  // in_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s13, [s4, #32]                  // in_ptr3: device_ptr64 at arg_base+32
    s.ld.d       s14, [s4, #40]                  // in_ptr4: device_ptr64 at arg_base+40
    s.ld.d       s15, [s4, #48]                  // out_ptr1: device_ptr64 at arg_base+48
__rctx_program:
    s.shli       s4, s9, #3                      // element offset -> bytes (x8)
    v.movi       v0, #0
    v.movi       v1, #1
    v.iota       v2                              // arange(0, VLEN)
    s.add        s16, s3, s4                     // &in_ptr0[...]
    v.splat      v3, s2
    v.movi       v4, #16
    v.shl        v5, v0, v1
    v.movi       v0, #0
    v.movi       v1, #0
    v.movi       v6, #0
    s.addi       s4, s16, #4
    v.cmp.lt     p1, v2, v3
    v.add        v3, v2, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s16, v5]              // index is in elements (ISA sec 9.1)
    s.addi       s16, s6, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s4, v5]               // index is in elements (ISA sec 9.1)
    v.mov        v1, v0
    v.mov        v6, v0
for_1:
    s.cmp.ge     s4, s16, s7
    br.nz        s4, endfor_2
    s.addi       s4, s16, #16
    s.addi       s17, s16, #16
    v.splat      v0, s16
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v8, s4
    v.splat      v9, s16
    s.movz       s18, #64
    s.muli       s19, s9, #256
    v.add        v10, v0, v5
    v.movi       v0, #0
    v.splat      v11, s7
    v.splat      v12, s9
    v.splat      v13, s18
    v.add        v14, v8, v5
    v.add        v8, v9, v5
    s.muli       s18, s16, #2
    s.muli       s20, s4, #2
    s.muli       s4, s16, #2
    v.cmp.ge     p1, v10, v0
    v.cmp.lt     p2, v10, v11
    v.cmp.ge     p3, v12, v0
    v.cmp.lt     p4, v12, v13
    s.add        s21, s11, s19
    p.and        p5, p1, p2
    v.cmp.ge     p1, v14, v0
    p.and        p2, p3, p4
    v.cmp.lt     p3, v14, v11
    p.and        p4, p1, p3
    v.cmp.ge     p1, v8, v0
    s.add        s22, s12, s19
    s.add        s23, s21, s18
    p.and        p3, p5, p2
    s.add        s18, s21, s20
    p.and        p5, p4, p2
    s.add        s20, s22, s4
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s23, #0]
    v.cmp.lt     p3, v8, v11
    p.and        p4, p1, p3
    v.splat      v8, s16
    s.muli       s4, s17, #2
    p.and        p1, p4, p2
    v.splat      v10, s16
    v.add        v12, v8, v2
    v.splat      v8, s17
    s.add        s17, s22, s4
    v.add        v13, v10, v3
    v.add        v10, v8, v5
    s.add        s4, s1, s16
    s.addi       s21, s16, #16
    v.splat      v8, s16
    v.splat      v14, s21
    s.muli       s22, s16, #2
    v.add        v15, v8, v5
    v.add        v8, v14, v5
    s.muli       s23, s21, #2
    v.cmp.ge     p3, v10, v0
    s.add        s21, s13, s19
    v.movi       v14, #0
    s.add        s19, s21, s22
    s.add        s22, s21, s23
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v16, [s18, #0]
    v.cmp.lt     p4, v10, v11
    v.extract    s18, v4, #0
    p.and        p5, p3, p4
    v.cmp.ge     p3, v15, v0
    p.and        p4, p5, p2
    vf.cvt.f16.f32 v10, v9
    v.extract    s21, v7, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v9, [s20, #0]
    v.cmp.lt     p1, v15, v11
    p.and        p5, p3, p1
    v.cmp.ge     p1, v8, v0
    p.and        p3, p5, p2
    vf.cvt.f16.f32 v15, v16
    s.shli       s20, s21, #32
    s.movz       s21, #0
    s.or         s23, s18, s20
    s.movz       s18, #512
    v.movi       v16, #0
    s.cmp.ge     s20, s23, s21
    s.cmp.lt     s24, s23, s18
    v.movi       v17, #1
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v18, [s17, #0]
    v.cmp.lt     p4, v8, v11
    p.and        p5, p1, p4
    s.movz       s17, #1
    p.and        p1, p5, p2
    v.splat      v8, s17
    vf.cvt.f16.f32 v11, v9
    v.cmp.lt     p2, v5, v8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s19, #0]
    vf.cvt.f16.f32 v8, v18
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v9, [s22, #0]
    v.insert     v14, s20, #0
    v.insert     v16, s24, #0
    vf.cvt.f16.f32 v18, v5
    v.cmp.ne     p1, v14, v0
    v.cmp.ne     p3, v16, v0
    p.and        p4, p1, p3
    @p4 v.sel        v5, v0, v17
    @p2 v.reduce.or  s17, v5
    s.cmp.eq     s18, s17, s21
    vf.cvt.f16.f32 v0, v9
    br.nz        s18, assert_ok_3
    trap         #677351
assert_ok_3:
    s.movz       s17, #128
    v.extract    s18, v12, #0
    s.mul        s19, s23, s17
    s.shli       s17, s18, #32
    v.extract    s18, v12, #1
    s.ashri      s20, s17, #32
    v.movi       v5, #0
    v.movi       v9, #0
    v.movi       v14, #0
    v.movi       v16, #0
    s.shli       s17, s18, #32
    s.lshri      s18, s19, #32
    s.lshri      s21, s20, #32
    v.extract    s22, v12, #2
    s.ashri      s23, s17, #32
    v.insert     v5, s19, #0
    v.insert     v9, s18, #0
    v.insert     v14, s20, #0
    v.insert     v16, s21, #0
    s.shli       s17, s22, #32
    s.lshri      s18, s23, #32
    v.extract    s19, v12, #3
    s.ashri      s20, s17, #32
    v.insert     v14, s23, #1
    v.insert     v16, s18, #1
    s.shli       s17, s19, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v12, #4
    s.ashri      s21, s17, #32
    v.insert     v14, s20, #2
    v.insert     v16, s18, #2
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    v.extract    s19, v12, #5
    s.ashri      s20, s17, #32
    v.insert     v14, s21, #3
    v.insert     v16, s18, #3
    s.shli       s17, s19, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v12, #6
    s.ashri      s21, s17, #32
    v.insert     v14, s20, #4
    v.insert     v16, s18, #4
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    v.extract    s19, v12, #7
    s.ashri      s20, s17, #32
    v.insert     v14, s21, #5
    v.insert     v16, s18, #5
    s.shli       s17, s19, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v12, #8
    s.ashri      s21, s17, #32
    v.insert     v14, s20, #6
    v.insert     v16, s18, #6
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    v.extract    s19, v12, #9
    s.ashri      s20, s17, #32
    v.insert     v14, s21, #7
    v.insert     v16, s18, #7
    s.shli       s17, s19, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v12, #10
    s.ashri      s21, s17, #32
    v.insert     v14, s20, #8
    v.insert     v16, s18, #8
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    v.extract    s19, v12, #11
    s.ashri      s20, s17, #32
    v.insert     v14, s21, #9
    v.insert     v16, s18, #9
    s.shli       s17, s19, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v12, #12
    s.ashri      s21, s17, #32
    v.insert     v14, s20, #10
    v.insert     v16, s18, #10
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    v.extract    s19, v12, #13
    s.ashri      s20, s17, #32
    v.insert     v14, s21, #11
    v.insert     v16, s18, #11
    s.shli       s17, s19, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v12, #14
    s.ashri      s21, s17, #32
    v.insert     v14, s20, #12
    v.insert     v16, s18, #12
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    v.extract    s19, v12, #15
    v.extract    s20, v13, #0
    s.ashri      s22, s17, #32
    v.insert     v14, s21, #13
    v.insert     v16, s18, #13
    s.shli       s17, s19, #32
    s.shli       s18, s20, #32
    s.lshri      s19, s22, #32
    v.extract    s20, v13, #1
    s.ashri      s21, s17, #32
    s.ashri      s17, s18, #32
    v.insert     v14, s22, #14
    v.insert     v16, s19, #14
    v.movi       v17, #0
    v.movi       v19, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    s.lshri      s20, s17, #32
    v.extract    s22, v13, #2
    s.ashri      s23, s18, #32
    v.insert     v14, s21, #15
    v.insert     v16, s19, #15
    v.insert     v17, s17, #0
    v.insert     v19, s20, #0
    s.shli       s17, s22, #32
    s.lshri      s18, s23, #32
    v.extract    s19, v13, #3
    s.ashri      s20, s17, #32
    v.insert     v17, s23, #1
    v.insert     v19, s18, #1
    s.shli       s17, s19, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v13, #4
    s.ashri      s21, s17, #32
    v.insert     v17, s20, #2
    v.insert     v19, s18, #2
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    v.extract    s19, v13, #5
    s.ashri      s20, s17, #32
    v.insert     v17, s21, #3
    v.insert     v19, s18, #3
    s.shli       s17, s19, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v13, #6
    s.ashri      s21, s17, #32
    v.insert     v17, s20, #4
    v.insert     v19, s18, #4
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    v.extract    s19, v13, #7
    s.ashri      s20, s17, #32
    v.insert     v17, s21, #5
    v.insert     v19, s18, #5
    s.shli       s17, s19, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v13, #8
    s.ashri      s21, s17, #32
    v.insert     v17, s20, #6
    v.insert     v19, s18, #6
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    v.extract    s19, v13, #9
    s.ashri      s20, s17, #32
    v.insert     v17, s21, #7
    v.insert     v19, s18, #7
    s.shli       s17, s19, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v13, #10
    s.ashri      s21, s17, #32
    v.insert     v17, s20, #8
    v.insert     v19, s18, #8
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    v.extract    s19, v13, #11
    s.ashri      s20, s17, #32
    v.insert     v17, s21, #9
    v.insert     v19, s18, #9
    s.shli       s17, s19, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v13, #12
    s.ashri      s21, s17, #32
    v.insert     v17, s20, #10
    v.insert     v19, s18, #10
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    v.extract    s19, v13, #13
    s.ashri      s20, s17, #32
    v.insert     v17, s21, #11
    v.insert     v19, s18, #11
    s.shli       s17, s19, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v13, #14
    s.ashri      s21, s17, #32
    v.insert     v17, s20, #12
    v.insert     v19, s18, #12
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    v.extract    s19, v13, #15
    v.extract    s20, v9, #0
    s.ashri      s22, s17, #32
    v.insert     v17, s21, #13
    v.insert     v19, s18, #13
    s.shli       s17, s19, #32
    v.extract    s18, v5, #0
    s.shli       s19, s20, #32
    s.lshri      s20, s22, #32
    v.extract    s21, v9, #0
    s.ashri      s23, s17, #32
    s.or         s17, s18, s19
    v.insert     v17, s22, #14
    v.insert     v19, s20, #14
    v.movi       v20, #0
    v.movi       v21, #0
    v.extract    s18, v5, #0
    s.shli       s19, s21, #32
    s.lshri      s20, s23, #32
    s.lshri      s21, s17, #32
    v.extract    s22, v9, #0
    s.or         s24, s18, s19
    v.insert     v17, s23, #15
    v.insert     v19, s20, #15
    v.insert     v20, s17, #0
    v.insert     v21, s21, #0
    v.extract    s17, v5, #0
    s.shli       s18, s22, #32
    s.lshri      s19, s24, #32
    v.extract    s20, v9, #0
    s.or         s21, s17, s18
    v.insert     v20, s24, #1
    v.insert     v21, s19, #1
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v9, #0
    s.or         s22, s17, s18
    v.insert     v20, s21, #2
    v.insert     v21, s19, #2
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s22, #32
    v.extract    s20, v9, #0
    s.or         s21, s17, s18
    v.insert     v20, s22, #3
    v.insert     v21, s19, #3
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v9, #0
    s.or         s22, s17, s18
    v.insert     v20, s21, #4
    v.insert     v21, s19, #4
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s22, #32
    v.extract    s20, v9, #0
    s.or         s21, s17, s18
    v.insert     v20, s22, #5
    v.insert     v21, s19, #5
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v9, #0
    s.or         s22, s17, s18
    v.insert     v20, s21, #6
    v.insert     v21, s19, #6
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s22, #32
    v.extract    s20, v9, #0
    s.or         s21, s17, s18
    v.insert     v20, s22, #7
    v.insert     v21, s19, #7
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v9, #0
    s.or         s22, s17, s18
    v.insert     v20, s21, #8
    v.insert     v21, s19, #8
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s22, #32
    v.extract    s20, v9, #0
    s.or         s21, s17, s18
    v.insert     v20, s22, #9
    v.insert     v21, s19, #9
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v9, #0
    s.or         s22, s17, s18
    v.insert     v20, s21, #10
    v.insert     v21, s19, #10
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s22, #32
    v.extract    s20, v9, #0
    s.or         s21, s17, s18
    v.insert     v20, s22, #11
    v.insert     v21, s19, #11
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v9, #0
    s.or         s22, s17, s18
    v.insert     v20, s21, #12
    v.insert     v21, s19, #12
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s22, #32
    v.extract    s20, v9, #0
    v.extract    s21, v9, #0
    s.or         s23, s17, s18
    v.insert     v20, s22, #13
    v.insert     v21, s19, #13
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    v.extract    s19, v5, #0
    s.shli       s20, s21, #32
    s.lshri      s21, s23, #32
    v.extract    s22, v9, #0
    s.or         s24, s17, s18
    s.or         s17, s19, s20
    v.insert     v20, s23, #14
    v.insert     v21, s21, #14
    v.movi       v22, #0
    v.movi       v23, #0
    v.extract    s18, v5, #0
    s.shli       s19, s22, #32
    s.lshri      s20, s24, #32
    s.lshri      s21, s17, #32
    v.extract    s22, v9, #0
    s.or         s23, s18, s19
    v.insert     v20, s24, #15
    v.insert     v21, s20, #15
    v.insert     v22, s17, #0
    v.insert     v23, s21, #0
    v.extract    s17, v5, #0
    s.shli       s18, s22, #32
    s.lshri      s19, s23, #32
    v.extract    s20, v9, #0
    s.or         s21, s17, s18
    v.insert     v22, s23, #1
    v.insert     v23, s19, #1
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v9, #0
    s.or         s22, s17, s18
    v.insert     v22, s21, #2
    v.insert     v23, s19, #2
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s22, #32
    v.extract    s20, v9, #0
    s.or         s21, s17, s18
    v.insert     v22, s22, #3
    v.insert     v23, s19, #3
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v9, #0
    s.or         s22, s17, s18
    v.insert     v22, s21, #4
    v.insert     v23, s19, #4
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s22, #32
    v.extract    s20, v9, #0
    s.or         s21, s17, s18
    v.insert     v22, s22, #5
    v.insert     v23, s19, #5
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v9, #0
    s.or         s22, s17, s18
    v.insert     v22, s21, #6
    v.insert     v23, s19, #6
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s22, #32
    v.extract    s20, v9, #0
    s.or         s21, s17, s18
    v.insert     v22, s22, #7
    v.insert     v23, s19, #7
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v9, #0
    s.or         s22, s17, s18
    v.insert     v22, s21, #8
    v.insert     v23, s19, #8
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s22, #32
    v.extract    s20, v9, #0
    s.or         s21, s17, s18
    v.insert     v22, s22, #9
    v.insert     v23, s19, #9
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v9, #0
    s.or         s22, s17, s18
    v.insert     v22, s21, #10
    v.insert     v23, s19, #10
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s22, #32
    v.extract    s20, v9, #0
    s.or         s21, s17, s18
    v.insert     v22, s22, #11
    v.insert     v23, s19, #11
    v.extract    s17, v5, #0
    s.shli       s18, s20, #32
    s.lshri      s19, s21, #32
    v.extract    s20, v9, #0
    s.or         s22, s17, s18
    v.extract    s17, v16, #0
    v.extract    s18, v21, #0
    v.insert     v22, s21, #12
    v.insert     v23, s19, #12
    v.extract    s19, v5, #0
    s.shli       s21, s20, #32
    s.lshri      s20, s22, #32
    v.extract    s23, v9, #0
    s.shli       s24, s17, #32
    s.shli       s17, s18, #32
    s.or         s18, s19, s21
    v.extract    s19, v14, #0
    v.insert     v22, s22, #13
    v.extract    s21, v20, #0
    v.insert     v23, s20, #13
    v.extract    s20, v16, #1
    s.shli       s22, s23, #32
    s.or         s23, s19, s24
    v.extract    s19, v21, #1
    s.or         s24, s21, s17
    v.extract    s17, v5, #0
    s.shli       s21, s20, #32
    s.shli       s20, s19, #32
    s.or         s19, s17, s22
    s.lshri      s17, s18, #32
    s.add        s22, s23, s24
    v.extract    s23, v14, #1
    v.insert     v22, s18, #14
    v.extract    s18, v20, #1
    v.insert     v23, s17, #14
    v.extract    s17, v16, #2
    v.movi       v5, #0
    v.movi       v9, #0
    s.or         s24, s23, s21
    v.extract    s21, v21, #2
    s.or         s23, s18, s20
    s.lshri      s18, s19, #32
    s.shli       s20, s17, #32
    s.shli       s17, s21, #32
    s.add        s21, s24, s23
    s.lshri      s23, s22, #32
    v.insert     v22, s19, #15
    v.extract    s19, v14, #2
    v.insert     v23, s18, #15
    v.extract    s18, v20, #2
    v.insert     v5, s22, #0
    v.extract    s22, v16, #3
    v.insert     v9, s23, #0
    v.extract    s23, v21, #3
    s.or         s24, s19, s20
    s.or         s19, s18, s17
    s.lshri      s17, s21, #32
    v.extract    s18, v14, #3
    s.shli       s20, s22, #32
    s.shli       s22, s23, #32
    s.add        s23, s24, s19
    v.extract    s19, v20, #3
    v.insert     v5, s21, #1
    v.extract    s21, v16, #4
    v.insert     v9, s17, #1
    v.extract    s17, v21, #4
    s.or         s24, s18, s20
    s.or         s18, s19, s22
    s.lshri      s19, s23, #32
    v.extract    s20, v14, #4
    s.shli       s22, s21, #32
    s.shli       s21, s17, #32
    s.add        s17, s24, s18
    v.extract    s18, v20, #4
    v.insert     v5, s23, #2
    v.extract    s23, v16, #5
    v.insert     v9, s19, #2
    v.extract    s19, v21, #5
    s.or         s24, s20, s22
    s.or         s20, s18, s21
    s.lshri      s18, s17, #32
    v.extract    s21, v14, #5
    s.shli       s22, s23, #32
    s.shli       s23, s19, #32
    s.add        s19, s24, s20
    v.extract    s20, v20, #5
    v.insert     v5, s17, #3
    v.extract    s17, v16, #6
    v.insert     v9, s18, #3
    v.extract    s18, v21, #6
    s.or         s24, s21, s22
    s.or         s21, s20, s23
    s.lshri      s20, s19, #32
    v.extract    s22, v14, #6
    s.shli       s23, s17, #32
    s.shli       s17, s18, #32
    s.add        s18, s24, s21
    v.extract    s21, v20, #6
    v.insert     v5, s19, #4
    v.extract    s19, v16, #7
    v.insert     v9, s20, #4
    v.extract    s20, v21, #7
    s.or         s24, s22, s23
    s.or         s22, s21, s17
    s.lshri      s17, s18, #32
    v.extract    s21, v14, #7
    s.shli       s23, s19, #32
    s.shli       s19, s20, #32
    s.add        s20, s24, s22
    v.extract    s22, v20, #7
    v.insert     v5, s18, #5
    v.extract    s18, v16, #8
    v.insert     v9, s17, #5
    v.extract    s17, v21, #8
    s.or         s24, s21, s23
    s.or         s21, s22, s19
    s.lshri      s19, s20, #32
    v.extract    s22, v14, #8
    s.shli       s23, s18, #32
    s.shli       s18, s17, #32
    s.add        s17, s24, s21
    v.extract    s21, v20, #8
    v.insert     v5, s20, #6
    v.extract    s20, v16, #9
    v.insert     v9, s19, #6
    v.extract    s19, v21, #9
    s.or         s24, s22, s23
    s.or         s22, s21, s18
    s.lshri      s18, s17, #32
    v.extract    s21, v14, #9
    s.shli       s23, s20, #32
    s.shli       s20, s19, #32
    s.add        s19, s24, s22
    v.extract    s22, v20, #9
    v.insert     v5, s17, #7
    v.extract    s17, v16, #10
    v.insert     v9, s18, #7
    v.extract    s18, v21, #10
    s.or         s24, s21, s23
    s.or         s21, s22, s20
    s.lshri      s20, s19, #32
    v.extract    s22, v14, #10
    s.shli       s23, s17, #32
    s.shli       s17, s18, #32
    s.add        s18, s24, s21
    v.extract    s21, v20, #10
    v.insert     v5, s19, #8
    v.extract    s19, v16, #11
    v.insert     v9, s20, #8
    v.extract    s20, v21, #11
    s.or         s24, s22, s23
    s.or         s22, s21, s17
    s.lshri      s17, s18, #32
    v.extract    s21, v14, #11
    s.shli       s23, s19, #32
    s.shli       s19, s20, #32
    s.add        s20, s24, s22
    v.extract    s22, v20, #11
    v.insert     v5, s18, #9
    v.extract    s18, v16, #12
    v.insert     v9, s17, #9
    v.extract    s17, v21, #12
    s.or         s24, s21, s23
    s.or         s21, s22, s19
    s.lshri      s19, s20, #32
    v.extract    s22, v14, #12
    s.shli       s23, s18, #32
    s.shli       s18, s17, #32
    s.add        s17, s24, s21
    v.extract    s21, v20, #12
    v.insert     v5, s20, #10
    v.extract    s20, v16, #13
    v.insert     v9, s19, #10
    v.extract    s19, v21, #13
    s.or         s24, s22, s23
    s.or         s22, s21, s18
    s.lshri      s18, s17, #32
    v.extract    s21, v14, #13
    s.shli       s23, s20, #32
    s.shli       s20, s19, #32
    s.add        s19, s24, s22
    v.extract    s22, v20, #13
    v.insert     v5, s17, #11
    v.extract    s17, v16, #14
    v.insert     v9, s18, #11
    v.extract    s18, v21, #14
    s.or         s24, s21, s23
    s.or         s21, s22, s20
    s.lshri      s20, s19, #32
    v.extract    s22, v14, #14
    s.shli       s23, s17, #32
    s.shli       s17, s18, #32
    s.add        s18, s24, s21
    v.extract    s21, v20, #14
    v.insert     v5, s19, #12
    v.extract    s19, v16, #15
    v.insert     v9, s20, #12
    v.extract    s20, v21, #15
    s.or         s24, s22, s23
    v.extract    s22, v19, #0
    s.or         s23, s21, s17
    v.extract    s17, v23, #0
    s.shli       s21, s19, #32
    s.shli       s19, s20, #32
    s.shli       s20, s22, #32
    s.shli       s22, s17, #32
    s.add        s17, s24, s23
    s.lshri      s23, s18, #32
    v.insert     v5, s18, #13
    v.extract    s18, v14, #15
    v.insert     v9, s23, #13
    v.extract    s23, v20, #15
    s.or         s24, s18, s21
    v.extract    s18, v17, #0
    s.or         s21, s23, s19
    v.extract    s19, v22, #0
    s.or         s23, s18, s20
    v.extract    s18, v19, #1
    s.or         s20, s19, s22
    v.extract    s19, v23, #1
    s.shli       s22, s18, #32
    s.shli       s18, s19, #32
    s.add        s19, s24, s21
    s.lshri      s21, s17, #32
    s.add        s24, s23, s20
    v.extract    s20, v17, #1
    v.insert     v5, s17, #14
    v.extract    s17, v22, #1
    v.insert     v9, s21, #14
    v.extract    s21, v19, #2
    v.movi       v14, #0
    v.movi       v16, #0
    s.or         s23, s20, s22
    v.extract    s20, v23, #2
    s.or         s22, s17, s18
    s.lshri      s17, s19, #32
    s.shli       s18, s21, #32
    s.shli       s21, s20, #32
    s.add        s20, s23, s22
    s.lshri      s22, s24, #32
    v.insert     v5, s19, #15
    v.extract    s19, v17, #2
    v.insert     v9, s17, #15
    v.extract    s17, v22, #2
    v.insert     v14, s24, #0
    v.extract    s23, v19, #3
    v.insert     v16, s22, #0
    v.extract    s22, v23, #3
    s.or         s24, s19, s18
    s.or         s18, s17, s21
    s.lshri      s17, s20, #32
    v.extract    s19, v17, #3
    s.shli       s21, s23, #32
    s.shli       s23, s22, #32
    s.add        s22, s24, s18
    v.extract    s18, v22, #3
    v.insert     v14, s20, #1
    v.extract    s20, v19, #4
    v.insert     v16, s17, #1
    v.extract    s17, v23, #4
    s.or         s24, s19, s21
    s.or         s19, s18, s23
    s.lshri      s18, s22, #32
    v.extract    s21, v17, #4
    s.shli       s23, s20, #32
    s.shli       s20, s17, #32
    s.add        s17, s24, s19
    v.extract    s19, v22, #4
    v.insert     v14, s22, #2
    v.extract    s22, v19, #5
    v.insert     v16, s18, #2
    v.extract    s18, v23, #5
    s.or         s24, s21, s23
    s.or         s21, s19, s20
    s.lshri      s19, s17, #32
    v.extract    s20, v17, #5
    s.shli       s23, s22, #32
    s.shli       s22, s18, #32
    s.add        s18, s24, s21
    v.extract    s21, v22, #5
    v.insert     v14, s17, #3
    v.extract    s17, v19, #6
    v.insert     v16, s19, #3
    v.extract    s19, v23, #6
    s.or         s24, s20, s23
    s.or         s20, s21, s22
    s.lshri      s21, s18, #32
    v.extract    s22, v17, #6
    s.shli       s23, s17, #32
    s.shli       s17, s19, #32
    s.add        s19, s24, s20
    v.extract    s20, v22, #6
    v.insert     v14, s18, #4
    v.extract    s18, v19, #7
    v.insert     v16, s21, #4
    v.extract    s21, v23, #7
    s.or         s24, s22, s23
    s.or         s22, s20, s17
    s.lshri      s17, s19, #32
    v.extract    s20, v17, #7
    s.shli       s23, s18, #32
    s.shli       s18, s21, #32
    s.add        s21, s24, s22
    v.extract    s22, v22, #7
    v.insert     v14, s19, #5
    v.extract    s19, v19, #8
    v.insert     v16, s17, #5
    v.extract    s17, v23, #8
    s.or         s24, s20, s23
    s.or         s20, s22, s18
    s.lshri      s18, s21, #32
    v.extract    s22, v17, #8
    s.shli       s23, s19, #32
    s.shli       s19, s17, #32
    s.add        s17, s24, s20
    v.extract    s20, v22, #8
    v.insert     v14, s21, #6
    v.extract    s21, v19, #9
    v.insert     v16, s18, #6
    v.extract    s18, v23, #9
    s.or         s24, s22, s23
    s.or         s22, s20, s19
    s.lshri      s19, s17, #32
    v.extract    s20, v17, #9
    s.shli       s23, s21, #32
    s.shli       s21, s18, #32
    s.add        s18, s24, s22
    v.extract    s22, v22, #9
    v.insert     v14, s17, #7
    v.extract    s17, v19, #10
    v.insert     v16, s19, #7
    v.extract    s19, v23, #10
    s.or         s24, s20, s23
    s.or         s20, s22, s21
    s.lshri      s21, s18, #32
    v.extract    s22, v17, #10
    s.shli       s23, s17, #32
    s.shli       s17, s19, #32
    s.add        s19, s24, s20
    v.extract    s20, v22, #10
    v.insert     v14, s18, #8
    v.extract    s18, v19, #11
    v.insert     v16, s21, #8
    v.extract    s21, v23, #11
    s.or         s24, s22, s23
    s.or         s22, s20, s17
    s.lshri      s17, s19, #32
    v.extract    s20, v17, #11
    s.shli       s23, s18, #32
    s.shli       s18, s21, #32
    s.add        s21, s24, s22
    v.extract    s22, v22, #11
    v.insert     v14, s19, #9
    v.extract    s19, v19, #12
    v.insert     v16, s17, #9
    v.extract    s17, v23, #12
    s.or         s24, s20, s23
    s.or         s20, s22, s18
    s.lshri      s18, s21, #32
    v.extract    s22, v17, #12
    s.shli       s23, s19, #32
    s.shli       s19, s17, #32
    s.add        s17, s24, s20
    v.extract    s20, v22, #12
    v.insert     v14, s21, #10
    v.extract    s21, v19, #13
    v.insert     v16, s18, #10
    v.extract    s18, v23, #13
    s.or         s24, s22, s23
    s.or         s22, s20, s19
    s.lshri      s19, s17, #32
    v.extract    s20, v17, #13
    s.shli       s23, s21, #32
    s.shli       s21, s18, #32
    s.add        s18, s24, s22
    v.extract    s22, v22, #13
    v.insert     v14, s17, #11
    v.extract    s17, v19, #14
    v.insert     v16, s19, #11
    v.movi       v20, #31
    v.extract    s19, v23, #14
    s.or         s24, s20, s23
    s.or         s20, s22, s21
    s.lshri      s21, s18, #32
    v.extract    s22, v17, #14
    s.shli       s23, s17, #32
    s.shli       s17, s19, #32
    v.ashr       v21, v5, v20
    s.add        s19, s24, s20
    v.extract    s20, v22, #14
    v.movi       v20, #1
    v.movi       v24, #0
    v.insert     v14, s18, #12
    v.extract    s18, v19, #15
    v.insert     v16, s21, #12
    v.extract    s21, v23, #15
    s.or         s24, s22, s23
    s.or         s22, s20, s17
    s.lshri      s17, s19, #32
    v.extract    s20, v17, #15
    s.shli       s23, s18, #32
    s.shli       s18, s21, #32
    v.cmp.ne     p1, v9, v21
    s.add        s21, s24, s22
    v.extract    s22, v22, #15
    @p1 v.sel        v9, v20, v24
    v.insert     v14, s19, #13
    v.insert     v16, s17, #13
    s.or         s17, s20, s23
    s.or         s19, s22, s18
    s.lshri      s18, s21, #32
    s.add        s20, s17, s19
    v.reduce.or  s17, v9
    s.movz       s19, #0
    v.insert     v14, s21, #14
    v.insert     v16, s18, #14
    s.lshri      s18, s20, #32
    s.cmp.eq     s21, s17, s19
    v.insert     v14, s20, #15
    v.insert     v16, s18, #15
    br.nz        s21, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v9, #31
    v.movi       v17, #1
    v.movi       v19, #0
    v.ashr       v20, v14, v9
    v.cmp.ne     p1, v16, v20
    @p1 v.sel        v9, v17, v19
    v.reduce.or  s17, v9
    s.cmp.eq     s18, s17, s19
    br.nz        s18, narrow_ok_5
    trap         #677220
narrow_ok_5:
    v.movi       v9, #128
    s.mul        s17, s9, s7
    v.cmp.lt     p1, v12, v9
    v.cmp.lt     p2, v13, v9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s5, v5]               // index is in elements (ISA sec 9.1)
    s.add        s18, s16, s17
    s.add        s19, s4, s17
    s.shli       s4, s18, #1                     // element offset -> bytes (x2)
    s.shli       s17, s19, #1                    // element offset -> bytes (x2)
    s.add        s18, s11, s4                    // &in_out_ptr0[...]
    s.add        s4, s11, s17                    // &in_out_ptr0[...]
    s.movz       s17, #1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v5, [s5, v14]              // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v12, v9
    vf.add       v9, v12, v10
    vf.add       v10, v9, v11
    vf.cvt.f16.f32 v9, v5
    vf.add       v5, v10, v18
    vf.add       v10, v9, v15
    vf.mul       v9, v5, v5
    vf.cvt.f32.f16 v11, v5
    vf.add       v5, v10, v8
    vf.add       v8, v1, v9
    @p1 v.st.h       [s18, #0], v11
    vf.add       v9, v5, v0
    @p1 v.sel        v1, v8, v1
    vf.mul       v0, v9, v9
    vf.cvt.f32.f16 v5, v9
    vf.add       v8, v6, v0
    @p2 v.st.h       [s4, #0], v5
    @p2 v.sel        v6, v8, v6
    s.add        s16, s16, s8
    br.nz        s17, for_1
endfor_2:
    .li       s4, #1124073472
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #1065353216
    v.splat      v2, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.add.b v3, v1
    v.rcp.approx v1, v0                          // ISA 8.8: <= 2**-22 relative
    vf.reduce.add.b v4, v6
    v.movi       v5, #0
    .li       s4, #925353388
    v.splat      v6, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v7, v3, v4
    .li       s4, #1077936128
    v.splat      v3, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #3204448256
    v.splat      v4, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s4, s9, s7
    s.addi       s16, s6, #0
    vf.add       v8, v7, v5
    s.muli       s17, s9, #256
    s.movz       s18, #64
    s.muli       s19, s16, #2
    v.splat      v5, s9
    s.add        s20, s16, s4
    s.add        s4, s11, s17
    s.shli       s17, s16, #1                    // element offset -> bytes (x2)
    s.shli       s21, s20, #1                    // element offset -> bytes (x2)
    s.movz       s20, #1
    s.add        s20, s4, s19
    s.add        s4, s14, s17                    // &in_ptr4[...]
    s.add        s17, s15, s21                   // &out_ptr1[...]
    vf.fms       v7, v0, v1, v2
    v.movi       v0, #0
    v.cmp.ge     p1, v5, v0
    vf.fms       v0, v1, v7, v1
    v.splat      v2, s18
    v.cmp.lt     p2, v5, v2
    vf.neg       v2, v0                          // Newton step: r0*(2 - x*r0)
    p.and        p3, p1, p2
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v1
    vf.mul       v1, v8, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v0, v1, v6
    v.rsqrt.approx v1, v0                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v2, v1, v1
    vf.mul       v5, v1, v4
    vf.fms       v4, v0, v2, v3
    vf.mul       v0, v5, v4                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v2, v0, v1
    v.extract    s18, v2, #0
    v.splat      v0, s18
for_6:
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s20, #0]
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s20, #32]
    vf.cvt.f16.f32 v3, v1
    vf.mul       v1, v3, v0
    v.ld.h       v3, [s4, #0]
    vf.cvt.f16.f32 v4, v2
    vf.mul       v2, v4, v0
    v.ld.h       v4, [s4, #32]
    vf.cvt.f16.f32 v5, v3
    vf.mul       v3, v1, v5
    vf.cvt.f32.f16 v1, v3
    vf.cvt.f16.f32 v3, v4
    v.st.h       [s17, #0], v1
    vf.mul       v1, v2, v3
    vf.cvt.f32.f16 v2, v1
    v.st.h       [s17, #32], v2
    s.addi       s20, s20, #64                   // the next iteration's address
    s.addi       s4, s4, #64                     // the next iteration's address
    s.addi       s17, s17, #64                   // the next iteration's address
    s.add        s16, s16, s8
    s.cmp.lt     s18, s16, s7
    br.nz        s18, for_6
endfor_7:
__rctx_next:
    s.addi       s4, s9, #2                      // the next program of this context: + 2
    s.cmp.lt     s16, s4, s10
    s.mov        s9, s4
    br.nz        s16, __rctx_program
    exit
