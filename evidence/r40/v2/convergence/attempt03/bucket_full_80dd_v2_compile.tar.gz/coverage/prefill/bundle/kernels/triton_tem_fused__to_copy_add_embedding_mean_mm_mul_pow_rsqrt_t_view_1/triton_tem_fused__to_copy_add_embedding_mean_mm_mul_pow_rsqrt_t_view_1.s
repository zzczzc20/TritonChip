    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s4, #512
    .li       s5, #2147483647
    s.mul        s6, s1, s4
    .li       s1, #2147483647
    s.movz       s4, #2048
    s.movz       s7, #2
    .li       s8, #68719476752
    .li       s9, #8589934592
    s.rdspecial  s10, arg_base
    s.ld.d       s11, [s2, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.add        s12, s3, s6                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s6, s12, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s12, #512
    .li       s13, #2147483647
    s.mul        s14, s3, s12
    .li       s3, #2147483647
    s.movz       s12, #2048
    s.movz       s15, #2
    .li       s16, #68719476752
    s.ld.d       s17, [s2, #8]                   // arg_B: device_ptr64 at arg_base+8
    s.movz       s18, #64
    .li       s19, #8589934592
    s.movz       s20, #0
    s.movz       s20, #0
    s.ld.d       s20, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.movz       s2, #0
    s.cmp.lt     s21, s18, s2
    s.st.d       [s6, #0], s11
    s.movz       s2, #0
    s.sub        s11, s2, s21
    s.movz       s2, #0
    s.st.d       [s6, #8], s5
    s.xor        s5, s18, s11
    s.sub        s21, s5, s11
    s.movz       s5, #0
    s.st.d       [s6, #16], s1
    s.movz       s1, #32
    s.st.d       [s6, #48], s4
    s.movz       s4, #1
    s.st.d       [s6, #56], s7
    s.movz       s7, #0
    s.st.d       [s6, #88], s8
    s.movz       s8, #0
    s.st.d       [s6, #104], s9
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s6, #0
    s.movz       s9, #0
    s.ld.d       s21, [s10, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s10, s21, s14                   // this context's own scratch
    s.movz       s14, #0
    s.addi       s21, s10, #256                  // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.st.d       [s21, #0], s17
    s.movz       s10, #0
    s.st.d       [s21, #8], s13
    s.movz       s13, #1
    s.st.d       [s21, #16], s3
    s.rdspecial  s3, role_id
    s.st.d       [s21, #48], s12
    s.rdspecial  s12, npid.x
    s.st.d       [s21, #56], s15
    s.st.d       [s21, #88], s16
    s.st.d       [s21, #104], s19
    fence.release.device
    td.load      d1, [s21]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
__rctx_program:
    s.cmp.lt     s15, s3, s5
    s.cmp.lt     s16, s3, s8
    s.sub        s17, s2, s15
    s.sub        s15, s7, s16
    s.xor        s16, s3, s17
    s.xor        s19, s17, s11
    s.sub        s21, s16, s17
    s.xor        s16, s3, s15
    s.lshri      s17, s21, #6
    s.sub        s22, s16, s15
    s.xor        s16, s17, s19
    s.muli       s23, s17, #64
    s.sub        s17, s16, s19
    s.addi       s16, s14, #0
    s.sub        s19, s1, s17
    s.addi       s24, s10, #0
    s.min.s      s25, s19, s4
    s.sub        s19, s21, s23
    s.cmp.lt     s19, s25, s9
    s.mov        s16, s22
    s.sub        s21, s6, s19
    s.xor        s19, s25, s21
    s.sub        s23, s19, s21
    s.cmp.eq     s19, s23, s13
    br.nz        s19, sdiv_done_1
    s.movz       s19, #0
    s.movz       s21, #31
    s.mov        s16, s19
    s.addi       s19, s21, #0
sdiv_2:
    s.lshr       s21, s22, s19
    s.shli       s26, s24, #1
    s.andi       s27, s21, #1
    s.movz       s21, #0
    s.or         s28, s26, s27
    s.movz       s26, #1
    s.cmp.geu    s27, s28, s23
    s.shl        s29, s26, s19
    s.sub        s26, s21, s27
    s.subi       s21, s19, #1
    s.and        s27, s23, s26
    s.and        s30, s29, s26
    s.sub        s26, s28, s27
    s.or         s27, s16, s30
    s.mov        s24, s26
    s.mov        s16, s27
    s.mov        s19, s21
    s.movz       s21, #0
    s.cmp.ge     s26, s19, s21
    br.nz        s26, sdiv_2
sdiv_done_1:
    s.movz       s16, #0
    s.movz       s19, #0
    s.cmp.lt     s21, s3, s16
    s.movz       s16, #0
    s.sub        s22, s19, s21
    s.movz       s19, #0
    s.xor        s21, s3, s22
    s.movz       s23, #0
    s.sub        s26, s21, s22
    s.cmp.lt     s21, s25, s16
    s.lshri      s16, s26, #6
    s.movz       s27, #0
    s.muli       s28, s16, #64
    s.movz       s16, #0
    s.sub        s29, s23, s21
    s.movz       s21, #0
    s.cmp.lt     s23, s18, s27
    s.sub        s27, s26, s28
    s.xor        s26, s25, s29
    s.xor        s25, s27, s22
    s.xor        s27, s24, s15
    s.sub        s24, s25, s22
    s.sub        s22, s21, s23
    s.cmp.lt     s21, s24, s19
    s.sub        s19, s26, s29
    s.sub        s23, s16, s21
    s.movz       s16, #0
    s.xor        s21, s24, s23
    s.movz       s24, #1
    s.sub        s25, s27, s15
    s.xor        s15, s18, s22
    s.sub        s26, s21, s23
    s.movz       s21, #0
    s.addi       s27, s16, #0
    s.cmp.eq     s16, s19, s24
    s.add        s24, s17, s25
    s.sub        s17, s15, s22
    s.addi       s15, s21, #0
    s.mov        s27, s26
    br.nz        s16, sdiv_done_3
    s.movz       s16, #0
    s.movz       s17, #31
    s.mov        s27, s16
    s.addi       s16, s17, #0
sdiv_4:
    s.lshr       s17, s26, s16
    s.shli       s21, s15, #1
    s.andi       s22, s17, #1
    s.movz       s17, #0
    s.or         s25, s21, s22
    s.movz       s21, #1
    s.cmp.geu    s22, s25, s19
    s.shl        s28, s21, s16
    s.sub        s21, s17, s22
    s.subi       s17, s16, #1
    s.and        s22, s19, s21
    s.and        s30, s28, s21
    s.sub        s21, s25, s22
    s.or         s22, s27, s30
    s.mov        s15, s21
    s.mov        s27, s22
    s.mov        s16, s17
    s.movz       s17, #0
    s.cmp.ge     s21, s16, s17
    br.nz        s21, sdiv_4
sdiv_done_3:
    s.xor        s15, s23, s29
    s.movz       s16, #16
    s.xor        s17, s27, s15
    s.mul        s19, s24, s16
    s.sub        s21, s17, s15
    s.movz       s15, #0
    s.mul        s17, s21, s16
    v.splat      v0, s24
    s.andi       s22, s19, #511
    v.splat      v1, s15
    v.splat      v2, s21
    s.andi       s21, s17, #1023
    v.splat      v3, s15
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s19
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s17
    v.splat      v1, s22
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s21
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.addi       s23, s15, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s15, s23, s18
    br.nz        s15, endfor_6
    s.mul        s15, s23, s16
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s24, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s25, s23, s4
    s.movz       s26, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s27, s22                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s15                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s27, s24
    mb.wait      s24
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s27, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s28, s21                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s15                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s28, s27
    mb.wait      s27
    mb.arm       s15, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s15
    mb.wait      s15
    s.mov        s23, s25
    br.nz        s26, for_5
endfor_6:
    s.movz       s16, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s21, #0
    s.add        s22, s16, s17                   // the tile origin
    s.movz       s16, #0
    s.muli       s23, s17, #2                    // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s22
    a.vread      v2, a0, s21
    s.add        s17, s16, s19                   // the tile origin
    s.movz       s16, #512
    s.movz       s21, #1024
    s.muli       s22, s19, #2048                 // a runtime tile origin, x2048
    v.splat      v3, s17
    v.splat      v4, s16
    v.add        v5, v0, v1
    v.splat      v0, s21
    vf.cvt.f32.f16 v1, v2
    s.add        s16, s20, s23                   // the tile origin
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s19, s16, s22                   // the tile origin
    p.and        p3, p1, p2
    s.movz       s16, #1
    @p3 v.st.h       [s19, #0], v1
    a.vread      v0, a0, s16
    s.addi       s16, s17, #1
    s.addi       s21, s19, #2048                 // row 1
    v.splat      v1, s16
    vf.cvt.f32.f16 v2, v0
    s.movz       s16, #2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s22, s17, #2
    s.addi       s23, s19, #4096                 // row 2
    v.splat      v0, s22
    s.movz       s22, #3
    s.addi       s25, s17, #3
    @p3 v.st.h       [s21, #0], v2
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    v.splat      v1, s25
    s.addi       s16, s19, #6144                 // row 3
    s.movz       s21, #4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    s.addi       s25, s17, #4
    s.addi       s26, s19, #8192                 // row 4
    v.splat      v1, s25
    s.movz       s25, #5
    @p3 v.st.h       [s23, #0], v0
    a.vread      v0, a0, s22
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s22, s17, #5
    s.addi       s23, s19, #10240                // row 5
    v.splat      v0, s22
    s.movz       s22, #6
    @p4 v.st.h       [s16, #0], v1
    a.vread      v1, a0, s21
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s16, s17, #6
    s.addi       s21, s19, #12288                // row 6
    v.splat      v1, s16
    s.movz       s16, #7
    @p3 v.st.h       [s26, #0], v0
    a.vread      v0, a0, s25
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s25, s17, #7
    s.addi       s26, s19, #14336                // row 7
    v.splat      v0, s25
    s.movz       s25, #8
    @p4 v.st.h       [s23, #0], v1
    a.vread      v1, a0, s22
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s22, s17, #8
    s.addi       s23, s19, #16384                // row 8
    v.splat      v1, s22
    s.movz       s22, #9
    @p3 v.st.h       [s21, #0], v0
    a.vread      v0, a0, s16
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s16, s17, #9
    s.addi       s21, s19, #18432                // row 9
    v.splat      v0, s16
    s.movz       s16, #10
    @p4 v.st.h       [s26, #0], v1
    a.vread      v1, a0, s25
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s25, s17, #10
    s.addi       s26, s19, #20480                // row 10
    v.splat      v1, s25
    s.movz       s25, #11
    @p3 v.st.h       [s23, #0], v0
    a.vread      v0, a0, s22
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s22, s17, #11
    s.addi       s23, s19, #22528                // row 11
    v.splat      v0, s22
    s.movz       s22, #12
    @p4 v.st.h       [s21, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s16, s17, #12
    s.addi       s21, s19, #24576                // row 12
    v.splat      v1, s16
    s.movz       s16, #13
    @p3 v.st.h       [s26, #0], v0
    a.vread      v0, a0, s25
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s25, s17, #13
    s.addi       s26, s19, #26624                // row 13
    v.splat      v0, s25
    s.movz       s25, #14
    @p4 v.st.h       [s23, #0], v1
    a.vread      v1, a0, s22
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s22, s17, #14
    s.addi       s23, s19, #28672                // row 14
    v.splat      v1, s22
    s.movz       s22, #15
    s.addi       s28, s17, #15
    s.addi       s17, s19, #30720                // row 15
    v.splat      v2, s28
    @p3 v.st.h       [s21, #0], v0
    a.vread      v0, a0, s16
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s26, #0], v1
    a.vread      v0, a0, s25
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v0
    @p3 v.st.h       [s23, #0], v1
    a.vread      v0, a0, s22
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s17, #0], v1
__rctx_next:
    s.addi       s16, s3, #2                     // the next program of this context: + 2
    s.cmp.lt     s17, s16, s12
    s.mov        s3, s16
    br.nz        s17, __rctx_program
    exit
