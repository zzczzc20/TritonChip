    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #768
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s8, #0
    s.st.d       [s7, #0], s2
    s.movz       s8, #512
    s.st.d       [s7, #8], s8
    s.movz       s8, #1024
    s.st.d       [s7, #16], s8
    s.movz       s8, #2048
    s.st.d       [s7, #48], s8
    s.movz       s8, #2
    s.st.d       [s7, #56], s8
    .li       s8, #68719476737
    s.st.d       [s7, #88], s8
    .li       s8, #8589934592
    s.st.d       [s7, #104], s8
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s7, s1, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s8, #0
    s.st.d       [s7, #0], s3
    s.movz       s8, #512
    s.st.d       [s7, #8], s8
    s.movz       s8, #1024
    s.st.d       [s7, #16], s8
    s.movz       s8, #2048
    s.st.d       [s7, #48], s8
    s.movz       s8, #2
    s.st.d       [s7, #56], s8
    .li       s8, #68719476737
    s.st.d       [s7, #88], s8
    .li       s8, #8589934592
    s.st.d       [s7, #104], s8
    fence.release.device
    td.load      d1, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s7, s1, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s7, #0], s4
    s.movz       s1, #512
    s.st.d       [s7, #8], s1
    s.movz       s1, #1024
    s.st.d       [s7, #16], s1
    s.movz       s1, #2048
    s.st.d       [s7, #48], s1
    s.movz       s1, #2
    s.st.d       [s7, #56], s1
    .li       s1, #68719476737
    s.st.d       [s7, #88], s1
    .li       s1, #8589934592
    s.st.d       [s7, #104], s1
    fence.release.device
    td.load      d2, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s7, #1024
    s.movz       s8, #16
    s.rdspecial  s9, role_id
    s.rdspecial  s10, npid.x
__rctx_program:
    v.movi       v0, #0
    v.movi       v1, #0
    v.splat      v2, s9
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s11, s1, #0
    v.mov        v1, v0
for_1:
    s.cmp.ge     s12, s11, s7
    br.nz        s12, endfor_2
    v.splat      v0, s11
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s11
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s12, #1024
    s.movz       s13, #512
    s.movz       s14, #1024
    s.movz       s15, #512
    s.muli       s16, s9, #2048
    s.muli       s17, s9, #2048
    v.add        v6, v0, v3
    v.movi       v0, #0
    v.splat      v3, s12
    v.splat      v7, s9
    v.movi       v8, #0
    v.splat      v9, s13
    v.add        v10, v4, v5
    v.movi       v4, #0
    s.muli       s12, s11, #2
    s.muli       s13, s11, #2
    v.cmp.ge     p1, v6, v0
    v.splat      v0, s14
    v.cmp.lt     p2, v6, v3
    v.splat      v3, s9
    v.movi       v5, #0
    v.cmp.ge     p3, v7, v8
    v.splat      v6, s15
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s14, s2, s16
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v0
    p.and        p2, p3, p4
    v.cmp.ge     p3, v3, v5
    s.add        s15, s3, s17
    p.and        p4, p5, p1
    v.cmp.lt     p1, v3, v6
    p.and        p5, p3, p1
    s.add        s16, s14, s12
    p.and        p1, p6, p2
    s.add        s12, s15, s13
    p.and        p2, p4, p5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s16, #0]
    v.splat      v3, s11
    v.movi       v4, #1024
    v.add        v5, v3, v2
    s.muli       s13, s9, #2048
    v.cmp.lt     p1, v5, v4
    v.splat      v3, s11
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s14, #1024
    s.movz       s15, #512
    v.add        v5, v3, v4
    v.movi       v3, #0
    v.splat      v4, s14
    v.splat      v6, s9
    v.movi       v7, #0
    v.splat      v8, s15
    s.muli       s14, s11, #2
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v9, [s12, #0]
    v.cmp.ge     p2, v5, v3
    v.cmp.lt     p3, v5, v4
    v.cmp.ge     p4, v6, v7
    v.cmp.lt     p5, v6, v8
    s.add        s12, s4, s13
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.add        s13, s12, s14
    p.and        p3, p6, p2
    vf.cvt.f16.f32 v3, v0
    v.movi       v0, #0
    s.add        s12, s11, s8
    s.movz       s14, #1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s13, #0]
    vf.cvt.f16.f32 v5, v9
    vf.add       v6, v3, v5
    vf.cvt.f16.f32 v3, v4
    vf.add       v4, v6, v3
    vf.mul       v3, v4, v4
    vf.add       v4, v1, v3
    @p1 v.sel        v3, v4, v1
    v.mov        v0, v3
    v.mov        v1, v0
    s.mov        s11, s12
    br.nz        s14, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s11, s1, #0
    vf.add       v3, v0, v1
for_3:
    s.cmp.ge     s12, s11, s7
    br.nz        s12, endfor_4
    v.splat      v0, s11
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v4, s11
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s12, #1024
    s.movz       s13, #512
    s.movz       s14, #1024
    s.movz       s15, #512
    s.muli       s16, s9, #2048
    s.muli       s17, s9, #2048
    v.add        v6, v0, v1
    v.movi       v0, #0
    v.splat      v1, s12
    v.splat      v7, s9
    v.movi       v8, #0
    v.splat      v9, s13
    v.add        v10, v4, v5
    v.movi       v4, #0
    v.splat      v5, s14
    s.muli       s12, s11, #2
    s.muli       s13, s11, #2
    v.cmp.ge     p1, v6, v0
    v.splat      v0, s9
    v.cmp.lt     p2, v6, v1
    v.movi       v1, #0
    v.splat      v6, s15
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s14, s2, s16
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v5
    p.and        p2, p3, p4
    v.cmp.ge     p3, v0, v1
    s.add        s15, s3, s17
    p.and        p4, p5, p1
    v.cmp.lt     p1, v0, v6
    p.and        p5, p3, p1
    s.add        s16, s14, s12
    p.and        p1, p6, p2
    s.add        s12, s15, s13
    p.and        p2, p4, p5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s16, #0]
    v.splat      v1, s11
    v.movi       v4, #1024
    v.add        v5, v1, v2
    s.muli       s13, s9, #2048
    v.cmp.lt     p1, v5, v4
    v.splat      v1, s11
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s14, #1024
    s.movz       s15, #512
    v.add        v6, v1, v4
    v.movi       v1, #0
    v.splat      v4, s14
    v.splat      v7, s9
    v.movi       v8, #0
    v.splat      v9, s15
    s.muli       s14, s11, #2
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v10, [s12, #0]
    v.cmp.ge     p2, v6, v1
    v.cmp.lt     p3, v6, v4
    v.cmp.ge     p4, v7, v8
    v.cmp.lt     p5, v7, v9
    s.add        s12, s4, s13
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.add        s13, s12, s14
    p.and        p3, p6, p2
    s.shli       s12, s11, #1                    // element offset -> bytes (x2)
    vf.cvt.f16.f32 v1, v0
    .li       s14, #1149239296
    v.splat      v0, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s14, #1065353216
    v.splat      v4, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s14, #925353388
    v.splat      v6, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v7, v0                          // ISA 8.8: <= 2**-22 relative
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v8, [s13, #0]
    .li       s13, #1077936128
    v.splat      v9, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s13, #3204448256
    v.splat      v11, s13                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s13, s5, s12                    // &in_ptr3[...]
    vf.cvt.f16.f32 v12, v10
    s.mul        s12, s9, s7
    s.add        s14, s11, s8
    s.movz       s15, #1
    vf.add       v10, v1, v12
    s.add        s16, s11, s12
    v.splat      v1, s12
    s.shli       s12, s16, #1                    // element offset -> bytes (x2)
    vf.cvt.f16.f32 v12, v8
    s.add        s16, s6, s12                    // &out_ptr1[...]
    v.add        v8, v5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s13, #0]
    vf.add       v5, v10, v12
    vf.fms       v8, v0, v7, v4
    vf.cvt.f16.f32 v0, v1
    vf.fms       v1, v7, v8, v7
    vf.neg       v4, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v1, v4, v7
    vf.mul       v4, v3, v1                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v1, v4, v6
    v.rsqrt.approx v4, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v6, v4, v4
    vf.mul       v7, v4, v11
    vf.fms       v8, v1, v6, v9
    vf.mul       v1, v7, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v6, v1, v4
    v.extract    s12, v6, #0
    v.splat      v1, s12
    vf.mul       v4, v5, v1
    vf.mul       v1, v4, v0
    vf.cvt.f32.f16 v0, v1
    @p1 v.st.h       [s16, #0], v0
    s.mov        s11, s14
    br.nz        s15, for_3
endfor_4:
__rctx_next:
    s.addi       s11, s9, #2                     // the next program of this context: + 2
    s.cmp.lt     s12, s11, s10
    s.mov        s9, s11
    br.nz        s12, __rctx_program
    exit
