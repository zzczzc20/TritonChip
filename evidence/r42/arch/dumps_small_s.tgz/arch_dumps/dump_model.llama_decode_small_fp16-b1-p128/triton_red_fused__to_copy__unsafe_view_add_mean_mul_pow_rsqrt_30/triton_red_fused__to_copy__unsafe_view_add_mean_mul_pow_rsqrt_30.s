    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.addi       s4, s2, #0
    v.movi       v0, #0
    s.muli       s5, s4, #2
    s.muli       s6, s4, #2
    v.movi       v1, #0
    s.rdspecial  s7, arg_base
    s.movz       s7, #128
    s.movz       s8, #16
    s.movz       s9, #1
    s.ld.d       s9, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.add        s10, s3, s5
    s.ld.d       s5, [s1, #16]                   // in_ptr1: device_ptr64 at arg_base+16
    v.mov        v1, v0
    s.add        s1, s9, s6
for_1:
    v.ld.h       v0, [s10, #0]
    v.ld.h       v2, [s1, #0]
    vf.cvt.f16.f32 v3, v0
    vf.cvt.f16.f32 v0, v2
    vf.add       v2, v3, v0
    vf.mul       v0, v2, v2
    vf.add       v1, v1, v0
    s.addi       s10, s10, #32                   // the next iteration's address
    s.addi       s1, s1, #32                     // the next iteration's address
    s.add        s4, s4, s8
    s.cmp.lt     s6, s4, s7
    br.nz        s6, for_1
endfor_2:
    .li       s1, #1124073472
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.add.b v3, v1
    v.rcp.approx v1, v0                          // ISA 8.8: <= 2**-22 relative
    v.movi       v4, #0
    .li       s1, #925353388
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1077936128
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v7, v3, v4
    .li       s1, #3204448256
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.addi       s1, s2, #0
    s.muli       s2, s1, #2
    s.muli       s4, s1, #2
    s.shli       s6, s1, #1                      // element offset -> bytes (x2)
    s.add        s10, s5, s6                     // &in_ptr1[...]
    s.add        s5, s3, s2
    s.add        s2, s9, s4
    vf.fms       v4, v0, v1, v2
    vf.fms       v0, v1, v4, v1
    vf.neg       v2, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v1
    vf.mul       v1, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v0, v1, v5
    v.rsqrt.approx v1, v0                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v2, v1, v1
    vf.mul       v4, v1, v3
    vf.fms       v3, v0, v2, v6
    vf.mul       v0, v4, v3                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v2, v0, v1
    v.extract    s3, v2, #0
    v.splat      v0, s3
for_3:
    v.ld.h       v1, [s5, #0]
    v.ld.h       v2, [s2, #0]
    vf.cvt.f16.f32 v3, v1
    v.ld.h       v1, [s10, #0]
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v3, v4
    vf.mul       v3, v2, v0
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v3, v2
    vf.cvt.f32.f16 v2, v1
    v.st.h       [s5, #0], v2
    s.addi       s5, s5, #32                     // the next iteration's address
    s.addi       s2, s2, #32                     // the next iteration's address
    s.addi       s10, s10, #32                   // the next iteration's address
    s.add        s1, s1, s8
    s.cmp.lt     s3, s1, s7
    br.nz        s3, for_3
endfor_4:
    exit
    exit
