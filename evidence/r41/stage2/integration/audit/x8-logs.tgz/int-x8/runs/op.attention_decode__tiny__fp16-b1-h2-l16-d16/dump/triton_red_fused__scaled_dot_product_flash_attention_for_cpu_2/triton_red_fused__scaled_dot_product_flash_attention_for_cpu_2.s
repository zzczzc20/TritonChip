    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    s.rdspecial  s1, role_id
    s.movz       s2, #256
    v.sub        v2, v1, v0
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    v.cmp.lt     p1, v0, v1
    @p1 v.sel        v3, v2, v0
    v.movi       v2, #4
    s.ld.d       s1, [s3, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.lshr       v4, v3, v2
    s.rdspecial  s2, arg_base
    s.add        s3, s1, s5                      // this context's own scratch
    v.sub        v2, v1, v4
    s.ld.d       s1, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.addi       s5, s3, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s3, #2
    s.ld.d       s6, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.movz       s7, #16
    s.movz       s8, #64
    s.movz       s9, #4
    .li       s10, #68719476737
    .li       s11, #2207613190144
    s.ld.d       s12, [s2, #0]                   // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v3, v2, v4
    s.movz       s13, #0
    s.ld.d       s14, [s2, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.movz       s15, #0
    v.iota       v2                              // arange(0, VLEN)
    s.ld.d       s16, [s2, #32]                  // out_ptr1: device_ptr64 at arg_base+32
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #0
    v.cmpi.lt    p1, v4, #1
    s.st.d       [s5, #0], s1
    v.sub        v4, v5, v0
    v.cmp.lt     p2, v0, v5
    s.st.d       [s5, #8], s3
    s.movz       s2, #0
    @p2 v.sel        v6, v4, v0
    s.st.d       [s5, #16], s7
    s.cmp.lt     s3, s7, s2
    s.movz       s2, #0
    s.st.d       [s5, #48], s8
    s.sub        s7, s2, s3
    s.movz       s2, #0
    s.st.d       [s5, #56], s9
    v.movi       v0, #15
    s.muli       s3, s2, #4
    s.st.d       [s5, #88], s10
    s.cmp.lt     s8, s4, s13
    v.cmpi.lt    p3, v2, #1
    s.st.d       [s5, #104], s11
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s6, v3]               // index is in elements (ISA sec 9.1)
    s.sub        s5, s15, s8
    v.splat      v4, s2
    s.xor        s2, s4, s5
    s.xor        s6, s5, s7
    s.sub        s7, s2, s5
    v.iota       v7                              // arange(0, VLEN)
    s.lshri      s2, s7, #4
    v.and        v8, v6, v0
    s.xor        s5, s2, s6
    v.add        v0, v4, v7
    s.sub        s2, s5, s6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v4, [s12, v3]             // index is in elements (ISA sec 9.1)
    s.muli       s5, s2, #64
    v.sub        v6, v5, v8
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v9, #0
    @p2 v.sel        v10, v6, v8
    s.add        s6, s1, s5
    v.movi       v6, #16
    s.add        s1, s6, s3
    v.movi       v8, #0
    v.cmp.lt     p1, v7, v6
    v.cmp.ne     p2, v4, v8
    v.movi       v4, #16
    v.cmp.ge     p3, v0, v9
    v.cmpi.lt    p4, v0, #16
    p.and        p5, p3, p4
    v.sub        v0, v1, v4
    v.sub        v8, v5, v4
    v.cmp.lt     p3, v4, v1
    v.splat      v1, s2
    v.movi       v9, #0
    v.cmpi.lt    p4, v1, #2
    v.cmp.ge     p6, v1, v9
    @p3 v.sel        v1, v0, v4
    p.and        p3, p6, p4
    v.movi       v0, #256
    p.and        p4, p5, p3
    v.extract    s2, v10, #0
    v.mul        v1, v3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s1, #0]
    v.mul        v3, v7, v6
    v.splat      v6, s2
    v.extract    s1, v1, #0
    v.add        v1, v6, v3
    v.splat      v3, s1
    v.movi       v6, #1
    v.add        v7, v1, v3
    v.cmp.lt     p3, v4, v5
    v.movi       v1, #0
    v.movi       v3, #0
    @p2 v.sel        v5, v6, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s14, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.eq     p2, v5, v3
    @p3 v.sel        v3, v8, v4
    v.extract    s1, v2, #0
    v.splat      v2, s1
    .li       s1, #1065353216
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v4, v2                          // ISA 8.8: <= 2**-22 relative
    v.movi       v5, #1
    v.movi       v6, #0
    v.movi       v7, #0
    @p2 v.sel        v8, v5, v6
    vf.cvt.f16.f32 v5, v1
    v.extract    s1, v8, #0
    v.splat      v1, s1
    v.movi       v6, #0
    v.cmp.ne     p2, v1, v7
    v.movi       v1, #0
    s.shli       s1, s4, #1                      // element offset -> bytes (x2)
    v.iota       v7                              // arange(0, VLEN)
    s.add        s2, s16, s1                     // &out_ptr1[...]
    v.cmpi.lt    p3, v7, #1
    vf.fms       v7, v2, v4, v3
    vf.fms       v2, v4, v7, v4
    vf.neg       v3, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v3, v3
    @p4 v.sel        v2, v3, v4
    vf.mul       v3, v0, v2                      // a/y as a refined reciprocal (ISA has no divide)
    @p2 v.sel        v0, v6, v3
    vf.mul       v2, v0, v5
    vf.add       v0, v2, v6
    @p1 v.sel        v2, v0, v6
    vf.reduce.add.b v0, v2
    vf.add       v2, v0, v1
    vf.cvt.f32.f16 v0, v2
    @p3 v.st.h       [s2, #0], v0
__rctx_next:
    exit
