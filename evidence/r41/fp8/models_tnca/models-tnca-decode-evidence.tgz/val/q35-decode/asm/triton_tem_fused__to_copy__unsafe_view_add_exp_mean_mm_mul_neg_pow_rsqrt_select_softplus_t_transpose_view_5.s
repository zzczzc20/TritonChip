    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #1024
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s8, #0], s3
    .li       s1, #2147483647
    s.st.d       [s8, #8], s1
    .li       s1, #2147483647
    s.st.d       [s8, #16], s1
    s.movz       s1, #5120
    s.st.d       [s8, #48], s1
    s.movz       s1, #2
    s.st.d       [s8, #56], s1
    .li       s1, #68719476752
    s.st.d       [s8, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #2
    s.movz       s3, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.cmp.lt     s11, s1, s10
    s.sub        s10, s9, s11
    s.xor        s9, s1, s10
    s.sub        s11, s9, s10
    s.movz       s9, #1
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #1
    s.cmp.lt     s18, s4, s8
    s.sub        s8, s3, s18
    s.xor        s3, s4, s8
    s.sub        s18, s3, s8
    s.lshri      s3, s18, #1
    s.muli       s19, s3, #2
    s.sub        s20, s18, s19
    s.xor        s18, s8, s10
    s.xor        s8, s3, s18
    s.sub        s3, s8, s18
    s.sub        s8, s9, s3
    s.min.s      s10, s8, s9
    s.cmp.lt     s8, s4, s12
    s.sub        s12, s11, s8
    s.cmp.lt     s8, s10, s14
    s.sub        s11, s13, s8
    s.xor        s8, s4, s12
    s.sub        s13, s8, s12
    s.xor        s8, s10, s11
    s.sub        s14, s8, s11
    s.addi       s8, s15, #0
    s.addi       s11, s16, #0
    s.cmp.eq     s15, s14, s17
    s.mov        s8, s13
    br.nz        s15, sdiv_done_1
    s.movz       s15, #0
    s.movz       s16, #31
    s.mov        s8, s15
    s.addi       s15, s16, #0
sdiv_2:
    s.lshr       s16, s13, s15
    s.shli       s17, s11, #1
    s.andi       s18, s16, #1
    s.movz       s16, #0
    s.or         s19, s17, s18
    s.movz       s17, #1
    s.cmp.geu    s18, s19, s14
    s.shl        s20, s17, s15
    s.sub        s17, s16, s18
    s.subi       s16, s15, #1
    s.and        s18, s14, s17
    s.and        s21, s20, s17
    s.sub        s17, s19, s18
    s.or         s18, s8, s21
    s.mov        s11, s17
    s.mov        s8, s18
    s.mov        s15, s16
    s.movz       s16, #0
    s.cmp.ge     s17, s15, s16
    br.nz        s17, sdiv_2
sdiv_done_1:
    s.movz       s8, #0
    s.movz       s13, #0
    s.cmp.lt     s14, s4, s8
    s.movz       s8, #0
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.xor        s14, s4, s15
    s.movz       s4, #0
    s.sub        s16, s14, s15
    s.cmp.lt     s14, s10, s8
    s.lshri      s8, s16, #1
    s.movz       s17, #0
    s.muli       s18, s8, #2
    s.sub        s8, s4, s14
    s.movz       s4, #0
    s.cmp.lt     s14, s1, s17
    s.xor        s17, s10, s8
    s.sub        s10, s16, s18
    s.movz       s16, #0
    s.xor        s18, s10, s15
    s.xor        s10, s11, s12
    s.sub        s11, s18, s15
    s.sub        s15, s16, s14
    s.cmp.lt     s14, s11, s13
    s.sub        s13, s17, s8
    s.sub        s16, s4, s14
    s.movz       s4, #0
    s.xor        s14, s11, s16
    s.movz       s11, #1
    s.sub        s17, s10, s12
    s.xor        s10, s1, s15
    s.sub        s1, s14, s16
    s.movz       s12, #0
    s.addi       s14, s4, #0
    s.cmp.eq     s4, s13, s11
    s.add        s11, s3, s17
    s.sub        s3, s10, s15
    s.addi       s3, s12, #0
    s.mov        s14, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s10, #31
    s.mov        s14, s4
    s.addi       s4, s10, #0
sdiv_4:
    s.lshr       s10, s1, s4
    s.shli       s12, s3, #1
    s.andi       s15, s10, #1
    s.movz       s10, #0
    s.or         s17, s12, s15
    s.movz       s12, #1
    s.cmp.geu    s15, s17, s13
    s.shl        s18, s12, s4
    s.sub        s12, s10, s15
    s.subi       s10, s4, #1
    s.and        s15, s13, s12
    s.and        s19, s18, s12
    s.sub        s12, s17, s15
    s.or         s15, s14, s19
    s.mov        s3, s12
    s.mov        s14, s15
    s.mov        s4, s10
    s.movz       s10, #0
    s.cmp.ge     s12, s4, s10
    br.nz        s12, sdiv_4
sdiv_done_3:
    s.xor        s1, s16, s8
    s.movz       s3, #16
    s.xor        s4, s14, s1
    s.movz       s8, #0
    s.sub        s10, s4, s1
    v.splat      v0, s11
    s.mul        s1, s10, s3
    v.splat      v1, s8
    v.splat      v2, s10
    v.splat      v3, s8
    v.iota       v4                              // arange(0, VLEN)
    s.andi       s4, s1, #31
    v.splat      v5, s1
    v.splat      v6, s4
    v.cmp.ge     p1, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ge     p1, v2, v3
    v.add        v1, v5, v4
    v.add        v1, v6, v0
    s.movz       s10, #160
    s.addi       s12, s8, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s8, s12, s10
    br.nz        s8, endfor_6
    s.mul        s8, s12, s3
    s.rdspecial  s13, role_id
    s.movz       s14, #1024
    s.rdspecial  s15, arg_base
    s.mul        s16, s13, s14
    s.muli       s13, s8, #2                     // a runtime tile origin, x2
    s.movz       s14, #16
    s.movz       s17, #0
    s.add        s17, s2, s13                    // the tile origin
    v.ld.h       v0, [s17, #0]
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s13, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s17, #16
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s18, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s19, s8                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s18, s13
    mb.wait      s13
    s.ld.d       s8, [s15, #40]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s15, #32
    s.movz       s18, #2
    s.add        s19, s8, s16                    // this context's own scratch
    .li       s8, #68719476752
    s.addi       s16, s19, #256                  // 512 bytes of repack scratch
    s.addi       s20, s19, #768                  // TensorMap 1: a repacked tile
    s.addi       s19, s16, #32                   // row 1
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s16, #0], v0
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #64                   // row 2
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #96                   // row 3
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #128                  // row 4
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #160                  // row 5
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #192                  // row 6
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #224                  // row 7
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #256                  // row 8
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #288                  // row 9
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #320                  // row 10
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #352                  // row 11
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #384                  // row 12
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #416                  // row 13
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #448                  // row 14
    v.st.h       [s19, #0], v0
    s.addi       s19, s16, #480                  // row 15
    v.st.h       [s19, #0], v0
    .li       s19, #1108101562368
    s.st.d       [s20, #0], s16
    s.movz       s16, #0
    s.st.d       [s20, #8], s14
    s.add        s14, s12, s9
    s.st.d       [s20, #16], s17
    s.movz       s17, #1
    s.st.d       [s20, #48], s15
    s.st.d       [s20, #56], s18
    s.st.d       [s20, #88], s8
    s.st.d       [s20, #104], s19
    fence.release.device
    td.load      d1, [s20]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s8, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s18, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s19, s16                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s18, s8
    mb.wait      s8
    mb.arm       s15, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v48, v56, s15
    mb.wait      s15
    s.mov        s12, s14
    br.nz        s17, for_5
endfor_6:
    s.mul        s2, s11, s3
    s.movz       s3, #0
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s4, s1, #2                      // a runtime tile origin, x2
    s.movz       s10, #0
    s.add        s11, s3, s1                     // the tile origin
    s.muli       s3, s2, #64                     // a runtime tile origin, x64
    s.add        s12, s10, s2                    // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s11
    s.movz       s10, #32
    v.splat      v2, s12
    v.splat      v3, s9
    v.add        v5, v0, v1
    v.splat      v0, s10
    s.add        s9, s6, s4                      // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v5, v0
    s.add        s4, s9, s3                      // the tile origin
    s.movz       s3, #0
    p.and        p3, p1, p2
    a.vread      v0, a0, s3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    vf.cvt.f32.bf16 v2, v0
    s.addi       s3, s12, #1
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    v.splat      v0, s3
    vf.cvt.bf16.f32 v5, v2
    vf.cvt.bf16.f32 v2, v1
    v.cmp.lt     p1, v0, v3
    s.movz       s3, #1
    s.addi       s9, s4, #64                     // row 1
    vf.add       v0, v5, v2
    p.and        p3, p1, p2
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a1, s6, v0
    a.vread      v0, a0, s3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s9, #0]
    vf.cvt.f32.bf16 v2, v0
    s.muli       s3, s1, #2                      // a runtime tile origin, x2
    s.muli       s6, s2, #64                     // a runtime tile origin, x64
    v.splat      v0, s2
    vf.cvt.bf16.f32 v5, v2
    vf.cvt.bf16.f32 v2, v1
    s.movz       s9, #2
    s.add        s14, s5, s3                     // the tile origin
    v.add        v1, v0, v4
    vf.add       v0, v5, v2
    s.addi       s3, s4, #128                    // row 2
    s.add        s5, s14, s6                     // the tile origin
    s.addi       s6, s12, #2
    a.vwrite     a1, s10, v0
    v.splat      v0, s6
    a.vread      v1, a0, s9
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    s.addi       s3, s12, #3
    s.movz       s6, #3
    vf.cvt.bf16.f32 v2, v0
    v.splat      v0, s3
    s.addi       s3, s4, #192                    // row 3
    vf.cvt.bf16.f32 v4, v1
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s9, s12, #4
    vf.add       v0, v2, v4
    v.splat      v1, s9
    s.movz       s9, #3
    v.cmp.lt     p1, v1, v3
    a.vwrite     a1, s11, v0
    a.vread      v0, a0, s6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    vf.cvt.f32.bf16 v2, v0
    s.movz       s3, #4
    s.addi       s6, s4, #256                    // row 4
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v0, v2
    vf.cvt.bf16.f32 v2, v1
    s.addi       s10, s12, #5
    s.movz       s11, #4
    v.splat      v1, s10
    vf.add       v4, v0, v2
    v.cmp.lt     p1, v1, v3
    s.movz       s10, #5
    s.addi       s14, s4, #320                   // row 5
    a.vwrite     a1, s9, v4
    a.vread      v0, a0, s3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s6, #0]
    vf.cvt.f32.bf16 v2, v0
    p.and        p3, p1, p2
    s.addi       s3, s12, #6
    s.movz       s6, #5
    vf.cvt.bf16.f32 v0, v2
    vf.cvt.bf16.f32 v2, v1
    v.splat      v1, s3
    s.movz       s3, #6
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v0, v2
    s.addi       s9, s4, #384                    // row 6
    p.and        p4, p1, p2
    s.addi       s16, s12, #7
    a.vwrite     a1, s11, v1
    a.vread      v0, a0, s10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s14, #0]
    vf.cvt.f32.bf16 v2, v0
    v.splat      v0, s16
    s.movz       s10, #6
    v.cmp.lt     p1, v0, v3
    vf.cvt.bf16.f32 v0, v2
    vf.cvt.bf16.f32 v2, v1
    s.movz       s11, #7
    s.addi       s14, s4, #448                   // row 7
    p.and        p3, p1, p2
    vf.add       v1, v0, v2
    s.addi       s16, s12, #8
    v.splat      v0, s16
    a.vwrite     a1, s6, v1
    a.vread      v1, a0, s3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s9, #0]
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v0, v3
    s.movz       s3, #7
    s.movz       s6, #8
    vf.cvt.bf16.f32 v0, v4
    vf.cvt.bf16.f32 v1, v2
    s.addi       s9, s4, #512                    // row 8
    p.and        p4, p1, p2
    s.addi       s16, s12, #9
    vf.add       v2, v0, v1
    v.splat      v0, s16
    s.movz       s16, #8
    v.cmp.lt     p1, v0, v3
    a.vwrite     a1, s10, v2
    a.vread      v0, a0, s11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s14, #0]
    vf.cvt.f32.bf16 v2, v0
    s.movz       s10, #9
    s.addi       s11, s4, #576                   // row 9
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v0, v2
    vf.cvt.bf16.f32 v2, v1
    s.addi       s14, s12, #10
    v.splat      v1, s14
    vf.add       v4, v0, v2
    v.cmp.lt     p1, v1, v3
    s.movz       s14, #9
    p.and        p5, p1, p2
    a.vwrite     a1, s3, v4
    a.vread      v0, a0, s6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s9, #0]
    vf.cvt.f32.bf16 v2, v0
    s.movz       s3, #10
    s.addi       s6, s4, #640                    // row 10
    s.addi       s9, s12, #11
    vf.cvt.bf16.f32 v0, v2
    vf.cvt.bf16.f32 v2, v1
    v.splat      v1, s9
    s.movz       s9, #10
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v0, v2
    p.and        p4, p1, p2
    a.vwrite     a1, s16, v1
    a.vread      v0, a0, s10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s11, #0]
    vf.cvt.f32.bf16 v2, v0
    s.movz       s10, #11
    s.addi       s11, s4, #704                   // row 11
    s.addi       s16, s12, #12
    vf.cvt.bf16.f32 v0, v2
    vf.cvt.bf16.f32 v2, v1
    v.splat      v1, s16
    s.movz       s16, #11
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v0, v2
    p.and        p3, p1, p2
    a.vwrite     a1, s14, v1
    a.vread      v0, a0, s3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v1, [s6, #0]
    vf.cvt.f32.bf16 v2, v0
    s.movz       s3, #12
    s.addi       s6, s4, #768                    // row 12
    s.addi       s14, s12, #13
    vf.cvt.bf16.f32 v0, v2
    vf.cvt.bf16.f32 v2, v1
    v.splat      v1, s14
    s.movz       s14, #12
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v0, v2
    p.and        p5, p1, p2
    a.vwrite     a1, s9, v1
    a.vread      v0, a0, s10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s11, #0]
    vf.cvt.f32.bf16 v2, v0
    s.movz       s9, #13
    s.addi       s10, s4, #832                   // row 13
    s.addi       s11, s12, #14
    vf.cvt.bf16.f32 v0, v2
    vf.cvt.bf16.f32 v2, v1
    v.splat      v1, s11
    s.movz       s11, #13
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v0, v2
    p.and        p4, p1, p2
    a.vwrite     a1, s16, v1
    a.vread      v0, a0, s3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s6, #0]
    vf.cvt.f32.bf16 v2, v0
    s.movz       s3, #14
    s.addi       s6, s4, #896                    // row 14
    s.addi       s16, s12, #15
    vf.cvt.bf16.f32 v0, v2
    vf.cvt.bf16.f32 v2, v1
    v.splat      v1, s16
    s.movz       s16, #14
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v0, v2
    s.addi       s17, s4, #960                   // row 15
    p.and        p3, p1, p2
    .li       s4, #1101004800
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    a.vwrite     a1, s14, v1
    a.vread      v1, a0, s9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v2, [s10, #0]
    vf.cvt.f32.bf16 v4, v1
    s.movz       s4, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    v.splat      v1, s12
    s.movz       s9, #15
    vf.cvt.bf16.f32 v5, v4
    vf.cvt.bf16.f32 v4, v2
    v.cmp.lt     p1, v1, v3
    p.and        p5, p1, p2
    .li       s10, #1069066811
    v.splat      v1, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v2, v5, v4
    .li       s10, #1060205080
    v.splat      v4, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s10, s1, #4                     // a runtime tile origin, x4
    s.muli       s1, s2, #128                    // a runtime tile origin, x128
    a.vwrite     a1, s11, v2
    a.vread      v2, a0, s3
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s6, #0]
    vf.cvt.f32.bf16 v6, v2
    s.movz       s2, #0
    s.movz       s3, #0
    s.add        s6, s7, s10                     // the tile origin
    vf.cvt.bf16.f32 v2, v6
    vf.cvt.bf16.f32 v6, v5
    s.movz       s7, #0
    s.add        s10, s6, s1                     // the tile origin
    vf.add       v5, v2, v6
    a.vwrite     a1, s16, v5
    a.vread      v2, a0, s4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s17, #0]
    vf.cvt.f32.bf16 v6, v2
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #4913933
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v8, v6
    vf.cvt.bf16.f32 v6, v5
    v.movi       v5, #23
    v.movi       v9, #127
    v.movi       v10, #25
    vf.add       v11, v8, v6
    v.movi       v6, #23
    a.vwrite     a1, s9, v11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v8, [s5, #0]
    a.vread      v11, a1, s2
    a.vread      v12, a1, s3
    a.vread      v13, a1, s7
    v.movi       v14, #127
    vf.mul       v15, v13, v1
    v.movi       v16, #23
    vf.cvt.bf16.f32 v17, v8
    vf.cmp.gt    p1, v11, v0
    v.exp2.approx v8, v15                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v11, v13, v1, v15               // the exact rounding error of x*log2(e)
    vf.mul       v13, v17, v1
    .li       s1, #1032451959
    v.splat      v15, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v18, v11, v4
    v.exp2.approx v11, v13                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v19, v17, v1, v13               // the exact rounding error of x*log2(e)
    .li       s1, #3186590336
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1039390164
    v.splat      v17, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v20, v19, v4
    vf.fma       v19, v8, v18, v8                // 2**t * 2**d
    vf.cmp.o     p3, v19, v19
    @p3 v.sel        v18, v19, v8
    vf.fma       v8, v11, v20, v11               // 2**t * 2**d
    vf.add       v19, v18, v2
    .li       s1, #3187543230
    v.splat      v20, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.o     p3, v8, v8
    v.add        v21, v19, v7
    @p3 v.sel        v7, v8, v11
    v.lshr       v8, v21, v5
    .li       s1, #1041339458
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v11, v8, v9
    vf.neg       v8, v7
    v.min.s      v7, v11, v10
    v.shl        v9, v11, v6
    v.sub        v6, v14, v7
    v.sub        v7, v18, v9
    v.shl        v9, v6, v16
    .li       s1, #3190467997
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.sub       v10, v9, v2
    .li       s1, #1045222078
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.s32.f32 v14, v11
    .li       s1, #3196059656
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v16, v7, v10                    // f = x*2**-k + (2**-k - 1)
    .li       s1, #1060205056
    v.splat      v19, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1051372195
    v.splat      v21, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v22, v14, v19                   // k*ln2_hi, exact
    vf.fma       v23, v15, v16, v13
    vf.sub       v24, v16, v7
    vf.neg       v25, v16
    vf.add       v26, v22, v16
    vf.fma       v27, v23, v16, v17
    vf.sub       v23, v16, v24
    vf.sub       v28, v10, v24
    .li       s1, #3204448256
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v24, v27, v16, v20
    vf.sub       v27, v7, v23
    .li       s1, #901758606
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v23, v16, v16
    vf.fma       v29, v24, v16, v5
    vf.add       v24, v27, v28                   // TwoSum: the exact error of f
    vf.sub       v27, v26, v22
    vf.abs       v22, v18
    vf.fma       v28, v29, v16, v6
    vf.fma       v29, v25, v24, v24              // f_lo/(1 + f_hi)
    vf.sub       v24, v16, v27                   // Fast2Sum
    .li       s1, #855638016
    v.splat      v25, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v27, v28, v16, v9
    vf.fma       v28, v14, v7, v29
    vf.cmp.lt    p3, v22, v25
    .li       s1, #3212836864
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v22, v27, v16, v11
    .li       s1, #4286578688
    v.splat      v27, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.eq    p4, v18, v14
    .li       s1, #2143289344
    v.splat      v29, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v30, v22, v16, v21
    .li       s1, #2139095040
    v.splat      v22, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.addi       s1, s12, #1
    v.splat      v31, s12
    vf.fma       v32, v30, v16, v10
    v.splat      v16, s1
    s.addi       s1, s5, #64                     // row 1
    vf.fma       v30, v23, v32, v28
    s.movz       s2, #1
    vf.add       v23, v24, v30
    vf.add       v24, v26, v23
    s.movz       s3, #1
    s.movz       s4, #1
    @p3 v.sel        v23, v18, v24
    vf.cmp.lt    p3, v18, v14
    @p4 v.sel        v24, v27, v23
    vf.cmp.eq    p4, v18, v22
    @p3 v.sel        v23, v29, v24
    vf.cmp.uo    p3, v18, v18
    @p4 v.sel        v24, v18, v23
    v.cmp.lt     p4, v31, v3
    @p3 v.sel        v23, v18, v24
    v.cmp.lt     p3, v16, v3
    @p1 v.sel        v16, v12, v23
    p.and        p1, p4, p2
    vf.mul       v12, v8, v16
    p.and        p4, p3, p2
    .li       s6, #4913933
    v.splat      v8, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v12, v1
    v.movi       v23, #127
    v.movi       v24, #25
    v.exp2.approx v26, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v28, v12, v1, v18               // the exact rounding error of x*log2(e)
    v.movi       v12, #23
    vf.mul       v18, v28, v4
    vf.fma       v28, v26, v18, v26              // 2**t * 2**d
    v.movi       v18, #127
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v30, v28, v26
    v.movi       v26, #23
    @p1 v.st.w       [s10, #0], v30
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s2
    a.vread      v31, a1, s3
    a.vread      v32, a1, s4
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v8
    @p3 v.sel        v8, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v8
    v.sub        v8, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v8, v24
    v.shl        v24, v8, v12
    v.sub        v12, v18, v28
    v.sub        v18, v32, v24
    v.shl        v24, v12, v26
    vf.cvt.s32.f32 v12, v8
    vf.sub       v8, v24, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v23, v12, v19                   // k*ln2_hi, exact
    vf.add       v24, v18, v8                    // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #1
    s.addi       s2, s10, #128                   // row 1
    vf.fma       v26, v15, v24, v13
    vf.sub       v28, v24, v18
    vf.neg       v30, v24
    vf.add       v33, v23, v24
    vf.fma       v34, v26, v24, v17
    vf.sub       v26, v24, v28
    vf.sub       v35, v8, v28
    vf.mul       v8, v24, v24
    vf.fma       v28, v34, v24, v20
    vf.sub       v34, v18, v26
    vf.sub       v18, v33, v23
    v.splat      v23, s1
    vf.fma       v26, v28, v24, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v24, v18                   // Fast2Sum
    s.addi       s1, s12, #2
    vf.fma       v18, v26, v24, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #128                    // row 2
    vf.fma       v30, v18, v24, v9
    vf.fma       v18, v12, v7, v26
    vf.fma       v12, v30, v24, v11
    vf.fma       v26, v12, v24, v21
    vf.fma       v12, v26, v24, v10
    vf.fma       v24, v8, v12, v18
    s.movz       s3, #2
    s.movz       s4, #2
    vf.add       v8, v34, v24
    s.movz       s6, #2
    vf.add       v12, v33, v8
    @p3 v.sel        v8, v32, v12
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v12, v27, v8
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v8, v29, v12
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v12, v32, v8
    v.cmp.lt     p4, v23, v3
    @p3 v.sel        v8, v32, v12
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #2
    s.addi       s2, s10, #256                   // row 2
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #3
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #192                    // row 3
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #3
    s.movz       s4, #3
    vf.add       v12, v34, v23
    s.movz       s6, #3
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #3
    s.addi       s2, s10, #384                   // row 3
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #4
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #256                    // row 4
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #4
    s.movz       s4, #4
    vf.add       v12, v34, v23
    s.movz       s6, #4
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #4
    s.addi       s2, s10, #512                   // row 4
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #5
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #320                    // row 5
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #5
    s.movz       s4, #5
    vf.add       v12, v34, v23
    s.movz       s6, #5
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #5
    s.addi       s2, s10, #640                   // row 5
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #6
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #384                    // row 6
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #6
    s.movz       s4, #6
    vf.add       v12, v34, v23
    s.movz       s6, #6
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #6
    s.addi       s2, s10, #768                   // row 6
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #7
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #448                    // row 7
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #7
    s.movz       s4, #7
    vf.add       v12, v34, v23
    s.movz       s6, #7
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #7
    s.addi       s2, s10, #896                   // row 7
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #8
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #512                    // row 8
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #8
    s.movz       s4, #8
    vf.add       v12, v34, v23
    s.movz       s6, #8
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #8
    s.addi       s2, s10, #1024                  // row 8
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #9
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #576                    // row 9
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #9
    s.movz       s4, #9
    vf.add       v12, v34, v23
    s.movz       s6, #9
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #9
    s.addi       s2, s10, #1152                  // row 9
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #10
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #640                    // row 10
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #10
    s.movz       s4, #10
    vf.add       v12, v34, v23
    s.movz       s6, #10
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #10
    s.addi       s2, s10, #1280                  // row 10
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #11
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #704                    // row 11
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #11
    s.movz       s4, #11
    vf.add       v12, v34, v23
    s.movz       s6, #11
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #11
    s.addi       s2, s10, #1408                  // row 11
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #12
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #768                    // row 12
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #12
    s.movz       s4, #12
    vf.add       v12, v34, v23
    s.movz       s6, #12
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #12
    s.addi       s2, s10, #1536                  // row 12
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #13
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #832                    // row 13
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #13
    s.movz       s4, #13
    vf.add       v12, v34, v23
    s.movz       s6, #13
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #13
    s.addi       s2, s10, #1664                  // row 13
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #14
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #896                    // row 14
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #14
    s.movz       s4, #14
    vf.add       v12, v34, v23
    s.movz       s6, #14
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s7, #4913933
    v.splat      v12, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s6
    vf.cmp.gt    p1, v30, v0
    vf.mul       v30, v32, v1
    vf.cvt.bf16.f32 v33, v28
    v.exp2.approx v28, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v32, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v33, v1
    vf.mul       v32, v34, v4
    v.exp2.approx v34, v30                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v35, v33, v1, v30               // the exact rounding error of x*log2(e)
    vf.mul       v30, v35, v4
    vf.fma       v33, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v33, v33
    @p3 v.sel        v32, v33, v28
    vf.fma       v28, v34, v30, v34              // 2**t * 2**d
    vf.add       v30, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v33, v30, v12
    @p3 v.sel        v12, v28, v34
    v.lshr       v28, v33, v16
    vf.neg       v16, v12
    v.sub        v12, v28, v23
    vf.abs       v23, v32
    v.min.s      v28, v12, v8
    v.shl        v8, v12, v26
    v.sub        v26, v24, v28
    v.sub        v24, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v12
    vf.sub       v12, v8, v2
    vf.cmp.lt    p3, v23, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v8, v18, v19                    // k*ln2_hi, exact
    vf.add       v23, v24, v12                   // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #14
    s.addi       s2, s10, #1792                  // row 14
    vf.fma       v26, v15, v23, v13
    vf.sub       v28, v23, v24
    vf.neg       v30, v23
    vf.add       v33, v8, v23
    vf.fma       v34, v26, v23, v17
    vf.sub       v26, v23, v28
    vf.sub       v35, v12, v28
    vf.mul       v12, v23, v23
    vf.fma       v28, v34, v23, v20
    vf.sub       v34, v24, v26
    vf.sub       v24, v33, v8
    v.splat      v8, s1
    vf.fma       v26, v28, v23, v5
    vf.add       v28, v34, v35                   // TwoSum: the exact error of f
    vf.sub       v34, v23, v24                   // Fast2Sum
    s.addi       s1, s12, #15
    vf.fma       v24, v26, v23, v6
    vf.fma       v26, v30, v28, v28              // f_lo/(1 + f_hi)
    v.splat      v28, s1
    s.addi       s1, s5, #960                    // row 15
    vf.fma       v30, v24, v23, v9
    vf.fma       v24, v18, v7, v26
    vf.fma       v18, v30, v23, v11
    vf.fma       v26, v18, v23, v21
    vf.fma       v18, v26, v23, v10
    vf.fma       v23, v12, v18, v24
    s.movz       s3, #15
    s.movz       s4, #15
    vf.add       v12, v34, v23
    s.movz       s5, #15
    vf.add       v18, v33, v12
    @p3 v.sel        v12, v32, v18
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v18, v27, v12
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v12, v29, v18
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v18, v32, v12
    v.cmp.lt     p4, v8, v3
    @p3 v.sel        v8, v32, v18
    v.cmp.lt     p3, v28, v3
    @p1 v.sel        v12, v31, v8
    p.and        p1, p4, p2
    vf.mul       v8, v16, v12
    p.and        p4, p3, p2
    .li       s6, #4913933
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v16, #23
    vf.mul       v18, v8, v1
    v.movi       v23, #127
    v.exp2.approx v24, v18                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v26, v8, v1, v18                // the exact rounding error of x*log2(e)
    v.movi       v8, #25
    vf.mul       v18, v26, v4
    v.movi       v26, #23
    vf.fma       v28, v24, v18, v24              // 2**t * 2**d
    vf.cmp.o     p3, v28, v28
    @p3 v.sel        v18, v28, v24
    v.movi       v24, #127
    @p1 v.st.w       [s2, #0], v18
    v.movi       v18, #23
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v28, [s1, #0]
    a.vread      v30, a1, s3
    a.vread      v31, a1, s4
    a.vread      v32, a1, s5
    vf.cmp.gt    p1, v30, v0
    vf.mul       v0, v32, v1
    vf.cvt.bf16.f32 v30, v28
    v.exp2.approx v28, v0                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v33, v32, v1, v0                // the exact rounding error of x*log2(e)
    vf.mul       v0, v30, v1
    vf.mul       v32, v33, v4
    v.exp2.approx v33, v0                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v34, v30, v1, v0                // the exact rounding error of x*log2(e)
    vf.mul       v0, v34, v4
    vf.fma       v30, v28, v32, v28              // 2**t * 2**d
    vf.cmp.o     p3, v30, v30
    @p3 v.sel        v32, v30, v28
    vf.fma       v28, v33, v0, v33               // 2**t * 2**d
    vf.add       v0, v32, v2
    vf.cmp.o     p3, v28, v28
    v.add        v30, v0, v12
    @p3 v.sel        v0, v28, v33
    v.lshr       v12, v30, v16
    vf.neg       v16, v0
    v.sub        v0, v12, v23
    vf.abs       v12, v32
    v.min.s      v23, v0, v8
    v.shl        v8, v0, v26
    v.sub        v26, v24, v23
    v.sub        v23, v32, v8
    v.shl        v8, v26, v18
    vf.cvt.s32.f32 v18, v0
    vf.sub       v0, v8, v2
    vf.cmp.lt    p3, v12, v25
    vf.cmp.eq    p4, v32, v14
    vf.mul       v2, v18, v19                    // k*ln2_hi, exact
    vf.add       v8, v23, v0                     // f = x*2**-k + (2**-k - 1)
    s.addi       s1, s12, #15
    s.addi       s2, s10, #1920                  // row 15
    vf.fma       v12, v15, v8, v13
    vf.sub       v13, v8, v23
    vf.neg       v15, v8
    vf.add       v19, v2, v8
    vf.fma       v24, v12, v8, v17
    vf.sub       v12, v8, v13
    vf.sub       v17, v0, v13
    vf.mul       v0, v8, v8
    vf.fma       v13, v24, v8, v20
    vf.sub       v20, v23, v12
    vf.sub       v12, v19, v2
    v.splat      v2, s1
    vf.fma       v23, v13, v8, v5
    vf.add       v5, v20, v17                    // TwoSum: the exact error of f
    vf.sub       v13, v8, v12                    // Fast2Sum
    vf.fma       v12, v23, v8, v6
    vf.fma       v6, v15, v5, v5                 // f_lo/(1 + f_hi)
    vf.fma       v5, v12, v8, v9
    vf.fma       v9, v18, v7, v6
    vf.fma       v6, v5, v8, v11
    vf.fma       v5, v6, v8, v21
    vf.fma       v6, v5, v8, v10
    vf.fma       v5, v0, v6, v9
    vf.add       v0, v13, v5
    vf.add       v5, v19, v0
    @p3 v.sel        v0, v32, v5
    vf.cmp.lt    p3, v32, v14
    @p4 v.sel        v5, v27, v0
    vf.cmp.eq    p4, v32, v22
    @p3 v.sel        v0, v29, v5
    vf.cmp.uo    p3, v32, v32
    @p4 v.sel        v5, v32, v0
    v.cmp.lt     p4, v2, v3
    @p3 v.sel        v0, v32, v5
    p.and        p3, p4, p2
    @p1 v.sel        v2, v31, v0
    vf.mul       v0, v16, v2
    vf.mul       v2, v0, v1
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v4
    vf.fma       v1, v3, v0, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v3
    @p3 v.st.w       [s2, #0], v0
__rctx_next:
    exit
