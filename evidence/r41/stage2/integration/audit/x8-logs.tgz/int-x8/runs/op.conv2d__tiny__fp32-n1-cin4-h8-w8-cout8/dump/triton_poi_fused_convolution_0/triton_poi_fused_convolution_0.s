    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.rdspecial  s1, pid.y
    s.movz       s5, #4
    s.shli       s6, s1, #2                      // x4 as a shift
    s.movz       s1, #16
    s.muli       s7, s6, #256                    // a runtime tile origin, x256
    s.rdspecial  s8, arg_base
    s.ld.d       s9, [s8, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s8, role_id
    s.movz       s10, #512
    s.mul        s11, s8, s10
    s.add        s8, s9, s11                     // this context's own scratch
    s.addi       s9, s8, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #0
    s.st.d       [s9, #0], s3
    s.movz       s11, #64
    s.st.d       [s9, #8], s11
    s.st.d       [s9, #16], s5
    s.st.d       [s9, #48], s1
    s.st.d       [s9, #56], s5
    .li       s1, #17179869200
    s.st.d       [s9, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s9, #104], s1
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s8, #256                    // 256 bytes of repack scratch
    s.add        s5, s10, s6                     // the tile origin
    s.addi       s8, s5, #1
    s.movz       s9, #1
    s.muli       s11, s9, #64
    s.add        s9, s1, s11
    s.addi       s11, s5, #2
    s.movz       s12, #2
    s.muli       s13, s12, #64
    s.add        s12, s1, s13
    s.addi       s13, s5, #3
    s.movz       s14, #3
    s.muli       s15, s14, #64
    s.add        s14, s1, s15
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #16
    s.muli       s18, s15, #64
    s.add        s15, s1, s18
    s.muli       s18, s16, #4
    s.add        s16, s15, s18
    s.addi       s15, s16, #4                    // column 1
    s.addi       s18, s16, #8                    // column 2
    s.addi       s19, s16, #12                   // column 3
    s.addi       s20, s16, #16                   // column 4
    s.addi       s21, s16, #20                   // column 5
    s.addi       s22, s16, #24                   // column 6
    s.addi       s23, s16, #28                   // column 7
    s.addi       s24, s16, #32                   // column 8
    s.addi       s25, s16, #36                   // column 9
    s.addi       s26, s16, #40                   // column 10
    s.addi       s27, s16, #44                   // column 11
    s.addi       s28, s16, #48                   // column 12
    s.addi       s29, s16, #52                   // column 13
    s.addi       s30, s16, #56                   // column 14
    s.addi       s31, s16, #60                   // column 15
    s.muli       s32, s6, #4
    s.movz       s33, #1
    s.muli       s34, s33, #16
    s.movz       s33, #2
    s.muli       s35, s33, #16
    s.movz       s33, #3
    s.muli       s36, s33, #16
    s.movz       s33, #4
    s.muli       s37, s33, #16
    s.movz       s33, #5
    s.muli       s38, s33, #16
    s.movz       s33, #6
    s.muli       s39, s33, #16
    s.movz       s33, #7
    s.muli       s40, s33, #16
    s.movz       s33, #8
    s.muli       s41, s33, #16
    s.movz       s33, #9
    s.muli       s42, s33, #16
    s.movz       s33, #10
    s.muli       s43, s33, #16
    s.movz       s33, #11
    s.muli       s44, s33, #16
    s.movz       s33, #12
    s.muli       s45, s33, #16
    s.movz       s33, #13
    s.muli       s46, s33, #16
    s.movz       s33, #14
    s.muli       s47, s33, #16
    s.movz       s33, #15
    s.muli       s48, s33, #16
    s.shli       s33, s4, #4                     // x16 as a shift
    s.muli       s4, s33, #4                     // a runtime tile origin, x4
    s.add        s49, s2, s4                     // the tile origin
    s.add        s2, s49, s7                     // the tile origin
    // a masked 4x16 tile with contiguous rows: one predicated load a row
    // tile epilogue: 4 rows through the vector unit, as f32 (ISA sec 9B)
    s.add        s4, s10, s33                    // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s4
    v.add        v2, v0, v1
    v.cmpi.lt    p1, v2, #64
    v.splat      v0, s5
    v.cmpi.lt    p2, v0, #4
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s2, #0]
    v.st.w       [s1, #0], v0
    s.addi       s1, s2, #256                    // row 1
    v.splat      v0, s8
    v.cmpi.lt    p2, v0, #4
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s1, #0]
    v.st.w       [s9, #0], v0
    s.addi       s1, s2, #512                    // row 2
    v.splat      v0, s11
    v.cmpi.lt    p2, v0, #4
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s1, #0]
    v.st.w       [s12, #0], v0
    s.addi       s1, s2, #768                    // row 3
    v.splat      v0, s13
    v.cmpi.lt    p2, v0, #4
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s1, #0]
    v.st.w       [s14, #0], v0
    fence.acq_rel.device
    // tl.trans: 16 columns, gathered %c73:scalar elements apart (ISA sec 9.1)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s17
    v.mul        v2, v0, v1                      // one element per source row
    v.ld.gather.w v0, [s16, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v1, [s15, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v3, [s18, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v4, [s19, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v5, [s20, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v6, [s21, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v7, [s22, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v8, [s23, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v9, [s24, v2]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v10, [s25, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v11, [s26, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v12, [s27, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v13, [s28, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v14, [s29, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v15, [s30, v2]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v16, [s31, v2]                 // index is in elements (ISA sec 9.1)
    s.muli       s1, s33, #16
    s.add        s2, s3, s1
    s.add        s1, s2, s32
    v.splat      v2, s6
    v.iota       v17                             // arange(0, VLEN)
    v.add        v18, v2, v17
    v.movi       v2, #0
    v.cmp.ge     p1, v18, v2
    v.cmpi.lt    p2, v18, #4
    p.and        p3, p1, p2
    v.splat      v2, s33
    v.movi       v17, #0
    v.cmp.ge     p1, v2, v17
    v.cmpi.lt    p2, v2, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v2                              // arange(0, VLEN)
    v.cmpi.lt    p2, v2, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s1, #0], v0
    s.add        s2, s1, s34
    s.addi       s3, s33, #1
    v.splat      v0, s3
    v.movi       v2, #0
    v.cmp.ge     p1, v0, v2
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v1
    s.add        s2, s1, s35
    s.addi       s3, s33, #2
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v3
    s.add        s2, s1, s36
    s.addi       s3, s33, #3
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v4
    s.add        s2, s1, s37
    s.addi       s3, s33, #4
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v5
    s.add        s2, s1, s38
    s.addi       s3, s33, #5
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v6
    s.add        s2, s1, s39
    s.addi       s3, s33, #6
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v7
    s.add        s2, s1, s40
    s.addi       s3, s33, #7
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v8
    s.add        s2, s1, s41
    s.addi       s3, s33, #8
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v9
    s.add        s2, s1, s42
    s.addi       s3, s33, #9
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v10
    s.add        s2, s1, s43
    s.addi       s3, s33, #10
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v11
    s.add        s2, s1, s44
    s.addi       s3, s33, #11
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v12
    s.add        s2, s1, s45
    s.addi       s3, s33, #12
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v13
    s.add        s2, s1, s46
    s.addi       s3, s33, #13
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v14
    s.add        s2, s1, s47
    s.addi       s3, s33, #14
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p4, p2, p1
    @p4 v.st.w       [s2, #0], v15
    s.add        s2, s1, s48
    s.addi       s1, s33, #15
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ge     p1, v0, v1
    v.cmpi.lt    p2, v0, #64
    p.and        p4, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    v.cmpi.lt    p2, v0, #4
    p.and        p3, p2, p1
    @p3 v.st.w       [s2, #0], v16
__rctx_next:
    exit
