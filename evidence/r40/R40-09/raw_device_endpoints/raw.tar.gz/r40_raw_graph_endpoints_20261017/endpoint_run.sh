source ~/tc_env/env.sh
cd /home/zhongchun/r40_raw_graph_endpoints_20261017
export OMP_NUM_THREADS=2 MAX_JOBS=2 TNCA_HOST_TIMEOUT=1800 CUDA_VISIBLE_DEVICES=
export PYTHONPATH="$PWD:$PWD/python:$PWD/compiler/python:$PWD/tools/asm"
/home/zhongchun/tc_env/torchenv/bin/python tools/r40/device_clock_tests.py > endpoint_unit.log 2>&1
echo $? > endpoint_unit.exit
/home/zhongchun/tc_env/torchenv/bin/python -u -m archbench.run --platform tnca --profile core-vrf-sync-v5 --backend fpga-multicore-sim --backend-args '{"core_count": 3, "memory_ports": 3, "memory_bytes": 1048576, "link_stages": 2, "noc_link_stages": 2, "dispatch_stages": 2, "home_stages": 2, "code_stages": 2, "board_top": true, "maintenance": true, "memory_controls": true, "hbm_dma": true}' --point op.add/tiny/fp16-n1000 --jobs 1 --seed 0 --warmup 1 --timed 2 --timeout 2400 --set TNCA_TORCH_DEVICE=native --set TNCA_TRANSFER_POLICY=resident --out /home/zhongchun/r40_raw_graph_endpoints_20261017/endpoint_result.jsonl > endpoint_native.log 2>&1
echo $? > endpoint_native.exit
