    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr0: device_ptr64 at arg_base+32
    s.movz       s1, #1
    s.addi       s8, s5, #4096
    s.rdspecial  s5, arg_base
    s.ld.d       s9, [s5, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s5, role_id
    s.movz       s10, #256
    s.mul        s11, s5, s10
    s.add        s5, s9, s11                     // this context's own scratch
    s.addi       s9, s5, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s5, #0
    s.st.d       [s9, #0], s8
    s.movz       s5, #16
    s.st.d       [s9, #8], s5
    s.movz       s5, #128
    s.st.d       [s9, #16], s5
    s.movz       s5, #256
    s.st.d       [s9, #48], s5
    s.movz       s5, #2
    s.st.d       [s9, #56], s5
    .li       s5, #68719476737
    s.st.d       [s9, #88], s5
    .li       s5, #1108101562368
    s.st.d       [s9, #104], s5
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s5, #1
    s.movz       s9, #0
    s.movz       s10, #128
    s.movz       s11, #16
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #128
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v4, v3, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v4, #127
    v.and        v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.movi       v4, #0
    v.movi       v5, #1
    v.cmp.lt     p1, v0, v4
    v.cmp.lt     p2, v2, v4
    v.sub        v5, v4, v0
    @p1 v.sel        v6, v5, v0
    v.sub        v0, v4, v2
    @p2 v.sel        v5, v0, v2
    v.movi       v0, #7
    v.lshr       v2, v6, v0
    v.sub        v0, v4, v2
    @p1 v.sel        v4, v0, v2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s1
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s3, v4]               // index is in elements (ISA sec 9.1)
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v5, s5
    v.cmp.lt     p1, v2, v5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s6, v4]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s9, #0
    v.movi       v5, #0
    v.movi       v6, #0
    v.mov        v6, v5
for_1:
    s.cmp.ge     s3, s1, s10
    br.nz        s3, endfor_2
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s6, s4, s3
    s.movz       s3, #256
    s.sub        s9, s5, s6
    s.movz       s5, #0
    s.movz       s6, #0
    s.cmp.lt     s12, s3, s5
    s.xor        s5, s4, s9
    s.sub        s13, s6, s12
    s.sub        s6, s5, s9
    s.xor        s5, s9, s13
    s.lshri      s9, s6, #8
    v.splat      v5, s1
    v.movi       v7, #16384
    s.xor        s12, s9, s5
    v.add        v8, v5, v1
    v.movi       v5, #128
    s.sub        s14, s12, s5
    v.splat      v9, s1
    v.iota       v10                             // arange(0, VLEN)
    v.extract    s5, v3, #0
    v.mul        v11, v4, v7
    s.movz       s12, #128
    s.movz       s15, #16
    v.mul        v7, v8, v5
    v.splat      v12, s5
    s.muli       s5, s14, #256
    v.add        v13, v9, v10
    v.movi       v9, #0
    v.splat      v10, s12
    v.extract    s12, v11, #0
    v.splat      v11, s14
    s.muli       s14, s1, #2
    v.add        v14, v12, v7
    v.movi       v7, #0
    v.cmp.ge     p1, v13, v9
    v.splat      v9, s12
    v.cmp.lt     p2, v13, v10
    v.cmp.ge     p3, v11, v7
    s.add        s12, s8, s5
    p.and        p4, p1, p2
    v.add        v7, v14, v9
    s.add        s5, s12, s14
    v.cmp.lt     p1, v8, v5
    v.splat      v5, s15
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s2, v7]               // index is in elements (ISA sec 9.1)
    s.muli       s12, s9, #256
    v.cmp.lt     p2, v11, v5
    p.and        p5, p3, p2
    s.xor        s9, s3, s13
    p.and        p2, p4, p5
    s.movz       s3, #16384
    .li       s3, #897988541
    v.splat      v5, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1077936128
    v.splat      v7, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #3204448256
    v.splat      v9, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v10, v2, v5
    v.extract    s3, v0, #0
    s.sub        s14, s9, s13
    v.splat      v5, s3
    v.movi       v11, #0
    v.rsqrt.approx v12, v10                      // ISA 8.8: <= 2**-22 relative
    s.sub        s3, s6, s12
    s.add        s3, s1, s11
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s5, #0]
    vf.mul       v14, v8, v5
    s.movz       s5, #1
    vf.cvt.bf16.f32 v5, v13
    vf.mul       v8, v12, v12
    vf.mul       v13, v12, v9
    vf.fms       v9, v10, v8, v7
    vf.mul       v7, v13, v9                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v7, v7
    @p2 v.sel        v8, v7, v12
    v.extract    s6, v8, #0
    v.splat      v7, s6
    vf.mul       v8, v5, v7
    vf.mul       v5, v14, v8
    vf.add       v7, v6, v5
    @p1 v.sel        v5, v7, v6
    v.mov        v11, v5
    v.mov        v6, v11
    s.mov        s1, s3
    br.nz        s5, for_1
endfor_2:
    vf.reduce.add.b v0, v6
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s7, s2                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
