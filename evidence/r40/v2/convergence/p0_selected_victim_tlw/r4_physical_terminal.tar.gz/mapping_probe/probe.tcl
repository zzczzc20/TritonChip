set_param general.maxThreads 2
set source [lindex $argv 0]
set out [lindex $argv 1]
file mkdir $out
open_checkpoint $source
set f [open $out/unresolved.tsv w]
puts $f "cell\tref\tloc\tpl\tsites\tslrs\tparent\tparentref\tparentsites\tparentslrs"
set cells [get_cells -hierarchical -quiet -filter {IS_PRIMITIVE == 1}]
set names [get_property NAME $cells]
set all [get_cells -hierarchical -quiet]
set lookup [dict create]
foreach cell $all name [get_property NAME $all] {dict set lookup $name $cell}
set bad 0
foreach cell $cells name $names {
 if {![string match {tmu/*} $name] || ![regexp {^(FD|RAM|SRL)} [get_property REF_NAME $cell]]} {continue}
 set slrs [get_slrs -quiet -of_objects $cell]
 if {[llength $slrs]} {continue}
 set parent [join [lrange [split $name /] 0 end-1] /]
 set parentref {};set parentsites {};set parentslrs {}
 if {[dict exists $lookup $parent]} {
  set pc [dict get $lookup $parent]
  set parentref [get_property REF_NAME $pc]
  set parentsites [get_sites -quiet -of_objects $pc]
  set parentslrs [get_slrs -quiet -of_objects $pc]
 }
 puts $f [join [list $name [get_property REF_NAME $cell] [get_property LOC $cell] [get_property IS_PLACED $cell] [get_sites -quiet -of_objects $cell] $slrs $parent $parentref $parentsites $parentslrs] "\t"]
 incr bad
 if {$bad>=20} {break}
}
close $f
puts "UNRESOLVED_SAMPLE $bad"
exit
