    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // out_ptr0: device_ptr64 at arg_base+40
    s.rdspecial  s1, arg_base
    s.ld.d       s9, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s10, #512
    s.mul        s11, s1, s10
    s.add        s1, s9, s11                     // this context's own scratch
    s.addi       s9, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s9, #0], s2
    .li       s1, #2147483647
    s.st.d       [s9, #8], s1
    .li       s1, #2147483647
    s.st.d       [s9, #16], s1
    s.movz       s1, #64
    s.st.d       [s9, #48], s1
    s.movz       s1, #1
    s.st.d       [s9, #56], s1
    .li       s1, #68719476752
    s.st.d       [s9, #88], s1
    .li       s1, #7705171329024
    s.st.d       [s9, #104], s1
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #3
    s.movz       s2, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.cmp.lt     s12, s1, s11
    s.sub        s11, s10, s12
    s.xor        s10, s1, s11
    s.sub        s12, s10, s11
    .li       s10, #1431655766
    s.movz       s12, #2
    s.movz       s13, #1
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #0
    s.movz       s18, #0
    s.movz       s19, #0
    s.movz       s20, #1
    s.cmp.lt     s21, s4, s9
    s.sub        s9, s2, s21
    s.xor        s2, s4, s9
    s.sub        s21, s2, s9
    s.mul        s2, s21, s10
    s.lshri      s10, s2, #32
    s.sub        s2, s21, s10
    s.lshri      s22, s2, #1
    s.add        s2, s10, s22
    s.lshri      s10, s2, #1
    s.muli       s2, s10, #3
    s.sub        s22, s21, s2
    s.xor        s2, s9, s11
    s.xor        s9, s10, s2
    s.sub        s10, s9, s2
    s.sub        s2, s12, s10
    s.min.s      s9, s2, s13
    s.cmp.lt     s2, s4, s15
    s.sub        s11, s14, s2
    s.cmp.lt     s2, s9, s17
    s.sub        s12, s16, s2
    s.xor        s2, s4, s11
    s.sub        s14, s2, s11
    s.xor        s2, s9, s12
    s.sub        s15, s2, s12
    s.addi       s2, s18, #0
    s.addi       s12, s19, #0
    s.cmp.eq     s16, s15, s20
    s.mov        s2, s14
    br.nz        s16, sdiv_done_1
    s.movz       s16, #0
    s.movz       s17, #31
    s.mov        s2, s16
    s.addi       s16, s17, #0
sdiv_2:
    s.lshr       s17, s14, s16
    s.shli       s18, s12, #1
    s.andi       s19, s17, #1
    s.movz       s17, #0
    s.or         s20, s18, s19
    s.movz       s18, #1
    s.cmp.geu    s19, s20, s15
    s.shl        s21, s18, s16
    s.sub        s18, s17, s19
    s.subi       s17, s16, #1
    s.and        s19, s15, s18
    s.and        s22, s21, s18
    s.sub        s18, s20, s19
    s.or         s19, s2, s22
    s.mov        s12, s18
    s.mov        s2, s19
    s.mov        s16, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s16, s17
    br.nz        s18, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s14, #0
    s.cmp.lt     s15, s4, s2
    .li       s2, #1431655766
    s.sub        s16, s14, s15
    s.movz       s14, #0
    s.xor        s15, s4, s16
    s.movz       s4, #0
    s.sub        s17, s15, s16
    s.movz       s15, #0
    s.mul        s18, s17, s2
    s.cmp.lt     s2, s9, s14
    s.movz       s14, #0
    s.sub        s19, s15, s2
    s.movz       s2, #0
    s.lshri      s15, s18, #32
    s.cmp.lt     s18, s1, s14
    s.xor        s14, s9, s19
    s.xor        s9, s12, s11
    s.sub        s12, s14, s19
    s.sub        s14, s9, s11
    s.sub        s9, s17, s15
    s.add        s11, s10, s14
    s.lshri      s10, s9, #1
    s.movz       s9, #0
    s.add        s14, s15, s10
    s.sub        s10, s9, s18
    s.lshri      s9, s14, #1
    s.movz       s14, #0
    s.muli       s15, s9, #3
    s.movz       s9, #1
    s.xor        s18, s1, s10
    s.addi       s1, s14, #0
    s.cmp.eq     s14, s12, s9
    s.sub        s9, s17, s15
    s.movz       s15, #0
    s.xor        s17, s9, s16
    s.sub        s9, s18, s10
    s.sub        s9, s17, s16
    s.addi       s10, s15, #0
    s.cmp.lt     s15, s9, s4
    s.sub        s4, s2, s15
    s.xor        s2, s9, s4
    s.sub        s9, s2, s4
    s.mov        s1, s9
    br.nz        s14, sdiv_done_3
    s.movz       s2, #0
    s.movz       s14, #31
    s.mov        s1, s2
    s.addi       s2, s14, #0
sdiv_4:
    s.lshr       s14, s9, s2
    s.shli       s15, s10, #1
    s.andi       s16, s14, #1
    s.movz       s14, #0
    s.or         s17, s15, s16
    s.movz       s15, #1
    s.cmp.geu    s16, s17, s12
    s.shl        s18, s15, s2
    s.sub        s15, s14, s16
    s.subi       s14, s2, #1
    s.and        s16, s12, s15
    s.and        s20, s18, s15
    s.sub        s15, s17, s16
    s.or         s16, s1, s20
    s.mov        s10, s15
    s.mov        s1, s16
    s.mov        s2, s14
    s.movz       s14, #0
    s.cmp.ge     s15, s2, s14
    br.nz        s15, sdiv_4
sdiv_done_3:
    s.xor        s2, s4, s19
    s.movz       s4, #16
    s.xor        s9, s1, s2
    .li       s1, #1431655766
    s.sub        s10, s9, s2
    s.mul        s2, s11, s4
    s.mul        s9, s10, s4
    s.movz       s12, #0
    v.splat      v0, s11
    v.splat      v1, s12
    s.andi       s11, s2, #31
    s.mul        s14, s9, s1
    v.splat      v2, s10
    v.splat      v3, s12
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s2
    s.lshri      s1, s14, #32
    v.cmp.ge     p1, v0, v1
    s.sub        s10, s9, s1
    v.splat      v0, s9
    s.lshri      s14, s10, #1
    v.splat      v1, s11
    s.add        s10, s1, s14
    v.cmp.ge     p1, v2, v3
    s.lshri      s1, s10, #5
    v.iota       v2                              // arange(0, VLEN)
    s.muli       s10, s1, #48
    v.iota       v3                              // arange(0, VLEN)
    v.add        v6, v5, v4
    v.add        v5, v0, v4
    v.add        v0, v1, v2
    s.sub        s1, s9, s10
    s.movz       s10, #4
    v.splat      v0, s1
    s.addi       s14, s12, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    v.add        v1, v0, v3
for_5:
    s.cmp.ge     s12, s14, s10
    br.nz        s12, endfor_6
    s.mul        s12, s14, s4
    s.muli       s15, s1, #64                    // a runtime tile origin, x64
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.movz       s16, #0
    s.movz       s17, #64
    v.iota       v0                              // arange(0, VLEN)
    s.add        s18, s16, s12                   // the tile origin
    v.splat      v1, s17
    s.add        s16, s18, s15                   // the tile origin
    w.def        w0, #60, #4                     // v60..v63
    mb.arm       s15, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.mul        v2, v0, v1
    v.splat      v0, s16
    s.rdspecial  s17, arg_base
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s18, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s19, s12                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s18, s15
    mb.wait      s15
    s.ld.d       s12, [s17, #48]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.add        v1, v2, v0
    s.rdspecial  s17, role_id
    s.movz       s18, #512
    s.addi       s19, s16, #1
    s.mul        s20, s17, s18
    v.splat      v0, s19
    s.addi       s17, s16, #2
    s.addi       s18, s16, #3
    v.add        v3, v2, v0
    v.splat      v0, s17
    v.ld.gather.b v4, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.add        s17, s12, s20                   // this context's own scratch
    v.add        v1, v2, v0
    s.addi       s12, s17, #256                  // 256 bytes of repack scratch
    v.splat      v0, s18
    s.addi       s17, s12, #16                   // row 1
    s.addi       s18, s12, #32                   // row 2
    v.add        v5, v2, v0
    s.addi       s19, s16, #4
    s.addi       s20, s12, #48                   // row 3
    v.splat      v0, s19
    s.addi       s19, s16, #5
    v.st.b       [s12, #0], v4
    v.add        v4, v2, v0
    v.splat      v0, s19
    s.addi       s19, s12, #64                   // row 4
    s.addi       s21, s16, #6
    v.add        v6, v2, v0
    s.addi       s22, s12, #80                   // row 5
    s.addi       s23, s16, #7
    v.ld.gather.b v0, [s3, v3]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s17, #0], v0
    v.splat      v0, s21
    s.addi       s17, s12, #96                   // row 6
    s.addi       s21, s16, #8
    v.add        v3, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s18, #0], v0
    v.splat      v0, s23
    s.addi       s18, s12, #112                  // row 7
    s.addi       s23, s16, #9
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v5]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s20, #0], v0
    v.splat      v0, s21
    s.addi       s20, s12, #128                  // row 8
    s.addi       s21, s16, #10
    v.add        v5, v2, v0
    v.ld.gather.b v0, [s3, v4]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s19, #0], v0
    v.splat      v0, s23
    s.addi       s19, s12, #144                  // row 9
    s.addi       s23, s16, #11
    v.add        v4, v2, v0
    v.ld.gather.b v0, [s3, v6]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s22, #0], v0
    v.splat      v0, s21
    s.addi       s21, s12, #160                  // row 10
    s.addi       s22, s16, #12
    v.add        v6, v2, v0
    v.ld.gather.b v0, [s3, v3]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s17, #0], v0
    v.splat      v0, s23
    s.addi       s17, s12, #176                  // row 11
    s.addi       s23, s16, #13
    v.add        v3, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s18, #0], v0
    v.splat      v0, s22
    s.addi       s18, s12, #192                  // row 12
    s.addi       s22, s16, #14
    v.add        v1, v2, v0
    s.addi       s24, s16, #15
    v.ld.gather.b v0, [s3, v5]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s20, #0], v0
    v.splat      v0, s23
    s.addi       s16, s12, #208                  // row 13
    s.addi       s20, s12, #224                  // row 14
    v.add        v5, v2, v0
    v.ld.gather.b v0, [s3, v4]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s19, #0], v0
    v.splat      v0, s22
    s.addi       s19, s12, #240                  // row 15
    s.addi       s22, s12, #64
    v.add        v4, v2, v0
    v.ld.gather.b v0, [s3, v6]                   // index is in elements (ISA sec 9.1)
    s.add        s23, s14, s13
    v.st.b       [s21, #0], v0
    v.splat      v0, s24
    s.addi       s21, s12, #128
    s.addi       s24, s12, #192
    v.add        v6, v2, v0
    v.ld.gather.b v0, [s3, v3]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s17, #0], v0
    s.movz       s17, #1
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s18, #0], v0
    v.ld.gather.b v0, [s3, v5]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s16, #0], v0
    v.ld.gather.b v0, [s3, v4]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s20, #0], v0
    v.ld.gather.b v0, [s3, v6]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s19, #0], v0
    w.def        w1, #56, #4                     // v56..v59
    fence.acq_rel.device
    v.ld.w       v0, [s12, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s22, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s21, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s24, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s12, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.e4m3 a0, v60, v56, s12
    mb.wait      s12
    s.mov        s14, s23
    br.nz        s17, for_5
endfor_6:
    s.ld.w       s1, [s5, #0]                    // one element, not a vector
    v.splat      v0, s1
    s.ld.w       s1, [s6, #0]                    // one element, not a vector
    v.splat      v1, s1
    s.muli       s1, s9, #2                      // a runtime tile origin, x2
    s.add        s3, s7, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s1, s9, #2                      // a runtime tile origin, x2
    s.add        s4, s8, s1                      // the tile origin
    s.muli       s1, s2, #96                     // a runtime tile origin, x96
    s.add        s5, s4, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v2, a0, s1
    vf.mul       v3, v0, v1
    vf.mul       v4, v2, v3
    s.movz       s1, #0
    s.add        s4, s1, s2                      // the tile origin
    v.splat      v2, s4
    s.movz       s1, #32
    v.splat      v3, s1
    v.cmp.lt     p1, v2, v3
    s.movz       s1, #0
    s.add        s2, s1, s9                      // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v5, s2
    v.add        v6, v2, v5
    s.movz       s1, #48
    v.splat      v2, s1
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v5, v2
    vf.add       v2, v4, v5
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s5, #0], v4
    s.movz       s1, #1
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #1
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #96                     // row 1
    s.addi       s2, s4, #1
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #2
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #2
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #192                    // row 2
    s.addi       s2, s4, #2
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #3
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #3
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #288                    // row 3
    s.addi       s2, s4, #3
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #4
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #4
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #384                    // row 4
    s.addi       s2, s4, #4
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #5
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #5
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #480                    // row 5
    s.addi       s2, s4, #5
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #6
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #6
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #576                    // row 6
    s.addi       s2, s4, #6
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #7
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #7
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #672                    // row 7
    s.addi       s2, s4, #7
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #8
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #8
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #768                    // row 8
    s.addi       s2, s4, #8
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #9
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #9
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #864                    // row 9
    s.addi       s2, s4, #9
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #10
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #10
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #960                    // row 10
    s.addi       s2, s4, #10
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #11
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #11
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1056                   // row 11
    s.addi       s2, s4, #11
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #12
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #12
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1152                   // row 12
    s.addi       s2, s4, #12
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #13
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #13
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1248                   // row 13
    s.addi       s2, s4, #13
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #14
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s4, #14
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1344                   // row 14
    s.addi       s2, s4, #14
    v.splat      v2, s2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #15
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v0, v2, v4
    s.addi       s1, s4, #15
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    vf.cvt.bf16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s5, #1440                   // row 15
    s.addi       s2, s4, #15
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
__rctx_next:
    exit
