import re,sys
G=[('txf internal (u_txf -> u_txf)', lambda s,d: 'u_txf/' in s and 'u_txf/' in d),
   ('txf xbuf from walk (t_* -> xbuf)', lambda s,d: 'u_txf/t_' in s and 'xbuf' in d),
   ('NI response -> txf', lambda s,d: 'u_cni/' in s and 'u_txf/' in d),
   ('W forward (w_idx/en/class/rctx -> any)', lambda s,d: re.search(r'u_core/w_(idx|en|class|rctx)_reg',s)),
   ('VRF bank read side (-> bank s1_*/mem)', lambda s,d: 'u_bank/' in d),
   ('F04 writeback (-> w_vdata/w_sdata/w_pdata)', lambda s,d: re.search(r'w_[svp]data_reg',d)),
   ('tile', lambda s,d: True)]
def load(f, cols):
    out=[]
    for i,l in enumerate(open(f)):
        if i==0: continue
        p=l.rstrip().split('\t'); out.append((float(p[0]),p[cols[0]],p[cols[1]]))
    return out
runs=[('e843bc4','ev/vivado/x8_%s_screen.top_paths.tsv',(5,6)),('r1 8a333a0','s1/%s_screen/near_endpoints_1p5.tsv',(3,4)),
      ('r2 1332058','s2/%s_screen/near_endpoints_1p5.tsv',(3,4)),('r3 89a6441','s3/%s_screen/near_endpoints_1p5.tsv',(3,4))]
for t in ('tile1','tile0'):
    print(f"### {t}  (worst slack ns / endpoints < +1.4; '>=1.5' = none below 1.5; e843bc4 report floor shown)")
    data={n:load(f%t,c) for n,f,c in runs}
    print('| family | '+' | '.join(n for n,_,_ in runs)+' |'); print('|---'*(len(runs)+1)+'|')
    for name,fn in G:
        cells=[]
        for n,_,_ in runs:
            v=[x for x in data[n] if fn(x[1],x[2])]
            if not v: cells.append('>=1.5' if n!='e843bc4' else f'> {max(x[0] for x in data[n]):.2f}')
            else: cells.append(f"{min(x[0] for x in v):+.3f} / {sum(1 for x in v if x[0]<1.4)}")
        print(f'| {name} | '+' | '.join(cells)+' |')
