    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #1152
    v.movi       v2, #0
    v.movi       v3, #3456
    s.rdspecial  s1, arg_base
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v0, #1
    v.sub        v4, v2, v6
    v.cmp.lt     p2, v6, v2
    v.cmp.lt     p3, v6, v3
    @p2 v.sel        v3, v4, v6
    @p1 v.sel        v4, v5, v1
    v.movi       v1, #0
    v.movi       v5, #0
    s.movz       s4, #31
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s6, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.ld.d       s7, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
idiv_1:
    v.splat      v7, s4
    v.shl        v8, v5, v0
    v.cmp.lt     p4, v5, v2
    v.lshr       v9, v3, v7
    v.shl        v10, v0, v7
    s.subi       s1, s4, #1
    v.and        v7, v9, v0
    s.movz       s8, #0
    v.or         v9, v8, v7
    v.cmp.geu    p5, v9, v4
    p.or         p6, p4, p5
    v.sub        v7, v9, v4
    @p6 v.sel        v8, v10, v2
    @p6 v.sel        v10, v7, v9
    v.or         v7, v1, v8
    v.mov        v5, v10
    v.mov        v1, v7
    s.mov        s4, s1
    s.cmp.ge     s1, s4, s8
    br.nz        s1, idiv_1
    v.movi       v0, #0
    v.movi       v3, #0
    v.movi       v4, #6
    v.sub        v5, v0, v6
    v.cmp.lt     p4, v6, v0
    v.sub        v7, v3, v6
    @p4 v.sel        v8, v5, v6
    v.movi       v5, #63
    v.movi       v9, #64
    v.lshr       v10, v8, v4
    v.movi       v4, #18
    v.movi       v8, #0
    v.sub        v11, v0, v10
    v.sub        v12, v2, v1
    v.sub        v2, v3, v9
    @p4 v.sel        v13, v11, v10
    v.cmp.lt     p4, v6, v3
    @p4 v.sel        v10, v7, v6
    v.sub        v6, v0, v9
    v.sub        v7, v8, v13
    v.and        v11, v10, v5
    v.sub        v5, v8, v4
    p.xor        p5, p2, p1
    v.sub        v10, v3, v11
    v.cmp.lt     p1, v9, v3
    @p5 v.sel        v3, v12, v1
    v.cmp.lt     p2, v9, v0
    v.movi       v0, #1
    @p1 v.sel        v0, v2, v9
    v.cmp.lt     p1, v13, v8
    @p4 v.sel        v0, v10, v11
    v.cmp.lt     p4, v4, v8
    v.movi       v1, #1
    @p2 v.sel        v1, v6, v9
    v.movi       v1, #1
    @p1 v.sel        v2, v7, v13
    @p4 v.sel        v6, v5, v4
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v9, s1
    v.shl        v10, v7, v1
    v.cmp.lt     p2, v7, v8
    v.lshr       v11, v2, v9
    v.shl        v12, v1, v9
    s.subi       s4, s1, #1
    v.and        v9, v11, v1
    s.movz       s8, #0
    v.or         v11, v10, v9
    v.cmp.geu    p4, v11, v6
    p.or         p5, p2, p4
    v.sub        v9, v11, v6
    @p5 v.sel        v10, v12, v8
    @p5 v.sel        v12, v9, v11
    v.or         v9, v5, v10
    v.mov        v7, v12
    v.mov        v5, v9
    s.mov        s1, s4
    s.cmp.ge     s4, s1, s8
    br.nz        s4, idiv_2
    v.sub        v1, v8, v7
    v.extract    s1, v0, #0
    v.movi       v2, #1
    @p1 v.sel        v5, v1, v7
    v.add        v1, v13, v4
    v.movi       v6, #1
    v.add        v7, v5, v4
    s.shli       s4, s1, #32
    v.extract    s1, v0, #1
    s.ashri      s8, s4, #32
    v.shl        v4, v7, v2
    v.shl        v2, v1, v6
    v.movi       v1, #0
    v.movi       v6, #0
    s.shli       s4, s1, #32
    s.addi       s1, s3, #4
    s.addi       s9, s3, #4
    s.lshri      s10, s8, #32
    v.extract    s11, v0, #2
    s.ashri      s12, s4, #32
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s3, v4]               // index is in elements (ISA sec 9.1)
    s.shli       s4, s11, #32
    v.movi       v8, #0
    s.ashri      s11, s4, #32
    s.movz       s4, #18
    v.cmp.eq     p1, v3, v8
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v3, [s1, v4]               // index is in elements (ISA sec 9.1)
    s.lshri      s1, s12, #32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s5, v0]               // index is in elements (ISA sec 9.1)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v9, [s3, v2]               // index is in elements (ISA sec 9.1)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v10, [s9, v2]              // index is in elements (ISA sec 9.1)
    v.insert     v1, s8, #0
    v.insert     v6, s10, #0
    v.extract    s4, v0, #3
    v.insert     v1, s12, #1
    v.insert     v6, s1, #1
    s.shli       s1, s4, #32
    s.lshri      s4, s11, #32
    v.extract    s8, v0, #4
    s.ashri      s9, s1, #32
    v.insert     v1, s11, #2
    v.insert     v6, s4, #2
    s.shli       s1, s8, #32
    s.lshri      s4, s9, #32
    v.extract    s8, v0, #5
    s.ashri      s10, s1, #32
    v.insert     v1, s9, #3
    v.insert     v6, s4, #3
    s.shli       s1, s8, #32
    s.lshri      s4, s10, #32
    v.extract    s8, v0, #6
    s.ashri      s9, s1, #32
    v.insert     v1, s10, #4
    v.insert     v6, s4, #4
    s.shli       s1, s8, #32
    s.lshri      s4, s9, #32
    v.extract    s8, v0, #7
    s.ashri      s10, s1, #32
    v.insert     v1, s9, #5
    v.insert     v6, s4, #5
    s.shli       s1, s8, #32
    s.lshri      s4, s10, #32
    v.extract    s8, v0, #8
    s.ashri      s9, s1, #32
    v.insert     v1, s10, #6
    v.insert     v6, s4, #6
    s.shli       s1, s8, #32
    s.lshri      s4, s9, #32
    v.extract    s8, v0, #9
    s.ashri      s10, s1, #32
    v.insert     v1, s9, #7
    v.insert     v6, s4, #7
    s.shli       s1, s8, #32
    s.lshri      s4, s10, #32
    v.extract    s8, v0, #10
    s.ashri      s9, s1, #32
    v.insert     v1, s10, #8
    v.insert     v6, s4, #8
    s.shli       s1, s8, #32
    s.lshri      s4, s9, #32
    v.extract    s8, v0, #11
    s.ashri      s10, s1, #32
    v.insert     v1, s9, #9
    v.insert     v6, s4, #9
    s.shli       s1, s8, #32
    s.lshri      s4, s10, #32
    v.extract    s8, v0, #12
    s.ashri      s9, s1, #32
    v.insert     v1, s10, #10
    v.insert     v6, s4, #10
    s.shli       s1, s8, #32
    s.lshri      s4, s9, #32
    v.extract    s8, v0, #13
    s.ashri      s10, s1, #32
    v.insert     v1, s9, #11
    v.insert     v6, s4, #11
    s.shli       s1, s8, #32
    s.lshri      s4, s10, #32
    v.extract    s8, v0, #14
    s.ashri      s9, s1, #32
    v.insert     v1, s10, #12
    v.insert     v6, s4, #12
    s.shli       s1, s8, #32
    s.lshri      s4, s9, #32
    v.extract    s8, v0, #15
    s.ashri      s10, s1, #32
    v.insert     v1, s9, #13
    v.insert     v6, s4, #13
    s.shli       s1, s8, #32
    s.lshri      s4, s10, #32
    s.ashri      s8, s1, #32
    v.insert     v1, s10, #14
    v.insert     v6, s4, #14
    s.lshri      s1, s8, #32
    v.insert     v1, s8, #15
    v.insert     v6, s1, #15
    s.movz       s1, #1
    v.extract    s4, v1, #0
    v.extract    s8, v6, #0
    v.extract    s9, v6, #1
    s.shli       s10, s8, #32
    v.movi       v2, #0
    s.or         s8, s4, s10
    v.extract    s4, v1, #1
    s.shli       s10, s9, #32
    s.cmp.ge     s9, s8, s1
    v.extract    s1, v6, #2
    s.or         s8, s4, s10
    s.movz       s4, #1
    v.insert     v2, s9, #0
    v.extract    s9, v1, #2
    s.shli       s10, s1, #32
    s.cmp.ge     s1, s8, s4
    v.extract    s4, v6, #3
    s.or         s8, s9, s10
    s.movz       s9, #1
    v.insert     v2, s1, #1
    v.extract    s1, v1, #3
    s.shli       s10, s4, #32
    s.cmp.ge     s4, s8, s9
    v.extract    s8, v6, #4
    s.or         s9, s1, s10
    s.movz       s1, #1
    v.insert     v2, s4, #2
    v.extract    s4, v1, #4
    s.shli       s10, s8, #32
    s.cmp.ge     s8, s9, s1
    v.extract    s1, v6, #5
    s.or         s9, s4, s10
    s.movz       s4, #1
    v.insert     v2, s8, #3
    v.extract    s8, v1, #5
    s.shli       s10, s1, #32
    s.cmp.ge     s1, s9, s4
    v.extract    s4, v6, #6
    s.or         s9, s8, s10
    s.movz       s8, #1
    v.insert     v2, s1, #4
    v.extract    s1, v1, #6
    s.shli       s10, s4, #32
    s.cmp.ge     s4, s9, s8
    v.extract    s8, v6, #7
    s.or         s9, s1, s10
    s.movz       s1, #1
    v.insert     v2, s4, #5
    v.extract    s4, v1, #7
    s.shli       s10, s8, #32
    s.cmp.ge     s8, s9, s1
    v.extract    s1, v6, #8
    s.or         s9, s4, s10
    s.movz       s4, #1
    v.insert     v2, s8, #6
    v.extract    s8, v1, #8
    s.shli       s10, s1, #32
    s.cmp.ge     s1, s9, s4
    v.extract    s4, v6, #9
    s.or         s9, s8, s10
    s.movz       s8, #1
    v.insert     v2, s1, #7
    v.extract    s1, v1, #9
    s.shli       s10, s4, #32
    s.cmp.ge     s4, s9, s8
    v.extract    s8, v6, #10
    s.or         s9, s1, s10
    s.movz       s1, #1
    v.insert     v2, s4, #8
    v.extract    s4, v1, #10
    s.shli       s10, s8, #32
    s.cmp.ge     s8, s9, s1
    v.extract    s1, v6, #11
    s.or         s9, s4, s10
    s.movz       s4, #1
    v.insert     v2, s8, #9
    v.extract    s8, v1, #11
    s.shli       s10, s1, #32
    s.cmp.ge     s1, s9, s4
    v.extract    s4, v6, #12
    s.or         s9, s8, s10
    s.movz       s8, #1
    v.insert     v2, s1, #10
    v.extract    s1, v1, #12
    s.shli       s10, s4, #32
    s.cmp.ge     s4, s9, s8
    v.extract    s8, v6, #13
    s.or         s9, s1, s10
    s.movz       s1, #1
    v.insert     v2, s4, #11
    v.extract    s4, v1, #13
    s.shli       s10, s8, #32
    s.cmp.ge     s8, s9, s1
    v.extract    s1, v6, #14
    s.or         s9, s4, s10
    s.movz       s4, #1
    v.insert     v2, s8, #12
    v.extract    s8, v1, #14
    s.shli       s10, s1, #32
    s.cmp.ge     s1, s9, s4
    v.extract    s4, v6, #15
    v.extract    s9, v6, #0
    s.or         s11, s8, s10
    s.movz       s8, #1
    v.insert     v2, s1, #13
    v.extract    s1, v1, #15
    s.shli       s10, s4, #32
    v.extract    s4, v1, #0
    s.shli       s12, s9, #32
    s.cmp.ge     s9, s11, s8
    v.extract    s8, v6, #1
    s.or         s11, s1, s10
    s.movz       s1, #1
    s.or         s10, s4, s12
    s.movz       s4, #60
    v.insert     v2, s9, #14
    v.movi       v11, #0
    v.extract    s9, v1, #1
    s.shli       s12, s8, #32
    s.cmp.ge     s8, s11, s1
    s.cmp.lt     s1, s10, s4
    v.extract    s4, v6, #2
    s.or         s10, s9, s12
    s.movz       s9, #60
    v.insert     v2, s8, #15
    v.insert     v11, s1, #0
    v.extract    s1, v1, #2
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s10, s9
    v.extract    s9, v6, #3
    s.or         s10, s1, s8
    s.movz       s1, #60
    v.insert     v11, s4, #1
    v.extract    s4, v1, #3
    s.shli       s8, s9, #32
    s.cmp.lt     s9, s10, s1
    v.extract    s1, v6, #4
    s.or         s10, s4, s8
    s.movz       s4, #60
    v.insert     v11, s9, #2
    v.extract    s8, v1, #4
    s.shli       s9, s1, #32
    s.cmp.lt     s1, s10, s4
    v.extract    s4, v6, #5
    s.or         s10, s8, s9
    s.movz       s8, #60
    v.insert     v11, s1, #3
    v.extract    s1, v1, #5
    s.shli       s9, s4, #32
    s.cmp.lt     s4, s10, s8
    v.extract    s8, v6, #6
    s.or         s10, s1, s9
    s.movz       s1, #60
    v.insert     v11, s4, #4
    v.extract    s4, v1, #6
    s.shli       s9, s8, #32
    s.cmp.lt     s8, s10, s1
    v.movi       v12, #0
    s.or         s1, s4, s9
    v.insert     v11, s8, #5
    v.cmp.ne     p2, v2, v12
    v.extract    s4, v6, #7
    s.movz       s8, #60
    v.extract    s9, v1, #7
    s.shli       s10, s4, #32
    s.cmp.lt     s4, s1, s8
    v.extract    s1, v6, #8
    s.or         s8, s9, s10
    s.movz       s9, #60
    v.insert     v11, s4, #6
    v.extract    s4, v1, #8
    s.shli       s10, s1, #32
    s.cmp.lt     s1, s8, s9
    v.extract    s8, v6, #9
    s.or         s9, s4, s10
    s.movz       s4, #60
    v.insert     v11, s1, #7
    v.extract    s1, v1, #9
    s.shli       s10, s8, #32
    s.cmp.lt     s8, s9, s4
    v.extract    s4, v6, #10
    s.or         s9, s1, s10
    s.movz       s1, #60
    v.insert     v11, s8, #8
    v.extract    s8, v1, #10
    s.shli       s10, s4, #32
    s.cmp.lt     s4, s9, s1
    v.extract    s1, v6, #11
    s.or         s9, s8, s10
    s.movz       s8, #60
    v.insert     v11, s4, #9
    v.extract    s4, v1, #11
    s.shli       s10, s1, #32
    s.cmp.lt     s1, s9, s8
    v.extract    s8, v6, #12
    s.or         s9, s4, s10
    s.movz       s4, #60
    v.insert     v11, s1, #10
    v.extract    s1, v1, #12
    s.shli       s10, s8, #32
    s.cmp.lt     s8, s9, s4
    v.extract    s4, v6, #13
    s.or         s9, s1, s10
    s.movz       s1, #60
    v.insert     v11, s8, #11
    v.extract    s8, v1, #13
    s.shli       s10, s4, #32
    s.cmp.lt     s4, s9, s1
    v.extract    s1, v6, #14
    s.or         s9, s8, s10
    s.movz       s8, #60
    v.insert     v11, s4, #12
    v.extract    s4, v1, #14
    s.shli       s10, s1, #32
    s.cmp.lt     s1, s9, s8
    v.extract    s8, v6, #15
    s.or         s9, s4, s10
    s.movz       s4, #60
    v.insert     v11, s1, #13
    v.extract    s1, v1, #15
    s.shli       s10, s8, #32
    v.movi       v1, #-1
    s.cmp.lt     s8, s9, s4
    s.or         s4, s1, s10
    s.movz       s1, #60
    v.insert     v11, s8, #14
    v.add        v2, v0, v1
    v.movi       v0, #3
    v.movi       v1, #0
    s.cmp.lt     s8, s4, s1
    v.movi       v6, #0
    v.insert     v11, s8, #15
    v.sub        v12, v1, v2
    v.sub        v13, v1, v0
    v.cmp.lt     p4, v2, v1
    v.cmp.lt     p5, v0, v1
    v.cmp.ne     p6, v11, v6
    .li       s1, #-1
    v.movi       v6, #1
    @p4 v.sel        v11, v12, v2
    @p5 v.sel        v12, v13, v0
    v.movi       v13, #0
    v.movi       v14, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v15, s1
    v.shl        v16, v14, v6
    v.cmp.lt     p5, v14, v1
    v.lshr       v17, v11, v15
    v.shl        v18, v6, v15
    s.subi       s4, s1, #1
    v.and        v15, v17, v6
    s.movz       s8, #0
    v.or         v17, v16, v15
    v.cmp.geu    p7, v17, v12
    p.or         p8, p5, p7
    v.sub        v15, v17, v12
    @p8 v.sel        v16, v18, v1
    @p8 v.sel        v18, v15, v17
    v.or         v15, v13, v16
    v.mov        v14, v18
    v.mov        v13, v15
    s.mov        s1, s4
    s.cmp.ge     s4, s1, s8
    br.nz        s4, idiv_3
    v.sub        v6, v1, v14
    @p4 v.sel        v1, v6, v14
    v.movi       v6, #0
    v.movi       v11, #0
    v.extract    s1, v1, #0
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #0
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #0
    v.extract    s1, v1, #1
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #1
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #1
    v.extract    s1, v1, #2
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #2
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #2
    v.extract    s1, v1, #3
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #3
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #3
    v.extract    s1, v1, #4
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #4
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #4
    v.extract    s1, v1, #5
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #5
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #5
    v.extract    s1, v1, #6
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #6
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #6
    v.extract    s1, v1, #7
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #7
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #7
    v.extract    s1, v1, #8
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #8
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #8
    v.extract    s1, v1, #9
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #9
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #9
    v.extract    s1, v1, #10
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #10
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #10
    v.extract    s1, v1, #11
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #11
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #11
    v.extract    s1, v1, #12
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #12
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #12
    v.extract    s1, v1, #13
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #13
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #13
    v.extract    s1, v1, #14
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #14
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #14
    v.extract    s1, v1, #15
    s.shli       s4, s1, #32
    s.ashri      s1, s4, #32
    v.insert     v6, s1, #15
    s.lshri      s4, s1, #32
    v.insert     v11, s4, #15
    v.movi       v12, #0
    v.extract    s1, v6, #0
    v.extract    s4, v11, #0
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #0
    v.extract    s1, v6, #1
    v.extract    s4, v11, #1
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #1
    v.extract    s1, v6, #2
    v.extract    s4, v11, #2
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #2
    v.extract    s1, v6, #3
    v.extract    s4, v11, #3
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #3
    v.extract    s1, v6, #4
    v.extract    s4, v11, #4
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #4
    v.extract    s1, v6, #5
    v.extract    s4, v11, #5
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #5
    v.extract    s1, v6, #6
    v.extract    s4, v11, #6
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #6
    v.extract    s1, v6, #7
    v.extract    s4, v11, #7
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #7
    v.extract    s1, v6, #8
    v.extract    s4, v11, #8
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #8
    v.extract    s1, v6, #9
    v.extract    s4, v11, #9
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #9
    v.extract    s1, v6, #10
    v.extract    s4, v11, #10
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #10
    v.extract    s1, v6, #11
    v.extract    s4, v11, #11
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #11
    v.extract    s1, v6, #12
    v.extract    s4, v11, #12
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #12
    v.extract    s1, v6, #13
    v.extract    s4, v11, #13
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #13
    v.extract    s1, v6, #14
    v.extract    s4, v11, #14
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #14
    v.extract    s1, v6, #15
    v.extract    s4, v11, #15
    s.shli       s8, s4, #32
    s.or         s4, s1, s8
    s.movz       s1, #0
    s.cmp.eq     s8, s4, s1
    v.insert     v12, s8, #15
    v.movi       v6, #0
    v.cmp.ne     p4, v12, v6
    p.and        p5, p2, p6
    p.and        p2, p5, p4
    s.movz       s1, #36
    v.movi       v6, #36
    v.add        v11, v5, v6
    p.and        p4, p2, p3
    v.movi       v5, #1
    v.shl        v6, v11, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v5, [s3, v6]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s3, #4
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v11, [s1, v6]              // index is in elements (ISA sec 9.1)
    v.movi       v6, #31
    v.ashr       v12, v11, v6
    v.xor        v6, v5, v12
    v.sub        v5, v6, v12
    v.movi       v6, #0
    v.cmp.eq     p5, v5, v6
    v.movi       v6, #1
    v.movi       v13, #0
    @p5 v.sel        v14, v6, v13
    v.and        v6, v12, v14
    v.xor        v13, v11, v12
    v.add        v12, v13, v6
    vf.cvt.u32.f32 v6, v5                        // |x| < 2**32: one rounding
    v.clz        v13, v12
    v.movi       v14, #32
    v.sub        v15, v14, v13
    v.shl        v14, v12, v13
    v.movi       v16, #1
    v.sub        v17, v15, v16
    v.lshr       v16, v5, v17
    v.movi       v17, #1
    v.lshr       v18, v16, v17
    v.or         v16, v14, v18
    v.movi       v14, #-1
    v.lshr       v17, v14, v13
    v.and        v13, v5, v17
    v.movi       v5, #0
    v.cmp.ne     p5, v13, v5
    v.movi       v5, #1
    v.movi       v13, #0
    @p5 v.sel        v14, v5, v13
    v.or         v5, v16, v14
    vf.cvt.u32.f32 v13, v5                       // top 32 bits + sticky: one rounding
    v.movi       v5, #127
    v.add        v14, v15, v5
    v.movi       v5, #23
    v.shl        v15, v14, v5
    vf.mul       v5, v13, v15                    // * 2**n, exact
    v.movi       v13, #0
    v.cmp.eq     p5, v12, v13
    @p5 v.sel        v12, v6, v5
    v.movi       v5, #0
    v.cmp.lt     p5, v11, v5
    vf.neg       v5, v12
    @p5 v.sel        v6, v5, v12
    v.movi       v5, #0
    v.movi       v11, #1
    v.cmp.lt     p5, v2, v5
    v.cmp.lt     p6, v0, v5
    v.sub        v12, v5, v2
    @p5 v.sel        v13, v12, v2
    v.sub        v12, v5, v0
    @p6 v.sel        v14, v12, v0
    v.movi       v12, #0
    v.movi       v15, #0
    s.movz       s1, #31
idiv_4:
    v.splat      v16, s1
    v.shl        v17, v15, v11
    v.cmp.lt     p7, v15, v5
    v.lshr       v18, v13, v16
    v.shl        v19, v11, v16
    s.subi       s3, s1, #1
    v.and        v16, v18, v11
    s.movz       s4, #0
    v.or         v18, v17, v16
    v.cmp.geu    p8, v18, v14
    p.or         p9, p7, p8
    v.sub        v16, v18, v14
    @p9 v.sel        v17, v19, v5
    @p9 v.sel        v19, v16, v18
    v.or         v16, v12, v17
    v.mov        v15, v19
    v.mov        v12, v16
    s.mov        s1, s3
    s.cmp.ge     s3, s1, s4
    br.nz        s3, idiv_4
    p.xor        p7, p5, p6
    v.sub        v11, v5, v12
    @p7 v.sel        v5, v11, v12
    v.cmp.ne     p5, v1, v8
    s.movz       s1, #1
    v.movi       v1, #1
    v.sub        v11, v5, v1
    @p5 v.sel        v12, v11, v5
    v.cmp.lt     p5, v2, v8
    @p5 v.sel        v2, v12, v5
    s.movz       s1, #3
    v.mul        v5, v2, v0
    v.add        v0, v5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v1, [s5, v0]               // index is in elements (ISA sec 9.1)
    vf.mul       v0, v6, v1
    vf.abs       v1, v0
    v.movi       v2, #23
    v.lshr       v5, v1, v2
    v.movi       v2, #127
    v.sub        v6, v5, v2
    .li       s1, #8388607
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v5, v1, v2
    .li       s1, #8388608
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.or         v8, v5, v2
    v.movi       v2, #-1
    v.max.s      v5, v6, v2
    v.movi       v2, #7
    v.add        v11, v5, v2
    v.movi       v2, #5
    v.lshr       v5, v11, v2
    v.movi       v2, #31
    v.and        v12, v11, v2
    v.movi       v2, #1
    v.cmp.eq     p4, v5, v2
    v.movi       v2, #2
    v.cmp.eq     p5, v5, v2
    v.movi       v2, #3
    v.cmp.eq     p6, v5, v2
    v.movi       v2, #4
    v.cmp.eq     p7, v5, v2
    v.movi       v2, #0
    .li       s1, #-1560706194
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v11, v5, v2
    .li       s1, #1313084713
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v5, v2, v11
    .li       s1, #-64530479
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v11, v2, v5
    .li       s1, #-181084736
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v5, v2, v11
    .li       s1, #-1560706194
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1313084713
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v13, v11, v2
    .li       s1, #-64530479
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v11, v2, v13
    .li       s1, #-181084736
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v13, v2, v11
    .li       s1, #-614296167
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v11, v2, v13
    .li       s1, #1313084713
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-64530479
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v14, v13, v2
    .li       s1, #-181084736
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v13, v2, v14
    .li       s1, #-614296167
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v14, v2, v13
    .li       s1, #1011060801
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v13, v2, v14
    .li       s1, #-64530479
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-181084736
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v15, v14, v2
    .li       s1, #-614296167
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v14, v2, v15
    .li       s1, #1011060801
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v15, v2, v14
    .li       s1, #-28220501
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v14, v2, v15
    v.movi       v2, #31
    v.sub        v15, v2, v12
    v.shl        v2, v5, v12
    v.movi       v5, #1
    v.lshr       v16, v11, v5
    v.lshr       v5, v16, v15
    v.or         v16, v2, v5
    v.shl        v2, v11, v12
    v.movi       v5, #1
    v.lshr       v11, v13, v5
    v.lshr       v5, v11, v15
    v.or         v11, v2, v5
    v.shl        v2, v13, v12
    v.movi       v5, #1
    v.lshr       v12, v14, v5
    v.lshr       v5, v12, v15
    v.or         v12, v2, v5
    v.mul        v2, v8, v12
    v.mulh.u     v5, v8, v12
    v.mul        v12, v8, v11
    v.add        v13, v12, v5
    v.cmp.ltu    p4, v13, v5
    v.movi       v5, #1
    v.movi       v12, #0
    @p4 v.sel        v14, v5, v12
    v.mul        v5, v8, v16
    v.mulh.u     v12, v8, v11
    v.add        v8, v5, v12
    v.add        v5, v8, v14
    .li       s1, #536870912
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v11, v5, v8
    v.movi       v8, #30
    v.lshr       v12, v11, v8
    v.movi       v8, #2
    v.shl        v11, v5, v8
    v.movi       v5, #30
    v.lshr       v8, v13, v5
    v.or         v5, v11, v8
    v.movi       v8, #2
    v.shl        v11, v13, v8
    v.movi       v8, #30
    v.lshr       v13, v2, v8
    v.or         v2, v11, v13
    v.movi       v8, #31
    v.ashr       v11, v5, v8
    v.xor        v8, v5, v11
    v.xor        v5, v2, v11
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v2
    @p4 v.sel        v2, v8, v5
    v.movi       v8, #0
    @p4 v.sel        v13, v5, v8
    v.clz        v5, v2
    v.shl        v8, v2, v5
    v.movi       v14, #1
    v.lshr       v15, v13, v14
    v.movi       v14, #31
    v.sub        v16, v14, v5
    v.lshr       v14, v15, v16
    v.or         v15, v8, v14
    v.shl        v8, v13, v5
    v.movi       v13, #0
    v.movi       v14, #32
    @p4 v.sel        v16, v13, v14
    v.add        v13, v5, v16
    v.movi       v5, #8
    v.lshr       v14, v15, v5
    vf.cvt.u32.f32 v5, v14
    v.movi       v14, #255
    v.and        v16, v15, v14
    v.movi       v14, #16
    v.shl        v15, v16, v14
    v.movi       v14, #16
    v.lshr       v16, v8, v14
    v.or         v8, v15, v16
    vf.cvt.u32.f32 v14, v8
    v.movi       v8, #103
    v.sub        v15, v8, v13
    v.movi       v8, #23
    v.shl        v16, v15, v8
    vf.mul       v8, v5, v16
    v.movi       v5, #79
    v.sub        v15, v5, v13
    v.movi       v5, #23
    v.shl        v13, v15, v5
    vf.mul       v5, v14, v13
    v.movi       v13, #0
    v.cmp.eq     p4, v2, v13
    .li       s1, #-2147483648
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v13, v11, v2
    v.movi       v2, #0
    v.xor        v11, v8, v13
    @p4 v.sel        v8, v2, v11
    v.xor        v11, v5, v13
    @p4 v.sel        v5, v2, v11
    .li       s1, #1070141403
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v13, v8, v11
    vf.fms       v14, v8, v11, v13               // exact error of f_hi*pi/2
    .li       s1, #3007036718
    v.splat      v15, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v16, v8, v15, v14
    vf.fma       v8, v5, v11, v16
    v.movi       v5, #-1
    v.cmp.lt     p4, v6, v5
    v.movi       v5, #0
    @p4 v.sel        v14, v5, v12
    @p4 v.sel        v5, v1, v13
    @p4 v.sel        v1, v2, v8
    vf.mul       v8, v5, v5
    vf.fms       v12, v5, v5, v8                 // exact error of r*r
    .li       s1, #1056964608
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v16, v8, v13
    vf.mul       v17, v5, v8
    vf.neg       v18, v16
    vf.fma       v19, v18, v1, v1
    .li       s1, #909535061
    v.splat      v18, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3109029817
    v.splat      v20, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v21, v18, v8, v20
    .li       s1, #1007192196
    v.splat      v22, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v23, v21, v8, v22
    .li       s1, #3190467243
    v.splat      v21, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v24, v23, v8, v21
    vf.fma       v23, v17, v24, v19
    vf.add       v17, v5, v23
    .li       s1, #1065353216
    v.splat      v19, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.sub       v23, v19, v16
    vf.sub       v24, v19, v23
    vf.sub       v25, v24, v16
    .li       s1, #3204448256
    v.splat      v16, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v24, v16, v12, v25
    vf.neg       v12, v5
    vf.fma       v5, v12, v1, v24
    vf.mul       v1, v8, v8
    .li       s1, #936178630
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3132491283
    v.splat      v24, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v25, v12, v8, v24
    .li       s1, #1026206373
    v.splat      v26, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v27, v25, v8, v26
    vf.fma       v8, v1, v27, v5
    vf.add       v1, v23, v8
    v.movi       v5, #1
    v.and        v8, v14, v5
    v.movi       v5, #0
    v.cmp.ne     p4, v8, v5
    v.movi       v5, #128
    v.cmp.eq     p5, v6, v5
    v.movi       v5, #2
    v.and        v6, v14, v5
    v.movi       v5, #30
    v.shl        v8, v6, v5
    .li       s1, #-2147483648
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v6, v0, v5
    v.xor        v0, v8, v6
    .li       s1, #2143289344
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v6, v1, v17
    v.xor        v8, v6, v0
    @p5 v.sel        v0, v5, v8
    v.movi       v6, #1
    v.add        v8, v14, v6
    v.movi       v6, #2
    v.and        v14, v8, v6
    v.movi       v6, #30
    v.shl        v8, v14, v6
    @p4 v.sel        v6, v17, v1
    v.xor        v1, v6, v8
    @p5 v.sel        v6, v5, v1
    v.movi       v1, #31
    v.ashr       v8, v3, v1
    v.xor        v1, v7, v8
    v.sub        v7, v1, v8
    v.movi       v1, #0
    v.cmp.eq     p4, v7, v1
    v.movi       v1, #1
    v.movi       v14, #0
    @p4 v.sel        v17, v1, v14
    v.and        v1, v8, v17
    v.xor        v14, v3, v8
    v.add        v8, v14, v1
    vf.cvt.u32.f32 v1, v7                        // |x| < 2**32: one rounding
    v.clz        v14, v8
    v.movi       v17, #32
    v.sub        v23, v17, v14
    v.shl        v17, v8, v14
    v.movi       v25, #1
    v.sub        v27, v23, v25
    v.lshr       v25, v7, v27
    v.movi       v27, #1
    v.lshr       v28, v25, v27
    v.or         v25, v17, v28
    v.movi       v17, #-1
    v.lshr       v27, v17, v14
    v.and        v14, v7, v27
    v.movi       v7, #0
    v.cmp.ne     p4, v14, v7
    v.movi       v7, #1
    v.movi       v14, #0
    @p4 v.sel        v17, v7, v14
    v.or         v7, v25, v17
    vf.cvt.u32.f32 v14, v7                       // top 32 bits + sticky: one rounding
    v.movi       v7, #127
    v.add        v17, v23, v7
    v.movi       v7, #23
    v.shl        v23, v17, v7
    vf.mul       v7, v14, v23                    // * 2**n, exact
    v.movi       v14, #0
    v.cmp.eq     p4, v8, v14
    @p4 v.sel        v8, v1, v7
    v.movi       v1, #0
    v.cmp.lt     p4, v3, v1
    vf.neg       v1, v8
    @p4 v.sel        v3, v1, v8
    vf.mul       v1, v3, v4
    vf.abs       v3, v1
    v.movi       v7, #23
    v.lshr       v8, v3, v7
    v.movi       v7, #127
    v.sub        v14, v8, v7
    .li       s1, #8388607
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v8, v3, v7
    .li       s1, #8388608
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.or         v17, v8, v7
    v.movi       v7, #-1
    v.max.s      v8, v14, v7
    v.movi       v7, #7
    v.add        v23, v8, v7
    v.movi       v7, #5
    v.lshr       v8, v23, v7
    v.movi       v7, #31
    v.and        v25, v23, v7
    v.movi       v7, #1
    v.cmp.eq     p4, v8, v7
    v.movi       v7, #2
    v.cmp.eq     p5, v8, v7
    v.movi       v7, #3
    v.cmp.eq     p6, v8, v7
    v.movi       v7, #4
    v.cmp.eq     p7, v8, v7
    v.movi       v7, #0
    .li       s1, #-1560706194
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v23, v8, v7
    .li       s1, #1313084713
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v8, v7, v23
    .li       s1, #-64530479
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v23, v7, v8
    .li       s1, #-181084736
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v8, v7, v23
    .li       s1, #-1560706194
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1313084713
    v.splat      v23, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v27, v23, v7
    .li       s1, #-64530479
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v23, v7, v27
    .li       s1, #-181084736
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v27, v7, v23
    .li       s1, #-614296167
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v23, v7, v27
    .li       s1, #1313084713
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-64530479
    v.splat      v27, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v28, v27, v7
    .li       s1, #-181084736
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v27, v7, v28
    .li       s1, #-614296167
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v28, v7, v27
    .li       s1, #1011060801
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v27, v7, v28
    .li       s1, #-64530479
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-181084736
    v.splat      v28, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v29, v28, v7
    .li       s1, #-614296167
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v28, v7, v29
    .li       s1, #1011060801
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v29, v7, v28
    .li       s1, #-28220501
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v28, v7, v29
    v.movi       v7, #31
    v.sub        v29, v7, v25
    v.shl        v7, v8, v25
    v.movi       v8, #1
    v.lshr       v30, v23, v8
    v.lshr       v8, v30, v29
    v.or         v30, v7, v8
    v.shl        v7, v23, v25
    v.movi       v8, #1
    v.lshr       v23, v27, v8
    v.lshr       v8, v23, v29
    v.or         v23, v7, v8
    v.shl        v7, v27, v25
    v.movi       v8, #1
    v.lshr       v25, v28, v8
    v.lshr       v8, v25, v29
    v.or         v25, v7, v8
    v.mul        v7, v17, v25
    v.mulh.u     v8, v17, v25
    v.mul        v25, v17, v23
    v.add        v27, v25, v8
    v.cmp.ltu    p4, v27, v8
    v.movi       v8, #1
    v.movi       v25, #0
    @p4 v.sel        v28, v8, v25
    v.mul        v8, v17, v30
    v.mulh.u     v25, v17, v23
    v.add        v17, v8, v25
    v.add        v8, v17, v28
    .li       s1, #536870912
    v.splat      v17, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v23, v8, v17
    v.movi       v17, #30
    v.lshr       v25, v23, v17
    v.movi       v17, #2
    v.shl        v23, v8, v17
    v.movi       v8, #30
    v.lshr       v17, v27, v8
    v.or         v8, v23, v17
    v.movi       v17, #2
    v.shl        v23, v27, v17
    v.movi       v17, #30
    v.lshr       v27, v7, v17
    v.or         v7, v23, v27
    v.movi       v17, #31
    v.ashr       v23, v8, v17
    v.xor        v17, v8, v23
    v.xor        v8, v7, v23
    v.movi       v7, #0
    v.cmp.ne     p4, v17, v7
    @p4 v.sel        v7, v17, v8
    v.movi       v17, #0
    @p4 v.sel        v27, v8, v17
    v.clz        v8, v7
    v.shl        v17, v7, v8
    v.movi       v28, #1
    v.lshr       v29, v27, v28
    v.movi       v28, #31
    v.sub        v30, v28, v8
    v.lshr       v28, v29, v30
    v.or         v29, v17, v28
    v.shl        v17, v27, v8
    v.movi       v27, #0
    v.movi       v28, #32
    @p4 v.sel        v30, v27, v28
    v.add        v27, v8, v30
    v.movi       v8, #8
    v.lshr       v28, v29, v8
    vf.cvt.u32.f32 v8, v28
    v.movi       v28, #255
    v.and        v30, v29, v28
    v.movi       v28, #16
    v.shl        v29, v30, v28
    v.movi       v28, #16
    v.lshr       v30, v17, v28
    v.or         v17, v29, v30
    vf.cvt.u32.f32 v28, v17
    v.movi       v17, #103
    v.sub        v29, v17, v27
    v.movi       v17, #23
    v.shl        v30, v29, v17
    vf.mul       v17, v8, v30
    v.movi       v8, #79
    v.sub        v29, v8, v27
    v.movi       v8, #23
    v.shl        v27, v29, v8
    vf.mul       v8, v28, v27
    v.movi       v27, #0
    v.cmp.eq     p4, v7, v27
    .li       s1, #-2147483648
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v27, v23, v7
    v.xor        v7, v17, v27
    @p4 v.sel        v17, v2, v7
    v.xor        v7, v8, v27
    @p4 v.sel        v8, v2, v7
    vf.mul       v7, v17, v11
    vf.fms       v23, v17, v11, v7               // exact error of f_hi*pi/2
    vf.fma       v27, v17, v15, v23
    vf.fma       v17, v8, v11, v27
    v.movi       v8, #-1
    v.cmp.lt     p4, v14, v8
    v.movi       v8, #0
    @p4 v.sel        v23, v8, v25
    @p4 v.sel        v8, v3, v7
    @p4 v.sel        v3, v2, v17
    vf.mul       v7, v8, v8
    vf.fms       v17, v8, v8, v7                 // exact error of r*r
    vf.mul       v25, v7, v13
    vf.mul       v27, v8, v7
    vf.neg       v28, v25
    vf.fma       v29, v28, v3, v3
    vf.fma       v28, v18, v7, v20
    vf.fma       v30, v28, v7, v22
    vf.fma       v28, v30, v7, v21
    vf.fma       v30, v27, v28, v29
    vf.add       v27, v8, v30
    vf.sub       v28, v19, v25
    vf.sub       v29, v19, v28
    vf.sub       v30, v29, v25
    vf.fma       v25, v16, v17, v30
    vf.neg       v17, v8
    vf.fma       v8, v17, v3, v25
    vf.mul       v3, v7, v7
    vf.fma       v17, v12, v7, v24
    vf.fma       v25, v17, v7, v26
    vf.fma       v7, v3, v25, v8
    vf.add       v3, v28, v7
    v.movi       v7, #1
    v.and        v8, v23, v7
    v.movi       v7, #0
    v.cmp.ne     p4, v8, v7
    v.movi       v7, #128
    v.cmp.eq     p5, v14, v7
    v.movi       v7, #2
    v.and        v8, v23, v7
    v.movi       v7, #30
    v.shl        v14, v8, v7
    .li       s1, #-2147483648
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v8, v1, v7
    v.xor        v1, v14, v8
    @p4 v.sel        v7, v3, v27
    v.xor        v8, v7, v1
    @p5 v.sel        v1, v5, v8
    v.movi       v7, #1
    v.add        v8, v23, v7
    v.movi       v7, #2
    v.and        v14, v8, v7
    v.movi       v7, #30
    v.shl        v8, v14, v7
    @p4 v.sel        v7, v27, v3
    v.xor        v3, v7, v8
    @p5 v.sel        v7, v5, v3
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #31
    v.ashr       v1, v10, v0
    v.xor        v0, v9, v1
    v.sub        v8, v0, v1
    v.movi       v0, #0
    v.cmp.eq     p4, v8, v0
    v.movi       v0, #1
    v.movi       v9, #0
    @p4 v.sel        v14, v0, v9
    v.and        v0, v1, v14
    v.xor        v9, v10, v1
    v.add        v1, v9, v0
    vf.cvt.u32.f32 v0, v8                        // |x| < 2**32: one rounding
    v.clz        v9, v1
    v.movi       v14, #32
    v.sub        v17, v14, v9
    v.shl        v14, v1, v9
    v.movi       v23, #1
    v.sub        v25, v17, v23
    v.lshr       v23, v8, v25
    v.movi       v25, #1
    v.lshr       v27, v23, v25
    v.or         v23, v14, v27
    v.movi       v14, #-1
    v.lshr       v25, v14, v9
    v.and        v9, v8, v25
    v.movi       v8, #0
    v.cmp.ne     p4, v9, v8
    v.movi       v8, #1
    v.movi       v9, #0
    @p4 v.sel        v14, v8, v9
    v.or         v8, v23, v14
    vf.cvt.u32.f32 v9, v8                        // top 32 bits + sticky: one rounding
    v.movi       v8, #127
    v.add        v14, v17, v8
    v.movi       v8, #23
    v.shl        v17, v14, v8
    vf.mul       v8, v9, v17                     // * 2**n, exact
    v.movi       v9, #0
    v.cmp.eq     p4, v1, v9
    @p4 v.sel        v1, v0, v8
    v.movi       v0, #0
    v.cmp.lt     p4, v10, v0
    vf.neg       v0, v1
    @p4 v.sel        v8, v0, v1
    vf.mul       v0, v8, v4
    vf.abs       v1, v0
    v.movi       v4, #23
    v.lshr       v8, v1, v4
    v.movi       v4, #127
    v.sub        v9, v8, v4
    .li       s1, #8388607
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v8, v1, v4
    .li       s1, #8388608
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.or         v10, v8, v4
    v.movi       v4, #-1
    v.max.s      v8, v9, v4
    v.movi       v4, #7
    v.add        v14, v8, v4
    v.movi       v4, #5
    v.lshr       v8, v14, v4
    v.movi       v4, #31
    v.and        v17, v14, v4
    v.movi       v4, #1
    v.cmp.eq     p4, v8, v4
    v.movi       v4, #2
    v.cmp.eq     p5, v8, v4
    v.movi       v4, #3
    v.cmp.eq     p6, v8, v4
    v.movi       v4, #4
    v.cmp.eq     p7, v8, v4
    v.movi       v4, #0
    .li       s1, #-1560706194
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v14, v8, v4
    .li       s1, #1313084713
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v8, v4, v14
    .li       s1, #-64530479
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v14, v4, v8
    .li       s1, #-181084736
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v8, v4, v14
    .li       s1, #-1560706194
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1313084713
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v23, v14, v4
    .li       s1, #-64530479
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v14, v4, v23
    .li       s1, #-181084736
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v23, v4, v14
    .li       s1, #-614296167
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v14, v4, v23
    .li       s1, #1313084713
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-64530479
    v.splat      v23, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v25, v23, v4
    .li       s1, #-181084736
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v23, v4, v25
    .li       s1, #-614296167
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v25, v4, v23
    .li       s1, #1011060801
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v23, v4, v25
    .li       s1, #-64530479
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-181084736
    v.splat      v25, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v27, v25, v4
    .li       s1, #-614296167
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v25, v4, v27
    .li       s1, #1011060801
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v27, v4, v25
    .li       s1, #-28220501
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v25, v4, v27
    v.movi       v4, #31
    v.sub        v27, v4, v17
    v.shl        v4, v8, v17
    v.movi       v8, #1
    v.lshr       v28, v14, v8
    v.lshr       v8, v28, v27
    v.or         v28, v4, v8
    v.shl        v4, v14, v17
    v.movi       v8, #1
    v.lshr       v14, v23, v8
    v.lshr       v8, v14, v27
    v.or         v14, v4, v8
    v.shl        v4, v23, v17
    v.movi       v8, #1
    v.lshr       v17, v25, v8
    v.lshr       v8, v17, v27
    v.or         v17, v4, v8
    v.mul        v4, v10, v17
    v.mulh.u     v8, v10, v17
    v.mul        v17, v10, v14
    v.add        v23, v17, v8
    v.cmp.ltu    p4, v23, v8
    v.movi       v8, #1
    v.movi       v17, #0
    @p4 v.sel        v25, v8, v17
    v.mul        v8, v10, v28
    v.mulh.u     v17, v10, v14
    v.add        v10, v8, v17
    v.add        v8, v10, v25
    .li       s1, #536870912
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v14, v8, v10
    v.movi       v10, #30
    v.lshr       v17, v14, v10
    v.movi       v10, #2
    v.shl        v14, v8, v10
    v.movi       v8, #30
    v.lshr       v10, v23, v8
    v.or         v8, v14, v10
    v.movi       v10, #2
    v.shl        v14, v23, v10
    v.movi       v10, #30
    v.lshr       v23, v4, v10
    v.or         v4, v14, v23
    v.movi       v10, #31
    v.ashr       v14, v8, v10
    v.xor        v10, v8, v14
    v.xor        v8, v4, v14
    v.movi       v4, #0
    v.cmp.ne     p4, v10, v4
    @p4 v.sel        v4, v10, v8
    v.movi       v10, #0
    @p4 v.sel        v23, v8, v10
    v.clz        v8, v4
    v.shl        v10, v4, v8
    v.movi       v25, #1
    v.lshr       v27, v23, v25
    v.movi       v25, #31
    v.sub        v28, v25, v8
    v.lshr       v25, v27, v28
    v.or         v27, v10, v25
    v.shl        v10, v23, v8
    v.movi       v23, #0
    v.movi       v25, #32
    @p4 v.sel        v28, v23, v25
    v.add        v23, v8, v28
    v.movi       v8, #8
    v.lshr       v25, v27, v8
    vf.cvt.u32.f32 v8, v25
    v.movi       v25, #255
    v.and        v28, v27, v25
    v.movi       v25, #16
    v.shl        v27, v28, v25
    v.movi       v25, #16
    v.lshr       v28, v10, v25
    v.or         v10, v27, v28
    vf.cvt.u32.f32 v25, v10
    v.movi       v10, #103
    v.sub        v27, v10, v23
    v.movi       v10, #23
    v.shl        v28, v27, v10
    vf.mul       v10, v8, v28
    v.movi       v8, #79
    v.sub        v27, v8, v23
    v.movi       v8, #23
    v.shl        v23, v27, v8
    vf.mul       v8, v25, v23
    v.movi       v23, #0
    v.cmp.eq     p4, v4, v23
    .li       s1, #-2147483648
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v23, v14, v4
    v.xor        v4, v10, v23
    @p4 v.sel        v10, v2, v4
    v.xor        v4, v8, v23
    @p4 v.sel        v8, v2, v4
    vf.mul       v4, v10, v11
    vf.fms       v14, v10, v11, v4               // exact error of f_hi*pi/2
    vf.fma       v23, v10, v15, v14
    vf.fma       v10, v8, v11, v23
    v.movi       v8, #-1
    v.cmp.lt     p4, v9, v8
    v.movi       v8, #0
    @p4 v.sel        v11, v8, v17
    @p4 v.sel        v8, v1, v4
    @p4 v.sel        v1, v2, v10
    vf.mul       v2, v8, v8
    vf.fms       v4, v8, v8, v2                  // exact error of r*r
    vf.mul       v10, v2, v13
    vf.mul       v13, v8, v2
    vf.neg       v14, v10
    vf.fma       v15, v14, v1, v1
    vf.fma       v14, v18, v2, v20
    vf.fma       v17, v14, v2, v22
    vf.fma       v14, v17, v2, v21
    vf.fma       v17, v13, v14, v15
    vf.add       v13, v8, v17
    vf.sub       v14, v19, v10
    vf.sub       v15, v19, v14
    vf.sub       v17, v15, v10
    vf.fma       v10, v16, v4, v17
    vf.neg       v4, v8
    vf.fma       v8, v4, v1, v10
    vf.mul       v1, v2, v2
    vf.fma       v4, v12, v2, v24
    vf.fma       v10, v4, v2, v26
    vf.fma       v2, v1, v10, v8
    vf.add       v1, v14, v2
    v.movi       v2, #1
    v.and        v4, v11, v2
    v.movi       v2, #0
    v.cmp.ne     p4, v4, v2
    v.movi       v2, #128
    v.cmp.eq     p5, v9, v2
    v.movi       v2, #2
    v.and        v4, v11, v2
    v.movi       v2, #30
    v.shl        v8, v4, v2
    .li       s1, #-2147483648
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v4, v0, v2
    v.xor        v0, v8, v4
    @p4 v.sel        v2, v1, v13
    v.xor        v4, v2, v0
    @p5 v.sel        v0, v5, v4
    v.movi       v2, #1
    v.add        v4, v11, v2
    v.movi       v2, #2
    v.and        v8, v4, v2
    v.movi       v2, #30
    v.shl        v4, v8, v2
    @p4 v.sel        v2, v13, v1
    v.xor        v1, v2, v4
    @p5 v.sel        v2, v5, v1
    @p1 v.sel        v1, v3, v0
    @p2 v.sel        v0, v6, v7
    @p1 v.sel        v3, v0, v2
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    s.add        s2, s6, s1                      // &out_ptr0[...]
    @p3 v.st.w       [s2, #0], v1
    s.add        s2, s7, s1                      // &out_ptr1[...]
    @p3 v.st.w       [s2, #0], v3
__rctx_next:
    exit
