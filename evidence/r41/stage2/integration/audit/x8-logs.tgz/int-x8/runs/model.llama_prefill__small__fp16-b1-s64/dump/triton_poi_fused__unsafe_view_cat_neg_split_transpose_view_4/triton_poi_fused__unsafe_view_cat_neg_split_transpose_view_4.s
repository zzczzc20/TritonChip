    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #4
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.movi       v6, #0
    @p1 v.sel        v7, v4, v5
    v.sub        v4, v1, v3
    v.cmp.lt     p1, v3, v1
    v.sub        v5, v0, v3
    v.sub        v8, v6, v7
    @p1 v.sel        v9, v4, v3
    v.cmp.lt     p2, v3, v0
    v.cmp.lt     p3, v7, v6
    @p2 v.sel        v4, v5, v3
    v.movi       v3, #15
    @p3 v.sel        v5, v8, v7
    v.movi       v8, #63
    v.and        v10, v4, v3
    v.and        v3, v5, v8
    v.sub        v4, v0, v10
    v.sub        v5, v6, v3
    @p2 v.sel        v8, v4, v10
    @p3 v.sel        v4, v5, v3
    s.rdspecial  s1, arg_base
    v.movi       v3, #16
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v5, #64
    v.movi       v10, #1024
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.cmp.lt     p2, v3, v0
    v.sub        v11, v0, v3
    v.cmp.lt     p3, v3, v2
    v.sub        v0, v2, v3
    @p2 v.sel        v2, v11, v3
    v.movi       v2, #10
    v.cmp.lt     p2, v5, v6
    v.lshr       v11, v9, v2
    v.movi       v2, #32
    v.sub        v9, v6, v5
    v.mul        v6, v7, v2
    @p3 v.sel        v7, v0, v3
    v.sub        v0, v1, v11
    v.movi       v3, #128
    @p1 v.sel        v7, v0, v11
    v.mul        v0, v4, v3
    v.mul        v3, v7, v2
    v.sub        v2, v1, v10
    v.add        v4, v8, v3
    v.add        v3, v8, v6
    v.add        v6, v4, v0
    v.cmp.lt     p1, v10, v1
    v.ld.gather.h v0, [s2, v6]                   // index is in elements (ISA sec 9.1)
    @p2 v.sel        v1, v9, v5
    @p1 v.sel        v1, v2, v10
    v.st.scatter.h [s3, v3], v0
__rctx_next:
    exit
