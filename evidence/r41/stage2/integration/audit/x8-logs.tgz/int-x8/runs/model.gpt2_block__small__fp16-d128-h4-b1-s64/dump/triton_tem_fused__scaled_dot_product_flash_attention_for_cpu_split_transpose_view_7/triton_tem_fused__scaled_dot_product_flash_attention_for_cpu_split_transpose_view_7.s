    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #2
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #1
    s.movz       s6, #4
    s.xor        s8, s5, s3
    s.movz       s9, #1
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s9
    s.movz       s8, #0
    s.cmp.lt     s9, s12, s3
    s.movz       s3, #0
    s.cmp.lt     s13, s4, s11
    s.sub        s11, s8, s9
    s.sub        s8, s3, s13
    s.xor        s3, s12, s11
    s.muli       s9, s5, #2
    s.movz       s5, #0
    s.movz       s13, #1
    s.xor        s14, s4, s8
    s.sub        s15, s3, s11
    s.rdspecial  s3, arg_base
    s.xor        s11, s1, s7
    s.movz       s16, #0
    s.sub        s17, s14, s8
    s.addi       s14, s5, #0
    s.cmp.eq     s5, s15, s13
    s.ld.d       s13, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s18, s11, s7
    s.sub        s7, s2, s9
    s.ld.d       s2, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.addi       s7, s16, #0
    s.ld.d       s9, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s14, s17
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s14, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s17, s3
    s.shli       s11, s7, #1
    s.andi       s16, s5, #1
    s.movz       s5, #0
    s.or         s18, s11, s16
    s.movz       s11, #1
    s.cmp.geu    s16, s18, s15
    s.shl        s19, s11, s3
    s.sub        s11, s5, s16
    s.subi       s5, s3, #1
    s.and        s16, s15, s11
    s.and        s20, s19, s11
    s.sub        s11, s18, s16
    s.or         s16, s14, s20
    s.mov        s7, s11
    s.mov        s14, s16
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s11, s3, s5
    br.nz        s11, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s11, s4, s3
    s.movz       s3, #0
    s.sub        s14, s5, s11
    s.movz       s5, #0
    s.xor        s11, s4, s14
    s.movz       s4, #0
    s.sub        s15, s11, s14
    s.cmp.lt     s11, s12, s3
    s.lshri      s3, s15, #1
    s.movz       s16, #0
    s.muli       s17, s3, #2
    s.sub        s3, s4, s11
    s.movz       s4, #0
    s.cmp.lt     s11, s1, s16
    s.xor        s16, s12, s3
    s.sub        s12, s15, s17
    s.movz       s15, #0
    s.xor        s17, s12, s14
    s.xor        s12, s7, s8
    s.sub        s7, s17, s14
    s.sub        s14, s15, s11
    s.cmp.lt     s11, s7, s5
    s.sub        s5, s16, s3
    s.sub        s15, s4, s11
    s.movz       s4, #0
    s.xor        s11, s7, s15
    s.movz       s7, #1
    s.sub        s16, s12, s8
    s.xor        s8, s1, s14
    s.sub        s1, s11, s15
    s.movz       s11, #0
    s.addi       s12, s4, #0
    s.cmp.eq     s4, s5, s7
    s.add        s7, s10, s16
    s.sub        s10, s8, s14
    s.addi       s8, s11, #0
    s.mov        s12, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s10, #31
    s.mov        s12, s4
    s.addi       s4, s10, #0
sdiv_4:
    s.lshr       s10, s1, s4
    s.shli       s11, s8, #1
    s.andi       s14, s10, #1
    s.movz       s10, #0
    s.or         s16, s11, s14
    s.movz       s11, #1
    s.cmp.geu    s14, s16, s5
    s.shl        s17, s11, s4
    s.sub        s11, s10, s14
    s.subi       s10, s4, #1
    s.and        s14, s5, s11
    s.and        s18, s17, s11
    s.sub        s11, s16, s14
    s.or         s14, s12, s18
    s.mov        s8, s11
    s.mov        s12, s14
    s.mov        s4, s10
    s.movz       s10, #0
    s.cmp.ge     s11, s4, s10
    br.nz        s11, sdiv_4
sdiv_done_3:
    s.movz       s1, #16
    s.rdspecial  s4, pid.z
    s.rdspecial  s5, npid.y
    s.xor        s8, s15, s3
    s.mul        s3, s7, s1
    s.mul        s10, s4, s5
    s.xor        s4, s12, s8
    s.rdspecial  s5, pid.y
    s.sub        s11, s4, s8
    s.andi       s4, s3, #63
    s.mul        s8, s11, s1
    s.add        s12, s5, s10
    s.movz       s5, #3
    s.movz       s10, #4096
    s.min.s      s14, s12, s5
    s.movz       s5, #2048
    s.muli       s15, s4, #64                    // a runtime tile origin, x64
    s.mul        s16, s14, s10
    s.mul        s10, s14, s5
    s.rdspecial  s14, role_id
    s.movz       s17, #6144
    s.andi       s18, s8, #31
    s.movz       s19, #0
    s.rdspecial  s20, arg_base
    s.mul        s21, s14, s17
    s.add        s14, s19, s15                   // the tile origin
    s.ld.d       s15, [s20, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s17, s14, s16                   // the tile origin
    s.movz       s14, #0
    s.add        s16, s15, s21                   // this context's own scratch
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s15, s16, #0
    v.splat      v1, s7
    v.splat      v2, s17
    v.splat      v3, s14
    v.splat      v4, s11
    v.splat      v5, s14
    v.add        v6, v0, v2
    v.cmp.ge     p1, v1, v3
    s.addi       s7, s17, #64
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s7
    s.addi       s7, s15, #64
    v.cmp.ge     p1, v4, v5
    s.addi       s11, s17, #128
    v.splat      v3, s3
    v.splat      v4, s11
    v.add        v5, v0, v2
    s.addi       s11, s15, #128
    v.add        v2, v3, v1
    v.splat      v2, s8
    v.add        v3, v0, v4
    s.addi       s19, s15, #192
    v.add        v4, v2, v1
    s.addi       s20, s17, #192
    v.splat      v1, s4
    v.splat      v2, s20
    s.movz       s4, #64
    v.add        v4, v0, v2
    s.addi       s20, s14, #0
    v.st.w       [s15, #0], v6
    v.iota       v2                              // arange(0, VLEN)
    v.add        v6, v1, v2
    s.addi       s14, s17, #256
    v.splat      v1, s18
    v.splat      v2, s14
    s.addi       s14, s15, #256
    v.st.w       [s7, #0], v5
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v2
    v.add        v2, v1, v5
    s.addi       s7, s17, #320
    s.addi       s21, s17, #384
    s.addi       s22, s17, #448
    v.splat      v1, s7
    s.addi       s7, s17, #512
    v.splat      v2, s21
    s.addi       s21, s17, #576
    v.add        v5, v0, v1
    v.add        v1, v0, v2
    v.st.w       [s11, #0], v3
    s.addi       s11, s17, #640
    v.splat      v2, s22
    s.addi       s22, s17, #704
    v.add        v3, v0, v2
    v.st.w       [s19, #0], v4
    s.addi       s19, s17, #768
    v.splat      v2, s7
    s.addi       s7, s17, #832
    v.add        v4, v0, v2
    v.st.w       [s14, #0], v6
    s.addi       s14, s17, #896
    v.splat      v2, s21
    s.addi       s21, s15, #320
    s.addi       s23, s17, #960
    v.add        v6, v0, v2
    v.st.w       [s21, #0], v5
    v.splat      v2, s11
    s.addi       s11, s15, #384
    s.addi       s17, s16, #1024
    v.add        v5, v0, v2
    v.st.w       [s11, #0], v1
    s.movz       s11, #0
    v.splat      v1, s22
    s.addi       s21, s15, #448
    s.add        s22, s11, s18                   // the tile origin
    s.addi       s11, s15, #512
    s.add        s18, s22, s10                   // the tile origin
    s.addi       s10, s15, #576
    v.add        v2, v0, v1
    v.st.w       [s21, #0], v3
    s.addi       s21, s18, #32
    v.splat      v1, s19
    s.addi       s19, s15, #640
    v.add        v3, v0, v1
    v.st.w       [s11, #0], v4
    s.addi       s11, s18, #64
    v.splat      v1, s7
    s.addi       s7, s15, #704
    v.add        v4, v0, v1
    v.st.w       [s10, #0], v6
    s.addi       s10, s18, #96
    v.splat      v1, s14
    s.addi       s14, s15, #768
    v.add        v6, v0, v1
    v.st.w       [s19, #0], v5
    s.addi       s19, s18, #128
    v.splat      v1, s23
    s.addi       s22, s15, #832
    v.add        v5, v0, v1
    v.st.w       [s7, #0], v2
    s.addi       s7, s18, #160
    v.splat      v1, s18
    v.add        v2, v0, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s18, #192
    v.splat      v1, s21
    s.addi       s21, s15, #896
    s.addi       s23, s15, #960
    v.add        v3, v0, v1
    v.st.w       [s22, #0], v4
    s.addi       s15, s18, #224
    v.splat      v1, s11
    s.addi       s11, s17, #64
    v.add        v4, v0, v1
    v.st.w       [s21, #0], v6
    s.addi       s21, s18, #256
    v.splat      v1, s10
    s.addi       s10, s17, #128
    v.add        v6, v0, v1
    v.st.w       [s23, #0], v5
    v.splat      v1, s19
    s.addi       s19, s17, #192
    s.addi       s22, s17, #256
    v.add        v5, v0, v1
    fence.acq_rel.device
    v.st.w       [s17, #0], v2
    v.splat      v1, s7
    s.addi       s7, s18, #288
    v.add        v2, v0, v1
    v.st.w       [s11, #0], v3
    s.addi       s11, s18, #320
    v.splat      v1, s14
    s.addi       s14, s18, #352
    v.add        v3, v0, v1
    v.st.w       [s10, #0], v4
    s.addi       s10, s18, #384
    v.splat      v1, s15
    s.addi       s15, s18, #416
    v.add        v4, v0, v1
    v.st.w       [s19, #0], v6
    s.addi       s19, s18, #448
    v.splat      v1, s21
    s.addi       s21, s17, #320
    v.add        v6, v0, v1
    v.st.w       [s22, #0], v5
    s.addi       s22, s18, #480
    v.splat      v1, s7
    s.addi       s7, s17, #384
    s.addi       s18, s17, #448
    v.add        v5, v0, v1
    v.st.w       [s21, #0], v2
    v.splat      v1, s11
    s.addi       s11, s17, #512
    s.addi       s21, s17, #576
    v.add        v2, v0, v1
    v.st.w       [s7, #0], v3
    v.splat      v1, s14
    s.addi       s7, s17, #640
    s.addi       s14, s17, #704
    v.add        v3, v0, v1
    v.st.w       [s18, #0], v4
    v.splat      v1, s10
    s.addi       s10, s17, #768
    v.add        v4, v0, v1
    s.addi       s18, s17, #832
    v.st.w       [s11, #0], v6
    v.splat      v1, s15
    s.addi       s11, s17, #896
    v.add        v6, v0, v1
    s.addi       s15, s17, #960
    v.st.w       [s21, #0], v5
    v.splat      v1, s19
    v.add        v5, v0, v1
    v.st.w       [s7, #0], v2
    v.splat      v1, s22
    v.add        v2, v0, v1
    v.st.w       [s14, #0], v3
    v.st.w       [s10, #0], v4
    v.st.w       [s18, #0], v6
    v.st.w       [s11, #0], v5
    v.st.w       [s15, #0], v2
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s7, s20, s4
    br.nz        s7, endfor_6
    s.addi       s7, s16, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s10, #0
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s16, #64
    s.movz       s11, #1
    s.addi       s14, s16, #128
    s.movz       s15, #2
    s.addi       s17, s16, #192
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v2
    v.ld.w       v1, [s7, #0]
    s.movz       s7, #3
    s.addi       s10, s16, #256
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s11, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s11, #4
    s.addi       s14, s16, #320
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s15, #5
    s.addi       s17, s16, #384
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v2
    v.ld.w       v1, [s10, #0]
    s.movz       s7, #6
    s.addi       s10, s16, #448
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s11, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s11, #7
    s.addi       s14, s16, #512
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s15, #8
    s.addi       s17, s16, #576
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v2
    v.ld.w       v1, [s10, #0]
    s.movz       s7, #9
    s.addi       s10, s16, #640
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s11, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s11, #10
    s.addi       s14, s16, #704
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s15, #11
    s.addi       s17, s16, #768
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v2
    v.ld.w       v1, [s10, #0]
    s.movz       s7, #12
    s.addi       s10, s16, #832
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s11, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s11, #13
    s.addi       s14, s16, #896
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s15, #14
    s.addi       s17, s16, #960
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v2
    v.ld.w       v1, [s10, #0]
    s.movz       s7, #15
    s.addi       s10, s16, #1024
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s11, v2
    v.ld.w       v1, [s14, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s11, #0
    s.addi       s14, s16, #1088
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s15, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s15, #1
    s.addi       s17, s16, #1152
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    s.movz       s18, #2
    a.vwrite     a1, s7, v2
    v.ld.w       v1, [s10, #0]
    s.addi       s7, s16, #1216
    s.movz       s10, #3
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s11, v2
    v.ld.w       v1, [s14, #0]
    s.addi       s11, s16, #1280
    s.movz       s14, #4
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v2
    v.ld.w       v1, [s17, #0]
    s.addi       s15, s16, #1344
    s.movz       s17, #5
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s18, v2
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s16, #1408
    s.movz       s18, #6
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s10, v2
    v.ld.w       v1, [s11, #0]
    s.addi       s10, s16, #1472
    s.movz       s11, #7
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v2
    v.ld.w       v1, [s15, #0]
    s.addi       s14, s16, #1536
    s.movz       s15, #8
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v2
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s16, #1600
    s.movz       s17, #9
    v.movi       v2, #0
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s18, v3
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s16, #1664
    s.movz       s18, #10
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s11, v3
    v.ld.w       v1, [s14, #0]
    s.addi       s11, s16, #1728
    s.movz       s14, #11
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s16, #1792
    s.movz       s15, #12
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s16, #1856
    s.movz       s17, #13
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s18, v3
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #1920
    s.movz       s18, #14
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s16, #1984
    s.movz       s14, #15
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v1, [s10, #0]
    s.movz       s10, #0
    s.movz       s15, #0
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v1, [s11, #0]
    s.movz       s11, #1
    s.movz       s17, #2
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s18, v3
    v.ld.w       v1, [s7, #0]
    s.movz       s7, #3
    s.movz       s18, #4
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s19, #5
    a.vwrite     a2, s14, v3
    a.vread      v1, a1, s10
    a.vread      v3, a2, s15
    v.extract    s10, v1, #0
    v.splat      v4, s10
    v.extract    s10, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s10
    a.vread      v4, a2, s11
    v.extract    s10, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s10
    a.vread      v4, a2, s17
    v.extract    s10, v1, #3
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    v.extract    s7, v1, #4
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s18
    v.extract    s7, v1, #5
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s7
    a.vread      v4, a2, s19
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s7, #0
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #1
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #1
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #2
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #2
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #3
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #4
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #5
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #6
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #7
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #8
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #9
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #9
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #10
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #11
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #12
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #13
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #14
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s7
    a.vread      v4, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s7
    a.vread      v4, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #3
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #4
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #5
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #6
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s10, v1, #7
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s10, v1, #8
    v.splat      v3, s10
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v5, v3, v4, v6
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #10
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #11
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #12
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #13
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #14
    v.splat      v3, s11
    a.vread      v4, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v3, a2, s10
    s.movz       s10, #15
    vf.fma       v4, v1, v3, v5
    s.movz       s11, #0
    s.movz       s14, #1
    s.movz       s15, #2
    a.vwrite     a3, s7, v4
    a.vread      v1, a1, s10
    a.vread      v3, a2, s11
    v.extract    s7, v1, #0
    v.splat      v4, s7
    v.extract    s7, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v2, s7
    a.vread      v3, a2, s14
    v.extract    s7, v1, #2
    vf.fma       v4, v2, v3, v5
    v.splat      v2, s7
    a.vread      v3, a2, s15
    s.movz       s7, #3
    vf.fma       v5, v2, v3, v4
    v.extract    s10, v1, #3
    v.splat      v2, s10
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v4, v2, v3, v5
    v.extract    s10, v1, #4
    v.splat      v2, s10
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v5, v2, v3, v4
    v.extract    s10, v1, #5
    v.splat      v2, s10
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v4, v2, v3, v5
    v.extract    s10, v1, #6
    v.splat      v2, s10
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v5, v2, v3, v4
    v.extract    s10, v1, #7
    v.splat      v2, s10
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v4, v2, v3, v5
    v.extract    s10, v1, #8
    v.splat      v2, s10
    a.vread      v3, a2, s7
    s.movz       s7, #15
    vf.fma       v5, v2, v3, v4
    s.movz       s10, #9
    v.extract    s11, v1, #9
    v.splat      v2, s11
    a.vread      v3, a2, s10
    s.movz       s10, #10
    vf.fma       v4, v2, v3, v5
    v.extract    s11, v1, #10
    v.splat      v2, s11
    a.vread      v3, a2, s10
    s.movz       s10, #11
    vf.fma       v5, v2, v3, v4
    v.extract    s11, v1, #11
    v.splat      v2, s11
    a.vread      v3, a2, s10
    s.movz       s10, #12
    vf.fma       v4, v2, v3, v5
    v.extract    s11, v1, #12
    v.splat      v2, s11
    a.vread      v3, a2, s10
    s.movz       s10, #13
    vf.fma       v5, v2, v3, v4
    v.extract    s11, v1, #13
    v.splat      v2, s11
    a.vread      v3, a2, s10
    s.movz       s10, #14
    vf.fma       v4, v2, v3, v5
    v.extract    s11, v1, #14
    v.splat      v2, s11
    a.vread      v3, a2, s10
    s.movz       s10, #15
    vf.fma       v5, v2, v3, v4
    v.extract    s11, v1, #15
    v.splat      v1, s11
    a.vread      v2, a2, s10
    s.addi       s10, s16, #0
    vf.fma       v3, v1, v2, v5
    v.splat      v1, s1
    s.addi       s11, s16, #2048
    s.addi       s14, s16, #64
    a.vwrite     a3, s7, v3
    v.ld.w       v2, [s10, #0]
    s.addi       s7, s11, #64
    s.addi       s10, s16, #128
    s.addi       s15, s11, #128
    s.addi       s17, s16, #192
    s.addi       s18, s11, #192
    s.addi       s19, s16, #256
    v.add        v3, v2, v1
    v.st.w       [s11, #0], v3
    v.ld.w       v2, [s14, #0]
    s.addi       s14, s11, #256
    v.add        v3, v2, v1
    v.st.w       [s7, #0], v3
    s.addi       s7, s16, #320
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s11, #320
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s16, #384
    v.ld.w       v2, [s17, #0]
    s.addi       s17, s11, #384
    v.add        v3, v2, v1
    v.st.w       [s18, #0], v3
    s.addi       s18, s16, #448
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s11, #448
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s16, #512
    v.ld.w       v2, [s7, #0]
    s.addi       s7, s11, #512
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s16, #576
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s11, #576
    v.add        v3, v2, v1
    v.st.w       [s17, #0], v3
    s.addi       s17, s16, #640
    v.ld.w       v2, [s18, #0]
    s.addi       s18, s11, #640
    v.add        v3, v2, v1
    v.st.w       [s19, #0], v3
    s.addi       s19, s16, #704
    v.ld.w       v2, [s14, #0]
    s.addi       s14, s11, #704
    v.add        v3, v2, v1
    v.st.w       [s7, #0], v3
    s.addi       s7, s16, #768
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s11, #768
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s16, #832
    v.ld.w       v2, [s17, #0]
    s.addi       s17, s11, #832
    v.add        v3, v2, v1
    v.st.w       [s18, #0], v3
    s.addi       s18, s16, #896
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s11, #896
    s.addi       s21, s11, #960
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s11, s16, #960
    v.ld.w       v2, [s7, #0]
    s.addi       s7, s16, #1024
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.movz       s10, #512
    v.splat      v2, s10
    s.addi       s10, s16, #3072
    v.ld.w       v3, [s15, #0]
    s.addi       s14, s16, #1088
    v.add        v4, v3, v1
    v.st.w       [s17, #0], v4
    s.addi       s15, s10, #64
    v.ld.w       v3, [s18, #0]
    s.addi       s17, s16, #1152
    v.add        v4, v3, v1
    v.st.w       [s19, #0], v4
    s.addi       s18, s10, #128
    v.ld.w       v3, [s11, #0]
    s.addi       s11, s16, #1216
    v.add        v4, v3, v1
    v.st.w       [s21, #0], v4
    fence.acq_rel.device
    s.addi       s19, s10, #192
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s16, #1280
    v.add        v3, v1, v2
    v.st.w       [s10, #0], v3
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #256
    v.add        v3, v1, v2
    v.st.w       [s15, #0], v3
    s.addi       s15, s16, #1344
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s10, #320
    v.add        v3, v1, v2
    v.st.w       [s18, #0], v3
    s.addi       s18, s16, #1408
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #384
    v.add        v3, v1, v2
    v.st.w       [s19, #0], v3
    s.addi       s19, s16, #1472
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #448
    v.add        v3, v1, v2
    v.st.w       [s14, #0], v3
    s.addi       s14, s16, #1536
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s10, #512
    v.add        v3, v1, v2
    v.st.w       [s17, #0], v3
    s.addi       s17, s16, #1600
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s10, #576
    v.add        v3, v1, v2
    v.st.w       [s11, #0], v3
    s.addi       s11, s16, #1664
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #640
    v.add        v3, v1, v2
    v.st.w       [s7, #0], v3
    s.addi       s7, s16, #1728
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #704
    v.add        v3, v1, v2
    v.st.w       [s15, #0], v3
    s.addi       s15, s16, #1792
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s10, #768
    v.add        v3, v1, v2
    v.st.w       [s18, #0], v3
    s.addi       s18, s16, #1856
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #832
    v.add        v3, v1, v2
    v.st.w       [s19, #0], v3
    s.addi       s19, s16, #1920
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #896
    s.addi       s21, s10, #960
    v.add        v3, v1, v2
    v.st.w       [s14, #0], v3
    s.addi       s10, s16, #1984
    v.ld.w       v1, [s15, #0]
    s.addi       s14, s16, #2048
    v.add        v3, v1, v2
    v.st.w       [s17, #0], v3
    s.addi       s15, s16, #4096
    v.ld.w       v1, [s18, #0]
    s.addi       s17, s16, #2112
    v.add        v3, v1, v2
    v.st.w       [s11, #0], v3
    s.addi       s11, s15, #64
    v.ld.w       v1, [s19, #0]
    s.addi       s18, s16, #2176
    v.add        v3, v1, v2
    v.st.w       [s7, #0], v3
    s.addi       s7, s15, #128
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s16, #2240
    v.add        v3, v1, v2
    v.st.w       [s21, #0], v3
    fence.acq_rel.device
    s.addi       s19, s15, #192
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s16, #2304
    v.st.w       [s15, #0], v1
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s15, #256
    v.st.w       [s11, #0], v1
    s.addi       s11, s16, #2368
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s15, #320
    v.st.w       [s7, #0], v1
    s.addi       s7, s16, #2432
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s15, #384
    v.st.w       [s19, #0], v1
    s.addi       s19, s16, #2496
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s15, #448
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #2560
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s15, #512
    v.st.w       [s18, #0], v1
    s.addi       s18, s16, #2624
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s15, #576
    v.st.w       [s10, #0], v1
    s.addi       s10, s16, #2688
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s15, #640
    v.st.w       [s14, #0], v1
    s.addi       s14, s16, #2752
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s15, #704
    v.st.w       [s11, #0], v1
    s.addi       s11, s16, #2816
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s15, #768
    v.st.w       [s7, #0], v1
    s.addi       s7, s16, #2880
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s15, #832
    v.st.w       [s19, #0], v1
    s.addi       s19, s16, #2944
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s15, #896
    s.addi       s21, s15, #960
    v.st.w       [s17, #0], v1
    s.addi       s15, s16, #3008
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #3072
    v.st.w       [s18, #0], v1
    s.addi       s17, s16, #5120
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s16, #3136
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #64
    v.ld.w       v1, [s19, #0]
    s.addi       s18, s16, #3200
    v.st.w       [s14, #0], v1
    s.addi       s14, s17, #128
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #3264
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    s.addi       s19, s17, #192
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #3328
    v.st.w       [s17, #0], v1
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s17, #256
    v.st.w       [s10, #0], v1
    s.addi       s10, s16, #3392
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #320
    v.st.w       [s14, #0], v1
    s.addi       s14, s16, #3456
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #384
    v.st.w       [s19, #0], v1
    s.addi       s19, s16, #3520
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s17, #448
    v.st.w       [s7, #0], v1
    s.addi       s7, s16, #3584
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #512
    v.st.w       [s18, #0], v1
    s.addi       s18, s16, #3648
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s17, #576
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #3712
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s17, #640
    v.st.w       [s11, #0], v1
    s.addi       s11, s16, #3776
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s17, #704
    v.st.w       [s10, #0], v1
    s.addi       s10, s16, #3840
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #768
    v.st.w       [s14, #0], v1
    s.addi       s14, s16, #3904
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #832
    v.st.w       [s19, #0], v1
    s.addi       s19, s16, #3968
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s17, #896
    s.addi       s21, s17, #960
    v.st.w       [s7, #0], v1
    s.addi       s7, s16, #4032
    v.ld.w       v1, [s10, #0]
    s.movz       s10, #0
    v.st.w       [s18, #0], v1
    s.movz       s17, #0
    v.ld.w       v1, [s14, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s14, #0
    v.st.w       [s15, #0], v1
    s.movz       s15, #1
    v.ld.w       v1, [s19, #0]
    s.movz       s18, #1
    v.st.w       [s11, #0], v1
    s.movz       s11, #1
    v.ld.w       v1, [s7, #0]
    s.movz       s7, #2
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s10
    a.vread      v2, a3, s17
    s.movz       s10, #2
    vf.add       v3, v1, v2
    s.movz       s17, #2
    s.movz       s19, #3
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s18
    s.movz       s14, #3
    vf.add       v3, v1, v2
    s.movz       s15, #3
    s.movz       s18, #4
    a.vwrite     a4, s11, v3
    a.vread      v1, a0, s7
    a.vread      v2, a3, s10
    s.movz       s7, #4
    vf.add       v3, v1, v2
    s.movz       s10, #4
    s.movz       s11, #5
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s14
    s.movz       s14, #5
    vf.add       v3, v1, v2
    s.movz       s17, #5
    s.movz       s19, #6
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s18
    a.vread      v2, a3, s7
    s.movz       s7, #6
    vf.add       v3, v1, v2
    s.movz       s15, #6
    s.movz       s18, #7
    a.vwrite     a4, s10, v3
    a.vread      v1, a0, s11
    a.vread      v2, a3, s14
    s.movz       s10, #7
    vf.add       v3, v1, v2
    s.movz       s11, #7
    s.movz       s14, #8
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s7
    s.movz       s7, #8
    vf.add       v3, v1, v2
    s.movz       s17, #8
    s.movz       s19, #9
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s18
    a.vread      v2, a3, s10
    s.movz       s10, #9
    vf.add       v3, v1, v2
    s.movz       s15, #9
    s.movz       s18, #10
    a.vwrite     a4, s11, v3
    a.vread      v1, a0, s14
    a.vread      v2, a3, s7
    s.movz       s7, #10
    vf.add       v3, v1, v2
    s.movz       s11, #10
    s.movz       s14, #11
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s10
    s.movz       s10, #11
    vf.add       v3, v1, v2
    s.movz       s17, #11
    s.movz       s19, #12
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s18
    a.vread      v2, a3, s7
    s.movz       s7, #12
    vf.add       v3, v1, v2
    s.movz       s15, #12
    s.movz       s18, #13
    a.vwrite     a4, s11, v3
    a.vread      v1, a0, s14
    a.vread      v2, a3, s10
    s.movz       s10, #13
    vf.add       v3, v1, v2
    s.movz       s11, #13
    s.movz       s14, #14
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s7
    s.movz       s7, #14
    vf.add       v3, v1, v2
    s.movz       s17, #14
    s.movz       s19, #15
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s18
    a.vread      v2, a3, s10
    s.movz       s10, #15
    vf.add       v3, v1, v2
    s.movz       s15, #15
    s.addi       s18, s16, #4096
    a.vwrite     a4, s11, v3
    a.vread      v1, a0, s14
    a.vread      v2, a3, s7
    s.addi       s7, s16, #0
    vf.add       v3, v1, v2
    s.addi       s11, s16, #4160
    s.addi       s14, s16, #64
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s10
    s.addi       s10, s16, #4224
    vf.add       v3, v1, v2
    s.addi       s17, s16, #128
    s.addi       s19, s16, #4288
    a.vwrite     a4, s15, v3
    v.ld.w       v1, [s18, #0]
    s.addi       s15, s16, #192
    s.addi       s18, s16, #4352
    v.st.w       [s7, #0], v1
    s.addi       s7, s16, #256
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #4416
    v.st.w       [s14, #0], v1
    s.addi       s14, s16, #320
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s16, #4480
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #384
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s16, #4544
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #448
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s16, #4608
    v.st.w       [s7, #0], v1
    s.addi       s7, s16, #512
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #4672
    v.st.w       [s14, #0], v1
    s.addi       s14, s16, #576
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s16, #4736
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #640
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s16, #4800
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #704
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s16, #4864
    v.st.w       [s7, #0], v1
    s.addi       s7, s16, #768
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #4928
    v.st.w       [s14, #0], v1
    s.addi       s14, s16, #832
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s16, #4992
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #896
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s16, #5056
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #960
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s16, #5120
    v.st.w       [s7, #0], v1
    s.addi       s7, s16, #1024
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #5184
    v.st.w       [s14, #0], v1
    s.addi       s14, s16, #1088
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s16, #5248
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #1152
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s16, #5312
    v.st.w       [s15, #0], v1
    fence.acq_rel.device
    s.addi       s15, s16, #1216
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s16, #5376
    v.st.w       [s7, #0], v1
    s.addi       s7, s16, #1280
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #5440
    v.st.w       [s14, #0], v1
    s.addi       s14, s16, #1344
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s16, #5504
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #1408
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s16, #5568
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #1472
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s16, #5632
    v.st.w       [s7, #0], v1
    s.addi       s7, s16, #1536
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #5696
    v.st.w       [s14, #0], v1
    s.addi       s14, s16, #1600
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s16, #5760
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #1664
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s16, #5824
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #1728
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s16, #5888
    v.st.w       [s7, #0], v1
    s.addi       s7, s16, #1792
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #5952
    v.st.w       [s14, #0], v1
    s.addi       s14, s16, #1856
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s16, #6016
    v.st.w       [s17, #0], v1
    s.addi       s17, s16, #1920
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s16, #6080
    s.addi       s21, s16, #1984
    v.st.w       [s15, #0], v1
    s.movz       s15, #0
    v.ld.w       v1, [s18, #0]
    s.movz       s18, #0
    v.st.w       [s7, #0], v1
    s.movz       s7, #1
    v.ld.w       v1, [s11, #0]
    s.movz       s11, #1
    v.st.w       [s14, #0], v1
    s.movz       s14, #2
    v.ld.w       v1, [s10, #0]
    s.movz       s10, #2
    v.st.w       [s17, #0], v1
    s.movz       s17, #3
    v.ld.w       v1, [s19, #0]
    s.movz       s19, #3
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    a.vread      v1, a4, s15
    s.movz       s15, #4
    a.vwrite     a0, s18, v1
    a.vread      v1, a4, s7
    s.movz       s7, #4
    a.vwrite     a0, s11, v1
    a.vread      v1, a4, s14
    s.movz       s11, #5
    a.vwrite     a0, s10, v1
    a.vread      v1, a4, s17
    s.movz       s10, #5
    a.vwrite     a0, s19, v1
    a.vread      v1, a4, s15
    s.movz       s14, #6
    a.vwrite     a0, s7, v1
    a.vread      v1, a4, s11
    s.movz       s7, #6
    a.vwrite     a0, s10, v1
    a.vread      v1, a4, s14
    s.movz       s10, #7
    a.vwrite     a0, s7, v1
    s.movz       s7, #7
    a.vread      v1, a4, s10
    s.movz       s10, #8
    a.vwrite     a0, s7, v1
    s.movz       s7, #8
    a.vread      v1, a4, s10
    s.movz       s10, #9
    a.vwrite     a0, s7, v1
    s.movz       s7, #9
    a.vread      v1, a4, s10
    s.movz       s10, #10
    a.vwrite     a0, s7, v1
    s.movz       s7, #10
    a.vread      v1, a4, s10
    s.movz       s10, #11
    a.vwrite     a0, s7, v1
    s.movz       s7, #11
    a.vread      v1, a4, s10
    s.movz       s10, #12
    a.vwrite     a0, s7, v1
    s.movz       s7, #12
    a.vread      v1, a4, s10
    s.movz       s10, #13
    a.vwrite     a0, s7, v1
    s.movz       s7, #13
    a.vread      v1, a4, s10
    s.movz       s10, #14
    a.vwrite     a0, s7, v1
    s.movz       s7, #14
    a.vread      v1, a4, s10
    s.movz       s10, #15
    a.vwrite     a0, s7, v1
    s.movz       s7, #15
    a.vread      v1, a4, s10
    s.add        s10, s20, s1
    s.movz       s11, #1
    a.vwrite     a0, s7, v1
    s.mov        s20, s10
    br.nz        s11, for_5
endfor_6:
    s.movz       s1, #0
    s.mul        s2, s12, s5
    s.muli       s5, s8, #4                      // a runtime tile origin, x4
    s.movz       s7, #0
    s.add        s10, s1, s8                     // the tile origin
    s.muli       s1, s3, #128                    // a runtime tile origin, x128
    s.add        s8, s7, s3                      // the tile origin
    v.splat      v1, s10
    s.movz       s3, #32
    s.muli       s7, s2, #4                      // a runtime tile origin, x4
    v.splat      v2, s8
    v.splat      v3, s4
    v.add        v4, v0, v1
    v.splat      v0, s3
    s.addi       s2, s8, #1
    s.add        s3, s9, s5                      // the tile origin
    v.splat      v1, s12
    v.splat      v5, s6
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s2
    s.addi       s2, s8, #2
    s.add        s4, s3, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    p.and        p3, p1, p2
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s2
    s.addi       s2, s8, #3
    s.add        s3, s4, s7                      // the tile origin
    a.vread      v1, a0, s1
    p.and        p5, p3, p1
    s.movz       s1, #1
    p.and        p3, p4, p2
    v.splat      v2, s2
    s.addi       s2, s8, #4
    @p5 v.st.w       [s3, #0], v1
    v.cmp.lt     p4, v0, v3
    a.vread      v0, a0, s1
    s.addi       s1, s3, #128                    // row 1
    p.and        p5, p3, p1
    s.movz       s4, #2
    p.and        p3, p4, p2
    v.splat      v1, s2
    s.addi       s2, s8, #5
    s.addi       s5, s3, #256                    // row 2
    @p5 v.st.w       [s1, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s4
    p.and        p5, p3, p1
    s.movz       s1, #3
    p.and        p3, p4, p2
    v.splat      v2, s2
    s.addi       s2, s8, #6
    s.addi       s4, s3, #384                    // row 3
    p.and        p4, p3, p1
    @p5 v.st.w       [s5, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s1
    s.movz       s1, #4
    p.and        p5, p3, p2
    v.splat      v1, s2
    s.addi       s2, s8, #7
    s.addi       s5, s3, #512                    // row 4
    p.and        p3, p5, p1
    s.movz       s6, #5
    @p4 v.st.w       [s4, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s1
    p.and        p5, p4, p2
    v.splat      v2, s2
    s.addi       s1, s8, #8
    s.addi       s2, s3, #640                    // row 5
    p.and        p4, p5, p1
    s.movz       s4, #6
    v.splat      v4, s1
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s6
    p.and        p5, p3, p2
    s.addi       s1, s8, #9
    s.addi       s5, s3, #768                    // row 6
    p.and        p3, p5, p1
    s.movz       s6, #7
    v.splat      v1, s1
    s.addi       s1, s8, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s4
    p.and        p5, p4, p2
    s.addi       s2, s3, #896                    // row 7
    p.and        p4, p5, p1
    s.movz       s4, #8
    v.splat      v2, s1
    s.addi       s1, s8, #11
    s.addi       s7, s3, #1024                   // row 8
    @p3 v.st.w       [s5, #0], v0
    v.cmp.lt     p3, v4, v3
    a.vread      v0, a0, s6
    p.and        p5, p3, p2
    s.movz       s5, #9
    p.and        p3, p5, p1
    v.splat      v4, s1
    s.addi       s1, s8, #12
    s.addi       s6, s3, #1152                   // row 9
    s.movz       s9, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v1, v3
    a.vread      v0, a0, s4
    p.and        p5, p4, p2
    v.splat      v1, s1
    p.and        p4, p5, p1
    s.addi       s1, s8, #13
    s.addi       s2, s3, #1280                   // row 10
    s.movz       s4, #11
    v.splat      v5, s1
    @p3 v.st.w       [s7, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s5
    p.and        p5, p3, p2
    s.addi       s1, s8, #14
    p.and        p3, p5, p1
    s.addi       s5, s3, #1408                   // row 11
    s.movz       s7, #12
    v.splat      v2, s1
    s.addi       s1, s3, #1536                   // row 12
    @p4 v.st.w       [s6, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    s.addi       s6, s8, #15
    p.and        p4, p5, p1
    s.movz       s8, #13
    v.splat      v4, s6
    s.addi       s6, s3, #1664                   // row 13
    s.movz       s9, #14
    @p3 v.st.w       [s2, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s4
    p.and        p5, p3, p2
    s.addi       s2, s3, #1792                   // row 14
    p.and        p3, p5, p1
    s.movz       s4, #15
    s.addi       s10, s3, #1920                  // row 15
    @p4 v.st.w       [s5, #0], v0
    v.cmp.lt     p4, v5, v3
    a.vread      v0, a0, s7
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s8
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s6, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    p.and        p2, p5, p1
    @p3 v.st.w       [s2, #0], v0
    a.vread      v0, a0, s4
    @p2 v.st.w       [s10, #0], v0
__rctx_next:
    exit
