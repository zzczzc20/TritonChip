#!/bin/bash
source ~/tc_env/env.sh
cd /tmp/r40_pipeline_control17 || exit 2
export PYTHONPATH="$PWD/python:$PWD/compiler/python:$PWD/tools/asm"
"$HOME/tc_env/torchenv/bin/python" tools/r40/pipeline_stage_options_tests.py > /tmp/r40_pipeline_control17_options.log 2>&1
rc=$?
printf '%s
' "$rc" > /tmp/r40_pipeline_control17_options.exit
if [ "$rc" != 0 ]; then exit "$rc"; fi
CUDA_VISIBLE_DEVICES='' TNCA_PIPELINE=1 "$HOME/tc_env/torchenv/bin/python" tools/r40/native_pipeline_tests.py --stages 1 > /tmp/r40_pipeline_control17_torch.log 2>&1
rc=$?
printf '%s
' "$rc" > /tmp/r40_pipeline_control17_torch.exit
exit "$rc"
