    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #0
    v.movi       v2, #0
    v.extract    s1, v0, #0
    v.extract    s2, v0, #1
    s.shli       s3, s1, #32
    s.shli       s1, s2, #32
    s.ashri      s2, s3, #32
    s.rdspecial  s3, arg_base
    s.lshri      s5, s2, #32
    v.extract    s6, v0, #2
    s.ashri      s7, s1, #32
    s.ld.d       s1, [s3, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.shli       s8, s6, #32
    s.lshri      s6, s7, #32
    v.extract    s9, v0, #3
    s.ashri      s10, s8, #32
    s.shli       s8, s9, #32
    s.lshri      s9, s10, #32
    v.extract    s11, v0, #4
    s.ashri      s12, s8, #32
    s.shli       s8, s11, #32
    s.lshri      s11, s12, #32
    s.ld.d       s13, [s3, #8]                   // in_ptr1: device_ptr64 at arg_base+8
    s.ashri      s14, s8, #32
    s.shli       s8, s4, #32
    s.lshri      s4, s14, #32
    s.ashri      s15, s8, #32
    s.movz       s8, #6144
    s.shli       s16, s15, #4                    // x16 as a shift
    s.movz       s15, #6144
    s.movz       s17, #6144
    s.movz       s18, #6144
    s.movz       s19, #6144
    s.ld.d       s20, [s3, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    v.insert     v1, s2, #0
    v.insert     v2, s5, #0
    v.extract    s2, v0, #5
    v.insert     v1, s7, #1
    v.insert     v2, s6, #1
    s.shli       s3, s2, #32
    v.insert     v1, s10, #2
    v.insert     v2, s9, #2
    s.ashri      s2, s3, #32
    v.insert     v1, s12, #3
    v.insert     v2, s11, #3
    s.lshri      s3, s2, #32
    v.insert     v1, s14, #4
    v.insert     v2, s4, #4
    s.movz       s4, #6144
    v.insert     v1, s2, #5
    v.insert     v2, s3, #5
    s.movz       s2, #6144
    v.extract    s3, v0, #6
    s.movz       s5, #6144
    s.shli       s6, s3, #32
    s.movz       s3, #6144
    s.ashri      s7, s6, #32
    s.movz       s6, #6144
    v.insert     v1, s7, #6
    s.movz       s9, #6144
    s.lshri      s10, s7, #32
    s.movz       s7, #6144
    v.extract    s11, v0, #7
    v.extract    s12, v0, #8
    s.shli       s14, s11, #32
    v.insert     v2, s10, #6
    s.ashri      s10, s14, #32
    s.shli       s11, s12, #32
    s.lshri      s12, s10, #32
    v.extract    s14, v0, #9
    s.ashri      s21, s11, #32
    v.insert     v1, s10, #7
    v.insert     v2, s12, #7
    s.shli       s10, s14, #32
    s.lshri      s11, s21, #32
    v.extract    s12, v0, #10
    s.ashri      s14, s10, #32
    v.insert     v1, s21, #8
    v.insert     v2, s11, #8
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v0, #11
    s.ashri      s21, s10, #32
    v.insert     v1, s14, #9
    v.insert     v2, s11, #9
    s.shli       s10, s12, #32
    s.lshri      s11, s21, #32
    v.extract    s12, v0, #12
    s.ashri      s14, s10, #32
    v.insert     v1, s21, #10
    v.insert     v2, s11, #10
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v0, #13
    s.ashri      s21, s10, #32
    v.insert     v1, s14, #11
    v.insert     v2, s11, #11
    s.shli       s10, s12, #32
    s.lshri      s11, s21, #32
    v.extract    s12, v0, #14
    s.ashri      s14, s10, #32
    v.insert     v1, s21, #12
    v.insert     v2, s11, #12
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v0, #15
    s.ashri      s21, s10, #32
    v.insert     v1, s14, #13
    v.insert     v2, s11, #13
    s.shli       s10, s12, #32
    s.lshri      s11, s21, #32
    s.ashri      s12, s10, #32
    v.insert     v1, s21, #14
    v.insert     v2, s11, #14
    v.movi       v0, #0
    v.movi       v3, #0
    s.lshri      s10, s12, #32
    s.lshri      s11, s16, #32
    v.insert     v1, s12, #15
    v.insert     v2, s10, #15
    v.insert     v0, s16, #0
    v.insert     v3, s11, #0
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #1
    v.insert     v3, s10, #1
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #2
    v.insert     v3, s10, #2
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #3
    v.insert     v3, s10, #3
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #4
    v.insert     v3, s10, #4
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #5
    v.insert     v3, s10, #5
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #6
    v.insert     v3, s10, #6
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #7
    v.insert     v3, s10, #7
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #8
    v.insert     v3, s10, #8
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #9
    v.insert     v3, s10, #9
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #10
    v.insert     v3, s10, #10
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #11
    v.insert     v3, s10, #11
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #12
    v.insert     v3, s10, #12
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #13
    v.insert     v3, s10, #13
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #14
    v.insert     v3, s10, #14
    s.lshri      s10, s16, #32
    v.insert     v0, s16, #15
    v.insert     v3, s10, #15
    v.extract    s10, v2, #0
    v.extract    s11, v0, #0
    v.extract    s12, v3, #0
    v.extract    s14, v1, #0
    s.shli       s21, s12, #32
    s.shli       s12, s10, #32
    v.extract    s10, v3, #1
    v.extract    s22, v2, #1
    s.or         s23, s11, s21
    s.or         s11, s14, s12
    v.extract    s12, v0, #1
    s.shli       s14, s10, #32
    v.extract    s10, v1, #1
    s.shli       s21, s22, #32
    s.add        s22, s23, s11
    v.extract    s11, v3, #2
    v.extract    s23, v2, #2
    v.movi       v4, #0
    v.movi       v5, #0
    s.or         s24, s12, s14
    s.or         s12, s10, s21
    s.lshri      s10, s22, #32
    v.extract    s14, v0, #2
    s.shli       s21, s11, #32
    s.shli       s11, s23, #32
    s.add        s23, s24, s12
    v.extract    s12, v1, #2
    v.insert     v4, s22, #0
    v.extract    s22, v3, #3
    v.insert     v5, s10, #0
    v.extract    s10, v2, #3
    s.or         s24, s14, s21
    s.or         s14, s12, s11
    s.lshri      s11, s23, #32
    v.extract    s12, v0, #3
    s.shli       s21, s22, #32
    s.shli       s22, s10, #32
    s.add        s10, s24, s14
    v.extract    s14, v1, #3
    v.insert     v4, s23, #1
    v.extract    s23, v3, #4
    v.insert     v5, s11, #1
    v.extract    s11, v2, #4
    s.or         s24, s12, s21
    s.or         s12, s14, s22
    s.lshri      s14, s10, #32
    v.extract    s21, v0, #4
    s.shli       s22, s23, #32
    s.shli       s23, s11, #32
    s.add        s11, s24, s12
    v.extract    s12, v1, #4
    v.insert     v4, s10, #2
    v.extract    s10, v3, #5
    v.insert     v5, s14, #2
    v.extract    s14, v2, #5
    s.or         s24, s21, s22
    s.or         s21, s12, s23
    s.lshri      s12, s11, #32
    v.extract    s22, v0, #5
    s.shli       s23, s10, #32
    s.shli       s10, s14, #32
    s.add        s14, s24, s21
    v.extract    s21, v1, #5
    v.insert     v4, s11, #3
    v.extract    s11, v3, #6
    v.insert     v5, s12, #3
    v.extract    s12, v2, #6
    s.or         s24, s22, s23
    s.or         s22, s21, s10
    s.lshri      s10, s14, #32
    v.extract    s21, v0, #6
    s.shli       s23, s11, #32
    s.shli       s11, s12, #32
    s.add        s12, s24, s22
    v.extract    s22, v1, #6
    v.insert     v4, s14, #4
    v.extract    s14, v3, #7
    v.insert     v5, s10, #4
    v.extract    s10, v2, #7
    s.or         s24, s21, s23
    s.or         s21, s22, s11
    s.lshri      s11, s12, #32
    v.extract    s22, v0, #7
    s.shli       s23, s14, #32
    s.shli       s14, s10, #32
    s.add        s10, s24, s21
    v.extract    s21, v1, #7
    v.insert     v4, s12, #5
    v.extract    s12, v3, #8
    v.insert     v5, s11, #5
    v.extract    s11, v2, #8
    s.or         s24, s22, s23
    s.or         s22, s21, s14
    s.lshri      s14, s10, #32
    v.extract    s21, v0, #8
    s.shli       s23, s12, #32
    s.shli       s12, s11, #32
    s.add        s11, s24, s22
    v.extract    s22, v1, #8
    v.insert     v4, s10, #6
    v.extract    s10, v3, #9
    v.insert     v5, s14, #6
    v.extract    s14, v2, #9
    s.or         s24, s21, s23
    s.or         s21, s22, s12
    s.lshri      s12, s11, #32
    v.extract    s22, v0, #9
    s.shli       s23, s10, #32
    s.shli       s10, s14, #32
    s.add        s14, s24, s21
    v.extract    s21, v1, #9
    v.insert     v4, s11, #7
    v.extract    s11, v3, #10
    v.insert     v5, s12, #7
    v.extract    s12, v2, #10
    s.or         s24, s22, s23
    s.or         s22, s21, s10
    s.lshri      s10, s14, #32
    v.extract    s21, v0, #10
    s.shli       s23, s11, #32
    s.shli       s11, s12, #32
    s.add        s12, s24, s22
    v.extract    s22, v1, #10
    v.insert     v4, s14, #8
    v.extract    s14, v3, #11
    v.insert     v5, s10, #8
    v.extract    s10, v2, #11
    s.or         s24, s21, s23
    s.or         s21, s22, s11
    s.lshri      s11, s12, #32
    v.extract    s22, v0, #11
    s.shli       s23, s14, #32
    s.shli       s14, s10, #32
    s.add        s10, s24, s21
    v.extract    s21, v1, #11
    v.insert     v4, s12, #9
    v.extract    s12, v3, #12
    v.insert     v5, s11, #9
    v.extract    s11, v2, #12
    s.or         s24, s22, s23
    s.or         s22, s21, s14
    s.lshri      s14, s10, #32
    v.extract    s21, v0, #12
    s.shli       s23, s12, #32
    s.shli       s12, s11, #32
    s.add        s11, s24, s22
    v.extract    s22, v1, #12
    v.insert     v4, s10, #10
    v.extract    s10, v3, #13
    v.insert     v5, s14, #10
    v.extract    s14, v2, #13
    s.or         s24, s21, s23
    s.or         s21, s22, s12
    s.lshri      s12, s11, #32
    v.extract    s22, v0, #13
    s.shli       s23, s10, #32
    s.shli       s10, s14, #32
    s.add        s14, s24, s21
    v.extract    s21, v1, #13
    v.insert     v4, s11, #11
    v.extract    s11, v3, #14
    v.insert     v5, s12, #11
    v.extract    s12, v2, #14
    s.or         s24, s22, s23
    s.or         s22, s21, s10
    s.lshri      s10, s14, #32
    v.extract    s21, v0, #14
    s.shli       s23, s11, #32
    s.shli       s11, s12, #32
    s.add        s12, s24, s22
    v.extract    s22, v1, #14
    v.insert     v4, s14, #12
    v.extract    s14, v3, #15
    v.insert     v5, s10, #12
    v.extract    s10, v2, #15
    s.or         s24, s21, s23
    s.or         s21, s22, s11
    s.lshri      s11, s12, #32
    v.extract    s22, v0, #15
    s.shli       s23, s14, #32
    s.shli       s14, s10, #32
    s.add        s10, s24, s21
    v.extract    s21, v1, #15
    v.insert     v4, s12, #13
    v.insert     v5, s11, #13
    s.or         s11, s22, s23
    s.or         s12, s21, s14
    s.lshri      s14, s10, #32
    s.add        s21, s11, s12
    v.insert     v4, s10, #14
    v.insert     v5, s14, #14
    s.lshri      s10, s21, #32
    v.insert     v4, s21, #15
    v.insert     v5, s10, #15
    v.movi       v0, #0
    v.extract    s10, v4, #0
    v.extract    s11, v5, #0
    v.extract    s12, v5, #1
    s.shli       s14, s11, #32
    v.extract    s11, v4, #1
    s.or         s21, s10, s14
    s.shli       s10, s12, #32
    s.cmp.lt     s12, s21, s8
    v.extract    s14, v5, #2
    s.or         s21, s11, s10
    v.insert     v0, s12, #0
    v.extract    s10, v4, #2
    s.shli       s11, s14, #32
    s.cmp.lt     s12, s21, s8
    v.extract    s14, v5, #3
    s.or         s21, s10, s11
    v.insert     v0, s12, #1
    v.extract    s10, v4, #3
    s.shli       s11, s14, #32
    s.cmp.lt     s12, s21, s8
    v.extract    s14, v5, #4
    s.or         s21, s10, s11
    v.insert     v0, s12, #2
    v.extract    s10, v4, #4
    s.shli       s11, s14, #32
    s.cmp.lt     s12, s21, s8
    v.extract    s14, v5, #5
    s.or         s21, s10, s11
    v.insert     v0, s12, #3
    v.extract    s10, v4, #5
    s.shli       s11, s14, #32
    s.cmp.lt     s12, s21, s8
    v.extract    s8, v5, #6
    s.or         s14, s10, s11
    v.insert     v0, s12, #4
    v.extract    s10, v4, #6
    s.shli       s11, s8, #32
    s.cmp.lt     s8, s14, s15
    v.extract    s12, v5, #7
    s.or         s14, s10, s11
    v.insert     v0, s8, #5
    v.extract    s8, v4, #7
    s.shli       s10, s12, #32
    s.cmp.lt     s11, s14, s17
    v.extract    s12, v5, #8
    s.or         s14, s8, s10
    v.insert     v0, s11, #6
    v.extract    s8, v4, #8
    s.shli       s10, s12, #32
    s.cmp.lt     s11, s14, s18
    v.extract    s12, v5, #9
    s.or         s14, s8, s10
    v.insert     v0, s11, #7
    v.extract    s8, v4, #9
    s.shli       s10, s12, #32
    s.cmp.lt     s11, s14, s19
    v.extract    s12, v5, #10
    s.or         s14, s8, s10
    v.insert     v0, s11, #8
    v.extract    s8, v4, #10
    s.shli       s10, s12, #32
    s.cmp.lt     s11, s14, s4
    v.extract    s4, v5, #11
    v.extract    s12, v5, #0
    s.or         s14, s8, s10
    v.insert     v0, s11, #9
    v.extract    s8, v4, #11
    s.shli       s10, s4, #32
    v.extract    s4, v4, #0
    s.shli       s11, s12, #32
    s.cmp.lt     s12, s14, s2
    v.extract    s2, v5, #12
    s.or         s14, s8, s10
    s.or         s8, s4, s11
    v.insert     v0, s12, #10
    v.extract    s4, v5, #1
    v.extract    s10, v4, #12
    s.shli       s11, s2, #32
    v.extract    s2, v4, #1
    s.shli       s12, s4, #32
    s.cmp.lt     s4, s14, s5
    v.extract    s5, v5, #13
    s.ashri      s14, s8, #63
    s.or         s15, s10, s11
    s.or         s10, s2, s12
    v.insert     v0, s4, #11
    v.extract    s2, v4, #13
    s.shli       s4, s5, #32
    s.xor        s5, s8, s14
    s.cmp.lt     s8, s15, s3
    v.extract    s3, v5, #14
    s.ashri      s11, s10, #63
    s.or         s12, s2, s4
    s.sub        s2, s5, s14
    v.insert     v0, s8, #12
    v.extract    s4, v5, #2
    v.extract    s5, v4, #2
    s.shli       s8, s4, #32
    v.extract    s4, v4, #14
    s.or         s15, s5, s8
    s.shli       s5, s3, #32
    s.xor        s3, s10, s11
    s.cmp.lt     s8, s12, s6
    v.extract    s6, v5, #15
    s.lshri      s10, s2, #11
    s.ashri      s2, s15, #63
    s.or         s12, s4, s5
    s.sub        s4, s3, s11
    v.insert     v0, s8, #13
    v.extract    s3, v4, #15
    s.shli       s5, s6, #32
    s.xor        s6, s10, s14
    s.xor        s8, s15, s2
    s.cmp.lt     s10, s12, s9
    s.lshri      s9, s4, #11
    s.or         s4, s3, s5
    s.sub        s3, s6, s14
    s.sub        s5, s8, s2
    v.insert     v0, s10, #14
    v.extract    s6, v5, #3
    v.extract    s8, v4, #3
    s.shli       s10, s6, #32
    v.movi       v1, #0
    v.movi       v2, #0
    s.xor        s6, s9, s11
    s.cmp.lt     s9, s4, s7
    s.or         s4, s8, s10
    s.lshri      s7, s3, #32
    s.lshri      s8, s5, #11
    s.sub        s5, s6, s11
    v.insert     v0, s9, #15
    s.ashri      s6, s4, #63
    v.insert     v1, s3, #0
    v.insert     v2, s7, #0
    s.xor        s3, s8, s2
    s.lshri      s7, s5, #32
    s.sub        s8, s3, s2
    v.insert     v1, s5, #1
    v.insert     v2, s7, #1
    s.lshri      s2, s8, #32
    v.insert     v1, s8, #2
    v.insert     v2, s2, #2
    v.movi       v3, #0
    s.xor        s2, s4, s6
    v.cmp.ne     p1, v0, v3
    v.extract    s3, v5, #4
    v.extract    s4, v4, #4
    s.shli       s5, s3, #32
    v.extract    s3, v5, #5
    s.or         s7, s4, s5
    v.extract    s4, v4, #5
    s.shli       s5, s3, #32
    s.ashri      s3, s7, #63
    v.extract    s8, v5, #6
    s.sub        s9, s2, s6
    s.or         s2, s4, s5
    s.xor        s4, s7, s3
    v.extract    s5, v4, #6
    s.shli       s7, s8, #32
    s.lshri      s8, s9, #11
    s.ashri      s9, s2, #63
    v.extract    s10, v5, #7
    s.sub        s11, s4, s3
    s.or         s4, s5, s7
    s.xor        s5, s8, s6
    s.xor        s7, s2, s9
    v.extract    s2, v4, #7
    s.shli       s8, s10, #32
    s.lshri      s10, s11, #11
    s.ashri      s11, s4, #63
    s.sub        s12, s5, s6
    s.sub        s5, s7, s9
    s.or         s6, s2, s8
    s.xor        s2, s10, s3
    s.xor        s7, s4, s11
    s.lshri      s4, s12, #32
    s.lshri      s8, s5, #11
    s.ashri      s5, s6, #63
    s.sub        s10, s2, s3
    s.sub        s2, s7, s11
    v.insert     v1, s12, #3
    v.insert     v2, s4, #3
    v.extract    s3, v5, #8
    v.extract    s4, v4, #8
    s.shli       s7, s3, #32
    s.xor        s3, s8, s9
    s.or         s8, s4, s7
    s.xor        s4, s6, s5
    s.lshri      s6, s10, #32
    s.lshri      s7, s2, #11
    s.ashri      s2, s8, #63
    s.sub        s12, s3, s9
    s.sub        s3, s4, s5
    v.insert     v1, s10, #4
    v.insert     v2, s6, #4
    v.extract    s4, v5, #9
    v.extract    s6, v4, #9
    s.shli       s9, s4, #32
    s.xor        s4, s7, s11
    s.or         s7, s6, s9
    s.xor        s6, s8, s2
    s.lshri      s8, s12, #32
    s.lshri      s9, s3, #11
    s.ashri      s3, s7, #63
    s.sub        s10, s4, s11
    s.sub        s4, s6, s2
    v.insert     v1, s12, #5
    v.insert     v2, s8, #5
    v.extract    s6, v5, #10
    v.extract    s8, v4, #10
    s.shli       s11, s6, #32
    s.xor        s6, s9, s5
    s.or         s9, s8, s11
    s.xor        s8, s7, s3
    s.lshri      s7, s10, #32
    s.lshri      s11, s4, #11
    s.ashri      s4, s9, #63
    s.sub        s12, s6, s5
    s.sub        s5, s8, s3
    v.insert     v1, s10, #6
    v.insert     v2, s7, #6
    v.extract    s6, v5, #11
    v.extract    s7, v4, #11
    s.shli       s8, s6, #32
    s.xor        s6, s11, s2
    s.or         s10, s7, s8
    s.xor        s7, s9, s4
    s.lshri      s8, s12, #32
    s.lshri      s9, s5, #11
    s.ashri      s5, s10, #63
    s.sub        s11, s6, s2
    s.sub        s2, s7, s4
    v.insert     v1, s12, #7
    v.insert     v2, s8, #7
    v.extract    s6, v5, #12
    v.extract    s7, v4, #12
    s.shli       s8, s6, #32
    s.xor        s6, s9, s3
    s.or         s9, s7, s8
    s.xor        s7, s10, s5
    s.lshri      s8, s11, #32
    s.lshri      s10, s2, #11
    s.ashri      s2, s9, #63
    s.sub        s12, s6, s3
    s.sub        s3, s7, s5
    v.insert     v1, s11, #8
    v.insert     v2, s8, #8
    v.extract    s6, v5, #13
    v.extract    s7, v4, #13
    s.shli       s8, s6, #32
    s.xor        s6, s10, s4
    s.or         s10, s7, s8
    s.xor        s7, s9, s2
    s.lshri      s8, s12, #32
    s.lshri      s9, s3, #11
    s.ashri      s3, s10, #63
    s.sub        s11, s6, s4
    s.sub        s4, s7, s2
    v.insert     v1, s12, #9
    v.insert     v2, s8, #9
    v.extract    s6, v5, #14
    v.extract    s7, v4, #14
    s.shli       s8, s6, #32
    s.xor        s6, s9, s5
    s.or         s9, s7, s8
    s.xor        s7, s10, s3
    s.lshri      s8, s11, #32
    s.lshri      s10, s4, #11
    s.ashri      s4, s9, #63
    s.sub        s12, s6, s5
    s.sub        s5, s7, s3
    v.insert     v1, s11, #10
    v.insert     v2, s8, #10
    v.extract    s6, v5, #15
    v.extract    s7, v4, #15
    s.shli       s8, s6, #32
    s.xor        s6, s10, s2
    s.or         s10, s7, s8
    s.xor        s7, s9, s4
    s.lshri      s8, s12, #32
    s.lshri      s9, s5, #11
    s.ashri      s5, s10, #63
    s.sub        s11, s6, s2
    s.sub        s2, s7, s4
    v.insert     v1, s12, #11
    v.insert     v2, s8, #11
    v.extract    s6, v5, #0
    v.extract    s7, v4, #0
    s.shli       s8, s6, #32
    s.xor        s6, s9, s3
    s.or         s9, s7, s8
    s.xor        s7, s10, s5
    s.lshri      s8, s11, #32
    s.lshri      s10, s2, #11
    s.sub        s2, s6, s3
    s.sub        s3, s7, s5
    v.insert     v1, s11, #12
    s.ashri      s6, s9, #63
    v.insert     v2, s8, #12
    v.extract    s7, v5, #1
    v.extract    s8, v4, #1
    s.xor        s11, s9, s6
    s.xor        s12, s10, s4
    s.sub        s10, s11, s6
    s.lshri      s11, s2, #32
    s.lshri      s14, s10, #11
    s.lshri      s10, s3, #11
    s.xor        s3, s14, s6
    s.sub        s14, s12, s4
    s.sub        s4, s3, s6
    v.insert     v1, s2, #13
    s.shli       s2, s7, #32
    s.muli       s3, s4, #2048
    s.or         s4, s8, s2
    v.insert     v2, s11, #13
    s.ashri      s2, s4, #63
    s.xor        s6, s10, s5
    s.xor        s7, s4, s2
    s.lshri      s8, s14, #32
    s.sub        s10, s7, s2
    s.sub        s7, s6, s5
    s.lshri      s5, s10, #11
    s.sub        s6, s9, s3
    s.xor        s3, s5, s2
    v.insert     v1, s14, #14
    v.extract    s5, v5, #2
    v.extract    s9, v4, #2
    s.sub        s10, s3, s2
    v.insert     v2, s8, #14
    s.shli       s2, s5, #32
    s.muli       s3, s10, #2048
    s.or         s5, s9, s2
    v.movi       v0, #0
    s.ashri      s2, s5, #63
    v.movi       v3, #0
    s.xor        s8, s5, s2
    s.lshri      s9, s7, #32
    s.sub        s10, s8, s2
    s.lshri      s8, s6, #32
    s.lshri      s11, s10, #11
    s.sub        s10, s4, s3
    s.xor        s3, s11, s2
    v.insert     v1, s7, #15
    s.sub        s4, s3, s2
    v.insert     v2, s9, #15
    v.extract    s2, v5, #3
    v.extract    s3, v4, #3
    s.shli       s7, s2, #32
    s.muli       s2, s4, #2048
    s.or         s4, s3, s7
    v.insert     v0, s6, #0
    v.extract    s3, v5, #4
    v.extract    s6, v4, #4
    s.ashri      s7, s4, #63
    v.insert     v3, s8, #0
    s.shli       s8, s3, #32
    s.xor        s3, s4, s7
    s.or         s9, s6, s8
    s.sub        s6, s3, s7
    s.ashri      s3, s9, #63
    s.lshri      s8, s6, #11
    s.xor        s6, s9, s3
    s.xor        s11, s8, s7
    s.sub        s8, s6, s3
    s.sub        s6, s11, s7
    s.lshri      s7, s8, #11
    s.muli       s8, s6, #2048
    s.xor        s6, s7, s3
    s.lshri      s7, s10, #32
    s.sub        s11, s6, s3
    s.sub        s3, s5, s2
    v.insert     v0, s10, #1
    v.extract    s2, v5, #5
    v.extract    s5, v4, #5
    v.insert     v3, s7, #1
    s.shli       s6, s2, #32
    s.muli       s2, s11, #2048
    s.or         s7, s5, s6
    s.lshri      s5, s3, #32
    s.ashri      s6, s7, #63
    s.sub        s10, s4, s8
    s.xor        s4, s7, s6
    v.insert     v0, s3, #2
    v.extract    s3, v5, #6
    v.extract    s8, v4, #6
    s.sub        s11, s4, s6
    v.insert     v3, s5, #2
    s.shli       s4, s3, #32
    s.lshri      s3, s11, #11
    s.or         s5, s8, s4
    s.xor        s4, s3, s6
    s.ashri      s3, s5, #63
    s.sub        s8, s4, s6
    s.xor        s4, s5, s3
    s.muli       s6, s8, #2048
    s.sub        s8, s4, s3
    s.lshri      s4, s10, #32
    s.lshri      s11, s8, #11
    s.sub        s8, s9, s2
    s.xor        s2, s11, s3
    v.insert     v0, s10, #3
    v.extract    s9, v5, #7
    v.extract    s10, v4, #7
    s.sub        s11, s2, s3
    v.insert     v3, s4, #3
    s.shli       s2, s9, #32
    s.muli       s3, s11, #2048
    s.or         s4, s10, s2
    s.lshri      s2, s8, #32
    s.ashri      s9, s4, #63
    s.sub        s10, s7, s6
    s.xor        s6, s4, s9
    v.insert     v0, s8, #4
    v.extract    s7, v5, #8
    v.extract    s8, v4, #8
    s.sub        s11, s6, s9
    v.insert     v3, s2, #4
    s.shli       s2, s7, #32
    s.lshri      s6, s11, #11
    s.or         s7, s8, s2
    s.xor        s2, s6, s9
    s.ashri      s6, s7, #63
    s.sub        s8, s2, s9
    s.xor        s2, s7, s6
    s.muli       s9, s8, #2048
    s.sub        s8, s2, s6
    s.lshri      s2, s10, #32
    s.lshri      s11, s8, #11
    s.sub        s8, s5, s3
    s.xor        s3, s11, s6
    v.insert     v0, s10, #5
    v.extract    s5, v5, #9
    v.extract    s10, v4, #9
    s.sub        s11, s3, s6
    v.insert     v3, s2, #5
    s.shli       s2, s5, #32
    s.muli       s3, s11, #2048
    s.or         s5, s10, s2
    s.lshri      s2, s8, #32
    s.ashri      s6, s5, #63
    s.sub        s10, s4, s9
    s.xor        s4, s5, s6
    v.insert     v0, s8, #6
    v.extract    s8, v5, #10
    v.extract    s9, v4, #10
    s.sub        s11, s4, s6
    v.insert     v3, s2, #6
    s.shli       s2, s8, #32
    s.lshri      s4, s11, #11
    s.or         s8, s9, s2
    s.xor        s2, s4, s6
    s.ashri      s4, s8, #63
    s.sub        s9, s2, s6
    s.xor        s2, s8, s4
    s.muli       s6, s9, #2048
    s.sub        s9, s2, s4
    s.lshri      s2, s10, #32
    s.lshri      s11, s9, #11
    s.sub        s9, s7, s3
    s.xor        s3, s11, s4
    v.insert     v0, s10, #7
    v.extract    s7, v5, #11
    v.extract    s10, v4, #11
    s.sub        s11, s3, s4
    v.insert     v3, s2, #7
    s.shli       s2, s7, #32
    s.muli       s3, s11, #2048
    s.or         s4, s10, s2
    s.lshri      s2, s9, #32
    s.ashri      s7, s4, #63
    s.sub        s10, s5, s6
    s.xor        s5, s4, s7
    v.insert     v0, s9, #8
    v.extract    s6, v5, #12
    v.extract    s9, v4, #12
    s.sub        s11, s5, s7
    v.insert     v3, s2, #8
    s.shli       s2, s6, #32
    s.lshri      s5, s11, #11
    s.or         s6, s9, s2
    s.xor        s2, s5, s7
    s.ashri      s5, s6, #63
    s.sub        s9, s2, s7
    s.xor        s2, s6, s5
    s.muli       s7, s9, #2048
    s.sub        s9, s2, s5
    s.lshri      s2, s10, #32
    s.lshri      s11, s9, #11
    s.sub        s9, s8, s3
    s.xor        s3, s11, s5
    v.insert     v0, s10, #9
    v.extract    s8, v5, #13
    v.extract    s10, v4, #13
    s.sub        s11, s3, s5
    v.insert     v3, s2, #9
    s.shli       s2, s8, #32
    s.muli       s3, s11, #2048
    s.or         s5, s10, s2
    s.lshri      s2, s9, #32
    s.ashri      s8, s5, #63
    s.sub        s10, s4, s7
    s.xor        s4, s5, s8
    v.insert     v0, s9, #10
    v.extract    s7, v5, #14
    v.extract    s9, v4, #14
    s.sub        s11, s4, s8
    v.insert     v3, s2, #10
    s.shli       s2, s7, #32
    s.lshri      s4, s11, #11
    s.or         s7, s9, s2
    s.xor        s2, s4, s8
    s.ashri      s4, s7, #63
    s.sub        s9, s2, s8
    s.xor        s2, s7, s4
    s.muli       s8, s9, #2048
    s.sub        s9, s2, s4
    s.lshri      s2, s10, #32
    s.lshri      s11, s9, #11
    s.sub        s9, s6, s3
    s.xor        s3, s11, s4
    v.insert     v0, s10, #11
    v.extract    s6, v5, #15
    v.extract    s10, v4, #15
    s.sub        s11, s3, s4
    v.insert     v3, s2, #11
    s.shli       s2, s6, #32
    s.muli       s3, s11, #2048
    s.or         s4, s10, s2
    s.lshri      s2, s9, #32
    s.ashri      s6, s4, #63
    s.sub        s10, s5, s8
    s.xor        s5, s4, s6
    v.insert     v0, s9, #12
    s.sub        s8, s5, s6
    v.extract    s5, v1, #0
    s.lshri      s9, s8, #11
    v.insert     v3, s2, #12
    s.xor        s2, s9, s6
    v.extract    s8, v2, #0
    v.extract    s9, v2, #1
    s.sub        s11, s2, s6
    s.shli       s2, s8, #32
    v.extract    s6, v1, #1
    s.muli       s8, s11, #2048
    s.lshri      s11, s10, #32
    s.or         s12, s5, s2
    s.sub        s2, s7, s3
    v.insert     v0, s10, #13
    s.shli       s3, s9, #32
    v.insert     v3, s11, #13
    v.extract    s5, v2, #2
    s.or         s7, s6, s3
    v.extract    s3, v1, #2
    s.shli       s6, s5, #32
    s.shli       s5, s12, #3
    v.iota       v4                              // arange(0, VLEN)
    s.shli       s9, s7, #3
    v.iota       v5                              // arange(0, VLEN)
    s.lshri      s7, s2, #32
    s.sub        s10, s4, s8
    s.add        s4, s1, s5                      // lane 0: a 64-bit address
    s.add        s5, s1, s9                      // lane 1: a 64-bit address
    v.insert     v0, s2, #14
    s.or         s2, s3, s6
    v.insert     v3, s7, #14
    v.extract    s3, v2, #3
    v.extract    s6, v1, #3
    s.shli       s7, s3, #32
    v.movi       v6, #0
    v.cmpi.eq    p2, v4, #0
    v.cmpi.eq    p3, v5, #1
    s.shli       s3, s2, #3
    v.iota       v4                              // arange(0, VLEN)
    s.lshri      s2, s10, #32
    p.and        p4, p1, p2
    s.addi       s8, s4, #4
    p.and        p2, p1, p3
    s.addi       s9, s5, #4
    s.or         s11, s6, s7
    s.add        s6, s1, s3                      // lane 2: a 64-bit address
    v.insert     v0, s10, #15
    v.insert     v3, s2, #15
    v.extract    s2, v2, #4
    v.extract    s3, v1, #4
    s.shli       s7, s2, #32
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v5, [s8, v6]               // index is in elements (ISA sec 9.1)
    s.shli       s2, s11, #3
    v.iota       v7                              // arange(0, VLEN)
    s.addi       s8, s6, #4
    s.add        s10, s1, s2                     // lane 3: a 64-bit address
    s.addi       s2, s10, #4
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s9, v6]               // index is in elements (ISA sec 9.1)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s4, v6]               // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p4, v4, #2
    s.or         s4, s3, s7
    v.extract    s3, v1, #5
    s.shli       s7, s4, #3
    v.iota       v4                              // arange(0, VLEN)
    s.add        s4, s1, s7                      // lane 4: a 64-bit address
    @p3 v.sel        v10, v8, v5
    s.addi       s7, s4, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s5, v6]               // index is in elements (ISA sec 9.1)
    v.extract    s5, v2, #5
    p.and        p2, p1, p4
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s8, v6]               // index is in elements (ISA sec 9.1)
    @p3 v.sel        v11, v5, v9
    s.shli       s8, s5, #32
    v.cmpi.eq    p3, v7, #3
    s.or         s5, s3, s8
    v.extract    s3, v1, #6
    s.shli       s8, s5, #3
    v.iota       v5                              // arange(0, VLEN)
    s.add        s5, s1, s8                      // lane 5: a 64-bit address
    s.addi       s8, s5, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s6, v6]               // index is in elements (ISA sec 9.1)
    v.extract    s6, v2, #6
    p.and        p2, p1, p3
    @p4 v.sel        v9, v8, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s2, v6]               // index is in elements (ISA sec 9.1)
    @p4 v.sel        v10, v7, v11
    s.shli       s2, s6, #32
    v.cmpi.eq    p4, v4, #4
    s.or         s6, s3, s2
    v.extract    s2, v1, #7
    s.shli       s3, s6, #3
    v.iota       v4                              // arange(0, VLEN)
    s.add        s6, s1, s3                      // lane 6: a 64-bit address
    s.addi       s3, s6, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s10, v6]              // index is in elements (ISA sec 9.1)
    v.extract    s9, v2, #7
    p.and        p2, p1, p4
    @p3 v.sel        v11, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s7, v6]               // index is in elements (ISA sec 9.1)
    @p3 v.sel        v9, v7, v10
    s.shli       s7, s9, #32
    v.cmpi.eq    p3, v5, #5
    s.or         s9, s2, s7
    v.extract    s2, v1, #8
    s.shli       s7, s9, #3
    v.iota       v5                              // arange(0, VLEN)
    s.add        s9, s1, s7                      // lane 7: a 64-bit address
    s.addi       s7, s9, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s4, v6]               // index is in elements (ISA sec 9.1)
    v.extract    s4, v2, #8
    p.and        p2, p1, p3
    @p4 v.sel        v10, v8, v11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s8, v6]               // index is in elements (ISA sec 9.1)
    @p4 v.sel        v11, v7, v9
    s.shli       s8, s4, #32
    v.cmpi.eq    p4, v4, #6
    s.or         s4, s2, s8
    v.extract    s2, v1, #9
    s.shli       s8, s4, #3
    v.iota       v4                              // arange(0, VLEN)
    s.add        s4, s1, s8                      // lane 8: a 64-bit address
    s.addi       s8, s4, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s5, v6]               // index is in elements (ISA sec 9.1)
    v.extract    s5, v2, #9
    p.and        p2, p1, p4
    @p3 v.sel        v9, v8, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s3, v6]               // index is in elements (ISA sec 9.1)
    @p3 v.sel        v10, v7, v11
    s.shli       s3, s5, #32
    v.cmpi.eq    p3, v5, #7
    s.or         s5, s2, s3
    v.extract    s2, v1, #10
    s.shli       s3, s5, #3
    v.iota       v5                              // arange(0, VLEN)
    s.add        s5, s1, s3                      // lane 9: a 64-bit address
    s.addi       s3, s5, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s6, v6]               // index is in elements (ISA sec 9.1)
    v.extract    s6, v2, #10
    p.and        p2, p1, p3
    @p4 v.sel        v11, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s7, v6]               // index is in elements (ISA sec 9.1)
    @p4 v.sel        v9, v7, v10
    s.shli       s7, s6, #32
    v.cmpi.eq    p4, v4, #8
    s.or         s6, s2, s7
    v.extract    s2, v1, #11
    s.shli       s7, s6, #3
    v.iota       v4                              // arange(0, VLEN)
    s.add        s6, s1, s7                      // lane 10: a 64-bit address
    s.addi       s7, s6, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s9, v6]               // index is in elements (ISA sec 9.1)
    v.extract    s9, v2, #11
    p.and        p2, p1, p4
    @p3 v.sel        v10, v8, v11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s8, v6]               // index is in elements (ISA sec 9.1)
    @p3 v.sel        v11, v7, v9
    s.shli       s8, s9, #32
    v.cmpi.eq    p3, v5, #9
    s.or         s9, s2, s8
    v.extract    s2, v1, #12
    s.shli       s8, s9, #3
    v.iota       v5                              // arange(0, VLEN)
    s.add        s9, s1, s8                      // lane 11: a 64-bit address
    s.addi       s8, s9, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s4, v6]               // index is in elements (ISA sec 9.1)
    v.extract    s4, v2, #12
    p.and        p2, p1, p3
    @p4 v.sel        v9, v8, v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s3, v6]               // index is in elements (ISA sec 9.1)
    @p4 v.sel        v10, v7, v11
    s.shli       s3, s4, #32
    v.cmpi.eq    p4, v4, #10
    s.or         s4, s2, s3
    v.extract    s2, v1, #13
    s.shli       s3, s4, #3
    v.iota       v4                              // arange(0, VLEN)
    s.add        s4, s1, s3                      // lane 12: a 64-bit address
    s.addi       s3, s4, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s5, v6]               // index is in elements (ISA sec 9.1)
    v.extract    s5, v2, #13
    p.and        p2, p1, p4
    @p3 v.sel        v11, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s7, v6]               // index is in elements (ISA sec 9.1)
    @p3 v.sel        v9, v7, v10
    s.shli       s7, s5, #32
    v.cmpi.eq    p3, v5, #11
    s.or         s5, s2, s7
    v.extract    s2, v1, #14
    s.shli       s7, s5, #3
    v.iota       v5                              // arange(0, VLEN)
    s.add        s5, s1, s7                      // lane 13: a 64-bit address
    s.addi       s7, s5, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s6, v6]               // index is in elements (ISA sec 9.1)
    v.extract    s6, v2, #14
    p.and        p2, p1, p3
    @p4 v.sel        v10, v8, v11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s8, v6]               // index is in elements (ISA sec 9.1)
    @p4 v.sel        v11, v7, v9
    s.shli       s8, s6, #32
    v.cmpi.eq    p4, v4, #12
    s.or         s6, s2, s8
    v.extract    s2, v1, #15
    s.shli       s8, s6, #3
    v.iota       v1                              // arange(0, VLEN)
    s.add        s6, s1, s8                      // lane 14: a 64-bit address
    s.addi       s8, s6, #4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s9, v6]               // index is in elements (ISA sec 9.1)
    v.extract    s9, v2, #15
    p.and        p2, p1, p4
    @p3 v.sel        v2, v8, v10
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s3, v6]               // index is in elements (ISA sec 9.1)
    @p3 v.sel        v8, v4, v11
    s.shli       s3, s9, #32
    v.cmpi.eq    p3, v5, #13
    s.or         s9, s2, s3
    v.iota       v4                              // arange(0, VLEN)
    s.shli       s2, s9, #3
    v.movi       v5, #0
    s.add        s3, s1, s2                      // lane 15: a 64-bit address
    s.addi       s1, s3, #4
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s4, v6]               // index is in elements (ISA sec 9.1)
    p.and        p2, p1, p3
    @p4 v.sel        v10, v7, v2
    v.movi       v2, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s7, v6]               // index is in elements (ISA sec 9.1)
    @p4 v.sel        v11, v9, v8
    v.cmpi.eq    p4, v1, #14
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s5, v6]               // index is in elements (ISA sec 9.1)
    p.and        p2, p1, p4
    @p3 v.sel        v8, v7, v10
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s8, v6]               // index is in elements (ISA sec 9.1)
    @p3 v.sel        v9, v1, v11
    v.cmpi.eq    p3, v4, #15
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s6, v6]               // index is in elements (ISA sec 9.1)
    p.and        p2, p1, p3
    @p4 v.sel        v4, v7, v8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s1, v6]               // index is in elements (ISA sec 9.1)
    @p4 v.sel        v8, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s3, v6]               // index is in elements (ISA sec 9.1)
    @p3 v.sel        v6, v7, v4
    v.extract    s1, v6, #0
    v.extract    s2, v6, #1
    s.shli       s3, s1, #32
    s.shli       s1, s2, #32
    v.extract    s2, v6, #2
    v.extract    s4, v6, #3
    s.shli       s5, s2, #32
    s.shli       s2, s4, #32
    v.extract    s4, v6, #4
    v.extract    s6, v6, #5
    s.shli       s7, s4, #32
    @p3 v.sel        v4, v1, v8
    s.shli       s4, s6, #32
    v.extract    s6, v4, #0
    v.extract    s8, v4, #1
    s.or         s9, s6, s3
    s.or         s3, s8, s1
    s.shli       s1, s9, #11                     // x2048 as a shift
    v.extract    s6, v4, #2
    s.lshri      s8, s1, #32
    s.shli       s9, s3, #11                     // x2048 as a shift
    v.insert     v5, s1, #0
    v.insert     v2, s8, #0
    s.or         s1, s6, s5
    s.lshri      s3, s9, #32
    v.extract    s5, v4, #3
    s.shli       s6, s1, #11                     // x2048 as a shift
    v.insert     v5, s9, #1
    v.insert     v2, s3, #1
    s.or         s1, s5, s2
    s.lshri      s2, s6, #32
    v.extract    s3, v4, #4
    s.shli       s5, s1, #11                     // x2048 as a shift
    v.insert     v5, s6, #2
    v.insert     v2, s2, #2
    s.or         s1, s3, s7
    s.lshri      s2, s5, #32
    v.extract    s3, v4, #5
    s.shli       s6, s1, #11                     // x2048 as a shift
    v.extract    s1, v6, #6
    v.insert     v5, s5, #3
    v.insert     v2, s2, #3
    s.or         s2, s3, s4
    s.lshri      s3, s6, #32
    v.extract    s4, v4, #6
    s.shli       s5, s1, #32
    s.shli       s1, s2, #11                     // x2048 as a shift
    v.extract    s2, v6, #7
    v.insert     v5, s6, #4
    v.insert     v2, s3, #4
    s.or         s3, s4, s5
    s.lshri      s4, s1, #32
    v.extract    s5, v4, #7
    s.shli       s6, s2, #32
    s.shli       s2, s3, #11                     // x2048 as a shift
    v.extract    s3, v6, #8
    v.insert     v5, s1, #5
    v.insert     v2, s4, #5
    s.or         s1, s5, s6
    s.lshri      s4, s2, #32
    v.extract    s5, v4, #8
    s.shli       s6, s3, #32
    s.shli       s3, s1, #11                     // x2048 as a shift
    v.extract    s1, v6, #9
    v.insert     v5, s2, #6
    v.insert     v2, s4, #6
    s.or         s2, s5, s6
    s.lshri      s4, s3, #32
    v.extract    s5, v4, #9
    s.shli       s6, s1, #32
    s.shli       s1, s2, #11                     // x2048 as a shift
    v.extract    s2, v6, #10
    v.insert     v5, s3, #7
    v.insert     v2, s4, #7
    s.or         s3, s5, s6
    s.lshri      s4, s1, #32
    v.extract    s5, v4, #10
    s.shli       s6, s2, #32
    s.shli       s2, s3, #11                     // x2048 as a shift
    v.extract    s3, v6, #11
    v.insert     v5, s1, #8
    v.insert     v2, s4, #8
    s.or         s1, s5, s6
    s.lshri      s4, s2, #32
    v.extract    s5, v4, #11
    s.shli       s6, s3, #32
    s.shli       s3, s1, #11                     // x2048 as a shift
    v.extract    s1, v6, #12
    v.insert     v5, s2, #9
    v.insert     v2, s4, #9
    s.or         s2, s5, s6
    s.lshri      s4, s3, #32
    v.extract    s5, v4, #12
    s.shli       s6, s1, #32
    s.shli       s1, s2, #11                     // x2048 as a shift
    v.extract    s2, v6, #13
    v.insert     v5, s3, #10
    v.insert     v2, s4, #10
    s.or         s3, s5, s6
    s.lshri      s4, s1, #32
    v.extract    s5, v4, #13
    s.shli       s6, s2, #32
    s.shli       s2, s3, #11                     // x2048 as a shift
    v.extract    s3, v6, #14
    v.insert     v5, s1, #11
    v.insert     v2, s4, #11
    s.or         s1, s5, s6
    s.lshri      s4, s2, #32
    v.extract    s5, v4, #14
    s.shli       s6, s3, #32
    s.shli       s3, s1, #11                     // x2048 as a shift
    v.extract    s1, v6, #15
    v.insert     v5, s2, #12
    v.insert     v2, s4, #12
    s.or         s2, s5, s6
    s.lshri      s4, s3, #32
    v.extract    s5, v4, #15
    s.shli       s6, s1, #32
    s.shli       s1, s2, #11                     // x2048 as a shift
    v.insert     v5, s3, #13
    v.insert     v2, s4, #13
    s.or         s2, s5, s6
    s.lshri      s3, s1, #32
    s.shli       s4, s2, #11                     // x2048 as a shift
    v.insert     v5, s1, #14
    v.insert     v2, s3, #14
    s.lshri      s1, s4, #32
    v.insert     v5, s4, #15
    v.insert     v2, s1, #15
    v.extract    s1, v3, #0
    v.extract    s2, v0, #0
    v.extract    s3, v2, #0
    s.shli       s4, s1, #32
    v.extract    s1, v5, #0
    s.shli       s5, s3, #32
    v.extract    s3, v3, #1
    v.extract    s6, v2, #1
    s.or         s7, s2, s4
    s.or         s2, s1, s5
    v.extract    s1, v0, #1
    s.shli       s4, s3, #32
    v.extract    s3, v5, #1
    s.shli       s5, s6, #32
    s.add        s6, s7, s2
    v.extract    s2, v3, #2
    v.extract    s7, v2, #2
    v.movi       v1, #0
    v.movi       v4, #0
    s.or         s8, s1, s4
    s.or         s1, s3, s5
    s.lshri      s3, s6, #32
    v.extract    s4, v0, #2
    s.shli       s5, s2, #32
    v.extract    s2, v5, #2
    s.shli       s9, s7, #32
    s.add        s7, s8, s1
    v.extract    s1, v3, #3
    v.extract    s8, v2, #3
    v.insert     v1, s6, #0
    v.insert     v4, s3, #0
    s.or         s3, s4, s5
    s.or         s4, s2, s9
    s.lshri      s2, s7, #32
    v.extract    s5, v0, #3
    s.shli       s6, s1, #32
    v.extract    s1, v5, #3
    s.shli       s9, s8, #32
    s.add        s8, s3, s4
    v.extract    s3, v3, #4
    v.extract    s4, v2, #4
    v.insert     v1, s7, #1
    v.insert     v4, s2, #1
    s.or         s2, s5, s6
    s.or         s5, s1, s9
    s.lshri      s1, s8, #32
    v.extract    s6, v0, #4
    s.shli       s7, s3, #32
    v.extract    s3, v5, #4
    s.shli       s9, s4, #32
    s.add        s4, s2, s5
    v.extract    s2, v3, #5
    v.extract    s5, v2, #5
    v.insert     v1, s8, #2
    v.insert     v4, s1, #2
    s.or         s1, s6, s7
    s.or         s6, s3, s9
    s.lshri      s3, s4, #32
    v.extract    s7, v0, #5
    s.shli       s8, s2, #32
    v.extract    s2, v5, #5
    s.shli       s9, s5, #32
    s.add        s5, s1, s6
    v.extract    s1, v3, #6
    v.extract    s6, v2, #6
    v.insert     v1, s4, #3
    v.insert     v4, s3, #3
    s.or         s3, s7, s8
    s.or         s4, s2, s9
    s.lshri      s2, s5, #32
    v.extract    s7, v0, #6
    s.shli       s8, s1, #32
    v.extract    s1, v5, #6
    s.shli       s9, s6, #32
    s.add        s6, s3, s4
    v.extract    s3, v3, #7
    v.extract    s4, v2, #7
    v.insert     v1, s5, #4
    v.insert     v4, s2, #4
    s.or         s2, s7, s8
    s.or         s5, s1, s9
    s.lshri      s1, s6, #32
    v.extract    s7, v0, #7
    s.shli       s8, s3, #32
    v.extract    s3, v5, #7
    s.shli       s9, s4, #32
    s.add        s4, s2, s5
    v.extract    s2, v3, #8
    v.extract    s5, v2, #8
    v.insert     v1, s6, #5
    v.insert     v4, s1, #5
    s.or         s1, s7, s8
    s.or         s6, s3, s9
    s.lshri      s3, s4, #32
    v.extract    s7, v0, #8
    s.shli       s8, s2, #32
    v.extract    s2, v5, #8
    s.shli       s9, s5, #32
    s.add        s5, s1, s6
    v.extract    s1, v3, #9
    v.extract    s6, v2, #9
    v.insert     v1, s4, #6
    v.insert     v4, s3, #6
    s.or         s3, s7, s8
    s.or         s4, s2, s9
    s.lshri      s2, s5, #32
    v.extract    s7, v0, #9
    s.shli       s8, s1, #32
    v.extract    s1, v5, #9
    s.shli       s9, s6, #32
    s.add        s6, s3, s4
    v.extract    s3, v3, #10
    v.extract    s4, v2, #10
    v.insert     v1, s5, #7
    v.insert     v4, s2, #7
    s.or         s2, s7, s8
    s.or         s5, s1, s9
    s.lshri      s1, s6, #32
    v.extract    s7, v0, #10
    s.shli       s8, s3, #32
    v.extract    s3, v5, #10
    s.shli       s9, s4, #32
    s.add        s4, s2, s5
    v.extract    s2, v3, #11
    v.extract    s5, v2, #11
    v.insert     v1, s6, #8
    v.insert     v4, s1, #8
    s.or         s1, s7, s8
    s.or         s6, s3, s9
    s.lshri      s3, s4, #32
    v.extract    s7, v0, #11
    s.shli       s8, s2, #32
    v.extract    s2, v5, #11
    s.shli       s9, s5, #32
    s.add        s5, s1, s6
    v.extract    s1, v3, #12
    v.extract    s6, v2, #12
    v.insert     v1, s4, #9
    v.insert     v4, s3, #9
    s.or         s3, s7, s8
    s.or         s4, s2, s9
    s.lshri      s2, s5, #32
    v.extract    s7, v0, #12
    s.shli       s8, s1, #32
    v.extract    s1, v5, #12
    s.shli       s9, s6, #32
    s.add        s6, s3, s4
    v.extract    s3, v3, #13
    v.extract    s4, v2, #13
    v.insert     v1, s5, #10
    v.insert     v4, s2, #10
    s.or         s2, s7, s8
    s.or         s5, s1, s9
    s.lshri      s1, s6, #32
    v.extract    s7, v0, #13
    s.shli       s8, s3, #32
    v.extract    s3, v5, #13
    s.shli       s9, s4, #32
    s.add        s4, s2, s5
    v.extract    s2, v3, #14
    v.extract    s5, v2, #14
    v.insert     v1, s6, #11
    v.insert     v4, s1, #11
    s.or         s1, s7, s8
    s.or         s6, s3, s9
    s.lshri      s3, s4, #32
    v.extract    s7, v0, #14
    s.shli       s8, s2, #32
    v.extract    s2, v5, #14
    s.shli       s9, s5, #32
    s.add        s5, s1, s6
    v.extract    s1, v3, #15
    v.extract    s6, v2, #15
    v.insert     v1, s4, #12
    v.insert     v4, s3, #12
    s.or         s3, s7, s8
    s.or         s4, s2, s9
    s.lshri      s2, s5, #32
    v.extract    s7, v0, #15
    s.shli       s8, s1, #32
    v.extract    s1, v5, #15
    s.shli       s9, s6, #32
    s.add        s6, s3, s4
    v.insert     v1, s5, #13
    v.insert     v4, s2, #13
    s.or         s2, s7, s8
    s.or         s3, s1, s9
    s.lshri      s1, s6, #32
    s.add        s4, s2, s3
    v.insert     v1, s6, #14
    v.insert     v4, s1, #14
    s.lshri      s1, s4, #32
    v.insert     v1, s4, #15
    v.insert     v4, s1, #15
    v.iota       v0                              // arange(0, VLEN)
    v.extract    s1, v1, #0
    v.extract    s2, v4, #0
    v.extract    s3, v4, #1
    s.shli       s4, s2, #32
    v.extract    s2, v1, #1
    s.shli       s5, s3, #32
    v.iota       v2                              // arange(0, VLEN)
    v.extract    s3, v4, #2
    s.or         s6, s1, s4
    s.or         s1, s2, s5
    v.movi       v3, #0
    v.cmpi.eq    p2, v0, #0
    v.cmpi.eq    p3, v2, #1
    v.extract    s2, v1, #2
    s.shli       s4, s3, #32
    v.iota       v0                              // arange(0, VLEN)
    s.add        s3, s13, s6                     // lane 0: a 64-bit address
    p.and        p4, p1, p2
    s.add        s5, s13, s1                     // lane 1: a 64-bit address
    p.and        p2, p1, p3
    v.extract    s1, v4, #3
    s.or         s6, s2, s4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.sb v2, [s3, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p4, v0, #2
    v.extract    s2, v1, #3
    s.shli       s3, s1, #32
    v.iota       v0                              // arange(0, VLEN)
    s.add        s1, s13, s6                     // lane 2: a 64-bit address
    v.extract    s4, v4, #4
    s.or         s6, s2, s3
    v.extract    s2, v1, #4
    s.shli       s3, s4, #32
    v.iota       v5                              // arange(0, VLEN)
    s.add        s4, s13, s6                     // lane 3: a 64-bit address
    v.extract    s6, v4, #5
    s.or         s7, s2, s3
    v.extract    s2, v1, #5
    s.shli       s3, s6, #32
    v.iota       v6                              // arange(0, VLEN)
    s.add        s6, s13, s7                     // lane 4: a 64-bit address
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v7, [s5, v3]              // index is in elements (ISA sec 9.1)
    p.and        p2, p1, p4
    v.extract    s5, v4, #6
    s.or         s7, s2, s3
    v.extract    s2, v1, #6
    s.shli       s3, s5, #32
    v.iota       v8                              // arange(0, VLEN)
    s.add        s5, s13, s7                     // lane 5: a 64-bit address
    s.or         s7, s2, s3
    s.add        s2, s13, s7                     // lane 6: a 64-bit address
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v9, [s1, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p2, v0, #3
    @p3 v.sel        v0, v7, v2
    p.and        p3, p1, p2
    v.extract    s1, v4, #7
    v.extract    s3, v1, #7
    s.shli       s7, s1, #32
    v.iota       v2                              // arange(0, VLEN)
    s.or         s1, s3, s7
    s.add        s3, s13, s1                     // lane 7: a 64-bit address
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v7, [s4, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p3, v5, #4
    @p4 v.sel        v5, v9, v0
    p.and        p4, p1, p3
    v.extract    s1, v4, #8
    v.extract    s4, v1, #8
    s.shli       s7, s1, #32
    v.iota       v0                              // arange(0, VLEN)
    s.or         s1, s4, s7
    s.add        s4, s13, s1                     // lane 8: a 64-bit address
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.sb v9, [s6, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p4, v6, #5
    @p2 v.sel        v6, v7, v5
    p.and        p2, p1, p4
    v.extract    s1, v4, #9
    v.extract    s6, v1, #9
    s.shli       s7, s1, #32
    v.iota       v5                              // arange(0, VLEN)
    s.or         s1, s6, s7
    s.add        s6, s13, s1                     // lane 9: a 64-bit address
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v7, [s5, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p2, v8, #6
    @p3 v.sel        v8, v9, v6
    p.and        p3, p1, p2
    v.extract    s1, v4, #10
    v.extract    s5, v1, #10
    s.shli       s7, s1, #32
    v.iota       v6                              // arange(0, VLEN)
    s.or         s1, s5, s7
    s.add        s5, s13, s1                     // lane 10: a 64-bit address
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v9, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p3, v2, #7
    @p4 v.sel        v2, v7, v8
    p.and        p4, p1, p3
    v.extract    s1, v4, #11
    v.extract    s2, v1, #11
    s.shli       s7, s1, #32
    v.iota       v7                              // arange(0, VLEN)
    s.or         s1, s2, s7
    s.add        s2, s13, s1                     // lane 11: a 64-bit address
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.sb v8, [s3, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p4, v0, #8
    @p2 v.sel        v0, v9, v2
    p.and        p2, p1, p4
    v.extract    s1, v4, #12
    v.extract    s3, v1, #12
    s.shli       s7, s1, #32
    v.iota       v2                              // arange(0, VLEN)
    s.or         s1, s3, s7
    s.add        s3, s13, s1                     // lane 12: a 64-bit address
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v9, [s4, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p2, v5, #9
    @p3 v.sel        v5, v8, v0
    p.and        p3, p1, p2
    v.extract    s1, v4, #13
    v.extract    s4, v1, #13
    s.shli       s7, s1, #32
    v.iota       v0                              // arange(0, VLEN)
    s.or         s1, s4, s7
    s.add        s4, s13, s1                     // lane 13: a 64-bit address
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v8, [s6, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p3, v6, #10
    @p4 v.sel        v6, v9, v5
    p.and        p4, p1, p3
    v.extract    s1, v4, #14
    v.extract    s6, v1, #14
    s.shli       s7, s1, #32
    v.iota       v5                              // arange(0, VLEN)
    s.or         s1, s6, s7
    s.add        s6, s13, s1                     // lane 14: a 64-bit address
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.sb v9, [s5, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p4, v7, #11
    @p2 v.sel        v7, v8, v6
    p.and        p2, p1, p4
    v.extract    s1, v4, #15
    v.extract    s5, v1, #15
    s.shli       s7, s1, #32
    v.iota       v1                              // arange(0, VLEN)
    s.or         s1, s5, s7
    s.add        s5, s13, s1                     // lane 15: a 64-bit address
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v4, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p2, v2, #12
    @p3 v.sel        v2, v9, v7
    p.and        p3, p1, p2
    s.shli       s1, s16, #2                     // element offset -> bytes (x4)
    s.add        s2, s20, s1                     // &out_ptr0[...]
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v6, [s3, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p3, v0, #13
    @p4 v.sel        v0, v4, v2
    p.and        p4, p1, p3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.sb v2, [s4, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p4, v5, #14
    @p2 v.sel        v4, v6, v0
    p.and        p2, p1, p4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v0, [s6, v3]              // index is in elements (ISA sec 9.1)
    v.cmpi.eq    p2, v1, #15
    @p3 v.sel        v1, v2, v4
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v2, [s5, v3]              // index is in elements (ISA sec 9.1)
    @p4 v.sel        v3, v0, v1
    @p2 v.sel        v0, v2, v3
    vf.cvt.s32.f32 v1, v0
    @p1 v.st.w       [s2, #0], v1
__rctx_next:
    exit
