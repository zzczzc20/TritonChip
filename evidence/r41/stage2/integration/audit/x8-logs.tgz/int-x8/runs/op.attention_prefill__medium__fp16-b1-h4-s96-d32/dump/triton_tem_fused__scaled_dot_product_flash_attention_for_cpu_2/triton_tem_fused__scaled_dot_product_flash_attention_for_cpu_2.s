    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    .li       s1, #1431655766
    s.sub        s5, s2, s3
    s.movz       s2, #6
    s.xor        s3, s4, s5
    s.movz       s6, #0
    s.sub        s7, s3, s5
    s.movz       s3, #0
    s.mul        s8, s7, s1
    s.cmp.lt     s1, s2, s6
    s.movz       s6, #1
    s.sub        s9, s3, s1
    s.movz       s1, #0
    s.lshri      s3, s8, #32
    s.xor        s8, s5, s9
    s.sub        s5, s7, s3
    s.movz       s10, #0
    s.lshri      s11, s5, #1
    s.movz       s5, #0
    s.add        s12, s3, s11
    s.movz       s3, #0
    s.lshri      s11, s12, #2
    s.cmp.lt     s12, s4, s10
    s.xor        s10, s11, s8
    s.sub        s13, s3, s12
    s.sub        s3, s10, s8
    s.muli       s8, s11, #6
    s.sub        s10, s2, s3
    s.movz       s11, #0
    s.min.s      s12, s10, s6
    s.movz       s6, #1
    s.cmp.lt     s10, s12, s1
    s.xor        s1, s4, s13
    s.sub        s14, s5, s10
    s.rdspecial  s5, arg_base
    s.xor        s10, s12, s14
    s.xor        s15, s2, s9
    s.sub        s16, s10, s14
    s.movz       s10, #0
    s.sub        s14, s1, s13
    s.addi       s1, s11, #0
    s.ld.d       s11, [s5, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.cmp.eq     s17, s16, s6
    s.sub        s6, s15, s9
    s.ld.d       s6, [s5, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.sub        s9, s7, s8
    s.addi       s7, s10, #0
    s.ld.d       s8, [s5, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s1, s14
    br.nz        s17, sdiv_done_1
    s.movz       s5, #0
    s.movz       s9, #31
    s.mov        s1, s5
    s.addi       s5, s9, #0
sdiv_2:
    s.lshr       s9, s14, s5
    s.shli       s10, s7, #1
    s.andi       s15, s9, #1
    s.movz       s9, #0
    s.or         s17, s10, s15
    s.movz       s10, #1
    s.cmp.geu    s15, s17, s16
    s.shl        s18, s10, s5
    s.sub        s10, s9, s15
    s.subi       s9, s5, #1
    s.and        s15, s16, s10
    s.and        s19, s18, s10
    s.sub        s10, s17, s15
    s.or         s15, s1, s19
    s.mov        s7, s10
    s.mov        s1, s15
    s.mov        s5, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s5, s9
    br.nz        s10, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s1
    .li       s1, #1431655766
    s.sub        s10, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s10
    s.movz       s4, #0
    s.sub        s14, s9, s10
    s.movz       s9, #0
    s.mul        s15, s14, s1
    s.cmp.lt     s1, s12, s5
    s.movz       s5, #0
    s.sub        s16, s9, s1
    s.movz       s1, #0
    s.lshri      s9, s15, #32
    s.cmp.lt     s15, s2, s5
    s.xor        s5, s12, s16
    s.xor        s12, s7, s13
    s.sub        s7, s5, s16
    s.sub        s5, s12, s13
    s.sub        s12, s14, s9
    s.add        s13, s3, s5
    s.lshri      s3, s12, #1
    s.movz       s5, #0
    s.add        s12, s9, s3
    s.sub        s3, s5, s15
    s.lshri      s5, s12, #2
    s.movz       s9, #0
    s.muli       s12, s5, #6
    s.movz       s5, #1
    s.xor        s15, s2, s3
    s.addi       s2, s9, #0
    s.cmp.eq     s9, s7, s5
    s.sub        s5, s14, s12
    s.movz       s12, #0
    s.xor        s14, s5, s10
    s.sub        s5, s15, s3
    s.sub        s3, s14, s10
    s.addi       s5, s12, #0
    s.cmp.lt     s10, s3, s4
    s.sub        s4, s1, s10
    s.xor        s1, s3, s4
    s.sub        s3, s1, s4
    s.mov        s2, s3
    br.nz        s9, sdiv_done_3
    s.movz       s1, #0
    s.movz       s9, #31
    s.mov        s2, s1
    s.addi       s1, s9, #0
sdiv_4:
    s.lshr       s9, s3, s1
    s.shli       s10, s5, #1
    s.andi       s12, s9, #1
    s.movz       s9, #0
    s.or         s14, s10, s12
    s.movz       s10, #1
    s.cmp.geu    s12, s14, s7
    s.shl        s15, s10, s1
    s.sub        s10, s9, s12
    s.subi       s9, s1, #1
    s.and        s12, s7, s10
    s.and        s17, s15, s10
    s.sub        s10, s14, s12
    s.or         s12, s2, s17
    s.mov        s5, s10
    s.mov        s2, s12
    s.mov        s1, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s1, s9
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.movz       s1, #16
    s.xor        s3, s4, s16
    s.mul        s4, s13, s1
    s.xor        s5, s2, s3
    .li       s2, #1431655766
    s.sub        s7, s5, s3
    .li       s3, #1431655766
    s.mul        s5, s7, s1
    s.mul        s9, s4, s2
    s.rdspecial  s2, pid.z
    s.rdspecial  s10, npid.y
    s.rdspecial  s12, pid.y
    s.mul        s14, s5, s3
    s.lshri      s3, s9, #32
    s.mul        s9, s2, s10
    s.sub        s2, s4, s3
    s.movz       s10, #3
    s.lshri      s15, s2, #1
    s.lshri      s2, s14, #32
    s.add        s14, s3, s15
    s.sub        s3, s5, s2
    s.lshri      s15, s14, #6
    s.lshri      s14, s3, #1
    s.muli       s3, s15, #96
    s.add        s15, s2, s14
    s.add        s2, s12, s9
    s.lshri      s9, s15, #6
    s.min.s      s12, s2, s10
    s.sub        s10, s4, s3
    s.muli       s3, s9, #96
    s.movz       s9, #3072
    s.movz       s14, #0
    s.mul        s15, s12, s9
    v.splat      v0, s13
    s.sub        s9, s5, s3
    v.splat      v1, s14
    s.rdspecial  s3, arg_base
    v.splat      v2, s7
    v.splat      v3, s14
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s4
    v.cmp.ge     p1, v0, v1
    s.rdspecial  s7, role_id
    s.movz       s12, #6144
    s.ld.d       s13, [s3, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v0, s5
    v.splat      v1, s10
    v.cmp.ge     p1, v2, v3
    s.muli       s3, s10, #32                    // a runtime tile origin, x32
    s.movz       s10, #0
    s.mul        s16, s7, s12
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s9
    v.add        v6, v5, v4
    s.add        s7, s10, s3                     // the tile origin
    s.add        s3, s13, s16                    // this context's own scratch
    s.add        s10, s7, s15                    // the tile origin
    s.addi       s7, s3, #0
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    s.addi       s12, s10, #32
    s.addi       s13, s10, #64
    v.splat      v0, s10
    v.splat      v4, s12
    v.add        v6, v5, v0
    s.addi       s12, s7, #64
    v.add        v0, v5, v4
    s.addi       s16, s7, #128
    v.add        v4, v1, v2
    s.addi       s17, s10, #96
    s.addi       s18, s10, #128
    v.splat      v1, s13
    v.splat      v2, s17
    v.add        v4, v5, v1
    s.addi       s13, s7, #192
    v.add        v1, v5, v2
    s.addi       s17, s7, #256
    s.movz       s19, #32
    s.addi       s20, s14, #0
    v.st.w       [s7, #0], v6
    v.splat      v2, s18
    v.add        v6, v5, v2
    v.st.w       [s12, #0], v0
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s12, s7, #320
    v.add        v2, v3, v0
    s.addi       s14, s10, #160
    s.addi       s18, s10, #192
    v.splat      v0, s14
    s.addi       s14, s10, #224
    v.splat      v2, s18
    s.addi       s18, s10, #256
    v.add        v3, v5, v0
    v.add        v0, v5, v2
    v.st.w       [s16, #0], v4
    s.addi       s16, s10, #288
    v.splat      v2, s14
    s.addi       s14, s10, #320
    v.add        v4, v5, v2
    v.st.w       [s13, #0], v1
    s.addi       s13, s10, #352
    v.splat      v1, s18
    s.addi       s18, s10, #384
    v.add        v2, v5, v1
    v.st.w       [s17, #0], v6
    s.addi       s17, s10, #416
    v.splat      v1, s16
    s.addi       s16, s10, #448
    s.addi       s21, s10, #480
    v.add        v6, v5, v1
    v.st.w       [s12, #0], v3
    v.splat      v1, s14
    s.addi       s10, s7, #384
    s.addi       s12, s3, #1024
    v.add        v3, v5, v1
    v.st.w       [s10, #0], v0
    s.movz       s10, #0
    v.splat      v0, s13
    s.addi       s13, s7, #448
    s.add        s14, s10, s9                    // the tile origin
    s.addi       s9, s7, #512
    s.add        s10, s14, s15                   // the tile origin
    s.addi       s14, s7, #576
    v.add        v1, v5, v0
    v.st.w       [s13, #0], v4
    s.addi       s13, s10, #96
    v.splat      v0, s18
    s.addi       s15, s7, #640
    v.add        v4, v5, v0
    v.st.w       [s9, #0], v2
    s.addi       s9, s10, #192
    v.splat      v0, s17
    s.addi       s17, s7, #704
    v.add        v2, v5, v0
    v.st.w       [s14, #0], v6
    s.addi       s14, s10, #288
    v.splat      v0, s16
    s.addi       s16, s7, #768
    v.add        v6, v5, v0
    v.st.w       [s15, #0], v3
    s.addi       s15, s10, #384
    v.splat      v0, s21
    s.addi       s18, s7, #832
    v.add        v3, v5, v0
    v.st.w       [s17, #0], v1
    s.addi       s17, s10, #480
    v.splat      v0, s10
    v.add        v1, v5, v0
    v.st.w       [s16, #0], v4
    s.addi       s16, s10, #576
    v.splat      v0, s13
    s.addi       s13, s7, #896
    s.addi       s21, s7, #960
    v.add        v4, v5, v0
    v.st.w       [s18, #0], v2
    s.addi       s7, s10, #672
    v.splat      v0, s9
    s.addi       s9, s12, #64
    v.add        v2, v5, v0
    v.st.w       [s13, #0], v6
    s.addi       s13, s10, #768
    v.splat      v0, s14
    s.addi       s14, s12, #128
    v.add        v6, v5, v0
    v.st.w       [s21, #0], v3
    v.splat      v0, s15
    s.addi       s15, s12, #192
    s.addi       s18, s12, #256
    v.add        v3, v5, v0
    fence.acq_rel.device
    v.st.w       [s12, #0], v1
    v.splat      v0, s17
    s.addi       s17, s10, #864
    v.add        v1, v5, v0
    v.st.w       [s9, #0], v4
    s.addi       s9, s10, #960
    v.splat      v0, s16
    s.addi       s16, s10, #1056
    v.add        v4, v5, v0
    v.st.w       [s14, #0], v2
    s.addi       s14, s10, #1152
    v.splat      v0, s7
    s.addi       s7, s10, #1248
    v.add        v2, v5, v0
    v.st.w       [s15, #0], v6
    s.addi       s15, s10, #1344
    v.splat      v0, s13
    s.addi       s13, s12, #320
    v.add        v6, v5, v0
    v.st.w       [s18, #0], v3
    s.addi       s18, s10, #1440
    v.splat      v0, s17
    s.addi       s10, s12, #384
    s.addi       s17, s12, #448
    v.add        v3, v5, v0
    v.st.w       [s13, #0], v1
    v.splat      v0, s9
    s.addi       s9, s12, #512
    s.addi       s13, s12, #576
    v.add        v1, v5, v0
    v.st.w       [s10, #0], v4
    v.splat      v0, s16
    s.addi       s10, s12, #640
    s.addi       s16, s12, #704
    v.add        v4, v5, v0
    v.st.w       [s17, #0], v2
    v.splat      v0, s14
    s.addi       s14, s12, #768
    v.add        v2, v5, v0
    s.addi       s17, s12, #832
    v.st.w       [s9, #0], v6
    v.splat      v0, s7
    s.addi       s7, s12, #896
    v.add        v6, v5, v0
    s.addi       s9, s12, #960
    v.st.w       [s13, #0], v3
    v.splat      v0, s15
    v.add        v3, v5, v0
    v.st.w       [s10, #0], v1
    v.splat      v0, s18
    v.add        v1, v5, v0
    v.st.w       [s16, #0], v4
    v.st.w       [s14, #0], v2
    v.st.w       [s17, #0], v6
    v.st.w       [s7, #0], v3
    v.st.w       [s9, #0], v1
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s7, s20, s19
    br.nz        s7, endfor_6
    s.addi       s7, s3, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s3, #64
    s.movz       s10, #1
    s.addi       s12, s3, #128
    s.movz       s13, #2
    s.addi       s14, s3, #192
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s9, v1
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #3
    s.addi       s9, s3, #256
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v1
    v.ld.w       v0, [s12, #0]
    s.movz       s10, #4
    s.addi       s12, s3, #320
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v1
    v.ld.w       v0, [s14, #0]
    s.movz       s13, #5
    s.addi       s14, s3, #384
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v1
    v.ld.w       v0, [s9, #0]
    s.movz       s7, #6
    s.addi       s9, s3, #448
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v1
    v.ld.w       v0, [s12, #0]
    s.movz       s10, #7
    s.addi       s12, s3, #512
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v1
    v.ld.w       v0, [s14, #0]
    s.movz       s13, #8
    s.addi       s14, s3, #576
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v1
    v.ld.w       v0, [s9, #0]
    s.movz       s7, #9
    s.addi       s9, s3, #640
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v1
    v.ld.w       v0, [s12, #0]
    s.movz       s10, #10
    s.addi       s12, s3, #704
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v1
    v.ld.w       v0, [s14, #0]
    s.movz       s13, #11
    s.addi       s14, s3, #768
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v1
    v.ld.w       v0, [s9, #0]
    s.movz       s7, #12
    s.addi       s9, s3, #832
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v1
    v.ld.w       v0, [s12, #0]
    s.movz       s10, #13
    s.addi       s12, s3, #896
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v1
    v.ld.w       v0, [s14, #0]
    s.movz       s13, #14
    s.addi       s14, s3, #960
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s7, v1
    v.ld.w       v0, [s9, #0]
    s.movz       s7, #15
    s.addi       s9, s3, #1024
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s10, v1
    v.ld.w       v0, [s12, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s10, #0
    s.addi       s12, s3, #1088
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v1
    v.ld.w       v0, [s14, #0]
    s.movz       s13, #1
    s.addi       s14, s3, #1152
    v.ld.gather.w v1, [s11, v0]                  // index is in elements (ISA sec 9.1)
    s.movz       s15, #2
    a.vwrite     a1, s7, v1
    v.ld.w       v0, [s9, #0]
    s.addi       s7, s3, #1216
    s.movz       s9, #3
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s10, v1
    v.ld.w       v0, [s12, #0]
    s.addi       s10, s3, #1280
    s.movz       s12, #4
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v1
    v.ld.w       v0, [s14, #0]
    s.addi       s13, s3, #1344
    s.movz       s14, #5
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v1
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s3, #1408
    s.movz       s15, #6
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s9, v1
    v.ld.w       v0, [s10, #0]
    s.addi       s9, s3, #1472
    s.movz       s10, #7
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v1
    v.ld.w       v0, [s13, #0]
    s.addi       s12, s3, #1536
    s.movz       s13, #8
    v.ld.gather.w v1, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v1
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s3, #1600
    s.movz       s14, #9
    v.movi       v1, #0
    v.ld.gather.w v2, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v2
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #1664
    s.movz       s15, #10
    v.ld.gather.w v2, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s10, v2
    v.ld.w       v0, [s12, #0]
    s.addi       s10, s3, #1728
    s.movz       s12, #11
    v.ld.gather.w v2, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v2
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s3, #1792
    s.movz       s13, #12
    v.ld.gather.w v2, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v2
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #1856
    s.movz       s14, #13
    v.ld.gather.w v2, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v2
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s3, #1920
    s.movz       s15, #14
    v.ld.gather.w v2, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v2
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s3, #1984
    s.movz       s12, #15
    v.ld.gather.w v2, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v2
    v.ld.w       v0, [s9, #0]
    s.movz       s9, #0
    s.movz       s13, #0
    v.ld.gather.w v2, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v2
    v.ld.w       v0, [s10, #0]
    s.movz       s10, #1
    s.movz       s14, #2
    v.ld.gather.w v2, [s6, v0]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v2
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #3
    s.movz       s15, #4
    v.ld.gather.w v2, [s6, v0]                   // index is in elements (ISA sec 9.1)
    s.movz       s16, #5
    a.vwrite     a2, s12, v2
    a.vread      v0, a1, s9
    a.vread      v2, a2, s13
    v.extract    s9, v0, #0
    v.splat      v3, s9
    v.extract    s9, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s9
    a.vread      v3, a2, s10
    v.extract    s9, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s9
    a.vread      v3, a2, s14
    v.extract    s9, v0, #3
    vf.fma       v4, v2, v3, v6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    v.extract    s7, v0, #4
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s15
    v.extract    s7, v0, #5
    vf.fma       v4, v2, v3, v6
    v.splat      v2, s7
    a.vread      v3, a2, s16
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s7, #0
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #1
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #1
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #2
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #2
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #3
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #4
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #5
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #6
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #7
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #8
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #9
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #9
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #10
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #10
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #11
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #11
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #12
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #12
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #13
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #13
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #14
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v2, s7
    a.vread      v3, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v6, v2, v3, v4
    v.splat      v2, s7
    a.vread      v3, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #3
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #4
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #4
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #5
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #6
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #6
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v2, v3, v6
    v.extract    s9, v0, #7
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #8
    vf.fma       v6, v2, v3, v4
    v.extract    s9, v0, #8
    v.splat      v2, s9
    a.vread      v3, a2, s7
    s.movz       s7, #14
    vf.fma       v4, v2, v3, v6
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #10
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #10
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #11
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #12
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #12
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #13
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #14
    vf.fma       v6, v2, v3, v4
    v.extract    s10, v0, #14
    v.splat      v2, s10
    a.vread      v3, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v2, v3, v6
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v2, a2, s9
    s.movz       s9, #15
    vf.fma       v3, v0, v2, v4
    s.movz       s10, #0
    s.movz       s12, #1
    s.movz       s13, #2
    a.vwrite     a3, s7, v3
    a.vread      v0, a1, s9
    a.vread      v2, a2, s10
    v.extract    s7, v0, #0
    v.splat      v3, s7
    v.extract    s7, v0, #1
    vf.fma       v4, v3, v2, v1
    v.splat      v1, s7
    a.vread      v2, a2, s12
    v.extract    s7, v0, #2
    vf.fma       v3, v1, v2, v4
    v.splat      v1, s7
    a.vread      v2, a2, s13
    s.movz       s7, #3
    vf.fma       v4, v1, v2, v3
    v.extract    s9, v0, #3
    v.splat      v1, s9
    a.vread      v2, a2, s7
    s.movz       s7, #4
    vf.fma       v3, v1, v2, v4
    v.extract    s9, v0, #4
    v.splat      v1, s9
    a.vread      v2, a2, s7
    s.movz       s7, #5
    vf.fma       v4, v1, v2, v3
    v.extract    s9, v0, #5
    v.splat      v1, s9
    a.vread      v2, a2, s7
    s.movz       s7, #6
    vf.fma       v3, v1, v2, v4
    v.extract    s9, v0, #6
    v.splat      v1, s9
    a.vread      v2, a2, s7
    s.movz       s7, #7
    vf.fma       v4, v1, v2, v3
    v.extract    s9, v0, #7
    v.splat      v1, s9
    a.vread      v2, a2, s7
    s.movz       s7, #8
    vf.fma       v3, v1, v2, v4
    v.extract    s9, v0, #8
    v.splat      v1, s9
    a.vread      v2, a2, s7
    s.movz       s7, #15
    vf.fma       v4, v1, v2, v3
    s.movz       s9, #9
    v.extract    s10, v0, #9
    v.splat      v1, s10
    a.vread      v2, a2, s9
    s.movz       s9, #10
    vf.fma       v3, v1, v2, v4
    v.extract    s10, v0, #10
    v.splat      v1, s10
    a.vread      v2, a2, s9
    s.movz       s9, #11
    vf.fma       v4, v1, v2, v3
    v.extract    s10, v0, #11
    v.splat      v1, s10
    a.vread      v2, a2, s9
    s.movz       s9, #12
    vf.fma       v3, v1, v2, v4
    v.extract    s10, v0, #12
    v.splat      v1, s10
    a.vread      v2, a2, s9
    s.movz       s9, #13
    vf.fma       v4, v1, v2, v3
    v.extract    s10, v0, #13
    v.splat      v1, s10
    a.vread      v2, a2, s9
    s.movz       s9, #14
    vf.fma       v3, v1, v2, v4
    v.extract    s10, v0, #14
    v.splat      v1, s10
    a.vread      v2, a2, s9
    s.movz       s9, #15
    vf.fma       v4, v1, v2, v3
    v.extract    s10, v0, #15
    v.splat      v0, s10
    a.vread      v1, a2, s9
    s.addi       s9, s3, #0
    vf.fma       v2, v0, v1, v4
    v.splat      v0, s1
    s.addi       s10, s3, #2048
    s.addi       s12, s3, #64
    a.vwrite     a3, s7, v2
    v.ld.w       v1, [s9, #0]
    s.addi       s7, s10, #64
    s.addi       s9, s3, #128
    s.addi       s13, s10, #128
    s.addi       s14, s3, #192
    s.addi       s15, s10, #192
    s.addi       s16, s3, #256
    v.add        v2, v1, v0
    v.st.w       [s10, #0], v2
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #256
    v.add        v2, v1, v0
    v.st.w       [s7, #0], v2
    s.addi       s7, s3, #320
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s10, #320
    v.add        v2, v1, v0
    v.st.w       [s13, #0], v2
    s.addi       s13, s3, #384
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #384
    v.add        v2, v1, v0
    v.st.w       [s15, #0], v2
    s.addi       s15, s3, #448
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #448
    v.add        v2, v1, v0
    v.st.w       [s12, #0], v2
    s.addi       s12, s3, #512
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #512
    v.add        v2, v1, v0
    v.st.w       [s9, #0], v2
    s.addi       s9, s3, #576
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #576
    v.add        v2, v1, v0
    v.st.w       [s14, #0], v2
    s.addi       s14, s3, #640
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s10, #640
    v.add        v2, v1, v0
    v.st.w       [s16, #0], v2
    s.addi       s16, s3, #704
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #704
    v.add        v2, v1, v0
    v.st.w       [s7, #0], v2
    s.addi       s7, s3, #768
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s10, #768
    v.add        v2, v1, v0
    v.st.w       [s13, #0], v2
    s.addi       s13, s3, #832
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #832
    v.add        v2, v1, v0
    v.st.w       [s15, #0], v2
    s.addi       s15, s3, #896
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #896
    s.addi       s17, s10, #960
    v.add        v2, v1, v0
    v.st.w       [s12, #0], v2
    s.addi       s10, s3, #960
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s3, #1024
    v.add        v2, v1, v0
    v.st.w       [s9, #0], v2
    s.movz       s9, #1536
    v.splat      v1, s9
    s.addi       s9, s3, #3072
    v.ld.w       v2, [s13, #0]
    s.addi       s12, s3, #1088
    v.add        v3, v2, v0
    v.st.w       [s14, #0], v3
    s.addi       s13, s9, #64
    v.ld.w       v2, [s15, #0]
    s.addi       s14, s3, #1152
    v.add        v3, v2, v0
    v.st.w       [s16, #0], v3
    s.addi       s15, s9, #128
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s3, #1216
    v.add        v3, v2, v0
    v.st.w       [s17, #0], v3
    fence.acq_rel.device
    s.addi       s16, s9, #192
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s3, #1280
    v.add        v2, v0, v1
    v.st.w       [s9, #0], v2
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s9, #256
    v.add        v2, v0, v1
    v.st.w       [s13, #0], v2
    s.addi       s13, s3, #1344
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #320
    v.add        v2, v0, v1
    v.st.w       [s15, #0], v2
    s.addi       s15, s3, #1408
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s9, #384
    v.add        v2, v0, v1
    v.st.w       [s16, #0], v2
    s.addi       s16, s3, #1472
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s9, #448
    v.add        v2, v0, v1
    v.st.w       [s12, #0], v2
    s.addi       s12, s3, #1536
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s9, #512
    v.add        v2, v0, v1
    v.st.w       [s14, #0], v2
    s.addi       s14, s3, #1600
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s9, #576
    v.add        v2, v0, v1
    v.st.w       [s10, #0], v2
    s.addi       s10, s3, #1664
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s9, #640
    v.add        v2, v0, v1
    v.st.w       [s7, #0], v2
    s.addi       s7, s3, #1728
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s9, #704
    v.add        v2, v0, v1
    v.st.w       [s13, #0], v2
    s.addi       s13, s3, #1792
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s9, #768
    v.add        v2, v0, v1
    v.st.w       [s15, #0], v2
    s.addi       s15, s3, #1856
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s9, #832
    v.add        v2, v0, v1
    v.st.w       [s16, #0], v2
    s.addi       s16, s3, #1920
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s9, #896
    s.addi       s17, s9, #960
    v.add        v2, v0, v1
    v.st.w       [s12, #0], v2
    s.addi       s9, s3, #1984
    v.ld.w       v0, [s13, #0]
    s.addi       s12, s3, #2048
    v.add        v2, v0, v1
    v.st.w       [s14, #0], v2
    s.addi       s13, s3, #4096
    v.ld.w       v0, [s15, #0]
    s.addi       s14, s3, #2112
    v.add        v2, v0, v1
    v.st.w       [s10, #0], v2
    s.addi       s10, s13, #64
    v.ld.w       v0, [s16, #0]
    s.addi       s15, s3, #2176
    v.add        v2, v0, v1
    v.st.w       [s7, #0], v2
    s.addi       s7, s13, #128
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #2240
    v.add        v2, v0, v1
    v.st.w       [s17, #0], v2
    fence.acq_rel.device
    s.addi       s16, s13, #192
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s3, #2304
    v.st.w       [s13, #0], v0
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s13, #256
    v.st.w       [s10, #0], v0
    s.addi       s10, s3, #2368
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s13, #320
    v.st.w       [s7, #0], v0
    s.addi       s7, s3, #2432
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s13, #384
    v.st.w       [s16, #0], v0
    s.addi       s16, s3, #2496
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s13, #448
    v.st.w       [s14, #0], v0
    s.addi       s14, s3, #2560
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s13, #512
    v.st.w       [s15, #0], v0
    s.addi       s15, s3, #2624
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s13, #576
    v.st.w       [s9, #0], v0
    s.addi       s9, s3, #2688
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s13, #640
    v.st.w       [s12, #0], v0
    s.addi       s12, s3, #2752
    v.ld.w       v0, [s14, #0]
    s.addi       s14, s13, #704
    v.st.w       [s10, #0], v0
    s.addi       s10, s3, #2816
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s13, #768
    v.st.w       [s7, #0], v0
    s.addi       s7, s3, #2880
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s13, #832
    v.st.w       [s16, #0], v0
    s.addi       s16, s3, #2944
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s13, #896
    s.addi       s17, s13, #960
    v.st.w       [s14, #0], v0
    s.addi       s13, s3, #3008
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s3, #3072
    v.st.w       [s15, #0], v0
    s.addi       s14, s3, #5120
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s3, #3136
    v.st.w       [s9, #0], v0
    s.addi       s9, s14, #64
    v.ld.w       v0, [s16, #0]
    s.addi       s15, s3, #3200
    v.st.w       [s12, #0], v0
    s.addi       s12, s14, #128
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s3, #3264
    v.st.w       [s17, #0], v0
    fence.acq_rel.device
    s.addi       s16, s14, #192
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s3, #3328
    v.st.w       [s14, #0], v0
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s14, #256
    v.st.w       [s9, #0], v0
    s.addi       s9, s3, #3392
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #320
    v.st.w       [s12, #0], v0
    s.addi       s12, s3, #3456
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s14, #384
    v.st.w       [s16, #0], v0
    s.addi       s16, s3, #3520
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s14, #448
    v.st.w       [s7, #0], v0
    s.addi       s7, s3, #3584
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s14, #512
    v.st.w       [s15, #0], v0
    s.addi       s15, s3, #3648
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #576
    v.st.w       [s13, #0], v0
    s.addi       s13, s3, #3712
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #640
    v.st.w       [s10, #0], v0
    s.addi       s10, s3, #3776
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s14, #704
    v.st.w       [s9, #0], v0
    s.addi       s9, s3, #3840
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #768
    v.st.w       [s12, #0], v0
    s.addi       s12, s3, #3904
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s14, #832
    v.st.w       [s16, #0], v0
    s.addi       s16, s3, #3968
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s14, #896
    s.addi       s17, s14, #960
    v.st.w       [s7, #0], v0
    s.addi       s7, s3, #4032
    v.ld.w       v0, [s9, #0]
    s.movz       s9, #0
    v.st.w       [s15, #0], v0
    s.movz       s14, #0
    v.ld.w       v0, [s12, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s12, #0
    v.st.w       [s13, #0], v0
    s.movz       s13, #1
    v.ld.w       v0, [s16, #0]
    s.movz       s15, #1
    v.st.w       [s10, #0], v0
    s.movz       s10, #1
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #2
    v.st.w       [s17, #0], v0
    fence.acq_rel.device
    a.vread      v0, a0, s9
    a.vread      v1, a3, s14
    s.movz       s9, #2
    vf.add       v2, v0, v1
    s.movz       s14, #2
    s.movz       s16, #3
    a.vwrite     a4, s12, v2
    a.vread      v0, a0, s13
    a.vread      v1, a3, s15
    s.movz       s12, #3
    vf.add       v2, v0, v1
    s.movz       s13, #3
    s.movz       s15, #4
    a.vwrite     a4, s10, v2
    a.vread      v0, a0, s7
    a.vread      v1, a3, s9
    s.movz       s7, #4
    vf.add       v2, v0, v1
    s.movz       s9, #4
    s.movz       s10, #5
    a.vwrite     a4, s14, v2
    a.vread      v0, a0, s16
    a.vread      v1, a3, s12
    s.movz       s12, #5
    vf.add       v2, v0, v1
    s.movz       s14, #5
    s.movz       s16, #6
    a.vwrite     a4, s13, v2
    a.vread      v0, a0, s15
    a.vread      v1, a3, s7
    s.movz       s7, #6
    vf.add       v2, v0, v1
    s.movz       s13, #6
    s.movz       s15, #7
    a.vwrite     a4, s9, v2
    a.vread      v0, a0, s10
    a.vread      v1, a3, s12
    s.movz       s9, #7
    vf.add       v2, v0, v1
    s.movz       s10, #7
    s.movz       s12, #8
    a.vwrite     a4, s14, v2
    a.vread      v0, a0, s16
    a.vread      v1, a3, s7
    s.movz       s7, #8
    vf.add       v2, v0, v1
    s.movz       s14, #8
    s.movz       s16, #9
    a.vwrite     a4, s13, v2
    a.vread      v0, a0, s15
    a.vread      v1, a3, s9
    s.movz       s9, #9
    vf.add       v2, v0, v1
    s.movz       s13, #9
    s.movz       s15, #10
    a.vwrite     a4, s10, v2
    a.vread      v0, a0, s12
    a.vread      v1, a3, s7
    s.movz       s7, #10
    vf.add       v2, v0, v1
    s.movz       s10, #10
    s.movz       s12, #11
    a.vwrite     a4, s14, v2
    a.vread      v0, a0, s16
    a.vread      v1, a3, s9
    s.movz       s9, #11
    vf.add       v2, v0, v1
    s.movz       s14, #11
    s.movz       s16, #12
    a.vwrite     a4, s13, v2
    a.vread      v0, a0, s15
    a.vread      v1, a3, s7
    s.movz       s7, #12
    vf.add       v2, v0, v1
    s.movz       s13, #12
    s.movz       s15, #13
    a.vwrite     a4, s10, v2
    a.vread      v0, a0, s12
    a.vread      v1, a3, s9
    s.movz       s9, #13
    vf.add       v2, v0, v1
    s.movz       s10, #13
    s.movz       s12, #14
    a.vwrite     a4, s14, v2
    a.vread      v0, a0, s16
    a.vread      v1, a3, s7
    s.movz       s7, #14
    vf.add       v2, v0, v1
    s.movz       s14, #14
    s.movz       s16, #15
    a.vwrite     a4, s13, v2
    a.vread      v0, a0, s15
    a.vread      v1, a3, s9
    s.movz       s9, #15
    vf.add       v2, v0, v1
    s.movz       s13, #15
    s.addi       s15, s3, #4096
    a.vwrite     a4, s10, v2
    a.vread      v0, a0, s12
    a.vread      v1, a3, s7
    s.addi       s7, s3, #0
    vf.add       v2, v0, v1
    s.addi       s10, s3, #4160
    s.addi       s12, s3, #64
    a.vwrite     a4, s14, v2
    a.vread      v0, a0, s16
    a.vread      v1, a3, s9
    s.addi       s9, s3, #4224
    vf.add       v2, v0, v1
    s.addi       s14, s3, #128
    s.addi       s16, s3, #4288
    a.vwrite     a4, s13, v2
    v.ld.w       v0, [s15, #0]
    s.addi       s13, s3, #192
    s.addi       s15, s3, #4352
    v.st.w       [s7, #0], v0
    s.addi       s7, s3, #256
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s3, #4416
    v.st.w       [s12, #0], v0
    s.addi       s12, s3, #320
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #4480
    v.st.w       [s14, #0], v0
    s.addi       s14, s3, #384
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s3, #4544
    v.st.w       [s13, #0], v0
    s.addi       s13, s3, #448
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s3, #4608
    v.st.w       [s7, #0], v0
    s.addi       s7, s3, #512
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s3, #4672
    v.st.w       [s12, #0], v0
    s.addi       s12, s3, #576
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #4736
    v.st.w       [s14, #0], v0
    s.addi       s14, s3, #640
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s3, #4800
    v.st.w       [s13, #0], v0
    s.addi       s13, s3, #704
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s3, #4864
    v.st.w       [s7, #0], v0
    s.addi       s7, s3, #768
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s3, #4928
    v.st.w       [s12, #0], v0
    s.addi       s12, s3, #832
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #4992
    v.st.w       [s14, #0], v0
    s.addi       s14, s3, #896
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s3, #5056
    v.st.w       [s13, #0], v0
    s.addi       s13, s3, #960
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s3, #5120
    v.st.w       [s7, #0], v0
    s.addi       s7, s3, #1024
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s3, #5184
    v.st.w       [s12, #0], v0
    s.addi       s12, s3, #1088
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #5248
    v.st.w       [s14, #0], v0
    s.addi       s14, s3, #1152
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s3, #5312
    v.st.w       [s13, #0], v0
    fence.acq_rel.device
    s.addi       s13, s3, #1216
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s3, #5376
    v.st.w       [s7, #0], v0
    s.addi       s7, s3, #1280
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s3, #5440
    v.st.w       [s12, #0], v0
    s.addi       s12, s3, #1344
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #5504
    v.st.w       [s14, #0], v0
    s.addi       s14, s3, #1408
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s3, #5568
    v.st.w       [s13, #0], v0
    s.addi       s13, s3, #1472
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s3, #5632
    v.st.w       [s7, #0], v0
    s.addi       s7, s3, #1536
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s3, #5696
    v.st.w       [s12, #0], v0
    s.addi       s12, s3, #1600
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #5760
    v.st.w       [s14, #0], v0
    s.addi       s14, s3, #1664
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s3, #5824
    v.st.w       [s13, #0], v0
    s.addi       s13, s3, #1728
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s3, #5888
    v.st.w       [s7, #0], v0
    s.addi       s7, s3, #1792
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s3, #5952
    v.st.w       [s12, #0], v0
    s.addi       s12, s3, #1856
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #6016
    v.st.w       [s14, #0], v0
    s.addi       s14, s3, #1920
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s3, #6080
    s.addi       s17, s3, #1984
    v.st.w       [s13, #0], v0
    s.movz       s13, #0
    v.ld.w       v0, [s15, #0]
    s.movz       s15, #0
    v.st.w       [s7, #0], v0
    s.movz       s7, #1
    v.ld.w       v0, [s10, #0]
    s.movz       s10, #1
    v.st.w       [s12, #0], v0
    s.movz       s12, #2
    v.ld.w       v0, [s9, #0]
    s.movz       s9, #2
    v.st.w       [s14, #0], v0
    s.movz       s14, #3
    v.ld.w       v0, [s16, #0]
    s.movz       s16, #3
    v.st.w       [s17, #0], v0
    fence.acq_rel.device
    a.vread      v0, a4, s13
    s.movz       s13, #4
    a.vwrite     a0, s15, v0
    a.vread      v0, a4, s7
    s.movz       s7, #4
    a.vwrite     a0, s10, v0
    a.vread      v0, a4, s12
    s.movz       s10, #5
    a.vwrite     a0, s9, v0
    a.vread      v0, a4, s14
    s.movz       s9, #5
    a.vwrite     a0, s16, v0
    a.vread      v0, a4, s13
    s.movz       s12, #6
    a.vwrite     a0, s7, v0
    a.vread      v0, a4, s10
    s.movz       s7, #6
    a.vwrite     a0, s9, v0
    a.vread      v0, a4, s12
    s.movz       s9, #7
    a.vwrite     a0, s7, v0
    s.movz       s7, #7
    a.vread      v0, a4, s9
    s.movz       s9, #8
    a.vwrite     a0, s7, v0
    s.movz       s7, #8
    a.vread      v0, a4, s9
    s.movz       s9, #9
    a.vwrite     a0, s7, v0
    s.movz       s7, #9
    a.vread      v0, a4, s9
    s.movz       s9, #10
    a.vwrite     a0, s7, v0
    s.movz       s7, #10
    a.vread      v0, a4, s9
    s.movz       s9, #11
    a.vwrite     a0, s7, v0
    s.movz       s7, #11
    a.vread      v0, a4, s9
    s.movz       s9, #12
    a.vwrite     a0, s7, v0
    s.movz       s7, #12
    a.vread      v0, a4, s9
    s.movz       s9, #13
    a.vwrite     a0, s7, v0
    s.movz       s7, #13
    a.vread      v0, a4, s9
    s.movz       s9, #14
    a.vwrite     a0, s7, v0
    s.movz       s7, #14
    a.vread      v0, a4, s9
    s.movz       s9, #15
    a.vwrite     a0, s7, v0
    s.movz       s7, #15
    a.vread      v0, a4, s9
    s.add        s9, s20, s1
    s.movz       s10, #1
    a.vwrite     a0, s7, v0
    s.mov        s20, s9
    br.nz        s10, for_5
endfor_6:
    s.movz       s1, #9216
    s.movz       s3, #0
    s.mul        s6, s2, s1
    s.muli       s1, s5, #4                      // a runtime tile origin, x4
    s.movz       s7, #0
    s.add        s9, s3, s5                      // the tile origin
    s.muli       s3, s4, #384                    // a runtime tile origin, x384
    s.add        s5, s7, s4                      // the tile origin
    s.movz       s4, #96
    v.splat      v0, s9
    s.movz       s7, #4
    s.muli       s9, s6, #4                      // a runtime tile origin, x4
    v.splat      v1, s5
    v.splat      v2, s4
    v.add        v3, v5, v0
    v.splat      v0, s4
    s.addi       s4, s5, #1
    s.add        s6, s8, s1                      // the tile origin
    v.splat      v4, s2
    v.splat      v5, s7
    v.cmp.lt     p1, v1, v2
    v.cmp.lt     p2, v3, v0
    v.splat      v0, s4
    s.addi       s1, s5, #2
    s.add        s2, s6, s3                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    p.and        p3, p1, p2
    v.cmp.lt     p1, v4, v5
    v.cmp.lt     p4, v0, v2
    v.splat      v0, s1
    s.addi       s1, s5, #3
    s.add        s4, s2, s9                      // the tile origin
    a.vread      v1, a0, s3
    p.and        p5, p3, p1
    s.movz       s2, #1
    p.and        p3, p4, p2
    v.splat      v3, s1
    s.addi       s1, s5, #4
    @p5 v.st.w       [s4, #0], v1
    v.cmp.lt     p4, v0, v2
    a.vread      v0, a0, s2
    s.addi       s2, s4, #384                    // row 1
    p.and        p5, p3, p1
    s.movz       s3, #2
    p.and        p3, p4, p2
    v.splat      v1, s1
    s.addi       s1, s5, #5
    s.addi       s6, s4, #768                    // row 2
    @p5 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v3, v2
    a.vread      v0, a0, s3
    p.and        p5, p3, p1
    s.movz       s2, #3
    p.and        p3, p4, p2
    v.splat      v3, s1
    s.addi       s1, s5, #6
    s.addi       s3, s4, #1152                   // row 3
    p.and        p4, p3, p1
    @p5 v.st.w       [s6, #0], v0
    v.cmp.lt     p3, v1, v2
    a.vread      v0, a0, s2
    s.movz       s2, #4
    p.and        p5, p3, p2
    v.splat      v1, s1
    s.addi       s1, s5, #7
    s.addi       s6, s4, #1536                   // row 4
    p.and        p3, p5, p1
    s.movz       s7, #5
    @p4 v.st.w       [s3, #0], v0
    v.cmp.lt     p4, v3, v2
    a.vread      v0, a0, s2
    p.and        p5, p4, p2
    v.splat      v3, s1
    s.addi       s1, s5, #8
    s.addi       s2, s4, #1920                   // row 5
    p.and        p4, p5, p1
    s.movz       s3, #6
    v.splat      v4, s1
    @p3 v.st.w       [s6, #0], v0
    v.cmp.lt     p3, v1, v2
    a.vread      v0, a0, s7
    p.and        p5, p3, p2
    s.addi       s1, s5, #9
    s.addi       s6, s4, #2304                   // row 6
    p.and        p3, p5, p1
    s.movz       s7, #7
    v.splat      v1, s1
    s.addi       s1, s5, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v3, v2
    a.vread      v0, a0, s3
    p.and        p5, p4, p2
    s.addi       s2, s4, #2688                   // row 7
    p.and        p4, p5, p1
    s.movz       s3, #8
    v.splat      v3, s1
    s.addi       s1, s5, #11
    s.addi       s8, s4, #3072                   // row 8
    @p3 v.st.w       [s6, #0], v0
    v.cmp.lt     p3, v4, v2
    a.vread      v0, a0, s7
    p.and        p5, p3, p2
    s.movz       s6, #9
    p.and        p3, p5, p1
    v.splat      v4, s1
    s.addi       s1, s5, #12
    s.addi       s7, s4, #3456                   // row 9
    s.movz       s9, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v1, v2
    a.vread      v0, a0, s3
    p.and        p5, p4, p2
    v.splat      v1, s1
    p.and        p4, p5, p1
    s.addi       s1, s5, #13
    s.addi       s2, s4, #3840                   // row 10
    s.movz       s3, #11
    v.splat      v5, s1
    @p3 v.st.w       [s8, #0], v0
    v.cmp.lt     p3, v3, v2
    a.vread      v0, a0, s6
    p.and        p5, p3, p2
    s.addi       s1, s5, #14
    p.and        p3, p5, p1
    s.addi       s6, s4, #4224                   // row 11
    s.movz       s8, #12
    v.splat      v3, s1
    s.addi       s1, s4, #4608                   // row 12
    @p4 v.st.w       [s7, #0], v0
    v.cmp.lt     p4, v4, v2
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    s.addi       s7, s5, #15
    p.and        p4, p5, p1
    s.movz       s5, #13
    v.splat      v4, s7
    s.addi       s7, s4, #4992                   // row 13
    s.movz       s9, #14
    @p3 v.st.w       [s2, #0], v0
    v.cmp.lt     p3, v1, v2
    a.vread      v0, a0, s3
    p.and        p5, p3, p2
    s.addi       s2, s4, #5376                   // row 14
    p.and        p3, p5, p1
    s.movz       s3, #15
    s.addi       s10, s4, #5760                  // row 15
    @p4 v.st.w       [s6, #0], v0
    v.cmp.lt     p4, v5, v2
    a.vread      v0, a0, s8
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p3, v3, v2
    a.vread      v0, a0, s5
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s7, #0], v0
    v.cmp.lt     p4, v4, v2
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    p.and        p2, p5, p1
    @p3 v.st.w       [s2, #0], v0
    a.vread      v0, a0, s3
    @p2 v.st.w       [s10, #0], v0
__rctx_next:
    exit
