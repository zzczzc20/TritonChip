source /tools/Xilinx/Vivado/2023.2/settings64.sh >/dev/null 2>&1
cd /home/zzhouch/tnca_build/r40_hit_owner_module_20261017
timeout 5400 nice -n 19 vivado -mode batch -source /home/zzhouch/tnca_build/r40_hit_owner_module_20261017/source/flow/fpga/screen_local_tmu_rank.tcl -tclargs /home/zzhouch/tnca_build/r40_hit_owner_module_20261017/source /home/zzhouch/tnca_build/r40_hit_owner_module_20261017/reports > stdout.log 2>&1
echo $? > runner.exit
