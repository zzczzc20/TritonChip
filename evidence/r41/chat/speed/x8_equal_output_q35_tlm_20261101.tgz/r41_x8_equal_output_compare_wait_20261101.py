import os,select,subprocess,sys
from pathlib import Path
pids=[int(x) for x in sys.argv[1:]]
fds=[os.pidfd_open(pid) for pid in pids]
for fd in fds:
    select.select([fd],[],[])
    os.close(fd)
home=Path.home(); run=home/'flux-venv/bin/python'
subprocess.run([str(run),str(home/'r41_x8_equal_output_compare_20261101.py'),'--model','q35','--tree',str(home/'r41_current_x8_equal_output_20261101'),'--out',str(home/'r41_x8_equal_output_q35_compare_20261101.json')],check=True)
