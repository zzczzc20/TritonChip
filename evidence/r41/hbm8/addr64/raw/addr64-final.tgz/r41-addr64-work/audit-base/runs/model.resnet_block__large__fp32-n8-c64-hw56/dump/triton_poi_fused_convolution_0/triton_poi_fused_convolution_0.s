    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.rdspecial  s1, pid.y
    s.shli       s5, s1, #4                      // x16 as a shift
    s.shli       s1, s4, #4                      // x16 as a shift
    s.muli       s4, s1, #4                      // a runtime tile origin, x4
    s.add        s6, s2, s4                      // the tile origin
    s.muli       s2, s5, #12544                  // a runtime tile origin, x12544
    s.add        s4, s6, s2                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.rdspecial  s2, arg_base
    s.ld.d       s6, [s2, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, role_id
    s.movz       s7, #1024
    s.mul        s8, s2, s7
    s.add        s2, s6, s8                      // this context's own scratch
    s.addi       s6, s2, #0
    s.movz       s7, #0
    v.splat      v0, s7
    s.add        s8, s7, s5                      // the tile origin
    v.splat      v1, s8
    s.movz       s5, #64
    v.splat      v2, s5
    v.movi       v3, #0
    v.cmp.lt     p1, v1, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v1
    @p1 v.sel        v5, v4, v1
    v.sub        v1, v3, v2
    @p2 v.sel        v4, v1, v2
    v.movi       v1, #63
    v.and        v4, v5, v1
    v.sub        v1, v3, v4
    @p1 v.sel        v3, v1, v4
    s.muli       s9, s1, #64                     // a runtime tile origin, x64
    s.add        s10, s7, s9                     // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v4, s5
    v.mul        v5, v1, v4
    v.splat      v1, s10
    v.add        v4, v5, v1
    v.add        v1, v3, v4
    v.splat      v3, s8
    v.movi       v5, #0
    v.cmp.lt     p1, v3, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v3
    @p1 v.sel        v7, v6, v3
    v.sub        v3, v5, v2
    @p2 v.sel        v6, v3, v2
    v.movi       v3, #6
    v.lshr       v6, v7, v3
    v.sub        v3, v5, v6
    @p1 v.sel        v5, v3, v6
    .li       s5, #200704
    v.splat      v3, s5
    v.mul        v6, v5, v3
    v.add        v5, v1, v6
    v.add        v1, v0, v5
    v.st.w       [s6, #0], v1
    s.addi       s5, s6, #64
    s.addi       s7, s8, #1
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #1
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #128
    s.addi       s7, s8, #2
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #2
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #192
    s.addi       s7, s8, #3
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #3
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #256
    s.addi       s7, s8, #4
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #4
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #320
    s.addi       s7, s8, #5
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #5
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #384
    s.addi       s7, s8, #6
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #6
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #448
    s.addi       s7, s8, #7
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #7
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #512
    s.addi       s7, s8, #8
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #8
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #576
    s.addi       s7, s8, #9
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #9
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #640
    s.addi       s7, s8, #10
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #10
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #704
    s.addi       s7, s8, #11
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #11
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #768
    s.addi       s7, s8, #12
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #12
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #832
    s.addi       s7, s8, #13
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #13
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #896
    s.addi       s7, s8, #14
    v.splat      v1, s7
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s7, s8, #14
    v.splat      v5, s7
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v2, v6
    v.sub        v7, v6, v5
    @p1 v.sel        v8, v7, v5
    v.sub        v5, v6, v2
    @p2 v.sel        v7, v5, v2
    v.movi       v5, #6
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p1 v.sel        v6, v5, v7
    v.mul        v5, v6, v3
    v.add        v6, v1, v5
    v.add        v1, v0, v6
    v.st.w       [s5, #0], v1
    s.addi       s5, s6, #960
    s.addi       s6, s8, #15
    v.splat      v1, s6
    v.movi       v5, #0
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v1
    @p1 v.sel        v7, v6, v1
    v.sub        v1, v5, v2
    @p2 v.sel        v6, v1, v2
    v.movi       v1, #63
    v.and        v6, v7, v1
    v.sub        v1, v5, v6
    @p1 v.sel        v5, v1, v6
    v.add        v1, v5, v4
    s.addi       s6, s8, #15
    v.splat      v4, s6
    v.movi       v5, #0
    v.cmp.lt     p1, v4, v5
    v.cmp.lt     p2, v2, v5
    v.sub        v6, v5, v4
    @p1 v.sel        v7, v6, v4
    v.sub        v4, v5, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v2, #6
    v.lshr       v4, v7, v2
    v.sub        v2, v5, v4
    @p1 v.sel        v5, v2, v4
    v.mul        v2, v5, v3
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s5, #0], v1
    fence.acq_rel.device
    s.movz       s5, #0
    s.add        s6, s5, s1                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    v.add        v2, v0, v1
    v.cmpi.lt    p1, v2, #3136
    v.splat      v0, s8
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s4, #0]
    s.addi       s1, s2, #0
    v.ld.w       v1, [s1, #0]
    v.splat      v2, s8
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    s.addi       s1, s4, #12544                  // row 1
    s.addi       s5, s8, #1
    v.splat      v0, s5
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s1, #0]
    s.addi       s1, s2, #64
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #1
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    s.addi       s1, s4, #25088                  // row 2
    s.addi       s5, s8, #2
    v.splat      v0, s5
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s1, #0]
    s.addi       s1, s2, #128
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #2
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    s.movz       s1, #37632
    s.add        s5, s4, s1                      // row 3
    s.addi       s1, s8, #3
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #192
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #3
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    s.movz       s1, #50176
    s.add        s5, s4, s1                      // row 4
    s.addi       s1, s8, #4
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #256
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #4
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    s.movz       s1, #62720
    s.add        s5, s4, s1                      // row 5
    s.addi       s1, s8, #5
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #320
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #5
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    .li       s1, #75264
    s.add        s5, s4, s1                      // row 6
    s.addi       s1, s8, #6
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #384
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #6
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    .li       s1, #87808
    s.add        s5, s4, s1                      // row 7
    s.addi       s1, s8, #7
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #448
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #7
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    .li       s1, #100352
    s.add        s5, s4, s1                      // row 8
    s.addi       s1, s8, #8
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #512
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #8
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    .li       s1, #112896
    s.add        s5, s4, s1                      // row 9
    s.addi       s1, s8, #9
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #576
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #9
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    .li       s1, #125440
    s.add        s5, s4, s1                      // row 10
    s.addi       s1, s8, #10
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #640
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #10
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    .li       s1, #137984
    s.add        s5, s4, s1                      // row 11
    s.addi       s1, s8, #11
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #704
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #11
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    .li       s1, #150528
    s.add        s5, s4, s1                      // row 12
    s.addi       s1, s8, #12
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #768
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #12
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    .li       s1, #163072
    s.add        s5, s4, s1                      // row 13
    s.addi       s1, s8, #13
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #832
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #13
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    .li       s1, #175616
    s.add        s5, s4, s1                      // row 14
    s.addi       s1, s8, #14
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #896
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #14
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
    .li       s1, #188160
    s.add        s5, s4, s1                      // row 15
    s.addi       s1, s8, #15
    v.splat      v0, s1
    v.cmpi.lt    p2, v0, #512
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s5, #0]
    s.addi       s1, s2, #960
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #15
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #512
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s3, v1], v0
__rctx_next:
    exit
