    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s2, arg_base
    v.add        v3, v1, v0
    v.movi       v0, #6
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.movi       v4, #512
    @p1 v.sel        v5, v1, v3
    v.movi       v1, #0
    v.cmp.lt     p2, v3, v4
    v.lshr       v6, v5, v0
    v.sub        v0, v1, v3
    v.cmp.lt     p3, v3, v1
    v.sub        v5, v2, v6
    @p3 v.sel        v7, v0, v3
    v.movi       v0, #63
    @p1 v.sel        v8, v5, v6
    s.ld.d       s4, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.and        v5, v7, v0
    v.movi       v0, #0
    v.mul        v6, v8, v4
    v.sub        v4, v1, v5
    v.sub        v7, v0, v3
    v.cmp.lt     p1, v3, v0
    @p3 v.sel        v9, v4, v5
    @p1 v.sel        v4, v7, v3
    v.movi       v3, #64
    v.add        v5, v9, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v6, [s3, v8]               // index is in elements (ISA sec 9.1)
    v.movi       v7, #32
    v.sub        v10, v1, v3
    v.sub        v11, v2, v3
    v.sub        v12, v0, v7
    v.cmp.lt     p3, v3, v1
    v.cmp.lt     p4, v3, v2
    @p3 v.sel        v1, v10, v3
    v.cmp.lt     p3, v7, v0
    @p4 v.sel        v1, v11, v3
    s.ld.d       s3, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    @p3 v.sel        v1, v12, v7
    s.ld.d       s5, [s2, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s6, [s2, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.movi       v1, #31
    v.and        v2, v4, v1
    s.ld.d       s7, [s2, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    v.sub        v1, v0, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v0, [s4, v5]               // index is in elements (ISA sec 9.1)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v3, [s3, v9]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v4, v0
    vf.cvt.bf16.f32 v0, v3
    s.ld.d       s3, [s2, #48]                   // out_ptr0: device_ptr64 at arg_base+48
    .li       s2, #1132462080
    v.splat      v3, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #897988541
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v10, v3                         // ISA 8.8: <= 2**-22 relative
    .li       s2, #1077936128
    v.splat      v11, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v12, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    @p1 v.sel        v13, v1, v2
    s.add        s1, s5, s2                      // &in_ptr4[...]
    .li       s2, #1065353216
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s1, #0]
    v.movi       v14, #256
    vf.add       v15, v0, v1
    v.mul        v0, v8, v14
    v.add        v1, v9, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v0, [s6, v13]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v8, v2
    vf.fms       v2, v3, v10, v5
    vf.fms       v3, v10, v2, v10
    vf.neg       v2, v3                          // Newton step: r0*(2 - x*r0)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v3, [s7, v13]              // index is in elements (ISA sec 9.1)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v5, v2, v10
    vf.mul       v2, v6, v5                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v5, v2, v7
    v.rsqrt.approx v2, v5                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v6, v8, v3
    vf.mul       v3, v2, v2
    vf.mul       v7, v2, v12
    vf.fms       v8, v5, v3, v11
    vf.mul       v3, v7, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v5, v3, v2
    vf.mul       v2, v4, v5
    vf.mul       v3, v2, v15
    vf.mul       v2, v3, v0
    vf.add       v0, v2, v6
    vf.cvt.f32.bf16 v2, v0
    @p2 v.st.scatter.h [s3, v1], v2
__rctx_next:
    exit
