    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    v.movi       v2, #1024
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.splat      v3, s2
    s.movz       s4, #0
    v.add        v4, v3, v0
    s.addi       s5, s3, #4
    v.cmp.lt     p1, v4, v1
    v.cmp.lt     p2, v4, v2
    s.movz       s6, #0
    s.ld.d       s7, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v0, v1, v4
    s.movz       s8, #0
    s.ld.d       s9, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    @p1 v.sel        v2, v0, v4
    v.movi       v0, #6
    s.movz       s1, #0
    v.lshr       v3, v2, v0
    s.movz       s10, #0
    v.sub        v0, v1, v3
    s.movz       s11, #0
    @p1 v.sel        v2, v0, v3
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #0
    s.movz       s18, #0
    s.movz       s19, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.movz       s22, #256
    v.movi       v0, #1
    s.movz       s23, #256
    v.shl        v3, v2, v0
    s.movz       s24, #256
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v0, [s3, v3]               // index is in elements (ISA sec 9.1)
    s.movz       s3, #256
    s.movz       s25, #256
    v.movi       v2, #0
    s.movz       s26, #256
    s.movz       s27, #256
    s.movz       s28, #256
    s.movz       s29, #256
    s.movz       s30, #256
    s.movz       s31, #256
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s5, v3]               // index is in elements (ISA sec 9.1)
    v.extract    s5, v0, #0
    s.movz       s32, #256
    v.extract    s33, v0, #1
    s.movz       s34, #256
    s.movz       s35, #256
    s.movz       s36, #256
    s.movz       s37, #256
    v.movi       v3, #0
    v.movi       v6, #63
    v.extract    s38, v5, #0
    s.shli       s39, s38, #32
    v.extract    s38, v5, #1
    s.or         s40, s5, s39
    s.shli       s5, s38, #32
    s.cmp.ge     s38, s40, s4
    s.or         s4, s33, s5
    v.insert     v2, s38, #0
    s.cmp.ge     s5, s4, s6
    v.sub        v7, v3, v4
    v.cmp.lt     p1, v4, v3
    @p1 v.sel        v8, v7, v4
    s.movz       s4, #0
    v.extract    s6, v5, #2
    s.shli       s33, s6, #32
    v.extract    s6, v0, #2
    s.or         s38, s6, s33
    v.insert     v2, s5, #1
    s.cmp.ge     s5, s38, s8
    v.movi       v4, #64
    v.extract    s6, v5, #3
    v.extract    s8, v0, #3
    v.insert     v2, s5, #2
    v.and        v7, v8, v6
    v.sub        v6, v1, v4
    v.sub        v8, v3, v4
    v.cmp.lt     p3, v4, v1
    v.sub        v1, v3, v7
    v.cmp.lt     p4, v4, v3
    v.movi       v3, #1
    s.shli       s5, s6, #32
    v.extract    s6, v5, #4
    s.or         s33, s8, s5
    v.extract    s5, v0, #4
    s.cmp.ge     s8, s33, s1
    @p3 v.sel        v3, v6, v4
    s.shli       s1, s6, #32
    v.extract    s6, v5, #5
    s.or         s33, s5, s1
    v.extract    s1, v0, #5
    v.insert     v2, s8, #3
    s.cmp.ge     s5, s33, s10
    v.movi       v3, #1
    s.shli       s8, s6, #32
    v.extract    s6, v5, #6
    s.or         s10, s1, s8
    v.extract    s1, v0, #6
    v.insert     v2, s5, #4
    s.cmp.ge     s5, s10, s11
    @p4 v.sel        v3, v8, v4
    s.shli       s8, s6, #32
    v.insert     v2, s5, #5
    s.or         s5, s1, s8
    @p1 v.sel        v3, v1, v7
    v.extract    s1, v5, #7
    s.shli       s6, s1, #32
    v.extract    s1, v0, #7
    v.extract    s8, v5, #8
    s.cmp.ge     s10, s5, s12
    s.or         s5, s1, s6
    s.shli       s1, s8, #32
    v.extract    s6, v0, #8
    v.extract    s8, v5, #9
    v.insert     v2, s10, #6
    s.cmp.ge     s10, s5, s13
    s.or         s5, s6, s1
    s.shli       s1, s8, #32
    v.extract    s6, v0, #9
    v.extract    s8, v5, #10
    v.insert     v2, s10, #7
    s.cmp.ge     s10, s5, s14
    s.or         s5, s6, s1
    s.shli       s1, s8, #32
    v.extract    s6, v0, #10
    v.extract    s8, v5, #11
    v.insert     v2, s10, #8
    s.cmp.ge     s10, s5, s15
    s.or         s5, s6, s1
    s.shli       s1, s8, #32
    v.extract    s6, v0, #11
    v.extract    s8, v5, #12
    v.insert     v2, s10, #9
    s.cmp.ge     s10, s5, s16
    s.or         s5, s6, s1
    s.shli       s1, s8, #32
    v.extract    s6, v0, #12
    v.extract    s8, v5, #13
    v.insert     v2, s10, #10
    s.cmp.ge     s10, s5, s17
    s.or         s5, s6, s1
    s.shli       s1, s8, #32
    v.extract    s6, v0, #13
    v.extract    s8, v5, #14
    v.insert     v2, s10, #11
    s.cmp.ge     s10, s5, s18
    s.or         s5, s6, s1
    s.shli       s1, s8, #32
    v.extract    s6, v0, #14
    v.extract    s8, v5, #15
    v.extract    s11, v5, #0
    v.insert     v2, s10, #12
    s.cmp.ge     s10, s5, s19
    s.or         s5, s6, s1
    s.shli       s1, s8, #32
    s.shli       s6, s11, #32
    v.extract    s8, v0, #15
    v.extract    s11, v0, #0
    v.extract    s12, v5, #1
    v.insert     v2, s10, #13
    s.cmp.ge     s10, s5, s20
    s.or         s5, s8, s1
    s.or         s1, s11, s6
    s.shli       s6, s12, #32
    v.extract    s8, v0, #1
    v.extract    s11, v5, #2
    v.insert     v2, s10, #14
    s.cmp.ge     s10, s5, s21
    v.movi       v1, #0
    s.cmp.lt     s5, s1, s22
    s.or         s1, s8, s6
    s.shli       s6, s11, #32
    v.extract    s8, v0, #2
    v.extract    s11, v5, #3
    v.insert     v2, s10, #15
    v.insert     v1, s5, #0
    s.cmp.lt     s5, s1, s23
    s.or         s1, s8, s6
    s.shli       s6, s11, #32
    v.extract    s8, v0, #3
    v.extract    s10, v5, #4
    v.insert     v1, s5, #1
    s.cmp.lt     s5, s1, s24
    s.or         s1, s8, s6
    s.shli       s6, s10, #32
    v.extract    s8, v0, #4
    v.extract    s10, v5, #5
    v.insert     v1, s5, #2
    s.cmp.lt     s5, s1, s3
    s.or         s1, s8, s6
    s.shli       s3, s10, #32
    v.extract    s6, v0, #5
    v.extract    s8, v5, #6
    v.insert     v1, s5, #3
    s.cmp.lt     s5, s1, s25
    s.or         s1, s6, s3
    s.shli       s3, s8, #32
    v.extract    s6, v0, #6
    v.extract    s8, v5, #7
    v.insert     v1, s5, #4
    s.cmp.lt     s5, s1, s26
    s.or         s1, s6, s3
    s.shli       s3, s8, #32
    v.extract    s6, v0, #7
    v.insert     v1, s5, #5
    s.cmp.lt     s5, s1, s27
    v.movi       v4, #0
    s.or         s1, s6, s3
    v.insert     v1, s5, #6
    v.cmp.ne     p1, v2, v4
    v.extract    s3, v5, #8
    s.shli       s5, s3, #32
    v.extract    s3, v0, #8
    v.extract    s6, v5, #9
    s.cmp.lt     s8, s1, s28
    s.or         s1, s3, s5
    s.shli       s3, s6, #32
    v.extract    s5, v0, #9
    v.extract    s6, v5, #10
    v.insert     v1, s8, #7
    s.cmp.lt     s8, s1, s29
    s.or         s1, s5, s3
    s.shli       s3, s6, #32
    v.extract    s5, v0, #10
    v.extract    s6, v5, #11
    v.insert     v1, s8, #8
    s.cmp.lt     s8, s1, s30
    s.or         s1, s5, s3
    s.shli       s3, s6, #32
    v.extract    s5, v0, #11
    v.extract    s6, v5, #12
    v.insert     v1, s8, #9
    s.cmp.lt     s8, s1, s31
    s.or         s1, s5, s3
    s.shli       s3, s6, #32
    v.extract    s5, v0, #12
    v.extract    s6, v5, #13
    v.insert     v1, s8, #10
    s.cmp.lt     s8, s1, s32
    s.or         s1, s5, s3
    s.shli       s3, s6, #32
    v.extract    s5, v0, #13
    v.extract    s6, v5, #14
    v.insert     v1, s8, #11
    s.cmp.lt     s8, s1, s34
    s.or         s1, s5, s3
    s.shli       s3, s6, #32
    v.extract    s5, v0, #14
    v.extract    s6, v5, #15
    v.insert     v1, s8, #12
    s.cmp.lt     s8, s1, s35
    s.or         s1, s5, s3
    s.shli       s3, s6, #32
    v.extract    s5, v0, #15
    v.insert     v1, s8, #13
    s.cmp.lt     s6, s1, s36
    s.or         s1, s5, s3
    v.insert     v1, s6, #14
    s.cmp.lt     s3, s1, s37
    v.movi       v2, #0
    v.insert     v1, s3, #15
    v.movi       v4, #-1
    v.movi       v6, #0
    v.cmp.ne     p3, v1, v2
    v.cmp.ne     p4, v4, v6
    p.and        p5, p1, p3
    p.xor        p1, p2, p4
    v.movi       v1, #0
    p.or         p3, p5, p1
    v.movi       v2, #1
    @p3 v.sel        v4, v1, v2
    v.reduce.or  s1, v4
    s.cmp.eq     s3, s1, s4
    br.nz        s3, assert_ok_1
    trap         #677351
assert_ok_1:
    v.extract    s1, v5, #0
    s.shli       s3, s1, #32
    v.extract    s1, v0, #0
    v.extract    s4, v5, #1
    s.or         s5, s1, s3
    s.movz       s1, #64
    s.shli       s3, s4, #32
    v.extract    s4, v0, #1
    v.extract    s6, v5, #2
    s.mul        s8, s5, s1
    s.or         s1, s4, s3
    s.movz       s3, #64
    s.shli       s4, s6, #32
    v.extract    s5, v0, #2
    v.extract    s6, v5, #3
    s.mul        s10, s1, s3
    s.or         s1, s5, s4
    s.movz       s3, #64
    s.shli       s4, s6, #32
    v.extract    s5, v0, #3
    v.extract    s6, v5, #4
    s.mul        s11, s1, s3
    s.or         s1, s5, s4
    s.movz       s3, #64
    s.shli       s4, s6, #32
    v.movi       v1, #0
    v.movi       v2, #0
    s.lshri      s5, s8, #32
    s.mul        s6, s1, s3
    v.extract    s1, v0, #4
    s.or         s3, s1, s4
    v.extract    s1, v5, #5
    s.shli       s4, s1, #32
    v.insert     v1, s8, #0
    s.movz       s1, #64
    v.insert     v2, s5, #0
    s.lshri      s5, s10, #32
    s.mul        s8, s3, s1
    v.extract    s1, v0, #5
    s.or         s3, s1, s4
    v.extract    s1, v5, #6
    s.shli       s4, s1, #32
    v.insert     v1, s10, #1
    s.movz       s1, #64
    v.insert     v2, s5, #1
    s.lshri      s5, s11, #32
    s.mul        s10, s3, s1
    v.extract    s1, v0, #6
    s.or         s3, s1, s4
    v.extract    s1, v5, #7
    s.shli       s4, s1, #32
    v.insert     v1, s11, #2
    s.movz       s1, #64
    v.insert     v2, s5, #2
    s.lshri      s5, s6, #32
    s.mul        s11, s3, s1
    v.extract    s1, v0, #7
    s.or         s3, s1, s4
    v.extract    s1, v5, #8
    s.shli       s4, s1, #32
    v.insert     v1, s6, #3
    s.movz       s1, #64
    v.insert     v2, s5, #3
    s.lshri      s5, s8, #32
    s.mul        s6, s3, s1
    v.extract    s1, v0, #8
    s.or         s3, s1, s4
    v.extract    s1, v5, #9
    s.shli       s4, s1, #32
    v.insert     v1, s8, #4
    s.movz       s1, #64
    v.insert     v2, s5, #4
    s.lshri      s5, s10, #32
    s.mul        s8, s3, s1
    v.extract    s1, v0, #9
    s.or         s3, s1, s4
    v.extract    s1, v5, #10
    s.shli       s4, s1, #32
    v.insert     v1, s10, #5
    s.movz       s1, #64
    v.insert     v2, s5, #5
    s.lshri      s5, s11, #32
    s.mul        s10, s3, s1
    v.extract    s1, v0, #10
    s.or         s3, s1, s4
    v.extract    s1, v5, #11
    s.shli       s4, s1, #32
    v.insert     v1, s11, #6
    s.movz       s1, #64
    v.insert     v2, s5, #6
    s.lshri      s5, s6, #32
    s.mul        s11, s3, s1
    v.extract    s1, v0, #11
    s.or         s3, s1, s4
    v.extract    s1, v5, #12
    s.shli       s4, s1, #32
    v.insert     v1, s6, #7
    s.movz       s1, #64
    v.insert     v2, s5, #7
    s.lshri      s5, s8, #32
    s.mul        s6, s3, s1
    v.extract    s1, v0, #12
    s.or         s3, s1, s4
    v.extract    s1, v5, #13
    s.shli       s4, s1, #32
    v.insert     v1, s8, #8
    s.movz       s1, #64
    v.insert     v2, s5, #8
    s.lshri      s5, s10, #32
    s.mul        s8, s3, s1
    v.extract    s1, v0, #13
    s.or         s3, s1, s4
    v.extract    s1, v5, #14
    s.shli       s4, s1, #32
    v.insert     v1, s10, #9
    s.movz       s1, #64
    v.insert     v2, s5, #9
    s.lshri      s5, s11, #32
    s.mul        s10, s3, s1
    v.extract    s1, v0, #14
    s.or         s3, s1, s4
    v.extract    s1, v5, #15
    s.shli       s4, s1, #32
    v.insert     v1, s11, #10
    s.movz       s1, #64
    v.insert     v2, s5, #10
    s.lshri      s5, s6, #32
    s.mul        s11, s3, s1
    v.extract    s1, v0, #15
    s.or         s3, s1, s4
    s.movz       s1, #64
    v.insert     v1, s6, #11
    v.insert     v2, s5, #11
    s.lshri      s4, s8, #32
    s.mul        s5, s3, s1
    v.extract    s1, v3, #0
    v.insert     v1, s8, #12
    v.insert     v2, s4, #12
    s.lshri      s3, s10, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #1
    v.insert     v1, s10, #13
    v.insert     v2, s3, #13
    s.lshri      s3, s11, #32
    s.ashri      s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #2
    v.insert     v1, s11, #14
    v.insert     v2, s3, #14
    s.lshri      s3, s5, #32
    v.movi       v0, #0
    v.movi       v4, #0
    s.lshri      s8, s6, #32
    s.ashri      s10, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #3
    v.insert     v1, s5, #15
    v.insert     v2, s3, #15
    v.insert     v0, s6, #0
    v.insert     v4, s8, #0
    s.lshri      s3, s10, #32
    s.ashri      s5, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #4
    v.insert     v0, s10, #1
    v.insert     v4, s3, #1
    s.lshri      s3, s5, #32
    s.ashri      s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #5
    v.insert     v0, s5, #2
    v.insert     v4, s3, #2
    s.lshri      s3, s6, #32
    s.ashri      s5, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #6
    v.insert     v0, s6, #3
    v.insert     v4, s3, #3
    s.lshri      s3, s5, #32
    s.ashri      s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #7
    v.insert     v0, s5, #4
    v.insert     v4, s3, #4
    s.lshri      s3, s6, #32
    s.ashri      s5, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #8
    v.insert     v0, s6, #5
    v.insert     v4, s3, #5
    s.lshri      s3, s5, #32
    s.ashri      s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #9
    v.insert     v0, s5, #6
    v.insert     v4, s3, #6
    s.lshri      s3, s6, #32
    s.ashri      s5, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #10
    v.insert     v0, s6, #7
    v.insert     v4, s3, #7
    s.lshri      s3, s5, #32
    s.ashri      s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #11
    v.insert     v0, s5, #8
    v.insert     v4, s3, #8
    s.lshri      s3, s6, #32
    s.ashri      s5, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #12
    v.insert     v0, s6, #9
    v.insert     v4, s3, #9
    s.lshri      s3, s5, #32
    s.ashri      s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #13
    v.insert     v0, s5, #10
    v.insert     v4, s3, #10
    s.lshri      s3, s6, #32
    s.ashri      s5, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #14
    v.insert     v0, s6, #11
    v.insert     v4, s3, #11
    s.lshri      s3, s5, #32
    s.ashri      s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v3, #15
    v.insert     v0, s5, #12
    v.insert     v4, s3, #12
    s.lshri      s3, s6, #32
    s.ashri      s5, s4, #32
    s.shli       s4, s1, #32
    v.insert     v0, s6, #13
    v.insert     v4, s3, #13
    s.lshri      s1, s5, #32
    s.ashri      s3, s4, #32
    v.insert     v0, s5, #14
    v.insert     v4, s1, #14
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #15
    v.insert     v4, s1, #15
    v.extract    s1, v2, #0
    v.extract    s3, v4, #0
    s.shli       s4, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v0, #0
    v.extract    s5, v1, #0
    v.extract    s6, v4, #1
    v.extract    s8, v2, #1
    s.or         s10, s1, s4
    s.or         s1, s5, s3
    s.shli       s3, s6, #32
    s.shli       s4, s8, #32
    v.extract    s5, v0, #1
    v.extract    s6, v1, #1
    v.extract    s8, v4, #2
    v.movi       v3, #0
    s.add        s11, s10, s1
    v.extract    s1, v2, #2
    s.or         s10, s5, s3
    s.or         s3, s6, s4
    s.shli       s4, s8, #32
    s.shli       s5, s1, #32
    v.extract    s1, v0, #2
    v.extract    s6, v1, #2
    v.movi       v5, #0
    v.insert     v3, s11, #0
    s.lshri      s8, s11, #32
    s.add        s11, s10, s3
    v.extract    s3, v4, #3
    s.or         s10, s1, s4
    v.extract    s1, v2, #3
    s.or         s4, s6, s5
    s.shli       s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v0, #3
    v.insert     v5, s8, #0
    v.extract    s6, v1, #3
    v.insert     v3, s11, #1
    s.lshri      s8, s11, #32
    s.add        s11, s10, s4
    v.extract    s4, v4, #4
    s.or         s10, s1, s5
    v.extract    s1, v2, #4
    s.or         s5, s6, s3
    s.shli       s3, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v0, #4
    v.insert     v5, s8, #1
    v.extract    s6, v1, #4
    v.insert     v3, s11, #2
    s.lshri      s8, s11, #32
    s.add        s11, s10, s5
    v.extract    s5, v4, #5
    s.or         s10, s1, s3
    v.extract    s1, v2, #5
    s.or         s3, s6, s4
    s.shli       s4, s5, #32
    s.shli       s5, s1, #32
    v.extract    s1, v0, #5
    v.insert     v5, s8, #2
    v.extract    s6, v1, #5
    v.insert     v3, s11, #3
    s.lshri      s8, s11, #32
    s.add        s11, s10, s3
    v.extract    s3, v4, #6
    s.or         s10, s1, s4
    v.extract    s1, v2, #6
    s.or         s4, s6, s5
    s.shli       s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v0, #6
    v.insert     v5, s8, #3
    v.extract    s6, v1, #6
    v.insert     v3, s11, #4
    s.lshri      s8, s11, #32
    s.add        s11, s10, s4
    v.extract    s4, v4, #7
    s.or         s10, s1, s5
    v.extract    s1, v2, #7
    s.or         s5, s6, s3
    s.shli       s3, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v0, #7
    v.insert     v5, s8, #4
    v.extract    s6, v1, #7
    v.insert     v3, s11, #5
    s.lshri      s8, s11, #32
    s.add        s11, s10, s5
    v.extract    s5, v4, #8
    s.or         s10, s1, s3
    v.extract    s1, v2, #8
    s.or         s3, s6, s4
    s.shli       s4, s5, #32
    s.shli       s5, s1, #32
    v.extract    s1, v0, #8
    v.insert     v5, s8, #5
    v.extract    s6, v1, #8
    v.insert     v3, s11, #6
    s.lshri      s8, s11, #32
    s.add        s11, s10, s3
    v.extract    s3, v4, #9
    s.or         s10, s1, s4
    v.extract    s1, v2, #9
    s.or         s4, s6, s5
    s.shli       s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v0, #9
    v.insert     v5, s8, #6
    v.extract    s6, v1, #9
    v.insert     v3, s11, #7
    s.lshri      s8, s11, #32
    s.add        s11, s10, s4
    v.extract    s4, v4, #10
    s.or         s10, s1, s5
    v.extract    s1, v2, #10
    s.or         s5, s6, s3
    s.shli       s3, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v0, #10
    v.insert     v5, s8, #7
    v.extract    s6, v1, #10
    v.insert     v3, s11, #8
    s.lshri      s8, s11, #32
    s.add        s11, s10, s5
    v.extract    s5, v4, #11
    s.or         s10, s1, s3
    v.extract    s1, v2, #11
    s.or         s3, s6, s4
    s.shli       s4, s5, #32
    s.shli       s5, s1, #32
    v.extract    s1, v0, #11
    v.insert     v5, s8, #8
    v.extract    s6, v1, #11
    v.insert     v3, s11, #9
    s.lshri      s8, s11, #32
    s.add        s11, s10, s3
    v.extract    s3, v4, #12
    s.or         s10, s1, s4
    v.extract    s1, v2, #12
    s.or         s4, s6, s5
    s.shli       s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v0, #12
    v.insert     v5, s8, #9
    v.extract    s6, v1, #12
    v.insert     v3, s11, #10
    s.lshri      s8, s11, #32
    s.add        s11, s10, s4
    v.extract    s4, v4, #13
    s.or         s10, s1, s5
    v.extract    s1, v2, #13
    s.or         s5, s6, s3
    s.shli       s3, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v0, #13
    v.insert     v5, s8, #10
    v.extract    s6, v1, #13
    v.insert     v3, s11, #11
    s.lshri      s8, s11, #32
    s.add        s11, s10, s5
    v.extract    s5, v4, #14
    s.or         s10, s1, s3
    v.extract    s1, v2, #14
    s.or         s3, s6, s4
    s.shli       s4, s5, #32
    s.shli       s5, s1, #32
    v.extract    s1, v0, #14
    v.insert     v5, s8, #11
    v.extract    s6, v1, #14
    v.insert     v3, s11, #12
    s.lshri      s8, s11, #32
    s.add        s11, s10, s3
    v.extract    s3, v4, #15
    s.or         s10, s1, s4
    v.extract    s1, v2, #15
    s.or         s4, s6, s5
    s.shli       s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v0, #15
    v.insert     v5, s8, #12
    v.extract    s6, v1, #15
    v.insert     v3, s11, #13
    s.lshri      s8, s11, #32
    s.add        s11, s10, s4
    s.or         s4, s1, s5
    s.or         s1, s6, s3
    v.insert     v5, s8, #13
    v.insert     v3, s11, #14
    s.lshri      s3, s11, #32
    s.add        s5, s4, s1
    v.insert     v5, s3, #14
    v.insert     v3, s5, #15
    s.lshri      s1, s5, #32
    v.movi       v0, #31
    v.insert     v5, s1, #15
    v.ashr       v1, v3, v0
    v.movi       v0, #1
    v.movi       v2, #0
    v.cmp.ne     p1, v5, v1
    @p1 v.sel        v1, v0, v2
    s.movz       s1, #0
    v.reduce.or  s3, v1
    s.cmp.eq     s4, s3, s1
    br.nz        s4, narrow_ok_2
    trap         #677220
narrow_ok_2:
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v0, [s7, v3]               // index is in elements (ISA sec 9.1)
    s.shli       s1, s2, #1                      // element offset -> bytes (x2)
    s.add        s2, s9, s1                      // &out_ptr0[...]
    @p2 v.st.h       [s2, #0], v0
__rctx_next:
    exit
