    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    .li       s1, #1149239296
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v1                              // arange(0, VLEN)
    v.rcp.approx v2, v0                          // ISA 8.8: <= 2**-22 relative
    v.splat      v3, s1
    v.movi       v4, #0
    s.rdspecial  s2, arg_base
    v.add        v5, v3, v1
    v.movi       v1, #10
    s.ld.d       s3, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.sub        v3, v4, v5
    v.cmp.lt     p1, v5, v4
    .li       s4, #1065353216
    v.splat      v6, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v7, v3, v5
    v.movi       v3, #0
    v.movi       v8, #2
    v.lshr       v9, v7, v1
    v.sub        v1, v3, v5
    v.cmp.lt     p2, v5, v3
    v.sub        v7, v4, v9
    s.ld.d       s4, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.mul        v10, v5, v8
    @p1 v.sel        v8, v7, v9
    @p2 v.sel        v7, v1, v5
    v.movi       v1, #1023
    v.movi       v5, #1024
    v.and        v9, v7, v1
    v.sub        v1, v4, v5
    v.sub        v7, v3, v5
    v.cmp.lt     p1, v5, v4
    vf.fms       v4, v0, v2, v6
    v.ld.gather.w v0, [s3, v8]                   // index is in elements (ISA sec 9.1)
    v.sub        v6, v3, v9
    v.cmp.lt     p3, v5, v3
    @p1 v.sel        v3, v1, v5
    vf.fms       v1, v2, v4, v2
    @p2 v.sel        v3, v6, v9
    @p3 v.sel        v4, v7, v5
    vf.neg       v4, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v1, v4, v2
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    vf.mul       v2, v0, v1                      // a/y as a refined reciprocal (ISA has no divide)
    .li       s5, #925353388
    v.splat      v0, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.ld.d       s5, [s2, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    vf.add       v1, v2, v0
    v.ld.gather.w v0, [s4, v10]                  // index is in elements (ISA sec 9.1)
    v.ld.gather.w v2, [s3, v8]                   // index is in elements (ISA sec 9.1)
    s.ld.d       s3, [s2, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    v.rsqrt.approx v4, v1                        // ISA 8.8: <= 2**-22 relative
    vf.sub       v5, v0, v2
    v.ld.gather.w v0, [s5, v3]                   // index is in elements (ISA sec 9.1)
    v.ld.gather.w v2, [s3, v3]                   // index is in elements (ISA sec 9.1)
    s.ld.d       s3, [s2, #40]                   // out_ptr0: device_ptr64 at arg_base+40
    vf.mul       v3, v4, v4
    .li       s2, #1077936128
    v.splat      v6, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    vf.fms       v8, v1, v3, v6
    vf.mul       v1, v4, v7
    s.add        s1, s3, s2                      // &out_ptr0[...]
    vf.mul       v3, v1, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v1, v3, v4
    vf.mul       v3, v5, v1
    vf.mul       v1, v3, v0
    vf.add       v0, v1, v2
    v.st.w       [s1, #0], v0
__rctx_next:
    exit
