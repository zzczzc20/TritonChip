


def forward(self, arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1):
    unsqueeze_4 = torch.ops.aten.unsqueeze.default(arg0_1, 0)
    expand = torch.ops.aten.expand.default(unsqueeze_4, [4, 1, -1]);  unsqueeze_4 = None
    slice_1 = torch.ops.aten.slice.Tensor(expand, 0, 1, 9223372036854775807);  expand = None
    expand_1 = torch.ops.aten.expand.default(slice_1, [3, -1, -1]);  slice_1 = None
    unsqueeze_5 = torch.ops.aten.unsqueeze.default(expand_1, 3);  expand_1 = None
    convert_element_type = torch.ops.prims.convert_element_type.default(unsqueeze_5, torch.float32);  unsqueeze_5 = None
    convert_element_type_1 = torch.ops.prims.convert_element_type.default(arg3_1, torch.float32);  arg3_1 = None
    mul = torch.ops.aten.mul.Tensor(convert_element_type, convert_element_type_1);  convert_element_type = convert_element_type_1 = None
    sin = torch.ops.aten.sin.default(mul)
    select_1 = torch.ops.aten.select.int(sin, 0, 0)
    slice_3 = torch.ops.aten.slice.Tensor(select_1, 2, 1, 33, 3);  select_1 = slice_3 = None
    select_3 = torch.ops.aten.select.int(sin, 0, 0);  select_3 = None
    select_2 = torch.ops.aten.select.int(sin, 0, 1)
    slice_2 = torch.ops.aten.slice.Tensor(select_2, 2, 1, 33, 3);  select_2 = None
    select_int = torch.ops.aten.select.int(sin, 0, 0)
    slice_scatter_default = torch.ops.aten.slice_scatter.default(select_int, slice_2, 2, 1, 33, 3);  select_int = slice_2 = None
    select_scatter_default = torch.ops.aten.select_scatter.default(sin, slice_scatter_default, 0, 0);  sin = slice_scatter_default = None
    select_8 = torch.ops.aten.select.int(select_scatter_default, 0, 0)
    slice_7 = torch.ops.aten.slice.Tensor(select_8, 2, 2, 30, 3);  select_8 = slice_7 = None
    cos = torch.ops.aten.cos.default(mul);  mul = None
    select_13 = torch.ops.aten.select.int(cos, 0, 0)
    slice_11 = torch.ops.aten.slice.Tensor(select_13, 2, 1, 33, 3);  select_13 = slice_11 = None
    select_15 = torch.ops.aten.select.int(cos, 0, 0);  select_15 = None
    select_14 = torch.ops.aten.select.int(cos, 0, 1)
    slice_10 = torch.ops.aten.slice.Tensor(select_14, 2, 1, 33, 3);  select_14 = None
    select_int_1 = torch.ops.aten.select.int(cos, 0, 0)
    slice_scatter_default_1 = torch.ops.aten.slice_scatter.default(select_int_1, slice_10, 2, 1, 33, 3);  select_int_1 = slice_10 = None
    select_scatter_default_1 = torch.ops.aten.select_scatter.default(cos, slice_scatter_default_1, 0, 0);  cos = slice_scatter_default_1 = None
    select_20 = torch.ops.aten.select.int(select_scatter_default_1, 0, 0)
    slice_15 = torch.ops.aten.slice.Tensor(select_20, 2, 2, 30, 3);  select_20 = slice_15 = None
    embedding = torch.ops.aten.embedding.default(arg2_1, arg1_1);  arg1_1 = None
    convert_element_type_4 = torch.ops.prims.convert_element_type.default(embedding, torch.float32)
    pow_1 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_4, 2)
    mean = torch.ops.aten.mean.dim(pow_1, [-1], True);  pow_1 = None
    add = torch.ops.aten.add.Tensor(mean, 1e-06);  mean = None
    rsqrt = torch.ops.aten.rsqrt.default(add);  add = None
    mul_3 = torch.ops.aten.mul.Tensor(convert_element_type_4, rsqrt);  convert_element_type_4 = rsqrt = None
    convert_element_type_5 = torch.ops.prims.convert_element_type.default(arg4_1, torch.float32);  arg4_1 = None
    add_1 = torch.ops.aten.add.Tensor(convert_element_type_5, 1.0);  convert_element_type_5 = None
    mul_4 = torch.ops.aten.mul.Tensor(mul_3, add_1);  mul_3 = add_1 = None
    convert_element_type_6 = torch.ops.prims.convert_element_type.default(mul_4, torch.bfloat16);  mul_4 = None
    view_2 = torch.ops.aten.reshape.default(convert_element_type_6, [1, 2048])
    permute = torch.ops.aten.permute.default(arg5_1, [1, 0]);  arg5_1 = None
    mm = torch.ops.aten.mm.default(view_2, permute);  view_2 = permute = None
    view_3 = torch.ops.aten.reshape.default(mm, [1, 1, 6144]);  mm = None
    permute_1 = torch.ops.aten.permute.default(view_3, [0, 2, 1]);  view_3 = None
    cat = torch.ops.aten.cat.default([arg9_1, permute_1], -1);  permute_1 = None
    slice_18 = torch.ops.aten.slice.Tensor(cat, 2, -4, 9223372036854775807)
    copy_4 = torch.ops.aten.copy.default(arg9_1, slice_18);  slice_18 = None
    convert_element_type_15 = torch.ops.prims.convert_element_type.default(cat, torch.float32);  cat = None
    slice_19 = torch.ops.aten.slice.Tensor(convert_element_type_15, 2, 0, 2)
    squeeze = torch.ops.aten.squeeze.dim(arg10_1, 1);  arg10_1 = None
    unsqueeze_8 = torch.ops.aten.unsqueeze.default(squeeze, 1);  squeeze = None
    convert_element_type_16 = torch.ops.prims.convert_element_type.default(unsqueeze_8, torch.float32);  unsqueeze_8 = None
    select_25 = torch.ops.aten.select.int(convert_element_type_16, 1, 0)
    select_26 = torch.ops.aten.select.int(select_25, 1, 0);  select_25 = None
    view_11 = torch.ops.aten.reshape.default(select_26, [1, -1, 1]);  select_26 = None
    mul_5 = torch.ops.aten.mul.Tensor(slice_19, view_11);  slice_19 = view_11 = None
    slice_20 = torch.ops.aten.slice.Tensor(convert_element_type_15, 2, 1, 3)
    select_27 = torch.ops.aten.select.int(convert_element_type_16, 1, 0)
    select_28 = torch.ops.aten.select.int(select_27, 1, 1);  select_27 = None
    view_12 = torch.ops.aten.reshape.default(select_28, [1, -1, 1]);  select_28 = None
    mul_6 = torch.ops.aten.mul.Tensor(slice_20, view_12);  slice_20 = view_12 = None
    add_2 = torch.ops.aten.add.Tensor(mul_5, mul_6);  mul_5 = mul_6 = None
    slice_21 = torch.ops.aten.slice.Tensor(convert_element_type_15, 2, 2, 4)
    select_29 = torch.ops.aten.select.int(convert_element_type_16, 1, 0)
    select_30 = torch.ops.aten.select.int(select_29, 1, 2);  select_29 = None
    view_13 = torch.ops.aten.reshape.default(select_30, [1, -1, 1]);  select_30 = None
    mul_7 = torch.ops.aten.mul.Tensor(slice_21, view_13);  slice_21 = view_13 = None
    add_3 = torch.ops.aten.add.Tensor(add_2, mul_7);  add_2 = mul_7 = None
    slice_22 = torch.ops.aten.slice.Tensor(convert_element_type_15, 2, 3, 5);  convert_element_type_15 = None
    select_31 = torch.ops.aten.select.int(convert_element_type_16, 1, 0);  convert_element_type_16 = None
    select_32 = torch.ops.aten.select.int(select_31, 1, 3);  select_31 = None
    view_14 = torch.ops.aten.reshape.default(select_32, [1, -1, 1]);  select_32 = None
    mul_8 = torch.ops.aten.mul.Tensor(slice_22, view_14);  slice_22 = view_14 = None
    add_4 = torch.ops.aten.add.Tensor(add_3, mul_8);  add_3 = mul_8 = None
    convert_element_type_17 = torch.ops.prims.convert_element_type.default(add_4, torch.bfloat16);  add_4 = None
    slice_23 = torch.ops.aten.slice.Tensor(convert_element_type_17, 2, -1, 9223372036854775807);  convert_element_type_17 = None
    convert_element_type_18 = torch.ops.prims.convert_element_type.default(slice_23, torch.float32);  slice_23 = None
    neg = torch.ops.aten.neg.default(convert_element_type_18)
    exp = torch.ops.aten.exp.default(neg);  neg = None
    add_5 = torch.ops.aten.add.Tensor(exp, 1);  exp = None
    div = torch.ops.aten.div.Tensor(convert_element_type_18, add_5);  convert_element_type_18 = add_5 = None
    convert_element_type_19 = torch.ops.prims.convert_element_type.default(div, torch.bfloat16);  div = None
    permute_5 = torch.ops.aten.permute.default(convert_element_type_19, [0, 2, 1]);  convert_element_type_19 = None
    split_with_sizes = torch.ops.aten.split_with_sizes.default(permute_5, [2048, 2048, 2048], -1);  permute_5 = None
    getitem = split_with_sizes[0]
    getitem_1 = split_with_sizes[1]
    getitem_2 = split_with_sizes[2];  split_with_sizes = None
    full_default_2 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_38 = torch.ops.aten.select.int(full_default_2, 2, 0);  select_38 = None
    view_16 = torch.ops.aten.reshape.default(getitem_1, [1, 1, -1, 128]);  getitem_1 = None
    permute_7 = torch.ops.aten.permute.default(view_16, [0, 2, 1, 3]);  view_16 = None
    convert_element_type_22 = torch.ops.prims.convert_element_type.default(permute_7, torch.float32);  permute_7 = None
    clone_5 = torch.ops.aten.clone.default(convert_element_type_22, memory_format = torch.contiguous_format);  convert_element_type_22 = None
    mul_12 = torch.ops.aten.mul.Tensor(clone_5, clone_5)
    sum_2 = torch.ops.aten.sum.dim_IntList(mul_12, [-1], True);  mul_12 = None
    add_8 = torch.ops.aten.add.Tensor(sum_2, 1e-06);  sum_2 = None
    rsqrt_2 = torch.ops.aten.rsqrt.default(add_8);  add_8 = None
    mul_13 = torch.ops.aten.mul.Tensor(clone_5, rsqrt_2);  clone_5 = rsqrt_2 = None
    select_34 = torch.ops.aten.select.int(mul_13, 2, 0);  mul_13 = None
    unsqueeze_13 = torch.ops.aten.unsqueeze.default(select_34, -1)
    view_17 = torch.ops.aten.reshape.default(getitem_2, [1, 1, -1, 128]);  getitem_2 = None
    permute_8 = torch.ops.aten.permute.default(view_17, [0, 2, 1, 3]);  view_17 = None
    convert_element_type_23 = torch.ops.prims.convert_element_type.default(permute_8, torch.float32);  permute_8 = None
    clone_6 = torch.ops.aten.clone.default(convert_element_type_23, memory_format = torch.contiguous_format);  convert_element_type_23 = None
    select_35 = torch.ops.aten.select.int(clone_6, 2, 0);  clone_6 = None
    exp_1 = torch.ops.aten.exp.default(arg11_1);  arg11_1 = None
    neg_1 = torch.ops.aten.neg.default(exp_1);  exp_1 = None
    view_9 = torch.ops.aten.reshape.default(convert_element_type_6, [1, 2048])
    permute_4 = torch.ops.aten.permute.default(arg8_1, [1, 0]);  arg8_1 = None
    mm_3 = torch.ops.aten.mm.default(view_9, permute_4);  view_9 = permute_4 = None
    view_10 = torch.ops.aten.reshape.default(mm_3, [1, 1, 16]);  mm_3 = None
    convert_element_type_20 = torch.ops.prims.convert_element_type.default(view_10, torch.float32);  view_10 = None
    add_6 = torch.ops.aten.add.Tensor(convert_element_type_20, arg12_1);  convert_element_type_20 = arg12_1 = None
    gt = torch.ops.aten.gt.Scalar(add_6, 20)
    exp_2 = torch.ops.aten.exp.default(add_6)
    log1p = torch.ops.aten.log1p.default(exp_2);  exp_2 = None
    where_1 = torch.ops.aten.where.self(gt, add_6, log1p);  gt = add_6 = log1p = None
    mul_9 = torch.ops.aten.mul.Tensor(neg_1, where_1);  neg_1 = where_1 = None
    permute_10 = torch.ops.aten.permute.default(mul_9, [0, 2, 1]);  mul_9 = None
    select_36 = torch.ops.aten.select.int(permute_10, 2, 0);  permute_10 = None
    exp_3 = torch.ops.aten.exp.default(select_36);  select_36 = None
    unsqueeze_9 = torch.ops.aten.unsqueeze.default(exp_3, 2);  exp_3 = None
    unsqueeze_10 = torch.ops.aten.unsqueeze.default(unsqueeze_9, 3);  unsqueeze_9 = None
    mul_14 = torch.ops.aten.mul.Tensor(arg13_1, unsqueeze_10);  unsqueeze_10 = None
    unsqueeze_12 = torch.ops.aten.unsqueeze.default(select_34, -1);  select_34 = None
    mul_15 = torch.ops.aten.mul.Tensor(mul_14, unsqueeze_12);  unsqueeze_12 = None
    sum_3 = torch.ops.aten.sum.dim_IntList(mul_15, [-2]);  mul_15 = None
    sub = torch.ops.aten.sub.Tensor(select_35, sum_3);  select_35 = sum_3 = None
    view_7 = torch.ops.aten.reshape.default(convert_element_type_6, [1, 2048])
    permute_3 = torch.ops.aten.permute.default(arg7_1, [1, 0]);  arg7_1 = None
    mm_2 = torch.ops.aten.mm.default(view_7, permute_3);  view_7 = permute_3 = None
    view_8 = torch.ops.aten.reshape.default(mm_2, [1, 1, 16]);  mm_2 = None
    sigmoid = torch.ops.aten.sigmoid.default(view_8);  view_8 = None
    permute_9 = torch.ops.aten.permute.default(sigmoid, [0, 2, 1]);  sigmoid = None
    convert_element_type_24 = torch.ops.prims.convert_element_type.default(permute_9, torch.float32);  permute_9 = None
    clone_7 = torch.ops.aten.clone.default(convert_element_type_24, memory_format = torch.contiguous_format);  convert_element_type_24 = None
    select_37 = torch.ops.aten.select.int(clone_7, 2, 0);  clone_7 = None
    unsqueeze_11 = torch.ops.aten.unsqueeze.default(select_37, -1);  select_37 = None
    mul_16 = torch.ops.aten.mul.Tensor(sub, unsqueeze_11);  sub = unsqueeze_11 = None
    unsqueeze_14 = torch.ops.aten.unsqueeze.default(mul_16, -2);  mul_16 = None
    mul_17 = torch.ops.aten.mul.Tensor(unsqueeze_13, unsqueeze_14);  unsqueeze_13 = unsqueeze_14 = None
    add_9 = torch.ops.aten.add.Tensor(mul_14, mul_17);  mul_14 = mul_17 = None
    view_15 = torch.ops.aten.reshape.default(getitem, [1, 1, -1, 128]);  getitem = None
    permute_6 = torch.ops.aten.permute.default(view_15, [0, 2, 1, 3]);  view_15 = None
    convert_element_type_21 = torch.ops.prims.convert_element_type.default(permute_6, torch.float32);  permute_6 = None
    clone_4 = torch.ops.aten.clone.default(convert_element_type_21, memory_format = torch.contiguous_format);  convert_element_type_21 = None
    mul_10 = torch.ops.aten.mul.Tensor(clone_4, clone_4)
    sum_1 = torch.ops.aten.sum.dim_IntList(mul_10, [-1], True);  mul_10 = None
    add_7 = torch.ops.aten.add.Tensor(sum_1, 1e-06);  sum_1 = None
    rsqrt_1 = torch.ops.aten.rsqrt.default(add_7);  add_7 = None
    mul_11 = torch.ops.aten.mul.Tensor(clone_4, rsqrt_1);  clone_4 = rsqrt_1 = None
    div_1 = torch.ops.aten.div.Tensor(mul_11, 11.313708498984761);  mul_11 = None
    select_33 = torch.ops.aten.select.int(div_1, 2, 0);  div_1 = None
    unsqueeze_15 = torch.ops.aten.unsqueeze.default(select_33, -1);  select_33 = None
    mul_18 = torch.ops.aten.mul.Tensor(add_9, unsqueeze_15);  unsqueeze_15 = None
    sum_4 = torch.ops.aten.sum.dim_IntList(mul_18, [-2]);  mul_18 = None
    select_scatter_default_2 = torch.ops.aten.select_scatter.default(full_default_2, sum_4, 2, 0);  full_default_2 = sum_4 = None
    permute_12 = torch.ops.aten.permute.default(select_scatter_default_2, [0, 2, 1, 3]);  select_scatter_default_2 = None
    convert_element_type_25 = torch.ops.prims.convert_element_type.default(permute_12, torch.bfloat16);  permute_12 = None
    view_18 = torch.ops.aten.reshape.default(convert_element_type_25, [-1, 128]);  convert_element_type_25 = None
    convert_element_type_26 = torch.ops.prims.convert_element_type.default(view_18, torch.float32);  view_18 = None
    pow_2 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_26, 2)
    mean_1 = torch.ops.aten.mean.dim(pow_2, [-1], True);  pow_2 = None
    add_10 = torch.ops.aten.add.Tensor(mean_1, 1e-06);  mean_1 = None
    rsqrt_3 = torch.ops.aten.rsqrt.default(add_10);  add_10 = None
    mul_19 = torch.ops.aten.mul.Tensor(convert_element_type_26, rsqrt_3);  convert_element_type_26 = rsqrt_3 = None
    convert_element_type_27 = torch.ops.prims.convert_element_type.default(mul_19, torch.bfloat16);  mul_19 = None
    mul_20 = torch.ops.aten.mul.Tensor(arg14_1, convert_element_type_27);  arg14_1 = convert_element_type_27 = None
    view_4 = torch.ops.aten.reshape.default(convert_element_type_6, [1, 2048]);  convert_element_type_6 = None
    permute_2 = torch.ops.aten.permute.default(arg6_1, [1, 0]);  arg6_1 = None
    mm_1 = torch.ops.aten.mm.default(view_4, permute_2);  view_4 = permute_2 = None
    view_5 = torch.ops.aten.reshape.default(mm_1, [1, 1, 2048]);  mm_1 = None
    view_6 = torch.ops.aten.reshape.default(view_5, [1, 1, -1, 128]);  view_5 = None
    view_19 = torch.ops.aten.reshape.default(view_6, [-1, 128]);  view_6 = None
    convert_element_type_28 = torch.ops.prims.convert_element_type.default(view_19, torch.float32);  view_19 = None
    neg_2 = torch.ops.aten.neg.default(convert_element_type_28)
    exp_4 = torch.ops.aten.exp.default(neg_2);  neg_2 = None
    add_11 = torch.ops.aten.add.Tensor(exp_4, 1);  exp_4 = None
    div_2 = torch.ops.aten.div.Tensor(convert_element_type_28, add_11);  convert_element_type_28 = add_11 = None
    mul_21 = torch.ops.aten.mul.Tensor(mul_20, div_2);  mul_20 = div_2 = None
    convert_element_type_29 = torch.ops.prims.convert_element_type.default(mul_21, torch.bfloat16);  mul_21 = None
    view_20 = torch.ops.aten.reshape.default(convert_element_type_29, [1, 1, -1]);  convert_element_type_29 = None
    view_21 = torch.ops.aten.reshape.default(view_20, [1, 2048]);  view_20 = None
    permute_13 = torch.ops.aten.permute.default(arg15_1, [1, 0]);  arg15_1 = None
    mm_4 = torch.ops.aten.mm.default(view_21, permute_13);  view_21 = permute_13 = None
    view_22 = torch.ops.aten.reshape.default(mm_4, [1, 1, 2048]);  mm_4 = None
    add_12 = torch.ops.aten.add.Tensor(embedding, view_22);  embedding = view_22 = None
    convert_element_type_32 = torch.ops.prims.convert_element_type.default(add_12, torch.float32)
    pow_3 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_32, 2)
    mean_2 = torch.ops.aten.mean.dim(pow_3, [-1], True);  pow_3 = None
    add_13 = torch.ops.aten.add.Tensor(mean_2, 1e-06);  mean_2 = None
    rsqrt_4 = torch.ops.aten.rsqrt.default(add_13);  add_13 = None
    mul_22 = torch.ops.aten.mul.Tensor(convert_element_type_32, rsqrt_4);  convert_element_type_32 = rsqrt_4 = None
    convert_element_type_33 = torch.ops.prims.convert_element_type.default(arg16_1, torch.float32);  arg16_1 = None
    add_14 = torch.ops.aten.add.Tensor(convert_element_type_33, 1.0);  convert_element_type_33 = None
    mul_23 = torch.ops.aten.mul.Tensor(mul_22, add_14);  mul_22 = add_14 = None
    convert_element_type_34 = torch.ops.prims.convert_element_type.default(mul_23, torch.bfloat16);  mul_23 = None
    view_23 = torch.ops.aten.reshape.default(convert_element_type_34, [1, 2048])
    permute_14 = torch.ops.aten.permute.default(arg17_1, [1, 0]);  arg17_1 = None
    mm_5 = torch.ops.aten.mm.default(view_23, permute_14);  view_23 = permute_14 = None
    view_24 = torch.ops.aten.reshape.default(mm_5, [1, 1, 6144]);  mm_5 = None
    convert_element_type_37 = torch.ops.prims.convert_element_type.default(view_24, torch.float32);  view_24 = None
    neg_3 = torch.ops.aten.neg.default(convert_element_type_37)
    exp_5 = torch.ops.aten.exp.default(neg_3);  neg_3 = None
    add_15 = torch.ops.aten.add.Tensor(exp_5, 1);  exp_5 = None
    div_3 = torch.ops.aten.div.Tensor(convert_element_type_37, add_15);  convert_element_type_37 = add_15 = None
    convert_element_type_38 = torch.ops.prims.convert_element_type.default(div_3, torch.bfloat16);  div_3 = None
    view_25 = torch.ops.aten.reshape.default(convert_element_type_34, [1, 2048]);  convert_element_type_34 = None
    permute_15 = torch.ops.aten.permute.default(arg18_1, [1, 0]);  arg18_1 = None
    mm_6 = torch.ops.aten.mm.default(view_25, permute_15);  view_25 = permute_15 = None
    view_26 = torch.ops.aten.reshape.default(mm_6, [1, 1, 6144]);  mm_6 = None
    mul_24 = torch.ops.aten.mul.Tensor(convert_element_type_38, view_26);  convert_element_type_38 = view_26 = None
    view_27 = torch.ops.aten.reshape.default(mul_24, [1, 6144]);  mul_24 = None
    permute_16 = torch.ops.aten.permute.default(arg19_1, [1, 0]);  arg19_1 = None
    mm_7 = torch.ops.aten.mm.default(view_27, permute_16);  view_27 = permute_16 = None
    view_28 = torch.ops.aten.reshape.default(mm_7, [1, 1, 2048]);  mm_7 = None
    add_16 = torch.ops.aten.add.Tensor(add_12, view_28);  add_12 = view_28 = None
    convert_element_type_43 = torch.ops.prims.convert_element_type.default(add_16, torch.float32)
    pow_4 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_43, 2)
    mean_3 = torch.ops.aten.mean.dim(pow_4, [-1], True);  pow_4 = None
    add_17 = torch.ops.aten.add.Tensor(mean_3, 1e-06);  mean_3 = None
    rsqrt_5 = torch.ops.aten.rsqrt.default(add_17);  add_17 = None
    mul_25 = torch.ops.aten.mul.Tensor(convert_element_type_43, rsqrt_5);  convert_element_type_43 = rsqrt_5 = None
    convert_element_type_44 = torch.ops.prims.convert_element_type.default(arg20_1, torch.float32);  arg20_1 = None
    add_18 = torch.ops.aten.add.Tensor(convert_element_type_44, 1.0);  convert_element_type_44 = None
    mul_26 = torch.ops.aten.mul.Tensor(mul_25, add_18);  mul_25 = add_18 = None
    convert_element_type_45 = torch.ops.prims.convert_element_type.default(mul_26, torch.bfloat16);  mul_26 = None
    view_29 = torch.ops.aten.reshape.default(convert_element_type_45, [1, 2048])
    permute_17 = torch.ops.aten.permute.default(arg21_1, [1, 0]);  arg21_1 = None
    mm_8 = torch.ops.aten.mm.default(view_29, permute_17);  view_29 = permute_17 = None
    view_30 = torch.ops.aten.reshape.default(mm_8, [1, 1, 6144]);  mm_8 = None
    permute_18 = torch.ops.aten.permute.default(view_30, [0, 2, 1]);  view_30 = None
    cat_1 = torch.ops.aten.cat.default([arg25_1, permute_18], -1);  permute_18 = None
    slice_24 = torch.ops.aten.slice.Tensor(cat_1, 2, -4, 9223372036854775807)
    copy_7 = torch.ops.aten.copy.default(arg25_1, slice_24);  slice_24 = None
    convert_element_type_54 = torch.ops.prims.convert_element_type.default(cat_1, torch.float32);  cat_1 = None
    slice_25 = torch.ops.aten.slice.Tensor(convert_element_type_54, 2, 0, 2)
    squeeze_1 = torch.ops.aten.squeeze.dim(arg26_1, 1);  arg26_1 = None
    unsqueeze_16 = torch.ops.aten.unsqueeze.default(squeeze_1, 1);  squeeze_1 = None
    convert_element_type_55 = torch.ops.prims.convert_element_type.default(unsqueeze_16, torch.float32);  unsqueeze_16 = None
    select_40 = torch.ops.aten.select.int(convert_element_type_55, 1, 0)
    select_41 = torch.ops.aten.select.int(select_40, 1, 0);  select_40 = None
    view_38 = torch.ops.aten.reshape.default(select_41, [1, -1, 1]);  select_41 = None
    mul_27 = torch.ops.aten.mul.Tensor(slice_25, view_38);  slice_25 = view_38 = None
    slice_26 = torch.ops.aten.slice.Tensor(convert_element_type_54, 2, 1, 3)
    select_42 = torch.ops.aten.select.int(convert_element_type_55, 1, 0)
    select_43 = torch.ops.aten.select.int(select_42, 1, 1);  select_42 = None
    view_39 = torch.ops.aten.reshape.default(select_43, [1, -1, 1]);  select_43 = None
    mul_28 = torch.ops.aten.mul.Tensor(slice_26, view_39);  slice_26 = view_39 = None
    add_19 = torch.ops.aten.add.Tensor(mul_27, mul_28);  mul_27 = mul_28 = None
    slice_27 = torch.ops.aten.slice.Tensor(convert_element_type_54, 2, 2, 4)
    select_44 = torch.ops.aten.select.int(convert_element_type_55, 1, 0)
    select_45 = torch.ops.aten.select.int(select_44, 1, 2);  select_44 = None
    view_40 = torch.ops.aten.reshape.default(select_45, [1, -1, 1]);  select_45 = None
    mul_29 = torch.ops.aten.mul.Tensor(slice_27, view_40);  slice_27 = view_40 = None
    add_20 = torch.ops.aten.add.Tensor(add_19, mul_29);  add_19 = mul_29 = None
    slice_28 = torch.ops.aten.slice.Tensor(convert_element_type_54, 2, 3, 5);  convert_element_type_54 = None
    select_46 = torch.ops.aten.select.int(convert_element_type_55, 1, 0);  convert_element_type_55 = None
    select_47 = torch.ops.aten.select.int(select_46, 1, 3);  select_46 = None
    view_41 = torch.ops.aten.reshape.default(select_47, [1, -1, 1]);  select_47 = None
    mul_30 = torch.ops.aten.mul.Tensor(slice_28, view_41);  slice_28 = view_41 = None
    add_21 = torch.ops.aten.add.Tensor(add_20, mul_30);  add_20 = mul_30 = None
    convert_element_type_56 = torch.ops.prims.convert_element_type.default(add_21, torch.bfloat16);  add_21 = None
    slice_29 = torch.ops.aten.slice.Tensor(convert_element_type_56, 2, -1, 9223372036854775807);  convert_element_type_56 = None
    convert_element_type_57 = torch.ops.prims.convert_element_type.default(slice_29, torch.float32);  slice_29 = None
    neg_4 = torch.ops.aten.neg.default(convert_element_type_57)
    exp_6 = torch.ops.aten.exp.default(neg_4);  neg_4 = None
    add_22 = torch.ops.aten.add.Tensor(exp_6, 1);  exp_6 = None
    div_4 = torch.ops.aten.div.Tensor(convert_element_type_57, add_22);  convert_element_type_57 = add_22 = None
    convert_element_type_58 = torch.ops.prims.convert_element_type.default(div_4, torch.bfloat16);  div_4 = None
    permute_22 = torch.ops.aten.permute.default(convert_element_type_58, [0, 2, 1]);  convert_element_type_58 = None
    split_with_sizes_1 = torch.ops.aten.split_with_sizes.default(permute_22, [2048, 2048, 2048], -1);  permute_22 = None
    getitem_3 = split_with_sizes_1[0]
    getitem_4 = split_with_sizes_1[1]
    getitem_5 = split_with_sizes_1[2];  split_with_sizes_1 = None
    full_default_3 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_53 = torch.ops.aten.select.int(full_default_3, 2, 0);  select_53 = None
    view_43 = torch.ops.aten.reshape.default(getitem_4, [1, 1, -1, 128]);  getitem_4 = None
    permute_24 = torch.ops.aten.permute.default(view_43, [0, 2, 1, 3]);  view_43 = None
    convert_element_type_61 = torch.ops.prims.convert_element_type.default(permute_24, torch.float32);  permute_24 = None
    clone_9 = torch.ops.aten.clone.default(convert_element_type_61, memory_format = torch.contiguous_format);  convert_element_type_61 = None
    mul_34 = torch.ops.aten.mul.Tensor(clone_9, clone_9)
    sum_6 = torch.ops.aten.sum.dim_IntList(mul_34, [-1], True);  mul_34 = None
    add_25 = torch.ops.aten.add.Tensor(sum_6, 1e-06);  sum_6 = None
    rsqrt_7 = torch.ops.aten.rsqrt.default(add_25);  add_25 = None
    mul_35 = torch.ops.aten.mul.Tensor(clone_9, rsqrt_7);  clone_9 = rsqrt_7 = None
    select_49 = torch.ops.aten.select.int(mul_35, 2, 0);  mul_35 = None
    unsqueeze_21 = torch.ops.aten.unsqueeze.default(select_49, -1)
    view_44 = torch.ops.aten.reshape.default(getitem_5, [1, 1, -1, 128]);  getitem_5 = None
    permute_25 = torch.ops.aten.permute.default(view_44, [0, 2, 1, 3]);  view_44 = None
    convert_element_type_62 = torch.ops.prims.convert_element_type.default(permute_25, torch.float32);  permute_25 = None
    clone_10 = torch.ops.aten.clone.default(convert_element_type_62, memory_format = torch.contiguous_format);  convert_element_type_62 = None
    select_50 = torch.ops.aten.select.int(clone_10, 2, 0);  clone_10 = None
    exp_7 = torch.ops.aten.exp.default(arg27_1);  arg27_1 = None
    neg_5 = torch.ops.aten.neg.default(exp_7);  exp_7 = None
    view_36 = torch.ops.aten.reshape.default(convert_element_type_45, [1, 2048])
    permute_21 = torch.ops.aten.permute.default(arg24_1, [1, 0]);  arg24_1 = None
    mm_11 = torch.ops.aten.mm.default(view_36, permute_21);  view_36 = permute_21 = None
    view_37 = torch.ops.aten.reshape.default(mm_11, [1, 1, 16]);  mm_11 = None
    convert_element_type_59 = torch.ops.prims.convert_element_type.default(view_37, torch.float32);  view_37 = None
    add_23 = torch.ops.aten.add.Tensor(convert_element_type_59, arg28_1);  convert_element_type_59 = arg28_1 = None
    gt_1 = torch.ops.aten.gt.Scalar(add_23, 20)
    exp_8 = torch.ops.aten.exp.default(add_23)
    log1p_1 = torch.ops.aten.log1p.default(exp_8);  exp_8 = None
    where_2 = torch.ops.aten.where.self(gt_1, add_23, log1p_1);  gt_1 = add_23 = log1p_1 = None
    mul_31 = torch.ops.aten.mul.Tensor(neg_5, where_2);  neg_5 = where_2 = None
    permute_27 = torch.ops.aten.permute.default(mul_31, [0, 2, 1]);  mul_31 = None
    select_51 = torch.ops.aten.select.int(permute_27, 2, 0);  permute_27 = None
    exp_9 = torch.ops.aten.exp.default(select_51);  select_51 = None
    unsqueeze_17 = torch.ops.aten.unsqueeze.default(exp_9, 2);  exp_9 = None
    unsqueeze_18 = torch.ops.aten.unsqueeze.default(unsqueeze_17, 3);  unsqueeze_17 = None
    mul_36 = torch.ops.aten.mul.Tensor(arg29_1, unsqueeze_18);  unsqueeze_18 = None
    unsqueeze_20 = torch.ops.aten.unsqueeze.default(select_49, -1);  select_49 = None
    mul_37 = torch.ops.aten.mul.Tensor(mul_36, unsqueeze_20);  unsqueeze_20 = None
    sum_7 = torch.ops.aten.sum.dim_IntList(mul_37, [-2]);  mul_37 = None
    sub_1 = torch.ops.aten.sub.Tensor(select_50, sum_7);  select_50 = sum_7 = None
    view_34 = torch.ops.aten.reshape.default(convert_element_type_45, [1, 2048])
    permute_20 = torch.ops.aten.permute.default(arg23_1, [1, 0]);  arg23_1 = None
    mm_10 = torch.ops.aten.mm.default(view_34, permute_20);  view_34 = permute_20 = None
    view_35 = torch.ops.aten.reshape.default(mm_10, [1, 1, 16]);  mm_10 = None
    sigmoid_1 = torch.ops.aten.sigmoid.default(view_35);  view_35 = None
    permute_26 = torch.ops.aten.permute.default(sigmoid_1, [0, 2, 1]);  sigmoid_1 = None
    convert_element_type_63 = torch.ops.prims.convert_element_type.default(permute_26, torch.float32);  permute_26 = None
    clone_11 = torch.ops.aten.clone.default(convert_element_type_63, memory_format = torch.contiguous_format);  convert_element_type_63 = None
    select_52 = torch.ops.aten.select.int(clone_11, 2, 0);  clone_11 = None
    unsqueeze_19 = torch.ops.aten.unsqueeze.default(select_52, -1);  select_52 = None
    mul_38 = torch.ops.aten.mul.Tensor(sub_1, unsqueeze_19);  sub_1 = unsqueeze_19 = None
    unsqueeze_22 = torch.ops.aten.unsqueeze.default(mul_38, -2);  mul_38 = None
    mul_39 = torch.ops.aten.mul.Tensor(unsqueeze_21, unsqueeze_22);  unsqueeze_21 = unsqueeze_22 = None
    add_26 = torch.ops.aten.add.Tensor(mul_36, mul_39);  mul_36 = mul_39 = None
    view_42 = torch.ops.aten.reshape.default(getitem_3, [1, 1, -1, 128]);  getitem_3 = None
    permute_23 = torch.ops.aten.permute.default(view_42, [0, 2, 1, 3]);  view_42 = None
    convert_element_type_60 = torch.ops.prims.convert_element_type.default(permute_23, torch.float32);  permute_23 = None
    clone_8 = torch.ops.aten.clone.default(convert_element_type_60, memory_format = torch.contiguous_format);  convert_element_type_60 = None
    mul_32 = torch.ops.aten.mul.Tensor(clone_8, clone_8)
    sum_5 = torch.ops.aten.sum.dim_IntList(mul_32, [-1], True);  mul_32 = None
    add_24 = torch.ops.aten.add.Tensor(sum_5, 1e-06);  sum_5 = None
    rsqrt_6 = torch.ops.aten.rsqrt.default(add_24);  add_24 = None
    mul_33 = torch.ops.aten.mul.Tensor(clone_8, rsqrt_6);  clone_8 = rsqrt_6 = None
    div_5 = torch.ops.aten.div.Tensor(mul_33, 11.313708498984761);  mul_33 = None
    select_48 = torch.ops.aten.select.int(div_5, 2, 0);  div_5 = None
    unsqueeze_23 = torch.ops.aten.unsqueeze.default(select_48, -1);  select_48 = None
    mul_40 = torch.ops.aten.mul.Tensor(add_26, unsqueeze_23);  unsqueeze_23 = None
    sum_8 = torch.ops.aten.sum.dim_IntList(mul_40, [-2]);  mul_40 = None
    select_scatter_default_3 = torch.ops.aten.select_scatter.default(full_default_3, sum_8, 2, 0);  full_default_3 = sum_8 = None
    permute_29 = torch.ops.aten.permute.default(select_scatter_default_3, [0, 2, 1, 3]);  select_scatter_default_3 = None
    convert_element_type_64 = torch.ops.prims.convert_element_type.default(permute_29, torch.bfloat16);  permute_29 = None
    view_45 = torch.ops.aten.reshape.default(convert_element_type_64, [-1, 128]);  convert_element_type_64 = None
    convert_element_type_65 = torch.ops.prims.convert_element_type.default(view_45, torch.float32);  view_45 = None
    pow_5 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_65, 2)
    mean_4 = torch.ops.aten.mean.dim(pow_5, [-1], True);  pow_5 = None
    add_27 = torch.ops.aten.add.Tensor(mean_4, 1e-06);  mean_4 = None
    rsqrt_8 = torch.ops.aten.rsqrt.default(add_27);  add_27 = None
    mul_41 = torch.ops.aten.mul.Tensor(convert_element_type_65, rsqrt_8);  convert_element_type_65 = rsqrt_8 = None
    convert_element_type_66 = torch.ops.prims.convert_element_type.default(mul_41, torch.bfloat16);  mul_41 = None
    mul_42 = torch.ops.aten.mul.Tensor(arg30_1, convert_element_type_66);  arg30_1 = convert_element_type_66 = None
    view_31 = torch.ops.aten.reshape.default(convert_element_type_45, [1, 2048]);  convert_element_type_45 = None
    permute_19 = torch.ops.aten.permute.default(arg22_1, [1, 0]);  arg22_1 = None
    mm_9 = torch.ops.aten.mm.default(view_31, permute_19);  view_31 = permute_19 = None
    view_32 = torch.ops.aten.reshape.default(mm_9, [1, 1, 2048]);  mm_9 = None
    view_33 = torch.ops.aten.reshape.default(view_32, [1, 1, -1, 128]);  view_32 = None
    view_46 = torch.ops.aten.reshape.default(view_33, [-1, 128]);  view_33 = None
    convert_element_type_67 = torch.ops.prims.convert_element_type.default(view_46, torch.float32);  view_46 = None
    neg_6 = torch.ops.aten.neg.default(convert_element_type_67)
    exp_10 = torch.ops.aten.exp.default(neg_6);  neg_6 = None
    add_28 = torch.ops.aten.add.Tensor(exp_10, 1);  exp_10 = None
    div_6 = torch.ops.aten.div.Tensor(convert_element_type_67, add_28);  convert_element_type_67 = add_28 = None
    mul_43 = torch.ops.aten.mul.Tensor(mul_42, div_6);  mul_42 = div_6 = None
    convert_element_type_68 = torch.ops.prims.convert_element_type.default(mul_43, torch.bfloat16);  mul_43 = None
    view_47 = torch.ops.aten.reshape.default(convert_element_type_68, [1, 1, -1]);  convert_element_type_68 = None
    view_48 = torch.ops.aten.reshape.default(view_47, [1, 2048]);  view_47 = None
    permute_30 = torch.ops.aten.permute.default(arg31_1, [1, 0]);  arg31_1 = None
    mm_12 = torch.ops.aten.mm.default(view_48, permute_30);  view_48 = permute_30 = None
    view_49 = torch.ops.aten.reshape.default(mm_12, [1, 1, 2048]);  mm_12 = None
    add_29 = torch.ops.aten.add.Tensor(add_16, view_49);  add_16 = view_49 = None
    convert_element_type_71 = torch.ops.prims.convert_element_type.default(add_29, torch.float32)
    pow_6 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_71, 2)
    mean_5 = torch.ops.aten.mean.dim(pow_6, [-1], True);  pow_6 = None
    add_30 = torch.ops.aten.add.Tensor(mean_5, 1e-06);  mean_5 = None
    rsqrt_9 = torch.ops.aten.rsqrt.default(add_30);  add_30 = None
    mul_44 = torch.ops.aten.mul.Tensor(convert_element_type_71, rsqrt_9);  convert_element_type_71 = rsqrt_9 = None
    convert_element_type_72 = torch.ops.prims.convert_element_type.default(arg32_1, torch.float32);  arg32_1 = None
    add_31 = torch.ops.aten.add.Tensor(convert_element_type_72, 1.0);  convert_element_type_72 = None
    mul_45 = torch.ops.aten.mul.Tensor(mul_44, add_31);  mul_44 = add_31 = None
    convert_element_type_73 = torch.ops.prims.convert_element_type.default(mul_45, torch.bfloat16);  mul_45 = None
    view_50 = torch.ops.aten.reshape.default(convert_element_type_73, [1, 2048])
    permute_31 = torch.ops.aten.permute.default(arg33_1, [1, 0]);  arg33_1 = None
    mm_13 = torch.ops.aten.mm.default(view_50, permute_31);  view_50 = permute_31 = None
    view_51 = torch.ops.aten.reshape.default(mm_13, [1, 1, 6144]);  mm_13 = None
    convert_element_type_76 = torch.ops.prims.convert_element_type.default(view_51, torch.float32);  view_51 = None
    neg_7 = torch.ops.aten.neg.default(convert_element_type_76)
    exp_11 = torch.ops.aten.exp.default(neg_7);  neg_7 = None
    add_32 = torch.ops.aten.add.Tensor(exp_11, 1);  exp_11 = None
    div_7 = torch.ops.aten.div.Tensor(convert_element_type_76, add_32);  convert_element_type_76 = add_32 = None
    convert_element_type_77 = torch.ops.prims.convert_element_type.default(div_7, torch.bfloat16);  div_7 = None
    view_52 = torch.ops.aten.reshape.default(convert_element_type_73, [1, 2048]);  convert_element_type_73 = None
    permute_32 = torch.ops.aten.permute.default(arg34_1, [1, 0]);  arg34_1 = None
    mm_14 = torch.ops.aten.mm.default(view_52, permute_32);  view_52 = permute_32 = None
    view_53 = torch.ops.aten.reshape.default(mm_14, [1, 1, 6144]);  mm_14 = None
    mul_46 = torch.ops.aten.mul.Tensor(convert_element_type_77, view_53);  convert_element_type_77 = view_53 = None
    view_54 = torch.ops.aten.reshape.default(mul_46, [1, 6144]);  mul_46 = None
    permute_33 = torch.ops.aten.permute.default(arg35_1, [1, 0]);  arg35_1 = None
    mm_15 = torch.ops.aten.mm.default(view_54, permute_33);  view_54 = permute_33 = None
    view_55 = torch.ops.aten.reshape.default(mm_15, [1, 1, 2048]);  mm_15 = None
    add_33 = torch.ops.aten.add.Tensor(add_29, view_55);  add_29 = view_55 = None
    convert_element_type_82 = torch.ops.prims.convert_element_type.default(add_33, torch.float32)
    pow_7 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_82, 2)
    mean_6 = torch.ops.aten.mean.dim(pow_7, [-1], True);  pow_7 = None
    add_34 = torch.ops.aten.add.Tensor(mean_6, 1e-06);  mean_6 = None
    rsqrt_10 = torch.ops.aten.rsqrt.default(add_34);  add_34 = None
    mul_47 = torch.ops.aten.mul.Tensor(convert_element_type_82, rsqrt_10);  convert_element_type_82 = rsqrt_10 = None
    convert_element_type_83 = torch.ops.prims.convert_element_type.default(arg36_1, torch.float32);  arg36_1 = None
    add_35 = torch.ops.aten.add.Tensor(convert_element_type_83, 1.0);  convert_element_type_83 = None
    mul_48 = torch.ops.aten.mul.Tensor(mul_47, add_35);  mul_47 = add_35 = None
    convert_element_type_84 = torch.ops.prims.convert_element_type.default(mul_48, torch.bfloat16);  mul_48 = None
    view_56 = torch.ops.aten.reshape.default(convert_element_type_84, [1, 2048])
    permute_34 = torch.ops.aten.permute.default(arg37_1, [1, 0]);  arg37_1 = None
    mm_16 = torch.ops.aten.mm.default(view_56, permute_34);  view_56 = permute_34 = None
    view_57 = torch.ops.aten.reshape.default(mm_16, [1, 1, 6144]);  mm_16 = None
    permute_35 = torch.ops.aten.permute.default(view_57, [0, 2, 1]);  view_57 = None
    cat_2 = torch.ops.aten.cat.default([arg41_1, permute_35], -1);  permute_35 = None
    slice_30 = torch.ops.aten.slice.Tensor(cat_2, 2, -4, 9223372036854775807)
    copy_10 = torch.ops.aten.copy.default(arg41_1, slice_30);  slice_30 = None
    convert_element_type_93 = torch.ops.prims.convert_element_type.default(cat_2, torch.float32);  cat_2 = None
    slice_31 = torch.ops.aten.slice.Tensor(convert_element_type_93, 2, 0, 2)
    squeeze_2 = torch.ops.aten.squeeze.dim(arg42_1, 1);  arg42_1 = None
    unsqueeze_24 = torch.ops.aten.unsqueeze.default(squeeze_2, 1);  squeeze_2 = None
    convert_element_type_94 = torch.ops.prims.convert_element_type.default(unsqueeze_24, torch.float32);  unsqueeze_24 = None
    select_55 = torch.ops.aten.select.int(convert_element_type_94, 1, 0)
    select_56 = torch.ops.aten.select.int(select_55, 1, 0);  select_55 = None
    view_65 = torch.ops.aten.reshape.default(select_56, [1, -1, 1]);  select_56 = None
    mul_49 = torch.ops.aten.mul.Tensor(slice_31, view_65);  slice_31 = view_65 = None
    slice_32 = torch.ops.aten.slice.Tensor(convert_element_type_93, 2, 1, 3)
    select_57 = torch.ops.aten.select.int(convert_element_type_94, 1, 0)
    select_58 = torch.ops.aten.select.int(select_57, 1, 1);  select_57 = None
    view_66 = torch.ops.aten.reshape.default(select_58, [1, -1, 1]);  select_58 = None
    mul_50 = torch.ops.aten.mul.Tensor(slice_32, view_66);  slice_32 = view_66 = None
    add_36 = torch.ops.aten.add.Tensor(mul_49, mul_50);  mul_49 = mul_50 = None
    slice_33 = torch.ops.aten.slice.Tensor(convert_element_type_93, 2, 2, 4)
    select_59 = torch.ops.aten.select.int(convert_element_type_94, 1, 0)
    select_60 = torch.ops.aten.select.int(select_59, 1, 2);  select_59 = None
    view_67 = torch.ops.aten.reshape.default(select_60, [1, -1, 1]);  select_60 = None
    mul_51 = torch.ops.aten.mul.Tensor(slice_33, view_67);  slice_33 = view_67 = None
    add_37 = torch.ops.aten.add.Tensor(add_36, mul_51);  add_36 = mul_51 = None
    slice_34 = torch.ops.aten.slice.Tensor(convert_element_type_93, 2, 3, 5);  convert_element_type_93 = None
    select_61 = torch.ops.aten.select.int(convert_element_type_94, 1, 0);  convert_element_type_94 = None
    select_62 = torch.ops.aten.select.int(select_61, 1, 3);  select_61 = None
    view_68 = torch.ops.aten.reshape.default(select_62, [1, -1, 1]);  select_62 = None
    mul_52 = torch.ops.aten.mul.Tensor(slice_34, view_68);  slice_34 = view_68 = None
    add_38 = torch.ops.aten.add.Tensor(add_37, mul_52);  add_37 = mul_52 = None
    convert_element_type_95 = torch.ops.prims.convert_element_type.default(add_38, torch.bfloat16);  add_38 = None
    slice_35 = torch.ops.aten.slice.Tensor(convert_element_type_95, 2, -1, 9223372036854775807);  convert_element_type_95 = None
    convert_element_type_96 = torch.ops.prims.convert_element_type.default(slice_35, torch.float32);  slice_35 = None
    neg_8 = torch.ops.aten.neg.default(convert_element_type_96)
    exp_12 = torch.ops.aten.exp.default(neg_8);  neg_8 = None
    add_39 = torch.ops.aten.add.Tensor(exp_12, 1);  exp_12 = None
    div_8 = torch.ops.aten.div.Tensor(convert_element_type_96, add_39);  convert_element_type_96 = add_39 = None
    convert_element_type_97 = torch.ops.prims.convert_element_type.default(div_8, torch.bfloat16);  div_8 = None
    permute_39 = torch.ops.aten.permute.default(convert_element_type_97, [0, 2, 1]);  convert_element_type_97 = None
    split_with_sizes_2 = torch.ops.aten.split_with_sizes.default(permute_39, [2048, 2048, 2048], -1);  permute_39 = None
    getitem_6 = split_with_sizes_2[0]
    getitem_7 = split_with_sizes_2[1]
    getitem_8 = split_with_sizes_2[2];  split_with_sizes_2 = None
    full_default_4 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_68 = torch.ops.aten.select.int(full_default_4, 2, 0);  select_68 = None
    view_70 = torch.ops.aten.reshape.default(getitem_7, [1, 1, -1, 128]);  getitem_7 = None
    permute_41 = torch.ops.aten.permute.default(view_70, [0, 2, 1, 3]);  view_70 = None
    convert_element_type_100 = torch.ops.prims.convert_element_type.default(permute_41, torch.float32);  permute_41 = None
    clone_13 = torch.ops.aten.clone.default(convert_element_type_100, memory_format = torch.contiguous_format);  convert_element_type_100 = None
    mul_56 = torch.ops.aten.mul.Tensor(clone_13, clone_13)
    sum_10 = torch.ops.aten.sum.dim_IntList(mul_56, [-1], True);  mul_56 = None
    add_42 = torch.ops.aten.add.Tensor(sum_10, 1e-06);  sum_10 = None
    rsqrt_12 = torch.ops.aten.rsqrt.default(add_42);  add_42 = None
    mul_57 = torch.ops.aten.mul.Tensor(clone_13, rsqrt_12);  clone_13 = rsqrt_12 = None
    select_64 = torch.ops.aten.select.int(mul_57, 2, 0);  mul_57 = None
    unsqueeze_29 = torch.ops.aten.unsqueeze.default(select_64, -1)
    view_71 = torch.ops.aten.reshape.default(getitem_8, [1, 1, -1, 128]);  getitem_8 = None
    permute_42 = torch.ops.aten.permute.default(view_71, [0, 2, 1, 3]);  view_71 = None
    convert_element_type_101 = torch.ops.prims.convert_element_type.default(permute_42, torch.float32);  permute_42 = None
    clone_14 = torch.ops.aten.clone.default(convert_element_type_101, memory_format = torch.contiguous_format);  convert_element_type_101 = None
    select_65 = torch.ops.aten.select.int(clone_14, 2, 0);  clone_14 = None
    exp_13 = torch.ops.aten.exp.default(arg43_1);  arg43_1 = None
    neg_9 = torch.ops.aten.neg.default(exp_13);  exp_13 = None
    view_63 = torch.ops.aten.reshape.default(convert_element_type_84, [1, 2048])
    permute_38 = torch.ops.aten.permute.default(arg40_1, [1, 0]);  arg40_1 = None
    mm_19 = torch.ops.aten.mm.default(view_63, permute_38);  view_63 = permute_38 = None
    view_64 = torch.ops.aten.reshape.default(mm_19, [1, 1, 16]);  mm_19 = None
    convert_element_type_98 = torch.ops.prims.convert_element_type.default(view_64, torch.float32);  view_64 = None
    add_40 = torch.ops.aten.add.Tensor(convert_element_type_98, arg44_1);  convert_element_type_98 = arg44_1 = None
    gt_2 = torch.ops.aten.gt.Scalar(add_40, 20)
    exp_14 = torch.ops.aten.exp.default(add_40)
    log1p_2 = torch.ops.aten.log1p.default(exp_14);  exp_14 = None
    where_3 = torch.ops.aten.where.self(gt_2, add_40, log1p_2);  gt_2 = add_40 = log1p_2 = None
    mul_53 = torch.ops.aten.mul.Tensor(neg_9, where_3);  neg_9 = where_3 = None
    permute_44 = torch.ops.aten.permute.default(mul_53, [0, 2, 1]);  mul_53 = None
    select_66 = torch.ops.aten.select.int(permute_44, 2, 0);  permute_44 = None
    exp_15 = torch.ops.aten.exp.default(select_66);  select_66 = None
    unsqueeze_25 = torch.ops.aten.unsqueeze.default(exp_15, 2);  exp_15 = None
    unsqueeze_26 = torch.ops.aten.unsqueeze.default(unsqueeze_25, 3);  unsqueeze_25 = None
    mul_58 = torch.ops.aten.mul.Tensor(arg45_1, unsqueeze_26);  unsqueeze_26 = None
    unsqueeze_28 = torch.ops.aten.unsqueeze.default(select_64, -1);  select_64 = None
    mul_59 = torch.ops.aten.mul.Tensor(mul_58, unsqueeze_28);  unsqueeze_28 = None
    sum_11 = torch.ops.aten.sum.dim_IntList(mul_59, [-2]);  mul_59 = None
    sub_2 = torch.ops.aten.sub.Tensor(select_65, sum_11);  select_65 = sum_11 = None
    view_61 = torch.ops.aten.reshape.default(convert_element_type_84, [1, 2048])
    permute_37 = torch.ops.aten.permute.default(arg39_1, [1, 0]);  arg39_1 = None
    mm_18 = torch.ops.aten.mm.default(view_61, permute_37);  view_61 = permute_37 = None
    view_62 = torch.ops.aten.reshape.default(mm_18, [1, 1, 16]);  mm_18 = None
    sigmoid_2 = torch.ops.aten.sigmoid.default(view_62);  view_62 = None
    permute_43 = torch.ops.aten.permute.default(sigmoid_2, [0, 2, 1]);  sigmoid_2 = None
    convert_element_type_102 = torch.ops.prims.convert_element_type.default(permute_43, torch.float32);  permute_43 = None
    clone_15 = torch.ops.aten.clone.default(convert_element_type_102, memory_format = torch.contiguous_format);  convert_element_type_102 = None
    select_67 = torch.ops.aten.select.int(clone_15, 2, 0);  clone_15 = None
    unsqueeze_27 = torch.ops.aten.unsqueeze.default(select_67, -1);  select_67 = None
    mul_60 = torch.ops.aten.mul.Tensor(sub_2, unsqueeze_27);  sub_2 = unsqueeze_27 = None
    unsqueeze_30 = torch.ops.aten.unsqueeze.default(mul_60, -2);  mul_60 = None
    mul_61 = torch.ops.aten.mul.Tensor(unsqueeze_29, unsqueeze_30);  unsqueeze_29 = unsqueeze_30 = None
    add_43 = torch.ops.aten.add.Tensor(mul_58, mul_61);  mul_58 = mul_61 = None
    view_69 = torch.ops.aten.reshape.default(getitem_6, [1, 1, -1, 128]);  getitem_6 = None
    permute_40 = torch.ops.aten.permute.default(view_69, [0, 2, 1, 3]);  view_69 = None
    convert_element_type_99 = torch.ops.prims.convert_element_type.default(permute_40, torch.float32);  permute_40 = None
    clone_12 = torch.ops.aten.clone.default(convert_element_type_99, memory_format = torch.contiguous_format);  convert_element_type_99 = None
    mul_54 = torch.ops.aten.mul.Tensor(clone_12, clone_12)
    sum_9 = torch.ops.aten.sum.dim_IntList(mul_54, [-1], True);  mul_54 = None
    add_41 = torch.ops.aten.add.Tensor(sum_9, 1e-06);  sum_9 = None
    rsqrt_11 = torch.ops.aten.rsqrt.default(add_41);  add_41 = None
    mul_55 = torch.ops.aten.mul.Tensor(clone_12, rsqrt_11);  clone_12 = rsqrt_11 = None
    div_9 = torch.ops.aten.div.Tensor(mul_55, 11.313708498984761);  mul_55 = None
    select_63 = torch.ops.aten.select.int(div_9, 2, 0);  div_9 = None
    unsqueeze_31 = torch.ops.aten.unsqueeze.default(select_63, -1);  select_63 = None
    mul_62 = torch.ops.aten.mul.Tensor(add_43, unsqueeze_31);  unsqueeze_31 = None
    sum_12 = torch.ops.aten.sum.dim_IntList(mul_62, [-2]);  mul_62 = None
    select_scatter_default_4 = torch.ops.aten.select_scatter.default(full_default_4, sum_12, 2, 0);  full_default_4 = sum_12 = None
    permute_46 = torch.ops.aten.permute.default(select_scatter_default_4, [0, 2, 1, 3]);  select_scatter_default_4 = None
    convert_element_type_103 = torch.ops.prims.convert_element_type.default(permute_46, torch.bfloat16);  permute_46 = None
    view_72 = torch.ops.aten.reshape.default(convert_element_type_103, [-1, 128]);  convert_element_type_103 = None
    convert_element_type_104 = torch.ops.prims.convert_element_type.default(view_72, torch.float32);  view_72 = None
    pow_8 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_104, 2)
    mean_7 = torch.ops.aten.mean.dim(pow_8, [-1], True);  pow_8 = None
    add_44 = torch.ops.aten.add.Tensor(mean_7, 1e-06);  mean_7 = None
    rsqrt_13 = torch.ops.aten.rsqrt.default(add_44);  add_44 = None
    mul_63 = torch.ops.aten.mul.Tensor(convert_element_type_104, rsqrt_13);  convert_element_type_104 = rsqrt_13 = None
    convert_element_type_105 = torch.ops.prims.convert_element_type.default(mul_63, torch.bfloat16);  mul_63 = None
    mul_64 = torch.ops.aten.mul.Tensor(arg46_1, convert_element_type_105);  arg46_1 = convert_element_type_105 = None
    view_58 = torch.ops.aten.reshape.default(convert_element_type_84, [1, 2048]);  convert_element_type_84 = None
    permute_36 = torch.ops.aten.permute.default(arg38_1, [1, 0]);  arg38_1 = None
    mm_17 = torch.ops.aten.mm.default(view_58, permute_36);  view_58 = permute_36 = None
    view_59 = torch.ops.aten.reshape.default(mm_17, [1, 1, 2048]);  mm_17 = None
    view_60 = torch.ops.aten.reshape.default(view_59, [1, 1, -1, 128]);  view_59 = None
    view_73 = torch.ops.aten.reshape.default(view_60, [-1, 128]);  view_60 = None
    convert_element_type_106 = torch.ops.prims.convert_element_type.default(view_73, torch.float32);  view_73 = None
    neg_10 = torch.ops.aten.neg.default(convert_element_type_106)
    exp_16 = torch.ops.aten.exp.default(neg_10);  neg_10 = None
    add_45 = torch.ops.aten.add.Tensor(exp_16, 1);  exp_16 = None
    div_10 = torch.ops.aten.div.Tensor(convert_element_type_106, add_45);  convert_element_type_106 = add_45 = None
    mul_65 = torch.ops.aten.mul.Tensor(mul_64, div_10);  mul_64 = div_10 = None
    convert_element_type_107 = torch.ops.prims.convert_element_type.default(mul_65, torch.bfloat16);  mul_65 = None
    view_74 = torch.ops.aten.reshape.default(convert_element_type_107, [1, 1, -1]);  convert_element_type_107 = None
    view_75 = torch.ops.aten.reshape.default(view_74, [1, 2048]);  view_74 = None
    permute_47 = torch.ops.aten.permute.default(arg47_1, [1, 0]);  arg47_1 = None
    mm_20 = torch.ops.aten.mm.default(view_75, permute_47);  view_75 = permute_47 = None
    view_76 = torch.ops.aten.reshape.default(mm_20, [1, 1, 2048]);  mm_20 = None
    add_46 = torch.ops.aten.add.Tensor(add_33, view_76);  add_33 = view_76 = None
    convert_element_type_110 = torch.ops.prims.convert_element_type.default(add_46, torch.float32)
    pow_9 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_110, 2)
    mean_8 = torch.ops.aten.mean.dim(pow_9, [-1], True);  pow_9 = None
    add_47 = torch.ops.aten.add.Tensor(mean_8, 1e-06);  mean_8 = None
    rsqrt_14 = torch.ops.aten.rsqrt.default(add_47);  add_47 = None
    mul_66 = torch.ops.aten.mul.Tensor(convert_element_type_110, rsqrt_14);  convert_element_type_110 = rsqrt_14 = None
    convert_element_type_111 = torch.ops.prims.convert_element_type.default(arg48_1, torch.float32);  arg48_1 = None
    add_48 = torch.ops.aten.add.Tensor(convert_element_type_111, 1.0);  convert_element_type_111 = None
    mul_67 = torch.ops.aten.mul.Tensor(mul_66, add_48);  mul_66 = add_48 = None
    convert_element_type_112 = torch.ops.prims.convert_element_type.default(mul_67, torch.bfloat16);  mul_67 = None
    view_77 = torch.ops.aten.reshape.default(convert_element_type_112, [1, 2048])
    permute_48 = torch.ops.aten.permute.default(arg49_1, [1, 0]);  arg49_1 = None
    mm_21 = torch.ops.aten.mm.default(view_77, permute_48);  view_77 = permute_48 = None
    view_78 = torch.ops.aten.reshape.default(mm_21, [1, 1, 6144]);  mm_21 = None
    convert_element_type_115 = torch.ops.prims.convert_element_type.default(view_78, torch.float32);  view_78 = None
    neg_11 = torch.ops.aten.neg.default(convert_element_type_115)
    exp_17 = torch.ops.aten.exp.default(neg_11);  neg_11 = None
    add_49 = torch.ops.aten.add.Tensor(exp_17, 1);  exp_17 = None
    div_11 = torch.ops.aten.div.Tensor(convert_element_type_115, add_49);  convert_element_type_115 = add_49 = None
    convert_element_type_116 = torch.ops.prims.convert_element_type.default(div_11, torch.bfloat16);  div_11 = None
    view_79 = torch.ops.aten.reshape.default(convert_element_type_112, [1, 2048]);  convert_element_type_112 = None
    permute_49 = torch.ops.aten.permute.default(arg50_1, [1, 0]);  arg50_1 = None
    mm_22 = torch.ops.aten.mm.default(view_79, permute_49);  view_79 = permute_49 = None
    view_80 = torch.ops.aten.reshape.default(mm_22, [1, 1, 6144]);  mm_22 = None
    mul_68 = torch.ops.aten.mul.Tensor(convert_element_type_116, view_80);  convert_element_type_116 = view_80 = None
    view_81 = torch.ops.aten.reshape.default(mul_68, [1, 6144]);  mul_68 = None
    permute_50 = torch.ops.aten.permute.default(arg51_1, [1, 0]);  arg51_1 = None
    mm_23 = torch.ops.aten.mm.default(view_81, permute_50);  view_81 = permute_50 = None
    view_82 = torch.ops.aten.reshape.default(mm_23, [1, 1, 2048]);  mm_23 = None
    add_50 = torch.ops.aten.add.Tensor(add_46, view_82);  add_46 = view_82 = None
    convert_element_type_121 = torch.ops.prims.convert_element_type.default(add_50, torch.float32)
    pow_10 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_121, 2)
    mean_9 = torch.ops.aten.mean.dim(pow_10, [-1], True);  pow_10 = None
    add_51 = torch.ops.aten.add.Tensor(mean_9, 1e-06);  mean_9 = None
    rsqrt_15 = torch.ops.aten.rsqrt.default(add_51);  add_51 = None
    mul_69 = torch.ops.aten.mul.Tensor(convert_element_type_121, rsqrt_15);  convert_element_type_121 = rsqrt_15 = None
    convert_element_type_122 = torch.ops.prims.convert_element_type.default(arg52_1, torch.float32);  arg52_1 = None
    add_52 = torch.ops.aten.add.Tensor(convert_element_type_122, 1.0);  convert_element_type_122 = None
    mul_70 = torch.ops.aten.mul.Tensor(mul_69, add_52);  mul_69 = add_52 = None
    convert_element_type_123 = torch.ops.prims.convert_element_type.default(mul_70, torch.bfloat16);  mul_70 = None
    view_83 = torch.ops.aten.reshape.default(convert_element_type_123, [1, 2048])
    permute_51 = torch.ops.aten.permute.default(arg53_1, [1, 0]);  arg53_1 = None
    mm_24 = torch.ops.aten.mm.default(view_83, permute_51);  view_83 = permute_51 = None
    view_84 = torch.ops.aten.reshape.default(mm_24, [1, 1, 4096]);  mm_24 = None
    view_85 = torch.ops.aten.reshape.default(view_84, [1, 1, -1, 512]);  view_84 = None
    split = torch.ops.aten.split.Tensor(view_85, 256, -1);  view_85 = None
    getitem_9 = split[0]
    getitem_10 = split[1];  split = None
    add_60 = torch.ops.aten.add.Tensor(arg58_1, 1)
    convert_element_type_126 = torch.ops.prims.convert_element_type.default(getitem_9, torch.float32);  getitem_9 = None
    pow_11 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_126, 2)
    mean_10 = torch.ops.aten.mean.dim(pow_11, [-1], True);  pow_11 = None
    add_53 = torch.ops.aten.add.Tensor(mean_10, 1e-06);  mean_10 = None
    rsqrt_16 = torch.ops.aten.rsqrt.default(add_53);  add_53 = None
    mul_71 = torch.ops.aten.mul.Tensor(convert_element_type_126, rsqrt_16);  convert_element_type_126 = rsqrt_16 = None
    convert_element_type_127 = torch.ops.prims.convert_element_type.default(arg54_1, torch.float32);  arg54_1 = None
    add_54 = torch.ops.aten.add.Tensor(convert_element_type_127, 1.0);  convert_element_type_127 = None
    mul_72 = torch.ops.aten.mul.Tensor(mul_71, add_54);  mul_71 = add_54 = None
    convert_element_type_128 = torch.ops.prims.convert_element_type.default(mul_72, torch.bfloat16);  mul_72 = None
    permute_52 = torch.ops.aten.permute.default(convert_element_type_128, [0, 2, 1, 3]);  convert_element_type_128 = None
    slice_36 = torch.ops.aten.slice.Tensor(permute_52, 3, 0, 64)
    select_22 = torch.ops.aten.select.int(select_scatter_default_1, 0, 0);  select_22 = None
    select_21 = torch.ops.aten.select.int(select_scatter_default_1, 0, 2)
    slice_16 = torch.ops.aten.slice.Tensor(select_21, 2, 2, 30, 3);  select_21 = None
    select_int_2 = torch.ops.aten.select.int(select_scatter_default_1, 0, 0)
    slice_scatter_default_2 = torch.ops.aten.slice_scatter.default(select_int_2, slice_16, 2, 2, 30, 3);  select_int_2 = slice_16 = None
    select_scatter_default_5 = torch.ops.aten.select_scatter.default(select_scatter_default_1, slice_scatter_default_2, 0, 0);  select_scatter_default_1 = slice_scatter_default_2 = None
    select_24 = torch.ops.aten.select.int(select_scatter_default_5, 0, 0);  select_scatter_default_5 = None
    unsqueeze_7 = torch.ops.aten.unsqueeze.default(select_24, 2);  select_24 = None
    expand_3 = torch.ops.aten.expand.default(unsqueeze_7, [1, 1, 2, 32]);  unsqueeze_7 = None
    clone_2 = torch.ops.aten.clone.default(expand_3, memory_format = torch.contiguous_format);  expand_3 = None
    view_1 = torch.ops.aten.reshape.default(clone_2, [1, 1, 64]);  clone_2 = None
    convert_element_type_2 = torch.ops.prims.convert_element_type.default(view_1, torch.bfloat16);  view_1 = None
    unsqueeze_32 = torch.ops.aten.unsqueeze.default(convert_element_type_2, 1)
    mul_75 = torch.ops.aten.mul.Tensor(slice_36, unsqueeze_32)
    slice_41 = torch.ops.aten.slice.Tensor(slice_36, 3, 32, 9223372036854775807)
    neg_12 = torch.ops.aten.neg.default(slice_41);  slice_41 = None
    slice_40 = torch.ops.aten.slice.Tensor(slice_36, 3, 0, 32);  slice_36 = None
    cat_3 = torch.ops.aten.cat.default([neg_12, slice_40], -1);  neg_12 = slice_40 = None
    select_10 = torch.ops.aten.select.int(select_scatter_default, 0, 0);  select_10 = None
    select_9 = torch.ops.aten.select.int(select_scatter_default, 0, 2)
    slice_8 = torch.ops.aten.slice.Tensor(select_9, 2, 2, 30, 3);  select_9 = None
    select_int_3 = torch.ops.aten.select.int(select_scatter_default, 0, 0)
    slice_scatter_default_3 = torch.ops.aten.slice_scatter.default(select_int_3, slice_8, 2, 2, 30, 3);  select_int_3 = slice_8 = None
    select_scatter_default_6 = torch.ops.aten.select_scatter.default(select_scatter_default, slice_scatter_default_3, 0, 0);  select_scatter_default = slice_scatter_default_3 = None
    select_12 = torch.ops.aten.select.int(select_scatter_default_6, 0, 0);  select_scatter_default_6 = None
    unsqueeze_6 = torch.ops.aten.unsqueeze.default(select_12, 2);  select_12 = None
    expand_2 = torch.ops.aten.expand.default(unsqueeze_6, [1, 1, 2, 32]);  unsqueeze_6 = None
    clone = torch.ops.aten.clone.default(expand_2, memory_format = torch.contiguous_format);  expand_2 = None
    view = torch.ops.aten.reshape.default(clone, [1, 1, 64]);  clone = None
    convert_element_type_3 = torch.ops.prims.convert_element_type.default(view, torch.bfloat16);  view = None
    unsqueeze_33 = torch.ops.aten.unsqueeze.default(convert_element_type_3, 1)
    mul_76 = torch.ops.aten.mul.Tensor(cat_3, unsqueeze_33);  cat_3 = None
    add_57 = torch.ops.aten.add.Tensor(mul_75, mul_76);  mul_75 = mul_76 = None
    slice_37 = torch.ops.aten.slice.Tensor(permute_52, 3, 64, 9223372036854775807);  permute_52 = None
    cat_5 = torch.ops.aten.cat.default([add_57, slice_37], -1);  add_57 = slice_37 = None
    expand_8 = torch.ops.aten.expand.default(cat_5, [1, 8, 1, 256]);  cat_5 = None
    view_96 = torch.ops.aten.reshape.default(expand_8, [8, 1, 256]);  expand_8 = None
    iota_1 = torch.ops.prims.iota.default(1, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    add_59 = torch.ops.aten.add.Tensor(iota_1, arg58_1);  iota_1 = None
    view_88 = torch.ops.aten.reshape.default(convert_element_type_123, [1, 2048])
    permute_53 = torch.ops.aten.permute.default(arg55_1, [1, 0]);  arg55_1 = None
    mm_25 = torch.ops.aten.mm.default(view_88, permute_53);  view_88 = permute_53 = None
    view_89 = torch.ops.aten.reshape.default(mm_25, [1, 1, 512]);  mm_25 = None
    view_90 = torch.ops.aten.reshape.default(view_89, [1, 1, -1, 256]);  view_89 = None
    convert_element_type_131 = torch.ops.prims.convert_element_type.default(view_90, torch.float32);  view_90 = None
    pow_12 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_131, 2)
    mean_11 = torch.ops.aten.mean.dim(pow_12, [-1], True);  pow_12 = None
    add_55 = torch.ops.aten.add.Tensor(mean_11, 1e-06);  mean_11 = None
    rsqrt_17 = torch.ops.aten.rsqrt.default(add_55);  add_55 = None
    mul_73 = torch.ops.aten.mul.Tensor(convert_element_type_131, rsqrt_17);  convert_element_type_131 = rsqrt_17 = None
    convert_element_type_132 = torch.ops.prims.convert_element_type.default(arg56_1, torch.float32);  arg56_1 = None
    add_56 = torch.ops.aten.add.Tensor(convert_element_type_132, 1.0);  convert_element_type_132 = None
    mul_74 = torch.ops.aten.mul.Tensor(mul_73, add_56);  mul_73 = add_56 = None
    convert_element_type_133 = torch.ops.prims.convert_element_type.default(mul_74, torch.bfloat16);  mul_74 = None
    permute_54 = torch.ops.aten.permute.default(convert_element_type_133, [0, 2, 1, 3]);  convert_element_type_133 = None
    slice_38 = torch.ops.aten.slice.Tensor(permute_54, 3, 0, 64)
    mul_77 = torch.ops.aten.mul.Tensor(slice_38, unsqueeze_32);  unsqueeze_32 = None
    slice_43 = torch.ops.aten.slice.Tensor(slice_38, 3, 32, 9223372036854775807)
    neg_13 = torch.ops.aten.neg.default(slice_43);  slice_43 = None
    slice_42 = torch.ops.aten.slice.Tensor(slice_38, 3, 0, 32);  slice_38 = None
    cat_4 = torch.ops.aten.cat.default([neg_13, slice_42], -1);  neg_13 = slice_42 = None
    mul_78 = torch.ops.aten.mul.Tensor(cat_4, unsqueeze_33);  cat_4 = unsqueeze_33 = None
    add_58 = torch.ops.aten.add.Tensor(mul_77, mul_78);  mul_77 = mul_78 = None
    slice_39 = torch.ops.aten.slice.Tensor(permute_54, 3, 64, 9223372036854775807);  permute_54 = None
    cat_6 = torch.ops.aten.cat.default([add_58, slice_39], -1);  add_58 = slice_39 = None
    index_put = torch.ops.aten.index_put_.default(arg59_1, [None, None, add_59], cat_6);  arg59_1 = cat_6 = None
    unsqueeze_36 = torch.ops.aten.unsqueeze.default(index_put, 2);  index_put = None
    expand_5 = torch.ops.aten.expand.default(unsqueeze_36, [1, 2, 4, 144, 256]);  unsqueeze_36 = None
    clone_17 = torch.ops.aten.clone.default(expand_5, memory_format = torch.contiguous_format);  expand_5 = None
    view_94 = torch.ops.aten.reshape.default(clone_17, [1, 8, 144, 256]);  clone_17 = None
    permute_57 = torch.ops.aten.permute.default(view_94, [0, 1, 3, 2]);  view_94 = None
    expand_9 = torch.ops.aten.expand.default(permute_57, [1, 8, 256, 144]);  permute_57 = None
    view_97 = torch.ops.aten.reshape.default(expand_9, [8, 256, 144]);  expand_9 = None
    bmm = torch.ops.aten.bmm.default(view_96, view_97);  view_96 = view_97 = None
    view_98 = torch.ops.aten.reshape.default(bmm, [1, 8, 1, 144]);  bmm = None
    mul_79 = torch.ops.aten.mul.Tensor(view_98, 0.0625);  view_98 = None
    iota = torch.ops.prims.iota.default(144, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze = torch.ops.aten.unsqueeze.default(iota, 0);  iota = None
    select = torch.ops.aten.select.int(arg0_1, 0, 0);  arg0_1 = None
    unsqueeze_1 = torch.ops.aten.unsqueeze.default(select, 1);  select = None
    le = torch.ops.aten.le.Tensor(unsqueeze, unsqueeze_1);  unsqueeze = unsqueeze_1 = None
    full_default_1 = torch.ops.aten.full.default([], 0.0, dtype = torch.bfloat16, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    full_default = torch.ops.aten.full.default([1, 144], -inf, dtype = torch.bfloat16, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    where = torch.ops.aten.where.self(le, full_default_1, full_default);  le = full_default_1 = full_default = None
    unsqueeze_2 = torch.ops.aten.unsqueeze.default(where, 0);  where = None
    unsqueeze_3 = torch.ops.aten.unsqueeze.default(unsqueeze_2, 1);  unsqueeze_2 = None
    add_61 = torch.ops.aten.add.Tensor(mul_79, unsqueeze_3);  mul_79 = None
    convert_element_type_138 = torch.ops.prims.convert_element_type.default(add_61, torch.float32);  add_61 = None
    amax = torch.ops.aten.amax.default(convert_element_type_138, [-1], True)
    sub_3 = torch.ops.aten.sub.Tensor(convert_element_type_138, amax);  convert_element_type_138 = amax = None
    exp_18 = torch.ops.aten.exp.default(sub_3);  sub_3 = None
    sum_13 = torch.ops.aten.sum.dim_IntList(exp_18, [-1], True)
    div_12 = torch.ops.aten.div.Tensor(exp_18, sum_13);  exp_18 = sum_13 = None
    convert_element_type_139 = torch.ops.prims.convert_element_type.default(div_12, torch.bfloat16);  div_12 = None
    expand_10 = torch.ops.aten.expand.default(convert_element_type_139, [1, 8, 1, 144]);  convert_element_type_139 = None
    view_99 = torch.ops.aten.reshape.default(expand_10, [8, 1, 144]);  expand_10 = None
    view_91 = torch.ops.aten.reshape.default(convert_element_type_123, [1, 2048]);  convert_element_type_123 = None
    permute_55 = torch.ops.aten.permute.default(arg57_1, [1, 0]);  arg57_1 = None
    mm_26 = torch.ops.aten.mm.default(view_91, permute_55);  view_91 = permute_55 = None
    view_92 = torch.ops.aten.reshape.default(mm_26, [1, 1, 512]);  mm_26 = None
    view_93 = torch.ops.aten.reshape.default(view_92, [1, 1, -1, 256]);  view_92 = None
    permute_56 = torch.ops.aten.permute.default(view_93, [0, 2, 1, 3]);  view_93 = None
    index_put_1 = torch.ops.aten.index_put_.default(arg60_1, [None, None, add_59], permute_56);  arg60_1 = add_59 = permute_56 = None
    unsqueeze_39 = torch.ops.aten.unsqueeze.default(index_put_1, 2);  index_put_1 = None
    expand_7 = torch.ops.aten.expand.default(unsqueeze_39, [1, 2, 4, 144, 256]);  unsqueeze_39 = None
    clone_18 = torch.ops.aten.clone.default(expand_7, memory_format = torch.contiguous_format);  expand_7 = None
    view_95 = torch.ops.aten.reshape.default(clone_18, [1, 8, 144, 256]);  clone_18 = None
    expand_11 = torch.ops.aten.expand.default(view_95, [1, 8, 144, 256]);  view_95 = None
    view_100 = torch.ops.aten.reshape.default(expand_11, [8, 144, 256]);  expand_11 = None
    bmm_1 = torch.ops.aten.bmm.default(view_99, view_100);  view_99 = view_100 = None
    view_101 = torch.ops.aten.reshape.default(bmm_1, [1, 8, 1, 256]);  bmm_1 = None
    permute_58 = torch.ops.aten.permute.default(view_101, [0, 2, 1, 3]);  view_101 = None
    view_102 = torch.ops.aten.reshape.default(permute_58, [1, 1, -1]);  permute_58 = None
    clone_16 = torch.ops.aten.clone.default(getitem_10, memory_format = torch.contiguous_format);  getitem_10 = None
    view_86 = torch.ops.aten.reshape.default(clone_16, [1, 1, 2048]);  clone_16 = None
    sigmoid_3 = torch.ops.aten.sigmoid.default(view_86);  view_86 = None
    mul_80 = torch.ops.aten.mul.Tensor(view_102, sigmoid_3);  view_102 = sigmoid_3 = None
    view_103 = torch.ops.aten.reshape.default(mul_80, [1, 2048]);  mul_80 = None
    permute_59 = torch.ops.aten.permute.default(arg61_1, [1, 0]);  arg61_1 = None
    mm_27 = torch.ops.aten.mm.default(view_103, permute_59);  view_103 = permute_59 = None
    view_104 = torch.ops.aten.reshape.default(mm_27, [1, 1, 2048]);  mm_27 = None
    add_62 = torch.ops.aten.add.Tensor(add_50, view_104);  add_50 = view_104 = None
    convert_element_type_144 = torch.ops.prims.convert_element_type.default(add_62, torch.float32)
    pow_13 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_144, 2)
    mean_12 = torch.ops.aten.mean.dim(pow_13, [-1], True);  pow_13 = None
    add_63 = torch.ops.aten.add.Tensor(mean_12, 1e-06);  mean_12 = None
    rsqrt_18 = torch.ops.aten.rsqrt.default(add_63);  add_63 = None
    mul_81 = torch.ops.aten.mul.Tensor(convert_element_type_144, rsqrt_18);  convert_element_type_144 = rsqrt_18 = None
    convert_element_type_145 = torch.ops.prims.convert_element_type.default(arg62_1, torch.float32);  arg62_1 = None
    add_64 = torch.ops.aten.add.Tensor(convert_element_type_145, 1.0);  convert_element_type_145 = None
    mul_82 = torch.ops.aten.mul.Tensor(mul_81, add_64);  mul_81 = add_64 = None
    convert_element_type_146 = torch.ops.prims.convert_element_type.default(mul_82, torch.bfloat16);  mul_82 = None
    view_105 = torch.ops.aten.reshape.default(convert_element_type_146, [1, 2048])
    permute_60 = torch.ops.aten.permute.default(arg63_1, [1, 0]);  arg63_1 = None
    mm_28 = torch.ops.aten.mm.default(view_105, permute_60);  view_105 = permute_60 = None
    view_106 = torch.ops.aten.reshape.default(mm_28, [1, 1, 6144]);  mm_28 = None
    convert_element_type_149 = torch.ops.prims.convert_element_type.default(view_106, torch.float32);  view_106 = None
    neg_14 = torch.ops.aten.neg.default(convert_element_type_149)
    exp_19 = torch.ops.aten.exp.default(neg_14);  neg_14 = None
    add_65 = torch.ops.aten.add.Tensor(exp_19, 1);  exp_19 = None
    div_13 = torch.ops.aten.div.Tensor(convert_element_type_149, add_65);  convert_element_type_149 = add_65 = None
    convert_element_type_150 = torch.ops.prims.convert_element_type.default(div_13, torch.bfloat16);  div_13 = None
    view_107 = torch.ops.aten.reshape.default(convert_element_type_146, [1, 2048]);  convert_element_type_146 = None
    permute_61 = torch.ops.aten.permute.default(arg64_1, [1, 0]);  arg64_1 = None
    mm_29 = torch.ops.aten.mm.default(view_107, permute_61);  view_107 = permute_61 = None
    view_108 = torch.ops.aten.reshape.default(mm_29, [1, 1, 6144]);  mm_29 = None
    mul_83 = torch.ops.aten.mul.Tensor(convert_element_type_150, view_108);  convert_element_type_150 = view_108 = None
    view_109 = torch.ops.aten.reshape.default(mul_83, [1, 6144]);  mul_83 = None
    permute_62 = torch.ops.aten.permute.default(arg65_1, [1, 0]);  arg65_1 = None
    mm_30 = torch.ops.aten.mm.default(view_109, permute_62);  view_109 = permute_62 = None
    view_110 = torch.ops.aten.reshape.default(mm_30, [1, 1, 2048]);  mm_30 = None
    add_66 = torch.ops.aten.add.Tensor(add_62, view_110);  add_62 = view_110 = None
    convert_element_type_155 = torch.ops.prims.convert_element_type.default(add_66, torch.float32)
    pow_14 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_155, 2)
    mean_13 = torch.ops.aten.mean.dim(pow_14, [-1], True);  pow_14 = None
    add_67 = torch.ops.aten.add.Tensor(mean_13, 1e-06);  mean_13 = None
    rsqrt_19 = torch.ops.aten.rsqrt.default(add_67);  add_67 = None
    mul_84 = torch.ops.aten.mul.Tensor(convert_element_type_155, rsqrt_19);  convert_element_type_155 = rsqrt_19 = None
    convert_element_type_156 = torch.ops.prims.convert_element_type.default(arg66_1, torch.float32);  arg66_1 = None
    add_68 = torch.ops.aten.add.Tensor(convert_element_type_156, 1.0);  convert_element_type_156 = None
    mul_85 = torch.ops.aten.mul.Tensor(mul_84, add_68);  mul_84 = add_68 = None
    convert_element_type_157 = torch.ops.prims.convert_element_type.default(mul_85, torch.bfloat16);  mul_85 = None
    view_111 = torch.ops.aten.reshape.default(convert_element_type_157, [1, 2048])
    permute_63 = torch.ops.aten.permute.default(arg67_1, [1, 0]);  arg67_1 = None
    mm_31 = torch.ops.aten.mm.default(view_111, permute_63);  view_111 = permute_63 = None
    view_112 = torch.ops.aten.reshape.default(mm_31, [1, 1, 6144]);  mm_31 = None
    permute_64 = torch.ops.aten.permute.default(view_112, [0, 2, 1]);  view_112 = None
    cat_7 = torch.ops.aten.cat.default([arg71_1, permute_64], -1);  permute_64 = None
    slice_44 = torch.ops.aten.slice.Tensor(cat_7, 2, -4, 9223372036854775807)
    copy_13 = torch.ops.aten.copy.default(arg71_1, slice_44);  slice_44 = None
    convert_element_type_166 = torch.ops.prims.convert_element_type.default(cat_7, torch.float32);  cat_7 = None
    slice_45 = torch.ops.aten.slice.Tensor(convert_element_type_166, 2, 0, 2)
    squeeze_3 = torch.ops.aten.squeeze.dim(arg72_1, 1);  arg72_1 = None
    unsqueeze_40 = torch.ops.aten.unsqueeze.default(squeeze_3, 1);  squeeze_3 = None
    convert_element_type_167 = torch.ops.prims.convert_element_type.default(unsqueeze_40, torch.float32);  unsqueeze_40 = None
    select_70 = torch.ops.aten.select.int(convert_element_type_167, 1, 0)
    select_71 = torch.ops.aten.select.int(select_70, 1, 0);  select_70 = None
    view_120 = torch.ops.aten.reshape.default(select_71, [1, -1, 1]);  select_71 = None
    mul_86 = torch.ops.aten.mul.Tensor(slice_45, view_120);  slice_45 = view_120 = None
    slice_46 = torch.ops.aten.slice.Tensor(convert_element_type_166, 2, 1, 3)
    select_72 = torch.ops.aten.select.int(convert_element_type_167, 1, 0)
    select_73 = torch.ops.aten.select.int(select_72, 1, 1);  select_72 = None
    view_121 = torch.ops.aten.reshape.default(select_73, [1, -1, 1]);  select_73 = None
    mul_87 = torch.ops.aten.mul.Tensor(slice_46, view_121);  slice_46 = view_121 = None
    add_69 = torch.ops.aten.add.Tensor(mul_86, mul_87);  mul_86 = mul_87 = None
    slice_47 = torch.ops.aten.slice.Tensor(convert_element_type_166, 2, 2, 4)
    select_74 = torch.ops.aten.select.int(convert_element_type_167, 1, 0)
    select_75 = torch.ops.aten.select.int(select_74, 1, 2);  select_74 = None
    view_122 = torch.ops.aten.reshape.default(select_75, [1, -1, 1]);  select_75 = None
    mul_88 = torch.ops.aten.mul.Tensor(slice_47, view_122);  slice_47 = view_122 = None
    add_70 = torch.ops.aten.add.Tensor(add_69, mul_88);  add_69 = mul_88 = None
    slice_48 = torch.ops.aten.slice.Tensor(convert_element_type_166, 2, 3, 5);  convert_element_type_166 = None
    select_76 = torch.ops.aten.select.int(convert_element_type_167, 1, 0);  convert_element_type_167 = None
    select_77 = torch.ops.aten.select.int(select_76, 1, 3);  select_76 = None
    view_123 = torch.ops.aten.reshape.default(select_77, [1, -1, 1]);  select_77 = None
    mul_89 = torch.ops.aten.mul.Tensor(slice_48, view_123);  slice_48 = view_123 = None
    add_71 = torch.ops.aten.add.Tensor(add_70, mul_89);  add_70 = mul_89 = None
    convert_element_type_168 = torch.ops.prims.convert_element_type.default(add_71, torch.bfloat16);  add_71 = None
    slice_49 = torch.ops.aten.slice.Tensor(convert_element_type_168, 2, -1, 9223372036854775807);  convert_element_type_168 = None
    convert_element_type_169 = torch.ops.prims.convert_element_type.default(slice_49, torch.float32);  slice_49 = None
    neg_15 = torch.ops.aten.neg.default(convert_element_type_169)
    exp_20 = torch.ops.aten.exp.default(neg_15);  neg_15 = None
    add_72 = torch.ops.aten.add.Tensor(exp_20, 1);  exp_20 = None
    div_14 = torch.ops.aten.div.Tensor(convert_element_type_169, add_72);  convert_element_type_169 = add_72 = None
    convert_element_type_170 = torch.ops.prims.convert_element_type.default(div_14, torch.bfloat16);  div_14 = None
    permute_68 = torch.ops.aten.permute.default(convert_element_type_170, [0, 2, 1]);  convert_element_type_170 = None
    split_with_sizes_3 = torch.ops.aten.split_with_sizes.default(permute_68, [2048, 2048, 2048], -1);  permute_68 = None
    getitem_11 = split_with_sizes_3[0]
    getitem_12 = split_with_sizes_3[1]
    getitem_13 = split_with_sizes_3[2];  split_with_sizes_3 = None
    full_default_5 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_83 = torch.ops.aten.select.int(full_default_5, 2, 0);  select_83 = None
    view_125 = torch.ops.aten.reshape.default(getitem_12, [1, 1, -1, 128]);  getitem_12 = None
    permute_70 = torch.ops.aten.permute.default(view_125, [0, 2, 1, 3]);  view_125 = None
    convert_element_type_173 = torch.ops.prims.convert_element_type.default(permute_70, torch.float32);  permute_70 = None
    clone_20 = torch.ops.aten.clone.default(convert_element_type_173, memory_format = torch.contiguous_format);  convert_element_type_173 = None
    mul_93 = torch.ops.aten.mul.Tensor(clone_20, clone_20)
    sum_15 = torch.ops.aten.sum.dim_IntList(mul_93, [-1], True);  mul_93 = None
    add_75 = torch.ops.aten.add.Tensor(sum_15, 1e-06);  sum_15 = None
    rsqrt_21 = torch.ops.aten.rsqrt.default(add_75);  add_75 = None
    mul_94 = torch.ops.aten.mul.Tensor(clone_20, rsqrt_21);  clone_20 = rsqrt_21 = None
    select_79 = torch.ops.aten.select.int(mul_94, 2, 0);  mul_94 = None
    unsqueeze_45 = torch.ops.aten.unsqueeze.default(select_79, -1)
    view_126 = torch.ops.aten.reshape.default(getitem_13, [1, 1, -1, 128]);  getitem_13 = None
    permute_71 = torch.ops.aten.permute.default(view_126, [0, 2, 1, 3]);  view_126 = None
    convert_element_type_174 = torch.ops.prims.convert_element_type.default(permute_71, torch.float32);  permute_71 = None
    clone_21 = torch.ops.aten.clone.default(convert_element_type_174, memory_format = torch.contiguous_format);  convert_element_type_174 = None
    select_80 = torch.ops.aten.select.int(clone_21, 2, 0);  clone_21 = None
    exp_21 = torch.ops.aten.exp.default(arg73_1);  arg73_1 = None
    neg_16 = torch.ops.aten.neg.default(exp_21);  exp_21 = None
    view_118 = torch.ops.aten.reshape.default(convert_element_type_157, [1, 2048])
    permute_67 = torch.ops.aten.permute.default(arg70_1, [1, 0]);  arg70_1 = None
    mm_34 = torch.ops.aten.mm.default(view_118, permute_67);  view_118 = permute_67 = None
    view_119 = torch.ops.aten.reshape.default(mm_34, [1, 1, 16]);  mm_34 = None
    convert_element_type_171 = torch.ops.prims.convert_element_type.default(view_119, torch.float32);  view_119 = None
    add_73 = torch.ops.aten.add.Tensor(convert_element_type_171, arg74_1);  convert_element_type_171 = arg74_1 = None
    gt_3 = torch.ops.aten.gt.Scalar(add_73, 20)
    exp_22 = torch.ops.aten.exp.default(add_73)
    log1p_3 = torch.ops.aten.log1p.default(exp_22);  exp_22 = None
    where_4 = torch.ops.aten.where.self(gt_3, add_73, log1p_3);  gt_3 = add_73 = log1p_3 = None
    mul_90 = torch.ops.aten.mul.Tensor(neg_16, where_4);  neg_16 = where_4 = None
    permute_73 = torch.ops.aten.permute.default(mul_90, [0, 2, 1]);  mul_90 = None
    select_81 = torch.ops.aten.select.int(permute_73, 2, 0);  permute_73 = None
    exp_23 = torch.ops.aten.exp.default(select_81);  select_81 = None
    unsqueeze_41 = torch.ops.aten.unsqueeze.default(exp_23, 2);  exp_23 = None
    unsqueeze_42 = torch.ops.aten.unsqueeze.default(unsqueeze_41, 3);  unsqueeze_41 = None
    mul_95 = torch.ops.aten.mul.Tensor(arg75_1, unsqueeze_42);  unsqueeze_42 = None
    unsqueeze_44 = torch.ops.aten.unsqueeze.default(select_79, -1);  select_79 = None
    mul_96 = torch.ops.aten.mul.Tensor(mul_95, unsqueeze_44);  unsqueeze_44 = None
    sum_16 = torch.ops.aten.sum.dim_IntList(mul_96, [-2]);  mul_96 = None
    sub_4 = torch.ops.aten.sub.Tensor(select_80, sum_16);  select_80 = sum_16 = None
    view_116 = torch.ops.aten.reshape.default(convert_element_type_157, [1, 2048])
    permute_66 = torch.ops.aten.permute.default(arg69_1, [1, 0]);  arg69_1 = None
    mm_33 = torch.ops.aten.mm.default(view_116, permute_66);  view_116 = permute_66 = None
    view_117 = torch.ops.aten.reshape.default(mm_33, [1, 1, 16]);  mm_33 = None
    sigmoid_4 = torch.ops.aten.sigmoid.default(view_117);  view_117 = None
    permute_72 = torch.ops.aten.permute.default(sigmoid_4, [0, 2, 1]);  sigmoid_4 = None
    convert_element_type_175 = torch.ops.prims.convert_element_type.default(permute_72, torch.float32);  permute_72 = None
    clone_22 = torch.ops.aten.clone.default(convert_element_type_175, memory_format = torch.contiguous_format);  convert_element_type_175 = None
    select_82 = torch.ops.aten.select.int(clone_22, 2, 0);  clone_22 = None
    unsqueeze_43 = torch.ops.aten.unsqueeze.default(select_82, -1);  select_82 = None
    mul_97 = torch.ops.aten.mul.Tensor(sub_4, unsqueeze_43);  sub_4 = unsqueeze_43 = None
    unsqueeze_46 = torch.ops.aten.unsqueeze.default(mul_97, -2);  mul_97 = None
    mul_98 = torch.ops.aten.mul.Tensor(unsqueeze_45, unsqueeze_46);  unsqueeze_45 = unsqueeze_46 = None
    add_76 = torch.ops.aten.add.Tensor(mul_95, mul_98);  mul_95 = mul_98 = None
    view_124 = torch.ops.aten.reshape.default(getitem_11, [1, 1, -1, 128]);  getitem_11 = None
    permute_69 = torch.ops.aten.permute.default(view_124, [0, 2, 1, 3]);  view_124 = None
    convert_element_type_172 = torch.ops.prims.convert_element_type.default(permute_69, torch.float32);  permute_69 = None
    clone_19 = torch.ops.aten.clone.default(convert_element_type_172, memory_format = torch.contiguous_format);  convert_element_type_172 = None
    mul_91 = torch.ops.aten.mul.Tensor(clone_19, clone_19)
    sum_14 = torch.ops.aten.sum.dim_IntList(mul_91, [-1], True);  mul_91 = None
    add_74 = torch.ops.aten.add.Tensor(sum_14, 1e-06);  sum_14 = None
    rsqrt_20 = torch.ops.aten.rsqrt.default(add_74);  add_74 = None
    mul_92 = torch.ops.aten.mul.Tensor(clone_19, rsqrt_20);  clone_19 = rsqrt_20 = None
    div_15 = torch.ops.aten.div.Tensor(mul_92, 11.313708498984761);  mul_92 = None
    select_78 = torch.ops.aten.select.int(div_15, 2, 0);  div_15 = None
    unsqueeze_47 = torch.ops.aten.unsqueeze.default(select_78, -1);  select_78 = None
    mul_99 = torch.ops.aten.mul.Tensor(add_76, unsqueeze_47);  unsqueeze_47 = None
    sum_17 = torch.ops.aten.sum.dim_IntList(mul_99, [-2]);  mul_99 = None
    select_scatter_default_7 = torch.ops.aten.select_scatter.default(full_default_5, sum_17, 2, 0);  full_default_5 = sum_17 = None
    permute_75 = torch.ops.aten.permute.default(select_scatter_default_7, [0, 2, 1, 3]);  select_scatter_default_7 = None
    convert_element_type_176 = torch.ops.prims.convert_element_type.default(permute_75, torch.bfloat16);  permute_75 = None
    view_127 = torch.ops.aten.reshape.default(convert_element_type_176, [-1, 128]);  convert_element_type_176 = None
    convert_element_type_177 = torch.ops.prims.convert_element_type.default(view_127, torch.float32);  view_127 = None
    pow_15 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_177, 2)
    mean_14 = torch.ops.aten.mean.dim(pow_15, [-1], True);  pow_15 = None
    add_77 = torch.ops.aten.add.Tensor(mean_14, 1e-06);  mean_14 = None
    rsqrt_22 = torch.ops.aten.rsqrt.default(add_77);  add_77 = None
    mul_100 = torch.ops.aten.mul.Tensor(convert_element_type_177, rsqrt_22);  convert_element_type_177 = rsqrt_22 = None
    convert_element_type_178 = torch.ops.prims.convert_element_type.default(mul_100, torch.bfloat16);  mul_100 = None
    mul_101 = torch.ops.aten.mul.Tensor(arg76_1, convert_element_type_178);  arg76_1 = convert_element_type_178 = None
    view_113 = torch.ops.aten.reshape.default(convert_element_type_157, [1, 2048]);  convert_element_type_157 = None
    permute_65 = torch.ops.aten.permute.default(arg68_1, [1, 0]);  arg68_1 = None
    mm_32 = torch.ops.aten.mm.default(view_113, permute_65);  view_113 = permute_65 = None
    view_114 = torch.ops.aten.reshape.default(mm_32, [1, 1, 2048]);  mm_32 = None
    view_115 = torch.ops.aten.reshape.default(view_114, [1, 1, -1, 128]);  view_114 = None
    view_128 = torch.ops.aten.reshape.default(view_115, [-1, 128]);  view_115 = None
    convert_element_type_179 = torch.ops.prims.convert_element_type.default(view_128, torch.float32);  view_128 = None
    neg_17 = torch.ops.aten.neg.default(convert_element_type_179)
    exp_24 = torch.ops.aten.exp.default(neg_17);  neg_17 = None
    add_78 = torch.ops.aten.add.Tensor(exp_24, 1);  exp_24 = None
    div_16 = torch.ops.aten.div.Tensor(convert_element_type_179, add_78);  convert_element_type_179 = add_78 = None
    mul_102 = torch.ops.aten.mul.Tensor(mul_101, div_16);  mul_101 = div_16 = None
    convert_element_type_180 = torch.ops.prims.convert_element_type.default(mul_102, torch.bfloat16);  mul_102 = None
    view_129 = torch.ops.aten.reshape.default(convert_element_type_180, [1, 1, -1]);  convert_element_type_180 = None
    view_130 = torch.ops.aten.reshape.default(view_129, [1, 2048]);  view_129 = None
    permute_76 = torch.ops.aten.permute.default(arg77_1, [1, 0]);  arg77_1 = None
    mm_35 = torch.ops.aten.mm.default(view_130, permute_76);  view_130 = permute_76 = None
    view_131 = torch.ops.aten.reshape.default(mm_35, [1, 1, 2048]);  mm_35 = None
    add_79 = torch.ops.aten.add.Tensor(add_66, view_131);  add_66 = view_131 = None
    convert_element_type_183 = torch.ops.prims.convert_element_type.default(add_79, torch.float32)
    pow_16 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_183, 2)
    mean_15 = torch.ops.aten.mean.dim(pow_16, [-1], True);  pow_16 = None
    add_80 = torch.ops.aten.add.Tensor(mean_15, 1e-06);  mean_15 = None
    rsqrt_23 = torch.ops.aten.rsqrt.default(add_80);  add_80 = None
    mul_103 = torch.ops.aten.mul.Tensor(convert_element_type_183, rsqrt_23);  convert_element_type_183 = rsqrt_23 = None
    convert_element_type_184 = torch.ops.prims.convert_element_type.default(arg78_1, torch.float32);  arg78_1 = None
    add_81 = torch.ops.aten.add.Tensor(convert_element_type_184, 1.0);  convert_element_type_184 = None
    mul_104 = torch.ops.aten.mul.Tensor(mul_103, add_81);  mul_103 = add_81 = None
    convert_element_type_185 = torch.ops.prims.convert_element_type.default(mul_104, torch.bfloat16);  mul_104 = None
    view_132 = torch.ops.aten.reshape.default(convert_element_type_185, [1, 2048])
    permute_77 = torch.ops.aten.permute.default(arg79_1, [1, 0]);  arg79_1 = None
    mm_36 = torch.ops.aten.mm.default(view_132, permute_77);  view_132 = permute_77 = None
    view_133 = torch.ops.aten.reshape.default(mm_36, [1, 1, 6144]);  mm_36 = None
    convert_element_type_188 = torch.ops.prims.convert_element_type.default(view_133, torch.float32);  view_133 = None
    neg_18 = torch.ops.aten.neg.default(convert_element_type_188)
    exp_25 = torch.ops.aten.exp.default(neg_18);  neg_18 = None
    add_82 = torch.ops.aten.add.Tensor(exp_25, 1);  exp_25 = None
    div_17 = torch.ops.aten.div.Tensor(convert_element_type_188, add_82);  convert_element_type_188 = add_82 = None
    convert_element_type_189 = torch.ops.prims.convert_element_type.default(div_17, torch.bfloat16);  div_17 = None
    view_134 = torch.ops.aten.reshape.default(convert_element_type_185, [1, 2048]);  convert_element_type_185 = None
    permute_78 = torch.ops.aten.permute.default(arg80_1, [1, 0]);  arg80_1 = None
    mm_37 = torch.ops.aten.mm.default(view_134, permute_78);  view_134 = permute_78 = None
    view_135 = torch.ops.aten.reshape.default(mm_37, [1, 1, 6144]);  mm_37 = None
    mul_105 = torch.ops.aten.mul.Tensor(convert_element_type_189, view_135);  convert_element_type_189 = view_135 = None
    view_136 = torch.ops.aten.reshape.default(mul_105, [1, 6144]);  mul_105 = None
    permute_79 = torch.ops.aten.permute.default(arg81_1, [1, 0]);  arg81_1 = None
    mm_38 = torch.ops.aten.mm.default(view_136, permute_79);  view_136 = permute_79 = None
    view_137 = torch.ops.aten.reshape.default(mm_38, [1, 1, 2048]);  mm_38 = None
    add_83 = torch.ops.aten.add.Tensor(add_79, view_137);  add_79 = view_137 = None
    convert_element_type_194 = torch.ops.prims.convert_element_type.default(add_83, torch.float32)
    pow_17 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_194, 2)
    mean_16 = torch.ops.aten.mean.dim(pow_17, [-1], True);  pow_17 = None
    add_84 = torch.ops.aten.add.Tensor(mean_16, 1e-06);  mean_16 = None
    rsqrt_24 = torch.ops.aten.rsqrt.default(add_84);  add_84 = None
    mul_106 = torch.ops.aten.mul.Tensor(convert_element_type_194, rsqrt_24);  convert_element_type_194 = rsqrt_24 = None
    convert_element_type_195 = torch.ops.prims.convert_element_type.default(arg82_1, torch.float32);  arg82_1 = None
    add_85 = torch.ops.aten.add.Tensor(convert_element_type_195, 1.0);  convert_element_type_195 = None
    mul_107 = torch.ops.aten.mul.Tensor(mul_106, add_85);  mul_106 = add_85 = None
    convert_element_type_196 = torch.ops.prims.convert_element_type.default(mul_107, torch.bfloat16);  mul_107 = None
    view_138 = torch.ops.aten.reshape.default(convert_element_type_196, [1, 2048])
    permute_80 = torch.ops.aten.permute.default(arg83_1, [1, 0]);  arg83_1 = None
    mm_39 = torch.ops.aten.mm.default(view_138, permute_80);  view_138 = permute_80 = None
    view_139 = torch.ops.aten.reshape.default(mm_39, [1, 1, 6144]);  mm_39 = None
    permute_81 = torch.ops.aten.permute.default(view_139, [0, 2, 1]);  view_139 = None
    cat_8 = torch.ops.aten.cat.default([arg87_1, permute_81], -1);  permute_81 = None
    slice_50 = torch.ops.aten.slice.Tensor(cat_8, 2, -4, 9223372036854775807)
    copy_16 = torch.ops.aten.copy.default(arg87_1, slice_50);  slice_50 = None
    convert_element_type_205 = torch.ops.prims.convert_element_type.default(cat_8, torch.float32);  cat_8 = None
    slice_51 = torch.ops.aten.slice.Tensor(convert_element_type_205, 2, 0, 2)
    squeeze_4 = torch.ops.aten.squeeze.dim(arg88_1, 1);  arg88_1 = None
    unsqueeze_48 = torch.ops.aten.unsqueeze.default(squeeze_4, 1);  squeeze_4 = None
    convert_element_type_206 = torch.ops.prims.convert_element_type.default(unsqueeze_48, torch.float32);  unsqueeze_48 = None
    select_85 = torch.ops.aten.select.int(convert_element_type_206, 1, 0)
    select_86 = torch.ops.aten.select.int(select_85, 1, 0);  select_85 = None
    view_147 = torch.ops.aten.reshape.default(select_86, [1, -1, 1]);  select_86 = None
    mul_108 = torch.ops.aten.mul.Tensor(slice_51, view_147);  slice_51 = view_147 = None
    slice_52 = torch.ops.aten.slice.Tensor(convert_element_type_205, 2, 1, 3)
    select_87 = torch.ops.aten.select.int(convert_element_type_206, 1, 0)
    select_88 = torch.ops.aten.select.int(select_87, 1, 1);  select_87 = None
    view_148 = torch.ops.aten.reshape.default(select_88, [1, -1, 1]);  select_88 = None
    mul_109 = torch.ops.aten.mul.Tensor(slice_52, view_148);  slice_52 = view_148 = None
    add_86 = torch.ops.aten.add.Tensor(mul_108, mul_109);  mul_108 = mul_109 = None
    slice_53 = torch.ops.aten.slice.Tensor(convert_element_type_205, 2, 2, 4)
    select_89 = torch.ops.aten.select.int(convert_element_type_206, 1, 0)
    select_90 = torch.ops.aten.select.int(select_89, 1, 2);  select_89 = None
    view_149 = torch.ops.aten.reshape.default(select_90, [1, -1, 1]);  select_90 = None
    mul_110 = torch.ops.aten.mul.Tensor(slice_53, view_149);  slice_53 = view_149 = None
    add_87 = torch.ops.aten.add.Tensor(add_86, mul_110);  add_86 = mul_110 = None
    slice_54 = torch.ops.aten.slice.Tensor(convert_element_type_205, 2, 3, 5);  convert_element_type_205 = None
    select_91 = torch.ops.aten.select.int(convert_element_type_206, 1, 0);  convert_element_type_206 = None
    select_92 = torch.ops.aten.select.int(select_91, 1, 3);  select_91 = None
    view_150 = torch.ops.aten.reshape.default(select_92, [1, -1, 1]);  select_92 = None
    mul_111 = torch.ops.aten.mul.Tensor(slice_54, view_150);  slice_54 = view_150 = None
    add_88 = torch.ops.aten.add.Tensor(add_87, mul_111);  add_87 = mul_111 = None
    convert_element_type_207 = torch.ops.prims.convert_element_type.default(add_88, torch.bfloat16);  add_88 = None
    slice_55 = torch.ops.aten.slice.Tensor(convert_element_type_207, 2, -1, 9223372036854775807);  convert_element_type_207 = None
    convert_element_type_208 = torch.ops.prims.convert_element_type.default(slice_55, torch.float32);  slice_55 = None
    neg_19 = torch.ops.aten.neg.default(convert_element_type_208)
    exp_26 = torch.ops.aten.exp.default(neg_19);  neg_19 = None
    add_89 = torch.ops.aten.add.Tensor(exp_26, 1);  exp_26 = None
    div_18 = torch.ops.aten.div.Tensor(convert_element_type_208, add_89);  convert_element_type_208 = add_89 = None
    convert_element_type_209 = torch.ops.prims.convert_element_type.default(div_18, torch.bfloat16);  div_18 = None
    permute_85 = torch.ops.aten.permute.default(convert_element_type_209, [0, 2, 1]);  convert_element_type_209 = None
    split_with_sizes_4 = torch.ops.aten.split_with_sizes.default(permute_85, [2048, 2048, 2048], -1);  permute_85 = None
    getitem_14 = split_with_sizes_4[0]
    getitem_15 = split_with_sizes_4[1]
    getitem_16 = split_with_sizes_4[2];  split_with_sizes_4 = None
    full_default_6 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_98 = torch.ops.aten.select.int(full_default_6, 2, 0);  select_98 = None
    view_152 = torch.ops.aten.reshape.default(getitem_15, [1, 1, -1, 128]);  getitem_15 = None
    permute_87 = torch.ops.aten.permute.default(view_152, [0, 2, 1, 3]);  view_152 = None
    convert_element_type_212 = torch.ops.prims.convert_element_type.default(permute_87, torch.float32);  permute_87 = None
    clone_24 = torch.ops.aten.clone.default(convert_element_type_212, memory_format = torch.contiguous_format);  convert_element_type_212 = None
    mul_115 = torch.ops.aten.mul.Tensor(clone_24, clone_24)
    sum_19 = torch.ops.aten.sum.dim_IntList(mul_115, [-1], True);  mul_115 = None
    add_92 = torch.ops.aten.add.Tensor(sum_19, 1e-06);  sum_19 = None
    rsqrt_26 = torch.ops.aten.rsqrt.default(add_92);  add_92 = None
    mul_116 = torch.ops.aten.mul.Tensor(clone_24, rsqrt_26);  clone_24 = rsqrt_26 = None
    select_94 = torch.ops.aten.select.int(mul_116, 2, 0);  mul_116 = None
    unsqueeze_53 = torch.ops.aten.unsqueeze.default(select_94, -1)
    view_153 = torch.ops.aten.reshape.default(getitem_16, [1, 1, -1, 128]);  getitem_16 = None
    permute_88 = torch.ops.aten.permute.default(view_153, [0, 2, 1, 3]);  view_153 = None
    convert_element_type_213 = torch.ops.prims.convert_element_type.default(permute_88, torch.float32);  permute_88 = None
    clone_25 = torch.ops.aten.clone.default(convert_element_type_213, memory_format = torch.contiguous_format);  convert_element_type_213 = None
    select_95 = torch.ops.aten.select.int(clone_25, 2, 0);  clone_25 = None
    exp_27 = torch.ops.aten.exp.default(arg89_1);  arg89_1 = None
    neg_20 = torch.ops.aten.neg.default(exp_27);  exp_27 = None
    view_145 = torch.ops.aten.reshape.default(convert_element_type_196, [1, 2048])
    permute_84 = torch.ops.aten.permute.default(arg86_1, [1, 0]);  arg86_1 = None
    mm_42 = torch.ops.aten.mm.default(view_145, permute_84);  view_145 = permute_84 = None
    view_146 = torch.ops.aten.reshape.default(mm_42, [1, 1, 16]);  mm_42 = None
    convert_element_type_210 = torch.ops.prims.convert_element_type.default(view_146, torch.float32);  view_146 = None
    add_90 = torch.ops.aten.add.Tensor(convert_element_type_210, arg90_1);  convert_element_type_210 = arg90_1 = None
    gt_4 = torch.ops.aten.gt.Scalar(add_90, 20)
    exp_28 = torch.ops.aten.exp.default(add_90)
    log1p_4 = torch.ops.aten.log1p.default(exp_28);  exp_28 = None
    where_5 = torch.ops.aten.where.self(gt_4, add_90, log1p_4);  gt_4 = add_90 = log1p_4 = None
    mul_112 = torch.ops.aten.mul.Tensor(neg_20, where_5);  neg_20 = where_5 = None
    permute_90 = torch.ops.aten.permute.default(mul_112, [0, 2, 1]);  mul_112 = None
    select_96 = torch.ops.aten.select.int(permute_90, 2, 0);  permute_90 = None
    exp_29 = torch.ops.aten.exp.default(select_96);  select_96 = None
    unsqueeze_49 = torch.ops.aten.unsqueeze.default(exp_29, 2);  exp_29 = None
    unsqueeze_50 = torch.ops.aten.unsqueeze.default(unsqueeze_49, 3);  unsqueeze_49 = None
    mul_117 = torch.ops.aten.mul.Tensor(arg91_1, unsqueeze_50);  unsqueeze_50 = None
    unsqueeze_52 = torch.ops.aten.unsqueeze.default(select_94, -1);  select_94 = None
    mul_118 = torch.ops.aten.mul.Tensor(mul_117, unsqueeze_52);  unsqueeze_52 = None
    sum_20 = torch.ops.aten.sum.dim_IntList(mul_118, [-2]);  mul_118 = None
    sub_5 = torch.ops.aten.sub.Tensor(select_95, sum_20);  select_95 = sum_20 = None
    view_143 = torch.ops.aten.reshape.default(convert_element_type_196, [1, 2048])
    permute_83 = torch.ops.aten.permute.default(arg85_1, [1, 0]);  arg85_1 = None
    mm_41 = torch.ops.aten.mm.default(view_143, permute_83);  view_143 = permute_83 = None
    view_144 = torch.ops.aten.reshape.default(mm_41, [1, 1, 16]);  mm_41 = None
    sigmoid_5 = torch.ops.aten.sigmoid.default(view_144);  view_144 = None
    permute_89 = torch.ops.aten.permute.default(sigmoid_5, [0, 2, 1]);  sigmoid_5 = None
    convert_element_type_214 = torch.ops.prims.convert_element_type.default(permute_89, torch.float32);  permute_89 = None
    clone_26 = torch.ops.aten.clone.default(convert_element_type_214, memory_format = torch.contiguous_format);  convert_element_type_214 = None
    select_97 = torch.ops.aten.select.int(clone_26, 2, 0);  clone_26 = None
    unsqueeze_51 = torch.ops.aten.unsqueeze.default(select_97, -1);  select_97 = None
    mul_119 = torch.ops.aten.mul.Tensor(sub_5, unsqueeze_51);  sub_5 = unsqueeze_51 = None
    unsqueeze_54 = torch.ops.aten.unsqueeze.default(mul_119, -2);  mul_119 = None
    mul_120 = torch.ops.aten.mul.Tensor(unsqueeze_53, unsqueeze_54);  unsqueeze_53 = unsqueeze_54 = None
    add_93 = torch.ops.aten.add.Tensor(mul_117, mul_120);  mul_117 = mul_120 = None
    view_151 = torch.ops.aten.reshape.default(getitem_14, [1, 1, -1, 128]);  getitem_14 = None
    permute_86 = torch.ops.aten.permute.default(view_151, [0, 2, 1, 3]);  view_151 = None
    convert_element_type_211 = torch.ops.prims.convert_element_type.default(permute_86, torch.float32);  permute_86 = None
    clone_23 = torch.ops.aten.clone.default(convert_element_type_211, memory_format = torch.contiguous_format);  convert_element_type_211 = None
    mul_113 = torch.ops.aten.mul.Tensor(clone_23, clone_23)
    sum_18 = torch.ops.aten.sum.dim_IntList(mul_113, [-1], True);  mul_113 = None
    add_91 = torch.ops.aten.add.Tensor(sum_18, 1e-06);  sum_18 = None
    rsqrt_25 = torch.ops.aten.rsqrt.default(add_91);  add_91 = None
    mul_114 = torch.ops.aten.mul.Tensor(clone_23, rsqrt_25);  clone_23 = rsqrt_25 = None
    div_19 = torch.ops.aten.div.Tensor(mul_114, 11.313708498984761);  mul_114 = None
    select_93 = torch.ops.aten.select.int(div_19, 2, 0);  div_19 = None
    unsqueeze_55 = torch.ops.aten.unsqueeze.default(select_93, -1);  select_93 = None
    mul_121 = torch.ops.aten.mul.Tensor(add_93, unsqueeze_55);  unsqueeze_55 = None
    sum_21 = torch.ops.aten.sum.dim_IntList(mul_121, [-2]);  mul_121 = None
    select_scatter_default_8 = torch.ops.aten.select_scatter.default(full_default_6, sum_21, 2, 0);  full_default_6 = sum_21 = None
    permute_92 = torch.ops.aten.permute.default(select_scatter_default_8, [0, 2, 1, 3]);  select_scatter_default_8 = None
    convert_element_type_215 = torch.ops.prims.convert_element_type.default(permute_92, torch.bfloat16);  permute_92 = None
    view_154 = torch.ops.aten.reshape.default(convert_element_type_215, [-1, 128]);  convert_element_type_215 = None
    convert_element_type_216 = torch.ops.prims.convert_element_type.default(view_154, torch.float32);  view_154 = None
    pow_18 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_216, 2)
    mean_17 = torch.ops.aten.mean.dim(pow_18, [-1], True);  pow_18 = None
    add_94 = torch.ops.aten.add.Tensor(mean_17, 1e-06);  mean_17 = None
    rsqrt_27 = torch.ops.aten.rsqrt.default(add_94);  add_94 = None
    mul_122 = torch.ops.aten.mul.Tensor(convert_element_type_216, rsqrt_27);  convert_element_type_216 = rsqrt_27 = None
    convert_element_type_217 = torch.ops.prims.convert_element_type.default(mul_122, torch.bfloat16);  mul_122 = None
    mul_123 = torch.ops.aten.mul.Tensor(arg92_1, convert_element_type_217);  arg92_1 = convert_element_type_217 = None
    view_140 = torch.ops.aten.reshape.default(convert_element_type_196, [1, 2048]);  convert_element_type_196 = None
    permute_82 = torch.ops.aten.permute.default(arg84_1, [1, 0]);  arg84_1 = None
    mm_40 = torch.ops.aten.mm.default(view_140, permute_82);  view_140 = permute_82 = None
    view_141 = torch.ops.aten.reshape.default(mm_40, [1, 1, 2048]);  mm_40 = None
    view_142 = torch.ops.aten.reshape.default(view_141, [1, 1, -1, 128]);  view_141 = None
    view_155 = torch.ops.aten.reshape.default(view_142, [-1, 128]);  view_142 = None
    convert_element_type_218 = torch.ops.prims.convert_element_type.default(view_155, torch.float32);  view_155 = None
    neg_21 = torch.ops.aten.neg.default(convert_element_type_218)
    exp_30 = torch.ops.aten.exp.default(neg_21);  neg_21 = None
    add_95 = torch.ops.aten.add.Tensor(exp_30, 1);  exp_30 = None
    div_20 = torch.ops.aten.div.Tensor(convert_element_type_218, add_95);  convert_element_type_218 = add_95 = None
    mul_124 = torch.ops.aten.mul.Tensor(mul_123, div_20);  mul_123 = div_20 = None
    convert_element_type_219 = torch.ops.prims.convert_element_type.default(mul_124, torch.bfloat16);  mul_124 = None
    view_156 = torch.ops.aten.reshape.default(convert_element_type_219, [1, 1, -1]);  convert_element_type_219 = None
    view_157 = torch.ops.aten.reshape.default(view_156, [1, 2048]);  view_156 = None
    permute_93 = torch.ops.aten.permute.default(arg93_1, [1, 0]);  arg93_1 = None
    mm_43 = torch.ops.aten.mm.default(view_157, permute_93);  view_157 = permute_93 = None
    view_158 = torch.ops.aten.reshape.default(mm_43, [1, 1, 2048]);  mm_43 = None
    add_96 = torch.ops.aten.add.Tensor(add_83, view_158);  add_83 = view_158 = None
    convert_element_type_222 = torch.ops.prims.convert_element_type.default(add_96, torch.float32)
    pow_19 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_222, 2)
    mean_18 = torch.ops.aten.mean.dim(pow_19, [-1], True);  pow_19 = None
    add_97 = torch.ops.aten.add.Tensor(mean_18, 1e-06);  mean_18 = None
    rsqrt_28 = torch.ops.aten.rsqrt.default(add_97);  add_97 = None
    mul_125 = torch.ops.aten.mul.Tensor(convert_element_type_222, rsqrt_28);  convert_element_type_222 = rsqrt_28 = None
    convert_element_type_223 = torch.ops.prims.convert_element_type.default(arg94_1, torch.float32);  arg94_1 = None
    add_98 = torch.ops.aten.add.Tensor(convert_element_type_223, 1.0);  convert_element_type_223 = None
    mul_126 = torch.ops.aten.mul.Tensor(mul_125, add_98);  mul_125 = add_98 = None
    convert_element_type_224 = torch.ops.prims.convert_element_type.default(mul_126, torch.bfloat16);  mul_126 = None
    view_159 = torch.ops.aten.reshape.default(convert_element_type_224, [1, 2048])
    permute_94 = torch.ops.aten.permute.default(arg95_1, [1, 0]);  arg95_1 = None
    mm_44 = torch.ops.aten.mm.default(view_159, permute_94);  view_159 = permute_94 = None
    view_160 = torch.ops.aten.reshape.default(mm_44, [1, 1, 6144]);  mm_44 = None
    convert_element_type_227 = torch.ops.prims.convert_element_type.default(view_160, torch.float32);  view_160 = None
    neg_22 = torch.ops.aten.neg.default(convert_element_type_227)
    exp_31 = torch.ops.aten.exp.default(neg_22);  neg_22 = None
    add_99 = torch.ops.aten.add.Tensor(exp_31, 1);  exp_31 = None
    div_21 = torch.ops.aten.div.Tensor(convert_element_type_227, add_99);  convert_element_type_227 = add_99 = None
    convert_element_type_228 = torch.ops.prims.convert_element_type.default(div_21, torch.bfloat16);  div_21 = None
    view_161 = torch.ops.aten.reshape.default(convert_element_type_224, [1, 2048]);  convert_element_type_224 = None
    permute_95 = torch.ops.aten.permute.default(arg96_1, [1, 0]);  arg96_1 = None
    mm_45 = torch.ops.aten.mm.default(view_161, permute_95);  view_161 = permute_95 = None
    view_162 = torch.ops.aten.reshape.default(mm_45, [1, 1, 6144]);  mm_45 = None
    mul_127 = torch.ops.aten.mul.Tensor(convert_element_type_228, view_162);  convert_element_type_228 = view_162 = None
    view_163 = torch.ops.aten.reshape.default(mul_127, [1, 6144]);  mul_127 = None
    permute_96 = torch.ops.aten.permute.default(arg97_1, [1, 0]);  arg97_1 = None
    mm_46 = torch.ops.aten.mm.default(view_163, permute_96);  view_163 = permute_96 = None
    view_164 = torch.ops.aten.reshape.default(mm_46, [1, 1, 2048]);  mm_46 = None
    add_100 = torch.ops.aten.add.Tensor(add_96, view_164);  add_96 = view_164 = None
    convert_element_type_233 = torch.ops.prims.convert_element_type.default(add_100, torch.float32)
    pow_20 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_233, 2)
    mean_19 = torch.ops.aten.mean.dim(pow_20, [-1], True);  pow_20 = None
    add_101 = torch.ops.aten.add.Tensor(mean_19, 1e-06);  mean_19 = None
    rsqrt_29 = torch.ops.aten.rsqrt.default(add_101);  add_101 = None
    mul_128 = torch.ops.aten.mul.Tensor(convert_element_type_233, rsqrt_29);  convert_element_type_233 = rsqrt_29 = None
    convert_element_type_234 = torch.ops.prims.convert_element_type.default(arg98_1, torch.float32);  arg98_1 = None
    add_102 = torch.ops.aten.add.Tensor(convert_element_type_234, 1.0);  convert_element_type_234 = None
    mul_129 = torch.ops.aten.mul.Tensor(mul_128, add_102);  mul_128 = add_102 = None
    convert_element_type_235 = torch.ops.prims.convert_element_type.default(mul_129, torch.bfloat16);  mul_129 = None
    view_165 = torch.ops.aten.reshape.default(convert_element_type_235, [1, 2048])
    permute_97 = torch.ops.aten.permute.default(arg99_1, [1, 0]);  arg99_1 = None
    mm_47 = torch.ops.aten.mm.default(view_165, permute_97);  view_165 = permute_97 = None
    view_166 = torch.ops.aten.reshape.default(mm_47, [1, 1, 6144]);  mm_47 = None
    permute_98 = torch.ops.aten.permute.default(view_166, [0, 2, 1]);  view_166 = None
    cat_9 = torch.ops.aten.cat.default([arg103_1, permute_98], -1);  permute_98 = None
    slice_56 = torch.ops.aten.slice.Tensor(cat_9, 2, -4, 9223372036854775807)
    copy_19 = torch.ops.aten.copy.default(arg103_1, slice_56);  slice_56 = None
    convert_element_type_244 = torch.ops.prims.convert_element_type.default(cat_9, torch.float32);  cat_9 = None
    slice_57 = torch.ops.aten.slice.Tensor(convert_element_type_244, 2, 0, 2)
    squeeze_5 = torch.ops.aten.squeeze.dim(arg104_1, 1);  arg104_1 = None
    unsqueeze_56 = torch.ops.aten.unsqueeze.default(squeeze_5, 1);  squeeze_5 = None
    convert_element_type_245 = torch.ops.prims.convert_element_type.default(unsqueeze_56, torch.float32);  unsqueeze_56 = None
    select_100 = torch.ops.aten.select.int(convert_element_type_245, 1, 0)
    select_101 = torch.ops.aten.select.int(select_100, 1, 0);  select_100 = None
    view_174 = torch.ops.aten.reshape.default(select_101, [1, -1, 1]);  select_101 = None
    mul_130 = torch.ops.aten.mul.Tensor(slice_57, view_174);  slice_57 = view_174 = None
    slice_58 = torch.ops.aten.slice.Tensor(convert_element_type_244, 2, 1, 3)
    select_102 = torch.ops.aten.select.int(convert_element_type_245, 1, 0)
    select_103 = torch.ops.aten.select.int(select_102, 1, 1);  select_102 = None
    view_175 = torch.ops.aten.reshape.default(select_103, [1, -1, 1]);  select_103 = None
    mul_131 = torch.ops.aten.mul.Tensor(slice_58, view_175);  slice_58 = view_175 = None
    add_103 = torch.ops.aten.add.Tensor(mul_130, mul_131);  mul_130 = mul_131 = None
    slice_59 = torch.ops.aten.slice.Tensor(convert_element_type_244, 2, 2, 4)
    select_104 = torch.ops.aten.select.int(convert_element_type_245, 1, 0)
    select_105 = torch.ops.aten.select.int(select_104, 1, 2);  select_104 = None
    view_176 = torch.ops.aten.reshape.default(select_105, [1, -1, 1]);  select_105 = None
    mul_132 = torch.ops.aten.mul.Tensor(slice_59, view_176);  slice_59 = view_176 = None
    add_104 = torch.ops.aten.add.Tensor(add_103, mul_132);  add_103 = mul_132 = None
    slice_60 = torch.ops.aten.slice.Tensor(convert_element_type_244, 2, 3, 5);  convert_element_type_244 = None
    select_106 = torch.ops.aten.select.int(convert_element_type_245, 1, 0);  convert_element_type_245 = None
    select_107 = torch.ops.aten.select.int(select_106, 1, 3);  select_106 = None
    view_177 = torch.ops.aten.reshape.default(select_107, [1, -1, 1]);  select_107 = None
    mul_133 = torch.ops.aten.mul.Tensor(slice_60, view_177);  slice_60 = view_177 = None
    add_105 = torch.ops.aten.add.Tensor(add_104, mul_133);  add_104 = mul_133 = None
    convert_element_type_246 = torch.ops.prims.convert_element_type.default(add_105, torch.bfloat16);  add_105 = None
    slice_61 = torch.ops.aten.slice.Tensor(convert_element_type_246, 2, -1, 9223372036854775807);  convert_element_type_246 = None
    convert_element_type_247 = torch.ops.prims.convert_element_type.default(slice_61, torch.float32);  slice_61 = None
    neg_23 = torch.ops.aten.neg.default(convert_element_type_247)
    exp_32 = torch.ops.aten.exp.default(neg_23);  neg_23 = None
    add_106 = torch.ops.aten.add.Tensor(exp_32, 1);  exp_32 = None
    div_22 = torch.ops.aten.div.Tensor(convert_element_type_247, add_106);  convert_element_type_247 = add_106 = None
    convert_element_type_248 = torch.ops.prims.convert_element_type.default(div_22, torch.bfloat16);  div_22 = None
    permute_102 = torch.ops.aten.permute.default(convert_element_type_248, [0, 2, 1]);  convert_element_type_248 = None
    split_with_sizes_5 = torch.ops.aten.split_with_sizes.default(permute_102, [2048, 2048, 2048], -1);  permute_102 = None
    getitem_17 = split_with_sizes_5[0]
    getitem_18 = split_with_sizes_5[1]
    getitem_19 = split_with_sizes_5[2];  split_with_sizes_5 = None
    full_default_7 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_113 = torch.ops.aten.select.int(full_default_7, 2, 0);  select_113 = None
    view_179 = torch.ops.aten.reshape.default(getitem_18, [1, 1, -1, 128]);  getitem_18 = None
    permute_104 = torch.ops.aten.permute.default(view_179, [0, 2, 1, 3]);  view_179 = None
    convert_element_type_251 = torch.ops.prims.convert_element_type.default(permute_104, torch.float32);  permute_104 = None
    clone_28 = torch.ops.aten.clone.default(convert_element_type_251, memory_format = torch.contiguous_format);  convert_element_type_251 = None
    mul_137 = torch.ops.aten.mul.Tensor(clone_28, clone_28)
    sum_23 = torch.ops.aten.sum.dim_IntList(mul_137, [-1], True);  mul_137 = None
    add_109 = torch.ops.aten.add.Tensor(sum_23, 1e-06);  sum_23 = None
    rsqrt_31 = torch.ops.aten.rsqrt.default(add_109);  add_109 = None
    mul_138 = torch.ops.aten.mul.Tensor(clone_28, rsqrt_31);  clone_28 = rsqrt_31 = None
    select_109 = torch.ops.aten.select.int(mul_138, 2, 0);  mul_138 = None
    unsqueeze_61 = torch.ops.aten.unsqueeze.default(select_109, -1)
    view_180 = torch.ops.aten.reshape.default(getitem_19, [1, 1, -1, 128]);  getitem_19 = None
    permute_105 = torch.ops.aten.permute.default(view_180, [0, 2, 1, 3]);  view_180 = None
    convert_element_type_252 = torch.ops.prims.convert_element_type.default(permute_105, torch.float32);  permute_105 = None
    clone_29 = torch.ops.aten.clone.default(convert_element_type_252, memory_format = torch.contiguous_format);  convert_element_type_252 = None
    select_110 = torch.ops.aten.select.int(clone_29, 2, 0);  clone_29 = None
    exp_33 = torch.ops.aten.exp.default(arg105_1);  arg105_1 = None
    neg_24 = torch.ops.aten.neg.default(exp_33);  exp_33 = None
    view_172 = torch.ops.aten.reshape.default(convert_element_type_235, [1, 2048])
    permute_101 = torch.ops.aten.permute.default(arg102_1, [1, 0]);  arg102_1 = None
    mm_50 = torch.ops.aten.mm.default(view_172, permute_101);  view_172 = permute_101 = None
    view_173 = torch.ops.aten.reshape.default(mm_50, [1, 1, 16]);  mm_50 = None
    convert_element_type_249 = torch.ops.prims.convert_element_type.default(view_173, torch.float32);  view_173 = None
    add_107 = torch.ops.aten.add.Tensor(convert_element_type_249, arg106_1);  convert_element_type_249 = arg106_1 = None
    gt_5 = torch.ops.aten.gt.Scalar(add_107, 20)
    exp_34 = torch.ops.aten.exp.default(add_107)
    log1p_5 = torch.ops.aten.log1p.default(exp_34);  exp_34 = None
    where_6 = torch.ops.aten.where.self(gt_5, add_107, log1p_5);  gt_5 = add_107 = log1p_5 = None
    mul_134 = torch.ops.aten.mul.Tensor(neg_24, where_6);  neg_24 = where_6 = None
    permute_107 = torch.ops.aten.permute.default(mul_134, [0, 2, 1]);  mul_134 = None
    select_111 = torch.ops.aten.select.int(permute_107, 2, 0);  permute_107 = None
    exp_35 = torch.ops.aten.exp.default(select_111);  select_111 = None
    unsqueeze_57 = torch.ops.aten.unsqueeze.default(exp_35, 2);  exp_35 = None
    unsqueeze_58 = torch.ops.aten.unsqueeze.default(unsqueeze_57, 3);  unsqueeze_57 = None
    mul_139 = torch.ops.aten.mul.Tensor(arg107_1, unsqueeze_58);  unsqueeze_58 = None
    unsqueeze_60 = torch.ops.aten.unsqueeze.default(select_109, -1);  select_109 = None
    mul_140 = torch.ops.aten.mul.Tensor(mul_139, unsqueeze_60);  unsqueeze_60 = None
    sum_24 = torch.ops.aten.sum.dim_IntList(mul_140, [-2]);  mul_140 = None
    sub_6 = torch.ops.aten.sub.Tensor(select_110, sum_24);  select_110 = sum_24 = None
    view_170 = torch.ops.aten.reshape.default(convert_element_type_235, [1, 2048])
    permute_100 = torch.ops.aten.permute.default(arg101_1, [1, 0]);  arg101_1 = None
    mm_49 = torch.ops.aten.mm.default(view_170, permute_100);  view_170 = permute_100 = None
    view_171 = torch.ops.aten.reshape.default(mm_49, [1, 1, 16]);  mm_49 = None
    sigmoid_6 = torch.ops.aten.sigmoid.default(view_171);  view_171 = None
    permute_106 = torch.ops.aten.permute.default(sigmoid_6, [0, 2, 1]);  sigmoid_6 = None
    convert_element_type_253 = torch.ops.prims.convert_element_type.default(permute_106, torch.float32);  permute_106 = None
    clone_30 = torch.ops.aten.clone.default(convert_element_type_253, memory_format = torch.contiguous_format);  convert_element_type_253 = None
    select_112 = torch.ops.aten.select.int(clone_30, 2, 0);  clone_30 = None
    unsqueeze_59 = torch.ops.aten.unsqueeze.default(select_112, -1);  select_112 = None
    mul_141 = torch.ops.aten.mul.Tensor(sub_6, unsqueeze_59);  sub_6 = unsqueeze_59 = None
    unsqueeze_62 = torch.ops.aten.unsqueeze.default(mul_141, -2);  mul_141 = None
    mul_142 = torch.ops.aten.mul.Tensor(unsqueeze_61, unsqueeze_62);  unsqueeze_61 = unsqueeze_62 = None
    add_110 = torch.ops.aten.add.Tensor(mul_139, mul_142);  mul_139 = mul_142 = None
    view_178 = torch.ops.aten.reshape.default(getitem_17, [1, 1, -1, 128]);  getitem_17 = None
    permute_103 = torch.ops.aten.permute.default(view_178, [0, 2, 1, 3]);  view_178 = None
    convert_element_type_250 = torch.ops.prims.convert_element_type.default(permute_103, torch.float32);  permute_103 = None
    clone_27 = torch.ops.aten.clone.default(convert_element_type_250, memory_format = torch.contiguous_format);  convert_element_type_250 = None
    mul_135 = torch.ops.aten.mul.Tensor(clone_27, clone_27)
    sum_22 = torch.ops.aten.sum.dim_IntList(mul_135, [-1], True);  mul_135 = None
    add_108 = torch.ops.aten.add.Tensor(sum_22, 1e-06);  sum_22 = None
    rsqrt_30 = torch.ops.aten.rsqrt.default(add_108);  add_108 = None
    mul_136 = torch.ops.aten.mul.Tensor(clone_27, rsqrt_30);  clone_27 = rsqrt_30 = None
    div_23 = torch.ops.aten.div.Tensor(mul_136, 11.313708498984761);  mul_136 = None
    select_108 = torch.ops.aten.select.int(div_23, 2, 0);  div_23 = None
    unsqueeze_63 = torch.ops.aten.unsqueeze.default(select_108, -1);  select_108 = None
    mul_143 = torch.ops.aten.mul.Tensor(add_110, unsqueeze_63);  unsqueeze_63 = None
    sum_25 = torch.ops.aten.sum.dim_IntList(mul_143, [-2]);  mul_143 = None
    select_scatter_default_9 = torch.ops.aten.select_scatter.default(full_default_7, sum_25, 2, 0);  full_default_7 = sum_25 = None
    permute_109 = torch.ops.aten.permute.default(select_scatter_default_9, [0, 2, 1, 3]);  select_scatter_default_9 = None
    convert_element_type_254 = torch.ops.prims.convert_element_type.default(permute_109, torch.bfloat16);  permute_109 = None
    view_181 = torch.ops.aten.reshape.default(convert_element_type_254, [-1, 128]);  convert_element_type_254 = None
    convert_element_type_255 = torch.ops.prims.convert_element_type.default(view_181, torch.float32);  view_181 = None
    pow_21 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_255, 2)
    mean_20 = torch.ops.aten.mean.dim(pow_21, [-1], True);  pow_21 = None
    add_111 = torch.ops.aten.add.Tensor(mean_20, 1e-06);  mean_20 = None
    rsqrt_32 = torch.ops.aten.rsqrt.default(add_111);  add_111 = None
    mul_144 = torch.ops.aten.mul.Tensor(convert_element_type_255, rsqrt_32);  convert_element_type_255 = rsqrt_32 = None
    convert_element_type_256 = torch.ops.prims.convert_element_type.default(mul_144, torch.bfloat16);  mul_144 = None
    mul_145 = torch.ops.aten.mul.Tensor(arg108_1, convert_element_type_256);  arg108_1 = convert_element_type_256 = None
    view_167 = torch.ops.aten.reshape.default(convert_element_type_235, [1, 2048]);  convert_element_type_235 = None
    permute_99 = torch.ops.aten.permute.default(arg100_1, [1, 0]);  arg100_1 = None
    mm_48 = torch.ops.aten.mm.default(view_167, permute_99);  view_167 = permute_99 = None
    view_168 = torch.ops.aten.reshape.default(mm_48, [1, 1, 2048]);  mm_48 = None
    view_169 = torch.ops.aten.reshape.default(view_168, [1, 1, -1, 128]);  view_168 = None
    view_182 = torch.ops.aten.reshape.default(view_169, [-1, 128]);  view_169 = None
    convert_element_type_257 = torch.ops.prims.convert_element_type.default(view_182, torch.float32);  view_182 = None
    neg_25 = torch.ops.aten.neg.default(convert_element_type_257)
    exp_36 = torch.ops.aten.exp.default(neg_25);  neg_25 = None
    add_112 = torch.ops.aten.add.Tensor(exp_36, 1);  exp_36 = None
    div_24 = torch.ops.aten.div.Tensor(convert_element_type_257, add_112);  convert_element_type_257 = add_112 = None
    mul_146 = torch.ops.aten.mul.Tensor(mul_145, div_24);  mul_145 = div_24 = None
    convert_element_type_258 = torch.ops.prims.convert_element_type.default(mul_146, torch.bfloat16);  mul_146 = None
    view_183 = torch.ops.aten.reshape.default(convert_element_type_258, [1, 1, -1]);  convert_element_type_258 = None
    view_184 = torch.ops.aten.reshape.default(view_183, [1, 2048]);  view_183 = None
    permute_110 = torch.ops.aten.permute.default(arg109_1, [1, 0]);  arg109_1 = None
    mm_51 = torch.ops.aten.mm.default(view_184, permute_110);  view_184 = permute_110 = None
    view_185 = torch.ops.aten.reshape.default(mm_51, [1, 1, 2048]);  mm_51 = None
    add_113 = torch.ops.aten.add.Tensor(add_100, view_185);  add_100 = view_185 = None
    convert_element_type_261 = torch.ops.prims.convert_element_type.default(add_113, torch.float32)
    pow_22 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_261, 2)
    mean_21 = torch.ops.aten.mean.dim(pow_22, [-1], True);  pow_22 = None
    add_114 = torch.ops.aten.add.Tensor(mean_21, 1e-06);  mean_21 = None
    rsqrt_33 = torch.ops.aten.rsqrt.default(add_114);  add_114 = None
    mul_147 = torch.ops.aten.mul.Tensor(convert_element_type_261, rsqrt_33);  convert_element_type_261 = rsqrt_33 = None
    convert_element_type_262 = torch.ops.prims.convert_element_type.default(arg110_1, torch.float32);  arg110_1 = None
    add_115 = torch.ops.aten.add.Tensor(convert_element_type_262, 1.0);  convert_element_type_262 = None
    mul_148 = torch.ops.aten.mul.Tensor(mul_147, add_115);  mul_147 = add_115 = None
    convert_element_type_263 = torch.ops.prims.convert_element_type.default(mul_148, torch.bfloat16);  mul_148 = None
    view_186 = torch.ops.aten.reshape.default(convert_element_type_263, [1, 2048])
    permute_111 = torch.ops.aten.permute.default(arg111_1, [1, 0]);  arg111_1 = None
    mm_52 = torch.ops.aten.mm.default(view_186, permute_111);  view_186 = permute_111 = None
    view_187 = torch.ops.aten.reshape.default(mm_52, [1, 1, 6144]);  mm_52 = None
    convert_element_type_266 = torch.ops.prims.convert_element_type.default(view_187, torch.float32);  view_187 = None
    neg_26 = torch.ops.aten.neg.default(convert_element_type_266)
    exp_37 = torch.ops.aten.exp.default(neg_26);  neg_26 = None
    add_116 = torch.ops.aten.add.Tensor(exp_37, 1);  exp_37 = None
    div_25 = torch.ops.aten.div.Tensor(convert_element_type_266, add_116);  convert_element_type_266 = add_116 = None
    convert_element_type_267 = torch.ops.prims.convert_element_type.default(div_25, torch.bfloat16);  div_25 = None
    view_188 = torch.ops.aten.reshape.default(convert_element_type_263, [1, 2048]);  convert_element_type_263 = None
    permute_112 = torch.ops.aten.permute.default(arg112_1, [1, 0]);  arg112_1 = None
    mm_53 = torch.ops.aten.mm.default(view_188, permute_112);  view_188 = permute_112 = None
    view_189 = torch.ops.aten.reshape.default(mm_53, [1, 1, 6144]);  mm_53 = None
    mul_149 = torch.ops.aten.mul.Tensor(convert_element_type_267, view_189);  convert_element_type_267 = view_189 = None
    view_190 = torch.ops.aten.reshape.default(mul_149, [1, 6144]);  mul_149 = None
    permute_113 = torch.ops.aten.permute.default(arg113_1, [1, 0]);  arg113_1 = None
    mm_54 = torch.ops.aten.mm.default(view_190, permute_113);  view_190 = permute_113 = None
    view_191 = torch.ops.aten.reshape.default(mm_54, [1, 1, 2048]);  mm_54 = None
    add_117 = torch.ops.aten.add.Tensor(add_113, view_191);  add_113 = view_191 = None
    convert_element_type_272 = torch.ops.prims.convert_element_type.default(add_117, torch.float32)
    pow_23 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_272, 2)
    mean_22 = torch.ops.aten.mean.dim(pow_23, [-1], True);  pow_23 = None
    add_118 = torch.ops.aten.add.Tensor(mean_22, 1e-06);  mean_22 = None
    rsqrt_34 = torch.ops.aten.rsqrt.default(add_118);  add_118 = None
    mul_150 = torch.ops.aten.mul.Tensor(convert_element_type_272, rsqrt_34);  convert_element_type_272 = rsqrt_34 = None
    convert_element_type_273 = torch.ops.prims.convert_element_type.default(arg114_1, torch.float32);  arg114_1 = None
    add_119 = torch.ops.aten.add.Tensor(convert_element_type_273, 1.0);  convert_element_type_273 = None
    mul_151 = torch.ops.aten.mul.Tensor(mul_150, add_119);  mul_150 = add_119 = None
    convert_element_type_274 = torch.ops.prims.convert_element_type.default(mul_151, torch.bfloat16);  mul_151 = None
    view_192 = torch.ops.aten.reshape.default(convert_element_type_274, [1, 2048])
    permute_114 = torch.ops.aten.permute.default(arg115_1, [1, 0]);  arg115_1 = None
    mm_55 = torch.ops.aten.mm.default(view_192, permute_114);  view_192 = permute_114 = None
    view_193 = torch.ops.aten.reshape.default(mm_55, [1, 1, 4096]);  mm_55 = None
    view_194 = torch.ops.aten.reshape.default(view_193, [1, 1, -1, 512]);  view_193 = None
    split_1 = torch.ops.aten.split.Tensor(view_194, 256, -1);  view_194 = None
    getitem_20 = split_1[0]
    getitem_21 = split_1[1];  split_1 = None
    add_127 = torch.ops.aten.add.Tensor(arg120_1, 1)
    convert_element_type_277 = torch.ops.prims.convert_element_type.default(getitem_20, torch.float32);  getitem_20 = None
    pow_24 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_277, 2)
    mean_23 = torch.ops.aten.mean.dim(pow_24, [-1], True);  pow_24 = None
    add_120 = torch.ops.aten.add.Tensor(mean_23, 1e-06);  mean_23 = None
    rsqrt_35 = torch.ops.aten.rsqrt.default(add_120);  add_120 = None
    mul_152 = torch.ops.aten.mul.Tensor(convert_element_type_277, rsqrt_35);  convert_element_type_277 = rsqrt_35 = None
    convert_element_type_278 = torch.ops.prims.convert_element_type.default(arg116_1, torch.float32);  arg116_1 = None
    add_121 = torch.ops.aten.add.Tensor(convert_element_type_278, 1.0);  convert_element_type_278 = None
    mul_153 = torch.ops.aten.mul.Tensor(mul_152, add_121);  mul_152 = add_121 = None
    convert_element_type_279 = torch.ops.prims.convert_element_type.default(mul_153, torch.bfloat16);  mul_153 = None
    permute_115 = torch.ops.aten.permute.default(convert_element_type_279, [0, 2, 1, 3]);  convert_element_type_279 = None
    slice_62 = torch.ops.aten.slice.Tensor(permute_115, 3, 0, 64)
    unsqueeze_64 = torch.ops.aten.unsqueeze.default(convert_element_type_2, 1)
    mul_156 = torch.ops.aten.mul.Tensor(slice_62, unsqueeze_64)
    slice_67 = torch.ops.aten.slice.Tensor(slice_62, 3, 32, 9223372036854775807)
    neg_27 = torch.ops.aten.neg.default(slice_67);  slice_67 = None
    slice_66 = torch.ops.aten.slice.Tensor(slice_62, 3, 0, 32);  slice_62 = None
    cat_10 = torch.ops.aten.cat.default([neg_27, slice_66], -1);  neg_27 = slice_66 = None
    unsqueeze_65 = torch.ops.aten.unsqueeze.default(convert_element_type_3, 1)
    mul_157 = torch.ops.aten.mul.Tensor(cat_10, unsqueeze_65);  cat_10 = None
    add_124 = torch.ops.aten.add.Tensor(mul_156, mul_157);  mul_156 = mul_157 = None
    slice_63 = torch.ops.aten.slice.Tensor(permute_115, 3, 64, 9223372036854775807);  permute_115 = None
    cat_12 = torch.ops.aten.cat.default([add_124, slice_63], -1);  add_124 = slice_63 = None
    expand_16 = torch.ops.aten.expand.default(cat_12, [1, 8, 1, 256]);  cat_12 = None
    view_205 = torch.ops.aten.reshape.default(expand_16, [8, 1, 256]);  expand_16 = None
    iota_2 = torch.ops.prims.iota.default(1, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    add_126 = torch.ops.aten.add.Tensor(iota_2, arg120_1);  iota_2 = None
    view_197 = torch.ops.aten.reshape.default(convert_element_type_274, [1, 2048])
    permute_116 = torch.ops.aten.permute.default(arg117_1, [1, 0]);  arg117_1 = None
    mm_56 = torch.ops.aten.mm.default(view_197, permute_116);  view_197 = permute_116 = None
    view_198 = torch.ops.aten.reshape.default(mm_56, [1, 1, 512]);  mm_56 = None
    view_199 = torch.ops.aten.reshape.default(view_198, [1, 1, -1, 256]);  view_198 = None
    convert_element_type_282 = torch.ops.prims.convert_element_type.default(view_199, torch.float32);  view_199 = None
    pow_25 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_282, 2)
    mean_24 = torch.ops.aten.mean.dim(pow_25, [-1], True);  pow_25 = None
    add_122 = torch.ops.aten.add.Tensor(mean_24, 1e-06);  mean_24 = None
    rsqrt_36 = torch.ops.aten.rsqrt.default(add_122);  add_122 = None
    mul_154 = torch.ops.aten.mul.Tensor(convert_element_type_282, rsqrt_36);  convert_element_type_282 = rsqrt_36 = None
    convert_element_type_283 = torch.ops.prims.convert_element_type.default(arg118_1, torch.float32);  arg118_1 = None
    add_123 = torch.ops.aten.add.Tensor(convert_element_type_283, 1.0);  convert_element_type_283 = None
    mul_155 = torch.ops.aten.mul.Tensor(mul_154, add_123);  mul_154 = add_123 = None
    convert_element_type_284 = torch.ops.prims.convert_element_type.default(mul_155, torch.bfloat16);  mul_155 = None
    permute_117 = torch.ops.aten.permute.default(convert_element_type_284, [0, 2, 1, 3]);  convert_element_type_284 = None
    slice_64 = torch.ops.aten.slice.Tensor(permute_117, 3, 0, 64)
    mul_158 = torch.ops.aten.mul.Tensor(slice_64, unsqueeze_64);  unsqueeze_64 = None
    slice_69 = torch.ops.aten.slice.Tensor(slice_64, 3, 32, 9223372036854775807)
    neg_28 = torch.ops.aten.neg.default(slice_69);  slice_69 = None
    slice_68 = torch.ops.aten.slice.Tensor(slice_64, 3, 0, 32);  slice_64 = None
    cat_11 = torch.ops.aten.cat.default([neg_28, slice_68], -1);  neg_28 = slice_68 = None
    mul_159 = torch.ops.aten.mul.Tensor(cat_11, unsqueeze_65);  cat_11 = unsqueeze_65 = None
    add_125 = torch.ops.aten.add.Tensor(mul_158, mul_159);  mul_158 = mul_159 = None
    slice_65 = torch.ops.aten.slice.Tensor(permute_117, 3, 64, 9223372036854775807);  permute_117 = None
    cat_13 = torch.ops.aten.cat.default([add_125, slice_65], -1);  add_125 = slice_65 = None
    index_put_2 = torch.ops.aten.index_put_.default(arg121_1, [None, None, add_126], cat_13);  arg121_1 = cat_13 = None
    unsqueeze_68 = torch.ops.aten.unsqueeze.default(index_put_2, 2);  index_put_2 = None
    expand_13 = torch.ops.aten.expand.default(unsqueeze_68, [1, 2, 4, 144, 256]);  unsqueeze_68 = None
    clone_32 = torch.ops.aten.clone.default(expand_13, memory_format = torch.contiguous_format);  expand_13 = None
    view_203 = torch.ops.aten.reshape.default(clone_32, [1, 8, 144, 256]);  clone_32 = None
    permute_120 = torch.ops.aten.permute.default(view_203, [0, 1, 3, 2]);  view_203 = None
    expand_17 = torch.ops.aten.expand.default(permute_120, [1, 8, 256, 144]);  permute_120 = None
    view_206 = torch.ops.aten.reshape.default(expand_17, [8, 256, 144]);  expand_17 = None
    bmm_2 = torch.ops.aten.bmm.default(view_205, view_206);  view_205 = view_206 = None
    view_207 = torch.ops.aten.reshape.default(bmm_2, [1, 8, 1, 144]);  bmm_2 = None
    mul_160 = torch.ops.aten.mul.Tensor(view_207, 0.0625);  view_207 = None
    add_128 = torch.ops.aten.add.Tensor(mul_160, unsqueeze_3);  mul_160 = None
    convert_element_type_289 = torch.ops.prims.convert_element_type.default(add_128, torch.float32);  add_128 = None
    amax_1 = torch.ops.aten.amax.default(convert_element_type_289, [-1], True)
    sub_7 = torch.ops.aten.sub.Tensor(convert_element_type_289, amax_1);  convert_element_type_289 = amax_1 = None
    exp_38 = torch.ops.aten.exp.default(sub_7);  sub_7 = None
    sum_26 = torch.ops.aten.sum.dim_IntList(exp_38, [-1], True)
    div_26 = torch.ops.aten.div.Tensor(exp_38, sum_26);  exp_38 = sum_26 = None
    convert_element_type_290 = torch.ops.prims.convert_element_type.default(div_26, torch.bfloat16);  div_26 = None
    expand_18 = torch.ops.aten.expand.default(convert_element_type_290, [1, 8, 1, 144]);  convert_element_type_290 = None
    view_208 = torch.ops.aten.reshape.default(expand_18, [8, 1, 144]);  expand_18 = None
    view_200 = torch.ops.aten.reshape.default(convert_element_type_274, [1, 2048]);  convert_element_type_274 = None
    permute_118 = torch.ops.aten.permute.default(arg119_1, [1, 0]);  arg119_1 = None
    mm_57 = torch.ops.aten.mm.default(view_200, permute_118);  view_200 = permute_118 = None
    view_201 = torch.ops.aten.reshape.default(mm_57, [1, 1, 512]);  mm_57 = None
    view_202 = torch.ops.aten.reshape.default(view_201, [1, 1, -1, 256]);  view_201 = None
    permute_119 = torch.ops.aten.permute.default(view_202, [0, 2, 1, 3]);  view_202 = None
    index_put_3 = torch.ops.aten.index_put_.default(arg122_1, [None, None, add_126], permute_119);  arg122_1 = add_126 = permute_119 = None
    unsqueeze_71 = torch.ops.aten.unsqueeze.default(index_put_3, 2);  index_put_3 = None
    expand_15 = torch.ops.aten.expand.default(unsqueeze_71, [1, 2, 4, 144, 256]);  unsqueeze_71 = None
    clone_33 = torch.ops.aten.clone.default(expand_15, memory_format = torch.contiguous_format);  expand_15 = None
    view_204 = torch.ops.aten.reshape.default(clone_33, [1, 8, 144, 256]);  clone_33 = None
    expand_19 = torch.ops.aten.expand.default(view_204, [1, 8, 144, 256]);  view_204 = None
    view_209 = torch.ops.aten.reshape.default(expand_19, [8, 144, 256]);  expand_19 = None
    bmm_3 = torch.ops.aten.bmm.default(view_208, view_209);  view_208 = view_209 = None
    view_210 = torch.ops.aten.reshape.default(bmm_3, [1, 8, 1, 256]);  bmm_3 = None
    permute_121 = torch.ops.aten.permute.default(view_210, [0, 2, 1, 3]);  view_210 = None
    view_211 = torch.ops.aten.reshape.default(permute_121, [1, 1, -1]);  permute_121 = None
    clone_31 = torch.ops.aten.clone.default(getitem_21, memory_format = torch.contiguous_format);  getitem_21 = None
    view_195 = torch.ops.aten.reshape.default(clone_31, [1, 1, 2048]);  clone_31 = None
    sigmoid_7 = torch.ops.aten.sigmoid.default(view_195);  view_195 = None
    mul_161 = torch.ops.aten.mul.Tensor(view_211, sigmoid_7);  view_211 = sigmoid_7 = None
    view_212 = torch.ops.aten.reshape.default(mul_161, [1, 2048]);  mul_161 = None
    permute_122 = torch.ops.aten.permute.default(arg123_1, [1, 0]);  arg123_1 = None
    mm_58 = torch.ops.aten.mm.default(view_212, permute_122);  view_212 = permute_122 = None
    view_213 = torch.ops.aten.reshape.default(mm_58, [1, 1, 2048]);  mm_58 = None
    add_129 = torch.ops.aten.add.Tensor(add_117, view_213);  add_117 = view_213 = None
    convert_element_type_295 = torch.ops.prims.convert_element_type.default(add_129, torch.float32)
    pow_26 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_295, 2)
    mean_25 = torch.ops.aten.mean.dim(pow_26, [-1], True);  pow_26 = None
    add_130 = torch.ops.aten.add.Tensor(mean_25, 1e-06);  mean_25 = None
    rsqrt_37 = torch.ops.aten.rsqrt.default(add_130);  add_130 = None
    mul_162 = torch.ops.aten.mul.Tensor(convert_element_type_295, rsqrt_37);  convert_element_type_295 = rsqrt_37 = None
    convert_element_type_296 = torch.ops.prims.convert_element_type.default(arg124_1, torch.float32);  arg124_1 = None
    add_131 = torch.ops.aten.add.Tensor(convert_element_type_296, 1.0);  convert_element_type_296 = None
    mul_163 = torch.ops.aten.mul.Tensor(mul_162, add_131);  mul_162 = add_131 = None
    convert_element_type_297 = torch.ops.prims.convert_element_type.default(mul_163, torch.bfloat16);  mul_163 = None
    view_214 = torch.ops.aten.reshape.default(convert_element_type_297, [1, 2048])
    permute_123 = torch.ops.aten.permute.default(arg125_1, [1, 0]);  arg125_1 = None
    mm_59 = torch.ops.aten.mm.default(view_214, permute_123);  view_214 = permute_123 = None
    view_215 = torch.ops.aten.reshape.default(mm_59, [1, 1, 6144]);  mm_59 = None
    convert_element_type_300 = torch.ops.prims.convert_element_type.default(view_215, torch.float32);  view_215 = None
    neg_29 = torch.ops.aten.neg.default(convert_element_type_300)
    exp_39 = torch.ops.aten.exp.default(neg_29);  neg_29 = None
    add_132 = torch.ops.aten.add.Tensor(exp_39, 1);  exp_39 = None
    div_27 = torch.ops.aten.div.Tensor(convert_element_type_300, add_132);  convert_element_type_300 = add_132 = None
    convert_element_type_301 = torch.ops.prims.convert_element_type.default(div_27, torch.bfloat16);  div_27 = None
    view_216 = torch.ops.aten.reshape.default(convert_element_type_297, [1, 2048]);  convert_element_type_297 = None
    permute_124 = torch.ops.aten.permute.default(arg126_1, [1, 0]);  arg126_1 = None
    mm_60 = torch.ops.aten.mm.default(view_216, permute_124);  view_216 = permute_124 = None
    view_217 = torch.ops.aten.reshape.default(mm_60, [1, 1, 6144]);  mm_60 = None
    mul_164 = torch.ops.aten.mul.Tensor(convert_element_type_301, view_217);  convert_element_type_301 = view_217 = None
    view_218 = torch.ops.aten.reshape.default(mul_164, [1, 6144]);  mul_164 = None
    permute_125 = torch.ops.aten.permute.default(arg127_1, [1, 0]);  arg127_1 = None
    mm_61 = torch.ops.aten.mm.default(view_218, permute_125);  view_218 = permute_125 = None
    view_219 = torch.ops.aten.reshape.default(mm_61, [1, 1, 2048]);  mm_61 = None
    add_133 = torch.ops.aten.add.Tensor(add_129, view_219);  add_129 = view_219 = None
    convert_element_type_306 = torch.ops.prims.convert_element_type.default(add_133, torch.float32)
    pow_27 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_306, 2)
    mean_26 = torch.ops.aten.mean.dim(pow_27, [-1], True);  pow_27 = None
    add_134 = torch.ops.aten.add.Tensor(mean_26, 1e-06);  mean_26 = None
    rsqrt_38 = torch.ops.aten.rsqrt.default(add_134);  add_134 = None
    mul_165 = torch.ops.aten.mul.Tensor(convert_element_type_306, rsqrt_38);  convert_element_type_306 = rsqrt_38 = None
    convert_element_type_307 = torch.ops.prims.convert_element_type.default(arg128_1, torch.float32);  arg128_1 = None
    add_135 = torch.ops.aten.add.Tensor(convert_element_type_307, 1.0);  convert_element_type_307 = None
    mul_166 = torch.ops.aten.mul.Tensor(mul_165, add_135);  mul_165 = add_135 = None
    convert_element_type_308 = torch.ops.prims.convert_element_type.default(mul_166, torch.bfloat16);  mul_166 = None
    view_220 = torch.ops.aten.reshape.default(convert_element_type_308, [1, 2048])
    permute_126 = torch.ops.aten.permute.default(arg129_1, [1, 0]);  arg129_1 = None
    mm_62 = torch.ops.aten.mm.default(view_220, permute_126);  view_220 = permute_126 = None
    view_221 = torch.ops.aten.reshape.default(mm_62, [1, 1, 6144]);  mm_62 = None
    permute_127 = torch.ops.aten.permute.default(view_221, [0, 2, 1]);  view_221 = None
    cat_14 = torch.ops.aten.cat.default([arg133_1, permute_127], -1);  permute_127 = None
    slice_70 = torch.ops.aten.slice.Tensor(cat_14, 2, -4, 9223372036854775807)
    copy_22 = torch.ops.aten.copy.default(arg133_1, slice_70);  slice_70 = None
    convert_element_type_317 = torch.ops.prims.convert_element_type.default(cat_14, torch.float32);  cat_14 = None
    slice_71 = torch.ops.aten.slice.Tensor(convert_element_type_317, 2, 0, 2)
    squeeze_6 = torch.ops.aten.squeeze.dim(arg134_1, 1);  arg134_1 = None
    unsqueeze_72 = torch.ops.aten.unsqueeze.default(squeeze_6, 1);  squeeze_6 = None
    convert_element_type_318 = torch.ops.prims.convert_element_type.default(unsqueeze_72, torch.float32);  unsqueeze_72 = None
    select_115 = torch.ops.aten.select.int(convert_element_type_318, 1, 0)
    select_116 = torch.ops.aten.select.int(select_115, 1, 0);  select_115 = None
    view_229 = torch.ops.aten.reshape.default(select_116, [1, -1, 1]);  select_116 = None
    mul_167 = torch.ops.aten.mul.Tensor(slice_71, view_229);  slice_71 = view_229 = None
    slice_72 = torch.ops.aten.slice.Tensor(convert_element_type_317, 2, 1, 3)
    select_117 = torch.ops.aten.select.int(convert_element_type_318, 1, 0)
    select_118 = torch.ops.aten.select.int(select_117, 1, 1);  select_117 = None
    view_230 = torch.ops.aten.reshape.default(select_118, [1, -1, 1]);  select_118 = None
    mul_168 = torch.ops.aten.mul.Tensor(slice_72, view_230);  slice_72 = view_230 = None
    add_136 = torch.ops.aten.add.Tensor(mul_167, mul_168);  mul_167 = mul_168 = None
    slice_73 = torch.ops.aten.slice.Tensor(convert_element_type_317, 2, 2, 4)
    select_119 = torch.ops.aten.select.int(convert_element_type_318, 1, 0)
    select_120 = torch.ops.aten.select.int(select_119, 1, 2);  select_119 = None
    view_231 = torch.ops.aten.reshape.default(select_120, [1, -1, 1]);  select_120 = None
    mul_169 = torch.ops.aten.mul.Tensor(slice_73, view_231);  slice_73 = view_231 = None
    add_137 = torch.ops.aten.add.Tensor(add_136, mul_169);  add_136 = mul_169 = None
    slice_74 = torch.ops.aten.slice.Tensor(convert_element_type_317, 2, 3, 5);  convert_element_type_317 = None
    select_121 = torch.ops.aten.select.int(convert_element_type_318, 1, 0);  convert_element_type_318 = None
    select_122 = torch.ops.aten.select.int(select_121, 1, 3);  select_121 = None
    view_232 = torch.ops.aten.reshape.default(select_122, [1, -1, 1]);  select_122 = None
    mul_170 = torch.ops.aten.mul.Tensor(slice_74, view_232);  slice_74 = view_232 = None
    add_138 = torch.ops.aten.add.Tensor(add_137, mul_170);  add_137 = mul_170 = None
    convert_element_type_319 = torch.ops.prims.convert_element_type.default(add_138, torch.bfloat16);  add_138 = None
    slice_75 = torch.ops.aten.slice.Tensor(convert_element_type_319, 2, -1, 9223372036854775807);  convert_element_type_319 = None
    convert_element_type_320 = torch.ops.prims.convert_element_type.default(slice_75, torch.float32);  slice_75 = None
    neg_30 = torch.ops.aten.neg.default(convert_element_type_320)
    exp_40 = torch.ops.aten.exp.default(neg_30);  neg_30 = None
    add_139 = torch.ops.aten.add.Tensor(exp_40, 1);  exp_40 = None
    div_28 = torch.ops.aten.div.Tensor(convert_element_type_320, add_139);  convert_element_type_320 = add_139 = None
    convert_element_type_321 = torch.ops.prims.convert_element_type.default(div_28, torch.bfloat16);  div_28 = None
    permute_131 = torch.ops.aten.permute.default(convert_element_type_321, [0, 2, 1]);  convert_element_type_321 = None
    split_with_sizes_6 = torch.ops.aten.split_with_sizes.default(permute_131, [2048, 2048, 2048], -1);  permute_131 = None
    getitem_22 = split_with_sizes_6[0]
    getitem_23 = split_with_sizes_6[1]
    getitem_24 = split_with_sizes_6[2];  split_with_sizes_6 = None
    full_default_8 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_128 = torch.ops.aten.select.int(full_default_8, 2, 0);  select_128 = None
    view_234 = torch.ops.aten.reshape.default(getitem_23, [1, 1, -1, 128]);  getitem_23 = None
    permute_133 = torch.ops.aten.permute.default(view_234, [0, 2, 1, 3]);  view_234 = None
    convert_element_type_324 = torch.ops.prims.convert_element_type.default(permute_133, torch.float32);  permute_133 = None
    clone_35 = torch.ops.aten.clone.default(convert_element_type_324, memory_format = torch.contiguous_format);  convert_element_type_324 = None
    mul_174 = torch.ops.aten.mul.Tensor(clone_35, clone_35)
    sum_28 = torch.ops.aten.sum.dim_IntList(mul_174, [-1], True);  mul_174 = None
    add_142 = torch.ops.aten.add.Tensor(sum_28, 1e-06);  sum_28 = None
    rsqrt_40 = torch.ops.aten.rsqrt.default(add_142);  add_142 = None
    mul_175 = torch.ops.aten.mul.Tensor(clone_35, rsqrt_40);  clone_35 = rsqrt_40 = None
    select_124 = torch.ops.aten.select.int(mul_175, 2, 0);  mul_175 = None
    unsqueeze_77 = torch.ops.aten.unsqueeze.default(select_124, -1)
    view_235 = torch.ops.aten.reshape.default(getitem_24, [1, 1, -1, 128]);  getitem_24 = None
    permute_134 = torch.ops.aten.permute.default(view_235, [0, 2, 1, 3]);  view_235 = None
    convert_element_type_325 = torch.ops.prims.convert_element_type.default(permute_134, torch.float32);  permute_134 = None
    clone_36 = torch.ops.aten.clone.default(convert_element_type_325, memory_format = torch.contiguous_format);  convert_element_type_325 = None
    select_125 = torch.ops.aten.select.int(clone_36, 2, 0);  clone_36 = None
    exp_41 = torch.ops.aten.exp.default(arg135_1);  arg135_1 = None
    neg_31 = torch.ops.aten.neg.default(exp_41);  exp_41 = None
    view_227 = torch.ops.aten.reshape.default(convert_element_type_308, [1, 2048])
    permute_130 = torch.ops.aten.permute.default(arg132_1, [1, 0]);  arg132_1 = None
    mm_65 = torch.ops.aten.mm.default(view_227, permute_130);  view_227 = permute_130 = None
    view_228 = torch.ops.aten.reshape.default(mm_65, [1, 1, 16]);  mm_65 = None
    convert_element_type_322 = torch.ops.prims.convert_element_type.default(view_228, torch.float32);  view_228 = None
    add_140 = torch.ops.aten.add.Tensor(convert_element_type_322, arg136_1);  convert_element_type_322 = arg136_1 = None
    gt_6 = torch.ops.aten.gt.Scalar(add_140, 20)
    exp_42 = torch.ops.aten.exp.default(add_140)
    log1p_6 = torch.ops.aten.log1p.default(exp_42);  exp_42 = None
    where_7 = torch.ops.aten.where.self(gt_6, add_140, log1p_6);  gt_6 = add_140 = log1p_6 = None
    mul_171 = torch.ops.aten.mul.Tensor(neg_31, where_7);  neg_31 = where_7 = None
    permute_136 = torch.ops.aten.permute.default(mul_171, [0, 2, 1]);  mul_171 = None
    select_126 = torch.ops.aten.select.int(permute_136, 2, 0);  permute_136 = None
    exp_43 = torch.ops.aten.exp.default(select_126);  select_126 = None
    unsqueeze_73 = torch.ops.aten.unsqueeze.default(exp_43, 2);  exp_43 = None
    unsqueeze_74 = torch.ops.aten.unsqueeze.default(unsqueeze_73, 3);  unsqueeze_73 = None
    mul_176 = torch.ops.aten.mul.Tensor(arg137_1, unsqueeze_74);  unsqueeze_74 = None
    unsqueeze_76 = torch.ops.aten.unsqueeze.default(select_124, -1);  select_124 = None
    mul_177 = torch.ops.aten.mul.Tensor(mul_176, unsqueeze_76);  unsqueeze_76 = None
    sum_29 = torch.ops.aten.sum.dim_IntList(mul_177, [-2]);  mul_177 = None
    sub_8 = torch.ops.aten.sub.Tensor(select_125, sum_29);  select_125 = sum_29 = None
    view_225 = torch.ops.aten.reshape.default(convert_element_type_308, [1, 2048])
    permute_129 = torch.ops.aten.permute.default(arg131_1, [1, 0]);  arg131_1 = None
    mm_64 = torch.ops.aten.mm.default(view_225, permute_129);  view_225 = permute_129 = None
    view_226 = torch.ops.aten.reshape.default(mm_64, [1, 1, 16]);  mm_64 = None
    sigmoid_8 = torch.ops.aten.sigmoid.default(view_226);  view_226 = None
    permute_135 = torch.ops.aten.permute.default(sigmoid_8, [0, 2, 1]);  sigmoid_8 = None
    convert_element_type_326 = torch.ops.prims.convert_element_type.default(permute_135, torch.float32);  permute_135 = None
    clone_37 = torch.ops.aten.clone.default(convert_element_type_326, memory_format = torch.contiguous_format);  convert_element_type_326 = None
    select_127 = torch.ops.aten.select.int(clone_37, 2, 0);  clone_37 = None
    unsqueeze_75 = torch.ops.aten.unsqueeze.default(select_127, -1);  select_127 = None
    mul_178 = torch.ops.aten.mul.Tensor(sub_8, unsqueeze_75);  sub_8 = unsqueeze_75 = None
    unsqueeze_78 = torch.ops.aten.unsqueeze.default(mul_178, -2);  mul_178 = None
    mul_179 = torch.ops.aten.mul.Tensor(unsqueeze_77, unsqueeze_78);  unsqueeze_77 = unsqueeze_78 = None
    add_143 = torch.ops.aten.add.Tensor(mul_176, mul_179);  mul_176 = mul_179 = None
    view_233 = torch.ops.aten.reshape.default(getitem_22, [1, 1, -1, 128]);  getitem_22 = None
    permute_132 = torch.ops.aten.permute.default(view_233, [0, 2, 1, 3]);  view_233 = None
    convert_element_type_323 = torch.ops.prims.convert_element_type.default(permute_132, torch.float32);  permute_132 = None
    clone_34 = torch.ops.aten.clone.default(convert_element_type_323, memory_format = torch.contiguous_format);  convert_element_type_323 = None
    mul_172 = torch.ops.aten.mul.Tensor(clone_34, clone_34)
    sum_27 = torch.ops.aten.sum.dim_IntList(mul_172, [-1], True);  mul_172 = None
    add_141 = torch.ops.aten.add.Tensor(sum_27, 1e-06);  sum_27 = None
    rsqrt_39 = torch.ops.aten.rsqrt.default(add_141);  add_141 = None
    mul_173 = torch.ops.aten.mul.Tensor(clone_34, rsqrt_39);  clone_34 = rsqrt_39 = None
    div_29 = torch.ops.aten.div.Tensor(mul_173, 11.313708498984761);  mul_173 = None
    select_123 = torch.ops.aten.select.int(div_29, 2, 0);  div_29 = None
    unsqueeze_79 = torch.ops.aten.unsqueeze.default(select_123, -1);  select_123 = None
    mul_180 = torch.ops.aten.mul.Tensor(add_143, unsqueeze_79);  unsqueeze_79 = None
    sum_30 = torch.ops.aten.sum.dim_IntList(mul_180, [-2]);  mul_180 = None
    select_scatter_default_10 = torch.ops.aten.select_scatter.default(full_default_8, sum_30, 2, 0);  full_default_8 = sum_30 = None
    permute_138 = torch.ops.aten.permute.default(select_scatter_default_10, [0, 2, 1, 3]);  select_scatter_default_10 = None
    convert_element_type_327 = torch.ops.prims.convert_element_type.default(permute_138, torch.bfloat16);  permute_138 = None
    view_236 = torch.ops.aten.reshape.default(convert_element_type_327, [-1, 128]);  convert_element_type_327 = None
    convert_element_type_328 = torch.ops.prims.convert_element_type.default(view_236, torch.float32);  view_236 = None
    pow_28 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_328, 2)
    mean_27 = torch.ops.aten.mean.dim(pow_28, [-1], True);  pow_28 = None
    add_144 = torch.ops.aten.add.Tensor(mean_27, 1e-06);  mean_27 = None
    rsqrt_41 = torch.ops.aten.rsqrt.default(add_144);  add_144 = None
    mul_181 = torch.ops.aten.mul.Tensor(convert_element_type_328, rsqrt_41);  convert_element_type_328 = rsqrt_41 = None
    convert_element_type_329 = torch.ops.prims.convert_element_type.default(mul_181, torch.bfloat16);  mul_181 = None
    mul_182 = torch.ops.aten.mul.Tensor(arg138_1, convert_element_type_329);  arg138_1 = convert_element_type_329 = None
    view_222 = torch.ops.aten.reshape.default(convert_element_type_308, [1, 2048]);  convert_element_type_308 = None
    permute_128 = torch.ops.aten.permute.default(arg130_1, [1, 0]);  arg130_1 = None
    mm_63 = torch.ops.aten.mm.default(view_222, permute_128);  view_222 = permute_128 = None
    view_223 = torch.ops.aten.reshape.default(mm_63, [1, 1, 2048]);  mm_63 = None
    view_224 = torch.ops.aten.reshape.default(view_223, [1, 1, -1, 128]);  view_223 = None
    view_237 = torch.ops.aten.reshape.default(view_224, [-1, 128]);  view_224 = None
    convert_element_type_330 = torch.ops.prims.convert_element_type.default(view_237, torch.float32);  view_237 = None
    neg_32 = torch.ops.aten.neg.default(convert_element_type_330)
    exp_44 = torch.ops.aten.exp.default(neg_32);  neg_32 = None
    add_145 = torch.ops.aten.add.Tensor(exp_44, 1);  exp_44 = None
    div_30 = torch.ops.aten.div.Tensor(convert_element_type_330, add_145);  convert_element_type_330 = add_145 = None
    mul_183 = torch.ops.aten.mul.Tensor(mul_182, div_30);  mul_182 = div_30 = None
    convert_element_type_331 = torch.ops.prims.convert_element_type.default(mul_183, torch.bfloat16);  mul_183 = None
    view_238 = torch.ops.aten.reshape.default(convert_element_type_331, [1, 1, -1]);  convert_element_type_331 = None
    view_239 = torch.ops.aten.reshape.default(view_238, [1, 2048]);  view_238 = None
    permute_139 = torch.ops.aten.permute.default(arg139_1, [1, 0]);  arg139_1 = None
    mm_66 = torch.ops.aten.mm.default(view_239, permute_139);  view_239 = permute_139 = None
    view_240 = torch.ops.aten.reshape.default(mm_66, [1, 1, 2048]);  mm_66 = None
    add_146 = torch.ops.aten.add.Tensor(add_133, view_240);  add_133 = view_240 = None
    convert_element_type_334 = torch.ops.prims.convert_element_type.default(add_146, torch.float32)
    pow_29 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_334, 2)
    mean_28 = torch.ops.aten.mean.dim(pow_29, [-1], True);  pow_29 = None
    add_147 = torch.ops.aten.add.Tensor(mean_28, 1e-06);  mean_28 = None
    rsqrt_42 = torch.ops.aten.rsqrt.default(add_147);  add_147 = None
    mul_184 = torch.ops.aten.mul.Tensor(convert_element_type_334, rsqrt_42);  convert_element_type_334 = rsqrt_42 = None
    convert_element_type_335 = torch.ops.prims.convert_element_type.default(arg140_1, torch.float32);  arg140_1 = None
    add_148 = torch.ops.aten.add.Tensor(convert_element_type_335, 1.0);  convert_element_type_335 = None
    mul_185 = torch.ops.aten.mul.Tensor(mul_184, add_148);  mul_184 = add_148 = None
    convert_element_type_336 = torch.ops.prims.convert_element_type.default(mul_185, torch.bfloat16);  mul_185 = None
    view_241 = torch.ops.aten.reshape.default(convert_element_type_336, [1, 2048])
    permute_140 = torch.ops.aten.permute.default(arg141_1, [1, 0]);  arg141_1 = None
    mm_67 = torch.ops.aten.mm.default(view_241, permute_140);  view_241 = permute_140 = None
    view_242 = torch.ops.aten.reshape.default(mm_67, [1, 1, 6144]);  mm_67 = None
    convert_element_type_339 = torch.ops.prims.convert_element_type.default(view_242, torch.float32);  view_242 = None
    neg_33 = torch.ops.aten.neg.default(convert_element_type_339)
    exp_45 = torch.ops.aten.exp.default(neg_33);  neg_33 = None
    add_149 = torch.ops.aten.add.Tensor(exp_45, 1);  exp_45 = None
    div_31 = torch.ops.aten.div.Tensor(convert_element_type_339, add_149);  convert_element_type_339 = add_149 = None
    convert_element_type_340 = torch.ops.prims.convert_element_type.default(div_31, torch.bfloat16);  div_31 = None
    view_243 = torch.ops.aten.reshape.default(convert_element_type_336, [1, 2048]);  convert_element_type_336 = None
    permute_141 = torch.ops.aten.permute.default(arg142_1, [1, 0]);  arg142_1 = None
    mm_68 = torch.ops.aten.mm.default(view_243, permute_141);  view_243 = permute_141 = None
    view_244 = torch.ops.aten.reshape.default(mm_68, [1, 1, 6144]);  mm_68 = None
    mul_186 = torch.ops.aten.mul.Tensor(convert_element_type_340, view_244);  convert_element_type_340 = view_244 = None
    view_245 = torch.ops.aten.reshape.default(mul_186, [1, 6144]);  mul_186 = None
    permute_142 = torch.ops.aten.permute.default(arg143_1, [1, 0]);  arg143_1 = None
    mm_69 = torch.ops.aten.mm.default(view_245, permute_142);  view_245 = permute_142 = None
    view_246 = torch.ops.aten.reshape.default(mm_69, [1, 1, 2048]);  mm_69 = None
    add_150 = torch.ops.aten.add.Tensor(add_146, view_246);  add_146 = view_246 = None
    convert_element_type_345 = torch.ops.prims.convert_element_type.default(add_150, torch.float32)
    pow_30 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_345, 2)
    mean_29 = torch.ops.aten.mean.dim(pow_30, [-1], True);  pow_30 = None
    add_151 = torch.ops.aten.add.Tensor(mean_29, 1e-06);  mean_29 = None
    rsqrt_43 = torch.ops.aten.rsqrt.default(add_151);  add_151 = None
    mul_187 = torch.ops.aten.mul.Tensor(convert_element_type_345, rsqrt_43);  convert_element_type_345 = rsqrt_43 = None
    convert_element_type_346 = torch.ops.prims.convert_element_type.default(arg144_1, torch.float32);  arg144_1 = None
    add_152 = torch.ops.aten.add.Tensor(convert_element_type_346, 1.0);  convert_element_type_346 = None
    mul_188 = torch.ops.aten.mul.Tensor(mul_187, add_152);  mul_187 = add_152 = None
    convert_element_type_347 = torch.ops.prims.convert_element_type.default(mul_188, torch.bfloat16);  mul_188 = None
    view_247 = torch.ops.aten.reshape.default(convert_element_type_347, [1, 2048])
    permute_143 = torch.ops.aten.permute.default(arg145_1, [1, 0]);  arg145_1 = None
    mm_70 = torch.ops.aten.mm.default(view_247, permute_143);  view_247 = permute_143 = None
    view_248 = torch.ops.aten.reshape.default(mm_70, [1, 1, 6144]);  mm_70 = None
    permute_144 = torch.ops.aten.permute.default(view_248, [0, 2, 1]);  view_248 = None
    cat_15 = torch.ops.aten.cat.default([arg149_1, permute_144], -1);  permute_144 = None
    slice_76 = torch.ops.aten.slice.Tensor(cat_15, 2, -4, 9223372036854775807)
    copy_25 = torch.ops.aten.copy.default(arg149_1, slice_76);  slice_76 = None
    convert_element_type_356 = torch.ops.prims.convert_element_type.default(cat_15, torch.float32);  cat_15 = None
    slice_77 = torch.ops.aten.slice.Tensor(convert_element_type_356, 2, 0, 2)
    squeeze_7 = torch.ops.aten.squeeze.dim(arg150_1, 1);  arg150_1 = None
    unsqueeze_80 = torch.ops.aten.unsqueeze.default(squeeze_7, 1);  squeeze_7 = None
    convert_element_type_357 = torch.ops.prims.convert_element_type.default(unsqueeze_80, torch.float32);  unsqueeze_80 = None
    select_130 = torch.ops.aten.select.int(convert_element_type_357, 1, 0)
    select_131 = torch.ops.aten.select.int(select_130, 1, 0);  select_130 = None
    view_256 = torch.ops.aten.reshape.default(select_131, [1, -1, 1]);  select_131 = None
    mul_189 = torch.ops.aten.mul.Tensor(slice_77, view_256);  slice_77 = view_256 = None
    slice_78 = torch.ops.aten.slice.Tensor(convert_element_type_356, 2, 1, 3)
    select_132 = torch.ops.aten.select.int(convert_element_type_357, 1, 0)
    select_133 = torch.ops.aten.select.int(select_132, 1, 1);  select_132 = None
    view_257 = torch.ops.aten.reshape.default(select_133, [1, -1, 1]);  select_133 = None
    mul_190 = torch.ops.aten.mul.Tensor(slice_78, view_257);  slice_78 = view_257 = None
    add_153 = torch.ops.aten.add.Tensor(mul_189, mul_190);  mul_189 = mul_190 = None
    slice_79 = torch.ops.aten.slice.Tensor(convert_element_type_356, 2, 2, 4)
    select_134 = torch.ops.aten.select.int(convert_element_type_357, 1, 0)
    select_135 = torch.ops.aten.select.int(select_134, 1, 2);  select_134 = None
    view_258 = torch.ops.aten.reshape.default(select_135, [1, -1, 1]);  select_135 = None
    mul_191 = torch.ops.aten.mul.Tensor(slice_79, view_258);  slice_79 = view_258 = None
    add_154 = torch.ops.aten.add.Tensor(add_153, mul_191);  add_153 = mul_191 = None
    slice_80 = torch.ops.aten.slice.Tensor(convert_element_type_356, 2, 3, 5);  convert_element_type_356 = None
    select_136 = torch.ops.aten.select.int(convert_element_type_357, 1, 0);  convert_element_type_357 = None
    select_137 = torch.ops.aten.select.int(select_136, 1, 3);  select_136 = None
    view_259 = torch.ops.aten.reshape.default(select_137, [1, -1, 1]);  select_137 = None
    mul_192 = torch.ops.aten.mul.Tensor(slice_80, view_259);  slice_80 = view_259 = None
    add_155 = torch.ops.aten.add.Tensor(add_154, mul_192);  add_154 = mul_192 = None
    convert_element_type_358 = torch.ops.prims.convert_element_type.default(add_155, torch.bfloat16);  add_155 = None
    slice_81 = torch.ops.aten.slice.Tensor(convert_element_type_358, 2, -1, 9223372036854775807);  convert_element_type_358 = None
    convert_element_type_359 = torch.ops.prims.convert_element_type.default(slice_81, torch.float32);  slice_81 = None
    neg_34 = torch.ops.aten.neg.default(convert_element_type_359)
    exp_46 = torch.ops.aten.exp.default(neg_34);  neg_34 = None
    add_156 = torch.ops.aten.add.Tensor(exp_46, 1);  exp_46 = None
    div_32 = torch.ops.aten.div.Tensor(convert_element_type_359, add_156);  convert_element_type_359 = add_156 = None
    convert_element_type_360 = torch.ops.prims.convert_element_type.default(div_32, torch.bfloat16);  div_32 = None
    permute_148 = torch.ops.aten.permute.default(convert_element_type_360, [0, 2, 1]);  convert_element_type_360 = None
    split_with_sizes_7 = torch.ops.aten.split_with_sizes.default(permute_148, [2048, 2048, 2048], -1);  permute_148 = None
    getitem_25 = split_with_sizes_7[0]
    getitem_26 = split_with_sizes_7[1]
    getitem_27 = split_with_sizes_7[2];  split_with_sizes_7 = None
    full_default_9 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_143 = torch.ops.aten.select.int(full_default_9, 2, 0);  select_143 = None
    view_261 = torch.ops.aten.reshape.default(getitem_26, [1, 1, -1, 128]);  getitem_26 = None
    permute_150 = torch.ops.aten.permute.default(view_261, [0, 2, 1, 3]);  view_261 = None
    convert_element_type_363 = torch.ops.prims.convert_element_type.default(permute_150, torch.float32);  permute_150 = None
    clone_39 = torch.ops.aten.clone.default(convert_element_type_363, memory_format = torch.contiguous_format);  convert_element_type_363 = None
    mul_196 = torch.ops.aten.mul.Tensor(clone_39, clone_39)
    sum_32 = torch.ops.aten.sum.dim_IntList(mul_196, [-1], True);  mul_196 = None
    add_159 = torch.ops.aten.add.Tensor(sum_32, 1e-06);  sum_32 = None
    rsqrt_45 = torch.ops.aten.rsqrt.default(add_159);  add_159 = None
    mul_197 = torch.ops.aten.mul.Tensor(clone_39, rsqrt_45);  clone_39 = rsqrt_45 = None
    select_139 = torch.ops.aten.select.int(mul_197, 2, 0);  mul_197 = None
    unsqueeze_85 = torch.ops.aten.unsqueeze.default(select_139, -1)
    view_262 = torch.ops.aten.reshape.default(getitem_27, [1, 1, -1, 128]);  getitem_27 = None
    permute_151 = torch.ops.aten.permute.default(view_262, [0, 2, 1, 3]);  view_262 = None
    convert_element_type_364 = torch.ops.prims.convert_element_type.default(permute_151, torch.float32);  permute_151 = None
    clone_40 = torch.ops.aten.clone.default(convert_element_type_364, memory_format = torch.contiguous_format);  convert_element_type_364 = None
    select_140 = torch.ops.aten.select.int(clone_40, 2, 0);  clone_40 = None
    exp_47 = torch.ops.aten.exp.default(arg151_1);  arg151_1 = None
    neg_35 = torch.ops.aten.neg.default(exp_47);  exp_47 = None
    view_254 = torch.ops.aten.reshape.default(convert_element_type_347, [1, 2048])
    permute_147 = torch.ops.aten.permute.default(arg148_1, [1, 0]);  arg148_1 = None
    mm_73 = torch.ops.aten.mm.default(view_254, permute_147);  view_254 = permute_147 = None
    view_255 = torch.ops.aten.reshape.default(mm_73, [1, 1, 16]);  mm_73 = None
    convert_element_type_361 = torch.ops.prims.convert_element_type.default(view_255, torch.float32);  view_255 = None
    add_157 = torch.ops.aten.add.Tensor(convert_element_type_361, arg152_1);  convert_element_type_361 = arg152_1 = None
    gt_7 = torch.ops.aten.gt.Scalar(add_157, 20)
    exp_48 = torch.ops.aten.exp.default(add_157)
    log1p_7 = torch.ops.aten.log1p.default(exp_48);  exp_48 = None
    where_8 = torch.ops.aten.where.self(gt_7, add_157, log1p_7);  gt_7 = add_157 = log1p_7 = None
    mul_193 = torch.ops.aten.mul.Tensor(neg_35, where_8);  neg_35 = where_8 = None
    permute_153 = torch.ops.aten.permute.default(mul_193, [0, 2, 1]);  mul_193 = None
    select_141 = torch.ops.aten.select.int(permute_153, 2, 0);  permute_153 = None
    exp_49 = torch.ops.aten.exp.default(select_141);  select_141 = None
    unsqueeze_81 = torch.ops.aten.unsqueeze.default(exp_49, 2);  exp_49 = None
    unsqueeze_82 = torch.ops.aten.unsqueeze.default(unsqueeze_81, 3);  unsqueeze_81 = None
    mul_198 = torch.ops.aten.mul.Tensor(arg153_1, unsqueeze_82);  unsqueeze_82 = None
    unsqueeze_84 = torch.ops.aten.unsqueeze.default(select_139, -1);  select_139 = None
    mul_199 = torch.ops.aten.mul.Tensor(mul_198, unsqueeze_84);  unsqueeze_84 = None
    sum_33 = torch.ops.aten.sum.dim_IntList(mul_199, [-2]);  mul_199 = None
    sub_9 = torch.ops.aten.sub.Tensor(select_140, sum_33);  select_140 = sum_33 = None
    view_252 = torch.ops.aten.reshape.default(convert_element_type_347, [1, 2048])
    permute_146 = torch.ops.aten.permute.default(arg147_1, [1, 0]);  arg147_1 = None
    mm_72 = torch.ops.aten.mm.default(view_252, permute_146);  view_252 = permute_146 = None
    view_253 = torch.ops.aten.reshape.default(mm_72, [1, 1, 16]);  mm_72 = None
    sigmoid_9 = torch.ops.aten.sigmoid.default(view_253);  view_253 = None
    permute_152 = torch.ops.aten.permute.default(sigmoid_9, [0, 2, 1]);  sigmoid_9 = None
    convert_element_type_365 = torch.ops.prims.convert_element_type.default(permute_152, torch.float32);  permute_152 = None
    clone_41 = torch.ops.aten.clone.default(convert_element_type_365, memory_format = torch.contiguous_format);  convert_element_type_365 = None
    select_142 = torch.ops.aten.select.int(clone_41, 2, 0);  clone_41 = None
    unsqueeze_83 = torch.ops.aten.unsqueeze.default(select_142, -1);  select_142 = None
    mul_200 = torch.ops.aten.mul.Tensor(sub_9, unsqueeze_83);  sub_9 = unsqueeze_83 = None
    unsqueeze_86 = torch.ops.aten.unsqueeze.default(mul_200, -2);  mul_200 = None
    mul_201 = torch.ops.aten.mul.Tensor(unsqueeze_85, unsqueeze_86);  unsqueeze_85 = unsqueeze_86 = None
    add_160 = torch.ops.aten.add.Tensor(mul_198, mul_201);  mul_198 = mul_201 = None
    view_260 = torch.ops.aten.reshape.default(getitem_25, [1, 1, -1, 128]);  getitem_25 = None
    permute_149 = torch.ops.aten.permute.default(view_260, [0, 2, 1, 3]);  view_260 = None
    convert_element_type_362 = torch.ops.prims.convert_element_type.default(permute_149, torch.float32);  permute_149 = None
    clone_38 = torch.ops.aten.clone.default(convert_element_type_362, memory_format = torch.contiguous_format);  convert_element_type_362 = None
    mul_194 = torch.ops.aten.mul.Tensor(clone_38, clone_38)
    sum_31 = torch.ops.aten.sum.dim_IntList(mul_194, [-1], True);  mul_194 = None
    add_158 = torch.ops.aten.add.Tensor(sum_31, 1e-06);  sum_31 = None
    rsqrt_44 = torch.ops.aten.rsqrt.default(add_158);  add_158 = None
    mul_195 = torch.ops.aten.mul.Tensor(clone_38, rsqrt_44);  clone_38 = rsqrt_44 = None
    div_33 = torch.ops.aten.div.Tensor(mul_195, 11.313708498984761);  mul_195 = None
    select_138 = torch.ops.aten.select.int(div_33, 2, 0);  div_33 = None
    unsqueeze_87 = torch.ops.aten.unsqueeze.default(select_138, -1);  select_138 = None
    mul_202 = torch.ops.aten.mul.Tensor(add_160, unsqueeze_87);  unsqueeze_87 = None
    sum_34 = torch.ops.aten.sum.dim_IntList(mul_202, [-2]);  mul_202 = None
    select_scatter_default_11 = torch.ops.aten.select_scatter.default(full_default_9, sum_34, 2, 0);  full_default_9 = sum_34 = None
    permute_155 = torch.ops.aten.permute.default(select_scatter_default_11, [0, 2, 1, 3]);  select_scatter_default_11 = None
    convert_element_type_366 = torch.ops.prims.convert_element_type.default(permute_155, torch.bfloat16);  permute_155 = None
    view_263 = torch.ops.aten.reshape.default(convert_element_type_366, [-1, 128]);  convert_element_type_366 = None
    convert_element_type_367 = torch.ops.prims.convert_element_type.default(view_263, torch.float32);  view_263 = None
    pow_31 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_367, 2)
    mean_30 = torch.ops.aten.mean.dim(pow_31, [-1], True);  pow_31 = None
    add_161 = torch.ops.aten.add.Tensor(mean_30, 1e-06);  mean_30 = None
    rsqrt_46 = torch.ops.aten.rsqrt.default(add_161);  add_161 = None
    mul_203 = torch.ops.aten.mul.Tensor(convert_element_type_367, rsqrt_46);  convert_element_type_367 = rsqrt_46 = None
    convert_element_type_368 = torch.ops.prims.convert_element_type.default(mul_203, torch.bfloat16);  mul_203 = None
    mul_204 = torch.ops.aten.mul.Tensor(arg154_1, convert_element_type_368);  arg154_1 = convert_element_type_368 = None
    view_249 = torch.ops.aten.reshape.default(convert_element_type_347, [1, 2048]);  convert_element_type_347 = None
    permute_145 = torch.ops.aten.permute.default(arg146_1, [1, 0]);  arg146_1 = None
    mm_71 = torch.ops.aten.mm.default(view_249, permute_145);  view_249 = permute_145 = None
    view_250 = torch.ops.aten.reshape.default(mm_71, [1, 1, 2048]);  mm_71 = None
    view_251 = torch.ops.aten.reshape.default(view_250, [1, 1, -1, 128]);  view_250 = None
    view_264 = torch.ops.aten.reshape.default(view_251, [-1, 128]);  view_251 = None
    convert_element_type_369 = torch.ops.prims.convert_element_type.default(view_264, torch.float32);  view_264 = None
    neg_36 = torch.ops.aten.neg.default(convert_element_type_369)
    exp_50 = torch.ops.aten.exp.default(neg_36);  neg_36 = None
    add_162 = torch.ops.aten.add.Tensor(exp_50, 1);  exp_50 = None
    div_34 = torch.ops.aten.div.Tensor(convert_element_type_369, add_162);  convert_element_type_369 = add_162 = None
    mul_205 = torch.ops.aten.mul.Tensor(mul_204, div_34);  mul_204 = div_34 = None
    convert_element_type_370 = torch.ops.prims.convert_element_type.default(mul_205, torch.bfloat16);  mul_205 = None
    view_265 = torch.ops.aten.reshape.default(convert_element_type_370, [1, 1, -1]);  convert_element_type_370 = None
    view_266 = torch.ops.aten.reshape.default(view_265, [1, 2048]);  view_265 = None
    permute_156 = torch.ops.aten.permute.default(arg155_1, [1, 0]);  arg155_1 = None
    mm_74 = torch.ops.aten.mm.default(view_266, permute_156);  view_266 = permute_156 = None
    view_267 = torch.ops.aten.reshape.default(mm_74, [1, 1, 2048]);  mm_74 = None
    add_163 = torch.ops.aten.add.Tensor(add_150, view_267);  add_150 = view_267 = None
    convert_element_type_373 = torch.ops.prims.convert_element_type.default(add_163, torch.float32)
    pow_32 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_373, 2)
    mean_31 = torch.ops.aten.mean.dim(pow_32, [-1], True);  pow_32 = None
    add_164 = torch.ops.aten.add.Tensor(mean_31, 1e-06);  mean_31 = None
    rsqrt_47 = torch.ops.aten.rsqrt.default(add_164);  add_164 = None
    mul_206 = torch.ops.aten.mul.Tensor(convert_element_type_373, rsqrt_47);  convert_element_type_373 = rsqrt_47 = None
    convert_element_type_374 = torch.ops.prims.convert_element_type.default(arg156_1, torch.float32);  arg156_1 = None
    add_165 = torch.ops.aten.add.Tensor(convert_element_type_374, 1.0);  convert_element_type_374 = None
    mul_207 = torch.ops.aten.mul.Tensor(mul_206, add_165);  mul_206 = add_165 = None
    convert_element_type_375 = torch.ops.prims.convert_element_type.default(mul_207, torch.bfloat16);  mul_207 = None
    view_268 = torch.ops.aten.reshape.default(convert_element_type_375, [1, 2048])
    permute_157 = torch.ops.aten.permute.default(arg157_1, [1, 0]);  arg157_1 = None
    mm_75 = torch.ops.aten.mm.default(view_268, permute_157);  view_268 = permute_157 = None
    view_269 = torch.ops.aten.reshape.default(mm_75, [1, 1, 6144]);  mm_75 = None
    convert_element_type_378 = torch.ops.prims.convert_element_type.default(view_269, torch.float32);  view_269 = None
    neg_37 = torch.ops.aten.neg.default(convert_element_type_378)
    exp_51 = torch.ops.aten.exp.default(neg_37);  neg_37 = None
    add_166 = torch.ops.aten.add.Tensor(exp_51, 1);  exp_51 = None
    div_35 = torch.ops.aten.div.Tensor(convert_element_type_378, add_166);  convert_element_type_378 = add_166 = None
    convert_element_type_379 = torch.ops.prims.convert_element_type.default(div_35, torch.bfloat16);  div_35 = None
    view_270 = torch.ops.aten.reshape.default(convert_element_type_375, [1, 2048]);  convert_element_type_375 = None
    permute_158 = torch.ops.aten.permute.default(arg158_1, [1, 0]);  arg158_1 = None
    mm_76 = torch.ops.aten.mm.default(view_270, permute_158);  view_270 = permute_158 = None
    view_271 = torch.ops.aten.reshape.default(mm_76, [1, 1, 6144]);  mm_76 = None
    mul_208 = torch.ops.aten.mul.Tensor(convert_element_type_379, view_271);  convert_element_type_379 = view_271 = None
    view_272 = torch.ops.aten.reshape.default(mul_208, [1, 6144]);  mul_208 = None
    permute_159 = torch.ops.aten.permute.default(arg159_1, [1, 0]);  arg159_1 = None
    mm_77 = torch.ops.aten.mm.default(view_272, permute_159);  view_272 = permute_159 = None
    view_273 = torch.ops.aten.reshape.default(mm_77, [1, 1, 2048]);  mm_77 = None
    add_167 = torch.ops.aten.add.Tensor(add_163, view_273);  add_163 = view_273 = None
    convert_element_type_384 = torch.ops.prims.convert_element_type.default(add_167, torch.float32)
    pow_33 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_384, 2)
    mean_32 = torch.ops.aten.mean.dim(pow_33, [-1], True);  pow_33 = None
    add_168 = torch.ops.aten.add.Tensor(mean_32, 1e-06);  mean_32 = None
    rsqrt_48 = torch.ops.aten.rsqrt.default(add_168);  add_168 = None
    mul_209 = torch.ops.aten.mul.Tensor(convert_element_type_384, rsqrt_48);  convert_element_type_384 = rsqrt_48 = None
    convert_element_type_385 = torch.ops.prims.convert_element_type.default(arg160_1, torch.float32);  arg160_1 = None
    add_169 = torch.ops.aten.add.Tensor(convert_element_type_385, 1.0);  convert_element_type_385 = None
    mul_210 = torch.ops.aten.mul.Tensor(mul_209, add_169);  mul_209 = add_169 = None
    convert_element_type_386 = torch.ops.prims.convert_element_type.default(mul_210, torch.bfloat16);  mul_210 = None
    view_274 = torch.ops.aten.reshape.default(convert_element_type_386, [1, 2048])
    permute_160 = torch.ops.aten.permute.default(arg161_1, [1, 0]);  arg161_1 = None
    mm_78 = torch.ops.aten.mm.default(view_274, permute_160);  view_274 = permute_160 = None
    view_275 = torch.ops.aten.reshape.default(mm_78, [1, 1, 6144]);  mm_78 = None
    permute_161 = torch.ops.aten.permute.default(view_275, [0, 2, 1]);  view_275 = None
    cat_16 = torch.ops.aten.cat.default([arg165_1, permute_161], -1);  permute_161 = None
    slice_82 = torch.ops.aten.slice.Tensor(cat_16, 2, -4, 9223372036854775807)
    copy_28 = torch.ops.aten.copy.default(arg165_1, slice_82);  slice_82 = None
    convert_element_type_395 = torch.ops.prims.convert_element_type.default(cat_16, torch.float32);  cat_16 = None
    slice_83 = torch.ops.aten.slice.Tensor(convert_element_type_395, 2, 0, 2)
    squeeze_8 = torch.ops.aten.squeeze.dim(arg166_1, 1);  arg166_1 = None
    unsqueeze_88 = torch.ops.aten.unsqueeze.default(squeeze_8, 1);  squeeze_8 = None
    convert_element_type_396 = torch.ops.prims.convert_element_type.default(unsqueeze_88, torch.float32);  unsqueeze_88 = None
    select_145 = torch.ops.aten.select.int(convert_element_type_396, 1, 0)
    select_146 = torch.ops.aten.select.int(select_145, 1, 0);  select_145 = None
    view_283 = torch.ops.aten.reshape.default(select_146, [1, -1, 1]);  select_146 = None
    mul_211 = torch.ops.aten.mul.Tensor(slice_83, view_283);  slice_83 = view_283 = None
    slice_84 = torch.ops.aten.slice.Tensor(convert_element_type_395, 2, 1, 3)
    select_147 = torch.ops.aten.select.int(convert_element_type_396, 1, 0)
    select_148 = torch.ops.aten.select.int(select_147, 1, 1);  select_147 = None
    view_284 = torch.ops.aten.reshape.default(select_148, [1, -1, 1]);  select_148 = None
    mul_212 = torch.ops.aten.mul.Tensor(slice_84, view_284);  slice_84 = view_284 = None
    add_170 = torch.ops.aten.add.Tensor(mul_211, mul_212);  mul_211 = mul_212 = None
    slice_85 = torch.ops.aten.slice.Tensor(convert_element_type_395, 2, 2, 4)
    select_149 = torch.ops.aten.select.int(convert_element_type_396, 1, 0)
    select_150 = torch.ops.aten.select.int(select_149, 1, 2);  select_149 = None
    view_285 = torch.ops.aten.reshape.default(select_150, [1, -1, 1]);  select_150 = None
    mul_213 = torch.ops.aten.mul.Tensor(slice_85, view_285);  slice_85 = view_285 = None
    add_171 = torch.ops.aten.add.Tensor(add_170, mul_213);  add_170 = mul_213 = None
    slice_86 = torch.ops.aten.slice.Tensor(convert_element_type_395, 2, 3, 5);  convert_element_type_395 = None
    select_151 = torch.ops.aten.select.int(convert_element_type_396, 1, 0);  convert_element_type_396 = None
    select_152 = torch.ops.aten.select.int(select_151, 1, 3);  select_151 = None
    view_286 = torch.ops.aten.reshape.default(select_152, [1, -1, 1]);  select_152 = None
    mul_214 = torch.ops.aten.mul.Tensor(slice_86, view_286);  slice_86 = view_286 = None
    add_172 = torch.ops.aten.add.Tensor(add_171, mul_214);  add_171 = mul_214 = None
    convert_element_type_397 = torch.ops.prims.convert_element_type.default(add_172, torch.bfloat16);  add_172 = None
    slice_87 = torch.ops.aten.slice.Tensor(convert_element_type_397, 2, -1, 9223372036854775807);  convert_element_type_397 = None
    convert_element_type_398 = torch.ops.prims.convert_element_type.default(slice_87, torch.float32);  slice_87 = None
    neg_38 = torch.ops.aten.neg.default(convert_element_type_398)
    exp_52 = torch.ops.aten.exp.default(neg_38);  neg_38 = None
    add_173 = torch.ops.aten.add.Tensor(exp_52, 1);  exp_52 = None
    div_36 = torch.ops.aten.div.Tensor(convert_element_type_398, add_173);  convert_element_type_398 = add_173 = None
    convert_element_type_399 = torch.ops.prims.convert_element_type.default(div_36, torch.bfloat16);  div_36 = None
    permute_165 = torch.ops.aten.permute.default(convert_element_type_399, [0, 2, 1]);  convert_element_type_399 = None
    split_with_sizes_8 = torch.ops.aten.split_with_sizes.default(permute_165, [2048, 2048, 2048], -1);  permute_165 = None
    getitem_28 = split_with_sizes_8[0]
    getitem_29 = split_with_sizes_8[1]
    getitem_30 = split_with_sizes_8[2];  split_with_sizes_8 = None
    full_default_10 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_158 = torch.ops.aten.select.int(full_default_10, 2, 0);  select_158 = None
    view_288 = torch.ops.aten.reshape.default(getitem_29, [1, 1, -1, 128]);  getitem_29 = None
    permute_167 = torch.ops.aten.permute.default(view_288, [0, 2, 1, 3]);  view_288 = None
    convert_element_type_402 = torch.ops.prims.convert_element_type.default(permute_167, torch.float32);  permute_167 = None
    clone_43 = torch.ops.aten.clone.default(convert_element_type_402, memory_format = torch.contiguous_format);  convert_element_type_402 = None
    mul_218 = torch.ops.aten.mul.Tensor(clone_43, clone_43)
    sum_36 = torch.ops.aten.sum.dim_IntList(mul_218, [-1], True);  mul_218 = None
    add_176 = torch.ops.aten.add.Tensor(sum_36, 1e-06);  sum_36 = None
    rsqrt_50 = torch.ops.aten.rsqrt.default(add_176);  add_176 = None
    mul_219 = torch.ops.aten.mul.Tensor(clone_43, rsqrt_50);  clone_43 = rsqrt_50 = None
    select_154 = torch.ops.aten.select.int(mul_219, 2, 0);  mul_219 = None
    unsqueeze_93 = torch.ops.aten.unsqueeze.default(select_154, -1)
    view_289 = torch.ops.aten.reshape.default(getitem_30, [1, 1, -1, 128]);  getitem_30 = None
    permute_168 = torch.ops.aten.permute.default(view_289, [0, 2, 1, 3]);  view_289 = None
    convert_element_type_403 = torch.ops.prims.convert_element_type.default(permute_168, torch.float32);  permute_168 = None
    clone_44 = torch.ops.aten.clone.default(convert_element_type_403, memory_format = torch.contiguous_format);  convert_element_type_403 = None
    select_155 = torch.ops.aten.select.int(clone_44, 2, 0);  clone_44 = None
    exp_53 = torch.ops.aten.exp.default(arg167_1);  arg167_1 = None
    neg_39 = torch.ops.aten.neg.default(exp_53);  exp_53 = None
    view_281 = torch.ops.aten.reshape.default(convert_element_type_386, [1, 2048])
    permute_164 = torch.ops.aten.permute.default(arg164_1, [1, 0]);  arg164_1 = None
    mm_81 = torch.ops.aten.mm.default(view_281, permute_164);  view_281 = permute_164 = None
    view_282 = torch.ops.aten.reshape.default(mm_81, [1, 1, 16]);  mm_81 = None
    convert_element_type_400 = torch.ops.prims.convert_element_type.default(view_282, torch.float32);  view_282 = None
    add_174 = torch.ops.aten.add.Tensor(convert_element_type_400, arg168_1);  convert_element_type_400 = arg168_1 = None
    gt_8 = torch.ops.aten.gt.Scalar(add_174, 20)
    exp_54 = torch.ops.aten.exp.default(add_174)
    log1p_8 = torch.ops.aten.log1p.default(exp_54);  exp_54 = None
    where_9 = torch.ops.aten.where.self(gt_8, add_174, log1p_8);  gt_8 = add_174 = log1p_8 = None
    mul_215 = torch.ops.aten.mul.Tensor(neg_39, where_9);  neg_39 = where_9 = None
    permute_170 = torch.ops.aten.permute.default(mul_215, [0, 2, 1]);  mul_215 = None
    select_156 = torch.ops.aten.select.int(permute_170, 2, 0);  permute_170 = None
    exp_55 = torch.ops.aten.exp.default(select_156);  select_156 = None
    unsqueeze_89 = torch.ops.aten.unsqueeze.default(exp_55, 2);  exp_55 = None
    unsqueeze_90 = torch.ops.aten.unsqueeze.default(unsqueeze_89, 3);  unsqueeze_89 = None
    mul_220 = torch.ops.aten.mul.Tensor(arg169_1, unsqueeze_90);  unsqueeze_90 = None
    unsqueeze_92 = torch.ops.aten.unsqueeze.default(select_154, -1);  select_154 = None
    mul_221 = torch.ops.aten.mul.Tensor(mul_220, unsqueeze_92);  unsqueeze_92 = None
    sum_37 = torch.ops.aten.sum.dim_IntList(mul_221, [-2]);  mul_221 = None
    sub_10 = torch.ops.aten.sub.Tensor(select_155, sum_37);  select_155 = sum_37 = None
    view_279 = torch.ops.aten.reshape.default(convert_element_type_386, [1, 2048])
    permute_163 = torch.ops.aten.permute.default(arg163_1, [1, 0]);  arg163_1 = None
    mm_80 = torch.ops.aten.mm.default(view_279, permute_163);  view_279 = permute_163 = None
    view_280 = torch.ops.aten.reshape.default(mm_80, [1, 1, 16]);  mm_80 = None
    sigmoid_10 = torch.ops.aten.sigmoid.default(view_280);  view_280 = None
    permute_169 = torch.ops.aten.permute.default(sigmoid_10, [0, 2, 1]);  sigmoid_10 = None
    convert_element_type_404 = torch.ops.prims.convert_element_type.default(permute_169, torch.float32);  permute_169 = None
    clone_45 = torch.ops.aten.clone.default(convert_element_type_404, memory_format = torch.contiguous_format);  convert_element_type_404 = None
    select_157 = torch.ops.aten.select.int(clone_45, 2, 0);  clone_45 = None
    unsqueeze_91 = torch.ops.aten.unsqueeze.default(select_157, -1);  select_157 = None
    mul_222 = torch.ops.aten.mul.Tensor(sub_10, unsqueeze_91);  sub_10 = unsqueeze_91 = None
    unsqueeze_94 = torch.ops.aten.unsqueeze.default(mul_222, -2);  mul_222 = None
    mul_223 = torch.ops.aten.mul.Tensor(unsqueeze_93, unsqueeze_94);  unsqueeze_93 = unsqueeze_94 = None
    add_177 = torch.ops.aten.add.Tensor(mul_220, mul_223);  mul_220 = mul_223 = None
    view_287 = torch.ops.aten.reshape.default(getitem_28, [1, 1, -1, 128]);  getitem_28 = None
    permute_166 = torch.ops.aten.permute.default(view_287, [0, 2, 1, 3]);  view_287 = None
    convert_element_type_401 = torch.ops.prims.convert_element_type.default(permute_166, torch.float32);  permute_166 = None
    clone_42 = torch.ops.aten.clone.default(convert_element_type_401, memory_format = torch.contiguous_format);  convert_element_type_401 = None
    mul_216 = torch.ops.aten.mul.Tensor(clone_42, clone_42)
    sum_35 = torch.ops.aten.sum.dim_IntList(mul_216, [-1], True);  mul_216 = None
    add_175 = torch.ops.aten.add.Tensor(sum_35, 1e-06);  sum_35 = None
    rsqrt_49 = torch.ops.aten.rsqrt.default(add_175);  add_175 = None
    mul_217 = torch.ops.aten.mul.Tensor(clone_42, rsqrt_49);  clone_42 = rsqrt_49 = None
    div_37 = torch.ops.aten.div.Tensor(mul_217, 11.313708498984761);  mul_217 = None
    select_153 = torch.ops.aten.select.int(div_37, 2, 0);  div_37 = None
    unsqueeze_95 = torch.ops.aten.unsqueeze.default(select_153, -1);  select_153 = None
    mul_224 = torch.ops.aten.mul.Tensor(add_177, unsqueeze_95);  unsqueeze_95 = None
    sum_38 = torch.ops.aten.sum.dim_IntList(mul_224, [-2]);  mul_224 = None
    select_scatter_default_12 = torch.ops.aten.select_scatter.default(full_default_10, sum_38, 2, 0);  full_default_10 = sum_38 = None
    permute_172 = torch.ops.aten.permute.default(select_scatter_default_12, [0, 2, 1, 3]);  select_scatter_default_12 = None
    convert_element_type_405 = torch.ops.prims.convert_element_type.default(permute_172, torch.bfloat16);  permute_172 = None
    view_290 = torch.ops.aten.reshape.default(convert_element_type_405, [-1, 128]);  convert_element_type_405 = None
    convert_element_type_406 = torch.ops.prims.convert_element_type.default(view_290, torch.float32);  view_290 = None
    pow_34 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_406, 2)
    mean_33 = torch.ops.aten.mean.dim(pow_34, [-1], True);  pow_34 = None
    add_178 = torch.ops.aten.add.Tensor(mean_33, 1e-06);  mean_33 = None
    rsqrt_51 = torch.ops.aten.rsqrt.default(add_178);  add_178 = None
    mul_225 = torch.ops.aten.mul.Tensor(convert_element_type_406, rsqrt_51);  convert_element_type_406 = rsqrt_51 = None
    convert_element_type_407 = torch.ops.prims.convert_element_type.default(mul_225, torch.bfloat16);  mul_225 = None
    mul_226 = torch.ops.aten.mul.Tensor(arg170_1, convert_element_type_407);  arg170_1 = convert_element_type_407 = None
    view_276 = torch.ops.aten.reshape.default(convert_element_type_386, [1, 2048]);  convert_element_type_386 = None
    permute_162 = torch.ops.aten.permute.default(arg162_1, [1, 0]);  arg162_1 = None
    mm_79 = torch.ops.aten.mm.default(view_276, permute_162);  view_276 = permute_162 = None
    view_277 = torch.ops.aten.reshape.default(mm_79, [1, 1, 2048]);  mm_79 = None
    view_278 = torch.ops.aten.reshape.default(view_277, [1, 1, -1, 128]);  view_277 = None
    view_291 = torch.ops.aten.reshape.default(view_278, [-1, 128]);  view_278 = None
    convert_element_type_408 = torch.ops.prims.convert_element_type.default(view_291, torch.float32);  view_291 = None
    neg_40 = torch.ops.aten.neg.default(convert_element_type_408)
    exp_56 = torch.ops.aten.exp.default(neg_40);  neg_40 = None
    add_179 = torch.ops.aten.add.Tensor(exp_56, 1);  exp_56 = None
    div_38 = torch.ops.aten.div.Tensor(convert_element_type_408, add_179);  convert_element_type_408 = add_179 = None
    mul_227 = torch.ops.aten.mul.Tensor(mul_226, div_38);  mul_226 = div_38 = None
    convert_element_type_409 = torch.ops.prims.convert_element_type.default(mul_227, torch.bfloat16);  mul_227 = None
    view_292 = torch.ops.aten.reshape.default(convert_element_type_409, [1, 1, -1]);  convert_element_type_409 = None
    view_293 = torch.ops.aten.reshape.default(view_292, [1, 2048]);  view_292 = None
    permute_173 = torch.ops.aten.permute.default(arg171_1, [1, 0]);  arg171_1 = None
    mm_82 = torch.ops.aten.mm.default(view_293, permute_173);  view_293 = permute_173 = None
    view_294 = torch.ops.aten.reshape.default(mm_82, [1, 1, 2048]);  mm_82 = None
    add_180 = torch.ops.aten.add.Tensor(add_167, view_294);  add_167 = view_294 = None
    convert_element_type_412 = torch.ops.prims.convert_element_type.default(add_180, torch.float32)
    pow_35 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_412, 2)
    mean_34 = torch.ops.aten.mean.dim(pow_35, [-1], True);  pow_35 = None
    add_181 = torch.ops.aten.add.Tensor(mean_34, 1e-06);  mean_34 = None
    rsqrt_52 = torch.ops.aten.rsqrt.default(add_181);  add_181 = None
    mul_228 = torch.ops.aten.mul.Tensor(convert_element_type_412, rsqrt_52);  convert_element_type_412 = rsqrt_52 = None
    convert_element_type_413 = torch.ops.prims.convert_element_type.default(arg172_1, torch.float32);  arg172_1 = None
    add_182 = torch.ops.aten.add.Tensor(convert_element_type_413, 1.0);  convert_element_type_413 = None
    mul_229 = torch.ops.aten.mul.Tensor(mul_228, add_182);  mul_228 = add_182 = None
    convert_element_type_414 = torch.ops.prims.convert_element_type.default(mul_229, torch.bfloat16);  mul_229 = None
    view_295 = torch.ops.aten.reshape.default(convert_element_type_414, [1, 2048])
    permute_174 = torch.ops.aten.permute.default(arg173_1, [1, 0]);  arg173_1 = None
    mm_83 = torch.ops.aten.mm.default(view_295, permute_174);  view_295 = permute_174 = None
    view_296 = torch.ops.aten.reshape.default(mm_83, [1, 1, 6144]);  mm_83 = None
    convert_element_type_417 = torch.ops.prims.convert_element_type.default(view_296, torch.float32);  view_296 = None
    neg_41 = torch.ops.aten.neg.default(convert_element_type_417)
    exp_57 = torch.ops.aten.exp.default(neg_41);  neg_41 = None
    add_183 = torch.ops.aten.add.Tensor(exp_57, 1);  exp_57 = None
    div_39 = torch.ops.aten.div.Tensor(convert_element_type_417, add_183);  convert_element_type_417 = add_183 = None
    convert_element_type_418 = torch.ops.prims.convert_element_type.default(div_39, torch.bfloat16);  div_39 = None
    view_297 = torch.ops.aten.reshape.default(convert_element_type_414, [1, 2048]);  convert_element_type_414 = None
    permute_175 = torch.ops.aten.permute.default(arg174_1, [1, 0]);  arg174_1 = None
    mm_84 = torch.ops.aten.mm.default(view_297, permute_175);  view_297 = permute_175 = None
    view_298 = torch.ops.aten.reshape.default(mm_84, [1, 1, 6144]);  mm_84 = None
    mul_230 = torch.ops.aten.mul.Tensor(convert_element_type_418, view_298);  convert_element_type_418 = view_298 = None
    view_299 = torch.ops.aten.reshape.default(mul_230, [1, 6144]);  mul_230 = None
    permute_176 = torch.ops.aten.permute.default(arg175_1, [1, 0]);  arg175_1 = None
    mm_85 = torch.ops.aten.mm.default(view_299, permute_176);  view_299 = permute_176 = None
    view_300 = torch.ops.aten.reshape.default(mm_85, [1, 1, 2048]);  mm_85 = None
    add_184 = torch.ops.aten.add.Tensor(add_180, view_300);  add_180 = view_300 = None
    convert_element_type_423 = torch.ops.prims.convert_element_type.default(add_184, torch.float32)
    pow_36 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_423, 2)
    mean_35 = torch.ops.aten.mean.dim(pow_36, [-1], True);  pow_36 = None
    add_185 = torch.ops.aten.add.Tensor(mean_35, 1e-06);  mean_35 = None
    rsqrt_53 = torch.ops.aten.rsqrt.default(add_185);  add_185 = None
    mul_231 = torch.ops.aten.mul.Tensor(convert_element_type_423, rsqrt_53);  convert_element_type_423 = rsqrt_53 = None
    convert_element_type_424 = torch.ops.prims.convert_element_type.default(arg176_1, torch.float32);  arg176_1 = None
    add_186 = torch.ops.aten.add.Tensor(convert_element_type_424, 1.0);  convert_element_type_424 = None
    mul_232 = torch.ops.aten.mul.Tensor(mul_231, add_186);  mul_231 = add_186 = None
    convert_element_type_425 = torch.ops.prims.convert_element_type.default(mul_232, torch.bfloat16);  mul_232 = None
    view_301 = torch.ops.aten.reshape.default(convert_element_type_425, [1, 2048])
    permute_177 = torch.ops.aten.permute.default(arg177_1, [1, 0]);  arg177_1 = None
    mm_86 = torch.ops.aten.mm.default(view_301, permute_177);  view_301 = permute_177 = None
    view_302 = torch.ops.aten.reshape.default(mm_86, [1, 1, 4096]);  mm_86 = None
    view_303 = torch.ops.aten.reshape.default(view_302, [1, 1, -1, 512]);  view_302 = None
    split_2 = torch.ops.aten.split.Tensor(view_303, 256, -1);  view_303 = None
    getitem_31 = split_2[0]
    getitem_32 = split_2[1];  split_2 = None
    add_194 = torch.ops.aten.add.Tensor(arg182_1, 1)
    convert_element_type_428 = torch.ops.prims.convert_element_type.default(getitem_31, torch.float32);  getitem_31 = None
    pow_37 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_428, 2)
    mean_36 = torch.ops.aten.mean.dim(pow_37, [-1], True);  pow_37 = None
    add_187 = torch.ops.aten.add.Tensor(mean_36, 1e-06);  mean_36 = None
    rsqrt_54 = torch.ops.aten.rsqrt.default(add_187);  add_187 = None
    mul_233 = torch.ops.aten.mul.Tensor(convert_element_type_428, rsqrt_54);  convert_element_type_428 = rsqrt_54 = None
    convert_element_type_429 = torch.ops.prims.convert_element_type.default(arg178_1, torch.float32);  arg178_1 = None
    add_188 = torch.ops.aten.add.Tensor(convert_element_type_429, 1.0);  convert_element_type_429 = None
    mul_234 = torch.ops.aten.mul.Tensor(mul_233, add_188);  mul_233 = add_188 = None
    convert_element_type_430 = torch.ops.prims.convert_element_type.default(mul_234, torch.bfloat16);  mul_234 = None
    permute_178 = torch.ops.aten.permute.default(convert_element_type_430, [0, 2, 1, 3]);  convert_element_type_430 = None
    slice_88 = torch.ops.aten.slice.Tensor(permute_178, 3, 0, 64)
    unsqueeze_96 = torch.ops.aten.unsqueeze.default(convert_element_type_2, 1)
    mul_237 = torch.ops.aten.mul.Tensor(slice_88, unsqueeze_96)
    slice_93 = torch.ops.aten.slice.Tensor(slice_88, 3, 32, 9223372036854775807)
    neg_42 = torch.ops.aten.neg.default(slice_93);  slice_93 = None
    slice_92 = torch.ops.aten.slice.Tensor(slice_88, 3, 0, 32);  slice_88 = None
    cat_17 = torch.ops.aten.cat.default([neg_42, slice_92], -1);  neg_42 = slice_92 = None
    unsqueeze_97 = torch.ops.aten.unsqueeze.default(convert_element_type_3, 1)
    mul_238 = torch.ops.aten.mul.Tensor(cat_17, unsqueeze_97);  cat_17 = None
    add_191 = torch.ops.aten.add.Tensor(mul_237, mul_238);  mul_237 = mul_238 = None
    slice_89 = torch.ops.aten.slice.Tensor(permute_178, 3, 64, 9223372036854775807);  permute_178 = None
    cat_19 = torch.ops.aten.cat.default([add_191, slice_89], -1);  add_191 = slice_89 = None
    expand_24 = torch.ops.aten.expand.default(cat_19, [1, 8, 1, 256]);  cat_19 = None
    view_314 = torch.ops.aten.reshape.default(expand_24, [8, 1, 256]);  expand_24 = None
    iota_3 = torch.ops.prims.iota.default(1, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    add_193 = torch.ops.aten.add.Tensor(iota_3, arg182_1);  iota_3 = None
    view_306 = torch.ops.aten.reshape.default(convert_element_type_425, [1, 2048])
    permute_179 = torch.ops.aten.permute.default(arg179_1, [1, 0]);  arg179_1 = None
    mm_87 = torch.ops.aten.mm.default(view_306, permute_179);  view_306 = permute_179 = None
    view_307 = torch.ops.aten.reshape.default(mm_87, [1, 1, 512]);  mm_87 = None
    view_308 = torch.ops.aten.reshape.default(view_307, [1, 1, -1, 256]);  view_307 = None
    convert_element_type_433 = torch.ops.prims.convert_element_type.default(view_308, torch.float32);  view_308 = None
    pow_38 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_433, 2)
    mean_37 = torch.ops.aten.mean.dim(pow_38, [-1], True);  pow_38 = None
    add_189 = torch.ops.aten.add.Tensor(mean_37, 1e-06);  mean_37 = None
    rsqrt_55 = torch.ops.aten.rsqrt.default(add_189);  add_189 = None
    mul_235 = torch.ops.aten.mul.Tensor(convert_element_type_433, rsqrt_55);  convert_element_type_433 = rsqrt_55 = None
    convert_element_type_434 = torch.ops.prims.convert_element_type.default(arg180_1, torch.float32);  arg180_1 = None
    add_190 = torch.ops.aten.add.Tensor(convert_element_type_434, 1.0);  convert_element_type_434 = None
    mul_236 = torch.ops.aten.mul.Tensor(mul_235, add_190);  mul_235 = add_190 = None
    convert_element_type_435 = torch.ops.prims.convert_element_type.default(mul_236, torch.bfloat16);  mul_236 = None
    permute_180 = torch.ops.aten.permute.default(convert_element_type_435, [0, 2, 1, 3]);  convert_element_type_435 = None
    slice_90 = torch.ops.aten.slice.Tensor(permute_180, 3, 0, 64)
    mul_239 = torch.ops.aten.mul.Tensor(slice_90, unsqueeze_96);  unsqueeze_96 = None
    slice_95 = torch.ops.aten.slice.Tensor(slice_90, 3, 32, 9223372036854775807)
    neg_43 = torch.ops.aten.neg.default(slice_95);  slice_95 = None
    slice_94 = torch.ops.aten.slice.Tensor(slice_90, 3, 0, 32);  slice_90 = None
    cat_18 = torch.ops.aten.cat.default([neg_43, slice_94], -1);  neg_43 = slice_94 = None
    mul_240 = torch.ops.aten.mul.Tensor(cat_18, unsqueeze_97);  cat_18 = unsqueeze_97 = None
    add_192 = torch.ops.aten.add.Tensor(mul_239, mul_240);  mul_239 = mul_240 = None
    slice_91 = torch.ops.aten.slice.Tensor(permute_180, 3, 64, 9223372036854775807);  permute_180 = None
    cat_20 = torch.ops.aten.cat.default([add_192, slice_91], -1);  add_192 = slice_91 = None
    index_put_4 = torch.ops.aten.index_put_.default(arg183_1, [None, None, add_193], cat_20);  arg183_1 = cat_20 = None
    unsqueeze_100 = torch.ops.aten.unsqueeze.default(index_put_4, 2);  index_put_4 = None
    expand_21 = torch.ops.aten.expand.default(unsqueeze_100, [1, 2, 4, 144, 256]);  unsqueeze_100 = None
    clone_47 = torch.ops.aten.clone.default(expand_21, memory_format = torch.contiguous_format);  expand_21 = None
    view_312 = torch.ops.aten.reshape.default(clone_47, [1, 8, 144, 256]);  clone_47 = None
    permute_183 = torch.ops.aten.permute.default(view_312, [0, 1, 3, 2]);  view_312 = None
    expand_25 = torch.ops.aten.expand.default(permute_183, [1, 8, 256, 144]);  permute_183 = None
    view_315 = torch.ops.aten.reshape.default(expand_25, [8, 256, 144]);  expand_25 = None
    bmm_4 = torch.ops.aten.bmm.default(view_314, view_315);  view_314 = view_315 = None
    view_316 = torch.ops.aten.reshape.default(bmm_4, [1, 8, 1, 144]);  bmm_4 = None
    mul_241 = torch.ops.aten.mul.Tensor(view_316, 0.0625);  view_316 = None
    add_195 = torch.ops.aten.add.Tensor(mul_241, unsqueeze_3);  mul_241 = None
    convert_element_type_440 = torch.ops.prims.convert_element_type.default(add_195, torch.float32);  add_195 = None
    amax_2 = torch.ops.aten.amax.default(convert_element_type_440, [-1], True)
    sub_11 = torch.ops.aten.sub.Tensor(convert_element_type_440, amax_2);  convert_element_type_440 = amax_2 = None
    exp_58 = torch.ops.aten.exp.default(sub_11);  sub_11 = None
    sum_39 = torch.ops.aten.sum.dim_IntList(exp_58, [-1], True)
    div_40 = torch.ops.aten.div.Tensor(exp_58, sum_39);  exp_58 = sum_39 = None
    convert_element_type_441 = torch.ops.prims.convert_element_type.default(div_40, torch.bfloat16);  div_40 = None
    expand_26 = torch.ops.aten.expand.default(convert_element_type_441, [1, 8, 1, 144]);  convert_element_type_441 = None
    view_317 = torch.ops.aten.reshape.default(expand_26, [8, 1, 144]);  expand_26 = None
    view_309 = torch.ops.aten.reshape.default(convert_element_type_425, [1, 2048]);  convert_element_type_425 = None
    permute_181 = torch.ops.aten.permute.default(arg181_1, [1, 0]);  arg181_1 = None
    mm_88 = torch.ops.aten.mm.default(view_309, permute_181);  view_309 = permute_181 = None
    view_310 = torch.ops.aten.reshape.default(mm_88, [1, 1, 512]);  mm_88 = None
    view_311 = torch.ops.aten.reshape.default(view_310, [1, 1, -1, 256]);  view_310 = None
    permute_182 = torch.ops.aten.permute.default(view_311, [0, 2, 1, 3]);  view_311 = None
    index_put_5 = torch.ops.aten.index_put_.default(arg184_1, [None, None, add_193], permute_182);  arg184_1 = add_193 = permute_182 = None
    unsqueeze_103 = torch.ops.aten.unsqueeze.default(index_put_5, 2);  index_put_5 = None
    expand_23 = torch.ops.aten.expand.default(unsqueeze_103, [1, 2, 4, 144, 256]);  unsqueeze_103 = None
    clone_48 = torch.ops.aten.clone.default(expand_23, memory_format = torch.contiguous_format);  expand_23 = None
    view_313 = torch.ops.aten.reshape.default(clone_48, [1, 8, 144, 256]);  clone_48 = None
    expand_27 = torch.ops.aten.expand.default(view_313, [1, 8, 144, 256]);  view_313 = None
    view_318 = torch.ops.aten.reshape.default(expand_27, [8, 144, 256]);  expand_27 = None
    bmm_5 = torch.ops.aten.bmm.default(view_317, view_318);  view_317 = view_318 = None
    view_319 = torch.ops.aten.reshape.default(bmm_5, [1, 8, 1, 256]);  bmm_5 = None
    permute_184 = torch.ops.aten.permute.default(view_319, [0, 2, 1, 3]);  view_319 = None
    view_320 = torch.ops.aten.reshape.default(permute_184, [1, 1, -1]);  permute_184 = None
    clone_46 = torch.ops.aten.clone.default(getitem_32, memory_format = torch.contiguous_format);  getitem_32 = None
    view_304 = torch.ops.aten.reshape.default(clone_46, [1, 1, 2048]);  clone_46 = None
    sigmoid_11 = torch.ops.aten.sigmoid.default(view_304);  view_304 = None
    mul_242 = torch.ops.aten.mul.Tensor(view_320, sigmoid_11);  view_320 = sigmoid_11 = None
    view_321 = torch.ops.aten.reshape.default(mul_242, [1, 2048]);  mul_242 = None
    permute_185 = torch.ops.aten.permute.default(arg185_1, [1, 0]);  arg185_1 = None
    mm_89 = torch.ops.aten.mm.default(view_321, permute_185);  view_321 = permute_185 = None
    view_322 = torch.ops.aten.reshape.default(mm_89, [1, 1, 2048]);  mm_89 = None
    add_196 = torch.ops.aten.add.Tensor(add_184, view_322);  add_184 = view_322 = None
    convert_element_type_446 = torch.ops.prims.convert_element_type.default(add_196, torch.float32)
    pow_39 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_446, 2)
    mean_38 = torch.ops.aten.mean.dim(pow_39, [-1], True);  pow_39 = None
    add_197 = torch.ops.aten.add.Tensor(mean_38, 1e-06);  mean_38 = None
    rsqrt_56 = torch.ops.aten.rsqrt.default(add_197);  add_197 = None
    mul_243 = torch.ops.aten.mul.Tensor(convert_element_type_446, rsqrt_56);  convert_element_type_446 = rsqrt_56 = None
    convert_element_type_447 = torch.ops.prims.convert_element_type.default(arg186_1, torch.float32);  arg186_1 = None
    add_198 = torch.ops.aten.add.Tensor(convert_element_type_447, 1.0);  convert_element_type_447 = None
    mul_244 = torch.ops.aten.mul.Tensor(mul_243, add_198);  mul_243 = add_198 = None
    convert_element_type_448 = torch.ops.prims.convert_element_type.default(mul_244, torch.bfloat16);  mul_244 = None
    view_323 = torch.ops.aten.reshape.default(convert_element_type_448, [1, 2048])
    permute_186 = torch.ops.aten.permute.default(arg187_1, [1, 0]);  arg187_1 = None
    mm_90 = torch.ops.aten.mm.default(view_323, permute_186);  view_323 = permute_186 = None
    view_324 = torch.ops.aten.reshape.default(mm_90, [1, 1, 6144]);  mm_90 = None
    convert_element_type_451 = torch.ops.prims.convert_element_type.default(view_324, torch.float32);  view_324 = None
    neg_44 = torch.ops.aten.neg.default(convert_element_type_451)
    exp_59 = torch.ops.aten.exp.default(neg_44);  neg_44 = None
    add_199 = torch.ops.aten.add.Tensor(exp_59, 1);  exp_59 = None
    div_41 = torch.ops.aten.div.Tensor(convert_element_type_451, add_199);  convert_element_type_451 = add_199 = None
    convert_element_type_452 = torch.ops.prims.convert_element_type.default(div_41, torch.bfloat16);  div_41 = None
    view_325 = torch.ops.aten.reshape.default(convert_element_type_448, [1, 2048]);  convert_element_type_448 = None
    permute_187 = torch.ops.aten.permute.default(arg188_1, [1, 0]);  arg188_1 = None
    mm_91 = torch.ops.aten.mm.default(view_325, permute_187);  view_325 = permute_187 = None
    view_326 = torch.ops.aten.reshape.default(mm_91, [1, 1, 6144]);  mm_91 = None
    mul_245 = torch.ops.aten.mul.Tensor(convert_element_type_452, view_326);  convert_element_type_452 = view_326 = None
    view_327 = torch.ops.aten.reshape.default(mul_245, [1, 6144]);  mul_245 = None
    permute_188 = torch.ops.aten.permute.default(arg189_1, [1, 0]);  arg189_1 = None
    mm_92 = torch.ops.aten.mm.default(view_327, permute_188);  view_327 = permute_188 = None
    view_328 = torch.ops.aten.reshape.default(mm_92, [1, 1, 2048]);  mm_92 = None
    add_200 = torch.ops.aten.add.Tensor(add_196, view_328);  add_196 = view_328 = None
    convert_element_type_457 = torch.ops.prims.convert_element_type.default(add_200, torch.float32)
    pow_40 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_457, 2)
    mean_39 = torch.ops.aten.mean.dim(pow_40, [-1], True);  pow_40 = None
    add_201 = torch.ops.aten.add.Tensor(mean_39, 1e-06);  mean_39 = None
    rsqrt_57 = torch.ops.aten.rsqrt.default(add_201);  add_201 = None
    mul_246 = torch.ops.aten.mul.Tensor(convert_element_type_457, rsqrt_57);  convert_element_type_457 = rsqrt_57 = None
    convert_element_type_458 = torch.ops.prims.convert_element_type.default(arg190_1, torch.float32);  arg190_1 = None
    add_202 = torch.ops.aten.add.Tensor(convert_element_type_458, 1.0);  convert_element_type_458 = None
    mul_247 = torch.ops.aten.mul.Tensor(mul_246, add_202);  mul_246 = add_202 = None
    convert_element_type_459 = torch.ops.prims.convert_element_type.default(mul_247, torch.bfloat16);  mul_247 = None
    view_329 = torch.ops.aten.reshape.default(convert_element_type_459, [1, 2048])
    permute_189 = torch.ops.aten.permute.default(arg191_1, [1, 0]);  arg191_1 = None
    mm_93 = torch.ops.aten.mm.default(view_329, permute_189);  view_329 = permute_189 = None
    view_330 = torch.ops.aten.reshape.default(mm_93, [1, 1, 6144]);  mm_93 = None
    permute_190 = torch.ops.aten.permute.default(view_330, [0, 2, 1]);  view_330 = None
    cat_21 = torch.ops.aten.cat.default([arg195_1, permute_190], -1);  permute_190 = None
    slice_96 = torch.ops.aten.slice.Tensor(cat_21, 2, -4, 9223372036854775807)
    copy_31 = torch.ops.aten.copy.default(arg195_1, slice_96);  slice_96 = None
    convert_element_type_468 = torch.ops.prims.convert_element_type.default(cat_21, torch.float32);  cat_21 = None
    slice_97 = torch.ops.aten.slice.Tensor(convert_element_type_468, 2, 0, 2)
    squeeze_9 = torch.ops.aten.squeeze.dim(arg196_1, 1);  arg196_1 = None
    unsqueeze_104 = torch.ops.aten.unsqueeze.default(squeeze_9, 1);  squeeze_9 = None
    convert_element_type_469 = torch.ops.prims.convert_element_type.default(unsqueeze_104, torch.float32);  unsqueeze_104 = None
    select_160 = torch.ops.aten.select.int(convert_element_type_469, 1, 0)
    select_161 = torch.ops.aten.select.int(select_160, 1, 0);  select_160 = None
    view_338 = torch.ops.aten.reshape.default(select_161, [1, -1, 1]);  select_161 = None
    mul_248 = torch.ops.aten.mul.Tensor(slice_97, view_338);  slice_97 = view_338 = None
    slice_98 = torch.ops.aten.slice.Tensor(convert_element_type_468, 2, 1, 3)
    select_162 = torch.ops.aten.select.int(convert_element_type_469, 1, 0)
    select_163 = torch.ops.aten.select.int(select_162, 1, 1);  select_162 = None
    view_339 = torch.ops.aten.reshape.default(select_163, [1, -1, 1]);  select_163 = None
    mul_249 = torch.ops.aten.mul.Tensor(slice_98, view_339);  slice_98 = view_339 = None
    add_203 = torch.ops.aten.add.Tensor(mul_248, mul_249);  mul_248 = mul_249 = None
    slice_99 = torch.ops.aten.slice.Tensor(convert_element_type_468, 2, 2, 4)
    select_164 = torch.ops.aten.select.int(convert_element_type_469, 1, 0)
    select_165 = torch.ops.aten.select.int(select_164, 1, 2);  select_164 = None
    view_340 = torch.ops.aten.reshape.default(select_165, [1, -1, 1]);  select_165 = None
    mul_250 = torch.ops.aten.mul.Tensor(slice_99, view_340);  slice_99 = view_340 = None
    add_204 = torch.ops.aten.add.Tensor(add_203, mul_250);  add_203 = mul_250 = None
    slice_100 = torch.ops.aten.slice.Tensor(convert_element_type_468, 2, 3, 5);  convert_element_type_468 = None
    select_166 = torch.ops.aten.select.int(convert_element_type_469, 1, 0);  convert_element_type_469 = None
    select_167 = torch.ops.aten.select.int(select_166, 1, 3);  select_166 = None
    view_341 = torch.ops.aten.reshape.default(select_167, [1, -1, 1]);  select_167 = None
    mul_251 = torch.ops.aten.mul.Tensor(slice_100, view_341);  slice_100 = view_341 = None
    add_205 = torch.ops.aten.add.Tensor(add_204, mul_251);  add_204 = mul_251 = None
    convert_element_type_470 = torch.ops.prims.convert_element_type.default(add_205, torch.bfloat16);  add_205 = None
    slice_101 = torch.ops.aten.slice.Tensor(convert_element_type_470, 2, -1, 9223372036854775807);  convert_element_type_470 = None
    convert_element_type_471 = torch.ops.prims.convert_element_type.default(slice_101, torch.float32);  slice_101 = None
    neg_45 = torch.ops.aten.neg.default(convert_element_type_471)
    exp_60 = torch.ops.aten.exp.default(neg_45);  neg_45 = None
    add_206 = torch.ops.aten.add.Tensor(exp_60, 1);  exp_60 = None
    div_42 = torch.ops.aten.div.Tensor(convert_element_type_471, add_206);  convert_element_type_471 = add_206 = None
    convert_element_type_472 = torch.ops.prims.convert_element_type.default(div_42, torch.bfloat16);  div_42 = None
    permute_194 = torch.ops.aten.permute.default(convert_element_type_472, [0, 2, 1]);  convert_element_type_472 = None
    split_with_sizes_9 = torch.ops.aten.split_with_sizes.default(permute_194, [2048, 2048, 2048], -1);  permute_194 = None
    getitem_33 = split_with_sizes_9[0]
    getitem_34 = split_with_sizes_9[1]
    getitem_35 = split_with_sizes_9[2];  split_with_sizes_9 = None
    full_default_11 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_173 = torch.ops.aten.select.int(full_default_11, 2, 0);  select_173 = None
    view_343 = torch.ops.aten.reshape.default(getitem_34, [1, 1, -1, 128]);  getitem_34 = None
    permute_196 = torch.ops.aten.permute.default(view_343, [0, 2, 1, 3]);  view_343 = None
    convert_element_type_475 = torch.ops.prims.convert_element_type.default(permute_196, torch.float32);  permute_196 = None
    clone_50 = torch.ops.aten.clone.default(convert_element_type_475, memory_format = torch.contiguous_format);  convert_element_type_475 = None
    mul_255 = torch.ops.aten.mul.Tensor(clone_50, clone_50)
    sum_41 = torch.ops.aten.sum.dim_IntList(mul_255, [-1], True);  mul_255 = None
    add_209 = torch.ops.aten.add.Tensor(sum_41, 1e-06);  sum_41 = None
    rsqrt_59 = torch.ops.aten.rsqrt.default(add_209);  add_209 = None
    mul_256 = torch.ops.aten.mul.Tensor(clone_50, rsqrt_59);  clone_50 = rsqrt_59 = None
    select_169 = torch.ops.aten.select.int(mul_256, 2, 0);  mul_256 = None
    unsqueeze_109 = torch.ops.aten.unsqueeze.default(select_169, -1)
    view_344 = torch.ops.aten.reshape.default(getitem_35, [1, 1, -1, 128]);  getitem_35 = None
    permute_197 = torch.ops.aten.permute.default(view_344, [0, 2, 1, 3]);  view_344 = None
    convert_element_type_476 = torch.ops.prims.convert_element_type.default(permute_197, torch.float32);  permute_197 = None
    clone_51 = torch.ops.aten.clone.default(convert_element_type_476, memory_format = torch.contiguous_format);  convert_element_type_476 = None
    select_170 = torch.ops.aten.select.int(clone_51, 2, 0);  clone_51 = None
    exp_61 = torch.ops.aten.exp.default(arg197_1);  arg197_1 = None
    neg_46 = torch.ops.aten.neg.default(exp_61);  exp_61 = None
    view_336 = torch.ops.aten.reshape.default(convert_element_type_459, [1, 2048])
    permute_193 = torch.ops.aten.permute.default(arg194_1, [1, 0]);  arg194_1 = None
    mm_96 = torch.ops.aten.mm.default(view_336, permute_193);  view_336 = permute_193 = None
    view_337 = torch.ops.aten.reshape.default(mm_96, [1, 1, 16]);  mm_96 = None
    convert_element_type_473 = torch.ops.prims.convert_element_type.default(view_337, torch.float32);  view_337 = None
    add_207 = torch.ops.aten.add.Tensor(convert_element_type_473, arg198_1);  convert_element_type_473 = arg198_1 = None
    gt_9 = torch.ops.aten.gt.Scalar(add_207, 20)
    exp_62 = torch.ops.aten.exp.default(add_207)
    log1p_9 = torch.ops.aten.log1p.default(exp_62);  exp_62 = None
    where_10 = torch.ops.aten.where.self(gt_9, add_207, log1p_9);  gt_9 = add_207 = log1p_9 = None
    mul_252 = torch.ops.aten.mul.Tensor(neg_46, where_10);  neg_46 = where_10 = None
    permute_199 = torch.ops.aten.permute.default(mul_252, [0, 2, 1]);  mul_252 = None
    select_171 = torch.ops.aten.select.int(permute_199, 2, 0);  permute_199 = None
    exp_63 = torch.ops.aten.exp.default(select_171);  select_171 = None
    unsqueeze_105 = torch.ops.aten.unsqueeze.default(exp_63, 2);  exp_63 = None
    unsqueeze_106 = torch.ops.aten.unsqueeze.default(unsqueeze_105, 3);  unsqueeze_105 = None
    mul_257 = torch.ops.aten.mul.Tensor(arg199_1, unsqueeze_106);  unsqueeze_106 = None
    unsqueeze_108 = torch.ops.aten.unsqueeze.default(select_169, -1);  select_169 = None
    mul_258 = torch.ops.aten.mul.Tensor(mul_257, unsqueeze_108);  unsqueeze_108 = None
    sum_42 = torch.ops.aten.sum.dim_IntList(mul_258, [-2]);  mul_258 = None
    sub_12 = torch.ops.aten.sub.Tensor(select_170, sum_42);  select_170 = sum_42 = None
    view_334 = torch.ops.aten.reshape.default(convert_element_type_459, [1, 2048])
    permute_192 = torch.ops.aten.permute.default(arg193_1, [1, 0]);  arg193_1 = None
    mm_95 = torch.ops.aten.mm.default(view_334, permute_192);  view_334 = permute_192 = None
    view_335 = torch.ops.aten.reshape.default(mm_95, [1, 1, 16]);  mm_95 = None
    sigmoid_12 = torch.ops.aten.sigmoid.default(view_335);  view_335 = None
    permute_198 = torch.ops.aten.permute.default(sigmoid_12, [0, 2, 1]);  sigmoid_12 = None
    convert_element_type_477 = torch.ops.prims.convert_element_type.default(permute_198, torch.float32);  permute_198 = None
    clone_52 = torch.ops.aten.clone.default(convert_element_type_477, memory_format = torch.contiguous_format);  convert_element_type_477 = None
    select_172 = torch.ops.aten.select.int(clone_52, 2, 0);  clone_52 = None
    unsqueeze_107 = torch.ops.aten.unsqueeze.default(select_172, -1);  select_172 = None
    mul_259 = torch.ops.aten.mul.Tensor(sub_12, unsqueeze_107);  sub_12 = unsqueeze_107 = None
    unsqueeze_110 = torch.ops.aten.unsqueeze.default(mul_259, -2);  mul_259 = None
    mul_260 = torch.ops.aten.mul.Tensor(unsqueeze_109, unsqueeze_110);  unsqueeze_109 = unsqueeze_110 = None
    add_210 = torch.ops.aten.add.Tensor(mul_257, mul_260);  mul_257 = mul_260 = None
    view_342 = torch.ops.aten.reshape.default(getitem_33, [1, 1, -1, 128]);  getitem_33 = None
    permute_195 = torch.ops.aten.permute.default(view_342, [0, 2, 1, 3]);  view_342 = None
    convert_element_type_474 = torch.ops.prims.convert_element_type.default(permute_195, torch.float32);  permute_195 = None
    clone_49 = torch.ops.aten.clone.default(convert_element_type_474, memory_format = torch.contiguous_format);  convert_element_type_474 = None
    mul_253 = torch.ops.aten.mul.Tensor(clone_49, clone_49)
    sum_40 = torch.ops.aten.sum.dim_IntList(mul_253, [-1], True);  mul_253 = None
    add_208 = torch.ops.aten.add.Tensor(sum_40, 1e-06);  sum_40 = None
    rsqrt_58 = torch.ops.aten.rsqrt.default(add_208);  add_208 = None
    mul_254 = torch.ops.aten.mul.Tensor(clone_49, rsqrt_58);  clone_49 = rsqrt_58 = None
    div_43 = torch.ops.aten.div.Tensor(mul_254, 11.313708498984761);  mul_254 = None
    select_168 = torch.ops.aten.select.int(div_43, 2, 0);  div_43 = None
    unsqueeze_111 = torch.ops.aten.unsqueeze.default(select_168, -1);  select_168 = None
    mul_261 = torch.ops.aten.mul.Tensor(add_210, unsqueeze_111);  unsqueeze_111 = None
    sum_43 = torch.ops.aten.sum.dim_IntList(mul_261, [-2]);  mul_261 = None
    select_scatter_default_13 = torch.ops.aten.select_scatter.default(full_default_11, sum_43, 2, 0);  full_default_11 = sum_43 = None
    permute_201 = torch.ops.aten.permute.default(select_scatter_default_13, [0, 2, 1, 3]);  select_scatter_default_13 = None
    convert_element_type_478 = torch.ops.prims.convert_element_type.default(permute_201, torch.bfloat16);  permute_201 = None
    view_345 = torch.ops.aten.reshape.default(convert_element_type_478, [-1, 128]);  convert_element_type_478 = None
    convert_element_type_479 = torch.ops.prims.convert_element_type.default(view_345, torch.float32);  view_345 = None
    pow_41 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_479, 2)
    mean_40 = torch.ops.aten.mean.dim(pow_41, [-1], True);  pow_41 = None
    add_211 = torch.ops.aten.add.Tensor(mean_40, 1e-06);  mean_40 = None
    rsqrt_60 = torch.ops.aten.rsqrt.default(add_211);  add_211 = None
    mul_262 = torch.ops.aten.mul.Tensor(convert_element_type_479, rsqrt_60);  convert_element_type_479 = rsqrt_60 = None
    convert_element_type_480 = torch.ops.prims.convert_element_type.default(mul_262, torch.bfloat16);  mul_262 = None
    mul_263 = torch.ops.aten.mul.Tensor(arg200_1, convert_element_type_480);  arg200_1 = convert_element_type_480 = None
    view_331 = torch.ops.aten.reshape.default(convert_element_type_459, [1, 2048]);  convert_element_type_459 = None
    permute_191 = torch.ops.aten.permute.default(arg192_1, [1, 0]);  arg192_1 = None
    mm_94 = torch.ops.aten.mm.default(view_331, permute_191);  view_331 = permute_191 = None
    view_332 = torch.ops.aten.reshape.default(mm_94, [1, 1, 2048]);  mm_94 = None
    view_333 = torch.ops.aten.reshape.default(view_332, [1, 1, -1, 128]);  view_332 = None
    view_346 = torch.ops.aten.reshape.default(view_333, [-1, 128]);  view_333 = None
    convert_element_type_481 = torch.ops.prims.convert_element_type.default(view_346, torch.float32);  view_346 = None
    neg_47 = torch.ops.aten.neg.default(convert_element_type_481)
    exp_64 = torch.ops.aten.exp.default(neg_47);  neg_47 = None
    add_212 = torch.ops.aten.add.Tensor(exp_64, 1);  exp_64 = None
    div_44 = torch.ops.aten.div.Tensor(convert_element_type_481, add_212);  convert_element_type_481 = add_212 = None
    mul_264 = torch.ops.aten.mul.Tensor(mul_263, div_44);  mul_263 = div_44 = None
    convert_element_type_482 = torch.ops.prims.convert_element_type.default(mul_264, torch.bfloat16);  mul_264 = None
    view_347 = torch.ops.aten.reshape.default(convert_element_type_482, [1, 1, -1]);  convert_element_type_482 = None
    view_348 = torch.ops.aten.reshape.default(view_347, [1, 2048]);  view_347 = None
    permute_202 = torch.ops.aten.permute.default(arg201_1, [1, 0]);  arg201_1 = None
    mm_97 = torch.ops.aten.mm.default(view_348, permute_202);  view_348 = permute_202 = None
    view_349 = torch.ops.aten.reshape.default(mm_97, [1, 1, 2048]);  mm_97 = None
    add_213 = torch.ops.aten.add.Tensor(add_200, view_349);  add_200 = view_349 = None
    convert_element_type_485 = torch.ops.prims.convert_element_type.default(add_213, torch.float32)
    pow_42 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_485, 2)
    mean_41 = torch.ops.aten.mean.dim(pow_42, [-1], True);  pow_42 = None
    add_214 = torch.ops.aten.add.Tensor(mean_41, 1e-06);  mean_41 = None
    rsqrt_61 = torch.ops.aten.rsqrt.default(add_214);  add_214 = None
    mul_265 = torch.ops.aten.mul.Tensor(convert_element_type_485, rsqrt_61);  convert_element_type_485 = rsqrt_61 = None
    convert_element_type_486 = torch.ops.prims.convert_element_type.default(arg202_1, torch.float32);  arg202_1 = None
    add_215 = torch.ops.aten.add.Tensor(convert_element_type_486, 1.0);  convert_element_type_486 = None
    mul_266 = torch.ops.aten.mul.Tensor(mul_265, add_215);  mul_265 = add_215 = None
    convert_element_type_487 = torch.ops.prims.convert_element_type.default(mul_266, torch.bfloat16);  mul_266 = None
    view_350 = torch.ops.aten.reshape.default(convert_element_type_487, [1, 2048])
    permute_203 = torch.ops.aten.permute.default(arg203_1, [1, 0]);  arg203_1 = None
    mm_98 = torch.ops.aten.mm.default(view_350, permute_203);  view_350 = permute_203 = None
    view_351 = torch.ops.aten.reshape.default(mm_98, [1, 1, 6144]);  mm_98 = None
    convert_element_type_490 = torch.ops.prims.convert_element_type.default(view_351, torch.float32);  view_351 = None
    neg_48 = torch.ops.aten.neg.default(convert_element_type_490)
    exp_65 = torch.ops.aten.exp.default(neg_48);  neg_48 = None
    add_216 = torch.ops.aten.add.Tensor(exp_65, 1);  exp_65 = None
    div_45 = torch.ops.aten.div.Tensor(convert_element_type_490, add_216);  convert_element_type_490 = add_216 = None
    convert_element_type_491 = torch.ops.prims.convert_element_type.default(div_45, torch.bfloat16);  div_45 = None
    view_352 = torch.ops.aten.reshape.default(convert_element_type_487, [1, 2048]);  convert_element_type_487 = None
    permute_204 = torch.ops.aten.permute.default(arg204_1, [1, 0]);  arg204_1 = None
    mm_99 = torch.ops.aten.mm.default(view_352, permute_204);  view_352 = permute_204 = None
    view_353 = torch.ops.aten.reshape.default(mm_99, [1, 1, 6144]);  mm_99 = None
    mul_267 = torch.ops.aten.mul.Tensor(convert_element_type_491, view_353);  convert_element_type_491 = view_353 = None
    view_354 = torch.ops.aten.reshape.default(mul_267, [1, 6144]);  mul_267 = None
    permute_205 = torch.ops.aten.permute.default(arg205_1, [1, 0]);  arg205_1 = None
    mm_100 = torch.ops.aten.mm.default(view_354, permute_205);  view_354 = permute_205 = None
    view_355 = torch.ops.aten.reshape.default(mm_100, [1, 1, 2048]);  mm_100 = None
    add_217 = torch.ops.aten.add.Tensor(add_213, view_355);  add_213 = view_355 = None
    convert_element_type_496 = torch.ops.prims.convert_element_type.default(add_217, torch.float32)
    pow_43 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_496, 2)
    mean_42 = torch.ops.aten.mean.dim(pow_43, [-1], True);  pow_43 = None
    add_218 = torch.ops.aten.add.Tensor(mean_42, 1e-06);  mean_42 = None
    rsqrt_62 = torch.ops.aten.rsqrt.default(add_218);  add_218 = None
    mul_268 = torch.ops.aten.mul.Tensor(convert_element_type_496, rsqrt_62);  convert_element_type_496 = rsqrt_62 = None
    convert_element_type_497 = torch.ops.prims.convert_element_type.default(arg206_1, torch.float32);  arg206_1 = None
    add_219 = torch.ops.aten.add.Tensor(convert_element_type_497, 1.0);  convert_element_type_497 = None
    mul_269 = torch.ops.aten.mul.Tensor(mul_268, add_219);  mul_268 = add_219 = None
    convert_element_type_498 = torch.ops.prims.convert_element_type.default(mul_269, torch.bfloat16);  mul_269 = None
    view_356 = torch.ops.aten.reshape.default(convert_element_type_498, [1, 2048])
    permute_206 = torch.ops.aten.permute.default(arg207_1, [1, 0]);  arg207_1 = None
    mm_101 = torch.ops.aten.mm.default(view_356, permute_206);  view_356 = permute_206 = None
    view_357 = torch.ops.aten.reshape.default(mm_101, [1, 1, 6144]);  mm_101 = None
    permute_207 = torch.ops.aten.permute.default(view_357, [0, 2, 1]);  view_357 = None
    cat_22 = torch.ops.aten.cat.default([arg211_1, permute_207], -1);  permute_207 = None
    slice_102 = torch.ops.aten.slice.Tensor(cat_22, 2, -4, 9223372036854775807)
    copy_34 = torch.ops.aten.copy.default(arg211_1, slice_102);  slice_102 = None
    convert_element_type_507 = torch.ops.prims.convert_element_type.default(cat_22, torch.float32);  cat_22 = None
    slice_103 = torch.ops.aten.slice.Tensor(convert_element_type_507, 2, 0, 2)
    squeeze_10 = torch.ops.aten.squeeze.dim(arg212_1, 1);  arg212_1 = None
    unsqueeze_112 = torch.ops.aten.unsqueeze.default(squeeze_10, 1);  squeeze_10 = None
    convert_element_type_508 = torch.ops.prims.convert_element_type.default(unsqueeze_112, torch.float32);  unsqueeze_112 = None
    select_175 = torch.ops.aten.select.int(convert_element_type_508, 1, 0)
    select_176 = torch.ops.aten.select.int(select_175, 1, 0);  select_175 = None
    view_365 = torch.ops.aten.reshape.default(select_176, [1, -1, 1]);  select_176 = None
    mul_270 = torch.ops.aten.mul.Tensor(slice_103, view_365);  slice_103 = view_365 = None
    slice_104 = torch.ops.aten.slice.Tensor(convert_element_type_507, 2, 1, 3)
    select_177 = torch.ops.aten.select.int(convert_element_type_508, 1, 0)
    select_178 = torch.ops.aten.select.int(select_177, 1, 1);  select_177 = None
    view_366 = torch.ops.aten.reshape.default(select_178, [1, -1, 1]);  select_178 = None
    mul_271 = torch.ops.aten.mul.Tensor(slice_104, view_366);  slice_104 = view_366 = None
    add_220 = torch.ops.aten.add.Tensor(mul_270, mul_271);  mul_270 = mul_271 = None
    slice_105 = torch.ops.aten.slice.Tensor(convert_element_type_507, 2, 2, 4)
    select_179 = torch.ops.aten.select.int(convert_element_type_508, 1, 0)
    select_180 = torch.ops.aten.select.int(select_179, 1, 2);  select_179 = None
    view_367 = torch.ops.aten.reshape.default(select_180, [1, -1, 1]);  select_180 = None
    mul_272 = torch.ops.aten.mul.Tensor(slice_105, view_367);  slice_105 = view_367 = None
    add_221 = torch.ops.aten.add.Tensor(add_220, mul_272);  add_220 = mul_272 = None
    slice_106 = torch.ops.aten.slice.Tensor(convert_element_type_507, 2, 3, 5);  convert_element_type_507 = None
    select_181 = torch.ops.aten.select.int(convert_element_type_508, 1, 0);  convert_element_type_508 = None
    select_182 = torch.ops.aten.select.int(select_181, 1, 3);  select_181 = None
    view_368 = torch.ops.aten.reshape.default(select_182, [1, -1, 1]);  select_182 = None
    mul_273 = torch.ops.aten.mul.Tensor(slice_106, view_368);  slice_106 = view_368 = None
    add_222 = torch.ops.aten.add.Tensor(add_221, mul_273);  add_221 = mul_273 = None
    convert_element_type_509 = torch.ops.prims.convert_element_type.default(add_222, torch.bfloat16);  add_222 = None
    slice_107 = torch.ops.aten.slice.Tensor(convert_element_type_509, 2, -1, 9223372036854775807);  convert_element_type_509 = None
    convert_element_type_510 = torch.ops.prims.convert_element_type.default(slice_107, torch.float32);  slice_107 = None
    neg_49 = torch.ops.aten.neg.default(convert_element_type_510)
    exp_66 = torch.ops.aten.exp.default(neg_49);  neg_49 = None
    add_223 = torch.ops.aten.add.Tensor(exp_66, 1);  exp_66 = None
    div_46 = torch.ops.aten.div.Tensor(convert_element_type_510, add_223);  convert_element_type_510 = add_223 = None
    convert_element_type_511 = torch.ops.prims.convert_element_type.default(div_46, torch.bfloat16);  div_46 = None
    permute_211 = torch.ops.aten.permute.default(convert_element_type_511, [0, 2, 1]);  convert_element_type_511 = None
    split_with_sizes_10 = torch.ops.aten.split_with_sizes.default(permute_211, [2048, 2048, 2048], -1);  permute_211 = None
    getitem_36 = split_with_sizes_10[0]
    getitem_37 = split_with_sizes_10[1]
    getitem_38 = split_with_sizes_10[2];  split_with_sizes_10 = None
    full_default_12 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_188 = torch.ops.aten.select.int(full_default_12, 2, 0);  select_188 = None
    view_370 = torch.ops.aten.reshape.default(getitem_37, [1, 1, -1, 128]);  getitem_37 = None
    permute_213 = torch.ops.aten.permute.default(view_370, [0, 2, 1, 3]);  view_370 = None
    convert_element_type_514 = torch.ops.prims.convert_element_type.default(permute_213, torch.float32);  permute_213 = None
    clone_54 = torch.ops.aten.clone.default(convert_element_type_514, memory_format = torch.contiguous_format);  convert_element_type_514 = None
    mul_277 = torch.ops.aten.mul.Tensor(clone_54, clone_54)
    sum_45 = torch.ops.aten.sum.dim_IntList(mul_277, [-1], True);  mul_277 = None
    add_226 = torch.ops.aten.add.Tensor(sum_45, 1e-06);  sum_45 = None
    rsqrt_64 = torch.ops.aten.rsqrt.default(add_226);  add_226 = None
    mul_278 = torch.ops.aten.mul.Tensor(clone_54, rsqrt_64);  clone_54 = rsqrt_64 = None
    select_184 = torch.ops.aten.select.int(mul_278, 2, 0);  mul_278 = None
    unsqueeze_117 = torch.ops.aten.unsqueeze.default(select_184, -1)
    view_371 = torch.ops.aten.reshape.default(getitem_38, [1, 1, -1, 128]);  getitem_38 = None
    permute_214 = torch.ops.aten.permute.default(view_371, [0, 2, 1, 3]);  view_371 = None
    convert_element_type_515 = torch.ops.prims.convert_element_type.default(permute_214, torch.float32);  permute_214 = None
    clone_55 = torch.ops.aten.clone.default(convert_element_type_515, memory_format = torch.contiguous_format);  convert_element_type_515 = None
    select_185 = torch.ops.aten.select.int(clone_55, 2, 0);  clone_55 = None
    exp_67 = torch.ops.aten.exp.default(arg213_1);  arg213_1 = None
    neg_50 = torch.ops.aten.neg.default(exp_67);  exp_67 = None
    view_363 = torch.ops.aten.reshape.default(convert_element_type_498, [1, 2048])
    permute_210 = torch.ops.aten.permute.default(arg210_1, [1, 0]);  arg210_1 = None
    mm_104 = torch.ops.aten.mm.default(view_363, permute_210);  view_363 = permute_210 = None
    view_364 = torch.ops.aten.reshape.default(mm_104, [1, 1, 16]);  mm_104 = None
    convert_element_type_512 = torch.ops.prims.convert_element_type.default(view_364, torch.float32);  view_364 = None
    add_224 = torch.ops.aten.add.Tensor(convert_element_type_512, arg214_1);  convert_element_type_512 = arg214_1 = None
    gt_10 = torch.ops.aten.gt.Scalar(add_224, 20)
    exp_68 = torch.ops.aten.exp.default(add_224)
    log1p_10 = torch.ops.aten.log1p.default(exp_68);  exp_68 = None
    where_11 = torch.ops.aten.where.self(gt_10, add_224, log1p_10);  gt_10 = add_224 = log1p_10 = None
    mul_274 = torch.ops.aten.mul.Tensor(neg_50, where_11);  neg_50 = where_11 = None
    permute_216 = torch.ops.aten.permute.default(mul_274, [0, 2, 1]);  mul_274 = None
    select_186 = torch.ops.aten.select.int(permute_216, 2, 0);  permute_216 = None
    exp_69 = torch.ops.aten.exp.default(select_186);  select_186 = None
    unsqueeze_113 = torch.ops.aten.unsqueeze.default(exp_69, 2);  exp_69 = None
    unsqueeze_114 = torch.ops.aten.unsqueeze.default(unsqueeze_113, 3);  unsqueeze_113 = None
    mul_279 = torch.ops.aten.mul.Tensor(arg215_1, unsqueeze_114);  unsqueeze_114 = None
    unsqueeze_116 = torch.ops.aten.unsqueeze.default(select_184, -1);  select_184 = None
    mul_280 = torch.ops.aten.mul.Tensor(mul_279, unsqueeze_116);  unsqueeze_116 = None
    sum_46 = torch.ops.aten.sum.dim_IntList(mul_280, [-2]);  mul_280 = None
    sub_13 = torch.ops.aten.sub.Tensor(select_185, sum_46);  select_185 = sum_46 = None
    view_361 = torch.ops.aten.reshape.default(convert_element_type_498, [1, 2048])
    permute_209 = torch.ops.aten.permute.default(arg209_1, [1, 0]);  arg209_1 = None
    mm_103 = torch.ops.aten.mm.default(view_361, permute_209);  view_361 = permute_209 = None
    view_362 = torch.ops.aten.reshape.default(mm_103, [1, 1, 16]);  mm_103 = None
    sigmoid_13 = torch.ops.aten.sigmoid.default(view_362);  view_362 = None
    permute_215 = torch.ops.aten.permute.default(sigmoid_13, [0, 2, 1]);  sigmoid_13 = None
    convert_element_type_516 = torch.ops.prims.convert_element_type.default(permute_215, torch.float32);  permute_215 = None
    clone_56 = torch.ops.aten.clone.default(convert_element_type_516, memory_format = torch.contiguous_format);  convert_element_type_516 = None
    select_187 = torch.ops.aten.select.int(clone_56, 2, 0);  clone_56 = None
    unsqueeze_115 = torch.ops.aten.unsqueeze.default(select_187, -1);  select_187 = None
    mul_281 = torch.ops.aten.mul.Tensor(sub_13, unsqueeze_115);  sub_13 = unsqueeze_115 = None
    unsqueeze_118 = torch.ops.aten.unsqueeze.default(mul_281, -2);  mul_281 = None
    mul_282 = torch.ops.aten.mul.Tensor(unsqueeze_117, unsqueeze_118);  unsqueeze_117 = unsqueeze_118 = None
    add_227 = torch.ops.aten.add.Tensor(mul_279, mul_282);  mul_279 = mul_282 = None
    view_369 = torch.ops.aten.reshape.default(getitem_36, [1, 1, -1, 128]);  getitem_36 = None
    permute_212 = torch.ops.aten.permute.default(view_369, [0, 2, 1, 3]);  view_369 = None
    convert_element_type_513 = torch.ops.prims.convert_element_type.default(permute_212, torch.float32);  permute_212 = None
    clone_53 = torch.ops.aten.clone.default(convert_element_type_513, memory_format = torch.contiguous_format);  convert_element_type_513 = None
    mul_275 = torch.ops.aten.mul.Tensor(clone_53, clone_53)
    sum_44 = torch.ops.aten.sum.dim_IntList(mul_275, [-1], True);  mul_275 = None
    add_225 = torch.ops.aten.add.Tensor(sum_44, 1e-06);  sum_44 = None
    rsqrt_63 = torch.ops.aten.rsqrt.default(add_225);  add_225 = None
    mul_276 = torch.ops.aten.mul.Tensor(clone_53, rsqrt_63);  clone_53 = rsqrt_63 = None
    div_47 = torch.ops.aten.div.Tensor(mul_276, 11.313708498984761);  mul_276 = None
    select_183 = torch.ops.aten.select.int(div_47, 2, 0);  div_47 = None
    unsqueeze_119 = torch.ops.aten.unsqueeze.default(select_183, -1);  select_183 = None
    mul_283 = torch.ops.aten.mul.Tensor(add_227, unsqueeze_119);  unsqueeze_119 = None
    sum_47 = torch.ops.aten.sum.dim_IntList(mul_283, [-2]);  mul_283 = None
    select_scatter_default_14 = torch.ops.aten.select_scatter.default(full_default_12, sum_47, 2, 0);  full_default_12 = sum_47 = None
    permute_218 = torch.ops.aten.permute.default(select_scatter_default_14, [0, 2, 1, 3]);  select_scatter_default_14 = None
    convert_element_type_517 = torch.ops.prims.convert_element_type.default(permute_218, torch.bfloat16);  permute_218 = None
    view_372 = torch.ops.aten.reshape.default(convert_element_type_517, [-1, 128]);  convert_element_type_517 = None
    convert_element_type_518 = torch.ops.prims.convert_element_type.default(view_372, torch.float32);  view_372 = None
    pow_44 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_518, 2)
    mean_43 = torch.ops.aten.mean.dim(pow_44, [-1], True);  pow_44 = None
    add_228 = torch.ops.aten.add.Tensor(mean_43, 1e-06);  mean_43 = None
    rsqrt_65 = torch.ops.aten.rsqrt.default(add_228);  add_228 = None
    mul_284 = torch.ops.aten.mul.Tensor(convert_element_type_518, rsqrt_65);  convert_element_type_518 = rsqrt_65 = None
    convert_element_type_519 = torch.ops.prims.convert_element_type.default(mul_284, torch.bfloat16);  mul_284 = None
    mul_285 = torch.ops.aten.mul.Tensor(arg216_1, convert_element_type_519);  arg216_1 = convert_element_type_519 = None
    view_358 = torch.ops.aten.reshape.default(convert_element_type_498, [1, 2048]);  convert_element_type_498 = None
    permute_208 = torch.ops.aten.permute.default(arg208_1, [1, 0]);  arg208_1 = None
    mm_102 = torch.ops.aten.mm.default(view_358, permute_208);  view_358 = permute_208 = None
    view_359 = torch.ops.aten.reshape.default(mm_102, [1, 1, 2048]);  mm_102 = None
    view_360 = torch.ops.aten.reshape.default(view_359, [1, 1, -1, 128]);  view_359 = None
    view_373 = torch.ops.aten.reshape.default(view_360, [-1, 128]);  view_360 = None
    convert_element_type_520 = torch.ops.prims.convert_element_type.default(view_373, torch.float32);  view_373 = None
    neg_51 = torch.ops.aten.neg.default(convert_element_type_520)
    exp_70 = torch.ops.aten.exp.default(neg_51);  neg_51 = None
    add_229 = torch.ops.aten.add.Tensor(exp_70, 1);  exp_70 = None
    div_48 = torch.ops.aten.div.Tensor(convert_element_type_520, add_229);  convert_element_type_520 = add_229 = None
    mul_286 = torch.ops.aten.mul.Tensor(mul_285, div_48);  mul_285 = div_48 = None
    convert_element_type_521 = torch.ops.prims.convert_element_type.default(mul_286, torch.bfloat16);  mul_286 = None
    view_374 = torch.ops.aten.reshape.default(convert_element_type_521, [1, 1, -1]);  convert_element_type_521 = None
    view_375 = torch.ops.aten.reshape.default(view_374, [1, 2048]);  view_374 = None
    permute_219 = torch.ops.aten.permute.default(arg217_1, [1, 0]);  arg217_1 = None
    mm_105 = torch.ops.aten.mm.default(view_375, permute_219);  view_375 = permute_219 = None
    view_376 = torch.ops.aten.reshape.default(mm_105, [1, 1, 2048]);  mm_105 = None
    add_230 = torch.ops.aten.add.Tensor(add_217, view_376);  add_217 = view_376 = None
    convert_element_type_524 = torch.ops.prims.convert_element_type.default(add_230, torch.float32)
    pow_45 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_524, 2)
    mean_44 = torch.ops.aten.mean.dim(pow_45, [-1], True);  pow_45 = None
    add_231 = torch.ops.aten.add.Tensor(mean_44, 1e-06);  mean_44 = None
    rsqrt_66 = torch.ops.aten.rsqrt.default(add_231);  add_231 = None
    mul_287 = torch.ops.aten.mul.Tensor(convert_element_type_524, rsqrt_66);  convert_element_type_524 = rsqrt_66 = None
    convert_element_type_525 = torch.ops.prims.convert_element_type.default(arg218_1, torch.float32);  arg218_1 = None
    add_232 = torch.ops.aten.add.Tensor(convert_element_type_525, 1.0);  convert_element_type_525 = None
    mul_288 = torch.ops.aten.mul.Tensor(mul_287, add_232);  mul_287 = add_232 = None
    convert_element_type_526 = torch.ops.prims.convert_element_type.default(mul_288, torch.bfloat16);  mul_288 = None
    view_377 = torch.ops.aten.reshape.default(convert_element_type_526, [1, 2048])
    permute_220 = torch.ops.aten.permute.default(arg219_1, [1, 0]);  arg219_1 = None
    mm_106 = torch.ops.aten.mm.default(view_377, permute_220);  view_377 = permute_220 = None
    view_378 = torch.ops.aten.reshape.default(mm_106, [1, 1, 6144]);  mm_106 = None
    convert_element_type_529 = torch.ops.prims.convert_element_type.default(view_378, torch.float32);  view_378 = None
    neg_52 = torch.ops.aten.neg.default(convert_element_type_529)
    exp_71 = torch.ops.aten.exp.default(neg_52);  neg_52 = None
    add_233 = torch.ops.aten.add.Tensor(exp_71, 1);  exp_71 = None
    div_49 = torch.ops.aten.div.Tensor(convert_element_type_529, add_233);  convert_element_type_529 = add_233 = None
    convert_element_type_530 = torch.ops.prims.convert_element_type.default(div_49, torch.bfloat16);  div_49 = None
    view_379 = torch.ops.aten.reshape.default(convert_element_type_526, [1, 2048]);  convert_element_type_526 = None
    permute_221 = torch.ops.aten.permute.default(arg220_1, [1, 0]);  arg220_1 = None
    mm_107 = torch.ops.aten.mm.default(view_379, permute_221);  view_379 = permute_221 = None
    view_380 = torch.ops.aten.reshape.default(mm_107, [1, 1, 6144]);  mm_107 = None
    mul_289 = torch.ops.aten.mul.Tensor(convert_element_type_530, view_380);  convert_element_type_530 = view_380 = None
    view_381 = torch.ops.aten.reshape.default(mul_289, [1, 6144]);  mul_289 = None
    permute_222 = torch.ops.aten.permute.default(arg221_1, [1, 0]);  arg221_1 = None
    mm_108 = torch.ops.aten.mm.default(view_381, permute_222);  view_381 = permute_222 = None
    view_382 = torch.ops.aten.reshape.default(mm_108, [1, 1, 2048]);  mm_108 = None
    add_234 = torch.ops.aten.add.Tensor(add_230, view_382);  add_230 = view_382 = None
    convert_element_type_535 = torch.ops.prims.convert_element_type.default(add_234, torch.float32)
    pow_46 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_535, 2)
    mean_45 = torch.ops.aten.mean.dim(pow_46, [-1], True);  pow_46 = None
    add_235 = torch.ops.aten.add.Tensor(mean_45, 1e-06);  mean_45 = None
    rsqrt_67 = torch.ops.aten.rsqrt.default(add_235);  add_235 = None
    mul_290 = torch.ops.aten.mul.Tensor(convert_element_type_535, rsqrt_67);  convert_element_type_535 = rsqrt_67 = None
    convert_element_type_536 = torch.ops.prims.convert_element_type.default(arg222_1, torch.float32);  arg222_1 = None
    add_236 = torch.ops.aten.add.Tensor(convert_element_type_536, 1.0);  convert_element_type_536 = None
    mul_291 = torch.ops.aten.mul.Tensor(mul_290, add_236);  mul_290 = add_236 = None
    convert_element_type_537 = torch.ops.prims.convert_element_type.default(mul_291, torch.bfloat16);  mul_291 = None
    view_383 = torch.ops.aten.reshape.default(convert_element_type_537, [1, 2048])
    permute_223 = torch.ops.aten.permute.default(arg223_1, [1, 0]);  arg223_1 = None
    mm_109 = torch.ops.aten.mm.default(view_383, permute_223);  view_383 = permute_223 = None
    view_384 = torch.ops.aten.reshape.default(mm_109, [1, 1, 6144]);  mm_109 = None
    permute_224 = torch.ops.aten.permute.default(view_384, [0, 2, 1]);  view_384 = None
    cat_23 = torch.ops.aten.cat.default([arg227_1, permute_224], -1);  permute_224 = None
    slice_108 = torch.ops.aten.slice.Tensor(cat_23, 2, -4, 9223372036854775807)
    copy_37 = torch.ops.aten.copy.default(arg227_1, slice_108);  slice_108 = None
    convert_element_type_546 = torch.ops.prims.convert_element_type.default(cat_23, torch.float32);  cat_23 = None
    slice_109 = torch.ops.aten.slice.Tensor(convert_element_type_546, 2, 0, 2)
    squeeze_11 = torch.ops.aten.squeeze.dim(arg228_1, 1);  arg228_1 = None
    unsqueeze_120 = torch.ops.aten.unsqueeze.default(squeeze_11, 1);  squeeze_11 = None
    convert_element_type_547 = torch.ops.prims.convert_element_type.default(unsqueeze_120, torch.float32);  unsqueeze_120 = None
    select_190 = torch.ops.aten.select.int(convert_element_type_547, 1, 0)
    select_191 = torch.ops.aten.select.int(select_190, 1, 0);  select_190 = None
    view_392 = torch.ops.aten.reshape.default(select_191, [1, -1, 1]);  select_191 = None
    mul_292 = torch.ops.aten.mul.Tensor(slice_109, view_392);  slice_109 = view_392 = None
    slice_110 = torch.ops.aten.slice.Tensor(convert_element_type_546, 2, 1, 3)
    select_192 = torch.ops.aten.select.int(convert_element_type_547, 1, 0)
    select_193 = torch.ops.aten.select.int(select_192, 1, 1);  select_192 = None
    view_393 = torch.ops.aten.reshape.default(select_193, [1, -1, 1]);  select_193 = None
    mul_293 = torch.ops.aten.mul.Tensor(slice_110, view_393);  slice_110 = view_393 = None
    add_237 = torch.ops.aten.add.Tensor(mul_292, mul_293);  mul_292 = mul_293 = None
    slice_111 = torch.ops.aten.slice.Tensor(convert_element_type_546, 2, 2, 4)
    select_194 = torch.ops.aten.select.int(convert_element_type_547, 1, 0)
    select_195 = torch.ops.aten.select.int(select_194, 1, 2);  select_194 = None
    view_394 = torch.ops.aten.reshape.default(select_195, [1, -1, 1]);  select_195 = None
    mul_294 = torch.ops.aten.mul.Tensor(slice_111, view_394);  slice_111 = view_394 = None
    add_238 = torch.ops.aten.add.Tensor(add_237, mul_294);  add_237 = mul_294 = None
    slice_112 = torch.ops.aten.slice.Tensor(convert_element_type_546, 2, 3, 5);  convert_element_type_546 = None
    select_196 = torch.ops.aten.select.int(convert_element_type_547, 1, 0);  convert_element_type_547 = None
    select_197 = torch.ops.aten.select.int(select_196, 1, 3);  select_196 = None
    view_395 = torch.ops.aten.reshape.default(select_197, [1, -1, 1]);  select_197 = None
    mul_295 = torch.ops.aten.mul.Tensor(slice_112, view_395);  slice_112 = view_395 = None
    add_239 = torch.ops.aten.add.Tensor(add_238, mul_295);  add_238 = mul_295 = None
    convert_element_type_548 = torch.ops.prims.convert_element_type.default(add_239, torch.bfloat16);  add_239 = None
    slice_113 = torch.ops.aten.slice.Tensor(convert_element_type_548, 2, -1, 9223372036854775807);  convert_element_type_548 = None
    convert_element_type_549 = torch.ops.prims.convert_element_type.default(slice_113, torch.float32);  slice_113 = None
    neg_53 = torch.ops.aten.neg.default(convert_element_type_549)
    exp_72 = torch.ops.aten.exp.default(neg_53);  neg_53 = None
    add_240 = torch.ops.aten.add.Tensor(exp_72, 1);  exp_72 = None
    div_50 = torch.ops.aten.div.Tensor(convert_element_type_549, add_240);  convert_element_type_549 = add_240 = None
    convert_element_type_550 = torch.ops.prims.convert_element_type.default(div_50, torch.bfloat16);  div_50 = None
    permute_228 = torch.ops.aten.permute.default(convert_element_type_550, [0, 2, 1]);  convert_element_type_550 = None
    split_with_sizes_11 = torch.ops.aten.split_with_sizes.default(permute_228, [2048, 2048, 2048], -1);  permute_228 = None
    getitem_39 = split_with_sizes_11[0]
    getitem_40 = split_with_sizes_11[1]
    getitem_41 = split_with_sizes_11[2];  split_with_sizes_11 = None
    full_default_13 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_203 = torch.ops.aten.select.int(full_default_13, 2, 0);  select_203 = None
    view_397 = torch.ops.aten.reshape.default(getitem_40, [1, 1, -1, 128]);  getitem_40 = None
    permute_230 = torch.ops.aten.permute.default(view_397, [0, 2, 1, 3]);  view_397 = None
    convert_element_type_553 = torch.ops.prims.convert_element_type.default(permute_230, torch.float32);  permute_230 = None
    clone_58 = torch.ops.aten.clone.default(convert_element_type_553, memory_format = torch.contiguous_format);  convert_element_type_553 = None
    mul_299 = torch.ops.aten.mul.Tensor(clone_58, clone_58)
    sum_49 = torch.ops.aten.sum.dim_IntList(mul_299, [-1], True);  mul_299 = None
    add_243 = torch.ops.aten.add.Tensor(sum_49, 1e-06);  sum_49 = None
    rsqrt_69 = torch.ops.aten.rsqrt.default(add_243);  add_243 = None
    mul_300 = torch.ops.aten.mul.Tensor(clone_58, rsqrt_69);  clone_58 = rsqrt_69 = None
    select_199 = torch.ops.aten.select.int(mul_300, 2, 0);  mul_300 = None
    unsqueeze_125 = torch.ops.aten.unsqueeze.default(select_199, -1)
    view_398 = torch.ops.aten.reshape.default(getitem_41, [1, 1, -1, 128]);  getitem_41 = None
    permute_231 = torch.ops.aten.permute.default(view_398, [0, 2, 1, 3]);  view_398 = None
    convert_element_type_554 = torch.ops.prims.convert_element_type.default(permute_231, torch.float32);  permute_231 = None
    clone_59 = torch.ops.aten.clone.default(convert_element_type_554, memory_format = torch.contiguous_format);  convert_element_type_554 = None
    select_200 = torch.ops.aten.select.int(clone_59, 2, 0);  clone_59 = None
    exp_73 = torch.ops.aten.exp.default(arg229_1);  arg229_1 = None
    neg_54 = torch.ops.aten.neg.default(exp_73);  exp_73 = None
    view_390 = torch.ops.aten.reshape.default(convert_element_type_537, [1, 2048])
    permute_227 = torch.ops.aten.permute.default(arg226_1, [1, 0]);  arg226_1 = None
    mm_112 = torch.ops.aten.mm.default(view_390, permute_227);  view_390 = permute_227 = None
    view_391 = torch.ops.aten.reshape.default(mm_112, [1, 1, 16]);  mm_112 = None
    convert_element_type_551 = torch.ops.prims.convert_element_type.default(view_391, torch.float32);  view_391 = None
    add_241 = torch.ops.aten.add.Tensor(convert_element_type_551, arg230_1);  convert_element_type_551 = arg230_1 = None
    gt_11 = torch.ops.aten.gt.Scalar(add_241, 20)
    exp_74 = torch.ops.aten.exp.default(add_241)
    log1p_11 = torch.ops.aten.log1p.default(exp_74);  exp_74 = None
    where_12 = torch.ops.aten.where.self(gt_11, add_241, log1p_11);  gt_11 = add_241 = log1p_11 = None
    mul_296 = torch.ops.aten.mul.Tensor(neg_54, where_12);  neg_54 = where_12 = None
    permute_233 = torch.ops.aten.permute.default(mul_296, [0, 2, 1]);  mul_296 = None
    select_201 = torch.ops.aten.select.int(permute_233, 2, 0);  permute_233 = None
    exp_75 = torch.ops.aten.exp.default(select_201);  select_201 = None
    unsqueeze_121 = torch.ops.aten.unsqueeze.default(exp_75, 2);  exp_75 = None
    unsqueeze_122 = torch.ops.aten.unsqueeze.default(unsqueeze_121, 3);  unsqueeze_121 = None
    mul_301 = torch.ops.aten.mul.Tensor(arg231_1, unsqueeze_122);  unsqueeze_122 = None
    unsqueeze_124 = torch.ops.aten.unsqueeze.default(select_199, -1);  select_199 = None
    mul_302 = torch.ops.aten.mul.Tensor(mul_301, unsqueeze_124);  unsqueeze_124 = None
    sum_50 = torch.ops.aten.sum.dim_IntList(mul_302, [-2]);  mul_302 = None
    sub_14 = torch.ops.aten.sub.Tensor(select_200, sum_50);  select_200 = sum_50 = None
    view_388 = torch.ops.aten.reshape.default(convert_element_type_537, [1, 2048])
    permute_226 = torch.ops.aten.permute.default(arg225_1, [1, 0]);  arg225_1 = None
    mm_111 = torch.ops.aten.mm.default(view_388, permute_226);  view_388 = permute_226 = None
    view_389 = torch.ops.aten.reshape.default(mm_111, [1, 1, 16]);  mm_111 = None
    sigmoid_14 = torch.ops.aten.sigmoid.default(view_389);  view_389 = None
    permute_232 = torch.ops.aten.permute.default(sigmoid_14, [0, 2, 1]);  sigmoid_14 = None
    convert_element_type_555 = torch.ops.prims.convert_element_type.default(permute_232, torch.float32);  permute_232 = None
    clone_60 = torch.ops.aten.clone.default(convert_element_type_555, memory_format = torch.contiguous_format);  convert_element_type_555 = None
    select_202 = torch.ops.aten.select.int(clone_60, 2, 0);  clone_60 = None
    unsqueeze_123 = torch.ops.aten.unsqueeze.default(select_202, -1);  select_202 = None
    mul_303 = torch.ops.aten.mul.Tensor(sub_14, unsqueeze_123);  sub_14 = unsqueeze_123 = None
    unsqueeze_126 = torch.ops.aten.unsqueeze.default(mul_303, -2);  mul_303 = None
    mul_304 = torch.ops.aten.mul.Tensor(unsqueeze_125, unsqueeze_126);  unsqueeze_125 = unsqueeze_126 = None
    add_244 = torch.ops.aten.add.Tensor(mul_301, mul_304);  mul_301 = mul_304 = None
    view_396 = torch.ops.aten.reshape.default(getitem_39, [1, 1, -1, 128]);  getitem_39 = None
    permute_229 = torch.ops.aten.permute.default(view_396, [0, 2, 1, 3]);  view_396 = None
    convert_element_type_552 = torch.ops.prims.convert_element_type.default(permute_229, torch.float32);  permute_229 = None
    clone_57 = torch.ops.aten.clone.default(convert_element_type_552, memory_format = torch.contiguous_format);  convert_element_type_552 = None
    mul_297 = torch.ops.aten.mul.Tensor(clone_57, clone_57)
    sum_48 = torch.ops.aten.sum.dim_IntList(mul_297, [-1], True);  mul_297 = None
    add_242 = torch.ops.aten.add.Tensor(sum_48, 1e-06);  sum_48 = None
    rsqrt_68 = torch.ops.aten.rsqrt.default(add_242);  add_242 = None
    mul_298 = torch.ops.aten.mul.Tensor(clone_57, rsqrt_68);  clone_57 = rsqrt_68 = None
    div_51 = torch.ops.aten.div.Tensor(mul_298, 11.313708498984761);  mul_298 = None
    select_198 = torch.ops.aten.select.int(div_51, 2, 0);  div_51 = None
    unsqueeze_127 = torch.ops.aten.unsqueeze.default(select_198, -1);  select_198 = None
    mul_305 = torch.ops.aten.mul.Tensor(add_244, unsqueeze_127);  unsqueeze_127 = None
    sum_51 = torch.ops.aten.sum.dim_IntList(mul_305, [-2]);  mul_305 = None
    select_scatter_default_15 = torch.ops.aten.select_scatter.default(full_default_13, sum_51, 2, 0);  full_default_13 = sum_51 = None
    permute_235 = torch.ops.aten.permute.default(select_scatter_default_15, [0, 2, 1, 3]);  select_scatter_default_15 = None
    convert_element_type_556 = torch.ops.prims.convert_element_type.default(permute_235, torch.bfloat16);  permute_235 = None
    view_399 = torch.ops.aten.reshape.default(convert_element_type_556, [-1, 128]);  convert_element_type_556 = None
    convert_element_type_557 = torch.ops.prims.convert_element_type.default(view_399, torch.float32);  view_399 = None
    pow_47 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_557, 2)
    mean_46 = torch.ops.aten.mean.dim(pow_47, [-1], True);  pow_47 = None
    add_245 = torch.ops.aten.add.Tensor(mean_46, 1e-06);  mean_46 = None
    rsqrt_70 = torch.ops.aten.rsqrt.default(add_245);  add_245 = None
    mul_306 = torch.ops.aten.mul.Tensor(convert_element_type_557, rsqrt_70);  convert_element_type_557 = rsqrt_70 = None
    convert_element_type_558 = torch.ops.prims.convert_element_type.default(mul_306, torch.bfloat16);  mul_306 = None
    mul_307 = torch.ops.aten.mul.Tensor(arg232_1, convert_element_type_558);  arg232_1 = convert_element_type_558 = None
    view_385 = torch.ops.aten.reshape.default(convert_element_type_537, [1, 2048]);  convert_element_type_537 = None
    permute_225 = torch.ops.aten.permute.default(arg224_1, [1, 0]);  arg224_1 = None
    mm_110 = torch.ops.aten.mm.default(view_385, permute_225);  view_385 = permute_225 = None
    view_386 = torch.ops.aten.reshape.default(mm_110, [1, 1, 2048]);  mm_110 = None
    view_387 = torch.ops.aten.reshape.default(view_386, [1, 1, -1, 128]);  view_386 = None
    view_400 = torch.ops.aten.reshape.default(view_387, [-1, 128]);  view_387 = None
    convert_element_type_559 = torch.ops.prims.convert_element_type.default(view_400, torch.float32);  view_400 = None
    neg_55 = torch.ops.aten.neg.default(convert_element_type_559)
    exp_76 = torch.ops.aten.exp.default(neg_55);  neg_55 = None
    add_246 = torch.ops.aten.add.Tensor(exp_76, 1);  exp_76 = None
    div_52 = torch.ops.aten.div.Tensor(convert_element_type_559, add_246);  convert_element_type_559 = add_246 = None
    mul_308 = torch.ops.aten.mul.Tensor(mul_307, div_52);  mul_307 = div_52 = None
    convert_element_type_560 = torch.ops.prims.convert_element_type.default(mul_308, torch.bfloat16);  mul_308 = None
    view_401 = torch.ops.aten.reshape.default(convert_element_type_560, [1, 1, -1]);  convert_element_type_560 = None
    view_402 = torch.ops.aten.reshape.default(view_401, [1, 2048]);  view_401 = None
    permute_236 = torch.ops.aten.permute.default(arg233_1, [1, 0]);  arg233_1 = None
    mm_113 = torch.ops.aten.mm.default(view_402, permute_236);  view_402 = permute_236 = None
    view_403 = torch.ops.aten.reshape.default(mm_113, [1, 1, 2048]);  mm_113 = None
    add_247 = torch.ops.aten.add.Tensor(add_234, view_403);  add_234 = view_403 = None
    convert_element_type_563 = torch.ops.prims.convert_element_type.default(add_247, torch.float32)
    pow_48 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_563, 2)
    mean_47 = torch.ops.aten.mean.dim(pow_48, [-1], True);  pow_48 = None
    add_248 = torch.ops.aten.add.Tensor(mean_47, 1e-06);  mean_47 = None
    rsqrt_71 = torch.ops.aten.rsqrt.default(add_248);  add_248 = None
    mul_309 = torch.ops.aten.mul.Tensor(convert_element_type_563, rsqrt_71);  convert_element_type_563 = rsqrt_71 = None
    convert_element_type_564 = torch.ops.prims.convert_element_type.default(arg234_1, torch.float32);  arg234_1 = None
    add_249 = torch.ops.aten.add.Tensor(convert_element_type_564, 1.0);  convert_element_type_564 = None
    mul_310 = torch.ops.aten.mul.Tensor(mul_309, add_249);  mul_309 = add_249 = None
    convert_element_type_565 = torch.ops.prims.convert_element_type.default(mul_310, torch.bfloat16);  mul_310 = None
    view_404 = torch.ops.aten.reshape.default(convert_element_type_565, [1, 2048])
    permute_237 = torch.ops.aten.permute.default(arg235_1, [1, 0]);  arg235_1 = None
    mm_114 = torch.ops.aten.mm.default(view_404, permute_237);  view_404 = permute_237 = None
    view_405 = torch.ops.aten.reshape.default(mm_114, [1, 1, 6144]);  mm_114 = None
    convert_element_type_568 = torch.ops.prims.convert_element_type.default(view_405, torch.float32);  view_405 = None
    neg_56 = torch.ops.aten.neg.default(convert_element_type_568)
    exp_77 = torch.ops.aten.exp.default(neg_56);  neg_56 = None
    add_250 = torch.ops.aten.add.Tensor(exp_77, 1);  exp_77 = None
    div_53 = torch.ops.aten.div.Tensor(convert_element_type_568, add_250);  convert_element_type_568 = add_250 = None
    convert_element_type_569 = torch.ops.prims.convert_element_type.default(div_53, torch.bfloat16);  div_53 = None
    view_406 = torch.ops.aten.reshape.default(convert_element_type_565, [1, 2048]);  convert_element_type_565 = None
    permute_238 = torch.ops.aten.permute.default(arg236_1, [1, 0]);  arg236_1 = None
    mm_115 = torch.ops.aten.mm.default(view_406, permute_238);  view_406 = permute_238 = None
    view_407 = torch.ops.aten.reshape.default(mm_115, [1, 1, 6144]);  mm_115 = None
    mul_311 = torch.ops.aten.mul.Tensor(convert_element_type_569, view_407);  convert_element_type_569 = view_407 = None
    view_408 = torch.ops.aten.reshape.default(mul_311, [1, 6144]);  mul_311 = None
    permute_239 = torch.ops.aten.permute.default(arg237_1, [1, 0]);  arg237_1 = None
    mm_116 = torch.ops.aten.mm.default(view_408, permute_239);  view_408 = permute_239 = None
    view_409 = torch.ops.aten.reshape.default(mm_116, [1, 1, 2048]);  mm_116 = None
    add_251 = torch.ops.aten.add.Tensor(add_247, view_409);  add_247 = view_409 = None
    convert_element_type_574 = torch.ops.prims.convert_element_type.default(add_251, torch.float32)
    pow_49 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_574, 2)
    mean_48 = torch.ops.aten.mean.dim(pow_49, [-1], True);  pow_49 = None
    add_252 = torch.ops.aten.add.Tensor(mean_48, 1e-06);  mean_48 = None
    rsqrt_72 = torch.ops.aten.rsqrt.default(add_252);  add_252 = None
    mul_312 = torch.ops.aten.mul.Tensor(convert_element_type_574, rsqrt_72);  convert_element_type_574 = rsqrt_72 = None
    convert_element_type_575 = torch.ops.prims.convert_element_type.default(arg238_1, torch.float32);  arg238_1 = None
    add_253 = torch.ops.aten.add.Tensor(convert_element_type_575, 1.0);  convert_element_type_575 = None
    mul_313 = torch.ops.aten.mul.Tensor(mul_312, add_253);  mul_312 = add_253 = None
    convert_element_type_576 = torch.ops.prims.convert_element_type.default(mul_313, torch.bfloat16);  mul_313 = None
    view_410 = torch.ops.aten.reshape.default(convert_element_type_576, [1, 2048])
    permute_240 = torch.ops.aten.permute.default(arg239_1, [1, 0]);  arg239_1 = None
    mm_117 = torch.ops.aten.mm.default(view_410, permute_240);  view_410 = permute_240 = None
    view_411 = torch.ops.aten.reshape.default(mm_117, [1, 1, 4096]);  mm_117 = None
    view_412 = torch.ops.aten.reshape.default(view_411, [1, 1, -1, 512]);  view_411 = None
    split_3 = torch.ops.aten.split.Tensor(view_412, 256, -1);  view_412 = None
    getitem_42 = split_3[0]
    getitem_43 = split_3[1];  split_3 = None
    add_261 = torch.ops.aten.add.Tensor(arg244_1, 1)
    convert_element_type_579 = torch.ops.prims.convert_element_type.default(getitem_42, torch.float32);  getitem_42 = None
    pow_50 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_579, 2)
    mean_49 = torch.ops.aten.mean.dim(pow_50, [-1], True);  pow_50 = None
    add_254 = torch.ops.aten.add.Tensor(mean_49, 1e-06);  mean_49 = None
    rsqrt_73 = torch.ops.aten.rsqrt.default(add_254);  add_254 = None
    mul_314 = torch.ops.aten.mul.Tensor(convert_element_type_579, rsqrt_73);  convert_element_type_579 = rsqrt_73 = None
    convert_element_type_580 = torch.ops.prims.convert_element_type.default(arg240_1, torch.float32);  arg240_1 = None
    add_255 = torch.ops.aten.add.Tensor(convert_element_type_580, 1.0);  convert_element_type_580 = None
    mul_315 = torch.ops.aten.mul.Tensor(mul_314, add_255);  mul_314 = add_255 = None
    convert_element_type_581 = torch.ops.prims.convert_element_type.default(mul_315, torch.bfloat16);  mul_315 = None
    permute_241 = torch.ops.aten.permute.default(convert_element_type_581, [0, 2, 1, 3]);  convert_element_type_581 = None
    slice_114 = torch.ops.aten.slice.Tensor(permute_241, 3, 0, 64)
    unsqueeze_128 = torch.ops.aten.unsqueeze.default(convert_element_type_2, 1)
    mul_318 = torch.ops.aten.mul.Tensor(slice_114, unsqueeze_128)
    slice_119 = torch.ops.aten.slice.Tensor(slice_114, 3, 32, 9223372036854775807)
    neg_57 = torch.ops.aten.neg.default(slice_119);  slice_119 = None
    slice_118 = torch.ops.aten.slice.Tensor(slice_114, 3, 0, 32);  slice_114 = None
    cat_24 = torch.ops.aten.cat.default([neg_57, slice_118], -1);  neg_57 = slice_118 = None
    unsqueeze_129 = torch.ops.aten.unsqueeze.default(convert_element_type_3, 1)
    mul_319 = torch.ops.aten.mul.Tensor(cat_24, unsqueeze_129);  cat_24 = None
    add_258 = torch.ops.aten.add.Tensor(mul_318, mul_319);  mul_318 = mul_319 = None
    slice_115 = torch.ops.aten.slice.Tensor(permute_241, 3, 64, 9223372036854775807);  permute_241 = None
    cat_26 = torch.ops.aten.cat.default([add_258, slice_115], -1);  add_258 = slice_115 = None
    expand_32 = torch.ops.aten.expand.default(cat_26, [1, 8, 1, 256]);  cat_26 = None
    view_423 = torch.ops.aten.reshape.default(expand_32, [8, 1, 256]);  expand_32 = None
    iota_4 = torch.ops.prims.iota.default(1, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    add_260 = torch.ops.aten.add.Tensor(iota_4, arg244_1);  iota_4 = None
    view_415 = torch.ops.aten.reshape.default(convert_element_type_576, [1, 2048])
    permute_242 = torch.ops.aten.permute.default(arg241_1, [1, 0]);  arg241_1 = None
    mm_118 = torch.ops.aten.mm.default(view_415, permute_242);  view_415 = permute_242 = None
    view_416 = torch.ops.aten.reshape.default(mm_118, [1, 1, 512]);  mm_118 = None
    view_417 = torch.ops.aten.reshape.default(view_416, [1, 1, -1, 256]);  view_416 = None
    convert_element_type_584 = torch.ops.prims.convert_element_type.default(view_417, torch.float32);  view_417 = None
    pow_51 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_584, 2)
    mean_50 = torch.ops.aten.mean.dim(pow_51, [-1], True);  pow_51 = None
    add_256 = torch.ops.aten.add.Tensor(mean_50, 1e-06);  mean_50 = None
    rsqrt_74 = torch.ops.aten.rsqrt.default(add_256);  add_256 = None
    mul_316 = torch.ops.aten.mul.Tensor(convert_element_type_584, rsqrt_74);  convert_element_type_584 = rsqrt_74 = None
    convert_element_type_585 = torch.ops.prims.convert_element_type.default(arg242_1, torch.float32);  arg242_1 = None
    add_257 = torch.ops.aten.add.Tensor(convert_element_type_585, 1.0);  convert_element_type_585 = None
    mul_317 = torch.ops.aten.mul.Tensor(mul_316, add_257);  mul_316 = add_257 = None
    convert_element_type_586 = torch.ops.prims.convert_element_type.default(mul_317, torch.bfloat16);  mul_317 = None
    permute_243 = torch.ops.aten.permute.default(convert_element_type_586, [0, 2, 1, 3]);  convert_element_type_586 = None
    slice_116 = torch.ops.aten.slice.Tensor(permute_243, 3, 0, 64)
    mul_320 = torch.ops.aten.mul.Tensor(slice_116, unsqueeze_128);  unsqueeze_128 = None
    slice_121 = torch.ops.aten.slice.Tensor(slice_116, 3, 32, 9223372036854775807)
    neg_58 = torch.ops.aten.neg.default(slice_121);  slice_121 = None
    slice_120 = torch.ops.aten.slice.Tensor(slice_116, 3, 0, 32);  slice_116 = None
    cat_25 = torch.ops.aten.cat.default([neg_58, slice_120], -1);  neg_58 = slice_120 = None
    mul_321 = torch.ops.aten.mul.Tensor(cat_25, unsqueeze_129);  cat_25 = unsqueeze_129 = None
    add_259 = torch.ops.aten.add.Tensor(mul_320, mul_321);  mul_320 = mul_321 = None
    slice_117 = torch.ops.aten.slice.Tensor(permute_243, 3, 64, 9223372036854775807);  permute_243 = None
    cat_27 = torch.ops.aten.cat.default([add_259, slice_117], -1);  add_259 = slice_117 = None
    index_put_6 = torch.ops.aten.index_put_.default(arg245_1, [None, None, add_260], cat_27);  arg245_1 = cat_27 = None
    unsqueeze_132 = torch.ops.aten.unsqueeze.default(index_put_6, 2);  index_put_6 = None
    expand_29 = torch.ops.aten.expand.default(unsqueeze_132, [1, 2, 4, 144, 256]);  unsqueeze_132 = None
    clone_62 = torch.ops.aten.clone.default(expand_29, memory_format = torch.contiguous_format);  expand_29 = None
    view_421 = torch.ops.aten.reshape.default(clone_62, [1, 8, 144, 256]);  clone_62 = None
    permute_246 = torch.ops.aten.permute.default(view_421, [0, 1, 3, 2]);  view_421 = None
    expand_33 = torch.ops.aten.expand.default(permute_246, [1, 8, 256, 144]);  permute_246 = None
    view_424 = torch.ops.aten.reshape.default(expand_33, [8, 256, 144]);  expand_33 = None
    bmm_6 = torch.ops.aten.bmm.default(view_423, view_424);  view_423 = view_424 = None
    view_425 = torch.ops.aten.reshape.default(bmm_6, [1, 8, 1, 144]);  bmm_6 = None
    mul_322 = torch.ops.aten.mul.Tensor(view_425, 0.0625);  view_425 = None
    add_262 = torch.ops.aten.add.Tensor(mul_322, unsqueeze_3);  mul_322 = None
    convert_element_type_591 = torch.ops.prims.convert_element_type.default(add_262, torch.float32);  add_262 = None
    amax_3 = torch.ops.aten.amax.default(convert_element_type_591, [-1], True)
    sub_15 = torch.ops.aten.sub.Tensor(convert_element_type_591, amax_3);  convert_element_type_591 = amax_3 = None
    exp_78 = torch.ops.aten.exp.default(sub_15);  sub_15 = None
    sum_52 = torch.ops.aten.sum.dim_IntList(exp_78, [-1], True)
    div_54 = torch.ops.aten.div.Tensor(exp_78, sum_52);  exp_78 = sum_52 = None
    convert_element_type_592 = torch.ops.prims.convert_element_type.default(div_54, torch.bfloat16);  div_54 = None
    expand_34 = torch.ops.aten.expand.default(convert_element_type_592, [1, 8, 1, 144]);  convert_element_type_592 = None
    view_426 = torch.ops.aten.reshape.default(expand_34, [8, 1, 144]);  expand_34 = None
    view_418 = torch.ops.aten.reshape.default(convert_element_type_576, [1, 2048]);  convert_element_type_576 = None
    permute_244 = torch.ops.aten.permute.default(arg243_1, [1, 0]);  arg243_1 = None
    mm_119 = torch.ops.aten.mm.default(view_418, permute_244);  view_418 = permute_244 = None
    view_419 = torch.ops.aten.reshape.default(mm_119, [1, 1, 512]);  mm_119 = None
    view_420 = torch.ops.aten.reshape.default(view_419, [1, 1, -1, 256]);  view_419 = None
    permute_245 = torch.ops.aten.permute.default(view_420, [0, 2, 1, 3]);  view_420 = None
    index_put_7 = torch.ops.aten.index_put_.default(arg246_1, [None, None, add_260], permute_245);  arg246_1 = add_260 = permute_245 = None
    unsqueeze_135 = torch.ops.aten.unsqueeze.default(index_put_7, 2);  index_put_7 = None
    expand_31 = torch.ops.aten.expand.default(unsqueeze_135, [1, 2, 4, 144, 256]);  unsqueeze_135 = None
    clone_63 = torch.ops.aten.clone.default(expand_31, memory_format = torch.contiguous_format);  expand_31 = None
    view_422 = torch.ops.aten.reshape.default(clone_63, [1, 8, 144, 256]);  clone_63 = None
    expand_35 = torch.ops.aten.expand.default(view_422, [1, 8, 144, 256]);  view_422 = None
    view_427 = torch.ops.aten.reshape.default(expand_35, [8, 144, 256]);  expand_35 = None
    bmm_7 = torch.ops.aten.bmm.default(view_426, view_427);  view_426 = view_427 = None
    view_428 = torch.ops.aten.reshape.default(bmm_7, [1, 8, 1, 256]);  bmm_7 = None
    permute_247 = torch.ops.aten.permute.default(view_428, [0, 2, 1, 3]);  view_428 = None
    view_429 = torch.ops.aten.reshape.default(permute_247, [1, 1, -1]);  permute_247 = None
    clone_61 = torch.ops.aten.clone.default(getitem_43, memory_format = torch.contiguous_format);  getitem_43 = None
    view_413 = torch.ops.aten.reshape.default(clone_61, [1, 1, 2048]);  clone_61 = None
    sigmoid_15 = torch.ops.aten.sigmoid.default(view_413);  view_413 = None
    mul_323 = torch.ops.aten.mul.Tensor(view_429, sigmoid_15);  view_429 = sigmoid_15 = None
    view_430 = torch.ops.aten.reshape.default(mul_323, [1, 2048]);  mul_323 = None
    permute_248 = torch.ops.aten.permute.default(arg247_1, [1, 0]);  arg247_1 = None
    mm_120 = torch.ops.aten.mm.default(view_430, permute_248);  view_430 = permute_248 = None
    view_431 = torch.ops.aten.reshape.default(mm_120, [1, 1, 2048]);  mm_120 = None
    add_263 = torch.ops.aten.add.Tensor(add_251, view_431);  add_251 = view_431 = None
    convert_element_type_597 = torch.ops.prims.convert_element_type.default(add_263, torch.float32)
    pow_52 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_597, 2)
    mean_51 = torch.ops.aten.mean.dim(pow_52, [-1], True);  pow_52 = None
    add_264 = torch.ops.aten.add.Tensor(mean_51, 1e-06);  mean_51 = None
    rsqrt_75 = torch.ops.aten.rsqrt.default(add_264);  add_264 = None
    mul_324 = torch.ops.aten.mul.Tensor(convert_element_type_597, rsqrt_75);  convert_element_type_597 = rsqrt_75 = None
    convert_element_type_598 = torch.ops.prims.convert_element_type.default(arg248_1, torch.float32);  arg248_1 = None
    add_265 = torch.ops.aten.add.Tensor(convert_element_type_598, 1.0);  convert_element_type_598 = None
    mul_325 = torch.ops.aten.mul.Tensor(mul_324, add_265);  mul_324 = add_265 = None
    convert_element_type_599 = torch.ops.prims.convert_element_type.default(mul_325, torch.bfloat16);  mul_325 = None
    view_432 = torch.ops.aten.reshape.default(convert_element_type_599, [1, 2048])
    permute_249 = torch.ops.aten.permute.default(arg249_1, [1, 0]);  arg249_1 = None
    mm_121 = torch.ops.aten.mm.default(view_432, permute_249);  view_432 = permute_249 = None
    view_433 = torch.ops.aten.reshape.default(mm_121, [1, 1, 6144]);  mm_121 = None
    convert_element_type_602 = torch.ops.prims.convert_element_type.default(view_433, torch.float32);  view_433 = None
    neg_59 = torch.ops.aten.neg.default(convert_element_type_602)
    exp_79 = torch.ops.aten.exp.default(neg_59);  neg_59 = None
    add_266 = torch.ops.aten.add.Tensor(exp_79, 1);  exp_79 = None
    div_55 = torch.ops.aten.div.Tensor(convert_element_type_602, add_266);  convert_element_type_602 = add_266 = None
    convert_element_type_603 = torch.ops.prims.convert_element_type.default(div_55, torch.bfloat16);  div_55 = None
    view_434 = torch.ops.aten.reshape.default(convert_element_type_599, [1, 2048]);  convert_element_type_599 = None
    permute_250 = torch.ops.aten.permute.default(arg250_1, [1, 0]);  arg250_1 = None
    mm_122 = torch.ops.aten.mm.default(view_434, permute_250);  view_434 = permute_250 = None
    view_435 = torch.ops.aten.reshape.default(mm_122, [1, 1, 6144]);  mm_122 = None
    mul_326 = torch.ops.aten.mul.Tensor(convert_element_type_603, view_435);  convert_element_type_603 = view_435 = None
    view_436 = torch.ops.aten.reshape.default(mul_326, [1, 6144]);  mul_326 = None
    permute_251 = torch.ops.aten.permute.default(arg251_1, [1, 0]);  arg251_1 = None
    mm_123 = torch.ops.aten.mm.default(view_436, permute_251);  view_436 = permute_251 = None
    view_437 = torch.ops.aten.reshape.default(mm_123, [1, 1, 2048]);  mm_123 = None
    add_267 = torch.ops.aten.add.Tensor(add_263, view_437);  add_263 = view_437 = None
    convert_element_type_608 = torch.ops.prims.convert_element_type.default(add_267, torch.float32)
    pow_53 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_608, 2)
    mean_52 = torch.ops.aten.mean.dim(pow_53, [-1], True);  pow_53 = None
    add_268 = torch.ops.aten.add.Tensor(mean_52, 1e-06);  mean_52 = None
    rsqrt_76 = torch.ops.aten.rsqrt.default(add_268);  add_268 = None
    mul_327 = torch.ops.aten.mul.Tensor(convert_element_type_608, rsqrt_76);  convert_element_type_608 = rsqrt_76 = None
    convert_element_type_609 = torch.ops.prims.convert_element_type.default(arg252_1, torch.float32);  arg252_1 = None
    add_269 = torch.ops.aten.add.Tensor(convert_element_type_609, 1.0);  convert_element_type_609 = None
    mul_328 = torch.ops.aten.mul.Tensor(mul_327, add_269);  mul_327 = add_269 = None
    convert_element_type_610 = torch.ops.prims.convert_element_type.default(mul_328, torch.bfloat16);  mul_328 = None
    view_438 = torch.ops.aten.reshape.default(convert_element_type_610, [1, 2048])
    permute_252 = torch.ops.aten.permute.default(arg253_1, [1, 0]);  arg253_1 = None
    mm_124 = torch.ops.aten.mm.default(view_438, permute_252);  view_438 = permute_252 = None
    view_439 = torch.ops.aten.reshape.default(mm_124, [1, 1, 6144]);  mm_124 = None
    permute_253 = torch.ops.aten.permute.default(view_439, [0, 2, 1]);  view_439 = None
    cat_28 = torch.ops.aten.cat.default([arg257_1, permute_253], -1);  permute_253 = None
    slice_122 = torch.ops.aten.slice.Tensor(cat_28, 2, -4, 9223372036854775807)
    copy_40 = torch.ops.aten.copy.default(arg257_1, slice_122);  slice_122 = None
    convert_element_type_619 = torch.ops.prims.convert_element_type.default(cat_28, torch.float32);  cat_28 = None
    slice_123 = torch.ops.aten.slice.Tensor(convert_element_type_619, 2, 0, 2)
    squeeze_12 = torch.ops.aten.squeeze.dim(arg258_1, 1);  arg258_1 = None
    unsqueeze_136 = torch.ops.aten.unsqueeze.default(squeeze_12, 1);  squeeze_12 = None
    convert_element_type_620 = torch.ops.prims.convert_element_type.default(unsqueeze_136, torch.float32);  unsqueeze_136 = None
    select_205 = torch.ops.aten.select.int(convert_element_type_620, 1, 0)
    select_206 = torch.ops.aten.select.int(select_205, 1, 0);  select_205 = None
    view_447 = torch.ops.aten.reshape.default(select_206, [1, -1, 1]);  select_206 = None
    mul_329 = torch.ops.aten.mul.Tensor(slice_123, view_447);  slice_123 = view_447 = None
    slice_124 = torch.ops.aten.slice.Tensor(convert_element_type_619, 2, 1, 3)
    select_207 = torch.ops.aten.select.int(convert_element_type_620, 1, 0)
    select_208 = torch.ops.aten.select.int(select_207, 1, 1);  select_207 = None
    view_448 = torch.ops.aten.reshape.default(select_208, [1, -1, 1]);  select_208 = None
    mul_330 = torch.ops.aten.mul.Tensor(slice_124, view_448);  slice_124 = view_448 = None
    add_270 = torch.ops.aten.add.Tensor(mul_329, mul_330);  mul_329 = mul_330 = None
    slice_125 = torch.ops.aten.slice.Tensor(convert_element_type_619, 2, 2, 4)
    select_209 = torch.ops.aten.select.int(convert_element_type_620, 1, 0)
    select_210 = torch.ops.aten.select.int(select_209, 1, 2);  select_209 = None
    view_449 = torch.ops.aten.reshape.default(select_210, [1, -1, 1]);  select_210 = None
    mul_331 = torch.ops.aten.mul.Tensor(slice_125, view_449);  slice_125 = view_449 = None
    add_271 = torch.ops.aten.add.Tensor(add_270, mul_331);  add_270 = mul_331 = None
    slice_126 = torch.ops.aten.slice.Tensor(convert_element_type_619, 2, 3, 5);  convert_element_type_619 = None
    select_211 = torch.ops.aten.select.int(convert_element_type_620, 1, 0);  convert_element_type_620 = None
    select_212 = torch.ops.aten.select.int(select_211, 1, 3);  select_211 = None
    view_450 = torch.ops.aten.reshape.default(select_212, [1, -1, 1]);  select_212 = None
    mul_332 = torch.ops.aten.mul.Tensor(slice_126, view_450);  slice_126 = view_450 = None
    add_272 = torch.ops.aten.add.Tensor(add_271, mul_332);  add_271 = mul_332 = None
    convert_element_type_621 = torch.ops.prims.convert_element_type.default(add_272, torch.bfloat16);  add_272 = None
    slice_127 = torch.ops.aten.slice.Tensor(convert_element_type_621, 2, -1, 9223372036854775807);  convert_element_type_621 = None
    convert_element_type_622 = torch.ops.prims.convert_element_type.default(slice_127, torch.float32);  slice_127 = None
    neg_60 = torch.ops.aten.neg.default(convert_element_type_622)
    exp_80 = torch.ops.aten.exp.default(neg_60);  neg_60 = None
    add_273 = torch.ops.aten.add.Tensor(exp_80, 1);  exp_80 = None
    div_56 = torch.ops.aten.div.Tensor(convert_element_type_622, add_273);  convert_element_type_622 = add_273 = None
    convert_element_type_623 = torch.ops.prims.convert_element_type.default(div_56, torch.bfloat16);  div_56 = None
    permute_257 = torch.ops.aten.permute.default(convert_element_type_623, [0, 2, 1]);  convert_element_type_623 = None
    split_with_sizes_12 = torch.ops.aten.split_with_sizes.default(permute_257, [2048, 2048, 2048], -1);  permute_257 = None
    getitem_44 = split_with_sizes_12[0]
    getitem_45 = split_with_sizes_12[1]
    getitem_46 = split_with_sizes_12[2];  split_with_sizes_12 = None
    full_default_14 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_218 = torch.ops.aten.select.int(full_default_14, 2, 0);  select_218 = None
    view_452 = torch.ops.aten.reshape.default(getitem_45, [1, 1, -1, 128]);  getitem_45 = None
    permute_259 = torch.ops.aten.permute.default(view_452, [0, 2, 1, 3]);  view_452 = None
    convert_element_type_626 = torch.ops.prims.convert_element_type.default(permute_259, torch.float32);  permute_259 = None
    clone_65 = torch.ops.aten.clone.default(convert_element_type_626, memory_format = torch.contiguous_format);  convert_element_type_626 = None
    mul_336 = torch.ops.aten.mul.Tensor(clone_65, clone_65)
    sum_54 = torch.ops.aten.sum.dim_IntList(mul_336, [-1], True);  mul_336 = None
    add_276 = torch.ops.aten.add.Tensor(sum_54, 1e-06);  sum_54 = None
    rsqrt_78 = torch.ops.aten.rsqrt.default(add_276);  add_276 = None
    mul_337 = torch.ops.aten.mul.Tensor(clone_65, rsqrt_78);  clone_65 = rsqrt_78 = None
    select_214 = torch.ops.aten.select.int(mul_337, 2, 0);  mul_337 = None
    unsqueeze_141 = torch.ops.aten.unsqueeze.default(select_214, -1)
    view_453 = torch.ops.aten.reshape.default(getitem_46, [1, 1, -1, 128]);  getitem_46 = None
    permute_260 = torch.ops.aten.permute.default(view_453, [0, 2, 1, 3]);  view_453 = None
    convert_element_type_627 = torch.ops.prims.convert_element_type.default(permute_260, torch.float32);  permute_260 = None
    clone_66 = torch.ops.aten.clone.default(convert_element_type_627, memory_format = torch.contiguous_format);  convert_element_type_627 = None
    select_215 = torch.ops.aten.select.int(clone_66, 2, 0);  clone_66 = None
    exp_81 = torch.ops.aten.exp.default(arg259_1);  arg259_1 = None
    neg_61 = torch.ops.aten.neg.default(exp_81);  exp_81 = None
    view_445 = torch.ops.aten.reshape.default(convert_element_type_610, [1, 2048])
    permute_256 = torch.ops.aten.permute.default(arg256_1, [1, 0]);  arg256_1 = None
    mm_127 = torch.ops.aten.mm.default(view_445, permute_256);  view_445 = permute_256 = None
    view_446 = torch.ops.aten.reshape.default(mm_127, [1, 1, 16]);  mm_127 = None
    convert_element_type_624 = torch.ops.prims.convert_element_type.default(view_446, torch.float32);  view_446 = None
    add_274 = torch.ops.aten.add.Tensor(convert_element_type_624, arg260_1);  convert_element_type_624 = arg260_1 = None
    gt_12 = torch.ops.aten.gt.Scalar(add_274, 20)
    exp_82 = torch.ops.aten.exp.default(add_274)
    log1p_12 = torch.ops.aten.log1p.default(exp_82);  exp_82 = None
    where_13 = torch.ops.aten.where.self(gt_12, add_274, log1p_12);  gt_12 = add_274 = log1p_12 = None
    mul_333 = torch.ops.aten.mul.Tensor(neg_61, where_13);  neg_61 = where_13 = None
    permute_262 = torch.ops.aten.permute.default(mul_333, [0, 2, 1]);  mul_333 = None
    select_216 = torch.ops.aten.select.int(permute_262, 2, 0);  permute_262 = None
    exp_83 = torch.ops.aten.exp.default(select_216);  select_216 = None
    unsqueeze_137 = torch.ops.aten.unsqueeze.default(exp_83, 2);  exp_83 = None
    unsqueeze_138 = torch.ops.aten.unsqueeze.default(unsqueeze_137, 3);  unsqueeze_137 = None
    mul_338 = torch.ops.aten.mul.Tensor(arg261_1, unsqueeze_138);  unsqueeze_138 = None
    unsqueeze_140 = torch.ops.aten.unsqueeze.default(select_214, -1);  select_214 = None
    mul_339 = torch.ops.aten.mul.Tensor(mul_338, unsqueeze_140);  unsqueeze_140 = None
    sum_55 = torch.ops.aten.sum.dim_IntList(mul_339, [-2]);  mul_339 = None
    sub_16 = torch.ops.aten.sub.Tensor(select_215, sum_55);  select_215 = sum_55 = None
    view_443 = torch.ops.aten.reshape.default(convert_element_type_610, [1, 2048])
    permute_255 = torch.ops.aten.permute.default(arg255_1, [1, 0]);  arg255_1 = None
    mm_126 = torch.ops.aten.mm.default(view_443, permute_255);  view_443 = permute_255 = None
    view_444 = torch.ops.aten.reshape.default(mm_126, [1, 1, 16]);  mm_126 = None
    sigmoid_16 = torch.ops.aten.sigmoid.default(view_444);  view_444 = None
    permute_261 = torch.ops.aten.permute.default(sigmoid_16, [0, 2, 1]);  sigmoid_16 = None
    convert_element_type_628 = torch.ops.prims.convert_element_type.default(permute_261, torch.float32);  permute_261 = None
    clone_67 = torch.ops.aten.clone.default(convert_element_type_628, memory_format = torch.contiguous_format);  convert_element_type_628 = None
    select_217 = torch.ops.aten.select.int(clone_67, 2, 0);  clone_67 = None
    unsqueeze_139 = torch.ops.aten.unsqueeze.default(select_217, -1);  select_217 = None
    mul_340 = torch.ops.aten.mul.Tensor(sub_16, unsqueeze_139);  sub_16 = unsqueeze_139 = None
    unsqueeze_142 = torch.ops.aten.unsqueeze.default(mul_340, -2);  mul_340 = None
    mul_341 = torch.ops.aten.mul.Tensor(unsqueeze_141, unsqueeze_142);  unsqueeze_141 = unsqueeze_142 = None
    add_277 = torch.ops.aten.add.Tensor(mul_338, mul_341);  mul_338 = mul_341 = None
    view_451 = torch.ops.aten.reshape.default(getitem_44, [1, 1, -1, 128]);  getitem_44 = None
    permute_258 = torch.ops.aten.permute.default(view_451, [0, 2, 1, 3]);  view_451 = None
    convert_element_type_625 = torch.ops.prims.convert_element_type.default(permute_258, torch.float32);  permute_258 = None
    clone_64 = torch.ops.aten.clone.default(convert_element_type_625, memory_format = torch.contiguous_format);  convert_element_type_625 = None
    mul_334 = torch.ops.aten.mul.Tensor(clone_64, clone_64)
    sum_53 = torch.ops.aten.sum.dim_IntList(mul_334, [-1], True);  mul_334 = None
    add_275 = torch.ops.aten.add.Tensor(sum_53, 1e-06);  sum_53 = None
    rsqrt_77 = torch.ops.aten.rsqrt.default(add_275);  add_275 = None
    mul_335 = torch.ops.aten.mul.Tensor(clone_64, rsqrt_77);  clone_64 = rsqrt_77 = None
    div_57 = torch.ops.aten.div.Tensor(mul_335, 11.313708498984761);  mul_335 = None
    select_213 = torch.ops.aten.select.int(div_57, 2, 0);  div_57 = None
    unsqueeze_143 = torch.ops.aten.unsqueeze.default(select_213, -1);  select_213 = None
    mul_342 = torch.ops.aten.mul.Tensor(add_277, unsqueeze_143);  unsqueeze_143 = None
    sum_56 = torch.ops.aten.sum.dim_IntList(mul_342, [-2]);  mul_342 = None
    select_scatter_default_16 = torch.ops.aten.select_scatter.default(full_default_14, sum_56, 2, 0);  full_default_14 = sum_56 = None
    permute_264 = torch.ops.aten.permute.default(select_scatter_default_16, [0, 2, 1, 3]);  select_scatter_default_16 = None
    convert_element_type_629 = torch.ops.prims.convert_element_type.default(permute_264, torch.bfloat16);  permute_264 = None
    view_454 = torch.ops.aten.reshape.default(convert_element_type_629, [-1, 128]);  convert_element_type_629 = None
    convert_element_type_630 = torch.ops.prims.convert_element_type.default(view_454, torch.float32);  view_454 = None
    pow_54 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_630, 2)
    mean_53 = torch.ops.aten.mean.dim(pow_54, [-1], True);  pow_54 = None
    add_278 = torch.ops.aten.add.Tensor(mean_53, 1e-06);  mean_53 = None
    rsqrt_79 = torch.ops.aten.rsqrt.default(add_278);  add_278 = None
    mul_343 = torch.ops.aten.mul.Tensor(convert_element_type_630, rsqrt_79);  convert_element_type_630 = rsqrt_79 = None
    convert_element_type_631 = torch.ops.prims.convert_element_type.default(mul_343, torch.bfloat16);  mul_343 = None
    mul_344 = torch.ops.aten.mul.Tensor(arg262_1, convert_element_type_631);  arg262_1 = convert_element_type_631 = None
    view_440 = torch.ops.aten.reshape.default(convert_element_type_610, [1, 2048]);  convert_element_type_610 = None
    permute_254 = torch.ops.aten.permute.default(arg254_1, [1, 0]);  arg254_1 = None
    mm_125 = torch.ops.aten.mm.default(view_440, permute_254);  view_440 = permute_254 = None
    view_441 = torch.ops.aten.reshape.default(mm_125, [1, 1, 2048]);  mm_125 = None
    view_442 = torch.ops.aten.reshape.default(view_441, [1, 1, -1, 128]);  view_441 = None
    view_455 = torch.ops.aten.reshape.default(view_442, [-1, 128]);  view_442 = None
    convert_element_type_632 = torch.ops.prims.convert_element_type.default(view_455, torch.float32);  view_455 = None
    neg_62 = torch.ops.aten.neg.default(convert_element_type_632)
    exp_84 = torch.ops.aten.exp.default(neg_62);  neg_62 = None
    add_279 = torch.ops.aten.add.Tensor(exp_84, 1);  exp_84 = None
    div_58 = torch.ops.aten.div.Tensor(convert_element_type_632, add_279);  convert_element_type_632 = add_279 = None
    mul_345 = torch.ops.aten.mul.Tensor(mul_344, div_58);  mul_344 = div_58 = None
    convert_element_type_633 = torch.ops.prims.convert_element_type.default(mul_345, torch.bfloat16);  mul_345 = None
    view_456 = torch.ops.aten.reshape.default(convert_element_type_633, [1, 1, -1]);  convert_element_type_633 = None
    view_457 = torch.ops.aten.reshape.default(view_456, [1, 2048]);  view_456 = None
    permute_265 = torch.ops.aten.permute.default(arg263_1, [1, 0]);  arg263_1 = None
    mm_128 = torch.ops.aten.mm.default(view_457, permute_265);  view_457 = permute_265 = None
    view_458 = torch.ops.aten.reshape.default(mm_128, [1, 1, 2048]);  mm_128 = None
    add_280 = torch.ops.aten.add.Tensor(add_267, view_458);  add_267 = view_458 = None
    convert_element_type_636 = torch.ops.prims.convert_element_type.default(add_280, torch.float32)
    pow_55 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_636, 2)
    mean_54 = torch.ops.aten.mean.dim(pow_55, [-1], True);  pow_55 = None
    add_281 = torch.ops.aten.add.Tensor(mean_54, 1e-06);  mean_54 = None
    rsqrt_80 = torch.ops.aten.rsqrt.default(add_281);  add_281 = None
    mul_346 = torch.ops.aten.mul.Tensor(convert_element_type_636, rsqrt_80);  convert_element_type_636 = rsqrt_80 = None
    convert_element_type_637 = torch.ops.prims.convert_element_type.default(arg264_1, torch.float32);  arg264_1 = None
    add_282 = torch.ops.aten.add.Tensor(convert_element_type_637, 1.0);  convert_element_type_637 = None
    mul_347 = torch.ops.aten.mul.Tensor(mul_346, add_282);  mul_346 = add_282 = None
    convert_element_type_638 = torch.ops.prims.convert_element_type.default(mul_347, torch.bfloat16);  mul_347 = None
    view_459 = torch.ops.aten.reshape.default(convert_element_type_638, [1, 2048])
    permute_266 = torch.ops.aten.permute.default(arg265_1, [1, 0]);  arg265_1 = None
    mm_129 = torch.ops.aten.mm.default(view_459, permute_266);  view_459 = permute_266 = None
    view_460 = torch.ops.aten.reshape.default(mm_129, [1, 1, 6144]);  mm_129 = None
    convert_element_type_641 = torch.ops.prims.convert_element_type.default(view_460, torch.float32);  view_460 = None
    neg_63 = torch.ops.aten.neg.default(convert_element_type_641)
    exp_85 = torch.ops.aten.exp.default(neg_63);  neg_63 = None
    add_283 = torch.ops.aten.add.Tensor(exp_85, 1);  exp_85 = None
    div_59 = torch.ops.aten.div.Tensor(convert_element_type_641, add_283);  convert_element_type_641 = add_283 = None
    convert_element_type_642 = torch.ops.prims.convert_element_type.default(div_59, torch.bfloat16);  div_59 = None
    view_461 = torch.ops.aten.reshape.default(convert_element_type_638, [1, 2048]);  convert_element_type_638 = None
    permute_267 = torch.ops.aten.permute.default(arg266_1, [1, 0]);  arg266_1 = None
    mm_130 = torch.ops.aten.mm.default(view_461, permute_267);  view_461 = permute_267 = None
    view_462 = torch.ops.aten.reshape.default(mm_130, [1, 1, 6144]);  mm_130 = None
    mul_348 = torch.ops.aten.mul.Tensor(convert_element_type_642, view_462);  convert_element_type_642 = view_462 = None
    view_463 = torch.ops.aten.reshape.default(mul_348, [1, 6144]);  mul_348 = None
    permute_268 = torch.ops.aten.permute.default(arg267_1, [1, 0]);  arg267_1 = None
    mm_131 = torch.ops.aten.mm.default(view_463, permute_268);  view_463 = permute_268 = None
    view_464 = torch.ops.aten.reshape.default(mm_131, [1, 1, 2048]);  mm_131 = None
    add_284 = torch.ops.aten.add.Tensor(add_280, view_464);  add_280 = view_464 = None
    convert_element_type_647 = torch.ops.prims.convert_element_type.default(add_284, torch.float32)
    pow_56 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_647, 2)
    mean_55 = torch.ops.aten.mean.dim(pow_56, [-1], True);  pow_56 = None
    add_285 = torch.ops.aten.add.Tensor(mean_55, 1e-06);  mean_55 = None
    rsqrt_81 = torch.ops.aten.rsqrt.default(add_285);  add_285 = None
    mul_349 = torch.ops.aten.mul.Tensor(convert_element_type_647, rsqrt_81);  convert_element_type_647 = rsqrt_81 = None
    convert_element_type_648 = torch.ops.prims.convert_element_type.default(arg268_1, torch.float32);  arg268_1 = None
    add_286 = torch.ops.aten.add.Tensor(convert_element_type_648, 1.0);  convert_element_type_648 = None
    mul_350 = torch.ops.aten.mul.Tensor(mul_349, add_286);  mul_349 = add_286 = None
    convert_element_type_649 = torch.ops.prims.convert_element_type.default(mul_350, torch.bfloat16);  mul_350 = None
    view_465 = torch.ops.aten.reshape.default(convert_element_type_649, [1, 2048])
    permute_269 = torch.ops.aten.permute.default(arg269_1, [1, 0]);  arg269_1 = None
    mm_132 = torch.ops.aten.mm.default(view_465, permute_269);  view_465 = permute_269 = None
    view_466 = torch.ops.aten.reshape.default(mm_132, [1, 1, 6144]);  mm_132 = None
    permute_270 = torch.ops.aten.permute.default(view_466, [0, 2, 1]);  view_466 = None
    cat_29 = torch.ops.aten.cat.default([arg273_1, permute_270], -1);  permute_270 = None
    slice_128 = torch.ops.aten.slice.Tensor(cat_29, 2, -4, 9223372036854775807)
    copy_43 = torch.ops.aten.copy.default(arg273_1, slice_128);  slice_128 = None
    convert_element_type_658 = torch.ops.prims.convert_element_type.default(cat_29, torch.float32);  cat_29 = None
    slice_129 = torch.ops.aten.slice.Tensor(convert_element_type_658, 2, 0, 2)
    squeeze_13 = torch.ops.aten.squeeze.dim(arg274_1, 1);  arg274_1 = None
    unsqueeze_144 = torch.ops.aten.unsqueeze.default(squeeze_13, 1);  squeeze_13 = None
    convert_element_type_659 = torch.ops.prims.convert_element_type.default(unsqueeze_144, torch.float32);  unsqueeze_144 = None
    select_220 = torch.ops.aten.select.int(convert_element_type_659, 1, 0)
    select_221 = torch.ops.aten.select.int(select_220, 1, 0);  select_220 = None
    view_474 = torch.ops.aten.reshape.default(select_221, [1, -1, 1]);  select_221 = None
    mul_351 = torch.ops.aten.mul.Tensor(slice_129, view_474);  slice_129 = view_474 = None
    slice_130 = torch.ops.aten.slice.Tensor(convert_element_type_658, 2, 1, 3)
    select_222 = torch.ops.aten.select.int(convert_element_type_659, 1, 0)
    select_223 = torch.ops.aten.select.int(select_222, 1, 1);  select_222 = None
    view_475 = torch.ops.aten.reshape.default(select_223, [1, -1, 1]);  select_223 = None
    mul_352 = torch.ops.aten.mul.Tensor(slice_130, view_475);  slice_130 = view_475 = None
    add_287 = torch.ops.aten.add.Tensor(mul_351, mul_352);  mul_351 = mul_352 = None
    slice_131 = torch.ops.aten.slice.Tensor(convert_element_type_658, 2, 2, 4)
    select_224 = torch.ops.aten.select.int(convert_element_type_659, 1, 0)
    select_225 = torch.ops.aten.select.int(select_224, 1, 2);  select_224 = None
    view_476 = torch.ops.aten.reshape.default(select_225, [1, -1, 1]);  select_225 = None
    mul_353 = torch.ops.aten.mul.Tensor(slice_131, view_476);  slice_131 = view_476 = None
    add_288 = torch.ops.aten.add.Tensor(add_287, mul_353);  add_287 = mul_353 = None
    slice_132 = torch.ops.aten.slice.Tensor(convert_element_type_658, 2, 3, 5);  convert_element_type_658 = None
    select_226 = torch.ops.aten.select.int(convert_element_type_659, 1, 0);  convert_element_type_659 = None
    select_227 = torch.ops.aten.select.int(select_226, 1, 3);  select_226 = None
    view_477 = torch.ops.aten.reshape.default(select_227, [1, -1, 1]);  select_227 = None
    mul_354 = torch.ops.aten.mul.Tensor(slice_132, view_477);  slice_132 = view_477 = None
    add_289 = torch.ops.aten.add.Tensor(add_288, mul_354);  add_288 = mul_354 = None
    convert_element_type_660 = torch.ops.prims.convert_element_type.default(add_289, torch.bfloat16);  add_289 = None
    slice_133 = torch.ops.aten.slice.Tensor(convert_element_type_660, 2, -1, 9223372036854775807);  convert_element_type_660 = None
    convert_element_type_661 = torch.ops.prims.convert_element_type.default(slice_133, torch.float32);  slice_133 = None
    neg_64 = torch.ops.aten.neg.default(convert_element_type_661)
    exp_86 = torch.ops.aten.exp.default(neg_64);  neg_64 = None
    add_290 = torch.ops.aten.add.Tensor(exp_86, 1);  exp_86 = None
    div_60 = torch.ops.aten.div.Tensor(convert_element_type_661, add_290);  convert_element_type_661 = add_290 = None
    convert_element_type_662 = torch.ops.prims.convert_element_type.default(div_60, torch.bfloat16);  div_60 = None
    permute_274 = torch.ops.aten.permute.default(convert_element_type_662, [0, 2, 1]);  convert_element_type_662 = None
    split_with_sizes_13 = torch.ops.aten.split_with_sizes.default(permute_274, [2048, 2048, 2048], -1);  permute_274 = None
    getitem_47 = split_with_sizes_13[0]
    getitem_48 = split_with_sizes_13[1]
    getitem_49 = split_with_sizes_13[2];  split_with_sizes_13 = None
    full_default_15 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_233 = torch.ops.aten.select.int(full_default_15, 2, 0);  select_233 = None
    view_479 = torch.ops.aten.reshape.default(getitem_48, [1, 1, -1, 128]);  getitem_48 = None
    permute_276 = torch.ops.aten.permute.default(view_479, [0, 2, 1, 3]);  view_479 = None
    convert_element_type_665 = torch.ops.prims.convert_element_type.default(permute_276, torch.float32);  permute_276 = None
    clone_69 = torch.ops.aten.clone.default(convert_element_type_665, memory_format = torch.contiguous_format);  convert_element_type_665 = None
    mul_358 = torch.ops.aten.mul.Tensor(clone_69, clone_69)
    sum_58 = torch.ops.aten.sum.dim_IntList(mul_358, [-1], True);  mul_358 = None
    add_293 = torch.ops.aten.add.Tensor(sum_58, 1e-06);  sum_58 = None
    rsqrt_83 = torch.ops.aten.rsqrt.default(add_293);  add_293 = None
    mul_359 = torch.ops.aten.mul.Tensor(clone_69, rsqrt_83);  clone_69 = rsqrt_83 = None
    select_229 = torch.ops.aten.select.int(mul_359, 2, 0);  mul_359 = None
    unsqueeze_149 = torch.ops.aten.unsqueeze.default(select_229, -1)
    view_480 = torch.ops.aten.reshape.default(getitem_49, [1, 1, -1, 128]);  getitem_49 = None
    permute_277 = torch.ops.aten.permute.default(view_480, [0, 2, 1, 3]);  view_480 = None
    convert_element_type_666 = torch.ops.prims.convert_element_type.default(permute_277, torch.float32);  permute_277 = None
    clone_70 = torch.ops.aten.clone.default(convert_element_type_666, memory_format = torch.contiguous_format);  convert_element_type_666 = None
    select_230 = torch.ops.aten.select.int(clone_70, 2, 0);  clone_70 = None
    exp_87 = torch.ops.aten.exp.default(arg275_1);  arg275_1 = None
    neg_65 = torch.ops.aten.neg.default(exp_87);  exp_87 = None
    view_472 = torch.ops.aten.reshape.default(convert_element_type_649, [1, 2048])
    permute_273 = torch.ops.aten.permute.default(arg272_1, [1, 0]);  arg272_1 = None
    mm_135 = torch.ops.aten.mm.default(view_472, permute_273);  view_472 = permute_273 = None
    view_473 = torch.ops.aten.reshape.default(mm_135, [1, 1, 16]);  mm_135 = None
    convert_element_type_663 = torch.ops.prims.convert_element_type.default(view_473, torch.float32);  view_473 = None
    add_291 = torch.ops.aten.add.Tensor(convert_element_type_663, arg276_1);  convert_element_type_663 = arg276_1 = None
    gt_13 = torch.ops.aten.gt.Scalar(add_291, 20)
    exp_88 = torch.ops.aten.exp.default(add_291)
    log1p_13 = torch.ops.aten.log1p.default(exp_88);  exp_88 = None
    where_14 = torch.ops.aten.where.self(gt_13, add_291, log1p_13);  gt_13 = add_291 = log1p_13 = None
    mul_355 = torch.ops.aten.mul.Tensor(neg_65, where_14);  neg_65 = where_14 = None
    permute_279 = torch.ops.aten.permute.default(mul_355, [0, 2, 1]);  mul_355 = None
    select_231 = torch.ops.aten.select.int(permute_279, 2, 0);  permute_279 = None
    exp_89 = torch.ops.aten.exp.default(select_231);  select_231 = None
    unsqueeze_145 = torch.ops.aten.unsqueeze.default(exp_89, 2);  exp_89 = None
    unsqueeze_146 = torch.ops.aten.unsqueeze.default(unsqueeze_145, 3);  unsqueeze_145 = None
    mul_360 = torch.ops.aten.mul.Tensor(arg277_1, unsqueeze_146);  unsqueeze_146 = None
    unsqueeze_148 = torch.ops.aten.unsqueeze.default(select_229, -1);  select_229 = None
    mul_361 = torch.ops.aten.mul.Tensor(mul_360, unsqueeze_148);  unsqueeze_148 = None
    sum_59 = torch.ops.aten.sum.dim_IntList(mul_361, [-2]);  mul_361 = None
    sub_17 = torch.ops.aten.sub.Tensor(select_230, sum_59);  select_230 = sum_59 = None
    view_470 = torch.ops.aten.reshape.default(convert_element_type_649, [1, 2048])
    permute_272 = torch.ops.aten.permute.default(arg271_1, [1, 0]);  arg271_1 = None
    mm_134 = torch.ops.aten.mm.default(view_470, permute_272);  view_470 = permute_272 = None
    view_471 = torch.ops.aten.reshape.default(mm_134, [1, 1, 16]);  mm_134 = None
    sigmoid_17 = torch.ops.aten.sigmoid.default(view_471);  view_471 = None
    permute_278 = torch.ops.aten.permute.default(sigmoid_17, [0, 2, 1]);  sigmoid_17 = None
    convert_element_type_667 = torch.ops.prims.convert_element_type.default(permute_278, torch.float32);  permute_278 = None
    clone_71 = torch.ops.aten.clone.default(convert_element_type_667, memory_format = torch.contiguous_format);  convert_element_type_667 = None
    select_232 = torch.ops.aten.select.int(clone_71, 2, 0);  clone_71 = None
    unsqueeze_147 = torch.ops.aten.unsqueeze.default(select_232, -1);  select_232 = None
    mul_362 = torch.ops.aten.mul.Tensor(sub_17, unsqueeze_147);  sub_17 = unsqueeze_147 = None
    unsqueeze_150 = torch.ops.aten.unsqueeze.default(mul_362, -2);  mul_362 = None
    mul_363 = torch.ops.aten.mul.Tensor(unsqueeze_149, unsqueeze_150);  unsqueeze_149 = unsqueeze_150 = None
    add_294 = torch.ops.aten.add.Tensor(mul_360, mul_363);  mul_360 = mul_363 = None
    view_478 = torch.ops.aten.reshape.default(getitem_47, [1, 1, -1, 128]);  getitem_47 = None
    permute_275 = torch.ops.aten.permute.default(view_478, [0, 2, 1, 3]);  view_478 = None
    convert_element_type_664 = torch.ops.prims.convert_element_type.default(permute_275, torch.float32);  permute_275 = None
    clone_68 = torch.ops.aten.clone.default(convert_element_type_664, memory_format = torch.contiguous_format);  convert_element_type_664 = None
    mul_356 = torch.ops.aten.mul.Tensor(clone_68, clone_68)
    sum_57 = torch.ops.aten.sum.dim_IntList(mul_356, [-1], True);  mul_356 = None
    add_292 = torch.ops.aten.add.Tensor(sum_57, 1e-06);  sum_57 = None
    rsqrt_82 = torch.ops.aten.rsqrt.default(add_292);  add_292 = None
    mul_357 = torch.ops.aten.mul.Tensor(clone_68, rsqrt_82);  clone_68 = rsqrt_82 = None
    div_61 = torch.ops.aten.div.Tensor(mul_357, 11.313708498984761);  mul_357 = None
    select_228 = torch.ops.aten.select.int(div_61, 2, 0);  div_61 = None
    unsqueeze_151 = torch.ops.aten.unsqueeze.default(select_228, -1);  select_228 = None
    mul_364 = torch.ops.aten.mul.Tensor(add_294, unsqueeze_151);  unsqueeze_151 = None
    sum_60 = torch.ops.aten.sum.dim_IntList(mul_364, [-2]);  mul_364 = None
    select_scatter_default_17 = torch.ops.aten.select_scatter.default(full_default_15, sum_60, 2, 0);  full_default_15 = sum_60 = None
    permute_281 = torch.ops.aten.permute.default(select_scatter_default_17, [0, 2, 1, 3]);  select_scatter_default_17 = None
    convert_element_type_668 = torch.ops.prims.convert_element_type.default(permute_281, torch.bfloat16);  permute_281 = None
    view_481 = torch.ops.aten.reshape.default(convert_element_type_668, [-1, 128]);  convert_element_type_668 = None
    convert_element_type_669 = torch.ops.prims.convert_element_type.default(view_481, torch.float32);  view_481 = None
    pow_57 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_669, 2)
    mean_56 = torch.ops.aten.mean.dim(pow_57, [-1], True);  pow_57 = None
    add_295 = torch.ops.aten.add.Tensor(mean_56, 1e-06);  mean_56 = None
    rsqrt_84 = torch.ops.aten.rsqrt.default(add_295);  add_295 = None
    mul_365 = torch.ops.aten.mul.Tensor(convert_element_type_669, rsqrt_84);  convert_element_type_669 = rsqrt_84 = None
    convert_element_type_670 = torch.ops.prims.convert_element_type.default(mul_365, torch.bfloat16);  mul_365 = None
    mul_366 = torch.ops.aten.mul.Tensor(arg278_1, convert_element_type_670);  arg278_1 = convert_element_type_670 = None
    view_467 = torch.ops.aten.reshape.default(convert_element_type_649, [1, 2048]);  convert_element_type_649 = None
    permute_271 = torch.ops.aten.permute.default(arg270_1, [1, 0]);  arg270_1 = None
    mm_133 = torch.ops.aten.mm.default(view_467, permute_271);  view_467 = permute_271 = None
    view_468 = torch.ops.aten.reshape.default(mm_133, [1, 1, 2048]);  mm_133 = None
    view_469 = torch.ops.aten.reshape.default(view_468, [1, 1, -1, 128]);  view_468 = None
    view_482 = torch.ops.aten.reshape.default(view_469, [-1, 128]);  view_469 = None
    convert_element_type_671 = torch.ops.prims.convert_element_type.default(view_482, torch.float32);  view_482 = None
    neg_66 = torch.ops.aten.neg.default(convert_element_type_671)
    exp_90 = torch.ops.aten.exp.default(neg_66);  neg_66 = None
    add_296 = torch.ops.aten.add.Tensor(exp_90, 1);  exp_90 = None
    div_62 = torch.ops.aten.div.Tensor(convert_element_type_671, add_296);  convert_element_type_671 = add_296 = None
    mul_367 = torch.ops.aten.mul.Tensor(mul_366, div_62);  mul_366 = div_62 = None
    convert_element_type_672 = torch.ops.prims.convert_element_type.default(mul_367, torch.bfloat16);  mul_367 = None
    view_483 = torch.ops.aten.reshape.default(convert_element_type_672, [1, 1, -1]);  convert_element_type_672 = None
    view_484 = torch.ops.aten.reshape.default(view_483, [1, 2048]);  view_483 = None
    permute_282 = torch.ops.aten.permute.default(arg279_1, [1, 0]);  arg279_1 = None
    mm_136 = torch.ops.aten.mm.default(view_484, permute_282);  view_484 = permute_282 = None
    view_485 = torch.ops.aten.reshape.default(mm_136, [1, 1, 2048]);  mm_136 = None
    add_297 = torch.ops.aten.add.Tensor(add_284, view_485);  add_284 = view_485 = None
    convert_element_type_675 = torch.ops.prims.convert_element_type.default(add_297, torch.float32)
    pow_58 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_675, 2)
    mean_57 = torch.ops.aten.mean.dim(pow_58, [-1], True);  pow_58 = None
    add_298 = torch.ops.aten.add.Tensor(mean_57, 1e-06);  mean_57 = None
    rsqrt_85 = torch.ops.aten.rsqrt.default(add_298);  add_298 = None
    mul_368 = torch.ops.aten.mul.Tensor(convert_element_type_675, rsqrt_85);  convert_element_type_675 = rsqrt_85 = None
    convert_element_type_676 = torch.ops.prims.convert_element_type.default(arg280_1, torch.float32);  arg280_1 = None
    add_299 = torch.ops.aten.add.Tensor(convert_element_type_676, 1.0);  convert_element_type_676 = None
    mul_369 = torch.ops.aten.mul.Tensor(mul_368, add_299);  mul_368 = add_299 = None
    convert_element_type_677 = torch.ops.prims.convert_element_type.default(mul_369, torch.bfloat16);  mul_369 = None
    view_486 = torch.ops.aten.reshape.default(convert_element_type_677, [1, 2048])
    permute_283 = torch.ops.aten.permute.default(arg281_1, [1, 0]);  arg281_1 = None
    mm_137 = torch.ops.aten.mm.default(view_486, permute_283);  view_486 = permute_283 = None
    view_487 = torch.ops.aten.reshape.default(mm_137, [1, 1, 6144]);  mm_137 = None
    convert_element_type_680 = torch.ops.prims.convert_element_type.default(view_487, torch.float32);  view_487 = None
    neg_67 = torch.ops.aten.neg.default(convert_element_type_680)
    exp_91 = torch.ops.aten.exp.default(neg_67);  neg_67 = None
    add_300 = torch.ops.aten.add.Tensor(exp_91, 1);  exp_91 = None
    div_63 = torch.ops.aten.div.Tensor(convert_element_type_680, add_300);  convert_element_type_680 = add_300 = None
    convert_element_type_681 = torch.ops.prims.convert_element_type.default(div_63, torch.bfloat16);  div_63 = None
    view_488 = torch.ops.aten.reshape.default(convert_element_type_677, [1, 2048]);  convert_element_type_677 = None
    permute_284 = torch.ops.aten.permute.default(arg282_1, [1, 0]);  arg282_1 = None
    mm_138 = torch.ops.aten.mm.default(view_488, permute_284);  view_488 = permute_284 = None
    view_489 = torch.ops.aten.reshape.default(mm_138, [1, 1, 6144]);  mm_138 = None
    mul_370 = torch.ops.aten.mul.Tensor(convert_element_type_681, view_489);  convert_element_type_681 = view_489 = None
    view_490 = torch.ops.aten.reshape.default(mul_370, [1, 6144]);  mul_370 = None
    permute_285 = torch.ops.aten.permute.default(arg283_1, [1, 0]);  arg283_1 = None
    mm_139 = torch.ops.aten.mm.default(view_490, permute_285);  view_490 = permute_285 = None
    view_491 = torch.ops.aten.reshape.default(mm_139, [1, 1, 2048]);  mm_139 = None
    add_301 = torch.ops.aten.add.Tensor(add_297, view_491);  add_297 = view_491 = None
    convert_element_type_686 = torch.ops.prims.convert_element_type.default(add_301, torch.float32)
    pow_59 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_686, 2)
    mean_58 = torch.ops.aten.mean.dim(pow_59, [-1], True);  pow_59 = None
    add_302 = torch.ops.aten.add.Tensor(mean_58, 1e-06);  mean_58 = None
    rsqrt_86 = torch.ops.aten.rsqrt.default(add_302);  add_302 = None
    mul_371 = torch.ops.aten.mul.Tensor(convert_element_type_686, rsqrt_86);  convert_element_type_686 = rsqrt_86 = None
    convert_element_type_687 = torch.ops.prims.convert_element_type.default(arg284_1, torch.float32);  arg284_1 = None
    add_303 = torch.ops.aten.add.Tensor(convert_element_type_687, 1.0);  convert_element_type_687 = None
    mul_372 = torch.ops.aten.mul.Tensor(mul_371, add_303);  mul_371 = add_303 = None
    convert_element_type_688 = torch.ops.prims.convert_element_type.default(mul_372, torch.bfloat16);  mul_372 = None
    view_492 = torch.ops.aten.reshape.default(convert_element_type_688, [1, 2048])
    permute_286 = torch.ops.aten.permute.default(arg285_1, [1, 0]);  arg285_1 = None
    mm_140 = torch.ops.aten.mm.default(view_492, permute_286);  view_492 = permute_286 = None
    view_493 = torch.ops.aten.reshape.default(mm_140, [1, 1, 6144]);  mm_140 = None
    permute_287 = torch.ops.aten.permute.default(view_493, [0, 2, 1]);  view_493 = None
    cat_30 = torch.ops.aten.cat.default([arg289_1, permute_287], -1);  permute_287 = None
    slice_134 = torch.ops.aten.slice.Tensor(cat_30, 2, -4, 9223372036854775807)
    copy_46 = torch.ops.aten.copy.default(arg289_1, slice_134);  slice_134 = None
    convert_element_type_697 = torch.ops.prims.convert_element_type.default(cat_30, torch.float32);  cat_30 = None
    slice_135 = torch.ops.aten.slice.Tensor(convert_element_type_697, 2, 0, 2)
    squeeze_14 = torch.ops.aten.squeeze.dim(arg290_1, 1);  arg290_1 = None
    unsqueeze_152 = torch.ops.aten.unsqueeze.default(squeeze_14, 1);  squeeze_14 = None
    convert_element_type_698 = torch.ops.prims.convert_element_type.default(unsqueeze_152, torch.float32);  unsqueeze_152 = None
    select_235 = torch.ops.aten.select.int(convert_element_type_698, 1, 0)
    select_236 = torch.ops.aten.select.int(select_235, 1, 0);  select_235 = None
    view_501 = torch.ops.aten.reshape.default(select_236, [1, -1, 1]);  select_236 = None
    mul_373 = torch.ops.aten.mul.Tensor(slice_135, view_501);  slice_135 = view_501 = None
    slice_136 = torch.ops.aten.slice.Tensor(convert_element_type_697, 2, 1, 3)
    select_237 = torch.ops.aten.select.int(convert_element_type_698, 1, 0)
    select_238 = torch.ops.aten.select.int(select_237, 1, 1);  select_237 = None
    view_502 = torch.ops.aten.reshape.default(select_238, [1, -1, 1]);  select_238 = None
    mul_374 = torch.ops.aten.mul.Tensor(slice_136, view_502);  slice_136 = view_502 = None
    add_304 = torch.ops.aten.add.Tensor(mul_373, mul_374);  mul_373 = mul_374 = None
    slice_137 = torch.ops.aten.slice.Tensor(convert_element_type_697, 2, 2, 4)
    select_239 = torch.ops.aten.select.int(convert_element_type_698, 1, 0)
    select_240 = torch.ops.aten.select.int(select_239, 1, 2);  select_239 = None
    view_503 = torch.ops.aten.reshape.default(select_240, [1, -1, 1]);  select_240 = None
    mul_375 = torch.ops.aten.mul.Tensor(slice_137, view_503);  slice_137 = view_503 = None
    add_305 = torch.ops.aten.add.Tensor(add_304, mul_375);  add_304 = mul_375 = None
    slice_138 = torch.ops.aten.slice.Tensor(convert_element_type_697, 2, 3, 5);  convert_element_type_697 = None
    select_241 = torch.ops.aten.select.int(convert_element_type_698, 1, 0);  convert_element_type_698 = None
    select_242 = torch.ops.aten.select.int(select_241, 1, 3);  select_241 = None
    view_504 = torch.ops.aten.reshape.default(select_242, [1, -1, 1]);  select_242 = None
    mul_376 = torch.ops.aten.mul.Tensor(slice_138, view_504);  slice_138 = view_504 = None
    add_306 = torch.ops.aten.add.Tensor(add_305, mul_376);  add_305 = mul_376 = None
    convert_element_type_699 = torch.ops.prims.convert_element_type.default(add_306, torch.bfloat16);  add_306 = None
    slice_139 = torch.ops.aten.slice.Tensor(convert_element_type_699, 2, -1, 9223372036854775807);  convert_element_type_699 = None
    convert_element_type_700 = torch.ops.prims.convert_element_type.default(slice_139, torch.float32);  slice_139 = None
    neg_68 = torch.ops.aten.neg.default(convert_element_type_700)
    exp_92 = torch.ops.aten.exp.default(neg_68);  neg_68 = None
    add_307 = torch.ops.aten.add.Tensor(exp_92, 1);  exp_92 = None
    div_64 = torch.ops.aten.div.Tensor(convert_element_type_700, add_307);  convert_element_type_700 = add_307 = None
    convert_element_type_701 = torch.ops.prims.convert_element_type.default(div_64, torch.bfloat16);  div_64 = None
    permute_291 = torch.ops.aten.permute.default(convert_element_type_701, [0, 2, 1]);  convert_element_type_701 = None
    split_with_sizes_14 = torch.ops.aten.split_with_sizes.default(permute_291, [2048, 2048, 2048], -1);  permute_291 = None
    getitem_50 = split_with_sizes_14[0]
    getitem_51 = split_with_sizes_14[1]
    getitem_52 = split_with_sizes_14[2];  split_with_sizes_14 = None
    full_default_16 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_248 = torch.ops.aten.select.int(full_default_16, 2, 0);  select_248 = None
    view_506 = torch.ops.aten.reshape.default(getitem_51, [1, 1, -1, 128]);  getitem_51 = None
    permute_293 = torch.ops.aten.permute.default(view_506, [0, 2, 1, 3]);  view_506 = None
    convert_element_type_704 = torch.ops.prims.convert_element_type.default(permute_293, torch.float32);  permute_293 = None
    clone_73 = torch.ops.aten.clone.default(convert_element_type_704, memory_format = torch.contiguous_format);  convert_element_type_704 = None
    mul_380 = torch.ops.aten.mul.Tensor(clone_73, clone_73)
    sum_62 = torch.ops.aten.sum.dim_IntList(mul_380, [-1], True);  mul_380 = None
    add_310 = torch.ops.aten.add.Tensor(sum_62, 1e-06);  sum_62 = None
    rsqrt_88 = torch.ops.aten.rsqrt.default(add_310);  add_310 = None
    mul_381 = torch.ops.aten.mul.Tensor(clone_73, rsqrt_88);  clone_73 = rsqrt_88 = None
    select_244 = torch.ops.aten.select.int(mul_381, 2, 0);  mul_381 = None
    unsqueeze_157 = torch.ops.aten.unsqueeze.default(select_244, -1)
    view_507 = torch.ops.aten.reshape.default(getitem_52, [1, 1, -1, 128]);  getitem_52 = None
    permute_294 = torch.ops.aten.permute.default(view_507, [0, 2, 1, 3]);  view_507 = None
    convert_element_type_705 = torch.ops.prims.convert_element_type.default(permute_294, torch.float32);  permute_294 = None
    clone_74 = torch.ops.aten.clone.default(convert_element_type_705, memory_format = torch.contiguous_format);  convert_element_type_705 = None
    select_245 = torch.ops.aten.select.int(clone_74, 2, 0);  clone_74 = None
    exp_93 = torch.ops.aten.exp.default(arg291_1);  arg291_1 = None
    neg_69 = torch.ops.aten.neg.default(exp_93);  exp_93 = None
    view_499 = torch.ops.aten.reshape.default(convert_element_type_688, [1, 2048])
    permute_290 = torch.ops.aten.permute.default(arg288_1, [1, 0]);  arg288_1 = None
    mm_143 = torch.ops.aten.mm.default(view_499, permute_290);  view_499 = permute_290 = None
    view_500 = torch.ops.aten.reshape.default(mm_143, [1, 1, 16]);  mm_143 = None
    convert_element_type_702 = torch.ops.prims.convert_element_type.default(view_500, torch.float32);  view_500 = None
    add_308 = torch.ops.aten.add.Tensor(convert_element_type_702, arg292_1);  convert_element_type_702 = arg292_1 = None
    gt_14 = torch.ops.aten.gt.Scalar(add_308, 20)
    exp_94 = torch.ops.aten.exp.default(add_308)
    log1p_14 = torch.ops.aten.log1p.default(exp_94);  exp_94 = None
    where_15 = torch.ops.aten.where.self(gt_14, add_308, log1p_14);  gt_14 = add_308 = log1p_14 = None
    mul_377 = torch.ops.aten.mul.Tensor(neg_69, where_15);  neg_69 = where_15 = None
    permute_296 = torch.ops.aten.permute.default(mul_377, [0, 2, 1]);  mul_377 = None
    select_246 = torch.ops.aten.select.int(permute_296, 2, 0);  permute_296 = None
    exp_95 = torch.ops.aten.exp.default(select_246);  select_246 = None
    unsqueeze_153 = torch.ops.aten.unsqueeze.default(exp_95, 2);  exp_95 = None
    unsqueeze_154 = torch.ops.aten.unsqueeze.default(unsqueeze_153, 3);  unsqueeze_153 = None
    mul_382 = torch.ops.aten.mul.Tensor(arg293_1, unsqueeze_154);  unsqueeze_154 = None
    unsqueeze_156 = torch.ops.aten.unsqueeze.default(select_244, -1);  select_244 = None
    mul_383 = torch.ops.aten.mul.Tensor(mul_382, unsqueeze_156);  unsqueeze_156 = None
    sum_63 = torch.ops.aten.sum.dim_IntList(mul_383, [-2]);  mul_383 = None
    sub_18 = torch.ops.aten.sub.Tensor(select_245, sum_63);  select_245 = sum_63 = None
    view_497 = torch.ops.aten.reshape.default(convert_element_type_688, [1, 2048])
    permute_289 = torch.ops.aten.permute.default(arg287_1, [1, 0]);  arg287_1 = None
    mm_142 = torch.ops.aten.mm.default(view_497, permute_289);  view_497 = permute_289 = None
    view_498 = torch.ops.aten.reshape.default(mm_142, [1, 1, 16]);  mm_142 = None
    sigmoid_18 = torch.ops.aten.sigmoid.default(view_498);  view_498 = None
    permute_295 = torch.ops.aten.permute.default(sigmoid_18, [0, 2, 1]);  sigmoid_18 = None
    convert_element_type_706 = torch.ops.prims.convert_element_type.default(permute_295, torch.float32);  permute_295 = None
    clone_75 = torch.ops.aten.clone.default(convert_element_type_706, memory_format = torch.contiguous_format);  convert_element_type_706 = None
    select_247 = torch.ops.aten.select.int(clone_75, 2, 0);  clone_75 = None
    unsqueeze_155 = torch.ops.aten.unsqueeze.default(select_247, -1);  select_247 = None
    mul_384 = torch.ops.aten.mul.Tensor(sub_18, unsqueeze_155);  sub_18 = unsqueeze_155 = None
    unsqueeze_158 = torch.ops.aten.unsqueeze.default(mul_384, -2);  mul_384 = None
    mul_385 = torch.ops.aten.mul.Tensor(unsqueeze_157, unsqueeze_158);  unsqueeze_157 = unsqueeze_158 = None
    add_311 = torch.ops.aten.add.Tensor(mul_382, mul_385);  mul_382 = mul_385 = None
    view_505 = torch.ops.aten.reshape.default(getitem_50, [1, 1, -1, 128]);  getitem_50 = None
    permute_292 = torch.ops.aten.permute.default(view_505, [0, 2, 1, 3]);  view_505 = None
    convert_element_type_703 = torch.ops.prims.convert_element_type.default(permute_292, torch.float32);  permute_292 = None
    clone_72 = torch.ops.aten.clone.default(convert_element_type_703, memory_format = torch.contiguous_format);  convert_element_type_703 = None
    mul_378 = torch.ops.aten.mul.Tensor(clone_72, clone_72)
    sum_61 = torch.ops.aten.sum.dim_IntList(mul_378, [-1], True);  mul_378 = None
    add_309 = torch.ops.aten.add.Tensor(sum_61, 1e-06);  sum_61 = None
    rsqrt_87 = torch.ops.aten.rsqrt.default(add_309);  add_309 = None
    mul_379 = torch.ops.aten.mul.Tensor(clone_72, rsqrt_87);  clone_72 = rsqrt_87 = None
    div_65 = torch.ops.aten.div.Tensor(mul_379, 11.313708498984761);  mul_379 = None
    select_243 = torch.ops.aten.select.int(div_65, 2, 0);  div_65 = None
    unsqueeze_159 = torch.ops.aten.unsqueeze.default(select_243, -1);  select_243 = None
    mul_386 = torch.ops.aten.mul.Tensor(add_311, unsqueeze_159);  unsqueeze_159 = None
    sum_64 = torch.ops.aten.sum.dim_IntList(mul_386, [-2]);  mul_386 = None
    select_scatter_default_18 = torch.ops.aten.select_scatter.default(full_default_16, sum_64, 2, 0);  full_default_16 = sum_64 = None
    permute_298 = torch.ops.aten.permute.default(select_scatter_default_18, [0, 2, 1, 3]);  select_scatter_default_18 = None
    convert_element_type_707 = torch.ops.prims.convert_element_type.default(permute_298, torch.bfloat16);  permute_298 = None
    view_508 = torch.ops.aten.reshape.default(convert_element_type_707, [-1, 128]);  convert_element_type_707 = None
    convert_element_type_708 = torch.ops.prims.convert_element_type.default(view_508, torch.float32);  view_508 = None
    pow_60 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_708, 2)
    mean_59 = torch.ops.aten.mean.dim(pow_60, [-1], True);  pow_60 = None
    add_312 = torch.ops.aten.add.Tensor(mean_59, 1e-06);  mean_59 = None
    rsqrt_89 = torch.ops.aten.rsqrt.default(add_312);  add_312 = None
    mul_387 = torch.ops.aten.mul.Tensor(convert_element_type_708, rsqrt_89);  convert_element_type_708 = rsqrt_89 = None
    convert_element_type_709 = torch.ops.prims.convert_element_type.default(mul_387, torch.bfloat16);  mul_387 = None
    mul_388 = torch.ops.aten.mul.Tensor(arg294_1, convert_element_type_709);  arg294_1 = convert_element_type_709 = None
    view_494 = torch.ops.aten.reshape.default(convert_element_type_688, [1, 2048]);  convert_element_type_688 = None
    permute_288 = torch.ops.aten.permute.default(arg286_1, [1, 0]);  arg286_1 = None
    mm_141 = torch.ops.aten.mm.default(view_494, permute_288);  view_494 = permute_288 = None
    view_495 = torch.ops.aten.reshape.default(mm_141, [1, 1, 2048]);  mm_141 = None
    view_496 = torch.ops.aten.reshape.default(view_495, [1, 1, -1, 128]);  view_495 = None
    view_509 = torch.ops.aten.reshape.default(view_496, [-1, 128]);  view_496 = None
    convert_element_type_710 = torch.ops.prims.convert_element_type.default(view_509, torch.float32);  view_509 = None
    neg_70 = torch.ops.aten.neg.default(convert_element_type_710)
    exp_96 = torch.ops.aten.exp.default(neg_70);  neg_70 = None
    add_313 = torch.ops.aten.add.Tensor(exp_96, 1);  exp_96 = None
    div_66 = torch.ops.aten.div.Tensor(convert_element_type_710, add_313);  convert_element_type_710 = add_313 = None
    mul_389 = torch.ops.aten.mul.Tensor(mul_388, div_66);  mul_388 = div_66 = None
    convert_element_type_711 = torch.ops.prims.convert_element_type.default(mul_389, torch.bfloat16);  mul_389 = None
    view_510 = torch.ops.aten.reshape.default(convert_element_type_711, [1, 1, -1]);  convert_element_type_711 = None
    view_511 = torch.ops.aten.reshape.default(view_510, [1, 2048]);  view_510 = None
    permute_299 = torch.ops.aten.permute.default(arg295_1, [1, 0]);  arg295_1 = None
    mm_144 = torch.ops.aten.mm.default(view_511, permute_299);  view_511 = permute_299 = None
    view_512 = torch.ops.aten.reshape.default(mm_144, [1, 1, 2048]);  mm_144 = None
    add_314 = torch.ops.aten.add.Tensor(add_301, view_512);  add_301 = view_512 = None
    convert_element_type_714 = torch.ops.prims.convert_element_type.default(add_314, torch.float32)
    pow_61 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_714, 2)
    mean_60 = torch.ops.aten.mean.dim(pow_61, [-1], True);  pow_61 = None
    add_315 = torch.ops.aten.add.Tensor(mean_60, 1e-06);  mean_60 = None
    rsqrt_90 = torch.ops.aten.rsqrt.default(add_315);  add_315 = None
    mul_390 = torch.ops.aten.mul.Tensor(convert_element_type_714, rsqrt_90);  convert_element_type_714 = rsqrt_90 = None
    convert_element_type_715 = torch.ops.prims.convert_element_type.default(arg296_1, torch.float32);  arg296_1 = None
    add_316 = torch.ops.aten.add.Tensor(convert_element_type_715, 1.0);  convert_element_type_715 = None
    mul_391 = torch.ops.aten.mul.Tensor(mul_390, add_316);  mul_390 = add_316 = None
    convert_element_type_716 = torch.ops.prims.convert_element_type.default(mul_391, torch.bfloat16);  mul_391 = None
    view_513 = torch.ops.aten.reshape.default(convert_element_type_716, [1, 2048])
    permute_300 = torch.ops.aten.permute.default(arg297_1, [1, 0]);  arg297_1 = None
    mm_145 = torch.ops.aten.mm.default(view_513, permute_300);  view_513 = permute_300 = None
    view_514 = torch.ops.aten.reshape.default(mm_145, [1, 1, 6144]);  mm_145 = None
    convert_element_type_719 = torch.ops.prims.convert_element_type.default(view_514, torch.float32);  view_514 = None
    neg_71 = torch.ops.aten.neg.default(convert_element_type_719)
    exp_97 = torch.ops.aten.exp.default(neg_71);  neg_71 = None
    add_317 = torch.ops.aten.add.Tensor(exp_97, 1);  exp_97 = None
    div_67 = torch.ops.aten.div.Tensor(convert_element_type_719, add_317);  convert_element_type_719 = add_317 = None
    convert_element_type_720 = torch.ops.prims.convert_element_type.default(div_67, torch.bfloat16);  div_67 = None
    view_515 = torch.ops.aten.reshape.default(convert_element_type_716, [1, 2048]);  convert_element_type_716 = None
    permute_301 = torch.ops.aten.permute.default(arg298_1, [1, 0]);  arg298_1 = None
    mm_146 = torch.ops.aten.mm.default(view_515, permute_301);  view_515 = permute_301 = None
    view_516 = torch.ops.aten.reshape.default(mm_146, [1, 1, 6144]);  mm_146 = None
    mul_392 = torch.ops.aten.mul.Tensor(convert_element_type_720, view_516);  convert_element_type_720 = view_516 = None
    view_517 = torch.ops.aten.reshape.default(mul_392, [1, 6144]);  mul_392 = None
    permute_302 = torch.ops.aten.permute.default(arg299_1, [1, 0]);  arg299_1 = None
    mm_147 = torch.ops.aten.mm.default(view_517, permute_302);  view_517 = permute_302 = None
    view_518 = torch.ops.aten.reshape.default(mm_147, [1, 1, 2048]);  mm_147 = None
    add_318 = torch.ops.aten.add.Tensor(add_314, view_518);  add_314 = view_518 = None
    convert_element_type_725 = torch.ops.prims.convert_element_type.default(add_318, torch.float32)
    pow_62 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_725, 2)
    mean_61 = torch.ops.aten.mean.dim(pow_62, [-1], True);  pow_62 = None
    add_319 = torch.ops.aten.add.Tensor(mean_61, 1e-06);  mean_61 = None
    rsqrt_91 = torch.ops.aten.rsqrt.default(add_319);  add_319 = None
    mul_393 = torch.ops.aten.mul.Tensor(convert_element_type_725, rsqrt_91);  convert_element_type_725 = rsqrt_91 = None
    convert_element_type_726 = torch.ops.prims.convert_element_type.default(arg300_1, torch.float32);  arg300_1 = None
    add_320 = torch.ops.aten.add.Tensor(convert_element_type_726, 1.0);  convert_element_type_726 = None
    mul_394 = torch.ops.aten.mul.Tensor(mul_393, add_320);  mul_393 = add_320 = None
    convert_element_type_727 = torch.ops.prims.convert_element_type.default(mul_394, torch.bfloat16);  mul_394 = None
    view_519 = torch.ops.aten.reshape.default(convert_element_type_727, [1, 2048])
    permute_303 = torch.ops.aten.permute.default(arg301_1, [1, 0]);  arg301_1 = None
    mm_148 = torch.ops.aten.mm.default(view_519, permute_303);  view_519 = permute_303 = None
    view_520 = torch.ops.aten.reshape.default(mm_148, [1, 1, 4096]);  mm_148 = None
    view_521 = torch.ops.aten.reshape.default(view_520, [1, 1, -1, 512]);  view_520 = None
    split_4 = torch.ops.aten.split.Tensor(view_521, 256, -1);  view_521 = None
    getitem_53 = split_4[0]
    getitem_54 = split_4[1];  split_4 = None
    add_328 = torch.ops.aten.add.Tensor(arg306_1, 1)
    convert_element_type_730 = torch.ops.prims.convert_element_type.default(getitem_53, torch.float32);  getitem_53 = None
    pow_63 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_730, 2)
    mean_62 = torch.ops.aten.mean.dim(pow_63, [-1], True);  pow_63 = None
    add_321 = torch.ops.aten.add.Tensor(mean_62, 1e-06);  mean_62 = None
    rsqrt_92 = torch.ops.aten.rsqrt.default(add_321);  add_321 = None
    mul_395 = torch.ops.aten.mul.Tensor(convert_element_type_730, rsqrt_92);  convert_element_type_730 = rsqrt_92 = None
    convert_element_type_731 = torch.ops.prims.convert_element_type.default(arg302_1, torch.float32);  arg302_1 = None
    add_322 = torch.ops.aten.add.Tensor(convert_element_type_731, 1.0);  convert_element_type_731 = None
    mul_396 = torch.ops.aten.mul.Tensor(mul_395, add_322);  mul_395 = add_322 = None
    convert_element_type_732 = torch.ops.prims.convert_element_type.default(mul_396, torch.bfloat16);  mul_396 = None
    permute_304 = torch.ops.aten.permute.default(convert_element_type_732, [0, 2, 1, 3]);  convert_element_type_732 = None
    slice_140 = torch.ops.aten.slice.Tensor(permute_304, 3, 0, 64)
    unsqueeze_160 = torch.ops.aten.unsqueeze.default(convert_element_type_2, 1)
    mul_399 = torch.ops.aten.mul.Tensor(slice_140, unsqueeze_160)
    slice_145 = torch.ops.aten.slice.Tensor(slice_140, 3, 32, 9223372036854775807)
    neg_72 = torch.ops.aten.neg.default(slice_145);  slice_145 = None
    slice_144 = torch.ops.aten.slice.Tensor(slice_140, 3, 0, 32);  slice_140 = None
    cat_31 = torch.ops.aten.cat.default([neg_72, slice_144], -1);  neg_72 = slice_144 = None
    unsqueeze_161 = torch.ops.aten.unsqueeze.default(convert_element_type_3, 1)
    mul_400 = torch.ops.aten.mul.Tensor(cat_31, unsqueeze_161);  cat_31 = None
    add_325 = torch.ops.aten.add.Tensor(mul_399, mul_400);  mul_399 = mul_400 = None
    slice_141 = torch.ops.aten.slice.Tensor(permute_304, 3, 64, 9223372036854775807);  permute_304 = None
    cat_33 = torch.ops.aten.cat.default([add_325, slice_141], -1);  add_325 = slice_141 = None
    expand_40 = torch.ops.aten.expand.default(cat_33, [1, 8, 1, 256]);  cat_33 = None
    view_532 = torch.ops.aten.reshape.default(expand_40, [8, 1, 256]);  expand_40 = None
    iota_5 = torch.ops.prims.iota.default(1, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    add_327 = torch.ops.aten.add.Tensor(iota_5, arg306_1);  iota_5 = None
    view_524 = torch.ops.aten.reshape.default(convert_element_type_727, [1, 2048])
    permute_305 = torch.ops.aten.permute.default(arg303_1, [1, 0]);  arg303_1 = None
    mm_149 = torch.ops.aten.mm.default(view_524, permute_305);  view_524 = permute_305 = None
    view_525 = torch.ops.aten.reshape.default(mm_149, [1, 1, 512]);  mm_149 = None
    view_526 = torch.ops.aten.reshape.default(view_525, [1, 1, -1, 256]);  view_525 = None
    convert_element_type_735 = torch.ops.prims.convert_element_type.default(view_526, torch.float32);  view_526 = None
    pow_64 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_735, 2)
    mean_63 = torch.ops.aten.mean.dim(pow_64, [-1], True);  pow_64 = None
    add_323 = torch.ops.aten.add.Tensor(mean_63, 1e-06);  mean_63 = None
    rsqrt_93 = torch.ops.aten.rsqrt.default(add_323);  add_323 = None
    mul_397 = torch.ops.aten.mul.Tensor(convert_element_type_735, rsqrt_93);  convert_element_type_735 = rsqrt_93 = None
    convert_element_type_736 = torch.ops.prims.convert_element_type.default(arg304_1, torch.float32);  arg304_1 = None
    add_324 = torch.ops.aten.add.Tensor(convert_element_type_736, 1.0);  convert_element_type_736 = None
    mul_398 = torch.ops.aten.mul.Tensor(mul_397, add_324);  mul_397 = add_324 = None
    convert_element_type_737 = torch.ops.prims.convert_element_type.default(mul_398, torch.bfloat16);  mul_398 = None
    permute_306 = torch.ops.aten.permute.default(convert_element_type_737, [0, 2, 1, 3]);  convert_element_type_737 = None
    slice_142 = torch.ops.aten.slice.Tensor(permute_306, 3, 0, 64)
    mul_401 = torch.ops.aten.mul.Tensor(slice_142, unsqueeze_160);  unsqueeze_160 = None
    slice_147 = torch.ops.aten.slice.Tensor(slice_142, 3, 32, 9223372036854775807)
    neg_73 = torch.ops.aten.neg.default(slice_147);  slice_147 = None
    slice_146 = torch.ops.aten.slice.Tensor(slice_142, 3, 0, 32);  slice_142 = None
    cat_32 = torch.ops.aten.cat.default([neg_73, slice_146], -1);  neg_73 = slice_146 = None
    mul_402 = torch.ops.aten.mul.Tensor(cat_32, unsqueeze_161);  cat_32 = unsqueeze_161 = None
    add_326 = torch.ops.aten.add.Tensor(mul_401, mul_402);  mul_401 = mul_402 = None
    slice_143 = torch.ops.aten.slice.Tensor(permute_306, 3, 64, 9223372036854775807);  permute_306 = None
    cat_34 = torch.ops.aten.cat.default([add_326, slice_143], -1);  add_326 = slice_143 = None
    index_put_8 = torch.ops.aten.index_put_.default(arg307_1, [None, None, add_327], cat_34);  arg307_1 = cat_34 = None
    unsqueeze_164 = torch.ops.aten.unsqueeze.default(index_put_8, 2);  index_put_8 = None
    expand_37 = torch.ops.aten.expand.default(unsqueeze_164, [1, 2, 4, 144, 256]);  unsqueeze_164 = None
    clone_77 = torch.ops.aten.clone.default(expand_37, memory_format = torch.contiguous_format);  expand_37 = None
    view_530 = torch.ops.aten.reshape.default(clone_77, [1, 8, 144, 256]);  clone_77 = None
    permute_309 = torch.ops.aten.permute.default(view_530, [0, 1, 3, 2]);  view_530 = None
    expand_41 = torch.ops.aten.expand.default(permute_309, [1, 8, 256, 144]);  permute_309 = None
    view_533 = torch.ops.aten.reshape.default(expand_41, [8, 256, 144]);  expand_41 = None
    bmm_8 = torch.ops.aten.bmm.default(view_532, view_533);  view_532 = view_533 = None
    view_534 = torch.ops.aten.reshape.default(bmm_8, [1, 8, 1, 144]);  bmm_8 = None
    mul_403 = torch.ops.aten.mul.Tensor(view_534, 0.0625);  view_534 = None
    add_329 = torch.ops.aten.add.Tensor(mul_403, unsqueeze_3);  mul_403 = None
    convert_element_type_742 = torch.ops.prims.convert_element_type.default(add_329, torch.float32);  add_329 = None
    amax_4 = torch.ops.aten.amax.default(convert_element_type_742, [-1], True)
    sub_19 = torch.ops.aten.sub.Tensor(convert_element_type_742, amax_4);  convert_element_type_742 = amax_4 = None
    exp_98 = torch.ops.aten.exp.default(sub_19);  sub_19 = None
    sum_65 = torch.ops.aten.sum.dim_IntList(exp_98, [-1], True)
    div_68 = torch.ops.aten.div.Tensor(exp_98, sum_65);  exp_98 = sum_65 = None
    convert_element_type_743 = torch.ops.prims.convert_element_type.default(div_68, torch.bfloat16);  div_68 = None
    expand_42 = torch.ops.aten.expand.default(convert_element_type_743, [1, 8, 1, 144]);  convert_element_type_743 = None
    view_535 = torch.ops.aten.reshape.default(expand_42, [8, 1, 144]);  expand_42 = None
    view_527 = torch.ops.aten.reshape.default(convert_element_type_727, [1, 2048]);  convert_element_type_727 = None
    permute_307 = torch.ops.aten.permute.default(arg305_1, [1, 0]);  arg305_1 = None
    mm_150 = torch.ops.aten.mm.default(view_527, permute_307);  view_527 = permute_307 = None
    view_528 = torch.ops.aten.reshape.default(mm_150, [1, 1, 512]);  mm_150 = None
    view_529 = torch.ops.aten.reshape.default(view_528, [1, 1, -1, 256]);  view_528 = None
    permute_308 = torch.ops.aten.permute.default(view_529, [0, 2, 1, 3]);  view_529 = None
    index_put_9 = torch.ops.aten.index_put_.default(arg308_1, [None, None, add_327], permute_308);  arg308_1 = add_327 = permute_308 = None
    unsqueeze_167 = torch.ops.aten.unsqueeze.default(index_put_9, 2);  index_put_9 = None
    expand_39 = torch.ops.aten.expand.default(unsqueeze_167, [1, 2, 4, 144, 256]);  unsqueeze_167 = None
    clone_78 = torch.ops.aten.clone.default(expand_39, memory_format = torch.contiguous_format);  expand_39 = None
    view_531 = torch.ops.aten.reshape.default(clone_78, [1, 8, 144, 256]);  clone_78 = None
    expand_43 = torch.ops.aten.expand.default(view_531, [1, 8, 144, 256]);  view_531 = None
    view_536 = torch.ops.aten.reshape.default(expand_43, [8, 144, 256]);  expand_43 = None
    bmm_9 = torch.ops.aten.bmm.default(view_535, view_536);  view_535 = view_536 = None
    view_537 = torch.ops.aten.reshape.default(bmm_9, [1, 8, 1, 256]);  bmm_9 = None
    permute_310 = torch.ops.aten.permute.default(view_537, [0, 2, 1, 3]);  view_537 = None
    view_538 = torch.ops.aten.reshape.default(permute_310, [1, 1, -1]);  permute_310 = None
    clone_76 = torch.ops.aten.clone.default(getitem_54, memory_format = torch.contiguous_format);  getitem_54 = None
    view_522 = torch.ops.aten.reshape.default(clone_76, [1, 1, 2048]);  clone_76 = None
    sigmoid_19 = torch.ops.aten.sigmoid.default(view_522);  view_522 = None
    mul_404 = torch.ops.aten.mul.Tensor(view_538, sigmoid_19);  view_538 = sigmoid_19 = None
    view_539 = torch.ops.aten.reshape.default(mul_404, [1, 2048]);  mul_404 = None
    permute_311 = torch.ops.aten.permute.default(arg309_1, [1, 0]);  arg309_1 = None
    mm_151 = torch.ops.aten.mm.default(view_539, permute_311);  view_539 = permute_311 = None
    view_540 = torch.ops.aten.reshape.default(mm_151, [1, 1, 2048]);  mm_151 = None
    add_330 = torch.ops.aten.add.Tensor(add_318, view_540);  add_318 = view_540 = None
    convert_element_type_748 = torch.ops.prims.convert_element_type.default(add_330, torch.float32)
    pow_65 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_748, 2)
    mean_64 = torch.ops.aten.mean.dim(pow_65, [-1], True);  pow_65 = None
    add_331 = torch.ops.aten.add.Tensor(mean_64, 1e-06);  mean_64 = None
    rsqrt_94 = torch.ops.aten.rsqrt.default(add_331);  add_331 = None
    mul_405 = torch.ops.aten.mul.Tensor(convert_element_type_748, rsqrt_94);  convert_element_type_748 = rsqrt_94 = None
    convert_element_type_749 = torch.ops.prims.convert_element_type.default(arg310_1, torch.float32);  arg310_1 = None
    add_332 = torch.ops.aten.add.Tensor(convert_element_type_749, 1.0);  convert_element_type_749 = None
    mul_406 = torch.ops.aten.mul.Tensor(mul_405, add_332);  mul_405 = add_332 = None
    convert_element_type_750 = torch.ops.prims.convert_element_type.default(mul_406, torch.bfloat16);  mul_406 = None
    view_541 = torch.ops.aten.reshape.default(convert_element_type_750, [1, 2048])
    permute_312 = torch.ops.aten.permute.default(arg311_1, [1, 0]);  arg311_1 = None
    mm_152 = torch.ops.aten.mm.default(view_541, permute_312);  view_541 = permute_312 = None
    view_542 = torch.ops.aten.reshape.default(mm_152, [1, 1, 6144]);  mm_152 = None
    convert_element_type_753 = torch.ops.prims.convert_element_type.default(view_542, torch.float32);  view_542 = None
    neg_74 = torch.ops.aten.neg.default(convert_element_type_753)
    exp_99 = torch.ops.aten.exp.default(neg_74);  neg_74 = None
    add_333 = torch.ops.aten.add.Tensor(exp_99, 1);  exp_99 = None
    div_69 = torch.ops.aten.div.Tensor(convert_element_type_753, add_333);  convert_element_type_753 = add_333 = None
    convert_element_type_754 = torch.ops.prims.convert_element_type.default(div_69, torch.bfloat16);  div_69 = None
    view_543 = torch.ops.aten.reshape.default(convert_element_type_750, [1, 2048]);  convert_element_type_750 = None
    permute_313 = torch.ops.aten.permute.default(arg312_1, [1, 0]);  arg312_1 = None
    mm_153 = torch.ops.aten.mm.default(view_543, permute_313);  view_543 = permute_313 = None
    view_544 = torch.ops.aten.reshape.default(mm_153, [1, 1, 6144]);  mm_153 = None
    mul_407 = torch.ops.aten.mul.Tensor(convert_element_type_754, view_544);  convert_element_type_754 = view_544 = None
    view_545 = torch.ops.aten.reshape.default(mul_407, [1, 6144]);  mul_407 = None
    permute_314 = torch.ops.aten.permute.default(arg313_1, [1, 0]);  arg313_1 = None
    mm_154 = torch.ops.aten.mm.default(view_545, permute_314);  view_545 = permute_314 = None
    view_546 = torch.ops.aten.reshape.default(mm_154, [1, 1, 2048]);  mm_154 = None
    add_334 = torch.ops.aten.add.Tensor(add_330, view_546);  add_330 = view_546 = None
    convert_element_type_759 = torch.ops.prims.convert_element_type.default(add_334, torch.float32)
    pow_66 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_759, 2)
    mean_65 = torch.ops.aten.mean.dim(pow_66, [-1], True);  pow_66 = None
    add_335 = torch.ops.aten.add.Tensor(mean_65, 1e-06);  mean_65 = None
    rsqrt_95 = torch.ops.aten.rsqrt.default(add_335);  add_335 = None
    mul_408 = torch.ops.aten.mul.Tensor(convert_element_type_759, rsqrt_95);  convert_element_type_759 = rsqrt_95 = None
    convert_element_type_760 = torch.ops.prims.convert_element_type.default(arg314_1, torch.float32);  arg314_1 = None
    add_336 = torch.ops.aten.add.Tensor(convert_element_type_760, 1.0);  convert_element_type_760 = None
    mul_409 = torch.ops.aten.mul.Tensor(mul_408, add_336);  mul_408 = add_336 = None
    convert_element_type_761 = torch.ops.prims.convert_element_type.default(mul_409, torch.bfloat16);  mul_409 = None
    view_547 = torch.ops.aten.reshape.default(convert_element_type_761, [1, 2048])
    permute_315 = torch.ops.aten.permute.default(arg315_1, [1, 0]);  arg315_1 = None
    mm_155 = torch.ops.aten.mm.default(view_547, permute_315);  view_547 = permute_315 = None
    view_548 = torch.ops.aten.reshape.default(mm_155, [1, 1, 6144]);  mm_155 = None
    permute_316 = torch.ops.aten.permute.default(view_548, [0, 2, 1]);  view_548 = None
    cat_35 = torch.ops.aten.cat.default([arg319_1, permute_316], -1);  permute_316 = None
    slice_148 = torch.ops.aten.slice.Tensor(cat_35, 2, -4, 9223372036854775807)
    copy_49 = torch.ops.aten.copy.default(arg319_1, slice_148);  slice_148 = None
    convert_element_type_770 = torch.ops.prims.convert_element_type.default(cat_35, torch.float32);  cat_35 = None
    slice_149 = torch.ops.aten.slice.Tensor(convert_element_type_770, 2, 0, 2)
    squeeze_15 = torch.ops.aten.squeeze.dim(arg320_1, 1);  arg320_1 = None
    unsqueeze_168 = torch.ops.aten.unsqueeze.default(squeeze_15, 1);  squeeze_15 = None
    convert_element_type_771 = torch.ops.prims.convert_element_type.default(unsqueeze_168, torch.float32);  unsqueeze_168 = None
    select_250 = torch.ops.aten.select.int(convert_element_type_771, 1, 0)
    select_251 = torch.ops.aten.select.int(select_250, 1, 0);  select_250 = None
    view_556 = torch.ops.aten.reshape.default(select_251, [1, -1, 1]);  select_251 = None
    mul_410 = torch.ops.aten.mul.Tensor(slice_149, view_556);  slice_149 = view_556 = None
    slice_150 = torch.ops.aten.slice.Tensor(convert_element_type_770, 2, 1, 3)
    select_252 = torch.ops.aten.select.int(convert_element_type_771, 1, 0)
    select_253 = torch.ops.aten.select.int(select_252, 1, 1);  select_252 = None
    view_557 = torch.ops.aten.reshape.default(select_253, [1, -1, 1]);  select_253 = None
    mul_411 = torch.ops.aten.mul.Tensor(slice_150, view_557);  slice_150 = view_557 = None
    add_337 = torch.ops.aten.add.Tensor(mul_410, mul_411);  mul_410 = mul_411 = None
    slice_151 = torch.ops.aten.slice.Tensor(convert_element_type_770, 2, 2, 4)
    select_254 = torch.ops.aten.select.int(convert_element_type_771, 1, 0)
    select_255 = torch.ops.aten.select.int(select_254, 1, 2);  select_254 = None
    view_558 = torch.ops.aten.reshape.default(select_255, [1, -1, 1]);  select_255 = None
    mul_412 = torch.ops.aten.mul.Tensor(slice_151, view_558);  slice_151 = view_558 = None
    add_338 = torch.ops.aten.add.Tensor(add_337, mul_412);  add_337 = mul_412 = None
    slice_152 = torch.ops.aten.slice.Tensor(convert_element_type_770, 2, 3, 5);  convert_element_type_770 = None
    select_256 = torch.ops.aten.select.int(convert_element_type_771, 1, 0);  convert_element_type_771 = None
    select_257 = torch.ops.aten.select.int(select_256, 1, 3);  select_256 = None
    view_559 = torch.ops.aten.reshape.default(select_257, [1, -1, 1]);  select_257 = None
    mul_413 = torch.ops.aten.mul.Tensor(slice_152, view_559);  slice_152 = view_559 = None
    add_339 = torch.ops.aten.add.Tensor(add_338, mul_413);  add_338 = mul_413 = None
    convert_element_type_772 = torch.ops.prims.convert_element_type.default(add_339, torch.bfloat16);  add_339 = None
    slice_153 = torch.ops.aten.slice.Tensor(convert_element_type_772, 2, -1, 9223372036854775807);  convert_element_type_772 = None
    convert_element_type_773 = torch.ops.prims.convert_element_type.default(slice_153, torch.float32);  slice_153 = None
    neg_75 = torch.ops.aten.neg.default(convert_element_type_773)
    exp_100 = torch.ops.aten.exp.default(neg_75);  neg_75 = None
    add_340 = torch.ops.aten.add.Tensor(exp_100, 1);  exp_100 = None
    div_70 = torch.ops.aten.div.Tensor(convert_element_type_773, add_340);  convert_element_type_773 = add_340 = None
    convert_element_type_774 = torch.ops.prims.convert_element_type.default(div_70, torch.bfloat16);  div_70 = None
    permute_320 = torch.ops.aten.permute.default(convert_element_type_774, [0, 2, 1]);  convert_element_type_774 = None
    split_with_sizes_15 = torch.ops.aten.split_with_sizes.default(permute_320, [2048, 2048, 2048], -1);  permute_320 = None
    getitem_55 = split_with_sizes_15[0]
    getitem_56 = split_with_sizes_15[1]
    getitem_57 = split_with_sizes_15[2];  split_with_sizes_15 = None
    full_default_17 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_263 = torch.ops.aten.select.int(full_default_17, 2, 0);  select_263 = None
    view_561 = torch.ops.aten.reshape.default(getitem_56, [1, 1, -1, 128]);  getitem_56 = None
    permute_322 = torch.ops.aten.permute.default(view_561, [0, 2, 1, 3]);  view_561 = None
    convert_element_type_777 = torch.ops.prims.convert_element_type.default(permute_322, torch.float32);  permute_322 = None
    clone_80 = torch.ops.aten.clone.default(convert_element_type_777, memory_format = torch.contiguous_format);  convert_element_type_777 = None
    mul_417 = torch.ops.aten.mul.Tensor(clone_80, clone_80)
    sum_67 = torch.ops.aten.sum.dim_IntList(mul_417, [-1], True);  mul_417 = None
    add_343 = torch.ops.aten.add.Tensor(sum_67, 1e-06);  sum_67 = None
    rsqrt_97 = torch.ops.aten.rsqrt.default(add_343);  add_343 = None
    mul_418 = torch.ops.aten.mul.Tensor(clone_80, rsqrt_97);  clone_80 = rsqrt_97 = None
    select_259 = torch.ops.aten.select.int(mul_418, 2, 0);  mul_418 = None
    unsqueeze_173 = torch.ops.aten.unsqueeze.default(select_259, -1)
    view_562 = torch.ops.aten.reshape.default(getitem_57, [1, 1, -1, 128]);  getitem_57 = None
    permute_323 = torch.ops.aten.permute.default(view_562, [0, 2, 1, 3]);  view_562 = None
    convert_element_type_778 = torch.ops.prims.convert_element_type.default(permute_323, torch.float32);  permute_323 = None
    clone_81 = torch.ops.aten.clone.default(convert_element_type_778, memory_format = torch.contiguous_format);  convert_element_type_778 = None
    select_260 = torch.ops.aten.select.int(clone_81, 2, 0);  clone_81 = None
    exp_101 = torch.ops.aten.exp.default(arg321_1);  arg321_1 = None
    neg_76 = torch.ops.aten.neg.default(exp_101);  exp_101 = None
    view_554 = torch.ops.aten.reshape.default(convert_element_type_761, [1, 2048])
    permute_319 = torch.ops.aten.permute.default(arg318_1, [1, 0]);  arg318_1 = None
    mm_158 = torch.ops.aten.mm.default(view_554, permute_319);  view_554 = permute_319 = None
    view_555 = torch.ops.aten.reshape.default(mm_158, [1, 1, 16]);  mm_158 = None
    convert_element_type_775 = torch.ops.prims.convert_element_type.default(view_555, torch.float32);  view_555 = None
    add_341 = torch.ops.aten.add.Tensor(convert_element_type_775, arg322_1);  convert_element_type_775 = arg322_1 = None
    gt_15 = torch.ops.aten.gt.Scalar(add_341, 20)
    exp_102 = torch.ops.aten.exp.default(add_341)
    log1p_15 = torch.ops.aten.log1p.default(exp_102);  exp_102 = None
    where_16 = torch.ops.aten.where.self(gt_15, add_341, log1p_15);  gt_15 = add_341 = log1p_15 = None
    mul_414 = torch.ops.aten.mul.Tensor(neg_76, where_16);  neg_76 = where_16 = None
    permute_325 = torch.ops.aten.permute.default(mul_414, [0, 2, 1]);  mul_414 = None
    select_261 = torch.ops.aten.select.int(permute_325, 2, 0);  permute_325 = None
    exp_103 = torch.ops.aten.exp.default(select_261);  select_261 = None
    unsqueeze_169 = torch.ops.aten.unsqueeze.default(exp_103, 2);  exp_103 = None
    unsqueeze_170 = torch.ops.aten.unsqueeze.default(unsqueeze_169, 3);  unsqueeze_169 = None
    mul_419 = torch.ops.aten.mul.Tensor(arg323_1, unsqueeze_170);  unsqueeze_170 = None
    unsqueeze_172 = torch.ops.aten.unsqueeze.default(select_259, -1);  select_259 = None
    mul_420 = torch.ops.aten.mul.Tensor(mul_419, unsqueeze_172);  unsqueeze_172 = None
    sum_68 = torch.ops.aten.sum.dim_IntList(mul_420, [-2]);  mul_420 = None
    sub_20 = torch.ops.aten.sub.Tensor(select_260, sum_68);  select_260 = sum_68 = None
    view_552 = torch.ops.aten.reshape.default(convert_element_type_761, [1, 2048])
    permute_318 = torch.ops.aten.permute.default(arg317_1, [1, 0]);  arg317_1 = None
    mm_157 = torch.ops.aten.mm.default(view_552, permute_318);  view_552 = permute_318 = None
    view_553 = torch.ops.aten.reshape.default(mm_157, [1, 1, 16]);  mm_157 = None
    sigmoid_20 = torch.ops.aten.sigmoid.default(view_553);  view_553 = None
    permute_324 = torch.ops.aten.permute.default(sigmoid_20, [0, 2, 1]);  sigmoid_20 = None
    convert_element_type_779 = torch.ops.prims.convert_element_type.default(permute_324, torch.float32);  permute_324 = None
    clone_82 = torch.ops.aten.clone.default(convert_element_type_779, memory_format = torch.contiguous_format);  convert_element_type_779 = None
    select_262 = torch.ops.aten.select.int(clone_82, 2, 0);  clone_82 = None
    unsqueeze_171 = torch.ops.aten.unsqueeze.default(select_262, -1);  select_262 = None
    mul_421 = torch.ops.aten.mul.Tensor(sub_20, unsqueeze_171);  sub_20 = unsqueeze_171 = None
    unsqueeze_174 = torch.ops.aten.unsqueeze.default(mul_421, -2);  mul_421 = None
    mul_422 = torch.ops.aten.mul.Tensor(unsqueeze_173, unsqueeze_174);  unsqueeze_173 = unsqueeze_174 = None
    add_344 = torch.ops.aten.add.Tensor(mul_419, mul_422);  mul_419 = mul_422 = None
    view_560 = torch.ops.aten.reshape.default(getitem_55, [1, 1, -1, 128]);  getitem_55 = None
    permute_321 = torch.ops.aten.permute.default(view_560, [0, 2, 1, 3]);  view_560 = None
    convert_element_type_776 = torch.ops.prims.convert_element_type.default(permute_321, torch.float32);  permute_321 = None
    clone_79 = torch.ops.aten.clone.default(convert_element_type_776, memory_format = torch.contiguous_format);  convert_element_type_776 = None
    mul_415 = torch.ops.aten.mul.Tensor(clone_79, clone_79)
    sum_66 = torch.ops.aten.sum.dim_IntList(mul_415, [-1], True);  mul_415 = None
    add_342 = torch.ops.aten.add.Tensor(sum_66, 1e-06);  sum_66 = None
    rsqrt_96 = torch.ops.aten.rsqrt.default(add_342);  add_342 = None
    mul_416 = torch.ops.aten.mul.Tensor(clone_79, rsqrt_96);  clone_79 = rsqrt_96 = None
    div_71 = torch.ops.aten.div.Tensor(mul_416, 11.313708498984761);  mul_416 = None
    select_258 = torch.ops.aten.select.int(div_71, 2, 0);  div_71 = None
    unsqueeze_175 = torch.ops.aten.unsqueeze.default(select_258, -1);  select_258 = None
    mul_423 = torch.ops.aten.mul.Tensor(add_344, unsqueeze_175);  unsqueeze_175 = None
    sum_69 = torch.ops.aten.sum.dim_IntList(mul_423, [-2]);  mul_423 = None
    select_scatter_default_19 = torch.ops.aten.select_scatter.default(full_default_17, sum_69, 2, 0);  full_default_17 = sum_69 = None
    permute_327 = torch.ops.aten.permute.default(select_scatter_default_19, [0, 2, 1, 3]);  select_scatter_default_19 = None
    convert_element_type_780 = torch.ops.prims.convert_element_type.default(permute_327, torch.bfloat16);  permute_327 = None
    view_563 = torch.ops.aten.reshape.default(convert_element_type_780, [-1, 128]);  convert_element_type_780 = None
    convert_element_type_781 = torch.ops.prims.convert_element_type.default(view_563, torch.float32);  view_563 = None
    pow_67 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_781, 2)
    mean_66 = torch.ops.aten.mean.dim(pow_67, [-1], True);  pow_67 = None
    add_345 = torch.ops.aten.add.Tensor(mean_66, 1e-06);  mean_66 = None
    rsqrt_98 = torch.ops.aten.rsqrt.default(add_345);  add_345 = None
    mul_424 = torch.ops.aten.mul.Tensor(convert_element_type_781, rsqrt_98);  convert_element_type_781 = rsqrt_98 = None
    convert_element_type_782 = torch.ops.prims.convert_element_type.default(mul_424, torch.bfloat16);  mul_424 = None
    mul_425 = torch.ops.aten.mul.Tensor(arg324_1, convert_element_type_782);  arg324_1 = convert_element_type_782 = None
    view_549 = torch.ops.aten.reshape.default(convert_element_type_761, [1, 2048]);  convert_element_type_761 = None
    permute_317 = torch.ops.aten.permute.default(arg316_1, [1, 0]);  arg316_1 = None
    mm_156 = torch.ops.aten.mm.default(view_549, permute_317);  view_549 = permute_317 = None
    view_550 = torch.ops.aten.reshape.default(mm_156, [1, 1, 2048]);  mm_156 = None
    view_551 = torch.ops.aten.reshape.default(view_550, [1, 1, -1, 128]);  view_550 = None
    view_564 = torch.ops.aten.reshape.default(view_551, [-1, 128]);  view_551 = None
    convert_element_type_783 = torch.ops.prims.convert_element_type.default(view_564, torch.float32);  view_564 = None
    neg_77 = torch.ops.aten.neg.default(convert_element_type_783)
    exp_104 = torch.ops.aten.exp.default(neg_77);  neg_77 = None
    add_346 = torch.ops.aten.add.Tensor(exp_104, 1);  exp_104 = None
    div_72 = torch.ops.aten.div.Tensor(convert_element_type_783, add_346);  convert_element_type_783 = add_346 = None
    mul_426 = torch.ops.aten.mul.Tensor(mul_425, div_72);  mul_425 = div_72 = None
    convert_element_type_784 = torch.ops.prims.convert_element_type.default(mul_426, torch.bfloat16);  mul_426 = None
    view_565 = torch.ops.aten.reshape.default(convert_element_type_784, [1, 1, -1]);  convert_element_type_784 = None
    view_566 = torch.ops.aten.reshape.default(view_565, [1, 2048]);  view_565 = None
    permute_328 = torch.ops.aten.permute.default(arg325_1, [1, 0]);  arg325_1 = None
    mm_159 = torch.ops.aten.mm.default(view_566, permute_328);  view_566 = permute_328 = None
    view_567 = torch.ops.aten.reshape.default(mm_159, [1, 1, 2048]);  mm_159 = None
    add_347 = torch.ops.aten.add.Tensor(add_334, view_567);  add_334 = view_567 = None
    convert_element_type_787 = torch.ops.prims.convert_element_type.default(add_347, torch.float32)
    pow_68 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_787, 2)
    mean_67 = torch.ops.aten.mean.dim(pow_68, [-1], True);  pow_68 = None
    add_348 = torch.ops.aten.add.Tensor(mean_67, 1e-06);  mean_67 = None
    rsqrt_99 = torch.ops.aten.rsqrt.default(add_348);  add_348 = None
    mul_427 = torch.ops.aten.mul.Tensor(convert_element_type_787, rsqrt_99);  convert_element_type_787 = rsqrt_99 = None
    convert_element_type_788 = torch.ops.prims.convert_element_type.default(arg326_1, torch.float32);  arg326_1 = None
    add_349 = torch.ops.aten.add.Tensor(convert_element_type_788, 1.0);  convert_element_type_788 = None
    mul_428 = torch.ops.aten.mul.Tensor(mul_427, add_349);  mul_427 = add_349 = None
    convert_element_type_789 = torch.ops.prims.convert_element_type.default(mul_428, torch.bfloat16);  mul_428 = None
    view_568 = torch.ops.aten.reshape.default(convert_element_type_789, [1, 2048])
    permute_329 = torch.ops.aten.permute.default(arg327_1, [1, 0]);  arg327_1 = None
    mm_160 = torch.ops.aten.mm.default(view_568, permute_329);  view_568 = permute_329 = None
    view_569 = torch.ops.aten.reshape.default(mm_160, [1, 1, 6144]);  mm_160 = None
    convert_element_type_792 = torch.ops.prims.convert_element_type.default(view_569, torch.float32);  view_569 = None
    neg_78 = torch.ops.aten.neg.default(convert_element_type_792)
    exp_105 = torch.ops.aten.exp.default(neg_78);  neg_78 = None
    add_350 = torch.ops.aten.add.Tensor(exp_105, 1);  exp_105 = None
    div_73 = torch.ops.aten.div.Tensor(convert_element_type_792, add_350);  convert_element_type_792 = add_350 = None
    convert_element_type_793 = torch.ops.prims.convert_element_type.default(div_73, torch.bfloat16);  div_73 = None
    view_570 = torch.ops.aten.reshape.default(convert_element_type_789, [1, 2048]);  convert_element_type_789 = None
    permute_330 = torch.ops.aten.permute.default(arg328_1, [1, 0]);  arg328_1 = None
    mm_161 = torch.ops.aten.mm.default(view_570, permute_330);  view_570 = permute_330 = None
    view_571 = torch.ops.aten.reshape.default(mm_161, [1, 1, 6144]);  mm_161 = None
    mul_429 = torch.ops.aten.mul.Tensor(convert_element_type_793, view_571);  convert_element_type_793 = view_571 = None
    view_572 = torch.ops.aten.reshape.default(mul_429, [1, 6144]);  mul_429 = None
    permute_331 = torch.ops.aten.permute.default(arg329_1, [1, 0]);  arg329_1 = None
    mm_162 = torch.ops.aten.mm.default(view_572, permute_331);  view_572 = permute_331 = None
    view_573 = torch.ops.aten.reshape.default(mm_162, [1, 1, 2048]);  mm_162 = None
    add_351 = torch.ops.aten.add.Tensor(add_347, view_573);  add_347 = view_573 = None
    convert_element_type_798 = torch.ops.prims.convert_element_type.default(add_351, torch.float32)
    pow_69 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_798, 2)
    mean_68 = torch.ops.aten.mean.dim(pow_69, [-1], True);  pow_69 = None
    add_352 = torch.ops.aten.add.Tensor(mean_68, 1e-06);  mean_68 = None
    rsqrt_100 = torch.ops.aten.rsqrt.default(add_352);  add_352 = None
    mul_430 = torch.ops.aten.mul.Tensor(convert_element_type_798, rsqrt_100);  convert_element_type_798 = rsqrt_100 = None
    convert_element_type_799 = torch.ops.prims.convert_element_type.default(arg330_1, torch.float32);  arg330_1 = None
    add_353 = torch.ops.aten.add.Tensor(convert_element_type_799, 1.0);  convert_element_type_799 = None
    mul_431 = torch.ops.aten.mul.Tensor(mul_430, add_353);  mul_430 = add_353 = None
    convert_element_type_800 = torch.ops.prims.convert_element_type.default(mul_431, torch.bfloat16);  mul_431 = None
    view_574 = torch.ops.aten.reshape.default(convert_element_type_800, [1, 2048])
    permute_332 = torch.ops.aten.permute.default(arg331_1, [1, 0]);  arg331_1 = None
    mm_163 = torch.ops.aten.mm.default(view_574, permute_332);  view_574 = permute_332 = None
    view_575 = torch.ops.aten.reshape.default(mm_163, [1, 1, 6144]);  mm_163 = None
    permute_333 = torch.ops.aten.permute.default(view_575, [0, 2, 1]);  view_575 = None
    cat_36 = torch.ops.aten.cat.default([arg335_1, permute_333], -1);  permute_333 = None
    slice_154 = torch.ops.aten.slice.Tensor(cat_36, 2, -4, 9223372036854775807)
    copy_52 = torch.ops.aten.copy.default(arg335_1, slice_154);  slice_154 = None
    convert_element_type_809 = torch.ops.prims.convert_element_type.default(cat_36, torch.float32);  cat_36 = None
    slice_155 = torch.ops.aten.slice.Tensor(convert_element_type_809, 2, 0, 2)
    squeeze_16 = torch.ops.aten.squeeze.dim(arg336_1, 1);  arg336_1 = None
    unsqueeze_176 = torch.ops.aten.unsqueeze.default(squeeze_16, 1);  squeeze_16 = None
    convert_element_type_810 = torch.ops.prims.convert_element_type.default(unsqueeze_176, torch.float32);  unsqueeze_176 = None
    select_265 = torch.ops.aten.select.int(convert_element_type_810, 1, 0)
    select_266 = torch.ops.aten.select.int(select_265, 1, 0);  select_265 = None
    view_583 = torch.ops.aten.reshape.default(select_266, [1, -1, 1]);  select_266 = None
    mul_432 = torch.ops.aten.mul.Tensor(slice_155, view_583);  slice_155 = view_583 = None
    slice_156 = torch.ops.aten.slice.Tensor(convert_element_type_809, 2, 1, 3)
    select_267 = torch.ops.aten.select.int(convert_element_type_810, 1, 0)
    select_268 = torch.ops.aten.select.int(select_267, 1, 1);  select_267 = None
    view_584 = torch.ops.aten.reshape.default(select_268, [1, -1, 1]);  select_268 = None
    mul_433 = torch.ops.aten.mul.Tensor(slice_156, view_584);  slice_156 = view_584 = None
    add_354 = torch.ops.aten.add.Tensor(mul_432, mul_433);  mul_432 = mul_433 = None
    slice_157 = torch.ops.aten.slice.Tensor(convert_element_type_809, 2, 2, 4)
    select_269 = torch.ops.aten.select.int(convert_element_type_810, 1, 0)
    select_270 = torch.ops.aten.select.int(select_269, 1, 2);  select_269 = None
    view_585 = torch.ops.aten.reshape.default(select_270, [1, -1, 1]);  select_270 = None
    mul_434 = torch.ops.aten.mul.Tensor(slice_157, view_585);  slice_157 = view_585 = None
    add_355 = torch.ops.aten.add.Tensor(add_354, mul_434);  add_354 = mul_434 = None
    slice_158 = torch.ops.aten.slice.Tensor(convert_element_type_809, 2, 3, 5);  convert_element_type_809 = None
    select_271 = torch.ops.aten.select.int(convert_element_type_810, 1, 0);  convert_element_type_810 = None
    select_272 = torch.ops.aten.select.int(select_271, 1, 3);  select_271 = None
    view_586 = torch.ops.aten.reshape.default(select_272, [1, -1, 1]);  select_272 = None
    mul_435 = torch.ops.aten.mul.Tensor(slice_158, view_586);  slice_158 = view_586 = None
    add_356 = torch.ops.aten.add.Tensor(add_355, mul_435);  add_355 = mul_435 = None
    convert_element_type_811 = torch.ops.prims.convert_element_type.default(add_356, torch.bfloat16);  add_356 = None
    slice_159 = torch.ops.aten.slice.Tensor(convert_element_type_811, 2, -1, 9223372036854775807);  convert_element_type_811 = None
    convert_element_type_812 = torch.ops.prims.convert_element_type.default(slice_159, torch.float32);  slice_159 = None
    neg_79 = torch.ops.aten.neg.default(convert_element_type_812)
    exp_106 = torch.ops.aten.exp.default(neg_79);  neg_79 = None
    add_357 = torch.ops.aten.add.Tensor(exp_106, 1);  exp_106 = None
    div_74 = torch.ops.aten.div.Tensor(convert_element_type_812, add_357);  convert_element_type_812 = add_357 = None
    convert_element_type_813 = torch.ops.prims.convert_element_type.default(div_74, torch.bfloat16);  div_74 = None
    permute_337 = torch.ops.aten.permute.default(convert_element_type_813, [0, 2, 1]);  convert_element_type_813 = None
    split_with_sizes_16 = torch.ops.aten.split_with_sizes.default(permute_337, [2048, 2048, 2048], -1);  permute_337 = None
    getitem_58 = split_with_sizes_16[0]
    getitem_59 = split_with_sizes_16[1]
    getitem_60 = split_with_sizes_16[2];  split_with_sizes_16 = None
    full_default_18 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_278 = torch.ops.aten.select.int(full_default_18, 2, 0);  select_278 = None
    view_588 = torch.ops.aten.reshape.default(getitem_59, [1, 1, -1, 128]);  getitem_59 = None
    permute_339 = torch.ops.aten.permute.default(view_588, [0, 2, 1, 3]);  view_588 = None
    convert_element_type_816 = torch.ops.prims.convert_element_type.default(permute_339, torch.float32);  permute_339 = None
    clone_84 = torch.ops.aten.clone.default(convert_element_type_816, memory_format = torch.contiguous_format);  convert_element_type_816 = None
    mul_439 = torch.ops.aten.mul.Tensor(clone_84, clone_84)
    sum_71 = torch.ops.aten.sum.dim_IntList(mul_439, [-1], True);  mul_439 = None
    add_360 = torch.ops.aten.add.Tensor(sum_71, 1e-06);  sum_71 = None
    rsqrt_102 = torch.ops.aten.rsqrt.default(add_360);  add_360 = None
    mul_440 = torch.ops.aten.mul.Tensor(clone_84, rsqrt_102);  clone_84 = rsqrt_102 = None
    select_274 = torch.ops.aten.select.int(mul_440, 2, 0);  mul_440 = None
    unsqueeze_181 = torch.ops.aten.unsqueeze.default(select_274, -1)
    view_589 = torch.ops.aten.reshape.default(getitem_60, [1, 1, -1, 128]);  getitem_60 = None
    permute_340 = torch.ops.aten.permute.default(view_589, [0, 2, 1, 3]);  view_589 = None
    convert_element_type_817 = torch.ops.prims.convert_element_type.default(permute_340, torch.float32);  permute_340 = None
    clone_85 = torch.ops.aten.clone.default(convert_element_type_817, memory_format = torch.contiguous_format);  convert_element_type_817 = None
    select_275 = torch.ops.aten.select.int(clone_85, 2, 0);  clone_85 = None
    exp_107 = torch.ops.aten.exp.default(arg337_1);  arg337_1 = None
    neg_80 = torch.ops.aten.neg.default(exp_107);  exp_107 = None
    view_581 = torch.ops.aten.reshape.default(convert_element_type_800, [1, 2048])
    permute_336 = torch.ops.aten.permute.default(arg334_1, [1, 0]);  arg334_1 = None
    mm_166 = torch.ops.aten.mm.default(view_581, permute_336);  view_581 = permute_336 = None
    view_582 = torch.ops.aten.reshape.default(mm_166, [1, 1, 16]);  mm_166 = None
    convert_element_type_814 = torch.ops.prims.convert_element_type.default(view_582, torch.float32);  view_582 = None
    add_358 = torch.ops.aten.add.Tensor(convert_element_type_814, arg338_1);  convert_element_type_814 = arg338_1 = None
    gt_16 = torch.ops.aten.gt.Scalar(add_358, 20)
    exp_108 = torch.ops.aten.exp.default(add_358)
    log1p_16 = torch.ops.aten.log1p.default(exp_108);  exp_108 = None
    where_17 = torch.ops.aten.where.self(gt_16, add_358, log1p_16);  gt_16 = add_358 = log1p_16 = None
    mul_436 = torch.ops.aten.mul.Tensor(neg_80, where_17);  neg_80 = where_17 = None
    permute_342 = torch.ops.aten.permute.default(mul_436, [0, 2, 1]);  mul_436 = None
    select_276 = torch.ops.aten.select.int(permute_342, 2, 0);  permute_342 = None
    exp_109 = torch.ops.aten.exp.default(select_276);  select_276 = None
    unsqueeze_177 = torch.ops.aten.unsqueeze.default(exp_109, 2);  exp_109 = None
    unsqueeze_178 = torch.ops.aten.unsqueeze.default(unsqueeze_177, 3);  unsqueeze_177 = None
    mul_441 = torch.ops.aten.mul.Tensor(arg339_1, unsqueeze_178);  unsqueeze_178 = None
    unsqueeze_180 = torch.ops.aten.unsqueeze.default(select_274, -1);  select_274 = None
    mul_442 = torch.ops.aten.mul.Tensor(mul_441, unsqueeze_180);  unsqueeze_180 = None
    sum_72 = torch.ops.aten.sum.dim_IntList(mul_442, [-2]);  mul_442 = None
    sub_21 = torch.ops.aten.sub.Tensor(select_275, sum_72);  select_275 = sum_72 = None
    view_579 = torch.ops.aten.reshape.default(convert_element_type_800, [1, 2048])
    permute_335 = torch.ops.aten.permute.default(arg333_1, [1, 0]);  arg333_1 = None
    mm_165 = torch.ops.aten.mm.default(view_579, permute_335);  view_579 = permute_335 = None
    view_580 = torch.ops.aten.reshape.default(mm_165, [1, 1, 16]);  mm_165 = None
    sigmoid_21 = torch.ops.aten.sigmoid.default(view_580);  view_580 = None
    permute_341 = torch.ops.aten.permute.default(sigmoid_21, [0, 2, 1]);  sigmoid_21 = None
    convert_element_type_818 = torch.ops.prims.convert_element_type.default(permute_341, torch.float32);  permute_341 = None
    clone_86 = torch.ops.aten.clone.default(convert_element_type_818, memory_format = torch.contiguous_format);  convert_element_type_818 = None
    select_277 = torch.ops.aten.select.int(clone_86, 2, 0);  clone_86 = None
    unsqueeze_179 = torch.ops.aten.unsqueeze.default(select_277, -1);  select_277 = None
    mul_443 = torch.ops.aten.mul.Tensor(sub_21, unsqueeze_179);  sub_21 = unsqueeze_179 = None
    unsqueeze_182 = torch.ops.aten.unsqueeze.default(mul_443, -2);  mul_443 = None
    mul_444 = torch.ops.aten.mul.Tensor(unsqueeze_181, unsqueeze_182);  unsqueeze_181 = unsqueeze_182 = None
    add_361 = torch.ops.aten.add.Tensor(mul_441, mul_444);  mul_441 = mul_444 = None
    view_587 = torch.ops.aten.reshape.default(getitem_58, [1, 1, -1, 128]);  getitem_58 = None
    permute_338 = torch.ops.aten.permute.default(view_587, [0, 2, 1, 3]);  view_587 = None
    convert_element_type_815 = torch.ops.prims.convert_element_type.default(permute_338, torch.float32);  permute_338 = None
    clone_83 = torch.ops.aten.clone.default(convert_element_type_815, memory_format = torch.contiguous_format);  convert_element_type_815 = None
    mul_437 = torch.ops.aten.mul.Tensor(clone_83, clone_83)
    sum_70 = torch.ops.aten.sum.dim_IntList(mul_437, [-1], True);  mul_437 = None
    add_359 = torch.ops.aten.add.Tensor(sum_70, 1e-06);  sum_70 = None
    rsqrt_101 = torch.ops.aten.rsqrt.default(add_359);  add_359 = None
    mul_438 = torch.ops.aten.mul.Tensor(clone_83, rsqrt_101);  clone_83 = rsqrt_101 = None
    div_75 = torch.ops.aten.div.Tensor(mul_438, 11.313708498984761);  mul_438 = None
    select_273 = torch.ops.aten.select.int(div_75, 2, 0);  div_75 = None
    unsqueeze_183 = torch.ops.aten.unsqueeze.default(select_273, -1);  select_273 = None
    mul_445 = torch.ops.aten.mul.Tensor(add_361, unsqueeze_183);  unsqueeze_183 = None
    sum_73 = torch.ops.aten.sum.dim_IntList(mul_445, [-2]);  mul_445 = None
    select_scatter_default_20 = torch.ops.aten.select_scatter.default(full_default_18, sum_73, 2, 0);  full_default_18 = sum_73 = None
    permute_344 = torch.ops.aten.permute.default(select_scatter_default_20, [0, 2, 1, 3]);  select_scatter_default_20 = None
    convert_element_type_819 = torch.ops.prims.convert_element_type.default(permute_344, torch.bfloat16);  permute_344 = None
    view_590 = torch.ops.aten.reshape.default(convert_element_type_819, [-1, 128]);  convert_element_type_819 = None
    convert_element_type_820 = torch.ops.prims.convert_element_type.default(view_590, torch.float32);  view_590 = None
    pow_70 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_820, 2)
    mean_69 = torch.ops.aten.mean.dim(pow_70, [-1], True);  pow_70 = None
    add_362 = torch.ops.aten.add.Tensor(mean_69, 1e-06);  mean_69 = None
    rsqrt_103 = torch.ops.aten.rsqrt.default(add_362);  add_362 = None
    mul_446 = torch.ops.aten.mul.Tensor(convert_element_type_820, rsqrt_103);  convert_element_type_820 = rsqrt_103 = None
    convert_element_type_821 = torch.ops.prims.convert_element_type.default(mul_446, torch.bfloat16);  mul_446 = None
    mul_447 = torch.ops.aten.mul.Tensor(arg340_1, convert_element_type_821);  arg340_1 = convert_element_type_821 = None
    view_576 = torch.ops.aten.reshape.default(convert_element_type_800, [1, 2048]);  convert_element_type_800 = None
    permute_334 = torch.ops.aten.permute.default(arg332_1, [1, 0]);  arg332_1 = None
    mm_164 = torch.ops.aten.mm.default(view_576, permute_334);  view_576 = permute_334 = None
    view_577 = torch.ops.aten.reshape.default(mm_164, [1, 1, 2048]);  mm_164 = None
    view_578 = torch.ops.aten.reshape.default(view_577, [1, 1, -1, 128]);  view_577 = None
    view_591 = torch.ops.aten.reshape.default(view_578, [-1, 128]);  view_578 = None
    convert_element_type_822 = torch.ops.prims.convert_element_type.default(view_591, torch.float32);  view_591 = None
    neg_81 = torch.ops.aten.neg.default(convert_element_type_822)
    exp_110 = torch.ops.aten.exp.default(neg_81);  neg_81 = None
    add_363 = torch.ops.aten.add.Tensor(exp_110, 1);  exp_110 = None
    div_76 = torch.ops.aten.div.Tensor(convert_element_type_822, add_363);  convert_element_type_822 = add_363 = None
    mul_448 = torch.ops.aten.mul.Tensor(mul_447, div_76);  mul_447 = div_76 = None
    convert_element_type_823 = torch.ops.prims.convert_element_type.default(mul_448, torch.bfloat16);  mul_448 = None
    view_592 = torch.ops.aten.reshape.default(convert_element_type_823, [1, 1, -1]);  convert_element_type_823 = None
    view_593 = torch.ops.aten.reshape.default(view_592, [1, 2048]);  view_592 = None
    permute_345 = torch.ops.aten.permute.default(arg341_1, [1, 0]);  arg341_1 = None
    mm_167 = torch.ops.aten.mm.default(view_593, permute_345);  view_593 = permute_345 = None
    view_594 = torch.ops.aten.reshape.default(mm_167, [1, 1, 2048]);  mm_167 = None
    add_364 = torch.ops.aten.add.Tensor(add_351, view_594);  add_351 = view_594 = None
    convert_element_type_826 = torch.ops.prims.convert_element_type.default(add_364, torch.float32)
    pow_71 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_826, 2)
    mean_70 = torch.ops.aten.mean.dim(pow_71, [-1], True);  pow_71 = None
    add_365 = torch.ops.aten.add.Tensor(mean_70, 1e-06);  mean_70 = None
    rsqrt_104 = torch.ops.aten.rsqrt.default(add_365);  add_365 = None
    mul_449 = torch.ops.aten.mul.Tensor(convert_element_type_826, rsqrt_104);  convert_element_type_826 = rsqrt_104 = None
    convert_element_type_827 = torch.ops.prims.convert_element_type.default(arg342_1, torch.float32);  arg342_1 = None
    add_366 = torch.ops.aten.add.Tensor(convert_element_type_827, 1.0);  convert_element_type_827 = None
    mul_450 = torch.ops.aten.mul.Tensor(mul_449, add_366);  mul_449 = add_366 = None
    convert_element_type_828 = torch.ops.prims.convert_element_type.default(mul_450, torch.bfloat16);  mul_450 = None
    view_595 = torch.ops.aten.reshape.default(convert_element_type_828, [1, 2048])
    permute_346 = torch.ops.aten.permute.default(arg343_1, [1, 0]);  arg343_1 = None
    mm_168 = torch.ops.aten.mm.default(view_595, permute_346);  view_595 = permute_346 = None
    view_596 = torch.ops.aten.reshape.default(mm_168, [1, 1, 6144]);  mm_168 = None
    convert_element_type_831 = torch.ops.prims.convert_element_type.default(view_596, torch.float32);  view_596 = None
    neg_82 = torch.ops.aten.neg.default(convert_element_type_831)
    exp_111 = torch.ops.aten.exp.default(neg_82);  neg_82 = None
    add_367 = torch.ops.aten.add.Tensor(exp_111, 1);  exp_111 = None
    div_77 = torch.ops.aten.div.Tensor(convert_element_type_831, add_367);  convert_element_type_831 = add_367 = None
    convert_element_type_832 = torch.ops.prims.convert_element_type.default(div_77, torch.bfloat16);  div_77 = None
    view_597 = torch.ops.aten.reshape.default(convert_element_type_828, [1, 2048]);  convert_element_type_828 = None
    permute_347 = torch.ops.aten.permute.default(arg344_1, [1, 0]);  arg344_1 = None
    mm_169 = torch.ops.aten.mm.default(view_597, permute_347);  view_597 = permute_347 = None
    view_598 = torch.ops.aten.reshape.default(mm_169, [1, 1, 6144]);  mm_169 = None
    mul_451 = torch.ops.aten.mul.Tensor(convert_element_type_832, view_598);  convert_element_type_832 = view_598 = None
    view_599 = torch.ops.aten.reshape.default(mul_451, [1, 6144]);  mul_451 = None
    permute_348 = torch.ops.aten.permute.default(arg345_1, [1, 0]);  arg345_1 = None
    mm_170 = torch.ops.aten.mm.default(view_599, permute_348);  view_599 = permute_348 = None
    view_600 = torch.ops.aten.reshape.default(mm_170, [1, 1, 2048]);  mm_170 = None
    add_368 = torch.ops.aten.add.Tensor(add_364, view_600);  add_364 = view_600 = None
    convert_element_type_837 = torch.ops.prims.convert_element_type.default(add_368, torch.float32)
    pow_72 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_837, 2)
    mean_71 = torch.ops.aten.mean.dim(pow_72, [-1], True);  pow_72 = None
    add_369 = torch.ops.aten.add.Tensor(mean_71, 1e-06);  mean_71 = None
    rsqrt_105 = torch.ops.aten.rsqrt.default(add_369);  add_369 = None
    mul_452 = torch.ops.aten.mul.Tensor(convert_element_type_837, rsqrt_105);  convert_element_type_837 = rsqrt_105 = None
    convert_element_type_838 = torch.ops.prims.convert_element_type.default(arg346_1, torch.float32);  arg346_1 = None
    add_370 = torch.ops.aten.add.Tensor(convert_element_type_838, 1.0);  convert_element_type_838 = None
    mul_453 = torch.ops.aten.mul.Tensor(mul_452, add_370);  mul_452 = add_370 = None
    convert_element_type_839 = torch.ops.prims.convert_element_type.default(mul_453, torch.bfloat16);  mul_453 = None
    view_601 = torch.ops.aten.reshape.default(convert_element_type_839, [1, 2048])
    permute_349 = torch.ops.aten.permute.default(arg347_1, [1, 0]);  arg347_1 = None
    mm_171 = torch.ops.aten.mm.default(view_601, permute_349);  view_601 = permute_349 = None
    view_602 = torch.ops.aten.reshape.default(mm_171, [1, 1, 6144]);  mm_171 = None
    permute_350 = torch.ops.aten.permute.default(view_602, [0, 2, 1]);  view_602 = None
    cat_37 = torch.ops.aten.cat.default([arg351_1, permute_350], -1);  permute_350 = None
    slice_160 = torch.ops.aten.slice.Tensor(cat_37, 2, -4, 9223372036854775807)
    copy_55 = torch.ops.aten.copy.default(arg351_1, slice_160);  slice_160 = None
    convert_element_type_848 = torch.ops.prims.convert_element_type.default(cat_37, torch.float32);  cat_37 = None
    slice_161 = torch.ops.aten.slice.Tensor(convert_element_type_848, 2, 0, 2)
    squeeze_17 = torch.ops.aten.squeeze.dim(arg352_1, 1);  arg352_1 = None
    unsqueeze_184 = torch.ops.aten.unsqueeze.default(squeeze_17, 1);  squeeze_17 = None
    convert_element_type_849 = torch.ops.prims.convert_element_type.default(unsqueeze_184, torch.float32);  unsqueeze_184 = None
    select_280 = torch.ops.aten.select.int(convert_element_type_849, 1, 0)
    select_281 = torch.ops.aten.select.int(select_280, 1, 0);  select_280 = None
    view_610 = torch.ops.aten.reshape.default(select_281, [1, -1, 1]);  select_281 = None
    mul_454 = torch.ops.aten.mul.Tensor(slice_161, view_610);  slice_161 = view_610 = None
    slice_162 = torch.ops.aten.slice.Tensor(convert_element_type_848, 2, 1, 3)
    select_282 = torch.ops.aten.select.int(convert_element_type_849, 1, 0)
    select_283 = torch.ops.aten.select.int(select_282, 1, 1);  select_282 = None
    view_611 = torch.ops.aten.reshape.default(select_283, [1, -1, 1]);  select_283 = None
    mul_455 = torch.ops.aten.mul.Tensor(slice_162, view_611);  slice_162 = view_611 = None
    add_371 = torch.ops.aten.add.Tensor(mul_454, mul_455);  mul_454 = mul_455 = None
    slice_163 = torch.ops.aten.slice.Tensor(convert_element_type_848, 2, 2, 4)
    select_284 = torch.ops.aten.select.int(convert_element_type_849, 1, 0)
    select_285 = torch.ops.aten.select.int(select_284, 1, 2);  select_284 = None
    view_612 = torch.ops.aten.reshape.default(select_285, [1, -1, 1]);  select_285 = None
    mul_456 = torch.ops.aten.mul.Tensor(slice_163, view_612);  slice_163 = view_612 = None
    add_372 = torch.ops.aten.add.Tensor(add_371, mul_456);  add_371 = mul_456 = None
    slice_164 = torch.ops.aten.slice.Tensor(convert_element_type_848, 2, 3, 5);  convert_element_type_848 = None
    select_286 = torch.ops.aten.select.int(convert_element_type_849, 1, 0);  convert_element_type_849 = None
    select_287 = torch.ops.aten.select.int(select_286, 1, 3);  select_286 = None
    view_613 = torch.ops.aten.reshape.default(select_287, [1, -1, 1]);  select_287 = None
    mul_457 = torch.ops.aten.mul.Tensor(slice_164, view_613);  slice_164 = view_613 = None
    add_373 = torch.ops.aten.add.Tensor(add_372, mul_457);  add_372 = mul_457 = None
    convert_element_type_850 = torch.ops.prims.convert_element_type.default(add_373, torch.bfloat16);  add_373 = None
    slice_165 = torch.ops.aten.slice.Tensor(convert_element_type_850, 2, -1, 9223372036854775807);  convert_element_type_850 = None
    convert_element_type_851 = torch.ops.prims.convert_element_type.default(slice_165, torch.float32);  slice_165 = None
    neg_83 = torch.ops.aten.neg.default(convert_element_type_851)
    exp_112 = torch.ops.aten.exp.default(neg_83);  neg_83 = None
    add_374 = torch.ops.aten.add.Tensor(exp_112, 1);  exp_112 = None
    div_78 = torch.ops.aten.div.Tensor(convert_element_type_851, add_374);  convert_element_type_851 = add_374 = None
    convert_element_type_852 = torch.ops.prims.convert_element_type.default(div_78, torch.bfloat16);  div_78 = None
    permute_354 = torch.ops.aten.permute.default(convert_element_type_852, [0, 2, 1]);  convert_element_type_852 = None
    split_with_sizes_17 = torch.ops.aten.split_with_sizes.default(permute_354, [2048, 2048, 2048], -1);  permute_354 = None
    getitem_61 = split_with_sizes_17[0]
    getitem_62 = split_with_sizes_17[1]
    getitem_63 = split_with_sizes_17[2];  split_with_sizes_17 = None
    full_default_19 = torch.ops.aten.full.default([1, 16, 1, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    select_293 = torch.ops.aten.select.int(full_default_19, 2, 0);  select_293 = None
    view_615 = torch.ops.aten.reshape.default(getitem_62, [1, 1, -1, 128]);  getitem_62 = None
    permute_356 = torch.ops.aten.permute.default(view_615, [0, 2, 1, 3]);  view_615 = None
    convert_element_type_855 = torch.ops.prims.convert_element_type.default(permute_356, torch.float32);  permute_356 = None
    clone_88 = torch.ops.aten.clone.default(convert_element_type_855, memory_format = torch.contiguous_format);  convert_element_type_855 = None
    mul_461 = torch.ops.aten.mul.Tensor(clone_88, clone_88)
    sum_75 = torch.ops.aten.sum.dim_IntList(mul_461, [-1], True);  mul_461 = None
    add_377 = torch.ops.aten.add.Tensor(sum_75, 1e-06);  sum_75 = None
    rsqrt_107 = torch.ops.aten.rsqrt.default(add_377);  add_377 = None
    mul_462 = torch.ops.aten.mul.Tensor(clone_88, rsqrt_107);  clone_88 = rsqrt_107 = None
    select_289 = torch.ops.aten.select.int(mul_462, 2, 0);  mul_462 = None
    unsqueeze_189 = torch.ops.aten.unsqueeze.default(select_289, -1)
    view_616 = torch.ops.aten.reshape.default(getitem_63, [1, 1, -1, 128]);  getitem_63 = None
    permute_357 = torch.ops.aten.permute.default(view_616, [0, 2, 1, 3]);  view_616 = None
    convert_element_type_856 = torch.ops.prims.convert_element_type.default(permute_357, torch.float32);  permute_357 = None
    clone_89 = torch.ops.aten.clone.default(convert_element_type_856, memory_format = torch.contiguous_format);  convert_element_type_856 = None
    select_290 = torch.ops.aten.select.int(clone_89, 2, 0);  clone_89 = None
    exp_113 = torch.ops.aten.exp.default(arg353_1);  arg353_1 = None
    neg_84 = torch.ops.aten.neg.default(exp_113);  exp_113 = None
    view_608 = torch.ops.aten.reshape.default(convert_element_type_839, [1, 2048])
    permute_353 = torch.ops.aten.permute.default(arg350_1, [1, 0]);  arg350_1 = None
    mm_174 = torch.ops.aten.mm.default(view_608, permute_353);  view_608 = permute_353 = None
    view_609 = torch.ops.aten.reshape.default(mm_174, [1, 1, 16]);  mm_174 = None
    convert_element_type_853 = torch.ops.prims.convert_element_type.default(view_609, torch.float32);  view_609 = None
    add_375 = torch.ops.aten.add.Tensor(convert_element_type_853, arg354_1);  convert_element_type_853 = arg354_1 = None
    gt_17 = torch.ops.aten.gt.Scalar(add_375, 20)
    exp_114 = torch.ops.aten.exp.default(add_375)
    log1p_17 = torch.ops.aten.log1p.default(exp_114);  exp_114 = None
    where_18 = torch.ops.aten.where.self(gt_17, add_375, log1p_17);  gt_17 = add_375 = log1p_17 = None
    mul_458 = torch.ops.aten.mul.Tensor(neg_84, where_18);  neg_84 = where_18 = None
    permute_359 = torch.ops.aten.permute.default(mul_458, [0, 2, 1]);  mul_458 = None
    select_291 = torch.ops.aten.select.int(permute_359, 2, 0);  permute_359 = None
    exp_115 = torch.ops.aten.exp.default(select_291);  select_291 = None
    unsqueeze_185 = torch.ops.aten.unsqueeze.default(exp_115, 2);  exp_115 = None
    unsqueeze_186 = torch.ops.aten.unsqueeze.default(unsqueeze_185, 3);  unsqueeze_185 = None
    mul_463 = torch.ops.aten.mul.Tensor(arg355_1, unsqueeze_186);  unsqueeze_186 = None
    unsqueeze_188 = torch.ops.aten.unsqueeze.default(select_289, -1);  select_289 = None
    mul_464 = torch.ops.aten.mul.Tensor(mul_463, unsqueeze_188);  unsqueeze_188 = None
    sum_76 = torch.ops.aten.sum.dim_IntList(mul_464, [-2]);  mul_464 = None
    sub_22 = torch.ops.aten.sub.Tensor(select_290, sum_76);  select_290 = sum_76 = None
    view_606 = torch.ops.aten.reshape.default(convert_element_type_839, [1, 2048])
    permute_352 = torch.ops.aten.permute.default(arg349_1, [1, 0]);  arg349_1 = None
    mm_173 = torch.ops.aten.mm.default(view_606, permute_352);  view_606 = permute_352 = None
    view_607 = torch.ops.aten.reshape.default(mm_173, [1, 1, 16]);  mm_173 = None
    sigmoid_22 = torch.ops.aten.sigmoid.default(view_607);  view_607 = None
    permute_358 = torch.ops.aten.permute.default(sigmoid_22, [0, 2, 1]);  sigmoid_22 = None
    convert_element_type_857 = torch.ops.prims.convert_element_type.default(permute_358, torch.float32);  permute_358 = None
    clone_90 = torch.ops.aten.clone.default(convert_element_type_857, memory_format = torch.contiguous_format);  convert_element_type_857 = None
    select_292 = torch.ops.aten.select.int(clone_90, 2, 0);  clone_90 = None
    unsqueeze_187 = torch.ops.aten.unsqueeze.default(select_292, -1);  select_292 = None
    mul_465 = torch.ops.aten.mul.Tensor(sub_22, unsqueeze_187);  sub_22 = unsqueeze_187 = None
    unsqueeze_190 = torch.ops.aten.unsqueeze.default(mul_465, -2);  mul_465 = None
    mul_466 = torch.ops.aten.mul.Tensor(unsqueeze_189, unsqueeze_190);  unsqueeze_189 = unsqueeze_190 = None
    add_378 = torch.ops.aten.add.Tensor(mul_463, mul_466);  mul_463 = mul_466 = None
    view_614 = torch.ops.aten.reshape.default(getitem_61, [1, 1, -1, 128]);  getitem_61 = None
    permute_355 = torch.ops.aten.permute.default(view_614, [0, 2, 1, 3]);  view_614 = None
    convert_element_type_854 = torch.ops.prims.convert_element_type.default(permute_355, torch.float32);  permute_355 = None
    clone_87 = torch.ops.aten.clone.default(convert_element_type_854, memory_format = torch.contiguous_format);  convert_element_type_854 = None
    mul_459 = torch.ops.aten.mul.Tensor(clone_87, clone_87)
    sum_74 = torch.ops.aten.sum.dim_IntList(mul_459, [-1], True);  mul_459 = None
    add_376 = torch.ops.aten.add.Tensor(sum_74, 1e-06);  sum_74 = None
    rsqrt_106 = torch.ops.aten.rsqrt.default(add_376);  add_376 = None
    mul_460 = torch.ops.aten.mul.Tensor(clone_87, rsqrt_106);  clone_87 = rsqrt_106 = None
    div_79 = torch.ops.aten.div.Tensor(mul_460, 11.313708498984761);  mul_460 = None
    select_288 = torch.ops.aten.select.int(div_79, 2, 0);  div_79 = None
    unsqueeze_191 = torch.ops.aten.unsqueeze.default(select_288, -1);  select_288 = None
    mul_467 = torch.ops.aten.mul.Tensor(add_378, unsqueeze_191);  unsqueeze_191 = None
    sum_77 = torch.ops.aten.sum.dim_IntList(mul_467, [-2]);  mul_467 = None
    select_scatter_default_21 = torch.ops.aten.select_scatter.default(full_default_19, sum_77, 2, 0);  full_default_19 = sum_77 = None
    permute_361 = torch.ops.aten.permute.default(select_scatter_default_21, [0, 2, 1, 3]);  select_scatter_default_21 = None
    convert_element_type_858 = torch.ops.prims.convert_element_type.default(permute_361, torch.bfloat16);  permute_361 = None
    view_617 = torch.ops.aten.reshape.default(convert_element_type_858, [-1, 128]);  convert_element_type_858 = None
    convert_element_type_859 = torch.ops.prims.convert_element_type.default(view_617, torch.float32);  view_617 = None
    pow_73 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_859, 2)
    mean_72 = torch.ops.aten.mean.dim(pow_73, [-1], True);  pow_73 = None
    add_379 = torch.ops.aten.add.Tensor(mean_72, 1e-06);  mean_72 = None
    rsqrt_108 = torch.ops.aten.rsqrt.default(add_379);  add_379 = None
    mul_468 = torch.ops.aten.mul.Tensor(convert_element_type_859, rsqrt_108);  convert_element_type_859 = rsqrt_108 = None
    convert_element_type_860 = torch.ops.prims.convert_element_type.default(mul_468, torch.bfloat16);  mul_468 = None
    mul_469 = torch.ops.aten.mul.Tensor(arg356_1, convert_element_type_860);  arg356_1 = convert_element_type_860 = None
    view_603 = torch.ops.aten.reshape.default(convert_element_type_839, [1, 2048]);  convert_element_type_839 = None
    permute_351 = torch.ops.aten.permute.default(arg348_1, [1, 0]);  arg348_1 = None
    mm_172 = torch.ops.aten.mm.default(view_603, permute_351);  view_603 = permute_351 = None
    view_604 = torch.ops.aten.reshape.default(mm_172, [1, 1, 2048]);  mm_172 = None
    view_605 = torch.ops.aten.reshape.default(view_604, [1, 1, -1, 128]);  view_604 = None
    view_618 = torch.ops.aten.reshape.default(view_605, [-1, 128]);  view_605 = None
    convert_element_type_861 = torch.ops.prims.convert_element_type.default(view_618, torch.float32);  view_618 = None
    neg_85 = torch.ops.aten.neg.default(convert_element_type_861)
    exp_116 = torch.ops.aten.exp.default(neg_85);  neg_85 = None
    add_380 = torch.ops.aten.add.Tensor(exp_116, 1);  exp_116 = None
    div_80 = torch.ops.aten.div.Tensor(convert_element_type_861, add_380);  convert_element_type_861 = add_380 = None
    mul_470 = torch.ops.aten.mul.Tensor(mul_469, div_80);  mul_469 = div_80 = None
    convert_element_type_862 = torch.ops.prims.convert_element_type.default(mul_470, torch.bfloat16);  mul_470 = None
    view_619 = torch.ops.aten.reshape.default(convert_element_type_862, [1, 1, -1]);  convert_element_type_862 = None
    view_620 = torch.ops.aten.reshape.default(view_619, [1, 2048]);  view_619 = None
    permute_362 = torch.ops.aten.permute.default(arg357_1, [1, 0]);  arg357_1 = None
    mm_175 = torch.ops.aten.mm.default(view_620, permute_362);  view_620 = permute_362 = None
    view_621 = torch.ops.aten.reshape.default(mm_175, [1, 1, 2048]);  mm_175 = None
    add_381 = torch.ops.aten.add.Tensor(add_368, view_621);  add_368 = view_621 = None
    convert_element_type_865 = torch.ops.prims.convert_element_type.default(add_381, torch.float32)
    pow_74 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_865, 2)
    mean_73 = torch.ops.aten.mean.dim(pow_74, [-1], True);  pow_74 = None
    add_382 = torch.ops.aten.add.Tensor(mean_73, 1e-06);  mean_73 = None
    rsqrt_109 = torch.ops.aten.rsqrt.default(add_382);  add_382 = None
    mul_471 = torch.ops.aten.mul.Tensor(convert_element_type_865, rsqrt_109);  convert_element_type_865 = rsqrt_109 = None
    convert_element_type_866 = torch.ops.prims.convert_element_type.default(arg358_1, torch.float32);  arg358_1 = None
    add_383 = torch.ops.aten.add.Tensor(convert_element_type_866, 1.0);  convert_element_type_866 = None
    mul_472 = torch.ops.aten.mul.Tensor(mul_471, add_383);  mul_471 = add_383 = None
    convert_element_type_867 = torch.ops.prims.convert_element_type.default(mul_472, torch.bfloat16);  mul_472 = None
    view_622 = torch.ops.aten.reshape.default(convert_element_type_867, [1, 2048])
    permute_363 = torch.ops.aten.permute.default(arg359_1, [1, 0]);  arg359_1 = None
    mm_176 = torch.ops.aten.mm.default(view_622, permute_363);  view_622 = permute_363 = None
    view_623 = torch.ops.aten.reshape.default(mm_176, [1, 1, 6144]);  mm_176 = None
    convert_element_type_870 = torch.ops.prims.convert_element_type.default(view_623, torch.float32);  view_623 = None
    neg_86 = torch.ops.aten.neg.default(convert_element_type_870)
    exp_117 = torch.ops.aten.exp.default(neg_86);  neg_86 = None
    add_384 = torch.ops.aten.add.Tensor(exp_117, 1);  exp_117 = None
    div_81 = torch.ops.aten.div.Tensor(convert_element_type_870, add_384);  convert_element_type_870 = add_384 = None
    convert_element_type_871 = torch.ops.prims.convert_element_type.default(div_81, torch.bfloat16);  div_81 = None
    view_624 = torch.ops.aten.reshape.default(convert_element_type_867, [1, 2048]);  convert_element_type_867 = None
    permute_364 = torch.ops.aten.permute.default(arg360_1, [1, 0]);  arg360_1 = None
    mm_177 = torch.ops.aten.mm.default(view_624, permute_364);  view_624 = permute_364 = None
    view_625 = torch.ops.aten.reshape.default(mm_177, [1, 1, 6144]);  mm_177 = None
    mul_473 = torch.ops.aten.mul.Tensor(convert_element_type_871, view_625);  convert_element_type_871 = view_625 = None
    view_626 = torch.ops.aten.reshape.default(mul_473, [1, 6144]);  mul_473 = None
    permute_365 = torch.ops.aten.permute.default(arg361_1, [1, 0]);  arg361_1 = None
    mm_178 = torch.ops.aten.mm.default(view_626, permute_365);  view_626 = permute_365 = None
    view_627 = torch.ops.aten.reshape.default(mm_178, [1, 1, 2048]);  mm_178 = None
    add_385 = torch.ops.aten.add.Tensor(add_381, view_627);  add_381 = view_627 = None
    convert_element_type_876 = torch.ops.prims.convert_element_type.default(add_385, torch.float32)
    pow_75 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_876, 2)
    mean_74 = torch.ops.aten.mean.dim(pow_75, [-1], True);  pow_75 = None
    add_386 = torch.ops.aten.add.Tensor(mean_74, 1e-06);  mean_74 = None
    rsqrt_110 = torch.ops.aten.rsqrt.default(add_386);  add_386 = None
    mul_474 = torch.ops.aten.mul.Tensor(convert_element_type_876, rsqrt_110);  convert_element_type_876 = rsqrt_110 = None
    convert_element_type_877 = torch.ops.prims.convert_element_type.default(arg362_1, torch.float32);  arg362_1 = None
    add_387 = torch.ops.aten.add.Tensor(convert_element_type_877, 1.0);  convert_element_type_877 = None
    mul_475 = torch.ops.aten.mul.Tensor(mul_474, add_387);  mul_474 = add_387 = None
    convert_element_type_878 = torch.ops.prims.convert_element_type.default(mul_475, torch.bfloat16);  mul_475 = None
    view_628 = torch.ops.aten.reshape.default(convert_element_type_878, [1, 2048])
    permute_366 = torch.ops.aten.permute.default(arg363_1, [1, 0]);  arg363_1 = None
    mm_179 = torch.ops.aten.mm.default(view_628, permute_366);  view_628 = permute_366 = None
    view_629 = torch.ops.aten.reshape.default(mm_179, [1, 1, 4096]);  mm_179 = None
    view_630 = torch.ops.aten.reshape.default(view_629, [1, 1, -1, 512]);  view_629 = None
    split_5 = torch.ops.aten.split.Tensor(view_630, 256, -1);  view_630 = None
    getitem_64 = split_5[0]
    getitem_65 = split_5[1];  split_5 = None
    add_395 = torch.ops.aten.add.Tensor(arg368_1, 1)
    convert_element_type_881 = torch.ops.prims.convert_element_type.default(getitem_64, torch.float32);  getitem_64 = None
    pow_76 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_881, 2)
    mean_75 = torch.ops.aten.mean.dim(pow_76, [-1], True);  pow_76 = None
    add_388 = torch.ops.aten.add.Tensor(mean_75, 1e-06);  mean_75 = None
    rsqrt_111 = torch.ops.aten.rsqrt.default(add_388);  add_388 = None
    mul_476 = torch.ops.aten.mul.Tensor(convert_element_type_881, rsqrt_111);  convert_element_type_881 = rsqrt_111 = None
    convert_element_type_882 = torch.ops.prims.convert_element_type.default(arg364_1, torch.float32);  arg364_1 = None
    add_389 = torch.ops.aten.add.Tensor(convert_element_type_882, 1.0);  convert_element_type_882 = None
    mul_477 = torch.ops.aten.mul.Tensor(mul_476, add_389);  mul_476 = add_389 = None
    convert_element_type_883 = torch.ops.prims.convert_element_type.default(mul_477, torch.bfloat16);  mul_477 = None
    permute_367 = torch.ops.aten.permute.default(convert_element_type_883, [0, 2, 1, 3]);  convert_element_type_883 = None
    slice_166 = torch.ops.aten.slice.Tensor(permute_367, 3, 0, 64)
    unsqueeze_192 = torch.ops.aten.unsqueeze.default(convert_element_type_2, 1);  convert_element_type_2 = None
    mul_480 = torch.ops.aten.mul.Tensor(slice_166, unsqueeze_192)
    slice_171 = torch.ops.aten.slice.Tensor(slice_166, 3, 32, 9223372036854775807)
    neg_87 = torch.ops.aten.neg.default(slice_171);  slice_171 = None
    slice_170 = torch.ops.aten.slice.Tensor(slice_166, 3, 0, 32);  slice_166 = None
    cat_38 = torch.ops.aten.cat.default([neg_87, slice_170], -1);  neg_87 = slice_170 = None
    unsqueeze_193 = torch.ops.aten.unsqueeze.default(convert_element_type_3, 1);  convert_element_type_3 = None
    mul_481 = torch.ops.aten.mul.Tensor(cat_38, unsqueeze_193);  cat_38 = None
    add_392 = torch.ops.aten.add.Tensor(mul_480, mul_481);  mul_480 = mul_481 = None
    slice_167 = torch.ops.aten.slice.Tensor(permute_367, 3, 64, 9223372036854775807);  permute_367 = None
    cat_40 = torch.ops.aten.cat.default([add_392, slice_167], -1);  add_392 = slice_167 = None
    expand_48 = torch.ops.aten.expand.default(cat_40, [1, 8, 1, 256]);  cat_40 = None
    view_641 = torch.ops.aten.reshape.default(expand_48, [8, 1, 256]);  expand_48 = None
    iota_6 = torch.ops.prims.iota.default(1, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    add_394 = torch.ops.aten.add.Tensor(iota_6, arg368_1);  iota_6 = None
    view_633 = torch.ops.aten.reshape.default(convert_element_type_878, [1, 2048])
    permute_368 = torch.ops.aten.permute.default(arg365_1, [1, 0]);  arg365_1 = None
    mm_180 = torch.ops.aten.mm.default(view_633, permute_368);  view_633 = permute_368 = None
    view_634 = torch.ops.aten.reshape.default(mm_180, [1, 1, 512]);  mm_180 = None
    view_635 = torch.ops.aten.reshape.default(view_634, [1, 1, -1, 256]);  view_634 = None
    convert_element_type_886 = torch.ops.prims.convert_element_type.default(view_635, torch.float32);  view_635 = None
    pow_77 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_886, 2)
    mean_76 = torch.ops.aten.mean.dim(pow_77, [-1], True);  pow_77 = None
    add_390 = torch.ops.aten.add.Tensor(mean_76, 1e-06);  mean_76 = None
    rsqrt_112 = torch.ops.aten.rsqrt.default(add_390);  add_390 = None
    mul_478 = torch.ops.aten.mul.Tensor(convert_element_type_886, rsqrt_112);  convert_element_type_886 = rsqrt_112 = None
    convert_element_type_887 = torch.ops.prims.convert_element_type.default(arg366_1, torch.float32);  arg366_1 = None
    add_391 = torch.ops.aten.add.Tensor(convert_element_type_887, 1.0);  convert_element_type_887 = None
    mul_479 = torch.ops.aten.mul.Tensor(mul_478, add_391);  mul_478 = add_391 = None
    convert_element_type_888 = torch.ops.prims.convert_element_type.default(mul_479, torch.bfloat16);  mul_479 = None
    permute_369 = torch.ops.aten.permute.default(convert_element_type_888, [0, 2, 1, 3]);  convert_element_type_888 = None
    slice_168 = torch.ops.aten.slice.Tensor(permute_369, 3, 0, 64)
    mul_482 = torch.ops.aten.mul.Tensor(slice_168, unsqueeze_192);  unsqueeze_192 = None
    slice_173 = torch.ops.aten.slice.Tensor(slice_168, 3, 32, 9223372036854775807)
    neg_88 = torch.ops.aten.neg.default(slice_173);  slice_173 = None
    slice_172 = torch.ops.aten.slice.Tensor(slice_168, 3, 0, 32);  slice_168 = None
    cat_39 = torch.ops.aten.cat.default([neg_88, slice_172], -1);  neg_88 = slice_172 = None
    mul_483 = torch.ops.aten.mul.Tensor(cat_39, unsqueeze_193);  cat_39 = unsqueeze_193 = None
    add_393 = torch.ops.aten.add.Tensor(mul_482, mul_483);  mul_482 = mul_483 = None
    slice_169 = torch.ops.aten.slice.Tensor(permute_369, 3, 64, 9223372036854775807);  permute_369 = None
    cat_41 = torch.ops.aten.cat.default([add_393, slice_169], -1);  add_393 = slice_169 = None
    index_put_10 = torch.ops.aten.index_put_.default(arg369_1, [None, None, add_394], cat_41);  arg369_1 = cat_41 = None
    unsqueeze_196 = torch.ops.aten.unsqueeze.default(index_put_10, 2);  index_put_10 = None
    expand_45 = torch.ops.aten.expand.default(unsqueeze_196, [1, 2, 4, 144, 256]);  unsqueeze_196 = None
    clone_92 = torch.ops.aten.clone.default(expand_45, memory_format = torch.contiguous_format);  expand_45 = None
    view_639 = torch.ops.aten.reshape.default(clone_92, [1, 8, 144, 256]);  clone_92 = None
    permute_372 = torch.ops.aten.permute.default(view_639, [0, 1, 3, 2]);  view_639 = None
    expand_49 = torch.ops.aten.expand.default(permute_372, [1, 8, 256, 144]);  permute_372 = None
    view_642 = torch.ops.aten.reshape.default(expand_49, [8, 256, 144]);  expand_49 = None
    bmm_10 = torch.ops.aten.bmm.default(view_641, view_642);  view_641 = view_642 = None
    view_643 = torch.ops.aten.reshape.default(bmm_10, [1, 8, 1, 144]);  bmm_10 = None
    mul_484 = torch.ops.aten.mul.Tensor(view_643, 0.0625);  view_643 = None
    add_396 = torch.ops.aten.add.Tensor(mul_484, unsqueeze_3);  mul_484 = unsqueeze_3 = None
    convert_element_type_893 = torch.ops.prims.convert_element_type.default(add_396, torch.float32);  add_396 = None
    amax_5 = torch.ops.aten.amax.default(convert_element_type_893, [-1], True)
    sub_23 = torch.ops.aten.sub.Tensor(convert_element_type_893, amax_5);  convert_element_type_893 = amax_5 = None
    exp_118 = torch.ops.aten.exp.default(sub_23);  sub_23 = None
    sum_78 = torch.ops.aten.sum.dim_IntList(exp_118, [-1], True)
    div_82 = torch.ops.aten.div.Tensor(exp_118, sum_78);  exp_118 = sum_78 = None
    convert_element_type_894 = torch.ops.prims.convert_element_type.default(div_82, torch.bfloat16);  div_82 = None
    expand_50 = torch.ops.aten.expand.default(convert_element_type_894, [1, 8, 1, 144]);  convert_element_type_894 = None
    view_644 = torch.ops.aten.reshape.default(expand_50, [8, 1, 144]);  expand_50 = None
    view_636 = torch.ops.aten.reshape.default(convert_element_type_878, [1, 2048]);  convert_element_type_878 = None
    permute_370 = torch.ops.aten.permute.default(arg367_1, [1, 0]);  arg367_1 = None
    mm_181 = torch.ops.aten.mm.default(view_636, permute_370);  view_636 = permute_370 = None
    view_637 = torch.ops.aten.reshape.default(mm_181, [1, 1, 512]);  mm_181 = None
    view_638 = torch.ops.aten.reshape.default(view_637, [1, 1, -1, 256]);  view_637 = None
    permute_371 = torch.ops.aten.permute.default(view_638, [0, 2, 1, 3]);  view_638 = None
    index_put_11 = torch.ops.aten.index_put_.default(arg370_1, [None, None, add_394], permute_371);  arg370_1 = add_394 = permute_371 = None
    unsqueeze_199 = torch.ops.aten.unsqueeze.default(index_put_11, 2);  index_put_11 = None
    expand_47 = torch.ops.aten.expand.default(unsqueeze_199, [1, 2, 4, 144, 256]);  unsqueeze_199 = None
    clone_93 = torch.ops.aten.clone.default(expand_47, memory_format = torch.contiguous_format);  expand_47 = None
    view_640 = torch.ops.aten.reshape.default(clone_93, [1, 8, 144, 256]);  clone_93 = None
    expand_51 = torch.ops.aten.expand.default(view_640, [1, 8, 144, 256]);  view_640 = None
    view_645 = torch.ops.aten.reshape.default(expand_51, [8, 144, 256]);  expand_51 = None
    bmm_11 = torch.ops.aten.bmm.default(view_644, view_645);  view_644 = view_645 = None
    view_646 = torch.ops.aten.reshape.default(bmm_11, [1, 8, 1, 256]);  bmm_11 = None
    permute_373 = torch.ops.aten.permute.default(view_646, [0, 2, 1, 3]);  view_646 = None
    view_647 = torch.ops.aten.reshape.default(permute_373, [1, 1, -1]);  permute_373 = None
    clone_91 = torch.ops.aten.clone.default(getitem_65, memory_format = torch.contiguous_format);  getitem_65 = None
    view_631 = torch.ops.aten.reshape.default(clone_91, [1, 1, 2048]);  clone_91 = None
    sigmoid_23 = torch.ops.aten.sigmoid.default(view_631);  view_631 = None
    mul_485 = torch.ops.aten.mul.Tensor(view_647, sigmoid_23);  view_647 = sigmoid_23 = None
    view_648 = torch.ops.aten.reshape.default(mul_485, [1, 2048]);  mul_485 = None
    permute_374 = torch.ops.aten.permute.default(arg371_1, [1, 0]);  arg371_1 = None
    mm_182 = torch.ops.aten.mm.default(view_648, permute_374);  view_648 = permute_374 = None
    view_649 = torch.ops.aten.reshape.default(mm_182, [1, 1, 2048]);  mm_182 = None
    add_397 = torch.ops.aten.add.Tensor(add_385, view_649);  add_385 = view_649 = None
    convert_element_type_899 = torch.ops.prims.convert_element_type.default(add_397, torch.float32)
    pow_78 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_899, 2)
    mean_77 = torch.ops.aten.mean.dim(pow_78, [-1], True);  pow_78 = None
    add_398 = torch.ops.aten.add.Tensor(mean_77, 1e-06);  mean_77 = None
    rsqrt_113 = torch.ops.aten.rsqrt.default(add_398);  add_398 = None
    mul_486 = torch.ops.aten.mul.Tensor(convert_element_type_899, rsqrt_113);  convert_element_type_899 = rsqrt_113 = None
    convert_element_type_900 = torch.ops.prims.convert_element_type.default(arg372_1, torch.float32);  arg372_1 = None
    add_399 = torch.ops.aten.add.Tensor(convert_element_type_900, 1.0);  convert_element_type_900 = None
    mul_487 = torch.ops.aten.mul.Tensor(mul_486, add_399);  mul_486 = add_399 = None
    convert_element_type_901 = torch.ops.prims.convert_element_type.default(mul_487, torch.bfloat16);  mul_487 = None
    view_650 = torch.ops.aten.reshape.default(convert_element_type_901, [1, 2048])
    permute_375 = torch.ops.aten.permute.default(arg373_1, [1, 0]);  arg373_1 = None
    mm_183 = torch.ops.aten.mm.default(view_650, permute_375);  view_650 = permute_375 = None
    view_651 = torch.ops.aten.reshape.default(mm_183, [1, 1, 6144]);  mm_183 = None
    convert_element_type_904 = torch.ops.prims.convert_element_type.default(view_651, torch.float32);  view_651 = None
    neg_89 = torch.ops.aten.neg.default(convert_element_type_904)
    exp_119 = torch.ops.aten.exp.default(neg_89);  neg_89 = None
    add_400 = torch.ops.aten.add.Tensor(exp_119, 1);  exp_119 = None
    div_83 = torch.ops.aten.div.Tensor(convert_element_type_904, add_400);  convert_element_type_904 = add_400 = None
    convert_element_type_905 = torch.ops.prims.convert_element_type.default(div_83, torch.bfloat16);  div_83 = None
    view_652 = torch.ops.aten.reshape.default(convert_element_type_901, [1, 2048]);  convert_element_type_901 = None
    permute_376 = torch.ops.aten.permute.default(arg374_1, [1, 0]);  arg374_1 = None
    mm_184 = torch.ops.aten.mm.default(view_652, permute_376);  view_652 = permute_376 = None
    view_653 = torch.ops.aten.reshape.default(mm_184, [1, 1, 6144]);  mm_184 = None
    mul_488 = torch.ops.aten.mul.Tensor(convert_element_type_905, view_653);  convert_element_type_905 = view_653 = None
    view_654 = torch.ops.aten.reshape.default(mul_488, [1, 6144]);  mul_488 = None
    permute_377 = torch.ops.aten.permute.default(arg375_1, [1, 0]);  arg375_1 = None
    mm_185 = torch.ops.aten.mm.default(view_654, permute_377);  view_654 = permute_377 = None
    view_655 = torch.ops.aten.reshape.default(mm_185, [1, 1, 2048]);  mm_185 = None
    add_401 = torch.ops.aten.add.Tensor(add_397, view_655);  add_397 = view_655 = None
    convert_element_type_910 = torch.ops.prims.convert_element_type.default(add_401, torch.float32);  add_401 = None
    pow_79 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_910, 2)
    mean_78 = torch.ops.aten.mean.dim(pow_79, [-1], True);  pow_79 = None
    add_402 = torch.ops.aten.add.Tensor(mean_78, 1e-06);  mean_78 = None
    rsqrt_114 = torch.ops.aten.rsqrt.default(add_402);  add_402 = None
    mul_489 = torch.ops.aten.mul.Tensor(convert_element_type_910, rsqrt_114);  convert_element_type_910 = rsqrt_114 = None
    convert_element_type_911 = torch.ops.prims.convert_element_type.default(arg376_1, torch.float32);  arg376_1 = None
    add_403 = torch.ops.aten.add.Tensor(convert_element_type_911, 1.0);  convert_element_type_911 = None
    mul_490 = torch.ops.aten.mul.Tensor(mul_489, add_403);  mul_489 = add_403 = None
    convert_element_type_912 = torch.ops.prims.convert_element_type.default(mul_490, torch.bfloat16);  mul_490 = None
    slice_174 = torch.ops.aten.slice.Tensor(convert_element_type_912, 1, -1, 9223372036854775807);  convert_element_type_912 = None
    view_656 = torch.ops.aten.reshape.default(slice_174, [1, 2048]);  slice_174 = None
    permute_378 = torch.ops.aten.permute.default(arg2_1, [1, 0]);  arg2_1 = None
    mm_186 = torch.ops.aten.mm.default(view_656, permute_378);  view_656 = permute_378 = None
    view_657 = torch.ops.aten.reshape.default(mm_186, [1, 1, 248320]);  mm_186 = None
    copy_ = torch.ops.aten.copy_.default(arg9_1, copy_4);  arg9_1 = copy_4 = copy_ = None
    copy__1 = torch.ops.aten.copy_.default(arg13_1, add_9);  arg13_1 = add_9 = copy__1 = None
    copy__2 = torch.ops.aten.copy_.default(arg25_1, copy_7);  arg25_1 = copy_7 = copy__2 = None
    copy__3 = torch.ops.aten.copy_.default(arg29_1, add_26);  arg29_1 = add_26 = copy__3 = None
    copy__4 = torch.ops.aten.copy_.default(arg41_1, copy_10);  arg41_1 = copy_10 = copy__4 = None
    copy__5 = torch.ops.aten.copy_.default(arg45_1, add_43);  arg45_1 = add_43 = copy__5 = None
    copy__6 = torch.ops.aten.copy_.default(arg58_1, add_60);  arg58_1 = add_60 = copy__6 = None
    copy__9 = torch.ops.aten.copy_.default(arg71_1, copy_13);  arg71_1 = copy_13 = copy__9 = None
    copy__10 = torch.ops.aten.copy_.default(arg75_1, add_76);  arg75_1 = add_76 = copy__10 = None
    copy__11 = torch.ops.aten.copy_.default(arg87_1, copy_16);  arg87_1 = copy_16 = copy__11 = None
    copy__12 = torch.ops.aten.copy_.default(arg91_1, add_93);  arg91_1 = add_93 = copy__12 = None
    copy__13 = torch.ops.aten.copy_.default(arg103_1, copy_19);  arg103_1 = copy_19 = copy__13 = None
    copy__14 = torch.ops.aten.copy_.default(arg107_1, add_110);  arg107_1 = add_110 = copy__14 = None
    copy__15 = torch.ops.aten.copy_.default(arg120_1, add_127);  arg120_1 = add_127 = copy__15 = None
    copy__18 = torch.ops.aten.copy_.default(arg133_1, copy_22);  arg133_1 = copy_22 = copy__18 = None
    copy__19 = torch.ops.aten.copy_.default(arg137_1, add_143);  arg137_1 = add_143 = copy__19 = None
    copy__20 = torch.ops.aten.copy_.default(arg149_1, copy_25);  arg149_1 = copy_25 = copy__20 = None
    copy__21 = torch.ops.aten.copy_.default(arg153_1, add_160);  arg153_1 = add_160 = copy__21 = None
    copy__22 = torch.ops.aten.copy_.default(arg165_1, copy_28);  arg165_1 = copy_28 = copy__22 = None
    copy__23 = torch.ops.aten.copy_.default(arg169_1, add_177);  arg169_1 = add_177 = copy__23 = None
    copy__24 = torch.ops.aten.copy_.default(arg182_1, add_194);  arg182_1 = add_194 = copy__24 = None
    copy__27 = torch.ops.aten.copy_.default(arg195_1, copy_31);  arg195_1 = copy_31 = copy__27 = None
    copy__28 = torch.ops.aten.copy_.default(arg199_1, add_210);  arg199_1 = add_210 = copy__28 = None
    copy__29 = torch.ops.aten.copy_.default(arg211_1, copy_34);  arg211_1 = copy_34 = copy__29 = None
    copy__30 = torch.ops.aten.copy_.default(arg215_1, add_227);  arg215_1 = add_227 = copy__30 = None
    copy__31 = torch.ops.aten.copy_.default(arg227_1, copy_37);  arg227_1 = copy_37 = copy__31 = None
    copy__32 = torch.ops.aten.copy_.default(arg231_1, add_244);  arg231_1 = add_244 = copy__32 = None
    copy__33 = torch.ops.aten.copy_.default(arg244_1, add_261);  arg244_1 = add_261 = copy__33 = None
    copy__36 = torch.ops.aten.copy_.default(arg257_1, copy_40);  arg257_1 = copy_40 = copy__36 = None
    copy__37 = torch.ops.aten.copy_.default(arg261_1, add_277);  arg261_1 = add_277 = copy__37 = None
    copy__38 = torch.ops.aten.copy_.default(arg273_1, copy_43);  arg273_1 = copy_43 = copy__38 = None
    copy__39 = torch.ops.aten.copy_.default(arg277_1, add_294);  arg277_1 = add_294 = copy__39 = None
    copy__40 = torch.ops.aten.copy_.default(arg289_1, copy_46);  arg289_1 = copy_46 = copy__40 = None
    copy__41 = torch.ops.aten.copy_.default(arg293_1, add_311);  arg293_1 = add_311 = copy__41 = None
    copy__42 = torch.ops.aten.copy_.default(arg306_1, add_328);  arg306_1 = add_328 = copy__42 = None
    copy__45 = torch.ops.aten.copy_.default(arg319_1, copy_49);  arg319_1 = copy_49 = copy__45 = None
    copy__46 = torch.ops.aten.copy_.default(arg323_1, add_344);  arg323_1 = add_344 = copy__46 = None
    copy__47 = torch.ops.aten.copy_.default(arg335_1, copy_52);  arg335_1 = copy_52 = copy__47 = None
    copy__48 = torch.ops.aten.copy_.default(arg339_1, add_361);  arg339_1 = add_361 = copy__48 = None
    copy__49 = torch.ops.aten.copy_.default(arg351_1, copy_55);  arg351_1 = copy_55 = copy__49 = None
    copy__50 = torch.ops.aten.copy_.default(arg355_1, add_378);  arg355_1 = add_378 = copy__50 = None
    copy__51 = torch.ops.aten.copy_.default(arg368_1, add_395);  arg368_1 = add_395 = copy__51 = None
    return (view_657,)
    