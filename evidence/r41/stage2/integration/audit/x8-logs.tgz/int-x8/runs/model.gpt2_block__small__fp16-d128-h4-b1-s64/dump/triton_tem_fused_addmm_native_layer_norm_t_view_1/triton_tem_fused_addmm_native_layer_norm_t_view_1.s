    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #256
    s.movz       s10, #2
    .li       s11, #68719476752
    .li       s12, #8589934592
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    .li       s6, #2147483647
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // arg_B: device_ptr64 at arg_base+16
    s.movz       s17, #24
    s.movz       s18, #256
    s.ld.d       s19, [s2, #24]                  // out_ptr0: device_ptr64 at arg_base+24
    s.movz       s2, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s17, s21
    s.st.d       [s5, #0], s1
    s.sub        s1, s22, s23
    s.movz       s21, #2
    s.st.d       [s5, #8], s7
    .li       s7, #68719476752
    .li       s22, #8589934592
    s.st.d       [s5, #16], s8
    s.xor        s8, s17, s1
    s.movz       s23, #0
    s.st.d       [s5, #48], s9
    .li       s9, #1431655766
    s.movz       s23, #0
    s.st.d       [s5, #56], s10
    s.cmp.lt     s10, s4, s2
    s.movz       s2, #4
    s.st.d       [s5, #88], s11
    s.sub        s11, s20, s10
    s.movz       s10, #1
    s.xor        s20, s4, s11
    s.st.d       [s5, #104], s12
    s.sub        s12, s20, s11
    s.movz       s20, #0
    fence.release.device
    s.mul        s23, s12, s9
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s5, #0
    s.ld.d       s9, [s13, #32]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.sub        s13, s8, s1
    s.lshri      s8, s23, #32
    s.movz       s13, #0
    s.add        s23, s9, s14                    // this context's own scratch
    s.sub        s9, s12, s8
    s.addi       s14, s23, #256                  // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.lshri      s23, s9, #1
    s.xor        s9, s11, s1
    s.add        s1, s8, s23
    s.movz       s8, #0
    s.lshri      s11, s1, #4
    s.movz       s1, #0
    s.st.d       [s14, #0], s16
    s.xor        s16, s11, s9
    s.muli       s23, s11, #24
    s.sub        s11, s16, s9
    s.movz       s9, #1
    s.sub        s16, s2, s11
    s.st.d       [s14, #8], s6
    s.min.s      s2, s16, s10
    s.cmp.lt     s6, s4, s5
    s.movz       s5, #0
    s.st.d       [s14, #16], s15
    s.cmp.lt     s15, s2, s20
    s.sub        s16, s8, s6
    s.st.d       [s14, #48], s18
    s.sub        s6, s13, s15
    s.xor        s8, s4, s16
    s.st.d       [s14, #56], s21
    s.xor        s13, s2, s6
    s.sub        s15, s8, s16
    s.st.d       [s14, #88], s7
    s.sub        s7, s13, s6
    s.addi       s6, s1, #0
    s.st.d       [s14, #104], s22
    fence.release.device
    s.cmp.eq     s1, s7, s9
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.sub        s8, s12, s23
    s.addi       s8, s5, #0
    s.mov        s6, s15
    br.nz        s1, sdiv_done_1
    s.movz       s1, #0
    s.movz       s5, #31
    s.mov        s6, s1
    s.addi       s1, s5, #0
sdiv_2:
    s.lshr       s5, s15, s1
    s.shli       s9, s8, #1
    s.andi       s12, s5, #1
    s.movz       s5, #0
    s.or         s13, s9, s12
    s.movz       s9, #1
    s.cmp.geu    s12, s13, s7
    s.shl        s14, s9, s1
    s.sub        s9, s5, s12
    s.subi       s5, s1, #1
    s.and        s12, s7, s9
    s.and        s18, s14, s9
    s.sub        s9, s13, s12
    s.or         s12, s6, s18
    s.mov        s8, s9
    s.mov        s6, s12
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s1, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s5, #0
    s.cmp.lt     s6, s4, s1
    .li       s1, #1431655766
    s.sub        s7, s5, s6
    s.movz       s5, #0
    s.xor        s6, s4, s7
    s.movz       s4, #0
    s.sub        s9, s6, s7
    s.movz       s6, #0
    s.mul        s12, s9, s1
    s.cmp.lt     s1, s2, s5
    s.movz       s5, #0
    s.sub        s13, s6, s1
    s.movz       s1, #0
    s.lshri      s6, s12, #32
    s.cmp.lt     s12, s17, s5
    s.xor        s5, s2, s13
    s.xor        s2, s8, s16
    s.sub        s8, s5, s13
    s.sub        s5, s2, s16
    s.sub        s2, s9, s6
    s.add        s14, s11, s5
    s.lshri      s5, s2, #1
    s.movz       s2, #0
    s.add        s11, s6, s5
    s.sub        s5, s2, s12
    s.lshri      s2, s11, #4
    s.movz       s6, #0
    s.muli       s11, s2, #24
    s.movz       s2, #1
    s.xor        s12, s17, s5
    s.addi       s15, s6, #0
    s.cmp.eq     s6, s8, s2
    s.sub        s2, s9, s11
    s.movz       s9, #0
    s.xor        s11, s2, s7
    s.sub        s2, s12, s5
    s.sub        s2, s11, s7
    s.addi       s5, s9, #0
    s.cmp.lt     s7, s2, s4
    s.sub        s4, s1, s7
    s.xor        s1, s2, s4
    s.sub        s2, s1, s4
    s.mov        s15, s2
    br.nz        s6, sdiv_done_3
    s.movz       s1, #0
    s.movz       s6, #31
    s.mov        s15, s1
    s.addi       s1, s6, #0
sdiv_4:
    s.lshr       s6, s2, s1
    s.shli       s7, s5, #1
    s.andi       s9, s6, #1
    s.movz       s6, #0
    s.or         s11, s7, s9
    s.movz       s7, #1
    s.cmp.geu    s9, s11, s8
    s.shl        s12, s7, s1
    s.sub        s7, s6, s9
    s.subi       s6, s1, #1
    s.and        s9, s8, s7
    s.and        s16, s12, s7
    s.sub        s7, s11, s9
    s.or         s9, s15, s16
    s.mov        s5, s7
    s.mov        s15, s9
    s.mov        s1, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s1, s6
    br.nz        s7, sdiv_4
sdiv_done_3:
    s.xor        s1, s4, s13
    s.movz       s2, #16
    s.xor        s4, s15, s1
    .li       s5, #1431655766
    s.sub        s6, s4, s1
    s.mul        s1, s14, s2
    s.mul        s4, s6, s2
    s.movz       s7, #0
    v.splat      v0, s14
    v.splat      v1, s7
    s.andi       s8, s1, #63
    s.mul        s9, s4, s5
    v.splat      v2, s6
    v.splat      v3, s7
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s1
    s.lshri      s5, s9, #32
    v.cmp.ge     p1, v0, v1
    s.sub        s6, s4, s5
    v.splat      v0, s4
    s.lshri      s9, s6, #1
    v.splat      v1, s8
    s.add        s6, s5, s9
    v.cmp.ge     p1, v2, v3
    s.lshri      s5, s6, #8
    v.iota       v2                              // arange(0, VLEN)
    s.muli       s6, s5, #384
    v.iota       v3                              // arange(0, VLEN)
    v.add        v6, v5, v4
    v.add        v5, v0, v4
    v.add        v0, v1, v2
    s.sub        s5, s4, s6
    s.movz       s6, #8
    v.splat      v0, s5
    s.addi       s9, s7, #0
    v.add        v1, v0, v3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s7, s9, s6
    br.nz        s7, endfor_6
    s.mul        s7, s9, s2
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s12, s9, s10
    s.movz       s13, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s8                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s14, s11
    mb.wait      s11
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s14, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s15, s5                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s15, s14
    mb.wait      s14
    mb.arm       s7, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s7
    mb.wait      s7
    s.mov        s9, s12
    br.nz        s13, for_5
endfor_6:
    s.movz       s2, #0
    s.movz       s5, #0
    s.add        s6, s2, s4                      // the tile origin
    s.muli       s2, s4, #2                      // a runtime tile origin, x2
    s.add        s8, s5, s1                      // the tile origin
    s.movz       s5, #64
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    s.movz       s6, #384
    v.splat      v2, s8
    v.splat      v3, s5
    v.add        v4, v0, v1
    v.splat      v0, s6
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    s.add        s5, s3, s2                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    p.and        p3, p1, p2
    a.vread      v0, a0, s2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s2, s4, #2                      // a runtime tile origin, x2
    s.muli       s3, s1, #768                    // a runtime tile origin, x768
    s.addi       s1, s8, #1
    v.splat      v2, s8
    v.splat      v4, s1
    vf.cvt.f16.f32 v5, v1
    s.add        s1, s19, s2                     // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p3, v4, v3
    vf.add       v1, v0, v5
    s.add        s2, s1, s3                      // the tile origin
    p.and        p4, p1, p2
    s.movz       s1, #1
    vf.cvt.f32.f16 v0, v1
    p.and        p1, p3, p2
    s.addi       s3, s8, #1
    s.addi       s4, s8, #2
    @p4 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s1
    v.splat      v1, s3
    v.splat      v2, s4
    v.cmp.lt     p3, v1, v3
    s.addi       s1, s2, #768                    // row 1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s5, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p3, p2
    s.movz       s3, #2
    p.and        p3, p1, p2
    s.addi       s4, s8, #2
    vf.cvt.f16.f32 v2, v1
    s.addi       s6, s8, #3
    v.splat      v1, s4
    v.splat      v4, s6
    vf.add       v5, v0, v2
    s.addi       s4, s2, #1536                   // row 2
    s.movz       s6, #3
    s.addi       s9, s8, #3
    vf.cvt.f32.f16 v0, v5
    s.addi       s10, s8, #4
    v.splat      v2, s9
    v.splat      v5, s10
    @p4 v.st.h       [s1, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s1, s2, #2304                   // row 3
    s.movz       s3, #4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    s.addi       s9, s8, #4
    s.addi       s10, s8, #5
    v.splat      v4, s9
    vf.cvt.f16.f32 v6, v1
    v.splat      v1, s10
    s.addi       s9, s2, #3072                   // row 4
    s.movz       s10, #5
    vf.add       v7, v0, v6
    vf.cvt.f32.f16 v0, v7
    @p4 v.st.h       [s4, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s4, s8, #5
    s.addi       s6, s8, #6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s4
    v.splat      v6, s6
    s.addi       s4, s2, #3840                   // row 5
    vf.cvt.f16.f32 v7, v2
    s.movz       s6, #6
    vf.add       v2, v0, v7
    vf.cvt.f32.f16 v0, v2
    @p4 v.st.h       [s1, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.addi       s1, s8, #6
    s.addi       s3, s8, #7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.splat      v1, s1
    v.splat      v4, s3
    s.addi       s1, s2, #4608                   // row 6
    vf.cvt.f16.f32 v7, v2
    s.movz       s3, #7
    vf.add       v2, v0, v7
    vf.cvt.f32.f16 v0, v2
    @p4 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s10
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s9, s8, #7
    s.addi       s10, s8, #8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    v.splat      v5, s9
    v.splat      v6, s10
    s.addi       s9, s2, #5376                   // row 7
    vf.cvt.f16.f32 v7, v2
    s.movz       s10, #8
    vf.add       v2, v0, v7
    vf.cvt.f32.f16 v0, v2
    @p4 v.st.h       [s4, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s4, s8, #8
    s.addi       s6, s8, #9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.splat      v2, s4
    v.splat      v4, s6
    s.addi       s4, s2, #6144                   // row 8
    vf.cvt.f16.f32 v7, v1
    s.movz       s6, #9
    vf.add       v1, v0, v7
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s1, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s1, s8, #9
    s.addi       s3, s8, #10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    v.splat      v5, s1
    v.splat      v6, s3
    s.addi       s1, s2, #6912                   // row 9
    vf.cvt.f16.f32 v7, v1
    s.movz       s3, #10
    vf.add       v1, v0, v7
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s10
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s9, s8, #10
    s.addi       s10, s8, #11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.splat      v2, s9
    v.splat      v4, s10
    s.addi       s9, s2, #7680                   // row 10
    vf.cvt.f16.f32 v7, v1
    s.movz       s10, #11
    vf.add       v1, v0, v7
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s4, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s4, s8, #11
    s.addi       s6, s8, #12
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    v.splat      v5, s4
    v.splat      v6, s6
    s.addi       s4, s2, #8448                   // row 11
    vf.cvt.f16.f32 v7, v1
    s.movz       s6, #12
    vf.add       v1, v0, v7
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s1, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s1, s8, #12
    s.addi       s3, s8, #13
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.splat      v2, s1
    v.splat      v4, s3
    s.addi       s1, s2, #9216                   // row 12
    vf.cvt.f16.f32 v7, v1
    s.movz       s3, #13
    vf.add       v1, v0, v7
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s10
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s9, s8, #13
    s.addi       s10, s8, #14
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    v.splat      v5, s9
    v.splat      v6, s10
    s.addi       s9, s2, #9984                   // row 13
    vf.cvt.f16.f32 v7, v1
    s.movz       s10, #14
    vf.add       v1, v0, v7
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s4, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s4, s8, #14
    s.addi       s6, s8, #15
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.splat      v2, s4
    v.splat      v4, s6
    s.addi       s4, s2, #10752                  // row 14
    vf.cvt.f16.f32 v7, v1
    s.movz       s6, #15
    vf.add       v1, v0, v7
    vf.cvt.f32.f16 v0, v1
    s.addi       s12, s8, #15
    s.addi       s8, s2, #11520                  // row 15
    v.splat      v1, s12
    @p4 v.st.h       [s1, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s5, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v0, v6
    vf.cvt.f32.f16 v0, v5
    @p4 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s10
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    @p4 v.st.h       [s4, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s8, #0], v0
__rctx_next:
    exit
