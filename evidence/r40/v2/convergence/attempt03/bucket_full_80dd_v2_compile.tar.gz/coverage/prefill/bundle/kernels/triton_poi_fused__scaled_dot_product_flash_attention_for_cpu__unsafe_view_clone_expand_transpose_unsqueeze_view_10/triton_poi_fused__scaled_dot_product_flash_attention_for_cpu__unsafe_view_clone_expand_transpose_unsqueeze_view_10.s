    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    s.shli       s1, s2, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #0
    v.add        v4, v1, v0
    v.movi       v0, #15
    v.movi       v1, #6
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v3, v4
    @p1 v.sel        v7, v5, v4
    v.cmp.lt     p2, v4, v3
    @p2 v.sel        v5, v6, v4
    v.lshr       v6, v7, v0
    v.movi       v0, #0
    v.lshr       v7, v5, v1
    v.sub        v1, v2, v6
    v.movi       v5, #0
    v.sub        v8, v3, v7
    @p1 v.sel        v9, v1, v6
    v.sub        v1, v0, v4
    @p2 v.sel        v6, v8, v7
    v.cmp.lt     p1, v4, v0
    @p1 v.sel        v7, v1, v4
    v.sub        v1, v5, v6
    v.cmp.lt     p2, v6, v5
    v.movi       v4, #63
    @p2 v.sel        v8, v1, v6
    v.movi       v1, #511
    v.and        v6, v7, v4
    v.movi       v4, #64
    v.movi       v7, #0
    v.and        v10, v8, v1
    v.sub        v1, v0, v6
    v.cmp.lt     p3, v9, v7
    v.sub        v8, v5, v10
    @p1 v.sel        v11, v1, v6
    v.movi       v1, #512
    @p2 v.sel        v6, v8, v10
    s.movz       s6, #32768
    v.splat      v8, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p1, v4, v0
    v.sub        v10, v0, v4
    v.cmp.lt     p2, v4, v3
    v.sub        v0, v3, v4
    @p1 v.sel        v3, v10, v4
    v.sub        v3, v7, v9
    v.cmp.lt     p1, v1, v5
    v.sub        v10, v5, v1
    @p3 v.sel        v5, v3, v9
    v.movi       v3, #2
    @p2 v.sel        v9, v0, v4
    v.movi       v0, #256
    v.lshr       v9, v5, v3
    v.movi       v3, #4
    v.mul        v5, v6, v0
    v.sub        v0, v7, v9
    s.shli       s6, s1, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p2, v8, v2
    @p3 v.sel        v6, v0, v9
    v.sub        v0, v2, v8
    v.sub        v2, v7, v3
    v.mul        v9, v6, v4
    s.add        s1, s5, s6                      // &out_ptr0[...]
    v.cmp.lt     p3, v3, v7
    v.add        v4, v11, v9
    @p1 v.sel        v6, v10, v1
    @p2 v.sel        v1, v0, v8
    v.add        v0, v4, v5
    @p3 v.sel        v1, v2, v3
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v0, v1
    v.st.w       [s1, #0], v0
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s6, s1, s4
    s.mov        s2, s1
    br.nz        s6, __rctx_program
    exit
