    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s5, #512
    v.splat      v0, s4
    s.mul        s6, s1, s5
    v.movi       v1, #96
    v.movi       v2, #0
    s.movz       s1, #384
    s.movz       s5, #96
    v.sub        v3, v2, v0
    v.sub        v4, v2, v1
    s.ld.d       s7, [s2, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.add        s8, s3, s6                      // this context's own scratch
    s.movz       s3, #384
    s.addi       s6, s8, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s9, #4
    .li       s10, #68719476737
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    s.movz       s11, #0
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #1
    s.ld.d       s11, [s2, #0]                   // in_out_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v7, v3, v0
    @p2 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v3, #0
    s.st.d       [s6, #0], s7
    s.st.d       [s6, #8], s1
    .li       s1, #2207613190144
    s.st.d       [s6, #16], s5
    s.movz       s2, #31
    s.st.d       [s6, #48], s3
    s.st.d       [s6, #56], s9
    s.st.d       [s6, #88], s10
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
idiv_1:
    v.splat      v4, s2
    v.shl        v8, v3, v6
    v.cmp.lt     p2, v3, v2
    v.lshr       v9, v7, v4
    v.shl        v10, v6, v4
    s.subi       s1, s2, #1
    v.and        v4, v9, v6
    s.movz       s3, #0
    v.or         v9, v8, v4
    v.cmp.geu    p3, v9, v0
    p.or         p4, p2, p3
    v.sub        v4, v9, v0
    @p4 v.sel        v8, v10, v2
    @p4 v.sel        v10, v4, v9
    v.or         v4, v1, v8
    v.mov        v3, v10
    v.mov        v1, v4
    s.mov        s2, s1
    s.cmp.ge     s1, s2, s3
    br.nz        s1, idiv_1
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v4, v2, v3
    .li       s1, #4286578688
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v6, #0
    s.movz       s1, #0
    v.cmp.ne     p2, v0, v1
    @p1 v.sel        v0, v4, v3
    s.movz       s2, #96
    s.movz       s3, #16
    s.addi       s5, s1, #0
    p.mov        p1, p2
    v.mov        v6, v2
for_2:
    s.cmp.ge     s6, s5, s2
    br.nz        s6, endfor_3
    v.movi       v1, #-1
    v.splat      v3, s5
    v.splat      v4, s5
    v.mul        v7, v0, v1
    v.add        v1, v3, v5
    v.iota       v3                              // arange(0, VLEN)
    v.extract    s6, v7, #0
    s.movz       s9, #96
    v.splat      v7, s6
    s.movz       s6, #384
    s.muli       s10, s4, #384
    v.add        v8, v1, v7
    v.add        v7, v4, v3
    v.movi       v3, #0
    v.splat      v4, s9
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s6
    v.extract    s6, v8, #0
    s.muli       s9, s5, #4
    s.shli       s12, s6, #32
    v.cmp.ge     p2, v7, v3
    v.cmp.lt     p3, v7, v4
    v.cmp.ge     p4, v9, v10
    v.cmp.lt     p5, v9, v11
    v.extract    s6, v8, #1
    s.add        s13, s7, s10
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.ashri      s10, s12, #32
    v.movi       v3, #0
    v.movi       v4, #0
    s.shli       s12, s6, #32
    s.add        s6, s13, s9
    p.and        p3, p6, p2
    s.lshri      s9, s10, #32
    v.extract    s13, v8, #2
    s.ashri      s14, s12, #32
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v7, [s6, #0]
    v.insert     v3, s10, #0
    v.insert     v4, s9, #0
    s.shli       s6, s13, #32
    s.lshri      s9, s14, #32
    s.ashri      s10, s6, #32
    v.insert     v3, s14, #1
    v.insert     v4, s9, #1
    v.movi       v9, #96
    s.lshri      s6, s10, #32
    v.insert     v3, s10, #2
    v.cmp.lt     p2, v1, v9
    v.extract    s9, v8, #3
    v.extract    s10, v8, #4
    s.shli       s12, s9, #32
    v.insert     v4, s6, #2
    s.ashri      s6, s12, #32
    s.shli       s9, s10, #32
    s.lshri      s10, s6, #32
    v.extract    s12, v8, #5
    s.ashri      s13, s9, #32
    v.insert     v3, s6, #3
    v.insert     v4, s10, #3
    s.shli       s6, s12, #32
    s.lshri      s9, s13, #32
    v.extract    s10, v8, #6
    s.ashri      s12, s6, #32
    v.insert     v3, s13, #4
    v.insert     v4, s9, #4
    s.shli       s6, s10, #32
    s.lshri      s9, s12, #32
    s.ashri      s10, s6, #32
    v.insert     v3, s12, #5
    v.insert     v4, s9, #5
    .li       s6, #-1
    v.extract    s6, v8, #7
    s.lshri      s9, s10, #32
    s.shli       s12, s6, #32
    v.extract    s6, v8, #8
    s.ashri      s13, s12, #32
    v.insert     v3, s10, #6
    v.insert     v4, s9, #6
    s.shli       s9, s6, #32
    s.lshri      s6, s13, #32
    v.extract    s10, v8, #9
    s.ashri      s12, s9, #32
    v.insert     v3, s13, #7
    v.insert     v4, s6, #7
    s.shli       s6, s10, #32
    s.lshri      s9, s12, #32
    v.extract    s10, v8, #10
    s.ashri      s13, s6, #32
    v.insert     v3, s12, #8
    v.insert     v4, s9, #8
    s.shli       s6, s10, #32
    s.lshri      s9, s13, #32
    v.extract    s10, v8, #11
    s.ashri      s12, s6, #32
    v.insert     v3, s13, #9
    v.insert     v4, s9, #9
    s.shli       s6, s10, #32
    s.lshri      s9, s12, #32
    v.extract    s10, v8, #12
    s.ashri      s13, s6, #32
    v.insert     v3, s12, #10
    v.insert     v4, s9, #10
    s.shli       s6, s10, #32
    s.lshri      s9, s13, #32
    v.extract    s10, v8, #13
    s.ashri      s12, s6, #32
    v.insert     v3, s13, #11
    v.insert     v4, s9, #11
    s.shli       s6, s10, #32
    s.lshri      s9, s12, #32
    v.extract    s10, v8, #14
    s.ashri      s13, s6, #32
    v.insert     v3, s12, #12
    v.insert     v4, s9, #12
    s.shli       s6, s10, #32
    s.lshri      s9, s13, #32
    v.extract    s10, v8, #15
    s.ashri      s12, s6, #32
    v.insert     v3, s13, #13
    v.insert     v4, s9, #13
    s.shli       s6, s10, #32
    s.lshri      s9, s12, #32
    s.ashri      s10, s6, #32
    v.insert     v3, s12, #14
    v.insert     v4, s9, #14
    s.lshri      s6, s10, #32
    v.insert     v3, s10, #15
    v.insert     v4, s6, #15
    s.movz       s6, #0
    v.extract    s9, v3, #0
    v.extract    s10, v4, #0
    v.extract    s12, v4, #1
    s.shli       s13, s10, #32
    v.movi       v1, #0
    s.or         s10, s9, s13
    v.extract    s9, v3, #1
    s.shli       s13, s12, #32
    s.cmp.le     s12, s10, s6
    v.extract    s6, v4, #2
    s.or         s10, s9, s13
    s.movz       s9, #0
    v.insert     v1, s12, #0
    v.extract    s12, v3, #2
    s.shli       s13, s6, #32
    s.cmp.le     s6, s10, s9
    v.extract    s9, v4, #3
    s.or         s10, s12, s13
    s.movz       s12, #0
    v.insert     v1, s6, #1
    v.extract    s6, v3, #3
    s.shli       s13, s9, #32
    s.cmp.le     s9, s10, s12
    v.extract    s10, v4, #4
    s.or         s12, s6, s13
    s.movz       s6, #0
    v.insert     v1, s9, #2
    v.extract    s9, v3, #4
    s.shli       s13, s10, #32
    s.cmp.le     s10, s12, s6
    v.extract    s6, v4, #5
    s.or         s12, s9, s13
    s.movz       s9, #0
    v.insert     v1, s10, #3
    v.extract    s10, v3, #5
    s.shli       s13, s6, #32
    s.cmp.le     s6, s12, s9
    v.extract    s9, v4, #6
    s.or         s12, s10, s13
    s.movz       s10, #0
    v.insert     v1, s6, #4
    v.extract    s6, v3, #6
    s.shli       s13, s9, #32
    s.cmp.le     s9, s12, s10
    v.extract    s10, v4, #7
    s.or         s12, s6, s13
    s.movz       s6, #0
    v.insert     v1, s9, #5
    v.extract    s9, v3, #7
    s.shli       s13, s10, #32
    s.cmp.le     s10, s12, s6
    v.extract    s6, v4, #8
    s.or         s12, s9, s13
    s.movz       s9, #0
    v.insert     v1, s10, #6
    v.extract    s10, v3, #8
    s.shli       s13, s6, #32
    s.cmp.le     s6, s12, s9
    v.extract    s9, v4, #9
    s.or         s12, s10, s13
    s.movz       s10, #0
    v.insert     v1, s6, #7
    v.extract    s6, v3, #9
    s.shli       s13, s9, #32
    s.cmp.le     s9, s12, s10
    v.extract    s10, v4, #10
    s.or         s12, s6, s13
    s.movz       s6, #0
    v.insert     v1, s9, #8
    v.extract    s9, v3, #10
    s.shli       s13, s10, #32
    s.cmp.le     s10, s12, s6
    v.extract    s6, v4, #11
    s.or         s12, s9, s13
    s.movz       s9, #0
    v.insert     v1, s10, #9
    v.extract    s10, v3, #11
    s.shli       s13, s6, #32
    s.cmp.le     s6, s12, s9
    v.extract    s9, v4, #12
    s.or         s12, s10, s13
    s.movz       s10, #0
    v.insert     v1, s6, #10
    v.extract    s6, v3, #12
    s.shli       s13, s9, #32
    s.cmp.le     s9, s12, s10
    v.extract    s10, v4, #13
    s.or         s12, s6, s13
    s.movz       s6, #0
    v.insert     v1, s9, #11
    v.extract    s9, v3, #13
    s.shli       s13, s10, #32
    s.cmp.le     s10, s12, s6
    v.extract    s6, v4, #14
    s.or         s12, s9, s13
    s.movz       s9, #0
    v.insert     v1, s10, #12
    v.extract    s10, v3, #14
    s.shli       s13, s6, #32
    s.cmp.le     s6, s12, s9
    v.extract    s9, v4, #15
    s.or         s12, s10, s13
    s.movz       s10, #0
    v.insert     v1, s6, #13
    v.extract    s6, v3, #15
    s.shli       s13, s9, #32
    s.cmp.le     s9, s12, s10
    s.or         s10, s6, s13
    s.movz       s6, #0
    v.insert     v1, s9, #14
    s.cmp.le     s9, s10, s6
    v.movi       v3, #0
    v.insert     v1, s9, #15
    v.movi       v4, #0
    v.movi       v8, #1
    v.cmp.ne     p3, v1, v3
    @p3 v.sel        v1, v4, v2
    v.movi       v3, #0
    v.movi       v4, #0
    vf.add       v9, v7, v1
    v.movi       v1, #1
    v.movi       v7, #0
    v.movi       v10, #1
    v.movi       v11, #0
    vf.cmp.eq    p3, v9, v2
    @p3 v.sel        v12, v8, v3
    v.movi       v3, #1
    v.movi       v8, #0
    v.cmp.eq     p3, v12, v4
    @p3 v.sel        v4, v1, v7
    @p3 v.sel        v1, v10, v11
    v.movi       v7, #0
    v.extract    s6, v4, #0
    v.movi       v4, #0
    s.lshri      s9, s6, #32
    v.extract    s10, v1, #1
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s6, #0
    v.insert     v4, s9, #0
    s.lshri      s6, s10, #32
    v.extract    s9, v1, #2
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s10, #1
    v.insert     v4, s6, #1
    s.lshri      s6, s9, #32
    v.extract    s10, v1, #3
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s9, #2
    v.insert     v4, s6, #2
    s.lshri      s6, s10, #32
    v.extract    s9, v1, #4
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s10, #3
    v.insert     v4, s6, #3
    s.lshri      s6, s9, #32
    v.extract    s10, v1, #5
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s9, #4
    v.insert     v4, s6, #4
    s.lshri      s6, s10, #32
    v.extract    s9, v1, #6
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s10, #5
    v.insert     v4, s6, #5
    s.lshri      s6, s9, #32
    v.extract    s10, v1, #7
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s9, #6
    v.insert     v4, s6, #6
    s.lshri      s6, s10, #32
    v.extract    s9, v1, #8
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s10, #7
    v.insert     v4, s6, #7
    s.lshri      s6, s9, #32
    v.extract    s10, v1, #9
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s9, #8
    v.insert     v4, s6, #8
    s.lshri      s6, s10, #32
    v.extract    s9, v1, #10
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s10, #9
    v.insert     v4, s6, #9
    s.lshri      s6, s9, #32
    v.extract    s10, v1, #11
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s9, #10
    v.insert     v4, s6, #10
    s.lshri      s6, s10, #32
    v.extract    s9, v1, #12
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s10, #11
    v.insert     v4, s6, #11
    s.lshri      s6, s9, #32
    v.extract    s10, v1, #13
    @p3 v.sel        v1, v3, v8
    v.movi       v3, #1
    v.movi       v8, #0
    v.insert     v7, s9, #12
    v.insert     v4, s6, #12
    s.lshri      s6, s10, #32
    v.extract    s9, v1, #14
    @p3 v.sel        v1, v3, v8
    v.insert     v7, s10, #13
    v.insert     v4, s6, #13
    s.lshri      s6, s9, #32
    v.extract    s10, v1, #15
    v.insert     v7, s9, #14
    v.insert     v4, s6, #14
    s.lshri      s6, s10, #32
    v.insert     v7, s10, #15
    v.insert     v4, s6, #15
    s.movz       s6, #0
    v.extract    s9, v7, #0
    v.extract    s10, v4, #0
    v.extract    s12, v4, #1
    s.shli       s13, s10, #32
    v.movi       v1, #0
    s.or         s10, s9, s13
    v.extract    s9, v7, #1
    s.shli       s13, s12, #32
    s.cmp.ne     s12, s10, s6
    v.extract    s6, v4, #2
    s.or         s10, s9, s13
    s.movz       s9, #0
    v.insert     v1, s12, #0
    v.extract    s12, v7, #2
    s.shli       s13, s6, #32
    s.cmp.ne     s6, s10, s9
    v.extract    s9, v4, #3
    s.or         s10, s12, s13
    s.movz       s12, #0
    v.insert     v1, s6, #1
    v.extract    s6, v7, #3
    s.shli       s13, s9, #32
    s.cmp.ne     s9, s10, s12
    v.extract    s10, v4, #4
    s.or         s12, s6, s13
    s.movz       s6, #0
    v.insert     v1, s9, #2
    v.extract    s9, v7, #4
    s.shli       s13, s10, #32
    s.cmp.ne     s10, s12, s6
    v.extract    s6, v4, #5
    s.or         s12, s9, s13
    s.movz       s9, #0
    v.insert     v1, s10, #3
    v.extract    s10, v7, #5
    s.shli       s13, s6, #32
    s.cmp.ne     s6, s12, s9
    v.extract    s9, v4, #6
    s.or         s12, s10, s13
    s.movz       s10, #0
    v.insert     v1, s6, #4
    v.extract    s6, v7, #6
    s.shli       s13, s9, #32
    s.cmp.ne     s9, s12, s10
    v.extract    s10, v4, #7
    s.or         s12, s6, s13
    s.movz       s6, #0
    v.insert     v1, s9, #5
    v.extract    s9, v7, #7
    s.shli       s13, s10, #32
    s.cmp.ne     s10, s12, s6
    v.extract    s6, v4, #8
    s.or         s12, s9, s13
    s.movz       s9, #0
    v.insert     v1, s10, #6
    v.extract    s10, v7, #8
    s.shli       s13, s6, #32
    s.cmp.ne     s6, s12, s9
    v.extract    s9, v4, #9
    s.or         s12, s10, s13
    s.movz       s10, #0
    v.insert     v1, s6, #7
    v.extract    s6, v7, #9
    s.shli       s13, s9, #32
    s.cmp.ne     s9, s12, s10
    v.extract    s10, v4, #10
    s.or         s12, s6, s13
    s.movz       s6, #0
    v.insert     v1, s9, #8
    v.extract    s9, v7, #10
    s.shli       s13, s10, #32
    s.cmp.ne     s10, s12, s6
    v.extract    s6, v4, #11
    s.or         s12, s9, s13
    s.movz       s9, #0
    v.insert     v1, s10, #9
    v.extract    s10, v7, #11
    s.shli       s13, s6, #32
    s.cmp.ne     s6, s12, s9
    v.extract    s9, v4, #12
    s.or         s12, s10, s13
    s.movz       s10, #0
    v.insert     v1, s6, #10
    v.extract    s6, v7, #12
    s.shli       s13, s9, #32
    s.cmp.ne     s9, s12, s10
    v.extract    s10, v4, #13
    s.or         s12, s6, s13
    s.movz       s6, #0
    v.insert     v1, s9, #11
    v.extract    s9, v7, #13
    s.shli       s13, s10, #32
    s.cmp.ne     s10, s12, s6
    v.extract    s6, v4, #14
    s.or         s12, s9, s13
    s.movz       s9, #0
    v.insert     v1, s10, #12
    v.extract    s10, v7, #14
    s.shli       s13, s6, #32
    s.cmp.ne     s6, s12, s9
    v.extract    s9, v4, #15
    s.or         s12, s10, s13
    s.movz       s10, #0
    v.insert     v1, s6, #13
    v.extract    s6, v7, #15
    s.shli       s13, s9, #32
    s.cmp.ne     s9, s12, s10
    s.or         s10, s6, s13
    s.movz       s6, #0
    v.insert     v1, s9, #14
    s.cmp.ne     s9, s10, s6
    v.movi       v3, #0
    v.insert     v1, s9, #15
    vf.max       v4, v6, v9
    p.not        p3, p2
    v.cmp.ne     p4, v1, v3
    p.or         p5, p1, p4
    p.and        p4, p3, p1
    p.and        p3, p2, p5
    @p2 v.sel        v1, v4, v6
    v.movi       v3, #0
    p.or         p2, p3, p4
    s.add        s6, s5, s3
    p.mov        p3, p2
    v.mov        v3, v1
    s.movz       s9, #1
    p.mov        p1, p3
    v.mov        v6, v3
    s.mov        s5, s6
    br.nz        s9, for_2
endfor_3:
    v.movi       v1, #1
    v.movi       v3, #0
    vf.cmp.uo    p2, v6, v6
    v.movi       v4, #1
    @p2 v.sel        v7, v1, v3
    v.movi       v1, #0
    v.movi       v3, #0
    v.reduce.or.b v8, v7
    vf.reduce.max.b v7, v6
    .li       s5, #2143289344
    v.splat      v6, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v9, v4, v1
    v.cmp.ne     p1, v8, v3
    @p1 v.sel        v1, v6, v7
    v.movi       v3, #0
    v.movi       v4, #0
    v.movi       v6, #0
    v.reduce.or  s5, v9
    vf.add       v7, v1, v3
    v.splat      v1, s5
    s.addi       s5, s1, #0
    v.mov        v6, v4
for_4:
    s.cmp.ge     s6, s5, s2
    br.nz        s6, endfor_5
    v.movi       v8, #-1
    v.splat      v9, s5
    v.splat      v10, s5
    v.mul        v11, v0, v8
    v.add        v8, v9, v5
    v.iota       v9                              // arange(0, VLEN)
    v.extract    s6, v11, #0
    s.movz       s9, #96
    v.splat      v11, s6
    s.movz       s6, #384
    s.muli       s10, s4, #384
    v.add        v12, v8, v11
    v.add        v11, v10, v9
    v.movi       v9, #0
    v.splat      v10, s9
    v.splat      v13, s4
    v.movi       v14, #0
    v.splat      v15, s6
    v.extract    s6, v12, #0
    s.muli       s9, s5, #4
    s.shli       s12, s6, #32
    v.cmp.ge     p1, v11, v9
    v.cmp.lt     p2, v11, v10
    v.cmp.ge     p3, v13, v14
    v.cmp.lt     p4, v13, v15
    v.extract    s6, v12, #1
    s.add        s13, s7, s10
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.ashri      s10, s12, #32
    v.movi       v9, #0
    v.movi       v10, #0
    s.shli       s12, s6, #32
    s.add        s6, s13, s9
    p.and        p2, p5, p1
    s.lshri      s9, s10, #32
    v.extract    s13, v12, #2
    s.ashri      s14, s12, #32
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v11, [s6, #0]
    v.insert     v9, s10, #0
    v.insert     v10, s9, #0
    s.shli       s6, s13, #32
    s.lshri      s9, s14, #32
    s.ashri      s10, s6, #32
    v.insert     v9, s14, #1
    v.insert     v10, s9, #1
    v.movi       v13, #96
    s.lshri      s6, s10, #32
    v.insert     v9, s10, #2
    v.cmp.lt     p1, v8, v13
    v.extract    s9, v12, #3
    v.extract    s10, v12, #4
    s.shli       s12, s9, #32
    v.insert     v10, s6, #2
    s.ashri      s6, s12, #32
    s.shli       s9, s10, #32
    s.lshri      s10, s6, #32
    v.extract    s12, v12, #5
    s.ashri      s13, s9, #32
    v.insert     v9, s6, #3
    v.insert     v10, s10, #3
    s.shli       s6, s12, #32
    s.lshri      s9, s13, #32
    v.extract    s10, v12, #6
    s.ashri      s12, s6, #32
    v.insert     v9, s13, #4
    v.insert     v10, s9, #4
    s.shli       s6, s10, #32
    s.lshri      s9, s12, #32
    s.ashri      s10, s6, #32
    v.insert     v9, s12, #5
    v.insert     v10, s9, #5
    .li       s6, #-1
    v.extract    s6, v12, #7
    s.lshri      s9, s10, #32
    s.shli       s12, s6, #32
    v.extract    s6, v12, #8
    s.ashri      s13, s12, #32
    v.insert     v9, s10, #6
    v.insert     v10, s9, #6
    s.shli       s9, s6, #32
    s.lshri      s6, s13, #32
    v.extract    s10, v12, #9
    s.ashri      s12, s9, #32
    v.insert     v9, s13, #7
    v.insert     v10, s6, #7
    s.shli       s6, s10, #32
    s.lshri      s9, s12, #32
    v.extract    s10, v12, #10
    s.ashri      s13, s6, #32
    v.insert     v9, s12, #8
    v.insert     v10, s9, #8
    s.shli       s6, s10, #32
    s.lshri      s9, s13, #32
    v.extract    s10, v12, #11
    s.ashri      s12, s6, #32
    v.insert     v9, s13, #9
    v.insert     v10, s9, #9
    s.shli       s6, s10, #32
    s.lshri      s9, s12, #32
    v.extract    s10, v12, #12
    s.ashri      s13, s6, #32
    v.insert     v9, s12, #10
    v.insert     v10, s9, #10
    s.shli       s6, s10, #32
    s.lshri      s9, s13, #32
    v.extract    s10, v12, #13
    s.ashri      s12, s6, #32
    v.insert     v9, s13, #11
    v.insert     v10, s9, #11
    s.shli       s6, s10, #32
    s.lshri      s9, s12, #32
    v.extract    s10, v12, #14
    s.ashri      s13, s6, #32
    v.insert     v9, s12, #12
    v.insert     v10, s9, #12
    s.shli       s6, s10, #32
    s.lshri      s9, s13, #32
    v.extract    s10, v12, #15
    s.ashri      s12, s6, #32
    v.insert     v9, s13, #13
    v.insert     v10, s9, #13
    s.shli       s6, s10, #32
    s.lshri      s9, s12, #32
    s.ashri      s10, s6, #32
    v.insert     v9, s12, #14
    v.insert     v10, s9, #14
    s.lshri      s6, s10, #32
    v.insert     v9, s10, #15
    v.insert     v10, s6, #15
    s.movz       s6, #0
    v.extract    s9, v9, #0
    v.extract    s10, v10, #0
    v.extract    s12, v10, #1
    s.shli       s13, s10, #32
    v.movi       v12, #0
    s.or         s10, s9, s13
    v.extract    s9, v9, #1
    s.shli       s13, s12, #32
    s.cmp.le     s12, s10, s6
    v.extract    s6, v10, #2
    s.or         s10, s9, s13
    s.movz       s9, #0
    v.insert     v12, s12, #0
    v.extract    s12, v9, #2
    s.shli       s13, s6, #32
    s.cmp.le     s6, s10, s9
    v.extract    s9, v10, #3
    s.or         s10, s12, s13
    s.movz       s12, #0
    v.insert     v12, s6, #1
    v.extract    s6, v9, #3
    s.shli       s13, s9, #32
    s.cmp.le     s9, s10, s12
    v.extract    s10, v10, #4
    s.or         s12, s6, s13
    s.movz       s6, #0
    v.insert     v12, s9, #2
    v.extract    s9, v9, #4
    s.shli       s13, s10, #32
    s.cmp.le     s10, s12, s6
    v.extract    s6, v10, #5
    s.or         s12, s9, s13
    s.movz       s9, #0
    v.insert     v12, s10, #3
    v.extract    s10, v9, #5
    s.shli       s13, s6, #32
    s.cmp.le     s6, s12, s9
    v.extract    s9, v10, #6
    s.or         s12, s10, s13
    s.movz       s10, #0
    v.insert     v12, s6, #4
    v.extract    s6, v9, #6
    s.shli       s13, s9, #32
    s.cmp.le     s9, s12, s10
    v.extract    s10, v10, #7
    s.or         s12, s6, s13
    s.movz       s6, #0
    v.insert     v12, s9, #5
    v.extract    s9, v9, #7
    s.shli       s13, s10, #32
    s.cmp.le     s10, s12, s6
    v.extract    s6, v10, #8
    s.or         s12, s9, s13
    s.movz       s9, #0
    v.insert     v12, s10, #6
    v.extract    s10, v9, #8
    s.shli       s13, s6, #32
    s.cmp.le     s6, s12, s9
    v.extract    s9, v10, #9
    s.or         s12, s10, s13
    s.movz       s10, #0
    v.insert     v12, s6, #7
    v.extract    s6, v9, #9
    s.shli       s13, s9, #32
    s.cmp.le     s9, s12, s10
    v.extract    s10, v10, #10
    s.or         s12, s6, s13
    s.movz       s6, #0
    v.insert     v12, s9, #8
    v.extract    s9, v9, #10
    s.shli       s13, s10, #32
    s.cmp.le     s10, s12, s6
    v.extract    s6, v10, #11
    s.or         s12, s9, s13
    s.movz       s9, #0
    v.insert     v12, s10, #9
    v.extract    s10, v9, #11
    s.shli       s13, s6, #32
    s.cmp.le     s6, s12, s9
    v.extract    s9, v10, #12
    s.or         s12, s10, s13
    s.movz       s10, #0
    v.insert     v12, s6, #10
    v.extract    s6, v9, #12
    s.shli       s13, s9, #32
    s.cmp.le     s9, s12, s10
    v.extract    s10, v10, #13
    s.or         s12, s6, s13
    s.movz       s6, #0
    v.insert     v12, s9, #11
    v.extract    s9, v9, #13
    s.shli       s13, s10, #32
    s.cmp.le     s10, s12, s6
    v.extract    s6, v10, #14
    s.or         s12, s9, s13
    s.movz       s9, #0
    v.insert     v12, s10, #12
    v.extract    s10, v9, #14
    s.shli       s13, s6, #32
    s.cmp.le     s6, s12, s9
    v.extract    s9, v10, #15
    s.or         s12, s10, s13
    s.movz       s10, #0
    v.insert     v12, s6, #13
    v.extract    s6, v9, #15
    s.shli       s13, s9, #32
    s.cmp.le     s9, s12, s10
    s.or         s10, s6, s13
    s.movz       s6, #0
    v.insert     v12, s9, #14
    s.cmp.le     s9, s10, s6
    v.movi       v9, #0
    v.insert     v12, s9, #15
    v.extract    s6, v7, #0
    .li       s9, #1069066811
    v.splat      v10, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p2, v12, v9
    @p2 v.sel        v9, v4, v2
    v.splat      v12, s6
    .li       s6, #1060205080
    v.splat      v13, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v14, v11, v9
    s.mul        s6, s4, s2
    v.movi       v9, #0
    s.add        s9, s5, s3
    s.movz       s10, #1
    vf.sub       v11, v14, v12
    s.add        s12, s5, s6
    v.splat      v12, s6
    s.shli       s6, s12, #2                     // element offset -> bytes (x4)
    vf.mul       v14, v11, v10
    s.add        s12, s11, s6                    // &in_out_ptr0[...]
    v.add        v15, v8, v12
    v.exp2.approx v8, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v12, v11, v10, v14              // the exact rounding error of x*log2(e)
    vf.mul       v10, v12, v13
    vf.fma       v11, v8, v10, v8                // 2**t * 2**d
    vf.cmp.o     p2, v11, v11
    @p2 v.sel        v10, v11, v8
    vf.add       v8, v6, v10
    @p1 v.st.w       [s12, #0], v10
    @p1 v.sel        v10, v8, v6
    v.mov        v9, v10
    v.mov        v6, v9
    s.mov        s5, s9
    br.nz        s10, for_4
endfor_5:
    vf.reduce.add.b v0, v6
    vf.add       v2, v0, v3
    s.addi       s5, s8, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s6, #0
    s.st.d       [s5, #0], s11
    s.movz       s6, #384
    s.st.d       [s5, #8], s6
    s.movz       s6, #96
    s.st.d       [s5, #16], s6
    s.movz       s6, #384
    s.st.d       [s5, #48], s6
    s.movz       s6, #4
    s.st.d       [s5, #56], s6
    .li       s6, #68719476737
    s.st.d       [s5, #88], s6
    .li       s6, #2207613190144
    s.st.d       [s5, #104], s6
    fence.release.device
    td.load      d1, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s5, s1, #0
for_6:
    s.cmp.ge     s1, s5, s2
    br.nz        s1, endfor_7
    v.extract    s1, v2, #0
    v.splat      v0, s5
    v.splat      v3, s1
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s1, #96
    v.rcp.approx v7, v3                          // ISA 8.8: <= 2**-22 relative
    s.movz       s6, #384
    s.muli       s7, s4, #384
    v.add        v8, v0, v6
    v.movi       v0, #0
    v.splat      v6, s1
    v.splat      v9, s4
    v.movi       v10, #0
    s.muli       s1, s5, #4
    v.cmp.ge     p1, v8, v0
    v.splat      v0, s6
    v.cmp.lt     p2, v8, v6
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v0
    s.add        s6, s11, s7
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    .li       s7, #1065353216
    v.splat      v0, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s7, s6, s1
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s7, #0]
    v.movi       v8, #0
    v.movi       v9, #1
    v.movi       v10, #0
    v.cmp.eq     p1, v1, v8
    s.mul        s1, s4, s2
    @p1 v.sel        v8, v9, v10
    vf.fms       v9, v3, v7, v0
    v.splat      v0, s5
    v.extract    s6, v8, #0
    v.movi       v3, #0
    v.splat      v8, s6
    vf.fms       v10, v7, v9, v7
    v.add        v9, v0, v5
    v.movi       v0, #96
    s.add        s6, s5, s1
    v.cmp.ne     p1, v8, v3
    vf.neg       v3, v10                         // Newton step: r0*(2 - x*r0)
    v.splat      v8, s1
    v.cmp.lt     p2, v9, v0
    s.shli       s1, s6, #2                      // element offset -> bytes (x4)
    s.add        s6, s5, s3
    vf.cmp.o     p3, v3, v3
    @p3 v.sel        v0, v3, v7
    s.add        s7, s11, s1                     // &in_out_ptr0[...]
    s.movz       s1, #1
    vf.mul       v3, v6, v0                      // a/y as a refined reciprocal (ISA has no divide)
    v.add        v0, v9, v8
    @p1 v.sel        v0, v4, v3
    @p2 v.st.w       [s7, #0], v0
    s.mov        s5, s6
    br.nz        s1, for_6
endfor_7:
__rctx_next:
    exit
