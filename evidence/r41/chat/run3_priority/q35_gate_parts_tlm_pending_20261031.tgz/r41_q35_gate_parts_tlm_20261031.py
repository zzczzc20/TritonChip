#!/usr/bin/env python3
"""Decompose first gated RMS norm on identical real operands, CPU vs DP TLM."""
import json,sys,time
from pathlib import Path
import torch
from torch import nn
import torch.nn.functional as F
from safetensors.torch import load_file,save_file
h=Path.home();tree=h/'r41_q35_multiturn_diag_20261031';sys.path[:0]=[str(tree/'tools/models'),str(tree),str(tree/'python'),str(tree/'compiler/python'),str(tree/'tools/asm')]
import chat
class Parts(nn.Module):
 def __init__(self,norm):super().__init__();self.weight=nn.Parameter(norm.weight.detach().clone());self.eps=norm.variance_epsilon
 def forward(self,x,z):
  v=x.float().pow(2).mean(-1,keepdim=True);r=torch.rsqrt(v+self.eps);n=x.float()*r;w=self.weight*n.to(x.dtype);s=F.silu(z.float());p=w*s;return v,r,n,w,s,p,p.to(x.dtype)
chat.L.use_tnca(str(tree));args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1'])
start=time.monotonic();app=chat.ChatApplication(args);src=load_file(str(h/'r41_q35_first_delta_cpu_20261031_diag/states.safetensors'));x=src['norm_input_core'];z=src['norm_input_z'];expected=src['linear_attn.norm'];part=Parts(app.model.model.language_model.layers[0].linear_attn.norm).eval()
with torch.no_grad():cpu=tuple(t.contiguous().clone() for t in part(x,z))
if not torch.equal(cpu[-1],expected):raise ValueError('CPU reconstruction does not match captured reference')
stage,dev=chat.L.place(part,'tnca','eager')
with torch.no_grad():tlm=tuple(t.detach().cpu().contiguous().clone() for t in stage(x.to(dev),z.to(dev)))
names=('variance','rsqrt','normalized','weighted','silu','product','output');rows={};saved={}
for name,a,b in zip(names,cpu,tlm):
 if a.dtype!=b.dtype or a.shape!=b.shape:raise ValueError('mismatch '+name)
 it={2:torch.int16,4:torch.int32}.get(a.element_size())
 if it is None:raise ValueError('dtype '+str(a.dtype))
 af=a.float();bf=b.float();d=(af-bf).abs();rows[name]={'shape':list(a.shape),'dtype':str(a.dtype),'elements':a.numel(),'bit_mismatches':int((a.view(it)!=b.view(it)).sum()),'rel_l2':float((af-bf).norm()/af.norm().clamp_min(1e-30)),'max_abs':float(d.max())};saved['cpu_'+name]=a;saved['tlm_'+name]=b
previous=load_file(str(h/'r41_q35_gate_norm_tlm_20261031_diag/states.safetensors'))['got'];rows['output_vs_original_tlm']={'elements':previous.numel(),'bit_mismatches':int((previous.view(torch.int16)!=tlm[-1].view(torch.int16)).sum())}
out=h/'r41_q35_gate_parts_tlm_20261031_diag';out.mkdir(exist_ok=False);save_file(saved,str(out/'states.safetensors'))
r={'schema':'r41-q35-gated-norm-parts-tlm/1','scope':'instrumented standalone graph CPU vs DP TLM on same captured operands, not full graph or board','cpu_reconstruction_bitwise':True,'parts':rows,'seconds':time.monotonic()-start}
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
