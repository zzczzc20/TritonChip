    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.movz       s3, #0
    s.rdspecial  s5, arg_base
    s.rdspecial  s6, arg_base
    s.mul        s7, s1, s2
    s.ld.d       s1, [s5, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.muli       s2, s3, #4
    s.movz       s8, #32
    s.ld.d       s9, [s6, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s6, #16
    s.movz       s10, #64
    s.add        s11, s9, s7                     // this context's own scratch
    s.ld.d       s7, [s5, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    s.addi       s5, s11, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s9, #4
    .li       s12, #68719476737
    .li       s13, #2207613190144
    s.st.d       [s5, #0], s1
    s.addi       s14, s11, #256                  // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s11, #0
    s.st.d       [s5, #8], s8
    s.movz       s8, #32
    s.movz       s15, #0
    s.st.d       [s5, #16], s6
    s.movz       s6, #16
    s.movz       s16, #0
    s.st.d       [s5, #48], s10
    s.movz       s10, #64
    s.movz       s17, #0
    s.st.d       [s5, #56], s9
    s.movz       s9, #4
    s.movz       s18, #0
    s.st.d       [s5, #88], s12
    .li       s12, #68719476737
    s.movz       s19, #0
    s.st.d       [s5, #104], s13
    .li       s13, #2207613190144
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.splat      v0, s4
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    v.cmp.lt     p1, v0, v1
    s.st.d       [s14, #0], s7
    s.movz       s5, #0
    s.movz       s20, #0
    v.sub        v3, v1, v0
    s.st.d       [s14, #8], s8
    s.movz       s8, #0
    @p1 v.sel        v4, v3, v0
    s.st.d       [s14, #16], s6
    s.movz       s6, #0
    s.movz       s21, #0
    s.st.d       [s14, #48], s10
    s.movz       s10, #0
    v.movi       v0, #15
    s.st.d       [s14, #56], s9
    s.movz       s9, #0
    v.and        v3, v4, v0
    s.st.d       [s14, #88], s12
    s.movz       s12, #0
    v.sub        v0, v1, v3
    s.st.d       [s14, #104], s13
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s13, #0
    @p1 v.sel        v4, v0, v3
    s.movz       s14, #0
    v.movi       v0, #16
    s.movz       s22, #0
    v.cmp.lt     p1, v2, v0
    s.movz       s23, #0
    s.muli       s24, s4, #64
    s.movz       s25, #0
    s.movz       s26, #0
    s.movz       s27, #0
    v.splat      v0, s3
    s.add        s28, s1, s24
    s.movz       s1, #0
    v.iota       v3                              // arange(0, VLEN)
    s.add        s24, s28, s2
    s.movz       s2, #0
    v.add        v5, v0, v3
    s.movz       s28, #0
    v.movi       v0, #0
    s.movz       s29, #0
    v.cmp.ge     p2, v5, v0
    s.movz       s30, #0
    v.cmpi.lt    p3, v5, #16
    s.movz       s31, #0
    p.and        p4, p2, p3
    s.movz       s32, #0
    v.splat      v0, s4
    s.movz       s33, #0
    v.movi       v3, #0
    s.movz       s34, #0
    v.cmp.ge     p2, v0, v3
    s.movz       s35, #0
    v.cmpi.lt    p3, v0, #32
    s.movz       s36, #0
    v.movi       v0, #-1
    p.and        p5, p2, p3
    v.mul        v3, v4, v0
    p.and        p2, p4, p5
    v.extract    s37, v3, #0
    v.splat      v0, s37
    v.movi       v3, #0
    v.add        v4, v2, v0
    v.movi       v0, #0
    v.extract    s37, v4, #0
    s.shli       s38, s37, #32
    v.extract    s37, v4, #1
    s.ashri      s39, s38, #32
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s24, #0]
    s.lshri      s24, s39, #32
    v.insert     v3, s39, #0
    v.insert     v0, s24, #0
    s.muli       s24, s3, #4
    s.shli       s38, s37, #32
    v.movi       v6, #16
    v.extract    s37, v4, #2
    s.ashri      s39, s38, #32
    v.sub        v7, v1, v6
    s.lshri      s38, s39, #32
    v.insert     v3, s39, #1
    v.insert     v0, s38, #1
    v.cmp.lt     p2, v6, v1
    s.shli       s38, s37, #32
    @p2 v.sel        v1, v7, v6
    v.extract    s37, v4, #3
    s.ashri      s39, s38, #32
    s.shli       s38, s37, #32
    v.extract    s37, v4, #4
    s.lshri      s40, s39, #32
    s.ashri      s41, s38, #32
    s.shli       s38, s37, #32
    v.extract    s37, v4, #5
    v.insert     v3, s39, #2
    v.insert     v0, s40, #2
    s.lshri      s39, s41, #32
    s.ashri      s40, s38, #32
    s.shli       s38, s37, #32
    v.extract    s37, v4, #6
    v.insert     v3, s41, #3
    v.insert     v0, s39, #3
    s.lshri      s39, s40, #32
    s.ashri      s41, s38, #32
    s.shli       s38, s37, #32
    v.extract    s37, v4, #7
    v.insert     v3, s40, #4
    v.insert     v0, s39, #4
    s.lshri      s39, s41, #32
    s.ashri      s40, s38, #32
    s.shli       s38, s37, #32
    v.extract    s37, v4, #8
    v.insert     v3, s41, #5
    v.insert     v0, s39, #5
    s.lshri      s39, s40, #32
    s.ashri      s41, s38, #32
    s.shli       s38, s37, #32
    v.extract    s37, v4, #9
    v.insert     v3, s40, #6
    v.insert     v0, s39, #6
    s.lshri      s39, s41, #32
    s.ashri      s40, s38, #32
    s.shli       s38, s37, #32
    v.extract    s37, v4, #10
    v.insert     v3, s41, #7
    v.insert     v0, s39, #7
    s.lshri      s39, s40, #32
    s.ashri      s41, s38, #32
    s.shli       s38, s37, #32
    v.extract    s37, v4, #11
    v.insert     v3, s40, #8
    v.insert     v0, s39, #8
    s.lshri      s39, s41, #32
    s.ashri      s40, s38, #32
    s.shli       s38, s37, #32
    v.extract    s37, v4, #12
    v.insert     v3, s41, #9
    v.insert     v0, s39, #9
    s.lshri      s39, s40, #32
    s.ashri      s41, s38, #32
    s.shli       s38, s37, #32
    v.extract    s37, v4, #13
    v.insert     v3, s40, #10
    v.insert     v0, s39, #10
    s.lshri      s39, s41, #32
    s.ashri      s40, s38, #32
    s.shli       s38, s37, #32
    v.extract    s37, v4, #14
    v.insert     v3, s41, #11
    v.insert     v0, s39, #11
    s.lshri      s39, s40, #32
    s.ashri      s41, s38, #32
    s.shli       s38, s37, #32
    v.extract    s37, v4, #15
    v.insert     v3, s40, #12
    v.insert     v0, s39, #12
    s.lshri      s39, s41, #32
    s.ashri      s40, s38, #32
    s.shli       s38, s37, #32
    v.insert     v3, s41, #13
    v.insert     v0, s39, #13
    s.lshri      s37, s40, #32
    s.ashri      s39, s38, #32
    v.insert     v3, s40, #14
    v.insert     v0, s37, #14
    s.lshri      s37, s39, #32
    v.insert     v3, s39, #15
    v.insert     v0, s37, #15
    v.extract    s37, v3, #0
    v.extract    s38, v0, #0
    s.shli       s39, s38, #32
    v.extract    s38, v0, #1
    s.or         s40, s37, s39
    s.shli       s37, s38, #32
    v.extract    s38, v3, #1
    v.extract    s39, v0, #2
    v.movi       v1, #0
    s.cmp.le     s41, s40, s11
    s.or         s11, s38, s37
    s.shli       s37, s39, #32
    v.extract    s38, v3, #2
    v.extract    s39, v0, #3
    v.insert     v1, s41, #0
    s.cmp.le     s40, s11, s15
    s.or         s11, s38, s37
    s.shli       s15, s39, #32
    v.extract    s37, v3, #3
    v.extract    s38, v0, #4
    v.insert     v1, s40, #1
    s.cmp.le     s39, s11, s16
    s.or         s11, s37, s15
    s.shli       s15, s38, #32
    v.extract    s16, v3, #4
    v.extract    s37, v0, #5
    v.insert     v1, s39, #2
    s.cmp.le     s38, s11, s17
    s.or         s11, s16, s15
    s.shli       s15, s37, #32
    v.extract    s16, v3, #5
    v.extract    s17, v0, #6
    v.insert     v1, s38, #3
    s.cmp.le     s37, s11, s18
    s.or         s11, s16, s15
    s.shli       s15, s17, #32
    v.extract    s16, v3, #6
    v.extract    s17, v0, #7
    v.insert     v1, s37, #4
    s.cmp.le     s18, s11, s19
    s.or         s11, s16, s15
    s.shli       s15, s17, #32
    v.extract    s16, v3, #7
    v.extract    s17, v0, #8
    v.insert     v1, s18, #5
    s.cmp.le     s18, s11, s5
    s.or         s5, s16, s15
    s.shli       s11, s17, #32
    v.extract    s15, v3, #8
    v.extract    s16, v0, #9
    v.insert     v1, s18, #6
    s.cmp.le     s17, s5, s20
    s.or         s5, s15, s11
    s.shli       s11, s16, #32
    v.extract    s15, v3, #9
    v.extract    s16, v0, #10
    v.insert     v1, s17, #7
    s.cmp.le     s17, s5, s8
    s.or         s5, s15, s11
    s.shli       s8, s16, #32
    v.extract    s11, v3, #10
    v.extract    s15, v0, #11
    v.insert     v1, s17, #8
    s.cmp.le     s16, s5, s6
    s.or         s5, s11, s8
    s.shli       s6, s15, #32
    v.extract    s8, v3, #11
    v.extract    s11, v0, #12
    v.insert     v1, s16, #9
    s.cmp.le     s15, s5, s21
    s.or         s5, s8, s6
    s.shli       s6, s11, #32
    v.extract    s8, v3, #12
    v.extract    s11, v0, #13
    v.insert     v1, s15, #10
    s.cmp.le     s15, s5, s10
    s.or         s5, s8, s6
    s.shli       s6, s11, #32
    v.extract    s8, v3, #13
    v.extract    s10, v0, #14
    v.insert     v1, s15, #11
    s.cmp.le     s11, s5, s9
    s.or         s5, s8, s6
    s.shli       s6, s10, #32
    v.extract    s8, v3, #14
    v.extract    s9, v0, #15
    v.insert     v1, s11, #12
    s.cmp.le     s10, s5, s12
    s.or         s5, s8, s6
    s.shli       s6, s9, #32
    v.extract    s8, v3, #15
    v.insert     v1, s10, #13
    s.cmp.le     s9, s5, s13
    s.or         s5, s8, s6
    v.insert     v1, s9, #14
    s.cmp.le     s6, s5, s14
    v.movi       v0, #0
    v.insert     v1, s6, #15
    v.movi       v3, #0
    .li       s5, #4286578688
    v.splat      v4, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p2, v1, v0
    @p2 v.sel        v0, v3, v4
    v.movi       v1, #1
    vf.add       v6, v5, v0
    v.movi       v0, #0
    v.movi       v5, #0
    v.movi       v7, #1
    vf.cmp.eq    p2, v6, v4
    @p2 v.sel        v8, v1, v0
    v.movi       v0, #0
    v.cmp.eq     p2, v8, v5
    @p2 v.sel        v1, v7, v0
    v.movi       v0, #1
    v.movi       v5, #0
    v.extract    s5, v1, #0
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.movi       v7, #0
    v.movi       v8, #0
    s.lshri      s6, s5, #32
    v.extract    s8, v1, #1
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s5, #0
    v.insert     v8, s6, #0
    s.lshri      s5, s8, #32
    v.extract    s6, v1, #2
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s8, #1
    v.insert     v8, s5, #1
    s.lshri      s5, s6, #32
    v.extract    s8, v1, #3
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s6, #2
    v.insert     v8, s5, #2
    s.lshri      s5, s8, #32
    v.extract    s6, v1, #4
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s8, #3
    v.insert     v8, s5, #3
    s.lshri      s5, s6, #32
    v.extract    s8, v1, #5
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s6, #4
    v.insert     v8, s5, #4
    s.lshri      s5, s8, #32
    v.extract    s6, v1, #6
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s8, #5
    v.insert     v8, s5, #5
    s.lshri      s5, s6, #32
    v.extract    s8, v1, #7
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s6, #6
    v.insert     v8, s5, #6
    s.lshri      s5, s8, #32
    v.extract    s6, v1, #8
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s8, #7
    v.insert     v8, s5, #7
    s.lshri      s5, s6, #32
    v.extract    s8, v1, #9
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s6, #8
    v.insert     v8, s5, #8
    s.lshri      s5, s8, #32
    v.extract    s6, v1, #10
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s8, #9
    v.insert     v8, s5, #9
    s.lshri      s5, s6, #32
    v.extract    s8, v1, #11
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s6, #10
    v.insert     v8, s5, #10
    s.lshri      s5, s8, #32
    v.extract    s6, v1, #12
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s8, #11
    v.insert     v8, s5, #11
    s.lshri      s5, s6, #32
    v.extract    s8, v1, #13
    @p2 v.sel        v1, v0, v5
    v.movi       v0, #1
    v.movi       v5, #0
    v.insert     v7, s6, #12
    v.insert     v8, s5, #12
    s.lshri      s5, s8, #32
    v.extract    s6, v1, #14
    @p2 v.sel        v1, v0, v5
    v.insert     v7, s8, #13
    v.insert     v8, s5, #13
    s.lshri      s5, s6, #32
    v.extract    s8, v1, #15
    v.insert     v7, s6, #14
    v.insert     v8, s5, #14
    s.lshri      s5, s8, #32
    v.insert     v7, s8, #15
    v.insert     v8, s5, #15
    v.extract    s5, v7, #0
    v.extract    s6, v8, #0
    s.shli       s8, s6, #32
    v.extract    s6, v8, #1
    s.or         s9, s5, s8
    s.shli       s5, s6, #32
    v.extract    s6, v7, #1
    v.extract    s8, v8, #2
    v.movi       v0, #0
    s.cmp.ne     s10, s9, s22
    s.or         s9, s6, s5
    s.shli       s5, s8, #32
    v.extract    s6, v7, #2
    v.extract    s8, v8, #3
    v.insert     v0, s10, #0
    s.cmp.ne     s10, s9, s23
    s.or         s9, s6, s5
    s.shli       s5, s8, #32
    v.extract    s6, v7, #3
    v.extract    s8, v8, #4
    v.insert     v0, s10, #1
    s.cmp.ne     s10, s9, s25
    s.or         s9, s6, s5
    s.shli       s5, s8, #32
    v.extract    s6, v7, #4
    v.extract    s8, v8, #5
    v.insert     v0, s10, #2
    s.cmp.ne     s10, s9, s26
    s.or         s9, s6, s5
    s.shli       s5, s8, #32
    v.extract    s6, v7, #5
    v.extract    s8, v8, #6
    v.insert     v0, s10, #3
    s.cmp.ne     s10, s9, s27
    s.or         s9, s6, s5
    s.shli       s5, s8, #32
    v.extract    s6, v7, #6
    v.extract    s8, v8, #7
    v.insert     v0, s10, #4
    s.cmp.ne     s10, s9, s1
    s.or         s1, s6, s5
    s.shli       s5, s8, #32
    v.extract    s6, v7, #7
    v.extract    s8, v8, #8
    v.insert     v0, s10, #5
    s.cmp.ne     s9, s1, s2
    s.or         s1, s6, s5
    s.shli       s2, s8, #32
    v.extract    s5, v7, #8
    v.extract    s6, v8, #9
    v.insert     v0, s9, #6
    s.cmp.ne     s8, s1, s28
    s.or         s1, s5, s2
    s.shli       s2, s6, #32
    v.extract    s5, v7, #9
    v.extract    s6, v8, #10
    v.insert     v0, s8, #7
    s.cmp.ne     s8, s1, s29
    s.or         s1, s5, s2
    s.shli       s2, s6, #32
    v.extract    s5, v7, #10
    v.extract    s6, v8, #11
    v.insert     v0, s8, #8
    @p1 v.sel        v1, v6, v4
    s.cmp.ne     s8, s1, s30
    s.or         s1, s5, s2
    s.shli       s2, s6, #32
    v.extract    s5, v7, #11
    v.extract    s6, v8, #12
    v.insert     v0, s8, #9
    vf.reduce.max.b v4, v1
    s.cmp.ne     s8, s1, s31
    vf.cmp.uo    p2, v1, v1
    s.or         s1, s5, s2
    s.shli       s2, s6, #32
    v.extract    s5, v7, #12
    v.extract    s6, v8, #13
    v.insert     v0, s8, #10
    v.movi       v1, #1
    v.movi       v5, #0
    v.movi       v9, #0
    @p2 v.sel        v10, v1, v5
    s.cmp.ne     s8, s1, s32
    v.reduce.or.b v1, v10
    s.or         s1, s5, s2
    v.cmp.ne     p2, v1, v9
    s.shli       s2, s6, #32
    v.extract    s5, v7, #13
    v.extract    s6, v8, #14
    v.insert     v0, s8, #11
    .li       s8, #2143289344
    v.splat      v1, s8                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v5, #0
    @p2 v.sel        v9, v1, v4
    s.cmp.ne     s8, s1, s33
    vf.add       v1, v9, v5
    s.or         s1, s5, s2
    s.shli       s2, s6, #32
    v.extract    s5, v7, #14
    v.extract    s6, v1, #0
    v.splat      v1, s6
    v.extract    s6, v8, #15
    v.insert     v0, s8, #12
    vf.sub       v4, v6, v1
    .li       s8, #1069066811
    v.splat      v1, s8                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.cmp.ne     s8, s1, s34
    .li       s1, #1060205080
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v8, v4, v1
    s.or         s1, s5, s2
    s.shli       s2, s6, #32
    v.extract    s5, v7, #15
    v.exp2.approx v7, v8                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v4, v1, v8                  // the exact rounding error of x*log2(e)
    v.insert     v0, s8, #13
    s.cmp.ne     s6, s1, s35
    s.or         s1, s5, s2
    vf.mul       v1, v9, v6
    v.insert     v0, s6, #14
    s.cmp.ne     s2, s1, s36
    s.shli       s1, s4, #4                      // x16 as a shift
    v.insert     v0, s2, #15
    v.movi       v4, #0
    v.movi       v6, #0
    v.movi       v8, #0
    p.not        p2, p1
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    v.cmp.ne     p3, v0, v4
    s.muli       s5, s4, #64
    v.cmp.ne     p4, v6, v8
    p.and        p5, p1, p3
    v.splat      v0, s3
    v.iota       v4                              // arange(0, VLEN)
    s.add        s3, s7, s5
    p.and        p3, p2, p4
    v.add        v6, v0, v4
    s.add        s5, s7, s2                      // &in_out_ptr0[...]
    s.add        s6, s3, s24
    p.or         p2, p5, p3
    vf.fma       v0, v7, v1, v7                  // 2**t * 2**d
    v.movi       v1, #0
    v.movi       v4, #1
    v.cmp.ge     p3, v6, v1
    vf.cmp.o     p4, v0, v0
    @p4 v.sel        v1, v0, v7
    v.cmpi.lt    p4, v6, #16
    vf.add       v0, v1, v3
    v.movi       v6, #0
    p.and        p5, p3, p4
    @p1 v.st.w       [s5, #0], v1
    @p1 v.sel        v1, v0, v3
    fence.acq_rel.device
    vf.reduce.add.b v0, v1
    @p2 v.sel        v1, v4, v6
    vf.add       v4, v0, v5
    v.splat      v0, s4
    v.reduce.or  s3, v1
    v.movi       v1, #0
    v.splat      v5, s3
    v.extract    s3, v4, #0
    v.splat      v4, s3
    .li       s3, #1065353216
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v7, v4                          // ISA 8.8: <= 2**-22 relative
    v.cmp.ge     p2, v0, v1
    v.cmpi.lt    p3, v0, #32
    p.and        p4, p2, p3
    v.movi       v0, #0
    p.and        p2, p5, p4
    v.movi       v1, #1
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s6, #0]
    v.movi       v9, #0
    v.cmp.eq     p2, v5, v0
    @p2 v.sel        v0, v1, v9
    v.movi       v1, #0
    v.extract    s3, v0, #0
    v.splat      v0, s3
    v.splat      v5, s1
    v.cmp.ne     p2, v0, v1
    s.add        s1, s7, s2                      // &in_out_ptr0[...]
    v.add        v0, v2, v5
    vf.fms       v0, v4, v7, v6
    vf.fms       v1, v7, v0, v7
    vf.neg       v0, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v0, v0
    @p3 v.sel        v1, v0, v7
    vf.mul       v0, v8, v1                      // a/y as a refined reciprocal (ISA has no divide)
    @p2 v.sel        v1, v3, v0
    @p1 v.st.w       [s1, #0], v1
__rctx_next:
    exit
