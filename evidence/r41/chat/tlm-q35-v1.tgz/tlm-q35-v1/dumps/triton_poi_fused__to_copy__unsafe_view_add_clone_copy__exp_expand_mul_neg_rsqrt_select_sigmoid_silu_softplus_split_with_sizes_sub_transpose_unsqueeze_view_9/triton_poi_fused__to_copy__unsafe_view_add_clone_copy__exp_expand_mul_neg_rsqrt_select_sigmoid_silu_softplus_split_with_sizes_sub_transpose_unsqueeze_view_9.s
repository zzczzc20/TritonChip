    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s2, arg_base
    v.add        v3, v1, v0
    v.movi       v0, #14
    s.ld.d       s3, [s2, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.movi       v4, #0
    @p1 v.sel        v5, v1, v3
    v.movi       v1, #7
    v.sub        v6, v4, v3
    v.lshr       v7, v5, v0
    v.cmp.lt     p2, v3, v4
    @p2 v.sel        v0, v6, v3
    v.sub        v5, v2, v7
    v.movi       v6, #0
    v.lshr       v8, v0, v1
    @p1 v.sel        v0, v5, v7
    v.movi       v1, #0
    v.sub        v5, v4, v8
    v.movi       v7, #127
    s.ld.d       s4, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    @p2 v.sel        v9, v5, v8
    v.movi       v5, #128
    v.movi       v8, #16384
    v.sub        v10, v1, v9
    v.cmp.lt     p1, v9, v1
    v.sub        v11, v2, v8
    @p1 v.sel        v12, v10, v9
    v.sub        v9, v4, v5
    v.sub        v10, v1, v5
    v.and        v13, v12, v7
    s.ld.d       s5, [s2, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    v.cmp.lt     p2, v8, v2
    v.sub        v2, v1, v13
    v.cmp.lt     p3, v5, v4
    @p2 v.sel        v4, v11, v8
    @p1 v.sel        v4, v2, v13
    v.cmp.lt     p1, v5, v1
    @p3 v.sel        v1, v9, v5
    @p1 v.sel        v1, v10, v5
    s.ld.d       s6, [s2, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s7, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.cmp.lt     p1, v3, v6
    s.ld.d       s8, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v1, v6, v3
    v.sub        v2, v6, v5
    v.cmp.lt     p2, v5, v6
    @p1 v.sel        v7, v1, v3
    @p2 v.sel        v1, v2, v5
    s.ld.d       s9, [s2, #48]                   // out_ptr0: device_ptr64 at arg_base+48
    v.movi       v1, #127
    s.ld.d       s10, [s2, #56]                  // out_ptr1: device_ptr64 at arg_base+56
    .li       s2, #897988541
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #0
    v.and        v8, v7, v1
    v.movi       v1, #1
    v.sub        v7, v3, v0
    v.cmp.lt     p2, v0, v3
    v.sub        v9, v6, v8
    @p2 v.sel        v6, v7, v0
    v.movi       v7, #4096
    @p1 v.sel        v10, v9, v8
    v.ld.gather.w v8, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.lshr       v9, v6, v1
    v.add        v1, v10, v7
    v.mul        v6, v0, v5
    v.sub        v7, v3, v9
    v.movi       v11, #2048
    v.add        v12, v1, v6
    @p2 v.sel        v1, v7, v9
    v.add        v7, v10, v6
    v.add        v6, v4, v11
    v.mul        v4, v1, v5
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    .li       s1, #1077936128
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v5, v6, v4
    .li       s1, #3204448256
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s1, s7, s2                      // &in_ptr0[...]
    v.movi       v6, #2
    s.add        s3, s9, s2                      // &out_ptr0[...]
    vf.add       v9, v8, v2
    v.ld.gather.h v2, [s4, v12]                  // index is in elements (ISA sec 9.1)
    v.sub        v8, v3, v6
    v.cmp.lt     p1, v6, v3
    v.rsqrt.approx v3, v9                        // ISA 8.8: <= 2**-22 relative
    @p1 v.sel        v10, v8, v6
    v.ld.gather.w v6, [s5, v7]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v7, v2
    v.ld.gather.h v2, [s4, v5]                   // index is in elements (ISA sec 9.1)
    vf.mul       v5, v3, v3
    vf.mul       v8, v3, v4
    vf.sub       v4, v7, v6
    vf.fms       v6, v9, v5, v1
    vf.mul       v1, v8, v6                      // Newton step: 0.5*r0*(3 - x*r0^2)
    v.ld.gather.w v5, [s6, v0]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v6, v2
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v2, v1, v3
    vf.mul       v1, v6, v2
    v.ld.w       v2, [s1, #0]
    vf.mul       v3, v4, v5
    vf.mul       v4, v1, v3
    v.ld.gather.w v1, [s8, v0]                   // index is in elements (ISA sec 9.1)
    s.add        s1, s10, s2                     // &out_ptr1[...]
    vf.mul       v0, v2, v1
    vf.add       v1, v0, v4
    v.st.w       [s3, #0], v1
    v.st.w       [s1, #0], v1
__rctx_next:
    exit
