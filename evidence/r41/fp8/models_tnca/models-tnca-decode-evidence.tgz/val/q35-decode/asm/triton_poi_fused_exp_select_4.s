    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #64
    v.add        v3, v1, v0
    s.rdspecial  s2, arg_base
    v.mul        v0, v3, v2
    v.movi       v1, #63
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v2, #32
    v.add        v4, v0, v1
    v.cmp.lt     p1, v3, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s3, v4]               // index is in elements (ISA sec 9.1)
    .li       s3, #1069066811
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1060205080
    v.splat      v2, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s3, s1, #2                      // element offset -> bytes (x4)
    vf.mul       v3, v0, v1
    s.ld.d       s1, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.exp2.approx v4, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v0, v1, v3                  // the exact rounding error of x*log2(e)
    s.add        s2, s1, s3                      // &out_ptr0[...]
    vf.mul       v0, v5, v2
    vf.fma       v1, v4, v0, v4                  // 2**t * 2**d
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v0, v1, v4
    @p1 v.st.w       [s2, #0], v0
__rctx_next:
    exit
