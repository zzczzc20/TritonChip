
        mb.arm s3, b0, #0, #1
        p.frombits p1, s0
        @p1 t.ld.async.h w0, d0, s10, s3
        mb.wait s3
        mb.test s4, s3
        .li s5, #0x60000
        s.st.d [s5, #0], s4
        exit
    