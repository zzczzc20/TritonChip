#!/bin/bash
# run_cfg.sh OUT_NAME CONFIG_NAME CORESET JOBS POINT... : one what-if configuration over points
set -uo pipefail
source ~/tc_env/env.sh
W=~/r41-pmac-model-work
out=$1; cfg=$2; cores=$3; jobs=$4; shift 4
pts=(); for p in "$@"; do pts+=(--point "$p"); done
binary=${BINARY:-$HOME/r41-pmac-model-build/mod/tnca-chip}
export MAX_JOBS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
taskset -c $cores $TORCH_PYTHON -u ~/r41-pmac-model/tools/performance_harness/systemc/run_graphs.py \
  --source-root ~/r41-pmac-model-sw --binary $binary --config $W/tools/configs/$cfg.cfg \
  --points-module $W/tools/pmac_points.py --out $W/runs/$out --jobs $jobs --untimed-cold --monitor ${MONITOR:-aggregate} \
  --torch-extensions-dir $W/torch-ext --dram-path fast \
  --env TNCA_ACTIVE_CORES=3 --env TNCA_TRANSFER_POLICY=resident --env TNCA_RTL_MEM_PORTS=3 --env TNCA_RTL_OUTSTANDING=8 \
  --env TNCA_DRAM_MAP=$W/tools/b40-dram-map.txt ${EXTRA_ENV:-} "${pts[@]}" > $W/runs/$out.log 2>&1
echo EXIT=$? >> $W/runs/$out.log
