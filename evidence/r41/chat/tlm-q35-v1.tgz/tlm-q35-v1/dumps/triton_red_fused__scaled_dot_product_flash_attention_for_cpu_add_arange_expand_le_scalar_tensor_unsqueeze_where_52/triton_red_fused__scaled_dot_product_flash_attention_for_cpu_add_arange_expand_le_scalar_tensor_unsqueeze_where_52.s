    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr4: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #512
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s8, #0
    s.st.d       [s7, #0], s2
    s.movz       s8, #240
    s.st.d       [s7, #8], s8
    s.movz       s8, #64
    s.st.d       [s7, #16], s8
    s.movz       s8, #256
    s.st.d       [s7, #48], s8
    s.movz       s8, #4
    s.st.d       [s7, #56], s8
    .li       s8, #68719476737
    s.st.d       [s7, #88], s8
    .li       s8, #2207613190144
    s.st.d       [s7, #104], s8
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    s.ld.d       s7, [s3, #0]                    // one element, not a vector
    v.movi       v2, #0
    v.movi       v3, #0
    v.insert     v2, s7, #0
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #0
    v.insert     v2, s7, #1
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #1
    v.insert     v2, s7, #2
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #2
    v.insert     v2, s7, #3
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #3
    v.insert     v2, s7, #4
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #4
    v.insert     v2, s7, #5
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #5
    v.insert     v2, s7, #6
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #6
    v.insert     v2, s7, #7
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #7
    v.insert     v2, s7, #8
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #8
    v.insert     v2, s7, #9
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #9
    v.insert     v2, s7, #10
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #10
    v.insert     v2, s7, #11
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #11
    v.insert     v2, s7, #12
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #12
    v.insert     v2, s7, #13
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #13
    v.insert     v2, s7, #14
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #14
    v.insert     v2, s7, #15
    s.lshri      s3, s7, #32
    v.insert     v3, s3, #15
    v.movi       v4, #15
    v.movi       v5, #0
    v.movi       v6, #1
    v.cmp.lt     p1, v0, v5
    v.cmp.lt     p2, v4, v5
    v.sub        v7, v5, v0
    @p1 v.sel        v8, v7, v0
    v.sub        v0, v5, v4
    @p2 v.sel        v7, v0, v4
    v.movi       v0, #0
    v.movi       v4, #0
    s.movz       s3, #31
idiv_1:
    v.splat      v9, s3
    v.shl        v10, v4, v6
    v.cmp.lt     p2, v4, v5
    v.lshr       v11, v8, v9
    v.shl        v12, v6, v9
    s.subi       s7, s3, #1
    v.and        v9, v11, v6
    s.movz       s8, #0
    v.or         v11, v10, v9
    v.cmp.geu    p3, v11, v7
    p.or         p4, p2, p3
    v.sub        v9, v11, v7
    @p4 v.sel        v10, v12, v5
    @p4 v.sel        v12, v9, v11
    v.or         v9, v0, v10
    v.mov        v4, v12
    v.mov        v0, v9
    s.mov        s3, s7
    s.cmp.ge     s7, s3, s8
    br.nz        s7, idiv_1
    v.movi       v0, #0
    v.movi       v6, #0
    v.sub        v7, v5, v4
    .li       s3, #4286578688
    v.splat      v5, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v8, #0
    s.movz       s3, #0
    v.cmp.ne     p2, v0, v6
    @p1 v.sel        v0, v7, v4
    s.movz       s7, #64
    s.movz       s8, #16
    s.addi       s9, s3, #0
    p.mov        p1, p2
    v.mov        v8, v5
for_2:
    s.cmp.ge     s10, s9, s7
    br.nz        s10, endfor_3
    v.splat      v4, s9
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s10, #64
    s.movz       s11, #240
    s.muli       s12, s4, #256
    v.add        v7, v4, v6
    v.movi       v4, #0
    v.splat      v6, s10
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s11
    v.extract    s10, v0, #0
    s.muli       s11, s9, #4
    s.shli       s13, s10, #32
    v.cmp.ge     p2, v7, v4
    v.cmp.lt     p3, v7, v6
    v.cmp.ge     p4, v9, v10
    v.cmp.lt     p5, v9, v11
    s.add        s10, s2, s12
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.ashri      s12, s13, #32
    v.movi       v4, #0
    v.movi       v6, #0
    s.add        s13, s10, s11
    p.and        p3, p6, p2
    s.lshri      s10, s12, #32
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v7, [s13, #0]
    v.insert     v4, s12, #0
    v.insert     v6, s10, #0
    v.movi       v9, #0
    v.extract    s10, v4, #0
    v.extract    s11, v6, #0
    v.extract    s12, v6, #0
    s.shli       s13, s11, #32
    v.movi       v10, #0
    s.or         s11, s10, s13
    v.extract    s10, v4, #0
    s.shli       s13, s12, #32
    s.lshri      s12, s11, #32
    s.or         s14, s10, s13
    v.insert     v9, s11, #0
    v.insert     v10, s12, #0
    v.splat      v11, s9
    s.lshri      s10, s14, #32
    v.insert     v9, s14, #1
    v.add        v12, v11, v1
    v.insert     v10, s10, #1
    v.movi       v11, #64
    v.extract    s10, v4, #0
    v.cmp.lt     p2, v12, v11
    v.extract    s11, v6, #0
    v.extract    s12, v6, #0
    s.shli       s13, s11, #32
    v.extract    s11, v4, #0
    s.or         s14, s10, s13
    s.shli       s10, s12, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v6, #0
    s.or         s15, s11, s10
    v.insert     v9, s14, #2
    v.insert     v10, s12, #2
    v.extract    s10, v4, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v6, #0
    s.or         s14, s10, s11
    v.insert     v9, s15, #3
    v.insert     v10, s12, #3
    v.extract    s10, v4, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v6, #0
    s.or         s15, s10, s11
    v.insert     v9, s14, #4
    v.insert     v10, s12, #4
    v.extract    s10, v4, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v6, #0
    s.or         s14, s10, s11
    v.insert     v9, s15, #5
    v.insert     v10, s12, #5
    v.extract    s10, v4, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v6, #0
    s.or         s15, s10, s11
    v.insert     v9, s14, #6
    v.insert     v10, s12, #6
    v.extract    s10, v4, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v6, #0
    s.or         s14, s10, s11
    v.insert     v9, s15, #7
    v.insert     v10, s12, #7
    v.extract    s10, v4, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v6, #0
    s.or         s15, s10, s11
    v.insert     v9, s14, #8
    v.insert     v10, s12, #8
    v.extract    s10, v4, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v6, #0
    s.or         s14, s10, s11
    v.insert     v9, s15, #9
    v.insert     v10, s12, #9
    v.extract    s10, v4, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v6, #0
    s.or         s15, s10, s11
    v.insert     v9, s14, #10
    v.insert     v10, s12, #10
    v.extract    s10, v4, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v6, #0
    s.or         s14, s10, s11
    v.insert     v9, s15, #11
    v.insert     v10, s12, #11
    v.extract    s10, v4, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v6, #0
    s.or         s15, s10, s11
    v.insert     v9, s14, #12
    v.insert     v10, s12, #12
    v.extract    s10, v4, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v6, #0
    s.or         s14, s10, s11
    v.insert     v9, s15, #13
    v.insert     v10, s12, #13
    v.extract    s10, v4, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    s.or         s13, s10, s11
    v.insert     v9, s14, #14
    v.insert     v10, s12, #14
    s.lshri      s10, s13, #32
    v.insert     v9, s13, #15
    v.insert     v10, s10, #15
    v.extract    s10, v3, #0
    v.extract    s11, v9, #0
    v.extract    s12, v10, #0
    v.extract    s13, v2, #0
    s.shli       s14, s12, #32
    s.shli       s12, s10, #32
    v.extract    s10, v10, #1
    v.extract    s15, v3, #1
    s.or         s16, s11, s14
    s.or         s11, s13, s12
    v.extract    s12, v9, #1
    s.shli       s13, s10, #32
    v.extract    s10, v2, #1
    s.shli       s14, s15, #32
    s.add        s15, s16, s11
    v.extract    s11, v10, #2
    v.extract    s16, v3, #2
    v.movi       v4, #0
    v.movi       v6, #0
    s.or         s17, s12, s13
    s.or         s12, s10, s14
    s.lshri      s10, s15, #32
    v.extract    s13, v9, #2
    s.shli       s14, s11, #32
    s.shli       s11, s16, #32
    s.add        s16, s17, s12
    v.extract    s12, v2, #2
    v.insert     v4, s15, #0
    v.extract    s15, v10, #3
    v.insert     v6, s10, #0
    v.extract    s10, v3, #3
    s.or         s17, s13, s14
    s.or         s13, s12, s11
    s.lshri      s11, s16, #32
    v.extract    s12, v9, #3
    s.shli       s14, s15, #32
    s.shli       s15, s10, #32
    s.add        s10, s17, s13
    v.extract    s13, v2, #3
    v.insert     v4, s16, #1
    v.extract    s16, v10, #4
    v.insert     v6, s11, #1
    v.extract    s11, v3, #4
    s.or         s17, s12, s14
    s.or         s12, s13, s15
    s.lshri      s13, s10, #32
    v.extract    s14, v9, #4
    s.shli       s15, s16, #32
    s.shli       s16, s11, #32
    s.add        s11, s17, s12
    v.extract    s12, v2, #4
    v.insert     v4, s10, #2
    v.extract    s10, v10, #5
    v.insert     v6, s13, #2
    v.extract    s13, v3, #5
    s.or         s17, s14, s15
    s.or         s14, s12, s16
    s.lshri      s12, s11, #32
    v.extract    s15, v9, #5
    s.shli       s16, s10, #32
    s.shli       s10, s13, #32
    s.add        s13, s17, s14
    v.extract    s14, v2, #5
    v.insert     v4, s11, #3
    v.extract    s11, v10, #6
    v.insert     v6, s12, #3
    v.extract    s12, v3, #6
    s.or         s17, s15, s16
    s.or         s15, s14, s10
    s.lshri      s10, s13, #32
    v.extract    s14, v9, #6
    s.shli       s16, s11, #32
    s.shli       s11, s12, #32
    s.add        s12, s17, s15
    v.extract    s15, v2, #6
    v.insert     v4, s13, #4
    v.extract    s13, v10, #7
    v.insert     v6, s10, #4
    v.extract    s10, v3, #7
    s.or         s17, s14, s16
    s.or         s14, s15, s11
    s.lshri      s11, s12, #32
    v.extract    s15, v9, #7
    s.shli       s16, s13, #32
    s.shli       s13, s10, #32
    s.add        s10, s17, s14
    v.extract    s14, v2, #7
    v.insert     v4, s12, #5
    v.extract    s12, v10, #8
    v.insert     v6, s11, #5
    v.extract    s11, v3, #8
    s.or         s17, s15, s16
    s.or         s15, s14, s13
    s.lshri      s13, s10, #32
    v.extract    s14, v9, #8
    s.shli       s16, s12, #32
    s.shli       s12, s11, #32
    s.add        s11, s17, s15
    v.extract    s15, v2, #8
    v.insert     v4, s10, #6
    v.extract    s10, v10, #9
    v.insert     v6, s13, #6
    v.extract    s13, v3, #9
    s.or         s17, s14, s16
    s.or         s14, s15, s12
    s.lshri      s12, s11, #32
    v.extract    s15, v9, #9
    s.shli       s16, s10, #32
    s.shli       s10, s13, #32
    s.add        s13, s17, s14
    v.extract    s14, v2, #9
    v.insert     v4, s11, #7
    v.extract    s11, v10, #10
    v.insert     v6, s12, #7
    v.extract    s12, v3, #10
    s.or         s17, s15, s16
    s.or         s15, s14, s10
    s.lshri      s10, s13, #32
    v.extract    s14, v9, #10
    s.shli       s16, s11, #32
    s.shli       s11, s12, #32
    s.add        s12, s17, s15
    v.extract    s15, v2, #10
    v.insert     v4, s13, #8
    v.extract    s13, v10, #11
    v.insert     v6, s10, #8
    v.extract    s10, v3, #11
    s.or         s17, s14, s16
    s.or         s14, s15, s11
    s.lshri      s11, s12, #32
    v.extract    s15, v9, #11
    s.shli       s16, s13, #32
    s.shli       s13, s10, #32
    s.add        s10, s17, s14
    v.extract    s14, v2, #11
    v.insert     v4, s12, #9
    v.extract    s12, v10, #12
    v.insert     v6, s11, #9
    v.extract    s11, v3, #12
    s.or         s17, s15, s16
    s.or         s15, s14, s13
    s.lshri      s13, s10, #32
    v.extract    s14, v9, #12
    s.shli       s16, s12, #32
    s.shli       s12, s11, #32
    s.add        s11, s17, s15
    v.extract    s15, v2, #12
    v.insert     v4, s10, #10
    v.extract    s10, v10, #13
    v.insert     v6, s13, #10
    v.extract    s13, v3, #13
    s.or         s17, s14, s16
    s.or         s14, s15, s12
    s.lshri      s12, s11, #32
    v.extract    s15, v9, #13
    s.shli       s16, s10, #32
    s.shli       s10, s13, #32
    s.add        s13, s17, s14
    v.extract    s14, v2, #13
    v.insert     v4, s11, #11
    v.extract    s11, v10, #14
    v.insert     v6, s12, #11
    v.extract    s12, v3, #14
    s.or         s17, s15, s16
    s.or         s15, s14, s10
    s.lshri      s10, s13, #32
    v.extract    s14, v9, #14
    s.shli       s16, s11, #32
    s.shli       s11, s12, #32
    s.add        s12, s17, s15
    v.extract    s15, v2, #14
    v.insert     v4, s13, #12
    v.extract    s13, v10, #15
    v.insert     v6, s10, #12
    v.extract    s10, v3, #15
    s.or         s17, s14, s16
    s.or         s14, s15, s11
    s.lshri      s11, s12, #32
    v.extract    s15, v9, #15
    s.shli       s16, s13, #32
    s.shli       s13, s10, #32
    s.add        s10, s17, s14
    v.extract    s14, v2, #15
    v.insert     v4, s12, #13
    v.extract    s12, v12, #0
    v.insert     v6, s11, #13
    s.or         s11, s15, s16
    s.or         s15, s14, s13
    s.shli       s13, s12, #32
    s.lshri      s12, s10, #32
    v.extract    s14, v12, #1
    s.add        s16, s11, s15
    s.ashri      s11, s13, #32
    v.insert     v4, s10, #14
    v.insert     v6, s12, #14
    v.movi       v9, #0
    v.movi       v10, #0
    s.shli       s10, s14, #32
    s.lshri      s12, s16, #32
    s.lshri      s13, s11, #32
    v.extract    s14, v12, #2
    s.ashri      s15, s10, #32
    v.insert     v4, s16, #15
    v.insert     v6, s12, #15
    v.insert     v9, s11, #0
    v.insert     v10, s13, #0
    s.shli       s10, s14, #32
    s.lshri      s11, s15, #32
    v.extract    s12, v12, #3
    s.ashri      s13, s10, #32
    v.insert     v9, s15, #1
    v.insert     v10, s11, #1
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v12, #4
    s.ashri      s14, s10, #32
    v.insert     v9, s13, #2
    v.insert     v10, s11, #2
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v12, #5
    s.ashri      s13, s10, #32
    v.insert     v9, s14, #3
    v.insert     v10, s11, #3
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v12, #6
    s.ashri      s14, s10, #32
    v.insert     v9, s13, #4
    v.insert     v10, s11, #4
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v12, #7
    s.ashri      s13, s10, #32
    v.insert     v9, s14, #5
    v.insert     v10, s11, #5
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v12, #8
    s.ashri      s14, s10, #32
    v.insert     v9, s13, #6
    v.insert     v10, s11, #6
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v12, #9
    s.ashri      s13, s10, #32
    v.insert     v9, s14, #7
    v.insert     v10, s11, #7
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v12, #10
    s.ashri      s14, s10, #32
    v.insert     v9, s13, #8
    v.insert     v10, s11, #8
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v12, #11
    s.ashri      s13, s10, #32
    v.insert     v9, s14, #9
    v.insert     v10, s11, #9
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v12, #12
    s.ashri      s14, s10, #32
    v.insert     v9, s13, #10
    v.insert     v10, s11, #10
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v12, #13
    s.ashri      s13, s10, #32
    v.insert     v9, s14, #11
    v.insert     v10, s11, #11
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v12, #14
    s.ashri      s14, s10, #32
    v.insert     v9, s13, #12
    v.insert     v10, s11, #12
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v12, #15
    s.ashri      s13, s10, #32
    v.insert     v9, s14, #13
    v.insert     v10, s11, #13
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    s.ashri      s12, s10, #32
    v.insert     v9, s13, #14
    v.insert     v10, s11, #14
    s.lshri      s10, s12, #32
    v.insert     v9, s12, #15
    v.insert     v10, s10, #15
    v.extract    s10, v6, #0
    v.extract    s11, v9, #0
    v.extract    s12, v10, #0
    v.extract    s13, v4, #0
    s.shli       s14, s12, #32
    s.shli       s12, s10, #32
    v.extract    s10, v10, #1
    v.extract    s15, v6, #1
    s.or         s16, s11, s14
    s.or         s11, s13, s12
    v.movi       v11, #0
    v.extract    s12, v9, #1
    s.shli       s13, s10, #32
    v.extract    s10, v4, #1
    s.shli       s14, s15, #32
    s.cmp.le     s15, s16, s11
    v.extract    s11, v10, #2
    v.extract    s16, v6, #2
    s.or         s17, s12, s13
    s.or         s12, s10, s14
    v.insert     v11, s15, #0
    v.extract    s10, v9, #2
    s.shli       s13, s11, #32
    v.extract    s11, v4, #2
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s12
    v.extract    s12, v10, #3
    v.extract    s16, v6, #3
    s.or         s17, s10, s13
    s.or         s10, s11, s14
    v.insert     v11, s15, #1
    v.extract    s11, v9, #3
    s.shli       s13, s12, #32
    v.extract    s12, v4, #3
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s10
    v.extract    s10, v10, #4
    v.extract    s16, v6, #4
    s.or         s17, s11, s13
    s.or         s11, s12, s14
    v.insert     v11, s15, #2
    v.extract    s12, v9, #4
    s.shli       s13, s10, #32
    v.extract    s10, v4, #4
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s11
    v.extract    s11, v10, #5
    v.extract    s16, v6, #5
    s.or         s17, s12, s13
    s.or         s12, s10, s14
    v.insert     v11, s15, #3
    v.extract    s10, v9, #5
    s.shli       s13, s11, #32
    v.extract    s11, v4, #5
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s12
    v.extract    s12, v10, #6
    v.extract    s16, v6, #6
    s.or         s17, s10, s13
    s.or         s10, s11, s14
    v.insert     v11, s15, #4
    v.extract    s11, v9, #6
    s.shli       s13, s12, #32
    v.extract    s12, v4, #6
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s10
    v.extract    s10, v10, #7
    v.extract    s16, v6, #7
    s.or         s17, s11, s13
    s.or         s11, s12, s14
    v.insert     v11, s15, #5
    v.extract    s12, v9, #7
    s.shli       s13, s10, #32
    v.extract    s10, v4, #7
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s11
    v.extract    s11, v10, #8
    v.extract    s16, v6, #8
    s.or         s17, s12, s13
    s.or         s12, s10, s14
    v.insert     v11, s15, #6
    v.extract    s10, v9, #8
    s.shli       s13, s11, #32
    v.extract    s11, v4, #8
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s12
    v.extract    s12, v10, #9
    v.extract    s16, v6, #9
    s.or         s17, s10, s13
    s.or         s10, s11, s14
    v.insert     v11, s15, #7
    v.extract    s11, v9, #9
    s.shli       s13, s12, #32
    v.extract    s12, v4, #9
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s10
    v.extract    s10, v10, #10
    v.extract    s16, v6, #10
    s.or         s17, s11, s13
    s.or         s11, s12, s14
    v.insert     v11, s15, #8
    v.extract    s12, v9, #10
    s.shli       s13, s10, #32
    v.extract    s10, v4, #10
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s11
    v.extract    s11, v10, #11
    v.extract    s16, v6, #11
    s.or         s17, s12, s13
    s.or         s12, s10, s14
    v.insert     v11, s15, #9
    v.extract    s10, v9, #11
    s.shli       s13, s11, #32
    v.extract    s11, v4, #11
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s12
    v.extract    s12, v10, #12
    v.extract    s16, v6, #12
    s.or         s17, s10, s13
    s.or         s10, s11, s14
    v.insert     v11, s15, #10
    v.extract    s11, v9, #12
    s.shli       s13, s12, #32
    v.extract    s12, v4, #12
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s10
    v.extract    s10, v10, #13
    v.extract    s16, v6, #13
    s.or         s17, s11, s13
    s.or         s11, s12, s14
    v.insert     v11, s15, #11
    v.extract    s12, v9, #13
    s.shli       s13, s10, #32
    v.extract    s10, v4, #13
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s11
    v.extract    s11, v10, #14
    v.extract    s16, v6, #14
    s.or         s17, s12, s13
    s.or         s12, s10, s14
    v.insert     v11, s15, #12
    v.extract    s10, v9, #14
    s.shli       s13, s11, #32
    v.extract    s11, v4, #14
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s12
    v.extract    s12, v10, #15
    v.extract    s16, v6, #15
    s.or         s17, s10, s13
    s.or         s10, s11, s14
    v.insert     v11, s15, #13
    v.extract    s11, v9, #15
    s.shli       s13, s12, #32
    v.extract    s12, v4, #15
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s10
    s.or         s10, s11, s13
    s.or         s11, s12, s14
    v.insert     v11, s15, #14
    s.cmp.le     s12, s10, s11
    v.movi       v4, #0
    v.insert     v11, s12, #15
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.ne     p3, v11, v4
    @p3 v.sel        v4, v6, v5
    v.movi       v6, #0
    v.movi       v10, #0
    vf.add       v11, v7, v4
    v.movi       v4, #1
    v.movi       v7, #0
    v.movi       v12, #1
    v.movi       v13, #0
    vf.cmp.eq    p3, v11, v5
    @p3 v.sel        v14, v9, v6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.eq     p3, v14, v10
    @p3 v.sel        v10, v4, v7
    @p3 v.sel        v4, v12, v13
    v.movi       v7, #0
    v.extract    s10, v10, #0
    v.movi       v10, #0
    s.lshri      s11, s10, #32
    v.extract    s12, v4, #1
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s10, #0
    v.insert     v10, s11, #0
    s.lshri      s10, s12, #32
    v.extract    s11, v4, #2
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s12, #1
    v.insert     v10, s10, #1
    s.lshri      s10, s11, #32
    v.extract    s12, v4, #3
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s11, #2
    v.insert     v10, s10, #2
    s.lshri      s10, s12, #32
    v.extract    s11, v4, #4
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s12, #3
    v.insert     v10, s10, #3
    s.lshri      s10, s11, #32
    v.extract    s12, v4, #5
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s11, #4
    v.insert     v10, s10, #4
    s.lshri      s10, s12, #32
    v.extract    s11, v4, #6
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s12, #5
    v.insert     v10, s10, #5
    s.lshri      s10, s11, #32
    v.extract    s12, v4, #7
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s11, #6
    v.insert     v10, s10, #6
    s.lshri      s10, s12, #32
    v.extract    s11, v4, #8
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s12, #7
    v.insert     v10, s10, #7
    s.lshri      s10, s11, #32
    v.extract    s12, v4, #9
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s11, #8
    v.insert     v10, s10, #8
    s.lshri      s10, s12, #32
    v.extract    s11, v4, #10
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s12, #9
    v.insert     v10, s10, #9
    s.lshri      s10, s11, #32
    v.extract    s12, v4, #11
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s11, #10
    v.insert     v10, s10, #10
    s.lshri      s10, s12, #32
    v.extract    s11, v4, #12
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s12, #11
    v.insert     v10, s10, #11
    s.lshri      s10, s11, #32
    v.extract    s12, v4, #13
    @p3 v.sel        v4, v6, v9
    v.movi       v6, #1
    v.movi       v9, #0
    v.insert     v7, s11, #12
    v.insert     v10, s10, #12
    s.lshri      s10, s12, #32
    v.extract    s11, v4, #14
    @p3 v.sel        v4, v6, v9
    v.insert     v7, s12, #13
    v.insert     v10, s10, #13
    s.lshri      s10, s11, #32
    v.extract    s12, v4, #15
    v.insert     v7, s11, #14
    v.insert     v10, s10, #14
    s.lshri      s10, s12, #32
    v.insert     v7, s12, #15
    v.insert     v10, s10, #15
    s.movz       s10, #0
    v.extract    s11, v7, #0
    v.extract    s12, v10, #0
    v.extract    s13, v10, #1
    s.shli       s14, s12, #32
    v.movi       v4, #0
    s.or         s12, s11, s14
    v.extract    s11, v7, #1
    s.shli       s14, s13, #32
    s.cmp.ne     s13, s12, s10
    v.extract    s10, v10, #2
    s.or         s12, s11, s14
    s.movz       s11, #0
    v.insert     v4, s13, #0
    v.extract    s13, v7, #2
    s.shli       s14, s10, #32
    s.cmp.ne     s10, s12, s11
    v.extract    s11, v10, #3
    s.or         s12, s13, s14
    s.movz       s13, #0
    v.insert     v4, s10, #1
    v.extract    s10, v7, #3
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s12, s13
    v.extract    s12, v10, #4
    s.or         s13, s10, s14
    s.movz       s10, #0
    v.insert     v4, s11, #2
    v.extract    s11, v7, #4
    s.shli       s14, s12, #32
    s.cmp.ne     s12, s13, s10
    v.extract    s10, v10, #5
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v4, s12, #3
    v.extract    s12, v7, #5
    s.shli       s14, s10, #32
    s.cmp.ne     s10, s13, s11
    v.extract    s11, v10, #6
    s.or         s13, s12, s14
    s.movz       s12, #0
    v.insert     v4, s10, #4
    v.extract    s10, v7, #6
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s13, s12
    v.extract    s12, v10, #7
    s.or         s13, s10, s14
    s.movz       s10, #0
    v.insert     v4, s11, #5
    v.extract    s11, v7, #7
    s.shli       s14, s12, #32
    s.cmp.ne     s12, s13, s10
    v.extract    s10, v10, #8
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v4, s12, #6
    v.extract    s12, v7, #8
    s.shli       s14, s10, #32
    s.cmp.ne     s10, s13, s11
    v.extract    s11, v10, #9
    s.or         s13, s12, s14
    s.movz       s12, #0
    v.insert     v4, s10, #7
    v.extract    s10, v7, #9
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s13, s12
    v.extract    s12, v10, #10
    s.or         s13, s10, s14
    s.movz       s10, #0
    v.insert     v4, s11, #8
    v.extract    s11, v7, #10
    s.shli       s14, s12, #32
    s.cmp.ne     s12, s13, s10
    v.extract    s10, v10, #11
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v4, s12, #9
    v.extract    s12, v7, #11
    s.shli       s14, s10, #32
    s.cmp.ne     s10, s13, s11
    v.extract    s11, v10, #12
    s.or         s13, s12, s14
    s.movz       s12, #0
    v.insert     v4, s10, #10
    v.extract    s10, v7, #12
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s13, s12
    v.extract    s12, v10, #13
    s.or         s13, s10, s14
    s.movz       s10, #0
    v.insert     v4, s11, #11
    v.extract    s11, v7, #13
    s.shli       s14, s12, #32
    s.cmp.ne     s12, s13, s10
    v.extract    s10, v10, #14
    s.or         s13, s11, s14
    s.movz       s11, #0
    v.insert     v4, s12, #12
    v.extract    s12, v7, #14
    s.shli       s14, s10, #32
    s.cmp.ne     s10, s13, s11
    v.extract    s11, v10, #15
    s.or         s13, s12, s14
    s.movz       s12, #0
    v.insert     v4, s10, #13
    v.extract    s10, v7, #15
    s.shli       s14, s11, #32
    s.cmp.ne     s11, s13, s12
    s.or         s12, s10, s14
    s.movz       s10, #0
    v.insert     v4, s11, #14
    s.cmp.ne     s11, s12, s10
    v.movi       v6, #0
    v.insert     v4, s11, #15
    vf.max       v7, v8, v11
    p.not        p3, p2
    v.cmp.ne     p4, v4, v6
    p.or         p5, p1, p4
    p.and        p4, p3, p1
    p.and        p3, p2, p5
    @p2 v.sel        v4, v7, v8
    v.movi       v6, #0
    p.or         p2, p3, p4
    s.add        s10, s9, s8
    p.mov        p3, p2
    v.mov        v6, v4
    s.movz       s11, #1
    p.mov        p1, p3
    v.mov        v8, v6
    s.mov        s9, s10
    br.nz        s11, for_2
endfor_3:
    v.movi       v4, #1
    v.movi       v6, #0
    vf.cmp.uo    p2, v8, v8
    v.movi       v7, #1
    @p2 v.sel        v9, v4, v6
    v.movi       v4, #0
    v.movi       v6, #0
    v.reduce.or.b v10, v9
    vf.reduce.max.b v9, v8
    .li       s9, #2143289344
    v.splat      v8, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v11, v7, v4
    v.cmp.ne     p1, v10, v6
    @p1 v.sel        v4, v8, v9
    v.movi       v6, #0
    v.movi       v7, #0
    v.movi       v8, #0
    v.reduce.or  s9, v11
    vf.add       v9, v4, v6
    v.splat      v4, s9
    s.addi       s9, s3, #0
    v.mov        v8, v7
for_4:
    s.cmp.ge     s10, s9, s7
    br.nz        s10, endfor_5
    v.splat      v10, s9
    v.iota       v11                             // arange(0, VLEN)
    s.movz       s10, #64
    s.movz       s11, #240
    s.muli       s12, s4, #256
    v.add        v12, v10, v11
    v.movi       v10, #0
    v.splat      v11, s10
    v.splat      v13, s4
    v.movi       v14, #0
    v.splat      v15, s11
    v.extract    s10, v0, #0
    s.muli       s11, s9, #4
    s.shli       s13, s10, #32
    v.cmp.ge     p1, v12, v10
    v.cmp.lt     p2, v12, v11
    v.cmp.ge     p3, v13, v14
    v.cmp.lt     p4, v13, v15
    s.add        s10, s2, s12
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.ashri      s12, s13, #32
    v.movi       v10, #0
    v.movi       v11, #0
    s.add        s13, s10, s11
    p.and        p2, p5, p1
    s.lshri      s10, s12, #32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v12, [s13, #0]
    v.insert     v10, s12, #0
    v.insert     v11, s10, #0
    v.movi       v13, #0
    v.extract    s10, v10, #0
    v.extract    s11, v11, #0
    v.extract    s12, v11, #0
    s.shli       s13, s11, #32
    v.movi       v14, #0
    s.or         s11, s10, s13
    v.extract    s10, v10, #0
    s.shli       s13, s12, #32
    s.lshri      s12, s11, #32
    s.or         s14, s10, s13
    v.insert     v13, s11, #0
    v.insert     v14, s12, #0
    v.splat      v15, s9
    s.lshri      s10, s14, #32
    v.insert     v13, s14, #1
    v.add        v16, v15, v1
    v.insert     v14, s10, #1
    v.movi       v15, #64
    v.extract    s10, v10, #0
    v.cmp.lt     p1, v16, v15
    v.extract    s11, v11, #0
    v.extract    s12, v11, #0
    s.shli       s13, s11, #32
    v.extract    s11, v10, #0
    s.or         s14, s10, s13
    s.shli       s10, s12, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v11, #0
    s.or         s15, s11, s10
    v.insert     v13, s14, #2
    v.insert     v14, s12, #2
    v.extract    s10, v10, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v11, #0
    s.or         s14, s10, s11
    v.insert     v13, s15, #3
    v.insert     v14, s12, #3
    v.extract    s10, v10, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v11, #0
    s.or         s15, s10, s11
    v.insert     v13, s14, #4
    v.insert     v14, s12, #4
    v.extract    s10, v10, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v11, #0
    s.or         s14, s10, s11
    v.insert     v13, s15, #5
    v.insert     v14, s12, #5
    v.extract    s10, v10, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v11, #0
    s.or         s15, s10, s11
    v.insert     v13, s14, #6
    v.insert     v14, s12, #6
    v.extract    s10, v10, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v11, #0
    s.or         s14, s10, s11
    v.insert     v13, s15, #7
    v.insert     v14, s12, #7
    v.extract    s10, v10, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v11, #0
    s.or         s15, s10, s11
    v.insert     v13, s14, #8
    v.insert     v14, s12, #8
    v.extract    s10, v10, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v11, #0
    s.or         s14, s10, s11
    v.insert     v13, s15, #9
    v.insert     v14, s12, #9
    v.extract    s10, v10, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v11, #0
    s.or         s15, s10, s11
    v.insert     v13, s14, #10
    v.insert     v14, s12, #10
    v.extract    s10, v10, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v11, #0
    s.or         s14, s10, s11
    v.insert     v13, s15, #11
    v.insert     v14, s12, #11
    v.extract    s10, v10, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    v.extract    s13, v11, #0
    s.or         s15, s10, s11
    v.insert     v13, s14, #12
    v.insert     v14, s12, #12
    v.extract    s10, v10, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s15, #32
    v.extract    s13, v11, #0
    s.or         s14, s10, s11
    v.insert     v13, s15, #13
    v.insert     v14, s12, #13
    v.extract    s10, v10, #0
    s.shli       s11, s13, #32
    s.lshri      s12, s14, #32
    s.or         s13, s10, s11
    v.insert     v13, s14, #14
    v.insert     v14, s12, #14
    s.lshri      s10, s13, #32
    v.insert     v13, s13, #15
    v.insert     v14, s10, #15
    v.extract    s10, v3, #0
    v.extract    s11, v13, #0
    v.extract    s12, v14, #0
    v.extract    s13, v2, #0
    s.shli       s14, s12, #32
    s.shli       s12, s10, #32
    v.extract    s10, v14, #1
    v.extract    s15, v3, #1
    s.or         s16, s11, s14
    s.or         s11, s13, s12
    v.extract    s12, v13, #1
    s.shli       s13, s10, #32
    v.extract    s10, v2, #1
    s.shli       s14, s15, #32
    s.add        s15, s16, s11
    v.extract    s11, v14, #2
    v.extract    s16, v3, #2
    v.movi       v10, #0
    v.movi       v11, #0
    s.or         s17, s12, s13
    s.or         s12, s10, s14
    s.lshri      s10, s15, #32
    v.extract    s13, v13, #2
    s.shli       s14, s11, #32
    s.shli       s11, s16, #32
    s.add        s16, s17, s12
    v.extract    s12, v2, #2
    v.insert     v10, s15, #0
    v.extract    s15, v14, #3
    v.insert     v11, s10, #0
    v.extract    s10, v3, #3
    s.or         s17, s13, s14
    s.or         s13, s12, s11
    s.lshri      s11, s16, #32
    v.extract    s12, v13, #3
    s.shli       s14, s15, #32
    s.shli       s15, s10, #32
    s.add        s10, s17, s13
    v.extract    s13, v2, #3
    v.insert     v10, s16, #1
    v.extract    s16, v14, #4
    v.insert     v11, s11, #1
    v.extract    s11, v3, #4
    s.or         s17, s12, s14
    s.or         s12, s13, s15
    s.lshri      s13, s10, #32
    v.extract    s14, v13, #4
    s.shli       s15, s16, #32
    s.shli       s16, s11, #32
    s.add        s11, s17, s12
    v.extract    s12, v2, #4
    v.insert     v10, s10, #2
    v.extract    s10, v14, #5
    v.insert     v11, s13, #2
    v.extract    s13, v3, #5
    s.or         s17, s14, s15
    s.or         s14, s12, s16
    s.lshri      s12, s11, #32
    v.extract    s15, v13, #5
    s.shli       s16, s10, #32
    s.shli       s10, s13, #32
    s.add        s13, s17, s14
    v.extract    s14, v2, #5
    v.insert     v10, s11, #3
    v.extract    s11, v14, #6
    v.insert     v11, s12, #3
    v.extract    s12, v3, #6
    s.or         s17, s15, s16
    s.or         s15, s14, s10
    s.lshri      s10, s13, #32
    v.extract    s14, v13, #6
    s.shli       s16, s11, #32
    s.shli       s11, s12, #32
    s.add        s12, s17, s15
    v.extract    s15, v2, #6
    v.insert     v10, s13, #4
    v.extract    s13, v14, #7
    v.insert     v11, s10, #4
    v.extract    s10, v3, #7
    s.or         s17, s14, s16
    s.or         s14, s15, s11
    s.lshri      s11, s12, #32
    v.extract    s15, v13, #7
    s.shli       s16, s13, #32
    s.shli       s13, s10, #32
    s.add        s10, s17, s14
    v.extract    s14, v2, #7
    v.insert     v10, s12, #5
    v.extract    s12, v14, #8
    v.insert     v11, s11, #5
    v.extract    s11, v3, #8
    s.or         s17, s15, s16
    s.or         s15, s14, s13
    s.lshri      s13, s10, #32
    v.extract    s14, v13, #8
    s.shli       s16, s12, #32
    s.shli       s12, s11, #32
    s.add        s11, s17, s15
    v.extract    s15, v2, #8
    v.insert     v10, s10, #6
    v.extract    s10, v14, #9
    v.insert     v11, s13, #6
    v.extract    s13, v3, #9
    s.or         s17, s14, s16
    s.or         s14, s15, s12
    s.lshri      s12, s11, #32
    v.extract    s15, v13, #9
    s.shli       s16, s10, #32
    s.shli       s10, s13, #32
    s.add        s13, s17, s14
    v.extract    s14, v2, #9
    v.insert     v10, s11, #7
    v.extract    s11, v14, #10
    v.insert     v11, s12, #7
    v.extract    s12, v3, #10
    s.or         s17, s15, s16
    s.or         s15, s14, s10
    s.lshri      s10, s13, #32
    v.extract    s14, v13, #10
    s.shli       s16, s11, #32
    s.shli       s11, s12, #32
    s.add        s12, s17, s15
    v.extract    s15, v2, #10
    v.insert     v10, s13, #8
    v.extract    s13, v14, #11
    v.insert     v11, s10, #8
    v.extract    s10, v3, #11
    s.or         s17, s14, s16
    s.or         s14, s15, s11
    s.lshri      s11, s12, #32
    v.extract    s15, v13, #11
    s.shli       s16, s13, #32
    s.shli       s13, s10, #32
    s.add        s10, s17, s14
    v.extract    s14, v2, #11
    v.insert     v10, s12, #9
    v.extract    s12, v14, #12
    v.insert     v11, s11, #9
    v.extract    s11, v3, #12
    s.or         s17, s15, s16
    s.or         s15, s14, s13
    s.lshri      s13, s10, #32
    v.extract    s14, v13, #12
    s.shli       s16, s12, #32
    s.shli       s12, s11, #32
    s.add        s11, s17, s15
    v.extract    s15, v2, #12
    v.insert     v10, s10, #10
    v.extract    s10, v14, #13
    v.insert     v11, s13, #10
    v.extract    s13, v3, #13
    s.or         s17, s14, s16
    s.or         s14, s15, s12
    s.lshri      s12, s11, #32
    v.extract    s15, v13, #13
    s.shli       s16, s10, #32
    s.shli       s10, s13, #32
    s.add        s13, s17, s14
    v.extract    s14, v2, #13
    v.insert     v10, s11, #11
    v.extract    s11, v14, #14
    v.insert     v11, s12, #11
    v.extract    s12, v3, #14
    s.or         s17, s15, s16
    s.or         s15, s14, s10
    s.lshri      s10, s13, #32
    v.extract    s14, v13, #14
    s.shli       s16, s11, #32
    s.shli       s11, s12, #32
    s.add        s12, s17, s15
    v.extract    s15, v2, #14
    v.insert     v10, s13, #12
    v.extract    s13, v14, #15
    v.insert     v11, s10, #12
    v.extract    s10, v3, #15
    s.or         s17, s14, s16
    s.or         s14, s15, s11
    s.lshri      s11, s12, #32
    v.extract    s15, v13, #15
    s.shli       s16, s13, #32
    s.shli       s13, s10, #32
    s.add        s10, s17, s14
    v.extract    s14, v2, #15
    v.insert     v10, s12, #13
    v.extract    s12, v16, #0
    v.insert     v11, s11, #13
    s.or         s11, s15, s16
    s.or         s15, s14, s13
    s.shli       s13, s12, #32
    s.lshri      s12, s10, #32
    v.extract    s14, v16, #1
    s.add        s16, s11, s15
    s.ashri      s11, s13, #32
    v.insert     v10, s10, #14
    v.insert     v11, s12, #14
    v.movi       v13, #0
    v.movi       v14, #0
    s.shli       s10, s14, #32
    s.lshri      s12, s16, #32
    s.lshri      s13, s11, #32
    v.extract    s14, v16, #2
    s.ashri      s15, s10, #32
    v.insert     v10, s16, #15
    v.insert     v11, s12, #15
    v.insert     v13, s11, #0
    v.insert     v14, s13, #0
    s.shli       s10, s14, #32
    s.lshri      s11, s15, #32
    v.extract    s12, v16, #3
    s.ashri      s13, s10, #32
    v.insert     v13, s15, #1
    v.insert     v14, s11, #1
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v16, #4
    s.ashri      s14, s10, #32
    v.insert     v13, s13, #2
    v.insert     v14, s11, #2
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v16, #5
    s.ashri      s13, s10, #32
    v.insert     v13, s14, #3
    v.insert     v14, s11, #3
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v16, #6
    s.ashri      s14, s10, #32
    v.insert     v13, s13, #4
    v.insert     v14, s11, #4
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v16, #7
    s.ashri      s13, s10, #32
    v.insert     v13, s14, #5
    v.insert     v14, s11, #5
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v16, #8
    s.ashri      s14, s10, #32
    v.insert     v13, s13, #6
    v.insert     v14, s11, #6
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v16, #9
    s.ashri      s13, s10, #32
    v.insert     v13, s14, #7
    v.insert     v14, s11, #7
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v16, #10
    s.ashri      s14, s10, #32
    v.insert     v13, s13, #8
    v.insert     v14, s11, #8
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v16, #11
    s.ashri      s13, s10, #32
    v.insert     v13, s14, #9
    v.insert     v14, s11, #9
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v16, #12
    s.ashri      s14, s10, #32
    v.insert     v13, s13, #10
    v.insert     v14, s11, #10
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v16, #13
    s.ashri      s13, s10, #32
    v.insert     v13, s14, #11
    v.insert     v14, s11, #11
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    v.extract    s12, v16, #14
    s.ashri      s14, s10, #32
    v.insert     v13, s13, #12
    v.insert     v14, s11, #12
    s.shli       s10, s12, #32
    s.lshri      s11, s14, #32
    v.extract    s12, v16, #15
    s.ashri      s13, s10, #32
    v.insert     v13, s14, #13
    v.insert     v14, s11, #13
    s.shli       s10, s12, #32
    s.lshri      s11, s13, #32
    s.ashri      s12, s10, #32
    v.insert     v13, s13, #14
    v.insert     v14, s11, #14
    s.lshri      s10, s12, #32
    v.insert     v13, s12, #15
    v.insert     v14, s10, #15
    v.extract    s10, v11, #0
    v.extract    s11, v13, #0
    v.extract    s12, v14, #0
    v.extract    s13, v10, #0
    s.shli       s14, s12, #32
    s.shli       s12, s10, #32
    v.extract    s10, v14, #1
    v.extract    s15, v11, #1
    s.or         s16, s11, s14
    s.or         s11, s13, s12
    v.movi       v15, #0
    v.extract    s12, v13, #1
    s.shli       s13, s10, #32
    v.extract    s10, v10, #1
    s.shli       s14, s15, #32
    s.cmp.le     s15, s16, s11
    v.extract    s11, v14, #2
    v.extract    s16, v11, #2
    s.or         s17, s12, s13
    s.or         s12, s10, s14
    v.insert     v15, s15, #0
    v.extract    s10, v13, #2
    s.shli       s13, s11, #32
    v.extract    s11, v10, #2
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s12
    v.extract    s12, v14, #3
    v.extract    s16, v11, #3
    s.or         s17, s10, s13
    s.or         s10, s11, s14
    v.insert     v15, s15, #1
    v.extract    s11, v13, #3
    s.shli       s13, s12, #32
    v.extract    s12, v10, #3
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s10
    v.extract    s10, v14, #4
    v.extract    s16, v11, #4
    s.or         s17, s11, s13
    s.or         s11, s12, s14
    v.insert     v15, s15, #2
    v.extract    s12, v13, #4
    s.shli       s13, s10, #32
    v.extract    s10, v10, #4
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s11
    v.extract    s11, v14, #5
    v.extract    s16, v11, #5
    s.or         s17, s12, s13
    s.or         s12, s10, s14
    v.insert     v15, s15, #3
    v.extract    s10, v13, #5
    s.shli       s13, s11, #32
    v.extract    s11, v10, #5
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s12
    v.extract    s12, v14, #6
    v.extract    s16, v11, #6
    s.or         s17, s10, s13
    s.or         s10, s11, s14
    v.insert     v15, s15, #4
    v.extract    s11, v13, #6
    s.shli       s13, s12, #32
    v.extract    s12, v10, #6
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s10
    v.extract    s10, v14, #7
    v.extract    s16, v11, #7
    s.or         s17, s11, s13
    s.or         s11, s12, s14
    v.insert     v15, s15, #5
    v.extract    s12, v13, #7
    s.shli       s13, s10, #32
    v.extract    s10, v10, #7
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s11
    v.extract    s11, v14, #8
    v.extract    s16, v11, #8
    s.or         s17, s12, s13
    s.or         s12, s10, s14
    v.insert     v15, s15, #6
    v.extract    s10, v13, #8
    s.shli       s13, s11, #32
    v.extract    s11, v10, #8
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s12
    v.extract    s12, v14, #9
    v.extract    s16, v11, #9
    s.or         s17, s10, s13
    s.or         s10, s11, s14
    v.insert     v15, s15, #7
    v.extract    s11, v13, #9
    s.shli       s13, s12, #32
    v.extract    s12, v10, #9
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s10
    v.extract    s10, v14, #10
    v.extract    s16, v11, #10
    s.or         s17, s11, s13
    s.or         s11, s12, s14
    v.insert     v15, s15, #8
    v.extract    s12, v13, #10
    s.shli       s13, s10, #32
    v.extract    s10, v10, #10
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s11
    v.extract    s11, v14, #11
    v.extract    s16, v11, #11
    s.or         s17, s12, s13
    s.or         s12, s10, s14
    v.insert     v15, s15, #9
    v.extract    s10, v13, #11
    s.shli       s13, s11, #32
    v.extract    s11, v10, #11
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s12
    v.extract    s12, v14, #12
    v.extract    s16, v11, #12
    s.or         s17, s10, s13
    s.or         s10, s11, s14
    v.insert     v15, s15, #10
    v.extract    s11, v13, #12
    s.shli       s13, s12, #32
    v.extract    s12, v10, #12
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s10
    v.extract    s10, v14, #13
    v.extract    s16, v11, #13
    s.or         s17, s11, s13
    s.or         s11, s12, s14
    v.insert     v15, s15, #11
    v.extract    s12, v13, #13
    s.shli       s13, s10, #32
    v.extract    s10, v10, #13
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s11
    v.extract    s11, v14, #14
    v.extract    s16, v11, #14
    s.or         s17, s12, s13
    s.or         s12, s10, s14
    v.insert     v15, s15, #12
    v.extract    s10, v13, #14
    s.shli       s13, s11, #32
    v.extract    s11, v10, #14
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s12
    v.extract    s12, v14, #15
    v.extract    s16, v11, #15
    s.or         s17, s10, s13
    s.or         s10, s11, s14
    v.insert     v15, s15, #13
    v.extract    s11, v13, #15
    s.shli       s13, s12, #32
    v.extract    s12, v10, #15
    s.shli       s14, s16, #32
    s.cmp.le     s15, s17, s10
    s.or         s10, s11, s13
    s.or         s11, s12, s14
    v.insert     v15, s15, #14
    s.cmp.le     s12, s10, s11
    v.movi       v10, #0
    v.insert     v15, s12, #15
    v.extract    s10, v9, #0
    .li       s11, #1069066811
    v.splat      v11, s11                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p2, v15, v10
    @p2 v.sel        v10, v7, v5
    v.splat      v13, s10
    .li       s10, #1060205080
    v.splat      v14, s10                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v15, v12, v10
    s.mul        s10, s4, s7
    v.movi       v10, #0
    s.add        s11, s9, s8
    s.movz       s12, #1
    vf.sub       v12, v15, v13
    s.add        s13, s9, s10
    v.splat      v13, s10
    s.shli       s10, s13, #2                    // element offset -> bytes (x4)
    vf.mul       v15, v12, v11
    s.add        s13, s5, s10                    // &out_ptr2[...]
    v.add        v17, v16, v13
    v.exp2.approx v13, v15                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v12, v11, v15              // the exact rounding error of x*log2(e)
    vf.mul       v11, v16, v14
    vf.fma       v12, v13, v11, v13              // 2**t * 2**d
    vf.cmp.o     p2, v12, v12
    @p2 v.sel        v11, v12, v13
    vf.add       v12, v8, v11
    @p1 v.st.w       [s13, #0], v11
    @p1 v.sel        v11, v12, v8
    v.mov        v10, v11
    v.mov        v8, v10
    s.mov        s9, s11
    br.nz        s12, for_4
endfor_5:
    vf.reduce.add.b v0, v8
    vf.add       v2, v0, v6
    s.addi       s2, s1, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s2, #0], s5
    s.movz       s1, #240
    s.st.d       [s2, #8], s1
    s.movz       s1, #64
    s.st.d       [s2, #16], s1
    s.movz       s1, #256
    s.st.d       [s2, #48], s1
    s.movz       s1, #4
    s.st.d       [s2, #56], s1
    .li       s1, #68719476737
    s.st.d       [s2, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s2, #104], s1
    fence.release.device
    td.load      d1, [s2]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s3, #0
for_6:
    s.cmp.ge     s2, s1, s7
    br.nz        s2, endfor_7
    v.extract    s2, v2, #0
    v.splat      v0, s1
    v.splat      v3, s2
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s2, #64
    v.rcp.approx v6, v3                          // ISA 8.8: <= 2**-22 relative
    s.movz       s3, #240
    s.muli       s9, s4, #256
    v.add        v8, v0, v5
    v.movi       v0, #0
    v.splat      v5, s2
    v.splat      v9, s4
    v.movi       v10, #0
    s.muli       s2, s1, #4
    v.cmp.ge     p1, v8, v0
    v.splat      v0, s3
    v.cmp.lt     p2, v8, v5
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v0
    s.add        s3, s5, s9
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    .li       s9, #1065353216
    v.splat      v0, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s9, s3, s2
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s9, #0]
    v.movi       v8, #0
    v.movi       v9, #1
    v.movi       v10, #0
    v.cmp.eq     p1, v4, v8
    v.splat      v8, s1
    @p1 v.sel        v11, v9, v10
    vf.fms       v9, v3, v6, v0
    v.add        v0, v8, v1
    v.extract    s2, v11, #0
    v.movi       v8, #0
    v.splat      v10, s2
    vf.fms       v11, v6, v9, v6
    v.movi       v9, #64
    v.cmp.ne     p1, v10, v8
    v.cmp.lt     p2, v0, v9
    vf.neg       v8, v11                         // Newton step: r0*(2 - x*r0)
    s.mul        s2, s4, s7
    s.add        s3, s1, s8
    s.movz       s9, #1
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v9, v8, v6
    s.add        s10, s1, s2
    v.splat      v6, s2
    vf.mul       v8, v5, v9                      // a/y: faithful quotient
    s.shli       s2, s10, #2                     // element offset -> bytes (x4)
    v.add        v10, v0, v6
    s.add        s10, s6, s2                     // &out_ptr4[...]
    vf.fms       v0, v8, v3, v5
    vf.fms       v3, v0, v9, v8
    vf.neg       v0, v3                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v0, v0
    @p3 v.sel        v3, v0, v8
    @p1 v.sel        v0, v7, v3
    @p2 v.st.w       [s10, #0], v0
    s.mov        s1, s3
    br.nz        s9, for_6
endfor_7:
__rctx_next:
    exit
