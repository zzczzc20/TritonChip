    s.rdspecial  s1, pid.x
    s.movz       s2, #0
    s.movz       s3, #2
    s.cmp.lt     s4, s1, s2
    s.cmp.lt     s5, s3, s2
    s.sub        s6, s2, s4
    s.sub        s4, s2, s5
    s.xor        s5, s1, s6
    s.xor        s7, s6, s4
    s.sub        s8, s5, s6
    s.movz       s9, #1
    s.lshri      s10, s8, #1
    s.rdspecial  s11, arg_base
    s.xor        s12, s10, s7
    s.muli       s13, s10, #2
    s.sub        s10, s12, s7
    s.xor        s7, s3, s4
    s.sub        s12, s9, s10
    s.sub        s14, s5, s6
    s.min.s      s5, s12, s9
    s.addi       s12, s2, #0
    s.cmp.lt     s15, s5, s2
    s.ld.d       s16, [s11, #0]                  // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s2, s15
    s.sub        s15, s7, s4
    s.xor        s4, s5, s17
    s.sub        s7, s8, s13
    s.sub        s7, s4, s17
    s.addi       s4, s2, #0
    s.cmp.eq     s8, s7, s9
    s.ld.d       s13, [s11, #8]                  // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s15, [s11, #16]                 // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s17, [s11, #24]                 // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s18, [s11, #32]                 // out_ptr0: device_ptr64 at arg_base+32
    s.mov        s12, s14
    br.nz        s8, sdiv_done_1
    s.movz       s8, #0
    s.movz       s11, #31
    s.mov        s12, s8
    s.addi       s8, s11, #0
sdiv_2:
    s.lshr       s11, s14, s8
    s.shli       s19, s4, #1
    s.andi       s20, s11, #1
    s.shl        s11, s9, s8
    s.or         s21, s19, s20
    s.subi       s19, s8, #1
    s.cmp.geu    s20, s21, s7
    s.sub        s22, s2, s20
    s.and        s20, s7, s22
    s.and        s23, s11, s22
    s.sub        s11, s21, s20
    s.or         s20, s12, s23
    s.mov        s4, s11
    s.mov        s12, s20
    s.mov        s8, s19
    s.cmp.ge     s11, s8, s2
    br.nz        s11, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.xor        s7, s4, s6
    s.cmp.lt     s4, s1, s2
    s.cmp.lt     s8, s5, s2
    s.sub        s11, s2, s4
    s.sub        s4, s2, s8
    s.xor        s8, s1, s11
    s.cmp.lt     s1, s3, s2
    s.sub        s12, s8, s11
    s.xor        s8, s5, s4
    s.lshri      s5, s12, #1
    s.sub        s14, s2, s1
    s.muli       s1, s5, #2
    s.sub        s5, s8, s4
    s.movz       s8, #1
    s.sub        s19, s7, s6
    s.xor        s6, s3, s14
    s.sub        s7, s12, s1
    s.addi       s1, s2, #0
    s.xor        s12, s7, s11
    s.cmp.eq     s7, s5, s8
    s.sub        s20, s12, s11
    s.add        s11, s10, s19
    s.cmp.lt     s10, s20, s2
    s.sub        s12, s6, s14
    s.sub        s6, s2, s10
    s.addi       s10, s2, #0
    s.xor        s12, s20, s6
    s.sub        s14, s12, s6
    s.mov        s1, s14
    br.nz        s7, sdiv_done_3
    s.movz       s7, #0
    s.movz       s12, #31
    s.mov        s1, s7
    s.addi       s7, s12, #0
sdiv_4:
    s.lshr       s12, s14, s7
    s.shli       s19, s10, #1
    s.andi       s20, s12, #1
    s.shl        s12, s8, s7
    s.or         s21, s19, s20
    s.subi       s19, s7, #1
    s.cmp.geu    s20, s21, s5
    s.sub        s22, s2, s20
    s.and        s20, s5, s22
    s.and        s23, s12, s22
    s.sub        s12, s21, s20
    s.or         s20, s1, s23
    s.mov        s10, s12
    s.mov        s1, s20
    s.mov        s7, s19
    s.cmp.ge     s12, s7, s2
    br.nz        s12, sdiv_4
sdiv_done_3:
    s.xor        s2, s6, s4
    s.movz       s4, #16
    s.xor        s5, s1, s2
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s1, s5, s2
    v.movi       v1, #17
    s.mul        s2, s1, s4
    v.movi       v2, #0
    s.movz       s5, #0
    v.splat      v3, s11
    v.splat      v4, s5
    v.splat      v5, s2
    v.splat      v6, s1
    v.sub        v7, v2, v1
    v.add        v8, v5, v0
    v.cmp.lt     p1, v1, v2
    v.cmp.ge     p2, v3, v4
    v.sub        v3, v2, v8
    v.cmp.lt     p2, v8, v2
    v.cmp.ge     p3, v6, v4
    v.movi       v4, #1
    @p2 v.sel        v5, v3, v8
    @p1 v.sel        v3, v7, v1
    v.movi       v1, #0
    v.movi       v6, #0
    s.movz       s1, #31
idiv_5:
    v.splat      v7, s1
    v.shl        v8, v6, v4
    v.cmp.lt     p1, v6, v2
    v.lshr       v9, v5, v7
    v.shl        v10, v4, v7
    s.subi       s6, s1, #1
    v.and        v7, v9, v4
    v.or         v9, v8, v7
    v.cmp.geu    p3, v9, v3
    p.or         p4, p1, p3
    v.sub        v7, v9, v3
    @p4 v.sel        v8, v10, v2
    @p4 v.sel        v10, v7, v9
    v.or         v7, v1, v8
    v.mov        v6, v10
    v.mov        v1, v7
    s.mov        s1, s6
    s.cmp.ge     s6, s1, s5
    br.nz        s6, idiv_5
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.rdspecial  s1, arg_base
    v.ld.b       v1, [s16, #0]
    s.addi       s6, s16, #0                     // row 1
    s.movz       s7, #32
    s.movz       s8, #48
    v.sub        v3, v2, v6
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v4, #16
    @p2 v.sel        v5, v3, v6
    v.movi       v3, #32
    v.movi       v6, #48
    v.add        v7, v2, v4
    v.add        v4, v2, v3
    s.ld.d       s10, [s1, #40]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.add        v3, v2, v6
    s.addi       s1, s10, #0
    v.st.w       [s1, #0], v1
    s.addi       s12, s1, #64
    s.addi       s14, s1, #128
    s.addi       s19, s1, #192
    s.addi       s20, s1, #256
    s.addi       s21, s1, #320
    v.ld.b       v1, [s6, #0]
    v.st.w       [s12, #0], v1
    s.addi       s12, s1, #384
    v.ld.b       v1, [s6, #0]
    v.st.w       [s14, #0], v1
    s.addi       s14, s1, #448
    v.ld.b       v1, [s6, #0]
    v.st.w       [s19, #0], v1
    s.addi       s19, s1, #512
    v.ld.b       v1, [s6, #0]
    v.st.w       [s20, #0], v1
    s.addi       s20, s1, #576
    v.ld.b       v1, [s6, #0]
    v.st.w       [s21, #0], v1
    s.addi       s21, s1, #640
    v.ld.b       v1, [s6, #0]
    v.st.w       [s12, #0], v1
    s.addi       s12, s1, #704
    v.ld.b       v1, [s6, #0]
    v.st.w       [s14, #0], v1
    s.addi       s14, s1, #768
    v.ld.b       v1, [s6, #0]
    v.st.w       [s19, #0], v1
    s.addi       s19, s1, #832
    v.ld.b       v1, [s6, #0]
    v.st.w       [s20, #0], v1
    s.addi       s20, s1, #896
    s.addi       s22, s1, #960
    v.ld.b       v1, [s6, #0]
    v.st.w       [s21, #0], v1
    s.add        s1, s16, s4                     // the tile origin
    v.ld.b       v1, [s6, #0]
    v.st.w       [s12, #0], v1
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.addi       s12, s10, #1024
    v.ld.b       v1, [s6, #0]
    v.st.w       [s14, #0], v1
    s.addi       s14, s1, #0                     // row 1
    v.ld.b       v1, [s6, #0]
    v.st.w       [s19, #0], v1
    s.addi       s19, s12, #64
    v.ld.b       v1, [s6, #0]
    v.st.w       [s20, #0], v1
    s.addi       s20, s12, #128
    v.ld.b       v1, [s6, #0]
    s.addi       s6, s12, #192
    v.st.w       [s22, #0], v1
    fence.acq_rel.device
    s.addi       s21, s12, #256
    v.ld.b       v1, [s1, #0]
    s.addi       s1, s12, #320
    v.st.w       [s12, #0], v1
    v.ld.b       v1, [s14, #0]
    v.st.w       [s19, #0], v1
    s.addi       s19, s12, #384
    v.ld.b       v1, [s14, #0]
    v.st.w       [s20, #0], v1
    s.addi       s20, s12, #448
    v.ld.b       v1, [s14, #0]
    v.st.w       [s6, #0], v1
    s.addi       s6, s12, #512
    v.ld.b       v1, [s14, #0]
    v.st.w       [s21, #0], v1
    s.addi       s21, s12, #576
    v.ld.b       v1, [s14, #0]
    v.st.w       [s1, #0], v1
    s.addi       s1, s12, #640
    v.ld.b       v1, [s14, #0]
    v.st.w       [s19, #0], v1
    s.addi       s19, s12, #704
    v.ld.b       v1, [s14, #0]
    v.st.w       [s20, #0], v1
    s.addi       s20, s12, #768
    v.ld.b       v1, [s14, #0]
    v.st.w       [s6, #0], v1
    s.addi       s6, s12, #832
    v.ld.b       v1, [s14, #0]
    v.st.w       [s21, #0], v1
    s.addi       s21, s12, #896
    s.addi       s22, s12, #960
    v.ld.b       v1, [s14, #0]
    v.st.w       [s1, #0], v1
    s.add        s1, s16, s7                     // the tile origin
    v.ld.b       v1, [s14, #0]
    v.st.w       [s19, #0], v1
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.addi       s12, s10, #2048
    v.ld.b       v1, [s14, #0]
    v.st.w       [s20, #0], v1
    s.addi       s19, s1, #0                     // row 1
    v.ld.b       v1, [s14, #0]
    v.st.w       [s6, #0], v1
    s.addi       s6, s12, #64
    v.ld.b       v1, [s14, #0]
    v.st.w       [s21, #0], v1
    s.addi       s20, s12, #128
    v.ld.b       v1, [s14, #0]
    s.addi       s14, s12, #192
    v.st.w       [s22, #0], v1
    fence.acq_rel.device
    s.addi       s21, s12, #256
    v.ld.b       v1, [s1, #0]
    s.addi       s1, s12, #320
    v.st.w       [s12, #0], v1
    s.add        s22, s16, s8                    // the tile origin
    v.ld.b       v1, [s19, #0]
    v.st.w       [s6, #0], v1
    s.addi       s6, s12, #384
    v.ld.b       v1, [s19, #0]
    v.st.w       [s20, #0], v1
    s.addi       s16, s12, #448
    v.ld.b       v1, [s19, #0]
    v.st.w       [s14, #0], v1
    s.addi       s14, s12, #512
    v.ld.b       v1, [s19, #0]
    v.st.w       [s21, #0], v1
    s.addi       s20, s12, #576
    v.ld.b       v1, [s19, #0]
    v.st.w       [s1, #0], v1
    s.addi       s1, s12, #640
    v.ld.b       v1, [s19, #0]
    v.st.w       [s6, #0], v1
    s.addi       s6, s12, #704
    v.ld.b       v1, [s19, #0]
    v.st.w       [s16, #0], v1
    s.addi       s16, s12, #768
    v.ld.b       v1, [s19, #0]
    v.st.w       [s14, #0], v1
    s.addi       s14, s12, #832
    v.ld.b       v1, [s19, #0]
    v.st.w       [s20, #0], v1
    s.addi       s20, s12, #896
    s.addi       s21, s12, #960
    v.ld.b       v1, [s19, #0]
    v.st.w       [s1, #0], v1
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.addi       s1, s10, #3072
    v.ld.b       v1, [s19, #0]
    v.st.w       [s6, #0], v1
    s.addi       s6, s22, #0                     // row 1
    v.ld.b       v1, [s19, #0]
    v.st.w       [s16, #0], v1
    s.addi       s12, s1, #64
    v.ld.b       v1, [s19, #0]
    v.st.w       [s14, #0], v1
    s.addi       s14, s1, #128
    v.ld.b       v1, [s19, #0]
    v.st.w       [s20, #0], v1
    s.addi       s16, s1, #192
    v.ld.b       v1, [s19, #0]
    s.addi       s19, s1, #256
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    s.addi       s20, s1, #320
    v.ld.b       v1, [s22, #0]
    s.addi       s21, s1, #384
    v.st.w       [s1, #0], v1
    v.ld.b       v1, [s6, #0]
    v.st.w       [s12, #0], v1
    s.addi       s12, s1, #448
    v.ld.b       v1, [s6, #0]
    v.st.w       [s14, #0], v1
    s.addi       s14, s1, #512
    v.splat      v1, s5
    v.ld.b       v2, [s6, #0]
    v.st.w       [s16, #0], v2
    s.addi       s16, s1, #576
    v.ld.b       v2, [s6, #0]
    v.st.w       [s19, #0], v2
    s.addi       s19, s1, #640
    v.splat      v2, s9
    v.ld.b       v3, [s6, #0]
    v.st.w       [s20, #0], v3
    s.addi       s20, s1, #704
    v.ld.b       v3, [s6, #0]
    v.st.w       [s21, #0], v3
    s.addi       s21, s1, #768
    v.splat      v3, s3
    s.addi       s3, s1, #832
    v.ld.b       v4, [s6, #0]
    v.st.w       [s12, #0], v4
    s.addi       s12, s1, #896
    s.addi       s22, s1, #960
    v.ld.b       v4, [s6, #0]
    v.st.w       [s14, #0], v4
    s.movz       s1, #64
    v.splat      v4, s1
    s.addi       s1, s10, #4096
    v.mul        v6, v5, v4
    v.ld.b       v4, [s6, #0]
    v.st.w       [s16, #0], v4
    s.addi       s14, s10, #4160
    v.ld.b       v4, [s6, #0]
    v.st.w       [s19, #0], v4
    s.addi       s16, s14, #64
    v.ld.b       v4, [s6, #0]
    v.st.w       [s20, #0], v4
    s.addi       s19, s14, #128
    v.ld.b       v4, [s6, #0]
    v.st.w       [s21, #0], v4
    s.movz       s20, #3
    v.splat      v4, s20
    s.addi       s20, s14, #192
    v.ld.b       v5, [s6, #0]
    v.st.w       [s3, #0], v5
    s.movz       s3, #4
    v.splat      v5, s3
    s.addi       s3, s14, #256
    v.ld.b       v7, [s6, #0]
    v.st.w       [s12, #0], v7
    s.movz       s12, #5
    v.splat      v7, s12
    s.addi       s12, s14, #320
    v.ld.b       v8, [s6, #0]
    s.addi       s6, s14, #384
    v.st.w       [s22, #0], v8
    fence.acq_rel.device
    s.movz       s21, #6
    v.splat      v8, s21
    v.st.w       [s1, #0], v6
    fence.acq_rel.device
    s.movz       s21, #7
    v.splat      v6, s21
    s.addi       s21, s14, #448
    v.ld.w       v9, [s1, #0]
    v.add        v10, v1, v9
    v.add        v9, v1, v10
    v.st.w       [s14, #0], v9
    v.ld.w       v9, [s1, #0]
    v.add        v10, v2, v9
    v.add        v2, v1, v10
    v.st.w       [s16, #0], v2
    s.addi       s16, s10, #4096
    v.ld.w       v2, [s1, #0]
    v.add        v9, v3, v2
    v.add        v2, v1, v9
    v.st.w       [s19, #0], v2
    s.movz       s19, #8
    v.splat      v2, s19
    s.addi       s19, s14, #512
    v.ld.w       v3, [s1, #0]
    v.add        v9, v4, v3
    v.add        v3, v1, v9
    v.st.w       [s20, #0], v3
    s.movz       s20, #9
    v.splat      v3, s20
    s.addi       s20, s14, #576
    v.ld.w       v4, [s1, #0]
    v.add        v9, v5, v4
    v.add        v4, v1, v9
    v.st.w       [s3, #0], v4
    s.movz       s3, #10
    v.splat      v4, s3
    s.addi       s3, s14, #640
    v.ld.w       v5, [s1, #0]
    v.add        v9, v7, v5
    v.add        v5, v1, v9
    v.st.w       [s12, #0], v5
    s.movz       s12, #11
    v.splat      v5, s12
    s.addi       s12, s14, #704
    v.ld.w       v7, [s1, #0]
    v.add        v9, v8, v7
    v.add        v7, v1, v9
    v.st.w       [s6, #0], v7
    s.movz       s6, #12
    v.splat      v7, s6
    s.addi       s6, s14, #768
    v.ld.w       v8, [s1, #0]
    s.movz       s1, #13
    v.splat      v9, s1
    s.addi       s1, s14, #832
    v.add        v10, v6, v8
    v.add        v6, v1, v10
    v.st.w       [s21, #0], v6
    s.movz       s21, #14
    v.splat      v6, s21
    s.addi       s21, s14, #896
    s.addi       s22, s14, #960
    v.ld.w       v8, [s16, #0]
    v.add        v10, v2, v8
    v.add        v2, v1, v10
    v.st.w       [s19, #0], v2
    s.movz       s14, #15
    v.splat      v2, s14
    s.addi       s14, s10, #5184
    v.ld.w       v8, [s16, #0]
    v.splat      v10, s5
    v.add        v11, v3, v8
    v.add        v3, v1, v11
    v.st.w       [s20, #0], v3
    s.addi       s19, s10, #4096
    v.ld.w       v3, [s16, #0]
    v.add        v8, v4, v3
    v.add        v3, v1, v8
    v.st.w       [s3, #0], v3
    s.movz       s3, #0
    s.add        s20, s3, s4                     // the tile origin
    v.splat      v3, s20
    v.ld.w       v4, [s16, #0]
    v.add        v8, v5, v4
    v.add        v4, v1, v8
    v.st.w       [s12, #0], v4
    s.addi       s3, s20, #1
    v.splat      v4, s3
    s.addi       s3, s14, #64
    v.ld.w       v5, [s16, #0]
    v.add        v8, v7, v5
    v.add        v5, v1, v8
    v.st.w       [s6, #0], v5
    s.addi       s6, s20, #2
    v.splat      v5, s6
    s.addi       s6, s14, #128
    v.ld.w       v7, [s16, #0]
    v.add        v8, v9, v7
    v.add        v7, v1, v8
    v.st.w       [s1, #0], v7
    s.addi       s1, s20, #3
    v.splat      v7, s1
    s.addi       s1, s14, #192
    v.ld.w       v8, [s16, #0]
    v.add        v9, v6, v8
    v.add        v6, v1, v9
    v.st.w       [s21, #0], v6
    s.addi       s12, s20, #4
    v.splat      v6, s12
    s.addi       s12, s14, #256
    v.ld.w       v8, [s16, #0]
    s.addi       s16, s20, #5
    v.splat      v9, s16
    s.addi       s16, s14, #320
    v.add        v11, v2, v8
    v.add        v2, v1, v11
    v.st.w       [s22, #0], v2
    fence.acq_rel.device
    s.addi       s21, s20, #6
    v.splat      v1, s21
    s.addi       s21, s14, #384
    v.ld.w       v2, [s19, #0]
    v.add        v8, v3, v2
    v.add        v2, v10, v8
    v.st.w       [s14, #0], v2
    v.ld.w       v2, [s19, #0]
    v.add        v3, v4, v2
    v.add        v2, v10, v3
    v.st.w       [s3, #0], v2
    s.addi       s3, s20, #7
    v.splat      v2, s3
    s.addi       s3, s14, #448
    v.ld.w       v3, [s19, #0]
    v.add        v4, v5, v3
    v.add        v3, v10, v4
    v.st.w       [s6, #0], v3
    s.addi       s6, s20, #8
    v.splat      v3, s6
    s.addi       s6, s14, #512
    v.ld.w       v4, [s19, #0]
    v.add        v5, v7, v4
    v.add        v4, v10, v5
    v.st.w       [s1, #0], v4
    s.addi       s1, s10, #4096
    v.ld.w       v4, [s19, #0]
    v.add        v5, v6, v4
    v.add        v4, v10, v5
    v.st.w       [s12, #0], v4
    s.addi       s12, s20, #9
    v.splat      v4, s12
    s.addi       s12, s14, #576
    v.ld.w       v5, [s19, #0]
    v.add        v6, v9, v5
    v.add        v5, v10, v6
    v.st.w       [s16, #0], v5
    s.addi       s16, s20, #10
    v.splat      v5, s16
    s.addi       s16, s14, #640
    v.ld.w       v6, [s19, #0]
    v.add        v7, v1, v6
    v.add        v1, v10, v7
    v.st.w       [s21, #0], v1
    s.addi       s21, s20, #11
    v.splat      v1, s21
    s.addi       s21, s14, #704
    v.ld.w       v6, [s19, #0]
    v.add        v7, v2, v6
    v.add        v2, v10, v7
    v.st.w       [s3, #0], v2
    s.addi       s3, s20, #12
    v.splat      v2, s3
    s.addi       s3, s14, #768
    v.ld.w       v6, [s19, #0]
    s.addi       s19, s20, #13
    v.splat      v7, s19
    s.addi       s19, s14, #832
    v.add        v8, v3, v6
    v.add        v3, v10, v8
    v.st.w       [s6, #0], v3
    s.addi       s6, s20, #14
    s.addi       s22, s20, #15
    v.splat      v3, s6
    s.addi       s6, s14, #896
    v.splat      v6, s22
    s.addi       s20, s14, #960
    s.addi       s14, s10, #6208
    v.ld.w       v8, [s1, #0]
    v.splat      v9, s5
    v.add        v11, v4, v8
    v.add        v4, v10, v11
    v.st.w       [s12, #0], v4
    s.movz       s12, #0
    s.add        s22, s12, s7                    // the tile origin
    v.splat      v4, s22
    v.ld.w       v8, [s1, #0]
    v.add        v11, v5, v8
    s.addi       s7, s14, #64
    v.add        v5, v10, v11
    v.st.w       [s16, #0], v5
    s.addi       s12, s10, #4096
    v.ld.w       v5, [s1, #0]
    v.add        v8, v1, v5
    v.add        v1, v10, v8
    v.st.w       [s21, #0], v1
    s.addi       s16, s22, #1
    v.splat      v1, s16
    s.addi       s16, s22, #2
    v.splat      v5, s16
    s.addi       s16, s14, #128
    v.ld.w       v8, [s1, #0]
    v.add        v11, v2, v8
    v.add        v2, v10, v11
    v.st.w       [s3, #0], v2
    s.addi       s3, s22, #3
    v.splat      v2, s3
    s.addi       s3, s14, #192
    v.ld.w       v8, [s1, #0]
    v.add        v11, v7, v8
    v.add        v7, v10, v11
    v.st.w       [s19, #0], v7
    s.addi       s19, s22, #4
    v.splat      v7, s19
    s.addi       s19, s14, #256
    v.ld.w       v8, [s1, #0]
    v.add        v11, v3, v8
    v.add        v3, v10, v11
    v.st.w       [s6, #0], v3
    s.addi       s6, s22, #5
    v.splat      v3, s6
    s.addi       s6, s14, #320
    v.ld.w       v8, [s1, #0]
    v.add        v11, v6, v8
    v.add        v6, v10, v11
    v.st.w       [s20, #0], v6
    fence.acq_rel.device
    s.addi       s20, s22, #6
    v.splat      v6, s20
    s.addi       s20, s14, #384
    v.ld.w       v8, [s1, #0]
    s.addi       s1, s22, #7
    v.add        v10, v4, v8
    v.splat      v4, s1
    s.addi       s1, s14, #448
    v.add        v8, v9, v10
    v.st.w       [s14, #0], v8
    v.ld.w       v8, [s12, #0]
    v.add        v10, v1, v8
    v.add        v1, v9, v10
    v.st.w       [s7, #0], v1
    s.addi       s7, s22, #8
    v.splat      v1, s7
    s.addi       s7, s14, #512
    v.ld.w       v8, [s12, #0]
    v.add        v10, v5, v8
    v.add        v5, v9, v10
    v.st.w       [s16, #0], v5
    s.addi       s16, s22, #9
    v.splat      v5, s16
    s.addi       s16, s14, #576
    v.ld.w       v8, [s12, #0]
    v.add        v10, v2, v8
    v.add        v2, v9, v10
    v.st.w       [s3, #0], v2
    s.addi       s3, s10, #4096
    v.ld.w       v2, [s12, #0]
    v.add        v8, v7, v2
    v.add        v2, v9, v8
    v.st.w       [s19, #0], v2
    s.addi       s19, s22, #10
    v.splat      v2, s19
    s.addi       s19, s14, #640
    v.ld.w       v7, [s12, #0]
    v.add        v8, v3, v7
    v.add        v3, v9, v8
    v.st.w       [s6, #0], v3
    s.addi       s6, s22, #11
    v.splat      v3, s6
    s.addi       s6, s14, #704
    v.ld.w       v7, [s12, #0]
    v.add        v8, v6, v7
    v.add        v6, v9, v8
    v.st.w       [s20, #0], v6
    s.addi       s20, s22, #12
    v.splat      v6, s20
    s.addi       s20, s14, #768
    v.ld.w       v7, [s12, #0]
    v.add        v8, v4, v7
    v.add        v4, v9, v8
    v.st.w       [s1, #0], v4
    s.addi       s1, s22, #13
    v.splat      v4, s1
    s.addi       s1, s14, #832
    v.ld.w       v7, [s12, #0]
    v.add        v8, v1, v7
    v.add        v1, v9, v8
    v.st.w       [s7, #0], v1
    s.addi       s7, s22, #14
    s.addi       s21, s22, #15
    v.splat      v1, s7
    s.addi       s7, s14, #896
    v.splat      v7, s21
    s.addi       s21, s14, #960
    v.ld.w       v8, [s12, #0]
    s.addi       s12, s10, #7232
    v.add        v10, v5, v8
    v.splat      v5, s5
    v.add        v8, v9, v10
    s.movz       s5, #0
    v.st.w       [s16, #0], v8
    s.add        s14, s5, s8                     // the tile origin
    v.splat      v8, s14
    v.ld.w       v10, [s3, #0]
    v.add        v11, v2, v10
    s.addi       s5, s12, #64
    v.add        v2, v9, v11
    s.addi       s8, s14, #1
    v.st.w       [s19, #0], v2
    v.splat      v2, s8
    v.ld.w       v10, [s3, #0]
    v.add        v11, v3, v10
    s.addi       s8, s12, #128
    v.add        v3, v9, v11
    s.addi       s16, s14, #2
    v.st.w       [s6, #0], v3
    s.addi       s6, s10, #4096
    v.splat      v3, s16
    v.ld.w       v10, [s3, #0]
    v.add        v11, v6, v10
    v.add        v6, v9, v11
    s.addi       s16, s12, #192
    v.st.w       [s20, #0], v6
    s.addi       s19, s14, #3
    v.splat      v6, s19
    v.ld.w       v10, [s3, #0]
    v.add        v11, v4, v10
    v.add        v4, v9, v11
    s.addi       s19, s12, #256
    v.st.w       [s1, #0], v4
    s.addi       s1, s14, #4
    v.splat      v4, s1
    v.ld.w       v10, [s3, #0]
    v.add        v11, v1, v10
    v.add        v1, v9, v11
    s.addi       s1, s12, #320
    v.st.w       [s7, #0], v1
    s.addi       s7, s14, #5
    v.splat      v1, s7
    v.ld.w       v10, [s3, #0]
    v.add        v11, v7, v10
    v.add        v7, v9, v11
    s.addi       s7, s12, #384
    v.st.w       [s21, #0], v7
    fence.acq_rel.device
    s.addi       s20, s14, #6
    s.addi       s21, s12, #448
    v.splat      v7, s20
    v.ld.w       v9, [s3, #0]
    s.addi       s20, s14, #7
    v.add        v10, v8, v9
    v.splat      v8, s20
    v.add        v9, v5, v10
    v.st.w       [s12, #0], v9
    s.addi       s20, s12, #512
    v.ld.w       v9, [s3, #0]
    s.addi       s3, s14, #8
    v.add        v10, v2, v9
    v.splat      v2, s3
    v.add        v9, v5, v10
    v.st.w       [s5, #0], v9
    s.addi       s3, s14, #9
    s.addi       s5, s12, #576
    v.ld.w       v9, [s6, #0]
    v.splat      v10, s3
    v.add        v11, v3, v9
    v.add        v3, v5, v11
    v.st.w       [s8, #0], v3
    s.addi       s3, s14, #10
    s.addi       s8, s12, #640
    v.ld.w       v3, [s6, #0]
    v.splat      v9, s3
    v.add        v11, v6, v3
    v.add        v3, v5, v11
    v.st.w       [s16, #0], v3
    s.addi       s3, s14, #11
    s.addi       s16, s12, #704
    v.ld.w       v3, [s6, #0]
    v.splat      v6, s3
    v.add        v11, v4, v3
    s.addi       s3, s10, #4096
    v.add        v3, v5, v11
    v.st.w       [s19, #0], v3
    s.addi       s19, s12, #768
    v.ld.w       v3, [s6, #0]
    v.add        v4, v1, v3
    v.add        v1, v5, v4
    v.st.w       [s1, #0], v1
    s.addi       s1, s14, #12
    v.splat      v1, s1
    s.addi       s1, s12, #832
    v.ld.w       v3, [s6, #0]
    v.add        v4, v7, v3
    v.add        v3, v5, v4
    v.st.w       [s7, #0], v3
    s.addi       s7, s14, #13
    v.splat      v3, s7
    s.addi       s7, s12, #896
    v.ld.w       v4, [s6, #0]
    v.add        v7, v8, v4
    v.add        v4, v5, v7
    v.st.w       [s21, #0], v4
    s.addi       s21, s14, #14
    s.addi       s22, s12, #960
    v.splat      v4, s21
    v.ld.w       v7, [s6, #0]
    s.addi       s12, s14, #15
    v.add        v8, v2, v7
    v.splat      v2, s12
    v.add        v7, v5, v8
    v.st.w       [s20, #0], v7
    v.ld.w       v7, [s6, #0]
    s.addi       s12, s10, #8256
    v.add        v8, v10, v7
    s.addi       s14, s10, #4160
    v.add        v7, v5, v8
    v.st.w       [s5, #0], v7
    s.addi       s5, s10, #4224
    s.addi       s20, s12, #64
    v.ld.w       v7, [s6, #0]
    v.add        v8, v9, v7
    v.add        v7, v5, v8
    v.st.w       [s8, #0], v7
    s.addi       s6, s10, #4288
    s.addi       s8, s12, #128
    v.ld.w       v7, [s3, #0]
    v.add        v8, v6, v7
    v.add        v6, v5, v8
    v.st.w       [s16, #0], v6
    s.addi       s16, s10, #4352
    v.ld.w       v6, [s3, #0]
    v.add        v7, v1, v6
    v.add        v1, v5, v7
    v.st.w       [s19, #0], v1
    s.addi       s19, s12, #192
    v.ld.w       v1, [s3, #0]
    v.add        v6, v3, v1
    v.add        v1, v5, v6
    v.st.w       [s1, #0], v1
    s.addi       s1, s10, #4416
    v.ld.w       v1, [s3, #0]
    v.add        v3, v4, v1
    v.add        v1, v5, v3
    v.st.w       [s7, #0], v1
    s.addi       s7, s12, #256
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #4480
    v.add        v3, v2, v1
    v.add        v1, v5, v3
    v.st.w       [s22, #0], v1
    fence.acq_rel.device
    s.addi       s21, s12, #320
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #4544
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s12, #384
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s20, #0], v2
    s.addi       s20, s10, #4608
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s12, #448
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v2
    s.addi       s8, s10, #4672
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s12, #512
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s19, #0], v2
    s.addi       s19, s10, #4736
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s12, #576
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v2
    s.addi       s7, s10, #4800
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s12, #640
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s21, #0], v2
    s.addi       s21, s10, #4864
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s12, #704
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s10, #4928
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s12, #768
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s6, #0], v2
    s.addi       s6, s10, #4992
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s12, #832
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s10, #5056
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s12, #896
    s.addi       s22, s12, #960
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s1, #0], v2
    s.addi       s1, s10, #5120
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #5184
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s10, #9280
    v.ld.w       v1, [s21, #0]
    s.addi       s12, s10, #5248
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s3, #64
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s10, #5312
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s20, #0], v2
    s.addi       s20, s3, #128
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s10, #5376
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v2
    s.addi       s8, s3, #192
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #5440
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s19, #0], v2
    s.addi       s19, s3, #256
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s10, #5504
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s22, #0], v2
    fence.acq_rel.device
    s.addi       s21, s3, #320
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #5568
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s3, #384
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s10, #5632
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s3, #448
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s20, #0], v2
    s.addi       s20, s10, #5696
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s3, #512
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v2
    s.addi       s8, s10, #5760
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s3, #576
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s19, #0], v2
    s.addi       s19, s10, #5824
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s3, #640
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s21, #0], v2
    s.addi       s21, s10, #5888
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s3, #704
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s10, #5952
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s3, #768
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s10, #6016
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s3, #832
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s6, #0], v2
    s.addi       s6, s10, #6080
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s3, #896
    s.addi       s22, s3, #960
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s3, s10, #6144
    v.ld.w       v1, [s19, #0]
    s.addi       s16, s10, #6208
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s1, #0], v2
    s.addi       s1, s10, #10304
    v.ld.w       v1, [s21, #0]
    s.addi       s19, s10, #6272
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v2
    s.addi       s7, s1, #64
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #6336
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s1, #128
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s10, #6400
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s20, #0], v2
    s.addi       s20, s1, #192
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s10, #6464
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v2
    s.addi       s8, s1, #256
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #6528
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s22, #0], v2
    fence.acq_rel.device
    s.addi       s21, s1, #320
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #6592
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s1, #0], v2
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s1, #384
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v2
    s.addi       s7, s10, #6656
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s1, #448
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s10, #6720
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s1, #512
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s20, #0], v2
    s.addi       s20, s10, #6784
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s1, #576
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v2
    s.addi       s8, s10, #6848
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s1, #640
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s21, #0], v2
    s.addi       s21, s10, #6912
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s1, #704
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s19, #0], v2
    s.addi       s19, s10, #6976
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s1, #768
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s10, #7040
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s1, #832
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s10, #7104
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s1, #896
    s.addi       s22, s1, #960
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s6, #0], v2
    s.addi       s1, s10, #7168
    v.ld.w       v1, [s8, #0]
    s.addi       s6, s10, #7232
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s10, #11328
    v.ld.w       v1, [s21, #0]
    s.addi       s8, s10, #7296
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s3, #64
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #7360
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v2
    s.addi       s7, s3, #128
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #7424
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s3, #192
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s10, #7488
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s20, #0], v2
    s.addi       s20, s3, #256
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s10, #7552
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s22, #0], v2
    fence.acq_rel.device
    s.addi       s21, s3, #320
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s10, #7616
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s3, #384
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s10, #7680
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s3, #448
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v2
    s.addi       s7, s10, #7744
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s3, #512
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s10, #7808
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s3, #576
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s20, #0], v2
    s.addi       s20, s10, #7872
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s3, #640
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s21, #0], v2
    s.addi       s21, s10, #7936
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s3, #704
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s8, #0], v2
    s.addi       s8, s10, #8000
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s3, #768
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s19, #0], v2
    s.addi       s19, s10, #8064
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s3, #832
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s10, #8128
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s3, #896
    s.addi       s22, s3, #960
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s3, s10, #8192
    v.ld.w       v1, [s20, #0]
    s.addi       s5, s10, #0
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s1, #0], v2
    s.addi       s1, s10, #12352                 // 1024 bytes of repack scratch
    v.ld.w       v1, [s21, #0]
    s.addi       s20, s10, #64
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #64
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #128
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s1, #128
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #192
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v2
    s.addi       s7, s1, #192
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #256
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s14, #0], v2
    s.addi       s14, s1, #256
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #320
    v.ld.gather.b v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    s.addi       s13, s1, #320
    v.st.w       [s22, #0], v2
    fence.acq_rel.device
    s.addi       s21, s10, #384
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s1, #384
    v.st.b       [s1, #0], v1
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #448
    v.st.b       [s6, #0], v1
    s.addi       s6, s1, #448
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #512
    v.st.b       [s16, #0], v1
    s.addi       s16, s1, #512
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #576
    v.st.b       [s7, #0], v1
    s.addi       s7, s1, #576
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #640
    v.st.b       [s14, #0], v1
    s.addi       s14, s1, #640
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #704
    v.st.b       [s13, #0], v1
    s.addi       s13, s1, #704
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s10, #768
    v.st.b       [s5, #0], v1
    s.addi       s5, s1, #768
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #832
    v.st.b       [s6, #0], v1
    s.addi       s6, s1, #832
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #896
    v.st.b       [s16, #0], v1
    s.addi       s16, s1, #896
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #960
    v.st.b       [s7, #0], v1
    s.addi       s7, s1, #960
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #1024
    v.st.b       [s14, #0], v1
    s.addi       s14, s1, #16
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #1088
    v.st.b       [s13, #0], v1
    s.addi       s13, s1, #80
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s10, #1152
    v.st.b       [s5, #0], v1
    s.addi       s5, s1, #144
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #1216
    v.st.b       [s6, #0], v1
    s.addi       s6, s1, #208
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #1280
    v.st.b       [s16, #0], v1
    s.addi       s16, s1, #272
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #1344
    v.st.b       [s7, #0], v1
    s.addi       s7, s1, #336
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #1408
    v.st.b       [s14, #0], v1
    s.addi       s14, s1, #400
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #1472
    v.st.b       [s13, #0], v1
    s.addi       s13, s1, #464
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s10, #1536
    v.st.b       [s5, #0], v1
    s.addi       s5, s1, #528
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #1600
    v.st.b       [s6, #0], v1
    s.addi       s6, s1, #592
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #1664
    v.st.b       [s16, #0], v1
    s.addi       s16, s1, #656
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #1728
    v.st.b       [s7, #0], v1
    s.addi       s7, s1, #720
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #1792
    v.st.b       [s14, #0], v1
    s.addi       s14, s1, #784
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #1856
    v.st.b       [s13, #0], v1
    s.addi       s13, s1, #848
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s10, #1920
    v.st.b       [s5, #0], v1
    s.addi       s5, s1, #912
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #1984
    v.st.b       [s6, #0], v1
    s.addi       s6, s1, #976
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #2048
    v.st.b       [s16, #0], v1
    s.addi       s16, s1, #32
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #2112
    v.st.b       [s7, #0], v1
    s.addi       s7, s1, #96
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #2176
    v.st.b       [s14, #0], v1
    s.addi       s14, s1, #160
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #2240
    v.st.b       [s13, #0], v1
    s.addi       s13, s1, #224
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s10, #2304
    v.st.b       [s5, #0], v1
    s.addi       s5, s1, #288
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #2368
    v.st.b       [s6, #0], v1
    s.addi       s6, s1, #352
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #2432
    v.st.b       [s16, #0], v1
    s.addi       s16, s1, #416
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #2496
    v.st.b       [s7, #0], v1
    s.addi       s7, s1, #480
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #2560
    v.st.b       [s14, #0], v1
    s.addi       s14, s1, #544
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #2624
    v.st.b       [s13, #0], v1
    s.addi       s13, s1, #608
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s10, #2688
    v.st.b       [s5, #0], v1
    s.addi       s5, s1, #672
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #2752
    v.st.b       [s6, #0], v1
    s.addi       s6, s1, #736
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #2816
    v.st.b       [s16, #0], v1
    s.addi       s16, s1, #800
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #2880
    v.st.b       [s7, #0], v1
    s.addi       s7, s1, #864
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #2944
    v.st.b       [s14, #0], v1
    s.addi       s14, s1, #928
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #3008
    v.st.b       [s13, #0], v1
    s.addi       s13, s1, #992
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s10, #3072
    v.st.b       [s5, #0], v1
    s.addi       s5, s1, #48
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #3136
    v.st.b       [s6, #0], v1
    s.addi       s6, s1, #112
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #3200
    v.st.b       [s16, #0], v1
    s.addi       s16, s1, #176
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #3264
    v.st.b       [s7, #0], v1
    s.addi       s7, s1, #240
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #3328
    v.st.b       [s14, #0], v1
    s.addi       s14, s1, #304
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #3392
    v.st.b       [s13, #0], v1
    s.addi       s13, s1, #368
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s10, #3456
    v.st.b       [s5, #0], v1
    s.addi       s5, s1, #432
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #3520
    v.st.b       [s6, #0], v1
    s.addi       s6, s1, #496
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #3584
    v.st.b       [s16, #0], v1
    s.addi       s16, s1, #560
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #3648
    v.st.b       [s7, #0], v1
    s.addi       s7, s1, #624
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #3712
    v.st.b       [s14, #0], v1
    s.addi       s14, s1, #688
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #3776
    v.st.b       [s13, #0], v1
    s.addi       s13, s1, #752
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s10, #3840
    v.st.b       [s5, #0], v1
    s.addi       s5, s1, #816
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #3904
    v.st.b       [s6, #0], v1
    s.addi       s6, s1, #880
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #3968
    v.st.b       [s16, #0], v1
    s.addi       s16, s1, #944
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #4032
    v.st.b       [s7, #0], v1
    s.addi       s7, s1, #1008
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #13376                // TensorMap 0: K-wide matrix repack
    v.st.b       [s14, #0], v1
    s.movz       s14, #16
    v.ld.w       v1, [s3, #0]
    s.movz       s3, #64
    v.st.b       [s13, #0], v1
    s.movz       s13, #1
    v.ld.w       v1, [s21, #0]
    .li       s21, #274877906960
    v.st.b       [s5, #0], v1
    .li       s5, #7705171329024
    v.ld.w       v1, [s20, #0]
    s.movz       s20, #0
    v.st.b       [s6, #0], v1
    // repack 64x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s6, s10, #8256
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s10, #13632                 // 1024 bytes of repack scratch
    v.st.b       [s16, #0], v1
    s.addi       s16, s10, #8320
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s8, #16                    // row 1
    v.st.b       [s7, #0], v1
    fence.acq_rel.device
    s.addi       s7, s10, #8384
    s.st.d       [s12, #0], s1
    s.addi       s1, s8, #32                     // row 2
    s.st.d       [s12, #8], s14
    s.addi       s14, s10, #8448
    s.st.d       [s12, #16], s3
    s.st.d       [s12, #48], s3
    s.addi       s3, s8, #48                     // row 3
    s.st.d       [s12, #56], s13
    s.addi       s13, s10, #8512
    s.st.d       [s12, #88], s21
    s.addi       s21, s8, #64                    // row 4
    s.st.d       [s12, #104], s5
    fence.release.device
    td.load      d0, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #32, #16                    // v32..v47
    mb.arm       s5, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.addi       s12, s10, #8576
    s.addi       s22, s8, #80                    // row 5
    // K-wide matrix repack: one tile into a window (ISA sec 9E)
    s.mov        s23, s20                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s20                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s23, s5
    mb.wait      s5
    s.addi       s20, s10, #8640
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s8, #96                     // row 6
    v.st.b       [s8, #0], v1
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #8704
    v.st.b       [s19, #0], v1
    s.addi       s19, s8, #112                   // row 7
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #8768
    v.st.b       [s1, #0], v1
    s.addi       s1, s8, #128                    // row 8
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #8832
    v.st.b       [s3, #0], v1
    s.addi       s3, s8, #144                    // row 9
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #8896
    v.st.b       [s21, #0], v1
    s.addi       s21, s8, #160                   // row 10
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #8960
    v.st.b       [s22, #0], v1
    s.addi       s22, s8, #176                   // row 11
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #9024
    v.st.b       [s6, #0], v1
    s.addi       s6, s8, #192                    // row 12
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #9088
    v.st.b       [s19, #0], v1
    s.addi       s19, s8, #208                   // row 13
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #9152
    v.st.b       [s1, #0], v1
    s.addi       s1, s8, #224                    // row 14
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #9216
    v.st.b       [s3, #0], v1
    s.addi       s3, s8, #240                    // row 15
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #9280
    v.st.b       [s21, #0], v1
    s.addi       s21, s8, #256                   // row 16
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #9344
    v.st.b       [s22, #0], v1
    s.addi       s22, s8, #272                   // row 17
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #9408
    v.st.b       [s6, #0], v1
    s.addi       s6, s8, #288                    // row 18
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #9472
    v.st.b       [s19, #0], v1
    s.addi       s19, s8, #304                   // row 19
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #9536
    v.st.b       [s1, #0], v1
    s.addi       s1, s8, #320                    // row 20
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #9600
    v.st.b       [s3, #0], v1
    s.addi       s3, s8, #336                    // row 21
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #9664
    v.st.b       [s21, #0], v1
    s.addi       s21, s8, #352                   // row 22
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #9728
    v.st.b       [s22, #0], v1
    s.addi       s22, s8, #368                   // row 23
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #9792
    v.st.b       [s6, #0], v1
    s.addi       s6, s8, #384                    // row 24
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #9856
    v.st.b       [s19, #0], v1
    s.addi       s19, s8, #400                   // row 25
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #9920
    v.st.b       [s1, #0], v1
    s.addi       s1, s8, #416                    // row 26
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #9984
    v.st.b       [s3, #0], v1
    s.addi       s3, s8, #432                    // row 27
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #10048
    v.st.b       [s21, #0], v1
    s.addi       s21, s8, #448                   // row 28
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #10112
    v.st.b       [s22, #0], v1
    s.addi       s22, s8, #464                   // row 29
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #10176
    v.st.b       [s6, #0], v1
    s.addi       s6, s8, #480                    // row 30
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #10240
    v.st.b       [s19, #0], v1
    s.addi       s19, s8, #496                   // row 31
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #10304
    v.st.b       [s1, #0], v1
    s.addi       s1, s8, #512                    // row 32
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #10368
    v.st.b       [s3, #0], v1
    s.addi       s3, s8, #528                    // row 33
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #10432
    v.st.b       [s21, #0], v1
    s.addi       s21, s8, #544                   // row 34
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #10496
    v.st.b       [s22, #0], v1
    s.addi       s22, s8, #560                   // row 35
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #10560
    v.st.b       [s6, #0], v1
    s.addi       s6, s8, #576                    // row 36
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #10624
    v.st.b       [s19, #0], v1
    s.addi       s19, s8, #592                   // row 37
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #10688
    v.st.b       [s1, #0], v1
    s.addi       s1, s8, #608                    // row 38
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #10752
    v.st.b       [s3, #0], v1
    s.addi       s3, s8, #624                    // row 39
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #10816
    v.st.b       [s21, #0], v1
    s.addi       s21, s8, #640                   // row 40
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #10880
    v.st.b       [s22, #0], v1
    s.addi       s22, s8, #656                   // row 41
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #10944
    v.st.b       [s6, #0], v1
    s.addi       s6, s8, #672                    // row 42
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #11008
    v.st.b       [s19, #0], v1
    s.addi       s19, s8, #688                   // row 43
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #11072
    v.st.b       [s1, #0], v1
    s.addi       s1, s8, #704                    // row 44
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #11136
    v.st.b       [s3, #0], v1
    s.addi       s3, s8, #720                    // row 45
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #11200
    v.st.b       [s21, #0], v1
    s.addi       s21, s8, #736                   // row 46
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #11264
    v.st.b       [s22, #0], v1
    s.addi       s22, s8, #752                   // row 47
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #11328
    v.st.b       [s6, #0], v1
    s.addi       s6, s8, #768                    // row 48
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #11392
    v.st.b       [s19, #0], v1
    s.addi       s19, s8, #784                   // row 49
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #11456
    v.st.b       [s1, #0], v1
    s.addi       s1, s8, #800                    // row 50
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #11520
    v.st.b       [s3, #0], v1
    s.addi       s3, s8, #816                    // row 51
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #11584
    v.st.b       [s21, #0], v1
    s.addi       s21, s8, #832                   // row 52
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #11648
    v.st.b       [s22, #0], v1
    s.addi       s22, s8, #848                   // row 53
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #11712
    v.st.b       [s6, #0], v1
    s.addi       s6, s8, #864                    // row 54
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #11776
    v.st.b       [s19, #0], v1
    s.addi       s19, s8, #880                   // row 55
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #11840
    v.st.b       [s1, #0], v1
    s.addi       s1, s8, #896                    // row 56
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s10, #11904
    v.st.b       [s3, #0], v1
    s.addi       s3, s8, #912                    // row 57
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #11968
    v.st.b       [s21, #0], v1
    s.addi       s21, s8, #928                   // row 58
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s10, #12032
    v.st.b       [s22, #0], v1
    s.addi       s22, s8, #944                   // row 59
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #12096
    v.st.b       [s6, #0], v1
    s.addi       s6, s8, #960                    // row 60
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #12160
    v.st.b       [s19, #0], v1
    s.addi       s19, s8, #976                   // row 61
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s10, #12224
    s.addi       s23, s10, #12288
    v.st.b       [s1, #0], v1
    s.addi       s1, s8, #992                    // row 62
    v.ld.w       v1, [s14, #0]
    s.addi       s10, s8, #1008                  // row 63
    v.st.b       [s3, #0], v1
    s.addi       s3, s8, #64
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s8, #128
    v.st.b       [s21, #0], v1
    s.addi       s14, s8, #192
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s8, #256
    v.st.b       [s22, #0], v1
    s.addi       s21, s8, #320
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s8, #384
    v.st.b       [s6, #0], v1
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s8, #448
    v.st.b       [s19, #0], v1
    s.addi       s19, s8, #512
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s8, #576
    v.st.b       [s1, #0], v1
    s.addi       s1, s8, #640
    v.ld.w       v1, [s23, #0]
    s.addi       s22, s8, #704
    v.st.b       [s10, #0], v1
    w.def        w1, #48, #16                    // v48..v63
    fence.acq_rel.device
    s.addi       s10, s8, #768
    v.ld.w       v1, [s8, #0]
    v.mov        v48, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s8, #832
    s.addi       s23, s8, #896
    v.movi       v2, #0
    s.mul        s8, s11, s4
    v.mov        v49, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v1, [s13, #0]
    v.splat      v3, s8
    v.add        v4, v3, v0
    v.mov        v50, v1                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s14, #0]
    v.mov        v51, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s12, #0]
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s4, #0
    s.muli       s11, s2, #2                     // a runtime tile origin, x2
    s.add        s12, s18, s11                   // the tile origin
    v.mov        v52, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s21, #0]
    v.mov        v53, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s20, #0]
    s.add        s11, s4, s8                     // the tile origin
    v.mov        v54, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s16, #0]
    v.splat      v1, s11
    v.splat      v3, s9
    v.cmp.lt     p1, v1, v3
    v.mov        v55, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s19, #0]
    s.add        s8, s4, s2                      // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v4, s8
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s7, #0]
    s.movz       s2, #17
    v.add        v5, v1, v4
    v.splat      v1, s2
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s1, #0]
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s22, #0]
    s.movz       s1, #1
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s10, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s3, #0]
    s.addi       s2, s11, #1
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v3
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s23, #0]
    p.and        p4, p1, p2
    s.movz       s2, #2
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s6, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    m.zero       a0
    mb.arm       s3, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k64.e4m3 a0, v32, v48, s3
    mb.wait      s3
    s.ld.w       s6, [s15, #0]                   // one element, not a vector
    s.addi       s7, s11, #2
    s.movz       s8, #3
    v.splat      v0, s7
    s.ld.w       s7, [s17, #0]                   // one element, not a vector
    v.splat      v1, s6
    a.vread      v4, a0, s4
    vf.add       v5, v4, v2
    v.splat      v4, s7
    s.addi       s4, s11, #3
    vf.mul       v6, v1, v4
    vf.mul       v7, v1, v4
    vf.mul       v8, v1, v4
    vf.mul       v9, v1, v4
    v.splat      v10, s4
    vf.mul       v11, v5, v6
    s.movz       s4, #4
    vf.cvt.f32.bf16 v5, v11
    vf.mul       v6, v1, v4
    s.addi       s6, s11, #4
    s.movz       s7, #5
    @p3 v.st.h       [s12, #0], v5
    a.vread      v5, a0, s1
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    vf.add       v0, v5, v2
    v.splat      v5, s6
    s.addi       s1, s11, #5
    vf.mul       v11, v0, v7
    vf.mul       v0, v1, v4
    vf.cvt.f32.bf16 v7, v11
    s.movz       s6, #6
    @p4 v.st.h       [s12, #0], v7
    a.vread      v7, a0, s2
    v.cmp.lt     p1, v10, v3
    p.and        p4, p1, p2
    vf.add       v10, v7, v2
    v.splat      v7, s1
    s.addi       s1, s11, #6
    vf.mul       v11, v10, v8
    vf.mul       v8, v1, v4
    vf.cvt.f32.bf16 v10, v11
    s.movz       s2, #7
    @p3 v.st.h       [s12, #0], v10
    a.vread      v10, a0, s8
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.add       v5, v10, v2
    v.splat      v10, s1
    s.addi       s1, s11, #7
    vf.mul       v11, v5, v9
    vf.mul       v5, v1, v4
    vf.cvt.f32.bf16 v9, v11
    s.movz       s8, #8
    @p4 v.st.h       [s12, #0], v9
    a.vread      v9, a0, s4
    v.cmp.lt     p1, v7, v3
    p.and        p4, p1, p2
    vf.add       v7, v9, v2
    v.splat      v9, s1
    s.addi       s1, s11, #8
    vf.mul       v11, v7, v6
    vf.mul       v6, v1, v4
    vf.cvt.f32.bf16 v7, v11
    s.movz       s4, #9
    @p3 v.st.h       [s12, #0], v7
    a.vread      v7, a0, s7
    v.cmp.lt     p1, v10, v3
    p.and        p3, p1, p2
    vf.add       v10, v7, v2
    v.splat      v7, s1
    s.addi       s1, s11, #9
    vf.mul       v11, v10, v0
    vf.mul       v0, v1, v4
    vf.cvt.f32.bf16 v10, v11
    s.movz       s7, #10
    @p4 v.st.h       [s12, #0], v10
    a.vread      v10, a0, s6
    v.cmp.lt     p1, v9, v3
    p.and        p4, p1, p2
    vf.add       v9, v10, v2
    v.splat      v10, s1
    s.addi       s1, s11, #10
    vf.mul       v11, v9, v8
    vf.mul       v8, v1, v4
    vf.cvt.f32.bf16 v9, v11
    s.movz       s6, #11
    @p3 v.st.h       [s12, #0], v9
    a.vread      v9, a0, s2
    v.cmp.lt     p1, v7, v3
    p.and        p3, p1, p2
    vf.add       v7, v9, v2
    v.splat      v9, s1
    s.addi       s1, s11, #11
    vf.mul       v11, v7, v5
    vf.mul       v5, v1, v4
    vf.cvt.f32.bf16 v7, v11
    s.movz       s2, #12
    @p4 v.st.h       [s12, #0], v7
    a.vread      v7, a0, s8
    v.cmp.lt     p1, v10, v3
    p.and        p4, p1, p2
    vf.add       v10, v7, v2
    v.splat      v7, s1
    s.addi       s1, s11, #12
    vf.mul       v11, v10, v6
    vf.mul       v6, v1, v4
    vf.cvt.f32.bf16 v10, v11
    s.movz       s8, #13
    @p3 v.st.h       [s12, #0], v10
    a.vread      v10, a0, s4
    v.cmp.lt     p1, v9, v3
    p.and        p3, p1, p2
    vf.add       v9, v10, v2
    v.splat      v10, s1
    s.addi       s1, s11, #13
    vf.mul       v11, v9, v0
    vf.mul       v0, v1, v4
    vf.cvt.f32.bf16 v9, v11
    s.movz       s4, #14
    @p4 v.st.h       [s12, #0], v9
    a.vread      v9, a0, s7
    v.cmp.lt     p1, v7, v3
    p.and        p4, p1, p2
    vf.add       v7, v9, v2
    v.splat      v9, s1
    s.addi       s1, s11, #14
    vf.mul       v11, v7, v8
    vf.mul       v7, v1, v4
    vf.cvt.f32.bf16 v8, v11
    s.movz       s7, #15
    @p3 v.st.h       [s12, #0], v8
    a.vread      v8, a0, s6
    v.cmp.lt     p1, v10, v3
    p.and        p3, p1, p2
    vf.add       v10, v8, v2
    v.splat      v8, s1
    vf.mul       v11, v1, v4
    s.addi       s1, s11, #15
    vf.mul       v1, v10, v5
    v.splat      v4, s1
    vf.cvt.f32.bf16 v5, v1
    @p4 v.st.h       [s12, #0], v5
    a.vread      v1, a0, s2
    v.cmp.lt     p1, v9, v3
    p.and        p4, p1, p2
    vf.add       v5, v1, v2
    vf.mul       v1, v5, v6
    vf.cvt.f32.bf16 v5, v1
    @p3 v.st.h       [s12, #0], v5
    a.vread      v1, a0, s8
    v.cmp.lt     p1, v8, v3
    p.and        p3, p1, p2
    vf.add       v5, v1, v2
    vf.mul       v1, v5, v0
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s12, #0], v0
    a.vread      v0, a0, s4
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v7
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s12, #0], v1
    a.vread      v0, a0, s7
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v11
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s12, #0], v1
    exit
    exit
