#!/bin/bash
set -euo pipefail
source "$HOME/tc_env/env.sh"
ROOT="$HOME/r41-accept-p1-v2";OUT="$HOME/r41-accept-p1/fixed-v2"
mkdir -p "$OUT"
export PYTHONPATH="$ROOT:$ROOT/python:$ROOT/compiler/python:$ROOT/tools/asm:$ROOT/tools/performance_harness/systemc"
export TNCA_BACKEND=systemc-tlm-grid TNCA_PROFILE=core-vrf-sync-v5-x8 TNCA_TLM_BINARY="$HOME/r41-accept-p1/model-build/tnca-chip"
export TNCA_TLM_MEMORY_BYTES=0x200000000 TORCH_EXTENSIONS_DIR="$HOME/r41-accept-p1/extensions" OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export TNCA_KERNEL_DUMP=1 TNCA_IEEE_DIV=1
for dtype in float16 bfloat16; do
 for columns in 16 32; do
  for layout in contiguous strided; do
   flags=();if [ "$layout" = strided ]; then flags+=(--strided);fi
   tag="$dtype-$columns-$layout"
   export TNCA_DUMP_DIR="$OUT/dump-$tag"
   "$HOME/tc_env/torchenv/bin/python" "$ROOT/tools/performance_harness/fragment_case.py" --out "$OUT/$tag" --columns "$columns" --shapes 17x65x33,128x128x192 --dtype "$dtype" --bitwise --require-resident "${flags[@]}" > "$OUT/$tag.log" 2>&1
  done
 done
done
