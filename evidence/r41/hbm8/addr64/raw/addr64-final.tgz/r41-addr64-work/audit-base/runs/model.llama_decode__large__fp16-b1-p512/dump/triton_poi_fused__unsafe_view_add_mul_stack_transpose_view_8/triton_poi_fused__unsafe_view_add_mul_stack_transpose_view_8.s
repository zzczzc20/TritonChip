    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s2, arg_base
    v.add        v3, v1, v0
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v0, #63
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.movi       v4, #512
    @p1 v.sel        v5, v1, v3
    s.shli       s4, s1, #1                      // element offset -> bytes (x2)
    v.cmp.lt     p2, v3, v4
    v.and        v1, v5, v0
    v.movi       v0, #0
    v.movi       v4, #6
    s.ld.d       s1, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.sub        v5, v2, v1
    s.add        s5, s3, s4                      // &in_ptr0[...]
    v.sub        v6, v0, v3
    @p1 v.sel        v7, v5, v1
    v.cmp.lt     p1, v3, v0
    @p1 v.sel        v1, v6, v3
    v.movi       v3, #64
    v.lshr       v5, v1, v4
    v.sub        v1, v2, v3
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.add        s6, s1, s4                      // &in_ptr2[...]
    v.sub        v4, v0, v5
    s.movz       s1, #32832
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v8, v0, v3
    @p1 v.sel        v9, v4, v5
    v.cmp.lt     p1, v3, v2
    v.cmp.lt     p3, v3, v0
    v.mul        v0, v9, v6
    @p1 v.sel        v2, v1, v3
    @p3 v.sel        v1, v8, v3
    s.ld.d       s1, [s2, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.add        v1, v7, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v0, [s5, #0]
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v2, [s3, v7]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v0, [s6, #0]
    vf.cvt.f16.f32 v4, v2
    vf.mul       v2, v3, v4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v3, [s1, v7]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v4, v0
    vf.cvt.f16.f32 v0, v3
    s.ld.d       s1, [s2, #40]                   // out_ptr1: device_ptr64 at arg_base+40
    vf.mul       v3, v4, v0
    vf.add       v0, v2, v3
    s.ld.d       s3, [s2, #32]                   // out_ptr0: device_ptr64 at arg_base+32
    s.add        s2, s1, s4                      // &out_ptr1[...]
    vf.cvt.f32.f16 v2, v0
    @p2 v.st.scatter.h [s3, v1], v2
    @p2 v.st.h       [s2, #0], v2
__rctx_next:
    exit
