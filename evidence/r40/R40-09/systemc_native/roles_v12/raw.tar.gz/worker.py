from pathlib import Path
import subprocess,json,shutil,hashlib,sys
p=Path(__file__).resolve().parent
src=p/'source/tools/performance_harness/systemc'
prefix=Path.home()/'tc_env/systemc-3.0.2/install'
def build(source,out):
 subprocess.run(['cmake','-S',str(source),'-B',str(out),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix)],check=True)
 subprocess.run(['cmake','--build',str(out),'--target','tnca-chip','--parallel','4'],check=True)
build(src,p/'build')
subprocess.run([sys.executable,str(src/'validate_chip.py'),'--binary',str(p/'build/tnca-chip'),'--out',str(p/'chip-validation')],check=True)
shutil.copytree(p/'source',p/'mutant-source')
f=p/'mutant-source/tools/performance_harness/systemc/src/chip.cpp'
s=f.read_text();old='for(auto& t:f.sr)ready(t);\n                    for(auto& t:f.vr)ready(t);\n                    f.physical->commit(sc_time_stamp());\n                    barriers[a].arrive();'
assert s.count(old)==1
f.write_text(s.replace(old,'barriers[a].arrive();'))
(p/'mutation.json').write_text(json.dumps(dict(kind='early-arrive',source_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),scope='removed release writeback wait only; independent source clone'),indent=2))
build(p/'mutant-source/tools/performance_harness/systemc',p/'mutant-build')
subprocess.run([sys.executable,str(src/'validate_roles.py'),'--binary',str(p/'build/tnca-chip'),'--out',str(p/'role-validation'),'--early-arrive-mutant',str(p/'mutant-build/tnca-chip'),'--early-arrive-source',str(f)],check=True)
